//line j2g_strings.ae:1
package aot_arbace_j2g_decls

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.j2g.modelyn1,myn16,arbace.j2g.namesyn2,nmyn14,arbace.j2g.jrtyn3,jrtyn15,arbace.j2g.codeyn1,cyn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn3,tagkn3,pkgkn5,classkn5,fn-idkn7,targetskn9,try-framekn8,capturedkn5,nameskn5,takenkn4,usedkn7,counterkn10,label-usedyn5,panicyn3,letyn2,doyn6,returnyn2,ifkn4,anonkn5,localkn7,nestingkn2,idkn3,symkn8,captureskn5,statekn4,linekn6,memberks3,j2g4,linekn1,tkn4,thiskn6,statickn3,retkn10,method-retkn11,method-namekn4,namekn4,synckn5,flagskn9,method-fnkn6,paramsyn5,deferkn4,bodykn4,desckn6,fieldskn7,methodskn6,bodieskn5,superys6,atomic5,Int32ys6,atomic6,Uint64ys6,atomic6,Uint32ys6,atomic5,Int64ys6,atomic4,Boolys6,atomic7,Pointerkn15,outer-instance?kn4,typekn5,outerkn3,jrtkn4,elseyn4,thiskn4,kindkn10,cap-paramskn4,ctorkn9,enum-argskn9,anon-argskn1,xkn2,opkn1,bkn11,super-outerkn4,enumkn9,enum-bodykn11,enum-paramskn11,outer-paramkn17,super-outer-paramkn4,argskn20,super-outer-is-outerkn16,super-outer-pathkn7,derivedkn11,calls-superkn6,recordkn7,compactkn16,record-canonicalkn11,nested-callyn4,set!yn4,instkn4,callkn4,initkn8,prologuekn9,ctor-callkn10,componentskn12,ctor-call-fnyn1,*ys2,go6,methodys2,go4,funcyn4,addryn3,lityn4,convyn5,int32yn7,bit-xoryn5,int64yn2,>>yn6,uint64yn1,+yn4,whenyn2,==yn3,anyyn2,oryn2,!=yn5,otheryn6,assertyn3,andkn6,bridgekn9,bridge-ofkn7,specialkn11,enum-valueskn20,record-object-methodkn15,record-accessorkn9,componentkn4,exprks15,arbace.j2g.code2,gokn5,owneryn5,.Copykn12,enum-$valueskn12,enum-valueOfkn9,constantskn9,var-derefkn10,set-statickn10,get-statickn10,var-invokekn8,declarerkn5,fieldks15,arbace.j2g.code4,failkn5,funcskn15,analysis-failedkn7,defaultkn8,jrt-implkn6,objectyn3,Refyn15,GetClass__Classyn16,ToString__Stringyn8,Clone__Oyn12,CloneShallowys11,arbace.core5,derefyn12,.ClearHeaderkn8,promotedys2,go5,constkn3,valys2,go3,varyn7,recoveryn4,gotoyn8,continueyn11,fallthroughyn5,breakyn5,labelkn1,wkn3,stskn10,clj-constskn3,varkn2,nskn4,textkn6,clinityn3,notyn5,.Doneyn4,.Runyn2,okyn1,xyn6,valuesyn1,dyn3,dynyn14,.DynImplementsyn4,boolyn1,_yn1,vys3,j2g7,commentys2,go4,typeyn9,interfaceyn6,structyn10,j2g_headerv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.j2g.declsm2,R20,s410,j2g's declarations (J2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (j2g_classes).v11,arbace.core13,*loaded-libs*v11,arbace.core9,with-metaR21,v16,arbace.j2g.model4,has?v16,arbace.j2g.model7,go-typev11,arbace.core3,vecv11,arbace.core3,mapv16,arbace.j2g.decls3,tagv16,arbace.j2g.decls2,gtv16,arbace.j2g.decls11,result-metav11,arbace.core9,vary-metav11,arbace.core5,assocv11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core3,seqv11,arbace.core5,firstv11,arbace.core5,mergeR22,R23,R24,v11,arbace.core6,gensymR25,R26,R27,R28,v11,arbace.core4,atomR29,R30,R31,R32,v11,arbace.core4,intov16,arbace.j2g.names15,reserved-localsv11,arbace.core4,seq?R33,R34,v16,arbace.j2g.decls12,terminating?R35,R36,v11,arbace.core4,lastR37,v11,arbace.core3,notv11,arbace.core6,concatv11,arbace.core4,listR33,R33,v16,arbace.j2g.model7,jrt-symv13,arbace.string7,replacev16,arbace.j2g.model3,pkgv22,arbace.classes.analyze4,declS2,R38,R39,R40,v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendR41,v11,arbace.core6,symbolv16,arbace.j2g.names10,field-nameR42,v11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,restR43,R44,R45,R46,v16,arbace.j2g.decls11,member-lineR47,R48,R49,R50,R51,v15,arbace.j2g.code3,*f*v15,arbace.j2g.code10,with-blockv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv16,arbace.j2g.decls12,new-fn-statev15,arbace.j2g.code6,*line*R52,v16,arbace.j2g.decls15,captured-fieldsR53,R54,R55,v16,arbace.j2g.decls4,has?R56,i32,R57,v15,arbace.j2g.code11,binding-symR58,v15,arbace.j2g.code5,stmt!v15,arbace.j2g.code4,ret!v15,arbace.j2g.code4,csymv15,arbace.j2g.code5,emit!v15,arbace.j2g.code4,jsymR59,R60,v16,arbace.j2g.decls17,ensure-terminatedv11,arbace.core4,not=v16,arbace.j2g.model14,desc-in-world?R61,R62,v16,arbace.j2g.model15,mdesc-in-world?v22,arbace.classes.analyze14,ctor-real-descR63,R64,v11,arbace.core9,contains?v16,arbace.j2g.decls9,*reached*R65,v16,arbace.j2g.model9,class-symv15,arbace.j2g.code15,volatile-field?R66,R67,R68,v16,arbace.j2g.model13,pointer-desc?R66,R69,R70,R71,v11,arbace.core6,secondR72,v16,arbace.j2g.model9,in-world?S2,R38,R39,R73,R74,v22,arbace.classes.analyze10,this0-namev20,arbace.classes.types17,parse-method-descv16,arbace.j2g.decls8,with-retv16,arbace.j2g.names11,method-basev11,arbace.core11,map-indexedv11,arbace.core6,filterv16,arbace.j2g.model10,interface?v16,arbace.j2g.model14,all-supertypesv16,arbace.j2g.model7,go-namev11,arbace.core3,setv13,arbace.string12,starts-with?v11,arbace.core4,subsl3,v14,arbace.j2g.jrt14,struct-methodsR75,v16,arbace.j2g.model3,*w*v16,arbace.j2g.model11,translated?R76,v16,arbace.j2g.decls10,hw-markersv11,arbace.core6,removev16,arbace.j2g.decls17,interface-closurev16,arbace.j2g.model5,leaf?R5,R77,R78,v11,arbace.core4,somev16,arbace.j2g.decls9,ctor-descv16,arbace.j2g.names9,ctor-basev15,arbace.j2g.code8,operandsS2,R38,R39,R79,R80,R5,R77,R81,R82,S2,R38,R39,R83,v15,arbace.j2g.code9,local-valR84,R39,R85,v16,arbace.j2g.model19,method-desc-classesv15,arbace.j2g.code12,missing-exprR86,R87,R88,R89,R90,R91,R92,v11,arbace.core5,applyR5,V1,R77,R5,R93,R94,v11,arbace.core6,reducev15,arbace.j2g.code8,use-sym!v16,arbace.j2g.decls7,body-ofv16,arbace.j2g.decls8,reached?v15,arbace.j2g.code9,fresh-rawv11,arbace.core6,empty?S2,R38,R39,v11,arbace.core6,zipmapv16,arbace.j2g.decls9,stub-bodyR95,R96,R97,R98,R99,R100,v11,arbace.core6,vectorR101,R5,R102,R101,R5,R103,v16,arbace.j2g.decls20,ctor-call-translatorR104,R105,R106,m2,R61,s3,()VR5,R107,R101,R5,v11,arbace.core5,list*v16,arbace.j2g.decls7,at-lineR5,R5,R77,v11,arbace.core5,rangev16,arbace.j2g.names10,munge-nameR108,R5,R109,R110,v16,arbace.j2g.decls10,param-listR77,i1024,R111,v16,arbace.j2g.names8,new-nameR109,v16,arbace.j2g.model13,trivial-init?v16,arbace.j2g.model8,nest-topv16,arbace.j2g.decls11,code-class?R34,R5,R5,R112,R113,R5,V1,R5,v11,arbace.core3,strv11,arbace.core4,nil?R114,R115,R114,R115,R116,R114,R117,R118,l32,R114,R119,R114,R115,R116,R114,R117,R118,R114,R119,v15,arbace.j2g.code6,coerceR114,R115,R36,R120,R109,l31,R5,R114,R115,l0,p4,.*\\$v15,arbace.j2g.code10,string-litR5,R36,R121,R122,R114,R123,R5,R36,R121,R124,R122,R125,R36,R34,R126,R127,R109,R36,v11,arbace.core5,true?R5,R126,R122,R122,R122,R128,R5,R77,R129,R130,R131,v16,arbace.j2g.model13,hand-written?R132,R133,v16,arbace.j2g.decls18,record-object-bodyR134,R135,v20,arbace.classes.types4,ref?v18,arbace.classes.env11,assignable?v15,arbace.j2g.code8,cast-valR136,R137,R138,v16,arbace.j2g.names9,impl-nameR5,R5,R36,R36,R139,R140,R36,R5,R141,R36,R142,R36,R33,v11,arbace.core4,namev11,arbace.core9,volatile!v11,arbace.core4,map?v11,arbace.core4,run!v11,arbace.core7,vector?S4,R143,R144,R145,R146,v11,arbace.core7,vreset!R147,R148,v11,arbace.core4,valsv16,arbace.j2g.decls16,touches-statics?v16,arbace.j2g.model12,benign-init?v16,arbace.j2g.model16,superclass-chainv16,arbace.j2g.model7,static?v16,arbace.j2g.decls17,method-code-formsR5,R77,R5,R77,R149,v11,arbace.core7,ex-datav11,arbace.core7,ex-infoR33,i256,R150,V1,R5,R36,v16,arbace.j2g.decls12,derived-bodyR151,R111,v16,arbace.j2g.decls18,needs-entry-guard?R111,R77,R110,R5,R109,R110,R5,R109,R77,R152,R153,R5,R109,R5,R5,R5,R110,v16,arbace.j2g.model7,impl-ofR5,R109,V2,s8,toStrings20,()Ljava/lang/String;V2,s5,clones20,()Ljava/lang/Object;R154,R110,R155,R5,m2,R21,R123,R121,R122,R5,R36,v16,arbace.j2g.decls12,class-fieldsR110,R156,R109,R121,R125,R5,R36,R5,R110,R156,R109,R110,R157,R109,R5,R110,R158,m2,R21,R123,R5,R110,R159,m2,R21,R123,R34,R17,R160,R5,R161,R112,R17,R112,R17,R33,R5,S2,R162,R154,v16,arbace.j2g.decls9,forwarderR110,R5,R109,R33,S2,R162,R154,v16,arbace.j2g.decls13,class-methodsv16,arbace.j2g.model8,vmethodsv11,arbace.core4,sortv16,arbace.j2g.model11,object-keysv18,arbace.classes.env11,const-valuev16,arbace.j2g.names17,static-field-namev11,arbace.core5,some?v20,arbace.classes.types5,prim?v11,arbace.core5,char?v15,arbace.j2g.code9,float-litS2,s1,Fs1,Dv11,arbace.core7,string?i16,S2,s1,Fs1,DR163,R164,R165,R165,R165,v16,arbace.j2g.decls13,field-go-typeS2,s1,Fs1,DS2,s1,Fs1,Dv11,arbace.core5,coll?v11,arbace.core1,+v16,arbace.j2g.decls8,calls-inv11,arbace.core8,not-any?S8,R166,R167,R36,R168,R59,R169,R170,R171,v11,arbace.core7,symbol?v11,arbace.core8,tree-seqv16,arbace.j2g.decls17,clinit-part-callsv16,arbace.j2g.decls11,splittable?v11,arbace.core4,peekR172,R173,v11,arbace.core3,popv11,arbace.core4,mapvR111,R33,R174,R101,R175,R176,R177,R178,v16,arbace.j2g.decls12,split-clinitR165,R111,R121,R179,R180,R181,R111,R165,R109,R121,R128,R182,R183,R34,R184,R185,R186,R127,R183,R121,R186,R101,R182,R187,R185,R111,v16,arbace.j2g.names13,compiled-pkg?m2,R21,R188,R183,R123,R34,R182,R184,R189,R182,R127,R183,R121,R128,R179,R182,R125,R183,R183,R34,R184,R185,R186,R127,R183,R121,R186,R101,R182,R187,R185,R34,R182,R184,R189,R182,R127,R183,R111,R183,R123,R121,R122,R183,R36,R34,R190,R184,R190,R182,R127,R183,R121,R179,R182,R33,R183,R111,m2,R21,R188,R183,R123,R34,R182,R184,R189,R182,R127,R183,R111,R183,R123,R121,R122,R183,R36,R34,R190,R184,R190,R182,R127,R183,R121,R179,R182,R33,R183,v16,arbace.j2g.model4,infov16,arbace.j2g.model11,abstract-m?v16,arbace.j2g.model8,private?R77,R111,v16,arbace.j2g.decls14,instance-formsR191,R192,R193,v16,arbace.j2g.decls17,iface-method-elemv16,arbace.j2g.decls12,static-formsv16,arbace.j2g.decls16,clj-const-fieldsv16,arbace.j2g.decls10,init-formsv11,arbace.core6,mapcatR191,R192,R193,v16,arbace.j2g.decls11,code-iface?R110,R5,R109,R192,R194,v16,arbace.j2g.decls17,super-struct-typeR195,R119,v16,arbace.j2g.decls12,extra-fieldsR192,R193,v16,arbace.j2g.decls16,super-iface-typev16,arbace.j2g.model15,virtual-member?R109,R110,R5,R5,R109,R109,v16,arbace.j2g.decls7,markersv16,arbace.j2g.decls10,ctor-formsv16,arbace.j2g.decls12,method-formsv16,arbace.j2g.decls14,dispatch-formsv16,arbace.j2g.decls12,object-forms")

var Lit_1 *jrt.String = jrt.Intern("arbace.j2g.decls$at_line$fn__1464000041")

var Lit_2 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$iter__1464000028__1464000032")

var Lit_3 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$iter__1464000028__1464000032$fn__1464000033")

var Lit_4 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields$iter__1464000028__1464000032$fn__1464000033$fn__1464000034")

var Lit_5 *jrt.String = jrt.Intern(".-")

var Lit_6 *jrt.String = jrt.Intern("val$")

var Lit_7 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields$iter__1464000060__1464000064")

var Lit_8 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields$iter__1464000060__1464000064$fn__1464000065")

var Lit_9 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields$iter__1464000060__1464000064$fn__1464000065$fn__1464000066")

var Lit_10 *jrt.String = jrt.Intern("---- ")

var Lit_11 *jrt.String = jrt.Intern("/")

var Lit_12 *jrt.String = jrt.Intern(".")

var Lit_13 *jrt.String = jrt.Intern("Object_I")

var Lit_14 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000602__1464000606")

var Lit_15 *jrt.String = jrt.Intern("Is_")

var Lit_16 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000612__1464000616")

var Lit_17 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000622__1464000626")

var Lit_18 *jrt.String = jrt.Intern("_I")

var Lit_19 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000632__1464000636")

var Lit_20 *jrt.String = jrt.Intern("Self_")

var Lit_21 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000642__1464000646")

var Lit_22 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000652__1464000656")

var Lit_23 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000662")

var Lit_24 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000664")

var Lit_25 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000666")

var Lit_26 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$fn__1464000668")

var Lit_27 *jrt.String = jrt.Intern("<init>")

var Lit_28 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000602__1464000606$fn__1464000607")

var Lit_29 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000602__1464000606$fn__1464000607$fn__1464000608")

var Lit_30 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000612__1464000616$fn__1464000617")

var Lit_31 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000612__1464000616$fn__1464000617$fn__1464000618")

var Lit_32 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000622__1464000626$fn__1464000627")

var Lit_33 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000622__1464000626$fn__1464000627$fn__1464000628")

var Lit_34 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000632__1464000636$fn__1464000637")

var Lit_35 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000632__1464000636$fn__1464000637$fn__1464000638")

var Lit_36 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000642__1464000646$fn__1464000647")

var Lit_37 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000642__1464000646$fn__1464000647$fn__1464000648")

var Lit_38 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000652__1464000656$fn__1464000657")

var Lit_39 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms$iter__1464000652__1464000656$fn__1464000657$fn__1464000658")

var Lit_40 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods$iter__1464000071__1464000075")

var Lit_41 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods$iter__1464000071__1464000075$fn__1464000076")

var Lit_42 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods$iter__1464000071__1464000075$fn__1464000076$fn__1464000077")

var Lit_43 *jrt.String = jrt.Intern("<clinit>")

var Lit_44 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields$iter__1464000509__1464000513")

var Lit_45 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields$iter__1464000509__1464000513$fn__1464000514")

var Lit_46 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields$iter__1464000509__1464000513$fn__1464000514$fn__1464000515")

var Lit_47 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126")

var Lit_48 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$fn__1464000127")

var Lit_49 *jrt.String = jrt.Intern("constructor ")

var Lit_50 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_51 *jrt.String = jrt.Intern("V")

var Lit_52 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$iter__1464000132__1464000136")

var Lit_53 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_54 *jrt.String = jrt.Intern("superclass ")

var Lit_55 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$fn__1464000142")

var Lit_56 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$fn__1464000144")

var Lit_57 *jrt.String = jrt.Intern("L")

var Lit_58 *jrt.String = jrt.Intern(";")

var Lit_59 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$iter__1464000149__1464000153")

var Lit_60 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$iter__1464000132__1464000136$fn__1464000137")

var Lit_61 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$iter__1464000132__1464000136$fn__1464000137$fn__1464000138")

var Lit_62 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$iter__1464000149__1464000153$fn__1464000154")

var Lit_63 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator$fn__1464000126$iter__1464000149__1464000153$fn__1464000154$fn__1464000155")

var Lit_64 *jrt.String = jrt.Intern("this_0")

var Lit_65 *jrt.String = jrt.Intern("x0")

var Lit_66 *jrt.String = jrt.Intern("enumName")

var Lit_67 *jrt.String = jrt.Intern("enumOrdinal")

var Lit_68 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000165__1464000169")

var Lit_69 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000175__1464000179")

var Lit_70 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000185__1464000189")

var Lit_71 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000195")

var Lit_72 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000233__1464000237")

var Lit_73 *jrt.String = jrt.Intern("_Init")

var Lit_74 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000243")

var Lit_75 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000195$fn__1464000196")

var Lit_76 *jrt.String = jrt.Intern("NN")

var Lit_77 *jrt.String = jrt.Intern("J2g_NotNull")

var Lit_78 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$fn__1464000195$fn__1464000196$fn__1464000215")

var Lit_79 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000165__1464000169$fn__1464000170")

var Lit_80 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000165__1464000169$fn__1464000170$fn__1464000171")

var Lit_81 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000175__1464000179$fn__1464000180")

var Lit_82 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000175__1464000179$fn__1464000180$fn__1464000181")

var Lit_83 *jrt.String = jrt.Intern("a")

var Lit_84 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000185__1464000189$fn__1464000190")

var Lit_85 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000185__1464000189$fn__1464000190$fn__1464000191")

var Lit_86 *jrt.String = jrt.Intern("val_")

var Lit_87 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000233__1464000237$fn__1464000238")

var Lit_88 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms$iter__1464000233__1464000237$fn__1464000238$fn__1464000239")

var Lit_89 *jrt.String = jrt.Intern("p")

var Lit_90 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$fn__1464000272")

var Lit_91 *jrt.String = jrt.Intern(".Impl_")

var Lit_92 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_93 *jrt.String = jrt.Intern("__VALUES")

var Lit_94 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_95 *jrt.String = jrt.Intern("_class")

var Lit_96 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$iter__1464000274__1464000278")

var Lit_97 *jrt.String = jrt.Intern("_Cast")

var Lit_98 *jrt.String = jrt.Intern("Enum_ValueOf_Class_String__Enum")

var Lit_99 *jrt.String = jrt.Intern("J2g_NotTranslated")

var Lit_100 *jrt.String = jrt.Intern("derived ")

var Lit_101 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$iter__1464000274__1464000278$fn__1464000279")

var Lit_102 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body$iter__1464000274__1464000278$fn__1464000279$fn__1464000280")

var Lit_103 *jrt.String = jrt.Intern("_")

var Lit_104 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000371__1464000375")

var Lit_105 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385")

var Lit_106 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000429__1464000433")

var Lit_107 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000371__1464000375$fn__1464000376")

var Lit_108 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000371__1464000375$fn__1464000376$fn__1464000377")

var Lit_109 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386")

var Lit_110 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$fn__1464000387")

var Lit_111 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$iter__1464000417__1464000421")

var Lit_112 *jrt.String = jrt.Intern("abstract ")

var Lit_113 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$fn__1464000387$iter__1464000397__1464000401")

var Lit_114 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$fn__1464000387$iter__1464000397__1464000401$fn__1464000402")

var Lit_115 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$fn__1464000387$iter__1464000397__1464000401$fn__1464000402$fn__1464000403")

var Lit_116 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$iter__1464000417__1464000421$fn__1464000422")

var Lit_117 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000381__1464000385$fn__1464000386$iter__1464000417__1464000421$fn__1464000422$fn__1464000423")

var Lit_118 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000429__1464000433$fn__1464000434")

var Lit_119 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms$iter__1464000429__1464000433$fn__1464000434$fn__1464000435")

var Lit_120 *jrt.String = jrt.Intern("j2g: unreachable")

var Lit_121 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields$iter__1464000088__1464000092")

var Lit_122 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields$iter__1464000088__1464000092$fn__1464000093")

var Lit_123 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields$iter__1464000088__1464000092$fn__1464000093$fn__1464000094")

var Lit_124 *jrt.String = jrt.Intern("B")

var Lit_125 *jrt.String = jrt.Intern("C")

var Lit_126 *jrt.String = jrt.Intern("D")

var Lit_127 *jrt.String = jrt.Intern("F")

var Lit_128 *jrt.String = jrt.Intern("I")

var Lit_129 *jrt.String = jrt.Intern("J")

var Lit_130 *jrt.String = jrt.Intern("S")

var Lit_131 *jrt.String = jrt.Intern("Z")

var Lit_132 *jrt.String = jrt.Intern("Volatile")

var Lit_133 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder$iter__1464000355__1464000359")

var Lit_134 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder$iter__1464000355__1464000359$fn__1464000360")

var Lit_135 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder$iter__1464000355__1464000359$fn__1464000360$fn__1464000361")

var Lit_136 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers$iter__1464000109__1464000113")

var Lit_137 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers$iter__1464000109__1464000113$fn__1464000114")

var Lit_138 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers$iter__1464000109__1464000113$fn__1464000114$fn__1464000115")

var Lit_139 *jrt.String = jrt.Intern("arbace.j2g.decls$iface_method_elem$fn__1464000102")

var Lit_140 *jrt.String = jrt.Intern("()V")

var Lit_141 *jrt.String = jrt.Intern("arbace.j2g.decls$init_forms$fn__1464000484")

var Lit_142 *jrt.String = jrt.Intern("_init")

var Lit_143 *jrt.String = jrt.Intern("ClassInit")

var Lit_144 *jrt.String = jrt.Intern("_clinit")

var Lit_145 *jrt.String = jrt.Intern("arbace.j2g.decls$init_forms$fn__1464000484$fn__1464000485")

var Lit_146 *jrt.String = jrt.Intern(".<clinit>")

var Lit_147 *jrt.String = jrt.Intern("Clojure constant ")

var Lit_148 *jrt.String = jrt.Intern("#'")

var Lit_149 *jrt.String = jrt.Intern("IsDynamic")

var Lit_150 *jrt.String = jrt.Intern("Dynamic")

var Lit_151 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_152 *jrt.String = jrt.Intern("ClassCast")

var Lit_153 *jrt.String = jrt.Intern("arbace.j2g.decls$interface_closure$fn__1464000106")

var Lit_154 *jrt.String = jrt.Intern("arbace.j2g.decls$markers$fn__1464000121")

var Lit_155 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$iter__1464000047__1464000051")

var Lit_156 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$fn__1464000057")

var Lit_157 *jrt.String = jrt.Intern("MonitorEnter")

var Lit_158 *jrt.String = jrt.Intern("MonitorExit")

var Lit_159 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$iter__1464000047__1464000051$fn__1464000052")

var Lit_160 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms$iter__1464000047__1464000051$fn__1464000052$fn__1464000053")

var Lit_161 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000295__1464000299")

var Lit_162 *jrt.String = jrt.Intern("_native")

var Lit_163 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000305__1464000309")

var Lit_164 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000315__1464000319")

var Lit_165 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000325")

var Lit_166 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000337__1464000341")

var Lit_167 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000325$iter__1464000326__1464000330")

var Lit_168 *jrt.String = jrt.Intern(": ")

var Lit_169 *jrt.String = jrt.Intern("j2g: translating ")

var Lit_170 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000325$iter__1464000326__1464000330$fn__1464000331")

var Lit_171 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$fn__1464000325$iter__1464000326__1464000330$fn__1464000331$fn__1464000332")

var Lit_172 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000295__1464000299$fn__1464000300")

var Lit_173 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000295__1464000299$fn__1464000300$fn__1464000301")

var Lit_174 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000305__1464000309$fn__1464000310")

var Lit_175 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000305__1464000309$fn__1464000310$fn__1464000311")

var Lit_176 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000315__1464000319$fn__1464000320")

var Lit_177 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000315__1464000319$fn__1464000320$fn__1464000321")

var Lit_178 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000337__1464000341$fn__1464000342")

var Lit_179 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms$iter__1464000337__1464000341$fn__1464000342$fn__1464000343")

var Lit_180 *jrt.String = jrt.Intern("f")

var Lit_181 *jrt.String = jrt.Intern("Ljava/lang/Cloneable;")

var Lit_182 *jrt.String = jrt.Intern("arbace.j2g.decls$object_forms$fn__1464000368")

var Lit_183 *jrt.String = jrt.Intern("Class")

var Lit_184 *jrt.String = jrt.Intern("String")

var Lit_185 *jrt.String = jrt.Intern("Object_toString")

var Lit_186 *jrt.String = jrt.Intern("J2g_ObjectClone")

var Lit_187 *jrt.String = jrt.Intern("CloneNotSupported")

var Lit_188 *jrt.String = jrt.Intern("j2g$class")

var Lit_189 *jrt.String = jrt.Intern("arbace.j2g.decls$param_list$fn__1464000015")

var Lit_190 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$js__1464000246")

var Lit_191 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fld__1464000248")

var Lit_192 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$hash__1464000250")

var Lit_193 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$strof__1464000253")

var Lit_194 *jrt.String = jrt.Intern("hashCode")

var Lit_195 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fn__1464000257")

var Lit_196 *jrt.String = jrt.Intern("toString")

var Lit_197 *jrt.String = jrt.Intern("")

var Lit_198 *jrt.String = jrt.Intern("[")

var Lit_199 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fn__1464000259")

var Lit_200 *jrt.String = jrt.Intern("]")

var Lit_201 *jrt.String = jrt.Intern("Concat")

var Lit_202 *jrt.String = jrt.Intern("equals")

var Lit_203 *jrt.String = jrt.Intern("GetClass")

var Lit_204 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body$fn__1464000261")

var Lit_205 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_206 *jrt.String = jrt.Intern("=")

var Lit_207 *jrt.String = jrt.Intern(", ")

var Lit_208 *jrt.String = jrt.Intern("J2g_DoubleBits")

var Lit_209 *jrt.String = jrt.Intern("J2g_FloatBits")

var Lit_210 *jrt.String = jrt.Intern("J2g_ObjEquals")

var Lit_211 *jrt.String = jrt.Intern("J2g_BoolHash")

var Lit_212 *jrt.String = jrt.Intern("J2g_ObjHash")

var Lit_213 *jrt.String = jrt.Intern("StrOfInt")

var Lit_214 *jrt.String = jrt.Intern("StrOfChar")

var Lit_215 *jrt.String = jrt.Intern("StrOfDouble")

var Lit_216 *jrt.String = jrt.Intern("StrOfFloat")

var Lit_217 *jrt.String = jrt.Intern("StrOfLong")

var Lit_218 *jrt.String = jrt.Intern("StrOfBool")

var Lit_219 *jrt.String = jrt.Intern("StrOfObj")

var Lit_220 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000531__1464000535")

var Lit_221 *jrt.String = jrt.Intern(" (declared from reflection)")

var Lit_222 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000541__1464000545")

var Lit_223 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000551__1464000555")

var Lit_224 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565")

var Lit_225 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000531__1464000535$fn__1464000536")

var Lit_226 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000531__1464000535$fn__1464000536$fn__1464000537")

var Lit_227 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000541__1464000545$fn__1464000546")

var Lit_228 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000541__1464000545$fn__1464000546$fn__1464000547")

var Lit_229 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000551__1464000555$fn__1464000556")

var Lit_230 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000551__1464000555$fn__1464000556$fn__1464000557")

var Lit_231 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566")

var Lit_232 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$fn__1464000567")

var Lit_233 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$iter__1464000585__1464000589")

var Lit_234 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$fn__1464000567$iter__1464000571__1464000575")

var Lit_235 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$fn__1464000567$iter__1464000571__1464000575$fn__1464000576")

var Lit_236 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$fn__1464000567$iter__1464000571__1464000575$fn__1464000576$fn__1464000577")

var Lit_237 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$iter__1464000585__1464000589$fn__1464000590")

var Lit_238 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms$iter__1464000561__1464000565$fn__1464000566$iter__1464000585__1464000589$fn__1464000590$fn__1464000591")

var Lit_239 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$fn__1464000463")

var Lit_240 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$iter__1464000465__1464000469")

var Lit_241 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$fn__1464000476")

var Lit_242 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$iter__1464000465__1464000469$fn__1464000470")

var Lit_243 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit$iter__1464000465__1464000469$fn__1464000470$fn__1464000471")

var Lit_244 *jrt.String = jrt.Intern("_clinit_p")

var Lit_245 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444")

var Lit_246 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444$fn__1464000445")

var Lit_247 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444$fn__1464000445$fn__1464000446")

var Lit_248 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444$fn__1464000445$fn__1464000454")

var Lit_249 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444$fn__1464000445$fn__1464000456")

var Lit_250 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444$fn__1464000445$fn__1464000446$fn__1464000448")

var Lit_251 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms$iter__1464000440__1464000444$fn__1464000445$fn__1464000446$fn__1464000450")

var Lit_252 *jrt.String = jrt.Intern("Object")

var Lit_253 *jrt.String = jrt.Intern("arbace.j2g.decls$touches_statics_QMARK_$w__1464000285")

var Lit_254 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn3,symyn4,typeyn5,flagsyn1,fyn3,pkgyn1,dyn5,descsyn4,symsyn1,ryn1,vyn1,nyn1,&kn2,asyn4,moreyn5,formsyn11,has-resultsyn4,nameyn4,descyn4,tsymyn1,myn2,abkn4,keysyn1,tyn4,thisyn6,staticyn2,mmyn5,superyn4,infoyn2,psyn7,classesyn1,kyn4,implyn4,bodyyn1,gv11,arbace.core5,in-nsMyn16,arbace.j2g.declsm2,R0,s410,j2g's declarations (J2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (j2g_classes).m2,R0,s410,j2g's declarations (J2G-SPEC §4.5, §5, §6, §7.11-§7.13): what a translated class becomes in\n  Go forms: its struct or interface, class interface C_I and accessor Self_C (non-leaf\n  classes), markers, method implementations, dispatch methods and forwarders, constructors,\n  statics and lazy class initialization, the Object protocol, instanceof and cast, and its\n  registration with member tables (j2g_classes).R1,v16,arbace.j2g.decls9,*reached*m10,R2,TR3,i17,R4,i1,R5,s19,arbace/j2g/decls.aeR0,s49,The set of reached method keys [class name desc].v16,arbace.j2g.decls3,tagm10,R6,TR7,L1,V2,R8,R9,R3,i19,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls4,has?m10,R6,TR7,L1,V2,R10,R11,R3,i21,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls2,gtm8,R7,L1,V2,R12,R13,R3,i23,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,param-listm12,R6,TR7,L1,V3,R12,R14,R15,R0,s105,Go parameter symbols tagged with the Go types of descs, named after the analyzer's\n  bindings when given.R3,i25,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,result-metam10,R6,TR7,L1,V2,R12,R16,R3,i31,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls8,with-retm10,R6,TR7,L1,V3,R17,R12,R16,R3,i33,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,new-fn-statem8,R7,L1,V4,R12,R18,R19,m2,R20,R21,R3,i35,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,terminating?m10,R7,L1,V1,R11,R0,s164,Is Go form f a terminating statement (Go spec, \"Terminating statements\"): a return or\n  panic, a block (let, do) ending in one, an if whose two branches end in one?R3,i42,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,ensure-terminatedm10,R7,L1,V2,R22,R23,R0,s107,Go needs a terminating statement in a function with results: a final panic when the last\n  form is not one.R3,i53,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls9,stub-bodym8,R7,L1,V3,R18,R24,R25,R3,i61,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls15,captured-fieldsm12,R6,TR7,L1,V2,R18,R26,R0,s125,binding id -> Go form reading the captured local from the class's field (local and\n  anonymous classes), for code of class n.R3,i65,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,member-linem10,R7,L1,V1,R27,R0,s75,The Java forms line of method or constructor m (its member form's), or nil.R3,i75,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls7,at-linem12,R6,TR7,L1,V2,R27,R22,R0,s60,Declaration forms with the line of member m (J2G-SPEC §4.3).R3,i80,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,method-code-formsm12,R6,TR7,L1,V5,R12,R18,R27,R28,m2,R29,V3,R30,R31,R32,R0,s67,The Go statements of method m's body (analyzed body ab) of class n.R3,i87,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,class-fieldsm8,R7,L1,V1,R18,R3,i113,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls13,class-methodsm10,R7,L1,V1,R18,R0,s78,The methods of translated class n that exist in Go (descriptors in the world).R3,i118,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls7,body-ofm10,R6,TR7,L1,V2,R18,R33,R3,i128,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls8,reached?m8,R7,L1,V2,R18,R33,R3,i130,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,code-class?v16,arbace.j2g.model11,code-class?m6,R3,i135,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,code-iface?v16,arbace.j2g.model11,code-iface?m6,R3,i137,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,super-struct-typem10,R7,L1,V2,R12,R18,R0,s84,The Go struct type a class embeds: its superclass's struct (jrt.Object at the root).R3,i139,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls16,super-iface-typem8,R7,L1,V2,R12,R18,R3,i147,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls13,field-go-typem10,R7,L1,V2,R12,R11,R0,s57,The Go type of a field, atomic for a volatile one (§8.2).R3,i153,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,extra-fieldsm12,R6,TR7,L1,V2,R12,R18,R0,s85,The outer instance and captured locals' fields of an inner, local or anonymous class.R3,i166,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,iface-method-elemm8,R7,L1,V2,R12,R33,R3,i177,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,interface-closurem10,R7,L1,V1,R18,R0,s103,The interfaces a class or interface n implements (directly and through its supertypes),\n  in the world.R3,i182,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,hw-markersm10,R7,L1,V1,R34,R0,s66,The Is_ markers jrt's hand-written struct (and its ancestors) has.R3,i188,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls7,markersm10,R7,L1,V1,R18,R0,s109,The interfaces whose marker class n's struct declares: those not already marked by its\n  superclass's struct.R3,i194,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls9,ctor-descm8,R7,L1,V2,R18,R33,R3,i207,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls20,ctor-call-translatorm12,R6,TR7,L1,V3,R12,R18,R35,R0,s159,Translates the constructor call node of a constructor of class n (super. or this.):\n  the superclass's or this class's constructor body on the embedded struct.R3,i209,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,ctor-formsm10,R7,L1,V3,R12,R18,R33,R0,s118,The allocation function C_New_... (concrete classes) and the constructor body Ctor_... of\n  constructor mm of class n.R3,i268,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls18,record-object-bodym12,R6,TR7,L1,V4,R12,R18,R33,R36,R0,s257,A record's derived toString, hashCode or equals, as java.lang.runtime.ObjectMethods makes\n  them: Name[c=v, ...]; 31 * h + the component's hash, in order; the same class and equal\n  components (wrapper compare for primitives, Objects.equals for references).R3,i356,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,derived-bodym10,R7,L1,V4,R12,R18,R33,R36,R0,s245,Go statements of a derived method (enum values/valueOf/$values, bridges, record members).\n  The code's names are qualified as package pkg sees them (a bridge's casts in arbace/lang name\n  jrt's classes: the suite's Java fixtures, ConcreteClass).R3,i413,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls16,touches-statics?m12,R6,TR7,L1,V2,R28,R37,R0,s147,Does analyzed code ab access a static field of a class in classes (directly: the guarded\n  accesses of other classes run their own initialization)?R3,i459,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls18,needs-entry-guard?m10,R7,L1,V2,R18,R28,R0,s360,Does static method mm of class n (body ab) start with n's initialization guard (§6.2)? Not\n  when the initialization is benign (unobservable but through n's statics, model/benign-init?)\n  and the body reads none of the statics of n and its superclasses: then delaying the\n  initialization to the first guarded access cannot be told apart (J2G-NOTES, phase 2D).R3,i478,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,method-formsm10,R7,L1,V3,R12,R18,R33,R0,s113,The Go method (instance) or function (static) of method mm of class n: its body when\n  reached, a stub otherwise.R3,i489,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls9,forwarderm12,R6,TR7,L1,V4,R12,R18,V4,R24,R25,R20,R38,R39,R0,s85,A dispatch method of concrete class n for virtual method k: calls the implementation.R3,i557,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,object-formsm10,R7,L1,V2,R12,R18,R0,s90,Ref, GetClass__Class, ToString__String, Clone__O, CloneShallow of concrete class n (§5.8).R3,i572,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls14,dispatch-formsm10,R7,L1,V2,R12,R18,R0,s63,The dispatch methods and forwarders of concrete class n (§5.4).R3,i602,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,static-formsm8,R7,L1,V2,R12,R18,R3,i627,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls17,clinit-part-callsl48,m8,R3,i648,R4,i1,R5,s19,arbace/j2g/decls.aeR0,s75,The calls a part of a long static initializer holds at most (split-clinit).v16,arbace.j2g.decls8,calls-inm12,R6,TR7,L1,V1,R11,R0,s31,The calls (lists) in Go form f.R3,i652,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,splittable?m12,R6,TR7,L1,V1,R40,R0,s177,Can the statements of body run as consecutive functions of their own? Not when one leaves\n  the function or the block (return, goto, defer, a label's break), whatever its depth.R3,i657,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls12,split-clinitm10,R7,L1,V2,R41,R40,R0,s560,A long static initializer's statements (body) in parts of at most clinit-part-calls calls,\n  each the body of a function of its own, the initializer calling them in order: [calls parts]\n  (amendment SA153). gc's stack maps of one function are about its safepoints times its stack\n  slots, so a class's thousands of constants in one function made megabytes of them (and most\n  of gc's time); in parts they grow with the code. A statement declaring locals (a let) holds\n  the rest of the block, so it ends the last part; a body that may leave early is not split.R3,i664,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls10,init-formsm10,R7,L1,V2,R12,R18,R0,s78,C_init, C_Init and C_clinit of a class with non-trivial initialization (§6.2).R3,i686,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls16,clj-const-fieldsm8,R7,L1,V2,R12,R18,R3,i717,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls14,instance-formsm10,R7,L1,V2,R12,R18,R0,s31,C_InstanceOf and C_Cast (§5.7).R3,i724,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls15,reflected-formsm10,R7,L1,V1,R18,R0,s194,A JDK interface declared from reflection (no Java forms): its Go interface with the\n  methods in the world, its default and static methods as stubs (no code to translate), and\n  instanceof/cast.R3,i765,R4,i1,R5,s19,arbace/j2g/decls.aev16,arbace.j2g.decls11,class-formsm10,R7,L1,V1,R18,R0,s62,All Go forms of translated class n (in package pkg), in order.R3,i796,R4,i1,R5,s19,arbace/j2g/decls.ae")

var Lit_255 *jrt.String = jrt.Intern("arbace.j2g.decls$eval1464000004$loading__1927001464__auto____1464000005")

var Lit_256 *jrt.String = jrt.Intern("arbace.j2g.decls$eval1464000008$fn__1464000009")

var Lit_257 *jrt.String = jrt.Intern("arbace.j2g.decls$tag")

var Lit_258 *jrt.String = jrt.Intern("arbace.j2g.decls$has_QMARK_")

var Lit_259 *jrt.String = jrt.Intern("arbace.j2g.decls$gt")

var Lit_260 *jrt.String = jrt.Intern("arbace.j2g.decls$param_list")

var Lit_261 *jrt.String = jrt.Intern("arbace.j2g.decls$result_meta")

var Lit_262 *jrt.String = jrt.Intern("arbace.j2g.decls$with_ret")

var Lit_263 *jrt.String = jrt.Intern("arbace.j2g.decls$new_fn_state")

var Lit_264 *jrt.String = jrt.Intern("arbace.j2g.decls$terminating_QMARK_")

var Lit_265 *jrt.String = jrt.Intern("arbace.j2g.decls$ensure_terminated")

var Lit_266 *jrt.String = jrt.Intern("arbace.j2g.decls$stub_body")

var Lit_267 *jrt.String = jrt.Intern("arbace.j2g.decls$captured_fields")

var Lit_268 *jrt.String = jrt.Intern("arbace.j2g.decls$member_line")

var Lit_269 *jrt.String = jrt.Intern("arbace.j2g.decls$at_line")

var Lit_270 *jrt.String = jrt.Intern("arbace.j2g.decls$method_code_forms")

var Lit_271 *jrt.String = jrt.Intern("arbace.j2g.decls$class_fields")

var Lit_272 *jrt.String = jrt.Intern("arbace.j2g.decls$class_methods")

var Lit_273 *jrt.String = jrt.Intern("arbace.j2g.decls$body_of")

var Lit_274 *jrt.String = jrt.Intern("arbace.j2g.decls$reached_QMARK_")

var Lit_275 *jrt.String = jrt.Intern("arbace.j2g.decls$super_struct_type")

var Lit_276 *jrt.String = jrt.Intern("arbace.j2g.decls$super_iface_type")

var Lit_277 *jrt.String = jrt.Intern("arbace.j2g.decls$field_go_type")

var Lit_278 *jrt.String = jrt.Intern("arbace.j2g.decls$extra_fields")

var Lit_279 *jrt.String = jrt.Intern("arbace.j2g.decls$iface_method_elem")

var Lit_280 *jrt.String = jrt.Intern("arbace.j2g.decls$interface_closure")

var Lit_281 *jrt.String = jrt.Intern("arbace.j2g.decls$hw_markers")

var Lit_282 *jrt.String = jrt.Intern("arbace.j2g.decls$markers")

var Lit_283 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_desc")

var Lit_284 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_call_translator")

var Lit_285 *jrt.String = jrt.Intern("arbace.j2g.decls$ctor_forms")

var Lit_286 *jrt.String = jrt.Intern("arbace.j2g.decls$record_object_body")

var Lit_287 *jrt.String = jrt.Intern("arbace.j2g.decls$derived_body")

var Lit_288 *jrt.String = jrt.Intern("arbace.j2g.decls$touches_statics_QMARK_")

var Lit_289 *jrt.String = jrt.Intern("arbace.j2g.decls$needs_entry_guard_QMARK_")

var Lit_290 *jrt.String = jrt.Intern("arbace.j2g.decls$method_forms")

var Lit_291 *jrt.String = jrt.Intern("arbace.j2g.decls$forwarder")

var Lit_292 *jrt.String = jrt.Intern("arbace.j2g.decls$object_forms")

var Lit_293 *jrt.String = jrt.Intern("arbace.j2g.decls$dispatch_forms")

var Lit_294 *jrt.String = jrt.Intern("arbace.j2g.decls$static_forms")

var Lit_295 *jrt.String = jrt.Intern("arbace.j2g.decls$calls_in")

var Lit_296 *jrt.String = jrt.Intern("arbace.j2g.decls$splittable_QMARK_")

var Lit_297 *jrt.String = jrt.Intern("arbace.j2g.decls$split_clinit")

var Lit_298 *jrt.String = jrt.Intern("arbace.j2g.decls$init_forms")

var Lit_299 *jrt.String = jrt.Intern("arbace.j2g.decls$clj_const_fields")

var Lit_300 *jrt.String = jrt.Intern("arbace.j2g.decls$instance_forms")

var Lit_301 *jrt.String = jrt.Intern("arbace.j2g.decls$reflected_forms")

var Lit_302 *jrt.String = jrt.Intern("arbace.j2g.decls$class_forms")
