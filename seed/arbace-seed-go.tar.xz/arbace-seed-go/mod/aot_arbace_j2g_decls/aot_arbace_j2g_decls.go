//line aot_arbace_j2g_decls.ae:1
package aot_arbace_j2g_decls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_New() *A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_decls_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_2); tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_3, A_arbace_j2g_decls_A_const_4, A_arbace_j2g_decls_A_const_5, A_arbace_j2g_decls_A_const_6, A_arbace_j2g_decls_A_const_7, A_arbace_j2g_decls_A_const_8, A_arbace_j2g_decls_A_const_9, A_arbace_j2g_decls_A_const_10, A_arbace_j2g_decls_A_const_11); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_New() *A_arbace_j2g_decls_eval1464000008_fn__1464000009_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_eval1464000008_fn__1464000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000008_fn__1464000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000008_fn__1464000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_16), A_arbace_j2g_decls_A_const_14.GetRawRoot__O(), A_arbace_j2g_decls_A_const_15) }

















func A_arbace_j2g_decls_tag_A_New() *A_arbace_j2g_decls_tag_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_tag_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_decls_tag_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_decls_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(sym__0, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_18, type__1))) }

func A_arbace_j2g_decls_has_QMARK__A_New() *A_arbace_j2g_decls_has_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_has_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_j2g_decls_has_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_j2g_decls_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_19.GetRawRoot__O()).Invoke_O_O__O(flags__0, f__1) }

func A_arbace_j2g_decls_gt_A_New() *A_arbace_j2g_decls_gt_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_gt_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_decls_gt_A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_decls_gt_A) Invoke_O_O_O__O(self, pkg__0, d__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_20.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__1) }

func A_arbace_j2g_decls_param_list_A_New() *A_arbace_j2g_decls_param_list_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_param_list_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_decls_param_list_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_decls_param_list_A) Invoke_O_O_O_O__O(self, pkg__0, descs__1, syms__2 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_param_list_fn__1464000015_A_New_O(pkg__0); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_decls_param_list_fn__1464000015_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_203, false); A_arbace_j2g_decls_param_list_fn__1464000015_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), descs__1, syms__2)) }
//line :29:1
func A_arbace_j2g_decls_param_list_fn__1464000015_A_New_O(p0 any) *A_arbace_j2g_decls_param_list_fn__1464000015_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_param_list_fn__1464000015_A{}; t.Ctor_O(p0); return t }
//line :29:1
func (t *A_arbace_j2g_decls_param_list_fn__1464000015_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :29:1
func (t *A_arbace_j2g_decls_param_list_fn__1464000015_A) Invoke_O_O_O__O(self, d__1, s__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, d__1)) }

func A_arbace_j2g_decls_result_meta_A_New() *A_arbace_j2g_decls_result_meta_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_result_meta_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_j2g_decls_result_meta_A) Ctor() {}
//line :31:1
func (t *A_arbace_j2g_decls_result_meta_A) Invoke_O_O_O__O(self, pkg__0, r__1 any) any { if lang.Util_Equiv_O_O__Z_NoInit(r__1, Lit_62) { return nil } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, r__1) } }

func A_arbace_j2g_decls_with_ret_A_New() *A_arbace_j2g_decls_with_ret_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_with_ret_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_decls_with_ret_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_decls_with_ret_A) Invoke_O_O_O_O__O(self, v__0, pkg__1, r__2 any) any { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_25.GetRawRoot__O()).Invoke_O_O__O(pkg__1, r__2); if jrt.J2g_Truth(temp__1927000408__auto____4) { var g__5 any = temp__1927000408__auto____4; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_26.GetRawRoot__O()).Invoke_O_O_O_O__O(v__0, A_arbace_j2g_decls_A_const_27.GetRawRoot__O(), A_arbace_j2g_decls_A_const_18, g__5) } else { return v__0 } }

func A_arbace_j2g_decls_new_fn_state_A_New() *A_arbace_j2g_decls_new_fn_state_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_new_fn_state_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_decls_new_fn_state_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_decls_new_fn_state_A) DoInvoke_O_O_O_O__O(self, pkg__0, n__1, p__1464000020__2 any) any { var map__1464000021__4 any = p__1464000020__2; var map__1464000021__5 any; if lang.ISeq_InstanceOf(map__1464000021__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000021__4)) { map__1464000021__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000021__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000021__4)) { map__1464000021__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000021__4) } else { map__1464000021__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000021__5 = map__1464000021__4 }; var more__6 any = map__1464000021__5; var tmp1 any = A_arbace_j2g_decls_A_const_33; var tmp2 any = A_arbace_j2g_decls_A_const_34; var tmp3 any = A_arbace_j2g_decls_A_const_35; var tmp4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_194); var tmp5 any = A_arbace_j2g_decls_A_const_37; var tmp6 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp7 any = A_arbace_j2g_decls_A_const_38; var tmp8 any = A_arbace_j2g_decls_A_const_39; var tmp9 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp10 any = A_arbace_j2g_decls_A_const_40; var tmp11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp12 any = A_arbace_j2g_decls_A_const_42; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_46.GetRawRoot__O()); var tmp14 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp15 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()).Invoke_O__O(tmp13.Invoke_O_O__O(tmp14, A_arbace_j2g_decls_A_const_47.GetRawRoot__O())); var tmp16 any = A_arbace_j2g_decls_A_const_43; var tmp17 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.PersistentHashSet_EMPTY.Ref()); var tmp18 any = A_arbace_j2g_decls_A_const_44; var tmp19 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()); var tmp20 any = A_arbace_j2g_decls_A_const_45; return /*line :37:1*/ lang.IFn_Cast(A_arbace_j2g_decls_A_const_32.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, pkg__0, tmp2, n__1, tmp3, tmp4, tmp5, tmp6, tmp7, nil, tmp8, tmp9, tmp10, tmp11, tmp12, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()).Invoke_O__O(lang.PersistentHashSet_EMPTY.Ref()))), more__6) }




func A_arbace_j2g_decls_terminating_QMARK__A_New() *A_arbace_j2g_decls_terminating_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_terminating_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_j2g_decls_terminating_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_j2g_decls_terminating_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0); if



	jrt.J2g_Truth(and__1927000168__auto____2) { var G__1464000024__3_ any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)
		switch lang.Util_Hash_O__I_NoInit(G__1464000024__3_) >> 2 & 7 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000024__3_, A_arbace_j2g_decls_A_const_49) { return jrt.Boolean_TRUE.Ref() }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000024__3_, A_arbace_j2g_decls_A_const_50) {

			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_54.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :47:1
		case 4: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000024__3_, A_arbace_j2g_decls_A_const_52) {

			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_54.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :47:1
		case 5: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000024__3_, A_arbace_j2g_decls_A_const_53) { return jrt.Boolean_TRUE.Ref() }; case 7: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000024__3_, A_arbace_j2g_decls_A_const_55) { var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(4, int64(lang.RT_Count_O__I_NoInit(f__0)))


			if and__1927000168__auto____4 { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(f__0, lang.RT_IntCast_J__I_NoInit(2))); if jrt.J2g_Truth(and__1927000168__auto____5) { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O_NoInit(f__0, lang.RT_IntCast_J__I_NoInit(3))) } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } }
//line :47:1
		default:}; return jrt.Boolean_FALSE.Ref() } else {
//line :46:1
			return and__1927000168__auto____2 } }






func A_arbace_j2g_decls_ensure_terminated_A_New() *A_arbace_j2g_decls_ensure_terminated_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ensure_terminated_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_j2g_decls_ensure_terminated_A) Ctor() {}
//line :53:1
func (t *A_arbace_j2g_decls_ensure_terminated_A) Invoke_O_O_O__O(self, forms__0, has_results__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = has_results__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_54.GetRawRoot__O()).Invoke_O__O(forms__0))) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(forms__0, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_59, Lit_131))) } else {
//line :57:1
			return forms__0
		}
}

func A_arbace_j2g_decls_stub_body_A_New() *A_arbace_j2g_decls_stub_body_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_stub_body_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_decls_stub_body_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_decls_stub_body_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_60; return lang.Tuple_Create_O__IPersistentVector(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_63.GetRawRoot__O()).Invoke_O__O(n__0), Lit_109), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_11, Lit_12), nil, name__1, desc__2)).Ref()))) }



func A_arbace_j2g_decls_captured_fields_A_New() *A_arbace_j2g_decls_captured_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_j2g_decls_captured_fields_A) Ctor() {}
//line :65:1
func (t *A_arbace_j2g_decls_captured_fields_A) Invoke_O_O_O__O(self, n__0, tsym__1 any) any { var d__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any; var and__1927000168__auto____4 any = d__3; if




	jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_65); tmp1 = tmp2.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__3)) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_46.GetRawRoot__O()); var tmp4 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp5 any; var iter__1927001039__auto____4 any; var tmp6 any = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_New_O(tsym__1); var tmp7 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_fn_class = fncls__5d; tmp7 = fncls__5d } else { tmp7 = fncls__5 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 *lang.Keyword = A_arbace_j2g_decls_A_const_80; tmp5 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__3)))); return tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
//line :70:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }
func A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_New_O(p0 any) *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A) Ctor_O(c__tsym any) { t.F_tsym = c__tsym }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A) Invoke_O_O__O(self, s__1464000029__1 any) any { var tmp1 any = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_New_O_O_O(t.F_tsym, s__1464000029__1, self); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :71:1
func A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A) Ctor_O_O_O(c__tsym, c__s__1464000029, c__iter__1464000028 any) { t.F_tsym = c__tsym; t.F_s__1464000029 = c__s__1464000029; t.F_iter__1464000028 = c__iter__1464000028 }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A) Invoke_O__O(self any) any { { var s__1464000029__1 any; var t_ any = t.F_s__1464000029; t.F_s__1464000029 = nil; s__1464000029__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000029__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000029__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000029__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000029__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000031__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_New_O_O_I_O(t.F_tsym, b__1464000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000028); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000031__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000029__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000031__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000029__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000028); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__4), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__4))).Ref()))).Ref()), t.F_tsym)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000029__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :71:1
func A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A) Ctor_O_O_I_O(c__tsym, c__b__1464000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tsym = c__tsym; t.F_b__1464000031 = c__b__1464000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A) Invoke_O__O(self any) any { { var i__1464000030__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000030__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000031; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__2), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__2))).Ref()))).Ref()), t.F_tsym))); i__1464000030__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000030__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_member_line_A_New() *A_arbace_j2g_decls_member_line_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_member_line_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_j2g_decls_member_line_A) Ctor() {}
//line :75:1
func (t *A_arbace_j2g_decls_member_line_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_82; return tmp1.Invoke_O__O(A_arbace_j2g_decls_A_const_83.Invoke_O__O(m__0))
}
func A_arbace_j2g_decls_at_line_A_New() *A_arbace_j2g_decls_at_line_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_at_line_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_decls_at_line_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_decls_at_line_A) Invoke_O_O_O__O(self, m__0, forms__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_84.GetRawRoot__O()).Invoke_O__O(m__0); if


	jrt.J2g_Truth(temp__1927000408__auto____3) { var l__4 any = temp__1927000408__auto____3; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_at_line_fn__1464000041_A_New_O(l__4); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_decls_at_line_fn__1464000041_A_fn_class
		if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_j2g_decls_at_line_fn__1464000041_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), forms__1) } else {
//line :83:1
			return forms__1 } }
func A_arbace_j2g_decls_at_line_fn__1464000041_A_New_O(p0 any) *A_arbace_j2g_decls_at_line_fn__1464000041_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_at_line_fn__1464000041_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_j2g_decls_at_line_fn__1464000041_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :84:1
func (t *A_arbace_j2g_decls_at_line_fn__1464000041_A) Invoke_O_O__O(self, p1__1464000040_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(p1__1464000040_SHARP___1)) { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_26.GetRawRoot__O()).Invoke_O_O_O_O__O(p1__1464000040_SHARP___1, A_arbace_j2g_decls_A_const_27.GetRawRoot__O(), A_arbace_j2g_decls_A_const_85, t.F_l) } else { return p1__1464000040_SHARP___1 } }


func A_arbace_j2g_decls_method_code_forms_A_New() *A_arbace_j2g_decls_method_code_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_decls_method_code_forms_A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_decls_method_code_forms_A) Invoke_O_O_O_O_O_O__O(self, pkg__0, n__1, m__2, ab__3, p__1464000044__4 any) any { var map__1464000045__6 any = p__1464000044__4; var map__1464000045__7 any; if lang.ISeq_InstanceOf(map__1464000045__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000045__6)) { map__1464000045__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000045__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000045__6)) { map__1464000045__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000045__6) } else { map__1464000045__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000045__7 = map__1464000045__6 }; var t__8 any = lang.RT_Get_O_O__O_NoInit(map__1464000045__7, A_arbace_j2g_decls_A_const_86); var this__9 any = lang.RT_Get_O_O__O_NoInit(map__1464000045__7, A_arbace_j2g_decls_A_const_87); var static__10 any = lang.RT_Get_O_O__O_NoInit(map__1464000045__7, A_arbace_j2g_decls_A_const_88); var ret__11 any = A_arbace_j2g_decls_A_const_89.Invoke_O__O(m__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_88; var tmp6 any = A_arbace_j2g_decls_A_const_86; var tmp7 any = A_arbace_j2g_decls_A_const_87; var tmp8 any = A_arbace_j2g_decls_A_const_97; var tmp9 any = A_arbace_j2g_decls_A_const_39; var tmp10 any; if




	jrt.J2g_Truth(t__8) { tmp10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_98.GetRawRoot__O()).Invoke_O_O__O(n__1, t__8) } else { tmp10 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp11 any = tmp10; var tmp12 any = A_arbace_j2g_decls_A_const_99; var tmp13 any = /*line :91:1*/A_arbace_j2g_decls_A_const_100.Invoke_O__O(m__2); var tmp14 any = A_arbace_j2g_decls_A_const_101; var tmp15 any = tmp4.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(pkg__0, n__1, tmp5, static__10, tmp6, t__8, tmp7, this__9, tmp8, ret__11, tmp9, tmp11, tmp12, tmp13, tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(m__2), A_arbace_j2g_decls_A_const_104)); var tmp16 any = A_arbace_j2g_decls_A_const_96; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp15, tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_84.GetRawRoot__O()).Invoke_O__O(m__2))); var tmp17 any; tmp29 := /*line :87:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp18 *lang.Keyword = A_arbace_j2g_decls_A_const_35; var fid__14 any = tmp18.Invoke_O__O(A_arbace_j2g_decls_A_const_90.Get__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O())
		var tmp20 any = A_arbace_j2g_decls_A_const_90








		lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_90.Get__O(), A_arbace_j2g_decls_A_const_105, fid__14)))
//line :87:1
		tmp28 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var params__17 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____17 any; var tmp23 any = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_New(); var tmp24 *jrt.Class
			var fncls__9 /*line :87:1*/*jrt.Class = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_fn_class










			if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_fn_class = fncls__9d; tmp24 = fncls__9d } else { tmp24 = fncls__9 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(A_arbace_j2g_decls_A_const_107.Invoke_O__O(ab__3)); params__17 = tmp21.Invoke_O__O(tmp22)
//line :87:1
			var body__18 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_91.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_New_O_O_O_O_O_O_O(static__10, m__2, n__1, t__8, this__9, ret__11, ab__3); var tmp27 *jrt.Class
			var fncls__10 /*line :87:1*/*jrt.Class = A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_fn_class












			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_fn_class = fncls__10d; tmp27 = fncls__10d } else { tmp27 = fncls__10 }
//line :99:1
			body__18 = tmp25.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil))
//line :87:1
			tmp17 = lang.Tuple_Create_O_O__IPersistentVector(params__17, lang.IFn_Cast(A_arbace_j2g_decls_A_const_115.GetRawRoot__O()).Invoke_O_O__O(body__18, lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_62, ret__11))) }; return nil }()









		lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O()
//line :87:1
		if tmp28 != nil { panic(tmp28) } }; return nil }();



	lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if /*line :87:1*/ tmp29 != nil { panic(tmp29) }; return tmp17 }










func A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_New() *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A) Ctor() {}
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A) Invoke_O_O__O(self, s__1464000048__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_New_O_O(s__1464000048__1, self); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :98:1
func A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A) Ctor_O_O(c__s__1464000048, c__iter__1464000047 any) { t.F_s__1464000048 = c__s__1464000048; t.F_iter__1464000047 = c__iter__1464000047 }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A) Invoke_O__O(self any) any { { var s__1464000048__1 any; var t_ any = t.F_s__1464000048; t.F_s__1464000048 = nil; s__1464000048__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000048__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000048__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000048__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000048__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000050__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_New_O_I_O(b__1464000050__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000047); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000050__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000048__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000050__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000048__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000047); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000048__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :98:1
func A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A) Ctor_O_I_O(c__b__1464000050 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000050 = c__b__1464000050; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A) Invoke_O__O(self any) any { { var i__1464000049__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000049__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000049__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000050; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__2)); i__1464000049__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000049__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_j2g_decls_method_code_forms_fn__1464000057_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_fn__1464000057_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :100:1
func (t *A_arbace_j2g_decls_method_code_forms_fn__1464000057_A) Ctor_O_O_O_O_O_O_O(c__static, c__m, c__n, c__t, c__this, c__ret, c__ab any) { t.F_static = c__static; t.F_m = c__m; t.F_n = c__n; t.F_t = c__t; t.F_this = c__this; t.F_ret = c__ret; t.F_ab = c__ab }
//line :100:1
func (t *A_arbace_j2g_decls_method_code_forms_fn__1464000057_A) Invoke_O__O(self any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(t.F_m), A_arbace_j2g_decls_A_const_104)) { var lk__1 any
		if jrt.J2g_Truth(t.F_static) { lk__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_110.GetRawRoot__O()).Invoke_O_O__O(t.F_n, Lit_105) } else { var or__1927000174__auto____1 any = t.F_this; if jrt.J2g_Truth(or__1927000174__auto____1) { lk__1 = or__1927000174__auto____1 } else { lk__1 = t.F_t } }
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_167), lk__1))
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_113; lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_168), lk__1))) }
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, t.F_ret) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab)) } else {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_109.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab))
		}
}



func A_arbace_j2g_decls_class_fields_A_New() *A_arbace_j2g_decls_class_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_decls_class_fields_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_decls_class_fields_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_New(); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_fn_class; if
										fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_119; return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0))) }
//line :114:1
func A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_New() *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A) Ctor() {}
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A) Invoke_O_O__O(self, s__1464000061__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_New_O_O(s__1464000061__1, self); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A) Ctor_O_O(c__s__1464000061, c__iter__1464000060 any) { t.F_s__1464000061 = c__s__1464000061; t.F_iter__1464000060 = c__iter__1464000060 }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A) Invoke_O__O(self any) any { { var s__1464000061__1 any; var t_ any = t.F_s__1464000061; t.F_s__1464000061 = nil; s__1464000061__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000061__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000061__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000061__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000061__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000063__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_New_O_I_O(b__1464000063__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000060); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000063__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000061__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000063__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000061__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000060); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000061__3))) } else { s__1464000061__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000061__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A) Ctor_O_I_O(c__b__1464000063 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000063 = c__b__1464000063; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A) Invoke_O__O(self any) any { { var i__1464000062__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000062__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000062__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2))) { lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1464000063, f__2); i__1464000062__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000062__1); continue L1 } else { i__1464000062__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000062__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_class_methods_A_New() *A_arbace_j2g_decls_class_methods_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_decls_class_methods_A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_decls_class_methods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_fn_class; if


	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_122; return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0))) }
//line :121:1
func A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_New_O(p0 any) *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A) Invoke_O_O__O(self, s__1464000072__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_New_O_O_O(t.F_n, s__1464000072__1, self); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :121:1
func A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A) Ctor_O_O_O(c__n, c__s__1464000072, c__iter__1464000071 any) { t.F_n = c__n; t.F_s__1464000072 = c__s__1464000072; t.F_iter__1464000071 = c__iter__1464000071 }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A) Invoke_O__O(self any) any { { var s__1464000072__1 any; var t_ any = t.F_s__1464000072; t.F_s__1464000072 = nil; s__1464000072__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000072__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000072__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000072__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000074__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_New_O_O_I_O(t.F_n, b__1464000074__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_42, false); A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000071); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000074__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000072__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000074__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_43, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4))) { var tmp4 any

	if lang.Util_Equiv_O_O__Z_NoInit(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4)) {
		tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_121.GetRawRoot__O()).Invoke_O_O__O(t.F_n, mm__4)) } else {
			tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)) }
//line :121:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000071); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(mm__4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000072__3))) } else { s__1464000072__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); continue L1 } } else { s__1464000072__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :121:1
func A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A) Ctor_O_O_I_O(c__n, c__b__1464000074 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1464000074 = c__b__1464000074; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A) Invoke_O__O(self any) any { { var i__1464000073__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000073__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_43, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2))) { var tmp2 any

	if lang.Util_Equiv_O_O__Z_NoInit(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2)) {
		tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_121.GetRawRoot__O()).Invoke_O_O__O(t.F_n, mm__2)) } else {
			tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)) }
//line :121:1
	if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1464000074, mm__2); i__1464000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000073__1); continue L1 } else { i__1464000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000073__1); continue L1 } } else { i__1464000073__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000073__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_body_of_A_New() *A_arbace_j2g_decls_body_of_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_body_of_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_j2g_decls_body_of_A) Ctor() {}
//line :128:1
func (t *A_arbace_j2g_decls_body_of_A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_123; var tmp2 *lang.Keyword = A_arbace_j2g_decls_A_const_81; return lang.RT_Get_O_O__O_NoInit(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0)))), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__1), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1))) }

func A_arbace_j2g_decls_reached_QMARK__A_New() *A_arbace_j2g_decls_reached_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reached_QMARK__A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_j2g_decls_reached_QMARK__A) Ctor() {}
//line :130:1
func (t *A_arbace_j2g_decls_reached_QMARK__A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_125.Get__O(), lang.Tuple_Create_O_O_O__IPersistentVector(n__0, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__1), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1))) }








func A_arbace_j2g_decls_super_struct_type_A_New() *A_arbace_j2g_decls_super_struct_type_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_super_struct_type_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_decls_super_struct_type_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_decls_super_struct_type_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_126; var s__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp2 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(s__3, nil); if or__1927000174__auto____4 {



	tmp2 = or__1927000174__auto____4 } else { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(s__3, Lit_64) }; if tmp2 {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_265) } else {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(pkg__0, s__3) } }

func A_arbace_j2g_decls_super_iface_type_A_New() *A_arbace_j2g_decls_super_iface_type_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_super_iface_type_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_decls_super_iface_type_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_decls_super_iface_type_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_126; var s__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp2 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(s__3, nil); if or__1927000174__auto____4 {

	tmp2 = or__1927000174__auto____4 } else { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(s__3, Lit_64) }; if tmp2 {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_13) } else {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, s__3, Lit_18) } }

func A_arbace_j2g_decls_field_go_type_A_New() *A_arbace_j2g_decls_field_go_type_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_field_go_type_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_j2g_decls_field_go_type_A) Ctor() {}
//line :153:1
func (t *A_arbace_j2g_decls_field_go_type_A) Invoke_O_O_O__O(self, pkg__0, f__1 any) any { var d__3 any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__1); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_128.GetRawRoot__O()).Invoke_O__O(f__1)) { var G__1464000086__4_ any = d__3
		switch lang.Util_Hash_O__I_NoInit(G__1464000086__4_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_135) { return A_arbace_j2g_decls_A_const_129 }; case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_136) { return A_arbace_j2g_decls_A_const_129 }; case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_137) { return A_arbace_j2g_decls_A_const_130 }; case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_138) { return A_arbace_j2g_decls_A_const_131 }; case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_139) { return A_arbace_j2g_decls_A_const_133 }; case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_140) { return A_arbace_j2g_decls_A_const_134 }; case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_141) { return A_arbace_j2g_decls_A_const_129 }; case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000086__4_, Lit_142) { return A_arbace_j2g_decls_A_const_135 }; default:
		}

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_132.GetRawRoot__O()).Invoke_O__O(d__3)) { var g__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_136
			return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_137.GetRawRoot__O()).Invoke_O__O(g__5)) } else {
				return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_143), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__3)) } } else {
					return lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__3) } }

func A_arbace_j2g_decls_extra_fields_A_New() *A_arbace_j2g_decls_extra_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_j2g_decls_extra_fields_A) Ctor() {}
//line :166:1
func (t *A_arbace_j2g_decls_extra_fields_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var d__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp2 lang.IPersistentVector; var tmp3 any; var and__1927000168__auto____4 any = A_arbace_j2g_decls_A_const_138.Invoke_O__O(d__3); if




	jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_139.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_142.Invoke_O__O(d__3)) } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { tmp2 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_143.GetRawRoot__O()).Invoke_O__O(n__1))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_68, nil, Lit_69), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_142.Invoke_O__O(d__3), nil)).Ref()))) } else { tmp2 = nil }; var tmp4 any = tmp2; var tmp5 any; var tmp6 lang.IFn = /*line :170:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_140); if


	jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__3))) { var iter__1927001039__auto____4 any; var tmp7 any = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_New_O(pkg__0); var tmp8 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_fn_class
		if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_fn_class = fncls__20d; tmp8 = fncls__20d } else { tmp8 = fncls__20 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 *lang.Keyword = A_arbace_j2g_decls_A_const_80; tmp5 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__3)))) } else {
//line :173:1
			tmp5 = nil }; return /*line :170:1*/ tmp1.Invoke_O_O__O(tmp4, tmp5) }



func A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_New_O(p0 any) *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A) Invoke_O_O__O(self, s__1464000089__1 any) any { var tmp1 any = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_New_O_O_O(t.F_pkg, s__1464000089__1, self); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A) Ctor_O_O_O(c__pkg, c__s__1464000089, c__iter__1464000088 any) { t.F_pkg = c__pkg; t.F_s__1464000089 = c__s__1464000089; t.F_iter__1464000088 = c__iter__1464000088 }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A) Invoke_O__O(self any) any { { var s__1464000089__1 any; var t_ any = t.F_s__1464000089; t.F_s__1464000089 = nil; s__1464000089__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000089__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000089__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000089__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000091__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_New_O_O_I_O(t.F_pkg, b__1464000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000088); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000091__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000089__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000091__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000089__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__4))) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1464000088); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__4))).Ref())), tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__4))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000089__3))) } else { s__1464000089__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000089__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :174:1
func A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A) Ctor_O_O_I_O(c__pkg, c__b__1464000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg = c__pkg; t.F_b__1464000091 = c__b__1464000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A) Invoke_O__O(self any) any { { var i__1464000090__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000090__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000091; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__2))).Ref())), tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__2)))); i__1464000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000090__1); continue L1 } else { i__1464000090__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000090__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_iface_method_elem_A_New() *A_arbace_j2g_decls_iface_method_elem_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_iface_method_elem_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_decls_iface_method_elem_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_decls_iface_method_elem_A) Invoke_O_O_O__O(self, pkg__0, mm__1 any) any { var vec__1464000099__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1)); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000099__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000099__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__1), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1))); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_147.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_New_O(pkg__0); var tmp7 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_fn_class; if


	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_fn_class = fncls__21d; tmp7 = fncls__21d } else { tmp7 = fncls__21 }; return /*line :179:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), ps__4)), pkg__0, r__5)) }
func A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_New_O(p0 any) *A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :180:1
func (t *A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__1)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, p__2)) }

func A_arbace_j2g_decls_interface_closure_A_New() *A_arbace_j2g_decls_interface_closure_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_interface_closure_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_decls_interface_closure_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_decls_interface_closure_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_interface_closure_fn__1464000106_A_New_O(n__0); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_decls_interface_closure_fn__1464000106_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_j2g_decls_interface_closure_fn__1464000106_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_150.GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :186:1
func A_arbace_j2g_decls_interface_closure_fn__1464000106_A_New_O(p0 any) *A_arbace_j2g_decls_interface_closure_fn__1464000106_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_interface_closure_fn__1464000106_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_j2g_decls_interface_closure_fn__1464000106_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :186:1
func (t *A_arbace_j2g_decls_interface_closure_fn__1464000106_A) Invoke_O_O__O(self, p1__1464000105_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(p1__1464000105_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(p1__1464000105_SHARP___1, t.F_n) } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_decls_hw_markers_A_New() *A_arbace_j2g_decls_hw_markers_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_j2g_decls_hw_markers_A) Ctor() {}
//line :188:1
func (t *A_arbace_j2g_decls_hw_markers_A) Invoke_O_O__O(self, super__0 any) any { var g__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(super__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_fn_class; if



	fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_j2g_decls_A_const_157; tmp2 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_156.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O__O(A_arbace_j2g_decls_A_const_158.Get__O()), g__2)); return tmp1.Invoke_O__O(tmp2) }
//line :192:1
func A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_New() *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A) Invoke_O_O__O(self, s__1464000110__1 any) any { var tmp1 any = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_New_O_O(self, s__1464000110__1); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :192:1
func A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A) Ctor_O_O(c__iter__1464000109, c__s__1464000110 any) { t.F_iter__1464000109 = c__iter__1464000109; t.F_s__1464000110 = c__s__1464000110 }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A) Invoke_O__O(self any) any { { var s__1464000110__1 any; var t_ any = t.F_s__1464000110; t.F_s__1464000110 = nil; s__1464000110__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000110__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000110__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000110__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000110__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000112__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000112__6); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000109); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000112__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000110__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000112__6), nil) } } else { var mn__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000110__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_153.GetRawRoot__O()).Invoke_O_O__O(mn__4, Lit_15)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000109); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_154.GetRawRoot__O()).Invoke_O_O__O(mn__4, A_arbace_j2g_decls_A_const_155), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000110__3))) } else { s__1464000110__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000110__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :192:1
func A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000112 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000112 = c__b__1464000112 }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A) Invoke_O__O(self any) any { { var i__1464000111__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000111__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_153.GetRawRoot__O()).Invoke_O_O__O(mn__2, Lit_15)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000112; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_154.GetRawRoot__O()).Invoke_O_O__O(mn__2, A_arbace_j2g_decls_A_const_155)); i__1464000111__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000111__1); continue L1 } else { i__1464000111__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000111__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_markers_A_New() *A_arbace_j2g_decls_markers_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_markers_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_j2g_decls_markers_A) Ctor() {}
//line :194:1
func (t *A_arbace_j2g_decls_markers_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_126; var s__2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0)); var sup_marked__3 any; var tmp2 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z_NoInit(s__2, nil); if or__1927000174__auto____3 {




	tmp2 = or__1927000174__auto____3 } else { tmp2 = lang.Util_Equiv_O_O__Z_NoInit(s__2, Lit_64) }; if tmp2 { sup_marked__3 = lang.PersistentHashSet_EMPTY.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(s__2)) {
		sup_marked__3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_151.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(s__2))) } else {
//line :199:1
			if A_arbace_j2g_decls_A_const_160 != nil {

				sup_marked__3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_161.GetRawRoot__O()).Invoke_O__O(s__2) } else {
//line :199:1
					sup_marked__3 = nil } } }; var tmp3 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_markers_fn__1464000121_A_New_O(sup_marked__3); var tmp5 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_decls_markers_fn__1464000121_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_j2g_decls_markers_fn__1464000121_A_fn_class = fncls__26d; tmp5 = fncls__26d } else { tmp5 = fncls__26 }; return tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :202:1
func A_arbace_j2g_decls_markers_fn__1464000121_A_New_O(p0 any) *A_arbace_j2g_decls_markers_fn__1464000121_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_markers_fn__1464000121_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_j2g_decls_markers_fn__1464000121_A) Ctor_O(c__sup_marked any) { t.F_sup_marked = c__sup_marked }
//line :202:1
func (t *A_arbace_j2g_decls_markers_fn__1464000121_A) Invoke_O_O__O(self, p1__1464000120_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()); var tmp2 any = t.F_sup_marked; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(p1__1464000120_SHARP___1)) }




func A_arbace_j2g_decls_ctor_desc_A_New() *A_arbace_j2g_decls_ctor_desc_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_desc_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_j2g_decls_ctor_desc_A) Ctor() {}
//line :207:1
func (t *A_arbace_j2g_decls_ctor_desc_A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_121.GetRawRoot__O()).Invoke_O_O__O(n__0, mm__1) }

func A_arbace_j2g_decls_ctor_call_translator_A_New() *A_arbace_j2g_decls_ctor_call_translator_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_decls_ctor_call_translator_A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_decls_ctor_call_translator_A) Invoke_O_O_O_O__O(self, pkg__0, n__1, info__2 any) any {



	var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_New_O_O(info__2, n__1); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_58, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :213:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A) Ctor_O_O(c__info, c__n any) { t.F_info = c__info; t.F_n = c__n }
//line :213:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A) Invoke_O_O__O(self, node__1 any) any { var d__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(t.F_n); var leaf__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(t.F_n); var thisx__4 any; _ = thisx__4; if


	jrt.J2g_Truth(leaf__3) { thisx__4 = A_arbace_j2g_decls_A_const_165 } else { thisx__4 = A_arbace_j2g_decls_A_const_166 }; var kind__5 any = /*line :213:1*/A_arbace_j2g_decls_A_const_167.Invoke_O__O(node__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_168.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_fn_class; if






	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_59, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; var tmp4 /*line :218:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_118; if jrt.J2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_185.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1))))) {


		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_186.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_60, nil, nil, Lit_61); var tmp8 any; var or__1927000174__auto____10 any = A_arbace_j2g_decls_A_const_34.Invoke_O__O(node__1); if jrt.J2g_Truth(or__1927000174__auto____10) { tmp8 = or__1927000174__auto____10 } else { tmp8 = t.F_n }; var tmp9 *lang.Keyword = A_arbace_j2g_decls_A_const_118; return tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Invoke_O__O(A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1)), nil)).Ref(), Lit_62)) } else {
//line :218:1
			if lang.Util_Equiv_O_O__Z_NoInit(kind__5, A_arbace_j2g_decls_A_const_87) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_169.GetRawRoot__O()); var tmp11 any = t.F_n; var real__6 any = tmp10.Invoke_O_O__O(tmp11, A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1)); var base__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_170.GetRawRoot__O()).Invoke_O__O(real__6); var extra__8 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp13 lang.IPersistentVector








				if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_138.Invoke_O__O(d__2)) { tmp13 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_191.Invoke_O__O(t.F_info)) } else { tmp13 = nil }; var tmp14 any = tmp13; var tmp15 lang.IPersistentVector
				if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_187.Invoke_O__O(d__2)) { tmp15 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_192.Invoke_O__O(t.F_info)) } else { tmp15 = nil }
//line :227:1
				var tmp16 any = tmp15; var tmp17 any; var tmp18 any; var tmp19 any = A_arbace_j2g_decls_A_const_188; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp19, A_arbace_j2g_decls_A_const_167.Invoke_O__O(d__2))

				if or__1927000174__auto____8 { tmp18 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____8).Ref() } else { tmp18 = A_arbace_j2g_decls_A_const_189.Invoke_O__O(d__2) }; if jrt.J2g_Truth(tmp18) { tmp17 = A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info) } else { tmp17 = nil }
//line :227:1
				extra__8 = tmp12.Invoke_O_O_O__O(tmp14, tmp16, tmp17)
//line :218:1
				var tmp20 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var vec__1464000129__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1))); var ps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000129__9, lang.RT_IntCast_J__I_NoInit(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000129__9, lang.RT_IntCast_J__I_NoInit(1), nil); var args__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_171.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_193.Invoke_O__O(node__1), ps__10); var caps__13 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_172); _ = ___11













				if jrt.J2g_Truth(tmp21.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__2))) { var iter__1927001039__auto____13 any; var tmp22 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_New_O(t.F_info); var tmp23 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_fn_class
					if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_fn_class = fncls__29d; tmp23 = fncls__29d } else { tmp23 = fncls__29 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var tmp24 *lang.Keyword = A_arbace_j2g_decls_A_const_80; caps__13 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(tmp24.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__2)))) } else {
//line :232:1
						caps__13 = nil
					}
				var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp28 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__7)).Ref()); var tmp29 any = A_arbace_j2g_decls_A_const_195; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp31 any
				if jrt.J2g_Truth(leaf__3) { tmp31 = nil } else { tmp31 = A_arbace_j2g_decls_A_const_196 }
//line :234:1
				return tmp25.Invoke_O__O(tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, extra__8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_180, args__12), caps__13))) } else {
//line :218:1
					if A_arbace_j2g_decls_A_const_160 != nil { var sup__6 any = A_arbace_j2g_decls_A_const_34.Invoke_O__O(node__1); var tmp32 bool; var or__1927000174__auto____7 bool = lang.Util_Identical_O_O__Z_NoInit(sup__6, nil)




















						if or__1927000174__auto____7 { tmp32 = or__1927000174__auto____7 } else { tmp32 = lang.Util_Equiv_O_O__Z_NoInit(sup__6, Lit_64) }
//line :238:1
						if tmp32 { return nil } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_139.GetRawRoot__O()).Invoke_O__O(sup__6))) {

							return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_186.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_65, nil), jrt.RefArrayOf(jrt.Object_class, nil, sup__6)).Ref(), Lit_62)) } else {
//line :238:1
								if A_arbace_j2g_decls_A_const_160 != nil { var ss__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(sup__6))).Ref()), A_arbace_j2g_decls_A_const_197); var sctor__8 any = A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1); var real__9 any





									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(sup__6)) { real__9 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_169.GetRawRoot__O()).Invoke_O_O__O(sup__6, sctor__8) } else { real__9 = A_arbace_j2g_decls_A_const_118.Invoke_O__O(sctor__8) }
//line :238:1
									var base__10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_170.GetRawRoot__O()).Invoke_O__O(real__9); var sd__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(sup__6); var thisv__12 any








									if jrt.J2g_Truth(leaf__3) { thisv__12 = A_arbace_j2g_decls_A_const_175 } else { thisv__12 = A_arbace_j2g_decls_A_const_176 }
									if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_177.Invoke_O__O(node__1)) {

										return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref()), ss__7, thisv__12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info)))) } else {
//line :248:1
											if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_178.Invoke_O__O(node__1)) {



												var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp36 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref()); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp38 lang.IPersistentVector
												if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_187.Invoke_O__O(d__2)) { tmp38 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_192.Invoke_O__O(t.F_info)) } else { tmp38 = nil }
//line :252:1
												var tmp39 any = tmp38; var tmp40 lang.IPersistentVector

												if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_198.Invoke_O__O(d__2)) { tmp40 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_191.Invoke_O__O(t.F_info)) } else { tmp40 = nil }
//line :252:1
												var tmp41 any = tmp40; var tmp42 lang.IPersistentVector; var temp__1927000414__auto____13 any = A_arbace_j2g_decls_A_const_199.Invoke_O__O(d__2)


												if jrt.J2g_Truth(temp__1927000414__auto____13) { var p__14 any = temp__1927000414__auto____13; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_New(); var tmp45 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_fn_class
													if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_fn_class = fncls__34d; tmp45 = fncls__34d } else { tmp45 = fncls__34 }
//line :255:1
													tmp42 = lang.Tuple_Create_O__IPersistentVector(tmp43.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil), A_arbace_j2g_decls_A_const_191.Invoke_O__O(t.F_info), p__14)) } else { tmp42 = nil }
//line :252:1
												var tmp46 any = tmp42; var tmp47 any





												if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_189.Invoke_O__O(d__2)) { tmp47 = A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info) } else { tmp47 = nil }
//line :252:1
												var tmp48 any = tmp47; var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_New(); var tmp51 *jrt.Class
												var fncls__35 /*line :252:1*/*jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_fn_class






												if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_fn_class = fncls__35d; tmp51 = fncls__35d } else { tmp51 = fncls__35 }
//line :252:1
												return tmp33.Invoke_O__O(tmp34.Invoke_O_O_O_O_O__O(tmp35, tmp36, ss__7, thisv__12, tmp37.Invoke_O_O_O_O_O__O(tmp39, tmp41, tmp46, tmp48, tmp49.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil), A_arbace_j2g_decls_A_const_107.Invoke_O__O(t.F_info))))) } else {
//line :248:1
													if A_arbace_j2g_decls_A_const_160 != nil { var vec__1464000146__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(sctor__8)); var ps__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000146__13, lang.RT_IntCast_J__I_NoInit(0), nil); var ___15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000146__13, lang.RT_IntCast_J__I_NoInit(1), nil); var lead__16 any; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp53 lang.IPersistentVector; var tmp54 any; var and__1927000168__auto____16 any = sd__11; _ = ___15













														if jrt.J2g_Truth(and__1927000168__auto____16) { tmp54 = A_arbace_j2g_decls_A_const_138.Invoke_O__O(sd__11) } else { tmp54 = and__1927000168__auto____16 }; if jrt.J2g_Truth(tmp54) { tmp53 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_142.Invoke_O__O(node__1), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_68, nil, Lit_69), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_142.Invoke_O__O(sd__11), nil)).Ref())) } else { tmp53 = nil }; lead__16 = tmp52.Invoke_O__O(tmp53)
//line :248:1
														var vals__17 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_171.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_31.GetRawRoot__O(), lead__16), A_arbace_j2g_decls_A_const_193.Invoke_O__O(node__1)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_137.GetRawRoot__O(), lead__16), ps__14)); var caps__18 any; var tmp55 any
														var and__1927000168__auto____18 any = sd__11














														if jrt.J2g_Truth(and__1927000168__auto____18) { var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_179); tmp55 = tmp56.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(sd__11)) } else { tmp55 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp55) { var iter__1927001039__auto____18 any; var tmp57 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_New(); var tmp58 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_fn_class
															if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_fn_class = fncls__32d; tmp58 = fncls__32d } else { tmp58 = fncls__32 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil); var tmp59 *lang.Keyword = A_arbace_j2g_decls_A_const_80; caps__18 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(tmp59.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(sd__11)))) } else {
//line :264:1
																caps__18 = nil
															}
														return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref()), ss__7, thisv__12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_180, vals__17), caps__18))) } else {
//line :248:1
															return nil } } } } else {
//line :238:1
																return nil } } } } else {
//line :218:1
																	return nil } } } }

func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A) Ctor() {}
//line :220:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A) Invoke_O_O__O(self, p1__1464000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_139.GetRawRoot__O()).Invoke_O__O(p1__1464000125_SHARP___1)) }












func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_New_O(p0 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A) Ctor_O(c__info any) { t.F_info = c__info }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A) Invoke_O_O__O(self, s__1464000133__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_New_O_O_O(t.F_info, s__1464000133__1, self); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A) Ctor_O_O_O(c__info, c__s__1464000133, c__iter__1464000132 any) { t.F_info = c__info; t.F_s__1464000133 = c__s__1464000133; t.F_iter__1464000132 = c__iter__1464000132 }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A) Invoke_O__O(self any) any { { var s__1464000133__1 any; var t_ any = t.F_s__1464000133; t.F_s__1464000133 = nil; s__1464000133__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000133__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000133__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000133__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000133__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000135__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_New_O_O_I_O(b__1464000135__6, t.F_info, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000132); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000135__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000133__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000135__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000133__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000132); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_decls_A_const_173.Invoke_O__O(t.F_info), A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000133__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :233:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A) Ctor_O_O_I_O(c__b__1464000135, c__info any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000135 = c__b__1464000135; t.F_info = c__info; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A) Invoke_O__O(self any) any { { var i__1464000134__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000134__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000135; tmp2.Invoke_O_O__O(tmp3, lang.RT_Get_O_O__O_NoInit(A_arbace_j2g_decls_A_const_173.Invoke_O__O(t.F_info), A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__2))); i__1464000134__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000134__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A) Invoke_O_O_O__O(self, x__1, cl__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_143.GetRawRoot__O()).Invoke_O__O(cl__2)))).Ref()), x__1) }


func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A) Ctor() {}
//line :259:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A) Invoke_O_O__O(self, b__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_201.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__1)) }





func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A) Ctor() {}
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A) Invoke_O_O__O(self, s__1464000150__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_New_O_O(s__1464000150__1, self); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :265:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A) Ctor_O_O(c__s__1464000150, c__iter__1464000149 any) { t.F_s__1464000150 = c__s__1464000150; t.F_iter__1464000149 = c__iter__1464000149 }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A) Invoke_O__O(self any) any { { var s__1464000150__1 any; var t_ any = t.F_s__1464000150; t.F_s__1464000150 = nil; s__1464000150__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000150__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000150__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000150__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000150__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000152__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_New_O_I_O(b__1464000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000149); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000152__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000150__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000152__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000150__3); var tmp4 *lang.Keyword = A_arbace_j2g_decls_A_const_180; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000149); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_182, A_arbace_j2g_decls_A_const_183, A_arbace_j2g_decls_A_const_184, b__4)))), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000150__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :265:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A) Ctor_O_I_O(c__b__1464000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000152 = c__b__1464000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A) Invoke_O__O(self any) any { { var i__1464000151__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000151__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000152; var tmp4 *lang.Keyword = A_arbace_j2g_decls_A_const_180; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_182, A_arbace_j2g_decls_A_const_183, A_arbace_j2g_decls_A_const_184, b__2))))); i__1464000151__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000151__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_ctor_forms_A_New() *A_arbace_j2g_decls_ctor_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_j2g_decls_ctor_forms_A) Ctor() {}
//line :268:1
func (t *A_arbace_j2g_decls_ctor_forms_A) Invoke_O_O_O_O__O(self, pkg__0, n__1, mm__2 any) any { var d__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var g__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var leaf__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1); var real__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_169.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var vec__1464000162__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(real__7); var rps__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000162__8, lang.RT_IntCast_J__I_NoInit(0), nil); var ___10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000162__8, lang.RT_IntCast_J__I_NoInit(1), nil); var base__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_170.GetRawRoot__O()).Invoke_O__O(real__7); var ab__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_202.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var reached__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_203.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var st__14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__4)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_86; var tmp6 any = A_arbace_j2g_decls_A_const_233; var tmp7 any = A_arbace_j2g_decls_A_const_87; var tmp8 any; _ = ___10; if












	jrt.J2g_Truth(leaf__6) { tmp8 = A_arbace_j2g_decls_A_const_234 } else { tmp8 = A_arbace_j2g_decls_A_const_235 }; var tmp9 any = tmp4.Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(pkg__0, n__1, tmp5, tmp6, tmp7, tmp8, A_arbace_j2g_decls_A_const_97, Lit_62, A_arbace_j2g_decls_A_const_174, jrt.Boolean_TRUE.Ref(), A_arbace_j2g_decls_A_const_99, Lit_27); var tmp10 any = A_arbace_j2g_decls_A_const_96; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp9, tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_84.GetRawRoot__O()).Invoke_O__O(mm__2))); var tmp11 any; tmp100 := /*line :268:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp12 *lang.Keyword = A_arbace_j2g_decls_A_const_35; var fid__17 any = tmp12.Invoke_O__O(A_arbace_j2g_decls_A_const_90.Get__O()); var outer_p__18 any















		if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_138.Invoke_O__O(d__4)) { outer_p__18 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_75) } else { outer_p__18 = nil }
//line :268:1
		var so_p__19 any
















		if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_187.Invoke_O__O(d__4)) { so_p__19 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_76) } else { so_p__19 = nil }
//line :268:1
		var enum_ps__20 any; var tmp13 any; var tmp14 any = A_arbace_j2g_decls_A_const_188; var or__1927000174__auto____20 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp14, A_arbace_j2g_decls_A_const_167.Invoke_O__O(d__4))

















		if or__1927000174__auto____20 { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____20).Ref() } else { tmp13 = A_arbace_j2g_decls_A_const_189.Invoke_O__O(d__4) }; if jrt.J2g_Truth(tmp13) { enum_ps__20 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_77), lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_78)) } else { enum_ps__20 = nil }
//line :268:1
		var params__21 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp16 any; var iter__1927001039__auto____21 any; var tmp17 any = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_New(); var tmp18 *jrt.Class
		var fncls__42 /*line :268:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_fn_class


















		if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_fn_class = fncls__42d; tmp18 = fncls__42d } else { tmp18 = fncls__42 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(A_arbace_j2g_decls_A_const_107.Invoke_O__O(ab__12)); params__21 = tmp15.Invoke_O__O(tmp16)
//line :268:1
		var params__22 any; var tmp19 any; var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_205.GetRawRoot__O()).Invoke_O__O(params__21)



















		if jrt.J2g_Truth(and__1927000168__auto____22) { var and__1927000168__auto____23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_107.Invoke_O__O(mm__2)); if jrt.J2g_Truth(and__1927000168__auto____23) { tmp19 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(ab__12) } else { tmp19 = and__1927000168__auto____23 } } else { tmp19 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp19) {
			var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp21 any; var iter__1927001039__auto____22 any; var tmp22 any = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_New(); var tmp23 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_fn_class = fncls__45d; tmp23 = fncls__45d } else { tmp23 = fncls__45 }; iter__1927001039__auto____22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); tmp21 = lang.IFn_Cast(iter__1927001039__auto____22).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(A_arbace_j2g_decls_A_const_107.Invoke_O__O(mm__2))).Ref())); params__22 = tmp20.Invoke_O__O(tmp21) } else {
//line :288:1
				params__22 = params__21 }
//line :268:1
		var caps__23 any; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_206)






















		if jrt.J2g_Truth(tmp24.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__4))) { caps__23 = A_arbace_j2g_decls_A_const_80.Invoke_O__O(st__14) } else { caps__23 = nil }
//line :268:1
		var cap_ps__24 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp26 any; var iter__1927001039__auto____24 any; var tmp27 any = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_New(); var tmp28 *jrt.Class
		var fncls__48 /*line :268:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_fn_class























		if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_fn_class = fncls__48d; tmp28 = fncls__48d } else { tmp28 = fncls__48 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); tmp26 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(caps__23); cap_ps__24 = tmp25.Invoke_O__O(tmp26)
//line :268:1
		var all_ps__25 any; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp31 lang.IPersistentVector
























		if jrt.J2g_Truth(outer_p__18) { tmp31 = lang.Tuple_Create_O__IPersistentVector(outer_p__18) } else { tmp31 = nil }; var tmp32 any = tmp31; var tmp33 lang.IPersistentVector; if jrt.J2g_Truth(so_p__19) { tmp33 = lang.Tuple_Create_O__IPersistentVector(so_p__19) } else { tmp33 = nil }; all_ps__25 = tmp29.Invoke_O__O(tmp30.Invoke_O_O_O_O_O__O(tmp32, tmp33, enum_ps__20, params__22, cap_ps__24))
//line :268:1
		var tmp34 any = A_arbace_j2g_decls_A_const_191; var tmp35 any = A_arbace_j2g_decls_A_const_192; var tmp36 any = A_arbace_j2g_decls_A_const_190; var tmp37 any = A_arbace_j2g_decls_A_const_107; var tmp38 any = A_arbace_j2g_decls_A_const_107.Invoke_O__O(ab__12); var tmp39 any = A_arbace_j2g_decls_A_const_173; var info__26 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp34, outer_p__18, tmp35, so_p__19, tmp36, enum_ps__20, tmp37, tmp38, tmp39, lang.IFn_Cast(A_arbace_j2g_decls_A_const_207.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_71, caps__23), cap_ps__24))); var body__27 any; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_90; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_decls_A_const_90.Get__O(); var tmp44 any = A_arbace_j2g_decls_A_const_105; var tmp45 any = A_arbace_j2g_decls_A_const_191; var tmp46 any = A_arbace_j2g_decls_A_const_238; var tmp47 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_222.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, n__1, info__26)
		var tmp48 any = A_arbace_j2g_decls_A_const_39


























		lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp40.Invoke_O_O__O(tmp41, tmp42.Invoke_O_O_O_O_O_O_O_O_O__O(tmp43, tmp44, fid__17, tmp45, outer_p__18, tmp46, tmp47, tmp48, lang.IFn_Cast(A_arbace_j2g_decls_A_const_207.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_71, caps__23), cap_ps__24)))); var tmp49 any = A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_New_O_O_O_O_O_O_O_O_O_O_O_O(d__4, reached__13, all_ps__25, caps__23, pkg__0, n__1, st__14, info__26, ab__12, cap_ps__24, outer_p__18, mm__2); var tmp50 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_fn_class = fncls__39d; tmp50 = fncls__39d } else { tmp50 = fncls__39 }; body__27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil).Invoke__O()
//line :268:1
		var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp52 any = A_arbace_j2g_decls_A_const_239; var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp54 any = A_arbace_j2g_decls_A_const_240; var recv__28 any = tmp51.Invoke_O_O__O(tmp52, tmp53.Invoke_O_O__O(tmp54, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__5))); var ctor_form__29 any; var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp56 any = A_arbace_j2g_decls_A_const_241; var tmp57 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(base__11); var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp60 any = lang.Tuple_Create_O__IPersistentVector(recv__28); var tmp61 lang.IPersistentVector

































































		if jrt.J2g_Truth(leaf__6) { tmp61 = nil } else { var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_decls_A_const_243; tmp61 = lang.Tuple_Create_O__IPersistentVector(tmp62.Invoke_O_O__O(tmp63, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__5, nil)).Ref()))) }
//line :333:1
		ctor_form__29 = tmp55.Invoke_O_O_O_O__O(tmp56, tmp57, tmp58.Invoke_O__O(tmp59.Invoke_O_O_O__O(tmp60, tmp61, lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, rps__9, all_ps__25))), body__27)
//line :268:1
		var new_ps__30 any; var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp65 any; var iter__1927001039__auto____30 any; var tmp66 any = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_New_O_O(pkg__0, rps__9); var tmp67 *jrt.Class
		var fncls__51 /*line :268:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_fn_class




































































		if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_fn_class = fncls__51d; tmp67 = fncls__51d } else { tmp67 = fncls__51 }; iter__1927001039__auto____30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp66, tmp67, nil); tmp65 = lang.IFn_Cast(iter__1927001039__auto____30).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(rps__9)).Ref())); new_ps__30 = tmp64.Invoke_O__O(tmp65)
//line :268:1
		var new_form__31 any; var tmp68 any; var or__1927000174__auto____31 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(d__4), A_arbace_j2g_decls_A_const_244)





































































		if jrt.J2g_Truth(or__1927000174__auto____31) { tmp68 = or__1927000174__auto____31 } else { tmp68 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1) }; if jrt.J2g_Truth(tmp68) { new_form__31 = nil } else {
			var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp70 any = A_arbace_j2g_decls_A_const_245; var tmp71 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_246.GetRawRoot__O()).Invoke_O_O__O(g__5, real__7)); var tmp72 any = A_arbace_j2g_decls_A_const_18; var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_decls_A_const_247; var tmp75 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(new_ps__30, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp72, tmp73.Invoke_O_O__O(tmp74, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__5))))); var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp77 lang.IPersistentVector


			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp77 = nil } else { tmp77 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, g__5, nil)).Ref()))) }
//line :339:1
			var tmp78 any = tmp77; var tmp79 lang.IPersistentVector; var top__31 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_249.GetRawRoot__O()).Invoke_O__O(n__1); var tmp80 any; var and__1927000168__auto____32 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__1)






			if jrt.J2g_Truth(and__1927000168__auto____32) { var and__1927000168__auto____33 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(top__31, n__1); if jrt.J2g_Truth(and__1927000168__auto____33) { var and__1927000168__auto____34 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(top__31); if jrt.J2g_Truth(and__1927000168__auto____34) { tmp80 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(top__31)) } else { tmp80 = and__1927000168__auto____34 } } else { tmp80 = and__1927000168__auto____33 } } else { tmp80 = and__1927000168__auto____32 }; if jrt.J2g_Truth(tmp80) { tmp79 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, top__31, Lit_84))) } else { tmp79 = nil }
//line :339:1
			var tmp81 any = tmp79; var tmp82 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp83 any = A_arbace_j2g_decls_A_const_251; var tmp84 any = A_arbace_j2g_decls_A_const_253; var tmp85 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp86 any = A_arbace_j2g_decls_A_const_254; var tmp87 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp88 any = A_arbace_j2g_decls_A_const_255; var tmp89 any = lang.Tuple_Create_O_O__IPersistentVector(tmp84, tmp85.Invoke_O_O__O(tmp86, tmp87.Invoke_O_O__O(tmp88, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__5)))); var tmp90 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp91 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp92 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref()); var tmp93 any = A_arbace_j2g_decls_A_const_256; var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp95 any









			if jrt.J2g_Truth(leaf__6) { tmp95 = nil } else { tmp95 = A_arbace_j2g_decls_A_const_257 }
//line :339:1
			var tmp96 any = tmp95; var tmp97 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp98 any = A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_New(); var tmp99 *jrt.Class
			var fncls__52 /*line :339:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_fn_class









			if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_fn_class = fncls__52d; tmp99 = fncls__52d } else { tmp99 = fncls__52 }
//line :339:1
			new_form__31 = tmp69.Invoke_O_O_O_O__O(tmp70, tmp71, tmp75, tmp76.Invoke_O_O_O__O(tmp78, tmp81, lang.Tuple_Create_O__IPersistentVector(tmp82.Invoke_O_O_O_O__O(tmp83, tmp89, tmp90.Invoke_O_O_O_O__O(tmp91, tmp92, tmp93, tmp94.Invoke_O_O__O(tmp96, tmp97.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil), new_ps__30))), A_arbace_j2g_decls_A_const_252))))
		}










		tmp11 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_232.GetRawRoot__O()).Invoke_O_O__O(mm__2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_259.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(new_form__31, ctor_form__29))) }; return nil }(); /*line :281:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if /*line :268:1*/ tmp100 != nil { panic(tmp100) }; return tmp11 }


















func A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_New() *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A) Ctor() {}
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A) Invoke_O_O__O(self, s__1464000166__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_New_O_O(s__1464000166__1, self); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :287:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A{}; t.Ctor_O_O(p0, p1); return t }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A) Ctor_O_O(c__s__1464000166, c__iter__1464000165 any) { t.F_s__1464000166 = c__s__1464000166; t.F_iter__1464000165 = c__iter__1464000165 }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A) Invoke_O__O(self any) any { { var s__1464000166__1 any; var t_ any = t.F_s__1464000166; t.F_s__1464000166 = nil; s__1464000166__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000166__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000166__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000166__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000166__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000168__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_New_O_I_O(b__1464000168__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000165); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000168__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000166__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000168__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000166__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000165); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000166__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :287:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A) Ctor_O_I_O(c__b__1464000168 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000168 = c__b__1464000168; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A) Invoke_O__O(self any) any { { var i__1464000167__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000167__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000168; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__2)); i__1464000167__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000167__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_New() *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A) Ctor() {}
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A) Invoke_O_O__O(self, s__1464000176__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_New_O_O(s__1464000176__1, self); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :289:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A{}; t.Ctor_O_O(p0, p1); return t }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A) Ctor_O_O(c__s__1464000176, c__iter__1464000175 any) { t.F_s__1464000176 = c__s__1464000176; t.F_iter__1464000175 = c__iter__1464000175 }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A) Invoke_O__O(self any) any { { var s__1464000176__1 any; var t_ any = t.F_s__1464000176; t.F_s__1464000176 = nil; s__1464000176__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000176__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000176__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000176__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000176__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000178__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000178__6); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000175); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000178__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000176__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000178__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000176__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000175); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000176__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :289:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000178 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000178 = c__b__1464000178 }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A) Invoke_O__O(self any) any { { var i__1464000177__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000177__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000178; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_94, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000177__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000177__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_New() *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A) Ctor() {}
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A) Invoke_O_O__O(self, s__1464000186__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_New_O_O(s__1464000186__1, self); var tmp2 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_fn_class = fncls__47d; tmp2 = fncls__47d } else { tmp2 = fncls__47 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :292:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A{}; t.Ctor_O_O(p0, p1); return t }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A) Ctor_O_O(c__s__1464000186, c__iter__1464000185 any) { t.F_s__1464000186 = c__s__1464000186; t.F_iter__1464000185 = c__iter__1464000185 }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A) Invoke_O__O(self any) any { { var s__1464000186__1 any; var t_ any = t.F_s__1464000186; t.F_s__1464000186 = nil; s__1464000186__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000186__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000186__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000186__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000186__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000188__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_New_I_O_O(size__1927001038__auto____5, b__1464000188__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000185); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000188__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000186__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000188__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000186__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000185); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__4)))).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000186__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :292:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000188, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000188 = c__b__1464000188; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A) Invoke_O__O(self any) any { { var i__1464000187__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000187__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000187__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000188; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_97, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__2)))).Ref())); i__1464000187__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000187__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_New_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11 any) *A_arbace_j2g_decls_ctor_forms_fn__1464000195_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000195_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11); return t }
//line :296:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_A) Ctor_O_O_O_O_O_O_O_O_O_O_O_O(c__d, c__reached, c__all_ps, c__caps, c__pkg, c__n, c__st, c__info, c__ab, c__cap_ps, c__outer_p, c__mm any) { t.F_d = c__d; t.F_reached = c__reached; t.F_all_ps = c__all_ps; t.F_caps = c__caps; t.F_pkg = c__pkg; t.F_n = c__n; t.F_st = c__st; t.F_info = c__info; t.F_ab = c__ab; t.F_cap_ps = c__cap_ps; t.F_outer_p = c__outer_p; t.F_mm = c__mm }
//line :296:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____3 any; var t_ any = t.F_reached; t.F_reached = nil; or__1927000174__auto____3 = t_; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = A_arbace_j2g_decls_A_const_209.Invoke_O__O(t.F_mm); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t.F_ab, nil)).Ref() } }; if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_n; t.F_n = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp8 any; var t__3 any = t.F_mm; t.F_mm = nil; tmp8 = t__3; tmp1 = tmp4.Invoke_O_O_O__O(tmp6, Lit_27, tmp7.Invoke_O__O(tmp8)) } else {
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_91.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_New_O_O_O_O_O_O_O_O_O_O_O(t.F_d, t.F_all_ps, t.F_caps, t.F_pkg, t.F_n, t.F_st, t.F_info, t.F_ab, t.F_cap_ps, t.F_outer_p, t.F_mm); var tmp11 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_fn_class
			if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, false); A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_fn_class = fncls__38d; tmp11 = fncls__38d } else { tmp11 = fncls__38 }
//line :302:1
			tmp1 = tmp9.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)) } }
//line :296:1
	return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp12 != nil { panic(tmp12) }; return tmp1 }






func A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_New_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 any) *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10); return t }
//line :303:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A) Ctor_O_O_O_O_O_O_O_O_O_O_O(c__d, c__all_ps, c__caps, c__pkg, c__n, c__st, c__info, c__ab, c__cap_ps, c__outer_p, c__mm any) { t.F_d = c__d; t.F_all_ps = c__all_ps; t.F_caps = c__caps; t.F_pkg = c__pkg; t.F_n = c__n; t.F_st = c__st; t.F_info = c__info; t.F_ab = c__ab; t.F_cap_ps = c__cap_ps; t.F_outer_p = c__outer_p; t.F_mm = c__mm }
//line :303:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A) Invoke_O__O(self any) any { { var seq_1464000197__1 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(t.F_all_ps); var chunk_1464000198__2 any; var count_1464000199__3 int64 = 0; var i_1464000200__4 int64 = 0; L1: for {
													if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000200__4, count_1464000199__3) { var s__5 any = lang.Indexed_Cast(chunk_1464000198__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000200__4)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_201.GetRawRoot__O()).Invoke_O__O(s__5); seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, i_1464000200__4 = seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000200__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000197__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1464000197__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6); seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, i_1464000200__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var s__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6); lang.IFn_Cast(A_arbace_j2g_decls_A_const_201.GetRawRoot__O()).Invoke_O__O(s__7); seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, i_1464000200__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6), nil, 0, 0; continue L1 } } }
//line :303:1
	break L1 }; var calls_super__1 any; var or__1927000174__auto____1 any = A_arbace_j2g_decls_A_const_210.Invoke_O__O(t.F_ab)

	if jrt.J2g_Truth(or__1927000174__auto____1) { calls_super__1 = or__1927000174__auto____1 } else { calls_super__1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t.F_ab, nil)).Ref() }
	if jrt.J2g_Truth(calls_super__1) { var seq_1464000201__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_215.GetRawRoot__O(), t.F_caps, t.F_cap_ps)); var chunk_1464000202__3 any; var count_1464000203__4 int64 = 0; var i_1464000204__5 int64 = 0; L2: for {

		if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000204__5, count_1464000203__4) { var vec__1464000205__6 any = lang.Indexed_Cast(chunk_1464000202__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000204__5)); var b__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000205__6, lang.RT_IntCast_J__I_NoInit(0), nil); var p__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000205__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_216
			lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__7))).Ref()))).Ref()), A_arbace_j2g_decls_A_const_217), p__8))
//line :308:1
			seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, i_1464000204__5 = seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000204__5); continue L2 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000201__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1464000201__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7); seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, i_1464000204__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var vec__1464000208__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7); var b__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000208__8, lang.RT_IntCast_J__I_NoInit(0), nil); var p__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000208__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_216
				lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__9))).Ref()))).Ref()), A_arbace_j2g_decls_A_const_217), p__10))
//line :308:1
				seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, i_1464000204__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7), nil, 0, 0; continue L2 } } }
//line :306:1
		break L2
	}


		if jrt.J2g_Truth(t.F_outer_p) { var od__2 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_68, nil, Lit_69), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_142.Invoke_O__O(t.F_d), nil)).Ref(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp6 any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_132.GetRawRoot__O()).Invoke_O__O(od__2)) {
				tmp6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_87), t.F_outer_p) } else {
					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_218; tmp6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_88), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, od__2)), t.F_outer_p) }
//line :312:1
			tmp5.Invoke_O__O(tmp6)


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_219; lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_143.GetRawRoot__O()).Invoke_O__O(t.F_n)))).Ref()), A_arbace_j2g_decls_A_const_220), t.F_outer_p)) } }
	if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_214.Invoke_O__O(t.F_ab)) {
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab)) } else {
//line :316:1
			var seq_1464000211__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_224.Invoke_O__O(t.F_ab)); var chunk_1464000212__3 any; var count_1464000213__4 int64 = 0; var i_1464000214__5 int64 = 0; L3: for {


				if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000214__5, count_1464000213__4) { var p__6 any = lang.Indexed_Cast(chunk_1464000212__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000214__5)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(p__6); seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, i_1464000214__5 = seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000214__5); continue L3 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000211__2); if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1464000211__7 any = temp__1927000414__auto____6_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7); seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, i_1464000214__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var p__8_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(p__8_2); seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, i_1464000214__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7), nil, 0, 0; continue L3 } } }
//line :316:1
				break L3 }; var temp__1927000408__auto____2 any = A_arbace_j2g_decls_A_const_221.Invoke_O__O(t.F_ab)



			if jrt.J2g_Truth(temp__1927000408__auto____2) { var call__3 any = temp__1927000408__auto____2
				lang.IFn_Cast(lang.IFn_Cast(A_arbace_j2g_decls_A_const_222.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, t.F_info)).Invoke_O__O(call__3) } else {
					var tmp11 any = A_arbace_j2g_decls_A_const_182; var tmp12 any = A_arbace_j2g_decls_A_const_225; var tmp13 any = A_arbace_j2g_decls_A_const_167; var tmp14 any = A_arbace_j2g_decls_A_const_126; var tmp15 any = A_arbace_j2g_decls_A_const_34; lang.IFn_Cast(lang.IFn_Cast(A_arbace_j2g_decls_A_const_222.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, t.F_info)).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, tmp12, tmp13, tmp14, tmp15, A_arbace_j2g_decls_A_const_126.Invoke_O__O(t.F_d), A_arbace_j2g_decls_A_const_174, A_arbace_j2g_decls_A_const_226, A_arbace_j2g_decls_A_const_193, lang.PersistentVector_EMPTY.Ref())))
				}
			if jrt.J2g_Truth(calls_super__1) {
				var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_decls_A_const_90; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_A_const_90.Get__O(); var tmp20 any = A_arbace_j2g_decls_A_const_39; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O_O__O(tmp19, tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_98.GetRawRoot__O()).Invoke_O_O__O(t.F_n, A_arbace_j2g_decls_A_const_227)))); var tmp21 any = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_New_O(t.F_st); var tmp22 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_fn_class = fncls__37d; tmp22 = fncls__37d } else { tmp22 = fncls__37 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O() }
//line :316:1
			var temp__1927000414__auto____2 any = A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab)










			if jrt.J2g_Truth(temp__1927000414__auto____2) { var b__3 any = temp__1927000414__auto____2; lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(b__3) } }
	var tmp23 any; var tmp24 any = A_arbace_j2g_decls_A_const_211; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(tmp24, A_arbace_j2g_decls_A_const_167.Invoke_O__O(t.F_d)); if and__1927000168__auto____2 { var or__1927000174__auto____3 any = A_arbace_j2g_decls_A_const_212.Invoke_O__O(t.F_mm); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp23 = or__1927000174__auto____3 } else { var tmp25 any = A_arbace_j2g_decls_A_const_213; tmp23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp25, A_arbace_j2g_decls_A_const_209.Invoke_O__O(t.F_mm))).Ref() } } else { tmp23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp23) { var seq_1464000221__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_215.GetRawRoot__O(), A_arbace_j2g_decls_A_const_107.Invoke_O__O(t.F_ab), A_arbace_j2g_decls_A_const_228.Invoke_O__O(t.F_d))); var chunk_1464000222__3 any; var count_1464000223__4 int64 = 0; var i_1464000224__5 int64 = 0; L4: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000224__5, count_1464000223__4) { var vec__1464000225__6 any = lang.Indexed_Cast(chunk_1464000222__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000224__5)); var b__7_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000225__6, lang.RT_IntCast_J__I_NoInit(0), nil); var cm__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000225__6, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_229
			lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__8)))).Ref()), A_arbace_j2g_decls_A_const_230), lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__7_2)))
//line :329:1
			seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, i_1464000224__5 = seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000224__5); continue L4 } else { var temp__1927000414__auto____6_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000221__2); if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1464000221__7 any = temp__1927000414__auto____6_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7)) { var c__1927000678__auto____8_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7); seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, i_1464000224__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L4 } else { var vec__1464000228__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7); var b__9_2 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000228__8, lang.RT_IntCast_J__I_NoInit(0), nil); var cm__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000228__8, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_229
				lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp28.Invoke_O_O_O__O(tmp29, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__10)))).Ref()), A_arbace_j2g_decls_A_const_230), lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__9_2)))
//line :329:1
				seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, i_1464000224__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7), nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :328:1
					return nil } }; /*line :303:1*/panic("j2g: unreachable") }





















func A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_New_O(p0 any) *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A) Ctor_O(c__st any) { t.F_st = c__st }
//line :325:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1464000216__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_223; var tmp4 any; var t_ any = t.F_st
															t.F_st = nil; tmp4 = t_; seq_1464000216__3 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))
//line :325:1
	var chunk_1464000217__4 any; var count_1464000218__5 int64 = 0; var i_1464000219__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000219__6, count_1464000218__5) { var i__7 any = lang.Indexed_Cast(chunk_1464000217__4).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000219__6)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(i__7); seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, i_1464000219__6 = seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000219__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000216__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1464000216__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8); seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, i_1464000219__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var i__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(i__9); seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, i_1464000219__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8), nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :325:1
		break L1 } }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }











func A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A{}; t.Ctor_O_O(p0, p1); return t }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A) Ctor_O_O(c__pkg, c__rps any) { t.F_pkg = c__pkg; t.F_rps = c__rps }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A) Invoke_O_O__O(self, s__1464000234__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_New_O_O_O_O(t.F_pkg, t.F_rps, s__1464000234__1, self); var tmp2 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_fn_class = fncls__50d; tmp2 = fncls__50d } else { tmp2 = fncls__50 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A) Ctor_O_O_O_O(c__pkg, c__rps, c__s__1464000234, c__iter__1464000233 any) { t.F_pkg = c__pkg; t.F_rps = c__rps; t.F_s__1464000234 = c__s__1464000234; t.F_iter__1464000233 = c__iter__1464000233 }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A) Invoke_O__O(self any) any { { var s__1464000234__1 any; var t_ any = t.F_s__1464000234; t.F_s__1464000234 = nil; s__1464000234__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000234__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000234__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000234__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000234__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000236__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_New_O_O_O_I_O(b__1464000236__6, t.F_pkg, t.F_rps, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000233); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000236__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000234__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000236__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000234__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; var tmp6 any = t.F_rps; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1464000233); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O_O__O(tmp5, lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(i__4)))), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000234__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A) Ctor_O_O_O_I_O(c__b__1464000236, c__pkg, c__rps any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000236 = c__b__1464000236; t.F_pkg = c__pkg; t.F_rps = c__rps; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A) Invoke_O__O(self any) any { { var i__1464000235__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000235__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000235__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000236; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; var tmp6 any = t.F_rps; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref()), tmp4.Invoke_O_O__O(tmp5, lang.RT_Nth_O_I__O_NoInit(tmp6, lang.RT_IntCast_O__I_NoInit(i__2))))); i__1464000235__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000235__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_New() *A_arbace_j2g_decls_ctor_forms_fn__1464000243_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000243_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000243_A) Ctor() {}
//line :349:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000243_A) Invoke_O_O__O(self, p1__1464000161_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_258.GetRawRoot__O()).Invoke_O__O(p1__1464000161_SHARP___1)) }






func A_arbace_j2g_decls_record_object_body_A_New() *A_arbace_j2g_decls_record_object_body_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_j2g_decls_record_object_body_A) Ctor() {}
//line :356:1
func (t *A_arbace_j2g_decls_record_object_body_A) Invoke_O_O_O_O_O__O(self, pkg__0, n__1, mm__2, ps__3 any) any { var d__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var comps__6 any = A_arbace_j2g_decls_A_const_228.Invoke_O__O(d__5); var js__7 any; var tmp1 any = A_arbace_j2g_decls_record_object_body_js__1464000246_A_New_O(pkg__0); var tmp2 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_decls_record_object_body_js__1464000246_A_fn_class; if






	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_204, false); A_arbace_j2g_decls_record_object_body_js__1464000246_A_fn_class = fncls__53d; tmp2 = fncls__53d } else { tmp2 = fncls__53 }; js__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fld__8 any; var tmp3 any = /*line :356:1*/A_arbace_j2g_decls_record_object_body_fld__1464000248_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_decls_record_object_body_fld__1464000248_A_fn_class; if







	fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_205, false); A_arbace_j2g_decls_record_object_body_fld__1464000248_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; fld__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var hash__9 any; var tmp5 any = /*line :356:1*/A_arbace_j2g_decls_record_object_body_hash__1464000250_A_New_O(js__7); var tmp6 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_decls_record_object_body_hash__1464000250_A_fn_class; if








	fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_206, false); A_arbace_j2g_decls_record_object_body_hash__1464000250_A_fn_class = fncls__56d; tmp6 = fncls__56d } else { tmp6 = fncls__56 }; hash__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var strof__10 any; var tmp7 any = /*line :356:1*/A_arbace_j2g_decls_record_object_body_strof__1464000253_A_New_O(js__7); var tmp8 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_decls_record_object_body_strof__1464000253_A_fn_class; if

















	fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_207, false); A_arbace_j2g_decls_record_object_body_strof__1464000253_A_fn_class = fncls__58d; tmp8 = fncls__58d } else { tmp8 = fncls__58 }; strof__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var G__1464000256__11_ any = /*line :356:1*/A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2); switch


























	lang.Util_Hash_O__I_NoInit(G__1464000256__11_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000256__11_, Lit_208) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_282; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_record_object_body_fn__1464000257_A_New_O_O(hash__9, fld__8); var tmp13 *jrt.Class
		var fncls__60 /*line :383:1*/*jrt.Class = A_arbace_j2g_decls_record_object_body_fn__1464000257_A_fn_class











		if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_209, false); A_arbace_j2g_decls_record_object_body_fn__1464000257_A_fn_class = fncls__60d; tmp13 = fncls__60d } else { tmp13 = fncls__60 }
//line :383:1
		return lang.Tuple_Create_O__IPersistentVector(tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_287, A_arbace_j2g_decls_A_const_288, A_arbace_j2g_decls_A_const_289), comps__6))) }; case 2: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000256__11_, Lit_210) { var simple__12 any; var s__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_154.GetRawRoot__O()).Invoke_O_O__O(n__1, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(jrt.NN(jrt.String_Cast(n__1)).LastIndexOf_String__I(Lit_11)))).Ref()), A_arbace_j2g_decls_A_const_290, Lit_211); simple__12 = s__12; var parts__13 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp15 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_212), jrt.RefArrayOf(jrt.Object_class, simple__12, nil)).Ref())); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_decls_A_const_57.GetRawRoot__O(); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_147.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_record_object_body_fn__1464000259_A_New_O_O(fld__8, strof__10); var tmp20 *jrt.Class
			var fncls__63 /*line :383:1*/*jrt.Class = A_arbace_j2g_decls_record_object_body_fn__1464000259_A_fn_class




			if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_213, false); A_arbace_j2g_decls_record_object_body_fn__1464000259_A_fn_class = fncls__63d; tmp20 = fncls__63d } else { tmp20 = fncls__63 }
//line :386:1
			parts__13 = tmp14.Invoke_O_O_O__O(tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), comps__6)), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()).Invoke_O__O(Lit_214)))
//line :383:1
			var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_decls_A_const_293; return lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(js__7).Invoke_O__O(Lit_215), parts__13))) }; case 3: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000256__11_, Lit_216) { var o__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(ps__3); var g__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_decls_A_const_294; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_A_const_295; var tmp27 any = tmp23.Invoke_O_O_O__O(tmp24, tmp25.Invoke_O_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_296, A_arbace_j2g_decls_A_const_297, A_arbace_j2g_decls_A_const_298), o__12), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_299, jrt.Boolean_TRUE.Ref())); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_300; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_decls_A_const_301; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_decls_A_const_303; var tmp34 any = tmp28.Invoke_O_O_O__O(tmp29, tmp30.Invoke_O_O_O__O(tmp31, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_302, o__12, nil), tmp32.Invoke_O_O_O__O(tmp33, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(js__7).Invoke_O__O(Lit_217), o__12), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__13, nil)).Ref()))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_304, jrt.Boolean_FALSE.Ref())); var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp36 any = A_arbace_j2g_decls_A_const_305; var tmp37 any = A_arbace_j2g_decls_A_const_306; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp39 any = A_arbace_j2g_decls_A_const_307; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_308; var tmp42 any = lang.Tuple_Create_O_O__IPersistentVector(tmp37, tmp38.Invoke_O_O_O__O(tmp39, tmp40.Invoke_O_O__O(tmp41, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__13)), o__12)); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_A_const_309; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_decls_record_object_body_fn__1464000261_A_New_O_O(js__7, fld__8); var tmp47 *jrt.Class
				var fncls__65 /*line :383:1*/*jrt.Class = A_arbace_j2g_decls_record_object_body_fn__1464000261_A_fn_class


















				if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_218, false); A_arbace_j2g_decls_record_object_body_fn__1464000261_A_fn_class = fncls__65d; tmp47 = fncls__65d } else { tmp47 = fncls__65 }
//line :383:1
				return lang.Tuple_Create_O_O_O__IPersistentVector(tmp27, tmp34, tmp35.Invoke_O_O_O__O(tmp36, tmp42, tmp43.Invoke_O_O__O(tmp44, tmp45.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp46, tmp47, nil), jrt.Boolean_TRUE.Ref(), comps__6)))) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1464000256__11_))))) }
//line :363:1
func A_arbace_j2g_decls_record_object_body_js__1464000246_A_New_O(p0 any) *A_arbace_j2g_decls_record_object_body_js__1464000246_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_js__1464000246_A{}; t.Ctor_O(p0); return t }
//line :363:1
func (t *A_arbace_j2g_decls_record_object_body_js__1464000246_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :363:1
func (t *A_arbace_j2g_decls_record_object_body_js__1464000246_A) Invoke_O_O__O(self, s__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__1) }
func A_arbace_j2g_decls_record_object_body_fld__1464000248_A_New() *A_arbace_j2g_decls_record_object_body_fld__1464000248_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fld__1464000248_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_j2g_decls_record_object_body_fld__1464000248_A) Ctor() {}
//line :364:1
func (t *A_arbace_j2g_decls_record_object_body_fld__1464000248_A) Invoke_O_O_O__O(self, o__1, cm__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__2)))).Ref()), o__1) }
func A_arbace_j2g_decls_record_object_body_hash__1464000250_A_New_O(p0 any) *A_arbace_j2g_decls_record_object_body_hash__1464000250_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_hash__1464000250_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_j2g_decls_record_object_body_hash__1464000250_A) Ctor_O(c__js any) { t.F_js = c__js }
//line :365:1
func (t *A_arbace_j2g_decls_record_object_body_hash__1464000250_A) Invoke_O_O_O__O(self, cm__1, x__2 any) any { var G__1464000251__3_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1); switch
														lang.Util_Hash_O__I_NoInit(G__1464000251__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_135) {
															return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_136) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_137) { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_221), x__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_262; var tmp3 any = A_arbace_j2g_decls_A_const_263; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_264; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_265; var tmp8 any = A_arbace_j2g_decls_A_const_266; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O())
		var tmp10 any = A_arbace_j2g_decls_A_const_267




		return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, b__4, tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_269, A_arbace_j2g_decls_A_const_270, b__4), A_arbace_j2g_decls_A_const_268)))) }
//line :366:1
	case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_138) {



		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_222), x__2) }
//line :366:1
	case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_139) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_140) {


		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_271; var tmp13 any = A_arbace_j2g_decls_A_const_272; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_decls_A_const_273; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_decls_A_const_274; var tmp18 any = A_arbace_j2g_decls_A_const_275; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_decls_A_const_276; return tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14.Invoke_O_O_O__O(tmp15, x__2, tmp16.Invoke_O_O_O__O(tmp17, tmp18, tmp19.Invoke_O_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_277, A_arbace_j2g_decls_A_const_278, x__2), A_arbace_j2g_decls_A_const_268)))) }
//line :366:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_141) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000251__3_, Lit_142) {

		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_224), x__2) }
//line :366:1
	default:}; return /*line :373:1*/ lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_225), lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(x__2, A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1), Lit_56, jrt.Boolean_FALSE.Ref())) }
func A_arbace_j2g_decls_record_object_body_strof__1464000253_A_New_O(p0 any) *A_arbace_j2g_decls_record_object_body_strof__1464000253_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_strof__1464000253_A{}; t.Ctor_O(p0); return t }
//line :374:1
func (t *A_arbace_j2g_decls_record_object_body_strof__1464000253_A) Ctor_O(c__js any) { t.F_js = c__js }
//line :374:1
func (t *A_arbace_j2g_decls_record_object_body_strof__1464000253_A) Invoke_O_O_O__O(self, cm__1, x__2 any) any { var G__1464000254__3_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1); switch
														lang.Util_Hash_O__I_NoInit(G__1464000254__3_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_135) {
															return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_226), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_280, A_arbace_j2g_decls_A_const_281, x__2)) }
//line :375:1
	case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_136) {


		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_227), x__2) }
//line :375:1
	case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_137) {





		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_228), x__2) }
//line :375:1
	case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_138) {




		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_229), x__2) }
//line :375:1
	case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_139) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_226), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_280, A_arbace_j2g_decls_A_const_281, x__2)) }
//line :375:1
	case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_140) {

		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_230), x__2) }
//line :375:1
	case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_141) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_226), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_280, A_arbace_j2g_decls_A_const_281, x__2)) }
//line :375:1
	case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000254__3_, Lit_142) {



		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_231), x__2) }
//line :375:1
	default:}; return /*line :382:1*/ lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_232), lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(x__2, A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1), Lit_56, jrt.Boolean_FALSE.Ref())) }





func A_arbace_j2g_decls_record_object_body_fn__1464000259_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_record_object_body_fn__1464000259_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fn__1464000259_A{}; t.Ctor_O_O(p0, p1); return t }
//line :388:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000259_A) Ctor_O_O(c__fld, c__strof any) { t.F_fld = c__fld; t.F_strof = c__strof }
//line :388:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000259_A) Invoke_O_O_O__O(self, i__1, cm__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_219); var tmp3 *jrt.String; var tmp4 bool; var na_61 any = i__1; if
														jrt.Long_InstanceOf(na_61) { var n0_62 int64 = jrt.NN(jrt.Long_Cast(na_61)).LongValue__J(); tmp4 = n0_62 > 0 } else { if jrt.Double_InstanceOf(na_61) { var n0_62_2 float64 = jrt.NN(jrt.Double_Cast(na_61)).DoubleValue__D(); tmp4 = n0_62_2 > 0.0 } else { tmp4 = lang.Numbers_IsPos_O__Z_NoInit(na_61) } }; if tmp4 { tmp3 = Lit_220 } else { tmp3 = nil }; var tmp5 lang.IFn = /*line :388:1*/lang.IFn_Cast(t.F_strof); return lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3.Ref(), A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__2), nil)).Ref()), tmp5.Invoke_O_O__O(cm__2, lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_292, cm__2))) }






func A_arbace_j2g_decls_record_object_body_fn__1464000257_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_record_object_body_fn__1464000257_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fn__1464000257_A{}; t.Ctor_O_O(p0, p1); return t }
//line :395:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000257_A) Ctor_O_O(c__hash, c__fld any) { t.F_hash = c__hash; t.F_fld = c__fld }
//line :395:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000257_A) Invoke_O_O_O__O(self, acc__1, cm__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_283; var tmp3 lang.IFn = lang.IFn_Cast(t.F_hash); return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_284, acc__1, A_arbace_j2g_decls_A_const_285), tmp3.Invoke_O_O__O(cm__2, lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_286, cm__2))) }






func A_arbace_j2g_decls_record_object_body_fn__1464000261_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_record_object_body_fn__1464000261_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fn__1464000261_A{}; t.Ctor_O_O(p0, p1); return t }
//line :402:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000261_A) Ctor_O_O(c__js, c__fld any) { t.F_js = c__js; t.F_fld = c__fld }
//line :402:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000261_A) Invoke_O_O_O__O(self, acc__1, cm__2 any) any { var a__3 any = lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_311, cm__2); var b__4 any = lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_312, cm__2); var e__5 any; var G__1464000262__5_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__2); L1:

switch { default: switch lang.Util_Hash_O__I_NoInit(G__1464000262__5_) { case 66: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_135) {


	e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
	break L1 }; case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_136) {


		e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
		break L1 }; case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_137) {

			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_314; e__5 = tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_221), a__3), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_221), b__4))
//line :404:1
			break L1 }; case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_138) {
				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_315; e__5 = tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_222), a__3), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_222), b__4))
//line :404:1
				break L1 }; case 73: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_139) {


					e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
					break L1 }; case 74: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_140) {


						e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
						break L1 }; case 83: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_141) {


							e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
							break L1 }; case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000262__5_, Lit_142) {


								e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
								break L1 }; default:
}


	e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_223), lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(a__3, A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__2), Lit_56, jrt.Boolean_FALSE.Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(b__4, A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__2), Lit_56, jrt.Boolean_FALSE.Ref()))}; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_310.GetRawRoot__O()).Invoke_O__O(acc__1)) { return e__5 } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_316, acc__1, e__5) } }


func A_arbace_j2g_decls_derived_body_A_New() *A_arbace_j2g_decls_derived_body_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_j2g_decls_derived_body_A) Ctor() {}
//line :413:1
func (t *A_arbace_j2g_decls_derived_body_A) Invoke_O_O_O_O_O__O(self, pkg__0, n__1, mm__2, ps__3 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_90.Get__O(), A_arbace_j2g_decls_A_const_33, pkg__0)))
//line :413:1
	var tmp3 any; tmp38 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var g__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var d__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var leaf__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1); var this__10 any








		if jrt.J2g_Truth(leaf__9) { this__10 = A_arbace_j2g_decls_A_const_317 } else { this__10 = A_arbace_j2g_decls_A_const_318 }
//line :413:1
		var G__1464000265__11_ any = A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2)









	L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1464000265__11_) >> 5 & 7 { case 0: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_319) { var tg__12 any = A_arbace_j2g_decls_A_const_320.Invoke_O__O(mm__2); var vec__1464000266__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(tg__12)); var tps__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000266__13, lang.RT_IntCast_J__I_NoInit(0), nil); var tr__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000266__13, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1464000269__16 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var bps__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000269__16, lang.RT_IntCast_J__I_NoInit(0), nil); var br__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000269__16, lang.RT_IntCast_J__I_NoInit(1), nil); var args__19 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_derived_body_fn__1464000272_A_New(); var tmp6 *jrt.Class
		var fncls__67 /*line :423:1*/*jrt.Class = A_arbace_j2g_decls_derived_body_fn__1464000272_A_fn_class










		if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_j2g_decls_derived_body_fn__1464000272_A_fn_class = fncls__67d; tmp6 = fncls__67d } else { tmp6 = fncls__67 }; args__19 = tmp4.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ps__3, bps__17, tps__14)
//line :423:1
		var tbase__20 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(tg__12), A_arbace_j2g_decls_A_const_118.Invoke_O__O(tg__12)); var call__21 any
















		if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_321.Invoke_O__O(mm__2)) { var sup__21 any = A_arbace_j2g_decls_A_const_126.Invoke_O__O(d__8); var tmp7 any; var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_322.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_333.Invoke_O__O(tg__12))

			if jrt.J2g_Truth(and__1927000168__auto____22) { var tmp8 *lang.Keyword = A_arbace_j2g_decls_A_const_157; tmp7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_156.GetRawRoot__O()).Invoke_O_O__O(tmp8.Invoke_O__O(A_arbace_j2g_decls_A_const_158.Get__O()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_333.Invoke_O__O(tg__12))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_334.GetRawRoot__O()).Invoke_O__O(tbase__20))) } else { tmp7 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp7) {
				call__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, tbase__20)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(sup__21))).Ref()), A_arbace_j2g_decls_A_const_335), args__19) } else {
					call__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, tbase__20)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(sup__21))).Ref()), A_arbace_j2g_decls_A_const_336), this__10, args__19) } } else {
						call__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, tbase__20)).Ref()), this__10, args__19) }
		if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, br__18) { tmp3 = lang.Tuple_Create_O__IPersistentVector(call__21) } else { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_337; var tmp11 any; var tmp12 any; var and__1927000168__auto____22_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(tr__15)


			if jrt.J2g_Truth(and__1927000168__auto____22_2) { var and__1927000168__auto____23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(br__18); if jrt.J2g_Truth(and__1927000168__auto____23) { var and__1927000168__auto____24 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(tr__15, br__18); if jrt.J2g_Truth(and__1927000168__auto____24) { tmp12 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_329.GetRawRoot__O()).Invoke_O_O__O(tr__15, br__18)) } else { tmp12 = and__1927000168__auto____24 } } else { tmp12 = and__1927000168__auto____23 } } else { tmp12 = and__1927000168__auto____22_2 }; if jrt.J2g_Truth(tmp12) {


				var tmp13 *lang.Keyword = A_arbace_j2g_decls_A_const_180; var tmp14 any = A_arbace_j2g_decls_A_const_34; var tmp15 any = A_arbace_j2g_decls_A_const_331; var tmp16 any = A_arbace_j2g_decls_A_const_182; var tmp17 any = A_arbace_j2g_decls_A_const_332; var tmp18 any = A_arbace_j2g_decls_A_const_180; tmp11 = tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_330.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, br__18, tmp15, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(call__21, tr__15, Lit_56, jrt.Boolean_FALSE.Ref()), A_arbace_j2g_decls_A_const_86, Lit_56)))))) } else {
					tmp11 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(call__21, tr__15, br__18, jrt.Boolean_FALSE.Ref()) }
//line :446:1
			tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp9.Invoke_O_O__O(tmp10, tmp11)) }
//line :423:1
		break L1 }; case 1: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_323) { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_decls_A_const_338; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_decls_A_const_339; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp19.Invoke_O_O__O(tmp20, tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_103), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref())))); break L1 }; case 2: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_324) {
































			tmp3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_325.GetRawRoot__O()).Invoke_O_O_O_O__O(pkg__0, n__1, mm__2, ps__3)
//line :423:1
			break L1 }; case 4: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_326) { var cm__12 any = A_arbace_j2g_decls_A_const_327.Invoke_O__O(mm__2); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_decls_A_const_341; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp23.Invoke_O_O__O(tmp24, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__12)))).Ref()), A_arbace_j2g_decls_A_const_342))); break L1 }; case 5: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_340) { var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_A_const_344; var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp28 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp29 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_104); var tmp30 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref()); var tmp31 any; var iter__1927001039__auto____12 any; var tmp32 any = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_New_O(g__7); var tmp33 *jrt.Class
				var fncls__70 /*line :423:1*/*jrt.Class = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_fn_class





				if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_fn_class = fncls__70d; tmp33 = fncls__70d } else { tmp33 = fncls__70 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil); tmp31 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_decls_A_const_345.Invoke_O__O(d__8))
//line :423:1
				tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp25.Invoke_O_O__O(tmp26, tmp27.Invoke_O_O_O_O__O(tmp28, tmp29, tmp30, tmp31))); break L1 }; case 6: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_343) { var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_346; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp34.Invoke_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_108), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(ps__3))))); break L1 }; default:}; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp37 any = A_arbace_j2g_decls_A_const_347; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp36.Invoke_O_O__O(tmp37, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_109), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_348.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2)))).Ref())))} }; return nil }()
//line :418:1
	lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O()
//line :413:1
	if tmp38 != nil { panic(tmp38) }; return tmp3
}














func A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_New_O(p0 any) *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A{}; t.Ctor_O(p0); return t }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A) Invoke_O_O__O(self, s__1464000275__1 any) any { var tmp1 any = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_New_O_O_O(t.F_g, s__1464000275__1, self); var tmp2 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_fn_class = fncls__69d; tmp2 = fncls__69d } else { tmp2 = fncls__69 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :429:1
func A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A) Ctor_O_O_O(c__g, c__s__1464000275, c__iter__1464000274 any) { t.F_g = c__g; t.F_s__1464000275 = c__s__1464000275; t.F_iter__1464000274 = c__iter__1464000274 }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A) Invoke_O__O(self any) any { { var s__1464000275__1 any; var t_ any = t.F_s__1464000275; t.F_s__1464000275 = nil; s__1464000275__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000275__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000275__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000275__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000275__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000277__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_New_O_I_O_O(t.F_g, size__1927001038__auto____5, c__1927001037__auto____4, b__1464000277__6); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000274); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000277__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000275__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000277__6), nil) } } else { var cn__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000275__3); var tmp4 any = t.F_g; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000274); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, tmp4, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cn__4)))).Ref()), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000275__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :429:1
func A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A) Ctor_O_I_O_O(c__g any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000277 any) { t.F_g = c__g; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000277 = c__b__1464000277 }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A) Invoke_O__O(self any) any { { var i__1464000276__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000276__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000276__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000277; var tmp4 any = t.F_g; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, tmp4, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cn__2)))).Ref())); i__1464000276__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000276__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_decls_derived_body_fn__1464000272_A_New() *A_arbace_j2g_decls_derived_body_fn__1464000272_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_fn__1464000272_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_j2g_decls_derived_body_fn__1464000272_A) Ctor() {}
//line :434:1
func (t *A_arbace_j2g_decls_derived_body_fn__1464000272_A) Invoke_O_O_O_O__O(self, p__1, bp__2, tp__3 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(bp__2, tp__3) { return p__1 } else { var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(bp__2)
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(tp__3); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_329.GetRawRoot__O()).Invoke_O_O__O(bp__2, tp__3) } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }
//line :435:1
		if jrt.J2g_Truth(tmp1) {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(p__1, bp__2, tp__3, jrt.Boolean_FALSE.Ref()) } else {
//line :435:1
				if A_arbace_j2g_decls_A_const_160 != nil {

					var tmp2 *lang.Keyword = A_arbace_j2g_decls_A_const_180; var tmp3 any = A_arbace_j2g_decls_A_const_34; var tmp4 any = A_arbace_j2g_decls_A_const_331; var tmp5 any = A_arbace_j2g_decls_A_const_182; var tmp6 any = A_arbace_j2g_decls_A_const_332; var tmp7 any = A_arbace_j2g_decls_A_const_180; return tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_330.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tp__3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()).Invoke_O_O_O_O__O(p__1, bp__2, Lit_56, jrt.Boolean_FALSE.Ref()), A_arbace_j2g_decls_A_const_86, Lit_56)))))) } else {
//line :435:1
						return nil
					}
			}
	}
}



















func A_arbace_j2g_decls_touches_statics_QMARK__A_New() *A_arbace_j2g_decls_touches_statics_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_touches_statics_QMARK__A{}; t.Ctor(); return t }
//line :459:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__A) Ctor() {}
//line :459:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__A) Invoke_O_O_O__O(self, ab__0, classes__1 any) any { var hit__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_349.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_FALSE.Ref()); var body_w__4 *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A = A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_New_O_O(classes__1, hit__3); var w__4 any; var tmp1 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_266, false); A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_fn_class = fncls__71d; tmp1 = fncls__71d } else { tmp1 = fncls__71 }; w__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_w__4), tmp1, nil);















	lang.IFn_Cast(w__4).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(ab__0)); return /*line :463:1*/ lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(hit__3) }
func A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A{}; t.Ctor_O_O(p0, p1); return t }
//line :464:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A) Ctor_O_O(c__classes, c__hit any) { t.F_classes = c__classes; t.F_hit = c__hit }
//line :464:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_hit)) { return nil } else {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_350.GetRawRoot__O()).Invoke_O__O(x__1)) {

			var tmp1 any; var and__1927000168__auto____2 any = A_arbace_j2g_decls_A_const_182.Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_353); var and__1927000168__auto____3 any = tmp2.Invoke_O__O(A_arbace_j2g_decls_A_const_182.Invoke_O__O(x__1)); if jrt.J2g_Truth(and__1927000168__auto____3) {

				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()); var tmp4 any = t.F_classes; var tmp5 any; var tmp6 *lang.Keyword = A_arbace_j2g_decls_A_const_355; var or__1927000174__auto____4 any = tmp6.Invoke_O__O(A_arbace_j2g_decls_A_const_356.Invoke_O__O(x__1)); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var tmp7 *lang.Keyword = A_arbace_j2g_decls_A_const_333; tmp5 = tmp7.Invoke_O__O(A_arbace_j2g_decls_A_const_356.Invoke_O__O(x__1)) }; tmp1 = tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
//line :468:1
					tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {


						lang.IFn_Cast(A_arbace_j2g_decls_A_const_354.GetRawRoot__O()).Invoke_O_O__O(t.F_hit, jrt.Boolean_TRUE.Ref()) }
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_351.GetRawRoot__O()).Invoke_O_O__O(self, lang.IFn_Cast(A_arbace_j2g_decls_A_const_357.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :466:1
				var tmp8 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_352.GetRawRoot__O()).Invoke_O__O(x__1)






				if jrt.J2g_Truth(or__1927000174__auto____2) { tmp8 = or__1927000174__auto____2 } else { tmp8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :466:1
				if jrt.J2g_Truth(tmp8) {






					return lang.IFn_Cast(A_arbace_j2g_decls_A_const_351.GetRawRoot__O()).Invoke_O_O__O(self, x__1) } else {
//line :466:1
						if A_arbace_j2g_decls_A_const_160 != nil { return nil } else { return nil
						}
					}
			}
	}
}






func A_arbace_j2g_decls_needs_entry_guard_QMARK__A_New() *A_arbace_j2g_decls_needs_entry_guard_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_needs_entry_guard_QMARK__A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_j2g_decls_needs_entry_guard_QMARK__A) Ctor() {}
//line :478:1
func (t *A_arbace_j2g_decls_needs_entry_guard_QMARK__A) Invoke_O_O_O__O(self, n__0, ab__1 any) any { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(n__0)); if





	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(ab__1, nil)
		if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_359.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {

			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_358.GetRawRoot__O()).Invoke_O_O__O(ab__1, lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_360.GetRawRoot__O()).Invoke_O__O(n__0))) } } } else {
//line :484:1
				return and__1927000168__auto____3 } }




func A_arbace_j2g_decls_method_forms_A_New() *A_arbace_j2g_decls_method_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_j2g_decls_method_forms_A) Ctor() {}
//line :489:1
func (t *A_arbace_j2g_decls_method_forms_A) Invoke_O_O_O_O__O(self, pkg__0, n__1, mm__2 any) any { var g__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var iface__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1); var leaf__6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(iface__5); if





	jrt.J2g_Truth(and__1927000168__auto____6) { leaf__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1) } else { leaf__6 = and__1927000168__auto____6 }; var static__7 any = /*line :489:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2); var vec__1464000290__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var ps__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000290__8, lang.RT_IntCast_J__I_NoInit(0), nil); var r__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000290__8, lang.RT_IntCast_J__I_NoInit(1), nil); var base__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var ab__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_202.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var abstract__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_244); var native__14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_373); var reached__15 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_203.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); if













	jrt.J2g_Truth(abstract__13) { return nil } else { var vec__1464000293__16 any

		if jrt.J2g_Truth(native__14) { var pn__16 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____16 any; var tmp3 any = A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A_New(); var tmp4 *jrt.Class
			var fncls__78 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A_fn_class

			if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A_fn_class = fncls__78d; tmp4 = fncls__78d } else { tmp4 = fncls__78 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__9)).Ref())); pn__16 = tmp1.Invoke_O__O(tmp2)
//line :505:1
			var fname__17 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, Lit_172), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11, nil)).Ref(); var f__18 any
			var tmp5 /*line :505:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_374
			var tmp6 /*line :505:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_157






			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_decls_A_const_158.Get__O())), fname__17)) {
				f__18 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, fname__17) } else {
					f__18 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(fname__17) }
//line :505:1
			var call__19 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp10 any









			if jrt.J2g_Truth(static__7) { tmp10 = nil } else { tmp10 = A_arbace_j2g_decls_A_const_375 }; call__19 = tmp7.Invoke_O_O_O__O(tmp8, f__18, tmp9.Invoke_O_O__O(tmp10, pn__16))
//line :505:1
			var tmp11 any










			if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, r__10) { tmp11 = call__19 } else { tmp11 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_376, call__19) }
//line :505:1
			vec__1464000293__16 = lang.Tuple_Create_O_O__IPersistentVector(pn__16, lang.Tuple_Create_O__IPersistentVector(tmp11)) } else { var tmp12 any; var and__1927000168__auto____16 any = A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2)











				if jrt.J2g_Truth(and__1927000168__auto____16) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_319; var or__1927000174__auto____17 any = tmp13.Invoke_O_O__O(tmp14, A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2))
					if jrt.J2g_Truth(or__1927000174__auto____17) { tmp12 = or__1927000174__auto____17 } else { var and__1927000168__auto____18 any = reached__15
						if jrt.J2g_Truth(and__1927000168__auto____18) { var tmp15 *lang.Keyword = A_arbace_j2g_decls_A_const_118; tmp12 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(A_arbace_j2g_decls_A_const_320.Invoke_O__O(mm__2))) } else { tmp12 = and__1927000168__auto____18 } } } else {
//line :517:1
							tmp12 = and__1927000168__auto____16 }
//line :505:1
				if jrt.J2g_Truth(tmp12) { var pn__16_2 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp17 any; var iter__1927001039__auto____16_2 any; var tmp18 any = A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A_New(); var tmp19 *jrt.Class
					var fncls__81 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A_fn_class














					if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A_fn_class = fncls__81d; tmp19 = fncls__81d } else { tmp19 = fncls__81 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); tmp17 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__9)).Ref())); pn__16_2 = tmp16.Invoke_O__O(tmp17)
//line :505:1
					vec__1464000293__16 = lang.Tuple_Create_O_O__IPersistentVector(pn__16_2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_377.GetRawRoot__O()).Invoke_O_O_O_O__O(pkg__0, n__1, mm__2, pn__16_2)) } else { var tmp20 any
						var and__1927000168__auto____16_2 any = reached__15
















						if jrt.J2g_Truth(and__1927000168__auto____16_2) { var and__1927000168__auto____17 bool = lang.Util_Identical_O_O__Z_NoInit(ab__12, nil); if and__1927000168__auto____17 { var and__1927000168__auto____18_2 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_62, r__10); if and__1927000168__auto____18_2 { var tmp21 *lang.Keyword = A_arbace_j2g_decls_A_const_378; var tmp22 *lang.Keyword = A_arbace_j2g_decls_A_const_81; tmp20 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp21.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1))))) } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____18_2).Ref() } } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____17).Ref() } } else { tmp20 = and__1927000168__auto____16_2 }
//line :505:1
						if jrt.J2g_Truth(tmp20) { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp24 any; var iter__1927001039__auto____16_3 any; var tmp25 any = A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A_New(); var tmp26 *jrt.Class
							var fncls__84 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A_fn_class


















							if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A_fn_class = fncls__84d; tmp26 = fncls__84d } else { tmp26 = fncls__84 }; iter__1927001039__auto____16_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); tmp24 = lang.IFn_Cast(iter__1927001039__auto____16_3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__9)).Ref()))
//line :505:1
							vec__1464000293__16 = lang.Tuple_Create_O_O__IPersistentVector(tmp23.Invoke_O__O(tmp24), lang.PersistentVector_EMPTY.Ref()) } else { var tmp27 any
								var and__1927000168__auto____16_3 any = reached__15


















								if jrt.J2g_Truth(and__1927000168__auto____16_3) { var and__1927000168__auto____17_2 any = ab__12; if jrt.J2g_Truth(and__1927000168__auto____17_2) { var tmp28 *lang.Keyword = A_arbace_j2g_decls_A_const_378; var tmp29 *lang.Keyword = A_arbace_j2g_decls_A_const_81; tmp27 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp28.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1))))) } else { tmp27 = and__1927000168__auto____17_2 } } else { tmp27 = and__1927000168__auto____16_3 }
//line :505:1
								if jrt.J2g_Truth(tmp27) {




















									var tmp30 any = A_arbace_j2g_decls_method_forms_fn__1464000326_A_New_O_O_O_O_O_O_O_O(iface__5, static__7, pkg__0, n__1, ab__12, leaf__6, ps__9, mm__2); var tmp31 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000326_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_j2g_decls_method_forms_fn__1464000326_A_fn_class = fncls__75d; tmp31 = fncls__75d } else { tmp31 = fncls__75 }; vec__1464000293__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil).Invoke__O() } else {
//line :505:1
										if A_arbace_j2g_decls_A_const_160 != nil { var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp33 any; var iter__1927001039__auto____16_4 any; var tmp34 any = A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A_New(); var tmp35 *jrt.Class
											var fncls__87 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A_fn_class































											if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A_fn_class = fncls__87d; tmp35 = fncls__87d } else { tmp35 = fncls__87 }; iter__1927001039__auto____16_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); tmp33 = lang.IFn_Cast(iter__1927001039__auto____16_4).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__9)).Ref()))
//line :505:1
											vec__1464000293__16 = lang.Tuple_Create_O_O__IPersistentVector(tmp32.Invoke_O__O(tmp33), lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()).Invoke_O_O_O__O(n__1, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))) } else { vec__1464000293__16 = nil } } } } }
//line :503:1
		var pnames__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000293__16, lang.RT_IntCast_J__I_NoInit(0), nil); var body__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000293__16, lang.RT_IntCast_J__I_NoInit(1), nil); var plist__19 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, ps__9, pnames__17); var plist__20 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(plist__19, pkg__0, r__10); var body__21 any; var tmp36 any
		var and__1927000168__auto____21 any = static__7





































		if jrt.J2g_Truth(and__1927000168__auto____21) { var and__1927000168__auto____22 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_177, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2)); if and__1927000168__auto____22 { var and__1927000168__auto____23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_371.GetRawRoot__O()).Invoke_O__O(n__1); if jrt.J2g_Truth(and__1927000168__auto____23) { tmp36 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_372.GetRawRoot__O()).Invoke_O_O__O(n__1, Lit_178) } else { tmp36 = and__1927000168__auto____23 } } else { tmp36 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____22).Ref() } } else { tmp36 = and__1927000168__auto____21 }; if jrt.J2g_Truth(tmp36) {
			body__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_157)), body__18) } else {
//line :542:1
				body__21 = body__18
			}

		var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_232.GetRawRoot__O()); var tmp38 lang.IPersistentVector; var tmp39 any
		var and__1927000168__auto____22_2 any = static__7



		if jrt.J2g_Truth(and__1927000168__auto____22_2) { tmp39 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_379.GetRawRoot__O()).Invoke_O__O(n__1) } else { tmp39 = and__1927000168__auto____22_2 }
//line :546:1
		if jrt.J2g_Truth(tmp39) { var noinit__22 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil, Lit_179), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11, nil)).Ref()); var call__23 any; var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_decls_method_forms_fn__1464000348_A_New(); var tmp44 *jrt.Class
			var fncls__88 /*line :546:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000348_A_fn_class





			if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_j2g_decls_method_forms_fn__1464000348_A_fn_class = fncls__88d; tmp44 = fncls__88d } else { tmp44 = fncls__88 }; call__23 = tmp40.Invoke_O_O_O__O(tmp41, noinit__22, tmp42.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp43, tmp44, nil), plist__20))
//line :546:1
			var tmp45 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_380, noinit__22, plist__20, body__21); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_decls_A_const_381; var tmp48 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11)).Ref()); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp50 lang.IPersistentVector; var tmp51 any; var and__1927000168__auto____24 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(native__14)








			if jrt.J2g_Truth(and__1927000168__auto____24) { tmp51 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_382.GetRawRoot__O()).Invoke_O_O__O(n__1, ab__12) } else { tmp51 = and__1927000168__auto____24 }; if jrt.J2g_Truth(tmp51) { tmp50 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, g__4, nil)).Ref()))) } else { tmp50 = nil }
//line :546:1
			var tmp52 any = tmp50; var tmp53 any









			if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, r__10) { tmp53 = call__23 } else { tmp53 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_383, call__23) }
//line :546:1
			tmp38 = lang.Tuple_Create_O_O__IPersistentVector(tmp45, tmp46.Invoke_O_O_O_O__O(tmp47, tmp48, plist__20, tmp49.Invoke_O_O__O(tmp52, lang.Tuple_Create_O__IPersistentVector(tmp53)))) } else { if jrt.J2g_Truth(static__7) { var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp55 any = A_arbace_j2g_decls_A_const_384; var tmp56 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11)).Ref()); var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp58 lang.IPersistentVector; var tmp59 any; var and__1927000168__auto____22_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(native__14)












				if jrt.J2g_Truth(and__1927000168__auto____22_3) { tmp59 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_382.GetRawRoot__O()).Invoke_O_O__O(n__1, ab__12) } else { tmp59 = and__1927000168__auto____22_3 }; if jrt.J2g_Truth(tmp59) { tmp58 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, g__4, nil)).Ref()))) } else { tmp58 = nil }
//line :546:1
				tmp38 = lang.Tuple_Create_O__IPersistentVector(tmp54.Invoke_O_O_O_O__O(tmp55, tmp56, plist__20, tmp57.Invoke_O_O__O(tmp58, body__21))) } else { if jrt.J2g_Truth(iface__5) { var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp61 any = A_arbace_j2g_decls_A_const_385; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_decls_A_const_386; tmp38 = lang.Tuple_Create_O__IPersistentVector(tmp60.Invoke_O_O_O_O__O(tmp61, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp62.Invoke_O_O__O(tmp63, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__4)), plist__20)), lang.RT_Meta_O__IPersistentMap_NoInit(plist__20)), body__21)) } else { if jrt.J2g_Truth(leaf__6) { var tmp64 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp65 any = A_arbace_j2g_decls_A_const_387; var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp67 any = A_arbace_j2g_decls_A_const_388; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp69 any = A_arbace_j2g_decls_A_const_389; tmp38 = lang.Tuple_Create_O__IPersistentVector(tmp64.Invoke_O_O_O_O__O(tmp65, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(base__11), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp66.Invoke_O_O__O(tmp67, tmp68.Invoke_O_O__O(tmp69, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__4))), plist__20)), lang.RT_Meta_O__IPersistentMap_NoInit(plist__20)), body__21)) } else { if A_arbace_j2g_decls_A_const_160 != nil { var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp71 any = A_arbace_j2g_decls_A_const_390; var tmp72 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp73 any = A_arbace_j2g_decls_A_const_391; var tmp74 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp75 any = A_arbace_j2g_decls_A_const_392; var tmp76 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp77 any = A_arbace_j2g_decls_A_const_393; tmp38 = lang.Tuple_Create_O__IPersistentVector(tmp70.Invoke_O_O_O_O__O(tmp71, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_334.GetRawRoot__O()).Invoke_O__O(base__11)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp72.Invoke_O_O__O(tmp73, tmp74.Invoke_O_O__O(tmp75, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__4))), tmp76.Invoke_O_O__O(tmp77, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__4, nil)).Ref()))), plist__20)), lang.RT_Meta_O__IPersistentMap_NoInit(plist__20)), body__21)) } else { tmp38 = nil } } } } }
//line :545:1
		return tmp37.Invoke_O_O__O(mm__2, tmp38) } }
//line :507:1
func A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A) Ctor() {}
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A) Invoke_O_O__O(self, s__1464000297__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A_New_O_O(s__1464000297__1, self); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_186, false); A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :507:1
func A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A{}; t.Ctor_O_O(p0, p1); return t }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A) Ctor_O_O(c__s__1464000297, c__iter__1464000296 any) { t.F_s__1464000297 = c__s__1464000297; t.F_iter__1464000296 = c__iter__1464000296 }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A) Invoke_O__O(self any) any { { var s__1464000297__1 any; var t_ any = t.F_s__1464000297; t.F_s__1464000297 = nil; s__1464000297__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000297__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000297__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000297__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000297__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000299__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000299__6); var tmp2 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_187, false); A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A_fn_class = fncls__76d; tmp2 = fncls__76d } else { tmp2 = fncls__76 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000296); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000299__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000297__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000299__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000297__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000296); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000297__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :507:1
func A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000299 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000299 = c__b__1464000299 }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A) Invoke_O__O(self any) any { { var i__1464000298__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000298__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000298__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000299; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000298__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000298__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A) Invoke_O_O__O(self, s__1464000307__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A_New_O_O(self, s__1464000307__1); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_188, false); A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :520:1
func A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A{}; t.Ctor_O_O(p0, p1); return t }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A) Ctor_O_O(c__iter__1464000306, c__s__1464000307 any) { t.F_iter__1464000306 = c__iter__1464000306; t.F_s__1464000307 = c__s__1464000307 }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A) Invoke_O__O(self any) any { { var s__1464000307__1 any; var t_ any = t.F_s__1464000307; t.F_s__1464000307 = nil; s__1464000307__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000307__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000307__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000307__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000307__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000309__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A_New_O_I_O(b__1464000309__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000306); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000309__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000307__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000309__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000307__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000306); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000307__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :520:1
func A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A) Ctor_O_I_O(c__b__1464000309 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000309 = c__b__1464000309; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A) Invoke_O__O(self any) any { { var i__1464000308__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000308__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000308__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000309; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000308__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000308__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A) Ctor() {}
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A) Invoke_O_O__O(self, s__1464000317__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A_New_O_O(self, s__1464000317__1); var tmp2 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A_fn_class = fncls__83d; tmp2 = fncls__83d } else { tmp2 = fncls__83 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :524:1
func A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A{}; t.Ctor_O_O(p0, p1); return t }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A) Ctor_O_O(c__iter__1464000316, c__s__1464000317 any) { t.F_iter__1464000316 = c__iter__1464000316; t.F_s__1464000317 = c__s__1464000317 }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A) Invoke_O__O(self any) any { { var s__1464000317__1 any; var t_ any = t.F_s__1464000317; t.F_s__1464000317 = nil; s__1464000317__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000317__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000317__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000317__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000317__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000319__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A_New_O_I_O(b__1464000319__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, false); A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A_fn_class = fncls__82d; tmp2 = fncls__82d } else { tmp2 = fncls__82 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000316); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000319__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000317__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000319__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000317__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000316); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000317__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :524:1
func A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A) Ctor_O_I_O(c__b__1464000319 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000319 = c__b__1464000319; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A) Invoke_O__O(self any) any { { var i__1464000318__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000318__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000318__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000319; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000318__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000318__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_method_forms_fn__1464000326_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_j2g_decls_method_forms_fn__1464000326_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000326_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :526:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_A) Ctor_O_O_O_O_O_O_O_O(c__iface, c__static, c__pkg, c__n, c__ab, c__leaf, c__ps, c__mm any) { t.F_iface = c__iface; t.F_static = c__static; t.F_pkg = c__pkg; t.F_n = c__n; t.F_ab = c__ab; t.F_leaf = c__leaf; t.F_ps = c__ps; t.F_mm = c__mm }
//line :526:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_A) Invoke_O__O(self any) any { var tmp1 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_362.GetRawRoot__O()); var tmp3 any = t.F_pkg; var tmp4 any = t.F_n; var tmp5 any = t.F_mm; var tmp6 any; var t_ any = t.F_ab; t.F_ab = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 any = A_arbace_j2g_decls_A_const_86; var tmp9 any; var tmp10 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_static); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_iface) } else { tmp10 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp10) { tmp9 = A_arbace_j2g_decls_A_const_363 } else { tmp9 = nil }; var tmp11 any = tmp9; var tmp12 any = A_arbace_j2g_decls_A_const_87; var tmp13 any
												if jrt.J2g_Truth(t.F_static) { tmp13 = nil } else { var tmp14 any; var or__1927000174__auto____3 any; var t__2 any = t.F_leaf; t.F_leaf = nil; or__1927000174__auto____3 = t__2; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp14 = or__1927000174__auto____3 } else { tmp14 = t.F_iface }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var t__3 any = t.F_iface; t.F_iface = nil; tmp15 = t__3; if jrt.J2g_Truth(tmp15) { tmp13 = A_arbace_j2g_decls_A_const_364 } else { tmp13 = A_arbace_j2g_decls_A_const_365 } } else { tmp13 = A_arbace_j2g_decls_A_const_366 } }
//line :527:1
		var tmp16 any = tmp13; var tmp17 any = A_arbace_j2g_decls_A_const_88; var tmp18 any; var t__4 any = t.F_static; t.F_static = nil; tmp18 = t__4; tmp1 = tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp7, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp11, tmp12, tmp16, tmp17, tmp18))) }
//line :526:1
	return nil }(); if tmp19 != nil { if jrt.Exception_InstanceOf(tmp19) { var ex__3 jrt.Exception_I = jrt.Exception_Cast(tmp19)
		var tmp20 /*line :526:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_367




		if jrt.J2g_Truth(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_368.GetRawRoot__O()).Invoke_O__O(ex__3))) { var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____4 any; var tmp23 any = A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A_New(); var tmp24 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A_fn_class
			if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A_fn_class = fncls__74d; tmp24 = fncls__74d } else { tmp24 = fncls__74 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp25 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()); var tmp27 any; var t__5 any = t.F_ps; t.F_ps = nil; tmp27 = t__5; tmp22 = tmp25.Invoke_O__O(tmp26.Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(tmp27)).Ref()))
//line :531:1
			var tmp28 any = tmp21.Invoke_O__O(tmp22); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_decls_A_const_370; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()); var tmp33 any; var t__6 any = t.F_pkg

			t.F_pkg = nil; tmp33 = t__6
//line :531:1
			var tmp34 any = tmp32.Invoke_O_O__O(tmp33, Lit_109); var tmp35 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, nil, Lit_182, nil); var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()); var tmp37 any; var t__7 any = t.F_n


			t.F_n = nil; tmp37 = t__7
//line :531:1
			var tmp38 any = tmp36.Invoke_O_O_O__O(tmp37, Lit_11, Lit_12); var tmp39 any = A_arbace_j2g_decls_A_const_100.Invoke_O__O(t.F_mm); var tmp40 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp41 any; var t__8 any = t.F_mm


			t.F_mm = nil; tmp41 = t__8
//line :531:1
			tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, lang.Tuple_Create_O__IPersistentVector(tmp29.Invoke_O_O__O(tmp30, tmp31.Invoke_O_O__O(tmp34, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp35, jrt.RefArrayOf(jrt.Object_class, tmp38, nil, tmp39, tmp40.Invoke_O__O(tmp41), nil, ex__3.GetMessage__String().Ref())).Ref())))) } else { var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_369.GetRawRoot__O()); var tmp43 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_183, nil, Lit_12, nil, nil, Lit_182, nil); var tmp44 any; var t__9 any = t.F_n



				t.F_n = nil; tmp44 = t__9
//line :531:1
				var tmp45 any = tmp44; var tmp46 any = A_arbace_j2g_decls_A_const_100.Invoke_O__O(t.F_mm); var tmp47 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp48 any; var t__10 any = t.F_mm



				t.F_mm = nil; tmp48 = t__10
//line :531:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp42.Invoke_O_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp43, jrt.RefArrayOf(jrt.Object_class, nil, tmp45, nil, tmp46, tmp47.Invoke_O__O(tmp48), nil, ex__3.GetMessage__String().Ref())).Ref(), lang.PersistentArrayMap_EMPTY.Ref(), ex__3)))) } } else {
//line :526:1
					panic(tmp19) } }; return tmp1 }





func A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A_New() *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A) Ctor() {}
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A) Invoke_O_O__O(self, s__1464000328__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A_New_O_O(self, s__1464000328__1); var tmp2 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A_fn_class = fncls__73d; tmp2 = fncls__73d } else { tmp2 = fncls__73 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :532:1
func A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A{}; t.Ctor_O_O(p0, p1); return t }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A) Ctor_O_O(c__iter__1464000327, c__s__1464000328 any) { t.F_iter__1464000327 = c__iter__1464000327; t.F_s__1464000328 = c__s__1464000328 }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A) Invoke_O__O(self any) any { { var s__1464000328__1 any; var t_ any = t.F_s__1464000328; t.F_s__1464000328 = nil; s__1464000328__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000328__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000328__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000328__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000328__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000330__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A_New_I_O_O(size__1927001038__auto____5, b__1464000330__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_185, false); A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A_fn_class = fncls__72d; tmp2 = fncls__72d } else { tmp2 = fncls__72 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000327); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000330__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000328__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000330__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000328__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000327); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000328__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :532:1
func A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000330, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000330 = c__b__1464000330; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A) Invoke_O__O(self any) any { { var i__1464000329__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000329__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000329__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000330; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000329__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000329__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A) Ctor() {}
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A) Invoke_O_O__O(self, s__1464000339__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A_New_O_O(self, s__1464000339__1); var tmp2 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A_fn_class = fncls__86d; tmp2 = fncls__86d } else { tmp2 = fncls__86 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :537:1
func A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A{}; t.Ctor_O_O(p0, p1); return t }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A) Ctor_O_O(c__iter__1464000338, c__s__1464000339 any) { t.F_iter__1464000338 = c__iter__1464000338; t.F_s__1464000339 = c__s__1464000339 }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A) Invoke_O__O(self any) any { { var s__1464000339__1 any; var t_ any = t.F_s__1464000339; t.F_s__1464000339 = nil; s__1464000339__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000339__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000339__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000339__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000339__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000341__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A_New_I_O_O(size__1927001038__auto____5, b__1464000341__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A_fn_class = fncls__85d; tmp2 = fncls__85d } else { tmp2 = fncls__85 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000338); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000341__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000339__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000341__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000339__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000338); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000339__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :537:1
func A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000341, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000341 = c__b__1464000341; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A) Invoke_O__O(self any) any { { var i__1464000340__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000340__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000340__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000341; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000340__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000340__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }














func A_arbace_j2g_decls_method_forms_fn__1464000348_A_New() *A_arbace_j2g_decls_method_forms_fn__1464000348_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000348_A{}; t.Ctor(); return t }
//line :552:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000348_A) Ctor() {}
//line :552:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000348_A) Invoke_O_O__O(self, p1__1464000289_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(p1__1464000289_SHARP___1, nil) }



















func A_arbace_j2g_decls_forwarder_A_New() *A_arbace_j2g_decls_forwarder_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_j2g_decls_forwarder_A) Ctor() {}
//line :572:1
func (t *A_arbace_j2g_decls_forwarder_A) Invoke_O_O_O_O_O__O(self, pkg__0, n__1, p__1464000351__2, impl__3 any) any { var vec__1464000352__5 any = p__1464000351__2; var name__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000352__5, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000352__5, lang.RT_IntCast_J__I_NoInit(1), nil); var k__8 any = vec__1464000352__5; var g__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var vec__1464000355__10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(desc__7); var ps__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000355__10, lang.RT_IntCast_J__I_NoInit(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000355__10, lang.RT_IntCast_J__I_NoInit(1), nil); var base__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(name__6, desc__7); var pn__14 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____14 any; var tmp3 any = A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A_New(); var tmp4 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A_fn_class; _ = k__8; if





	fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A_fn_class = fncls__92d; tmp4 = fncls__92d } else { tmp4 = fncls__92 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__11)).Ref())); pn__14 = tmp1.Invoke_O__O(tmp2); var tmp5 lang.IFn = /*line :572:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_396; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_397; var plist__15 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__9))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, ps__11, pn__14))), pkg__0, r__12); var call__16 any; var G__1464000368__16_ any = A_arbace_j2g_decls_A_const_167.Invoke_O__O(impl__3); L1:







	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1464000368__16_) >> 3 & 3 { case 0: if any(G__1464000368__16_) == any(A_arbace_j2g_decls_A_const_394) {

		call__16 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, A_arbace_j2g_decls_A_const_333.Invoke_O__O(impl__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__13)).Ref()), A_arbace_j2g_decls_A_const_398, pn__14)
//line :580:1
		break L1 }; case 1: if any(G__1464000368__16_) == any(A_arbace_j2g_decls_A_const_34) {
			call__16 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__13)).Ref()), A_arbace_j2g_decls_A_const_399, A_arbace_j2g_decls_A_const_400, pn__14)
//line :580:1
			break L1 }; case 3: if any(G__1464000368__16_) == any(A_arbace_j2g_decls_A_const_395) {
				call__16 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_102, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__13)).Ref()), A_arbace_j2g_decls_A_const_399, A_arbace_j2g_decls_A_const_400, pn__14)
//line :580:1
				break L1 }; default:}; call__16 = nil}; if



	jrt.J2g_Truth(call__16) {
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_401; var tmp11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(base__13); var tmp12 any; if lang.Util_Equiv_O_O__Z_NoInit(Lit_62, r__12) { tmp12 = call__16 } else { tmp12 = call__16 }; return tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, plist__15, tmp12) } else {
//line :584:1
			return nil } }
//line :578:1
func A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A_New() *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A{}; t.Ctor(); return t }
//line :578:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A) Ctor() {}
//line :578:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A) Invoke_O_O__O(self, s__1464000359__1 any) any { var tmp1 any = A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A_New_O_O(s__1464000359__1, self); var tmp2 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A_fn_class = fncls__91d; tmp2 = fncls__91d } else { tmp2 = fncls__91 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :578:1
func A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :578:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A) Ctor_O_O(c__s__1464000359, c__iter__1464000358 any) { t.F_s__1464000359 = c__s__1464000359; t.F_iter__1464000358 = c__iter__1464000358 }
//line :578:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A) Invoke_O__O(self any) any { { var s__1464000359__1 any; var t_ any = t.F_s__1464000359; t.F_s__1464000359 = nil; s__1464000359__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000359__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000359__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000359__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000359__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000361__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A_New_O_I_O(b__1464000361__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A_fn_class = fncls__90d; tmp2 = fncls__90d } else { tmp2 = fncls__90 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000358); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000361__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000359__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000361__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000359__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000358); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000359__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :578:1
func A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :578:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A) Ctor_O_I_O(c__b__1464000361 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000361 = c__b__1464000361; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :578:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A) Invoke_O__O(self any) any { { var i__1464000360__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000360__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000360__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000361; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000360__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000360__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_decls_object_forms_A_New() *A_arbace_j2g_decls_object_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_object_forms_A{}; t.Ctor(); return t }
//line :587:1
func (t *A_arbace_j2g_decls_object_forms_A) Ctor() {}
//line :587:1
func (t *A_arbace_j2g_decls_object_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_403; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_404; var recv__4 any = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3))); var ts__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_402.GetRawRoot__O()).Invoke_O_O__O(n__1, A_arbace_j2g_decls_A_const_405); var cl__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_402.GetRawRoot__O()).Invoke_O_O__O(n__1, A_arbace_j2g_decls_A_const_406); var cloneable__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_329.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_68, nil, Lit_69), jrt.RefArrayOf(jrt.Object_class, nil, n__1, nil)).Ref(), Lit_195); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_259.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_408; var tmp9 any = A_arbace_j2g_decls_A_const_409; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_decls_A_const_412; var tmp12 any = tmp7.Invoke_O_O_O_O_O__O(tmp8, tmp9, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), A_arbace_j2g_decls_A_const_411), tmp10.Invoke_O_O_O__O(tmp11, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_413, A_arbace_j2g_decls_A_const_414, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_415, nil)), A_arbace_j2g_decls_A_const_410); var tmp13 any; var temp__1927000408__auto____8 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_object_forms_fn__1464000371_A_New(); var tmp17 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_decls_object_forms_fn__1464000371_A_fn_class; if











	fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_196, false); A_arbace_j2g_decls_object_forms_fn__1464000371_A_fn_class = fncls__93d; tmp17 = fncls__93d } else { tmp17 = fncls__93 }; temp__1927000408__auto____8 = tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_416.GetRawRoot__O()).Invoke_O__O(n__1))); if jrt.J2g_Truth(temp__1927000408__auto____8) { var f__9 any = temp__1927000408__auto____8; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_A_const_417; var tmp20 any = A_arbace_j2g_decls_A_const_418; var tmp21 any = A_arbace_j2g_decls_A_const_18; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_decls_A_const_419; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_420; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_421; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_423
		tmp13 = tmp18.Invoke_O_O_O_O_O__O(tmp19, tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp22.Invoke_O_O__O(tmp23, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_197))))), tmp24.Invoke_O_O_O__O(tmp25, tmp26.Invoke_O_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__9)))).Ref()), A_arbace_j2g_decls_A_const_422), nil), tmp28.Invoke_O_O__O(tmp29, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__9)))).Ref()), A_arbace_j2g_decls_A_const_424))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())) } else {



			var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_decls_A_const_425; var tmp32 any = A_arbace_j2g_decls_A_const_426; var tmp33 any = A_arbace_j2g_decls_A_const_18; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_427; tmp13 = tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34.Invoke_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_197))))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())) }; var tmp36 any = tmp13; var tmp37 any; var tmp38 any = A_arbace_j2g_decls_A_const_407; if
	lang.Util_Equiv_O_O__Z_NoInit(tmp38, A_arbace_j2g_decls_A_const_167.Invoke_O__O(ts__5)) {
		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_decls_A_const_428; var tmp41 any = A_arbace_j2g_decls_A_const_429; var tmp42 any = A_arbace_j2g_decls_A_const_18; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_A_const_430; tmp37 = tmp39.Invoke_O_O_O_O__O(tmp40, tmp41, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp43.Invoke_O_O__O(tmp44, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_198))))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_199), A_arbace_j2g_decls_A_const_431)) } else {
//line :605:1
			tmp37 = nil }; var tmp45 any = tmp37; var tmp46 any; var tmp47 any = A_arbace_j2g_decls_A_const_407; if


	lang.Util_Equiv_O_O__Z_NoInit(tmp47, A_arbace_j2g_decls_A_const_167.Invoke_O__O(cl__6)) {
		var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_decls_A_const_432; var tmp50 any = A_arbace_j2g_decls_A_const_433; tmp46 = tmp48.Invoke_O_O_O_O__O(tmp49, tmp50, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), A_arbace_j2g_decls_A_const_434), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_200), A_arbace_j2g_decls_A_const_435)) } else {
//line :608:1
			tmp46 = nil }; var tmp51 any = tmp46; var tmp52 lang.IFn = /*line :595:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp53 any = A_arbace_j2g_decls_A_const_436; var tmp54 any = A_arbace_j2g_decls_A_const_437; var tmp55 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), A_arbace_j2g_decls_A_const_438); var tmp56 any; if















	jrt.J2g_Truth(cloneable__7) {
		var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp58 any = A_arbace_j2g_decls_A_const_439; var tmp59 any = A_arbace_j2g_decls_A_const_440; var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp61 any = A_arbace_j2g_decls_A_const_443; tmp56 = tmp57.Invoke_O_O_O_O__O(tmp58, lang.Tuple_Create_O_O__IPersistentVector(tmp59, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_441, A_arbace_j2g_decls_A_const_442)), tmp60.Invoke_O_O__O(tmp61, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_444, A_arbace_j2g_decls_A_const_445)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_446, A_arbace_j2g_decls_A_const_447)) } else {


			var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_decls_A_const_448; tmp56 = tmp62.Invoke_O_O__O(tmp63, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_201), A_arbace_j2g_decls_A_const_449)) }; return /*line :595:1*/ tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp12, tmp36, tmp45, tmp51, tmp52.Invoke_O_O_O_O__O(tmp53, tmp54, tmp55, tmp56))) }



func A_arbace_j2g_decls_object_forms_fn__1464000371_A_New() *A_arbace_j2g_decls_object_forms_fn__1464000371_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_object_forms_fn__1464000371_A{}; t.Ctor(); return t }
//line :599:1
func (t *A_arbace_j2g_decls_object_forms_fn__1464000371_A) Ctor() {}
//line :599:1
func (t *A_arbace_j2g_decls_object_forms_fn__1464000371_A) Invoke_O_O__O(self, p1__1464000370_SHARP___1 any) any { var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_202, A_arbace_j2g_decls_A_const_100.Invoke_O__O(p1__1464000370_SHARP___1)); if and__1927000168__auto____2 { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(p1__1464000370_SHARP___1)) } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

















func A_arbace_j2g_decls_dispatch_forms_A_New() *A_arbace_j2g_decls_dispatch_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_A{}; t.Ctor(); return t }
//line :617:1
func (t *A_arbace_j2g_decls_dispatch_forms_A) Ctor() {}
//line :617:1
func (t *A_arbace_j2g_decls_dispatch_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var own__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A_New(); var tmp4 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A_fn_class; if


	fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A_fn_class = fncls__105d; tmp4 = fncls__105d } else { tmp4 = fncls__105 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_458.GetRawRoot__O()).Invoke_O__O(n__1)); own__3 = tmp1.Invoke_O__O(tmp2); var leaf__4 any = /*line :617:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1); var iter__1927001039__auto____5 any; var tmp5 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A_New_O_O_O_O(own__3, pkg__0, n__1, leaf__4); var tmp6 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A_fn_class; if





	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A_fn_class = fncls__102d; tmp6 = fncls__102d } else { tmp6 = fncls__102 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_459.GetRawRoot__O()).Invoke_O__O(n__1); var tmp10 any; var iter__1927001039__auto____6 any; var tmp11 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A_New(); var tmp12 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A_fn_class = fncls__108d; tmp12 = fncls__108d } else { tmp12 = fncls__108 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_461.GetRawRoot__O())); return tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10)) }
//line :620:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A{}; t.Ctor(); return t }
//line :620:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A) Ctor() {}
//line :620:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A) Invoke_O_O__O(self, s__1464000375__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A_New_O_O(s__1464000375__1, self); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :620:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A{}; t.Ctor_O_O(p0, p1); return t }
//line :620:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A) Ctor_O_O(c__s__1464000375, c__iter__1464000374 any) { t.F_s__1464000375 = c__s__1464000375; t.F_iter__1464000374 = c__iter__1464000374 }
//line :620:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A) Invoke_O__O(self any) any { { var s__1464000375__1 any; var t_ any = t.F_s__1464000375; t.F_s__1464000375 = nil; s__1464000375__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000375__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000375__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000375__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000375__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000377__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A_New_O_I_O(b__1464000377__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A_fn_class = fncls__103d; tmp2 = fncls__103d } else { tmp2 = fncls__103 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000374); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000377__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000375__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000377__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000375__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000374); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000375__3))) } else { s__1464000375__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000375__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :620:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :620:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A) Ctor_O_I_O(c__b__1464000377 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000377 = c__b__1464000377; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :620:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A) Invoke_O__O(self any) any { { var i__1464000376__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000376__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000376__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp4 any = t.F_b__1464000377; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))); i__1464000376__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000376__1); continue L1 } else { i__1464000376__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000376__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A) Ctor_O_O_O_O(c__own, c__pkg, c__n, c__leaf any) { t.F_own = c__own; t.F_pkg = c__pkg; t.F_n = c__n; t.F_leaf = c__leaf }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A) Invoke_O_O__O(self, s__1464000385__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A_New_O_O_O_O_O_O(t.F_own, t.F_pkg, t.F_n, s__1464000385__1, self, t.F_leaf); var tmp2 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A_fn_class = fncls__101d; tmp2 = fncls__101d } else { tmp2 = fncls__101 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :623:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A) Ctor_O_O_O_O_O_O(c__own, c__pkg, c__n, c__s__1464000385, c__iter__1464000384, c__leaf any) { t.F_own = c__own; t.F_pkg = c__pkg; t.F_n = c__n; t.F_s__1464000385 = c__s__1464000385; t.F_iter__1464000384 = c__iter__1464000384; t.F_leaf = c__leaf }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A) Invoke_O__O(self any) any { { var s__1464000385__1 any; var t_ any = t.F_s__1464000385; t.F_s__1464000385 = nil; s__1464000385__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000385__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000385__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000385__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000385__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000387__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A_New_O_O_O_O_I_O_O(t.F_own, t.F_pkg, t.F_n, t.F_leaf, size__1927001038__auto____5, c__1927001037__auto____4, b__1464000387__6); var tmp2 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A_fn_class = fncls__97d; tmp2 = fncls__97d } else { tmp2 = fncls__97 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000384); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000387__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000385__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000387__6), nil) } } else { var vec__1464000411__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000385__3); var k__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000411__4, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000411__4, lang.RT_IntCast_J__I_NoInit(1), nil); var impl__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_402.GetRawRoot__O()).Invoke_O_O__O(t.F_n, k__5); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____8 any = t.F_leaf

	if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_own, k__5); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 any = t.F_n; tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp6, A_arbace_j2g_decls_A_const_333.Invoke_O__O(impl__7))).Ref() } else { tmp5 = and__1927000168__auto____9 } } else { tmp5 = and__1927000168__auto____8 }
//line :623:1
	if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) { var f__8 any


		if lang.Util_Identical_O_O__Z_NoInit(impl__7, nil) { var vec__1464000414__8 any = k__5; var name__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000414__8, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000414__8, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1464000417__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(desc__10); var ps__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000417__11, lang.RT_IntCast_J__I_NoInit(0), nil); var r__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000417__11, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__14 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp8 any; var iter__1927001039__auto____14 any; var tmp9 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A_New(); var tmp10 *jrt.Class
			var fncls__100 /*line :626:1*/*jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A_fn_class



			if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A_fn_class = fncls__100d; tmp10 = fncls__100d } else { tmp10 = fncls__100 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__12)).Ref())); pn__14 = tmp7.Invoke_O__O(tmp8)
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_452; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_453; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_454; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_decls_A_const_455; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()); var tmp20 any = t.F_n; f__8 = tmp11.Invoke_O_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(name__9, desc__10)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(t.F_n)))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__12, pn__14))), t.F_pkg, r__13), lang.Tuple_Create_O__IPersistentVector(tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_122), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_123), tmp19.Invoke_O_O_O__O(tmp20, A_arbace_j2g_decls_A_const_333.Invoke_O__O(mm__6), k__5)))))) } else {
//line :626:1
				var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457); if jrt.J2g_Truth(tmp21.Invoke_O__O(A_arbace_j2g_decls_A_const_167.Invoke_O__O(impl__7))) { f__8 = nil } else { if A_arbace_j2g_decls_A_const_160 != nil {










					f__8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_451.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_pkg, t.F_n, k__5, impl__7) } else {
//line :626:1
						f__8 = nil } } }
//line :623:1
		if jrt.J2g_Truth(f__8) { var tmp22 lang.IFn = lang.IFn_Cast(t.F_iter__1464000384); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(f__8, tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000385__3))) } else { s__1464000385__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000385__3); continue L1 } } else { s__1464000385__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000385__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :623:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A) Ctor_O_O_O_O_I_O_O(c__own, c__pkg, c__n, c__leaf any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000387 any) { t.F_own = c__own; t.F_pkg = c__pkg; t.F_n = c__n; t.F_leaf = c__leaf; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000387 = c__b__1464000387 }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A) Invoke_O__O(self any) any { { var i__1464000386__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000386__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1464000391__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000386__1)); var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000391__2, lang.RT_IntCast_J__I_NoInit(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000391__2, lang.RT_IntCast_J__I_NoInit(1), nil); var impl__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_402.GetRawRoot__O()).Invoke_O_O__O(t.F_n, k__3); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp3 any; var and__1927000168__auto____6 any = t.F_leaf

	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_own, k__3); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp4 any = t.F_n; tmp3 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp4, A_arbace_j2g_decls_A_const_333.Invoke_O__O(impl__5))).Ref() } else { tmp3 = and__1927000168__auto____7 } } else { tmp3 = and__1927000168__auto____6 }
//line :623:1
	if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { var f__6 any


		if lang.Util_Identical_O_O__Z_NoInit(impl__5, nil) { var vec__1464000394__6 any = k__3; var name__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000394__6, lang.RT_IntCast_J__I_NoInit(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000394__6, lang.RT_IntCast_J__I_NoInit(1), nil); var vec__1464000397__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(desc__8); var ps__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000397__9, lang.RT_IntCast_J__I_NoInit(0), nil); var r__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000397__9, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__12 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____12 any; var tmp7 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A_New(); var tmp8 *jrt.Class
			var fncls__96 /*line :626:1*/*jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A_fn_class



			if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A_fn_class = fncls__96d; tmp8 = fncls__96d } else { tmp8 = fncls__96 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__10)).Ref())); pn__12 = tmp5.Invoke_O__O(tmp6)
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_452; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_453; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_454; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_455; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()); var tmp18 any = t.F_n; f__6 = tmp9.Invoke_O_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(name__7, desc__8)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(t.F_n)))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__10, pn__12))), t.F_pkg, r__11), lang.Tuple_Create_O__IPersistentVector(tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_122), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_123), tmp17.Invoke_O_O_O__O(tmp18, A_arbace_j2g_decls_A_const_333.Invoke_O__O(mm__4), k__3)))))) } else {
//line :626:1
				var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_450); if jrt.J2g_Truth(tmp19.Invoke_O__O(A_arbace_j2g_decls_A_const_167.Invoke_O__O(impl__5))) { f__6 = nil } else { if A_arbace_j2g_decls_A_const_160 != nil {










					f__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_451.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_pkg, t.F_n, k__3, impl__5) } else {
//line :626:1
						f__6 = nil } } }
//line :623:1
		if jrt.J2g_Truth(f__6) { lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1464000387, f__6); i__1464000386__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000386__1); continue L1 } else { i__1464000386__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000386__1); continue L1 } } else { i__1464000386__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000386__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :623:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A{}; t.Ctor(); return t }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A) Ctor() {}
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A) Invoke_O_O__O(self, s__1464000433__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A_New_O_O(s__1464000433__1, self); var tmp2 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A_fn_class = fncls__107d; tmp2 = fncls__107d } else { tmp2 = fncls__107 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :623:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A{}; t.Ctor_O_O(p0, p1); return t }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A) Ctor_O_O(c__s__1464000433, c__iter__1464000432 any) { t.F_s__1464000433 = c__s__1464000433; t.F_iter__1464000432 = c__iter__1464000432 }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A) Invoke_O__O(self any) any { { var s__1464000433__1 any; var t_ any = t.F_s__1464000433; t.F_s__1464000433 = nil; s__1464000433__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000433__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000433__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000433__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000433__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000435__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A_New_O_I_O(b__1464000435__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A_fn_class = fncls__106d; tmp2 = fncls__106d } else { tmp2 = fncls__106 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000432); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000435__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000433__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000435__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000433__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000432); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(k__4, nil), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000433__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :623:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A) Ctor_O_I_O(c__b__1464000435 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000435 = c__b__1464000435; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :623:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A) Invoke_O__O(self any) any { { var i__1464000434__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000434__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000434__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000435; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__2, nil)); i__1464000434__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000434__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A) Ctor() {}
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A) Invoke_O_O__O(self, s__1464000401__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A_New_O_O(s__1464000401__1, self); var tmp2 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A_fn_class = fncls__95d; tmp2 = fncls__95d } else { tmp2 = fncls__95 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :630:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A{}; t.Ctor_O_O(p0, p1); return t }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A) Ctor_O_O(c__s__1464000401, c__iter__1464000400 any) { t.F_s__1464000401 = c__s__1464000401; t.F_iter__1464000400 = c__iter__1464000400 }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A) Invoke_O__O(self any) any { { var s__1464000401__1 any; var t_ any = t.F_s__1464000401; t.F_s__1464000401 = nil; s__1464000401__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000401__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000401__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000401__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000401__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000403__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A_New_O_I_O(b__1464000403__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000400); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000403__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000401__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000403__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000401__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000400); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000401__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :630:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A) Ctor_O_I_O(c__b__1464000403 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000403 = c__b__1464000403; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A) Invoke_O__O(self any) any { { var i__1464000402__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000402__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000402__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000403; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000402__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000402__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :630:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A{}; t.Ctor(); return t }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A) Ctor() {}
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A) Invoke_O_O__O(self, s__1464000421__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A_New_O_O(s__1464000421__1, self); var tmp2 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A_fn_class = fncls__99d; tmp2 = fncls__99d } else { tmp2 = fncls__99 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :630:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A{}; t.Ctor_O_O(p0, p1); return t }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A) Ctor_O_O(c__s__1464000421, c__iter__1464000420 any) { t.F_s__1464000421 = c__s__1464000421; t.F_iter__1464000420 = c__iter__1464000420 }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A) Invoke_O__O(self any) any { { var s__1464000421__1 any; var t_ any = t.F_s__1464000421; t.F_s__1464000421 = nil; s__1464000421__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000421__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000421__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000421__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000421__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000423__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A_New_O_I_O(b__1464000423__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A_fn_class = fncls__98d; tmp2 = fncls__98d } else { tmp2 = fncls__98 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000420); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000423__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000421__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000423__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000421__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000420); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000421__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :630:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A) Ctor_O_I_O(c__b__1464000423 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000423 = c__b__1464000423; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :630:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A) Invoke_O__O(self any) any { { var i__1464000422__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000422__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000422__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000423; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000422__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000422__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }













func A_arbace_j2g_decls_static_forms_A_New() *A_arbace_j2g_decls_static_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_A{}; t.Ctor(); return t }
//line :644:1
func (t *A_arbace_j2g_decls_static_forms_A) Ctor() {}
//line :644:1
func (t *A_arbace_j2g_decls_static_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A_New_O_O_O(g__3, pkg__0, n__1); var tmp2 *jrt.Class; var fncls__117 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A_fn_class; if

	fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_258, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A_fn_class = fncls__117d; tmp2 = fncls__117d } else { tmp2 = fncls__117 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_416.GetRawRoot__O()).Invoke_O__O(n__1)) }
//line :646:1
func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :646:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A) Ctor_O_O_O(c__g, c__pkg, c__n any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n }
//line :646:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A) Invoke_O_O__O(self, s__1464000444__1 any) any { var tmp1 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A_New_O_O_O_O_O(t.F_g, t.F_pkg, t.F_n, s__1464000444__1, self); var tmp2 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_259, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A_fn_class = fncls__116d; tmp2 = fncls__116d } else { tmp2 = fncls__116 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :646:1
func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :646:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A) Ctor_O_O_O_O_O(c__g, c__pkg, c__n, c__s__1464000444, c__iter__1464000443 any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_s__1464000444 = c__s__1464000444; t.F_iter__1464000443 = c__iter__1464000443 }
//line :646:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A) Invoke_O__O(self any) any { { var s__1464000444__1 any; var t_ any = t.F_s__1464000444; t.F_s__1464000444 = nil; s__1464000444__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000444__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000444__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000444__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000444__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000446__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A_New_O_O_O_O_I_O(b__1464000446__6, t.F_g, t.F_pkg, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_260, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A_fn_class = fncls__112d; tmp2 = fncls__112d } else { tmp2 = fncls__112 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000443); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000446__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000444__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000446__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000444__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_463.GetRawRoot__O()); var tmp5 any = t.F_g; var s__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__4))); var cv__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_462.GetRawRoot__O()).Invoke_O__O(f__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()); var tmp7 any; var tmp8 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464.GetRawRoot__O()).Invoke_O__O(cv__6)



	if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_465.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)); if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(f__4), A_arbace_j2g_decls_A_const_470); if jrt.J2g_Truth(and__1927000168__auto____9) {
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp10 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_479); var and__1927000168__auto____10 any = tmp11.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)); if jrt.J2g_Truth(and__1927000168__auto____10) { var d__11 float64 = lang.RT_DoubleCast_O__D_NoInit(cv__6); var or__1927000174__auto____12 bool = jrt.Double_IsNaN_D__Z_NoInit(d__11); if or__1927000174__auto____12 { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____12).Ref() } else { var or__1927000174__auto____13 bool = jrt.Double_IsInfinite_D__Z_NoInit(d__11); if or__1927000174__auto____13 { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____13).Ref() } else { var and__1927000168__auto____14 bool = lang.Numbers_IsZero_D__Z_NoInit(d__11); if and__1927000168__auto____14 { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_D__Z_NoInit(jrt.Math_CopySign_D_D__D(1.0, d__11))).Ref() } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____14).Ref() } } } } else { tmp10 = and__1927000168__auto____10 }; tmp8 = tmp9.Invoke_O__O(tmp10) } else {
//line :650:1
			tmp8 = and__1927000168__auto____9 } } else { tmp8 = and__1927000168__auto____8 } } else { tmp8 = and__1927000168__auto____7 }
//line :649:1
	if jrt.J2g_Truth(tmp8) { var v__7 any; var G__1464000456__7_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)


	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1464000456__7_) { case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000456__7_, Lit_136) {

		var tmp12 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_466.GetRawRoot__O()).Invoke_O__O(cv__6)) { tmp12 = cv__6 } else { tmp12 = jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_O__C_NoInit(cv__6)).Ref() }; v__7 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(tmp12))).Ref()
//line :652:1
		break L2 }; case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000456__7_, Lit_137) {


			v__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_467.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4), cv__6)
//line :652:1
			break L2 }; case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000456__7_, Lit_138) {


				v__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_467.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4), cv__6)
//line :652:1
				break L2 }; case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000456__7_, Lit_142) {
					v__7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(cv__6)).Ref()
//line :652:1
					break L2 }; default:
	}


		v__7 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(cv__6)).Ref()}
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_472; var tmp15 any = A_arbace_j2g_decls_A_const_18; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp17 any = t.F_pkg; tmp7 = tmp13.Invoke_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(s__5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16.Invoke_O_O__O(tmp17, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)), A_arbace_j2g_decls_A_const_473, v__7))), v__7) } else {
//line :649:1
			var tmp18 any; var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464.GetRawRoot__O()).Invoke_O__O(cv__6)








			if jrt.J2g_Truth(and__1927000168__auto____7_2) { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_478); tmp18 = tmp19.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)) } else { tmp18 = and__1927000168__auto____7_2 }
//line :649:1
			if jrt.J2g_Truth(tmp18) {









				var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_decls_A_const_474; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp23 any = t.F_pkg; var tmp24 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__5, tmp22.Invoke_O_O__O(tmp23, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4))); var tmp25 any; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp28 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A_New_O_O(f__4, cv__6); var tmp29 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_261, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A_fn_class = fncls__114d; tmp29 = fncls__114d } else { tmp29 = fncls__114 }; tmp25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O(); tmp7 = tmp20.Invoke_O_O_O__O(tmp21, tmp24, tmp25) } else {
//line :649:1
					var tmp30 any; var and__1927000168__auto____7_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464.GetRawRoot__O()).Invoke_O__O(cv__6)










					if jrt.J2g_Truth(and__1927000168__auto____7_3) { tmp30 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_469.GetRawRoot__O()).Invoke_O__O(cv__6) } else { tmp30 = and__1927000168__auto____7_3 }
//line :649:1
					if jrt.J2g_Truth(tmp30) {











						var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_decls_A_const_475; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp34 any = t.F_pkg; var tmp35 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__5, tmp33.Invoke_O_O__O(tmp34, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4))); var tmp36 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp37.Invoke_O_O__O(tmp38, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp39 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A_New_O(cv__6); var tmp40 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_262, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A_fn_class = fncls__115d; tmp40 = fncls__115d } else { tmp40 = fncls__115 }; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil).Invoke__O(); tmp7 = tmp31.Invoke_O_O_O__O(tmp32, tmp35, tmp36) } else {
//line :649:1
							if A_arbace_j2g_decls_A_const_160 != nil {













								var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_decls_A_const_476; tmp7 = tmp41.Invoke_O_O__O(tmp42, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_477.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__4))) } else {
//line :649:1
									tmp7 = nil } } } }
//line :646:1
	var tmp43 lang.IFn = lang.IFn_Cast(t.F_iter__1464000443); return tmp6.Invoke_O_O__O(tmp7, tmp43.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000444__3))) } else { s__1464000444__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000444__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :646:1
func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :646:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A) Ctor_O_O_O_O_I_O(c__b__1464000446, c__g, c__pkg, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000446 = c__b__1464000446; t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :646:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A) Invoke_O__O(self any) any { { var i__1464000445__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000445__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000445__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_463.GetRawRoot__O()); var tmp3 any = t.F_g; var s__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__2))); var cv__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_462.GetRawRoot__O()).Invoke_O__O(f__2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp5 any = t.F_b__1464000446; var tmp6 any; var tmp7 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464.GetRawRoot__O()).Invoke_O__O(cv__4)



	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_465.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(f__2), A_arbace_j2g_decls_A_const_470); if jrt.J2g_Truth(and__1927000168__auto____7) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp9 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_471); var and__1927000168__auto____8 any = tmp10.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)); if jrt.J2g_Truth(and__1927000168__auto____8) { var d__9 float64 = lang.RT_DoubleCast_O__D_NoInit(cv__4); var or__1927000174__auto____10 bool = jrt.Double_IsNaN_D__Z_NoInit(d__9); if or__1927000174__auto____10 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____10).Ref() } else { var or__1927000174__auto____11 bool = jrt.Double_IsInfinite_D__Z_NoInit(d__9); if or__1927000174__auto____11 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 bool = lang.Numbers_IsZero_D__Z_NoInit(d__9); if and__1927000168__auto____12 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Numbers_IsNeg_D__Z_NoInit(jrt.Math_CopySign_D_D__D(1.0, d__9))).Ref() } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____12).Ref() } } } } else { tmp9 = and__1927000168__auto____8 }; tmp7 = tmp8.Invoke_O__O(tmp9) } else {
//line :650:1
			tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 } } else { tmp7 = and__1927000168__auto____5 }
//line :649:1
	if jrt.J2g_Truth(tmp7) { var v__5 any; var G__1464000450__5_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)


	L2: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1464000450__5_) { case 67: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000450__5_, Lit_136) {

		var tmp11 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_466.GetRawRoot__O()).Invoke_O__O(cv__4)) { tmp11 = cv__4 } else { tmp11 = jrt.Character_ValueOf_C__Character_NoInit(lang.RT_CharCast_O__C_NoInit(cv__4)).Ref() }; v__5 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_O__I_NoInit(tmp11))).Ref()
//line :652:1
		break L2 }; case 68: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000450__5_, Lit_137) {


			v__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_467.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2), cv__4)
//line :652:1
			break L2 }; case 70: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000450__5_, Lit_138) {


				v__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_467.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2), cv__4)
//line :652:1
				break L2 }; case 90: if lang.Util_Equiv_O_O__Z_NoInit(G__1464000450__5_, Lit_142) {
					v__5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(cv__4)).Ref()
//line :652:1
					break L2 }; default:
	}


		v__5 = jrt.Long_ValueOf_J__Long_NoInit(lang.RT_LongCast_O__J_NoInit(cv__4)).Ref()}
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_decls_A_const_472; var tmp14 any = A_arbace_j2g_decls_A_const_18; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp16 any = t.F_pkg; tmp6 = tmp12.Invoke_O_O_O__O(tmp13, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(s__3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15.Invoke_O_O__O(tmp16, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)), A_arbace_j2g_decls_A_const_473, v__5))), v__5) } else {
//line :649:1
			var tmp17 any; var and__1927000168__auto____5_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464.GetRawRoot__O()).Invoke_O__O(cv__4)








			if jrt.J2g_Truth(and__1927000168__auto____5_2) { var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_468); tmp17 = tmp18.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)) } else { tmp17 = and__1927000168__auto____5_2 }
//line :649:1
			if jrt.J2g_Truth(tmp17) {









				var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_decls_A_const_474; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp22 any = t.F_pkg; var tmp23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__3, tmp21.Invoke_O_O__O(tmp22, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2))); var tmp24 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp27 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A_New_O_O(f__2, cv__4); var tmp28 *jrt.Class; var fncls__110 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A_fn_class; if fncls__110 == nil { var fncls__110d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_263, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A_fn_class = fncls__110d; tmp28 = fncls__110d } else { tmp28 = fncls__110 }; tmp24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil).Invoke__O(); tmp6 = tmp19.Invoke_O_O_O__O(tmp20, tmp23, tmp24) } else {
//line :649:1
					var tmp29 any; var and__1927000168__auto____5_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464.GetRawRoot__O()).Invoke_O__O(cv__4)










					if jrt.J2g_Truth(and__1927000168__auto____5_3) { tmp29 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_469.GetRawRoot__O()).Invoke_O__O(cv__4) } else { tmp29 = and__1927000168__auto____5_3 }
//line :649:1
					if jrt.J2g_Truth(tmp29) {











						var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_decls_A_const_475; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp33 any = t.F_pkg; var tmp34 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__3, tmp32.Invoke_O_O__O(tmp33, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2))); var tmp35 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp37 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp36.Invoke_O_O__O(tmp37, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp38 any = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A_New_O(cv__4); var tmp39 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_264, false); A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A_fn_class = fncls__111d; tmp39 = fncls__111d } else { tmp39 = fncls__111 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O(); tmp6 = tmp30.Invoke_O_O_O__O(tmp31, tmp34, tmp35) } else {
//line :649:1
							if A_arbace_j2g_decls_A_const_160 != nil {













								var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_476; tmp6 = tmp40.Invoke_O_O__O(tmp41, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_477.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__2))) } else {
//line :649:1
									tmp6 = nil } } } }
//line :646:1
	tmp4.Invoke_O_O__O(tmp5, tmp6); i__1464000445__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000445__1); continue L1 } else { i__1464000445__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000445__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A{}; t.Ctor_O_O(p0, p1); return t }
//line :659:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A) Ctor_O_O(c__f, c__cv any) { t.F_f = c__f; t.F_cv = c__cv }
//line :659:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_467.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var t__2 any = t.F_cv; t.F_cv = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp5, tmp6) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :659:1
func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A{}; t.Ctor_O_O(p0, p1); return t }
//line :659:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A) Ctor_O_O(c__f, c__cv any) { t.F_f = c__f; t.F_cv = c__cv }
//line :659:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_467.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var t__2 any = t.F_cv; t.F_cv = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp5, tmp6) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A_New_O(p0 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A{}; t.Ctor_O(p0); return t }
//line :661:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A) Ctor_O(c__cv any) { t.F_cv = c__cv }
//line :661:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_cv; t.F_cv = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :661:1
func A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A_New_O(p0 any) *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A{}; t.Ctor_O(p0); return t }
//line :661:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A) Ctor_O(c__cv any) { t.F_cv = c__cv }
//line :661:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_cv; t.F_cv = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }







func A_arbace_j2g_decls_calls_in_A_New() *A_arbace_j2g_decls_calls_in_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_calls_in_A{}; t.Ctor(); return t }
//line :669:1
func (t *A_arbace_j2g_decls_calls_in_A) Ctor() {}
//line :669:1
func (t *A_arbace_j2g_decls_calls_in_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_480.GetRawRoot__O()).Invoke_O__O(f__0)) { var na_118 int64; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0)) { na_118 = 1 } else { na_118 = 0 }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_481.GetRawRoot__O(); var tmp3 any = A_arbace_j2g_decls_A_const_289; var na_119 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_482.GetRawRoot__O(), f__0)); if jrt.Long_InstanceOf(na_119) { var n0_120 int64 = na_118; var n1_121 int64 = jrt.NN(jrt.Long_Cast(na_119)).LongValue__J(); var nr_122 int64 = n0_120 + n1_121; if (n0_120^nr_122)&(n1_121^nr_122) >= 0 { return jrt.Long_ValueOf_J__Long_NoInit(nr_122).Ref() } else { return lang.Numbers_Add_J_O__Number_NoInit(na_118, na_119) } } else { return lang.Numbers_Add_J_O__Number_NoInit(na_118, na_119) } } else { return A_arbace_j2g_decls_A_const_289
	} }
func A_arbace_j2g_decls_splittable_QMARK__A_New() *A_arbace_j2g_decls_splittable_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_splittable_QMARK__A{}; t.Ctor(); return t }
//line :674:1
func (t *A_arbace_j2g_decls_splittable_QMARK__A) Ctor() {}
//line :674:1
func (t *A_arbace_j2g_decls_splittable_QMARK__A) Invoke_O_O__O(self, body__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_483.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_484; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_485.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_486.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_480.GetRawRoot__O(), A_arbace_j2g_decls_A_const_30.GetRawRoot__O(), body__0)))
}

func A_arbace_j2g_decls_split_clinit_A_New() *A_arbace_j2g_decls_split_clinit_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_A{}; t.Ctor(); return t }
//line :681:1
func (t *A_arbace_j2g_decls_split_clinit_A) Ctor() {}
//line :681:1
func (t *A_arbace_j2g_decls_split_clinit_A) Invoke_O_O_O__O(self, g__0, body__1 any) any { var body__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(body__1); var tmp1 any; var or__1927000174__auto____4 bool; var na_123 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_482.GetRawRoot__O()).Invoke_O__O(body__3); var na_124 any; var na_125 int64 = 2; var na_126 any = A_arbace_j2g_decls_A_const_487.GetRawRoot__O(); if








	jrt.Long_InstanceOf(na_126) { var n0_127 int64 = na_125; var n1_128 int64 = jrt.NN(jrt.Long_Cast(na_126)).LongValue__J(); var nr_129 int64 = n0_127 * n1_128; var tmp2 bool; var tmp3 bool; var tmp4 bool; var tmp5 bool; tmp5 = n0_127 == -9223372036854775808; if tmp5 { tmp5 = n1_128 < 0 }; tmp4 = tmp5; tmp3 = !tmp4; if tmp3 { var tmp6 bool; tmp6 = n1_128 == 0; if !tmp6 { tmp6 = nr_129/n1_128 == n0_127 }; tmp3 = tmp6 }; tmp2 = tmp3; if tmp2 { na_124 = jrt.Long_ValueOf_J__Long_NoInit(nr_129).Ref() } else { na_124 = lang.Numbers_Multiply_J_O__Number_NoInit(na_125, na_126) } } else { na_124 = lang.Numbers_Multiply_J_O__Number_NoInit(na_125, na_126) }; var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_123); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_124) }; tmp7 = tmp8; if tmp7 { var n0_130 int64 = jrt.NN(jrt.Long_Cast(na_123)).LongValue__J(); var n1_131 int64 = jrt.NN(jrt.Long_Cast(na_124)).LongValue__J(); or__1927000174__auto____4 = n0_130 < n1_131 } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_123); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_124) }; tmp9 = tmp10; if tmp9 { var n0_130_2 float64 = jrt.NN(jrt.Double_Cast(na_123)).DoubleValue__D(); var n1_131_2 float64 = jrt.NN(jrt.Double_Cast(na_124)).DoubleValue__D(); or__1927000174__auto____4 = n0_130_2 < n1_131_2 } else { or__1927000174__auto____4 = lang.Numbers_Lt_O_O__Z_NoInit(na_123, na_124) } }; if or__1927000174__auto____4 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____4).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_488.GetRawRoot__O()).Invoke_O__O(body__3)) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(body__3, nil) } else { var parts__4 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_split_clinit_fn__1464000466_A_New(); var tmp13 *jrt.Class
		var fncls__151 /*line :690:1*/*jrt.Class = A_arbace_j2g_decls_split_clinit_fn__1464000466_A_fn_class

		if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_252, false); A_arbace_j2g_decls_split_clinit_fn__1464000466_A_fn_class = fncls__151d; tmp13 = fncls__151d } else { tmp13 = fncls__151 }; parts__4 = tmp11.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_490, A_arbace_j2g_decls_A_const_289, A_arbace_j2g_decls_A_const_491, lang.PersistentVector_EMPTY.Ref()))), body__3)
//line :690:1
		var names__5 any; var iter__1927001039__auto____5 any; var tmp14 any = A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A_New_O(g__0); var tmp15 *jrt.Class
		var fncls__135 /*line :690:1*/*jrt.Class = A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A_fn_class








		if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_253, false); A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A_fn_class = fncls__135d; tmp15 = fncls__135d } else { tmp15 = fncls__135 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); names__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(parts__4)).Ref()))
//line :690:1
		var tmp16 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_493.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), names__5); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_493.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_decls_split_clinit_fn__1464000479_A_New(); var tmp19 *jrt.Class
		var fncls__152 /*line :690:1*/*jrt.Class = A_arbace_j2g_decls_split_clinit_fn__1464000479_A_fn_class










		if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_254, false); A_arbace_j2g_decls_split_clinit_fn__1464000479_A_fn_class = fncls__152d; tmp19 = fncls__152d } else { tmp19 = fncls__152 }
//line :690:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp16, tmp17.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil), names__5, parts__4)) } }

func A_arbace_j2g_decls_split_clinit_fn__1464000466_A_New() *A_arbace_j2g_decls_split_clinit_fn__1464000466_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_fn__1464000466_A{}; t.Ctor(); return t }
//line :692:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000466_A) Ctor() {}
//line :692:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000466_A) Invoke_O_O_O__O(self, parts__1, st__2 any) any { var w__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_482.GetRawRoot__O()).Invoke_O__O(st__2); var cur__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_489.GetRawRoot__O()).Invoke_O__O(parts__1); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_491.Invoke_O__O(cur__4)); if


	jrt.J2g_Truth(and__1927000168__auto____5) { var tmp2 bool; var na_136 any; var na_138 any = A_arbace_j2g_decls_A_const_490.Invoke_O__O(cur__4); var na_139 any = w__3; var tmp3 bool; var tmp4 bool; tmp4 = jrt.Long_InstanceOf(na_138); if tmp4 { tmp4 = jrt.Long_InstanceOf(na_139) }; tmp3 = tmp4; if tmp3 { var n0_140 int64 = jrt.NN(jrt.Long_Cast(na_138)).LongValue__J(); var n1_141 int64 = jrt.NN(jrt.Long_Cast(na_139)).LongValue__J(); var nr_142 int64 = n0_140 + n1_141; if (n0_140^nr_142)&(n1_141^nr_142) >= 0 { na_136 = jrt.Long_ValueOf_J__Long_NoInit(nr_142).Ref() } else { na_136 = lang.Numbers_Add_O_O__Number_NoInit(na_138, na_139) } } else { var tmp5 bool; var tmp6 bool; tmp6 = jrt.Double_InstanceOf(na_138); if tmp6 { tmp6 = jrt.Double_InstanceOf(na_139) }; tmp5 = tmp6; if tmp5 { var n0_140_2 float64 = jrt.NN(jrt.Double_Cast(na_138)).DoubleValue__D(); var n1_141_2 float64 = jrt.NN(jrt.Double_Cast(na_139)).DoubleValue__D(); na_136 = jrt.Double_ValueOf_D__Double_NoInit(n0_140_2 + n1_141_2).Ref() } else { na_136 = lang.Numbers_Add_O_O__Number_NoInit(na_138, na_139) } }; var na_137 any = A_arbace_j2g_decls_A_const_487.GetRawRoot__O(); var tmp7 bool; var tmp8 bool; tmp8 = jrt.Long_InstanceOf(na_136); if tmp8 { tmp8 = jrt.Long_InstanceOf(na_137) }; tmp7 = tmp8; if tmp7 { var n0_143 int64 = jrt.NN(jrt.Long_Cast(na_136)).LongValue__J(); var n1_144 int64 = jrt.NN(jrt.Long_Cast(na_137)).LongValue__J(); tmp2 = n0_143 > n1_144 } else { var tmp9 bool; var tmp10 bool; tmp10 = jrt.Double_InstanceOf(na_136); if tmp10 { tmp10 = jrt.Double_InstanceOf(na_137) }; tmp9 = tmp10; if tmp9 { var n0_143_2 float64 = jrt.NN(jrt.Double_Cast(na_136)).DoubleValue__D(); var n1_144_2 float64 = jrt.NN(jrt.Double_Cast(na_137)).DoubleValue__D(); tmp2 = n1_144_2 < n0_143_2 } else { tmp2 = lang.Numbers_Gt_O_O__Z_NoInit(na_136, na_137) } }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(tmp2).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {
		var tmp11 any = A_arbace_j2g_decls_A_const_490; var tmp12 any = A_arbace_j2g_decls_A_const_491; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_14.GetRawRoot__O()).Invoke_O_O__O(parts__1, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp11, w__3, tmp12, lang.Tuple_Create_O__IPersistentVector(st__2)))) } else {
			var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_14.GetRawRoot__O()); var tmp14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_492.GetRawRoot__O()).Invoke_O__O(parts__1); var tmp15 any = A_arbace_j2g_decls_A_const_490; var tmp16 jrt.Number_I; var na_146 any = A_arbace_j2g_decls_A_const_490.Invoke_O__O(cur__4); var na_147 any = w__3; var tmp17 bool; var tmp18 bool; tmp18 = jrt.Long_InstanceOf(na_146); if tmp18 { tmp18 = jrt.Long_InstanceOf(na_147) }; tmp17 = tmp18; if tmp17 { var n0_148 int64 = jrt.NN(jrt.Long_Cast(na_146)).LongValue__J(); var n1_149 int64 = jrt.NN(jrt.Long_Cast(na_147)).LongValue__J(); var nr_150 int64 = n0_148 + n1_149; if (n0_148^nr_150)&(n1_149^nr_150) >= 0 { tmp16 = Up_Long_Number(jrt.Long_ValueOf_J__Long_NoInit(nr_150)) } else { tmp16 = lang.Numbers_Add_O_O__Number_NoInit(na_146, na_147) } } else { var tmp19 bool; var tmp20 bool; tmp20 = jrt.Double_InstanceOf(na_146); if tmp20 { tmp20 = jrt.Double_InstanceOf(na_147) }; tmp19 = tmp20; if tmp19 { var n0_148_2 float64 = jrt.NN(jrt.Double_Cast(na_146)).DoubleValue__D(); var n1_149_2 float64 = jrt.NN(jrt.Double_Cast(na_147)).DoubleValue__D(); tmp16 = Up_Double_Number(jrt.Double_ValueOf_D__Double_NoInit(n0_148_2 + n1_149_2)) } else { tmp16 = lang.Numbers_Add_O_O__Number_NoInit(na_146, na_147) } }; var tmp21 any = tmp16; var tmp22 any = A_arbace_j2g_decls_A_const_491; return tmp13.Invoke_O_O__O(tmp14, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp21, tmp22, lang.IFn_Cast(A_arbace_j2g_decls_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_491.Invoke_O__O(cur__4), st__2)))) } }

func A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A_New_O(p0 any) *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A{}; t.Ctor_O(p0); return t }
//line :699:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :699:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A) Invoke_O_O__O(self, s__1464000469__1 any) any { var tmp1 any = A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A_New_O_O_O(t.F_g, s__1464000469__1, self); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_255, false); A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :699:1
func A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :699:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A) Ctor_O_O_O(c__g, c__s__1464000469, c__iter__1464000468 any) { t.F_g = c__g; t.F_s__1464000469 = c__s__1464000469; t.F_iter__1464000468 = c__iter__1464000468 }
//line :699:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A) Invoke_O__O(self any) any { { var s__1464000469__1 any; var t_ any = t.F_s__1464000469; t.F_s__1464000469 = nil; s__1464000469__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000469__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000469__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000469__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000469__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000471__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A_New_O_O_I_O(t.F_g, b__1464000471__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_256, false); A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A_fn_class = fncls__133d; tmp2 = fncls__133d } else { tmp2 = fncls__133 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000468); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000471__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000469__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000471__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000469__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000468); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_257, nil), jrt.RefArrayOf(jrt.Object_class, t.F_g, nil, k__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000469__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :699:1
func A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :699:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A) Ctor_O_O_I_O(c__g, c__b__1464000471 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_b__1464000471 = c__b__1464000471; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :699:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A) Invoke_O__O(self any) any { { var i__1464000470__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000470__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000470__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000471; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_257, nil), jrt.RefArrayOf(jrt.Object_class, t.F_g, nil, k__2)).Ref())); i__1464000470__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000470__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_split_clinit_fn__1464000479_A_New() *A_arbace_j2g_decls_split_clinit_fn__1464000479_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_fn__1464000479_A{}; t.Ctor(); return t }
//line :701:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000479_A) Ctor() {}
//line :701:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000479_A) Invoke_O_O_O__O(self, nm__1, p__1464000478__2 any) any { var map__1464000480__3 any = p__1464000478__2; var map__1464000480__4 any; if lang.ISeq_InstanceOf(map__1464000480__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000480__3)) { map__1464000480__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000480__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000480__3)) { map__1464000480__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000480__3) } else { map__1464000480__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000480__4 = map__1464000480__3 }; var sts__5 any = lang.RT_Get_O_O__O_NoInit(map__1464000480__4, A_arbace_j2g_decls_A_const_491); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_494, nm__1, lang.PersistentVector_EMPTY.Ref(), sts__5) }

func A_arbace_j2g_decls_clj_const_store_A_New() *A_arbace_j2g_decls_clj_const_store_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_store_A{}; t.Ctor(); return t }
//line :703:1
func (t *A_arbace_j2g_decls_clj_const_store_A) Ctor() {}
//line :703:1
func (t *A_arbace_j2g_decls_clj_const_store_A) Invoke_O_O_O__O(self, n__0, p__1464000484__1 any) any { var map__1464000485__3 any = p__1464000484__1; var map__1464000485__4 any; if lang.ISeq_InstanceOf(map__1464000485__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000485__3)) { map__1464000485__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000485__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000485__3)) { map__1464000485__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000485__3) } else { map__1464000485__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000485__4 = map__1464000485__3 }; var f__5 any = map__1464000485__4; var desc__6 any = lang.RT_Get_O_O__O_NoInit(map__1464000485__4, A_arbace_j2g_decls_A_const_118); var init__7 any = lang.RT_Get_O_O__O_NoInit(map__1464000485__4, A_arbace_j2g_decls_A_const_223); var rt__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_495.GetRawRoot__O()).Invoke_O__O(Lit_47); var sd__9 any = Lit_48; var strc__10 any; var tmp1 any = A_arbace_j2g_decls_clj_const_store_strc__1464000487_A_New_O(sd__9); var tmp2 *jrt.Class; var fncls__153 *jrt.Class = A_arbace_j2g_decls_clj_const_store_strc__1464000487_A_fn_class; if






	fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_j2g_decls_clj_const_store_strc__1464000487_A_fn_class = fncls__153d; tmp2 = fncls__153d } else { tmp2 = fncls__153 }; strc__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var call__11 any; var G__1464000489__11_ any = /*line :703:1*/A_arbace_j2g_decls_A_const_167.Invoke_O__O(init__7); L1:







	switch { default: switch lang.Util_Hash_O__I_NoInit(G__1464000489__11_) >> 0 & 1 { case 0: if any(G__1464000489__11_) == any(A_arbace_j2g_decls_A_const_497) { var tmp3 any = A_arbace_j2g_decls_A_const_182; var tmp4 any = A_arbace_j2g_decls_A_const_498; var tmp5 any = A_arbace_j2g_decls_A_const_167; var tmp6 any = A_arbace_j2g_decls_A_const_88; var tmp7 any = A_arbace_j2g_decls_A_const_333; var tmp8 any = A_arbace_j2g_decls_A_const_499; var tmp9 any = jrt.Boolean_FALSE.Ref(); var tmp10 any = A_arbace_j2g_decls_A_const_100; var tmp11 any = A_arbace_j2g_decls_A_const_500; var tmp12 any = A_arbace_j2g_decls_A_const_118; var tmp13 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, nil, Lit_52, nil), jrt.RefArrayOf(jrt.Object_class, nil, sd__9, sd__9, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_501.GetRawRoot__O()).Invoke_O__O(Lit_53))).Ref(); var tmp14 any = A_arbace_j2g_decls_A_const_193; var tmp15 any = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(strc__10).Invoke_O__O(A_arbace_j2g_decls_A_const_505.Invoke_O__O(init__7)), lang.IFn_Cast(strc__10).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(init__7))); var tmp16 any = A_arbace_j2g_decls_A_const_141; call__11 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, tmp6, tmp7, rt__8, tmp8, tmp9, tmp10, Lit_50, tmp11, nil, tmp12, tmp13, tmp14, tmp15, tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_501.GetRawRoot__O()).Invoke_O__O(Lit_53))); break L1 }; case 1: if any(G__1464000489__11_) == any(A_arbace_j2g_decls_A_const_502) { var tmp17 any = A_arbace_j2g_decls_A_const_182; var tmp18 any = A_arbace_j2g_decls_A_const_498; var tmp19 any = A_arbace_j2g_decls_A_const_167; var tmp20 any = A_arbace_j2g_decls_A_const_88; var tmp21 any = A_arbace_j2g_decls_A_const_333; var tmp22 any = A_arbace_j2g_decls_A_const_499; var tmp23 any = jrt.Boolean_FALSE.Ref(); var tmp24 any = A_arbace_j2g_decls_A_const_100; var tmp25 any = A_arbace_j2g_decls_A_const_500; var tmp26 any = A_arbace_j2g_decls_A_const_118; var tmp27 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, sd__9, nil)).Ref(); var tmp28 any = A_arbace_j2g_decls_A_const_193; call__11 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp20, tmp21, rt__8, tmp22, tmp23, tmp24, Lit_54, tmp25, nil, tmp26, tmp27, tmp28, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(strc__10).Invoke_O__O(A_arbace_j2g_decls_A_const_506.Invoke_O__O(init__7))), A_arbace_j2g_decls_A_const_141, Lit_56)); break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1464000489__11_)))))}; var v__12 any; if






	lang.Util_Equiv_O_O__Z_NoInit(desc__6, A_arbace_j2g_decls_A_const_141.Invoke_O__O(call__11)) { v__12 = call__11 } else { v__12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_182, A_arbace_j2g_decls_A_const_503, A_arbace_j2g_decls_A_const_34, desc__6, A_arbace_j2g_decls_A_const_331, call__11, A_arbace_j2g_decls_A_const_141, desc__6)) }; var tmp29 any = A_arbace_j2g_decls_A_const_182; var tmp30 any = A_arbace_j2g_decls_A_const_504; var tmp31 any = A_arbace_j2g_decls_A_const_333; var tmp32 any = A_arbace_j2g_decls_A_const_141; var tmp33 any = A_arbace_j2g_decls_A_const_473; var tmp34 any = A_arbace_j2g_decls_A_const_356; var tmp35 any = A_arbace_j2g_decls_A_const_333; var tmp36 any = A_arbace_j2g_decls_A_const_100; var tmp37 any = /*line :703:1*/A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__5); var tmp38 any = A_arbace_j2g_decls_A_const_118; var tmp39 any = A_arbace_j2g_decls_A_const_103; return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp29, tmp30, tmp31, n__0, tmp32, desc__6, tmp33, v__12, tmp34, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp35, n__0, tmp36, tmp37, tmp38, desc__6, tmp39, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Or_J_J__J_NoInit(8, 16)).Ref())))) }






func A_arbace_j2g_decls_clj_const_store_strc__1464000487_A_New_O(p0 any) *A_arbace_j2g_decls_clj_const_store_strc__1464000487_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_store_strc__1464000487_A{}; t.Ctor_O(p0); return t }
//line :710:1
func (t *A_arbace_j2g_decls_clj_const_store_strc__1464000487_A) Ctor_O(c__sd any) { t.F_sd = c__sd }
//line :710:1
func (t *A_arbace_j2g_decls_clj_const_store_strc__1464000487_A) Invoke_O_O__O(self, s__1 any) any { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_182, A_arbace_j2g_decls_A_const_496, A_arbace_j2g_decls_A_const_141, t.F_sd, A_arbace_j2g_decls_A_const_473, s__1)) }











func A_arbace_j2g_decls_init_forms_A_New() *A_arbace_j2g_decls_init_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_init_forms_A{}; t.Ctor(); return t }
//line :722:1
func (t *A_arbace_j2g_decls_init_forms_A) Ctor() {}
//line :722:1
func (t *A_arbace_j2g_decls_init_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(n__1)) { return nil } else { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var d__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var st__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__4)); var sup__6 any = A_arbace_j2g_decls_A_const_126.Invoke_O__O(d__4); var reached__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_125.Get__O(), lang.Tuple_Create_O_O_O__IPersistentVector(n__1, Lit_43, Lit_151)); var body__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O())
		var tmp2 any = A_arbace_j2g_decls_A_const_90




		lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O_O__O(pkg__0, n__1, A_arbace_j2g_decls_A_const_88, jrt.Boolean_TRUE.Ref(), A_arbace_j2g_decls_A_const_97, Lit_62, A_arbace_j2g_decls_A_const_510, jrt.Boolean_TRUE.Ref(), A_arbace_j2g_decls_A_const_99, Lit_43))); var tmp3 any = A_arbace_j2g_decls_init_forms_fn__1464000494_A_New_O_O_O_O_O(sup__6, pkg__0, reached__7, n__1, st__5); var tmp4 *jrt.Class; var fncls__156 *jrt.Class = A_arbace_j2g_decls_init_forms_fn__1464000494_A_fn_class; if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_j2g_decls_init_forms_fn__1464000494_A_fn_class = fncls__156d; tmp4 = fncls__156d } else { tmp4 = fncls__156 }; body__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
//line :725:1
		var vec__1464000491__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_511.GetRawRoot__O()).Invoke_O_O__O(g__3, body__8); var body__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000491__9, lang.RT_IntCast_J__I_NoInit(0), nil); var parts__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000491__9, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_512; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_513; var tmp9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_84), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp10 any = lang.PersistentVector_EMPTY.Ref(); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_514; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_515; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_516; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_decls_A_const_517; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O())
		var tmp20 any = A_arbace_j2g_decls_A_const_518























		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_46.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp5.Invoke_O_O__O(tmp6, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_153), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_154))), tmp7.Invoke_O_O_O_O__O(tmp8, tmp9, tmp10, tmp11.Invoke_O_O_O__O(tmp12, tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_153), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()))), tmp17.Invoke_O_O_O__O(tmp18, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_153), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_155), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))), tmp19.Invoke_O_O_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_155), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.PersistentVector_EMPTY.Ref(), body__10)), parts__11) } }
//line :731:1
func A_arbace_j2g_decls_init_forms_fn__1464000494_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_decls_init_forms_fn__1464000494_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_init_forms_fn__1464000494_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :731:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000494_A) Ctor_O_O_O_O_O(c__sup, c__pkg, c__reached, c__n, c__st any) { t.F_sup = c__sup; t.F_pkg = c__pkg; t.F_reached = c__reached; t.F_n = c__n; t.F_st = c__st }
//line :731:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000494_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_90.Get__O(); var tmp6 any = A_arbace_j2g_decls_A_const_105; var tmp7 *lang.Keyword = A_arbace_j2g_decls_A_const_35; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O__O(A_arbace_j2g_decls_A_const_90.Get__O())))); tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_91.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A_New_O_O_O_O_O(t.F_sup, t.F_pkg, t.F_reached, t.F_n, t.F_st); var tmp10 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A_fn_class
													if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A_fn_class = fncls__155d; tmp10 = fncls__155d } else { tmp10 = fncls__155 }
//line :733:1
			tmp1 = tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :732:1
		return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O()
//line :731:1
		if tmp11 != nil { panic(tmp11) } }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp12 != nil { panic(tmp12) }; return tmp1 }


func A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :734:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A) Ctor_O_O_O_O_O(c__sup, c__pkg, c__reached, c__n, c__st any) { t.F_sup = c__sup; t.F_pkg = c__pkg; t.F_reached = c__reached; t.F_n = c__n; t.F_st = c__st }
//line :734:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A) Invoke_O__O(self any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_371.GetRawRoot__O()).Invoke_O__O(t.F_n)) {
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_157))) }
	{ var tmp1 any; var and__1927000168__auto____1 any = t.F_sup; if jrt.J2g_Truth(and__1927000168__auto____1) { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(t.F_sup); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(t.F_sup)) } else { tmp1 = and__1927000168__auto____2 } } else { tmp1 = and__1927000168__auto____1 }; if jrt.J2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_sup, Lit_84))) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_reached)) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_507; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_109), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_158), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, Lit_11, Lit_12), nil)).Ref()))) } else {
//line :741:1
				var seq_1464000496__1 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_508.Invoke_O__O(t.F_st)); var chunk_1464000497__2 any; var count_1464000498__3 int64 = 0; var i_1464000499__4 int64 = 0; L1: for {




					if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000499__4, count_1464000498__3) { var vec__1464000500__5 any = lang.Indexed_Cast(chunk_1464000497__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000499__4)); var ___6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000500__5, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1464000503__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000500__5, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1464000503__8 any; _ = ___6; if lang.ISeq_InstanceOf(map__1464000503__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000503__7)) { map__1464000503__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000503__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000503__7)) { map__1464000503__8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000503__7) } else { map__1464000503__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000503__8 = map__1464000503__7 }; var f__9 any = map__1464000503__8; var name__10 any = lang.RT_Get_O_O__O_NoInit(map__1464000503__8, A_arbace_j2g_decls_A_const_100); var desc__11 any = lang.RT_Get_O_O__O_NoInit(map__1464000503__8, A_arbace_j2g_decls_A_const_118); var init__12 any = lang.RT_Get_O_O__O_NoInit(map__1464000503__8, A_arbace_j2g_decls_A_const_223); _ = name__10; _ = desc__11; _ = init__12
						lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_509.GetRawRoot__O()).Invoke_O_O__O(t.F_n, f__9))
//line :746:1
						seq_1464000496__1, chunk_1464000497__2, count_1464000498__3, i_1464000499__4 = seq_1464000496__1, chunk_1464000497__2, count_1464000498__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000499__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000496__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1464000496__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000496__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000496__6); seq_1464000496__1, chunk_1464000497__2, count_1464000498__3, i_1464000499__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000496__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1464000505__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000496__6); var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000505__7, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1464000508__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000505__7, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1464000508__10 any; _ = ___8; if lang.ISeq_InstanceOf(map__1464000508__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000508__9)) { map__1464000508__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000508__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000508__9)) { map__1464000508__10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000508__9) } else { map__1464000508__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000508__10 = map__1464000508__9 }; var f__11 any = map__1464000508__10; var name__12 any = lang.RT_Get_O_O__O_NoInit(map__1464000508__10, A_arbace_j2g_decls_A_const_100); var desc__13 any = lang.RT_Get_O_O__O_NoInit(map__1464000508__10, A_arbace_j2g_decls_A_const_118); var init__14 any = lang.RT_Get_O_O__O_NoInit(map__1464000508__10, A_arbace_j2g_decls_A_const_223); _ = name__12; _ = desc__13; _ = init__14
							lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_509.GetRawRoot__O()).Invoke_O_O__O(t.F_n, f__11))
//line :746:1
							seq_1464000496__1, chunk_1464000497__2, count_1464000498__3, i_1464000499__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000496__6), nil, 0, 0; continue L1 } } }
//line :741:1
					break L1 }; var seq_1464000510__1 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_510.Invoke_O__O(t.F_st)); var chunk_1464000511__2 any; var count_1464000512__3 int64 = 0; var i_1464000513__4 int64 = 0; L2: for {






						if lang.Numbers_Lt_J_J__Z_NoInit(i_1464000513__4, count_1464000512__3) { var nd__5 any = lang.Indexed_Cast(chunk_1464000511__2).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1464000513__4)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(nd__5); seq_1464000510__1, chunk_1464000511__2, count_1464000512__3, i_1464000513__4 = seq_1464000510__1, chunk_1464000511__2, count_1464000512__3, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1464000513__4); continue L2 } else { var temp__1927000414__auto____5_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000510__1); if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_1464000510__6 any = temp__1927000414__auto____5_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000510__6)) { var c__1927000678__auto____7_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000510__6); seq_1464000510__1, chunk_1464000511__2, count_1464000512__3, i_1464000513__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000510__6), c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var nd__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000510__6); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(nd__7); seq_1464000510__1, chunk_1464000511__2, count_1464000512__3, i_1464000513__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000510__6), nil, 0, 0; continue L2 } } else { return nil } } } } }
//line :734:1
	panic("j2g: unreachable")
}





















func A_arbace_j2g_decls_clj_const_fields_A_New() *A_arbace_j2g_decls_clj_const_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_A{}; t.Ctor(); return t }
//line :757:1
func (t *A_arbace_j2g_decls_clj_const_fields_A) Ctor() {}
//line :757:1
func (t *A_arbace_j2g_decls_clj_const_fields_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_81; var st__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1))); var iter__1927001039__auto____5 any; var tmp2 any = A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A_New_O_O(g__3, pkg__0); var tmp3 *jrt.Class; var fncls__159 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A_fn_class; if


	fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A_fn_class = fncls__159d; tmp3 = fncls__159d } else { tmp3 = fncls__159 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); return lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_j2g_decls_A_const_508.Invoke_O__O(st__4)) }
//line :760:1
func A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A{}; t.Ctor_O_O(p0, p1); return t }
//line :760:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A) Ctor_O_O(c__g, c__pkg any) { t.F_g = c__g; t.F_pkg = c__pkg }
//line :760:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A) Invoke_O_O__O(self, s__1464000518__1 any) any { var tmp1 any = A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A_New_O_O_O_O(t.F_g, self, t.F_pkg, s__1464000518__1); var tmp2 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A_fn_class = fncls__158d; tmp2 = fncls__158d } else { tmp2 = fncls__158 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :760:1
func A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :760:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A) Ctor_O_O_O_O(c__g, c__iter__1464000517, c__pkg, c__s__1464000518 any) { t.F_g = c__g; t.F_iter__1464000517 = c__iter__1464000517; t.F_pkg = c__pkg; t.F_s__1464000518 = c__s__1464000518 }
//line :760:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A) Invoke_O__O(self any) any { { var s__1464000518__1 any; var t_ any = t.F_s__1464000518; t.F_s__1464000518 = nil; s__1464000518__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000518__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000518__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000518__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000518__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000520__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A_New_O_O_O_I_O(b__1464000520__6, t.F_g, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A_fn_class = fncls__157d; tmp2 = fncls__157d } else { tmp2 = fncls__157 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000517); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000520__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000518__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000520__6), nil) } } else { var vec__1464000530__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000518__3); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000530__4, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1464000533__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000530__4, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1464000533__7 any; _ = ___5; if lang.ISeq_InstanceOf(map__1464000533__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000533__6)) { map__1464000533__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000533__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000533__6)) { map__1464000533__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000533__6) } else { map__1464000533__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000533__7 = map__1464000533__6 }; var name__8 any = lang.RT_Get_O_O__O_NoInit(map__1464000533__7, A_arbace_j2g_decls_A_const_100); var desc__9 any = lang.RT_Get_O_O__O_NoInit(map__1464000533__7, A_arbace_j2g_decls_A_const_118); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(desc__9)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_519; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1464000517); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_463.GetRawRoot__O()).Invoke_O_O__O(t.F_g, name__8)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, desc__9))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000518__3))) } else { s__1464000518__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000518__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :760:1
func A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :760:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A) Ctor_O_O_O_I_O(c__b__1464000520, c__g, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000520 = c__b__1464000520; t.F_g = c__g; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :760:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A) Invoke_O__O(self any) any { { var i__1464000519__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000519__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1464000524__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000519__1)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000524__2, lang.RT_IntCast_J__I_NoInit(0), nil); var map__1464000527__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000524__2, lang.RT_IntCast_J__I_NoInit(1), nil); var map__1464000527__5 any; _ = ___3; if lang.ISeq_InstanceOf(map__1464000527__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000527__4)) { map__1464000527__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000527__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000527__4)) { map__1464000527__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000527__4) } else { map__1464000527__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000527__5 = map__1464000527__4 }; var name__6 any = lang.RT_Get_O_O__O_NoInit(map__1464000527__5, A_arbace_j2g_decls_A_const_100); var desc__7 any = lang.RT_Get_O_O__O_NoInit(map__1464000527__5, A_arbace_j2g_decls_A_const_118); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(desc__7)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000520; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_519; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_463.GetRawRoot__O()).Invoke_O_O__O(t.F_g, name__6)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, desc__7)))); i__1464000519__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000519__1); continue L1 } else { i__1464000519__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000519__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_instance_forms_A_New() *A_arbace_j2g_decls_instance_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_instance_forms_A{}; t.Ctor(); return t }
//line :764:1
func (t *A_arbace_j2g_decls_instance_forms_A) Ctor() {}
//line :764:1
func (t *A_arbace_j2g_decls_instance_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var ty__4 any; var tmp1 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1); if



	jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1)) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()); var tmp3 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp3 = g__3 } else { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref() }; ty__4 = tmp2.Invoke_O__O(tmp3) } else {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_520; ty__4 = tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3)) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_521; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_522; var tmp10 any = A_arbace_j2g_decls_A_const_523; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_525; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_529; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_531; var tmp17 any = A_arbace_j2g_decls_A_const_532; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_A_const_533; var tmp20 any = A_arbace_j2g_decls_A_const_534; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_decls_A_const_535; var tmp23 any = A_arbace_j2g_decls_A_const_536; var dyn_check__5 any = tmp6.Invoke_O_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_159), A_arbace_j2g_decls_A_const_524)), tmp11.Invoke_O_O_O__O(tmp12, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_526, A_arbace_j2g_decls_A_const_527, A_arbace_j2g_decls_A_const_528), tmp13.Invoke_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_160), A_arbace_j2g_decls_A_const_530)), tmp15.Invoke_O_O_O__O(tmp16, tmp17, tmp18.Invoke_O_O_O__O(tmp19, tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp23, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))))); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_537; var tmp26 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_161), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp27 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_540, A_arbace_j2g_decls_A_const_541)), A_arbace_j2g_decls_A_const_539); var tmp28 any







		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_538.GetRawRoot__O()).Invoke_O__O(pkg__0)) {


			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_decls_A_const_542; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_decls_A_const_549; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_decls_A_const_550; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp36 any = A_arbace_j2g_decls_A_const_556; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_decls_A_const_560; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_decls_A_const_562; var tmp41 any = A_arbace_j2g_decls_A_const_563; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_decls_A_const_564; var tmp44 any = A_arbace_j2g_decls_A_const_565; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_decls_A_const_566; var tmp47 any = A_arbace_j2g_decls_A_const_567; tmp28 = tmp29.Invoke_O_O_O_O__O(tmp30, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_544, A_arbace_j2g_decls_A_const_545, A_arbace_j2g_decls_A_const_546), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_547, ty__4, A_arbace_j2g_decls_A_const_548)), tmp31.Invoke_O_O_O__O(tmp32, tmp33.Invoke_O_O_O_O__O(tmp34, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_551, A_arbace_j2g_decls_A_const_552), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_553, A_arbace_j2g_decls_A_const_554, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_159), A_arbace_j2g_decls_A_const_555)), tmp35.Invoke_O_O_O__O(tmp36, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_557, A_arbace_j2g_decls_A_const_558, A_arbace_j2g_decls_A_const_559), tmp37.Invoke_O_O_O__O(tmp38, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_160), A_arbace_j2g_decls_A_const_561)), tmp39.Invoke_O_O_O__O(tmp40, tmp41, tmp42.Invoke_O_O_O__O(tmp43, tmp44, tmp45.Invoke_O_O_O__O(tmp46, tmp47, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))))), A_arbace_j2g_decls_A_const_543) } else {




				var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_decls_A_const_568; tmp28 = tmp48.Invoke_O_O_O_O__O(tmp49, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_570, A_arbace_j2g_decls_A_const_571, A_arbace_j2g_decls_A_const_572), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_573, ty__4, A_arbace_j2g_decls_A_const_574)), dyn_check__5, A_arbace_j2g_decls_A_const_569) }
//line :771:1
		var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_decls_A_const_575; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp53 any = A_arbace_j2g_decls_A_const_578; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp55 any = A_arbace_j2g_decls_A_const_582; var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp57 any = A_arbace_j2g_decls_A_const_589; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp59 any = A_arbace_j2g_decls_A_const_592; var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp61 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_162); var tmp62 any = A_arbace_j2g_decls_A_const_593; return lang.Tuple_Create_O_O__IPersistentVector(tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, tmp27, tmp28), tmp50.Invoke_O_O_O_O_O__O(tmp51, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_576, A_arbace_j2g_decls_A_const_577)), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_18, ty__4))), tmp52.Invoke_O_O_O__O(tmp53, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_579, A_arbace_j2g_decls_A_const_580, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_581, nil)), tmp54.Invoke_O_O_O_O_O__O(tmp55, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_584, A_arbace_j2g_decls_A_const_585, A_arbace_j2g_decls_A_const_586), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_587, ty__4, A_arbace_j2g_decls_A_const_588)), dyn_check__5, tmp56.Invoke_O_O_O__O(tmp57, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_590, A_arbace_j2g_decls_A_const_591), tmp58.Invoke_O_O__O(tmp59, tmp60.Invoke_O_O_O__O(tmp61, tmp62, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))), A_arbace_j2g_decls_A_const_583))) } else { var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_decls_A_const_594; var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp66 any = A_arbace_j2g_decls_A_const_598; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp68 any = A_arbace_j2g_decls_A_const_605; var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp70 any = A_arbace_j2g_decls_A_const_608; var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp72 any = A_arbace_j2g_decls_A_const_612; var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_decls_A_const_619; var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp76 any = A_arbace_j2g_decls_A_const_622; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp78 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_162); var tmp79 any = A_arbace_j2g_decls_A_const_623; return lang.Tuple_Create_O_O__IPersistentVector(tmp63.Invoke_O_O_O_O__O(tmp64, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_161), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_596, A_arbace_j2g_decls_A_const_597)), A_arbace_j2g_decls_A_const_595), tmp65.Invoke_O_O_O__O(tmp66, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_600, A_arbace_j2g_decls_A_const_601, A_arbace_j2g_decls_A_const_602), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_603, ty__4, A_arbace_j2g_decls_A_const_604)), A_arbace_j2g_decls_A_const_599)), tmp67.Invoke_O_O_O_O_O__O(tmp68, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_107), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_606, A_arbace_j2g_decls_A_const_607)), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_18, ty__4))), tmp69.Invoke_O_O_O__O(tmp70, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_609, A_arbace_j2g_decls_A_const_610, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_611, nil)), tmp71.Invoke_O_O_O_O__O(tmp72, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_614, A_arbace_j2g_decls_A_const_615, A_arbace_j2g_decls_A_const_616), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_617, ty__4, A_arbace_j2g_decls_A_const_618)), tmp73.Invoke_O_O_O__O(tmp74, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_620, A_arbace_j2g_decls_A_const_621), tmp75.Invoke_O_O__O(tmp76, tmp77.Invoke_O_O_O__O(tmp78, tmp79, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_105), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))), A_arbace_j2g_decls_A_const_613))) } }

































func A_arbace_j2g_decls_reflected_forms_A_New() *A_arbace_j2g_decls_reflected_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_A{}; t.Ctor(); return t }
//line :805:1
func (t *A_arbace_j2g_decls_reflected_forms_A) Ctor() {}
//line :805:1
func (t *A_arbace_j2g_decls_reflected_forms_A) Invoke_O_O__O(self, n__0 any) any { var pkg__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_63.GetRawRoot__O()).Invoke_O__O(n__0); var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__0); var info__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_624.GetRawRoot__O()).Invoke_O__O(n__0); var ms__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__162 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A_fn_class; if







	fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_233, false); A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A_fn_class = fncls__162d; tmp2 = fncls__162d } else { tmp2 = fncls__162 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); ms__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_j2g_decls_A_const_122.Invoke_O__O(info__4)); var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_630; var tmp7 any = tmp5.Invoke_O_O__O(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_234), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_11, Lit_12), nil)).Ref()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_631; var tmp10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp13 any = A_arbace_j2g_decls_A_const_632; var tmp14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__2, Lit_13); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp16 any; var iter__1927001039__auto____6 any; var tmp17 any = A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A_New_O(pkg__2); var tmp18 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A_fn_class; if





	fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_235, false); A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A_fn_class = fncls__174d; tmp18 = fncls__174d } else { tmp18 = fncls__174 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0)); var tmp19 any = tmp16; var tmp20 any = /*line :814:1*/lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), lang.PersistentVector_EMPTY.Ref())); var tmp21 any; var iter__1927001039__auto____6_2 any; var tmp22 any = A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A_New_O(pkg__2); var tmp23 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A_fn_class; if







	fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_236, false); A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A_fn_class = fncls__177d; tmp23 = fncls__177d } else { tmp23 = fncls__177 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); tmp21 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(ms__5); var tmp24 any = /*line :814:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, tmp15.Invoke_O_O_O__O(tmp19, tmp20, tmp21)))); var tmp25 any; var iter__1927001039__auto____6_3 any; var tmp26 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A_New_O_O_O(g__3, pkg__2, n__0); var tmp27 *jrt.Class; var fncls__171 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A_fn_class; if











	fncls__171 == nil { var fncls__171d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_237, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A_fn_class = fncls__171d; tmp27 = fncls__171d } else { tmp27 = fncls__171 }; iter__1927001039__auto____6_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); tmp25 = lang.IFn_Cast(iter__1927001039__auto____6_3).Invoke_O__O(ms__5); return /*line :814:1*/ tmp3.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp24, tmp25, lang.IFn_Cast(A_arbace_j2g_decls_A_const_629.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0))) }
//line :813:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A_New_O(p0 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A{}; t.Ctor_O(p0); return t }
//line :813:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :813:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A) Invoke_O_O__O(self, s__1464000540__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A_New_O_O_O(self, t.F_n, s__1464000540__1); var tmp2 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_238, false); A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A_fn_class = fncls__161d; tmp2 = fncls__161d } else { tmp2 = fncls__161 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :813:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :813:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A) Ctor_O_O_O(c__iter__1464000539, c__n, c__s__1464000540 any) { t.F_iter__1464000539 = c__iter__1464000539; t.F_n = c__n; t.F_s__1464000540 = c__s__1464000540 }
//line :813:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A) Invoke_O__O(self any) any { { var s__1464000540__1 any; var t_ any = t.F_s__1464000540; t.F_s__1464000540 = nil; s__1464000540__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000540__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000540__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000540__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000540__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000542__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A_New_O_O_I_O(b__1464000542__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_239, false); A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A_fn_class = fncls__160d; tmp2 = fncls__160d } else { tmp2 = fncls__160 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000539); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000542__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000540__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000542__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000540__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000539); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(mm__4, A_arbace_j2g_decls_A_const_333, t.F_n), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000540__3))) } else { s__1464000540__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000540__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :813:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :813:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A) Ctor_O_O_I_O(c__b__1464000542, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000542 = c__b__1464000542; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :813:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A) Invoke_O__O(self any) any { { var i__1464000541__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000541__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000541__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000542; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(mm__2, A_arbace_j2g_decls_A_const_333, t.F_n)); i__1464000541__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000541__1); continue L1 } else { i__1464000541__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000541__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A_New_O(p0 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A{}; t.Ctor_O(p0); return t }
//line :820:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :820:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A) Invoke_O_O__O(self, s__1464000550__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A_New_O_O_O(self, t.F_pkg, s__1464000550__1); var tmp2 *jrt.Class; var fncls__173 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A_fn_class; if fncls__173 == nil { var fncls__173d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_240, false); A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A_fn_class = fncls__173d; tmp2 = fncls__173d } else { tmp2 = fncls__173 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :820:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :820:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A) Ctor_O_O_O(c__iter__1464000549, c__pkg, c__s__1464000550 any) { t.F_iter__1464000549 = c__iter__1464000549; t.F_pkg = c__pkg; t.F_s__1464000550 = c__s__1464000550 }
//line :820:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A) Invoke_O__O(self any) any { { var s__1464000550__1 any; var t_ any = t.F_s__1464000550; t.F_s__1464000550 = nil; s__1464000550__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000550__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000550__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000550__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000550__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000552__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A_New_O_I_O_O(t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4, b__1464000552__6); var tmp2 *jrt.Class; var fncls__172 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A_fn_class; if fncls__172 == nil { var fncls__172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_241, false); A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A_fn_class = fncls__172d; tmp2 = fncls__172d } else { tmp2 = fncls__172 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000549); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000552__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000550__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000552__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000550__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000549); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000550__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :820:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :820:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A) Ctor_O_I_O_O(c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000552 any) { t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000552 = c__b__1464000552 }
//line :820:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A) Invoke_O__O(self any) any { { var i__1464000551__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000551__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000551__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000552; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__2)); i__1464000551__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000551__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A_New_O(p0 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A{}; t.Ctor_O(p0); return t }
//line :822:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :822:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A) Invoke_O_O__O(self, s__1464000560__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A_New_O_O_O(self, t.F_pkg, s__1464000560__1); var tmp2 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_242, false); A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A_fn_class = fncls__176d; tmp2 = fncls__176d } else { tmp2 = fncls__176 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :822:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :822:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A) Ctor_O_O_O(c__iter__1464000559, c__pkg, c__s__1464000560 any) { t.F_iter__1464000559 = c__iter__1464000559; t.F_pkg = c__pkg; t.F_s__1464000560 = c__s__1464000560 }
//line :822:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A) Invoke_O__O(self any) any { { var s__1464000560__1 any; var t_ any = t.F_s__1464000560; t.F_s__1464000560 = nil; s__1464000560__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000560__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000560__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000560__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000560__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000562__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A_New_O_I_O_O(t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4, b__1464000562__6); var tmp2 *jrt.Class; var fncls__175 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A_fn_class; if fncls__175 == nil { var fncls__175d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_243, false); A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A_fn_class = fncls__175d; tmp2 = fncls__175d } else { tmp2 = fncls__175 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000559); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000562__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000560__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000562__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000560__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4))
															if jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_626.GetRawRoot__O()).Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____5 }
//line :822:1
	if jrt.J2g_Truth(tmp4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_461.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))))) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000559); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_633.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000560__3))) } else { s__1464000560__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000560__3); continue L1 } } else { s__1464000560__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000560__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :822:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :822:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A) Ctor_O_I_O_O(c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000562 any) { t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000562 = c__b__1464000562 }
//line :822:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A) Invoke_O__O(self any) any { { var i__1464000561__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000561__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000561__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2))
																	if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_626.GetRawRoot__O()).Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____3 }
//line :822:1
	if jrt.J2g_Truth(tmp2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_461.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))))) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp4 any = t.F_b__1464000562; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_633.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__2)); i__1464000561__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000561__1); continue L1 } else { i__1464000561__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000561__1); continue L1 } } else { i__1464000561__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000561__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :826:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A) Ctor_O_O_O(c__g, c__pkg, c__n any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n }
//line :826:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A) Invoke_O_O__O(self, s__1464000570__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A_New_O_O_O_O_O(self, t.F_g, t.F_pkg, t.F_n, s__1464000570__1); var tmp2 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_244, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A_fn_class = fncls__170d; tmp2 = fncls__170d } else { tmp2 = fncls__170 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :826:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :826:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A) Ctor_O_O_O_O_O(c__iter__1464000569, c__g, c__pkg, c__n, c__s__1464000570 any) { t.F_iter__1464000569 = c__iter__1464000569; t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_s__1464000570 = c__s__1464000570 }
//line :826:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A) Invoke_O__O(self any) any { { var s__1464000570__1 any; var t_ any = t.F_s__1464000570; t.F_s__1464000570 = nil; s__1464000570__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000570__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000570__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000570__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000570__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000572__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A_New_O_O_O_I_O_O(t.F_g, t.F_pkg, t.F_n, size__1927001038__auto____5, b__1464000572__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A_fn_class; if fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_245, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A_fn_class = fncls__166d; tmp2 = fncls__166d } else { tmp2 = fncls__166 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000569); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000572__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000570__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000572__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000570__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_625.GetRawRoot__O()).Invoke_O__O(mm__4))
															if jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_626.GetRawRoot__O()).Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____5 }
//line :826:1
	if jrt.J2g_Truth(tmp4) { var vec__1464000590__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)); var ps__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000590__5, lang.RT_IntCast_J__I_NoInit(0), nil); var r__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000590__5, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__8 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A_New(); var tmp8 *jrt.Class
		var fncls__169 /*line :826:1*/*jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A_fn_class


		if fncls__169 == nil { var fncls__169d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_246, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A_fn_class = fncls__169d; tmp8 = fncls__169d } else { tmp8 = fncls__169 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__6)).Ref())); pn__8 = tmp5.Invoke_O__O(tmp6)
//line :826:1
		var plist__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__6, pn__8), t.F_pkg, r__7); var plist__10 any




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4)) { plist__10 = plist__9 } else { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_627; plist__10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g)), plist__9)), lang.RT_Meta_O__IPersistentMap_NoInit(plist__9)) }
//line :826:1
		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_628; var tmp13 any = t.F_g; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()); var tmp15 any = t.F_n; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1464000569); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, tmp13, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)))).Ref()), plist__10, tmp14.Invoke_O_O_O__O(tmp15, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))), tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000570__3))) } else { s__1464000570__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000570__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :826:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A_New_O_O_O_I_O_O(p0, p1, p2 any, p3 int32, p4, p5 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A{}; t.Ctor_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :826:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A) Ctor_O_O_O_I_O_O(c__g, c__pkg, c__n any, c__size__1927001038__auto__ int32, c__b__1464000572, c__c__1927001037__auto__ any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000572 = c__b__1464000572; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :826:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A) Invoke_O__O(self any) any { { var i__1464000571__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000571__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000571__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_625.GetRawRoot__O()).Invoke_O__O(mm__2))
																	if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_626.GetRawRoot__O()).Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____3 }
//line :826:1
	if jrt.J2g_Truth(tmp2) { var vec__1464000576__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var ps__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000576__3, lang.RT_IntCast_J__I_NoInit(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1464000576__3, lang.RT_IntCast_J__I_NoInit(1), nil); var pn__6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp4 any; var iter__1927001039__auto____6 any; var tmp5 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A_New(); var tmp6 *jrt.Class
		var fncls__165 /*line :826:1*/*jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A_fn_class


		if fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_247, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A_fn_class = fncls__165d; tmp6 = fncls__165d } else { tmp6 = fncls__165 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(ps__4)).Ref())); pn__6 = tmp3.Invoke_O__O(tmp4)
//line :826:1
		var plist__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__4, pn__6), t.F_pkg, r__5); var plist__8 any




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2)) { plist__8 = plist__7 } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_627; plist__8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g)), plist__7)), lang.RT_Meta_O__IPersistentMap_NoInit(plist__7)) }
//line :826:1
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp10 any = t.F_b__1464000572; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_628; var tmp13 any = t.F_g; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()); var tmp15 any = t.F_n; tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_113, nil), jrt.RefArrayOf(jrt.Object_class, tmp13, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)))).Ref()), plist__8, tmp14.Invoke_O_O_O__O(tmp15, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)))); i__1464000571__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000571__1); continue L1 } else { i__1464000571__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000571__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A_New() *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A{}; t.Ctor(); return t }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A) Ctor() {}
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A) Invoke_O_O__O(self, s__1464000580__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A_New_O_O(self, s__1464000580__1); var tmp2 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_248, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A_fn_class = fncls__164d; tmp2 = fncls__164d } else { tmp2 = fncls__164 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :829:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A{}; t.Ctor_O_O(p0, p1); return t }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A) Ctor_O_O(c__iter__1464000579, c__s__1464000580 any) { t.F_iter__1464000579 = c__iter__1464000579; t.F_s__1464000580 = c__s__1464000580 }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A) Invoke_O__O(self any) any { { var s__1464000580__1 any; var t_ any = t.F_s__1464000580; t.F_s__1464000580 = nil; s__1464000580__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000580__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000580__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000580__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000580__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000582__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A_New_I_O_O(size__1927001038__auto____5, b__1464000582__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_249, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000579); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000582__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000580__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000582__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000580__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000579); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000580__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :829:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000582, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000582 = c__b__1464000582; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A) Invoke_O__O(self any) any { { var i__1464000581__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000581__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000581__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000582; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000581__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000581__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :829:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A_New() *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A{}; t.Ctor(); return t }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A) Ctor() {}
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A) Invoke_O_O__O(self, s__1464000594__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A_New_O_O(s__1464000594__1, self); var tmp2 *jrt.Class; var fncls__168 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A_fn_class; if fncls__168 == nil { var fncls__168d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_250, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A_fn_class = fncls__168d; tmp2 = fncls__168d } else { tmp2 = fncls__168 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :829:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A{}; t.Ctor_O_O(p0, p1); return t }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A) Ctor_O_O(c__s__1464000594, c__iter__1464000593 any) { t.F_s__1464000594 = c__s__1464000594; t.F_iter__1464000593 = c__iter__1464000593 }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A) Invoke_O__O(self any) any { { var s__1464000594__1 any; var t_ any = t.F_s__1464000594; t.F_s__1464000594 = nil; s__1464000594__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000594__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000594__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000594__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000594__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000596__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000596__6); var tmp2 *jrt.Class; var fncls__167 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A_fn_class; if fncls__167 == nil { var fncls__167d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_251, false); A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A_fn_class = fncls__167d; tmp2 = fncls__167d } else { tmp2 = fncls__167 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000593); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000596__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000594__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000596__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000594__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000593); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000594__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :829:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000596 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000596 = c__b__1464000596 }
//line :829:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A) Invoke_O__O(self any) any { { var i__1464000595__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000595__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000595__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000596; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000595__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000595__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_class_forms_A_New() *A_arbace_j2g_decls_class_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_A{}; t.Ctor(); return t }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_A) Ctor() {}
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_A) Invoke_O_O__O(self, n__0 any) any { var pkg__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_63.GetRawRoot__O()).Invoke_O__O(n__0); var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__0); var d__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0); var iface__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__0); var leaf__6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(iface__5); if






	jrt.J2g_Truth(and__1927000168__auto____6) { leaf__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__0) } else { leaf__6 = and__1927000168__auto____6 }; var abstract__7 any = /*line :836:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(d__4), A_arbace_j2g_decls_A_const_244); var fields__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_416.GetRawRoot__O()).Invoke_O__O(n__0); var ifields__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_361.GetRawRoot__O(), fields__8); var methods__10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_458.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_638; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_11, Lit_12))).Ref())); var tmp6 any; if














	jrt.J2g_Truth(iface__5) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_639; var tmp9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp12 any = A_arbace_j2g_decls_A_const_640; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp14 lang.IPersistentVector



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_641.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp14 = nil } else { tmp14 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__2, Lit_13)) }
//line :851:1
		var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____11 any; var tmp17 any = A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A_New_O(pkg__2); var tmp18 *jrt.Class
		var fncls__180 /*line :851:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A_fn_class




		if fncls__180 == nil { var fncls__180d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A_fn_class = fncls__180d; tmp18 = fncls__180d } else { tmp18 = fncls__180 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0))
//line :851:1
		var tmp19 any = tmp16; var tmp20 lang.IPersistentVector







		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_641.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp20 = nil } else { tmp20 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), lang.PersistentVector_EMPTY.Ref())) }
//line :851:1
		var tmp21 any = tmp20; var tmp22 any; var iter__1927001039__auto____11_2 any; var tmp23 any = A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A_New_O(pkg__2); var tmp24 *jrt.Class
		var fncls__183 /*line :851:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A_fn_class








		if fncls__183 == nil { var fncls__183d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A_fn_class = fncls__183d; tmp24 = fncls__183d } else { tmp24 = fncls__183 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____11_2).Invoke_O__O(A_arbace_j2g_decls_A_const_122.Invoke_O__O(d__4))
//line :851:1
		tmp6 = lang.Tuple_Create_O__IPersistentVector(tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13.Invoke_O_O_O_O__O(tmp15, tmp19, tmp21, tmp22)))) } else {












			var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_645; var tmp28 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp31 any = A_arbace_j2g_decls_A_const_646; var tmp32 any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp32 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_648, A_arbace_j2g_decls_A_const_649) } else { tmp32 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_647.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0) }
//line :864:1
			var tmp33 any = tmp32; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp35 any; var iter__1927001039__auto____11_3 any; var tmp36 any = A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A_New_O(pkg__2); var tmp37 *jrt.Class
			var fncls__189 /*line :864:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A_fn_class



			if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A_fn_class = fncls__189d; tmp37 = fncls__189d } else { tmp37 = fncls__189 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifields__9)
//line :864:1
			var tmp38 any = lang.Tuple_Create_O__IPersistentVector(tmp26.Invoke_O_O_O__O(tmp27, tmp28, tmp29.Invoke_O_O_O_O__O(tmp30, tmp31, tmp33, tmp34.Invoke_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_decls_A_const_650.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0))))); var tmp39 lang.IPersistentVector





			if jrt.J2g_Truth(leaf__6) { tmp39 = nil } else { var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_651; var tmp42 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp45 any = A_arbace_j2g_decls_A_const_652; var tmp46 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_653.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp48 any; var iter__1927001039__auto____11_4 any; var tmp49 any = A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A_New_O(pkg__2); var tmp50 *jrt.Class
				var fncls__192 /*line :870:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A_fn_class



				if fncls__192 == nil { var fncls__192d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_19, false); A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A_fn_class = fncls__192d; tmp50 = fncls__192d } else { tmp50 = fncls__192 }; iter__1927001039__auto____11_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp49, tmp50, nil); tmp48 = lang.IFn_Cast(iter__1927001039__auto____11_4).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0))
//line :870:1
				var tmp51 any = tmp48; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()); var tmp53 any = lang.PersistentVector_EMPTY.Ref(); var tmp54 any = A_arbace_j2g_decls_A_const_18; var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp56 any = A_arbace_j2g_decls_A_const_655; var tmp57 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), tmp52.Invoke_O_O__O(tmp53, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp54, tmp55.Invoke_O_O__O(tmp56, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3))))))); var tmp58 any; var iter__1927001039__auto____11_5 any; var tmp59 any = A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A_New_O(pkg__2); var tmp60 *jrt.Class
				var fncls__195 /*line :870:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A_fn_class





				if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_21, false); A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A_fn_class = fncls__195d; tmp60 = fncls__195d } else { tmp60 = fncls__195 }; iter__1927001039__auto____11_5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp59, tmp60, nil); tmp58 = lang.IFn_Cast(iter__1927001039__auto____11_5).Invoke_O__O(methods__10)
//line :870:1
				var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp62 any = A_arbace_j2g_decls_A_const_656; var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_decls_A_const_658; var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp66 any = A_arbace_j2g_decls_A_const_659; var tmp67 any = A_arbace_j2g_decls_A_const_18; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp69 any = A_arbace_j2g_decls_A_const_660; tmp39 = lang.Tuple_Create_O_O__IPersistentVector(tmp40.Invoke_O_O_O__O(tmp41, tmp42, tmp43.Invoke_O_O_O_O__O(tmp44, tmp45, tmp46, tmp47.Invoke_O_O_O__O(tmp51, tmp57, tmp58))), tmp61.Invoke_O_O_O_O__O(tmp62, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(tmp63.Invoke_O_O__O(tmp64, tmp65.Invoke_O_O__O(tmp66, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3)))), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp67, tmp68.Invoke_O_O__O(tmp69, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3))))), A_arbace_j2g_decls_A_const_657)) }
//line :864:1
			var tmp70 any = tmp39; var tmp71 any; var iter__1927001039__auto____11_6 any; var tmp72 any = A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A_New_O(g__3); var tmp73 *jrt.Class
			var fncls__186 /*line :864:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A_fn_class
















			if fncls__186 == nil { var fncls__186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A_fn_class = fncls__186d; tmp73 = fncls__186d } else { tmp73 = fncls__186 }; iter__1927001039__auto____11_6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp72, tmp73, nil); tmp71 = lang.IFn_Cast(iter__1927001039__auto____11_6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_661.GetRawRoot__O()).Invoke_O__O(n__0))
//line :864:1
			tmp6 = tmp25.Invoke_O_O_O__O(tmp38, tmp70, tmp71) }; var tmp74 any = tmp6; var tmp75 any = /*line :848:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_634.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp76 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_635.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp77 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_636.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp78 any; if






































	jrt.J2g_Truth(iface__5) { tmp78 = nil } else {
		var tmp79 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_637.GetRawRoot__O()); var tmp80 any = A_arbace_j2g_decls_class_forms_fn__1464000670_A_New_O_O(pkg__2, n__0); var tmp81 *jrt.Class; var fncls__196 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000670_A_fn_class; if fncls__196 == nil { var fncls__196d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_j2g_decls_class_forms_fn__1464000670_A_fn_class = fncls__196d; tmp81 = fncls__196d } else { tmp81 = fncls__196 }; var tmp82 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp80, tmp81, nil); var tmp83 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()); var tmp84 any = A_arbace_j2g_decls_class_forms_fn__1464000672_A_New(); var tmp85 *jrt.Class; var fncls__197 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000672_A_fn_class; if fncls__197 == nil { var fncls__197d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_j2g_decls_class_forms_fn__1464000672_A_fn_class = fncls__197d; tmp85 = fncls__197d } else { tmp85 = fncls__197 }; tmp78 = tmp79.Invoke_O_O__O(tmp82, tmp83.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp84, tmp85, nil), methods__10)) }; var tmp86 any = tmp78; var tmp87 lang.IFn = /*line :848:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_637.GetRawRoot__O()); var tmp88 any = A_arbace_j2g_decls_class_forms_fn__1464000674_A_New_O_O(pkg__2, n__0); var tmp89 *jrt.Class; var fncls__198 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000674_A_fn_class; if








































	fncls__198 == nil { var fncls__198d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_j2g_decls_class_forms_fn__1464000674_A_fn_class = fncls__198d; tmp89 = fncls__198d } else { tmp89 = fncls__198 }; var tmp90 any = /*line :848:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp88, tmp89, nil); var tmp91 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()); var tmp92 any = A_arbace_j2g_decls_class_forms_fn__1464000676_A_New(); var tmp93 *jrt.Class; var fncls__199 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000676_A_fn_class; if








































	fncls__199 == nil { var fncls__199d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_j2g_decls_class_forms_fn__1464000676_A_fn_class = fncls__199d; tmp93 = fncls__199d } else { tmp93 = fncls__199 }; var tmp94 any = /*line :848:1*/tmp87.Invoke_O_O__O(tmp90, tmp91.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp92, tmp93, nil), methods__10)); var tmp95 any; var tmp96 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(iface__5); if









































	jrt.J2g_Truth(and__1927000168__auto____11) { tmp96 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(abstract__7) } else { tmp96 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp96) {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp95 = nil } else {



			tmp95 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_664.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0), lang.IFn_Cast(A_arbace_j2g_decls_A_const_665.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0)) } } else {
//line :890:1
				tmp95 = nil }; var tmp97 any = tmp95; var tmp98 any; if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp98 = nil } else { tmp98 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_629.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0) }; return /*line :848:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp74, tmp75, tmp76, tmp77, tmp86, tmp94, tmp97, tmp98)) }







func A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A{}; t.Ctor_O(p0); return t }
//line :856:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :856:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A) Invoke_O_O__O(self, s__1464000611__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A_New_O_O_O(t.F_pkg, s__1464000611__1, self); var tmp2 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_28, false); A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A_fn_class = fncls__179d; tmp2 = fncls__179d } else { tmp2 = fncls__179 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :856:1
func A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :856:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A) Ctor_O_O_O(c__pkg, c__s__1464000611, c__iter__1464000610 any) { t.F_pkg = c__pkg; t.F_s__1464000611 = c__s__1464000611; t.F_iter__1464000610 = c__iter__1464000610 }
//line :856:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A) Invoke_O__O(self any) any { { var s__1464000611__1 any; var t_ any = t.F_s__1464000611; t.F_s__1464000611 = nil; s__1464000611__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000611__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000611__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000611__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000611__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000613__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A_New_O_O_I_O(b__1464000613__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__178 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A_fn_class; if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A_fn_class = fncls__178d; tmp2 = fncls__178d } else { tmp2 = fncls__178 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000610); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000613__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000611__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000613__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000611__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000610); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000611__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :856:1
func A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :856:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A) Ctor_O_O_I_O(c__b__1464000613, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000613 = c__b__1464000613; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :856:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A) Invoke_O__O(self any) any { { var i__1464000612__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000612__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000612__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000613; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__2)); i__1464000612__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000612__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A{}; t.Ctor_O(p0); return t }
//line :860:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :860:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A) Invoke_O_O__O(self, s__1464000621__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A_New_O_O_O(t.F_pkg, s__1464000621__1, self); var tmp2 *jrt.Class; var fncls__182 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A_fn_class; if fncls__182 == nil { var fncls__182d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A_fn_class = fncls__182d; tmp2 = fncls__182d } else { tmp2 = fncls__182 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :860:1
func A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :860:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A) Ctor_O_O_O(c__pkg, c__s__1464000621, c__iter__1464000620 any) { t.F_pkg = c__pkg; t.F_s__1464000621 = c__s__1464000621; t.F_iter__1464000620 = c__iter__1464000620 }
//line :860:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A) Invoke_O__O(self any) any { { var s__1464000621__1 any; var t_ any = t.F_s__1464000621; t.F_s__1464000621 = nil; s__1464000621__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000621__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000621__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000621__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000621__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000623__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A_New_O_O_I_O(b__1464000623__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_31, false); A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A_fn_class = fncls__181d; tmp2 = fncls__181d } else { tmp2 = fncls__181 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000620); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000623__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000621__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000623__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000621__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4))
															if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_626.GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____6 } } else { tmp4 = and__1927000168__auto____5 }
//line :860:1
	if jrt.J2g_Truth(tmp4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_461.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))))) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000620); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_633.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000621__3))) } else { s__1464000621__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000621__3); continue L1 } } else { s__1464000621__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000621__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :860:1
func A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :860:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A) Ctor_O_O_I_O(c__b__1464000623, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000623 = c__b__1464000623; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :860:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A) Invoke_O__O(self any) any { { var i__1464000622__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000622__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000622__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2))
																if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_626.GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :860:1
	if jrt.J2g_Truth(tmp2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_461.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))))) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp4 any = t.F_b__1464000623; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_633.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__2)); i__1464000622__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000622__1); continue L1 } else { i__1464000622__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000622__1); continue L1 } } else { i__1464000622__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000622__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A{}; t.Ctor_O(p0); return t }
//line :868:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :868:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A) Invoke_O_O__O(self, s__1464000631__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A_New_O_O_O(t.F_pkg, s__1464000631__1, self); var tmp2 *jrt.Class; var fncls__188 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A_fn_class; if fncls__188 == nil { var fncls__188d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A_fn_class = fncls__188d; tmp2 = fncls__188d } else { tmp2 = fncls__188 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :868:1
func A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :868:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A) Ctor_O_O_O(c__pkg, c__s__1464000631, c__iter__1464000630 any) { t.F_pkg = c__pkg; t.F_s__1464000631 = c__s__1464000631; t.F_iter__1464000630 = c__iter__1464000630 }
//line :868:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A) Invoke_O__O(self any) any { { var s__1464000631__1 any; var t_ any = t.F_s__1464000631; t.F_s__1464000631 = nil; s__1464000631__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000631__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000631__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000631__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000631__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000633__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A_New_O_O_I_O(b__1464000633__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__187 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A_fn_class; if fncls__187 == nil { var fncls__187d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A_fn_class = fncls__187d; tmp2 = fncls__187d } else { tmp2 = fncls__187 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000630); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000633__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000631__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000633__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000631__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000630); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__4))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_477.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000631__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :868:1
func A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :868:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A) Ctor_O_O_I_O(c__b__1464000633, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000633 = c__b__1464000633; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :868:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A) Invoke_O__O(self any) any { { var i__1464000632__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000632__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000632__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000633; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__2))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_477.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__2))); i__1464000632__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000632__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A{}; t.Ctor_O(p0); return t }
//line :874:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :874:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A) Invoke_O_O__O(self, s__1464000641__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A_New_O_O_O(t.F_pkg, s__1464000641__1, self); var tmp2 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_34, false); A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A_fn_class = fncls__191d; tmp2 = fncls__191d } else { tmp2 = fncls__191 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :874:1
func A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :874:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A) Ctor_O_O_O(c__pkg, c__s__1464000641, c__iter__1464000640 any) { t.F_pkg = c__pkg; t.F_s__1464000641 = c__s__1464000641; t.F_iter__1464000640 = c__iter__1464000640 }
//line :874:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A) Invoke_O__O(self any) any { { var s__1464000641__1 any; var t_ any = t.F_s__1464000641; t.F_s__1464000641 = nil; s__1464000641__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000641__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000641__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000641__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000641__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000643__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A_New_O_O_I_O(b__1464000643__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__190 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A_fn_class; if fncls__190 == nil { var fncls__190d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A_fn_class = fncls__190d; tmp2 = fncls__190d } else { tmp2 = fncls__190 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000640); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000643__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000641__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000643__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000641__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000640); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000641__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :874:1
func A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :874:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A) Ctor_O_O_I_O(c__b__1464000643, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000643 = c__b__1464000643; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :874:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A) Invoke_O__O(self any) any { { var i__1464000642__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000642__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000642__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000643; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__2)); i__1464000642__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000642__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A{}; t.Ctor_O(p0); return t }
//line :876:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :876:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A) Invoke_O_O__O(self, s__1464000651__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A_New_O_O_O(t.F_pkg, s__1464000651__1, self); var tmp2 *jrt.Class; var fncls__194 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A_fn_class; if fncls__194 == nil { var fncls__194d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A_fn_class = fncls__194d; tmp2 = fncls__194d } else { tmp2 = fncls__194 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :876:1
func A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :876:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A) Ctor_O_O_O(c__pkg, c__s__1464000651, c__iter__1464000650 any) { t.F_pkg = c__pkg; t.F_s__1464000651 = c__s__1464000651; t.F_iter__1464000650 = c__iter__1464000650 }
//line :876:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A) Invoke_O__O(self any) any { { var s__1464000651__1 any; var t_ any = t.F_s__1464000651; t.F_s__1464000651 = nil; s__1464000651__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000651__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000651__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000651__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000651__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000653__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A_New_O_O_I_O(b__1464000653__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_37, false); A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A_fn_class = fncls__193d; tmp2 = fncls__193d } else { tmp2 = fncls__193 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000650); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000653__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000651__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000653__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000651__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_654.GetRawRoot__O()).Invoke_O__O(mm__4)) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_461.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000650); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_633.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000651__3))) } else { s__1464000651__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000651__3); continue L1 } } else { s__1464000651__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000651__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :876:1
func A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :876:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A) Ctor_O_O_I_O(c__b__1464000653, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000653 = c__b__1464000653; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :876:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A) Invoke_O__O(self any) any { { var i__1464000652__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000652__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000652__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_654.GetRawRoot__O()).Invoke_O__O(mm__2)) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_461.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000653; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_633.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__2)); i__1464000652__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000652__1); continue L1 } else { i__1464000652__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000652__1); continue L1 } } else { i__1464000652__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000652__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A{}; t.Ctor_O(p0); return t }
//line :881:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :881:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A) Invoke_O_O__O(self, s__1464000661__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A_New_O_O_O(t.F_g, s__1464000661__1, self); var tmp2 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_38, false); A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A_fn_class = fncls__185d; tmp2 = fncls__185d } else { tmp2 = fncls__185 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :881:1
func A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :881:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A) Ctor_O_O_O(c__g, c__s__1464000661, c__iter__1464000660 any) { t.F_g = c__g; t.F_s__1464000661 = c__s__1464000661; t.F_iter__1464000660 = c__iter__1464000660 }
//line :881:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A) Invoke_O__O(self any) any { { var s__1464000661__1 any; var t_ any = t.F_s__1464000661; t.F_s__1464000661 = nil; s__1464000661__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000661__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000661__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000661__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000661__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1464000663__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A_New_O_O_I_O(b__1464000663__6, t.F_g, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__184 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A_fn_class; if fncls__184 == nil { var fncls__184d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_39, false); A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A_fn_class = fncls__184d; tmp2 = fncls__184d } else { tmp2 = fncls__184 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000660); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000663__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000661__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000663__6), nil) } } else { var j__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000661__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_641.GetRawRoot__O()).Invoke_O__O(j__4))) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_642; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_643; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_644; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1464000660); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(j__4))).Ref()), lang.Tuple_Create_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g))))), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000661__3))) } else { s__1464000661__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000661__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :881:1
func A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :881:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A) Ctor_O_O_I_O(c__b__1464000663, c__g any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000663 = c__b__1464000663; t.F_g = c__g; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :881:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A) Invoke_O__O(self any) any { { var i__1464000662__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1464000662__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1464000662__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_641.GetRawRoot__O()).Invoke_O__O(j__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000663; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_642; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_643; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_644; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(j__2))).Ref()), lang.Tuple_Create_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g)))))); i__1464000662__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000662__1); continue L1 } else { i__1464000662__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1464000662__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_class_forms_fn__1464000670_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_class_forms_fn__1464000670_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000670_A{}; t.Ctor_O_O(p0, p1); return t }
//line :888:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000670_A) Ctor_O_O(c__pkg, c__n any) { t.F_pkg = c__pkg; t.F_n = c__n }
//line :888:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000670_A) Invoke_O_O__O(self, p1__1464000606_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_662.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, p1__1464000606_SHARP___1) }
//line :888:1
func A_arbace_j2g_decls_class_forms_fn__1464000672_A_New() *A_arbace_j2g_decls_class_forms_fn__1464000672_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000672_A{}; t.Ctor(); return t }
//line :888:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000672_A) Ctor() {}
//line :888:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000672_A) Invoke_O_O__O(self, p1__1464000607_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(p1__1464000607_SHARP___1))).Ref() }
func A_arbace_j2g_decls_class_forms_fn__1464000674_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_class_forms_fn__1464000674_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000674_A{}; t.Ctor_O_O(p0, p1); return t }
//line :889:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000674_A) Ctor_O_O(c__pkg, c__n any) { t.F_pkg = c__pkg; t.F_n = c__n }
//line :889:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000674_A) Invoke_O_O__O(self, p1__1464000608_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_663.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, p1__1464000608_SHARP___1) }
//line :889:1
func A_arbace_j2g_decls_class_forms_fn__1464000676_A_New() *A_arbace_j2g_decls_class_forms_fn__1464000676_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000676_A{}; t.Ctor(); return t }
//line :889:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000676_A) Ctor() {}
//line :889:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000676_A) Invoke_O_O__O(self, p1__1464000609_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(p1__1464000609_SHARP___1))).Ref() }





























































































































































































































































































































































type A_arbace_j2g_decls_A struct{ jrt.Object }

var A_arbace_j2g_decls_A_const_pool *jrt.RefArray

var A_arbace_j2g_decls_A_const_0 *lang.Var

var A_arbace_j2g_decls_A_const_1 *lang.Var

var A_arbace_j2g_decls_A_const_2 any

var A_arbace_j2g_decls_A_const_3 any

var A_arbace_j2g_decls_A_const_4 any

var A_arbace_j2g_decls_A_const_5 any

var A_arbace_j2g_decls_A_const_6 any

var A_arbace_j2g_decls_A_const_7 any

var A_arbace_j2g_decls_A_const_8 any

var A_arbace_j2g_decls_A_const_9 any

var A_arbace_j2g_decls_A_const_10 any

var A_arbace_j2g_decls_A_const_11 any

var A_arbace_j2g_decls_A_const_12 *lang.Var

var A_arbace_j2g_decls_A_const_13 *lang.Var

var A_arbace_j2g_decls_A_const_14 *lang.Var

var A_arbace_j2g_decls_A_const_15 any

var A_arbace_j2g_decls_A_const_16 *lang.Var

var A_arbace_j2g_decls_A_const_17 *lang.Var

var A_arbace_j2g_decls_A_const_18 *lang.Keyword

var A_arbace_j2g_decls_A_const_19 *lang.Var

var A_arbace_j2g_decls_A_const_20 *lang.Var

var A_arbace_j2g_decls_A_const_21 *lang.Var

var A_arbace_j2g_decls_A_const_22 *lang.Var

var A_arbace_j2g_decls_A_const_23 *lang.Var

var A_arbace_j2g_decls_A_const_24 *lang.Var

var A_arbace_j2g_decls_A_const_25 *lang.Var

var A_arbace_j2g_decls_A_const_26 *lang.Var

var A_arbace_j2g_decls_A_const_27 *lang.Var

var A_arbace_j2g_decls_A_const_28 *lang.Var

var A_arbace_j2g_decls_A_const_29 *lang.Var

var A_arbace_j2g_decls_A_const_30 *lang.Var

var A_arbace_j2g_decls_A_const_31 *lang.Var

var A_arbace_j2g_decls_A_const_32 *lang.Var

var A_arbace_j2g_decls_A_const_33 *lang.Keyword

var A_arbace_j2g_decls_A_const_34 *lang.Keyword

var A_arbace_j2g_decls_A_const_35 *lang.Keyword

var A_arbace_j2g_decls_A_const_36 *lang.Var

var A_arbace_j2g_decls_A_const_37 *lang.Keyword

var A_arbace_j2g_decls_A_const_38 *lang.Keyword

var A_arbace_j2g_decls_A_const_39 *lang.Keyword

var A_arbace_j2g_decls_A_const_40 *lang.Keyword

var A_arbace_j2g_decls_A_const_41 *lang.Var

var A_arbace_j2g_decls_A_const_42 *lang.Keyword

var A_arbace_j2g_decls_A_const_43 *lang.Keyword

var A_arbace_j2g_decls_A_const_44 *lang.Keyword

var A_arbace_j2g_decls_A_const_45 *lang.Keyword

var A_arbace_j2g_decls_A_const_46 *lang.Var

var A_arbace_j2g_decls_A_const_47 *lang.Var

var A_arbace_j2g_decls_A_const_48 *lang.Var

var A_arbace_j2g_decls_A_const_49 any

var A_arbace_j2g_decls_A_const_50 any

var A_arbace_j2g_decls_A_const_51 *lang.Var

var A_arbace_j2g_decls_A_const_52 any

var A_arbace_j2g_decls_A_const_53 any

var A_arbace_j2g_decls_A_const_54 *lang.Var

var A_arbace_j2g_decls_A_const_55 any

var A_arbace_j2g_decls_A_const_56 *lang.Var

var A_arbace_j2g_decls_A_const_57 *lang.Var

var A_arbace_j2g_decls_A_const_58 *lang.Var

var A_arbace_j2g_decls_A_const_59 any

var A_arbace_j2g_decls_A_const_60 any

var A_arbace_j2g_decls_A_const_61 *lang.Var

var A_arbace_j2g_decls_A_const_62 *lang.Var

var A_arbace_j2g_decls_A_const_63 *lang.Var

var A_arbace_j2g_decls_A_const_64 *lang.Var

var A_arbace_j2g_decls_A_const_65 any

var A_arbace_j2g_decls_A_const_66 *lang.Keyword

var A_arbace_j2g_decls_A_const_67 *lang.Var

var A_arbace_j2g_decls_A_const_68 *lang.Var

var A_arbace_j2g_decls_A_const_69 *lang.Var

var A_arbace_j2g_decls_A_const_70 *lang.Var

var A_arbace_j2g_decls_A_const_71 *lang.Keyword

var A_arbace_j2g_decls_A_const_72 *lang.Var

var A_arbace_j2g_decls_A_const_73 *lang.Var

var A_arbace_j2g_decls_A_const_74 *lang.Keyword

var A_arbace_j2g_decls_A_const_75 *lang.Var

var A_arbace_j2g_decls_A_const_76 *lang.Var

var A_arbace_j2g_decls_A_const_77 *lang.Var

var A_arbace_j2g_decls_A_const_78 *lang.Var

var A_arbace_j2g_decls_A_const_79 *lang.Var

var A_arbace_j2g_decls_A_const_80 *lang.Keyword

var A_arbace_j2g_decls_A_const_81 *lang.Keyword

var A_arbace_j2g_decls_A_const_82 *lang.Keyword

var A_arbace_j2g_decls_A_const_83 *lang.Keyword

var A_arbace_j2g_decls_A_const_84 *lang.Var

var A_arbace_j2g_decls_A_const_85 *lang.Keyword

var A_arbace_j2g_decls_A_const_86 *lang.Keyword

var A_arbace_j2g_decls_A_const_87 *lang.Keyword

var A_arbace_j2g_decls_A_const_88 *lang.Keyword

var A_arbace_j2g_decls_A_const_89 *lang.Keyword

var A_arbace_j2g_decls_A_const_90 *lang.Var

var A_arbace_j2g_decls_A_const_91 *lang.Var

var A_arbace_j2g_decls_A_const_92 *lang.Var

var A_arbace_j2g_decls_A_const_93 *lang.Var

var A_arbace_j2g_decls_A_const_94 *lang.Var

var A_arbace_j2g_decls_A_const_95 *lang.Var

var A_arbace_j2g_decls_A_const_96 *lang.Var

var A_arbace_j2g_decls_A_const_97 *lang.Keyword

var A_arbace_j2g_decls_A_const_98 *lang.Var

var A_arbace_j2g_decls_A_const_99 *lang.Keyword

var A_arbace_j2g_decls_A_const_100 *lang.Keyword

var A_arbace_j2g_decls_A_const_101 *lang.Keyword

var A_arbace_j2g_decls_A_const_102 *lang.Var

var A_arbace_j2g_decls_A_const_103 *lang.Keyword

var A_arbace_j2g_decls_A_const_104 any

var A_arbace_j2g_decls_A_const_105 *lang.Keyword

var A_arbace_j2g_decls_A_const_106 *lang.Var

var A_arbace_j2g_decls_A_const_107 *lang.Keyword

var A_arbace_j2g_decls_A_const_108 *lang.Var

var A_arbace_j2g_decls_A_const_109 *lang.Var

var A_arbace_j2g_decls_A_const_110 *lang.Var

var A_arbace_j2g_decls_A_const_111 *lang.Var

var A_arbace_j2g_decls_A_const_112 *lang.Var

var A_arbace_j2g_decls_A_const_113 any

var A_arbace_j2g_decls_A_const_114 *lang.Keyword

var A_arbace_j2g_decls_A_const_115 *lang.Var

var A_arbace_j2g_decls_A_const_116 *lang.Var

var A_arbace_j2g_decls_A_const_117 *lang.Var

var A_arbace_j2g_decls_A_const_118 *lang.Keyword

var A_arbace_j2g_decls_A_const_119 *lang.Keyword

var A_arbace_j2g_decls_A_const_120 *lang.Var

var A_arbace_j2g_decls_A_const_121 *lang.Var

var A_arbace_j2g_decls_A_const_122 *lang.Keyword

var A_arbace_j2g_decls_A_const_123 *lang.Keyword

var A_arbace_j2g_decls_A_const_124 *lang.Var

var A_arbace_j2g_decls_A_const_125 *lang.Var

var A_arbace_j2g_decls_A_const_126 *lang.Keyword

var A_arbace_j2g_decls_A_const_127 *lang.Var

var A_arbace_j2g_decls_A_const_128 *lang.Var

var A_arbace_j2g_decls_A_const_129 any

var A_arbace_j2g_decls_A_const_130 any

var A_arbace_j2g_decls_A_const_131 any

var A_arbace_j2g_decls_A_const_132 *lang.Var

var A_arbace_j2g_decls_A_const_133 any

var A_arbace_j2g_decls_A_const_134 any

var A_arbace_j2g_decls_A_const_135 any

var A_arbace_j2g_decls_A_const_136 any

var A_arbace_j2g_decls_A_const_137 *lang.Var

var A_arbace_j2g_decls_A_const_138 *lang.Keyword

var A_arbace_j2g_decls_A_const_139 *lang.Var

var A_arbace_j2g_decls_A_const_140 any

var A_arbace_j2g_decls_A_const_141 *lang.Keyword

var A_arbace_j2g_decls_A_const_142 *lang.Keyword

var A_arbace_j2g_decls_A_const_143 *lang.Var

var A_arbace_j2g_decls_A_const_144 *lang.Var

var A_arbace_j2g_decls_A_const_145 *lang.Var

var A_arbace_j2g_decls_A_const_146 *lang.Var

var A_arbace_j2g_decls_A_const_147 *lang.Var

var A_arbace_j2g_decls_A_const_148 *lang.Var

var A_arbace_j2g_decls_A_const_149 *lang.Var

var A_arbace_j2g_decls_A_const_150 *lang.Var

var A_arbace_j2g_decls_A_const_151 *lang.Var

var A_arbace_j2g_decls_A_const_152 *lang.Var

var A_arbace_j2g_decls_A_const_153 *lang.Var

var A_arbace_j2g_decls_A_const_154 *lang.Var

var A_arbace_j2g_decls_A_const_155 any

var A_arbace_j2g_decls_A_const_156 *lang.Var

var A_arbace_j2g_decls_A_const_157 *lang.Keyword

var A_arbace_j2g_decls_A_const_158 *lang.Var

var A_arbace_j2g_decls_A_const_159 *lang.Var

var A_arbace_j2g_decls_A_const_160 *lang.Keyword

var A_arbace_j2g_decls_A_const_161 *lang.Var

var A_arbace_j2g_decls_A_const_162 *lang.Var

var A_arbace_j2g_decls_A_const_163 *lang.Var

var A_arbace_j2g_decls_A_const_164 *lang.Var

var A_arbace_j2g_decls_A_const_165 any

var A_arbace_j2g_decls_A_const_166 any

var A_arbace_j2g_decls_A_const_167 *lang.Keyword

var A_arbace_j2g_decls_A_const_168 *lang.Var

var A_arbace_j2g_decls_A_const_169 *lang.Var

var A_arbace_j2g_decls_A_const_170 *lang.Var

var A_arbace_j2g_decls_A_const_171 *lang.Var

var A_arbace_j2g_decls_A_const_172 any

var A_arbace_j2g_decls_A_const_173 *lang.Keyword

var A_arbace_j2g_decls_A_const_174 *lang.Keyword

var A_arbace_j2g_decls_A_const_175 any

var A_arbace_j2g_decls_A_const_176 any

var A_arbace_j2g_decls_A_const_177 *lang.Keyword

var A_arbace_j2g_decls_A_const_178 *lang.Keyword

var A_arbace_j2g_decls_A_const_179 any

var A_arbace_j2g_decls_A_const_180 *lang.Keyword

var A_arbace_j2g_decls_A_const_181 *lang.Var

var A_arbace_j2g_decls_A_const_182 *lang.Keyword

var A_arbace_j2g_decls_A_const_183 *lang.Keyword

var A_arbace_j2g_decls_A_const_184 *lang.Keyword

var A_arbace_j2g_decls_A_const_185 *lang.Var

var A_arbace_j2g_decls_A_const_186 *lang.Var

var A_arbace_j2g_decls_A_const_187 *lang.Keyword

var A_arbace_j2g_decls_A_const_188 *lang.Keyword

var A_arbace_j2g_decls_A_const_189 *lang.Keyword

var A_arbace_j2g_decls_A_const_190 *lang.Keyword

var A_arbace_j2g_decls_A_const_191 *lang.Keyword

var A_arbace_j2g_decls_A_const_192 *lang.Keyword

var A_arbace_j2g_decls_A_const_193 *lang.Keyword

var A_arbace_j2g_decls_A_const_194 *lang.Var

var A_arbace_j2g_decls_A_const_195 any

var A_arbace_j2g_decls_A_const_196 any

var A_arbace_j2g_decls_A_const_197 any

var A_arbace_j2g_decls_A_const_198 *lang.Keyword

var A_arbace_j2g_decls_A_const_199 *lang.Keyword

var A_arbace_j2g_decls_A_const_200 *lang.Var

var A_arbace_j2g_decls_A_const_201 *lang.Var

var A_arbace_j2g_decls_A_const_202 *lang.Var

var A_arbace_j2g_decls_A_const_203 *lang.Var

var A_arbace_j2g_decls_A_const_204 *lang.Var

var A_arbace_j2g_decls_A_const_205 *lang.Var

var A_arbace_j2g_decls_A_const_206 any

var A_arbace_j2g_decls_A_const_207 *lang.Var

var A_arbace_j2g_decls_A_const_208 *lang.Var

var A_arbace_j2g_decls_A_const_209 *lang.Keyword

var A_arbace_j2g_decls_A_const_210 *lang.Keyword

var A_arbace_j2g_decls_A_const_211 *lang.Keyword

var A_arbace_j2g_decls_A_const_212 *lang.Keyword

var A_arbace_j2g_decls_A_const_213 *lang.Keyword

var A_arbace_j2g_decls_A_const_214 *lang.Keyword

var A_arbace_j2g_decls_A_const_215 *lang.Var

var A_arbace_j2g_decls_A_const_216 any

var A_arbace_j2g_decls_A_const_217 any

var A_arbace_j2g_decls_A_const_218 any

var A_arbace_j2g_decls_A_const_219 any

var A_arbace_j2g_decls_A_const_220 any

var A_arbace_j2g_decls_A_const_221 *lang.Keyword

var A_arbace_j2g_decls_A_const_222 *lang.Var

var A_arbace_j2g_decls_A_const_223 *lang.Keyword

var A_arbace_j2g_decls_A_const_224 *lang.Keyword

var A_arbace_j2g_decls_A_const_225 *lang.Keyword

var A_arbace_j2g_decls_A_const_226 any

var A_arbace_j2g_decls_A_const_227 any

var A_arbace_j2g_decls_A_const_228 *lang.Keyword

var A_arbace_j2g_decls_A_const_229 any

var A_arbace_j2g_decls_A_const_230 any

var A_arbace_j2g_decls_A_const_231 *lang.Var

var A_arbace_j2g_decls_A_const_232 *lang.Var

var A_arbace_j2g_decls_A_const_233 any

var A_arbace_j2g_decls_A_const_234 any

var A_arbace_j2g_decls_A_const_235 any

var A_arbace_j2g_decls_A_const_236 *lang.Var

var A_arbace_j2g_decls_A_const_237 *lang.Var

var A_arbace_j2g_decls_A_const_238 *lang.Keyword

var A_arbace_j2g_decls_A_const_239 any

var A_arbace_j2g_decls_A_const_240 any

var A_arbace_j2g_decls_A_const_241 any

var A_arbace_j2g_decls_A_const_242 *lang.Var

var A_arbace_j2g_decls_A_const_243 any

var A_arbace_j2g_decls_A_const_244 any

var A_arbace_j2g_decls_A_const_245 any

var A_arbace_j2g_decls_A_const_246 *lang.Var

var A_arbace_j2g_decls_A_const_247 any

var A_arbace_j2g_decls_A_const_248 *lang.Var

var A_arbace_j2g_decls_A_const_249 *lang.Var

var A_arbace_j2g_decls_A_const_250 *lang.Var

var A_arbace_j2g_decls_A_const_251 any

var A_arbace_j2g_decls_A_const_252 any

var A_arbace_j2g_decls_A_const_253 any

var A_arbace_j2g_decls_A_const_254 any

var A_arbace_j2g_decls_A_const_255 any

var A_arbace_j2g_decls_A_const_256 any

var A_arbace_j2g_decls_A_const_257 any

var A_arbace_j2g_decls_A_const_258 *lang.Var

var A_arbace_j2g_decls_A_const_259 *lang.Var

var A_arbace_j2g_decls_A_const_260 any

var A_arbace_j2g_decls_A_const_261 any

var A_arbace_j2g_decls_A_const_262 any

var A_arbace_j2g_decls_A_const_263 any

var A_arbace_j2g_decls_A_const_264 any

var A_arbace_j2g_decls_A_const_265 any

var A_arbace_j2g_decls_A_const_266 any

var A_arbace_j2g_decls_A_const_267 any

var A_arbace_j2g_decls_A_const_268 any

var A_arbace_j2g_decls_A_const_269 any

var A_arbace_j2g_decls_A_const_270 any

var A_arbace_j2g_decls_A_const_271 any

var A_arbace_j2g_decls_A_const_272 any

var A_arbace_j2g_decls_A_const_273 any

var A_arbace_j2g_decls_A_const_274 any

var A_arbace_j2g_decls_A_const_275 any

var A_arbace_j2g_decls_A_const_276 any

var A_arbace_j2g_decls_A_const_277 any

var A_arbace_j2g_decls_A_const_278 any

var A_arbace_j2g_decls_A_const_279 *lang.Var

var A_arbace_j2g_decls_A_const_280 any

var A_arbace_j2g_decls_A_const_281 any

var A_arbace_j2g_decls_A_const_282 any

var A_arbace_j2g_decls_A_const_283 any

var A_arbace_j2g_decls_A_const_284 any

var A_arbace_j2g_decls_A_const_285 any

var A_arbace_j2g_decls_A_const_286 any

var A_arbace_j2g_decls_A_const_287 any

var A_arbace_j2g_decls_A_const_288 any

var A_arbace_j2g_decls_A_const_289 any

var A_arbace_j2g_decls_A_const_290 any

var A_arbace_j2g_decls_A_const_291 *lang.Var

var A_arbace_j2g_decls_A_const_292 any

var A_arbace_j2g_decls_A_const_293 any

var A_arbace_j2g_decls_A_const_294 any

var A_arbace_j2g_decls_A_const_295 any

var A_arbace_j2g_decls_A_const_296 any

var A_arbace_j2g_decls_A_const_297 any

var A_arbace_j2g_decls_A_const_298 any

var A_arbace_j2g_decls_A_const_299 any

var A_arbace_j2g_decls_A_const_300 any

var A_arbace_j2g_decls_A_const_301 any

var A_arbace_j2g_decls_A_const_302 any

var A_arbace_j2g_decls_A_const_303 any

var A_arbace_j2g_decls_A_const_304 any

var A_arbace_j2g_decls_A_const_305 any

var A_arbace_j2g_decls_A_const_306 any

var A_arbace_j2g_decls_A_const_307 any

var A_arbace_j2g_decls_A_const_308 any

var A_arbace_j2g_decls_A_const_309 any

var A_arbace_j2g_decls_A_const_310 *lang.Var

var A_arbace_j2g_decls_A_const_311 any

var A_arbace_j2g_decls_A_const_312 any

var A_arbace_j2g_decls_A_const_313 any

var A_arbace_j2g_decls_A_const_314 any

var A_arbace_j2g_decls_A_const_315 any

var A_arbace_j2g_decls_A_const_316 any

var A_arbace_j2g_decls_A_const_317 any

var A_arbace_j2g_decls_A_const_318 any

var A_arbace_j2g_decls_A_const_319 *lang.Keyword

var A_arbace_j2g_decls_A_const_320 *lang.Keyword

var A_arbace_j2g_decls_A_const_321 *lang.Keyword

var A_arbace_j2g_decls_A_const_322 *lang.Var

var A_arbace_j2g_decls_A_const_323 *lang.Keyword

var A_arbace_j2g_decls_A_const_324 *lang.Keyword

var A_arbace_j2g_decls_A_const_325 *lang.Var

var A_arbace_j2g_decls_A_const_326 *lang.Keyword

var A_arbace_j2g_decls_A_const_327 *lang.Keyword

var A_arbace_j2g_decls_A_const_328 *lang.Var

var A_arbace_j2g_decls_A_const_329 *lang.Var

var A_arbace_j2g_decls_A_const_330 *lang.Var

var A_arbace_j2g_decls_A_const_331 *lang.Keyword

var A_arbace_j2g_decls_A_const_332 *lang.Keyword

var A_arbace_j2g_decls_A_const_333 *lang.Keyword

var A_arbace_j2g_decls_A_const_334 *lang.Var

var A_arbace_j2g_decls_A_const_335 any

var A_arbace_j2g_decls_A_const_336 any

var A_arbace_j2g_decls_A_const_337 any

var A_arbace_j2g_decls_A_const_338 any

var A_arbace_j2g_decls_A_const_339 any

var A_arbace_j2g_decls_A_const_340 *lang.Keyword

var A_arbace_j2g_decls_A_const_341 any

var A_arbace_j2g_decls_A_const_342 any

var A_arbace_j2g_decls_A_const_343 *lang.Keyword

var A_arbace_j2g_decls_A_const_344 any

var A_arbace_j2g_decls_A_const_345 *lang.Keyword

var A_arbace_j2g_decls_A_const_346 any

var A_arbace_j2g_decls_A_const_347 any

var A_arbace_j2g_decls_A_const_348 *lang.Var

var A_arbace_j2g_decls_A_const_349 *lang.Var

var A_arbace_j2g_decls_A_const_350 *lang.Var

var A_arbace_j2g_decls_A_const_351 *lang.Var

var A_arbace_j2g_decls_A_const_352 *lang.Var

var A_arbace_j2g_decls_A_const_353 any

var A_arbace_j2g_decls_A_const_354 *lang.Var

var A_arbace_j2g_decls_A_const_355 *lang.Keyword

var A_arbace_j2g_decls_A_const_356 *lang.Keyword

var A_arbace_j2g_decls_A_const_357 *lang.Var

var A_arbace_j2g_decls_A_const_358 *lang.Var

var A_arbace_j2g_decls_A_const_359 *lang.Var

var A_arbace_j2g_decls_A_const_360 *lang.Var

var A_arbace_j2g_decls_A_const_361 *lang.Var

var A_arbace_j2g_decls_A_const_362 *lang.Var

var A_arbace_j2g_decls_A_const_363 any

var A_arbace_j2g_decls_A_const_364 any

var A_arbace_j2g_decls_A_const_365 any

var A_arbace_j2g_decls_A_const_366 any

var A_arbace_j2g_decls_A_const_367 *lang.Keyword

var A_arbace_j2g_decls_A_const_368 *lang.Var

var A_arbace_j2g_decls_A_const_369 *lang.Var

var A_arbace_j2g_decls_A_const_370 any

var A_arbace_j2g_decls_A_const_371 *lang.Var

var A_arbace_j2g_decls_A_const_372 *lang.Var

var A_arbace_j2g_decls_A_const_373 any

var A_arbace_j2g_decls_A_const_374 *lang.Keyword

var A_arbace_j2g_decls_A_const_375 any

var A_arbace_j2g_decls_A_const_376 any

var A_arbace_j2g_decls_A_const_377 *lang.Var

var A_arbace_j2g_decls_A_const_378 *lang.Keyword

var A_arbace_j2g_decls_A_const_379 *lang.Var

var A_arbace_j2g_decls_A_const_380 any

var A_arbace_j2g_decls_A_const_381 any

var A_arbace_j2g_decls_A_const_382 *lang.Var

var A_arbace_j2g_decls_A_const_383 any

var A_arbace_j2g_decls_A_const_384 any

var A_arbace_j2g_decls_A_const_385 any

var A_arbace_j2g_decls_A_const_386 any

var A_arbace_j2g_decls_A_const_387 any

var A_arbace_j2g_decls_A_const_388 any

var A_arbace_j2g_decls_A_const_389 any

var A_arbace_j2g_decls_A_const_390 any

var A_arbace_j2g_decls_A_const_391 any

var A_arbace_j2g_decls_A_const_392 any

var A_arbace_j2g_decls_A_const_393 any

var A_arbace_j2g_decls_A_const_394 *lang.Keyword

var A_arbace_j2g_decls_A_const_395 *lang.Keyword

var A_arbace_j2g_decls_A_const_396 any

var A_arbace_j2g_decls_A_const_397 any

var A_arbace_j2g_decls_A_const_398 any

var A_arbace_j2g_decls_A_const_399 any

var A_arbace_j2g_decls_A_const_400 any

var A_arbace_j2g_decls_A_const_401 any

var A_arbace_j2g_decls_A_const_402 *lang.Var

var A_arbace_j2g_decls_A_const_403 any

var A_arbace_j2g_decls_A_const_404 any

var A_arbace_j2g_decls_A_const_405 any

var A_arbace_j2g_decls_A_const_406 any

var A_arbace_j2g_decls_A_const_407 *lang.Keyword

var A_arbace_j2g_decls_A_const_408 any

var A_arbace_j2g_decls_A_const_409 any

var A_arbace_j2g_decls_A_const_410 any

var A_arbace_j2g_decls_A_const_411 any

var A_arbace_j2g_decls_A_const_412 any

var A_arbace_j2g_decls_A_const_413 any

var A_arbace_j2g_decls_A_const_414 any

var A_arbace_j2g_decls_A_const_415 any

var A_arbace_j2g_decls_A_const_416 *lang.Var

var A_arbace_j2g_decls_A_const_417 any

var A_arbace_j2g_decls_A_const_418 any

var A_arbace_j2g_decls_A_const_419 any

var A_arbace_j2g_decls_A_const_420 any

var A_arbace_j2g_decls_A_const_421 any

var A_arbace_j2g_decls_A_const_422 any

var A_arbace_j2g_decls_A_const_423 any

var A_arbace_j2g_decls_A_const_424 any

var A_arbace_j2g_decls_A_const_425 any

var A_arbace_j2g_decls_A_const_426 any

var A_arbace_j2g_decls_A_const_427 any

var A_arbace_j2g_decls_A_const_428 any

var A_arbace_j2g_decls_A_const_429 any

var A_arbace_j2g_decls_A_const_430 any

var A_arbace_j2g_decls_A_const_431 any

var A_arbace_j2g_decls_A_const_432 any

var A_arbace_j2g_decls_A_const_433 any

var A_arbace_j2g_decls_A_const_434 any

var A_arbace_j2g_decls_A_const_435 any

var A_arbace_j2g_decls_A_const_436 any

var A_arbace_j2g_decls_A_const_437 any

var A_arbace_j2g_decls_A_const_438 any

var A_arbace_j2g_decls_A_const_439 any

var A_arbace_j2g_decls_A_const_440 any

var A_arbace_j2g_decls_A_const_441 any

var A_arbace_j2g_decls_A_const_442 any

var A_arbace_j2g_decls_A_const_443 any

var A_arbace_j2g_decls_A_const_444 any

var A_arbace_j2g_decls_A_const_445 any

var A_arbace_j2g_decls_A_const_446 any

var A_arbace_j2g_decls_A_const_447 any

var A_arbace_j2g_decls_A_const_448 any

var A_arbace_j2g_decls_A_const_449 any

var A_arbace_j2g_decls_A_const_450 any

var A_arbace_j2g_decls_A_const_451 *lang.Var

var A_arbace_j2g_decls_A_const_452 any

var A_arbace_j2g_decls_A_const_453 any

var A_arbace_j2g_decls_A_const_454 any

var A_arbace_j2g_decls_A_const_455 any

var A_arbace_j2g_decls_A_const_456 *lang.Var

var A_arbace_j2g_decls_A_const_457 any

var A_arbace_j2g_decls_A_const_458 *lang.Var

var A_arbace_j2g_decls_A_const_459 *lang.Var

var A_arbace_j2g_decls_A_const_460 *lang.Var

var A_arbace_j2g_decls_A_const_461 *lang.Var

var A_arbace_j2g_decls_A_const_462 *lang.Var

var A_arbace_j2g_decls_A_const_463 *lang.Var

var A_arbace_j2g_decls_A_const_464 *lang.Var

var A_arbace_j2g_decls_A_const_465 *lang.Var

var A_arbace_j2g_decls_A_const_466 *lang.Var

var A_arbace_j2g_decls_A_const_467 *lang.Var

var A_arbace_j2g_decls_A_const_468 any

var A_arbace_j2g_decls_A_const_469 *lang.Var

var A_arbace_j2g_decls_A_const_470 any

var A_arbace_j2g_decls_A_const_471 any

var A_arbace_j2g_decls_A_const_472 any

var A_arbace_j2g_decls_A_const_473 *lang.Keyword

var A_arbace_j2g_decls_A_const_474 any

var A_arbace_j2g_decls_A_const_475 any

var A_arbace_j2g_decls_A_const_476 any

var A_arbace_j2g_decls_A_const_477 *lang.Var

var A_arbace_j2g_decls_A_const_478 any

var A_arbace_j2g_decls_A_const_479 any

var A_arbace_j2g_decls_A_const_480 *lang.Var

var A_arbace_j2g_decls_A_const_481 *lang.Var

var A_arbace_j2g_decls_A_const_482 *lang.Var

var A_arbace_j2g_decls_A_const_483 *lang.Var

var A_arbace_j2g_decls_A_const_484 any

var A_arbace_j2g_decls_A_const_485 *lang.Var

var A_arbace_j2g_decls_A_const_486 *lang.Var

var A_arbace_j2g_decls_A_const_487 *lang.Var

var A_arbace_j2g_decls_A_const_488 *lang.Var

var A_arbace_j2g_decls_A_const_489 *lang.Var

var A_arbace_j2g_decls_A_const_490 *lang.Keyword

var A_arbace_j2g_decls_A_const_491 *lang.Keyword

var A_arbace_j2g_decls_A_const_492 *lang.Var

var A_arbace_j2g_decls_A_const_493 *lang.Var

var A_arbace_j2g_decls_A_const_494 any

var A_arbace_j2g_decls_A_const_495 *lang.Var

var A_arbace_j2g_decls_A_const_496 *lang.Keyword

var A_arbace_j2g_decls_A_const_497 *lang.Keyword

var A_arbace_j2g_decls_A_const_498 *lang.Keyword

var A_arbace_j2g_decls_A_const_499 *lang.Keyword

var A_arbace_j2g_decls_A_const_500 *lang.Keyword

var A_arbace_j2g_decls_A_const_501 *lang.Var

var A_arbace_j2g_decls_A_const_502 *lang.Keyword

var A_arbace_j2g_decls_A_const_503 *lang.Keyword

var A_arbace_j2g_decls_A_const_504 *lang.Keyword

var A_arbace_j2g_decls_A_const_505 *lang.Keyword

var A_arbace_j2g_decls_A_const_506 *lang.Keyword

var A_arbace_j2g_decls_A_const_507 any

var A_arbace_j2g_decls_A_const_508 *lang.Keyword

var A_arbace_j2g_decls_A_const_509 *lang.Var

var A_arbace_j2g_decls_A_const_510 *lang.Keyword

var A_arbace_j2g_decls_A_const_511 *lang.Var

var A_arbace_j2g_decls_A_const_512 any

var A_arbace_j2g_decls_A_const_513 any

var A_arbace_j2g_decls_A_const_514 any

var A_arbace_j2g_decls_A_const_515 any

var A_arbace_j2g_decls_A_const_516 any

var A_arbace_j2g_decls_A_const_517 any

var A_arbace_j2g_decls_A_const_518 any

var A_arbace_j2g_decls_A_const_519 any

var A_arbace_j2g_decls_A_const_520 any

var A_arbace_j2g_decls_A_const_521 any

var A_arbace_j2g_decls_A_const_522 any

var A_arbace_j2g_decls_A_const_523 any

var A_arbace_j2g_decls_A_const_524 any

var A_arbace_j2g_decls_A_const_525 any

var A_arbace_j2g_decls_A_const_526 any

var A_arbace_j2g_decls_A_const_527 any

var A_arbace_j2g_decls_A_const_528 any

var A_arbace_j2g_decls_A_const_529 any

var A_arbace_j2g_decls_A_const_530 any

var A_arbace_j2g_decls_A_const_531 any

var A_arbace_j2g_decls_A_const_532 any

var A_arbace_j2g_decls_A_const_533 any

var A_arbace_j2g_decls_A_const_534 any

var A_arbace_j2g_decls_A_const_535 any

var A_arbace_j2g_decls_A_const_536 any

var A_arbace_j2g_decls_A_const_537 any

var A_arbace_j2g_decls_A_const_538 *lang.Var

var A_arbace_j2g_decls_A_const_539 any

var A_arbace_j2g_decls_A_const_540 any

var A_arbace_j2g_decls_A_const_541 any

var A_arbace_j2g_decls_A_const_542 any

var A_arbace_j2g_decls_A_const_543 any

var A_arbace_j2g_decls_A_const_544 any

var A_arbace_j2g_decls_A_const_545 any

var A_arbace_j2g_decls_A_const_546 any

var A_arbace_j2g_decls_A_const_547 any

var A_arbace_j2g_decls_A_const_548 any

var A_arbace_j2g_decls_A_const_549 any

var A_arbace_j2g_decls_A_const_550 any

var A_arbace_j2g_decls_A_const_551 any

var A_arbace_j2g_decls_A_const_552 any

var A_arbace_j2g_decls_A_const_553 any

var A_arbace_j2g_decls_A_const_554 any

var A_arbace_j2g_decls_A_const_555 any

var A_arbace_j2g_decls_A_const_556 any

var A_arbace_j2g_decls_A_const_557 any

var A_arbace_j2g_decls_A_const_558 any

var A_arbace_j2g_decls_A_const_559 any

var A_arbace_j2g_decls_A_const_560 any

var A_arbace_j2g_decls_A_const_561 any

var A_arbace_j2g_decls_A_const_562 any

var A_arbace_j2g_decls_A_const_563 any

var A_arbace_j2g_decls_A_const_564 any

var A_arbace_j2g_decls_A_const_565 any

var A_arbace_j2g_decls_A_const_566 any

var A_arbace_j2g_decls_A_const_567 any

var A_arbace_j2g_decls_A_const_568 any

var A_arbace_j2g_decls_A_const_569 any

var A_arbace_j2g_decls_A_const_570 any

var A_arbace_j2g_decls_A_const_571 any

var A_arbace_j2g_decls_A_const_572 any

var A_arbace_j2g_decls_A_const_573 any

var A_arbace_j2g_decls_A_const_574 any

var A_arbace_j2g_decls_A_const_575 any

var A_arbace_j2g_decls_A_const_576 any

var A_arbace_j2g_decls_A_const_577 any

var A_arbace_j2g_decls_A_const_578 any

var A_arbace_j2g_decls_A_const_579 any

var A_arbace_j2g_decls_A_const_580 any

var A_arbace_j2g_decls_A_const_581 any

var A_arbace_j2g_decls_A_const_582 any

var A_arbace_j2g_decls_A_const_583 any

var A_arbace_j2g_decls_A_const_584 any

var A_arbace_j2g_decls_A_const_585 any

var A_arbace_j2g_decls_A_const_586 any

var A_arbace_j2g_decls_A_const_587 any

var A_arbace_j2g_decls_A_const_588 any

var A_arbace_j2g_decls_A_const_589 any

var A_arbace_j2g_decls_A_const_590 any

var A_arbace_j2g_decls_A_const_591 any

var A_arbace_j2g_decls_A_const_592 any

var A_arbace_j2g_decls_A_const_593 any

var A_arbace_j2g_decls_A_const_594 any

var A_arbace_j2g_decls_A_const_595 any

var A_arbace_j2g_decls_A_const_596 any

var A_arbace_j2g_decls_A_const_597 any

var A_arbace_j2g_decls_A_const_598 any

var A_arbace_j2g_decls_A_const_599 any

var A_arbace_j2g_decls_A_const_600 any

var A_arbace_j2g_decls_A_const_601 any

var A_arbace_j2g_decls_A_const_602 any

var A_arbace_j2g_decls_A_const_603 any

var A_arbace_j2g_decls_A_const_604 any

var A_arbace_j2g_decls_A_const_605 any

var A_arbace_j2g_decls_A_const_606 any

var A_arbace_j2g_decls_A_const_607 any

var A_arbace_j2g_decls_A_const_608 any

var A_arbace_j2g_decls_A_const_609 any

var A_arbace_j2g_decls_A_const_610 any

var A_arbace_j2g_decls_A_const_611 any

var A_arbace_j2g_decls_A_const_612 any

var A_arbace_j2g_decls_A_const_613 any

var A_arbace_j2g_decls_A_const_614 any

var A_arbace_j2g_decls_A_const_615 any

var A_arbace_j2g_decls_A_const_616 any

var A_arbace_j2g_decls_A_const_617 any

var A_arbace_j2g_decls_A_const_618 any

var A_arbace_j2g_decls_A_const_619 any

var A_arbace_j2g_decls_A_const_620 any

var A_arbace_j2g_decls_A_const_621 any

var A_arbace_j2g_decls_A_const_622 any

var A_arbace_j2g_decls_A_const_623 any

var A_arbace_j2g_decls_A_const_624 *lang.Var

var A_arbace_j2g_decls_A_const_625 *lang.Var

var A_arbace_j2g_decls_A_const_626 *lang.Var

var A_arbace_j2g_decls_A_const_627 any

var A_arbace_j2g_decls_A_const_628 any

var A_arbace_j2g_decls_A_const_629 *lang.Var

var A_arbace_j2g_decls_A_const_630 any

var A_arbace_j2g_decls_A_const_631 any

var A_arbace_j2g_decls_A_const_632 any

var A_arbace_j2g_decls_A_const_633 *lang.Var

var A_arbace_j2g_decls_A_const_634 *lang.Var

var A_arbace_j2g_decls_A_const_635 *lang.Var

var A_arbace_j2g_decls_A_const_636 *lang.Var

var A_arbace_j2g_decls_A_const_637 *lang.Var

var A_arbace_j2g_decls_A_const_638 any

var A_arbace_j2g_decls_A_const_639 any

var A_arbace_j2g_decls_A_const_640 any

var A_arbace_j2g_decls_A_const_641 *lang.Var

var A_arbace_j2g_decls_A_const_642 any

var A_arbace_j2g_decls_A_const_643 any

var A_arbace_j2g_decls_A_const_644 any

var A_arbace_j2g_decls_A_const_645 any

var A_arbace_j2g_decls_A_const_646 any

var A_arbace_j2g_decls_A_const_647 *lang.Var

var A_arbace_j2g_decls_A_const_648 any

var A_arbace_j2g_decls_A_const_649 any

var A_arbace_j2g_decls_A_const_650 *lang.Var

var A_arbace_j2g_decls_A_const_651 any

var A_arbace_j2g_decls_A_const_652 any

var A_arbace_j2g_decls_A_const_653 *lang.Var

var A_arbace_j2g_decls_A_const_654 *lang.Var

var A_arbace_j2g_decls_A_const_655 any

var A_arbace_j2g_decls_A_const_656 any

var A_arbace_j2g_decls_A_const_657 any

var A_arbace_j2g_decls_A_const_658 any

var A_arbace_j2g_decls_A_const_659 any

var A_arbace_j2g_decls_A_const_660 any

var A_arbace_j2g_decls_A_const_661 *lang.Var

var A_arbace_j2g_decls_A_const_662 *lang.Var

var A_arbace_j2g_decls_A_const_663 *lang.Var

var A_arbace_j2g_decls_A_const_664 *lang.Var

var A_arbace_j2g_decls_A_const_665 *lang.Var

var A_arbace_j2g_decls_A_init jrt.ClassInit

func A_arbace_j2g_decls_A_Init() { if !A_arbace_j2g_decls_A_init.Done() { A_arbace_j2g_decls_A_init.Run(A_arbace_j2g_decls_A_clinit) } }

func A_arbace_j2g_decls_A_clinit() { A_arbace_j2g_decls_A_clinit_p0(); A_arbace_j2g_decls_A_clinit_p1(); A_arbace_j2g_decls_A_clinit_p2(); A_arbace_j2g_decls_A_clinit_p3(); A_arbace_j2g_decls_A_clinit_p4(); A_arbace_j2g_decls_A_clinit_p5(); A_arbace_j2g_decls_A_clinit_p6(); A_arbace_j2g_decls_A_clinit_p7(); A_arbace_j2g_decls_A_clinit_p8(); A_arbace_j2g_decls_A_clinit_p9(); A_arbace_j2g_decls_A_clinit_p10(); A_arbace_j2g_decls_A_clinit_p11(); A_arbace_j2g_decls_A_clinit_p12(); A_arbace_j2g_decls_A_clinit_p13(); A_arbace_j2g_decls_A_clinit_p14(); A_arbace_j2g_decls_A_clinit_p15(); A_arbace_j2g_decls_A_clinit_p16(); A_arbace_j2g_decls_A_clinit_p17(); A_arbace_j2g_decls_A_clinit_p18(); A_arbace_j2g_decls_A_clinit_p19(); A_arbace_j2g_decls_A_clinit_p20(); A_arbace_j2g_decls_A_clinit_p21(); A_arbace_j2g_decls_A_clinit_p22(); A_arbace_j2g_decls_A_clinit_p23(); A_arbace_j2g_decls_A_clinit_p24(); A_arbace_j2g_decls_A_clinit_p25(); A_arbace_j2g_decls_A_clinit_p26(); A_arbace_j2g_decls_A_clinit_p27(); A_arbace_j2g_decls_A_clinit_p28(); A_arbace_j2g_decls_A_clinit_p29(); A_arbace_j2g_decls_A_clinit_p30(); A_arbace_j2g_decls_A_clinit_p31(); A_arbace_j2g_decls_A_clinit_p32(); A_arbace_j2g_decls_A_clinit_p33(); A_arbace_j2g_decls_A_clinit_p34(); A_arbace_j2g_decls_A_clinit_p35(); A_arbace_j2g_decls_A_clinit_p36(); A_arbace_j2g_decls_A_clinit_p37(); A_arbace_j2g_decls_A_clinit_p38(); A_arbace_j2g_decls_A_clinit_p39(); A_arbace_j2g_decls_A_clinit_p40(); A_arbace_j2g_decls_A_clinit_p41(); A_arbace_j2g_decls_A_clinit_p42(); A_arbace_j2g_decls_A_clinit_p43(); A_arbace_j2g_decls_A_clinit_p44(); A_arbace_j2g_decls_A_clinit_p45(); A_arbace_j2g_decls_A_clinit_p46(); A_arbace_j2g_decls_A_clinit_p47(); A_arbace_j2g_decls_A_clinit_p48(); A_arbace_j2g_decls_A_clinit_p49() }

func A_arbace_j2g_decls_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_decls_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 868); A_arbace_j2g_decls_A_const_0 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[202]); A_arbace_j2g_decls_A_const_1 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[203]); A_arbace_j2g_decls_A_const_2 = A_arbace_j2g_decls_A_const_pool.A[204]; A_arbace_j2g_decls_A_const_3 = A_arbace_j2g_decls_A_const_pool.A[205]; A_arbace_j2g_decls_A_const_4 = A_arbace_j2g_decls_A_const_pool.A[206]; A_arbace_j2g_decls_A_const_5 = A_arbace_j2g_decls_A_const_pool.A[207]; A_arbace_j2g_decls_A_const_6 = A_arbace_j2g_decls_A_const_pool.A[208]; A_arbace_j2g_decls_A_const_7 = A_arbace_j2g_decls_A_const_pool.A[209]; A_arbace_j2g_decls_A_const_8 = A_arbace_j2g_decls_A_const_pool.A[210]; A_arbace_j2g_decls_A_const_9 = A_arbace_j2g_decls_A_const_pool.A[211]; A_arbace_j2g_decls_A_const_10 = A_arbace_j2g_decls_A_const_pool.A[212]; A_arbace_j2g_decls_A_const_11 = A_arbace_j2g_decls_A_const_pool.A[213]; A_arbace_j2g_decls_A_const_12 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[214]) }

func A_arbace_j2g_decls_A_clinit_p1() { A_arbace_j2g_decls_A_const_13 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[215]); A_arbace_j2g_decls_A_const_14 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[216]); A_arbace_j2g_decls_A_const_15 = A_arbace_j2g_decls_A_const_pool.A[217]; A_arbace_j2g_decls_A_const_16 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[218]); A_arbace_j2g_decls_A_const_17 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[219]); A_arbace_j2g_decls_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[220]); A_arbace_j2g_decls_A_const_19 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[221]); A_arbace_j2g_decls_A_const_20 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[222]); A_arbace_j2g_decls_A_const_21 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[223]); A_arbace_j2g_decls_A_const_22 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[224]); A_arbace_j2g_decls_A_const_23 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[225]); A_arbace_j2g_decls_A_const_24 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[226]) }

func A_arbace_j2g_decls_A_clinit_p2() { A_arbace_j2g_decls_A_const_25 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[227]); A_arbace_j2g_decls_A_const_26 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[228]); A_arbace_j2g_decls_A_const_27 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[229]); A_arbace_j2g_decls_A_const_28 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[230]); A_arbace_j2g_decls_A_const_29 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[231]); A_arbace_j2g_decls_A_const_30 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[232]); A_arbace_j2g_decls_A_const_31 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[233]); A_arbace_j2g_decls_A_const_32 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[234]); A_arbace_j2g_decls_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[235]); A_arbace_j2g_decls_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[236]); A_arbace_j2g_decls_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[237]); A_arbace_j2g_decls_A_const_36 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[238]) }

func A_arbace_j2g_decls_A_clinit_p3() { A_arbace_j2g_decls_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[239]); A_arbace_j2g_decls_A_const_38 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[240]); A_arbace_j2g_decls_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[241]); A_arbace_j2g_decls_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[242]); A_arbace_j2g_decls_A_const_41 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[243]); A_arbace_j2g_decls_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[244]); A_arbace_j2g_decls_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[245]); A_arbace_j2g_decls_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[246]); A_arbace_j2g_decls_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[247]); A_arbace_j2g_decls_A_const_46 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[248]); A_arbace_j2g_decls_A_const_47 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[249]); A_arbace_j2g_decls_A_const_48 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[250]) }

func A_arbace_j2g_decls_A_clinit_p4() { A_arbace_j2g_decls_A_const_49 = A_arbace_j2g_decls_A_const_pool.A[251]; A_arbace_j2g_decls_A_const_50 = A_arbace_j2g_decls_A_const_pool.A[252]; A_arbace_j2g_decls_A_const_51 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[253]); A_arbace_j2g_decls_A_const_52 = A_arbace_j2g_decls_A_const_pool.A[254]; A_arbace_j2g_decls_A_const_53 = A_arbace_j2g_decls_A_const_pool.A[255]; A_arbace_j2g_decls_A_const_54 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[256]); A_arbace_j2g_decls_A_const_55 = A_arbace_j2g_decls_A_const_pool.A[257]; A_arbace_j2g_decls_A_const_56 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[258]); A_arbace_j2g_decls_A_const_57 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[259]); A_arbace_j2g_decls_A_const_58 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[260]); A_arbace_j2g_decls_A_const_59 = A_arbace_j2g_decls_A_const_pool.A[261]; A_arbace_j2g_decls_A_const_60 = A_arbace_j2g_decls_A_const_pool.A[262]; A_arbace_j2g_decls_A_const_61 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[263]) }

func A_arbace_j2g_decls_A_clinit_p5() { A_arbace_j2g_decls_A_const_62 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[264]); A_arbace_j2g_decls_A_const_63 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[265]); A_arbace_j2g_decls_A_const_64 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[266]); A_arbace_j2g_decls_A_const_65 = A_arbace_j2g_decls_A_const_pool.A[267]; A_arbace_j2g_decls_A_const_66 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[268]); A_arbace_j2g_decls_A_const_67 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[269]); A_arbace_j2g_decls_A_const_68 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[270]); A_arbace_j2g_decls_A_const_69 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[271]); A_arbace_j2g_decls_A_const_70 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[272]); A_arbace_j2g_decls_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[273]); A_arbace_j2g_decls_A_const_72 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[274]); A_arbace_j2g_decls_A_const_73 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[275]) }

func A_arbace_j2g_decls_A_clinit_p6() { A_arbace_j2g_decls_A_const_74 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[276]); A_arbace_j2g_decls_A_const_75 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[277]); A_arbace_j2g_decls_A_const_76 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[278]); A_arbace_j2g_decls_A_const_77 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[279]); A_arbace_j2g_decls_A_const_78 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[280]); A_arbace_j2g_decls_A_const_79 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[281]); A_arbace_j2g_decls_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[282]); A_arbace_j2g_decls_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[283]); A_arbace_j2g_decls_A_const_82 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[284]); A_arbace_j2g_decls_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[285]); A_arbace_j2g_decls_A_const_84 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[286]); A_arbace_j2g_decls_A_const_85 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[287]) }

func A_arbace_j2g_decls_A_clinit_p7() { A_arbace_j2g_decls_A_const_86 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[288]); A_arbace_j2g_decls_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[289]); A_arbace_j2g_decls_A_const_88 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[290]); A_arbace_j2g_decls_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[291]); A_arbace_j2g_decls_A_const_90 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[292]); A_arbace_j2g_decls_A_const_91 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[293]); A_arbace_j2g_decls_A_const_92 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[294]); A_arbace_j2g_decls_A_const_93 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[295]); A_arbace_j2g_decls_A_const_94 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[296]); A_arbace_j2g_decls_A_const_95 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[297]); A_arbace_j2g_decls_A_const_96 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[298]); A_arbace_j2g_decls_A_const_97 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[299]) }

func A_arbace_j2g_decls_A_clinit_p8() { A_arbace_j2g_decls_A_const_98 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[300]); A_arbace_j2g_decls_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[301]); A_arbace_j2g_decls_A_const_100 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[302]); A_arbace_j2g_decls_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[303]); A_arbace_j2g_decls_A_const_102 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[304]); A_arbace_j2g_decls_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[305]); A_arbace_j2g_decls_A_const_104 = A_arbace_j2g_decls_A_const_pool.A[306]; A_arbace_j2g_decls_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[307]); A_arbace_j2g_decls_A_const_106 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[308]); A_arbace_j2g_decls_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[309]); A_arbace_j2g_decls_A_const_108 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[310]); A_arbace_j2g_decls_A_const_109 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[311]) }

func A_arbace_j2g_decls_A_clinit_p9() { A_arbace_j2g_decls_A_const_110 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[312]); A_arbace_j2g_decls_A_const_111 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[313]); A_arbace_j2g_decls_A_const_112 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[314]); A_arbace_j2g_decls_A_const_113 = A_arbace_j2g_decls_A_const_pool.A[315]; A_arbace_j2g_decls_A_const_114 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[316]); A_arbace_j2g_decls_A_const_115 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[317]); A_arbace_j2g_decls_A_const_116 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[318]); A_arbace_j2g_decls_A_const_117 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[319]); A_arbace_j2g_decls_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[320]); A_arbace_j2g_decls_A_const_119 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[321]); A_arbace_j2g_decls_A_const_120 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[322]); A_arbace_j2g_decls_A_const_121 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[323]) }

func A_arbace_j2g_decls_A_clinit_p10() { A_arbace_j2g_decls_A_const_122 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[324]); A_arbace_j2g_decls_A_const_123 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[325]); A_arbace_j2g_decls_A_const_124 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[326]); A_arbace_j2g_decls_A_const_125 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[327]); A_arbace_j2g_decls_A_const_126 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[328]); A_arbace_j2g_decls_A_const_127 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[329]); A_arbace_j2g_decls_A_const_128 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[330]); A_arbace_j2g_decls_A_const_129 = A_arbace_j2g_decls_A_const_pool.A[331]; A_arbace_j2g_decls_A_const_130 = A_arbace_j2g_decls_A_const_pool.A[332]; A_arbace_j2g_decls_A_const_131 = A_arbace_j2g_decls_A_const_pool.A[333]; A_arbace_j2g_decls_A_const_132 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[334]); A_arbace_j2g_decls_A_const_133 = A_arbace_j2g_decls_A_const_pool.A[335]; A_arbace_j2g_decls_A_const_134 = A_arbace_j2g_decls_A_const_pool.A[336] }

func A_arbace_j2g_decls_A_clinit_p11() { A_arbace_j2g_decls_A_const_135 = A_arbace_j2g_decls_A_const_pool.A[337]; A_arbace_j2g_decls_A_const_136 = A_arbace_j2g_decls_A_const_pool.A[338]; A_arbace_j2g_decls_A_const_137 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[339]); A_arbace_j2g_decls_A_const_138 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[340]); A_arbace_j2g_decls_A_const_139 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[341]); A_arbace_j2g_decls_A_const_140 = A_arbace_j2g_decls_A_const_pool.A[342]; A_arbace_j2g_decls_A_const_141 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[343]); A_arbace_j2g_decls_A_const_142 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[344]); A_arbace_j2g_decls_A_const_143 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[345]); A_arbace_j2g_decls_A_const_144 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[346]); A_arbace_j2g_decls_A_const_145 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[347]); A_arbace_j2g_decls_A_const_146 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[348]) }

func A_arbace_j2g_decls_A_clinit_p12() { A_arbace_j2g_decls_A_const_147 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[349]); A_arbace_j2g_decls_A_const_148 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[350]); A_arbace_j2g_decls_A_const_149 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[351]); A_arbace_j2g_decls_A_const_150 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[352]); A_arbace_j2g_decls_A_const_151 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[353]); A_arbace_j2g_decls_A_const_152 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[354]); A_arbace_j2g_decls_A_const_153 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[355]); A_arbace_j2g_decls_A_const_154 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[356]); A_arbace_j2g_decls_A_const_155 = A_arbace_j2g_decls_A_const_pool.A[357]; A_arbace_j2g_decls_A_const_156 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[358]); A_arbace_j2g_decls_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[359]); A_arbace_j2g_decls_A_const_158 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[360]) }

func A_arbace_j2g_decls_A_clinit_p13() { A_arbace_j2g_decls_A_const_159 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[361]); A_arbace_j2g_decls_A_const_160 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[362]); A_arbace_j2g_decls_A_const_161 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[363]); A_arbace_j2g_decls_A_const_162 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[364]); A_arbace_j2g_decls_A_const_163 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[365]); A_arbace_j2g_decls_A_const_164 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[366]); A_arbace_j2g_decls_A_const_165 = A_arbace_j2g_decls_A_const_pool.A[367]; A_arbace_j2g_decls_A_const_166 = A_arbace_j2g_decls_A_const_pool.A[368]; A_arbace_j2g_decls_A_const_167 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[369]); A_arbace_j2g_decls_A_const_168 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[370]); A_arbace_j2g_decls_A_const_169 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[371]); A_arbace_j2g_decls_A_const_170 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[372]) }

func A_arbace_j2g_decls_A_clinit_p14() { A_arbace_j2g_decls_A_const_171 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[373]); A_arbace_j2g_decls_A_const_172 = A_arbace_j2g_decls_A_const_pool.A[374]; A_arbace_j2g_decls_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[375]); A_arbace_j2g_decls_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[376]); A_arbace_j2g_decls_A_const_175 = A_arbace_j2g_decls_A_const_pool.A[377]; A_arbace_j2g_decls_A_const_176 = A_arbace_j2g_decls_A_const_pool.A[378]; A_arbace_j2g_decls_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[379]); A_arbace_j2g_decls_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[380]); A_arbace_j2g_decls_A_const_179 = A_arbace_j2g_decls_A_const_pool.A[381]; A_arbace_j2g_decls_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[382]); A_arbace_j2g_decls_A_const_181 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[383]); A_arbace_j2g_decls_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[384]); A_arbace_j2g_decls_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[385]) }

func A_arbace_j2g_decls_A_clinit_p15() { A_arbace_j2g_decls_A_const_184 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[386]); A_arbace_j2g_decls_A_const_185 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[387]); A_arbace_j2g_decls_A_const_186 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[388]); A_arbace_j2g_decls_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[389]); A_arbace_j2g_decls_A_const_188 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[390]); A_arbace_j2g_decls_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[391]); A_arbace_j2g_decls_A_const_190 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[392]); A_arbace_j2g_decls_A_const_191 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[393]); A_arbace_j2g_decls_A_const_192 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[394]); A_arbace_j2g_decls_A_const_193 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[395]); A_arbace_j2g_decls_A_const_194 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[396]); A_arbace_j2g_decls_A_const_195 = A_arbace_j2g_decls_A_const_pool.A[397] }

func A_arbace_j2g_decls_A_clinit_p16() { A_arbace_j2g_decls_A_const_196 = A_arbace_j2g_decls_A_const_pool.A[398]; A_arbace_j2g_decls_A_const_197 = A_arbace_j2g_decls_A_const_pool.A[399]; A_arbace_j2g_decls_A_const_198 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[400]); A_arbace_j2g_decls_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[401]); A_arbace_j2g_decls_A_const_200 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[402]); A_arbace_j2g_decls_A_const_201 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[403]); A_arbace_j2g_decls_A_const_202 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[404]); A_arbace_j2g_decls_A_const_203 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[405]); A_arbace_j2g_decls_A_const_204 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[406]); A_arbace_j2g_decls_A_const_205 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[407]); A_arbace_j2g_decls_A_const_206 = A_arbace_j2g_decls_A_const_pool.A[408]; A_arbace_j2g_decls_A_const_207 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[409]) }

func A_arbace_j2g_decls_A_clinit_p17() { A_arbace_j2g_decls_A_const_208 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[410]); A_arbace_j2g_decls_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[411]); A_arbace_j2g_decls_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[412]); A_arbace_j2g_decls_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[413]); A_arbace_j2g_decls_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[414]); A_arbace_j2g_decls_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[415]); A_arbace_j2g_decls_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[416]); A_arbace_j2g_decls_A_const_215 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[417]); A_arbace_j2g_decls_A_const_216 = A_arbace_j2g_decls_A_const_pool.A[418]; A_arbace_j2g_decls_A_const_217 = A_arbace_j2g_decls_A_const_pool.A[419]; A_arbace_j2g_decls_A_const_218 = A_arbace_j2g_decls_A_const_pool.A[420]; A_arbace_j2g_decls_A_const_219 = A_arbace_j2g_decls_A_const_pool.A[421]; A_arbace_j2g_decls_A_const_220 = A_arbace_j2g_decls_A_const_pool.A[422] }

func A_arbace_j2g_decls_A_clinit_p18() { A_arbace_j2g_decls_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[423]); A_arbace_j2g_decls_A_const_222 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[424]); A_arbace_j2g_decls_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[425]); A_arbace_j2g_decls_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[426]); A_arbace_j2g_decls_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[427]); A_arbace_j2g_decls_A_const_226 = A_arbace_j2g_decls_A_const_pool.A[428]; A_arbace_j2g_decls_A_const_227 = A_arbace_j2g_decls_A_const_pool.A[429]; A_arbace_j2g_decls_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[430]); A_arbace_j2g_decls_A_const_229 = A_arbace_j2g_decls_A_const_pool.A[431]; A_arbace_j2g_decls_A_const_230 = A_arbace_j2g_decls_A_const_pool.A[432]; A_arbace_j2g_decls_A_const_231 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[433]); A_arbace_j2g_decls_A_const_232 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[434]); A_arbace_j2g_decls_A_const_233 = A_arbace_j2g_decls_A_const_pool.A[435] }

func A_arbace_j2g_decls_A_clinit_p19() { A_arbace_j2g_decls_A_const_234 = A_arbace_j2g_decls_A_const_pool.A[436]; A_arbace_j2g_decls_A_const_235 = A_arbace_j2g_decls_A_const_pool.A[437]; A_arbace_j2g_decls_A_const_236 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[438]); A_arbace_j2g_decls_A_const_237 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[439]); A_arbace_j2g_decls_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[440]); A_arbace_j2g_decls_A_const_239 = A_arbace_j2g_decls_A_const_pool.A[441]; A_arbace_j2g_decls_A_const_240 = A_arbace_j2g_decls_A_const_pool.A[442]; A_arbace_j2g_decls_A_const_241 = A_arbace_j2g_decls_A_const_pool.A[443]; A_arbace_j2g_decls_A_const_242 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[444]); A_arbace_j2g_decls_A_const_243 = A_arbace_j2g_decls_A_const_pool.A[445]; A_arbace_j2g_decls_A_const_244 = A_arbace_j2g_decls_A_const_pool.A[446]; A_arbace_j2g_decls_A_const_245 = A_arbace_j2g_decls_A_const_pool.A[447]; A_arbace_j2g_decls_A_const_246 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[448]); A_arbace_j2g_decls_A_const_247 = A_arbace_j2g_decls_A_const_pool.A[449] }

func A_arbace_j2g_decls_A_clinit_p20() { A_arbace_j2g_decls_A_const_248 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[450]); A_arbace_j2g_decls_A_const_249 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[451]); A_arbace_j2g_decls_A_const_250 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[452]); A_arbace_j2g_decls_A_const_251 = A_arbace_j2g_decls_A_const_pool.A[453]; A_arbace_j2g_decls_A_const_252 = A_arbace_j2g_decls_A_const_pool.A[454]; A_arbace_j2g_decls_A_const_253 = A_arbace_j2g_decls_A_const_pool.A[455]; A_arbace_j2g_decls_A_const_254 = A_arbace_j2g_decls_A_const_pool.A[456]; A_arbace_j2g_decls_A_const_255 = A_arbace_j2g_decls_A_const_pool.A[457]; A_arbace_j2g_decls_A_const_256 = A_arbace_j2g_decls_A_const_pool.A[458]; A_arbace_j2g_decls_A_const_257 = A_arbace_j2g_decls_A_const_pool.A[459]; A_arbace_j2g_decls_A_const_258 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[460]); A_arbace_j2g_decls_A_const_259 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[461]); A_arbace_j2g_decls_A_const_260 = A_arbace_j2g_decls_A_const_pool.A[462]; A_arbace_j2g_decls_A_const_261 = A_arbace_j2g_decls_A_const_pool.A[463] }

func A_arbace_j2g_decls_A_clinit_p21() { A_arbace_j2g_decls_A_const_262 = A_arbace_j2g_decls_A_const_pool.A[464]; A_arbace_j2g_decls_A_const_263 = A_arbace_j2g_decls_A_const_pool.A[465]; A_arbace_j2g_decls_A_const_264 = A_arbace_j2g_decls_A_const_pool.A[466]; A_arbace_j2g_decls_A_const_265 = A_arbace_j2g_decls_A_const_pool.A[467]; A_arbace_j2g_decls_A_const_266 = A_arbace_j2g_decls_A_const_pool.A[468]; A_arbace_j2g_decls_A_const_267 = A_arbace_j2g_decls_A_const_pool.A[469]; A_arbace_j2g_decls_A_const_268 = A_arbace_j2g_decls_A_const_pool.A[470]; A_arbace_j2g_decls_A_const_269 = A_arbace_j2g_decls_A_const_pool.A[471]; A_arbace_j2g_decls_A_const_270 = A_arbace_j2g_decls_A_const_pool.A[472]; A_arbace_j2g_decls_A_const_271 = A_arbace_j2g_decls_A_const_pool.A[473]; A_arbace_j2g_decls_A_const_272 = A_arbace_j2g_decls_A_const_pool.A[474]; A_arbace_j2g_decls_A_const_273 = A_arbace_j2g_decls_A_const_pool.A[475]; A_arbace_j2g_decls_A_const_274 = A_arbace_j2g_decls_A_const_pool.A[476]; A_arbace_j2g_decls_A_const_275 = A_arbace_j2g_decls_A_const_pool.A[477]; A_arbace_j2g_decls_A_const_276 = A_arbace_j2g_decls_A_const_pool.A[478]; A_arbace_j2g_decls_A_const_277 = A_arbace_j2g_decls_A_const_pool.A[479] }

func A_arbace_j2g_decls_A_clinit_p22() { A_arbace_j2g_decls_A_const_278 = A_arbace_j2g_decls_A_const_pool.A[480]; A_arbace_j2g_decls_A_const_279 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[481]); A_arbace_j2g_decls_A_const_280 = A_arbace_j2g_decls_A_const_pool.A[482]; A_arbace_j2g_decls_A_const_281 = A_arbace_j2g_decls_A_const_pool.A[483]; A_arbace_j2g_decls_A_const_282 = A_arbace_j2g_decls_A_const_pool.A[484]; A_arbace_j2g_decls_A_const_283 = A_arbace_j2g_decls_A_const_pool.A[485]; A_arbace_j2g_decls_A_const_284 = A_arbace_j2g_decls_A_const_pool.A[486]; A_arbace_j2g_decls_A_const_285 = A_arbace_j2g_decls_A_const_pool.A[487]; A_arbace_j2g_decls_A_const_286 = A_arbace_j2g_decls_A_const_pool.A[488]; A_arbace_j2g_decls_A_const_287 = A_arbace_j2g_decls_A_const_pool.A[489]; A_arbace_j2g_decls_A_const_288 = A_arbace_j2g_decls_A_const_pool.A[490]; A_arbace_j2g_decls_A_const_289 = A_arbace_j2g_decls_A_const_pool.A[491]; A_arbace_j2g_decls_A_const_290 = A_arbace_j2g_decls_A_const_pool.A[492]; A_arbace_j2g_decls_A_const_291 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[493]); A_arbace_j2g_decls_A_const_292 = A_arbace_j2g_decls_A_const_pool.A[494] }

func A_arbace_j2g_decls_A_clinit_p23() { A_arbace_j2g_decls_A_const_293 = A_arbace_j2g_decls_A_const_pool.A[495]; A_arbace_j2g_decls_A_const_294 = A_arbace_j2g_decls_A_const_pool.A[496]; A_arbace_j2g_decls_A_const_295 = A_arbace_j2g_decls_A_const_pool.A[497]; A_arbace_j2g_decls_A_const_296 = A_arbace_j2g_decls_A_const_pool.A[498]; A_arbace_j2g_decls_A_const_297 = A_arbace_j2g_decls_A_const_pool.A[499]; A_arbace_j2g_decls_A_const_298 = A_arbace_j2g_decls_A_const_pool.A[500]; A_arbace_j2g_decls_A_const_299 = A_arbace_j2g_decls_A_const_pool.A[501]; A_arbace_j2g_decls_A_const_300 = A_arbace_j2g_decls_A_const_pool.A[502]; A_arbace_j2g_decls_A_const_301 = A_arbace_j2g_decls_A_const_pool.A[503]; A_arbace_j2g_decls_A_const_302 = A_arbace_j2g_decls_A_const_pool.A[504]; A_arbace_j2g_decls_A_const_303 = A_arbace_j2g_decls_A_const_pool.A[505]; A_arbace_j2g_decls_A_const_304 = A_arbace_j2g_decls_A_const_pool.A[506]; A_arbace_j2g_decls_A_const_305 = A_arbace_j2g_decls_A_const_pool.A[507]; A_arbace_j2g_decls_A_const_306 = A_arbace_j2g_decls_A_const_pool.A[508]; A_arbace_j2g_decls_A_const_307 = A_arbace_j2g_decls_A_const_pool.A[509]; A_arbace_j2g_decls_A_const_308 = A_arbace_j2g_decls_A_const_pool.A[510] }

func A_arbace_j2g_decls_A_clinit_p24() { A_arbace_j2g_decls_A_const_309 = A_arbace_j2g_decls_A_const_pool.A[511]; A_arbace_j2g_decls_A_const_310 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[512]); A_arbace_j2g_decls_A_const_311 = A_arbace_j2g_decls_A_const_pool.A[513]; A_arbace_j2g_decls_A_const_312 = A_arbace_j2g_decls_A_const_pool.A[514]; A_arbace_j2g_decls_A_const_313 = A_arbace_j2g_decls_A_const_pool.A[515]; A_arbace_j2g_decls_A_const_314 = A_arbace_j2g_decls_A_const_pool.A[516]; A_arbace_j2g_decls_A_const_315 = A_arbace_j2g_decls_A_const_pool.A[517]; A_arbace_j2g_decls_A_const_316 = A_arbace_j2g_decls_A_const_pool.A[518]; A_arbace_j2g_decls_A_const_317 = A_arbace_j2g_decls_A_const_pool.A[519]; A_arbace_j2g_decls_A_const_318 = A_arbace_j2g_decls_A_const_pool.A[520]; A_arbace_j2g_decls_A_const_319 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[521]); A_arbace_j2g_decls_A_const_320 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[522]); A_arbace_j2g_decls_A_const_321 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[523]); A_arbace_j2g_decls_A_const_322 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[524]) }

func A_arbace_j2g_decls_A_clinit_p25() { A_arbace_j2g_decls_A_const_323 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[525]); A_arbace_j2g_decls_A_const_324 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[526]); A_arbace_j2g_decls_A_const_325 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[527]); A_arbace_j2g_decls_A_const_326 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[528]); A_arbace_j2g_decls_A_const_327 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[529]); A_arbace_j2g_decls_A_const_328 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[530]); A_arbace_j2g_decls_A_const_329 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[531]); A_arbace_j2g_decls_A_const_330 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[532]); A_arbace_j2g_decls_A_const_331 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[533]); A_arbace_j2g_decls_A_const_332 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[534]); A_arbace_j2g_decls_A_const_333 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[535]); A_arbace_j2g_decls_A_const_334 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[536]) }

func A_arbace_j2g_decls_A_clinit_p26() { A_arbace_j2g_decls_A_const_335 = A_arbace_j2g_decls_A_const_pool.A[537]; A_arbace_j2g_decls_A_const_336 = A_arbace_j2g_decls_A_const_pool.A[538]; A_arbace_j2g_decls_A_const_337 = A_arbace_j2g_decls_A_const_pool.A[539]; A_arbace_j2g_decls_A_const_338 = A_arbace_j2g_decls_A_const_pool.A[540]; A_arbace_j2g_decls_A_const_339 = A_arbace_j2g_decls_A_const_pool.A[541]; A_arbace_j2g_decls_A_const_340 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[542]); A_arbace_j2g_decls_A_const_341 = A_arbace_j2g_decls_A_const_pool.A[543]; A_arbace_j2g_decls_A_const_342 = A_arbace_j2g_decls_A_const_pool.A[544]; A_arbace_j2g_decls_A_const_343 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[545]); A_arbace_j2g_decls_A_const_344 = A_arbace_j2g_decls_A_const_pool.A[546]; A_arbace_j2g_decls_A_const_345 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[547]); A_arbace_j2g_decls_A_const_346 = A_arbace_j2g_decls_A_const_pool.A[548]; A_arbace_j2g_decls_A_const_347 = A_arbace_j2g_decls_A_const_pool.A[549]; A_arbace_j2g_decls_A_const_348 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[550]) }

func A_arbace_j2g_decls_A_clinit_p27() { A_arbace_j2g_decls_A_const_349 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[551]); A_arbace_j2g_decls_A_const_350 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[552]); A_arbace_j2g_decls_A_const_351 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[553]); A_arbace_j2g_decls_A_const_352 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[554]); A_arbace_j2g_decls_A_const_353 = A_arbace_j2g_decls_A_const_pool.A[555]; A_arbace_j2g_decls_A_const_354 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[556]); A_arbace_j2g_decls_A_const_355 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[557]); A_arbace_j2g_decls_A_const_356 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[558]); A_arbace_j2g_decls_A_const_357 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[559]); A_arbace_j2g_decls_A_const_358 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[560]); A_arbace_j2g_decls_A_const_359 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[561]); A_arbace_j2g_decls_A_const_360 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[562]) }

func A_arbace_j2g_decls_A_clinit_p28() { A_arbace_j2g_decls_A_const_361 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[563]); A_arbace_j2g_decls_A_const_362 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[564]); A_arbace_j2g_decls_A_const_363 = A_arbace_j2g_decls_A_const_pool.A[565]; A_arbace_j2g_decls_A_const_364 = A_arbace_j2g_decls_A_const_pool.A[566]; A_arbace_j2g_decls_A_const_365 = A_arbace_j2g_decls_A_const_pool.A[567]; A_arbace_j2g_decls_A_const_366 = A_arbace_j2g_decls_A_const_pool.A[568]; A_arbace_j2g_decls_A_const_367 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[569]); A_arbace_j2g_decls_A_const_368 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[570]); A_arbace_j2g_decls_A_const_369 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[571]); A_arbace_j2g_decls_A_const_370 = A_arbace_j2g_decls_A_const_pool.A[572]; A_arbace_j2g_decls_A_const_371 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[573]); A_arbace_j2g_decls_A_const_372 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[574]); A_arbace_j2g_decls_A_const_373 = A_arbace_j2g_decls_A_const_pool.A[575] }

func A_arbace_j2g_decls_A_clinit_p29() { A_arbace_j2g_decls_A_const_374 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[576]); A_arbace_j2g_decls_A_const_375 = A_arbace_j2g_decls_A_const_pool.A[577]; A_arbace_j2g_decls_A_const_376 = A_arbace_j2g_decls_A_const_pool.A[578]; A_arbace_j2g_decls_A_const_377 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[579]); A_arbace_j2g_decls_A_const_378 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[580]); A_arbace_j2g_decls_A_const_379 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[581]); A_arbace_j2g_decls_A_const_380 = A_arbace_j2g_decls_A_const_pool.A[582]; A_arbace_j2g_decls_A_const_381 = A_arbace_j2g_decls_A_const_pool.A[583]; A_arbace_j2g_decls_A_const_382 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[584]); A_arbace_j2g_decls_A_const_383 = A_arbace_j2g_decls_A_const_pool.A[585]; A_arbace_j2g_decls_A_const_384 = A_arbace_j2g_decls_A_const_pool.A[586]; A_arbace_j2g_decls_A_const_385 = A_arbace_j2g_decls_A_const_pool.A[587]; A_arbace_j2g_decls_A_const_386 = A_arbace_j2g_decls_A_const_pool.A[588]; A_arbace_j2g_decls_A_const_387 = A_arbace_j2g_decls_A_const_pool.A[589] }

func A_arbace_j2g_decls_A_clinit_p30() { A_arbace_j2g_decls_A_const_388 = A_arbace_j2g_decls_A_const_pool.A[590]; A_arbace_j2g_decls_A_const_389 = A_arbace_j2g_decls_A_const_pool.A[591]; A_arbace_j2g_decls_A_const_390 = A_arbace_j2g_decls_A_const_pool.A[592]; A_arbace_j2g_decls_A_const_391 = A_arbace_j2g_decls_A_const_pool.A[593]; A_arbace_j2g_decls_A_const_392 = A_arbace_j2g_decls_A_const_pool.A[594]; A_arbace_j2g_decls_A_const_393 = A_arbace_j2g_decls_A_const_pool.A[595]; A_arbace_j2g_decls_A_const_394 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[596]); A_arbace_j2g_decls_A_const_395 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[597]); A_arbace_j2g_decls_A_const_396 = A_arbace_j2g_decls_A_const_pool.A[598]; A_arbace_j2g_decls_A_const_397 = A_arbace_j2g_decls_A_const_pool.A[599]; A_arbace_j2g_decls_A_const_398 = A_arbace_j2g_decls_A_const_pool.A[600]; A_arbace_j2g_decls_A_const_399 = A_arbace_j2g_decls_A_const_pool.A[601]; A_arbace_j2g_decls_A_const_400 = A_arbace_j2g_decls_A_const_pool.A[602]; A_arbace_j2g_decls_A_const_401 = A_arbace_j2g_decls_A_const_pool.A[603]; A_arbace_j2g_decls_A_const_402 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[604]) }

func A_arbace_j2g_decls_A_clinit_p31() { A_arbace_j2g_decls_A_const_403 = A_arbace_j2g_decls_A_const_pool.A[605]; A_arbace_j2g_decls_A_const_404 = A_arbace_j2g_decls_A_const_pool.A[606]; A_arbace_j2g_decls_A_const_405 = A_arbace_j2g_decls_A_const_pool.A[607]; A_arbace_j2g_decls_A_const_406 = A_arbace_j2g_decls_A_const_pool.A[608]; A_arbace_j2g_decls_A_const_407 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[609]); A_arbace_j2g_decls_A_const_408 = A_arbace_j2g_decls_A_const_pool.A[610]; A_arbace_j2g_decls_A_const_409 = A_arbace_j2g_decls_A_const_pool.A[611]; A_arbace_j2g_decls_A_const_410 = A_arbace_j2g_decls_A_const_pool.A[612]; A_arbace_j2g_decls_A_const_411 = A_arbace_j2g_decls_A_const_pool.A[613]; A_arbace_j2g_decls_A_const_412 = A_arbace_j2g_decls_A_const_pool.A[614]; A_arbace_j2g_decls_A_const_413 = A_arbace_j2g_decls_A_const_pool.A[615]; A_arbace_j2g_decls_A_const_414 = A_arbace_j2g_decls_A_const_pool.A[616]; A_arbace_j2g_decls_A_const_415 = A_arbace_j2g_decls_A_const_pool.A[617]; A_arbace_j2g_decls_A_const_416 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[618]); A_arbace_j2g_decls_A_const_417 = A_arbace_j2g_decls_A_const_pool.A[619] }

func A_arbace_j2g_decls_A_clinit_p32() { A_arbace_j2g_decls_A_const_418 = A_arbace_j2g_decls_A_const_pool.A[620]; A_arbace_j2g_decls_A_const_419 = A_arbace_j2g_decls_A_const_pool.A[621]; A_arbace_j2g_decls_A_const_420 = A_arbace_j2g_decls_A_const_pool.A[622]; A_arbace_j2g_decls_A_const_421 = A_arbace_j2g_decls_A_const_pool.A[623]; A_arbace_j2g_decls_A_const_422 = A_arbace_j2g_decls_A_const_pool.A[624]; A_arbace_j2g_decls_A_const_423 = A_arbace_j2g_decls_A_const_pool.A[625]; A_arbace_j2g_decls_A_const_424 = A_arbace_j2g_decls_A_const_pool.A[626]; A_arbace_j2g_decls_A_const_425 = A_arbace_j2g_decls_A_const_pool.A[627]; A_arbace_j2g_decls_A_const_426 = A_arbace_j2g_decls_A_const_pool.A[628]; A_arbace_j2g_decls_A_const_427 = A_arbace_j2g_decls_A_const_pool.A[629]; A_arbace_j2g_decls_A_const_428 = A_arbace_j2g_decls_A_const_pool.A[630]; A_arbace_j2g_decls_A_const_429 = A_arbace_j2g_decls_A_const_pool.A[631]; A_arbace_j2g_decls_A_const_430 = A_arbace_j2g_decls_A_const_pool.A[632]; A_arbace_j2g_decls_A_const_431 = A_arbace_j2g_decls_A_const_pool.A[633]; A_arbace_j2g_decls_A_const_432 = A_arbace_j2g_decls_A_const_pool.A[634]; A_arbace_j2g_decls_A_const_433 = A_arbace_j2g_decls_A_const_pool.A[635] }

func A_arbace_j2g_decls_A_clinit_p33() { A_arbace_j2g_decls_A_const_434 = A_arbace_j2g_decls_A_const_pool.A[636]; A_arbace_j2g_decls_A_const_435 = A_arbace_j2g_decls_A_const_pool.A[637]; A_arbace_j2g_decls_A_const_436 = A_arbace_j2g_decls_A_const_pool.A[638]; A_arbace_j2g_decls_A_const_437 = A_arbace_j2g_decls_A_const_pool.A[639]; A_arbace_j2g_decls_A_const_438 = A_arbace_j2g_decls_A_const_pool.A[640]; A_arbace_j2g_decls_A_const_439 = A_arbace_j2g_decls_A_const_pool.A[641]; A_arbace_j2g_decls_A_const_440 = A_arbace_j2g_decls_A_const_pool.A[642]; A_arbace_j2g_decls_A_const_441 = A_arbace_j2g_decls_A_const_pool.A[643]; A_arbace_j2g_decls_A_const_442 = A_arbace_j2g_decls_A_const_pool.A[644]; A_arbace_j2g_decls_A_const_443 = A_arbace_j2g_decls_A_const_pool.A[645]; A_arbace_j2g_decls_A_const_444 = A_arbace_j2g_decls_A_const_pool.A[646]; A_arbace_j2g_decls_A_const_445 = A_arbace_j2g_decls_A_const_pool.A[647]; A_arbace_j2g_decls_A_const_446 = A_arbace_j2g_decls_A_const_pool.A[648]; A_arbace_j2g_decls_A_const_447 = A_arbace_j2g_decls_A_const_pool.A[649]; A_arbace_j2g_decls_A_const_448 = A_arbace_j2g_decls_A_const_pool.A[650]; A_arbace_j2g_decls_A_const_449 = A_arbace_j2g_decls_A_const_pool.A[651] }

func A_arbace_j2g_decls_A_clinit_p34() { A_arbace_j2g_decls_A_const_450 = A_arbace_j2g_decls_A_const_pool.A[652]; A_arbace_j2g_decls_A_const_451 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[653]); A_arbace_j2g_decls_A_const_452 = A_arbace_j2g_decls_A_const_pool.A[654]; A_arbace_j2g_decls_A_const_453 = A_arbace_j2g_decls_A_const_pool.A[655]; A_arbace_j2g_decls_A_const_454 = A_arbace_j2g_decls_A_const_pool.A[656]; A_arbace_j2g_decls_A_const_455 = A_arbace_j2g_decls_A_const_pool.A[657]; A_arbace_j2g_decls_A_const_456 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[658]); A_arbace_j2g_decls_A_const_457 = A_arbace_j2g_decls_A_const_pool.A[659]; A_arbace_j2g_decls_A_const_458 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[660]); A_arbace_j2g_decls_A_const_459 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[661]); A_arbace_j2g_decls_A_const_460 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[662]); A_arbace_j2g_decls_A_const_461 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[663]); A_arbace_j2g_decls_A_const_462 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[664]) }

func A_arbace_j2g_decls_A_clinit_p35() { A_arbace_j2g_decls_A_const_463 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[665]); A_arbace_j2g_decls_A_const_464 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[666]); A_arbace_j2g_decls_A_const_465 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[667]); A_arbace_j2g_decls_A_const_466 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[668]); A_arbace_j2g_decls_A_const_467 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[669]); A_arbace_j2g_decls_A_const_468 = A_arbace_j2g_decls_A_const_pool.A[670]; A_arbace_j2g_decls_A_const_469 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[671]); A_arbace_j2g_decls_A_const_470 = A_arbace_j2g_decls_A_const_pool.A[672]; A_arbace_j2g_decls_A_const_471 = A_arbace_j2g_decls_A_const_pool.A[673]; A_arbace_j2g_decls_A_const_472 = A_arbace_j2g_decls_A_const_pool.A[674]; A_arbace_j2g_decls_A_const_473 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[675]); A_arbace_j2g_decls_A_const_474 = A_arbace_j2g_decls_A_const_pool.A[676]; A_arbace_j2g_decls_A_const_475 = A_arbace_j2g_decls_A_const_pool.A[677] }

func A_arbace_j2g_decls_A_clinit_p36() { A_arbace_j2g_decls_A_const_476 = A_arbace_j2g_decls_A_const_pool.A[678]; A_arbace_j2g_decls_A_const_477 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[679]); A_arbace_j2g_decls_A_const_478 = A_arbace_j2g_decls_A_const_pool.A[680]; A_arbace_j2g_decls_A_const_479 = A_arbace_j2g_decls_A_const_pool.A[681]; A_arbace_j2g_decls_A_const_480 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[682]); A_arbace_j2g_decls_A_const_481 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[683]); A_arbace_j2g_decls_A_const_482 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[684]); A_arbace_j2g_decls_A_const_483 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[685]); A_arbace_j2g_decls_A_const_484 = A_arbace_j2g_decls_A_const_pool.A[686]; A_arbace_j2g_decls_A_const_485 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[687]); A_arbace_j2g_decls_A_const_486 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[688]); A_arbace_j2g_decls_A_const_487 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[689]); A_arbace_j2g_decls_A_const_488 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[690]) }

func A_arbace_j2g_decls_A_clinit_p37() { A_arbace_j2g_decls_A_const_489 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[691]); A_arbace_j2g_decls_A_const_490 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[692]); A_arbace_j2g_decls_A_const_491 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[693]); A_arbace_j2g_decls_A_const_492 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[694]); A_arbace_j2g_decls_A_const_493 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[695]); A_arbace_j2g_decls_A_const_494 = A_arbace_j2g_decls_A_const_pool.A[696]; A_arbace_j2g_decls_A_const_495 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[697]); A_arbace_j2g_decls_A_const_496 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[698]); A_arbace_j2g_decls_A_const_497 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[699]); A_arbace_j2g_decls_A_const_498 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[700]); A_arbace_j2g_decls_A_const_499 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[701]); A_arbace_j2g_decls_A_const_500 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[702]) }

func A_arbace_j2g_decls_A_clinit_p38() { A_arbace_j2g_decls_A_const_501 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[703]); A_arbace_j2g_decls_A_const_502 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[704]); A_arbace_j2g_decls_A_const_503 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[705]); A_arbace_j2g_decls_A_const_504 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[706]); A_arbace_j2g_decls_A_const_505 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[707]); A_arbace_j2g_decls_A_const_506 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[708]); A_arbace_j2g_decls_A_const_507 = A_arbace_j2g_decls_A_const_pool.A[709]; A_arbace_j2g_decls_A_const_508 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[710]); A_arbace_j2g_decls_A_const_509 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[711]); A_arbace_j2g_decls_A_const_510 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[712]); A_arbace_j2g_decls_A_const_511 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[713]); A_arbace_j2g_decls_A_const_512 = A_arbace_j2g_decls_A_const_pool.A[714] }

func A_arbace_j2g_decls_A_clinit_p39() { A_arbace_j2g_decls_A_const_513 = A_arbace_j2g_decls_A_const_pool.A[715]; A_arbace_j2g_decls_A_const_514 = A_arbace_j2g_decls_A_const_pool.A[716]; A_arbace_j2g_decls_A_const_515 = A_arbace_j2g_decls_A_const_pool.A[717]; A_arbace_j2g_decls_A_const_516 = A_arbace_j2g_decls_A_const_pool.A[718]; A_arbace_j2g_decls_A_const_517 = A_arbace_j2g_decls_A_const_pool.A[719]; A_arbace_j2g_decls_A_const_518 = A_arbace_j2g_decls_A_const_pool.A[720]; A_arbace_j2g_decls_A_const_519 = A_arbace_j2g_decls_A_const_pool.A[721]; A_arbace_j2g_decls_A_const_520 = A_arbace_j2g_decls_A_const_pool.A[722]; A_arbace_j2g_decls_A_const_521 = A_arbace_j2g_decls_A_const_pool.A[723]; A_arbace_j2g_decls_A_const_522 = A_arbace_j2g_decls_A_const_pool.A[724]; A_arbace_j2g_decls_A_const_523 = A_arbace_j2g_decls_A_const_pool.A[725]; A_arbace_j2g_decls_A_const_524 = A_arbace_j2g_decls_A_const_pool.A[726]; A_arbace_j2g_decls_A_const_525 = A_arbace_j2g_decls_A_const_pool.A[727]; A_arbace_j2g_decls_A_const_526 = A_arbace_j2g_decls_A_const_pool.A[728]; A_arbace_j2g_decls_A_const_527 = A_arbace_j2g_decls_A_const_pool.A[729]; A_arbace_j2g_decls_A_const_528 = A_arbace_j2g_decls_A_const_pool.A[730] }

func A_arbace_j2g_decls_A_clinit_p40() { A_arbace_j2g_decls_A_const_529 = A_arbace_j2g_decls_A_const_pool.A[731]; A_arbace_j2g_decls_A_const_530 = A_arbace_j2g_decls_A_const_pool.A[732]; A_arbace_j2g_decls_A_const_531 = A_arbace_j2g_decls_A_const_pool.A[733]; A_arbace_j2g_decls_A_const_532 = A_arbace_j2g_decls_A_const_pool.A[734]; A_arbace_j2g_decls_A_const_533 = A_arbace_j2g_decls_A_const_pool.A[735]; A_arbace_j2g_decls_A_const_534 = A_arbace_j2g_decls_A_const_pool.A[736]; A_arbace_j2g_decls_A_const_535 = A_arbace_j2g_decls_A_const_pool.A[737]; A_arbace_j2g_decls_A_const_536 = A_arbace_j2g_decls_A_const_pool.A[738]; A_arbace_j2g_decls_A_const_537 = A_arbace_j2g_decls_A_const_pool.A[739]; A_arbace_j2g_decls_A_const_538 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[740]); A_arbace_j2g_decls_A_const_539 = A_arbace_j2g_decls_A_const_pool.A[741]; A_arbace_j2g_decls_A_const_540 = A_arbace_j2g_decls_A_const_pool.A[742]; A_arbace_j2g_decls_A_const_541 = A_arbace_j2g_decls_A_const_pool.A[743]; A_arbace_j2g_decls_A_const_542 = A_arbace_j2g_decls_A_const_pool.A[744]; A_arbace_j2g_decls_A_const_543 = A_arbace_j2g_decls_A_const_pool.A[745] }

func A_arbace_j2g_decls_A_clinit_p41() { A_arbace_j2g_decls_A_const_544 = A_arbace_j2g_decls_A_const_pool.A[746]; A_arbace_j2g_decls_A_const_545 = A_arbace_j2g_decls_A_const_pool.A[747]; A_arbace_j2g_decls_A_const_546 = A_arbace_j2g_decls_A_const_pool.A[748]; A_arbace_j2g_decls_A_const_547 = A_arbace_j2g_decls_A_const_pool.A[749]; A_arbace_j2g_decls_A_const_548 = A_arbace_j2g_decls_A_const_pool.A[750]; A_arbace_j2g_decls_A_const_549 = A_arbace_j2g_decls_A_const_pool.A[751]; A_arbace_j2g_decls_A_const_550 = A_arbace_j2g_decls_A_const_pool.A[752]; A_arbace_j2g_decls_A_const_551 = A_arbace_j2g_decls_A_const_pool.A[753]; A_arbace_j2g_decls_A_const_552 = A_arbace_j2g_decls_A_const_pool.A[754]; A_arbace_j2g_decls_A_const_553 = A_arbace_j2g_decls_A_const_pool.A[755]; A_arbace_j2g_decls_A_const_554 = A_arbace_j2g_decls_A_const_pool.A[756]; A_arbace_j2g_decls_A_const_555 = A_arbace_j2g_decls_A_const_pool.A[757]; A_arbace_j2g_decls_A_const_556 = A_arbace_j2g_decls_A_const_pool.A[758]; A_arbace_j2g_decls_A_const_557 = A_arbace_j2g_decls_A_const_pool.A[759]; A_arbace_j2g_decls_A_const_558 = A_arbace_j2g_decls_A_const_pool.A[760]; A_arbace_j2g_decls_A_const_559 = A_arbace_j2g_decls_A_const_pool.A[761] }

func A_arbace_j2g_decls_A_clinit_p42() { A_arbace_j2g_decls_A_const_560 = A_arbace_j2g_decls_A_const_pool.A[762]; A_arbace_j2g_decls_A_const_561 = A_arbace_j2g_decls_A_const_pool.A[763]; A_arbace_j2g_decls_A_const_562 = A_arbace_j2g_decls_A_const_pool.A[764]; A_arbace_j2g_decls_A_const_563 = A_arbace_j2g_decls_A_const_pool.A[765]; A_arbace_j2g_decls_A_const_564 = A_arbace_j2g_decls_A_const_pool.A[766]; A_arbace_j2g_decls_A_const_565 = A_arbace_j2g_decls_A_const_pool.A[767]; A_arbace_j2g_decls_A_const_566 = A_arbace_j2g_decls_A_const_pool.A[768]; A_arbace_j2g_decls_A_const_567 = A_arbace_j2g_decls_A_const_pool.A[769]; A_arbace_j2g_decls_A_const_568 = A_arbace_j2g_decls_A_const_pool.A[770]; A_arbace_j2g_decls_A_const_569 = A_arbace_j2g_decls_A_const_pool.A[771]; A_arbace_j2g_decls_A_const_570 = A_arbace_j2g_decls_A_const_pool.A[772]; A_arbace_j2g_decls_A_const_571 = A_arbace_j2g_decls_A_const_pool.A[773]; A_arbace_j2g_decls_A_const_572 = A_arbace_j2g_decls_A_const_pool.A[774]; A_arbace_j2g_decls_A_const_573 = A_arbace_j2g_decls_A_const_pool.A[775]; A_arbace_j2g_decls_A_const_574 = A_arbace_j2g_decls_A_const_pool.A[776]; A_arbace_j2g_decls_A_const_575 = A_arbace_j2g_decls_A_const_pool.A[777] }

func A_arbace_j2g_decls_A_clinit_p43() { A_arbace_j2g_decls_A_const_576 = A_arbace_j2g_decls_A_const_pool.A[778]; A_arbace_j2g_decls_A_const_577 = A_arbace_j2g_decls_A_const_pool.A[779]; A_arbace_j2g_decls_A_const_578 = A_arbace_j2g_decls_A_const_pool.A[780]; A_arbace_j2g_decls_A_const_579 = A_arbace_j2g_decls_A_const_pool.A[781]; A_arbace_j2g_decls_A_const_580 = A_arbace_j2g_decls_A_const_pool.A[782]; A_arbace_j2g_decls_A_const_581 = A_arbace_j2g_decls_A_const_pool.A[783]; A_arbace_j2g_decls_A_const_582 = A_arbace_j2g_decls_A_const_pool.A[784]; A_arbace_j2g_decls_A_const_583 = A_arbace_j2g_decls_A_const_pool.A[785]; A_arbace_j2g_decls_A_const_584 = A_arbace_j2g_decls_A_const_pool.A[786]; A_arbace_j2g_decls_A_const_585 = A_arbace_j2g_decls_A_const_pool.A[787]; A_arbace_j2g_decls_A_const_586 = A_arbace_j2g_decls_A_const_pool.A[788]; A_arbace_j2g_decls_A_const_587 = A_arbace_j2g_decls_A_const_pool.A[789]; A_arbace_j2g_decls_A_const_588 = A_arbace_j2g_decls_A_const_pool.A[790]; A_arbace_j2g_decls_A_const_589 = A_arbace_j2g_decls_A_const_pool.A[791]; A_arbace_j2g_decls_A_const_590 = A_arbace_j2g_decls_A_const_pool.A[792]; A_arbace_j2g_decls_A_const_591 = A_arbace_j2g_decls_A_const_pool.A[793] }

func A_arbace_j2g_decls_A_clinit_p44() { A_arbace_j2g_decls_A_const_592 = A_arbace_j2g_decls_A_const_pool.A[794]; A_arbace_j2g_decls_A_const_593 = A_arbace_j2g_decls_A_const_pool.A[795]; A_arbace_j2g_decls_A_const_594 = A_arbace_j2g_decls_A_const_pool.A[796]; A_arbace_j2g_decls_A_const_595 = A_arbace_j2g_decls_A_const_pool.A[797]; A_arbace_j2g_decls_A_const_596 = A_arbace_j2g_decls_A_const_pool.A[798]; A_arbace_j2g_decls_A_const_597 = A_arbace_j2g_decls_A_const_pool.A[799]; A_arbace_j2g_decls_A_const_598 = A_arbace_j2g_decls_A_const_pool.A[800]; A_arbace_j2g_decls_A_const_599 = A_arbace_j2g_decls_A_const_pool.A[801]; A_arbace_j2g_decls_A_const_600 = A_arbace_j2g_decls_A_const_pool.A[802]; A_arbace_j2g_decls_A_const_601 = A_arbace_j2g_decls_A_const_pool.A[803]; A_arbace_j2g_decls_A_const_602 = A_arbace_j2g_decls_A_const_pool.A[804]; A_arbace_j2g_decls_A_const_603 = A_arbace_j2g_decls_A_const_pool.A[805]; A_arbace_j2g_decls_A_const_604 = A_arbace_j2g_decls_A_const_pool.A[806]; A_arbace_j2g_decls_A_const_605 = A_arbace_j2g_decls_A_const_pool.A[807]; A_arbace_j2g_decls_A_const_606 = A_arbace_j2g_decls_A_const_pool.A[808]; A_arbace_j2g_decls_A_const_607 = A_arbace_j2g_decls_A_const_pool.A[809] }

func A_arbace_j2g_decls_A_clinit_p45() { A_arbace_j2g_decls_A_const_608 = A_arbace_j2g_decls_A_const_pool.A[810]; A_arbace_j2g_decls_A_const_609 = A_arbace_j2g_decls_A_const_pool.A[811]; A_arbace_j2g_decls_A_const_610 = A_arbace_j2g_decls_A_const_pool.A[812]; A_arbace_j2g_decls_A_const_611 = A_arbace_j2g_decls_A_const_pool.A[813]; A_arbace_j2g_decls_A_const_612 = A_arbace_j2g_decls_A_const_pool.A[814]; A_arbace_j2g_decls_A_const_613 = A_arbace_j2g_decls_A_const_pool.A[815]; A_arbace_j2g_decls_A_const_614 = A_arbace_j2g_decls_A_const_pool.A[816]; A_arbace_j2g_decls_A_const_615 = A_arbace_j2g_decls_A_const_pool.A[817]; A_arbace_j2g_decls_A_const_616 = A_arbace_j2g_decls_A_const_pool.A[818]; A_arbace_j2g_decls_A_const_617 = A_arbace_j2g_decls_A_const_pool.A[819]; A_arbace_j2g_decls_A_const_618 = A_arbace_j2g_decls_A_const_pool.A[820]; A_arbace_j2g_decls_A_const_619 = A_arbace_j2g_decls_A_const_pool.A[821]; A_arbace_j2g_decls_A_const_620 = A_arbace_j2g_decls_A_const_pool.A[822]; A_arbace_j2g_decls_A_const_621 = A_arbace_j2g_decls_A_const_pool.A[823]; A_arbace_j2g_decls_A_const_622 = A_arbace_j2g_decls_A_const_pool.A[824]; A_arbace_j2g_decls_A_const_623 = A_arbace_j2g_decls_A_const_pool.A[825] }

func A_arbace_j2g_decls_A_clinit_p46() { A_arbace_j2g_decls_A_const_624 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[826]); A_arbace_j2g_decls_A_const_625 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[827]); A_arbace_j2g_decls_A_const_626 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[828]); A_arbace_j2g_decls_A_const_627 = A_arbace_j2g_decls_A_const_pool.A[829]; A_arbace_j2g_decls_A_const_628 = A_arbace_j2g_decls_A_const_pool.A[830]; A_arbace_j2g_decls_A_const_629 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[831]); A_arbace_j2g_decls_A_const_630 = A_arbace_j2g_decls_A_const_pool.A[832]; A_arbace_j2g_decls_A_const_631 = A_arbace_j2g_decls_A_const_pool.A[833]; A_arbace_j2g_decls_A_const_632 = A_arbace_j2g_decls_A_const_pool.A[834]; A_arbace_j2g_decls_A_const_633 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[835]); A_arbace_j2g_decls_A_const_634 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[836]); A_arbace_j2g_decls_A_const_635 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[837]); A_arbace_j2g_decls_A_const_636 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[838]) }

func A_arbace_j2g_decls_A_clinit_p47() { A_arbace_j2g_decls_A_const_637 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[839]); A_arbace_j2g_decls_A_const_638 = A_arbace_j2g_decls_A_const_pool.A[840]; A_arbace_j2g_decls_A_const_639 = A_arbace_j2g_decls_A_const_pool.A[841]; A_arbace_j2g_decls_A_const_640 = A_arbace_j2g_decls_A_const_pool.A[842]; A_arbace_j2g_decls_A_const_641 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[843]); A_arbace_j2g_decls_A_const_642 = A_arbace_j2g_decls_A_const_pool.A[844]; A_arbace_j2g_decls_A_const_643 = A_arbace_j2g_decls_A_const_pool.A[845]; A_arbace_j2g_decls_A_const_644 = A_arbace_j2g_decls_A_const_pool.A[846]; A_arbace_j2g_decls_A_const_645 = A_arbace_j2g_decls_A_const_pool.A[847]; A_arbace_j2g_decls_A_const_646 = A_arbace_j2g_decls_A_const_pool.A[848]; A_arbace_j2g_decls_A_const_647 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[849]); A_arbace_j2g_decls_A_const_648 = A_arbace_j2g_decls_A_const_pool.A[850]; A_arbace_j2g_decls_A_const_649 = A_arbace_j2g_decls_A_const_pool.A[851]; A_arbace_j2g_decls_A_const_650 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[852]) }

func A_arbace_j2g_decls_A_clinit_p48() { A_arbace_j2g_decls_A_const_651 = A_arbace_j2g_decls_A_const_pool.A[853]; A_arbace_j2g_decls_A_const_652 = A_arbace_j2g_decls_A_const_pool.A[854]; A_arbace_j2g_decls_A_const_653 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[855]); A_arbace_j2g_decls_A_const_654 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[856]); A_arbace_j2g_decls_A_const_655 = A_arbace_j2g_decls_A_const_pool.A[857]; A_arbace_j2g_decls_A_const_656 = A_arbace_j2g_decls_A_const_pool.A[858]; A_arbace_j2g_decls_A_const_657 = A_arbace_j2g_decls_A_const_pool.A[859]; A_arbace_j2g_decls_A_const_658 = A_arbace_j2g_decls_A_const_pool.A[860]; A_arbace_j2g_decls_A_const_659 = A_arbace_j2g_decls_A_const_pool.A[861]; A_arbace_j2g_decls_A_const_660 = A_arbace_j2g_decls_A_const_pool.A[862]; A_arbace_j2g_decls_A_const_661 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[863]); A_arbace_j2g_decls_A_const_662 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[864]); A_arbace_j2g_decls_A_const_663 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[865]); A_arbace_j2g_decls_A_const_664 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[866]) }

func A_arbace_j2g_decls_A_clinit_p49() { A_arbace_j2g_decls_A_const_665 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[867]) }

func A_arbace_j2g_decls_A_New() *A_arbace_j2g_decls_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls_A) Ctor() {}

func (t *A_arbace_j2g_decls_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls_A_class }

func (t *A_arbace_j2g_decls_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls_A); return ok }

func A_arbace_j2g_decls_A_Cast(x any) *A_arbace_j2g_decls_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls_A_class)) }; return v }



type A_arbace_j2g_decls_at_line_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_at_line_A_fn_class *jrt.Class



type A_arbace_j2g_decls_at_line_fn__1464000041_A struct{ j2g_header uint64; F_l any }

var A_arbace_j2g_decls_at_line_fn__1464000041_A_fn_class *jrt.Class



type A_arbace_j2g_decls_body_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_body_of_A_fn_class *jrt.Class



type A_arbace_j2g_decls_calls_in_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_calls_in_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_captured_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A struct{ j2g_header uint64; F_tsym any }

var A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A struct{ j2g_header uint64; F_tsym, F_s__1464000029, F_iter__1464000028 any }

var A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A struct{ j2g_header uint64; F_tsym, F_b__1464000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A struct{ j2g_header uint64; F_s__1464000061, F_iter__1464000060 any }

var A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A struct{ j2g_header uint64; F_b__1464000063 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000670_A struct{ j2g_header uint64; F_pkg, F_n any }

var A_arbace_j2g_decls_class_forms_fn__1464000670_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000672_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_forms_fn__1464000672_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000674_A struct{ j2g_header uint64; F_pkg, F_n any }

var A_arbace_j2g_decls_class_forms_fn__1464000674_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000676_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_forms_fn__1464000676_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A struct{ j2g_header uint64; F_pkg, F_s__1464000611, F_iter__1464000610 any }

var A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A struct{ j2g_header uint64; F_b__1464000613, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000610__1464000614_fn__1464000615_fn__1464000616_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A struct{ j2g_header uint64; F_pkg, F_s__1464000621, F_iter__1464000620 any }

var A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A struct{ j2g_header uint64; F_b__1464000623, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000620__1464000624_fn__1464000625_fn__1464000626_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A struct{ j2g_header uint64; F_pkg, F_s__1464000631, F_iter__1464000630 any }

var A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A struct{ j2g_header uint64; F_b__1464000633, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000630__1464000634_fn__1464000635_fn__1464000636_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A struct{ j2g_header uint64; F_pkg, F_s__1464000641, F_iter__1464000640 any }

var A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A struct{ j2g_header uint64; F_b__1464000643, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000640__1464000644_fn__1464000645_fn__1464000646_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A struct{ j2g_header uint64; F_pkg, F_s__1464000651, F_iter__1464000650 any }

var A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A struct{ j2g_header uint64; F_b__1464000653, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000650__1464000654_fn__1464000655_fn__1464000656_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A struct{ j2g_header uint64; F_g any }

var A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A struct{ j2g_header uint64; F_g, F_s__1464000661, F_iter__1464000660 any }

var A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A struct{ j2g_header uint64; F_b__1464000663, F_g any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000660__1464000664_fn__1464000665_fn__1464000666_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_methods_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A struct{ j2g_header uint64; F_n, F_s__1464000072, F_iter__1464000071 any }

var A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A struct{ j2g_header uint64; F_n, F_b__1464000074 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_clj_const_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A struct{ j2g_header uint64; F_g, F_pkg any }

var A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A struct{ j2g_header uint64; F_g, F_iter__1464000517, F_pkg, F_s__1464000518 any }

var A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A struct{ j2g_header uint64; F_b__1464000520, F_g, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_clj_const_fields_iter__1464000517__1464000521_fn__1464000522_fn__1464000523_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_store_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_clj_const_store_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_store_strc__1464000487_A struct{ j2g_header uint64; F_sd any }

var A_arbace_j2g_decls_clj_const_store_strc__1464000487_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A struct{ j2g_header uint64; F_info, F_n any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A struct{ j2g_header uint64; F_info any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A struct{ j2g_header uint64; F_info, F_s__1464000133, F_iter__1464000132 any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A struct{ j2g_header uint64; F_b__1464000135, F_info any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A struct{ j2g_header uint64; F_s__1464000150, F_iter__1464000149 any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A struct{ j2g_header uint64; F_b__1464000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_desc_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_desc_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000195_A struct{ j2g_header uint64; F_d, F_reached, F_all_ps, F_caps, F_pkg, F_n, F_st, F_info, F_ab, F_cap_ps, F_outer_p, F_mm any }

var A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A struct{ j2g_header uint64; F_d, F_all_ps, F_caps, F_pkg, F_n, F_st, F_info, F_ab, F_cap_ps, F_outer_p, F_mm any }

var A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A struct{ j2g_header uint64; F_st any }

var A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000243_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A struct{ j2g_header uint64; F_s__1464000166, F_iter__1464000165 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A struct{ j2g_header uint64; F_b__1464000168 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A struct{ j2g_header uint64; F_s__1464000176, F_iter__1464000175 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000178 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A struct{ j2g_header uint64; F_s__1464000186, F_iter__1464000185 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000188, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A struct{ j2g_header uint64; F_pkg, F_rps any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A struct{ j2g_header uint64; F_pkg, F_rps, F_s__1464000234, F_iter__1464000233 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A struct{ j2g_header uint64; F_b__1464000236, F_pkg, F_rps any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_derived_body_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_fn__1464000272_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_derived_body_fn__1464000272_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A struct{ j2g_header uint64; F_g any }

var A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A struct{ j2g_header uint64; F_g, F_s__1464000275, F_iter__1464000274 any }

var A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A struct{ j2g_header uint64; F_g any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000277 any }

var A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A struct{ j2g_header uint64; F_s__1464000375, F_iter__1464000374 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A struct{ j2g_header uint64; F_b__1464000377 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000374__1464000378_fn__1464000379_fn__1464000380_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A struct{ j2g_header uint64; F_own, F_pkg, F_n, F_leaf any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A struct{ j2g_header uint64; F_own, F_pkg, F_n, F_s__1464000385, F_iter__1464000384, F_leaf any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A struct{ j2g_header uint64; F_own, F_pkg, F_n, F_leaf any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000387 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A struct{ j2g_header uint64; F_s__1464000401, F_iter__1464000400 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A struct{ j2g_header uint64; F_b__1464000403 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_fn__1464000390_iter__1464000400__1464000404_fn__1464000405_fn__1464000406_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A struct{ j2g_header uint64; F_s__1464000421, F_iter__1464000420 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A struct{ j2g_header uint64; F_b__1464000423 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000384__1464000388_fn__1464000389_iter__1464000420__1464000424_fn__1464000425_fn__1464000426_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A struct{ j2g_header uint64; F_s__1464000433, F_iter__1464000432 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A struct{ j2g_header uint64; F_b__1464000435 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000432__1464000436_fn__1464000437_fn__1464000438_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ensure_terminated_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ensure_terminated_A_fn_class *jrt.Class



type A_arbace_j2g_decls_eval1464000004_A struct{ jrt.Object }

func A_arbace_j2g_decls_eval1464000004_A_New() *A_arbace_j2g_decls_eval1464000004_A { t := &A_arbace_j2g_decls_eval1464000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls_eval1464000004_A) Ctor() {}

func (t *A_arbace_j2g_decls_eval1464000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls_eval1464000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls_eval1464000004_A_class }

func (t *A_arbace_j2g_decls_eval1464000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls_eval1464000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls_eval1464000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls_eval1464000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls_eval1464000004_A); return ok }

func A_arbace_j2g_decls_eval1464000004_A_Cast(x any) *A_arbace_j2g_decls_eval1464000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls_eval1464000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls_eval1464000004_A_class)) }; return v }



type A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_fn_class *jrt.Class



type A_arbace_j2g_decls_eval1464000008_A struct{ jrt.Object }

func A_arbace_j2g_decls_eval1464000008_A_New() *A_arbace_j2g_decls_eval1464000008_A { t := &A_arbace_j2g_decls_eval1464000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls_eval1464000008_A) Ctor() {}

func (t *A_arbace_j2g_decls_eval1464000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls_eval1464000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls_eval1464000008_A_class }

func (t *A_arbace_j2g_decls_eval1464000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls_eval1464000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls_eval1464000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls_eval1464000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls_eval1464000008_A); return ok }

func A_arbace_j2g_decls_eval1464000008_A_Cast(x any) *A_arbace_j2g_decls_eval1464000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls_eval1464000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls_eval1464000008_A_class)) }; return v }



type A_arbace_j2g_decls_eval1464000008_fn__1464000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_extra_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A struct{ j2g_header uint64; F_pkg, F_s__1464000089, F_iter__1464000088 any }

var A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A struct{ j2g_header uint64; F_pkg, F_b__1464000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_fn_class *jrt.Class



type A_arbace_j2g_decls_field_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_field_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_forwarder_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A struct{ j2g_header uint64; F_s__1464000359, F_iter__1464000358 any }

var A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A struct{ j2g_header uint64; F_b__1464000361 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_forwarder_iter__1464000358__1464000362_fn__1464000363_fn__1464000364_A_fn_class *jrt.Class



type A_arbace_j2g_decls_gt_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_gt_A_fn_class *jrt.Class



type A_arbace_j2g_decls_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_hw_markers_A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A struct{ j2g_header uint64; F_iter__1464000109, F_s__1464000110 any }

var A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000112 any }

var A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_fn_class *jrt.Class



type A_arbace_j2g_decls_iface_method_elem_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_iface_method_elem_A_fn_class *jrt.Class



type A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_fn_class *jrt.Class



type A_arbace_j2g_decls_init_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_init_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_init_forms_fn__1464000494_A struct{ j2g_header uint64; F_sup, F_pkg, F_reached, F_n, F_st any }

var A_arbace_j2g_decls_init_forms_fn__1464000494_A_fn_class *jrt.Class



type A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A struct{ j2g_header uint64; F_sup, F_pkg, F_reached, F_n, F_st any }

var A_arbace_j2g_decls_init_forms_fn__1464000494_fn__1464000495_A_fn_class *jrt.Class



type A_arbace_j2g_decls_instance_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_instance_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_interface_closure_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_interface_closure_A_fn_class *jrt.Class



type A_arbace_j2g_decls_interface_closure_fn__1464000106_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_decls_interface_closure_fn__1464000106_A_fn_class *jrt.Class



type A_arbace_j2g_decls_markers_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_markers_A_fn_class *jrt.Class



type A_arbace_j2g_decls_markers_fn__1464000121_A struct{ j2g_header uint64; F_sup_marked any }

var A_arbace_j2g_decls_markers_fn__1464000121_A_fn_class *jrt.Class



type A_arbace_j2g_decls_member_line_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_member_line_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_code_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_fn__1464000057_A struct{ j2g_header uint64; F_static, F_m, F_n, F_t, F_this, F_ret, F_ab any }

var A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A struct{ j2g_header uint64; F_s__1464000048, F_iter__1464000047 any }

var A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A struct{ j2g_header uint64; F_b__1464000050 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000326_A struct{ j2g_header uint64; F_iface, F_static, F_pkg, F_n, F_ab, F_leaf, F_ps, F_mm any }

var A_arbace_j2g_decls_method_forms_fn__1464000326_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A struct{ j2g_header uint64; F_iter__1464000327, F_s__1464000328 any }

var A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000330, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_fn__1464000326_iter__1464000327__1464000331_fn__1464000332_fn__1464000333_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000348_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_fn__1464000348_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A struct{ j2g_header uint64; F_s__1464000297, F_iter__1464000296 any }

var A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000299 any }

var A_arbace_j2g_decls_method_forms_iter__1464000296__1464000300_fn__1464000301_fn__1464000302_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A struct{ j2g_header uint64; F_iter__1464000306, F_s__1464000307 any }

var A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A struct{ j2g_header uint64; F_b__1464000309 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_iter__1464000306__1464000310_fn__1464000311_fn__1464000312_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A struct{ j2g_header uint64; F_iter__1464000316, F_s__1464000317 any }

var A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A struct{ j2g_header uint64; F_b__1464000319 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_iter__1464000316__1464000320_fn__1464000321_fn__1464000322_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A struct{ j2g_header uint64; F_iter__1464000338, F_s__1464000339 any }

var A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000341, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_iter__1464000338__1464000342_fn__1464000343_fn__1464000344_A_fn_class *jrt.Class



type A_arbace_j2g_decls_needs_entry_guard_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_needs_entry_guard_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_new_fn_state_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_new_fn_state_A_fn_class *jrt.Class



type A_arbace_j2g_decls_object_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_object_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_object_forms_fn__1464000371_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_object_forms_fn__1464000371_A_fn_class *jrt.Class



type A_arbace_j2g_decls_param_list_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_param_list_A_fn_class *jrt.Class



type A_arbace_j2g_decls_param_list_fn__1464000015_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_param_list_fn__1464000015_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reached_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reached_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_record_object_body_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fld__1464000248_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_record_object_body_fld__1464000248_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fn__1464000257_A struct{ j2g_header uint64; F_hash, F_fld any }

var A_arbace_j2g_decls_record_object_body_fn__1464000257_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fn__1464000259_A struct{ j2g_header uint64; F_fld, F_strof any }

var A_arbace_j2g_decls_record_object_body_fn__1464000259_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fn__1464000261_A struct{ j2g_header uint64; F_js, F_fld any }

var A_arbace_j2g_decls_record_object_body_fn__1464000261_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_hash__1464000250_A struct{ j2g_header uint64; F_js any }

var A_arbace_j2g_decls_record_object_body_hash__1464000250_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_js__1464000246_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_record_object_body_js__1464000246_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_strof__1464000253_A struct{ j2g_header uint64; F_js any }

var A_arbace_j2g_decls_record_object_body_strof__1464000253_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reflected_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A struct{ j2g_header uint64; F_iter__1464000539, F_n, F_s__1464000540 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A struct{ j2g_header uint64; F_b__1464000542, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000539__1464000543_fn__1464000544_fn__1464000545_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A struct{ j2g_header uint64; F_iter__1464000549, F_pkg, F_s__1464000550 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A struct{ j2g_header uint64; F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000552 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000549__1464000553_fn__1464000554_fn__1464000555_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A struct{ j2g_header uint64; F_iter__1464000559, F_pkg, F_s__1464000560 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A struct{ j2g_header uint64; F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000562 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000559__1464000563_fn__1464000564_fn__1464000565_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A struct{ j2g_header uint64; F_g, F_pkg, F_n any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A struct{ j2g_header uint64; F_iter__1464000569, F_g, F_pkg, F_n, F_s__1464000570 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A struct{ j2g_header uint64; F_g, F_pkg, F_n any; F_size__1927001038__auto__ int32; F_b__1464000572, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A struct{ j2g_header uint64; F_iter__1464000579, F_s__1464000580 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000582, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_fn__1464000575_iter__1464000579__1464000583_fn__1464000584_fn__1464000585_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A struct{ j2g_header uint64; F_s__1464000594, F_iter__1464000593 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000596 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000569__1464000573_fn__1464000574_iter__1464000593__1464000597_fn__1464000598_fn__1464000599_A_fn_class *jrt.Class



type A_arbace_j2g_decls_result_meta_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_result_meta_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_split_clinit_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_fn__1464000466_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_split_clinit_fn__1464000466_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_fn__1464000479_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_split_clinit_fn__1464000479_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A struct{ j2g_header uint64; F_g any }

var A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A struct{ j2g_header uint64; F_g, F_s__1464000469, F_iter__1464000468 any }

var A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A struct{ j2g_header uint64; F_g, F_b__1464000471 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_split_clinit_iter__1464000468__1464000472_fn__1464000473_fn__1464000474_A_fn_class *jrt.Class



type A_arbace_j2g_decls_splittable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_splittable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_static_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A struct{ j2g_header uint64; F_g, F_pkg, F_n any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A struct{ j2g_header uint64; F_g, F_pkg, F_n, F_s__1464000444, F_iter__1464000443 any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A struct{ j2g_header uint64; F_b__1464000446, F_g, F_pkg, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A struct{ j2g_header uint64; F_f, F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000451_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A struct{ j2g_header uint64; F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000449_fn__1464000453_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A struct{ j2g_header uint64; F_f, F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000457_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A struct{ j2g_header uint64; F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000443__1464000447_fn__1464000448_fn__1464000459_A_fn_class *jrt.Class



type A_arbace_j2g_decls_stub_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_stub_body_A_fn_class *jrt.Class



type A_arbace_j2g_decls_super_iface_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_super_iface_type_A_fn_class *jrt.Class



type A_arbace_j2g_decls_super_struct_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_super_struct_type_A_fn_class *jrt.Class



type A_arbace_j2g_decls_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_tag_A_fn_class *jrt.Class



type A_arbace_j2g_decls_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_touches_statics_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_touches_statics_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A struct{ j2g_header uint64; F_classes, F_hit any }

var A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_fn_class *jrt.Class



type A_arbace_j2g_decls_with_ret_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_with_ret_A_fn_class *jrt.Class
