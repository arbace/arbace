//line aot_arbace_j2g_decls.ae:1
package aot_arbace_j2g_decls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_New() *A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_j2g_decls_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_3, A_arbace_j2g_decls_A_const_4, A_arbace_j2g_decls_A_const_5, A_arbace_j2g_decls_A_const_6, A_arbace_j2g_decls_A_const_7, A_arbace_j2g_decls_A_const_8, A_arbace_j2g_decls_A_const_9, A_arbace_j2g_decls_A_const_10, A_arbace_j2g_decls_A_const_11); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_New() *A_arbace_j2g_decls_eval1464000008_fn__1464000009_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_eval1464000008_fn__1464000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000008_fn__1464000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_j2g_decls_eval1464000008_fn__1464000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_16), A_arbace_j2g_decls_A_const_14.GetRawRoot__O(), A_arbace_j2g_decls_A_const_15) }

















func A_arbace_j2g_decls_tag_A_New() *A_arbace_j2g_decls_tag_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_tag_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_j2g_decls_tag_A) Ctor() {}
//line :19:1
func (t *A_arbace_j2g_decls_tag_A) Invoke_O_O_O__O(self, sym__0, type__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(sym__0, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_18, type__1))) }

func A_arbace_j2g_decls_has_QMARK__A_New() *A_arbace_j2g_decls_has_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_has_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_j2g_decls_has_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_j2g_decls_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_19.GetRawRoot__O()).Invoke_O_O__O(flags__0, f__1) }

func A_arbace_j2g_decls_gt_A_New() *A_arbace_j2g_decls_gt_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_gt_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_j2g_decls_gt_A) Ctor() {}
//line :23:1
func (t *A_arbace_j2g_decls_gt_A) Invoke_O_O_O__O(self, pkg__0, d__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_20.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__1) }

func A_arbace_j2g_decls_param_list_A_New() *A_arbace_j2g_decls_param_list_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_param_list_A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_j2g_decls_param_list_A) Ctor() {}
//line :25:1
func (t *A_arbace_j2g_decls_param_list_A) Invoke_O_O_O_O__O(self, pkg__0, descs__1, syms__2 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_param_list_fn__1464000015_A_New_O(pkg__0); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_decls_param_list_fn__1464000015_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_189, false); A_arbace_j2g_decls_param_list_fn__1464000015_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), descs__1, syms__2)) }
//line :29:1
func A_arbace_j2g_decls_param_list_fn__1464000015_A_New_O(p0 any) *A_arbace_j2g_decls_param_list_fn__1464000015_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_param_list_fn__1464000015_A{}; t.Ctor_O(p0); return t }
//line :29:1
func (t *A_arbace_j2g_decls_param_list_fn__1464000015_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :29:1
func (t *A_arbace_j2g_decls_param_list_fn__1464000015_A) Invoke_O_O_O__O(self, d__1, s__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, d__1)) }

func A_arbace_j2g_decls_result_meta_A_New() *A_arbace_j2g_decls_result_meta_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_result_meta_A{}; t.Ctor(); return t }
//line :31:1
func (t *A_arbace_j2g_decls_result_meta_A) Ctor() {}
//line :31:1
func (t *A_arbace_j2g_decls_result_meta_A) Invoke_O_O_O__O(self, pkg__0, r__1 any) any { if lang.Util_Equiv_O_O__Z(r__1, Lit_51) { return nil } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, r__1) } }

func A_arbace_j2g_decls_with_ret_A_New() *A_arbace_j2g_decls_with_ret_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_with_ret_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_j2g_decls_with_ret_A) Ctor() {}
//line :33:1
func (t *A_arbace_j2g_decls_with_ret_A) Invoke_O_O_O_O__O(self, v__0, pkg__1, r__2 any) any { var temp__1927000408__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_25.GetRawRoot__O()).Invoke_O_O__O(pkg__1, r__2); if jrt.J2g_Truth(temp__1927000408__auto____4) { var g__5 any = temp__1927000408__auto____4; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_26.GetRawRoot__O()).Invoke_O_O_O_O__O(v__0, A_arbace_j2g_decls_A_const_27.GetRawRoot__O(), A_arbace_j2g_decls_A_const_18, g__5) } else { return v__0 } }

func A_arbace_j2g_decls_new_fn_state_A_New() *A_arbace_j2g_decls_new_fn_state_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_new_fn_state_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_j2g_decls_new_fn_state_A) Ctor() {}
//line :35:1
func (t *A_arbace_j2g_decls_new_fn_state_A) DoInvoke_O_O_O_O__O(self, pkg__0, n__1, p__1464000020__2 any) any { var map__1464000021__4 any = p__1464000020__2; var map__1464000021__5 any; if lang.ISeq_InstanceOf(map__1464000021__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000021__4)) { map__1464000021__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000021__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000021__4)) { map__1464000021__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000021__4) } else { lang.PersistentArrayMap_Init(); map__1464000021__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000021__5 = map__1464000021__4 }; var more__6 any = map__1464000021__5; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_32.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_33; var tmp3 any = A_arbace_j2g_decls_A_const_34; var tmp4 any = A_arbace_j2g_decls_A_const_35; var tmp5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_36.GetRawRoot__O()).Invoke_O__O(Lit_180); var tmp6 any = A_arbace_j2g_decls_A_const_37; var tmp7 *lang.PersistentArrayMap;

	lang.PersistentArrayMap_Init(); tmp7 = lang.PersistentArrayMap_EMPTY; var tmp8 any = tmp7.Ref(); var tmp9 any = A_arbace_j2g_decls_A_const_38; var tmp10 any = A_arbace_j2g_decls_A_const_39; var tmp11 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY; var tmp12 any = tmp11.Ref(); var tmp13 any = A_arbace_j2g_decls_A_const_40; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()); var tmp15 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp15 = lang.PersistentArrayMap_EMPTY; var tmp16 any = tmp14.Invoke_O__O(tmp15.Ref()); var tmp17 any = A_arbace_j2g_decls_A_const_42; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_46.GetRawRoot__O()); var tmp20 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp20 = lang.PersistentHashSet_EMPTY; var tmp21 any = tmp20.Ref(); var tmp22 any = tmp18.Invoke_O__O(tmp19.Invoke_O_O__O(tmp21, A_arbace_j2g_decls_A_const_47.GetRawRoot__O())); var tmp23 any = A_arbace_j2g_decls_A_const_43; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()); var tmp25 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp25 = lang.PersistentHashSet_EMPTY; var tmp26 any = tmp24.Invoke_O__O(tmp25.Ref()); var tmp27 any = A_arbace_j2g_decls_A_const_44; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()); var tmp29 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp29 = lang.PersistentArrayMap_EMPTY; var tmp30 any = tmp28.Invoke_O__O(tmp29.Ref()); var tmp31 any = A_arbace_j2g_decls_A_const_45; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_41.GetRawRoot__O()); var tmp33 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp33 = lang.PersistentHashSet_EMPTY; return tmp1.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, pkg__0, tmp3, n__1, tmp4, tmp5, tmp6, tmp8, tmp9, nil, tmp10, tmp12, tmp13, tmp16, tmp17, tmp22, tmp23, tmp26, tmp27, tmp30, tmp31, tmp32.Invoke_O__O(tmp33.Ref()))), more__6) }




func A_arbace_j2g_decls_terminating_QMARK__A_New() *A_arbace_j2g_decls_terminating_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_terminating_QMARK__A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_j2g_decls_terminating_QMARK__A) Ctor() {}
//line :42:1
func (t *A_arbace_j2g_decls_terminating_QMARK__A) Invoke_O_O__O(self, f__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0); if



	jrt.J2g_Truth(and__1927000168__auto____2) { var G__1464000024__3_ any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(f__0)
		switch lang.Util_Hash_O__I(G__1464000024__3_) >> 2 & 7 { case 0: if lang.Util_Equiv_O_O__Z(G__1464000024__3_, A_arbace_j2g_decls_A_const_49) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 1: if lang.Util_Equiv_O_O__Z(G__1464000024__3_, A_arbace_j2g_decls_A_const_50) {

			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_54.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :47:1
		case 4: if lang.Util_Equiv_O_O__Z(G__1464000024__3_, A_arbace_j2g_decls_A_const_52) {

			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_54.GetRawRoot__O()).Invoke_O__O(f__0)) }
//line :47:1
		case 5: if lang.Util_Equiv_O_O__Z(G__1464000024__3_, A_arbace_j2g_decls_A_const_53) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 7: if lang.Util_Equiv_O_O__Z(G__1464000024__3_, A_arbace_j2g_decls_A_const_55) { var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z(4, int64(lang.RT_Count_O__I(f__0)))


			if and__1927000168__auto____4 { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(f__0, lang.RT_IntCast_J__I(2))); if jrt.J2g_Truth(and__1927000168__auto____5) { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.RT_Nth_O_I__O(f__0, lang.RT_IntCast_J__I(3))) } else { return and__1927000168__auto____5 } } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____4).Ref() } }
//line :47:1
		default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else {
//line :46:1
			return and__1927000168__auto____2 } }






func A_arbace_j2g_decls_ensure_terminated_A_New() *A_arbace_j2g_decls_ensure_terminated_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ensure_terminated_A{}; t.Ctor(); return t }
//line :53:1
func (t *A_arbace_j2g_decls_ensure_terminated_A) Ctor() {}
//line :53:1
func (t *A_arbace_j2g_decls_ensure_terminated_A) Invoke_O_O_O__O(self, forms__0, has_results__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = has_results__1; if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_51.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_54.GetRawRoot__O()).Invoke_O__O(forms__0))) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(forms__0, lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_59, Lit_120))) } else {
//line :57:1
			return forms__0
		}
}

func A_arbace_j2g_decls_stub_body_A_New() *A_arbace_j2g_decls_stub_body_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_stub_body_A{}; t.Ctor(); return t }
//line :61:1
func (t *A_arbace_j2g_decls_stub_body_A) Ctor() {}
//line :61:1
func (t *A_arbace_j2g_decls_stub_body_A) Invoke_O_O_O_O__O(self, n__0, name__1, desc__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_60; return lang.Tuple_Create_O__IPersistentVector(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_63.GetRawRoot__O()).Invoke_O__O(n__0), Lit_99), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_11, Lit_12), nil, name__1, desc__2)).Ref()))) }



func A_arbace_j2g_decls_captured_fields_A_New() *A_arbace_j2g_decls_captured_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_j2g_decls_captured_fields_A) Ctor() {}
//line :65:1
func (t *A_arbace_j2g_decls_captured_fields_A) Invoke_O_O_O__O(self, n__0, tsym__1 any) any { var d__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 any; var and__1927000168__auto____4 any = d__3; if




	jrt.J2g_Truth(and__1927000168__auto____4) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_65); tmp1 = tmp2.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__3)) } else { tmp1 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp1) {
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_46.GetRawRoot__O()); var tmp4 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp4 = lang.PersistentArrayMap_EMPTY; var tmp5 any = tmp4.Ref(); var tmp6 any; var iter__1927001039__auto____4 any; var tmp7 any = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_New_O(tsym__1); var tmp8 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_fn_class = fncls__5d; tmp8 = fncls__5d } else { tmp8 = fncls__5 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 *lang.Keyword = A_arbace_j2g_decls_A_const_80; tmp6 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__3)))); return tmp3.Invoke_O_O__O(tmp5, tmp6) } else {
//line :70:1
			lang.PersistentArrayMap_Init(); return lang.PersistentArrayMap_EMPTY.Ref() } }
func A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_New_O(p0 any) *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A{}; t.Ctor_O(p0); return t }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A) Ctor_O(c__tsym any) { t.F_tsym = c__tsym }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A) Invoke_O_O__O(self, s__1464000029__1 any) any { var tmp1 any = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_New_O_O_O(t.F_tsym, s__1464000029__1, self); var tmp2 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_3, false); A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_fn_class = fncls__4d; tmp2 = fncls__4d } else { tmp2 = fncls__4 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :71:1
func A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A) Ctor_O_O_O(c__tsym, c__s__1464000029, c__iter__1464000028 any) { t.F_tsym = c__tsym; t.F_s__1464000029 = c__s__1464000029; t.F_iter__1464000028 = c__iter__1464000028 }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A) Invoke_O__O(self any) any { { var s__1464000029__1 any; var t_ any = t.F_s__1464000029; t.F_s__1464000029 = nil; s__1464000029__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000029__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000029__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000029__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000029__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000031__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_New_O_O_I_O(t.F_tsym, b__1464000031__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000028); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000031__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000029__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000031__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000029__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000028); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__4), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__4))).Ref()))).Ref()), t.F_tsym)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000029__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :71:1
func A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A) Ctor_O_O_I_O(c__tsym, c__b__1464000031 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_tsym = c__tsym; t.F_b__1464000031 = c__b__1464000031; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :71:1
func (t *A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A) Invoke_O__O(self any) any { { var i__1464000030__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000030__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000030__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000031; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__2), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__2))).Ref()))).Ref()), t.F_tsym))); i__1464000030__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000030__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_member_line_A_New() *A_arbace_j2g_decls_member_line_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_member_line_A{}; t.Ctor(); return t }
//line :75:1
func (t *A_arbace_j2g_decls_member_line_A) Ctor() {}
//line :75:1
func (t *A_arbace_j2g_decls_member_line_A) Invoke_O_O__O(self, m__0 any) any {


	var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_82; return tmp1.Invoke_O__O(A_arbace_j2g_decls_A_const_83.Invoke_O__O(m__0))
}
func A_arbace_j2g_decls_at_line_A_New() *A_arbace_j2g_decls_at_line_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_at_line_A{}; t.Ctor(); return t }
//line :80:1
func (t *A_arbace_j2g_decls_at_line_A) Ctor() {}
//line :80:1
func (t *A_arbace_j2g_decls_at_line_A) Invoke_O_O_O__O(self, m__0, forms__1 any) any { var temp__1927000408__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_84.GetRawRoot__O()).Invoke_O__O(m__0); if


	jrt.J2g_Truth(temp__1927000408__auto____3) { var l__4 any = temp__1927000408__auto____3; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_at_line_fn__1464000041_A_New_O(l__4); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_j2g_decls_at_line_fn__1464000041_A_fn_class
		if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_j2g_decls_at_line_fn__1464000041_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), forms__1) } else {
//line :83:1
			return forms__1 } }
func A_arbace_j2g_decls_at_line_fn__1464000041_A_New_O(p0 any) *A_arbace_j2g_decls_at_line_fn__1464000041_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_at_line_fn__1464000041_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_j2g_decls_at_line_fn__1464000041_A) Ctor_O(c__l any) { t.F_l = c__l }
//line :84:1
func (t *A_arbace_j2g_decls_at_line_fn__1464000041_A) Invoke_O_O__O(self, p1__1464000040_SHARP___1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(p1__1464000040_SHARP___1)) { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_26.GetRawRoot__O()).Invoke_O_O_O_O__O(p1__1464000040_SHARP___1, A_arbace_j2g_decls_A_const_27.GetRawRoot__O(), A_arbace_j2g_decls_A_const_85, t.F_l) } else { return p1__1464000040_SHARP___1 } }


func A_arbace_j2g_decls_method_code_forms_A_New() *A_arbace_j2g_decls_method_code_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_A{}; t.Ctor(); return t }
//line :87:1
func (t *A_arbace_j2g_decls_method_code_forms_A) Ctor() {}
//line :87:1
func (t *A_arbace_j2g_decls_method_code_forms_A) Invoke_O_O_O_O_O_O__O(self, pkg__0, n__1, m__2, ab__3, p__1464000044__4 any) any { var map__1464000045__6 any = p__1464000044__4; var map__1464000045__7 any; if lang.ISeq_InstanceOf(map__1464000045__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000045__6)) { map__1464000045__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000045__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000045__6)) { map__1464000045__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000045__6) } else { lang.PersistentArrayMap_Init(); map__1464000045__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000045__7 = map__1464000045__6 }; var t__8 any = lang.RT_Get_O_O__O(map__1464000045__7, A_arbace_j2g_decls_A_const_86); var this__9 any = lang.RT_Get_O_O__O(map__1464000045__7, A_arbace_j2g_decls_A_const_87); var static__10 any = lang.RT_Get_O_O__O(map__1464000045__7, A_arbace_j2g_decls_A_const_88); var ret__11 any = A_arbace_j2g_decls_A_const_89.Invoke_O__O(m__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_88; var tmp6 any = A_arbace_j2g_decls_A_const_86; var tmp7 any = A_arbace_j2g_decls_A_const_87; var tmp8 any = A_arbace_j2g_decls_A_const_97; var tmp9 any = A_arbace_j2g_decls_A_const_39; var tmp10 any; if




	jrt.J2g_Truth(t__8) { tmp10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_98.GetRawRoot__O()).Invoke_O_O__O(n__1, t__8) } else { lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY.Ref() }; var tmp11 any = tmp10; var tmp12 any = A_arbace_j2g_decls_A_const_99; var tmp13 any = /*line :91:1*/A_arbace_j2g_decls_A_const_100.Invoke_O__O(m__2); var tmp14 any = A_arbace_j2g_decls_A_const_101; var tmp15 any = tmp4.Invoke_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O_O__O(pkg__0, n__1, tmp5, static__10, tmp6, t__8, tmp7, this__9, tmp8, ret__11, tmp9, tmp11, tmp12, tmp13, tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(m__2), A_arbace_j2g_decls_A_const_104)); var tmp16 any = A_arbace_j2g_decls_A_const_96; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp15, tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_84.GetRawRoot__O()).Invoke_O__O(m__2))); var tmp17 any; tmp29 := /*line :87:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp18 *lang.Keyword = A_arbace_j2g_decls_A_const_35; var fid__14 any = tmp18.Invoke_O__O(A_arbace_j2g_decls_A_const_90.Get__O()); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O())
		var tmp20 any = A_arbace_j2g_decls_A_const_90








		lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_90.Get__O(), A_arbace_j2g_decls_A_const_105, fid__14)))
//line :87:1
		tmp28 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var params__17 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____17 any; var tmp23 any = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_New(); var tmp24 *jrt.Class
			var fncls__9 /*line :87:1*/*jrt.Class = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_fn_class










			if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_fn_class = fncls__9d; tmp24 = fncls__9d } else { tmp24 = fncls__9 }; iter__1927001039__auto____17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); tmp22 = lang.IFn_Cast(iter__1927001039__auto____17).Invoke_O__O(A_arbace_j2g_decls_A_const_107.Invoke_O__O(ab__3)); params__17 = tmp21.Invoke_O__O(tmp22)
//line :87:1
			var body__18 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_91.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_New_O_O_O_O_O_O_O(static__10, m__2, n__1, t__8, this__9, ret__11, ab__3); var tmp27 *jrt.Class
			var fncls__10 /*line :87:1*/*jrt.Class = A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_fn_class












			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_156, false); A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_fn_class = fncls__10d; tmp27 = fncls__10d } else { tmp27 = fncls__10 }
//line :99:1
			body__18 = tmp25.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil))
//line :87:1
			tmp17 = lang.Tuple_Create_O_O__IPersistentVector(params__17, lang.IFn_Cast(A_arbace_j2g_decls_A_const_115.GetRawRoot__O()).Invoke_O_O__O(body__18, lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_51, ret__11))) }; return nil }()









		lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O()
//line :87:1
		if tmp28 != nil { panic(tmp28) } }; return nil }();



	lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if /*line :87:1*/ tmp29 != nil { panic(tmp29) }; return tmp17 }










func A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_New() *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A) Ctor() {}
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A) Invoke_O_O__O(self, s__1464000048__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_New_O_O(s__1464000048__1, self); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, false); A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :98:1
func A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A{}; t.Ctor_O_O(p0, p1); return t }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A) Ctor_O_O(c__s__1464000048, c__iter__1464000047 any) { t.F_s__1464000048 = c__s__1464000048; t.F_iter__1464000047 = c__iter__1464000047 }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A) Invoke_O__O(self any) any { { var s__1464000048__1 any; var t_ any = t.F_s__1464000048; t.F_s__1464000048 = nil; s__1464000048__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000048__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000048__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000048__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000048__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000050__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_New_O_I_O(b__1464000050__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000047); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000050__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000048__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000050__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000048__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000047); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000048__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :98:1
func A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A) Ctor_O_I_O(c__b__1464000050 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000050 = c__b__1464000050; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :98:1
func (t *A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A) Invoke_O__O(self any) any { { var i__1464000049__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000049__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000049__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000050; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__2)); i__1464000049__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000049__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_New_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6 any) *A_arbace_j2g_decls_method_code_forms_fn__1464000057_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_code_forms_fn__1464000057_A{}; t.Ctor_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :100:1
func (t *A_arbace_j2g_decls_method_code_forms_fn__1464000057_A) Ctor_O_O_O_O_O_O_O(c__static, c__m, c__n, c__t, c__this, c__ret, c__ab any) { t.F_static = c__static; t.F_m = c__m; t.F_n = c__n; t.F_t = c__t; t.F_this = c__this; t.F_ret = c__ret; t.F_ab = c__ab }
//line :100:1
func (t *A_arbace_j2g_decls_method_code_forms_fn__1464000057_A) Invoke_O__O(self any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(t.F_m), A_arbace_j2g_decls_A_const_104)) { var lk__1 any
		if jrt.J2g_Truth(t.F_static) { lk__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_110.GetRawRoot__O()).Invoke_O_O__O(t.F_n, Lit_95) } else { var or__1927000174__auto____1 any = t.F_this; if jrt.J2g_Truth(or__1927000174__auto____1) { lk__1 = or__1927000174__auto____1 } else { lk__1 = t.F_t } }
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_157), lk__1))
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_113; lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_158), lk__1))) }
	if lang.Util_Equiv_O_O__Z(Lit_51, t.F_ret) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab)) } else {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_109.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab))
		}
}



func A_arbace_j2g_decls_class_fields_A_New() *A_arbace_j2g_decls_class_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_j2g_decls_class_fields_A) Ctor() {}
//line :113:1
func (t *A_arbace_j2g_decls_class_fields_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_New(); var tmp2 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_fn_class; if
										fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_fn_class = fncls__13d; tmp2 = fncls__13d } else { tmp2 = fncls__13 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_119; return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0))) }
//line :114:1
func A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_New() *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A) Ctor() {}
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A) Invoke_O_O__O(self, s__1464000061__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_New_O_O(s__1464000061__1, self); var tmp2 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_fn_class = fncls__12d; tmp2 = fncls__12d } else { tmp2 = fncls__12 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A) Ctor_O_O(c__s__1464000061, c__iter__1464000060 any) { t.F_s__1464000061 = c__s__1464000061; t.F_iter__1464000060 = c__iter__1464000060 }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A) Invoke_O__O(self any) any { { var s__1464000061__1 any; var t_ any = t.F_s__1464000061; t.F_s__1464000061 = nil; s__1464000061__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000061__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000061__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000061__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000061__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000063__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_New_O_I_O(b__1464000063__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_fn_class = fncls__11d; tmp2 = fncls__11d } else { tmp2 = fncls__11 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000060); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000063__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000061__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000063__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000061__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000060); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(f__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000061__3))) } else { s__1464000061__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000061__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A) Ctor_O_I_O(c__b__1464000063 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000063 = c__b__1464000063; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A) Invoke_O__O(self any) any { { var i__1464000062__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000062__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000062__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2))) { lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1464000063, f__2); i__1464000062__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000062__1); continue L1 } else { i__1464000062__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000062__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_class_methods_A_New() *A_arbace_j2g_decls_class_methods_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_j2g_decls_class_methods_A) Ctor() {}
//line :118:1
func (t *A_arbace_j2g_decls_class_methods_A) Invoke_O_O__O(self, n__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_fn_class; if


	fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_fn_class = fncls__16d; tmp2 = fncls__16d } else { tmp2 = fncls__16 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_122; return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0))) }
//line :121:1
func A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_New_O(p0 any) *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A{}; t.Ctor_O(p0); return t }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A) Invoke_O_O__O(self, s__1464000072__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_New_O_O_O(t.F_n, s__1464000072__1, self); var tmp2 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_fn_class = fncls__15d; tmp2 = fncls__15d } else { tmp2 = fncls__15 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :121:1
func A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A) Ctor_O_O_O(c__n, c__s__1464000072, c__iter__1464000071 any) { t.F_n = c__n; t.F_s__1464000072 = c__s__1464000072; t.F_iter__1464000071 = c__iter__1464000071 }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A) Invoke_O__O(self any) any { { var s__1464000072__1 any; var t_ any = t.F_s__1464000072; t.F_s__1464000072 = nil; s__1464000072__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000072__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000072__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000072__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000074__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_New_O_O_I_O(t.F_n, b__1464000074__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, false); A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_fn_class = fncls__14d; tmp2 = fncls__14d } else { tmp2 = fncls__14 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000071); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000074__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000072__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000074__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_43, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4))) { var tmp4 any

	if lang.Util_Equiv_O_O__Z(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4)) {
		tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_121.GetRawRoot__O()).Invoke_O_O__O(t.F_n, mm__4)) } else {
			tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)) }
//line :121:1
	if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000071); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(mm__4, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000072__3))) } else { s__1464000072__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); continue L1 } } else { s__1464000072__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000072__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :121:1
func A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A) Ctor_O_O_I_O(c__n, c__b__1464000074 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_n = c__n; t.F_b__1464000074 = c__b__1464000074; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :121:1
func (t *A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A) Invoke_O__O(self any) any { { var i__1464000073__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000073__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000073__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_43, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2))) { var tmp2 any

	if lang.Util_Equiv_O_O__Z(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2)) {
		tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_121.GetRawRoot__O()).Invoke_O_O__O(t.F_n, mm__2)) } else {
			tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)) }
//line :121:1
	if jrt.J2g_Truth(tmp2) { lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1464000074, mm__2); i__1464000073__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000073__1); continue L1 } else { i__1464000073__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000073__1); continue L1 } } else { i__1464000073__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000073__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_body_of_A_New() *A_arbace_j2g_decls_body_of_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_body_of_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_j2g_decls_body_of_A) Ctor() {}
//line :128:1
func (t *A_arbace_j2g_decls_body_of_A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_123; var tmp2 *lang.Keyword = A_arbace_j2g_decls_A_const_81; return lang.RT_Get_O_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0)))), lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__1), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1))) }

func A_arbace_j2g_decls_reached_QMARK__A_New() *A_arbace_j2g_decls_reached_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reached_QMARK__A{}; t.Ctor(); return t }
//line :130:1
func (t *A_arbace_j2g_decls_reached_QMARK__A) Ctor() {}
//line :130:1
func (t *A_arbace_j2g_decls_reached_QMARK__A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_125.Get__O(), lang.Tuple_Create_O_O_O__IPersistentVector(n__0, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__1), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1))) }








func A_arbace_j2g_decls_super_struct_type_A_New() *A_arbace_j2g_decls_super_struct_type_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_super_struct_type_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_j2g_decls_super_struct_type_A) Ctor() {}
//line :139:1
func (t *A_arbace_j2g_decls_super_struct_type_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_126; var s__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp2 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(s__3, nil); if or__1927000174__auto____4 {



	tmp2 = or__1927000174__auto____4 } else { tmp2 = lang.Util_Equiv_O_O__Z(s__3, Lit_53) }; if tmp2 {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_252) } else {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(pkg__0, s__3) } }

func A_arbace_j2g_decls_super_iface_type_A_New() *A_arbace_j2g_decls_super_iface_type_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_super_iface_type_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_j2g_decls_super_iface_type_A) Ctor() {}
//line :147:1
func (t *A_arbace_j2g_decls_super_iface_type_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_126; var s__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1)); var tmp2 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(s__3, nil); if or__1927000174__auto____4 {

	tmp2 = or__1927000174__auto____4 } else { tmp2 = lang.Util_Equiv_O_O__Z(s__3, Lit_53) }; if tmp2 {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_13) } else {
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, s__3, Lit_18) } }

func A_arbace_j2g_decls_field_go_type_A_New() *A_arbace_j2g_decls_field_go_type_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_field_go_type_A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_j2g_decls_field_go_type_A) Ctor() {}
//line :153:1
func (t *A_arbace_j2g_decls_field_go_type_A) Invoke_O_O_O__O(self, pkg__0, f__1 any) any { var d__3 any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__1); if



	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_128.GetRawRoot__O()).Invoke_O__O(f__1)) { var G__1464000086__4_ any = d__3
		switch lang.Util_Hash_O__I(G__1464000086__4_) { case 66: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_124) { return A_arbace_j2g_decls_A_const_129 }; case 67: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_125) { return A_arbace_j2g_decls_A_const_129 }; case 68: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_126) { return A_arbace_j2g_decls_A_const_130 }; case 70: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_127) { return A_arbace_j2g_decls_A_const_131 }; case 73: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_128) { return A_arbace_j2g_decls_A_const_133 }; case 74: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_129) { return A_arbace_j2g_decls_A_const_134 }; case 83: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_130) { return A_arbace_j2g_decls_A_const_129 }; case 90: if lang.Util_Equiv_O_O__Z(G__1464000086__4_, Lit_131) { return A_arbace_j2g_decls_A_const_135 }; default:
		}

		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_132.GetRawRoot__O()).Invoke_O__O(d__3)) { var g__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__3); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_136
			return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_137.GetRawRoot__O()).Invoke_O__O(g__5)) } else {
				return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_132), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__3)) } } else {
					return lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, d__3) } }

func A_arbace_j2g_decls_extra_fields_A_New() *A_arbace_j2g_decls_extra_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_j2g_decls_extra_fields_A) Ctor() {}
//line :166:1
func (t *A_arbace_j2g_decls_extra_fields_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var d__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp2 lang.IPersistentVector; var tmp3 any; var and__1927000168__auto____4 any = A_arbace_j2g_decls_A_const_138.Invoke_O__O(d__3); if




	jrt.J2g_Truth(and__1927000168__auto____4) { tmp3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_139.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_142.Invoke_O__O(d__3)) } else { tmp3 = and__1927000168__auto____4 }; if jrt.J2g_Truth(tmp3) { tmp2 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_143.GetRawRoot__O()).Invoke_O__O(n__1))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(pkg__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_142.Invoke_O__O(d__3), nil)).Ref()))) } else { tmp2 = nil }; var tmp4 any = tmp2; var tmp5 any; var tmp6 lang.IFn = /*line :170:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_140); if


	jrt.J2g_Truth(tmp6.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__3))) { var iter__1927001039__auto____4 any; var tmp7 any = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_New_O(pkg__0); var tmp8 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_fn_class
		if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_121, false); A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_fn_class = fncls__20d; tmp8 = fncls__20d } else { tmp8 = fncls__20 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp9 *lang.Keyword = A_arbace_j2g_decls_A_const_80; tmp5 = lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__3)))) } else {
//line :173:1
			tmp5 = nil }; return /*line :170:1*/ tmp1.Invoke_O_O__O(tmp4, tmp5) }



func A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_New_O(p0 any) *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A{}; t.Ctor_O(p0); return t }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A) Invoke_O_O__O(self, s__1464000089__1 any) any { var tmp1 any = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_New_O_O_O(t.F_pkg, s__1464000089__1, self); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_122, false); A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :174:1
func A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A) Ctor_O_O_O(c__pkg, c__s__1464000089, c__iter__1464000088 any) { t.F_pkg = c__pkg; t.F_s__1464000089 = c__s__1464000089; t.F_iter__1464000088 = c__iter__1464000088 }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A) Invoke_O__O(self any) any { { var s__1464000089__1 any; var t_ any = t.F_s__1464000089; t.F_s__1464000089 = nil; s__1464000089__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000089__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000089__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000089__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000089__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000091__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_New_O_O_I_O(t.F_pkg, b__1464000091__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_123, false); A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_fn_class = fncls__18d; tmp2 = fncls__18d } else { tmp2 = fncls__18 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000088); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000091__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000089__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000091__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000089__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__4))) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1464000088); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__4))).Ref())), tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__4))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000089__3))) } else { s__1464000089__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000089__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :174:1
func A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A) Ctor_O_O_I_O(c__pkg, c__b__1464000091 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg = c__pkg; t.F_b__1464000091 = c__b__1464000091; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :174:1
func (t *A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A) Invoke_O__O(self any) any { { var i__1464000090__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000090__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000090__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000091; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__2))).Ref())), tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_decls_A_const_141.Invoke_O__O(b__2)))); i__1464000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000090__1); continue L1 } else { i__1464000090__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000090__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_iface_method_elem_A_New() *A_arbace_j2g_decls_iface_method_elem_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_iface_method_elem_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_j2g_decls_iface_method_elem_A) Ctor() {}
//line :177:1
func (t *A_arbace_j2g_decls_iface_method_elem_A) Invoke_O_O_O__O(self, pkg__0, mm__1 any) any { var vec__1464000099__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1)); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__1464000099__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__1464000099__3, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__1), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__1))); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_147.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_New_O(pkg__0); var tmp7 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_fn_class; if


	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_fn_class = fncls__21d; tmp7 = fncls__21d } else { tmp7 = fncls__21 }; return /*line :179:1*/ tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp4.Invoke_O__O(tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), ps__4)), pkg__0, r__5)) }
func A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_New_O(p0 any) *A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :180:1
func (t *A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A) Invoke_O_O_O__O(self, i__1, p__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__1)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, p__2)) }

func A_arbace_j2g_decls_interface_closure_A_New() *A_arbace_j2g_decls_interface_closure_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_interface_closure_A{}; t.Ctor(); return t }
//line :182:1
func (t *A_arbace_j2g_decls_interface_closure_A) Ctor() {}
//line :182:1
func (t *A_arbace_j2g_decls_interface_closure_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_interface_closure_fn__1464000106_A_New_O(n__0); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_j2g_decls_interface_closure_fn__1464000106_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_j2g_decls_interface_closure_fn__1464000106_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_150.GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :186:1
func A_arbace_j2g_decls_interface_closure_fn__1464000106_A_New_O(p0 any) *A_arbace_j2g_decls_interface_closure_fn__1464000106_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_interface_closure_fn__1464000106_A{}; t.Ctor_O(p0); return t }
//line :186:1
func (t *A_arbace_j2g_decls_interface_closure_fn__1464000106_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :186:1
func (t *A_arbace_j2g_decls_interface_closure_fn__1464000106_A) Invoke_O_O__O(self, p1__1464000105_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(p1__1464000105_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(p1__1464000105_SHARP___1, t.F_n) } else { return and__1927000168__auto____2 } }

func A_arbace_j2g_decls_hw_markers_A_New() *A_arbace_j2g_decls_hw_markers_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_j2g_decls_hw_markers_A) Ctor() {}
//line :188:1
func (t *A_arbace_j2g_decls_hw_markers_A) Invoke_O_O__O(self, super__0 any) any { var g__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(super__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_New(); var tmp4 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_fn_class; if



	fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_fn_class = fncls__25d; tmp4 = fncls__25d } else { tmp4 = fncls__25 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp5 *lang.Keyword = A_arbace_j2g_decls_A_const_157; tmp2 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_156.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O__O(A_arbace_j2g_decls_A_const_158.Get__O()), g__2)); return tmp1.Invoke_O__O(tmp2) }
//line :192:1
func A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_New() *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A) Ctor() {}
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A) Invoke_O_O__O(self, s__1464000110__1 any) any { var tmp1 any = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_New_O_O(self, s__1464000110__1); var tmp2 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_137, false); A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_fn_class = fncls__24d; tmp2 = fncls__24d } else { tmp2 = fncls__24 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :192:1
func A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A{}; t.Ctor_O_O(p0, p1); return t }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A) Ctor_O_O(c__iter__1464000109, c__s__1464000110 any) { t.F_iter__1464000109 = c__iter__1464000109; t.F_s__1464000110 = c__s__1464000110 }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A) Invoke_O__O(self any) any { { var s__1464000110__1 any; var t_ any = t.F_s__1464000110; t.F_s__1464000110 = nil; s__1464000110__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000110__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000110__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000110__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000110__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000112__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000112__6); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, false); A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000109); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000112__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000110__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000112__6), nil) } } else { var mn__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000110__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_153.GetRawRoot__O()).Invoke_O_O__O(mn__4, Lit_15)) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000109); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_154.GetRawRoot__O()).Invoke_O_O__O(mn__4, A_arbace_j2g_decls_A_const_155), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000110__3))) } else { s__1464000110__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000110__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :192:1
func A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000112 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000112 = c__b__1464000112 }
//line :192:1
func (t *A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A) Invoke_O__O(self any) any { { var i__1464000111__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000111__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000111__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_153.GetRawRoot__O()).Invoke_O_O__O(mn__2, Lit_15)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000112; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_154.GetRawRoot__O()).Invoke_O_O__O(mn__2, A_arbace_j2g_decls_A_const_155)); i__1464000111__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000111__1); continue L1 } else { i__1464000111__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000111__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_markers_A_New() *A_arbace_j2g_decls_markers_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_markers_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_j2g_decls_markers_A) Ctor() {}
//line :194:1
func (t *A_arbace_j2g_decls_markers_A) Invoke_O_O__O(self, n__0 any) any { var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_126; var s__2 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0)); var sup_marked__3 any; var tmp2 bool; var or__1927000174__auto____3 bool = lang.Util_Identical_O_O__Z(s__2, nil); if or__1927000174__auto____3 {




	tmp2 = or__1927000174__auto____3 } else { tmp2 = lang.Util_Equiv_O_O__Z(s__2, Lit_53) }; if tmp2 { lang.PersistentHashSet_Init(); sup_marked__3 = lang.PersistentHashSet_EMPTY.Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(s__2)) {
		sup_marked__3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_151.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(s__2))) } else {
//line :199:1
			if A_arbace_j2g_decls_A_const_160 != nil {

				sup_marked__3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_161.GetRawRoot__O()).Invoke_O__O(s__2) } else {
//line :199:1
					sup_marked__3 = nil } } }; var tmp3 lang.IFn =


	lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_markers_fn__1464000121_A_New_O(sup_marked__3); var tmp5 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_j2g_decls_markers_fn__1464000121_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_j2g_decls_markers_fn__1464000121_A_fn_class = fncls__26d; tmp5 = fncls__26d } else { tmp5 = fncls__26 }; return tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0)) }
//line :202:1
func A_arbace_j2g_decls_markers_fn__1464000121_A_New_O(p0 any) *A_arbace_j2g_decls_markers_fn__1464000121_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_markers_fn__1464000121_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_j2g_decls_markers_fn__1464000121_A) Ctor_O(c__sup_marked any) { t.F_sup_marked = c__sup_marked }
//line :202:1
func (t *A_arbace_j2g_decls_markers_fn__1464000121_A) Invoke_O_O__O(self, p1__1464000120_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()); var tmp2 any = t.F_sup_marked; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(p1__1464000120_SHARP___1)) }




func A_arbace_j2g_decls_ctor_desc_A_New() *A_arbace_j2g_decls_ctor_desc_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_desc_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_j2g_decls_ctor_desc_A) Ctor() {}
//line :207:1
func (t *A_arbace_j2g_decls_ctor_desc_A) Invoke_O_O_O__O(self, n__0, mm__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_121.GetRawRoot__O()).Invoke_O_O__O(n__0, mm__1) }

func A_arbace_j2g_decls_ctor_call_translator_A_New() *A_arbace_j2g_decls_ctor_call_translator_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_A{}; t.Ctor(); return t }
//line :209:1
func (t *A_arbace_j2g_decls_ctor_call_translator_A) Ctor() {}
//line :209:1
func (t *A_arbace_j2g_decls_ctor_call_translator_A) Invoke_O_O_O_O__O(self, pkg__0, n__1, info__2 any) any {



	var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_New_O_O(info__2, n__1); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil) }
//line :213:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A) Ctor_O_O(c__info, c__n any) { t.F_info = c__info; t.F_n = c__n }
//line :213:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A) Invoke_O_O__O(self, node__1 any) any { var d__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(t.F_n); var leaf__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(t.F_n); var thisx__4 any; _ = thisx__4; if


	jrt.J2g_Truth(leaf__3) { thisx__4 = A_arbace_j2g_decls_A_const_165 } else { thisx__4 = A_arbace_j2g_decls_A_const_166 }; var kind__5 any = /*line :213:1*/A_arbace_j2g_decls_A_const_167.Invoke_O__O(node__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_168.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_fn_class; if






	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; var tmp4 /*line :218:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_118; if jrt.J2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_185.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1))))) {


		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_186.GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_49, nil, nil, Lit_50); var tmp8 any; var or__1927000174__auto____10 any = A_arbace_j2g_decls_A_const_34.Invoke_O__O(node__1); if jrt.J2g_Truth(or__1927000174__auto____10) { tmp8 = or__1927000174__auto____10 } else { tmp8 = t.F_n }; var tmp9 *lang.Keyword = A_arbace_j2g_decls_A_const_118; return tmp5.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, tmp8, tmp9.Invoke_O__O(A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1)), nil)).Ref(), Lit_51)) } else {
//line :218:1
			if lang.Util_Equiv_O_O__Z(kind__5, A_arbace_j2g_decls_A_const_87) { var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_169.GetRawRoot__O()); var tmp11 any = t.F_n; var real__6 any = tmp10.Invoke_O_O__O(tmp11, A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1)); var base__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_170.GetRawRoot__O()).Invoke_O__O(real__6); var extra__8 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp13 lang.IPersistentVector








				if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_138.Invoke_O__O(d__2)) { tmp13 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_191.Invoke_O__O(t.F_info)) } else { tmp13 = nil }; var tmp14 any = tmp13; var tmp15 lang.IPersistentVector
				if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_187.Invoke_O__O(d__2)) { tmp15 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_192.Invoke_O__O(t.F_info)) } else { tmp15 = nil }
//line :227:1
				var tmp16 any = tmp15; var tmp17 any; var tmp18 any; var tmp19 any = A_arbace_j2g_decls_A_const_188; var or__1927000174__auto____8 bool = lang.Util_Equiv_O_O__Z(tmp19, A_arbace_j2g_decls_A_const_167.Invoke_O__O(d__2))

				if or__1927000174__auto____8 { tmp18 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { tmp18 = A_arbace_j2g_decls_A_const_189.Invoke_O__O(d__2) }; if jrt.J2g_Truth(tmp18) { tmp17 = A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info) } else { tmp17 = nil }
//line :227:1
				extra__8 = tmp12.Invoke_O_O_O__O(tmp14, tmp16, tmp17)
//line :218:1
				var tmp20 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var vec__1464000129__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(tmp20.Invoke_O__O(A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1))); var ps__10 any = lang.RT_Nth_O_I_O__O(vec__1464000129__9, lang.RT_IntCast_J__I(0), nil); var ___11 any = lang.RT_Nth_O_I_O__O(vec__1464000129__9, lang.RT_IntCast_J__I(1), nil); var args__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_171.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_193.Invoke_O__O(node__1), ps__10); var caps__13 any; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_172); _ = ___11













				if jrt.J2g_Truth(tmp21.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__2))) { var iter__1927001039__auto____13 any; var tmp22 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_New_O(t.F_info); var tmp23 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_fn_class
					if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_fn_class = fncls__29d; tmp23 = fncls__29d } else { tmp23 = fncls__29 }; iter__1927001039__auto____13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var tmp24 *lang.Keyword = A_arbace_j2g_decls_A_const_80; caps__13 = lang.IFn_Cast(iter__1927001039__auto____13).Invoke_O__O(tmp24.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__2)))) } else {
//line :232:1
						caps__13 = nil
					}
				var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp28 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__7)).Ref()); var tmp29 any = A_arbace_j2g_decls_A_const_195; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp31 any
				if jrt.J2g_Truth(leaf__3) { tmp31 = nil } else { tmp31 = A_arbace_j2g_decls_A_const_196 }
//line :234:1
				return tmp25.Invoke_O__O(tmp26.Invoke_O_O_O_O__O(tmp27, tmp28, tmp29, tmp30.Invoke_O_O_O_O__O(tmp31, extra__8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_180, args__12), caps__13))) } else {
//line :218:1
					if A_arbace_j2g_decls_A_const_160 != nil { var sup__6 any = A_arbace_j2g_decls_A_const_34.Invoke_O__O(node__1); var tmp32 bool; var or__1927000174__auto____7 bool = lang.Util_Identical_O_O__Z(sup__6, nil)




















						if or__1927000174__auto____7 { tmp32 = or__1927000174__auto____7 } else { tmp32 = lang.Util_Equiv_O_O__Z(sup__6, Lit_53) }
//line :238:1
						if tmp32 { return nil } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_139.GetRawRoot__O()).Invoke_O__O(sup__6))) {

							return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_186.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_54, nil), jrt.RefArrayOf(jrt.Object_class, nil, sup__6)).Ref(), Lit_51)) } else {
//line :238:1
								if A_arbace_j2g_decls_A_const_160 != nil { var ss__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(sup__6))).Ref()), A_arbace_j2g_decls_A_const_197); var sctor__8 any = A_arbace_j2g_decls_A_const_174.Invoke_O__O(node__1); var real__9 any





									if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(sup__6)) { real__9 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_169.GetRawRoot__O()).Invoke_O_O__O(sup__6, sctor__8) } else { real__9 = A_arbace_j2g_decls_A_const_118.Invoke_O__O(sctor__8) }
//line :238:1
									var base__10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_170.GetRawRoot__O()).Invoke_O__O(real__9); var sd__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(sup__6); var thisv__12 any








									if jrt.J2g_Truth(leaf__3) { thisv__12 = A_arbace_j2g_decls_A_const_175 } else { thisv__12 = A_arbace_j2g_decls_A_const_176 }
									if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_177.Invoke_O__O(node__1)) {

										return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref()), ss__7, thisv__12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info)))) } else {
//line :248:1
											if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_178.Invoke_O__O(node__1)) {



												var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp36 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref()); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp38 lang.IPersistentVector
												if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_187.Invoke_O__O(d__2)) { tmp38 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_192.Invoke_O__O(t.F_info)) } else { tmp38 = nil }
//line :252:1
												var tmp39 any = tmp38; var tmp40 lang.IPersistentVector

												if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_198.Invoke_O__O(d__2)) { tmp40 = lang.Tuple_Create_O__IPersistentVector(A_arbace_j2g_decls_A_const_191.Invoke_O__O(t.F_info)) } else { tmp40 = nil }
//line :252:1
												var tmp41 any = tmp40; var tmp42 lang.IPersistentVector; var temp__1927000414__auto____13 any = A_arbace_j2g_decls_A_const_199.Invoke_O__O(d__2)


												if jrt.J2g_Truth(temp__1927000414__auto____13) { var p__14 any = temp__1927000414__auto____13; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_New(); var tmp45 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_fn_class
													if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_fn_class = fncls__34d; tmp45 = fncls__34d } else { tmp45 = fncls__34 }
//line :255:1
													tmp42 = lang.Tuple_Create_O__IPersistentVector(tmp43.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp44, tmp45, nil), A_arbace_j2g_decls_A_const_191.Invoke_O__O(t.F_info), p__14)) } else { tmp42 = nil }
//line :252:1
												var tmp46 any = tmp42; var tmp47 any





												if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_189.Invoke_O__O(d__2)) { tmp47 = A_arbace_j2g_decls_A_const_190.Invoke_O__O(t.F_info) } else { tmp47 = nil }
//line :252:1
												var tmp48 any = tmp47; var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp50 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_New(); var tmp51 *jrt.Class
												var fncls__35 /*line :252:1*/*jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_fn_class






												if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_fn_class = fncls__35d; tmp51 = fncls__35d } else { tmp51 = fncls__35 }
//line :252:1
												return tmp33.Invoke_O__O(tmp34.Invoke_O_O_O_O_O__O(tmp35, tmp36, ss__7, thisv__12, tmp37.Invoke_O_O_O_O_O__O(tmp39, tmp41, tmp46, tmp48, tmp49.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil), A_arbace_j2g_decls_A_const_107.Invoke_O__O(t.F_info))))) } else {
//line :248:1
													if A_arbace_j2g_decls_A_const_160 != nil { var vec__1464000146__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(sctor__8)); var ps__14 any = lang.RT_Nth_O_I_O__O(vec__1464000146__13, lang.RT_IntCast_J__I(0), nil); var ___15 any = lang.RT_Nth_O_I_O__O(vec__1464000146__13, lang.RT_IntCast_J__I(1), nil); var lead__16 any; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp53 lang.IPersistentVector; var tmp54 any; var and__1927000168__auto____16 any = sd__11; _ = ___15













														if jrt.J2g_Truth(and__1927000168__auto____16) { tmp54 = A_arbace_j2g_decls_A_const_138.Invoke_O__O(sd__11) } else { tmp54 = and__1927000168__auto____16 }; if jrt.J2g_Truth(tmp54) { tmp53 = lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_142.Invoke_O__O(node__1), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_142.Invoke_O__O(sd__11), nil)).Ref())) } else { tmp53 = nil }; lead__16 = tmp52.Invoke_O__O(tmp53)
//line :248:1
														var vals__17 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_171.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_31.GetRawRoot__O(), lead__16), A_arbace_j2g_decls_A_const_193.Invoke_O__O(node__1)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_137.GetRawRoot__O(), lead__16), ps__14)); var caps__18 any; var tmp55 any
														var and__1927000168__auto____18 any = sd__11














														if jrt.J2g_Truth(and__1927000168__auto____18) { var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_179); tmp55 = tmp56.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(sd__11)) } else { tmp55 = and__1927000168__auto____18 }; if jrt.J2g_Truth(tmp55) { var iter__1927001039__auto____18 any; var tmp57 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_New(); var tmp58 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_fn_class
															if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_fn_class = fncls__32d; tmp58 = fncls__32d } else { tmp58 = fncls__32 }; iter__1927001039__auto____18 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp57, tmp58, nil); var tmp59 *lang.Keyword = A_arbace_j2g_decls_A_const_80; caps__18 = lang.IFn_Cast(iter__1927001039__auto____18).Invoke_O__O(tmp59.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(sd__11)))) } else {
//line :264:1
																caps__18 = nil
															}
														return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__10)).Ref()), ss__7, thisv__12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_180, vals__17), caps__18))) } else {
//line :248:1
															return nil } } } } else {
//line :238:1
																return nil } } } } else {
//line :218:1
																	return nil } } } }

func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A) Ctor() {}
//line :220:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A) Invoke_O_O__O(self, p1__1464000125_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_139.GetRawRoot__O()).Invoke_O__O(p1__1464000125_SHARP___1)) }












func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_New_O(p0 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A{}; t.Ctor_O(p0); return t }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A) Ctor_O(c__info any) { t.F_info = c__info }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A) Invoke_O_O__O(self, s__1464000133__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_New_O_O_O(t.F_info, s__1464000133__1, self); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :233:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A) Ctor_O_O_O(c__info, c__s__1464000133, c__iter__1464000132 any) { t.F_info = c__info; t.F_s__1464000133 = c__s__1464000133; t.F_iter__1464000132 = c__iter__1464000132 }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A) Invoke_O__O(self any) any { { var s__1464000133__1 any; var t_ any = t.F_s__1464000133; t.F_s__1464000133 = nil; s__1464000133__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000133__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000133__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000133__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000133__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000135__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_New_O_O_I_O(b__1464000135__6, t.F_info, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000132); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000135__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000133__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000135__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000133__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000132); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Get_O_O__O(A_arbace_j2g_decls_A_const_173.Invoke_O__O(t.F_info), A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000133__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :233:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A) Ctor_O_O_I_O(c__b__1464000135, c__info any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000135 = c__b__1464000135; t.F_info = c__info; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :233:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A) Invoke_O__O(self any) any { { var i__1464000134__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000134__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000134__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000135; tmp2.Invoke_O_O__O(tmp3, lang.RT_Get_O_O__O(A_arbace_j2g_decls_A_const_173.Invoke_O__O(t.F_info), A_arbace_j2g_decls_A_const_71.Invoke_O__O(b__2))); i__1464000134__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000134__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






















func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A) Ctor() {}
//line :256:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A) Invoke_O_O_O__O(self, x__1, cl__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_143.GetRawRoot__O()).Invoke_O__O(cl__2)))).Ref()), x__1) }


func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A{}; t.Ctor(); return t }
//line :259:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A) Ctor() {}
//line :259:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A) Invoke_O_O__O(self, b__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_201.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__1)) }





func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_New() *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A{}; t.Ctor(); return t }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A) Ctor() {}
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A) Invoke_O_O__O(self, s__1464000150__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_New_O_O(s__1464000150__1, self); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :265:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A{}; t.Ctor_O_O(p0, p1); return t }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A) Ctor_O_O(c__s__1464000150, c__iter__1464000149 any) { t.F_s__1464000150 = c__s__1464000150; t.F_iter__1464000149 = c__iter__1464000149 }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A) Invoke_O__O(self any) any { { var s__1464000150__1 any; var t_ any = t.F_s__1464000150; t.F_s__1464000150 = nil; s__1464000150__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000150__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000150__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000150__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000150__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000152__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_New_O_I_O(b__1464000152__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000149); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000152__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000150__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000152__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000150__3); var tmp4 *lang.Keyword = A_arbace_j2g_decls_A_const_180; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000149); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_182, A_arbace_j2g_decls_A_const_183, A_arbace_j2g_decls_A_const_184, b__4)))), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000150__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :265:1
func A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A) Ctor_O_I_O(c__b__1464000152 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000152 = c__b__1464000152; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :265:1
func (t *A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A) Invoke_O__O(self any) any { { var i__1464000151__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000151__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000151__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000152; var tmp4 *lang.Keyword = A_arbace_j2g_decls_A_const_180; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_181.GetRawRoot__O()).Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_182, A_arbace_j2g_decls_A_const_183, A_arbace_j2g_decls_A_const_184, b__2))))); i__1464000151__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000151__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_ctor_forms_A_New() *A_arbace_j2g_decls_ctor_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_A{}; t.Ctor(); return t }
//line :268:1
func (t *A_arbace_j2g_decls_ctor_forms_A) Ctor() {}
//line :268:1
func (t *A_arbace_j2g_decls_ctor_forms_A) Invoke_O_O_O_O__O(self, pkg__0, n__1, mm__2 any) any { var d__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var g__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var leaf__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1); var real__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_169.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var vec__1464000162__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(real__7); var rps__9 any = lang.RT_Nth_O_I_O__O(vec__1464000162__8, lang.RT_IntCast_J__I(0), nil); var ___10 any = lang.RT_Nth_O_I_O__O(vec__1464000162__8, lang.RT_IntCast_J__I(1), nil); var base__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_170.GetRawRoot__O()).Invoke_O__O(real__7); var ab__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_202.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var reached__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_203.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var st__14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__4)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_86; var tmp6 any = A_arbace_j2g_decls_A_const_233; var tmp7 any = A_arbace_j2g_decls_A_const_87; var tmp8 any; _ = ___10; if












	jrt.J2g_Truth(leaf__6) { tmp8 = A_arbace_j2g_decls_A_const_234 } else { tmp8 = A_arbace_j2g_decls_A_const_235 }; var tmp9 any = tmp8; var tmp10 any = A_arbace_j2g_decls_A_const_97; var tmp11 any = A_arbace_j2g_decls_A_const_174; var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_TRUE; var tmp13 any = tmp4.Invoke_O_O_O_O_O_O_O_O_O_O_O_O__O(pkg__0, n__1, tmp5, tmp6, tmp7, tmp9, tmp10, Lit_51, tmp11, tmp12.Ref(), A_arbace_j2g_decls_A_const_99, Lit_27); var tmp14 any = A_arbace_j2g_decls_A_const_96; tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp13, tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_84.GetRawRoot__O()).Invoke_O__O(mm__2))); var tmp15 any; tmp104 := /*line :268:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp16 *lang.Keyword = A_arbace_j2g_decls_A_const_35; var fid__17 any = tmp16.Invoke_O__O(A_arbace_j2g_decls_A_const_90.Get__O()); var outer_p__18 any















		if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_138.Invoke_O__O(d__4)) { outer_p__18 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_64) } else { outer_p__18 = nil }
//line :268:1
		var so_p__19 any
















		if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_187.Invoke_O__O(d__4)) { so_p__19 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_65) } else { so_p__19 = nil }
//line :268:1
		var enum_ps__20 any; var tmp17 any; var tmp18 any = A_arbace_j2g_decls_A_const_188; var or__1927000174__auto____20 bool = lang.Util_Equiv_O_O__Z(tmp18, A_arbace_j2g_decls_A_const_167.Invoke_O__O(d__4))

















		if or__1927000174__auto____20 { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____20).Ref() } else { tmp17 = A_arbace_j2g_decls_A_const_189.Invoke_O__O(d__4) }; if jrt.J2g_Truth(tmp17) { enum_ps__20 = lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_66), lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(Lit_67)) } else { enum_ps__20 = nil }
//line :268:1
		var params__21 any; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp20 any; var iter__1927001039__auto____21 any; var tmp21 any = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_New(); var tmp22 *jrt.Class
		var fncls__42 /*line :268:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_fn_class


















		if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_fn_class = fncls__42d; tmp22 = fncls__42d } else { tmp22 = fncls__42 }; iter__1927001039__auto____21 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil); tmp20 = lang.IFn_Cast(iter__1927001039__auto____21).Invoke_O__O(A_arbace_j2g_decls_A_const_107.Invoke_O__O(ab__12)); params__21 = tmp19.Invoke_O__O(tmp20)
//line :268:1
		var params__22 any; var tmp23 any; var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_205.GetRawRoot__O()).Invoke_O__O(params__21)



















		if jrt.J2g_Truth(and__1927000168__auto____22) { var and__1927000168__auto____23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_107.Invoke_O__O(mm__2)); if jrt.J2g_Truth(and__1927000168__auto____23) { tmp23 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(ab__12) } else { tmp23 = and__1927000168__auto____23 } } else { tmp23 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp23) {
			var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp25 any; var iter__1927001039__auto____22 any; var tmp26 any = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_New(); var tmp27 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_fn_class = fncls__45d; tmp27 = fncls__45d } else { tmp27 = fncls__45 }; iter__1927001039__auto____22 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); tmp25 = lang.IFn_Cast(iter__1927001039__auto____22).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_j2g_decls_A_const_107.Invoke_O__O(mm__2))).Ref())); params__22 = tmp24.Invoke_O__O(tmp25) } else {
//line :288:1
				params__22 = params__21 }
//line :268:1
		var caps__23 any; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_206)






















		if jrt.J2g_Truth(tmp28.Invoke_O__O(A_arbace_j2g_decls_A_const_66.Invoke_O__O(d__4))) { caps__23 = A_arbace_j2g_decls_A_const_80.Invoke_O__O(st__14) } else { caps__23 = nil }
//line :268:1
		var cap_ps__24 any; var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp30 any; var iter__1927001039__auto____24 any; var tmp31 any = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_New(); var tmp32 *jrt.Class
		var fncls__48 /*line :268:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_fn_class























		if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_fn_class = fncls__48d; tmp32 = fncls__48d } else { tmp32 = fncls__48 }; iter__1927001039__auto____24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil); tmp30 = lang.IFn_Cast(iter__1927001039__auto____24).Invoke_O__O(caps__23); cap_ps__24 = tmp29.Invoke_O__O(tmp30)
//line :268:1
		var all_ps__25 any; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp35 lang.IPersistentVector
























		if jrt.J2g_Truth(outer_p__18) { tmp35 = lang.Tuple_Create_O__IPersistentVector(outer_p__18) } else { tmp35 = nil }; var tmp36 any = tmp35; var tmp37 lang.IPersistentVector; if jrt.J2g_Truth(so_p__19) { tmp37 = lang.Tuple_Create_O__IPersistentVector(so_p__19) } else { tmp37 = nil }; all_ps__25 = tmp33.Invoke_O__O(tmp34.Invoke_O_O_O_O_O__O(tmp36, tmp37, enum_ps__20, params__22, cap_ps__24))
//line :268:1
		var tmp38 any = A_arbace_j2g_decls_A_const_191; var tmp39 any = A_arbace_j2g_decls_A_const_192; var tmp40 any = A_arbace_j2g_decls_A_const_190; var tmp41 any = A_arbace_j2g_decls_A_const_107; var tmp42 any = A_arbace_j2g_decls_A_const_107.Invoke_O__O(ab__12); var tmp43 any = A_arbace_j2g_decls_A_const_173; var info__26 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp38, outer_p__18, tmp39, so_p__19, tmp40, enum_ps__20, tmp41, tmp42, tmp43, lang.IFn_Cast(A_arbace_j2g_decls_A_const_207.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_71, caps__23), cap_ps__24))); var body__27 any; var tmp44 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp45 any = A_arbace_j2g_decls_A_const_90; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_decls_A_const_90.Get__O(); var tmp48 any = A_arbace_j2g_decls_A_const_105; var tmp49 any = A_arbace_j2g_decls_A_const_191; var tmp50 any = A_arbace_j2g_decls_A_const_238; var tmp51 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_222.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, n__1, info__26)
		var tmp52 any = A_arbace_j2g_decls_A_const_39


























		lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp44.Invoke_O_O__O(tmp45, tmp46.Invoke_O_O_O_O_O_O_O_O_O__O(tmp47, tmp48, fid__17, tmp49, outer_p__18, tmp50, tmp51, tmp52, lang.IFn_Cast(A_arbace_j2g_decls_A_const_207.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_71, caps__23), cap_ps__24)))); var tmp53 any = A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_New_O_O_O_O_O_O_O_O_O_O_O_O(d__4, reached__13, all_ps__25, caps__23, pkg__0, n__1, st__14, info__26, ab__12, cap_ps__24, outer_p__18, mm__2); var tmp54 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_fn_class = fncls__39d; tmp54 = fncls__39d } else { tmp54 = fncls__39 }; body__27 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O()
//line :268:1
		var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp56 any = A_arbace_j2g_decls_A_const_239; var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp58 any = A_arbace_j2g_decls_A_const_240; var recv__28 any = tmp55.Invoke_O_O__O(tmp56, tmp57.Invoke_O_O__O(tmp58, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__5))); var ctor_form__29 any; var tmp59 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp60 any = A_arbace_j2g_decls_A_const_241; var tmp61 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(base__11); var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp64 any = lang.Tuple_Create_O__IPersistentVector(recv__28); var tmp65 lang.IPersistentVector

































































		if jrt.J2g_Truth(leaf__6) { tmp65 = nil } else { var tmp66 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp67 any = A_arbace_j2g_decls_A_const_243; tmp65 = lang.Tuple_Create_O__IPersistentVector(tmp66.Invoke_O_O__O(tmp67, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__5, nil)).Ref()))) }
//line :333:1
		ctor_form__29 = tmp59.Invoke_O_O_O_O__O(tmp60, tmp61, tmp62.Invoke_O__O(tmp63.Invoke_O_O_O__O(tmp64, tmp65, lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, rps__9, all_ps__25))), body__27)
//line :268:1
		var new_ps__30 any; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp69 any; var iter__1927001039__auto____30 any; var tmp70 any = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_New_O_O(pkg__0, rps__9); var tmp71 *jrt.Class
		var fncls__51 /*line :268:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_fn_class




































































		if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_fn_class = fncls__51d; tmp71 = fncls__51d } else { tmp71 = fncls__51 }; iter__1927001039__auto____30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp70, tmp71, nil); tmp69 = lang.IFn_Cast(iter__1927001039__auto____30).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(rps__9)).Ref())); new_ps__30 = tmp68.Invoke_O__O(tmp69)
//line :268:1
		var new_form__31 any; var tmp72 any; var or__1927000174__auto____31 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(d__4), A_arbace_j2g_decls_A_const_244)





































































		if jrt.J2g_Truth(or__1927000174__auto____31) { tmp72 = or__1927000174__auto____31 } else { tmp72 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1) }; if jrt.J2g_Truth(tmp72) { new_form__31 = nil } else {
			var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_decls_A_const_245; var tmp75 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_246.GetRawRoot__O()).Invoke_O_O__O(g__5, real__7)); var tmp76 any = A_arbace_j2g_decls_A_const_18; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp78 any = A_arbace_j2g_decls_A_const_247; var tmp79 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(new_ps__30, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp77.Invoke_O_O__O(tmp78, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__5))))); var tmp80 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp81 lang.IPersistentVector


			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp81 = nil } else { tmp81 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, g__5, nil)).Ref()))) }
//line :339:1
			var tmp82 any = tmp81; var tmp83 lang.IPersistentVector; var top__31 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_249.GetRawRoot__O()).Invoke_O__O(n__1); var tmp84 any; var and__1927000168__auto____32 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__1)






			if jrt.J2g_Truth(and__1927000168__auto____32) { var and__1927000168__auto____33 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(top__31, n__1); if jrt.J2g_Truth(and__1927000168__auto____33) { var and__1927000168__auto____34 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(top__31); if jrt.J2g_Truth(and__1927000168__auto____34) { tmp84 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(top__31)) } else { tmp84 = and__1927000168__auto____34 } } else { tmp84 = and__1927000168__auto____33 } } else { tmp84 = and__1927000168__auto____32 }; if jrt.J2g_Truth(tmp84) { tmp83 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, top__31, Lit_73))) } else { tmp83 = nil }
//line :339:1
			var tmp85 any = tmp83; var tmp86 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp87 any = A_arbace_j2g_decls_A_const_251; var tmp88 any = A_arbace_j2g_decls_A_const_253; var tmp89 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp90 any = A_arbace_j2g_decls_A_const_254; var tmp91 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp92 any = A_arbace_j2g_decls_A_const_255; var tmp93 any = lang.Tuple_Create_O_O__IPersistentVector(tmp88, tmp89.Invoke_O_O__O(tmp90, tmp91.Invoke_O_O__O(tmp92, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__5)))); var tmp94 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp95 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp96 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__11)).Ref()); var tmp97 any = A_arbace_j2g_decls_A_const_256; var tmp98 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp99 any









			if jrt.J2g_Truth(leaf__6) { tmp99 = nil } else { tmp99 = A_arbace_j2g_decls_A_const_257 }
//line :339:1
			var tmp100 any = tmp99; var tmp101 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp102 any = A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_New(); var tmp103 *jrt.Class
			var fncls__52 /*line :339:1*/*jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_fn_class









			if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_fn_class = fncls__52d; tmp103 = fncls__52d } else { tmp103 = fncls__52 }
//line :339:1
			new_form__31 = tmp73.Invoke_O_O_O_O__O(tmp74, tmp75, tmp79, tmp80.Invoke_O_O_O__O(tmp82, tmp85, lang.Tuple_Create_O__IPersistentVector(tmp86.Invoke_O_O_O_O__O(tmp87, tmp93, tmp94.Invoke_O_O_O_O__O(tmp95, tmp96, tmp97, tmp98.Invoke_O_O__O(tmp100, tmp101.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp102, tmp103, nil), new_ps__30))), A_arbace_j2g_decls_A_const_252))))
		}










		tmp15 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_232.GetRawRoot__O()).Invoke_O_O__O(mm__2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_259.GetRawRoot__O(), lang.Tuple_Create_O_O__IPersistentVector(new_form__31, ctor_form__29))) }; return nil }(); /*line :281:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if /*line :268:1*/ tmp104 != nil { panic(tmp104) }; return tmp15 }


















func A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_New() *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A{}; t.Ctor(); return t }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A) Ctor() {}
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A) Invoke_O_O__O(self, s__1464000166__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_New_O_O(s__1464000166__1, self); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :287:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A{}; t.Ctor_O_O(p0, p1); return t }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A) Ctor_O_O(c__s__1464000166, c__iter__1464000165 any) { t.F_s__1464000166 = c__s__1464000166; t.F_iter__1464000165 = c__iter__1464000165 }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A) Invoke_O__O(self any) any { { var s__1464000166__1 any; var t_ any = t.F_s__1464000166; t.F_s__1464000166 = nil; s__1464000166__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000166__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000166__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000166__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000166__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000168__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_New_O_I_O(b__1464000168__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_fn_class = fncls__40d; tmp2 = fncls__40d } else { tmp2 = fncls__40 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000165); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000168__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000166__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000168__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000166__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000165); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000166__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :287:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A) Ctor_O_I_O(c__b__1464000168 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000168 = c__b__1464000168; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :287:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A) Invoke_O__O(self any) any { { var i__1464000167__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000167__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000167__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000168; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__2)); i__1464000167__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000167__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_New() *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A{}; t.Ctor(); return t }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A) Ctor() {}
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A) Invoke_O_O__O(self, s__1464000176__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_New_O_O(s__1464000176__1, self); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :289:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A{}; t.Ctor_O_O(p0, p1); return t }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A) Ctor_O_O(c__s__1464000176, c__iter__1464000175 any) { t.F_s__1464000176 = c__s__1464000176; t.F_iter__1464000175 = c__iter__1464000175 }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A) Invoke_O__O(self any) any { { var s__1464000176__1 any; var t_ any = t.F_s__1464000176; t.F_s__1464000176 = nil; s__1464000176__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000176__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000176__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000176__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000176__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000178__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000178__6); var tmp2 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_fn_class = fncls__43d; tmp2 = fncls__43d } else { tmp2 = fncls__43 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000175); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000178__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000176__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000178__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000176__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000175); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_83, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000176__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :289:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000178 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000178 = c__b__1464000178 }
//line :289:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A) Invoke_O__O(self any) any { { var i__1464000177__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000177__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000177__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000178; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_83, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000177__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000177__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_New() *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A{}; t.Ctor(); return t }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A) Ctor() {}
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A) Invoke_O_O__O(self, s__1464000186__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_New_O_O(s__1464000186__1, self); var tmp2 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_fn_class = fncls__47d; tmp2 = fncls__47d } else { tmp2 = fncls__47 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :292:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A{}; t.Ctor_O_O(p0, p1); return t }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A) Ctor_O_O(c__s__1464000186, c__iter__1464000185 any) { t.F_s__1464000186 = c__s__1464000186; t.F_iter__1464000185 = c__iter__1464000185 }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A) Invoke_O__O(self any) any { { var s__1464000186__1 any; var t_ any = t.F_s__1464000186; t.F_s__1464000186 = nil; s__1464000186__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000186__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000186__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000186__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000186__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000188__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_New_I_O_O(size__1927001038__auto____5, b__1464000188__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_85, false); A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000185); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000188__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000186__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000188__6), nil) } } else { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000186__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000185); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_86, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__4)))).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000186__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :292:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000188, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000188 = c__b__1464000188; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :292:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A) Invoke_O__O(self any) any { { var i__1464000187__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000187__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var b__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000187__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000188; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_204.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_86, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__2)))).Ref())); i__1464000187__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000187__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_New_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11 any) *A_arbace_j2g_decls_ctor_forms_fn__1464000195_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000195_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11); return t }
//line :296:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_A) Ctor_O_O_O_O_O_O_O_O_O_O_O_O(c__d, c__reached, c__all_ps, c__caps, c__pkg, c__n, c__st, c__info, c__ab, c__cap_ps, c__outer_p, c__mm any) { t.F_d = c__d; t.F_reached = c__reached; t.F_all_ps = c__all_ps; t.F_caps = c__caps; t.F_pkg = c__pkg; t.F_n = c__n; t.F_st = c__st; t.F_info = c__info; t.F_ab = c__ab; t.F_cap_ps = c__cap_ps; t.F_outer_p = c__outer_p; t.F_mm = c__mm }
//line :296:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp3 any; var or__1927000174__auto____3 any; var t_ any = t.F_reached; t.F_reached = nil; or__1927000174__auto____3 = t_; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { var or__1927000174__auto____4 any = A_arbace_j2g_decls_A_const_209.Invoke_O__O(t.F_mm); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp3 = or__1927000174__auto____4 } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t.F_ab, nil)).Ref() } }; if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_n; t.F_n = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp8 any; var t__3 any = t.F_mm; t.F_mm = nil; tmp8 = t__3; tmp1 = tmp4.Invoke_O_O_O__O(tmp6, Lit_27, tmp7.Invoke_O__O(tmp8)) } else {
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_91.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_New_O_O_O_O_O_O_O_O_O_O_O(t.F_d, t.F_all_ps, t.F_caps, t.F_pkg, t.F_n, t.F_st, t.F_info, t.F_ab, t.F_cap_ps, t.F_outer_p, t.F_mm); var tmp11 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_fn_class
			if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_fn_class = fncls__38d; tmp11 = fncls__38d } else { tmp11 = fncls__38 }
//line :302:1
			tmp1 = tmp9.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil)) } }
//line :296:1
	return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp12 != nil { panic(tmp12) }; return tmp1 }






func A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_New_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10 any) *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A{}; t.Ctor_O_O_O_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10); return t }
//line :303:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A) Ctor_O_O_O_O_O_O_O_O_O_O_O(c__d, c__all_ps, c__caps, c__pkg, c__n, c__st, c__info, c__ab, c__cap_ps, c__outer_p, c__mm any) { t.F_d = c__d; t.F_all_ps = c__all_ps; t.F_caps = c__caps; t.F_pkg = c__pkg; t.F_n = c__n; t.F_st = c__st; t.F_info = c__info; t.F_ab = c__ab; t.F_cap_ps = c__cap_ps; t.F_outer_p = c__outer_p; t.F_mm = c__mm }
//line :303:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A) Invoke_O__O(self any) any { { var seq_1464000197__1 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(t.F_all_ps); var chunk_1464000198__2 any; var count_1464000199__3 int64 = 0; var i_1464000200__4 int64 = 0; L1: for {
													if lang.Numbers_Lt_J_J__Z(i_1464000200__4, count_1464000199__3) { var s__5 any = lang.Indexed_Cast(chunk_1464000198__2).Nth_I__O(lang.RT_IntCast_J__I(i_1464000200__4)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_201.GetRawRoot__O()).Invoke_O__O(s__5); seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, i_1464000200__4 = seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, lang.Numbers_Unchecked_inc_J__J(i_1464000200__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000197__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1464000197__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6); seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, i_1464000200__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var s__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6); lang.IFn_Cast(A_arbace_j2g_decls_A_const_201.GetRawRoot__O()).Invoke_O__O(s__7); seq_1464000197__1, chunk_1464000198__2, count_1464000199__3, i_1464000200__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000197__6), nil, 0, 0; continue L1 } } }
//line :303:1
	break L1 }; var calls_super__1 any; var or__1927000174__auto____1 any = A_arbace_j2g_decls_A_const_210.Invoke_O__O(t.F_ab)

	if jrt.J2g_Truth(or__1927000174__auto____1) { calls_super__1 = or__1927000174__auto____1 } else { calls_super__1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t.F_ab, nil)).Ref() }
	if jrt.J2g_Truth(calls_super__1) { var seq_1464000201__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_215.GetRawRoot__O(), t.F_caps, t.F_cap_ps)); var chunk_1464000202__3 any; var count_1464000203__4 int64 = 0; var i_1464000204__5 int64 = 0; L2: for {

		if lang.Numbers_Lt_J_J__Z(i_1464000204__5, count_1464000203__4) { var vec__1464000205__6 any = lang.Indexed_Cast(chunk_1464000202__3).Nth_I__O(lang.RT_IntCast_J__I(i_1464000204__5)); var b__7 any = lang.RT_Nth_O_I_O__O(vec__1464000205__6, lang.RT_IntCast_J__I(0), nil); var p__8 any = lang.RT_Nth_O_I_O__O(vec__1464000205__6, lang.RT_IntCast_J__I(1), nil); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_216
			lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__7))).Ref()))).Ref()), A_arbace_j2g_decls_A_const_217), p__8))
//line :308:1
			seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, i_1464000204__5 = seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, lang.Numbers_Unchecked_inc_J__J(i_1464000204__5); continue L2 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000201__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1464000201__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7); seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, i_1464000204__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var vec__1464000208__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7); var b__9 any = lang.RT_Nth_O_I_O__O(vec__1464000208__8, lang.RT_IntCast_J__I(0), nil); var p__10 any = lang.RT_Nth_O_I_O__O(vec__1464000208__8, lang.RT_IntCast_J__I(1), nil); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_216
				lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_74.Invoke_O__O(b__9))).Ref()))).Ref()), A_arbace_j2g_decls_A_const_217), p__10))
//line :308:1
				seq_1464000201__2, chunk_1464000202__3, count_1464000203__4, i_1464000204__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000201__7), nil, 0, 0; continue L2 } } }
//line :306:1
		break L2
	}


		if jrt.J2g_Truth(t.F_outer_p) { var od__2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_142.Invoke_O__O(t.F_d), nil)).Ref(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp6 any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_132.GetRawRoot__O()).Invoke_O__O(od__2)) {
				tmp6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_76), t.F_outer_p) } else {
					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_218; tmp6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_112.GetRawRoot__O()).Invoke_O__O(Lit_77), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, od__2)), t.F_outer_p) }
//line :312:1
			tmp5.Invoke_O__O(tmp6)


			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_219; lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_143.GetRawRoot__O()).Invoke_O__O(t.F_n)))).Ref()), A_arbace_j2g_decls_A_const_220), t.F_outer_p)) } }
	if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_214.Invoke_O__O(t.F_ab)) {
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab)) } else {
//line :316:1
			var seq_1464000211__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_224.Invoke_O__O(t.F_ab)); var chunk_1464000212__3 any; var count_1464000213__4 int64 = 0; var i_1464000214__5 int64 = 0; L3: for {


				if lang.Numbers_Lt_J_J__Z(i_1464000214__5, count_1464000213__4) { var p__6 any = lang.Indexed_Cast(chunk_1464000212__3).Nth_I__O(lang.RT_IntCast_J__I(i_1464000214__5)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(p__6); seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, i_1464000214__5 = seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, lang.Numbers_Unchecked_inc_J__J(i_1464000214__5); continue L3 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000211__2); if jrt.J2g_Truth(temp__1927000414__auto____6_2) { var seq_1464000211__7 any = temp__1927000414__auto____6_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7); seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, i_1464000214__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var p__8_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(p__8_2); seq_1464000211__2, chunk_1464000212__3, count_1464000213__4, i_1464000214__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000211__7), nil, 0, 0; continue L3 } } }
//line :316:1
				break L3 }; var temp__1927000408__auto____2 any = A_arbace_j2g_decls_A_const_221.Invoke_O__O(t.F_ab)



			if jrt.J2g_Truth(temp__1927000408__auto____2) { var call__3 any = temp__1927000408__auto____2
				lang.IFn_Cast(lang.IFn_Cast(A_arbace_j2g_decls_A_const_222.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, t.F_info)).Invoke_O__O(call__3) } else {
					var tmp11 lang.IFn = lang.IFn_Cast(lang.IFn_Cast(A_arbace_j2g_decls_A_const_222.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, t.F_info)); var tmp12 any = A_arbace_j2g_decls_A_const_182; var tmp13 any = A_arbace_j2g_decls_A_const_225; var tmp14 any = A_arbace_j2g_decls_A_const_167; var tmp15 any = A_arbace_j2g_decls_A_const_126; var tmp16 any = A_arbace_j2g_decls_A_const_34; var tmp17 any = A_arbace_j2g_decls_A_const_126.Invoke_O__O(t.F_d); var tmp18 any = A_arbace_j2g_decls_A_const_174; var tmp19 any = A_arbace_j2g_decls_A_const_226; var tmp20 any = A_arbace_j2g_decls_A_const_193; var tmp21 *lang.PersistentVector; lang.PersistentVector_Init(); tmp21 = lang.PersistentVector_EMPTY; tmp11.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, tmp15, tmp16, tmp17, tmp18, tmp19, tmp20, tmp21.Ref())))
				}
			if jrt.J2g_Truth(calls_super__1) {
				var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_decls_A_const_90; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_90.Get__O(); var tmp26 any = A_arbace_j2g_decls_A_const_39; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O_O__O(tmp23, tmp24.Invoke_O_O_O__O(tmp25, tmp26, lang.IFn_Cast(A_arbace_j2g_decls_A_const_98.GetRawRoot__O()).Invoke_O_O__O(t.F_n, A_arbace_j2g_decls_A_const_227)))); var tmp27 any = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_New_O(t.F_st); var tmp28 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_fn_class = fncls__37d; tmp28 = fncls__37d } else { tmp28 = fncls__37 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil).Invoke__O() }
//line :316:1
			var temp__1927000414__auto____2 any = A_arbace_j2g_decls_A_const_114.Invoke_O__O(t.F_ab)










			if jrt.J2g_Truth(temp__1927000414__auto____2) { var b__3 any = temp__1927000414__auto____2; lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(b__3) } }
	var tmp29 any; var tmp30 any = A_arbace_j2g_decls_A_const_211; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp30, A_arbace_j2g_decls_A_const_167.Invoke_O__O(t.F_d)); if and__1927000168__auto____2 { var or__1927000174__auto____3 any = A_arbace_j2g_decls_A_const_212.Invoke_O__O(t.F_mm); if jrt.J2g_Truth(or__1927000174__auto____3) { tmp29 = or__1927000174__auto____3 } else { var tmp31 any = A_arbace_j2g_decls_A_const_213; tmp29 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp31, A_arbace_j2g_decls_A_const_209.Invoke_O__O(t.F_mm))).Ref() } } else { tmp29 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp29) { var seq_1464000221__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_215.GetRawRoot__O(), A_arbace_j2g_decls_A_const_107.Invoke_O__O(t.F_ab), A_arbace_j2g_decls_A_const_228.Invoke_O__O(t.F_d))); var chunk_1464000222__3 any; var count_1464000223__4 int64 = 0; var i_1464000224__5 int64 = 0; L4: for {
		if lang.Numbers_Lt_J_J__Z(i_1464000224__5, count_1464000223__4) { var vec__1464000225__6 any = lang.Indexed_Cast(chunk_1464000222__3).Nth_I__O(lang.RT_IntCast_J__I(i_1464000224__5)); var b__7_2 any = lang.RT_Nth_O_I_O__O(vec__1464000225__6, lang.RT_IntCast_J__I(0), nil); var cm__8 any = lang.RT_Nth_O_I_O__O(vec__1464000225__6, lang.RT_IntCast_J__I(1), nil); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_decls_A_const_229
			lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp32.Invoke_O_O_O__O(tmp33, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__8)))).Ref()), A_arbace_j2g_decls_A_const_230), lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__7_2)))
//line :329:1
			seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, i_1464000224__5 = seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, lang.Numbers_Unchecked_inc_J__J(i_1464000224__5); continue L4 } else { var temp__1927000414__auto____6_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000221__2); if jrt.J2g_Truth(temp__1927000414__auto____6_3) { var seq_1464000221__7 any = temp__1927000414__auto____6_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7)) { var c__1927000678__auto____8_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7); seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, i_1464000224__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var vec__1464000228__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7); var b__9_2 any = lang.RT_Nth_O_I_O__O(vec__1464000228__8, lang.RT_IntCast_J__I(0), nil); var cm__10 any = lang.RT_Nth_O_I_O__O(vec__1464000228__8, lang.RT_IntCast_J__I(1), nil); var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_229
				lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp34.Invoke_O_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__10)))).Ref()), A_arbace_j2g_decls_A_const_230), lang.IFn_Cast(A_arbace_j2g_decls_A_const_106.GetRawRoot__O()).Invoke_O__O(b__9_2)))
//line :329:1
				seq_1464000221__2, chunk_1464000222__3, count_1464000223__4, i_1464000224__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000221__7), nil, 0, 0; continue L4 } } else { return nil } } } } else {
//line :328:1
					return nil } }; /*line :303:1*/panic("j2g: unreachable") }





















func A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_New_O(p0 any) *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A{}; t.Ctor_O(p0); return t }
//line :325:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A) Ctor_O(c__st any) { t.F_st = c__st }
//line :325:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_1464000216__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_223; var tmp4 any; var t_ any = t.F_st
															t.F_st = nil; tmp4 = t_; seq_1464000216__3 = tmp2.Invoke_O__O(tmp3.Invoke_O__O(tmp4))
//line :325:1
	var chunk_1464000217__4 any; var count_1464000218__5 int64 = 0; var i_1464000219__6 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_1464000219__6, count_1464000218__5) { var i__7 any = lang.Indexed_Cast(chunk_1464000217__4).Nth_I__O(lang.RT_IntCast_J__I(i_1464000219__6)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(i__7); seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, i_1464000219__6 = seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, lang.Numbers_Unchecked_inc_J__J(i_1464000219__6); continue L1 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000216__3); if jrt.J2g_Truth(temp__1927000414__auto____7) { var seq_1464000216__8 any = temp__1927000414__auto____7; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8); seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, i_1464000219__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(i__9); seq_1464000216__3, chunk_1464000217__4, count_1464000218__5, i_1464000219__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000216__8), nil, 0, 0; continue L1 } } else { tmp1 = nil } }
//line :325:1
		break L1 } }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }











func A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A{}; t.Ctor_O_O(p0, p1); return t }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A) Ctor_O_O(c__pkg, c__rps any) { t.F_pkg = c__pkg; t.F_rps = c__rps }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A) Invoke_O_O__O(self, s__1464000234__1 any) any { var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_New_O_O_O_O(t.F_pkg, t.F_rps, s__1464000234__1, self); var tmp2 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_fn_class; if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_fn_class = fncls__50d; tmp2 = fncls__50d } else { tmp2 = fncls__50 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :337:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A) Ctor_O_O_O_O(c__pkg, c__rps, c__s__1464000234, c__iter__1464000233 any) { t.F_pkg = c__pkg; t.F_rps = c__rps; t.F_s__1464000234 = c__s__1464000234; t.F_iter__1464000233 = c__iter__1464000233 }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A) Invoke_O__O(self any) any { { var s__1464000234__1 any; var t_ any = t.F_s__1464000234; t.F_s__1464000234 = nil; s__1464000234__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000234__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000234__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000234__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000234__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000236__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_New_O_O_O_I_O(b__1464000236__6, t.F_pkg, t.F_rps, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000233); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000236__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000234__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000236__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000234__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; var tmp6 any = t.F_rps; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1464000233); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O_O__O(tmp5, lang.RT_Nth_O_I__O(tmp6, lang.RT_IntCast_O__I(i__4)))), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000234__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :337:1
func A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A) Ctor_O_O_O_I_O(c__b__1464000236, c__pkg, c__rps any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000236 = c__b__1464000236; t.F_pkg = c__pkg; t.F_rps = c__rps; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :337:1
func (t *A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A) Invoke_O__O(self any) any { { var i__1464000235__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000235__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000235__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000236; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp5 any = t.F_pkg; var tmp6 any = t.F_rps; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref()), tmp4.Invoke_O_O__O(tmp5, lang.RT_Nth_O_I__O(tmp6, lang.RT_IntCast_O__I(i__2))))); i__1464000235__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000235__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_New() *A_arbace_j2g_decls_ctor_forms_fn__1464000243_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_ctor_forms_fn__1464000243_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000243_A) Ctor() {}
//line :349:1
func (t *A_arbace_j2g_decls_ctor_forms_fn__1464000243_A) Invoke_O_O__O(self, p1__1464000161_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_258.GetRawRoot__O()).Invoke_O__O(p1__1464000161_SHARP___1)) }






func A_arbace_j2g_decls_record_object_body_A_New() *A_arbace_j2g_decls_record_object_body_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_j2g_decls_record_object_body_A) Ctor() {}
//line :356:1
func (t *A_arbace_j2g_decls_record_object_body_A) Invoke_O_O_O_O_O__O(self, pkg__0, n__1, mm__2, ps__3 any) any { var d__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var comps__6 any = A_arbace_j2g_decls_A_const_228.Invoke_O__O(d__5); var js__7 any; var tmp1 any = A_arbace_j2g_decls_record_object_body_js__1464000246_A_New_O(pkg__0); var tmp2 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_decls_record_object_body_js__1464000246_A_fn_class; if






	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_190, false); A_arbace_j2g_decls_record_object_body_js__1464000246_A_fn_class = fncls__53d; tmp2 = fncls__53d } else { tmp2 = fncls__53 }; js__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fld__8 any; var tmp3 any = /*line :356:1*/A_arbace_j2g_decls_record_object_body_fld__1464000248_A_New(); var tmp4 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_j2g_decls_record_object_body_fld__1464000248_A_fn_class; if







	fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_191, false); A_arbace_j2g_decls_record_object_body_fld__1464000248_A_fn_class = fncls__54d; tmp4 = fncls__54d } else { tmp4 = fncls__54 }; fld__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var hash__9 any; var tmp5 any = /*line :356:1*/A_arbace_j2g_decls_record_object_body_hash__1464000250_A_New_O(js__7); var tmp6 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_j2g_decls_record_object_body_hash__1464000250_A_fn_class; if








	fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_192, false); A_arbace_j2g_decls_record_object_body_hash__1464000250_A_fn_class = fncls__56d; tmp6 = fncls__56d } else { tmp6 = fncls__56 }; hash__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var strof__10 any; var tmp7 any = /*line :356:1*/A_arbace_j2g_decls_record_object_body_strof__1464000253_A_New_O(js__7); var tmp8 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_j2g_decls_record_object_body_strof__1464000253_A_fn_class; if

















	fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_193, false); A_arbace_j2g_decls_record_object_body_strof__1464000253_A_fn_class = fncls__58d; tmp8 = fncls__58d } else { tmp8 = fncls__58 }; strof__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var G__1464000256__11_ any = /*line :356:1*/A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2); switch


























	lang.Util_Hash_O__I(G__1464000256__11_) >> 1 & 3 { case 1: if lang.Util_Equiv_O_O__Z(G__1464000256__11_, Lit_194) { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_282; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_record_object_body_fn__1464000257_A_New_O_O(hash__9, fld__8); var tmp13 *jrt.Class
		var fncls__60 /*line :383:1*/*jrt.Class = A_arbace_j2g_decls_record_object_body_fn__1464000257_A_fn_class











		if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_195, false); A_arbace_j2g_decls_record_object_body_fn__1464000257_A_fn_class = fncls__60d; tmp13 = fncls__60d } else { tmp13 = fncls__60 }
//line :383:1
		return lang.Tuple_Create_O__IPersistentVector(tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_287, A_arbace_j2g_decls_A_const_288, A_arbace_j2g_decls_A_const_289), comps__6))) }; case 2: if lang.Util_Equiv_O_O__Z(G__1464000256__11_, Lit_196) { var simple__12 any; var s__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_154.GetRawRoot__O()).Invoke_O_O__O(n__1, jrt.Long_ValueOf_J__Long(lang.Numbers_Inc_J__J(int64(jrt.NN(jrt.String_Cast(n__1)).LastIndexOf_String__I(Lit_11)))).Ref()), A_arbace_j2g_decls_A_const_290, Lit_197); simple__12 = s__12; var parts__13 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp15 any = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_198), jrt.RefArrayOf(jrt.Object_class, simple__12, nil)).Ref())); var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_decls_A_const_57.GetRawRoot__O(); var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_147.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_record_object_body_fn__1464000259_A_New_O_O(fld__8, strof__10); var tmp20 *jrt.Class
			var fncls__61 /*line :383:1*/*jrt.Class = A_arbace_j2g_decls_record_object_body_fn__1464000259_A_fn_class




			if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_199, false); A_arbace_j2g_decls_record_object_body_fn__1464000259_A_fn_class = fncls__61d; tmp20 = fncls__61d } else { tmp20 = fncls__61 }
//line :386:1
			parts__13 = tmp14.Invoke_O_O_O__O(tmp15, tmp16.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil), comps__6)), lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()).Invoke_O__O(Lit_200)))
//line :383:1
			var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_decls_A_const_293; return lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O__O(tmp22, lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(js__7).Invoke_O__O(Lit_201), parts__13))) }; case 3: if lang.Util_Equiv_O_O__Z(G__1464000256__11_, Lit_202) { var o__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(ps__3); var g__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_decls_A_const_294; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_A_const_295; var tmp27 any = tmp25.Invoke_O_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_296, A_arbace_j2g_decls_A_const_297, A_arbace_j2g_decls_A_const_298), o__12); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_299; var tmp30 *jrt.Boolean; jrt.Boolean_Init(); tmp30 = jrt.Boolean_TRUE; var tmp31 any = tmp23.Invoke_O_O_O__O(tmp24, tmp27, tmp28.Invoke_O_O__O(tmp29, tmp30.Ref())); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_decls_A_const_300; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_301; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp37 any = A_arbace_j2g_decls_A_const_303; var tmp38 any = tmp34.Invoke_O_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_302, o__12, nil), tmp36.Invoke_O_O_O__O(tmp37, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(js__7).Invoke_O__O(Lit_203), o__12), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__13, nil)).Ref()))); var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_decls_A_const_304; var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_FALSE; var tmp42 any = tmp32.Invoke_O_O_O__O(tmp33, tmp38, tmp39.Invoke_O_O__O(tmp40, tmp41.Ref())); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_A_const_305; var tmp45 any = A_arbace_j2g_decls_A_const_306; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_decls_A_const_307; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_decls_A_const_308; var tmp50 any = lang.Tuple_Create_O_O__IPersistentVector(tmp45, tmp46.Invoke_O_O_O__O(tmp47, tmp48.Invoke_O_O__O(tmp49, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__13)), o__12)); var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp52 any = A_arbace_j2g_decls_A_const_309; var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp54 any = A_arbace_j2g_decls_record_object_body_fn__1464000261_A_New_O_O(js__7, fld__8); var tmp55 *jrt.Class
				var fncls__63 /*line :383:1*/*jrt.Class = A_arbace_j2g_decls_record_object_body_fn__1464000261_A_fn_class


















				if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_204, false); A_arbace_j2g_decls_record_object_body_fn__1464000261_A_fn_class = fncls__63d; tmp55 = fncls__63d } else { tmp55 = fncls__63 }
//line :383:1
				var tmp56 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp54, tmp55, nil); var tmp57 *jrt.Boolean; jrt.Boolean_Init(); tmp57 = jrt.Boolean_TRUE; return lang.Tuple_Create_O_O_O__IPersistentVector(tmp31, tmp42, tmp43.Invoke_O_O_O__O(tmp44, tmp50, tmp51.Invoke_O_O__O(tmp52, tmp53.Invoke_O_O_O__O(tmp56, tmp57.Ref(), comps__6)))) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_205, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1464000256__11_))))) }
//line :363:1
func A_arbace_j2g_decls_record_object_body_js__1464000246_A_New_O(p0 any) *A_arbace_j2g_decls_record_object_body_js__1464000246_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_js__1464000246_A{}; t.Ctor_O(p0); return t }
//line :363:1
func (t *A_arbace_j2g_decls_record_object_body_js__1464000246_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :363:1
func (t *A_arbace_j2g_decls_record_object_body_js__1464000246_A) Invoke_O_O__O(self, s__1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__1) }
func A_arbace_j2g_decls_record_object_body_fld__1464000248_A_New() *A_arbace_j2g_decls_record_object_body_fld__1464000248_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fld__1464000248_A{}; t.Ctor(); return t }
//line :364:1
func (t *A_arbace_j2g_decls_record_object_body_fld__1464000248_A) Ctor() {}
//line :364:1
func (t *A_arbace_j2g_decls_record_object_body_fld__1464000248_A) Invoke_O_O_O__O(self, o__1, cm__2 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__2)))).Ref()), o__1) }
func A_arbace_j2g_decls_record_object_body_hash__1464000250_A_New_O(p0 any) *A_arbace_j2g_decls_record_object_body_hash__1464000250_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_hash__1464000250_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_j2g_decls_record_object_body_hash__1464000250_A) Ctor_O(c__js any) { t.F_js = c__js }
//line :365:1
func (t *A_arbace_j2g_decls_record_object_body_hash__1464000250_A) Invoke_O_O_O__O(self, cm__1, x__2 any) any { var G__1464000251__3_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1); switch
														lang.Util_Hash_O__I(G__1464000251__3_) { case 66: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_124) {
															return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 67: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_125) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 68: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_126) { var b__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_208), x__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_262; var tmp3 any = A_arbace_j2g_decls_A_const_263; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_264; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_265; var tmp8 any = A_arbace_j2g_decls_A_const_266; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O())
		var tmp10 any = A_arbace_j2g_decls_A_const_267




		return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, b__4, tmp6.Invoke_O_O_O__O(tmp7, tmp8, tmp9.Invoke_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_269, A_arbace_j2g_decls_A_const_270, b__4), A_arbace_j2g_decls_A_const_268)))) }
//line :366:1
	case 70: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_127) {



		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_209), x__2) }
//line :366:1
	case 73: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_128) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 74: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_129) {


		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_271; var tmp13 any = A_arbace_j2g_decls_A_const_272; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_decls_A_const_273; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp17 any = A_arbace_j2g_decls_A_const_274; var tmp18 any = A_arbace_j2g_decls_A_const_275; var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_decls_A_const_276; return tmp11.Invoke_O_O_O__O(tmp12, tmp13, tmp14.Invoke_O_O_O__O(tmp15, x__2, tmp16.Invoke_O_O_O__O(tmp17, tmp18, tmp19.Invoke_O_O_O__O(tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_277, A_arbace_j2g_decls_A_const_278, x__2), A_arbace_j2g_decls_A_const_268)))) }
//line :366:1
	case 83: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_130) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_260, A_arbace_j2g_decls_A_const_261, x__2) }
//line :366:1
	case 90: if lang.Util_Equiv_O_O__Z(G__1464000251__3_, Lit_131) {

		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_211), x__2) }
//line :366:1
	default:}; var tmp21 lang.IFn =






	lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_212); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp24 any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1); var tmp25 *jrt.Boolean; jrt.Boolean_Init(); tmp25 = jrt.Boolean_FALSE; return tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O_O_O__O(x__2, tmp24, Lit_92, tmp25.Ref())) }
func A_arbace_j2g_decls_record_object_body_strof__1464000253_A_New_O(p0 any) *A_arbace_j2g_decls_record_object_body_strof__1464000253_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_strof__1464000253_A{}; t.Ctor_O(p0); return t }
//line :374:1
func (t *A_arbace_j2g_decls_record_object_body_strof__1464000253_A) Ctor_O(c__js any) { t.F_js = c__js }
//line :374:1
func (t *A_arbace_j2g_decls_record_object_body_strof__1464000253_A) Invoke_O_O_O__O(self, cm__1, x__2 any) any { var G__1464000254__3_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1); switch
														lang.Util_Hash_O__I(G__1464000254__3_) { case 66: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_124) {
															return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_213), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_280, A_arbace_j2g_decls_A_const_281, x__2)) }
//line :375:1
	case 67: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_125) {


		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_214), x__2) }
//line :375:1
	case 68: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_126) {





		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_215), x__2) }
//line :375:1
	case 70: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_127) {




		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_216), x__2) }
//line :375:1
	case 73: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_128) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_213), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_280, A_arbace_j2g_decls_A_const_281, x__2)) }
//line :375:1
	case 74: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_129) {

		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_217), x__2) }
//line :375:1
	case 83: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_130) {
		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_213), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_280, A_arbace_j2g_decls_A_const_281, x__2)) }
//line :375:1
	case 90: if lang.Util_Equiv_O_O__Z(G__1464000254__3_, Lit_131) {



		return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_218), x__2) }
//line :375:1
	default:}; var tmp1 lang.IFn =






	lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_219); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__1); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_FALSE; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O_O__O(x__2, tmp4, Lit_92, tmp5.Ref())) }





func A_arbace_j2g_decls_record_object_body_fn__1464000259_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_record_object_body_fn__1464000259_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fn__1464000259_A{}; t.Ctor_O_O(p0, p1); return t }
//line :388:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000259_A) Ctor_O_O(c__fld, c__strof any) { t.F_fld = c__fld; t.F_strof = c__strof }
//line :388:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000259_A) Invoke_O_O_O__O(self, i__1, cm__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()); var tmp2 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, nil, Lit_206); var tmp3 *jrt.String; if
														lang.Numbers_IsPos_O__Z(i__1) { tmp3 = Lit_207 } else { tmp3 = nil }; var tmp4 lang.IFn = /*line :388:1*/lang.IFn_Cast(t.F_strof); return lang.Tuple_Create_O_O__IPersistentVector(tmp1.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp2, jrt.RefArrayOf(jrt.Object_class, tmp3.Ref(), A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__2), nil)).Ref()), tmp4.Invoke_O_O__O(cm__2, lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_292, cm__2))) }






func A_arbace_j2g_decls_record_object_body_fn__1464000257_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_record_object_body_fn__1464000257_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fn__1464000257_A{}; t.Ctor_O_O(p0, p1); return t }
//line :395:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000257_A) Ctor_O_O(c__hash, c__fld any) { t.F_hash = c__hash; t.F_fld = c__fld }
//line :395:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000257_A) Invoke_O_O_O__O(self, acc__1, cm__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_283; var tmp3 lang.IFn = lang.IFn_Cast(t.F_hash); return tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_284, acc__1, A_arbace_j2g_decls_A_const_285), tmp3.Invoke_O_O__O(cm__2, lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_286, cm__2))) }






func A_arbace_j2g_decls_record_object_body_fn__1464000261_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_record_object_body_fn__1464000261_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_record_object_body_fn__1464000261_A{}; t.Ctor_O_O(p0, p1); return t }
//line :402:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000261_A) Ctor_O_O(c__js, c__fld any) { t.F_js = c__js; t.F_fld = c__fld }
//line :402:1
func (t *A_arbace_j2g_decls_record_object_body_fn__1464000261_A) Invoke_O_O_O__O(self, acc__1, cm__2 any) any { var a__3 any = lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_311, cm__2); var b__4 any = lang.IFn_Cast(t.F_fld).Invoke_O_O__O(A_arbace_j2g_decls_A_const_312, cm__2); var e__5 any; var G__1464000262__5_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__2); L1:

switch { default: switch lang.Util_Hash_O__I(G__1464000262__5_) { case 66: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_124) {


	e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
	break L1 }; case 67: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_125) {


		e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
		break L1 }; case 68: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_126) {

			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_314; e__5 = tmp1.Invoke_O_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_208), a__3), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_208), b__4))
//line :404:1
			break L1 }; case 70: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_127) {
				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_315; e__5 = tmp3.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_209), a__3), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_209), b__4))
//line :404:1
				break L1 }; case 73: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_128) {


					e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
					break L1 }; case 74: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_129) {


						e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
						break L1 }; case 83: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_130) {


							e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
							break L1 }; case 90: if lang.Util_Equiv_O_O__Z(G__1464000262__5_, Lit_131) {


								e__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_313, a__3, b__4)
//line :404:1
								break L1 }; default:
}


	var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp6 any = lang.IFn_Cast(t.F_js).Invoke_O__O(Lit_210); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__2); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_FALSE; var tmp10 any = tmp7.Invoke_O_O_O_O__O(a__3, tmp8, Lit_92, tmp9.Ref()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(cm__2); var tmp13 *jrt.Boolean; jrt.Boolean_Init(); tmp13 = jrt.Boolean_FALSE; e__5 = tmp5.Invoke_O_O_O__O(tmp6, tmp10, tmp11.Invoke_O_O_O_O__O(b__4, tmp12, Lit_92, tmp13.Ref()))}; if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_310.GetRawRoot__O()).Invoke_O__O(acc__1)) { return e__5 } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_316, acc__1, e__5) } }


func A_arbace_j2g_decls_derived_body_A_New() *A_arbace_j2g_decls_derived_body_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_A{}; t.Ctor(); return t }
//line :413:1
func (t *A_arbace_j2g_decls_derived_body_A) Ctor() {}
//line :413:1
func (t *A_arbace_j2g_decls_derived_body_A) Invoke_O_O_O_O_O__O(self, pkg__0, n__1, mm__2, ps__3 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_90.Get__O(), A_arbace_j2g_decls_A_const_33, pkg__0)))
//line :413:1
	var tmp3 any; tmp43 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var g__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var d__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var leaf__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1); var this__10 any








		if jrt.J2g_Truth(leaf__9) { this__10 = A_arbace_j2g_decls_A_const_317 } else { this__10 = A_arbace_j2g_decls_A_const_318 }
//line :413:1
		var G__1464000265__11_ any = A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2)









	L1: switch { default: switch lang.Util_Hash_O__I(G__1464000265__11_) >> 5 & 7 { case 0: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_319) { var tg__12 any = A_arbace_j2g_decls_A_const_320.Invoke_O__O(mm__2); var vec__1464000266__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(tg__12)); var tps__14 any = lang.RT_Nth_O_I_O__O(vec__1464000266__13, lang.RT_IntCast_J__I(0), nil); var tr__15 any = lang.RT_Nth_O_I_O__O(vec__1464000266__13, lang.RT_IntCast_J__I(1), nil); var vec__1464000269__16 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var bps__17 any = lang.RT_Nth_O_I_O__O(vec__1464000269__16, lang.RT_IntCast_J__I(0), nil); var br__18 any = lang.RT_Nth_O_I_O__O(vec__1464000269__16, lang.RT_IntCast_J__I(1), nil); var args__19 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_derived_body_fn__1464000272_A_New(); var tmp6 *jrt.Class
		var fncls__65 /*line :423:1*/*jrt.Class = A_arbace_j2g_decls_derived_body_fn__1464000272_A_fn_class










		if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_j2g_decls_derived_body_fn__1464000272_A_fn_class = fncls__65d; tmp6 = fncls__65d } else { tmp6 = fncls__65 }; args__19 = tmp4.Invoke_O_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ps__3, bps__17, tps__14)
//line :423:1
		var tbase__20 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(tg__12), A_arbace_j2g_decls_A_const_118.Invoke_O__O(tg__12)); var call__21 any
















		if jrt.J2g_Truth(A_arbace_j2g_decls_A_const_321.Invoke_O__O(mm__2)) { var sup__21 any = A_arbace_j2g_decls_A_const_126.Invoke_O__O(d__8); var tmp7 any; var and__1927000168__auto____22 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_322.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_333.Invoke_O__O(tg__12))

			if jrt.J2g_Truth(and__1927000168__auto____22) { var tmp8 *lang.Keyword = A_arbace_j2g_decls_A_const_157; tmp7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_156.GetRawRoot__O()).Invoke_O_O__O(tmp8.Invoke_O__O(A_arbace_j2g_decls_A_const_158.Get__O()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_333.Invoke_O__O(tg__12))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_334.GetRawRoot__O()).Invoke_O__O(tbase__20))) } else { tmp7 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp7) {
				call__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, tbase__20)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(sup__21))).Ref()), A_arbace_j2g_decls_A_const_335), args__19) } else {
					call__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_91, nil), jrt.RefArrayOf(jrt.Object_class, nil, tbase__20)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(sup__21))).Ref()), A_arbace_j2g_decls_A_const_336), this__10, args__19) } } else {
						call__21 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_12, nil), jrt.RefArrayOf(jrt.Object_class, nil, tbase__20)).Ref()), this__10, args__19) }
		if lang.Util_Equiv_O_O__Z(Lit_51, br__18) { tmp3 = lang.Tuple_Create_O__IPersistentVector(call__21) } else { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_337; var tmp11 any; var tmp12 any; var and__1927000168__auto____22_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(tr__15)


			if jrt.J2g_Truth(and__1927000168__auto____22_2) { var and__1927000168__auto____23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(br__18); if jrt.J2g_Truth(and__1927000168__auto____23) { var and__1927000168__auto____24 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(tr__15, br__18); if jrt.J2g_Truth(and__1927000168__auto____24) { tmp12 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_329.GetRawRoot__O()).Invoke_O_O__O(tr__15, br__18)) } else { tmp12 = and__1927000168__auto____24 } } else { tmp12 = and__1927000168__auto____23 } } else { tmp12 = and__1927000168__auto____22_2 }; if jrt.J2g_Truth(tmp12) {


				var tmp13 *lang.Keyword = A_arbace_j2g_decls_A_const_180; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_330.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_decls_A_const_34; var tmp16 any = A_arbace_j2g_decls_A_const_331; var tmp17 any = A_arbace_j2g_decls_A_const_182; var tmp18 any = A_arbace_j2g_decls_A_const_332; var tmp19 any = A_arbace_j2g_decls_A_const_180; var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp21 *jrt.Boolean; jrt.Boolean_Init(); tmp21 = jrt.Boolean_FALSE; tmp11 = tmp13.Invoke_O__O(tmp14.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, br__18, tmp16, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp20.Invoke_O_O_O_O__O(call__21, tr__15, Lit_92, tmp21.Ref()), A_arbace_j2g_decls_A_const_86, Lit_92)))))) } else {
					var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_FALSE; tmp11 = tmp22.Invoke_O_O_O_O__O(call__21, tr__15, br__18, tmp23.Ref()) }
//line :446:1
			tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp9.Invoke_O_O__O(tmp10, tmp11)) }
//line :423:1
		break L1 }; case 1: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_323) { var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_338; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_339; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_93), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref())))); break L1 }; case 2: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_324) {
































			tmp3 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_325.GetRawRoot__O()).Invoke_O_O_O_O__O(pkg__0, n__1, mm__2, ps__3)
//line :423:1
			break L1 }; case 4: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_326) { var cm__12 any = A_arbace_j2g_decls_A_const_327.Invoke_O__O(mm__2); var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_341; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp28.Invoke_O_O__O(tmp29, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cm__12)))).Ref()), A_arbace_j2g_decls_A_const_342))); break L1 }; case 5: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_340) { var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_decls_A_const_344; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp34 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_94); var tmp35 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref()); var tmp36 any; var iter__1927001039__auto____12 any; var tmp37 any = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_New_O(g__7); var tmp38 *jrt.Class
				var fncls__68 /*line :423:1*/*jrt.Class = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_fn_class





				if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_fn_class = fncls__68d; tmp38 = fncls__68d } else { tmp38 = fncls__68 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp37, tmp38, nil); tmp36 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(A_arbace_j2g_decls_A_const_345.Invoke_O__O(d__8))
//line :423:1
				tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp30.Invoke_O_O__O(tmp31, tmp32.Invoke_O_O_O_O__O(tmp33, tmp34, tmp35, tmp36))); break L1 }; case 6: if any(G__1464000265__11_) == any(A_arbace_j2g_decls_A_const_343) { var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_decls_A_const_346; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp39.Invoke_O_O__O(tmp40, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_97), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_98), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__7, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(ps__3))))); break L1 }; default:}; var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_decls_A_const_347; tmp3 = lang.Tuple_Create_O__IPersistentVector(tmp41.Invoke_O_O__O(tmp42, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_99), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_100, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_348.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2)))).Ref())))} }; return nil }()
//line :418:1
	lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O()
//line :413:1
	if tmp43 != nil { panic(tmp43) }; return tmp3
}














func A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_New_O(p0 any) *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A{}; t.Ctor_O(p0); return t }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A) Invoke_O_O__O(self, s__1464000275__1 any) any { var tmp1 any = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_New_O_O_O(t.F_g, s__1464000275__1, self); var tmp2 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_101, false); A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_fn_class = fncls__67d; tmp2 = fncls__67d } else { tmp2 = fncls__67 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :429:1
func A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A) Ctor_O_O_O(c__g, c__s__1464000275, c__iter__1464000274 any) { t.F_g = c__g; t.F_s__1464000275 = c__s__1464000275; t.F_iter__1464000274 = c__iter__1464000274 }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A) Invoke_O__O(self any) any { { var s__1464000275__1 any; var t_ any = t.F_s__1464000275; t.F_s__1464000275 = nil; s__1464000275__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000275__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000275__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000275__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000275__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000277__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_New_O_I_O_O(t.F_g, size__1927001038__auto____5, c__1927001037__auto____4, b__1464000277__6); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_102, false); A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000274); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000277__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000275__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000277__6), nil) } } else { var cn__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000275__3); var tmp4 any = t.F_g; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000274); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, tmp4, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cn__4)))).Ref()), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000275__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :429:1
func A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A) Ctor_O_I_O_O(c__g any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000277 any) { t.F_g = c__g; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000277 = c__b__1464000277 }
//line :429:1
func (t *A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A) Invoke_O__O(self any) any { { var i__1464000276__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000276__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var cn__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000276__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000277; var tmp4 any = t.F_g; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, tmp4, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_237.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(cn__2)))).Ref())); i__1464000276__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000276__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_decls_derived_body_fn__1464000272_A_New() *A_arbace_j2g_decls_derived_body_fn__1464000272_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_derived_body_fn__1464000272_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_j2g_decls_derived_body_fn__1464000272_A) Ctor() {}
//line :434:1
func (t *A_arbace_j2g_decls_derived_body_fn__1464000272_A) Invoke_O_O_O_O__O(self, p__1, bp__2, tp__3 any) any {
	if lang.Util_Equiv_O_O__Z(bp__2, tp__3) { return p__1 } else { var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(bp__2)
		if jrt.J2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_328.GetRawRoot__O()).Invoke_O__O(tp__3); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_329.GetRawRoot__O()).Invoke_O_O__O(bp__2, tp__3) } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }
//line :435:1
		if jrt.J2g_Truth(tmp1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_FALSE; return tmp2.Invoke_O_O_O_O__O(p__1, bp__2, tp__3, tmp3.Ref()) } else {
//line :435:1
				if A_arbace_j2g_decls_A_const_160 != nil {

					var tmp4 *lang.Keyword = A_arbace_j2g_decls_A_const_180; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_330.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_34; var tmp7 any = A_arbace_j2g_decls_A_const_331; var tmp8 any = A_arbace_j2g_decls_A_const_182; var tmp9 any = A_arbace_j2g_decls_A_const_332; var tmp10 any = A_arbace_j2g_decls_A_const_180; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_279.GetRawRoot__O()); var tmp12 *jrt.Boolean; jrt.Boolean_Init(); tmp12 = jrt.Boolean_FALSE; return tmp4.Invoke_O__O(tmp5.Invoke_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tp__3, tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, tmp10, tmp11.Invoke_O_O_O_O__O(p__1, bp__2, Lit_92, tmp12.Ref()), A_arbace_j2g_decls_A_const_86, Lit_92)))))) } else {
//line :435:1
						return nil
					}
			}
	}
}



















func A_arbace_j2g_decls_touches_statics_QMARK__A_New() *A_arbace_j2g_decls_touches_statics_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_touches_statics_QMARK__A{}; t.Ctor(); return t }
//line :459:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__A) Ctor() {}
//line :459:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__A) Invoke_O_O_O__O(self, ab__0, classes__1 any) any { var hit__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_349.GetRawRoot__O()); var tmp2 *jrt.Boolean;



	jrt.Boolean_Init(); tmp2 = jrt.Boolean_FALSE; hit__3 = tmp1.Invoke_O__O(tmp2.Ref()); var body_w__4 /*line :459:1*/*A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A = A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_New_O_O(classes__1, hit__3); var w__4 any; var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_253, false); A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; w__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_w__4), tmp3, nil);















	lang.IFn_Cast(w__4).Invoke_O__O(A_arbace_j2g_decls_A_const_114.Invoke_O__O(ab__0)); return /*line :463:1*/ lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(hit__3) }
func A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A{}; t.Ctor_O_O(p0, p1); return t }
//line :464:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A) Ctor_O_O(c__classes, c__hit any) { t.F_classes = c__classes; t.F_hit = c__hit }
//line :464:1
func (t *A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A) Invoke_O_O__O(self, x__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(t.F_hit)) { return nil } else {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_350.GetRawRoot__O()).Invoke_O__O(x__1)) {

			var tmp1 any; var and__1927000168__auto____2 any = A_arbace_j2g_decls_A_const_182.Invoke_O__O(x__1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_353); var and__1927000168__auto____3 any = tmp2.Invoke_O__O(A_arbace_j2g_decls_A_const_182.Invoke_O__O(x__1)); if jrt.J2g_Truth(and__1927000168__auto____3) {

				var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()); var tmp4 any = t.F_classes; var tmp5 any; var tmp6 *lang.Keyword = A_arbace_j2g_decls_A_const_355; var or__1927000174__auto____4 any = tmp6.Invoke_O__O(A_arbace_j2g_decls_A_const_356.Invoke_O__O(x__1)); if jrt.J2g_Truth(or__1927000174__auto____4) { tmp5 = or__1927000174__auto____4 } else { var tmp7 *lang.Keyword = A_arbace_j2g_decls_A_const_333; tmp5 = tmp7.Invoke_O__O(A_arbace_j2g_decls_A_const_356.Invoke_O__O(x__1)) }; tmp1 = tmp3.Invoke_O_O__O(tmp4, tmp5) } else {
//line :468:1
					tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.J2g_Truth(tmp1) {


						var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_354.GetRawRoot__O()); var tmp9 any = t.F_hit; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; tmp8.Invoke_O_O__O(tmp9, tmp10.Ref()) }
			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_351.GetRawRoot__O()).Invoke_O_O__O(self, lang.IFn_Cast(A_arbace_j2g_decls_A_const_357.GetRawRoot__O()).Invoke_O__O(x__1)) } else {
//line :466:1
				var tmp11 any; var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_352.GetRawRoot__O()).Invoke_O__O(x__1)






				if jrt.J2g_Truth(or__1927000174__auto____2) { tmp11 = or__1927000174__auto____2 } else { tmp11 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(x__1) }
//line :466:1
				if jrt.J2g_Truth(tmp11) {






					return lang.IFn_Cast(A_arbace_j2g_decls_A_const_351.GetRawRoot__O()).Invoke_O_O__O(self, x__1) } else {
//line :466:1
						if A_arbace_j2g_decls_A_const_160 != nil { return nil } else { return nil
						}
					}
			}
	}
}






func A_arbace_j2g_decls_needs_entry_guard_QMARK__A_New() *A_arbace_j2g_decls_needs_entry_guard_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_needs_entry_guard_QMARK__A{}; t.Ctor(); return t }
//line :478:1
func (t *A_arbace_j2g_decls_needs_entry_guard_QMARK__A) Ctor() {}
//line :478:1
func (t *A_arbace_j2g_decls_needs_entry_guard_QMARK__A) Invoke_O_O_O__O(self, n__0, ab__1 any) any { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(n__0)); if





	jrt.J2g_Truth(and__1927000168__auto____3) { var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z(ab__1, nil)
		if or__1927000174__auto____4 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { var or__1927000174__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_359.GetRawRoot__O()).Invoke_O__O(n__0)); if jrt.J2g_Truth(or__1927000174__auto____5) { return or__1927000174__auto____5 } else {

			return lang.IFn_Cast(A_arbace_j2g_decls_A_const_358.GetRawRoot__O()).Invoke_O_O__O(ab__1, lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_360.GetRawRoot__O()).Invoke_O__O(n__0))) } } } else {
//line :484:1
				return and__1927000168__auto____3 } }




func A_arbace_j2g_decls_method_forms_A_New() *A_arbace_j2g_decls_method_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_j2g_decls_method_forms_A) Ctor() {}
//line :489:1
func (t *A_arbace_j2g_decls_method_forms_A) Invoke_O_O_O_O__O(self, pkg__0, n__1, mm__2 any) any { var g__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var iface__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1); var leaf__6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(iface__5); if





	jrt.J2g_Truth(and__1927000168__auto____6) { leaf__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1) } else { leaf__6 = and__1927000168__auto____6 }; var static__7 any = /*line :489:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2); var vec__1464000289__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var ps__9 any = lang.RT_Nth_O_I_O__O(vec__1464000289__8, lang.RT_IntCast_J__I(0), nil); var r__10 any = lang.RT_Nth_O_I_O__O(vec__1464000289__8, lang.RT_IntCast_J__I(1), nil); var base__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var ab__12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_202.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); var abstract__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_244); var native__14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_371); var reached__15 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_203.GetRawRoot__O()).Invoke_O_O__O(n__1, mm__2); if













	jrt.J2g_Truth(abstract__13) { return nil } else { var vec__1464000292__16 any

		if jrt.J2g_Truth(native__14) { var pn__16 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____16 any; var tmp3 any = A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A_New(); var tmp4 *jrt.Class
			var fncls__76 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A_fn_class

			if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_161, false); A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A_fn_class = fncls__76d; tmp4 = fncls__76d } else { tmp4 = fncls__76 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__9)).Ref())); pn__16 = tmp1.Invoke_O__O(tmp2)
//line :505:1
			var fname__17 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil, Lit_162), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11, nil)).Ref(); var f__18 any
			var tmp5 /*line :505:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_372
			var tmp6 /*line :505:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_157






			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O__O(tmp6.Invoke_O__O(A_arbace_j2g_decls_A_const_158.Get__O())), fname__17)) {
				f__18 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, fname__17) } else {
					f__18 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(fname__17) }
//line :505:1
			var call__19 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp10 any









			if jrt.J2g_Truth(static__7) { tmp10 = nil } else { tmp10 = A_arbace_j2g_decls_A_const_373 }; call__19 = tmp7.Invoke_O_O_O__O(tmp8, f__18, tmp9.Invoke_O_O__O(tmp10, pn__16))
//line :505:1
			var tmp11 any










			if lang.Util_Equiv_O_O__Z(Lit_51, r__10) { tmp11 = call__19 } else { tmp11 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_374, call__19) }
//line :505:1
			vec__1464000292__16 = lang.Tuple_Create_O_O__IPersistentVector(pn__16, lang.Tuple_Create_O__IPersistentVector(tmp11)) } else { var tmp12 any; var and__1927000168__auto____16 any = A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2)











				if jrt.J2g_Truth(and__1927000168__auto____16) { var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_319; var or__1927000174__auto____17 any = tmp13.Invoke_O_O__O(tmp14, A_arbace_j2g_decls_A_const_209.Invoke_O__O(mm__2))
					if jrt.J2g_Truth(or__1927000174__auto____17) { tmp12 = or__1927000174__auto____17 } else { var and__1927000168__auto____18 any = reached__15
						if jrt.J2g_Truth(and__1927000168__auto____18) { var tmp15 *lang.Keyword = A_arbace_j2g_decls_A_const_118; tmp12 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O__O(A_arbace_j2g_decls_A_const_320.Invoke_O__O(mm__2))) } else { tmp12 = and__1927000168__auto____18 } } } else {
//line :517:1
							tmp12 = and__1927000168__auto____16 }
//line :505:1
				if jrt.J2g_Truth(tmp12) { var pn__16_2 any; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp17 any; var iter__1927001039__auto____16_2 any; var tmp18 any = A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A_New(); var tmp19 *jrt.Class
					var fncls__79 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A_fn_class














					if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A_fn_class = fncls__79d; tmp19 = fncls__79d } else { tmp19 = fncls__79 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); tmp17 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__9)).Ref())); pn__16_2 = tmp16.Invoke_O__O(tmp17)
//line :505:1
					vec__1464000292__16 = lang.Tuple_Create_O_O__IPersistentVector(pn__16_2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_375.GetRawRoot__O()).Invoke_O_O_O_O__O(pkg__0, n__1, mm__2, pn__16_2)) } else { var tmp20 any
						var and__1927000168__auto____16_2 any = reached__15
















						if jrt.J2g_Truth(and__1927000168__auto____16_2) { var and__1927000168__auto____17 bool = lang.Util_Identical_O_O__Z(ab__12, nil); if and__1927000168__auto____17 { var and__1927000168__auto____18_2 bool = lang.Util_Equiv_O_O__Z(Lit_51, r__10); if and__1927000168__auto____18_2 { var tmp21 *lang.Keyword = A_arbace_j2g_decls_A_const_376; var tmp22 *lang.Keyword = A_arbace_j2g_decls_A_const_81; tmp20 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp21.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp22.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1))))) } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____18_2).Ref() } } else { tmp20 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____17).Ref() } } else { tmp20 = and__1927000168__auto____16_2 }
//line :505:1
						if jrt.J2g_Truth(tmp20) { var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp24 any; var iter__1927001039__auto____16_3 any; var tmp25 any = A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A_New(); var tmp26 *jrt.Class
							var fncls__82 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A_fn_class


















							if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_164, false); A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A_fn_class = fncls__82d; tmp26 = fncls__82d } else { tmp26 = fncls__82 }; iter__1927001039__auto____16_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); tmp24 = lang.IFn_Cast(iter__1927001039__auto____16_3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__9)).Ref()))
//line :505:1
							var tmp27 any = tmp23.Invoke_O__O(tmp24); var tmp28 *lang.PersistentVector; lang.PersistentVector_Init(); tmp28 = lang.PersistentVector_EMPTY; vec__1464000292__16 = lang.Tuple_Create_O_O__IPersistentVector(tmp27, tmp28.Ref()) } else { var tmp29 any
								var and__1927000168__auto____16_3 any = reached__15


















								if jrt.J2g_Truth(and__1927000168__auto____16_3) { var and__1927000168__auto____17_2 any = ab__12; if jrt.J2g_Truth(and__1927000168__auto____17_2) { var tmp30 *lang.Keyword = A_arbace_j2g_decls_A_const_376; var tmp31 *lang.Keyword = A_arbace_j2g_decls_A_const_81; tmp29 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(tmp30.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp31.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1))))) } else { tmp29 = and__1927000168__auto____17_2 } } else { tmp29 = and__1927000168__auto____16_3 }
//line :505:1
								if jrt.J2g_Truth(tmp29) {




















									var tmp32 any = A_arbace_j2g_decls_method_forms_fn__1464000325_A_New_O_O_O_O_O_O_O_O(iface__5, static__7, pkg__0, n__1, ab__12, leaf__6, ps__9, mm__2); var tmp33 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000325_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, false); A_arbace_j2g_decls_method_forms_fn__1464000325_A_fn_class = fncls__73d; tmp33 = fncls__73d } else { tmp33 = fncls__73 }; vec__1464000292__16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil).Invoke__O() } else {
//line :505:1
										if A_arbace_j2g_decls_A_const_160 != nil { var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp35 any; var iter__1927001039__auto____16_4 any; var tmp36 any = A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A_New(); var tmp37 *jrt.Class
											var fncls__85 /*line :505:1*/*jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A_fn_class































											if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A_fn_class = fncls__85d; tmp37 = fncls__85d } else { tmp37 = fncls__85 }; iter__1927001039__auto____16_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp36, tmp37, nil); tmp35 = lang.IFn_Cast(iter__1927001039__auto____16_4).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__9)).Ref()))
//line :505:1
											vec__1464000292__16 = lang.Tuple_Create_O_O__IPersistentVector(tmp34.Invoke_O__O(tmp35), lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()).Invoke_O_O_O__O(n__1, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))) } else { vec__1464000292__16 = nil } } } } }
//line :503:1
		var pnames__17 any = lang.RT_Nth_O_I_O__O(vec__1464000292__16, lang.RT_IntCast_J__I(0), nil); var body__18 any = lang.RT_Nth_O_I_O__O(vec__1464000292__16, lang.RT_IntCast_J__I(1), nil); var plist__19 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, ps__9, pnames__17); var plist__20 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(plist__19, pkg__0, r__10); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_232.GetRawRoot__O()); var tmp39 lang.IPersistentVector





































		if jrt.J2g_Truth(static__7) { var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_377; var tmp42 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11)).Ref()); var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp44 lang.IPersistentVector; var tmp45 any; var and__1927000168__auto____21 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(native__14)


			if jrt.J2g_Truth(and__1927000168__auto____21) { tmp45 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_378.GetRawRoot__O()).Invoke_O_O__O(n__1, ab__12) } else { tmp45 = and__1927000168__auto____21 }; if jrt.J2g_Truth(tmp45) { tmp44 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, g__4, nil)).Ref()))) } else { tmp44 = nil }
//line :541:1
			tmp39 = lang.Tuple_Create_O__IPersistentVector(tmp40.Invoke_O_O_O_O__O(tmp41, tmp42, plist__20, tmp43.Invoke_O_O__O(tmp44, body__18))) } else { if jrt.J2g_Truth(iface__5) { var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_decls_A_const_379; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_decls_A_const_380; tmp39 = lang.Tuple_Create_O__IPersistentVector(tmp46.Invoke_O_O_O_O__O(tmp47, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__11)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp48.Invoke_O_O__O(tmp49, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__4)), plist__20)), lang.RT_Meta_O__IPersistentMap(plist__20)), body__18)) } else { if jrt.J2g_Truth(leaf__6) { var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_decls_A_const_381; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp53 any = A_arbace_j2g_decls_A_const_382; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp55 any = A_arbace_j2g_decls_A_const_383; tmp39 = lang.Tuple_Create_O__IPersistentVector(tmp50.Invoke_O_O_O_O__O(tmp51, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(base__11), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp52.Invoke_O_O__O(tmp53, tmp54.Invoke_O_O__O(tmp55, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__4))), plist__20)), lang.RT_Meta_O__IPersistentMap(plist__20)), body__18)) } else { if A_arbace_j2g_decls_A_const_160 != nil { var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp57 any = A_arbace_j2g_decls_A_const_384; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp59 any = A_arbace_j2g_decls_A_const_385; var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp61 any = A_arbace_j2g_decls_A_const_386; var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_decls_A_const_387; tmp39 = lang.Tuple_Create_O__IPersistentVector(tmp56.Invoke_O_O_O_O__O(tmp57, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_334.GetRawRoot__O()).Invoke_O__O(base__11)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp58.Invoke_O_O__O(tmp59, tmp60.Invoke_O_O__O(tmp61, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__4))), tmp62.Invoke_O_O__O(tmp63, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__4, nil)).Ref()))), plist__20)), lang.RT_Meta_O__IPersistentMap(plist__20)), body__18)) } else { tmp39 = nil } } } }
//line :540:1
		return tmp38.Invoke_O_O__O(mm__2, tmp39) } }
//line :507:1
func A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A{}; t.Ctor(); return t }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A) Ctor() {}
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A) Invoke_O_O__O(self, s__1464000296__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A_New_O_O(s__1464000296__1, self); var tmp2 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_172, false); A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A_fn_class = fncls__75d; tmp2 = fncls__75d } else { tmp2 = fncls__75 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :507:1
func A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A{}; t.Ctor_O_O(p0, p1); return t }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A) Ctor_O_O(c__s__1464000296, c__iter__1464000295 any) { t.F_s__1464000296 = c__s__1464000296; t.F_iter__1464000295 = c__iter__1464000295 }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A) Invoke_O__O(self any) any { { var s__1464000296__1 any; var t_ any = t.F_s__1464000296; t.F_s__1464000296 = nil; s__1464000296__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000296__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000296__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000296__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000296__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000298__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000298__6); var tmp2 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_173, false); A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A_fn_class = fncls__74d; tmp2 = fncls__74d } else { tmp2 = fncls__74 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000295); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000298__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000296__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000298__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000296__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000295); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000296__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :507:1
func A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000298 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000298 = c__b__1464000298 }
//line :507:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A) Invoke_O__O(self any) any { { var i__1464000297__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000297__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000297__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000298; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000297__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000297__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A{}; t.Ctor(); return t }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A) Ctor() {}
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A) Invoke_O_O__O(self, s__1464000306__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A_New_O_O(self, s__1464000306__1); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_174, false); A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :520:1
func A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A{}; t.Ctor_O_O(p0, p1); return t }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A) Ctor_O_O(c__iter__1464000305, c__s__1464000306 any) { t.F_iter__1464000305 = c__iter__1464000305; t.F_s__1464000306 = c__s__1464000306 }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A) Invoke_O__O(self any) any { { var s__1464000306__1 any; var t_ any = t.F_s__1464000306; t.F_s__1464000306 = nil; s__1464000306__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000306__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000306__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000306__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000306__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000308__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A_New_O_I_O(b__1464000308__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_175, false); A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000305); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000308__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000306__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000308__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000306__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000305); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000306__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :520:1
func A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A) Ctor_O_I_O(c__b__1464000308 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000308 = c__b__1464000308; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :520:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A) Invoke_O__O(self any) any { { var i__1464000307__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000307__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000307__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000308; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000307__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000307__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A{}; t.Ctor(); return t }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A) Ctor() {}
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A) Invoke_O_O__O(self, s__1464000316__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A_New_O_O(self, s__1464000316__1); var tmp2 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_176, false); A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A_fn_class = fncls__81d; tmp2 = fncls__81d } else { tmp2 = fncls__81 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :524:1
func A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A{}; t.Ctor_O_O(p0, p1); return t }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A) Ctor_O_O(c__iter__1464000315, c__s__1464000316 any) { t.F_iter__1464000315 = c__iter__1464000315; t.F_s__1464000316 = c__s__1464000316 }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A) Invoke_O__O(self any) any { { var s__1464000316__1 any; var t_ any = t.F_s__1464000316; t.F_s__1464000316 = nil; s__1464000316__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000316__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000316__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000316__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000316__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000318__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A_New_O_I_O(b__1464000318__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_177, false); A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A_fn_class = fncls__80d; tmp2 = fncls__80d } else { tmp2 = fncls__80 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000315); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000318__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000316__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000318__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000316__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000315); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000316__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :524:1
func A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A) Ctor_O_I_O(c__b__1464000318 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000318 = c__b__1464000318; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :524:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A) Invoke_O__O(self any) any { { var i__1464000317__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000317__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000317__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000318; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000317__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000317__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_method_forms_fn__1464000325_A_New_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7 any) *A_arbace_j2g_decls_method_forms_fn__1464000325_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000325_A{}; t.Ctor_O_O_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5, p6, p7); return t }
//line :526:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_A) Ctor_O_O_O_O_O_O_O_O(c__iface, c__static, c__pkg, c__n, c__ab, c__leaf, c__ps, c__mm any) { t.F_iface = c__iface; t.F_static = c__static; t.F_pkg = c__pkg; t.F_n = c__n; t.F_ab = c__ab; t.F_leaf = c__leaf; t.F_ps = c__ps; t.F_mm = c__mm }
//line :526:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_A) Invoke_O__O(self any) any { var tmp1 any; tmp19 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_362.GetRawRoot__O()); var tmp3 any = t.F_pkg; var tmp4 any = t.F_n; var tmp5 any = t.F_mm; var tmp6 any; var t_ any = t.F_ab; t.F_ab = nil; tmp6 = t_; var tmp7 any = tmp6; var tmp8 any = A_arbace_j2g_decls_A_const_86; var tmp9 any; var tmp10 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_static); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_iface) } else { tmp10 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp10) { tmp9 = A_arbace_j2g_decls_A_const_363 } else { tmp9 = nil }; var tmp11 any = tmp9; var tmp12 any = A_arbace_j2g_decls_A_const_87; var tmp13 any
												if jrt.J2g_Truth(t.F_static) { tmp13 = nil } else { var tmp14 any; var or__1927000174__auto____3 any; var t__2 any = t.F_leaf; t.F_leaf = nil; or__1927000174__auto____3 = t__2; if jrt.J2g_Truth(or__1927000174__auto____3) { tmp14 = or__1927000174__auto____3 } else { tmp14 = t.F_iface }; if jrt.J2g_Truth(tmp14) { var tmp15 any; var t__3 any = t.F_iface; t.F_iface = nil; tmp15 = t__3; if jrt.J2g_Truth(tmp15) { tmp13 = A_arbace_j2g_decls_A_const_364 } else { tmp13 = A_arbace_j2g_decls_A_const_365 } } else { tmp13 = A_arbace_j2g_decls_A_const_366 } }
//line :527:1
		var tmp16 any = tmp13; var tmp17 any = A_arbace_j2g_decls_A_const_88; var tmp18 any; var t__4 any = t.F_static; t.F_static = nil; tmp18 = t__4; tmp1 = tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp7, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp11, tmp12, tmp16, tmp17, tmp18))) }
//line :526:1
	return nil }(); if tmp19 != nil { if jrt.Exception_InstanceOf(tmp19) { var ex__3 jrt.Exception_I = jrt.Exception_Cast(tmp19)
		var tmp20 /*line :526:1*/*lang.Keyword = A_arbace_j2g_decls_A_const_367




		if jrt.J2g_Truth(tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_368.GetRawRoot__O()).Invoke_O__O(ex__3))) { var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp22 any; var iter__1927001039__auto____4 any; var tmp23 any = A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A_New(); var tmp24 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A_fn_class
			if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_167, false); A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A_fn_class = fncls__72d; tmp24 = fncls__72d } else { tmp24 = fncls__72 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp25 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____4); var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()); var tmp27 any; var t__5 any = t.F_ps; t.F_ps = nil; tmp27 = t__5; tmp22 = tmp25.Invoke_O__O(tmp26.Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(tmp27)).Ref()))
//line :531:1
			var tmp28 any = tmp21.Invoke_O__O(tmp22); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_decls_A_const_370; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()); var tmp33 any; var t__6 any = t.F_pkg

			t.F_pkg = nil; tmp33 = t__6
//line :531:1
			var tmp34 any = tmp32.Invoke_O_O__O(tmp33, Lit_99); var tmp35 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_12, nil, nil, Lit_168, nil); var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()); var tmp37 any; var t__7 any = t.F_n


			t.F_n = nil; tmp37 = t__7
//line :531:1
			var tmp38 any = tmp36.Invoke_O_O_O__O(tmp37, Lit_11, Lit_12); var tmp39 any = A_arbace_j2g_decls_A_const_100.Invoke_O__O(t.F_mm); var tmp40 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp41 any; var t__8 any = t.F_mm


			t.F_mm = nil; tmp41 = t__8
//line :531:1
			tmp1 = lang.Tuple_Create_O_O__IPersistentVector(tmp28, lang.Tuple_Create_O__IPersistentVector(tmp29.Invoke_O_O__O(tmp30, tmp31.Invoke_O_O__O(tmp34, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp35, jrt.RefArrayOf(jrt.Object_class, tmp38, nil, tmp39, tmp40.Invoke_O__O(tmp41), nil, ex__3.GetMessage__String().Ref())).Ref())))) } else { var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_369.GetRawRoot__O()); var tmp43 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_169, nil, Lit_12, nil, nil, Lit_168, nil); var tmp44 any; var t__9 any = t.F_n



				t.F_n = nil; tmp44 = t__9
//line :531:1
				var tmp45 any = tmp44; var tmp46 any = A_arbace_j2g_decls_A_const_100.Invoke_O__O(t.F_mm); var tmp47 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp48 any; var t__10 any = t.F_mm



				t.F_mm = nil; tmp48 = t__10
//line :531:1
				var tmp49 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp43, jrt.RefArrayOf(jrt.Object_class, nil, tmp45, nil, tmp46, tmp47.Invoke_O__O(tmp48), nil, ex__3.GetMessage__String().Ref())).Ref(); var tmp50 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp50 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp42.Invoke_O_O_O__O(tmp49, tmp50.Ref(), ex__3)))) } } else {
//line :526:1
					panic(tmp19) } }; return tmp1 }





func A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A_New() *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A) Ctor() {}
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A) Invoke_O_O__O(self, s__1464000327__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A_New_O_O(self, s__1464000327__1); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_170, false); A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :532:1
func A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A{}; t.Ctor_O_O(p0, p1); return t }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A) Ctor_O_O(c__iter__1464000326, c__s__1464000327 any) { t.F_iter__1464000326 = c__iter__1464000326; t.F_s__1464000327 = c__s__1464000327 }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A) Invoke_O__O(self any) any { { var s__1464000327__1 any; var t_ any = t.F_s__1464000327; t.F_s__1464000327 = nil; s__1464000327__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000327__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000327__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000327__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000327__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000329__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A_New_O_I_O(b__1464000329__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_171, false); A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A_fn_class = fncls__70d; tmp2 = fncls__70d } else { tmp2 = fncls__70 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000326); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000329__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000327__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000329__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000327__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000326); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000327__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :532:1
func A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A) Ctor_O_I_O(c__b__1464000329 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000329 = c__b__1464000329; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :532:1
func (t *A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A) Invoke_O__O(self any) any { { var i__1464000328__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000328__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000328__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000329; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000328__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000328__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A_New() *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A{}; t.Ctor(); return t }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A) Ctor() {}
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A) Invoke_O_O__O(self, s__1464000338__1 any) any { var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A_New_O_O(self, s__1464000338__1); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_178, false); A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :537:1
func A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A{}; t.Ctor_O_O(p0, p1); return t }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A) Ctor_O_O(c__iter__1464000337, c__s__1464000338 any) { t.F_iter__1464000337 = c__iter__1464000337; t.F_s__1464000338 = c__s__1464000338 }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A) Invoke_O__O(self any) any { { var s__1464000338__1 any; var t_ any = t.F_s__1464000338; t.F_s__1464000338 = nil; s__1464000338__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000338__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000338__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000338__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000338__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000340__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A_New_I_O_O(size__1927001038__auto____5, b__1464000340__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_179, false); A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A_fn_class = fncls__83d; tmp2 = fncls__83d } else { tmp2 = fncls__83 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000337); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000340__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000338__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000340__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000338__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000337); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000338__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :537:1
func A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000340, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000340 = c__b__1464000340; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :537:1
func (t *A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A) Invoke_O__O(self any) any { { var i__1464000339__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000339__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000339__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000340; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000339__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000339__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



















func A_arbace_j2g_decls_forwarder_A_New() *A_arbace_j2g_decls_forwarder_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_A{}; t.Ctor(); return t }
//line :557:1
func (t *A_arbace_j2g_decls_forwarder_A) Ctor() {}
//line :557:1
func (t *A_arbace_j2g_decls_forwarder_A) Invoke_O_O_O_O_O__O(self, pkg__0, n__1, p__1464000348__2, impl__3 any) any { var vec__1464000349__5 any = p__1464000348__2; var name__6 any = lang.RT_Nth_O_I_O__O(vec__1464000349__5, lang.RT_IntCast_J__I(0), nil); var desc__7 any = lang.RT_Nth_O_I_O__O(vec__1464000349__5, lang.RT_IntCast_J__I(1), nil); var k__8 any = vec__1464000349__5; var g__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var vec__1464000352__10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(desc__7); var ps__11 any = lang.RT_Nth_O_I_O__O(vec__1464000352__10, lang.RT_IntCast_J__I(0), nil); var r__12 any = lang.RT_Nth_O_I_O__O(vec__1464000352__10, lang.RT_IntCast_J__I(1), nil); var base__13 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(name__6, desc__7); var pn__14 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____14 any; var tmp3 any = A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A_New(); var tmp4 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A_fn_class; _ = k__8; if





	fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A_fn_class = fncls__89d; tmp4 = fncls__89d } else { tmp4 = fncls__89 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__11)).Ref())); pn__14 = tmp1.Invoke_O__O(tmp2); var tmp5 lang.IFn = /*line :557:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_390; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_391; var plist__15 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__9))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, ps__11, pn__14))), pkg__0, r__12); var call__16 any; var G__1464000365__16_ any = A_arbace_j2g_decls_A_const_167.Invoke_O__O(impl__3); L1:







	switch { default: switch lang.Util_Hash_O__I(G__1464000365__16_) >> 3 & 3 { case 0: if any(G__1464000365__16_) == any(A_arbace_j2g_decls_A_const_388) {

		call__16 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(pkg__0, A_arbace_j2g_decls_A_const_333.Invoke_O__O(impl__3), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__13)).Ref()), A_arbace_j2g_decls_A_const_392, pn__14)
//line :565:1
		break L1 }; case 1: if any(G__1464000365__16_) == any(A_arbace_j2g_decls_A_const_34) {
			call__16 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_91, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__13)).Ref()), A_arbace_j2g_decls_A_const_393, A_arbace_j2g_decls_A_const_394, pn__14)
//line :565:1
			break L1 }; case 3: if any(G__1464000365__16_) == any(A_arbace_j2g_decls_A_const_389) {
				call__16 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()).Invoke_O_O_O_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_91, nil), jrt.RefArrayOf(jrt.Object_class, nil, base__13)).Ref()), A_arbace_j2g_decls_A_const_393, A_arbace_j2g_decls_A_const_394, pn__14)
//line :565:1
				break L1 }; default:}; call__16 = nil}; if



	jrt.J2g_Truth(call__16) {
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_395; var tmp11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(base__13); var tmp12 any; if lang.Util_Equiv_O_O__Z(Lit_51, r__12) { tmp12 = call__16 } else { tmp12 = call__16 }; return tmp9.Invoke_O_O_O_O__O(tmp10, tmp11, plist__15, tmp12) } else {
//line :569:1
			return nil } }
//line :563:1
func A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A_New() *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A{}; t.Ctor(); return t }
//line :563:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A) Ctor() {}
//line :563:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A) Invoke_O_O__O(self, s__1464000356__1 any) any { var tmp1 any = A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A_New_O_O(s__1464000356__1, self); var tmp2 *jrt.Class; var fncls__88 *jrt.Class = A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A_fn_class; if fncls__88 == nil { var fncls__88d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A_fn_class = fncls__88d; tmp2 = fncls__88d } else { tmp2 = fncls__88 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :563:1
func A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A{}; t.Ctor_O_O(p0, p1); return t }
//line :563:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A) Ctor_O_O(c__s__1464000356, c__iter__1464000355 any) { t.F_s__1464000356 = c__s__1464000356; t.F_iter__1464000355 = c__iter__1464000355 }
//line :563:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A) Invoke_O__O(self any) any { { var s__1464000356__1 any; var t_ any = t.F_s__1464000356; t.F_s__1464000356 = nil; s__1464000356__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000356__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000356__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000356__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000356__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000358__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A_New_O_I_O(b__1464000358__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A_fn_class = fncls__87d; tmp2 = fncls__87d } else { tmp2 = fncls__87 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000355); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000358__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000356__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000358__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000356__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000355); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000356__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :563:1
func A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :563:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A) Ctor_O_I_O(c__b__1464000358 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000358 = c__b__1464000358; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :563:1
func (t *A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A) Invoke_O__O(self any) any { { var i__1464000357__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000357__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000357__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000358; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000357__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000357__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }








func A_arbace_j2g_decls_object_forms_A_New() *A_arbace_j2g_decls_object_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_object_forms_A{}; t.Ctor(); return t }
//line :572:1
func (t *A_arbace_j2g_decls_object_forms_A) Ctor() {}
//line :572:1
func (t *A_arbace_j2g_decls_object_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_397; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_398; var recv__4 any = tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3))); var ts__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_396.GetRawRoot__O()).Invoke_O_O__O(n__1, A_arbace_j2g_decls_A_const_399); var cl__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_396.GetRawRoot__O()).Invoke_O_O__O(n__1, A_arbace_j2g_decls_A_const_400); var cloneable__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_329.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, n__1, nil)).Ref(), Lit_181); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_259.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_402; var tmp9 any = A_arbace_j2g_decls_A_const_403; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_decls_A_const_406; var tmp12 any = tmp7.Invoke_O_O_O_O_O__O(tmp8, tmp9, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), A_arbace_j2g_decls_A_const_405), tmp10.Invoke_O_O_O__O(tmp11, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_407, A_arbace_j2g_decls_A_const_408, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_409, nil)), A_arbace_j2g_decls_A_const_404); var tmp13 any; var temp__1927000408__auto____8 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_object_forms_fn__1464000368_A_New(); var tmp17 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_j2g_decls_object_forms_fn__1464000368_A_fn_class; if











	fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_182, false); A_arbace_j2g_decls_object_forms_fn__1464000368_A_fn_class = fncls__90d; tmp17 = fncls__90d } else { tmp17 = fncls__90 }; temp__1927000408__auto____8 = tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_410.GetRawRoot__O()).Invoke_O__O(n__1))); if jrt.J2g_Truth(temp__1927000408__auto____8) { var f__9 any = temp__1927000408__auto____8; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_A_const_411; var tmp20 any = A_arbace_j2g_decls_A_const_412; var tmp21 any = A_arbace_j2g_decls_A_const_18; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_decls_A_const_413; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_414; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_415; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_417
		tmp13 = tmp18.Invoke_O_O_O_O_O__O(tmp19, tmp20, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp22.Invoke_O_O__O(tmp23, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_183))))), tmp24.Invoke_O_O_O__O(tmp25, tmp26.Invoke_O_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__9)))).Ref()), A_arbace_j2g_decls_A_const_416), nil), tmp28.Invoke_O_O__O(tmp29, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__9)))).Ref()), A_arbace_j2g_decls_A_const_418))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())) } else {



			var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_decls_A_const_419; var tmp32 any = A_arbace_j2g_decls_A_const_420; var tmp33 any = A_arbace_j2g_decls_A_const_18; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp35 any = A_arbace_j2g_decls_A_const_421; tmp13 = tmp30.Invoke_O_O_O_O__O(tmp31, tmp32, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp34.Invoke_O_O__O(tmp35, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_183))))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())) }; var tmp36 any = tmp13; var tmp37 any; var tmp38 any = A_arbace_j2g_decls_A_const_401; if
	lang.Util_Equiv_O_O__Z(tmp38, A_arbace_j2g_decls_A_const_167.Invoke_O__O(ts__5)) {
		var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_decls_A_const_422; var tmp41 any = A_arbace_j2g_decls_A_const_423; var tmp42 any = A_arbace_j2g_decls_A_const_18; var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_A_const_424; tmp37 = tmp39.Invoke_O_O_O_O__O(tmp40, tmp41, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp42, tmp43.Invoke_O_O__O(tmp44, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_184))))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_185), A_arbace_j2g_decls_A_const_425)) } else {
//line :590:1
			tmp37 = nil }; var tmp45 any = tmp37; var tmp46 any; var tmp47 any = A_arbace_j2g_decls_A_const_401; if


	lang.Util_Equiv_O_O__Z(tmp47, A_arbace_j2g_decls_A_const_167.Invoke_O__O(cl__6)) {
		var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_decls_A_const_426; var tmp50 any = A_arbace_j2g_decls_A_const_427; tmp46 = tmp48.Invoke_O_O_O_O__O(tmp49, tmp50, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), A_arbace_j2g_decls_A_const_428), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_186), A_arbace_j2g_decls_A_const_429)) } else {
//line :593:1
			tmp46 = nil }; var tmp51 any = tmp46; var tmp52 lang.IFn = /*line :580:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp53 any = A_arbace_j2g_decls_A_const_430; var tmp54 any = A_arbace_j2g_decls_A_const_431; var tmp55 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(recv__4), A_arbace_j2g_decls_A_const_432); var tmp56 any; if















	jrt.J2g_Truth(cloneable__7) {
		var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp58 any = A_arbace_j2g_decls_A_const_433; var tmp59 any = A_arbace_j2g_decls_A_const_434; var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp61 any = A_arbace_j2g_decls_A_const_437; tmp56 = tmp57.Invoke_O_O_O_O__O(tmp58, lang.Tuple_Create_O_O__IPersistentVector(tmp59, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_435, A_arbace_j2g_decls_A_const_436)), tmp60.Invoke_O_O__O(tmp61, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_438, A_arbace_j2g_decls_A_const_439)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_440, A_arbace_j2g_decls_A_const_441)) } else {


			var tmp62 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp63 any = A_arbace_j2g_decls_A_const_442; tmp56 = tmp62.Invoke_O_O__O(tmp63, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_187), A_arbace_j2g_decls_A_const_443)) }; return /*line :580:1*/ tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp12, tmp36, tmp45, tmp51, tmp52.Invoke_O_O_O_O__O(tmp53, tmp54, tmp55, tmp56))) }



func A_arbace_j2g_decls_object_forms_fn__1464000368_A_New() *A_arbace_j2g_decls_object_forms_fn__1464000368_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_object_forms_fn__1464000368_A{}; t.Ctor(); return t }
//line :584:1
func (t *A_arbace_j2g_decls_object_forms_fn__1464000368_A) Ctor() {}
//line :584:1
func (t *A_arbace_j2g_decls_object_forms_fn__1464000368_A) Invoke_O_O__O(self, p1__1464000367_SHARP___1 any) any { var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(Lit_188, A_arbace_j2g_decls_A_const_100.Invoke_O__O(p1__1464000367_SHARP___1)); if and__1927000168__auto____2 { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(p1__1464000367_SHARP___1)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }

















func A_arbace_j2g_decls_dispatch_forms_A_New() *A_arbace_j2g_decls_dispatch_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_A{}; t.Ctor(); return t }
//line :602:1
func (t *A_arbace_j2g_decls_dispatch_forms_A) Ctor() {}
//line :602:1
func (t *A_arbace_j2g_decls_dispatch_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var own__3 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_152.GetRawRoot__O()); var tmp2 any; var iter__1927001039__auto____3 any; var tmp3 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A_New(); var tmp4 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A_fn_class; if


	fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_104, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A_fn_class = fncls__102d; tmp4 = fncls__102d } else { tmp4 = fncls__102 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); tmp2 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_451.GetRawRoot__O()).Invoke_O__O(n__1)); own__3 = tmp1.Invoke_O__O(tmp2); var leaf__4 any = /*line :602:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1); var iter__1927001039__auto____5 any; var tmp5 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A_New_O_O_O_O(own__3, pkg__0, n__1, leaf__4); var tmp6 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A_fn_class; if





	fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_105, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A_fn_class = fncls__99d; tmp6 = fncls__99d } else { tmp6 = fncls__99 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp7 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____5); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_452.GetRawRoot__O()).Invoke_O__O(n__1); var tmp10 any; var iter__1927001039__auto____6 any; var tmp11 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A_New(); var tmp12 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_106, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A_fn_class = fncls__105d; tmp12 = fncls__105d } else { tmp12 = fncls__105 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_453.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_454.GetRawRoot__O())); return tmp7.Invoke_O__O(tmp8.Invoke_O_O__O(tmp9, tmp10)) }
//line :605:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A{}; t.Ctor(); return t }
//line :605:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A) Ctor() {}
//line :605:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A) Invoke_O_O__O(self, s__1464000372__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A_New_O_O(s__1464000372__1, self); var tmp2 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_107, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A_fn_class = fncls__101d; tmp2 = fncls__101d } else { tmp2 = fncls__101 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :605:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A{}; t.Ctor_O_O(p0, p1); return t }
//line :605:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A) Ctor_O_O(c__s__1464000372, c__iter__1464000371 any) { t.F_s__1464000372 = c__s__1464000372; t.F_iter__1464000371 = c__iter__1464000371 }
//line :605:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A) Invoke_O__O(self any) any { { var s__1464000372__1 any; var t_ any = t.F_s__1464000372; t.F_s__1464000372 = nil; s__1464000372__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000372__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000372__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000372__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000372__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000374__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A_New_I_O_O(size__1927001038__auto____5, b__1464000374__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_108, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A_fn_class = fncls__100d; tmp2 = fncls__100d } else { tmp2 = fncls__100 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000371); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000374__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000372__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000374__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000372__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000371); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000372__3))) } else { s__1464000372__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000372__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :605:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :605:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__b__1464000374, c__c__1927001037__auto__ any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000374 = c__b__1464000374; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :605:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A) Invoke_O__O(self any) any { { var i__1464000373__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000373__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000373__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_116.GetRawRoot__O()).Invoke_O_O__O(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp4 any = t.F_b__1464000374; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))); i__1464000373__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000373__1); continue L1 } else { i__1464000373__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000373__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A) Ctor_O_O_O_O(c__own, c__pkg, c__n, c__leaf any) { t.F_own = c__own; t.F_pkg = c__pkg; t.F_n = c__n; t.F_leaf = c__leaf }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A) Invoke_O_O__O(self, s__1464000382__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A_New_O_O_O_O_O_O(t.F_own, t.F_pkg, t.F_n, s__1464000382__1, self, t.F_leaf); var tmp2 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_109, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A_fn_class = fncls__98d; tmp2 = fncls__98d } else { tmp2 = fncls__98 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :608:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A) Ctor_O_O_O_O_O_O(c__own, c__pkg, c__n, c__s__1464000382, c__iter__1464000381, c__leaf any) { t.F_own = c__own; t.F_pkg = c__pkg; t.F_n = c__n; t.F_s__1464000382 = c__s__1464000382; t.F_iter__1464000381 = c__iter__1464000381; t.F_leaf = c__leaf }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A) Invoke_O__O(self any) any { { var s__1464000382__1 any; var t_ any = t.F_s__1464000382; t.F_s__1464000382 = nil; s__1464000382__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000382__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000382__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000382__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000382__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000384__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A_New_O_O_O_O_I_O_O(t.F_own, t.F_pkg, t.F_n, t.F_leaf, size__1927001038__auto____5, b__1464000384__6, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_110, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A_fn_class = fncls__94d; tmp2 = fncls__94d } else { tmp2 = fncls__94 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000381); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000384__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000382__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000384__6), nil) } } else { var vec__1464000408__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000382__3); var k__5 any = lang.RT_Nth_O_I_O__O(vec__1464000408__4, lang.RT_IntCast_J__I(0), nil); var mm__6 any = lang.RT_Nth_O_I_O__O(vec__1464000408__4, lang.RT_IntCast_J__I(1), nil); var impl__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_396.GetRawRoot__O()).Invoke_O_O__O(t.F_n, k__5); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp5 any; var and__1927000168__auto____8 any = t.F_leaf; _ = mm__6

	if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_own, k__5); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp6 any = t.F_n; tmp5 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp6, A_arbace_j2g_decls_A_const_333.Invoke_O__O(impl__7))).Ref() } else { tmp5 = and__1927000168__auto____9 } } else { tmp5 = and__1927000168__auto____8 }
//line :608:1
	if jrt.J2g_Truth(tmp4.Invoke_O__O(tmp5)) { var f__8 any


		if lang.Util_Identical_O_O__Z(impl__7, nil) { var vec__1464000411__8 any = k__5; var name__9 any = lang.RT_Nth_O_I_O__O(vec__1464000411__8, lang.RT_IntCast_J__I(0), nil); var desc__10 any = lang.RT_Nth_O_I_O__O(vec__1464000411__8, lang.RT_IntCast_J__I(1), nil); var vec__1464000414__11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(desc__10); var ps__12 any = lang.RT_Nth_O_I_O__O(vec__1464000414__11, lang.RT_IntCast_J__I(0), nil); var r__13 any = lang.RT_Nth_O_I_O__O(vec__1464000414__11, lang.RT_IntCast_J__I(1), nil); var pn__14 any; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp8 any; var iter__1927001039__auto____14 any; var tmp9 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A_New(); var tmp10 *jrt.Class
			var fncls__97 /*line :611:1*/*jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A_fn_class



			if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_111, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A_fn_class = fncls__97d; tmp10 = fncls__97d } else { tmp10 = fncls__97 }; iter__1927001039__auto____14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); tmp8 = lang.IFn_Cast(iter__1927001039__auto____14).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__12)).Ref())); pn__14 = tmp7.Invoke_O__O(tmp8)
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_446; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_447; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_448; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_decls_A_const_449; f__8 = tmp11.Invoke_O_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(name__9, desc__10)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(t.F_n)))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__12, pn__14))), t.F_pkg, r__13), lang.Tuple_Create_O__IPersistentVector(tmp17.Invoke_O_O__O(tmp18, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_99), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_112, nil, Lit_12, nil, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, Lit_11, Lit_12), nil, name__9, desc__10)).Ref())))) } else {
//line :611:1
				var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_450); if jrt.J2g_Truth(tmp19.Invoke_O__O(A_arbace_j2g_decls_A_const_167.Invoke_O__O(impl__7))) { f__8 = nil } else { if A_arbace_j2g_decls_A_const_160 != nil {








					f__8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_445.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_pkg, t.F_n, k__5, impl__7) } else {
//line :611:1
						f__8 = nil } } }
//line :608:1
		if jrt.J2g_Truth(f__8) { var tmp20 lang.IFn = lang.IFn_Cast(t.F_iter__1464000381); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(f__8, tmp20.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000382__3))) } else { s__1464000382__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000382__3); continue L1 } } else { s__1464000382__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000382__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :608:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A_New_O_O_O_O_I_O_O(p0, p1, p2, p3 any, p4 int32, p5, p6 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A{}; t.Ctor_O_O_O_O_I_O_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A) Ctor_O_O_O_O_I_O_O(c__own, c__pkg, c__n, c__leaf any, c__size__1927001038__auto__ int32, c__b__1464000384, c__c__1927001037__auto__ any) { t.F_own = c__own; t.F_pkg = c__pkg; t.F_n = c__n; t.F_leaf = c__leaf; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_b__1464000384 = c__b__1464000384; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A) Invoke_O__O(self any) any { { var i__1464000383__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000383__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1464000388__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000383__1)); var k__3 any = lang.RT_Nth_O_I_O__O(vec__1464000388__2, lang.RT_IntCast_J__I(0), nil); var mm__4 any = lang.RT_Nth_O_I_O__O(vec__1464000388__2, lang.RT_IntCast_J__I(1), nil); var impl__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_396.GetRawRoot__O()).Invoke_O_O__O(t.F_n, k__3); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp3 any; var and__1927000168__auto____6 any = t.F_leaf; _ = mm__4

	if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(t.F_own, k__3); if jrt.J2g_Truth(and__1927000168__auto____7) { var tmp4 any = t.F_n; tmp3 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp4, A_arbace_j2g_decls_A_const_333.Invoke_O__O(impl__5))).Ref() } else { tmp3 = and__1927000168__auto____7 } } else { tmp3 = and__1927000168__auto____6 }
//line :608:1
	if jrt.J2g_Truth(tmp2.Invoke_O__O(tmp3)) { var f__6 any


		if lang.Util_Identical_O_O__Z(impl__5, nil) { var vec__1464000391__6 any = k__3; var name__7 any = lang.RT_Nth_O_I_O__O(vec__1464000391__6, lang.RT_IntCast_J__I(0), nil); var desc__8 any = lang.RT_Nth_O_I_O__O(vec__1464000391__6, lang.RT_IntCast_J__I(1), nil); var vec__1464000394__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(desc__8); var ps__10 any = lang.RT_Nth_O_I_O__O(vec__1464000394__9, lang.RT_IntCast_J__I(0), nil); var r__11 any = lang.RT_Nth_O_I_O__O(vec__1464000394__9, lang.RT_IntCast_J__I(1), nil); var pn__12 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____12 any; var tmp7 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A_New(); var tmp8 *jrt.Class
			var fncls__93 /*line :611:1*/*jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A_fn_class



			if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_113, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A_fn_class = fncls__93d; tmp8 = fncls__93d } else { tmp8 = fncls__93 }; iter__1927001039__auto____12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____12).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__10)).Ref())); pn__12 = tmp5.Invoke_O__O(tmp6)
			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_446; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_447; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_448; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_449; f__6 = tmp9.Invoke_O_O_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(name__7, desc__8)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O_O__O(tmp12, tmp13.Invoke_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(t.F_n)))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__10, pn__12))), t.F_pkg, r__11), lang.Tuple_Create_O__IPersistentVector(tmp15.Invoke_O_O__O(tmp16, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_99), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_112, nil, Lit_12, nil, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, Lit_11, Lit_12), nil, name__7, desc__8)).Ref())))) } else {
//line :611:1
				var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_444); if jrt.J2g_Truth(tmp17.Invoke_O__O(A_arbace_j2g_decls_A_const_167.Invoke_O__O(impl__5))) { f__6 = nil } else { if A_arbace_j2g_decls_A_const_160 != nil {








					f__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_445.GetRawRoot__O()).Invoke_O_O_O_O__O(t.F_pkg, t.F_n, k__3, impl__5) } else {
//line :611:1
						f__6 = nil } } }
//line :608:1
		if jrt.J2g_Truth(f__6) { lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1464000384, f__6); i__1464000383__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000383__1); continue L1 } else { i__1464000383__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000383__1); continue L1 } } else { i__1464000383__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000383__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :608:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A{}; t.Ctor(); return t }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A) Ctor() {}
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A) Invoke_O_O__O(self, s__1464000430__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A_New_O_O(self, s__1464000430__1); var tmp2 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_118, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A_fn_class = fncls__104d; tmp2 = fncls__104d } else { tmp2 = fncls__104 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :608:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A{}; t.Ctor_O_O(p0, p1); return t }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A) Ctor_O_O(c__iter__1464000429, c__s__1464000430 any) { t.F_iter__1464000429 = c__iter__1464000429; t.F_s__1464000430 = c__s__1464000430 }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A) Invoke_O__O(self any) any { { var s__1464000430__1 any; var t_ any = t.F_s__1464000430; t.F_s__1464000430 = nil; s__1464000430__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000430__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000430__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000430__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000430__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000432__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A_New_O_I_O(b__1464000432__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_119, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A_fn_class = fncls__103d; tmp2 = fncls__103d } else { tmp2 = fncls__103 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000429); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000432__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000430__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000432__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000430__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000429); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(k__4, nil), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000430__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :608:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A) Ctor_O_I_O(c__b__1464000432 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000432 = c__b__1464000432; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :608:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A) Invoke_O__O(self any) any { { var i__1464000431__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000431__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000431__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000432; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(k__2, nil)); i__1464000431__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000431__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A{}; t.Ctor(); return t }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A) Ctor() {}
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A) Invoke_O_O__O(self, s__1464000398__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A_New_O_O(s__1464000398__1, self); var tmp2 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_114, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A_fn_class = fncls__92d; tmp2 = fncls__92d } else { tmp2 = fncls__92 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :615:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A{}; t.Ctor_O_O(p0, p1); return t }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A) Ctor_O_O(c__s__1464000398, c__iter__1464000397 any) { t.F_s__1464000398 = c__s__1464000398; t.F_iter__1464000397 = c__iter__1464000397 }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A) Invoke_O__O(self any) any { { var s__1464000398__1 any; var t_ any = t.F_s__1464000398; t.F_s__1464000398 = nil; s__1464000398__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000398__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000398__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000398__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000398__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000400__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A_New_O_I_O(b__1464000400__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_115, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A_fn_class = fncls__91d; tmp2 = fncls__91d } else { tmp2 = fncls__91 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000397); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000400__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000398__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000400__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000398__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000397); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000398__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :615:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A) Ctor_O_I_O(c__b__1464000400 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000400 = c__b__1464000400; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A) Invoke_O__O(self any) any { { var i__1464000399__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000399__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000399__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000400; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000399__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000399__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :615:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A_New() *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A{}; t.Ctor(); return t }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A) Ctor() {}
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A) Invoke_O_O__O(self, s__1464000418__1 any) any { var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A_New_O_O(self, s__1464000418__1); var tmp2 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_116, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A_fn_class = fncls__96d; tmp2 = fncls__96d } else { tmp2 = fncls__96 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :615:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A{}; t.Ctor_O_O(p0, p1); return t }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A) Ctor_O_O(c__iter__1464000417, c__s__1464000418 any) { t.F_iter__1464000417 = c__iter__1464000417; t.F_s__1464000418 = c__s__1464000418 }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A) Invoke_O__O(self any) any { { var s__1464000418__1 any; var t_ any = t.F_s__1464000418; t.F_s__1464000418 = nil; s__1464000418__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000418__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000418__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000418__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000418__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000420__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000420__6); var tmp2 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_117, false); A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A_fn_class = fncls__95d; tmp2 = fncls__95d } else { tmp2 = fncls__95 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000417); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000420__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000418__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000420__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000418__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000417); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000418__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :615:1
func A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000420 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000420 = c__b__1464000420 }
//line :615:1
func (t *A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A) Invoke_O__O(self any) any { { var i__1464000419__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000419__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000419__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000420; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000419__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000419__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_j2g_decls_static_forms_A_New() *A_arbace_j2g_decls_static_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_A{}; t.Ctor(); return t }
//line :627:1
func (t *A_arbace_j2g_decls_static_forms_A) Ctor() {}
//line :627:1
func (t *A_arbace_j2g_decls_static_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var iter__1927001039__auto____4 any; var tmp1 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A_New_O_O_O(g__3, pkg__0, n__1); var tmp2 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A_fn_class; if

	fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_245, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A_fn_class = fncls__114d; tmp2 = fncls__114d } else { tmp2 = fncls__114 }; iter__1927001039__auto____4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____4).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_410.GetRawRoot__O()).Invoke_O__O(n__1)) }
//line :629:1
func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :629:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A) Ctor_O_O_O(c__g, c__pkg, c__n any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n }
//line :629:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A) Invoke_O_O__O(self, s__1464000441__1 any) any { var tmp1 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A_New_O_O_O_O_O(t.F_g, t.F_pkg, t.F_n, s__1464000441__1, self); var tmp2 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_246, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A_fn_class = fncls__113d; tmp2 = fncls__113d } else { tmp2 = fncls__113 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :629:1
func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :629:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A) Ctor_O_O_O_O_O(c__g, c__pkg, c__n, c__s__1464000441, c__iter__1464000440 any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_s__1464000441 = c__s__1464000441; t.F_iter__1464000440 = c__iter__1464000440 }
//line :629:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A) Invoke_O__O(self any) any { { var s__1464000441__1 any; var t_ any = t.F_s__1464000441; t.F_s__1464000441 = nil; s__1464000441__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000441__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000441__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000441__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000441__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000443__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A_New_O_O_O_O_I_O(b__1464000443__6, t.F_g, t.F_pkg, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__109 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A_fn_class; if fncls__109 == nil { var fncls__109d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_247, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A_fn_class = fncls__109d; tmp2 = fncls__109d } else { tmp2 = fncls__109 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000440); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000443__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000441__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000443__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000441__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()); var tmp5 any = t.F_g; var s__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O_O__O(tmp5, A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__4))); var cv__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_455.GetRawRoot__O()).Invoke_O__O(f__4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()); var tmp7 any; var tmp8 any; var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457.GetRawRoot__O()).Invoke_O__O(cv__6)



	if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_458.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)); if jrt.J2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(f__4), A_arbace_j2g_decls_A_const_463); if jrt.J2g_Truth(and__1927000168__auto____9) {
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp10 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_472); var and__1927000168__auto____10 any = tmp11.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)); if jrt.J2g_Truth(and__1927000168__auto____10) { var d__11 float64 = lang.RT_DoubleCast_O__D(cv__6); var or__1927000174__auto____12 bool = jrt.Double_IsNaN_D__Z(d__11); if or__1927000174__auto____12 { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____12).Ref() } else { var or__1927000174__auto____13 bool = jrt.Double_IsInfinite_D__Z(d__11); if or__1927000174__auto____13 { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____13).Ref() } else { var and__1927000168__auto____14 bool = lang.Numbers_IsZero_D__Z(d__11); if and__1927000168__auto____14 { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_D__Z(jrt.Math_CopySign_D_D__D(1.0, d__11))).Ref() } else { tmp10 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() } } } } else { tmp10 = and__1927000168__auto____10 }; tmp8 = tmp9.Invoke_O__O(tmp10) } else {
//line :633:1
			tmp8 = and__1927000168__auto____9 } } else { tmp8 = and__1927000168__auto____8 } } else { tmp8 = and__1927000168__auto____7 }
//line :632:1
	if jrt.J2g_Truth(tmp8) { var v__7 any; var G__1464000453__7_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)


	L2: switch { default: switch lang.Util_Hash_O__I(G__1464000453__7_) { case 67: if lang.Util_Equiv_O_O__Z(G__1464000453__7_, Lit_125) {

		var tmp12 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_459.GetRawRoot__O()).Invoke_O__O(cv__6)) { tmp12 = cv__6 } else { tmp12 = jrt.Character_ValueOf_C__Character(lang.RT_CharCast_O__C(cv__6)).Ref() }; v__7 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(lang.RT_IntCast_O__I(tmp12))).Ref()
//line :635:1
		break L2 }; case 68: if lang.Util_Equiv_O_O__Z(G__1464000453__7_, Lit_126) {


			v__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4), cv__6)
//line :635:1
			break L2 }; case 70: if lang.Util_Equiv_O_O__Z(G__1464000453__7_, Lit_127) {


				v__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4), cv__6)
//line :635:1
				break L2 }; case 90: if lang.Util_Equiv_O_O__Z(G__1464000453__7_, Lit_131) {
					v__7 = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(cv__6)).Ref()
//line :635:1
					break L2 }; default:
	}


		v__7 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(cv__6)).Ref()}
		var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_465; var tmp15 any = A_arbace_j2g_decls_A_const_18; var tmp16 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp17 any = t.F_pkg; tmp7 = tmp13.Invoke_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(s__5, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp16.Invoke_O_O__O(tmp17, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)), A_arbace_j2g_decls_A_const_466, v__7))), v__7) } else {
//line :632:1
			var tmp18 any; var and__1927000168__auto____7_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457.GetRawRoot__O()).Invoke_O__O(cv__6)








			if jrt.J2g_Truth(and__1927000168__auto____7_2) { var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_471); tmp18 = tmp19.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4)) } else { tmp18 = and__1927000168__auto____7_2 }
//line :632:1
			if jrt.J2g_Truth(tmp18) {









				var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp21 any = A_arbace_j2g_decls_A_const_467; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp23 any = t.F_pkg; var tmp24 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__5, tmp22.Invoke_O_O__O(tmp23, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4))); var tmp25 any; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp28 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A_New_O_O(f__4, cv__6); var tmp29 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_248, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A_fn_class = fncls__111d; tmp29 = fncls__111d } else { tmp29 = fncls__111 }; tmp25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O(); tmp7 = tmp20.Invoke_O_O_O__O(tmp21, tmp24, tmp25) } else {
//line :632:1
					var tmp30 any; var and__1927000168__auto____7_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457.GetRawRoot__O()).Invoke_O__O(cv__6)










					if jrt.J2g_Truth(and__1927000168__auto____7_3) { tmp30 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_462.GetRawRoot__O()).Invoke_O__O(cv__6) } else { tmp30 = and__1927000168__auto____7_3 }
//line :632:1
					if jrt.J2g_Truth(tmp30) {











						var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_decls_A_const_468; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp34 any = t.F_pkg; var tmp35 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__5, tmp33.Invoke_O_O__O(tmp34, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__4))); var tmp36 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp37.Invoke_O_O__O(tmp38, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp39 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A_New_O(cv__6); var tmp40 *jrt.Class; var fncls__112 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A_fn_class; if fncls__112 == nil { var fncls__112d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_249, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A_fn_class = fncls__112d; tmp40 = fncls__112d } else { tmp40 = fncls__112 }; tmp36 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil).Invoke__O(); tmp7 = tmp31.Invoke_O_O_O__O(tmp32, tmp35, tmp36) } else {
//line :632:1
							if A_arbace_j2g_decls_A_const_160 != nil {













								var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp42 any = A_arbace_j2g_decls_A_const_469; tmp7 = tmp41.Invoke_O_O__O(tmp42, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_470.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__4))) } else {
//line :632:1
									tmp7 = nil } } } }
//line :629:1
	var tmp43 lang.IFn = lang.IFn_Cast(t.F_iter__1464000440); return tmp6.Invoke_O_O__O(tmp7, tmp43.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000441__3))) } else { s__1464000441__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000441__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :629:1
func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :629:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A) Ctor_O_O_O_O_I_O(c__b__1464000443, c__g, c__pkg, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000443 = c__b__1464000443; t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :629:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A) Invoke_O__O(self any) any { { var i__1464000442__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000442__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000442__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()); var tmp3 any = t.F_g; var s__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__2))); var cv__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_455.GetRawRoot__O()).Invoke_O__O(f__2); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp5 any = t.F_b__1464000443; var tmp6 any; var tmp7 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457.GetRawRoot__O()).Invoke_O__O(cv__4)



	if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_458.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)); if jrt.J2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(f__2), A_arbace_j2g_decls_A_const_463); if jrt.J2g_Truth(and__1927000168__auto____7) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()); var tmp9 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_464); var and__1927000168__auto____8 any = tmp10.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)); if jrt.J2g_Truth(and__1927000168__auto____8) { var d__9 float64 = lang.RT_DoubleCast_O__D(cv__4); var or__1927000174__auto____10 bool = jrt.Double_IsNaN_D__Z(d__9); if or__1927000174__auto____10 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____10).Ref() } else { var or__1927000174__auto____11 bool = jrt.Double_IsInfinite_D__Z(d__9); if or__1927000174__auto____11 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 bool = lang.Numbers_IsZero_D__Z(d__9); if and__1927000168__auto____12 { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsNeg_D__Z(jrt.Math_CopySign_D_D__D(1.0, d__9))).Ref() } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() } } } } else { tmp9 = and__1927000168__auto____8 }; tmp7 = tmp8.Invoke_O__O(tmp9) } else {
//line :633:1
			tmp7 = and__1927000168__auto____7 } } else { tmp7 = and__1927000168__auto____6 } } else { tmp7 = and__1927000168__auto____5 }
//line :632:1
	if jrt.J2g_Truth(tmp7) { var v__5 any; var G__1464000447__5_ any = A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)


	L2: switch { default: switch lang.Util_Hash_O__I(G__1464000447__5_) { case 67: if lang.Util_Equiv_O_O__Z(G__1464000447__5_, Lit_125) {

		var tmp11 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_459.GetRawRoot__O()).Invoke_O__O(cv__4)) { tmp11 = cv__4 } else { tmp11 = jrt.Character_ValueOf_C__Character(lang.RT_CharCast_O__C(cv__4)).Ref() }; v__5 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_I__J(lang.RT_IntCast_O__I(tmp11))).Ref()
//line :635:1
		break L2 }; case 68: if lang.Util_Equiv_O_O__Z(G__1464000447__5_, Lit_126) {


			v__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2), cv__4)
//line :635:1
			break L2 }; case 70: if lang.Util_Equiv_O_O__Z(G__1464000447__5_, Lit_127) {


				v__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2), cv__4)
//line :635:1
				break L2 }; case 90: if lang.Util_Equiv_O_O__Z(G__1464000447__5_, Lit_131) {
					v__5 = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(cv__4)).Ref()
//line :635:1
					break L2 }; default:
	}


		v__5 = jrt.Long_ValueOf_J__Long(lang.RT_LongCast_O__J(cv__4)).Ref()}
		var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_decls_A_const_465; var tmp14 any = A_arbace_j2g_decls_A_const_18; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp16 any = t.F_pkg; tmp6 = tmp12.Invoke_O_O_O__O(tmp13, lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(s__3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp15.Invoke_O_O__O(tmp16, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)), A_arbace_j2g_decls_A_const_466, v__5))), v__5) } else {
//line :632:1
			var tmp17 any; var and__1927000168__auto____5_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457.GetRawRoot__O()).Invoke_O__O(cv__4)








			if jrt.J2g_Truth(and__1927000168__auto____5_2) { var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_461); tmp17 = tmp18.Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2)) } else { tmp17 = and__1927000168__auto____5_2 }
//line :632:1
			if jrt.J2g_Truth(tmp17) {









				var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp20 any = A_arbace_j2g_decls_A_const_467; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp22 any = t.F_pkg; var tmp23 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__3, tmp21.Invoke_O_O__O(tmp22, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2))); var tmp24 any; var tmp25 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp26 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp25.Invoke_O_O__O(tmp26, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp27 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A_New_O_O(f__2, cv__4); var tmp28 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_250, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A_fn_class = fncls__107d; tmp28 = fncls__107d } else { tmp28 = fncls__107 }; tmp24 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil).Invoke__O(); tmp6 = tmp19.Invoke_O_O_O__O(tmp20, tmp23, tmp24) } else {
//line :632:1
					var tmp29 any; var and__1927000168__auto____5_3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_457.GetRawRoot__O()).Invoke_O__O(cv__4)










					if jrt.J2g_Truth(and__1927000168__auto____5_3) { tmp29 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_462.GetRawRoot__O()).Invoke_O__O(cv__4) } else { tmp29 = and__1927000168__auto____5_3 }
//line :632:1
					if jrt.J2g_Truth(tmp29) {











						var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp31 any = A_arbace_j2g_decls_A_const_468; var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()); var tmp33 any = t.F_pkg; var tmp34 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__3, tmp32.Invoke_O_O__O(tmp33, A_arbace_j2g_decls_A_const_118.Invoke_O__O(f__2))); var tmp35 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp37 any = A_arbace_j2g_decls_A_const_90; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp36.Invoke_O_O__O(tmp37, lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, t.F_n))); var tmp38 any = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A_New_O(cv__4); var tmp39 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_251, false); A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A_fn_class = fncls__108d; tmp39 = fncls__108d } else { tmp39 = fncls__108 }; tmp35 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil).Invoke__O(); tmp6 = tmp30.Invoke_O_O_O__O(tmp31, tmp34, tmp35) } else {
//line :632:1
							if A_arbace_j2g_decls_A_const_160 != nil {













								var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp41 any = A_arbace_j2g_decls_A_const_469; tmp6 = tmp40.Invoke_O_O__O(tmp41, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(s__3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_470.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__2))) } else {
//line :632:1
									tmp6 = nil } } } }
//line :629:1
	tmp4.Invoke_O_O__O(tmp5, tmp6); i__1464000442__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000442__1); continue L1 } else { i__1464000442__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000442__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }












func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A{}; t.Ctor_O_O(p0, p1); return t }
//line :642:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A) Ctor_O_O(c__f, c__cv any) { t.F_f = c__f; t.F_cv = c__cv }
//line :642:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var t__2 any = t.F_cv; t.F_cv = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp5, tmp6) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }
//line :642:1
func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A{}; t.Ctor_O_O(p0, p1); return t }
//line :642:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A) Ctor_O_O(c__f, c__cv any) { t.F_f = c__f; t.F_cv = c__cv }
//line :642:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_460.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_j2g_decls_A_const_118; var tmp4 any; var t_ any = t.F_f; t.F_f = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var t__2 any = t.F_cv; t.F_cv = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp5, tmp6) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }

func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A_New_O(p0 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A{}; t.Ctor_O(p0); return t }
//line :644:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A) Ctor_O(c__cv any) { t.F_cv = c__cv }
//line :644:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_cv; t.F_cv = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :644:1
func A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A_New_O(p0 any) *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A{}; t.Ctor_O(p0); return t }
//line :644:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A) Ctor_O(c__cv any) { t.F_cv = c__cv }
//line :644:1
func (t *A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_291.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_cv; t.F_cv = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }







func A_arbace_j2g_decls_calls_in_A_New() *A_arbace_j2g_decls_calls_in_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_calls_in_A{}; t.Ctor(); return t }
//line :652:1
func (t *A_arbace_j2g_decls_calls_in_A) Ctor() {}
//line :652:1
func (t *A_arbace_j2g_decls_calls_in_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_473.GetRawRoot__O()).Invoke_O__O(f__0)) { var tmp1 int64; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_48.GetRawRoot__O()).Invoke_O__O(f__0)) { tmp1 = 1 } else { tmp1 = 0 }; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_474.GetRawRoot__O(); var tmp4 any = A_arbace_j2g_decls_A_const_289; return lang.Numbers_Add_J_O__Number(tmp1, tmp2.Invoke_O_O_O__O(tmp3, tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_22.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_475.GetRawRoot__O(), f__0))) } else { return A_arbace_j2g_decls_A_const_289
	} }
func A_arbace_j2g_decls_splittable_QMARK__A_New() *A_arbace_j2g_decls_splittable_QMARK__A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_splittable_QMARK__A{}; t.Ctor(); return t }
//line :657:1
func (t *A_arbace_j2g_decls_splittable_QMARK__A) Ctor() {}
//line :657:1
func (t *A_arbace_j2g_decls_splittable_QMARK__A) Invoke_O_O__O(self, body__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_476.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_477; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_478.GetRawRoot__O(), lang.IFn_Cast(A_arbace_j2g_decls_A_const_479.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_473.GetRawRoot__O(), A_arbace_j2g_decls_A_const_30.GetRawRoot__O(), body__0)))
}

func A_arbace_j2g_decls_split_clinit_A_New() *A_arbace_j2g_decls_split_clinit_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_A{}; t.Ctor(); return t }
//line :664:1
func (t *A_arbace_j2g_decls_split_clinit_A) Ctor() {}
//line :664:1
func (t *A_arbace_j2g_decls_split_clinit_A) Invoke_O_O_O__O(self, g__0, body__1 any) any { var body__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(body__1); var tmp1 any; var or__1927000174__auto____4 bool = lang.Numbers_Lt_O_O__Z(lang.IFn_Cast(A_arbace_j2g_decls_A_const_475.GetRawRoot__O()).Invoke_O__O(body__3), lang.Numbers_Multiply_J_O__Number(2, A_arbace_j2g_decls_A_const_480.GetRawRoot__O())); if or__1927000174__auto____4 {








	tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____4).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_481.GetRawRoot__O()).Invoke_O__O(body__3)) }; if jrt.J2g_Truth(tmp1) { return lang.Tuple_Create_O_O__IPersistentVector(body__3, nil) } else { var parts__4 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_200.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_split_clinit_fn__1464000463_A_New(); var tmp4 *jrt.Class
		var fncls__118 /*line :673:1*/*jrt.Class = A_arbace_j2g_decls_split_clinit_fn__1464000463_A_fn_class

		if fncls__118 == nil { var fncls__118d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_239, false); A_arbace_j2g_decls_split_clinit_fn__1464000463_A_fn_class = fncls__118d; tmp4 = fncls__118d } else { tmp4 = fncls__118 }; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_j2g_decls_A_const_483; var tmp7 any = A_arbace_j2g_decls_A_const_289; var tmp8 any = A_arbace_j2g_decls_A_const_484; var tmp9 *lang.PersistentVector; lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY; parts__4 = tmp2.Invoke_O_O_O__O(tmp5, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, tmp8, tmp9.Ref()))), body__3)
//line :673:1
		var names__5 any; var iter__1927001039__auto____5 any; var tmp10 any = A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A_New_O(g__0); var tmp11 *jrt.Class
		var fncls__117 /*line :673:1*/*jrt.Class = A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A_fn_class








		if fncls__117 == nil { var fncls__117d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_240, false); A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A_fn_class = fncls__117d; tmp11 = fncls__117d } else { tmp11 = fncls__117 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); names__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(parts__4)).Ref()))
//line :673:1
		var tmp12 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_486.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_58.GetRawRoot__O(), names__5); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_486.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_split_clinit_fn__1464000476_A_New(); var tmp15 *jrt.Class
		var fncls__119 /*line :673:1*/*jrt.Class = A_arbace_j2g_decls_split_clinit_fn__1464000476_A_fn_class










		if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_241, false); A_arbace_j2g_decls_split_clinit_fn__1464000476_A_fn_class = fncls__119d; tmp15 = fncls__119d } else { tmp15 = fncls__119 }
//line :673:1
		return lang.Tuple_Create_O_O__IPersistentVector(tmp12, tmp13.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil), names__5, parts__4)) } }

func A_arbace_j2g_decls_split_clinit_fn__1464000463_A_New() *A_arbace_j2g_decls_split_clinit_fn__1464000463_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_fn__1464000463_A{}; t.Ctor(); return t }
//line :675:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000463_A) Ctor() {}
//line :675:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000463_A) Invoke_O_O_O__O(self, parts__1, st__2 any) any { var w__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_475.GetRawRoot__O()).Invoke_O__O(st__2); var cur__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_482.GetRawRoot__O()).Invoke_O__O(parts__1); var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_484.Invoke_O__O(cur__4)); if


	jrt.J2g_Truth(and__1927000168__auto____5) { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_Gt_O_O__Z(lang.Numbers_Add_O_O__Number(A_arbace_j2g_decls_A_const_483.Invoke_O__O(cur__4), w__3), A_arbace_j2g_decls_A_const_480.GetRawRoot__O())).Ref() } else { tmp1 = and__1927000168__auto____5 }; if jrt.J2g_Truth(tmp1) {
		var tmp2 any = A_arbace_j2g_decls_A_const_483; var tmp3 any = A_arbace_j2g_decls_A_const_484; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_14.GetRawRoot__O()).Invoke_O_O__O(parts__1, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, w__3, tmp3, lang.Tuple_Create_O__IPersistentVector(st__2)))) } else {
			var tmp4 any = A_arbace_j2g_decls_A_const_483; var tmp5 any = lang.Numbers_Add_O_O__Number(A_arbace_j2g_decls_A_const_483.Invoke_O__O(cur__4), w__3); var tmp6 any = A_arbace_j2g_decls_A_const_484; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_485.GetRawRoot__O()).Invoke_O__O(parts__1), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp5, tmp6, lang.IFn_Cast(A_arbace_j2g_decls_A_const_14.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_484.Invoke_O__O(cur__4), st__2)))) } }

func A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A_New_O(p0 any) *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A{}; t.Ctor_O(p0); return t }
//line :682:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :682:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A) Invoke_O_O__O(self, s__1464000466__1 any) any { var tmp1 any = A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A_New_O_O_O(t.F_g, s__1464000466__1, self); var tmp2 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_242, false); A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A_fn_class = fncls__116d; tmp2 = fncls__116d } else { tmp2 = fncls__116 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :682:1
func A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :682:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A) Ctor_O_O_O(c__g, c__s__1464000466, c__iter__1464000465 any) { t.F_g = c__g; t.F_s__1464000466 = c__s__1464000466; t.F_iter__1464000465 = c__iter__1464000465 }
//line :682:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A) Invoke_O__O(self any) any { { var s__1464000466__1 any; var t_ any = t.F_s__1464000466; t.F_s__1464000466 = nil; s__1464000466__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000466__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000466__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000466__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000466__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000468__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A_New_O_O_I_O(b__1464000468__6, t.F_g, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_243, false); A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A_fn_class = fncls__115d; tmp2 = fncls__115d } else { tmp2 = fncls__115 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000465); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000468__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000466__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000468__6), nil) } } else { var k__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000466__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000465); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_244, nil), jrt.RefArrayOf(jrt.Object_class, t.F_g, nil, k__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000466__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :682:1
func A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :682:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A) Ctor_O_O_I_O(c__b__1464000468, c__g any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000468 = c__b__1464000468; t.F_g = c__g; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :682:1
func (t *A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A) Invoke_O__O(self any) any { { var i__1464000467__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000467__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var k__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000467__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000468; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_244, nil), jrt.RefArrayOf(jrt.Object_class, t.F_g, nil, k__2)).Ref())); i__1464000467__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000467__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_split_clinit_fn__1464000476_A_New() *A_arbace_j2g_decls_split_clinit_fn__1464000476_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_split_clinit_fn__1464000476_A{}; t.Ctor(); return t }
//line :684:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000476_A) Ctor() {}
//line :684:1
func (t *A_arbace_j2g_decls_split_clinit_fn__1464000476_A) Invoke_O_O_O__O(self, nm__1, p__1464000475__2 any) any { var map__1464000477__3 any = p__1464000475__2; var map__1464000477__4 any; if lang.ISeq_InstanceOf(map__1464000477__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000477__3)) { map__1464000477__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000477__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000477__3)) { map__1464000477__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000477__3) } else { lang.PersistentArrayMap_Init(); map__1464000477__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000477__4 = map__1464000477__3 }; var sts__5 any = lang.RT_Get_O_O__O(map__1464000477__4, A_arbace_j2g_decls_A_const_484); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp2 any = A_arbace_j2g_decls_A_const_487; var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; return tmp1.Invoke_O_O_O_O__O(tmp2, nm__1, tmp3.Ref(), sts__5) }

func A_arbace_j2g_decls_init_forms_A_New() *A_arbace_j2g_decls_init_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_init_forms_A{}; t.Ctor(); return t }
//line :686:1
func (t *A_arbace_j2g_decls_init_forms_A) Ctor() {}
//line :686:1
func (t *A_arbace_j2g_decls_init_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any {


	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(n__1)) { return nil } else { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var d__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1); var st__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_81.Invoke_O__O(d__4)); var sup__6 any = A_arbace_j2g_decls_A_const_126.Invoke_O__O(d__4); var reached__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_124.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_125.Get__O(), lang.Tuple_Create_O_O_O__IPersistentVector(n__1, Lit_43, Lit_140)); var body__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_95.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_88; var tmp6 *jrt.Boolean





		jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; var tmp7 any = tmp6.Ref(); var tmp8 any = A_arbace_j2g_decls_A_const_97; var tmp9 any = A_arbace_j2g_decls_A_const_494; var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O_O__O(pkg__0, n__1, tmp5, tmp7, tmp8, Lit_51, tmp9, tmp10.Ref(), A_arbace_j2g_decls_A_const_99, Lit_43))); var tmp11 any = A_arbace_j2g_decls_init_forms_fn__1464000484_A_New_O_O_O_O_O_O(g__3, sup__6, pkg__0, reached__7, n__1, st__5); var tmp12 *jrt.Class; var fncls__123 *jrt.Class = A_arbace_j2g_decls_init_forms_fn__1464000484_A_fn_class; if fncls__123 == nil { var fncls__123d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_141, false); A_arbace_j2g_decls_init_forms_fn__1464000484_A_fn_class = fncls__123d; tmp12 = fncls__123d } else { tmp12 = fncls__123 }; body__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
//line :689:1
		var vec__1464000481__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_495.GetRawRoot__O()).Invoke_O_O__O(g__3, body__8); var body__10 any = lang.RT_Nth_O_I_O__O(vec__1464000481__9, lang.RT_IntCast_J__I(0), nil); var parts__11 any = lang.RT_Nth_O_I_O__O(vec__1464000481__9, lang.RT_IntCast_J__I(1), nil); var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_46.GetRawRoot__O()); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp15 any = A_arbace_j2g_decls_A_const_496; var tmp16 any = tmp14.Invoke_O_O__O(tmp15, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_143))); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp18 any = A_arbace_j2g_decls_A_const_497; var tmp19 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_73), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp20 *lang.PersistentVector




















		lang.PersistentVector_Init(); tmp20 = lang.PersistentVector_EMPTY; var tmp21 any = tmp20.Ref(); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp23 any = A_arbace_j2g_decls_A_const_498; var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_499; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp27 any = A_arbace_j2g_decls_A_const_500; var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp29 any = A_arbace_j2g_decls_A_const_501; var tmp30 any = tmp17.Invoke_O_O_O_O__O(tmp18, tmp19, tmp21, tmp22.Invoke_O_O_O__O(tmp23, tmp24.Invoke_O_O__O(tmp25, tmp26.Invoke_O_O__O(tmp27, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()))), tmp28.Invoke_O_O_O__O(tmp29, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_142), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_144), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_decls_A_const_502; var tmp33 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_144), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp34 *lang.PersistentVector; lang.PersistentVector_Init(); tmp34 = lang.PersistentVector_EMPTY; return tmp13.Invoke_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp16, tmp30, tmp31.Invoke_O_O_O_O__O(tmp32, tmp33, tmp34.Ref(), body__10)), parts__11) } }
//line :695:1
func A_arbace_j2g_decls_init_forms_fn__1464000484_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_j2g_decls_init_forms_fn__1464000484_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_init_forms_fn__1464000484_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :695:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000484_A) Ctor_O_O_O_O_O_O(c__g, c__sup, c__pkg, c__reached, c__n, c__st any) { t.F_g = c__g; t.F_sup = c__sup; t.F_pkg = c__pkg; t.F_reached = c__reached; t.F_n = c__n; t.F_st = c__st }
//line :695:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000484_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
											{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_94.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_90.Get__O(); var tmp6 any = A_arbace_j2g_decls_A_const_105; var tmp7 *lang.Keyword = A_arbace_j2g_decls_A_const_35; lang.IFn_Cast(A_arbace_j2g_decls_A_const_93.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O__O(A_arbace_j2g_decls_A_const_90.Get__O())))); tmp11 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
												{ var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_91.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A_New_O_O_O_O_O_O(t.F_g, t.F_sup, t.F_pkg, t.F_reached, t.F_n, t.F_st); var tmp10 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A_fn_class
													if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A_fn_class = fncls__122d; tmp10 = fncls__122d } else { tmp10 = fncls__122 }
//line :697:1
			tmp1 = tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) }
//line :696:1
		return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O()
//line :695:1
		if tmp11 != nil { panic(tmp11) } }; return nil }(); lang.IFn_Cast(A_arbace_j2g_decls_A_const_92.GetRawRoot__O()).Invoke__O(); if tmp12 != nil { panic(tmp12) }; return tmp1 }


func A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :698:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A) Ctor_O_O_O_O_O_O(c__g, c__sup, c__pkg, c__reached, c__n, c__st any) { t.F_g = c__g; t.F_sup = c__sup; t.F_pkg = c__pkg; t.F_reached = c__reached; t.F_n = c__n; t.F_st = c__st }
//line :698:1
func (t *A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A) Invoke_O__O(self any) any {
	{ var tmp1 any; var and__1927000168__auto____1 any = t.F_sup; if jrt.J2g_Truth(and__1927000168__auto____1) { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_159.GetRawRoot__O()).Invoke_O__O(t.F_sup); if jrt.J2g_Truth(and__1927000168__auto____2) { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_248.GetRawRoot__O()).Invoke_O__O(t.F_sup)) } else { tmp1 = and__1927000168__auto____2 } } else { tmp1 = and__1927000168__auto____1 }; if jrt.J2g_Truth(tmp1) {
		lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_sup, Lit_73))) }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(t.F_reached)) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp3 any = A_arbace_j2g_decls_A_const_488; return lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, Lit_99), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_146), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(t.F_n, Lit_11, Lit_12), nil)).Ref()))) } else {
//line :701:1
				var seq_1464000486__1 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_489.Invoke_O__O(t.F_st)); var chunk_1464000487__2 any; var count_1464000488__3 int64 = 0; var i_1464000489__4 int64 = 0; L1: for {


					if lang.Numbers_Lt_J_J__Z(i_1464000489__4, count_1464000488__3) { var vec__1464000490__5 any = lang.Indexed_Cast(chunk_1464000487__2).Nth_I__O(lang.RT_IntCast_J__I(i_1464000489__4)); var ___6 any = lang.RT_Nth_O_I_O__O(vec__1464000490__5, lang.RT_IntCast_J__I(0), nil); var map__1464000493__7 any = lang.RT_Nth_O_I_O__O(vec__1464000490__5, lang.RT_IntCast_J__I(1), nil); var map__1464000493__8 any; _ = ___6; if lang.ISeq_InstanceOf(map__1464000493__7) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000493__7)) { map__1464000493__8 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000493__7), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000493__7)) { map__1464000493__8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000493__7) } else { lang.PersistentArrayMap_Init(); map__1464000493__8 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000493__8 = map__1464000493__7 }; var name__9 any = lang.RT_Get_O_O__O(map__1464000493__8, A_arbace_j2g_decls_A_const_100); var desc__10 any = lang.RT_Get_O_O__O(map__1464000493__8, A_arbace_j2g_decls_A_const_118); var init__11 any = lang.RT_Get_O_O__O(map__1464000493__8, A_arbace_j2g_decls_A_const_223); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_490; var tmp7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()).Invoke_O_O__O(t.F_g, name__9)); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_186.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_147, nil); var tmp10 any; var G__1464000495__14_ any = A_arbace_j2g_decls_A_const_167.Invoke_O__O(init__11)

					L2: switch { default: switch lang.Util_Hash_O__I(G__1464000495__14_) { case 1021307934: if any(G__1464000495__14_) == any(A_arbace_j2g_decls_A_const_491) { tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_148, nil, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_492.Invoke_O__O(init__11), nil, A_arbace_j2g_decls_A_const_100.Invoke_O__O(init__11))).Ref(); break L2 }; default:}; tmp10 = A_arbace_j2g_decls_A_const_493.Invoke_O__O(init__11)}
//line :705:1
						tmp4.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp6, tmp7, tmp8.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10)).Ref(), desc__10)))
//line :704:1
						seq_1464000486__1, chunk_1464000487__2, count_1464000488__3, i_1464000489__4 = seq_1464000486__1, chunk_1464000487__2, count_1464000488__3, lang.Numbers_Unchecked_inc_J__J(i_1464000489__4); continue L1 } else { var temp__1927000414__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000486__1); if jrt.J2g_Truth(temp__1927000414__auto____5) { var seq_1464000486__6 any = temp__1927000414__auto____5; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000486__6)) { var c__1927000678__auto____7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000486__6); seq_1464000486__1, chunk_1464000487__2, count_1464000488__3, i_1464000489__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000486__6), c__1927000678__auto____7, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__1464000496__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000486__6); var ___8 any = lang.RT_Nth_O_I_O__O(vec__1464000496__7, lang.RT_IntCast_J__I(0), nil); var map__1464000499__9 any = lang.RT_Nth_O_I_O__O(vec__1464000496__7, lang.RT_IntCast_J__I(1), nil); var map__1464000499__10 any; _ = ___8; if lang.ISeq_InstanceOf(map__1464000499__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000499__9)) { map__1464000499__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000499__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000499__9)) { map__1464000499__10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000499__9) } else { lang.PersistentArrayMap_Init(); map__1464000499__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000499__10 = map__1464000499__9 }; var name__11 any = lang.RT_Get_O_O__O(map__1464000499__10, A_arbace_j2g_decls_A_const_100); var desc__12 any = lang.RT_Get_O_O__O(map__1464000499__10, A_arbace_j2g_decls_A_const_118); var init__13 any = lang.RT_Get_O_O__O(map__1464000499__10, A_arbace_j2g_decls_A_const_223); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_111.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp13 any = A_arbace_j2g_decls_A_const_490; var tmp14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()).Invoke_O_O__O(t.F_g, name__11)); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_186.GetRawRoot__O()); var tmp16 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_147, nil); var tmp17 any; var G__1464000501__16_ any = A_arbace_j2g_decls_A_const_167.Invoke_O__O(init__13)

						L3: switch { default: switch lang.Util_Hash_O__I(G__1464000501__16_) { case 1021307934: if any(G__1464000501__16_) == any(A_arbace_j2g_decls_A_const_491) { tmp17 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_148, nil, Lit_11, nil), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_j2g_decls_A_const_492.Invoke_O__O(init__13), nil, A_arbace_j2g_decls_A_const_100.Invoke_O__O(init__13))).Ref(); break L3 }; default:}; tmp17 = A_arbace_j2g_decls_A_const_493.Invoke_O__O(init__13)}
//line :705:1
							tmp11.Invoke_O__O(tmp12.Invoke_O_O_O__O(tmp13, tmp14, tmp15.Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp16, jrt.RefArrayOf(jrt.Object_class, nil, tmp17)).Ref(), desc__12)))
//line :704:1
							seq_1464000486__1, chunk_1464000487__2, count_1464000488__3, i_1464000489__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000486__6), nil, 0, 0; continue L1 } } }
//line :701:1
					break L1 }; var seq_1464000502__1 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_494.Invoke_O__O(t.F_st)); var chunk_1464000503__2 any; var count_1464000504__3 int64 = 0; var i_1464000505__4 int64 = 0; L4: for {






						if lang.Numbers_Lt_J_J__Z(i_1464000505__4, count_1464000504__3) { var nd__5 any = lang.Indexed_Cast(chunk_1464000503__2).Nth_I__O(lang.RT_IntCast_J__I(i_1464000505__4)); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(nd__5); seq_1464000502__1, chunk_1464000503__2, count_1464000504__3, i_1464000505__4 = seq_1464000502__1, chunk_1464000503__2, count_1464000504__3, lang.Numbers_Unchecked_inc_J__J(i_1464000505__4); continue L4 } else { var temp__1927000414__auto____5_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(seq_1464000502__1); if jrt.J2g_Truth(temp__1927000414__auto____5_2) { var seq_1464000502__6 any = temp__1927000414__auto____5_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(seq_1464000502__6)) { var c__1927000678__auto____7_2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(seq_1464000502__6); seq_1464000502__1, chunk_1464000503__2, count_1464000504__3, i_1464000505__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(seq_1464000502__6), c__1927000678__auto____7_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____7_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var nd__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1464000502__6); lang.IFn_Cast(A_arbace_j2g_decls_A_const_108.GetRawRoot__O()).Invoke_O__O(nd__7); seq_1464000502__1, chunk_1464000503__2, count_1464000504__3, i_1464000505__4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_1464000502__6), nil, 0, 0; continue L4 } } else { return nil } } } } }
//line :698:1
	panic("j2g: unreachable")
}

















func A_arbace_j2g_decls_clj_const_fields_A_New() *A_arbace_j2g_decls_clj_const_fields_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_A{}; t.Ctor(); return t }
//line :717:1
func (t *A_arbace_j2g_decls_clj_const_fields_A) Ctor() {}
//line :717:1
func (t *A_arbace_j2g_decls_clj_const_fields_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var tmp1 *lang.Keyword = A_arbace_j2g_decls_A_const_81; var st__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__1))); var iter__1927001039__auto____5 any; var tmp2 any = A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A_New_O_O(g__3, pkg__0); var tmp3 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A_fn_class; if


	fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A_fn_class = fncls__126d; tmp3 = fncls__126d } else { tmp3 = fncls__126 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); return lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_j2g_decls_A_const_489.Invoke_O__O(st__4)) }
//line :720:1
func A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A{}; t.Ctor_O_O(p0, p1); return t }
//line :720:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A) Ctor_O_O(c__g, c__pkg any) { t.F_g = c__g; t.F_pkg = c__pkg }
//line :720:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A) Invoke_O_O__O(self, s__1464000510__1 any) any { var tmp1 any = A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A_New_O_O_O_O(t.F_g, self, t.F_pkg, s__1464000510__1); var tmp2 *jrt.Class; var fncls__125 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A_fn_class; if fncls__125 == nil { var fncls__125d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A_fn_class = fncls__125d; tmp2 = fncls__125d } else { tmp2 = fncls__125 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :720:1
func A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :720:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A) Ctor_O_O_O_O(c__g, c__iter__1464000509, c__pkg, c__s__1464000510 any) { t.F_g = c__g; t.F_iter__1464000509 = c__iter__1464000509; t.F_pkg = c__pkg; t.F_s__1464000510 = c__s__1464000510 }
//line :720:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A) Invoke_O__O(self any) any { { var s__1464000510__1 any; var t_ any = t.F_s__1464000510; t.F_s__1464000510 = nil; s__1464000510__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000510__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000510__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000510__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000510__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000512__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A_New_O_O_O_I_O(b__1464000512__6, t.F_g, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A_fn_class = fncls__124d; tmp2 = fncls__124d } else { tmp2 = fncls__124 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000509); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000512__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000510__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000512__6), nil) } } else { var vec__1464000522__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000510__3); var ___5 any = lang.RT_Nth_O_I_O__O(vec__1464000522__4, lang.RT_IntCast_J__I(0), nil); var map__1464000525__6 any = lang.RT_Nth_O_I_O__O(vec__1464000522__4, lang.RT_IntCast_J__I(1), nil); var map__1464000525__7 any; _ = ___5; if lang.ISeq_InstanceOf(map__1464000525__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000525__6)) { map__1464000525__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000525__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000525__6)) { map__1464000525__7 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000525__6) } else { lang.PersistentArrayMap_Init(); map__1464000525__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000525__7 = map__1464000525__6 }; var name__8 any = lang.RT_Get_O_O__O(map__1464000525__7, A_arbace_j2g_decls_A_const_100); var desc__9 any = lang.RT_Get_O_O__O(map__1464000525__7, A_arbace_j2g_decls_A_const_118); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(desc__9)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_503; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1464000509); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()).Invoke_O_O__O(t.F_g, name__8)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, desc__9))), tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000510__3))) } else { s__1464000510__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000510__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :720:1
func A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A_New_O_O_O_I_O(p0, p1, p2 any, p3 int32, p4 any) *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A{}; t.Ctor_O_O_O_I_O(p0, p1, p2, p3, p4); return t }
//line :720:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A) Ctor_O_O_O_I_O(c__b__1464000512, c__g, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000512 = c__b__1464000512; t.F_g = c__g; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :720:1
func (t *A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A) Invoke_O__O(self any) any { { var i__1464000511__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000511__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1464000516__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000511__1)); var ___3 any = lang.RT_Nth_O_I_O__O(vec__1464000516__2, lang.RT_IntCast_J__I(0), nil); var map__1464000519__4 any = lang.RT_Nth_O_I_O__O(vec__1464000516__2, lang.RT_IntCast_J__I(1), nil); var map__1464000519__5 any; _ = ___3; if lang.ISeq_InstanceOf(map__1464000519__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_28.GetRawRoot__O()).Invoke_O__O(map__1464000519__4)) { map__1464000519__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_j2g_decls_A_const_29.GetRawRoot__O()).Invoke_O__O(map__1464000519__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(map__1464000519__4)) { map__1464000519__5 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1464000519__4) } else { lang.PersistentArrayMap_Init(); map__1464000519__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1464000519__5 = map__1464000519__4 }; var name__6 any = lang.RT_Get_O_O__O(map__1464000519__5, A_arbace_j2g_decls_A_const_100); var desc__7 any = lang.RT_Get_O_O__O(map__1464000519__5, A_arbace_j2g_decls_A_const_118); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_117.GetRawRoot__O()).Invoke_O__O(desc__7)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000512; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_503; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_456.GetRawRoot__O()).Invoke_O_O__O(t.F_g, name__6)), lang.IFn_Cast(A_arbace_j2g_decls_A_const_24.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, desc__7)))); i__1464000511__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000511__1); continue L1 } else { i__1464000511__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000511__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_instance_forms_A_New() *A_arbace_j2g_decls_instance_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_instance_forms_A{}; t.Ctor(); return t }
//line :724:1
func (t *A_arbace_j2g_decls_instance_forms_A) Ctor() {}
//line :724:1
func (t *A_arbace_j2g_decls_instance_forms_A) Invoke_O_O_O__O(self, pkg__0, n__1 any) any { var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__1); var ty__4 any; var tmp1 any; var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1); if



	jrt.J2g_Truth(or__1927000174__auto____4) { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__1)) }; if jrt.J2g_Truth(tmp1) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()); var tmp3 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1)) { tmp3 = g__3 } else { tmp3 = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref() }; ty__4 = tmp2.Invoke_O__O(tmp3) } else {
			var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_504; ty__4 = tmp4.Invoke_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3)) }; if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__1)) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_505; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_506; var tmp10 any = A_arbace_j2g_decls_A_const_507; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_509; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp14 any = A_arbace_j2g_decls_A_const_513; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp16 any = A_arbace_j2g_decls_A_const_515; var tmp17 any = A_arbace_j2g_decls_A_const_516; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp19 any = A_arbace_j2g_decls_A_const_517; var tmp20 any = A_arbace_j2g_decls_A_const_518; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = A_arbace_j2g_decls_A_const_519; var tmp23 any = A_arbace_j2g_decls_A_const_520; var dyn_check__5 any = tmp6.Invoke_O_O_O__O(tmp7, tmp8.Invoke_O_O_O__O(tmp9, tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_149), A_arbace_j2g_decls_A_const_508)), tmp11.Invoke_O_O_O__O(tmp12, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_510, A_arbace_j2g_decls_A_const_511, A_arbace_j2g_decls_A_const_512), tmp13.Invoke_O_O_O__O(tmp14, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_150), A_arbace_j2g_decls_A_const_514)), tmp15.Invoke_O_O_O__O(tmp16, tmp17, tmp18.Invoke_O_O_O__O(tmp19, tmp20, tmp21.Invoke_O_O_O__O(tmp22, tmp23, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))))); var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp25 any = A_arbace_j2g_decls_A_const_521; var tmp26 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_151), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp27 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_524, A_arbace_j2g_decls_A_const_525)), A_arbace_j2g_decls_A_const_523); var tmp28 any







		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_522.GetRawRoot__O()).Invoke_O__O(pkg__0)) {


			var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_decls_A_const_526; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp32 any = A_arbace_j2g_decls_A_const_533; var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp34 any = A_arbace_j2g_decls_A_const_534; var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp36 any = A_arbace_j2g_decls_A_const_540; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp38 any = A_arbace_j2g_decls_A_const_544; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp40 any = A_arbace_j2g_decls_A_const_546; var tmp41 any = A_arbace_j2g_decls_A_const_547; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp43 any = A_arbace_j2g_decls_A_const_548; var tmp44 any = A_arbace_j2g_decls_A_const_549; var tmp45 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp46 any = A_arbace_j2g_decls_A_const_550; var tmp47 any = A_arbace_j2g_decls_A_const_551; tmp28 = tmp29.Invoke_O_O_O_O__O(tmp30, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_528, A_arbace_j2g_decls_A_const_529, A_arbace_j2g_decls_A_const_530), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_531, ty__4, A_arbace_j2g_decls_A_const_532)), tmp31.Invoke_O_O_O__O(tmp32, tmp33.Invoke_O_O_O_O__O(tmp34, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_535, A_arbace_j2g_decls_A_const_536), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_537, A_arbace_j2g_decls_A_const_538, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_149), A_arbace_j2g_decls_A_const_539)), tmp35.Invoke_O_O_O__O(tmp36, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_541, A_arbace_j2g_decls_A_const_542, A_arbace_j2g_decls_A_const_543), tmp37.Invoke_O_O_O__O(tmp38, lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_150), A_arbace_j2g_decls_A_const_545)), tmp39.Invoke_O_O_O__O(tmp40, tmp41, tmp42.Invoke_O_O_O__O(tmp43, tmp44, tmp45.Invoke_O_O_O__O(tmp46, tmp47, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))))), A_arbace_j2g_decls_A_const_527) } else {




				var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp49 any = A_arbace_j2g_decls_A_const_552; tmp28 = tmp48.Invoke_O_O_O_O__O(tmp49, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_554, A_arbace_j2g_decls_A_const_555, A_arbace_j2g_decls_A_const_556), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_557, ty__4, A_arbace_j2g_decls_A_const_558)), dyn_check__5, A_arbace_j2g_decls_A_const_553) }
//line :731:1
		var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp51 any = A_arbace_j2g_decls_A_const_559; var tmp52 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp53 any = A_arbace_j2g_decls_A_const_562; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp55 any = A_arbace_j2g_decls_A_const_566; var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp57 any = A_arbace_j2g_decls_A_const_573; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp59 any = A_arbace_j2g_decls_A_const_576; var tmp60 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp61 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_152); var tmp62 any = A_arbace_j2g_decls_A_const_577; return lang.Tuple_Create_O_O__IPersistentVector(tmp24.Invoke_O_O_O_O__O(tmp25, tmp26, tmp27, tmp28), tmp50.Invoke_O_O_O_O_O__O(tmp51, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_97), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_560, A_arbace_j2g_decls_A_const_561)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_18, ty__4))), tmp52.Invoke_O_O_O__O(tmp53, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_563, A_arbace_j2g_decls_A_const_564, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_565, nil)), tmp54.Invoke_O_O_O_O_O__O(tmp55, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_568, A_arbace_j2g_decls_A_const_569, A_arbace_j2g_decls_A_const_570), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_571, ty__4, A_arbace_j2g_decls_A_const_572)), dyn_check__5, tmp56.Invoke_O_O_O__O(tmp57, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_574, A_arbace_j2g_decls_A_const_575), tmp58.Invoke_O_O__O(tmp59, tmp60.Invoke_O_O_O__O(tmp61, tmp62, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))), A_arbace_j2g_decls_A_const_567))) } else { var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp64 any = A_arbace_j2g_decls_A_const_578; var tmp65 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp66 any = A_arbace_j2g_decls_A_const_582; var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp68 any = A_arbace_j2g_decls_A_const_589; var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp70 any = A_arbace_j2g_decls_A_const_592; var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp72 any = A_arbace_j2g_decls_A_const_596; var tmp73 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp74 any = A_arbace_j2g_decls_A_const_603; var tmp75 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp76 any = A_arbace_j2g_decls_A_const_606; var tmp77 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp78 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__0, Lit_152); var tmp79 any = A_arbace_j2g_decls_A_const_607; return lang.Tuple_Create_O_O__IPersistentVector(tmp63.Invoke_O_O_O_O__O(tmp64, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_151), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_580, A_arbace_j2g_decls_A_const_581)), A_arbace_j2g_decls_A_const_579), tmp65.Invoke_O_O_O__O(tmp66, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_584, A_arbace_j2g_decls_A_const_585, A_arbace_j2g_decls_A_const_586), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_587, ty__4, A_arbace_j2g_decls_A_const_588)), A_arbace_j2g_decls_A_const_583)), tmp67.Invoke_O_O_O_O_O__O(tmp68, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_97), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_590, A_arbace_j2g_decls_A_const_591)), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_j2g_decls_A_const_18, ty__4))), tmp69.Invoke_O_O_O__O(tmp70, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_593, A_arbace_j2g_decls_A_const_594, nil), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_595, nil)), tmp71.Invoke_O_O_O_O__O(tmp72, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_598, A_arbace_j2g_decls_A_const_599, A_arbace_j2g_decls_A_const_600), lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_j2g_decls_A_const_601, ty__4, A_arbace_j2g_decls_A_const_602)), tmp73.Invoke_O_O_O__O(tmp74, lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_604, A_arbace_j2g_decls_A_const_605), tmp75.Invoke_O_O__O(tmp76, tmp77.Invoke_O_O_O__O(tmp78, tmp79, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_95), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref())))), A_arbace_j2g_decls_A_const_597))) } }

































func A_arbace_j2g_decls_reflected_forms_A_New() *A_arbace_j2g_decls_reflected_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_A{}; t.Ctor(); return t }
//line :765:1
func (t *A_arbace_j2g_decls_reflected_forms_A) Ctor() {}
//line :765:1
func (t *A_arbace_j2g_decls_reflected_forms_A) Invoke_O_O__O(self, n__0 any) any { var pkg__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_63.GetRawRoot__O()).Invoke_O__O(n__0); var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__0); var info__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_608.GetRawRoot__O()).Invoke_O__O(n__0); var ms__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A_New_O(n__0); var tmp2 *jrt.Class; var fncls__129 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A_fn_class; if







	fncls__129 == nil { var fncls__129d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_220, false); A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A_fn_class = fncls__129d; tmp2 = fncls__129d } else { tmp2 = fncls__129 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); ms__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(A_arbace_j2g_decls_A_const_122.Invoke_O__O(info__4)); var tmp3 lang.IFn =
	lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp6 any = A_arbace_j2g_decls_A_const_614; var tmp7 any = tmp5.Invoke_O_O__O(tmp6, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil, Lit_221), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_11, Lit_12), nil)).Ref()); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_615; var tmp10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp13 any = A_arbace_j2g_decls_A_const_616; var tmp14 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__2, Lit_13); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp16 any; var iter__1927001039__auto____6 any; var tmp17 any = A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A_New_O(pkg__2); var tmp18 *jrt.Class; var fncls__141 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A_fn_class; if





	fncls__141 == nil { var fncls__141d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_222, false); A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A_fn_class = fncls__141d; tmp18 = fncls__141d } else { tmp18 = fncls__141 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0)); var tmp19 any = tmp16; var tmp20 lang.IFn = /*line :774:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp21 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()); var tmp22 *lang.PersistentVector; lang.PersistentVector_Init(); tmp22 = lang.PersistentVector_EMPTY; var tmp23 any = lang.Tuple_Create_O__IPersistentVector(tmp20.Invoke_O_O__O(tmp21, tmp22.Ref())); var tmp24 any; var iter__1927001039__auto____6_2 any; var tmp25 any = A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A_New_O(pkg__2); var tmp26 *jrt.Class; var fncls__144 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A_fn_class; if







	fncls__144 == nil { var fncls__144d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_223, false); A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A_fn_class = fncls__144d; tmp26 = fncls__144d } else { tmp26 = fncls__144 }; iter__1927001039__auto____6_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); tmp24 = lang.IFn_Cast(iter__1927001039__auto____6_2).Invoke_O__O(ms__5); var tmp27 any = /*line :774:1*/lang.Tuple_Create_O_O__IPersistentVector(tmp7, tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11.Invoke_O_O_O_O__O(tmp12, tmp13, tmp14, tmp15.Invoke_O_O_O__O(tmp19, tmp23, tmp24)))); var tmp28 any; var iter__1927001039__auto____6_3 any; var tmp29 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A_New_O_O_O(g__3, pkg__2, n__0); var tmp30 *jrt.Class; var fncls__138 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A_fn_class; if











	fncls__138 == nil { var fncls__138d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_224, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A_fn_class = fncls__138d; tmp30 = fncls__138d } else { tmp30 = fncls__138 }; iter__1927001039__auto____6_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); tmp28 = lang.IFn_Cast(iter__1927001039__auto____6_3).Invoke_O__O(ms__5); return /*line :774:1*/ tmp3.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp27, tmp28, lang.IFn_Cast(A_arbace_j2g_decls_A_const_613.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0))) }
//line :773:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A_New_O(p0 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A{}; t.Ctor_O(p0); return t }
//line :773:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A) Ctor_O(c__n any) { t.F_n = c__n }
//line :773:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A) Invoke_O_O__O(self, s__1464000532__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A_New_O_O_O(t.F_n, s__1464000532__1, self); var tmp2 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A_fn_class; if fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_225, false); A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A_fn_class = fncls__128d; tmp2 = fncls__128d } else { tmp2 = fncls__128 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :773:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :773:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A) Ctor_O_O_O(c__n, c__s__1464000532, c__iter__1464000531 any) { t.F_n = c__n; t.F_s__1464000532 = c__s__1464000532; t.F_iter__1464000531 = c__iter__1464000531 }
//line :773:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A) Invoke_O__O(self any) any { { var s__1464000532__1 any; var t_ any = t.F_s__1464000532; t.F_s__1464000532 = nil; s__1464000532__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000532__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000532__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000532__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000532__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000534__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A_New_O_O_I_O(b__1464000534__6, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__127 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A_fn_class; if fncls__127 == nil { var fncls__127d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_226, false); A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A_fn_class = fncls__127d; tmp2 = fncls__127d } else { tmp2 = fncls__127 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000531); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000534__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000532__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000534__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000532__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000531); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(mm__4, A_arbace_j2g_decls_A_const_333, t.F_n), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000532__3))) } else { s__1464000532__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000532__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :773:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :773:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A) Ctor_O_O_I_O(c__b__1464000534, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000534 = c__b__1464000534; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :773:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A) Invoke_O__O(self any) any { { var i__1464000533__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000533__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000533__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000534; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_27.GetRawRoot__O()).Invoke_O_O_O__O(mm__2, A_arbace_j2g_decls_A_const_333, t.F_n)); i__1464000533__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000533__1); continue L1 } else { i__1464000533__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000533__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A_New_O(p0 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A{}; t.Ctor_O(p0); return t }
//line :780:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :780:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A) Invoke_O_O__O(self, s__1464000542__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A_New_O_O_O(t.F_pkg, s__1464000542__1, self); var tmp2 *jrt.Class; var fncls__140 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A_fn_class; if fncls__140 == nil { var fncls__140d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_227, false); A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A_fn_class = fncls__140d; tmp2 = fncls__140d } else { tmp2 = fncls__140 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :780:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :780:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A) Ctor_O_O_O(c__pkg, c__s__1464000542, c__iter__1464000541 any) { t.F_pkg = c__pkg; t.F_s__1464000542 = c__s__1464000542; t.F_iter__1464000541 = c__iter__1464000541 }
//line :780:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A) Invoke_O__O(self any) any { { var s__1464000542__1 any; var t_ any = t.F_s__1464000542; t.F_s__1464000542 = nil; s__1464000542__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000542__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000542__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000542__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000542__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000544__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A_New_O_O_I_O(b__1464000544__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_228, false); A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000541); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000544__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000542__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000544__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000542__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000541); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000542__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :780:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :780:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A) Ctor_O_O_I_O(c__b__1464000544, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000544 = c__b__1464000544; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :780:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A) Invoke_O__O(self any) any { { var i__1464000543__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000543__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000543__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000544; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__2)); i__1464000543__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000543__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A_New_O(p0 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A{}; t.Ctor_O(p0); return t }
//line :782:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :782:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A) Invoke_O_O__O(self, s__1464000552__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A_New_O_O_O(t.F_pkg, s__1464000552__1, self); var tmp2 *jrt.Class; var fncls__143 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A_fn_class; if fncls__143 == nil { var fncls__143d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_229, false); A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A_fn_class = fncls__143d; tmp2 = fncls__143d } else { tmp2 = fncls__143 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :782:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :782:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A) Ctor_O_O_O(c__pkg, c__s__1464000552, c__iter__1464000551 any) { t.F_pkg = c__pkg; t.F_s__1464000552 = c__s__1464000552; t.F_iter__1464000551 = c__iter__1464000551 }
//line :782:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A) Invoke_O__O(self any) any { { var s__1464000552__1 any; var t_ any = t.F_s__1464000552; t.F_s__1464000552 = nil; s__1464000552__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000552__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000552__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000552__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000552__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000554__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A_New_O_O_I_O(b__1464000554__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__142 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A_fn_class; if fncls__142 == nil { var fncls__142d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_230, false); A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A_fn_class = fncls__142d; tmp2 = fncls__142d } else { tmp2 = fncls__142 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000551); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000554__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000552__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000554__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000552__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4))
															if jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_610.GetRawRoot__O()).Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____5 }
//line :782:1
	if jrt.J2g_Truth(tmp4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_454.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))))) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000551); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_617.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000552__3))) } else { s__1464000552__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000552__3); continue L1 } } else { s__1464000552__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000552__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :782:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :782:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A) Ctor_O_O_I_O(c__b__1464000554, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000554 = c__b__1464000554; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :782:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A) Invoke_O__O(self any) any { { var i__1464000553__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000553__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000553__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2))
																	if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_610.GetRawRoot__O()).Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____3 }
//line :782:1
	if jrt.J2g_Truth(tmp2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_454.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))))) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp4 any = t.F_b__1464000554; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_617.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__2)); i__1464000553__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000553__1); continue L1 } else { i__1464000553__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000553__1); continue L1 } } else { i__1464000553__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000553__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :786:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A) Ctor_O_O_O(c__g, c__pkg, c__n any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n }
//line :786:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A) Invoke_O_O__O(self, s__1464000562__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A_New_O_O_O_O_O(t.F_g, t.F_pkg, t.F_n, s__1464000562__1, self); var tmp2 *jrt.Class; var fncls__137 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A_fn_class; if fncls__137 == nil { var fncls__137d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_231, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A_fn_class = fncls__137d; tmp2 = fncls__137d } else { tmp2 = fncls__137 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :786:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :786:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A) Ctor_O_O_O_O_O(c__g, c__pkg, c__n, c__s__1464000562, c__iter__1464000561 any) { t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_s__1464000562 = c__s__1464000562; t.F_iter__1464000561 = c__iter__1464000561 }
//line :786:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A) Invoke_O__O(self any) any { { var s__1464000562__1 any; var t_ any = t.F_s__1464000562; t.F_s__1464000562 = nil; s__1464000562__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000562__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000562__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000562__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000562__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000564__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A_New_O_O_O_O_I_O(b__1464000564__6, t.F_g, t.F_pkg, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_232, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A_fn_class = fncls__133d; tmp2 = fncls__133d } else { tmp2 = fncls__133 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000561); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000564__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000562__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000564__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000562__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_609.GetRawRoot__O()).Invoke_O__O(mm__4))
															if jrt.J2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_610.GetRawRoot__O()).Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____5 }
//line :786:1
	if jrt.J2g_Truth(tmp4) { var vec__1464000582__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)); var ps__6 any = lang.RT_Nth_O_I_O__O(vec__1464000582__5, lang.RT_IntCast_J__I(0), nil); var r__7 any = lang.RT_Nth_O_I_O__O(vec__1464000582__5, lang.RT_IntCast_J__I(1), nil); var pn__8 any; var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp6 any; var iter__1927001039__auto____8 any; var tmp7 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A_New(); var tmp8 *jrt.Class
		var fncls__136 /*line :786:1*/*jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A_fn_class


		if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_233, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A_fn_class = fncls__136d; tmp8 = fncls__136d } else { tmp8 = fncls__136 }; iter__1927001039__auto____8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); tmp6 = lang.IFn_Cast(iter__1927001039__auto____8).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__6)).Ref())); pn__8 = tmp5.Invoke_O__O(tmp6)
//line :786:1
		var plist__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__6, pn__8), t.F_pkg, r__7); var plist__10 any




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4)) { plist__10 = plist__9 } else { var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp10 any = A_arbace_j2g_decls_A_const_611; plist__10 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp9.Invoke_O_O__O(tmp10, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g)), plist__9)), lang.RT_Meta_O__IPersistentMap(plist__9)) }
//line :786:1
		var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_612; var tmp13 any = t.F_g; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()); var tmp15 any = t.F_n; var tmp16 lang.IFn = lang.IFn_Cast(t.F_iter__1464000561); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp11.Invoke_O_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, tmp13, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)))).Ref()), plist__10, tmp14.Invoke_O_O_O__O(tmp15, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))), tmp16.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000562__3))) } else { s__1464000562__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000562__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :786:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :786:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A) Ctor_O_O_O_O_I_O(c__b__1464000564, c__g, c__pkg, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000564 = c__b__1464000564; t.F_g = c__g; t.F_pkg = c__pkg; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :786:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A) Invoke_O__O(self any) any { { var i__1464000563__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000563__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000563__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_609.GetRawRoot__O()).Invoke_O__O(mm__2))
																	if jrt.J2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_610.GetRawRoot__O()).Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____3 }
//line :786:1
	if jrt.J2g_Truth(tmp2) { var vec__1464000568__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_144.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)); var ps__4 any = lang.RT_Nth_O_I_O__O(vec__1464000568__3, lang.RT_IntCast_J__I(0), nil); var r__5 any = lang.RT_Nth_O_I_O__O(vec__1464000568__3, lang.RT_IntCast_J__I(1), nil); var pn__6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp4 any; var iter__1927001039__auto____6 any; var tmp5 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A_New(); var tmp6 *jrt.Class
		var fncls__132 /*line :786:1*/*jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A_fn_class


		if fncls__132 == nil { var fncls__132d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_234, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A_fn_class = fncls__132d; tmp6 = fncls__132d } else { tmp6 = fncls__132 }; iter__1927001039__auto____6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); tmp4 = lang.IFn_Cast(iter__1927001039__auto____6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_236.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(ps__4)).Ref())); pn__6 = tmp3.Invoke_O__O(tmp4)
//line :786:1
		var plist__7 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_145.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_242.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, ps__4, pn__6), t.F_pkg, r__5); var plist__8 any




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2)) { plist__8 = plist__7 } else { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_611; plist__8 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp7.Invoke_O_O__O(tmp8, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g)), plist__7)), lang.RT_Meta_O__IPersistentMap(plist__7)) }
//line :786:1
		var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp10 any = t.F_b__1464000564; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_231.GetRawRoot__O()); var tmp12 any = A_arbace_j2g_decls_A_const_612; var tmp13 any = t.F_g; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_208.GetRawRoot__O()); var tmp15 any = t.F_n; tmp9.Invoke_O_O__O(tmp10, tmp11.Invoke_O_O_O_O__O(tmp12, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_103, nil), jrt.RefArrayOf(jrt.Object_class, tmp13, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_146.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)))).Ref()), plist__8, tmp14.Invoke_O_O_O__O(tmp15, A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)))); i__1464000563__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000563__1); continue L1 } else { i__1464000563__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000563__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A_New() *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A{}; t.Ctor(); return t }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A) Ctor() {}
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A) Invoke_O_O__O(self, s__1464000572__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A_New_O_O(s__1464000572__1, self); var tmp2 *jrt.Class; var fncls__131 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A_fn_class; if fncls__131 == nil { var fncls__131d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_235, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A_fn_class = fncls__131d; tmp2 = fncls__131d } else { tmp2 = fncls__131 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :789:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A{}; t.Ctor_O_O(p0, p1); return t }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A) Ctor_O_O(c__s__1464000572, c__iter__1464000571 any) { t.F_s__1464000572 = c__s__1464000572; t.F_iter__1464000571 = c__iter__1464000571 }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A) Invoke_O__O(self any) any { { var s__1464000572__1 any; var t_ any = t.F_s__1464000572; t.F_s__1464000572 = nil; s__1464000572__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000572__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000572__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000572__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000572__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000574__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A_New_I_O_O(size__1927001038__auto____5, c__1927001037__auto____4, b__1464000574__6); var tmp2 *jrt.Class; var fncls__130 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A_fn_class; if fncls__130 == nil { var fncls__130d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_236, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A_fn_class = fncls__130d; tmp2 = fncls__130d } else { tmp2 = fncls__130 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000571); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000574__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000572__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000574__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000572__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000571); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000572__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :789:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A_New_I_O_O(p0 int32, p1, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A{}; t.Ctor_I_O_O(p0, p1, p2); return t }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A) Ctor_I_O_O(c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__b__1464000574 any) { t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_b__1464000574 = c__b__1464000574 }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A) Invoke_O__O(self any) any { { var i__1464000573__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000573__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000573__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000574; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000573__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000573__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
//line :789:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A_New() *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A{}; t.Ctor(); return t }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A) Ctor() {}
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A) Invoke_O_O__O(self, s__1464000586__1 any) any { var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A_New_O_O(s__1464000586__1, self); var tmp2 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A_fn_class; if fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_237, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A_fn_class = fncls__135d; tmp2 = fncls__135d } else { tmp2 = fncls__135 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :789:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A{}; t.Ctor_O_O(p0, p1); return t }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A) Ctor_O_O(c__s__1464000586, c__iter__1464000585 any) { t.F_s__1464000586 = c__s__1464000586; t.F_iter__1464000585 = c__iter__1464000585 }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A) Invoke_O__O(self any) any { { var s__1464000586__1 any; var t_ any = t.F_s__1464000586; t.F_s__1464000586 = nil; s__1464000586__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000586__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000586__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000586__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000586__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000588__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A_New_O_I_O(b__1464000588__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_238, false); A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A_fn_class = fncls__134d; tmp2 = fncls__134d } else { tmp2 = fncls__134 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000585); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000588__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000586__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000588__6), nil) } } else { var i__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000586__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000585); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__4)).Ref()), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000586__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :789:1
func A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A) Ctor_O_I_O(c__b__1464000588 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000588 = c__b__1464000588; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :789:1
func (t *A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A) Invoke_O__O(self any) any { { var i__1464000587__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000587__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var i__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000587__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000588; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_89, nil), jrt.RefArrayOf(jrt.Object_class, nil, i__2)).Ref())); i__1464000587__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000587__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_class_forms_A_New() *A_arbace_j2g_decls_class_forms_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_A{}; t.Ctor(); return t }
//line :796:1
func (t *A_arbace_j2g_decls_class_forms_A) Ctor() {}
//line :796:1
func (t *A_arbace_j2g_decls_class_forms_A) Invoke_O_O__O(self, n__0 any) any { var pkg__2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_63.GetRawRoot__O()).Invoke_O__O(n__0); var g__3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(n__0); var d__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_64.GetRawRoot__O()).Invoke_O__O(n__0); var iface__5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_149.GetRawRoot__O()).Invoke_O__O(n__0); var leaf__6 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(iface__5); if






	jrt.J2g_Truth(and__1927000168__auto____6) { leaf__6 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_164.GetRawRoot__O()).Invoke_O__O(n__0) } else { leaf__6 = and__1927000168__auto____6 }; var abstract__7 any = /*line :796:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_102.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_103.Invoke_O__O(d__4), A_arbace_j2g_decls_A_const_244); var fields__8 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_410.GetRawRoot__O()).Invoke_O__O(n__0); var ifields__9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_361.GetRawRoot__O(), fields__8); var methods__10 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_451.GetRawRoot__O()).Invoke_O__O(n__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_21.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp4 any = A_arbace_j2g_decls_A_const_622; var tmp5 any = lang.Tuple_Create_O__IPersistentVector(tmp3.Invoke_O_O__O(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_10, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_11, Lit_12))).Ref())); var tmp6 any; if














	jrt.J2g_Truth(iface__5) { var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp8 any = A_arbace_j2g_decls_A_const_623; var tmp9 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp11 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp12 any = A_arbace_j2g_decls_A_const_624; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp14 lang.IPersistentVector



		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_625.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp14 = nil } else { tmp14 = lang.Tuple_Create_O__IPersistentVector(lang.IFn_Cast(A_arbace_j2g_decls_A_const_61.GetRawRoot__O()).Invoke_O_O__O(pkg__2, Lit_13)) }
//line :811:1
		var tmp15 any = tmp14; var tmp16 any; var iter__1927001039__auto____11 any; var tmp17 any = A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A_New_O(pkg__2); var tmp18 *jrt.Class
		var fncls__147 /*line :811:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A_fn_class




		if fncls__147 == nil { var fncls__147d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A_fn_class = fncls__147d; tmp18 = fncls__147d } else { tmp18 = fncls__147 }; iter__1927001039__auto____11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); tmp16 = lang.IFn_Cast(iter__1927001039__auto____11).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0))
//line :811:1
		var tmp19 any = tmp16; var tmp20 lang.IPersistentVector







		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_625.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp20 = nil } else { var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp22 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()); var tmp23 *lang.PersistentVector; lang.PersistentVector_Init(); tmp23 = lang.PersistentVector_EMPTY; tmp20 = lang.Tuple_Create_O__IPersistentVector(tmp21.Invoke_O_O__O(tmp22, tmp23.Ref())) }
//line :811:1
		var tmp24 any = tmp20; var tmp25 any; var iter__1927001039__auto____11_2 any; var tmp26 any = A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A_New_O(pkg__2); var tmp27 *jrt.Class
		var fncls__150 /*line :811:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A_fn_class








		if fncls__150 == nil { var fncls__150d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_16, false); A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A_fn_class = fncls__150d; tmp27 = fncls__150d } else { tmp27 = fncls__150 }; iter__1927001039__auto____11_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); tmp25 = lang.IFn_Cast(iter__1927001039__auto____11_2).Invoke_O__O(A_arbace_j2g_decls_A_const_122.Invoke_O__O(d__4))
//line :811:1
		tmp6 = lang.Tuple_Create_O__IPersistentVector(tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O_O__O(tmp11, tmp12, tmp13.Invoke_O_O_O_O__O(tmp15, tmp19, tmp24, tmp25)))) } else {












			var tmp28 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp30 any = A_arbace_j2g_decls_A_const_629; var tmp31 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp33 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp34 any = A_arbace_j2g_decls_A_const_630; var tmp35 any

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp35 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_j2g_decls_A_const_632, A_arbace_j2g_decls_A_const_633) } else { tmp35 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_631.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0) }
//line :824:1
			var tmp36 any = tmp35; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp38 any; var iter__1927001039__auto____11_3 any; var tmp39 any = A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A_New_O(pkg__2); var tmp40 *jrt.Class
			var fncls__156 /*line :824:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A_fn_class



			if fncls__156 == nil { var fncls__156d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A_fn_class = fncls__156d; tmp40 = fncls__156d } else { tmp40 = fncls__156 }; iter__1927001039__auto____11_3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil); tmp38 = lang.IFn_Cast(iter__1927001039__auto____11_3).Invoke_O__O(ifields__9)
//line :824:1
			var tmp41 any = lang.Tuple_Create_O__IPersistentVector(tmp29.Invoke_O_O_O__O(tmp30, tmp31, tmp32.Invoke_O_O_O_O__O(tmp33, tmp34, tmp36, tmp37.Invoke_O_O__O(tmp38, lang.IFn_Cast(A_arbace_j2g_decls_A_const_634.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0))))); var tmp42 lang.IPersistentVector





			if jrt.J2g_Truth(leaf__6) { tmp42 = nil } else { var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp44 any = A_arbace_j2g_decls_A_const_635; var tmp45 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_18), jrt.RefArrayOf(jrt.Object_class, g__3, nil)).Ref()); var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_194.GetRawRoot__O()); var tmp47 any = A_arbace_j2g_decls_A_const_58.GetRawRoot__O(); var tmp48 any = A_arbace_j2g_decls_A_const_636; var tmp49 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_637.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()); var tmp51 any; var iter__1927001039__auto____11_4 any; var tmp52 any = A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A_New_O(pkg__2); var tmp53 *jrt.Class
				var fncls__159 /*line :830:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A_fn_class



				if fncls__159 == nil { var fncls__159d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A_fn_class = fncls__159d; tmp53 = fncls__159d } else { tmp53 = fncls__159 }; iter__1927001039__auto____11_4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); tmp51 = lang.IFn_Cast(iter__1927001039__auto____11_4).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_163.GetRawRoot__O()).Invoke_O__O(n__0))
//line :830:1
				var tmp54 any = tmp51; var tmp55 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp56 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()); var tmp57 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()); var tmp58 *lang.PersistentVector; lang.PersistentVector_Init(); tmp58 = lang.PersistentVector_EMPTY; var tmp59 any = tmp58.Ref(); var tmp60 any = A_arbace_j2g_decls_A_const_18; var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp62 any = A_arbace_j2g_decls_A_const_639; var tmp63 any = lang.Tuple_Create_O__IPersistentVector(tmp55.Invoke_O_O__O(tmp56, tmp57.Invoke_O_O__O(tmp59, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp60, tmp61.Invoke_O_O__O(tmp62, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3))))))); var tmp64 any; var iter__1927001039__auto____11_5 any; var tmp65 any = A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A_New_O(pkg__2); var tmp66 *jrt.Class
				var fncls__162 /*line :830:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A_fn_class





				if fncls__162 == nil { var fncls__162d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A_fn_class = fncls__162d; tmp66 = fncls__162d } else { tmp66 = fncls__162 }; iter__1927001039__auto____11_5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp65, tmp66, nil); tmp64 = lang.IFn_Cast(iter__1927001039__auto____11_5).Invoke_O__O(methods__10)
//line :830:1
				var tmp67 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp68 any = A_arbace_j2g_decls_A_const_640; var tmp69 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp70 any = A_arbace_j2g_decls_A_const_642; var tmp71 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp72 any = A_arbace_j2g_decls_A_const_643; var tmp73 any = A_arbace_j2g_decls_A_const_18; var tmp74 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp75 any = A_arbace_j2g_decls_A_const_644; tmp42 = lang.Tuple_Create_O_O__IPersistentVector(tmp43.Invoke_O_O_O__O(tmp44, tmp45, tmp46.Invoke_O_O_O_O__O(tmp47, tmp48, tmp49, tmp50.Invoke_O_O_O__O(tmp54, tmp63, tmp64))), tmp67.Invoke_O_O_O_O__O(tmp68, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_20, nil), jrt.RefArrayOf(jrt.Object_class, nil, g__3)).Ref()), lang.IFn_Cast(A_arbace_j2g_decls_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O__IPersistentVector(tmp69.Invoke_O_O__O(tmp70, tmp71.Invoke_O_O__O(tmp72, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3)))), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp74.Invoke_O_O__O(tmp75, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(g__3))))), A_arbace_j2g_decls_A_const_641)) }
//line :824:1
			var tmp76 any = tmp42; var tmp77 any; var iter__1927001039__auto____11_6 any; var tmp78 any = A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A_New_O(g__3); var tmp79 *jrt.Class
			var fncls__153 /*line :824:1*/*jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A_fn_class
















			if fncls__153 == nil { var fncls__153d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A_fn_class = fncls__153d; tmp79 = fncls__153d } else { tmp79 = fncls__153 }; iter__1927001039__auto____11_6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp78, tmp79, nil); tmp77 = lang.IFn_Cast(iter__1927001039__auto____11_6).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_645.GetRawRoot__O()).Invoke_O__O(n__0))
//line :824:1
			tmp6 = tmp28.Invoke_O_O_O__O(tmp41, tmp76, tmp77) }; var tmp80 any = tmp6; var tmp81 any = /*line :808:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_618.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp82 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_619.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp83 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_620.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0); var tmp84 any; if






































	jrt.J2g_Truth(iface__5) { tmp84 = nil } else {
		var tmp85 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_621.GetRawRoot__O()); var tmp86 any = A_arbace_j2g_decls_class_forms_fn__1464000662_A_New_O_O(pkg__2, n__0); var tmp87 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000662_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_j2g_decls_class_forms_fn__1464000662_A_fn_class = fncls__163d; tmp87 = fncls__163d } else { tmp87 = fncls__163 }; var tmp88 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp86, tmp87, nil); var tmp89 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_148.GetRawRoot__O()); var tmp90 any = A_arbace_j2g_decls_class_forms_fn__1464000664_A_New(); var tmp91 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000664_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_j2g_decls_class_forms_fn__1464000664_A_fn_class = fncls__164d; tmp91 = fncls__164d } else { tmp91 = fncls__164 }; tmp84 = tmp85.Invoke_O_O__O(tmp88, tmp89.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp90, tmp91, nil), methods__10)) }; var tmp92 any = tmp84; var tmp93 lang.IFn = /*line :808:1*/lang.IFn_Cast(A_arbace_j2g_decls_A_const_621.GetRawRoot__O()); var tmp94 any = A_arbace_j2g_decls_class_forms_fn__1464000666_A_New_O_O(pkg__2, n__0); var tmp95 *jrt.Class; var fncls__165 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000666_A_fn_class; if








































	fncls__165 == nil { var fncls__165d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_j2g_decls_class_forms_fn__1464000666_A_fn_class = fncls__165d; tmp95 = fncls__165d } else { tmp95 = fncls__165 }; var tmp96 any = /*line :808:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp94, tmp95, nil); var tmp97 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_162.GetRawRoot__O()); var tmp98 any = A_arbace_j2g_decls_class_forms_fn__1464000668_A_New(); var tmp99 *jrt.Class; var fncls__166 *jrt.Class = A_arbace_j2g_decls_class_forms_fn__1464000668_A_fn_class; if








































	fncls__166 == nil { var fncls__166d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_j2g_decls_class_forms_fn__1464000668_A_fn_class = fncls__166d; tmp99 = fncls__166d } else { tmp99 = fncls__166 }; var tmp100 any = /*line :808:1*/tmp93.Invoke_O_O__O(tmp96, tmp97.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil), methods__10)); var tmp101 any; var tmp102 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(iface__5); if









































	jrt.J2g_Truth(and__1927000168__auto____11) { tmp102 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(abstract__7) } else { tmp102 = and__1927000168__auto____11 }; if jrt.J2g_Truth(tmp102) {
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp101 = nil } else {



			tmp101 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_57.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_648.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0), lang.IFn_Cast(A_arbace_j2g_decls_A_const_649.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0)) } } else {
//line :850:1
				tmp101 = nil }; var tmp103 any = tmp101; var tmp104 any; if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_250.GetRawRoot__O()).Invoke_O__O(n__0)) { tmp104 = nil } else { tmp104 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_613.GetRawRoot__O()).Invoke_O_O__O(pkg__2, n__0) }; return /*line :808:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp80, tmp81, tmp82, tmp83, tmp92, tmp100, tmp103, tmp104)) }







func A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A{}; t.Ctor_O(p0); return t }
//line :816:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :816:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A) Invoke_O_O__O(self, s__1464000603__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A_New_O_O_O(self, t.F_pkg, s__1464000603__1); var tmp2 *jrt.Class; var fncls__146 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A_fn_class; if fncls__146 == nil { var fncls__146d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A_fn_class = fncls__146d; tmp2 = fncls__146d } else { tmp2 = fncls__146 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :816:1
func A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :816:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A) Ctor_O_O_O(c__iter__1464000602, c__pkg, c__s__1464000603 any) { t.F_iter__1464000602 = c__iter__1464000602; t.F_pkg = c__pkg; t.F_s__1464000603 = c__s__1464000603 }
//line :816:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A) Invoke_O__O(self any) any { { var s__1464000603__1 any; var t_ any = t.F_s__1464000603; t.F_s__1464000603 = nil; s__1464000603__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000603__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000603__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000603__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000603__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000605__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A_New_O_O_I_O(b__1464000605__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A_fn_class = fncls__145d; tmp2 = fncls__145d } else { tmp2 = fncls__145 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000602); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000605__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000603__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000605__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000603__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000602); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000603__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :816:1
func A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :816:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A) Ctor_O_O_I_O(c__b__1464000605, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000605 = c__b__1464000605; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :816:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A) Invoke_O__O(self any) any { { var i__1464000604__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000604__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000604__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000605; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__2)); i__1464000604__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000604__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }



func A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A{}; t.Ctor_O(p0); return t }
//line :820:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :820:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A) Invoke_O_O__O(self, s__1464000613__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A_New_O_O_O(self, t.F_pkg, s__1464000613__1); var tmp2 *jrt.Class; var fncls__149 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A_fn_class; if fncls__149 == nil { var fncls__149d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A_fn_class = fncls__149d; tmp2 = fncls__149d } else { tmp2 = fncls__149 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :820:1
func A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :820:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A) Ctor_O_O_O(c__iter__1464000612, c__pkg, c__s__1464000613 any) { t.F_iter__1464000612 = c__iter__1464000612; t.F_pkg = c__pkg; t.F_s__1464000613 = c__s__1464000613 }
//line :820:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A) Invoke_O__O(self any) any { { var s__1464000613__1 any; var t_ any = t.F_s__1464000613; t.F_s__1464000613 = nil; s__1464000613__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000613__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000613__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000613__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000613__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000615__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A_New_O_O_I_O(b__1464000615__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__148 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A_fn_class; if fncls__148 == nil { var fncls__148d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_31, false); A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A_fn_class = fncls__148d; tmp2 = fncls__148d } else { tmp2 = fncls__148 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000612); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000615__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000613__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000615__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000613__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__4))
															if jrt.J2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_610.GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.J2g_Truth(and__1927000168__auto____6) { tmp4 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____6 } } else { tmp4 = and__1927000168__auto____5 }
//line :820:1
	if jrt.J2g_Truth(tmp4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_454.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))))) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1464000612); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_617.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__4), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000613__3))) } else { s__1464000613__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000613__3); continue L1 } } else { s__1464000613__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000613__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :820:1
func A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :820:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A) Ctor_O_O_I_O(c__b__1464000615, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000615 = c__b__1464000615; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :820:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A) Invoke_O__O(self any) any { { var i__1464000614__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000614__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000614__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_361.GetRawRoot__O()).Invoke_O__O(mm__2))
																if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_610.GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.J2g_Truth(and__1927000168__auto____4) { tmp2 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_120.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :820:1
	if jrt.J2g_Truth(tmp2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_454.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))))) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp4 any = t.F_b__1464000615; tmp3.Invoke_O_O__O(tmp4, lang.IFn_Cast(A_arbace_j2g_decls_A_const_617.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__2)); i__1464000614__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000614__1); continue L1 } else { i__1464000614__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000614__1); continue L1 } } else { i__1464000614__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000614__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }







func A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A{}; t.Ctor_O(p0); return t }
//line :828:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :828:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A) Invoke_O_O__O(self, s__1464000623__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A_New_O_O_O(t.F_pkg, s__1464000623__1, self); var tmp2 *jrt.Class; var fncls__155 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A_fn_class; if fncls__155 == nil { var fncls__155d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_32, false); A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A_fn_class = fncls__155d; tmp2 = fncls__155d } else { tmp2 = fncls__155 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :828:1
func A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :828:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A) Ctor_O_O_O(c__pkg, c__s__1464000623, c__iter__1464000622 any) { t.F_pkg = c__pkg; t.F_s__1464000623 = c__s__1464000623; t.F_iter__1464000622 = c__iter__1464000622 }
//line :828:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A) Invoke_O__O(self any) any { { var s__1464000623__1 any; var t_ any = t.F_s__1464000623; t.F_s__1464000623 = nil; s__1464000623__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000623__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000623__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000623__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000623__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000625__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A_New_O_O_I_O(b__1464000625__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__154 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A_fn_class; if fncls__154 == nil { var fncls__154d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_33, false); A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A_fn_class = fncls__154d; tmp2 = fncls__154d } else { tmp2 = fncls__154 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000622); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000625__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000623__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000625__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000623__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000622); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__4))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_470.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__4)), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000623__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :828:1
func A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :828:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A) Ctor_O_O_I_O(c__b__1464000625, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000625 = c__b__1464000625; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :828:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A) Invoke_O__O(self any) any { { var i__1464000624__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000624__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000624__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000625; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_73.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls_A_const_100.Invoke_O__O(f__2))), lang.IFn_Cast(A_arbace_j2g_decls_A_const_470.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, f__2))); i__1464000624__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000624__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }





func A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A{}; t.Ctor_O(p0); return t }
//line :834:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :834:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A) Invoke_O_O__O(self, s__1464000633__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A_New_O_O_O(t.F_pkg, s__1464000633__1, self); var tmp2 *jrt.Class; var fncls__158 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A_fn_class; if fncls__158 == nil { var fncls__158d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A_fn_class = fncls__158d; tmp2 = fncls__158d } else { tmp2 = fncls__158 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :834:1
func A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :834:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A) Ctor_O_O_O(c__pkg, c__s__1464000633, c__iter__1464000632 any) { t.F_pkg = c__pkg; t.F_s__1464000633 = c__s__1464000633; t.F_iter__1464000632 = c__iter__1464000632 }
//line :834:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A) Invoke_O__O(self any) any { { var s__1464000633__1 any; var t_ any = t.F_s__1464000633; t.F_s__1464000633 = nil; s__1464000633__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000633__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000633__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000633__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000633__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000635__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A_New_O_O_I_O(b__1464000635__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A_fn_class = fncls__157d; tmp2 = fncls__157d } else { tmp2 = fncls__157 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000632); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000635__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000633__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000635__6), nil) } } else { var s__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000633__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000632); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000633__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :834:1
func A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :834:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A) Ctor_O_O_I_O(c__b__1464000635, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000635 = c__b__1464000635; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :834:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A) Invoke_O__O(self any) any { { var i__1464000634__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000634__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var s__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000634__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000635; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_127.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, s__2)); i__1464000634__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000634__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A{}; t.Ctor_O(p0); return t }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A) Invoke_O_O__O(self, s__1464000643__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A_New_O_O_O(t.F_pkg, s__1464000643__1, self); var tmp2 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A_fn_class = fncls__161d; tmp2 = fncls__161d } else { tmp2 = fncls__161 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :836:1
func A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A) Ctor_O_O_O(c__pkg, c__s__1464000643, c__iter__1464000642 any) { t.F_pkg = c__pkg; t.F_s__1464000643 = c__s__1464000643; t.F_iter__1464000642 = c__iter__1464000642 }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A) Invoke_O__O(self any) any { { var s__1464000643__1 any; var t_ any = t.F_s__1464000643; t.F_s__1464000643 = nil; s__1464000643__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000643__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000643__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000643__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000643__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000645__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A_New_O_O_I_O(b__1464000645__6, t.F_pkg, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__160 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A_fn_class; if fncls__160 == nil { var fncls__160d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A_fn_class = fncls__160d; tmp2 = fncls__160d } else { tmp2 = fncls__160 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000642); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000645__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000643__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000645__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000643__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_638.GetRawRoot__O()).Invoke_O__O(mm__4)) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_454.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__4), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__4))))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1464000642); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_617.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__4), tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000643__3))) } else { s__1464000643__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000643__3); continue L1 } } else { s__1464000643__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000643__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :836:1
func A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A) Ctor_O_O_I_O(c__b__1464000645, c__pkg any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000645 = c__b__1464000645; t.F_pkg = c__pkg; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :836:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A) Invoke_O__O(self any) any { { var i__1464000644__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000644__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000644__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_638.GetRawRoot__O()).Invoke_O__O(mm__2)) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_454.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_j2g_decls_A_const_100.Invoke_O__O(mm__2), A_arbace_j2g_decls_A_const_118.Invoke_O__O(mm__2))))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000645; tmp2.Invoke_O_O__O(tmp3, lang.IFn_Cast(A_arbace_j2g_decls_A_const_617.GetRawRoot__O()).Invoke_O_O__O(t.F_pkg, mm__2)); i__1464000644__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000644__1); continue L1 } else { i__1464000644__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000644__1); continue L1 } } else { i__1464000644__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000644__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }




func A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A_New_O(p0 any) *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A{}; t.Ctor_O(p0); return t }
//line :841:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A) Ctor_O(c__g any) { t.F_g = c__g }
//line :841:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A) Invoke_O_O__O(self, s__1464000653__1 any) any { var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A_New_O_O_O(t.F_g, s__1464000653__1, self); var tmp2 *jrt.Class; var fncls__152 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A_fn_class; if fncls__152 == nil { var fncls__152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A_fn_class = fncls__152d; tmp2 = fncls__152d } else { tmp2 = fncls__152 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :841:1
func A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A_New_O_O_O(p0, p1, p2 any) *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :841:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A) Ctor_O_O_O(c__g, c__s__1464000653, c__iter__1464000652 any) { t.F_g = c__g; t.F_s__1464000653 = c__s__1464000653; t.F_iter__1464000652 = c__iter__1464000652 }
//line :841:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A) Invoke_O__O(self any) any { { var s__1464000653__1 any; var t_ any = t.F_s__1464000653; t.F_s__1464000653 = nil; s__1464000653__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_30.GetRawRoot__O()).Invoke_O__O(s__1464000653__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1464000653__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_67.GetRawRoot__O()).Invoke_O__O(s__1464000653__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_68.GetRawRoot__O()).Invoke_O__O(s__1464000653__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__1464000655__6 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_69.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A_New_O_O_I_O(b__1464000655__6, t.F_g, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A_fn_class = fncls__151d; tmp2 = fncls__151d } else { tmp2 = fncls__151 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1464000652); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000655__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_78.GetRawRoot__O()).Invoke_O__O(s__1464000653__3))) } else { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_75.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_77.GetRawRoot__O()).Invoke_O__O(b__1464000655__6), nil) } } else { var j__4 any = lang.IFn_Cast(A_arbace_j2g_decls_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1464000653__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_625.GetRawRoot__O()).Invoke_O__O(j__4))) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_626; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_627; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_628; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__1464000652); return lang.IFn_Cast(A_arbace_j2g_decls_A_const_76.GetRawRoot__O()).Invoke_O_O__O(tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(j__4))).Ref()), lang.Tuple_Create_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g))))), tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000653__3))) } else { s__1464000653__1 = lang.IFn_Cast(A_arbace_j2g_decls_A_const_79.GetRawRoot__O()).Invoke_O__O(s__1464000653__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :841:1
func A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :841:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A) Ctor_O_O_I_O(c__b__1464000655, c__g any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1464000655 = c__b__1464000655; t.F_g = c__g; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :841:1
func (t *A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A) Invoke_O__O(self any) any { { var i__1464000654__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__1464000654__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var j__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__1464000654__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_j2g_decls_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_j2g_decls_A_const_625.GetRawRoot__O()).Invoke_O__O(j__2))) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_70.GetRawRoot__O()); var tmp3 any = t.F_b__1464000655; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp5 any = A_arbace_j2g_decls_A_const_626; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_23.GetRawRoot__O()); var tmp7 any = A_arbace_j2g_decls_A_const_627; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_j2g_decls_A_const_58.GetRawRoot__O()); var tmp9 any = A_arbace_j2g_decls_A_const_628; tmp2.Invoke_O_O__O(tmp3, tmp4.Invoke_O_O_O__O(tmp5, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_j2g_decls_A_const_151.GetRawRoot__O()).Invoke_O__O(j__2))).Ref()), lang.Tuple_Create_O__IPersistentVector(tmp6.Invoke_O_O__O(tmp7, tmp8.Invoke_O_O__O(tmp9, lang.IFn_Cast(A_arbace_j2g_decls_A_const_72.GetRawRoot__O()).Invoke_O__O(t.F_g)))))); i__1464000654__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000654__1); continue L1 } else { i__1464000654__1 = lang.Numbers_Unchecked_inc_J__J(i__1464000654__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_j2g_decls_class_forms_fn__1464000662_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_class_forms_fn__1464000662_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000662_A{}; t.Ctor_O_O(p0, p1); return t }
//line :848:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000662_A) Ctor_O_O(c__pkg, c__n any) { t.F_pkg = c__pkg; t.F_n = c__n }
//line :848:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000662_A) Invoke_O_O__O(self, p1__1464000598_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_646.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, p1__1464000598_SHARP___1) }
//line :848:1
func A_arbace_j2g_decls_class_forms_fn__1464000664_A_New() *A_arbace_j2g_decls_class_forms_fn__1464000664_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000664_A{}; t.Ctor(); return t }
//line :848:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000664_A) Ctor() {}
//line :848:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000664_A) Invoke_O_O__O(self, p1__1464000599_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(p1__1464000599_SHARP___1))).Ref() }
func A_arbace_j2g_decls_class_forms_fn__1464000666_A_New_O_O(p0, p1 any) *A_arbace_j2g_decls_class_forms_fn__1464000666_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000666_A{}; t.Ctor_O_O(p0, p1); return t }
//line :849:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000666_A) Ctor_O_O(c__pkg, c__n any) { t.F_pkg = c__pkg; t.F_n = c__n }
//line :849:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000666_A) Invoke_O_O__O(self, p1__1464000600_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_j2g_decls_A_const_647.GetRawRoot__O()).Invoke_O_O_O__O(t.F_pkg, t.F_n, p1__1464000600_SHARP___1) }
//line :849:1
func A_arbace_j2g_decls_class_forms_fn__1464000668_A_New() *A_arbace_j2g_decls_class_forms_fn__1464000668_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_class_forms_fn__1464000668_A{}; t.Ctor(); return t }
//line :849:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000668_A) Ctor() {}
//line :849:1
func (t *A_arbace_j2g_decls_class_forms_fn__1464000668_A) Invoke_O_O__O(self, p1__1464000601_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_27, A_arbace_j2g_decls_A_const_100.Invoke_O__O(p1__1464000601_SHARP___1))).Ref() }



















































































































































































































































































































































































type A_arbace_j2g_decls_A struct{ jrt.Object }

var A_arbace_j2g_decls_A_const_pool *jrt.RefArray

var A_arbace_j2g_decls_A_const_0 *lang.Var

var A_arbace_j2g_decls_A_const_1 *lang.Var

var A_arbace_j2g_decls_A_const_2 any

var A_arbace_j2g_decls_A_const_3 any

var A_arbace_j2g_decls_A_const_4 any

var A_arbace_j2g_decls_A_const_5 any

var A_arbace_j2g_decls_A_const_6 any

var A_arbace_j2g_decls_A_const_7 any

var A_arbace_j2g_decls_A_const_8 any

var A_arbace_j2g_decls_A_const_9 any

var A_arbace_j2g_decls_A_const_10 any

var A_arbace_j2g_decls_A_const_11 any

var A_arbace_j2g_decls_A_const_12 *lang.Var

var A_arbace_j2g_decls_A_const_13 *lang.Var

var A_arbace_j2g_decls_A_const_14 *lang.Var

var A_arbace_j2g_decls_A_const_15 any

var A_arbace_j2g_decls_A_const_16 *lang.Var

var A_arbace_j2g_decls_A_const_17 *lang.Var

var A_arbace_j2g_decls_A_const_18 *lang.Keyword

var A_arbace_j2g_decls_A_const_19 *lang.Var

var A_arbace_j2g_decls_A_const_20 *lang.Var

var A_arbace_j2g_decls_A_const_21 *lang.Var

var A_arbace_j2g_decls_A_const_22 *lang.Var

var A_arbace_j2g_decls_A_const_23 *lang.Var

var A_arbace_j2g_decls_A_const_24 *lang.Var

var A_arbace_j2g_decls_A_const_25 *lang.Var

var A_arbace_j2g_decls_A_const_26 *lang.Var

var A_arbace_j2g_decls_A_const_27 *lang.Var

var A_arbace_j2g_decls_A_const_28 *lang.Var

var A_arbace_j2g_decls_A_const_29 *lang.Var

var A_arbace_j2g_decls_A_const_30 *lang.Var

var A_arbace_j2g_decls_A_const_31 *lang.Var

var A_arbace_j2g_decls_A_const_32 *lang.Var

var A_arbace_j2g_decls_A_const_33 *lang.Keyword

var A_arbace_j2g_decls_A_const_34 *lang.Keyword

var A_arbace_j2g_decls_A_const_35 *lang.Keyword

var A_arbace_j2g_decls_A_const_36 *lang.Var

var A_arbace_j2g_decls_A_const_37 *lang.Keyword

var A_arbace_j2g_decls_A_const_38 *lang.Keyword

var A_arbace_j2g_decls_A_const_39 *lang.Keyword

var A_arbace_j2g_decls_A_const_40 *lang.Keyword

var A_arbace_j2g_decls_A_const_41 *lang.Var

var A_arbace_j2g_decls_A_const_42 *lang.Keyword

var A_arbace_j2g_decls_A_const_43 *lang.Keyword

var A_arbace_j2g_decls_A_const_44 *lang.Keyword

var A_arbace_j2g_decls_A_const_45 *lang.Keyword

var A_arbace_j2g_decls_A_const_46 *lang.Var

var A_arbace_j2g_decls_A_const_47 *lang.Var

var A_arbace_j2g_decls_A_const_48 *lang.Var

var A_arbace_j2g_decls_A_const_49 any

var A_arbace_j2g_decls_A_const_50 any

var A_arbace_j2g_decls_A_const_51 *lang.Var

var A_arbace_j2g_decls_A_const_52 any

var A_arbace_j2g_decls_A_const_53 any

var A_arbace_j2g_decls_A_const_54 *lang.Var

var A_arbace_j2g_decls_A_const_55 any

var A_arbace_j2g_decls_A_const_56 *lang.Var

var A_arbace_j2g_decls_A_const_57 *lang.Var

var A_arbace_j2g_decls_A_const_58 *lang.Var

var A_arbace_j2g_decls_A_const_59 any

var A_arbace_j2g_decls_A_const_60 any

var A_arbace_j2g_decls_A_const_61 *lang.Var

var A_arbace_j2g_decls_A_const_62 *lang.Var

var A_arbace_j2g_decls_A_const_63 *lang.Var

var A_arbace_j2g_decls_A_const_64 *lang.Var

var A_arbace_j2g_decls_A_const_65 any

var A_arbace_j2g_decls_A_const_66 *lang.Keyword

var A_arbace_j2g_decls_A_const_67 *lang.Var

var A_arbace_j2g_decls_A_const_68 *lang.Var

var A_arbace_j2g_decls_A_const_69 *lang.Var

var A_arbace_j2g_decls_A_const_70 *lang.Var

var A_arbace_j2g_decls_A_const_71 *lang.Keyword

var A_arbace_j2g_decls_A_const_72 *lang.Var

var A_arbace_j2g_decls_A_const_73 *lang.Var

var A_arbace_j2g_decls_A_const_74 *lang.Keyword

var A_arbace_j2g_decls_A_const_75 *lang.Var

var A_arbace_j2g_decls_A_const_76 *lang.Var

var A_arbace_j2g_decls_A_const_77 *lang.Var

var A_arbace_j2g_decls_A_const_78 *lang.Var

var A_arbace_j2g_decls_A_const_79 *lang.Var

var A_arbace_j2g_decls_A_const_80 *lang.Keyword

var A_arbace_j2g_decls_A_const_81 *lang.Keyword

var A_arbace_j2g_decls_A_const_82 *lang.Keyword

var A_arbace_j2g_decls_A_const_83 *lang.Keyword

var A_arbace_j2g_decls_A_const_84 *lang.Var

var A_arbace_j2g_decls_A_const_85 *lang.Keyword

var A_arbace_j2g_decls_A_const_86 *lang.Keyword

var A_arbace_j2g_decls_A_const_87 *lang.Keyword

var A_arbace_j2g_decls_A_const_88 *lang.Keyword

var A_arbace_j2g_decls_A_const_89 *lang.Keyword

var A_arbace_j2g_decls_A_const_90 *lang.Var

var A_arbace_j2g_decls_A_const_91 *lang.Var

var A_arbace_j2g_decls_A_const_92 *lang.Var

var A_arbace_j2g_decls_A_const_93 *lang.Var

var A_arbace_j2g_decls_A_const_94 *lang.Var

var A_arbace_j2g_decls_A_const_95 *lang.Var

var A_arbace_j2g_decls_A_const_96 *lang.Var

var A_arbace_j2g_decls_A_const_97 *lang.Keyword

var A_arbace_j2g_decls_A_const_98 *lang.Var

var A_arbace_j2g_decls_A_const_99 *lang.Keyword

var A_arbace_j2g_decls_A_const_100 *lang.Keyword

var A_arbace_j2g_decls_A_const_101 *lang.Keyword

var A_arbace_j2g_decls_A_const_102 *lang.Var

var A_arbace_j2g_decls_A_const_103 *lang.Keyword

var A_arbace_j2g_decls_A_const_104 any

var A_arbace_j2g_decls_A_const_105 *lang.Keyword

var A_arbace_j2g_decls_A_const_106 *lang.Var

var A_arbace_j2g_decls_A_const_107 *lang.Keyword

var A_arbace_j2g_decls_A_const_108 *lang.Var

var A_arbace_j2g_decls_A_const_109 *lang.Var

var A_arbace_j2g_decls_A_const_110 *lang.Var

var A_arbace_j2g_decls_A_const_111 *lang.Var

var A_arbace_j2g_decls_A_const_112 *lang.Var

var A_arbace_j2g_decls_A_const_113 any

var A_arbace_j2g_decls_A_const_114 *lang.Keyword

var A_arbace_j2g_decls_A_const_115 *lang.Var

var A_arbace_j2g_decls_A_const_116 *lang.Var

var A_arbace_j2g_decls_A_const_117 *lang.Var

var A_arbace_j2g_decls_A_const_118 *lang.Keyword

var A_arbace_j2g_decls_A_const_119 *lang.Keyword

var A_arbace_j2g_decls_A_const_120 *lang.Var

var A_arbace_j2g_decls_A_const_121 *lang.Var

var A_arbace_j2g_decls_A_const_122 *lang.Keyword

var A_arbace_j2g_decls_A_const_123 *lang.Keyword

var A_arbace_j2g_decls_A_const_124 *lang.Var

var A_arbace_j2g_decls_A_const_125 *lang.Var

var A_arbace_j2g_decls_A_const_126 *lang.Keyword

var A_arbace_j2g_decls_A_const_127 *lang.Var

var A_arbace_j2g_decls_A_const_128 *lang.Var

var A_arbace_j2g_decls_A_const_129 any

var A_arbace_j2g_decls_A_const_130 any

var A_arbace_j2g_decls_A_const_131 any

var A_arbace_j2g_decls_A_const_132 *lang.Var

var A_arbace_j2g_decls_A_const_133 any

var A_arbace_j2g_decls_A_const_134 any

var A_arbace_j2g_decls_A_const_135 any

var A_arbace_j2g_decls_A_const_136 any

var A_arbace_j2g_decls_A_const_137 *lang.Var

var A_arbace_j2g_decls_A_const_138 *lang.Keyword

var A_arbace_j2g_decls_A_const_139 *lang.Var

var A_arbace_j2g_decls_A_const_140 any

var A_arbace_j2g_decls_A_const_141 *lang.Keyword

var A_arbace_j2g_decls_A_const_142 *lang.Keyword

var A_arbace_j2g_decls_A_const_143 *lang.Var

var A_arbace_j2g_decls_A_const_144 *lang.Var

var A_arbace_j2g_decls_A_const_145 *lang.Var

var A_arbace_j2g_decls_A_const_146 *lang.Var

var A_arbace_j2g_decls_A_const_147 *lang.Var

var A_arbace_j2g_decls_A_const_148 *lang.Var

var A_arbace_j2g_decls_A_const_149 *lang.Var

var A_arbace_j2g_decls_A_const_150 *lang.Var

var A_arbace_j2g_decls_A_const_151 *lang.Var

var A_arbace_j2g_decls_A_const_152 *lang.Var

var A_arbace_j2g_decls_A_const_153 *lang.Var

var A_arbace_j2g_decls_A_const_154 *lang.Var

var A_arbace_j2g_decls_A_const_155 any

var A_arbace_j2g_decls_A_const_156 *lang.Var

var A_arbace_j2g_decls_A_const_157 *lang.Keyword

var A_arbace_j2g_decls_A_const_158 *lang.Var

var A_arbace_j2g_decls_A_const_159 *lang.Var

var A_arbace_j2g_decls_A_const_160 *lang.Keyword

var A_arbace_j2g_decls_A_const_161 *lang.Var

var A_arbace_j2g_decls_A_const_162 *lang.Var

var A_arbace_j2g_decls_A_const_163 *lang.Var

var A_arbace_j2g_decls_A_const_164 *lang.Var

var A_arbace_j2g_decls_A_const_165 any

var A_arbace_j2g_decls_A_const_166 any

var A_arbace_j2g_decls_A_const_167 *lang.Keyword

var A_arbace_j2g_decls_A_const_168 *lang.Var

var A_arbace_j2g_decls_A_const_169 *lang.Var

var A_arbace_j2g_decls_A_const_170 *lang.Var

var A_arbace_j2g_decls_A_const_171 *lang.Var

var A_arbace_j2g_decls_A_const_172 any

var A_arbace_j2g_decls_A_const_173 *lang.Keyword

var A_arbace_j2g_decls_A_const_174 *lang.Keyword

var A_arbace_j2g_decls_A_const_175 any

var A_arbace_j2g_decls_A_const_176 any

var A_arbace_j2g_decls_A_const_177 *lang.Keyword

var A_arbace_j2g_decls_A_const_178 *lang.Keyword

var A_arbace_j2g_decls_A_const_179 any

var A_arbace_j2g_decls_A_const_180 *lang.Keyword

var A_arbace_j2g_decls_A_const_181 *lang.Var

var A_arbace_j2g_decls_A_const_182 *lang.Keyword

var A_arbace_j2g_decls_A_const_183 *lang.Keyword

var A_arbace_j2g_decls_A_const_184 *lang.Keyword

var A_arbace_j2g_decls_A_const_185 *lang.Var

var A_arbace_j2g_decls_A_const_186 *lang.Var

var A_arbace_j2g_decls_A_const_187 *lang.Keyword

var A_arbace_j2g_decls_A_const_188 *lang.Keyword

var A_arbace_j2g_decls_A_const_189 *lang.Keyword

var A_arbace_j2g_decls_A_const_190 *lang.Keyword

var A_arbace_j2g_decls_A_const_191 *lang.Keyword

var A_arbace_j2g_decls_A_const_192 *lang.Keyword

var A_arbace_j2g_decls_A_const_193 *lang.Keyword

var A_arbace_j2g_decls_A_const_194 *lang.Var

var A_arbace_j2g_decls_A_const_195 any

var A_arbace_j2g_decls_A_const_196 any

var A_arbace_j2g_decls_A_const_197 any

var A_arbace_j2g_decls_A_const_198 *lang.Keyword

var A_arbace_j2g_decls_A_const_199 *lang.Keyword

var A_arbace_j2g_decls_A_const_200 *lang.Var

var A_arbace_j2g_decls_A_const_201 *lang.Var

var A_arbace_j2g_decls_A_const_202 *lang.Var

var A_arbace_j2g_decls_A_const_203 *lang.Var

var A_arbace_j2g_decls_A_const_204 *lang.Var

var A_arbace_j2g_decls_A_const_205 *lang.Var

var A_arbace_j2g_decls_A_const_206 any

var A_arbace_j2g_decls_A_const_207 *lang.Var

var A_arbace_j2g_decls_A_const_208 *lang.Var

var A_arbace_j2g_decls_A_const_209 *lang.Keyword

var A_arbace_j2g_decls_A_const_210 *lang.Keyword

var A_arbace_j2g_decls_A_const_211 *lang.Keyword

var A_arbace_j2g_decls_A_const_212 *lang.Keyword

var A_arbace_j2g_decls_A_const_213 *lang.Keyword

var A_arbace_j2g_decls_A_const_214 *lang.Keyword

var A_arbace_j2g_decls_A_const_215 *lang.Var

var A_arbace_j2g_decls_A_const_216 any

var A_arbace_j2g_decls_A_const_217 any

var A_arbace_j2g_decls_A_const_218 any

var A_arbace_j2g_decls_A_const_219 any

var A_arbace_j2g_decls_A_const_220 any

var A_arbace_j2g_decls_A_const_221 *lang.Keyword

var A_arbace_j2g_decls_A_const_222 *lang.Var

var A_arbace_j2g_decls_A_const_223 *lang.Keyword

var A_arbace_j2g_decls_A_const_224 *lang.Keyword

var A_arbace_j2g_decls_A_const_225 *lang.Keyword

var A_arbace_j2g_decls_A_const_226 any

var A_arbace_j2g_decls_A_const_227 any

var A_arbace_j2g_decls_A_const_228 *lang.Keyword

var A_arbace_j2g_decls_A_const_229 any

var A_arbace_j2g_decls_A_const_230 any

var A_arbace_j2g_decls_A_const_231 *lang.Var

var A_arbace_j2g_decls_A_const_232 *lang.Var

var A_arbace_j2g_decls_A_const_233 any

var A_arbace_j2g_decls_A_const_234 any

var A_arbace_j2g_decls_A_const_235 any

var A_arbace_j2g_decls_A_const_236 *lang.Var

var A_arbace_j2g_decls_A_const_237 *lang.Var

var A_arbace_j2g_decls_A_const_238 *lang.Keyword

var A_arbace_j2g_decls_A_const_239 any

var A_arbace_j2g_decls_A_const_240 any

var A_arbace_j2g_decls_A_const_241 any

var A_arbace_j2g_decls_A_const_242 *lang.Var

var A_arbace_j2g_decls_A_const_243 any

var A_arbace_j2g_decls_A_const_244 any

var A_arbace_j2g_decls_A_const_245 any

var A_arbace_j2g_decls_A_const_246 *lang.Var

var A_arbace_j2g_decls_A_const_247 any

var A_arbace_j2g_decls_A_const_248 *lang.Var

var A_arbace_j2g_decls_A_const_249 *lang.Var

var A_arbace_j2g_decls_A_const_250 *lang.Var

var A_arbace_j2g_decls_A_const_251 any

var A_arbace_j2g_decls_A_const_252 any

var A_arbace_j2g_decls_A_const_253 any

var A_arbace_j2g_decls_A_const_254 any

var A_arbace_j2g_decls_A_const_255 any

var A_arbace_j2g_decls_A_const_256 any

var A_arbace_j2g_decls_A_const_257 any

var A_arbace_j2g_decls_A_const_258 *lang.Var

var A_arbace_j2g_decls_A_const_259 *lang.Var

var A_arbace_j2g_decls_A_const_260 any

var A_arbace_j2g_decls_A_const_261 any

var A_arbace_j2g_decls_A_const_262 any

var A_arbace_j2g_decls_A_const_263 any

var A_arbace_j2g_decls_A_const_264 any

var A_arbace_j2g_decls_A_const_265 any

var A_arbace_j2g_decls_A_const_266 any

var A_arbace_j2g_decls_A_const_267 any

var A_arbace_j2g_decls_A_const_268 any

var A_arbace_j2g_decls_A_const_269 any

var A_arbace_j2g_decls_A_const_270 any

var A_arbace_j2g_decls_A_const_271 any

var A_arbace_j2g_decls_A_const_272 any

var A_arbace_j2g_decls_A_const_273 any

var A_arbace_j2g_decls_A_const_274 any

var A_arbace_j2g_decls_A_const_275 any

var A_arbace_j2g_decls_A_const_276 any

var A_arbace_j2g_decls_A_const_277 any

var A_arbace_j2g_decls_A_const_278 any

var A_arbace_j2g_decls_A_const_279 *lang.Var

var A_arbace_j2g_decls_A_const_280 any

var A_arbace_j2g_decls_A_const_281 any

var A_arbace_j2g_decls_A_const_282 any

var A_arbace_j2g_decls_A_const_283 any

var A_arbace_j2g_decls_A_const_284 any

var A_arbace_j2g_decls_A_const_285 any

var A_arbace_j2g_decls_A_const_286 any

var A_arbace_j2g_decls_A_const_287 any

var A_arbace_j2g_decls_A_const_288 any

var A_arbace_j2g_decls_A_const_289 any

var A_arbace_j2g_decls_A_const_290 any

var A_arbace_j2g_decls_A_const_291 *lang.Var

var A_arbace_j2g_decls_A_const_292 any

var A_arbace_j2g_decls_A_const_293 any

var A_arbace_j2g_decls_A_const_294 any

var A_arbace_j2g_decls_A_const_295 any

var A_arbace_j2g_decls_A_const_296 any

var A_arbace_j2g_decls_A_const_297 any

var A_arbace_j2g_decls_A_const_298 any

var A_arbace_j2g_decls_A_const_299 any

var A_arbace_j2g_decls_A_const_300 any

var A_arbace_j2g_decls_A_const_301 any

var A_arbace_j2g_decls_A_const_302 any

var A_arbace_j2g_decls_A_const_303 any

var A_arbace_j2g_decls_A_const_304 any

var A_arbace_j2g_decls_A_const_305 any

var A_arbace_j2g_decls_A_const_306 any

var A_arbace_j2g_decls_A_const_307 any

var A_arbace_j2g_decls_A_const_308 any

var A_arbace_j2g_decls_A_const_309 any

var A_arbace_j2g_decls_A_const_310 *lang.Var

var A_arbace_j2g_decls_A_const_311 any

var A_arbace_j2g_decls_A_const_312 any

var A_arbace_j2g_decls_A_const_313 any

var A_arbace_j2g_decls_A_const_314 any

var A_arbace_j2g_decls_A_const_315 any

var A_arbace_j2g_decls_A_const_316 any

var A_arbace_j2g_decls_A_const_317 any

var A_arbace_j2g_decls_A_const_318 any

var A_arbace_j2g_decls_A_const_319 *lang.Keyword

var A_arbace_j2g_decls_A_const_320 *lang.Keyword

var A_arbace_j2g_decls_A_const_321 *lang.Keyword

var A_arbace_j2g_decls_A_const_322 *lang.Var

var A_arbace_j2g_decls_A_const_323 *lang.Keyword

var A_arbace_j2g_decls_A_const_324 *lang.Keyword

var A_arbace_j2g_decls_A_const_325 *lang.Var

var A_arbace_j2g_decls_A_const_326 *lang.Keyword

var A_arbace_j2g_decls_A_const_327 *lang.Keyword

var A_arbace_j2g_decls_A_const_328 *lang.Var

var A_arbace_j2g_decls_A_const_329 *lang.Var

var A_arbace_j2g_decls_A_const_330 *lang.Var

var A_arbace_j2g_decls_A_const_331 *lang.Keyword

var A_arbace_j2g_decls_A_const_332 *lang.Keyword

var A_arbace_j2g_decls_A_const_333 *lang.Keyword

var A_arbace_j2g_decls_A_const_334 *lang.Var

var A_arbace_j2g_decls_A_const_335 any

var A_arbace_j2g_decls_A_const_336 any

var A_arbace_j2g_decls_A_const_337 any

var A_arbace_j2g_decls_A_const_338 any

var A_arbace_j2g_decls_A_const_339 any

var A_arbace_j2g_decls_A_const_340 *lang.Keyword

var A_arbace_j2g_decls_A_const_341 any

var A_arbace_j2g_decls_A_const_342 any

var A_arbace_j2g_decls_A_const_343 *lang.Keyword

var A_arbace_j2g_decls_A_const_344 any

var A_arbace_j2g_decls_A_const_345 *lang.Keyword

var A_arbace_j2g_decls_A_const_346 any

var A_arbace_j2g_decls_A_const_347 any

var A_arbace_j2g_decls_A_const_348 *lang.Var

var A_arbace_j2g_decls_A_const_349 *lang.Var

var A_arbace_j2g_decls_A_const_350 *lang.Var

var A_arbace_j2g_decls_A_const_351 *lang.Var

var A_arbace_j2g_decls_A_const_352 *lang.Var

var A_arbace_j2g_decls_A_const_353 any

var A_arbace_j2g_decls_A_const_354 *lang.Var

var A_arbace_j2g_decls_A_const_355 *lang.Keyword

var A_arbace_j2g_decls_A_const_356 *lang.Keyword

var A_arbace_j2g_decls_A_const_357 *lang.Var

var A_arbace_j2g_decls_A_const_358 *lang.Var

var A_arbace_j2g_decls_A_const_359 *lang.Var

var A_arbace_j2g_decls_A_const_360 *lang.Var

var A_arbace_j2g_decls_A_const_361 *lang.Var

var A_arbace_j2g_decls_A_const_362 *lang.Var

var A_arbace_j2g_decls_A_const_363 any

var A_arbace_j2g_decls_A_const_364 any

var A_arbace_j2g_decls_A_const_365 any

var A_arbace_j2g_decls_A_const_366 any

var A_arbace_j2g_decls_A_const_367 *lang.Keyword

var A_arbace_j2g_decls_A_const_368 *lang.Var

var A_arbace_j2g_decls_A_const_369 *lang.Var

var A_arbace_j2g_decls_A_const_370 any

var A_arbace_j2g_decls_A_const_371 any

var A_arbace_j2g_decls_A_const_372 *lang.Keyword

var A_arbace_j2g_decls_A_const_373 any

var A_arbace_j2g_decls_A_const_374 any

var A_arbace_j2g_decls_A_const_375 *lang.Var

var A_arbace_j2g_decls_A_const_376 *lang.Keyword

var A_arbace_j2g_decls_A_const_377 any

var A_arbace_j2g_decls_A_const_378 *lang.Var

var A_arbace_j2g_decls_A_const_379 any

var A_arbace_j2g_decls_A_const_380 any

var A_arbace_j2g_decls_A_const_381 any

var A_arbace_j2g_decls_A_const_382 any

var A_arbace_j2g_decls_A_const_383 any

var A_arbace_j2g_decls_A_const_384 any

var A_arbace_j2g_decls_A_const_385 any

var A_arbace_j2g_decls_A_const_386 any

var A_arbace_j2g_decls_A_const_387 any

var A_arbace_j2g_decls_A_const_388 *lang.Keyword

var A_arbace_j2g_decls_A_const_389 *lang.Keyword

var A_arbace_j2g_decls_A_const_390 any

var A_arbace_j2g_decls_A_const_391 any

var A_arbace_j2g_decls_A_const_392 any

var A_arbace_j2g_decls_A_const_393 any

var A_arbace_j2g_decls_A_const_394 any

var A_arbace_j2g_decls_A_const_395 any

var A_arbace_j2g_decls_A_const_396 *lang.Var

var A_arbace_j2g_decls_A_const_397 any

var A_arbace_j2g_decls_A_const_398 any

var A_arbace_j2g_decls_A_const_399 any

var A_arbace_j2g_decls_A_const_400 any

var A_arbace_j2g_decls_A_const_401 *lang.Keyword

var A_arbace_j2g_decls_A_const_402 any

var A_arbace_j2g_decls_A_const_403 any

var A_arbace_j2g_decls_A_const_404 any

var A_arbace_j2g_decls_A_const_405 any

var A_arbace_j2g_decls_A_const_406 any

var A_arbace_j2g_decls_A_const_407 any

var A_arbace_j2g_decls_A_const_408 any

var A_arbace_j2g_decls_A_const_409 any

var A_arbace_j2g_decls_A_const_410 *lang.Var

var A_arbace_j2g_decls_A_const_411 any

var A_arbace_j2g_decls_A_const_412 any

var A_arbace_j2g_decls_A_const_413 any

var A_arbace_j2g_decls_A_const_414 any

var A_arbace_j2g_decls_A_const_415 any

var A_arbace_j2g_decls_A_const_416 any

var A_arbace_j2g_decls_A_const_417 any

var A_arbace_j2g_decls_A_const_418 any

var A_arbace_j2g_decls_A_const_419 any

var A_arbace_j2g_decls_A_const_420 any

var A_arbace_j2g_decls_A_const_421 any

var A_arbace_j2g_decls_A_const_422 any

var A_arbace_j2g_decls_A_const_423 any

var A_arbace_j2g_decls_A_const_424 any

var A_arbace_j2g_decls_A_const_425 any

var A_arbace_j2g_decls_A_const_426 any

var A_arbace_j2g_decls_A_const_427 any

var A_arbace_j2g_decls_A_const_428 any

var A_arbace_j2g_decls_A_const_429 any

var A_arbace_j2g_decls_A_const_430 any

var A_arbace_j2g_decls_A_const_431 any

var A_arbace_j2g_decls_A_const_432 any

var A_arbace_j2g_decls_A_const_433 any

var A_arbace_j2g_decls_A_const_434 any

var A_arbace_j2g_decls_A_const_435 any

var A_arbace_j2g_decls_A_const_436 any

var A_arbace_j2g_decls_A_const_437 any

var A_arbace_j2g_decls_A_const_438 any

var A_arbace_j2g_decls_A_const_439 any

var A_arbace_j2g_decls_A_const_440 any

var A_arbace_j2g_decls_A_const_441 any

var A_arbace_j2g_decls_A_const_442 any

var A_arbace_j2g_decls_A_const_443 any

var A_arbace_j2g_decls_A_const_444 any

var A_arbace_j2g_decls_A_const_445 *lang.Var

var A_arbace_j2g_decls_A_const_446 any

var A_arbace_j2g_decls_A_const_447 any

var A_arbace_j2g_decls_A_const_448 any

var A_arbace_j2g_decls_A_const_449 any

var A_arbace_j2g_decls_A_const_450 any

var A_arbace_j2g_decls_A_const_451 *lang.Var

var A_arbace_j2g_decls_A_const_452 *lang.Var

var A_arbace_j2g_decls_A_const_453 *lang.Var

var A_arbace_j2g_decls_A_const_454 *lang.Var

var A_arbace_j2g_decls_A_const_455 *lang.Var

var A_arbace_j2g_decls_A_const_456 *lang.Var

var A_arbace_j2g_decls_A_const_457 *lang.Var

var A_arbace_j2g_decls_A_const_458 *lang.Var

var A_arbace_j2g_decls_A_const_459 *lang.Var

var A_arbace_j2g_decls_A_const_460 *lang.Var

var A_arbace_j2g_decls_A_const_461 any

var A_arbace_j2g_decls_A_const_462 *lang.Var

var A_arbace_j2g_decls_A_const_463 any

var A_arbace_j2g_decls_A_const_464 any

var A_arbace_j2g_decls_A_const_465 any

var A_arbace_j2g_decls_A_const_466 *lang.Keyword

var A_arbace_j2g_decls_A_const_467 any

var A_arbace_j2g_decls_A_const_468 any

var A_arbace_j2g_decls_A_const_469 any

var A_arbace_j2g_decls_A_const_470 *lang.Var

var A_arbace_j2g_decls_A_const_471 any

var A_arbace_j2g_decls_A_const_472 any

var A_arbace_j2g_decls_A_const_473 *lang.Var

var A_arbace_j2g_decls_A_const_474 *lang.Var

var A_arbace_j2g_decls_A_const_475 *lang.Var

var A_arbace_j2g_decls_A_const_476 *lang.Var

var A_arbace_j2g_decls_A_const_477 any

var A_arbace_j2g_decls_A_const_478 *lang.Var

var A_arbace_j2g_decls_A_const_479 *lang.Var

var A_arbace_j2g_decls_A_const_480 *lang.Var

var A_arbace_j2g_decls_A_const_481 *lang.Var

var A_arbace_j2g_decls_A_const_482 *lang.Var

var A_arbace_j2g_decls_A_const_483 *lang.Keyword

var A_arbace_j2g_decls_A_const_484 *lang.Keyword

var A_arbace_j2g_decls_A_const_485 *lang.Var

var A_arbace_j2g_decls_A_const_486 *lang.Var

var A_arbace_j2g_decls_A_const_487 any

var A_arbace_j2g_decls_A_const_488 any

var A_arbace_j2g_decls_A_const_489 *lang.Keyword

var A_arbace_j2g_decls_A_const_490 any

var A_arbace_j2g_decls_A_const_491 *lang.Keyword

var A_arbace_j2g_decls_A_const_492 *lang.Keyword

var A_arbace_j2g_decls_A_const_493 *lang.Keyword

var A_arbace_j2g_decls_A_const_494 *lang.Keyword

var A_arbace_j2g_decls_A_const_495 *lang.Var

var A_arbace_j2g_decls_A_const_496 any

var A_arbace_j2g_decls_A_const_497 any

var A_arbace_j2g_decls_A_const_498 any

var A_arbace_j2g_decls_A_const_499 any

var A_arbace_j2g_decls_A_const_500 any

var A_arbace_j2g_decls_A_const_501 any

var A_arbace_j2g_decls_A_const_502 any

var A_arbace_j2g_decls_A_const_503 any

var A_arbace_j2g_decls_A_const_504 any

var A_arbace_j2g_decls_A_const_505 any

var A_arbace_j2g_decls_A_const_506 any

var A_arbace_j2g_decls_A_const_507 any

var A_arbace_j2g_decls_A_const_508 any

var A_arbace_j2g_decls_A_const_509 any

var A_arbace_j2g_decls_A_const_510 any

var A_arbace_j2g_decls_A_const_511 any

var A_arbace_j2g_decls_A_const_512 any

var A_arbace_j2g_decls_A_const_513 any

var A_arbace_j2g_decls_A_const_514 any

var A_arbace_j2g_decls_A_const_515 any

var A_arbace_j2g_decls_A_const_516 any

var A_arbace_j2g_decls_A_const_517 any

var A_arbace_j2g_decls_A_const_518 any

var A_arbace_j2g_decls_A_const_519 any

var A_arbace_j2g_decls_A_const_520 any

var A_arbace_j2g_decls_A_const_521 any

var A_arbace_j2g_decls_A_const_522 *lang.Var

var A_arbace_j2g_decls_A_const_523 any

var A_arbace_j2g_decls_A_const_524 any

var A_arbace_j2g_decls_A_const_525 any

var A_arbace_j2g_decls_A_const_526 any

var A_arbace_j2g_decls_A_const_527 any

var A_arbace_j2g_decls_A_const_528 any

var A_arbace_j2g_decls_A_const_529 any

var A_arbace_j2g_decls_A_const_530 any

var A_arbace_j2g_decls_A_const_531 any

var A_arbace_j2g_decls_A_const_532 any

var A_arbace_j2g_decls_A_const_533 any

var A_arbace_j2g_decls_A_const_534 any

var A_arbace_j2g_decls_A_const_535 any

var A_arbace_j2g_decls_A_const_536 any

var A_arbace_j2g_decls_A_const_537 any

var A_arbace_j2g_decls_A_const_538 any

var A_arbace_j2g_decls_A_const_539 any

var A_arbace_j2g_decls_A_const_540 any

var A_arbace_j2g_decls_A_const_541 any

var A_arbace_j2g_decls_A_const_542 any

var A_arbace_j2g_decls_A_const_543 any

var A_arbace_j2g_decls_A_const_544 any

var A_arbace_j2g_decls_A_const_545 any

var A_arbace_j2g_decls_A_const_546 any

var A_arbace_j2g_decls_A_const_547 any

var A_arbace_j2g_decls_A_const_548 any

var A_arbace_j2g_decls_A_const_549 any

var A_arbace_j2g_decls_A_const_550 any

var A_arbace_j2g_decls_A_const_551 any

var A_arbace_j2g_decls_A_const_552 any

var A_arbace_j2g_decls_A_const_553 any

var A_arbace_j2g_decls_A_const_554 any

var A_arbace_j2g_decls_A_const_555 any

var A_arbace_j2g_decls_A_const_556 any

var A_arbace_j2g_decls_A_const_557 any

var A_arbace_j2g_decls_A_const_558 any

var A_arbace_j2g_decls_A_const_559 any

var A_arbace_j2g_decls_A_const_560 any

var A_arbace_j2g_decls_A_const_561 any

var A_arbace_j2g_decls_A_const_562 any

var A_arbace_j2g_decls_A_const_563 any

var A_arbace_j2g_decls_A_const_564 any

var A_arbace_j2g_decls_A_const_565 any

var A_arbace_j2g_decls_A_const_566 any

var A_arbace_j2g_decls_A_const_567 any

var A_arbace_j2g_decls_A_const_568 any

var A_arbace_j2g_decls_A_const_569 any

var A_arbace_j2g_decls_A_const_570 any

var A_arbace_j2g_decls_A_const_571 any

var A_arbace_j2g_decls_A_const_572 any

var A_arbace_j2g_decls_A_const_573 any

var A_arbace_j2g_decls_A_const_574 any

var A_arbace_j2g_decls_A_const_575 any

var A_arbace_j2g_decls_A_const_576 any

var A_arbace_j2g_decls_A_const_577 any

var A_arbace_j2g_decls_A_const_578 any

var A_arbace_j2g_decls_A_const_579 any

var A_arbace_j2g_decls_A_const_580 any

var A_arbace_j2g_decls_A_const_581 any

var A_arbace_j2g_decls_A_const_582 any

var A_arbace_j2g_decls_A_const_583 any

var A_arbace_j2g_decls_A_const_584 any

var A_arbace_j2g_decls_A_const_585 any

var A_arbace_j2g_decls_A_const_586 any

var A_arbace_j2g_decls_A_const_587 any

var A_arbace_j2g_decls_A_const_588 any

var A_arbace_j2g_decls_A_const_589 any

var A_arbace_j2g_decls_A_const_590 any

var A_arbace_j2g_decls_A_const_591 any

var A_arbace_j2g_decls_A_const_592 any

var A_arbace_j2g_decls_A_const_593 any

var A_arbace_j2g_decls_A_const_594 any

var A_arbace_j2g_decls_A_const_595 any

var A_arbace_j2g_decls_A_const_596 any

var A_arbace_j2g_decls_A_const_597 any

var A_arbace_j2g_decls_A_const_598 any

var A_arbace_j2g_decls_A_const_599 any

var A_arbace_j2g_decls_A_const_600 any

var A_arbace_j2g_decls_A_const_601 any

var A_arbace_j2g_decls_A_const_602 any

var A_arbace_j2g_decls_A_const_603 any

var A_arbace_j2g_decls_A_const_604 any

var A_arbace_j2g_decls_A_const_605 any

var A_arbace_j2g_decls_A_const_606 any

var A_arbace_j2g_decls_A_const_607 any

var A_arbace_j2g_decls_A_const_608 *lang.Var

var A_arbace_j2g_decls_A_const_609 *lang.Var

var A_arbace_j2g_decls_A_const_610 *lang.Var

var A_arbace_j2g_decls_A_const_611 any

var A_arbace_j2g_decls_A_const_612 any

var A_arbace_j2g_decls_A_const_613 *lang.Var

var A_arbace_j2g_decls_A_const_614 any

var A_arbace_j2g_decls_A_const_615 any

var A_arbace_j2g_decls_A_const_616 any

var A_arbace_j2g_decls_A_const_617 *lang.Var

var A_arbace_j2g_decls_A_const_618 *lang.Var

var A_arbace_j2g_decls_A_const_619 *lang.Var

var A_arbace_j2g_decls_A_const_620 *lang.Var

var A_arbace_j2g_decls_A_const_621 *lang.Var

var A_arbace_j2g_decls_A_const_622 any

var A_arbace_j2g_decls_A_const_623 any

var A_arbace_j2g_decls_A_const_624 any

var A_arbace_j2g_decls_A_const_625 *lang.Var

var A_arbace_j2g_decls_A_const_626 any

var A_arbace_j2g_decls_A_const_627 any

var A_arbace_j2g_decls_A_const_628 any

var A_arbace_j2g_decls_A_const_629 any

var A_arbace_j2g_decls_A_const_630 any

var A_arbace_j2g_decls_A_const_631 *lang.Var

var A_arbace_j2g_decls_A_const_632 any

var A_arbace_j2g_decls_A_const_633 any

var A_arbace_j2g_decls_A_const_634 *lang.Var

var A_arbace_j2g_decls_A_const_635 any

var A_arbace_j2g_decls_A_const_636 any

var A_arbace_j2g_decls_A_const_637 *lang.Var

var A_arbace_j2g_decls_A_const_638 *lang.Var

var A_arbace_j2g_decls_A_const_639 any

var A_arbace_j2g_decls_A_const_640 any

var A_arbace_j2g_decls_A_const_641 any

var A_arbace_j2g_decls_A_const_642 any

var A_arbace_j2g_decls_A_const_643 any

var A_arbace_j2g_decls_A_const_644 any

var A_arbace_j2g_decls_A_const_645 *lang.Var

var A_arbace_j2g_decls_A_const_646 *lang.Var

var A_arbace_j2g_decls_A_const_647 *lang.Var

var A_arbace_j2g_decls_A_const_648 *lang.Var

var A_arbace_j2g_decls_A_const_649 *lang.Var

var A_arbace_j2g_decls_A_init jrt.ClassInit

func A_arbace_j2g_decls_A_Init() { if !A_arbace_j2g_decls_A_init.Done() { A_arbace_j2g_decls_A_init.Run(A_arbace_j2g_decls_A_clinit) } }

func A_arbace_j2g_decls_A_clinit() { A_arbace_j2g_decls_A_clinit_p0(); A_arbace_j2g_decls_A_clinit_p1(); A_arbace_j2g_decls_A_clinit_p2(); A_arbace_j2g_decls_A_clinit_p3(); A_arbace_j2g_decls_A_clinit_p4(); A_arbace_j2g_decls_A_clinit_p5(); A_arbace_j2g_decls_A_clinit_p6(); A_arbace_j2g_decls_A_clinit_p7(); A_arbace_j2g_decls_A_clinit_p8(); A_arbace_j2g_decls_A_clinit_p9(); A_arbace_j2g_decls_A_clinit_p10(); A_arbace_j2g_decls_A_clinit_p11(); A_arbace_j2g_decls_A_clinit_p12(); A_arbace_j2g_decls_A_clinit_p13(); A_arbace_j2g_decls_A_clinit_p14(); A_arbace_j2g_decls_A_clinit_p15(); A_arbace_j2g_decls_A_clinit_p16(); A_arbace_j2g_decls_A_clinit_p17(); A_arbace_j2g_decls_A_clinit_p18(); A_arbace_j2g_decls_A_clinit_p19(); A_arbace_j2g_decls_A_clinit_p20(); A_arbace_j2g_decls_A_clinit_p21(); A_arbace_j2g_decls_A_clinit_p22(); A_arbace_j2g_decls_A_clinit_p23(); A_arbace_j2g_decls_A_clinit_p24(); A_arbace_j2g_decls_A_clinit_p25(); A_arbace_j2g_decls_A_clinit_p26(); A_arbace_j2g_decls_A_clinit_p27(); A_arbace_j2g_decls_A_clinit_p28(); A_arbace_j2g_decls_A_clinit_p29(); A_arbace_j2g_decls_A_clinit_p30(); A_arbace_j2g_decls_A_clinit_p31(); A_arbace_j2g_decls_A_clinit_p32(); A_arbace_j2g_decls_A_clinit_p33(); A_arbace_j2g_decls_A_clinit_p34(); A_arbace_j2g_decls_A_clinit_p35(); A_arbace_j2g_decls_A_clinit_p36(); A_arbace_j2g_decls_A_clinit_p37(); A_arbace_j2g_decls_A_clinit_p38(); A_arbace_j2g_decls_A_clinit_p39(); A_arbace_j2g_decls_A_clinit_p40(); A_arbace_j2g_decls_A_clinit_p41(); A_arbace_j2g_decls_A_clinit_p42(); A_arbace_j2g_decls_A_clinit_p43(); A_arbace_j2g_decls_A_clinit_p44(); A_arbace_j2g_decls_A_clinit_p45(); A_arbace_j2g_decls_A_clinit_p46(); A_arbace_j2g_decls_A_clinit_p47() }

func A_arbace_j2g_decls_A_clinit_p0() { A_arbace_j2g_decls_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 846); A_arbace_j2g_decls_A_const_0 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[196]); A_arbace_j2g_decls_A_const_1 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[197]); A_arbace_j2g_decls_A_const_2 = A_arbace_j2g_decls_A_const_pool.A[198]; A_arbace_j2g_decls_A_const_3 = A_arbace_j2g_decls_A_const_pool.A[199]; A_arbace_j2g_decls_A_const_4 = A_arbace_j2g_decls_A_const_pool.A[200]; A_arbace_j2g_decls_A_const_5 = A_arbace_j2g_decls_A_const_pool.A[201]; A_arbace_j2g_decls_A_const_6 = A_arbace_j2g_decls_A_const_pool.A[202]; A_arbace_j2g_decls_A_const_7 = A_arbace_j2g_decls_A_const_pool.A[203]; A_arbace_j2g_decls_A_const_8 = A_arbace_j2g_decls_A_const_pool.A[204]; A_arbace_j2g_decls_A_const_9 = A_arbace_j2g_decls_A_const_pool.A[205]; A_arbace_j2g_decls_A_const_10 = A_arbace_j2g_decls_A_const_pool.A[206]; A_arbace_j2g_decls_A_const_11 = A_arbace_j2g_decls_A_const_pool.A[207]; A_arbace_j2g_decls_A_const_12 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[208]); A_arbace_j2g_decls_A_const_13 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[209]) }

func A_arbace_j2g_decls_A_clinit_p1() { A_arbace_j2g_decls_A_const_14 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[210]); A_arbace_j2g_decls_A_const_15 = A_arbace_j2g_decls_A_const_pool.A[211]; A_arbace_j2g_decls_A_const_16 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[212]); A_arbace_j2g_decls_A_const_17 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[213]); A_arbace_j2g_decls_A_const_18 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[214]); A_arbace_j2g_decls_A_const_19 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[215]); A_arbace_j2g_decls_A_const_20 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[216]); A_arbace_j2g_decls_A_const_21 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[217]); A_arbace_j2g_decls_A_const_22 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[218]); A_arbace_j2g_decls_A_const_23 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[219]); A_arbace_j2g_decls_A_const_24 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[220]); A_arbace_j2g_decls_A_const_25 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[221]) }

func A_arbace_j2g_decls_A_clinit_p2() { A_arbace_j2g_decls_A_const_26 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[222]); A_arbace_j2g_decls_A_const_27 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[223]); A_arbace_j2g_decls_A_const_28 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[224]); A_arbace_j2g_decls_A_const_29 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[225]); A_arbace_j2g_decls_A_const_30 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[226]); A_arbace_j2g_decls_A_const_31 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[227]); A_arbace_j2g_decls_A_const_32 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[228]); A_arbace_j2g_decls_A_const_33 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[229]); A_arbace_j2g_decls_A_const_34 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[230]); A_arbace_j2g_decls_A_const_35 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[231]); A_arbace_j2g_decls_A_const_36 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[232]); A_arbace_j2g_decls_A_const_37 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[233]) }

func A_arbace_j2g_decls_A_clinit_p3() { A_arbace_j2g_decls_A_const_38 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[234]); A_arbace_j2g_decls_A_const_39 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[235]); A_arbace_j2g_decls_A_const_40 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[236]); A_arbace_j2g_decls_A_const_41 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[237]); A_arbace_j2g_decls_A_const_42 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[238]); A_arbace_j2g_decls_A_const_43 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[239]); A_arbace_j2g_decls_A_const_44 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[240]); A_arbace_j2g_decls_A_const_45 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[241]); A_arbace_j2g_decls_A_const_46 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[242]); A_arbace_j2g_decls_A_const_47 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[243]); A_arbace_j2g_decls_A_const_48 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[244]); A_arbace_j2g_decls_A_const_49 = A_arbace_j2g_decls_A_const_pool.A[245] }

func A_arbace_j2g_decls_A_clinit_p4() { A_arbace_j2g_decls_A_const_50 = A_arbace_j2g_decls_A_const_pool.A[246]; A_arbace_j2g_decls_A_const_51 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[247]); A_arbace_j2g_decls_A_const_52 = A_arbace_j2g_decls_A_const_pool.A[248]; A_arbace_j2g_decls_A_const_53 = A_arbace_j2g_decls_A_const_pool.A[249]; A_arbace_j2g_decls_A_const_54 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[250]); A_arbace_j2g_decls_A_const_55 = A_arbace_j2g_decls_A_const_pool.A[251]; A_arbace_j2g_decls_A_const_56 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[252]); A_arbace_j2g_decls_A_const_57 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[253]); A_arbace_j2g_decls_A_const_58 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[254]); A_arbace_j2g_decls_A_const_59 = A_arbace_j2g_decls_A_const_pool.A[255]; A_arbace_j2g_decls_A_const_60 = A_arbace_j2g_decls_A_const_pool.A[256]; A_arbace_j2g_decls_A_const_61 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[257]); A_arbace_j2g_decls_A_const_62 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[258]) }

func A_arbace_j2g_decls_A_clinit_p5() { A_arbace_j2g_decls_A_const_63 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[259]); A_arbace_j2g_decls_A_const_64 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[260]); A_arbace_j2g_decls_A_const_65 = A_arbace_j2g_decls_A_const_pool.A[261]; A_arbace_j2g_decls_A_const_66 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[262]); A_arbace_j2g_decls_A_const_67 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[263]); A_arbace_j2g_decls_A_const_68 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[264]); A_arbace_j2g_decls_A_const_69 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[265]); A_arbace_j2g_decls_A_const_70 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[266]); A_arbace_j2g_decls_A_const_71 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[267]); A_arbace_j2g_decls_A_const_72 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[268]); A_arbace_j2g_decls_A_const_73 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[269]); A_arbace_j2g_decls_A_const_74 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[270]) }

func A_arbace_j2g_decls_A_clinit_p6() { A_arbace_j2g_decls_A_const_75 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[271]); A_arbace_j2g_decls_A_const_76 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[272]); A_arbace_j2g_decls_A_const_77 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[273]); A_arbace_j2g_decls_A_const_78 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[274]); A_arbace_j2g_decls_A_const_79 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[275]); A_arbace_j2g_decls_A_const_80 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[276]); A_arbace_j2g_decls_A_const_81 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[277]); A_arbace_j2g_decls_A_const_82 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[278]); A_arbace_j2g_decls_A_const_83 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[279]); A_arbace_j2g_decls_A_const_84 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[280]); A_arbace_j2g_decls_A_const_85 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[281]); A_arbace_j2g_decls_A_const_86 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[282]) }

func A_arbace_j2g_decls_A_clinit_p7() { A_arbace_j2g_decls_A_const_87 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[283]); A_arbace_j2g_decls_A_const_88 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[284]); A_arbace_j2g_decls_A_const_89 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[285]); A_arbace_j2g_decls_A_const_90 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[286]); A_arbace_j2g_decls_A_const_91 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[287]); A_arbace_j2g_decls_A_const_92 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[288]); A_arbace_j2g_decls_A_const_93 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[289]); A_arbace_j2g_decls_A_const_94 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[290]); A_arbace_j2g_decls_A_const_95 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[291]); A_arbace_j2g_decls_A_const_96 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[292]); A_arbace_j2g_decls_A_const_97 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[293]); A_arbace_j2g_decls_A_const_98 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[294]) }

func A_arbace_j2g_decls_A_clinit_p8() { A_arbace_j2g_decls_A_const_99 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[295]); A_arbace_j2g_decls_A_const_100 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[296]); A_arbace_j2g_decls_A_const_101 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[297]); A_arbace_j2g_decls_A_const_102 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[298]); A_arbace_j2g_decls_A_const_103 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[299]); A_arbace_j2g_decls_A_const_104 = A_arbace_j2g_decls_A_const_pool.A[300]; A_arbace_j2g_decls_A_const_105 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[301]); A_arbace_j2g_decls_A_const_106 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[302]); A_arbace_j2g_decls_A_const_107 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[303]); A_arbace_j2g_decls_A_const_108 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[304]); A_arbace_j2g_decls_A_const_109 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[305]); A_arbace_j2g_decls_A_const_110 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[306]) }

func A_arbace_j2g_decls_A_clinit_p9() { A_arbace_j2g_decls_A_const_111 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[307]); A_arbace_j2g_decls_A_const_112 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[308]); A_arbace_j2g_decls_A_const_113 = A_arbace_j2g_decls_A_const_pool.A[309]; A_arbace_j2g_decls_A_const_114 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[310]); A_arbace_j2g_decls_A_const_115 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[311]); A_arbace_j2g_decls_A_const_116 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[312]); A_arbace_j2g_decls_A_const_117 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[313]); A_arbace_j2g_decls_A_const_118 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[314]); A_arbace_j2g_decls_A_const_119 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[315]); A_arbace_j2g_decls_A_const_120 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[316]); A_arbace_j2g_decls_A_const_121 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[317]); A_arbace_j2g_decls_A_const_122 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[318]) }

func A_arbace_j2g_decls_A_clinit_p10() { A_arbace_j2g_decls_A_const_123 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[319]); A_arbace_j2g_decls_A_const_124 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[320]); A_arbace_j2g_decls_A_const_125 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[321]); A_arbace_j2g_decls_A_const_126 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[322]); A_arbace_j2g_decls_A_const_127 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[323]); A_arbace_j2g_decls_A_const_128 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[324]); A_arbace_j2g_decls_A_const_129 = A_arbace_j2g_decls_A_const_pool.A[325]; A_arbace_j2g_decls_A_const_130 = A_arbace_j2g_decls_A_const_pool.A[326]; A_arbace_j2g_decls_A_const_131 = A_arbace_j2g_decls_A_const_pool.A[327]; A_arbace_j2g_decls_A_const_132 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[328]); A_arbace_j2g_decls_A_const_133 = A_arbace_j2g_decls_A_const_pool.A[329]; A_arbace_j2g_decls_A_const_134 = A_arbace_j2g_decls_A_const_pool.A[330]; A_arbace_j2g_decls_A_const_135 = A_arbace_j2g_decls_A_const_pool.A[331] }

func A_arbace_j2g_decls_A_clinit_p11() { A_arbace_j2g_decls_A_const_136 = A_arbace_j2g_decls_A_const_pool.A[332]; A_arbace_j2g_decls_A_const_137 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[333]); A_arbace_j2g_decls_A_const_138 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[334]); A_arbace_j2g_decls_A_const_139 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[335]); A_arbace_j2g_decls_A_const_140 = A_arbace_j2g_decls_A_const_pool.A[336]; A_arbace_j2g_decls_A_const_141 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[337]); A_arbace_j2g_decls_A_const_142 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[338]); A_arbace_j2g_decls_A_const_143 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[339]); A_arbace_j2g_decls_A_const_144 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[340]); A_arbace_j2g_decls_A_const_145 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[341]); A_arbace_j2g_decls_A_const_146 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[342]); A_arbace_j2g_decls_A_const_147 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[343]) }

func A_arbace_j2g_decls_A_clinit_p12() { A_arbace_j2g_decls_A_const_148 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[344]); A_arbace_j2g_decls_A_const_149 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[345]); A_arbace_j2g_decls_A_const_150 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[346]); A_arbace_j2g_decls_A_const_151 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[347]); A_arbace_j2g_decls_A_const_152 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[348]); A_arbace_j2g_decls_A_const_153 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[349]); A_arbace_j2g_decls_A_const_154 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[350]); A_arbace_j2g_decls_A_const_155 = A_arbace_j2g_decls_A_const_pool.A[351]; A_arbace_j2g_decls_A_const_156 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[352]); A_arbace_j2g_decls_A_const_157 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[353]); A_arbace_j2g_decls_A_const_158 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[354]); A_arbace_j2g_decls_A_const_159 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[355]) }

func A_arbace_j2g_decls_A_clinit_p13() { A_arbace_j2g_decls_A_const_160 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[356]); A_arbace_j2g_decls_A_const_161 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[357]); A_arbace_j2g_decls_A_const_162 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[358]); A_arbace_j2g_decls_A_const_163 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[359]); A_arbace_j2g_decls_A_const_164 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[360]); A_arbace_j2g_decls_A_const_165 = A_arbace_j2g_decls_A_const_pool.A[361]; A_arbace_j2g_decls_A_const_166 = A_arbace_j2g_decls_A_const_pool.A[362]; A_arbace_j2g_decls_A_const_167 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[363]); A_arbace_j2g_decls_A_const_168 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[364]); A_arbace_j2g_decls_A_const_169 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[365]); A_arbace_j2g_decls_A_const_170 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[366]); A_arbace_j2g_decls_A_const_171 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[367]) }

func A_arbace_j2g_decls_A_clinit_p14() { A_arbace_j2g_decls_A_const_172 = A_arbace_j2g_decls_A_const_pool.A[368]; A_arbace_j2g_decls_A_const_173 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[369]); A_arbace_j2g_decls_A_const_174 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[370]); A_arbace_j2g_decls_A_const_175 = A_arbace_j2g_decls_A_const_pool.A[371]; A_arbace_j2g_decls_A_const_176 = A_arbace_j2g_decls_A_const_pool.A[372]; A_arbace_j2g_decls_A_const_177 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[373]); A_arbace_j2g_decls_A_const_178 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[374]); A_arbace_j2g_decls_A_const_179 = A_arbace_j2g_decls_A_const_pool.A[375]; A_arbace_j2g_decls_A_const_180 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[376]); A_arbace_j2g_decls_A_const_181 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[377]); A_arbace_j2g_decls_A_const_182 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[378]); A_arbace_j2g_decls_A_const_183 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[379]); A_arbace_j2g_decls_A_const_184 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[380]) }

func A_arbace_j2g_decls_A_clinit_p15() { A_arbace_j2g_decls_A_const_185 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[381]); A_arbace_j2g_decls_A_const_186 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[382]); A_arbace_j2g_decls_A_const_187 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[383]); A_arbace_j2g_decls_A_const_188 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[384]); A_arbace_j2g_decls_A_const_189 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[385]); A_arbace_j2g_decls_A_const_190 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[386]); A_arbace_j2g_decls_A_const_191 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[387]); A_arbace_j2g_decls_A_const_192 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[388]); A_arbace_j2g_decls_A_const_193 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[389]); A_arbace_j2g_decls_A_const_194 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[390]); A_arbace_j2g_decls_A_const_195 = A_arbace_j2g_decls_A_const_pool.A[391]; A_arbace_j2g_decls_A_const_196 = A_arbace_j2g_decls_A_const_pool.A[392] }

func A_arbace_j2g_decls_A_clinit_p16() { A_arbace_j2g_decls_A_const_197 = A_arbace_j2g_decls_A_const_pool.A[393]; A_arbace_j2g_decls_A_const_198 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[394]); A_arbace_j2g_decls_A_const_199 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[395]); A_arbace_j2g_decls_A_const_200 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[396]); A_arbace_j2g_decls_A_const_201 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[397]); A_arbace_j2g_decls_A_const_202 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[398]); A_arbace_j2g_decls_A_const_203 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[399]); A_arbace_j2g_decls_A_const_204 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[400]); A_arbace_j2g_decls_A_const_205 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[401]); A_arbace_j2g_decls_A_const_206 = A_arbace_j2g_decls_A_const_pool.A[402]; A_arbace_j2g_decls_A_const_207 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[403]); A_arbace_j2g_decls_A_const_208 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[404]) }

func A_arbace_j2g_decls_A_clinit_p17() { A_arbace_j2g_decls_A_const_209 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[405]); A_arbace_j2g_decls_A_const_210 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[406]); A_arbace_j2g_decls_A_const_211 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[407]); A_arbace_j2g_decls_A_const_212 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[408]); A_arbace_j2g_decls_A_const_213 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[409]); A_arbace_j2g_decls_A_const_214 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[410]); A_arbace_j2g_decls_A_const_215 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[411]); A_arbace_j2g_decls_A_const_216 = A_arbace_j2g_decls_A_const_pool.A[412]; A_arbace_j2g_decls_A_const_217 = A_arbace_j2g_decls_A_const_pool.A[413]; A_arbace_j2g_decls_A_const_218 = A_arbace_j2g_decls_A_const_pool.A[414]; A_arbace_j2g_decls_A_const_219 = A_arbace_j2g_decls_A_const_pool.A[415]; A_arbace_j2g_decls_A_const_220 = A_arbace_j2g_decls_A_const_pool.A[416]; A_arbace_j2g_decls_A_const_221 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[417]) }

func A_arbace_j2g_decls_A_clinit_p18() { A_arbace_j2g_decls_A_const_222 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[418]); A_arbace_j2g_decls_A_const_223 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[419]); A_arbace_j2g_decls_A_const_224 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[420]); A_arbace_j2g_decls_A_const_225 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[421]); A_arbace_j2g_decls_A_const_226 = A_arbace_j2g_decls_A_const_pool.A[422]; A_arbace_j2g_decls_A_const_227 = A_arbace_j2g_decls_A_const_pool.A[423]; A_arbace_j2g_decls_A_const_228 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[424]); A_arbace_j2g_decls_A_const_229 = A_arbace_j2g_decls_A_const_pool.A[425]; A_arbace_j2g_decls_A_const_230 = A_arbace_j2g_decls_A_const_pool.A[426]; A_arbace_j2g_decls_A_const_231 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[427]); A_arbace_j2g_decls_A_const_232 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[428]); A_arbace_j2g_decls_A_const_233 = A_arbace_j2g_decls_A_const_pool.A[429]; A_arbace_j2g_decls_A_const_234 = A_arbace_j2g_decls_A_const_pool.A[430] }

func A_arbace_j2g_decls_A_clinit_p19() { A_arbace_j2g_decls_A_const_235 = A_arbace_j2g_decls_A_const_pool.A[431]; A_arbace_j2g_decls_A_const_236 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[432]); A_arbace_j2g_decls_A_const_237 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[433]); A_arbace_j2g_decls_A_const_238 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[434]); A_arbace_j2g_decls_A_const_239 = A_arbace_j2g_decls_A_const_pool.A[435]; A_arbace_j2g_decls_A_const_240 = A_arbace_j2g_decls_A_const_pool.A[436]; A_arbace_j2g_decls_A_const_241 = A_arbace_j2g_decls_A_const_pool.A[437]; A_arbace_j2g_decls_A_const_242 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[438]); A_arbace_j2g_decls_A_const_243 = A_arbace_j2g_decls_A_const_pool.A[439]; A_arbace_j2g_decls_A_const_244 = A_arbace_j2g_decls_A_const_pool.A[440]; A_arbace_j2g_decls_A_const_245 = A_arbace_j2g_decls_A_const_pool.A[441]; A_arbace_j2g_decls_A_const_246 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[442]); A_arbace_j2g_decls_A_const_247 = A_arbace_j2g_decls_A_const_pool.A[443]; A_arbace_j2g_decls_A_const_248 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[444]) }

func A_arbace_j2g_decls_A_clinit_p20() { A_arbace_j2g_decls_A_const_249 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[445]); A_arbace_j2g_decls_A_const_250 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[446]); A_arbace_j2g_decls_A_const_251 = A_arbace_j2g_decls_A_const_pool.A[447]; A_arbace_j2g_decls_A_const_252 = A_arbace_j2g_decls_A_const_pool.A[448]; A_arbace_j2g_decls_A_const_253 = A_arbace_j2g_decls_A_const_pool.A[449]; A_arbace_j2g_decls_A_const_254 = A_arbace_j2g_decls_A_const_pool.A[450]; A_arbace_j2g_decls_A_const_255 = A_arbace_j2g_decls_A_const_pool.A[451]; A_arbace_j2g_decls_A_const_256 = A_arbace_j2g_decls_A_const_pool.A[452]; A_arbace_j2g_decls_A_const_257 = A_arbace_j2g_decls_A_const_pool.A[453]; A_arbace_j2g_decls_A_const_258 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[454]); A_arbace_j2g_decls_A_const_259 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[455]); A_arbace_j2g_decls_A_const_260 = A_arbace_j2g_decls_A_const_pool.A[456]; A_arbace_j2g_decls_A_const_261 = A_arbace_j2g_decls_A_const_pool.A[457]; A_arbace_j2g_decls_A_const_262 = A_arbace_j2g_decls_A_const_pool.A[458] }

func A_arbace_j2g_decls_A_clinit_p21() { A_arbace_j2g_decls_A_const_263 = A_arbace_j2g_decls_A_const_pool.A[459]; A_arbace_j2g_decls_A_const_264 = A_arbace_j2g_decls_A_const_pool.A[460]; A_arbace_j2g_decls_A_const_265 = A_arbace_j2g_decls_A_const_pool.A[461]; A_arbace_j2g_decls_A_const_266 = A_arbace_j2g_decls_A_const_pool.A[462]; A_arbace_j2g_decls_A_const_267 = A_arbace_j2g_decls_A_const_pool.A[463]; A_arbace_j2g_decls_A_const_268 = A_arbace_j2g_decls_A_const_pool.A[464]; A_arbace_j2g_decls_A_const_269 = A_arbace_j2g_decls_A_const_pool.A[465]; A_arbace_j2g_decls_A_const_270 = A_arbace_j2g_decls_A_const_pool.A[466]; A_arbace_j2g_decls_A_const_271 = A_arbace_j2g_decls_A_const_pool.A[467]; A_arbace_j2g_decls_A_const_272 = A_arbace_j2g_decls_A_const_pool.A[468]; A_arbace_j2g_decls_A_const_273 = A_arbace_j2g_decls_A_const_pool.A[469]; A_arbace_j2g_decls_A_const_274 = A_arbace_j2g_decls_A_const_pool.A[470]; A_arbace_j2g_decls_A_const_275 = A_arbace_j2g_decls_A_const_pool.A[471]; A_arbace_j2g_decls_A_const_276 = A_arbace_j2g_decls_A_const_pool.A[472]; A_arbace_j2g_decls_A_const_277 = A_arbace_j2g_decls_A_const_pool.A[473]; A_arbace_j2g_decls_A_const_278 = A_arbace_j2g_decls_A_const_pool.A[474] }

func A_arbace_j2g_decls_A_clinit_p22() { A_arbace_j2g_decls_A_const_279 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[475]); A_arbace_j2g_decls_A_const_280 = A_arbace_j2g_decls_A_const_pool.A[476]; A_arbace_j2g_decls_A_const_281 = A_arbace_j2g_decls_A_const_pool.A[477]; A_arbace_j2g_decls_A_const_282 = A_arbace_j2g_decls_A_const_pool.A[478]; A_arbace_j2g_decls_A_const_283 = A_arbace_j2g_decls_A_const_pool.A[479]; A_arbace_j2g_decls_A_const_284 = A_arbace_j2g_decls_A_const_pool.A[480]; A_arbace_j2g_decls_A_const_285 = A_arbace_j2g_decls_A_const_pool.A[481]; A_arbace_j2g_decls_A_const_286 = A_arbace_j2g_decls_A_const_pool.A[482]; A_arbace_j2g_decls_A_const_287 = A_arbace_j2g_decls_A_const_pool.A[483]; A_arbace_j2g_decls_A_const_288 = A_arbace_j2g_decls_A_const_pool.A[484]; A_arbace_j2g_decls_A_const_289 = A_arbace_j2g_decls_A_const_pool.A[485]; A_arbace_j2g_decls_A_const_290 = A_arbace_j2g_decls_A_const_pool.A[486]; A_arbace_j2g_decls_A_const_291 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[487]); A_arbace_j2g_decls_A_const_292 = A_arbace_j2g_decls_A_const_pool.A[488]; A_arbace_j2g_decls_A_const_293 = A_arbace_j2g_decls_A_const_pool.A[489] }

func A_arbace_j2g_decls_A_clinit_p23() { A_arbace_j2g_decls_A_const_294 = A_arbace_j2g_decls_A_const_pool.A[490]; A_arbace_j2g_decls_A_const_295 = A_arbace_j2g_decls_A_const_pool.A[491]; A_arbace_j2g_decls_A_const_296 = A_arbace_j2g_decls_A_const_pool.A[492]; A_arbace_j2g_decls_A_const_297 = A_arbace_j2g_decls_A_const_pool.A[493]; A_arbace_j2g_decls_A_const_298 = A_arbace_j2g_decls_A_const_pool.A[494]; A_arbace_j2g_decls_A_const_299 = A_arbace_j2g_decls_A_const_pool.A[495]; A_arbace_j2g_decls_A_const_300 = A_arbace_j2g_decls_A_const_pool.A[496]; A_arbace_j2g_decls_A_const_301 = A_arbace_j2g_decls_A_const_pool.A[497]; A_arbace_j2g_decls_A_const_302 = A_arbace_j2g_decls_A_const_pool.A[498]; A_arbace_j2g_decls_A_const_303 = A_arbace_j2g_decls_A_const_pool.A[499]; A_arbace_j2g_decls_A_const_304 = A_arbace_j2g_decls_A_const_pool.A[500]; A_arbace_j2g_decls_A_const_305 = A_arbace_j2g_decls_A_const_pool.A[501]; A_arbace_j2g_decls_A_const_306 = A_arbace_j2g_decls_A_const_pool.A[502]; A_arbace_j2g_decls_A_const_307 = A_arbace_j2g_decls_A_const_pool.A[503]; A_arbace_j2g_decls_A_const_308 = A_arbace_j2g_decls_A_const_pool.A[504]; A_arbace_j2g_decls_A_const_309 = A_arbace_j2g_decls_A_const_pool.A[505] }

func A_arbace_j2g_decls_A_clinit_p24() { A_arbace_j2g_decls_A_const_310 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[506]); A_arbace_j2g_decls_A_const_311 = A_arbace_j2g_decls_A_const_pool.A[507]; A_arbace_j2g_decls_A_const_312 = A_arbace_j2g_decls_A_const_pool.A[508]; A_arbace_j2g_decls_A_const_313 = A_arbace_j2g_decls_A_const_pool.A[509]; A_arbace_j2g_decls_A_const_314 = A_arbace_j2g_decls_A_const_pool.A[510]; A_arbace_j2g_decls_A_const_315 = A_arbace_j2g_decls_A_const_pool.A[511]; A_arbace_j2g_decls_A_const_316 = A_arbace_j2g_decls_A_const_pool.A[512]; A_arbace_j2g_decls_A_const_317 = A_arbace_j2g_decls_A_const_pool.A[513]; A_arbace_j2g_decls_A_const_318 = A_arbace_j2g_decls_A_const_pool.A[514]; A_arbace_j2g_decls_A_const_319 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[515]); A_arbace_j2g_decls_A_const_320 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[516]); A_arbace_j2g_decls_A_const_321 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[517]); A_arbace_j2g_decls_A_const_322 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[518]); A_arbace_j2g_decls_A_const_323 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[519]) }

func A_arbace_j2g_decls_A_clinit_p25() { A_arbace_j2g_decls_A_const_324 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[520]); A_arbace_j2g_decls_A_const_325 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[521]); A_arbace_j2g_decls_A_const_326 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[522]); A_arbace_j2g_decls_A_const_327 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[523]); A_arbace_j2g_decls_A_const_328 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[524]); A_arbace_j2g_decls_A_const_329 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[525]); A_arbace_j2g_decls_A_const_330 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[526]); A_arbace_j2g_decls_A_const_331 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[527]); A_arbace_j2g_decls_A_const_332 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[528]); A_arbace_j2g_decls_A_const_333 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[529]); A_arbace_j2g_decls_A_const_334 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[530]); A_arbace_j2g_decls_A_const_335 = A_arbace_j2g_decls_A_const_pool.A[531] }

func A_arbace_j2g_decls_A_clinit_p26() { A_arbace_j2g_decls_A_const_336 = A_arbace_j2g_decls_A_const_pool.A[532]; A_arbace_j2g_decls_A_const_337 = A_arbace_j2g_decls_A_const_pool.A[533]; A_arbace_j2g_decls_A_const_338 = A_arbace_j2g_decls_A_const_pool.A[534]; A_arbace_j2g_decls_A_const_339 = A_arbace_j2g_decls_A_const_pool.A[535]; A_arbace_j2g_decls_A_const_340 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[536]); A_arbace_j2g_decls_A_const_341 = A_arbace_j2g_decls_A_const_pool.A[537]; A_arbace_j2g_decls_A_const_342 = A_arbace_j2g_decls_A_const_pool.A[538]; A_arbace_j2g_decls_A_const_343 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[539]); A_arbace_j2g_decls_A_const_344 = A_arbace_j2g_decls_A_const_pool.A[540]; A_arbace_j2g_decls_A_const_345 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[541]); A_arbace_j2g_decls_A_const_346 = A_arbace_j2g_decls_A_const_pool.A[542]; A_arbace_j2g_decls_A_const_347 = A_arbace_j2g_decls_A_const_pool.A[543]; A_arbace_j2g_decls_A_const_348 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[544]); A_arbace_j2g_decls_A_const_349 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[545]) }

func A_arbace_j2g_decls_A_clinit_p27() { A_arbace_j2g_decls_A_const_350 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[546]); A_arbace_j2g_decls_A_const_351 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[547]); A_arbace_j2g_decls_A_const_352 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[548]); A_arbace_j2g_decls_A_const_353 = A_arbace_j2g_decls_A_const_pool.A[549]; A_arbace_j2g_decls_A_const_354 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[550]); A_arbace_j2g_decls_A_const_355 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[551]); A_arbace_j2g_decls_A_const_356 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[552]); A_arbace_j2g_decls_A_const_357 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[553]); A_arbace_j2g_decls_A_const_358 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[554]); A_arbace_j2g_decls_A_const_359 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[555]); A_arbace_j2g_decls_A_const_360 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[556]); A_arbace_j2g_decls_A_const_361 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[557]) }

func A_arbace_j2g_decls_A_clinit_p28() { A_arbace_j2g_decls_A_const_362 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[558]); A_arbace_j2g_decls_A_const_363 = A_arbace_j2g_decls_A_const_pool.A[559]; A_arbace_j2g_decls_A_const_364 = A_arbace_j2g_decls_A_const_pool.A[560]; A_arbace_j2g_decls_A_const_365 = A_arbace_j2g_decls_A_const_pool.A[561]; A_arbace_j2g_decls_A_const_366 = A_arbace_j2g_decls_A_const_pool.A[562]; A_arbace_j2g_decls_A_const_367 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[563]); A_arbace_j2g_decls_A_const_368 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[564]); A_arbace_j2g_decls_A_const_369 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[565]); A_arbace_j2g_decls_A_const_370 = A_arbace_j2g_decls_A_const_pool.A[566]; A_arbace_j2g_decls_A_const_371 = A_arbace_j2g_decls_A_const_pool.A[567]; A_arbace_j2g_decls_A_const_372 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[568]); A_arbace_j2g_decls_A_const_373 = A_arbace_j2g_decls_A_const_pool.A[569]; A_arbace_j2g_decls_A_const_374 = A_arbace_j2g_decls_A_const_pool.A[570]; A_arbace_j2g_decls_A_const_375 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[571]) }

func A_arbace_j2g_decls_A_clinit_p29() { A_arbace_j2g_decls_A_const_376 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[572]); A_arbace_j2g_decls_A_const_377 = A_arbace_j2g_decls_A_const_pool.A[573]; A_arbace_j2g_decls_A_const_378 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[574]); A_arbace_j2g_decls_A_const_379 = A_arbace_j2g_decls_A_const_pool.A[575]; A_arbace_j2g_decls_A_const_380 = A_arbace_j2g_decls_A_const_pool.A[576]; A_arbace_j2g_decls_A_const_381 = A_arbace_j2g_decls_A_const_pool.A[577]; A_arbace_j2g_decls_A_const_382 = A_arbace_j2g_decls_A_const_pool.A[578]; A_arbace_j2g_decls_A_const_383 = A_arbace_j2g_decls_A_const_pool.A[579]; A_arbace_j2g_decls_A_const_384 = A_arbace_j2g_decls_A_const_pool.A[580]; A_arbace_j2g_decls_A_const_385 = A_arbace_j2g_decls_A_const_pool.A[581]; A_arbace_j2g_decls_A_const_386 = A_arbace_j2g_decls_A_const_pool.A[582]; A_arbace_j2g_decls_A_const_387 = A_arbace_j2g_decls_A_const_pool.A[583]; A_arbace_j2g_decls_A_const_388 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[584]); A_arbace_j2g_decls_A_const_389 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[585]) }

func A_arbace_j2g_decls_A_clinit_p30() { A_arbace_j2g_decls_A_const_390 = A_arbace_j2g_decls_A_const_pool.A[586]; A_arbace_j2g_decls_A_const_391 = A_arbace_j2g_decls_A_const_pool.A[587]; A_arbace_j2g_decls_A_const_392 = A_arbace_j2g_decls_A_const_pool.A[588]; A_arbace_j2g_decls_A_const_393 = A_arbace_j2g_decls_A_const_pool.A[589]; A_arbace_j2g_decls_A_const_394 = A_arbace_j2g_decls_A_const_pool.A[590]; A_arbace_j2g_decls_A_const_395 = A_arbace_j2g_decls_A_const_pool.A[591]; A_arbace_j2g_decls_A_const_396 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[592]); A_arbace_j2g_decls_A_const_397 = A_arbace_j2g_decls_A_const_pool.A[593]; A_arbace_j2g_decls_A_const_398 = A_arbace_j2g_decls_A_const_pool.A[594]; A_arbace_j2g_decls_A_const_399 = A_arbace_j2g_decls_A_const_pool.A[595]; A_arbace_j2g_decls_A_const_400 = A_arbace_j2g_decls_A_const_pool.A[596]; A_arbace_j2g_decls_A_const_401 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[597]); A_arbace_j2g_decls_A_const_402 = A_arbace_j2g_decls_A_const_pool.A[598]; A_arbace_j2g_decls_A_const_403 = A_arbace_j2g_decls_A_const_pool.A[599]; A_arbace_j2g_decls_A_const_404 = A_arbace_j2g_decls_A_const_pool.A[600] }

func A_arbace_j2g_decls_A_clinit_p31() { A_arbace_j2g_decls_A_const_405 = A_arbace_j2g_decls_A_const_pool.A[601]; A_arbace_j2g_decls_A_const_406 = A_arbace_j2g_decls_A_const_pool.A[602]; A_arbace_j2g_decls_A_const_407 = A_arbace_j2g_decls_A_const_pool.A[603]; A_arbace_j2g_decls_A_const_408 = A_arbace_j2g_decls_A_const_pool.A[604]; A_arbace_j2g_decls_A_const_409 = A_arbace_j2g_decls_A_const_pool.A[605]; A_arbace_j2g_decls_A_const_410 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[606]); A_arbace_j2g_decls_A_const_411 = A_arbace_j2g_decls_A_const_pool.A[607]; A_arbace_j2g_decls_A_const_412 = A_arbace_j2g_decls_A_const_pool.A[608]; A_arbace_j2g_decls_A_const_413 = A_arbace_j2g_decls_A_const_pool.A[609]; A_arbace_j2g_decls_A_const_414 = A_arbace_j2g_decls_A_const_pool.A[610]; A_arbace_j2g_decls_A_const_415 = A_arbace_j2g_decls_A_const_pool.A[611]; A_arbace_j2g_decls_A_const_416 = A_arbace_j2g_decls_A_const_pool.A[612]; A_arbace_j2g_decls_A_const_417 = A_arbace_j2g_decls_A_const_pool.A[613]; A_arbace_j2g_decls_A_const_418 = A_arbace_j2g_decls_A_const_pool.A[614]; A_arbace_j2g_decls_A_const_419 = A_arbace_j2g_decls_A_const_pool.A[615] }

func A_arbace_j2g_decls_A_clinit_p32() { A_arbace_j2g_decls_A_const_420 = A_arbace_j2g_decls_A_const_pool.A[616]; A_arbace_j2g_decls_A_const_421 = A_arbace_j2g_decls_A_const_pool.A[617]; A_arbace_j2g_decls_A_const_422 = A_arbace_j2g_decls_A_const_pool.A[618]; A_arbace_j2g_decls_A_const_423 = A_arbace_j2g_decls_A_const_pool.A[619]; A_arbace_j2g_decls_A_const_424 = A_arbace_j2g_decls_A_const_pool.A[620]; A_arbace_j2g_decls_A_const_425 = A_arbace_j2g_decls_A_const_pool.A[621]; A_arbace_j2g_decls_A_const_426 = A_arbace_j2g_decls_A_const_pool.A[622]; A_arbace_j2g_decls_A_const_427 = A_arbace_j2g_decls_A_const_pool.A[623]; A_arbace_j2g_decls_A_const_428 = A_arbace_j2g_decls_A_const_pool.A[624]; A_arbace_j2g_decls_A_const_429 = A_arbace_j2g_decls_A_const_pool.A[625]; A_arbace_j2g_decls_A_const_430 = A_arbace_j2g_decls_A_const_pool.A[626]; A_arbace_j2g_decls_A_const_431 = A_arbace_j2g_decls_A_const_pool.A[627]; A_arbace_j2g_decls_A_const_432 = A_arbace_j2g_decls_A_const_pool.A[628]; A_arbace_j2g_decls_A_const_433 = A_arbace_j2g_decls_A_const_pool.A[629]; A_arbace_j2g_decls_A_const_434 = A_arbace_j2g_decls_A_const_pool.A[630]; A_arbace_j2g_decls_A_const_435 = A_arbace_j2g_decls_A_const_pool.A[631] }

func A_arbace_j2g_decls_A_clinit_p33() { A_arbace_j2g_decls_A_const_436 = A_arbace_j2g_decls_A_const_pool.A[632]; A_arbace_j2g_decls_A_const_437 = A_arbace_j2g_decls_A_const_pool.A[633]; A_arbace_j2g_decls_A_const_438 = A_arbace_j2g_decls_A_const_pool.A[634]; A_arbace_j2g_decls_A_const_439 = A_arbace_j2g_decls_A_const_pool.A[635]; A_arbace_j2g_decls_A_const_440 = A_arbace_j2g_decls_A_const_pool.A[636]; A_arbace_j2g_decls_A_const_441 = A_arbace_j2g_decls_A_const_pool.A[637]; A_arbace_j2g_decls_A_const_442 = A_arbace_j2g_decls_A_const_pool.A[638]; A_arbace_j2g_decls_A_const_443 = A_arbace_j2g_decls_A_const_pool.A[639]; A_arbace_j2g_decls_A_const_444 = A_arbace_j2g_decls_A_const_pool.A[640]; A_arbace_j2g_decls_A_const_445 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[641]); A_arbace_j2g_decls_A_const_446 = A_arbace_j2g_decls_A_const_pool.A[642]; A_arbace_j2g_decls_A_const_447 = A_arbace_j2g_decls_A_const_pool.A[643]; A_arbace_j2g_decls_A_const_448 = A_arbace_j2g_decls_A_const_pool.A[644]; A_arbace_j2g_decls_A_const_449 = A_arbace_j2g_decls_A_const_pool.A[645]; A_arbace_j2g_decls_A_const_450 = A_arbace_j2g_decls_A_const_pool.A[646] }

func A_arbace_j2g_decls_A_clinit_p34() { A_arbace_j2g_decls_A_const_451 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[647]); A_arbace_j2g_decls_A_const_452 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[648]); A_arbace_j2g_decls_A_const_453 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[649]); A_arbace_j2g_decls_A_const_454 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[650]); A_arbace_j2g_decls_A_const_455 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[651]); A_arbace_j2g_decls_A_const_456 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[652]); A_arbace_j2g_decls_A_const_457 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[653]); A_arbace_j2g_decls_A_const_458 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[654]); A_arbace_j2g_decls_A_const_459 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[655]); A_arbace_j2g_decls_A_const_460 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[656]); A_arbace_j2g_decls_A_const_461 = A_arbace_j2g_decls_A_const_pool.A[657]; A_arbace_j2g_decls_A_const_462 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[658]) }

func A_arbace_j2g_decls_A_clinit_p35() { A_arbace_j2g_decls_A_const_463 = A_arbace_j2g_decls_A_const_pool.A[659]; A_arbace_j2g_decls_A_const_464 = A_arbace_j2g_decls_A_const_pool.A[660]; A_arbace_j2g_decls_A_const_465 = A_arbace_j2g_decls_A_const_pool.A[661]; A_arbace_j2g_decls_A_const_466 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[662]); A_arbace_j2g_decls_A_const_467 = A_arbace_j2g_decls_A_const_pool.A[663]; A_arbace_j2g_decls_A_const_468 = A_arbace_j2g_decls_A_const_pool.A[664]; A_arbace_j2g_decls_A_const_469 = A_arbace_j2g_decls_A_const_pool.A[665]; A_arbace_j2g_decls_A_const_470 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[666]); A_arbace_j2g_decls_A_const_471 = A_arbace_j2g_decls_A_const_pool.A[667]; A_arbace_j2g_decls_A_const_472 = A_arbace_j2g_decls_A_const_pool.A[668]; A_arbace_j2g_decls_A_const_473 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[669]); A_arbace_j2g_decls_A_const_474 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[670]); A_arbace_j2g_decls_A_const_475 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[671]); A_arbace_j2g_decls_A_const_476 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[672]) }

func A_arbace_j2g_decls_A_clinit_p36() { A_arbace_j2g_decls_A_const_477 = A_arbace_j2g_decls_A_const_pool.A[673]; A_arbace_j2g_decls_A_const_478 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[674]); A_arbace_j2g_decls_A_const_479 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[675]); A_arbace_j2g_decls_A_const_480 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[676]); A_arbace_j2g_decls_A_const_481 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[677]); A_arbace_j2g_decls_A_const_482 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[678]); A_arbace_j2g_decls_A_const_483 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[679]); A_arbace_j2g_decls_A_const_484 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[680]); A_arbace_j2g_decls_A_const_485 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[681]); A_arbace_j2g_decls_A_const_486 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[682]); A_arbace_j2g_decls_A_const_487 = A_arbace_j2g_decls_A_const_pool.A[683]; A_arbace_j2g_decls_A_const_488 = A_arbace_j2g_decls_A_const_pool.A[684] }

func A_arbace_j2g_decls_A_clinit_p37() { A_arbace_j2g_decls_A_const_489 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[685]); A_arbace_j2g_decls_A_const_490 = A_arbace_j2g_decls_A_const_pool.A[686]; A_arbace_j2g_decls_A_const_491 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[687]); A_arbace_j2g_decls_A_const_492 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[688]); A_arbace_j2g_decls_A_const_493 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[689]); A_arbace_j2g_decls_A_const_494 = lang.Keyword_Cast(A_arbace_j2g_decls_A_const_pool.A[690]); A_arbace_j2g_decls_A_const_495 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[691]); A_arbace_j2g_decls_A_const_496 = A_arbace_j2g_decls_A_const_pool.A[692]; A_arbace_j2g_decls_A_const_497 = A_arbace_j2g_decls_A_const_pool.A[693]; A_arbace_j2g_decls_A_const_498 = A_arbace_j2g_decls_A_const_pool.A[694]; A_arbace_j2g_decls_A_const_499 = A_arbace_j2g_decls_A_const_pool.A[695]; A_arbace_j2g_decls_A_const_500 = A_arbace_j2g_decls_A_const_pool.A[696]; A_arbace_j2g_decls_A_const_501 = A_arbace_j2g_decls_A_const_pool.A[697]; A_arbace_j2g_decls_A_const_502 = A_arbace_j2g_decls_A_const_pool.A[698] }

func A_arbace_j2g_decls_A_clinit_p38() { A_arbace_j2g_decls_A_const_503 = A_arbace_j2g_decls_A_const_pool.A[699]; A_arbace_j2g_decls_A_const_504 = A_arbace_j2g_decls_A_const_pool.A[700]; A_arbace_j2g_decls_A_const_505 = A_arbace_j2g_decls_A_const_pool.A[701]; A_arbace_j2g_decls_A_const_506 = A_arbace_j2g_decls_A_const_pool.A[702]; A_arbace_j2g_decls_A_const_507 = A_arbace_j2g_decls_A_const_pool.A[703]; A_arbace_j2g_decls_A_const_508 = A_arbace_j2g_decls_A_const_pool.A[704]; A_arbace_j2g_decls_A_const_509 = A_arbace_j2g_decls_A_const_pool.A[705]; A_arbace_j2g_decls_A_const_510 = A_arbace_j2g_decls_A_const_pool.A[706]; A_arbace_j2g_decls_A_const_511 = A_arbace_j2g_decls_A_const_pool.A[707]; A_arbace_j2g_decls_A_const_512 = A_arbace_j2g_decls_A_const_pool.A[708]; A_arbace_j2g_decls_A_const_513 = A_arbace_j2g_decls_A_const_pool.A[709]; A_arbace_j2g_decls_A_const_514 = A_arbace_j2g_decls_A_const_pool.A[710]; A_arbace_j2g_decls_A_const_515 = A_arbace_j2g_decls_A_const_pool.A[711]; A_arbace_j2g_decls_A_const_516 = A_arbace_j2g_decls_A_const_pool.A[712]; A_arbace_j2g_decls_A_const_517 = A_arbace_j2g_decls_A_const_pool.A[713]; A_arbace_j2g_decls_A_const_518 = A_arbace_j2g_decls_A_const_pool.A[714] }

func A_arbace_j2g_decls_A_clinit_p39() { A_arbace_j2g_decls_A_const_519 = A_arbace_j2g_decls_A_const_pool.A[715]; A_arbace_j2g_decls_A_const_520 = A_arbace_j2g_decls_A_const_pool.A[716]; A_arbace_j2g_decls_A_const_521 = A_arbace_j2g_decls_A_const_pool.A[717]; A_arbace_j2g_decls_A_const_522 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[718]); A_arbace_j2g_decls_A_const_523 = A_arbace_j2g_decls_A_const_pool.A[719]; A_arbace_j2g_decls_A_const_524 = A_arbace_j2g_decls_A_const_pool.A[720]; A_arbace_j2g_decls_A_const_525 = A_arbace_j2g_decls_A_const_pool.A[721]; A_arbace_j2g_decls_A_const_526 = A_arbace_j2g_decls_A_const_pool.A[722]; A_arbace_j2g_decls_A_const_527 = A_arbace_j2g_decls_A_const_pool.A[723]; A_arbace_j2g_decls_A_const_528 = A_arbace_j2g_decls_A_const_pool.A[724]; A_arbace_j2g_decls_A_const_529 = A_arbace_j2g_decls_A_const_pool.A[725]; A_arbace_j2g_decls_A_const_530 = A_arbace_j2g_decls_A_const_pool.A[726]; A_arbace_j2g_decls_A_const_531 = A_arbace_j2g_decls_A_const_pool.A[727]; A_arbace_j2g_decls_A_const_532 = A_arbace_j2g_decls_A_const_pool.A[728]; A_arbace_j2g_decls_A_const_533 = A_arbace_j2g_decls_A_const_pool.A[729] }

func A_arbace_j2g_decls_A_clinit_p40() { A_arbace_j2g_decls_A_const_534 = A_arbace_j2g_decls_A_const_pool.A[730]; A_arbace_j2g_decls_A_const_535 = A_arbace_j2g_decls_A_const_pool.A[731]; A_arbace_j2g_decls_A_const_536 = A_arbace_j2g_decls_A_const_pool.A[732]; A_arbace_j2g_decls_A_const_537 = A_arbace_j2g_decls_A_const_pool.A[733]; A_arbace_j2g_decls_A_const_538 = A_arbace_j2g_decls_A_const_pool.A[734]; A_arbace_j2g_decls_A_const_539 = A_arbace_j2g_decls_A_const_pool.A[735]; A_arbace_j2g_decls_A_const_540 = A_arbace_j2g_decls_A_const_pool.A[736]; A_arbace_j2g_decls_A_const_541 = A_arbace_j2g_decls_A_const_pool.A[737]; A_arbace_j2g_decls_A_const_542 = A_arbace_j2g_decls_A_const_pool.A[738]; A_arbace_j2g_decls_A_const_543 = A_arbace_j2g_decls_A_const_pool.A[739]; A_arbace_j2g_decls_A_const_544 = A_arbace_j2g_decls_A_const_pool.A[740]; A_arbace_j2g_decls_A_const_545 = A_arbace_j2g_decls_A_const_pool.A[741]; A_arbace_j2g_decls_A_const_546 = A_arbace_j2g_decls_A_const_pool.A[742]; A_arbace_j2g_decls_A_const_547 = A_arbace_j2g_decls_A_const_pool.A[743]; A_arbace_j2g_decls_A_const_548 = A_arbace_j2g_decls_A_const_pool.A[744]; A_arbace_j2g_decls_A_const_549 = A_arbace_j2g_decls_A_const_pool.A[745] }

func A_arbace_j2g_decls_A_clinit_p41() { A_arbace_j2g_decls_A_const_550 = A_arbace_j2g_decls_A_const_pool.A[746]; A_arbace_j2g_decls_A_const_551 = A_arbace_j2g_decls_A_const_pool.A[747]; A_arbace_j2g_decls_A_const_552 = A_arbace_j2g_decls_A_const_pool.A[748]; A_arbace_j2g_decls_A_const_553 = A_arbace_j2g_decls_A_const_pool.A[749]; A_arbace_j2g_decls_A_const_554 = A_arbace_j2g_decls_A_const_pool.A[750]; A_arbace_j2g_decls_A_const_555 = A_arbace_j2g_decls_A_const_pool.A[751]; A_arbace_j2g_decls_A_const_556 = A_arbace_j2g_decls_A_const_pool.A[752]; A_arbace_j2g_decls_A_const_557 = A_arbace_j2g_decls_A_const_pool.A[753]; A_arbace_j2g_decls_A_const_558 = A_arbace_j2g_decls_A_const_pool.A[754]; A_arbace_j2g_decls_A_const_559 = A_arbace_j2g_decls_A_const_pool.A[755]; A_arbace_j2g_decls_A_const_560 = A_arbace_j2g_decls_A_const_pool.A[756]; A_arbace_j2g_decls_A_const_561 = A_arbace_j2g_decls_A_const_pool.A[757]; A_arbace_j2g_decls_A_const_562 = A_arbace_j2g_decls_A_const_pool.A[758]; A_arbace_j2g_decls_A_const_563 = A_arbace_j2g_decls_A_const_pool.A[759]; A_arbace_j2g_decls_A_const_564 = A_arbace_j2g_decls_A_const_pool.A[760]; A_arbace_j2g_decls_A_const_565 = A_arbace_j2g_decls_A_const_pool.A[761] }

func A_arbace_j2g_decls_A_clinit_p42() { A_arbace_j2g_decls_A_const_566 = A_arbace_j2g_decls_A_const_pool.A[762]; A_arbace_j2g_decls_A_const_567 = A_arbace_j2g_decls_A_const_pool.A[763]; A_arbace_j2g_decls_A_const_568 = A_arbace_j2g_decls_A_const_pool.A[764]; A_arbace_j2g_decls_A_const_569 = A_arbace_j2g_decls_A_const_pool.A[765]; A_arbace_j2g_decls_A_const_570 = A_arbace_j2g_decls_A_const_pool.A[766]; A_arbace_j2g_decls_A_const_571 = A_arbace_j2g_decls_A_const_pool.A[767]; A_arbace_j2g_decls_A_const_572 = A_arbace_j2g_decls_A_const_pool.A[768]; A_arbace_j2g_decls_A_const_573 = A_arbace_j2g_decls_A_const_pool.A[769]; A_arbace_j2g_decls_A_const_574 = A_arbace_j2g_decls_A_const_pool.A[770]; A_arbace_j2g_decls_A_const_575 = A_arbace_j2g_decls_A_const_pool.A[771]; A_arbace_j2g_decls_A_const_576 = A_arbace_j2g_decls_A_const_pool.A[772]; A_arbace_j2g_decls_A_const_577 = A_arbace_j2g_decls_A_const_pool.A[773]; A_arbace_j2g_decls_A_const_578 = A_arbace_j2g_decls_A_const_pool.A[774]; A_arbace_j2g_decls_A_const_579 = A_arbace_j2g_decls_A_const_pool.A[775]; A_arbace_j2g_decls_A_const_580 = A_arbace_j2g_decls_A_const_pool.A[776]; A_arbace_j2g_decls_A_const_581 = A_arbace_j2g_decls_A_const_pool.A[777] }

func A_arbace_j2g_decls_A_clinit_p43() { A_arbace_j2g_decls_A_const_582 = A_arbace_j2g_decls_A_const_pool.A[778]; A_arbace_j2g_decls_A_const_583 = A_arbace_j2g_decls_A_const_pool.A[779]; A_arbace_j2g_decls_A_const_584 = A_arbace_j2g_decls_A_const_pool.A[780]; A_arbace_j2g_decls_A_const_585 = A_arbace_j2g_decls_A_const_pool.A[781]; A_arbace_j2g_decls_A_const_586 = A_arbace_j2g_decls_A_const_pool.A[782]; A_arbace_j2g_decls_A_const_587 = A_arbace_j2g_decls_A_const_pool.A[783]; A_arbace_j2g_decls_A_const_588 = A_arbace_j2g_decls_A_const_pool.A[784]; A_arbace_j2g_decls_A_const_589 = A_arbace_j2g_decls_A_const_pool.A[785]; A_arbace_j2g_decls_A_const_590 = A_arbace_j2g_decls_A_const_pool.A[786]; A_arbace_j2g_decls_A_const_591 = A_arbace_j2g_decls_A_const_pool.A[787]; A_arbace_j2g_decls_A_const_592 = A_arbace_j2g_decls_A_const_pool.A[788]; A_arbace_j2g_decls_A_const_593 = A_arbace_j2g_decls_A_const_pool.A[789]; A_arbace_j2g_decls_A_const_594 = A_arbace_j2g_decls_A_const_pool.A[790]; A_arbace_j2g_decls_A_const_595 = A_arbace_j2g_decls_A_const_pool.A[791]; A_arbace_j2g_decls_A_const_596 = A_arbace_j2g_decls_A_const_pool.A[792]; A_arbace_j2g_decls_A_const_597 = A_arbace_j2g_decls_A_const_pool.A[793] }

func A_arbace_j2g_decls_A_clinit_p44() { A_arbace_j2g_decls_A_const_598 = A_arbace_j2g_decls_A_const_pool.A[794]; A_arbace_j2g_decls_A_const_599 = A_arbace_j2g_decls_A_const_pool.A[795]; A_arbace_j2g_decls_A_const_600 = A_arbace_j2g_decls_A_const_pool.A[796]; A_arbace_j2g_decls_A_const_601 = A_arbace_j2g_decls_A_const_pool.A[797]; A_arbace_j2g_decls_A_const_602 = A_arbace_j2g_decls_A_const_pool.A[798]; A_arbace_j2g_decls_A_const_603 = A_arbace_j2g_decls_A_const_pool.A[799]; A_arbace_j2g_decls_A_const_604 = A_arbace_j2g_decls_A_const_pool.A[800]; A_arbace_j2g_decls_A_const_605 = A_arbace_j2g_decls_A_const_pool.A[801]; A_arbace_j2g_decls_A_const_606 = A_arbace_j2g_decls_A_const_pool.A[802]; A_arbace_j2g_decls_A_const_607 = A_arbace_j2g_decls_A_const_pool.A[803]; A_arbace_j2g_decls_A_const_608 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[804]); A_arbace_j2g_decls_A_const_609 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[805]); A_arbace_j2g_decls_A_const_610 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[806]); A_arbace_j2g_decls_A_const_611 = A_arbace_j2g_decls_A_const_pool.A[807]; A_arbace_j2g_decls_A_const_612 = A_arbace_j2g_decls_A_const_pool.A[808] }

func A_arbace_j2g_decls_A_clinit_p45() { A_arbace_j2g_decls_A_const_613 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[809]); A_arbace_j2g_decls_A_const_614 = A_arbace_j2g_decls_A_const_pool.A[810]; A_arbace_j2g_decls_A_const_615 = A_arbace_j2g_decls_A_const_pool.A[811]; A_arbace_j2g_decls_A_const_616 = A_arbace_j2g_decls_A_const_pool.A[812]; A_arbace_j2g_decls_A_const_617 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[813]); A_arbace_j2g_decls_A_const_618 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[814]); A_arbace_j2g_decls_A_const_619 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[815]); A_arbace_j2g_decls_A_const_620 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[816]); A_arbace_j2g_decls_A_const_621 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[817]); A_arbace_j2g_decls_A_const_622 = A_arbace_j2g_decls_A_const_pool.A[818]; A_arbace_j2g_decls_A_const_623 = A_arbace_j2g_decls_A_const_pool.A[819]; A_arbace_j2g_decls_A_const_624 = A_arbace_j2g_decls_A_const_pool.A[820]; A_arbace_j2g_decls_A_const_625 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[821]) }

func A_arbace_j2g_decls_A_clinit_p46() { A_arbace_j2g_decls_A_const_626 = A_arbace_j2g_decls_A_const_pool.A[822]; A_arbace_j2g_decls_A_const_627 = A_arbace_j2g_decls_A_const_pool.A[823]; A_arbace_j2g_decls_A_const_628 = A_arbace_j2g_decls_A_const_pool.A[824]; A_arbace_j2g_decls_A_const_629 = A_arbace_j2g_decls_A_const_pool.A[825]; A_arbace_j2g_decls_A_const_630 = A_arbace_j2g_decls_A_const_pool.A[826]; A_arbace_j2g_decls_A_const_631 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[827]); A_arbace_j2g_decls_A_const_632 = A_arbace_j2g_decls_A_const_pool.A[828]; A_arbace_j2g_decls_A_const_633 = A_arbace_j2g_decls_A_const_pool.A[829]; A_arbace_j2g_decls_A_const_634 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[830]); A_arbace_j2g_decls_A_const_635 = A_arbace_j2g_decls_A_const_pool.A[831]; A_arbace_j2g_decls_A_const_636 = A_arbace_j2g_decls_A_const_pool.A[832]; A_arbace_j2g_decls_A_const_637 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[833]); A_arbace_j2g_decls_A_const_638 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[834]); A_arbace_j2g_decls_A_const_639 = A_arbace_j2g_decls_A_const_pool.A[835] }

func A_arbace_j2g_decls_A_clinit_p47() { A_arbace_j2g_decls_A_const_640 = A_arbace_j2g_decls_A_const_pool.A[836]; A_arbace_j2g_decls_A_const_641 = A_arbace_j2g_decls_A_const_pool.A[837]; A_arbace_j2g_decls_A_const_642 = A_arbace_j2g_decls_A_const_pool.A[838]; A_arbace_j2g_decls_A_const_643 = A_arbace_j2g_decls_A_const_pool.A[839]; A_arbace_j2g_decls_A_const_644 = A_arbace_j2g_decls_A_const_pool.A[840]; A_arbace_j2g_decls_A_const_645 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[841]); A_arbace_j2g_decls_A_const_646 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[842]); A_arbace_j2g_decls_A_const_647 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[843]); A_arbace_j2g_decls_A_const_648 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[844]); A_arbace_j2g_decls_A_const_649 = lang.Var_Cast(A_arbace_j2g_decls_A_const_pool.A[845]) }

func A_arbace_j2g_decls_A_New() *A_arbace_j2g_decls_A { A_arbace_j2g_decls_A_Init(); t := &A_arbace_j2g_decls_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls_A) Ctor() {}

func (t *A_arbace_j2g_decls_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls_A_class }

func (t *A_arbace_j2g_decls_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls_A); return ok }

func A_arbace_j2g_decls_A_Cast(x any) *A_arbace_j2g_decls_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls_A_class)) }; return v }



type A_arbace_j2g_decls_at_line_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_at_line_A_fn_class *jrt.Class



type A_arbace_j2g_decls_at_line_fn__1464000041_A struct{ j2g_header uint64; F_l any }

var A_arbace_j2g_decls_at_line_fn__1464000041_A_fn_class *jrt.Class



type A_arbace_j2g_decls_body_of_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_body_of_A_fn_class *jrt.Class



type A_arbace_j2g_decls_calls_in_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_calls_in_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_captured_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A struct{ j2g_header uint64; F_tsym any }

var A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A struct{ j2g_header uint64; F_tsym, F_s__1464000029, F_iter__1464000028 any }

var A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_A_fn_class *jrt.Class



type A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A struct{ j2g_header uint64; F_tsym, F_b__1464000031 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_captured_fields_iter__1464000028__1464000032_fn__1464000033_fn__1464000034_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A struct{ j2g_header uint64; F_s__1464000061, F_iter__1464000060 any }

var A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A struct{ j2g_header uint64; F_b__1464000063 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_fields_iter__1464000060__1464000064_fn__1464000065_fn__1464000066_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000662_A struct{ j2g_header uint64; F_pkg, F_n any }

var A_arbace_j2g_decls_class_forms_fn__1464000662_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000664_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_forms_fn__1464000664_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000666_A struct{ j2g_header uint64; F_pkg, F_n any }

var A_arbace_j2g_decls_class_forms_fn__1464000666_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_fn__1464000668_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_forms_fn__1464000668_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A struct{ j2g_header uint64; F_iter__1464000602, F_pkg, F_s__1464000603 any }

var A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A struct{ j2g_header uint64; F_b__1464000605, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000602__1464000606_fn__1464000607_fn__1464000608_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A struct{ j2g_header uint64; F_iter__1464000612, F_pkg, F_s__1464000613 any }

var A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A struct{ j2g_header uint64; F_b__1464000615, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000612__1464000616_fn__1464000617_fn__1464000618_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A struct{ j2g_header uint64; F_pkg, F_s__1464000623, F_iter__1464000622 any }

var A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A struct{ j2g_header uint64; F_b__1464000625, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000622__1464000626_fn__1464000627_fn__1464000628_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A struct{ j2g_header uint64; F_pkg, F_s__1464000633, F_iter__1464000632 any }

var A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A struct{ j2g_header uint64; F_b__1464000635, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000632__1464000636_fn__1464000637_fn__1464000638_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A struct{ j2g_header uint64; F_pkg, F_s__1464000643, F_iter__1464000642 any }

var A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A struct{ j2g_header uint64; F_b__1464000645, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000642__1464000646_fn__1464000647_fn__1464000648_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A struct{ j2g_header uint64; F_g any }

var A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A struct{ j2g_header uint64; F_g, F_s__1464000653, F_iter__1464000652 any }

var A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A struct{ j2g_header uint64; F_b__1464000655, F_g any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_forms_iter__1464000652__1464000656_fn__1464000657_fn__1464000658_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_class_methods_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A struct{ j2g_header uint64; F_n, F_s__1464000072, F_iter__1464000071 any }

var A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_A_fn_class *jrt.Class



type A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A struct{ j2g_header uint64; F_n, F_b__1464000074 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_class_methods_iter__1464000071__1464000075_fn__1464000076_fn__1464000077_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_clj_const_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A struct{ j2g_header uint64; F_g, F_pkg any }

var A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A struct{ j2g_header uint64; F_g, F_iter__1464000509, F_pkg, F_s__1464000510 any }

var A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_A_fn_class *jrt.Class



type A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A struct{ j2g_header uint64; F_b__1464000512, F_g, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_clj_const_fields_iter__1464000509__1464000513_fn__1464000514_fn__1464000515_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A struct{ j2g_header uint64; F_info, F_n any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000127_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000142_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_fn__1464000144_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A struct{ j2g_header uint64; F_info any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A struct{ j2g_header uint64; F_info, F_s__1464000133, F_iter__1464000132 any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A struct{ j2g_header uint64; F_b__1464000135, F_info any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000132__1464000136_fn__1464000137_fn__1464000138_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A struct{ j2g_header uint64; F_s__1464000150, F_iter__1464000149 any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A struct{ j2g_header uint64; F_b__1464000152 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_call_translator_fn__1464000126_iter__1464000149__1464000153_fn__1464000154_fn__1464000155_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_desc_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_desc_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000195_A struct{ j2g_header uint64; F_d, F_reached, F_all_ps, F_caps, F_pkg, F_n, F_st, F_info, F_ab, F_cap_ps, F_outer_p, F_mm any }

var A_arbace_j2g_decls_ctor_forms_fn__1464000195_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A struct{ j2g_header uint64; F_d, F_all_ps, F_caps, F_pkg, F_n, F_st, F_info, F_ab, F_cap_ps, F_outer_p, F_mm any }

var A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A struct{ j2g_header uint64; F_st any }

var A_arbace_j2g_decls_ctor_forms_fn__1464000195_fn__1464000196_fn__1464000215_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_fn__1464000243_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_fn__1464000243_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A struct{ j2g_header uint64; F_s__1464000166, F_iter__1464000165 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A struct{ j2g_header uint64; F_b__1464000168 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000165__1464000169_fn__1464000170_fn__1464000171_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A struct{ j2g_header uint64; F_s__1464000176, F_iter__1464000175 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000178 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000175__1464000179_fn__1464000180_fn__1464000181_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A struct{ j2g_header uint64; F_s__1464000186, F_iter__1464000185 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000188, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000185__1464000189_fn__1464000190_fn__1464000191_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A struct{ j2g_header uint64; F_pkg, F_rps any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A struct{ j2g_header uint64; F_pkg, F_rps, F_s__1464000234, F_iter__1464000233 any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A struct{ j2g_header uint64; F_b__1464000236, F_pkg, F_rps any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_ctor_forms_iter__1464000233__1464000237_fn__1464000238_fn__1464000239_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_derived_body_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_fn__1464000272_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_derived_body_fn__1464000272_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A struct{ j2g_header uint64; F_g any }

var A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A struct{ j2g_header uint64; F_g, F_s__1464000275, F_iter__1464000274 any }

var A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_A_fn_class *jrt.Class



type A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A struct{ j2g_header uint64; F_g any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000277 any }

var A_arbace_j2g_decls_derived_body_iter__1464000274__1464000278_fn__1464000279_fn__1464000280_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A struct{ j2g_header uint64; F_s__1464000372, F_iter__1464000371 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000374, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000371__1464000375_fn__1464000376_fn__1464000377_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A struct{ j2g_header uint64; F_own, F_pkg, F_n, F_leaf any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A struct{ j2g_header uint64; F_own, F_pkg, F_n, F_s__1464000382, F_iter__1464000381, F_leaf any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A struct{ j2g_header uint64; F_own, F_pkg, F_n, F_leaf any; F_size__1927001038__auto__ int32; F_b__1464000384, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A struct{ j2g_header uint64; F_s__1464000398, F_iter__1464000397 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A struct{ j2g_header uint64; F_b__1464000400 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_fn__1464000387_iter__1464000397__1464000401_fn__1464000402_fn__1464000403_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A struct{ j2g_header uint64; F_iter__1464000417, F_s__1464000418 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000420 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000381__1464000385_fn__1464000386_iter__1464000417__1464000421_fn__1464000422_fn__1464000423_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A struct{ j2g_header uint64; F_iter__1464000429, F_s__1464000430 any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_A_fn_class *jrt.Class



type A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A struct{ j2g_header uint64; F_b__1464000432 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_dispatch_forms_iter__1464000429__1464000433_fn__1464000434_fn__1464000435_A_fn_class *jrt.Class



type A_arbace_j2g_decls_ensure_terminated_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_ensure_terminated_A_fn_class *jrt.Class



type A_arbace_j2g_decls_eval1464000004_A struct{ jrt.Object }

func A_arbace_j2g_decls_eval1464000004_A_New() *A_arbace_j2g_decls_eval1464000004_A { t := &A_arbace_j2g_decls_eval1464000004_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls_eval1464000004_A) Ctor() {}

func (t *A_arbace_j2g_decls_eval1464000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls_eval1464000004_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls_eval1464000004_A_class }

func (t *A_arbace_j2g_decls_eval1464000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls_eval1464000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls_eval1464000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls_eval1464000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls_eval1464000004_A); return ok }

func A_arbace_j2g_decls_eval1464000004_A_Cast(x any) *A_arbace_j2g_decls_eval1464000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls_eval1464000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls_eval1464000004_A_class)) }; return v }



type A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_fn_class *jrt.Class



type A_arbace_j2g_decls_eval1464000008_A struct{ jrt.Object }

func A_arbace_j2g_decls_eval1464000008_A_New() *A_arbace_j2g_decls_eval1464000008_A { t := &A_arbace_j2g_decls_eval1464000008_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls_eval1464000008_A) Ctor() {}

func (t *A_arbace_j2g_decls_eval1464000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls_eval1464000008_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls_eval1464000008_A_class }

func (t *A_arbace_j2g_decls_eval1464000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls_eval1464000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls_eval1464000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls_eval1464000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls_eval1464000008_A); return ok }

func A_arbace_j2g_decls_eval1464000008_A_Cast(x any) *A_arbace_j2g_decls_eval1464000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls_eval1464000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls_eval1464000008_A_class)) }; return v }



type A_arbace_j2g_decls_eval1464000008_fn__1464000009_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_extra_fields_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A struct{ j2g_header uint64; F_pkg, F_s__1464000089, F_iter__1464000088 any }

var A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_A_fn_class *jrt.Class



type A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A struct{ j2g_header uint64; F_pkg, F_b__1464000091 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_extra_fields_iter__1464000088__1464000092_fn__1464000093_fn__1464000094_A_fn_class *jrt.Class



type A_arbace_j2g_decls_field_go_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_field_go_type_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_forwarder_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A struct{ j2g_header uint64; F_s__1464000356, F_iter__1464000355 any }

var A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_A_fn_class *jrt.Class



type A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A struct{ j2g_header uint64; F_b__1464000358 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_forwarder_iter__1464000355__1464000359_fn__1464000360_fn__1464000361_A_fn_class *jrt.Class



type A_arbace_j2g_decls_gt_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_gt_A_fn_class *jrt.Class



type A_arbace_j2g_decls_has_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_has_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_hw_markers_A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A struct{ j2g_header uint64; F_iter__1464000109, F_s__1464000110 any }

var A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_A_fn_class *jrt.Class



type A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000112 any }

var A_arbace_j2g_decls_hw_markers_iter__1464000109__1464000113_fn__1464000114_fn__1464000115_A_fn_class *jrt.Class



type A_arbace_j2g_decls_iface_method_elem_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_iface_method_elem_A_fn_class *jrt.Class



type A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_iface_method_elem_fn__1464000102_A_fn_class *jrt.Class



type A_arbace_j2g_decls_init_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_init_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_init_forms_fn__1464000484_A struct{ j2g_header uint64; F_g, F_sup, F_pkg, F_reached, F_n, F_st any }

var A_arbace_j2g_decls_init_forms_fn__1464000484_A_fn_class *jrt.Class



type A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A struct{ j2g_header uint64; F_g, F_sup, F_pkg, F_reached, F_n, F_st any }

var A_arbace_j2g_decls_init_forms_fn__1464000484_fn__1464000485_A_fn_class *jrt.Class



type A_arbace_j2g_decls_instance_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_instance_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_interface_closure_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_interface_closure_A_fn_class *jrt.Class



type A_arbace_j2g_decls_interface_closure_fn__1464000106_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_decls_interface_closure_fn__1464000106_A_fn_class *jrt.Class



type A_arbace_j2g_decls_markers_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_markers_A_fn_class *jrt.Class



type A_arbace_j2g_decls_markers_fn__1464000121_A struct{ j2g_header uint64; F_sup_marked any }

var A_arbace_j2g_decls_markers_fn__1464000121_A_fn_class *jrt.Class



type A_arbace_j2g_decls_member_line_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_member_line_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_code_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_fn__1464000057_A struct{ j2g_header uint64; F_static, F_m, F_n, F_t, F_this, F_ret, F_ab any }

var A_arbace_j2g_decls_method_code_forms_fn__1464000057_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A struct{ j2g_header uint64; F_s__1464000048, F_iter__1464000047 any }

var A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A struct{ j2g_header uint64; F_b__1464000050 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_code_forms_iter__1464000047__1464000051_fn__1464000052_fn__1464000053_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000325_A struct{ j2g_header uint64; F_iface, F_static, F_pkg, F_n, F_ab, F_leaf, F_ps, F_mm any }

var A_arbace_j2g_decls_method_forms_fn__1464000325_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A struct{ j2g_header uint64; F_iter__1464000326, F_s__1464000327 any }

var A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A struct{ j2g_header uint64; F_b__1464000329 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_fn__1464000325_iter__1464000326__1464000330_fn__1464000331_fn__1464000332_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A struct{ j2g_header uint64; F_s__1464000296, F_iter__1464000295 any }

var A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000298 any }

var A_arbace_j2g_decls_method_forms_iter__1464000295__1464000299_fn__1464000300_fn__1464000301_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A struct{ j2g_header uint64; F_iter__1464000305, F_s__1464000306 any }

var A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A struct{ j2g_header uint64; F_b__1464000308 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_iter__1464000305__1464000309_fn__1464000310_fn__1464000311_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A struct{ j2g_header uint64; F_iter__1464000315, F_s__1464000316 any }

var A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A struct{ j2g_header uint64; F_b__1464000318 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_iter__1464000315__1464000319_fn__1464000320_fn__1464000321_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A struct{ j2g_header uint64; F_iter__1464000337, F_s__1464000338 any }

var A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_A_fn_class *jrt.Class



type A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_b__1464000340, F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_method_forms_iter__1464000337__1464000341_fn__1464000342_fn__1464000343_A_fn_class *jrt.Class



type A_arbace_j2g_decls_needs_entry_guard_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_needs_entry_guard_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_new_fn_state_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_new_fn_state_A_fn_class *jrt.Class



type A_arbace_j2g_decls_object_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_object_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_object_forms_fn__1464000368_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_object_forms_fn__1464000368_A_fn_class *jrt.Class



type A_arbace_j2g_decls_param_list_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_param_list_A_fn_class *jrt.Class



type A_arbace_j2g_decls_param_list_fn__1464000015_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_param_list_fn__1464000015_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reached_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reached_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_record_object_body_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fld__1464000248_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_record_object_body_fld__1464000248_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fn__1464000257_A struct{ j2g_header uint64; F_hash, F_fld any }

var A_arbace_j2g_decls_record_object_body_fn__1464000257_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fn__1464000259_A struct{ j2g_header uint64; F_fld, F_strof any }

var A_arbace_j2g_decls_record_object_body_fn__1464000259_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_fn__1464000261_A struct{ j2g_header uint64; F_js, F_fld any }

var A_arbace_j2g_decls_record_object_body_fn__1464000261_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_hash__1464000250_A struct{ j2g_header uint64; F_js any }

var A_arbace_j2g_decls_record_object_body_hash__1464000250_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_js__1464000246_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_record_object_body_js__1464000246_A_fn_class *jrt.Class



type A_arbace_j2g_decls_record_object_body_strof__1464000253_A struct{ j2g_header uint64; F_js any }

var A_arbace_j2g_decls_record_object_body_strof__1464000253_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reflected_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A struct{ j2g_header uint64; F_n any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A struct{ j2g_header uint64; F_n, F_s__1464000532, F_iter__1464000531 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A struct{ j2g_header uint64; F_b__1464000534, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000531__1464000535_fn__1464000536_fn__1464000537_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A struct{ j2g_header uint64; F_pkg, F_s__1464000542, F_iter__1464000541 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A struct{ j2g_header uint64; F_b__1464000544, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000541__1464000545_fn__1464000546_fn__1464000547_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A struct{ j2g_header uint64; F_pkg, F_s__1464000552, F_iter__1464000551 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A struct{ j2g_header uint64; F_b__1464000554, F_pkg any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000551__1464000555_fn__1464000556_fn__1464000557_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A struct{ j2g_header uint64; F_g, F_pkg, F_n any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A struct{ j2g_header uint64; F_g, F_pkg, F_n, F_s__1464000562, F_iter__1464000561 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A struct{ j2g_header uint64; F_b__1464000564, F_g, F_pkg, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A struct{ j2g_header uint64; F_s__1464000572, F_iter__1464000571 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A struct{ j2g_header uint64; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_b__1464000574 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_fn__1464000567_iter__1464000571__1464000575_fn__1464000576_fn__1464000577_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A struct{ j2g_header uint64; F_s__1464000586, F_iter__1464000585 any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_A_fn_class *jrt.Class



type A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A struct{ j2g_header uint64; F_b__1464000588 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_reflected_forms_iter__1464000561__1464000565_fn__1464000566_iter__1464000585__1464000589_fn__1464000590_fn__1464000591_A_fn_class *jrt.Class



type A_arbace_j2g_decls_result_meta_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_result_meta_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_split_clinit_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_fn__1464000463_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_split_clinit_fn__1464000463_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_fn__1464000476_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_split_clinit_fn__1464000476_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A struct{ j2g_header uint64; F_g any }

var A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A struct{ j2g_header uint64; F_g, F_s__1464000466, F_iter__1464000465 any }

var A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_A_fn_class *jrt.Class



type A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A struct{ j2g_header uint64; F_b__1464000468, F_g any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_split_clinit_iter__1464000465__1464000469_fn__1464000470_fn__1464000471_A_fn_class *jrt.Class



type A_arbace_j2g_decls_splittable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_splittable_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_static_forms_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A struct{ j2g_header uint64; F_g, F_pkg, F_n any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A struct{ j2g_header uint64; F_g, F_pkg, F_n, F_s__1464000441, F_iter__1464000440 any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A struct{ j2g_header uint64; F_b__1464000443, F_g, F_pkg, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A struct{ j2g_header uint64; F_f, F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000448_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A struct{ j2g_header uint64; F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000446_fn__1464000450_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A struct{ j2g_header uint64; F_f, F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000454_A_fn_class *jrt.Class



type A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A struct{ j2g_header uint64; F_cv any }

var A_arbace_j2g_decls_static_forms_iter__1464000440__1464000444_fn__1464000445_fn__1464000456_A_fn_class *jrt.Class



type A_arbace_j2g_decls_stub_body_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_stub_body_A_fn_class *jrt.Class



type A_arbace_j2g_decls_super_iface_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_super_iface_type_A_fn_class *jrt.Class



type A_arbace_j2g_decls_super_struct_type_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_super_struct_type_A_fn_class *jrt.Class



type A_arbace_j2g_decls_tag_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_tag_A_fn_class *jrt.Class



type A_arbace_j2g_decls_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_touches_statics_QMARK__A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_touches_statics_QMARK__A_fn_class *jrt.Class



type A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A struct{ j2g_header uint64; F_classes, F_hit any }

var A_arbace_j2g_decls_touches_statics_QMARK__w__1464000285_A_fn_class *jrt.Class



type A_arbace_j2g_decls_with_ret_A struct{ j2g_header uint64 }

var A_arbace_j2g_decls_with_ret_A_fn_class *jrt.Class
