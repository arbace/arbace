//line aot_arbace_j2g_decls__init.ae:1
package aot_arbace_j2g_decls

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_j2g_decls__init_A_Unit0__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_j2g_decls__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_j2g_decls__init_A_const_1) }
//line :1:1
func A_arbace_j2g_decls__init_A_Unit1__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_j2g_decls__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_2)) }
//line :1:1
func A_arbace_j2g_decls__init_A_Unit2__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_287, false, nil); A_arbace_j2g_decls_eval1464000004_loading__1927001464__auto____1464000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_j2g_decls__init_A_Unit3__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_j2g_decls__init_A_const_1)).Equals_O__Z(A_arbace_j2g_decls__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_288, false, nil); A_arbace_j2g_decls_eval1464000008_fn__1464000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_j2g_decls__init_A_Load__O() any { A_arbace_j2g_decls__init_A_Init(); jrt.StartCheck(); A_arbace_j2g_decls__init_A_Unit0__O(); A_arbace_j2g_decls__init_A_Unit1__O(); A_arbace_j2g_decls__init_A_Unit2__O(); A_arbace_j2g_decls__init_A_Unit3__O(); A_arbace_j2g_decls__init_A_Unit4__O(); A_arbace_j2g_decls__init_A_Unit5__O(); A_arbace_j2g_decls__init_A_Unit6__O(); A_arbace_j2g_decls__init_A_Unit7__O(); A_arbace_j2g_decls__init_A_Unit8__O(); A_arbace_j2g_decls__init_A_Unit9__O(); A_arbace_j2g_decls__init_A_Unit10__O(); A_arbace_j2g_decls__init_A_Unit11__O(); A_arbace_j2g_decls__init_A_Unit12__O(); A_arbace_j2g_decls__init_A_Unit13__O(); A_arbace_j2g_decls__init_A_Unit14__O(); A_arbace_j2g_decls__init_A_Unit15__O(); A_arbace_j2g_decls__init_A_Unit16__O(); A_arbace_j2g_decls__init_A_Unit17__O(); A_arbace_j2g_decls__init_A_Unit18__O(); A_arbace_j2g_decls__init_A_Unit19__O(); A_arbace_j2g_decls__init_A_Unit20__O(); A_arbace_j2g_decls__init_A_Unit21__O(); A_arbace_j2g_decls__init_A_Unit22__O(); A_arbace_j2g_decls__init_A_Unit23__O(); A_arbace_j2g_decls__init_A_Unit24__O(); A_arbace_j2g_decls__init_A_Unit25__O(); A_arbace_j2g_decls__init_A_Unit26__O(); A_arbace_j2g_decls__init_A_Unit27__O(); A_arbace_j2g_decls__init_A_Unit28__O(); A_arbace_j2g_decls__init_A_Unit29__O(); A_arbace_j2g_decls__init_A_Unit30__O(); A_arbace_j2g_decls__init_A_Unit31__O(); A_arbace_j2g_decls__init_A_Unit32__O(); A_arbace_j2g_decls__init_A_Unit33__O(); A_arbace_j2g_decls__init_A_Unit34__O(); A_arbace_j2g_decls__init_A_Unit35__O(); A_arbace_j2g_decls__init_A_Unit36__O(); A_arbace_j2g_decls__init_A_Unit37__O(); A_arbace_j2g_decls__init_A_Unit38__O(); A_arbace_j2g_decls__init_A_Unit39__O(); A_arbace_j2g_decls__init_A_Unit40__O(); A_arbace_j2g_decls__init_A_Unit41__O(); A_arbace_j2g_decls__init_A_Unit42__O(); A_arbace_j2g_decls__init_A_Unit43__O(); A_arbace_j2g_decls__init_A_Unit44__O(); A_arbace_j2g_decls__init_A_Unit45__O(); A_arbace_j2g_decls__init_A_Unit46__O(); A_arbace_j2g_decls__init_A_Unit47__O(); A_arbace_j2g_decls__init_A_Unit48__O(); A_arbace_j2g_decls__init_A_Unit49__O(); A_arbace_j2g_decls__init_A_Unit50__O(); A_arbace_j2g_decls__init_A_Unit51__O(); A_arbace_j2g_decls__init_A_Unit52__O(); A_arbace_j2g_decls__init_A_Unit53__O(); A_arbace_j2g_decls__init_A_Unit54__O(); A_arbace_j2g_decls__init_A_Unit55__O(); return nil }











func A_arbace_j2g_decls__init_A_Unit4__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(17, 1); A_arbace_j2g_decls__init_A_const_4.BindRoot_O__V(lang.PersistentHashSet_EMPTY.Ref()); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_5)); return A_arbace_j2g_decls__init_A_const_4.SetDynamic_Z__Var(true).Ref() }

func A_arbace_j2g_decls__init_A_Unit5__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(19, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_6; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_j2g_decls_tag_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_j2g_decls_tag_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_289, false, nil); A_arbace_j2g_decls_tag_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_7)); return A_arbace_j2g_decls__init_A_const_6 }

func A_arbace_j2g_decls__init_A_Unit6__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(21, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_8; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_j2g_decls_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_j2g_decls_has_QMARK__A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_290, false, nil); A_arbace_j2g_decls_has_QMARK__A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_9)); return A_arbace_j2g_decls__init_A_const_8 }

func A_arbace_j2g_decls__init_A_Unit7__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(23, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_10; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_j2g_decls_gt_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_j2g_decls_gt_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_291, false, nil); A_arbace_j2g_decls_gt_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_11)); return A_arbace_j2g_decls__init_A_const_10 }

func A_arbace_j2g_decls__init_A_Unit8__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_j2g_decls_param_list_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_j2g_decls_param_list_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_292, false, nil); A_arbace_j2g_decls_param_list_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_13)); return A_arbace_j2g_decls__init_A_const_12 }





func A_arbace_j2g_decls__init_A_Unit9__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(31, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_j2g_decls_result_meta_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_j2g_decls_result_meta_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_293, false, nil); A_arbace_j2g_decls_result_meta_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_15)); return A_arbace_j2g_decls__init_A_const_14 }

func A_arbace_j2g_decls__init_A_Unit10__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_j2g_decls_with_ret_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_j2g_decls_with_ret_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_294, false, nil); A_arbace_j2g_decls_with_ret_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_17)); return A_arbace_j2g_decls__init_A_const_16 }

func A_arbace_j2g_decls__init_A_Unit11__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(35, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_18; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__18 any = A_arbace_j2g_decls_new_fn_state_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_j2g_decls_new_fn_state_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_295, true, nil); A_arbace_j2g_decls_new_fn_state_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__18, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_19)); return A_arbace_j2g_decls__init_A_const_18 }






func A_arbace_j2g_decls__init_A_Unit12__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(42, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__20 any = A_arbace_j2g_decls_terminating_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_j2g_decls_terminating_QMARK__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_296, false, nil); A_arbace_j2g_decls_terminating_QMARK__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__20, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_21)); return A_arbace_j2g_decls__init_A_const_20 }










func A_arbace_j2g_decls__init_A_Unit13__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__22 any = A_arbace_j2g_decls_ensure_terminated_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_j2g_decls_ensure_terminated_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_297, false, nil); A_arbace_j2g_decls_ensure_terminated_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__22, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_23)); return A_arbace_j2g_decls__init_A_const_22 }







func A_arbace_j2g_decls__init_A_Unit14__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(61, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_j2g_decls_stub_body_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_j2g_decls_stub_body_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_298, false, nil); A_arbace_j2g_decls_stub_body_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_25)); return A_arbace_j2g_decls__init_A_const_24 }



func A_arbace_j2g_decls__init_A_Unit15__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(65, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_j2g_decls_capture_field_name_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_j2g_decls_capture_field_name_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_299, false, nil); A_arbace_j2g_decls_capture_field_name_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_27)); return A_arbace_j2g_decls__init_A_const_26 }


















func A_arbace_j2g_decls__init_A_Unit16__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(84, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_28; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__28 any = A_arbace_j2g_decls_captured_fields_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_j2g_decls_captured_fields_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_300, true, nil); A_arbace_j2g_decls_captured_fields_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__28, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_29)); return A_arbace_j2g_decls__init_A_const_28 }



























func A_arbace_j2g_decls__init_A_Unit17__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(112, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_30; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_j2g_decls_member_line_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_j2g_decls_member_line_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_301, false, nil); A_arbace_j2g_decls_member_line_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_31)); return A_arbace_j2g_decls__init_A_const_30 }




func A_arbace_j2g_decls__init_A_Unit18__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(117, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_j2g_decls_at_line_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_j2g_decls_at_line_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_302, false, nil); A_arbace_j2g_decls_at_line_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_33)); return A_arbace_j2g_decls__init_A_const_32 }






func A_arbace_j2g_decls__init_A_Unit19__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_34; var tmp2 *lang.Compiler_AOTFn; var fnbody__34 any = A_arbace_j2g_decls_method_code_forms_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_j2g_decls_method_code_forms_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_303, false, nil); A_arbace_j2g_decls_method_code_forms_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__34, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_35)); return A_arbace_j2g_decls__init_A_const_34 }

























func A_arbace_j2g_decls__init_A_Unit20__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(150, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_36; var tmp2 *lang.Compiler_AOTFn; var fnbody__36 any = A_arbace_j2g_decls_class_fields_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_j2g_decls_class_fields_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_304, false, nil); A_arbace_j2g_decls_class_fields_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_36; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_37)); return A_arbace_j2g_decls__init_A_const_36 }




func A_arbace_j2g_decls__init_A_Unit21__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(155, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_38; var tmp2 *lang.Compiler_AOTFn; var fnbody__38 any = A_arbace_j2g_decls_class_methods_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_j2g_decls_class_methods_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_305, false, nil); A_arbace_j2g_decls_class_methods_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__38, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_39)); return A_arbace_j2g_decls__init_A_const_38 }









func A_arbace_j2g_decls__init_A_Unit22__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(165, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__40 any = A_arbace_j2g_decls_body_of_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_j2g_decls_body_of_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_306, false, nil); A_arbace_j2g_decls_body_of_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__40, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_41)); return A_arbace_j2g_decls__init_A_const_40 }

func A_arbace_j2g_decls__init_A_Unit23__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_42; var tmp2 *lang.Compiler_AOTFn; var fnbody__42 any = A_arbace_j2g_decls_reached_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_j2g_decls_reached_QMARK__A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_307, false, nil); A_arbace_j2g_decls_reached_QMARK__A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_43)); return A_arbace_j2g_decls__init_A_const_42 }




func A_arbace_j2g_decls__init_A_Unit24__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(172, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_44; tmp1.BindRoot_O__V(A_arbace_j2g_decls__init_A_const_45.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_j2g_decls__init_A_const_44; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_46)); return A_arbace_j2g_decls__init_A_const_44 }

func A_arbace_j2g_decls__init_A_Unit25__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(174, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_47; tmp1.BindRoot_O__V(A_arbace_j2g_decls__init_A_const_48.GetRawRoot__O()); var tmp2 *lang.Var = A_arbace_j2g_decls__init_A_const_47; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_49)); return A_arbace_j2g_decls__init_A_const_47 }

func A_arbace_j2g_decls__init_A_Unit26__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(176, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_50; var tmp2 *lang.Compiler_AOTFn; var fnbody__44 any = A_arbace_j2g_decls_super_struct_type_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_j2g_decls_super_struct_type_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_308, false, nil); A_arbace_j2g_decls_super_struct_type_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__44, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_51)); return A_arbace_j2g_decls__init_A_const_50 }







func A_arbace_j2g_decls__init_A_Unit27__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(184, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_52; var tmp2 *lang.Compiler_AOTFn; var fnbody__46 any = A_arbace_j2g_decls_super_iface_type_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_j2g_decls_super_iface_type_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_309, false, nil); A_arbace_j2g_decls_super_iface_type_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__46, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_53)); return A_arbace_j2g_decls__init_A_const_52 }





func A_arbace_j2g_decls__init_A_Unit28__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(190, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_54; var tmp2 *lang.Compiler_AOTFn; var fnbody__48 any = A_arbace_j2g_decls_field_go_type_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_j2g_decls_field_go_type_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_310, false, nil); A_arbace_j2g_decls_field_go_type_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__48, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_55)); return A_arbace_j2g_decls__init_A_const_54 }












func A_arbace_j2g_decls__init_A_Unit29__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(203, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_56; var tmp2 *lang.Compiler_AOTFn; var fnbody__50 any = A_arbace_j2g_decls_extra_fields_A_New(); var tmp3 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_j2g_decls_extra_fields_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_311, false, nil); A_arbace_j2g_decls_extra_fields_A_fn_class = fncls__49d; tmp3 = fncls__49d } else { tmp3 = fncls__49 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__50, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_57)); return A_arbace_j2g_decls__init_A_const_56 }










func A_arbace_j2g_decls__init_A_Unit30__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(214, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_58; var tmp2 *lang.Compiler_AOTFn; var fnbody__52 any = A_arbace_j2g_decls_iface_method_elem_A_New(); var tmp3 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_j2g_decls_iface_method_elem_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_312, false, nil); A_arbace_j2g_decls_iface_method_elem_A_fn_class = fncls__51d; tmp3 = fncls__51d } else { tmp3 = fncls__51 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__52, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_59)); return A_arbace_j2g_decls__init_A_const_58 }




func A_arbace_j2g_decls__init_A_Unit31__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(219, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_60; var tmp2 *lang.Compiler_AOTFn; var fnbody__54 any = A_arbace_j2g_decls_interface_closure_A_New(); var tmp3 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_j2g_decls_interface_closure_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_313, false, nil); A_arbace_j2g_decls_interface_closure_A_fn_class = fncls__53d; tmp3 = fncls__53d } else { tmp3 = fncls__53 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__54, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_61)); return A_arbace_j2g_decls__init_A_const_60 }





func A_arbace_j2g_decls__init_A_Unit32__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(225, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_62; var tmp2 *lang.Compiler_AOTFn; var fnbody__56 any = A_arbace_j2g_decls_hw_markers_A_New(); var tmp3 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_j2g_decls_hw_markers_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_314, false, nil); A_arbace_j2g_decls_hw_markers_A_fn_class = fncls__55d; tmp3 = fncls__55d } else { tmp3 = fncls__55 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__56, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_63)); return A_arbace_j2g_decls__init_A_const_62 }





func A_arbace_j2g_decls__init_A_Unit33__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(231, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_64; var tmp2 *lang.Compiler_AOTFn; var fnbody__58 any = A_arbace_j2g_decls_markers_A_New(); var tmp3 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_j2g_decls_markers_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_315, false, nil); A_arbace_j2g_decls_markers_A_fn_class = fncls__57d; tmp3 = fncls__57d } else { tmp3 = fncls__57 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_65)); return A_arbace_j2g_decls__init_A_const_64 }












func A_arbace_j2g_decls__init_A_Unit34__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(244, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_66; var tmp2 *lang.Compiler_AOTFn; var fnbody__60 any = A_arbace_j2g_decls_ctor_desc_A_New(); var tmp3 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_j2g_decls_ctor_desc_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_316, false, nil); A_arbace_j2g_decls_ctor_desc_A_fn_class = fncls__59d; tmp3 = fncls__59d } else { tmp3 = fncls__59 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__60, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_67)); return A_arbace_j2g_decls__init_A_const_66 }

func A_arbace_j2g_decls__init_A_Unit35__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(246, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_68; var tmp2 *lang.Compiler_AOTFn; var fnbody__62 any = A_arbace_j2g_decls_ctor_call_translator_A_New(); var tmp3 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_j2g_decls_ctor_call_translator_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_317, false, nil); A_arbace_j2g_decls_ctor_call_translator_A_fn_class = fncls__61d; tmp3 = fncls__61d } else { tmp3 = fncls__61 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__62, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_69)); return A_arbace_j2g_decls__init_A_const_68 }































































func A_arbace_j2g_decls__init_A_Unit36__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(310, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_70; var tmp2 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_j2g_decls_ctor_forms_A_New(); var tmp3 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_j2g_decls_ctor_forms_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_318, false, nil); A_arbace_j2g_decls_ctor_forms_A_fn_class = fncls__63d; tmp3 = fncls__63d } else { tmp3 = fncls__63 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_71)); return A_arbace_j2g_decls__init_A_const_70 }





























































































func A_arbace_j2g_decls__init_A_Unit37__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(404, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_72; var tmp2 *lang.Compiler_AOTFn; var fnbody__66 any = A_arbace_j2g_decls_record_object_body_A_New(); var tmp3 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_j2g_decls_record_object_body_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_319, false, nil); A_arbace_j2g_decls_record_object_body_A_fn_class = fncls__65d; tmp3 = fncls__65d } else { tmp3 = fncls__65 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__66, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_73)); return A_arbace_j2g_decls__init_A_const_72 }





































































func A_arbace_j2g_decls__init_A_Unit38__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(474, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__68 any = A_arbace_j2g_decls_derived_body_A_New(); var tmp3 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_j2g_decls_derived_body_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_320, false, nil); A_arbace_j2g_decls_derived_body_A_fn_class = fncls__67d; tmp3 = fncls__67d } else { tmp3 = fncls__67 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__68, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_75)); return A_arbace_j2g_decls__init_A_const_74 }













































func A_arbace_j2g_decls__init_A_Unit39__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(520, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__70 any = A_arbace_j2g_decls_touches_statics_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_j2g_decls_touches_statics_QMARK__A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_321, false, nil); A_arbace_j2g_decls_touches_statics_QMARK__A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_77)); return A_arbace_j2g_decls__init_A_const_76 }


















func A_arbace_j2g_decls__init_A_Unit40__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(539, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__72 any = A_arbace_j2g_decls_needs_entry_guard_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_j2g_decls_needs_entry_guard_QMARK__A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_322, false, nil); A_arbace_j2g_decls_needs_entry_guard_QMARK__A_fn_class = fncls__71d; tmp3 = fncls__71d } else { tmp3 = fncls__71 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__72, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_79)); return A_arbace_j2g_decls__init_A_const_78 }










func A_arbace_j2g_decls__init_A_Unit41__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(550, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_80; var tmp2 *lang.Compiler_AOTFn; var fnbody__74 any = A_arbace_j2g_decls_method_forms_A_New(); var tmp3 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_j2g_decls_method_forms_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_323, false, nil); A_arbace_j2g_decls_method_forms_A_fn_class = fncls__73d; tmp3 = fncls__73d } else { tmp3 = fncls__73 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__74, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_81)); return A_arbace_j2g_decls__init_A_const_80 }






















































































func A_arbace_j2g_decls__init_A_Unit42__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(637, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_82; var tmp2 *lang.Compiler_AOTFn; var fnbody__76 any = A_arbace_j2g_decls_forwarder_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_j2g_decls_forwarder_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_324, false, nil); A_arbace_j2g_decls_forwarder_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__76, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_83)); return A_arbace_j2g_decls__init_A_const_82 }














func A_arbace_j2g_decls__init_A_Unit43__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(652, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_84; var tmp2 *lang.Compiler_AOTFn; var fnbody__78 any = A_arbace_j2g_decls_object_forms_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_j2g_decls_object_forms_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_325, false, nil); A_arbace_j2g_decls_object_forms_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__78, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_85)); return A_arbace_j2g_decls__init_A_const_84 }





























func A_arbace_j2g_decls__init_A_Unit44__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(682, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__80 any = A_arbace_j2g_decls_dispatch_forms_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_j2g_decls_dispatch_forms_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_326, false, nil); A_arbace_j2g_decls_dispatch_forms_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_87)); return A_arbace_j2g_decls__init_A_const_86 }


























func A_arbace_j2g_decls__init_A_Unit45__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(709, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__82 any = A_arbace_j2g_decls_static_forms_A_New(); var tmp3 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_j2g_decls_static_forms_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_327, false, nil); A_arbace_j2g_decls_static_forms_A_fn_class = fncls__81d; tmp3 = fncls__81d } else { tmp3 = fncls__81 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_89)); return A_arbace_j2g_decls__init_A_const_88 }




















func A_arbace_j2g_decls__init_A_Unit46__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(730, 1); A_arbace_j2g_decls__init_A_const_90.BindRoot_O__V(A_arbace_j2g_decls__init_A_const_91); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_90; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_92)); return A_arbace_j2g_decls__init_A_const_90 }



func A_arbace_j2g_decls__init_A_Unit47__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(734, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_93; var tmp2 *lang.Compiler_AOTFn; var fnbody__84 any = A_arbace_j2g_decls_calls_in_A_New(); var tmp3 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_j2g_decls_calls_in_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_328, false, nil); A_arbace_j2g_decls_calls_in_A_fn_class = fncls__83d; tmp3 = fncls__83d } else { tmp3 = fncls__83 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__84, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_93; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_94)); return A_arbace_j2g_decls__init_A_const_93 }




func A_arbace_j2g_decls__init_A_Unit48__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(739, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_95; var tmp2 *lang.Compiler_AOTFn; var fnbody__86 any = A_arbace_j2g_decls_splittable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__85 *jrt.Class = A_arbace_j2g_decls_splittable_QMARK__A_fn_class; if fncls__85 == nil { var fncls__85d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_329, false, nil); A_arbace_j2g_decls_splittable_QMARK__A_fn_class = fncls__85d; tmp3 = fncls__85d } else { tmp3 = fncls__85 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__86, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_95; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_96)); return A_arbace_j2g_decls__init_A_const_95 }






func A_arbace_j2g_decls__init_A_Unit49__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(746, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_97; var tmp2 *lang.Compiler_AOTFn; var fnbody__88 any = A_arbace_j2g_decls_split_clinit_A_New(); var tmp3 *jrt.Class; var fncls__87 *jrt.Class = A_arbace_j2g_decls_split_clinit_A_fn_class; if fncls__87 == nil { var fncls__87d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_330, false, nil); A_arbace_j2g_decls_split_clinit_A_fn_class = fncls__87d; tmp3 = fncls__87d } else { tmp3 = fncls__87 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__88, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_97; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_98)); return A_arbace_j2g_decls__init_A_const_97 }





















func A_arbace_j2g_decls__init_A_Unit50__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(768, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_99; var tmp2 *lang.Compiler_AOTFn; var fnbody__90 any = A_arbace_j2g_decls_clj_const_store_A_New(); var tmp3 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_j2g_decls_clj_const_store_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_331, false, nil); A_arbace_j2g_decls_clj_const_store_A_fn_class = fncls__89d; tmp3 = fncls__89d } else { tmp3 = fncls__89 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__90, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_99; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_100)); return A_arbace_j2g_decls__init_A_const_99 }


















func A_arbace_j2g_decls__init_A_Unit51__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(787, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_101; var tmp2 *lang.Compiler_AOTFn; var fnbody__92 any = A_arbace_j2g_decls_init_forms_A_New(); var tmp3 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_j2g_decls_init_forms_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_332, false, nil); A_arbace_j2g_decls_init_forms_A_fn_class = fncls__91d; tmp3 = fncls__91d } else { tmp3 = fncls__91 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__92, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_102)); return A_arbace_j2g_decls__init_A_const_101 }





































func A_arbace_j2g_decls__init_A_Unit52__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(825, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_103; var tmp2 *lang.Compiler_AOTFn; var fnbody__94 any = A_arbace_j2g_decls_clj_const_fields_A_New(); var tmp3 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_j2g_decls_clj_const_fields_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_333, false, nil); A_arbace_j2g_decls_clj_const_fields_A_fn_class = fncls__93d; tmp3 = fncls__93d } else { tmp3 = fncls__93 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_104)); return A_arbace_j2g_decls__init_A_const_103 }






func A_arbace_j2g_decls__init_A_Unit53__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(832, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_105; var tmp2 *lang.Compiler_AOTFn; var fnbody__96 any = A_arbace_j2g_decls_instance_forms_A_New(); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_j2g_decls_instance_forms_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_334, false, nil); A_arbace_j2g_decls_instance_forms_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__96, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_105; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_106)); return A_arbace_j2g_decls__init_A_const_105 }












































func A_arbace_j2g_decls__init_A_Unit54__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(877, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_107; var tmp2 *lang.Compiler_AOTFn; var fnbody__98 any = A_arbace_j2g_decls_reflected_forms_A_New(); var tmp3 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_j2g_decls_reflected_forms_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_335, false, nil); A_arbace_j2g_decls_reflected_forms_A_fn_class = fncls__97d; tmp3 = fncls__97d } else { tmp3 = fncls__97 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__98, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_107; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_108)); return A_arbace_j2g_decls__init_A_const_107 }






























func A_arbace_j2g_decls__init_A_Unit55__O() any { A_arbace_j2g_decls__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(908, 1); var tmp1 *lang.Var = A_arbace_j2g_decls__init_A_const_109; var tmp2 *lang.Compiler_AOTFn; var fnbody__100 any = A_arbace_j2g_decls_class_forms_A_New(); var tmp3 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_j2g_decls_class_forms_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_336, false, nil); A_arbace_j2g_decls_class_forms_A_fn_class = fncls__99d; tmp3 = fncls__99d } else { tmp3 = fncls__99 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__100, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_j2g_decls__init_A_const_109; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_j2g_decls__init_A_const_110)); return A_arbace_j2g_decls__init_A_const_109 }



type A_arbace_j2g_decls__init_A struct{ jrt.Object }

var A_arbace_j2g_decls__init_A_const_pool *jrt.RefArray

var A_arbace_j2g_decls__init_A_const_0 *lang.Var

var A_arbace_j2g_decls__init_A_const_1 any

var A_arbace_j2g_decls__init_A_const_2 any

var A_arbace_j2g_decls__init_A_const_3 any

var A_arbace_j2g_decls__init_A_const_4 *lang.Var

var A_arbace_j2g_decls__init_A_const_5 any

var A_arbace_j2g_decls__init_A_const_6 *lang.Var

var A_arbace_j2g_decls__init_A_const_7 any

var A_arbace_j2g_decls__init_A_const_8 *lang.Var

var A_arbace_j2g_decls__init_A_const_9 any

var A_arbace_j2g_decls__init_A_const_10 *lang.Var

var A_arbace_j2g_decls__init_A_const_11 any

var A_arbace_j2g_decls__init_A_const_12 *lang.Var

var A_arbace_j2g_decls__init_A_const_13 any

var A_arbace_j2g_decls__init_A_const_14 *lang.Var

var A_arbace_j2g_decls__init_A_const_15 any

var A_arbace_j2g_decls__init_A_const_16 *lang.Var

var A_arbace_j2g_decls__init_A_const_17 any

var A_arbace_j2g_decls__init_A_const_18 *lang.Var

var A_arbace_j2g_decls__init_A_const_19 any

var A_arbace_j2g_decls__init_A_const_20 *lang.Var

var A_arbace_j2g_decls__init_A_const_21 any

var A_arbace_j2g_decls__init_A_const_22 *lang.Var

var A_arbace_j2g_decls__init_A_const_23 any

var A_arbace_j2g_decls__init_A_const_24 *lang.Var

var A_arbace_j2g_decls__init_A_const_25 any

var A_arbace_j2g_decls__init_A_const_26 *lang.Var

var A_arbace_j2g_decls__init_A_const_27 any

var A_arbace_j2g_decls__init_A_const_28 *lang.Var

var A_arbace_j2g_decls__init_A_const_29 any

var A_arbace_j2g_decls__init_A_const_30 *lang.Var

var A_arbace_j2g_decls__init_A_const_31 any

var A_arbace_j2g_decls__init_A_const_32 *lang.Var

var A_arbace_j2g_decls__init_A_const_33 any

var A_arbace_j2g_decls__init_A_const_34 *lang.Var

var A_arbace_j2g_decls__init_A_const_35 any

var A_arbace_j2g_decls__init_A_const_36 *lang.Var

var A_arbace_j2g_decls__init_A_const_37 any

var A_arbace_j2g_decls__init_A_const_38 *lang.Var

var A_arbace_j2g_decls__init_A_const_39 any

var A_arbace_j2g_decls__init_A_const_40 *lang.Var

var A_arbace_j2g_decls__init_A_const_41 any

var A_arbace_j2g_decls__init_A_const_42 *lang.Var

var A_arbace_j2g_decls__init_A_const_43 any

var A_arbace_j2g_decls__init_A_const_44 *lang.Var

var A_arbace_j2g_decls__init_A_const_45 *lang.Var

var A_arbace_j2g_decls__init_A_const_46 any

var A_arbace_j2g_decls__init_A_const_47 *lang.Var

var A_arbace_j2g_decls__init_A_const_48 *lang.Var

var A_arbace_j2g_decls__init_A_const_49 any

var A_arbace_j2g_decls__init_A_const_50 *lang.Var

var A_arbace_j2g_decls__init_A_const_51 any

var A_arbace_j2g_decls__init_A_const_52 *lang.Var

var A_arbace_j2g_decls__init_A_const_53 any

var A_arbace_j2g_decls__init_A_const_54 *lang.Var

var A_arbace_j2g_decls__init_A_const_55 any

var A_arbace_j2g_decls__init_A_const_56 *lang.Var

var A_arbace_j2g_decls__init_A_const_57 any

var A_arbace_j2g_decls__init_A_const_58 *lang.Var

var A_arbace_j2g_decls__init_A_const_59 any

var A_arbace_j2g_decls__init_A_const_60 *lang.Var

var A_arbace_j2g_decls__init_A_const_61 any

var A_arbace_j2g_decls__init_A_const_62 *lang.Var

var A_arbace_j2g_decls__init_A_const_63 any

var A_arbace_j2g_decls__init_A_const_64 *lang.Var

var A_arbace_j2g_decls__init_A_const_65 any

var A_arbace_j2g_decls__init_A_const_66 *lang.Var

var A_arbace_j2g_decls__init_A_const_67 any

var A_arbace_j2g_decls__init_A_const_68 *lang.Var

var A_arbace_j2g_decls__init_A_const_69 any

var A_arbace_j2g_decls__init_A_const_70 *lang.Var

var A_arbace_j2g_decls__init_A_const_71 any

var A_arbace_j2g_decls__init_A_const_72 *lang.Var

var A_arbace_j2g_decls__init_A_const_73 any

var A_arbace_j2g_decls__init_A_const_74 *lang.Var

var A_arbace_j2g_decls__init_A_const_75 any

var A_arbace_j2g_decls__init_A_const_76 *lang.Var

var A_arbace_j2g_decls__init_A_const_77 any

var A_arbace_j2g_decls__init_A_const_78 *lang.Var

var A_arbace_j2g_decls__init_A_const_79 any

var A_arbace_j2g_decls__init_A_const_80 *lang.Var

var A_arbace_j2g_decls__init_A_const_81 any

var A_arbace_j2g_decls__init_A_const_82 *lang.Var

var A_arbace_j2g_decls__init_A_const_83 any

var A_arbace_j2g_decls__init_A_const_84 *lang.Var

var A_arbace_j2g_decls__init_A_const_85 any

var A_arbace_j2g_decls__init_A_const_86 *lang.Var

var A_arbace_j2g_decls__init_A_const_87 any

var A_arbace_j2g_decls__init_A_const_88 *lang.Var

var A_arbace_j2g_decls__init_A_const_89 any

var A_arbace_j2g_decls__init_A_const_90 *lang.Var

var A_arbace_j2g_decls__init_A_const_91 any

var A_arbace_j2g_decls__init_A_const_92 any

var A_arbace_j2g_decls__init_A_const_93 *lang.Var

var A_arbace_j2g_decls__init_A_const_94 any

var A_arbace_j2g_decls__init_A_const_95 *lang.Var

var A_arbace_j2g_decls__init_A_const_96 any

var A_arbace_j2g_decls__init_A_const_97 *lang.Var

var A_arbace_j2g_decls__init_A_const_98 any

var A_arbace_j2g_decls__init_A_const_99 *lang.Var

var A_arbace_j2g_decls__init_A_const_100 any

var A_arbace_j2g_decls__init_A_const_101 *lang.Var

var A_arbace_j2g_decls__init_A_const_102 any

var A_arbace_j2g_decls__init_A_const_103 *lang.Var

var A_arbace_j2g_decls__init_A_const_104 any

var A_arbace_j2g_decls__init_A_const_105 *lang.Var

var A_arbace_j2g_decls__init_A_const_106 any

var A_arbace_j2g_decls__init_A_const_107 *lang.Var

var A_arbace_j2g_decls__init_A_const_108 any

var A_arbace_j2g_decls__init_A_const_109 *lang.Var

var A_arbace_j2g_decls__init_A_const_110 any

var A_arbace_j2g_decls__init_A_init jrt.ClassInit

func A_arbace_j2g_decls__init_A_Init() { if !A_arbace_j2g_decls__init_A_init.Done() { A_arbace_j2g_decls__init_A_init.Run(A_arbace_j2g_decls__init_A_clinit) } }

func A_arbace_j2g_decls__init_A_clinit() { A_arbace_j2g_decls__init_A_clinit_p0(); A_arbace_j2g_decls__init_A_clinit_p1(); A_arbace_j2g_decls__init_A_clinit_p2(); A_arbace_j2g_decls__init_A_clinit_p3(); A_arbace_j2g_decls__init_A_clinit_p4(); A_arbace_j2g_decls__init_A_clinit_p5(); A_arbace_j2g_decls__init_A_clinit_p6(); A_arbace_j2g_decls__init_A_clinit_p7(); A_arbace_j2g_decls__init_A_clinit_p8() }

func A_arbace_j2g_decls__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_j2g_decls__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_286, 156); A_arbace_j2g_decls__init_A_const_0 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[45]); A_arbace_j2g_decls__init_A_const_1 = A_arbace_j2g_decls__init_A_const_pool.A[46]; A_arbace_j2g_decls__init_A_const_2 = A_arbace_j2g_decls__init_A_const_pool.A[47]; A_arbace_j2g_decls__init_A_const_3 = A_arbace_j2g_decls__init_A_const_pool.A[48]; A_arbace_j2g_decls__init_A_const_4 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[49]); A_arbace_j2g_decls__init_A_const_5 = A_arbace_j2g_decls__init_A_const_pool.A[50]; A_arbace_j2g_decls__init_A_const_6 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[51]); A_arbace_j2g_decls__init_A_const_7 = A_arbace_j2g_decls__init_A_const_pool.A[52]; A_arbace_j2g_decls__init_A_const_8 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[53]); A_arbace_j2g_decls__init_A_const_9 = A_arbace_j2g_decls__init_A_const_pool.A[54]; A_arbace_j2g_decls__init_A_const_10 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[55]); A_arbace_j2g_decls__init_A_const_11 = A_arbace_j2g_decls__init_A_const_pool.A[56]; A_arbace_j2g_decls__init_A_const_12 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[57]) }

func A_arbace_j2g_decls__init_A_clinit_p1() { A_arbace_j2g_decls__init_A_const_13 = A_arbace_j2g_decls__init_A_const_pool.A[58]; A_arbace_j2g_decls__init_A_const_14 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[59]); A_arbace_j2g_decls__init_A_const_15 = A_arbace_j2g_decls__init_A_const_pool.A[60]; A_arbace_j2g_decls__init_A_const_16 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[61]); A_arbace_j2g_decls__init_A_const_17 = A_arbace_j2g_decls__init_A_const_pool.A[62]; A_arbace_j2g_decls__init_A_const_18 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[63]); A_arbace_j2g_decls__init_A_const_19 = A_arbace_j2g_decls__init_A_const_pool.A[64]; A_arbace_j2g_decls__init_A_const_20 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[65]); A_arbace_j2g_decls__init_A_const_21 = A_arbace_j2g_decls__init_A_const_pool.A[66]; A_arbace_j2g_decls__init_A_const_22 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[67]); A_arbace_j2g_decls__init_A_const_23 = A_arbace_j2g_decls__init_A_const_pool.A[68]; A_arbace_j2g_decls__init_A_const_24 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[69]); A_arbace_j2g_decls__init_A_const_25 = A_arbace_j2g_decls__init_A_const_pool.A[70] }

func A_arbace_j2g_decls__init_A_clinit_p2() { A_arbace_j2g_decls__init_A_const_26 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[71]); A_arbace_j2g_decls__init_A_const_27 = A_arbace_j2g_decls__init_A_const_pool.A[72]; A_arbace_j2g_decls__init_A_const_28 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[73]); A_arbace_j2g_decls__init_A_const_29 = A_arbace_j2g_decls__init_A_const_pool.A[74]; A_arbace_j2g_decls__init_A_const_30 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[75]); A_arbace_j2g_decls__init_A_const_31 = A_arbace_j2g_decls__init_A_const_pool.A[76]; A_arbace_j2g_decls__init_A_const_32 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[77]); A_arbace_j2g_decls__init_A_const_33 = A_arbace_j2g_decls__init_A_const_pool.A[78]; A_arbace_j2g_decls__init_A_const_34 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[79]); A_arbace_j2g_decls__init_A_const_35 = A_arbace_j2g_decls__init_A_const_pool.A[80]; A_arbace_j2g_decls__init_A_const_36 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[81]); A_arbace_j2g_decls__init_A_const_37 = A_arbace_j2g_decls__init_A_const_pool.A[82]; A_arbace_j2g_decls__init_A_const_38 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[83]) }

func A_arbace_j2g_decls__init_A_clinit_p3() { A_arbace_j2g_decls__init_A_const_39 = A_arbace_j2g_decls__init_A_const_pool.A[84]; A_arbace_j2g_decls__init_A_const_40 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[85]); A_arbace_j2g_decls__init_A_const_41 = A_arbace_j2g_decls__init_A_const_pool.A[86]; A_arbace_j2g_decls__init_A_const_42 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[87]); A_arbace_j2g_decls__init_A_const_43 = A_arbace_j2g_decls__init_A_const_pool.A[88]; A_arbace_j2g_decls__init_A_const_44 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[89]); A_arbace_j2g_decls__init_A_const_45 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[90]); A_arbace_j2g_decls__init_A_const_46 = A_arbace_j2g_decls__init_A_const_pool.A[91]; A_arbace_j2g_decls__init_A_const_47 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[92]); A_arbace_j2g_decls__init_A_const_48 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[93]); A_arbace_j2g_decls__init_A_const_49 = A_arbace_j2g_decls__init_A_const_pool.A[94]; A_arbace_j2g_decls__init_A_const_50 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[95]); A_arbace_j2g_decls__init_A_const_51 = A_arbace_j2g_decls__init_A_const_pool.A[96] }

func A_arbace_j2g_decls__init_A_clinit_p4() { A_arbace_j2g_decls__init_A_const_52 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[97]); A_arbace_j2g_decls__init_A_const_53 = A_arbace_j2g_decls__init_A_const_pool.A[98]; A_arbace_j2g_decls__init_A_const_54 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[99]); A_arbace_j2g_decls__init_A_const_55 = A_arbace_j2g_decls__init_A_const_pool.A[100]; A_arbace_j2g_decls__init_A_const_56 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[101]); A_arbace_j2g_decls__init_A_const_57 = A_arbace_j2g_decls__init_A_const_pool.A[102]; A_arbace_j2g_decls__init_A_const_58 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[103]); A_arbace_j2g_decls__init_A_const_59 = A_arbace_j2g_decls__init_A_const_pool.A[104]; A_arbace_j2g_decls__init_A_const_60 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[105]); A_arbace_j2g_decls__init_A_const_61 = A_arbace_j2g_decls__init_A_const_pool.A[106]; A_arbace_j2g_decls__init_A_const_62 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[107]); A_arbace_j2g_decls__init_A_const_63 = A_arbace_j2g_decls__init_A_const_pool.A[108]; A_arbace_j2g_decls__init_A_const_64 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[109]) }

func A_arbace_j2g_decls__init_A_clinit_p5() { A_arbace_j2g_decls__init_A_const_65 = A_arbace_j2g_decls__init_A_const_pool.A[110]; A_arbace_j2g_decls__init_A_const_66 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[111]); A_arbace_j2g_decls__init_A_const_67 = A_arbace_j2g_decls__init_A_const_pool.A[112]; A_arbace_j2g_decls__init_A_const_68 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[113]); A_arbace_j2g_decls__init_A_const_69 = A_arbace_j2g_decls__init_A_const_pool.A[114]; A_arbace_j2g_decls__init_A_const_70 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[115]); A_arbace_j2g_decls__init_A_const_71 = A_arbace_j2g_decls__init_A_const_pool.A[116]; A_arbace_j2g_decls__init_A_const_72 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[117]); A_arbace_j2g_decls__init_A_const_73 = A_arbace_j2g_decls__init_A_const_pool.A[118]; A_arbace_j2g_decls__init_A_const_74 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[119]); A_arbace_j2g_decls__init_A_const_75 = A_arbace_j2g_decls__init_A_const_pool.A[120]; A_arbace_j2g_decls__init_A_const_76 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[121]); A_arbace_j2g_decls__init_A_const_77 = A_arbace_j2g_decls__init_A_const_pool.A[122] }

func A_arbace_j2g_decls__init_A_clinit_p6() { A_arbace_j2g_decls__init_A_const_78 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[123]); A_arbace_j2g_decls__init_A_const_79 = A_arbace_j2g_decls__init_A_const_pool.A[124]; A_arbace_j2g_decls__init_A_const_80 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[125]); A_arbace_j2g_decls__init_A_const_81 = A_arbace_j2g_decls__init_A_const_pool.A[126]; A_arbace_j2g_decls__init_A_const_82 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[127]); A_arbace_j2g_decls__init_A_const_83 = A_arbace_j2g_decls__init_A_const_pool.A[128]; A_arbace_j2g_decls__init_A_const_84 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[129]); A_arbace_j2g_decls__init_A_const_85 = A_arbace_j2g_decls__init_A_const_pool.A[130]; A_arbace_j2g_decls__init_A_const_86 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[131]); A_arbace_j2g_decls__init_A_const_87 = A_arbace_j2g_decls__init_A_const_pool.A[132]; A_arbace_j2g_decls__init_A_const_88 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[133]); A_arbace_j2g_decls__init_A_const_89 = A_arbace_j2g_decls__init_A_const_pool.A[134]; A_arbace_j2g_decls__init_A_const_90 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[135]) }

func A_arbace_j2g_decls__init_A_clinit_p7() { A_arbace_j2g_decls__init_A_const_91 = A_arbace_j2g_decls__init_A_const_pool.A[136]; A_arbace_j2g_decls__init_A_const_92 = A_arbace_j2g_decls__init_A_const_pool.A[137]; A_arbace_j2g_decls__init_A_const_93 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[138]); A_arbace_j2g_decls__init_A_const_94 = A_arbace_j2g_decls__init_A_const_pool.A[139]; A_arbace_j2g_decls__init_A_const_95 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[140]); A_arbace_j2g_decls__init_A_const_96 = A_arbace_j2g_decls__init_A_const_pool.A[141]; A_arbace_j2g_decls__init_A_const_97 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[142]); A_arbace_j2g_decls__init_A_const_98 = A_arbace_j2g_decls__init_A_const_pool.A[143]; A_arbace_j2g_decls__init_A_const_99 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[144]); A_arbace_j2g_decls__init_A_const_100 = A_arbace_j2g_decls__init_A_const_pool.A[145]; A_arbace_j2g_decls__init_A_const_101 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[146]); A_arbace_j2g_decls__init_A_const_102 = A_arbace_j2g_decls__init_A_const_pool.A[147]; A_arbace_j2g_decls__init_A_const_103 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[148]); A_arbace_j2g_decls__init_A_const_104 = A_arbace_j2g_decls__init_A_const_pool.A[149] }

func A_arbace_j2g_decls__init_A_clinit_p8() { A_arbace_j2g_decls__init_A_const_105 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[150]); A_arbace_j2g_decls__init_A_const_106 = A_arbace_j2g_decls__init_A_const_pool.A[151]; A_arbace_j2g_decls__init_A_const_107 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[152]); A_arbace_j2g_decls__init_A_const_108 = A_arbace_j2g_decls__init_A_const_pool.A[153]; A_arbace_j2g_decls__init_A_const_109 = lang.Var_Cast(A_arbace_j2g_decls__init_A_const_pool.A[154]); A_arbace_j2g_decls__init_A_const_110 = A_arbace_j2g_decls__init_A_const_pool.A[155] }

func A_arbace_j2g_decls__init_A_New() *A_arbace_j2g_decls__init_A { A_arbace_j2g_decls__init_A_Init(); t := &A_arbace_j2g_decls__init_A{}; t.Ctor(); return t }

func (t *A_arbace_j2g_decls__init_A) Ctor() {}

func (t *A_arbace_j2g_decls__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_j2g_decls__init_A) GetClass__Class() *jrt.Class { return A_arbace_j2g_decls__init_A_class }

func (t *A_arbace_j2g_decls__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_j2g_decls__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_j2g_decls__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_j2g_decls__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_j2g_decls__init_A); return ok }

func A_arbace_j2g_decls__init_A_Cast(x any) *A_arbace_j2g_decls__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_j2g_decls__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_j2g_decls__init_A_class)) }; return v }
