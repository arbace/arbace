//line aot_arbace_java_io.ae:1
package aot_arbace_java_io

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New() *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_io_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io_A_const_1); lang.IFn_Cast(A_arbace_java_io_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_25)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_26)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_28)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_29)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_31)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_java_io_eval1661000008_fn__1661000009_A_New() *A_arbace_java_io_eval1661000008_fn__1661000009_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000008_fn__1661000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_java_io_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_java_io_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_io_A_const_7.GetRawRoot__O(), A_arbace_java_io_A_const_8) }




























func A_arbace_java_io_eval1661000024_fn__1661000025_A_New() *A_arbace_java_io_eval1661000024_fn__1661000025_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000015__2_ any; var tmp1 any = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_New(); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_32, false); A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; G__1661000015__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_New_O(G__1661000015__2_); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_33, false); A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_New_O(p0 any) *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Ctor_O(c__G__1661000015 any) { t.F_G__1661000015 = c__G__1661000015 }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Invoke_O_O__O(self, gf__x__1661000029__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000029__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__1661000029__1) } else { var tmp1 any; var root_21 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = self; var arg_25 any = gf__x__1661000029__1; var arg_26 any = A_arbace_java_io_A_const_10; var arg_27 any = t.F_G__1661000015; if linked_22 == nil { tmp1 = ifn_23.Invoke_O_O_O_O__O(arg_24, arg_25, arg_26, arg_27) } else { tmp1 = linked_22.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_21, arg_24, arg_25, arg_26, arg_27) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__x__1661000029__1) } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_New() *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Invoke_O_O__O(self, gf__x__1661000026__1 any) any { var target_19 any = gf__x__1661000026__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_19 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_19) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_19, Lit_34, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_java_io_Coercions_A_Cast(target_19).As_file__O() } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_A_New() *A_arbace_java_io_eval1661000024_fn__1661000033_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000017__2_ any; var tmp1 any = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_New(); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_35, false); A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; G__1661000017__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_New_O(G__1661000017__2_); var tmp4 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_36, false); A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class = fncls__38d; tmp4 = fncls__38d } else { tmp4 = fncls__38 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_New_O(p0 any) *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Ctor_O(c__G__1661000017 any) { t.F_G__1661000017 = c__G__1661000017 }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Invoke_O_O__O(self, gf__x__1661000037__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000037__1)); if jrt.J2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__1661000037__1) } else { var tmp1 any; var root_31 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = self; var arg_35 any = gf__x__1661000037__1; var arg_36 any = A_arbace_java_io_A_const_10; var arg_37 any = t.F_G__1661000017; if linked_32 == nil { tmp1 = ifn_33.Invoke_O_O_O_O__O(arg_34, arg_35, arg_36, arg_37) } else { tmp1 = linked_32.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_31, arg_34, arg_35, arg_36, arg_37) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__x__1661000037__1) } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_New() *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Invoke_O_O__O(self, gf__x__1661000034__1 any) any { var target_29 any = gf__x__1661000034__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_29 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_29) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_29, Lit_37, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_java_io_Coercions_A_Cast(target_29).As_url__O() } }




func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New() *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_escaped_utf8_urlstring__GT_str_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Ctor() {}
//line :43:1
func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 any; var root_39 any = A_arbace_java_io_A_const_11.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_41 lang.IFn
//line :44:1
	if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any = s__0; var arg_43 any = Lit_4; var arg_44 any = Lit_5; if linked_40 == nil { tmp1 = ifn_41.Invoke_O_O_O__O(arg_42, arg_43, arg_44) } else { tmp1 = linked_40.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_39, arg_42, arg_43, arg_44) }
	return jrt.URLDecoder_Decode_String_String__String(jrt.String_Cast(tmp1), Lit_3).Ref()
}
func A_arbace_java_io_eval1661000047_fn__1661000048_A_New() *A_arbace_java_io_eval1661000047_fn__1661000048_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000047_fn__1661000048_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :47:1
func A_arbace_java_io_eval1661000047_fn__1661000050_A_New() *A_arbace_java_io_eval1661000047_fn__1661000050_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000047_fn__1661000050_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :47:1
func A_arbace_java_io_eval1661000053_fn__1661000054_A_New() *A_arbace_java_io_eval1661000053_fn__1661000054_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000053_fn__1661000054_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Invoke_O_O__O(self, s__1 any) any { return jrt.File_New_String(jrt.String_Cast(s__1)) }
//line :47:1
func A_arbace_java_io_eval1661000053_fn__1661000056_A_New() *A_arbace_java_io_eval1661000053_fn__1661000056_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000053_fn__1661000056_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Invoke_O_O__O(self, s__1 any) any {






	return lang.RT_ToUrl_String__URL_NoInit(jrt.String_Cast(s__1)).Ref() }
//line :47:1
func A_arbace_java_io_eval1661000059_fn__1661000060_A_New() *A_arbace_java_io_eval1661000059_fn__1661000060_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000059_fn__1661000060_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Invoke_O_O__O(self, f__1 any) any { return f__1 }
//line :47:1
func A_arbace_java_io_eval1661000059_fn__1661000062_A_New() *A_arbace_java_io_eval1661000059_fn__1661000062_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000059_fn__1661000062_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Invoke_O_O__O(self, f__1 any) any {










	return lang.RT_ToUrl_File__URL_NoInit(jrt.File_Cast(f__1)).Ref() }
//line :47:1
func A_arbace_java_io_eval1661000065_fn__1661000066_A_New() *A_arbace_java_io_eval1661000065_fn__1661000066_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000065_fn__1661000066_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Invoke_O_O__O(self, u__1 any) any { return u__1 }
//line :47:1
func A_arbace_java_io_eval1661000065_fn__1661000068_A_New() *A_arbace_java_io_eval1661000065_fn__1661000068_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000065_fn__1661000068_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Invoke_O_O__O(self, u__1 any) any {















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_38, jrt.NN(jrt.URL_Cast(u__1)).GetProtocol__String().Ref()) {
		var target_45 any; var root_46 any = A_arbace_java_io_A_const_12.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = jrt.NN(jrt.NN(jrt.URL_Cast(u__1)).GetFile__String()).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_java_io_A_const_13)).CharValue__C(), jrt.File_separatorChar).Ref(); if linked_47 == nil { target_45 = ifn_48.Invoke_O__O(arg_49) } else { target_45 = linked_47.(*A_arbace_java_io_escaped_utf8_urlstring__GT_str_A).Invoke_O_O__O(root_46, arg_49) }; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_45); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_45) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_Coercions_A_Cast(target_45).As_file__O() } else { return lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_45) } } else {
//line :63:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_39, nil), jrt.RefArrayOf(jrt.Object_class, nil, u__1))))) } }
//line :47:1
func A_arbace_java_io_eval1661000071_fn__1661000072_A_New() *A_arbace_java_io_eval1661000071_fn__1661000072_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000071_fn__1661000072_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Invoke_O_O__O(self, u__1 any) any {





















	return jrt.NN(jrt.URI_Cast(u__1)).ToURL__URL().Ref() }
//line :47:1
func A_arbace_java_io_eval1661000071_fn__1661000074_A_New() *A_arbace_java_io_eval1661000071_fn__1661000074_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000071_fn__1661000074_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Invoke_O_O__O(self, u__1 any) any {






















	var target_50 any; var target_51 any = u__1; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_51); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_51) }; tmp1 = tmp2; if tmp1 { target_50 = A_arbace_java_io_Coercions_A_Cast(target_51).As_url__O() } else { target_50 = lang.IFn_Cast(A_arbace_java_io_A_const_15.GetRawRoot__O()).Invoke_O__O(target_51) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_Coercions_A_InstanceOf(target_50); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_50) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_Coercions_A_Cast(target_50).As_file__O() } else { return lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_50)
	} }
func A_arbace_java_io_eval1661000091_fn__1661000092_A_New() *A_arbace_java_io_eval1661000091_fn__1661000092_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000082__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_New(); var tmp2 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class; if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_40, false); A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class = fncls__53d; tmp2 = fncls__53d } else { tmp2 = fncls__53 }; G__1661000082__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_New_O(G__1661000082__2_); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_41, false); A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Ctor_O(c__G__1661000082 any) { t.F_G__1661000082 = c__G__1661000082 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Invoke_O_O_O__O(self, gf__x__1661000097__1, gf__opts__1661000098__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000097__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000097__1, gf__opts__1661000098__2) } else { var tmp1 any; var root_54 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = self; var arg_58 any = gf__x__1661000097__1; var arg_59 any = A_arbace_java_io_A_const_16; var arg_60 any = t.F_G__1661000082; if linked_55 == nil { tmp1 = ifn_56.Invoke_O_O_O_O__O(arg_57, arg_58, arg_59, arg_60) } else { tmp1 = linked_55.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_54, arg_57, arg_58, arg_59, arg_60) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000097__1, gf__opts__1661000098__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_New() *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Invoke_O_O_O__O(self, gf__x__1661000093__1, gf__opts__1661000094__2 any) any { var target_52 any = gf__x__1661000093__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_52 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_52) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_52, Lit_42, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000094__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_52).Make_input_stream_O__O(gf__opts__1661000094__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_A_New() *A_arbace_java_io_eval1661000091_fn__1661000102_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000084__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_New(); var tmp2 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class = fncls__63d; tmp2 = fncls__63d } else { tmp2 = fncls__63 }; G__1661000084__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_New_O(G__1661000084__2_); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Ctor_O(c__G__1661000084 any) { t.F_G__1661000084 = c__G__1661000084 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Invoke_O_O_O__O(self, gf__x__1661000107__1, gf__opts__1661000108__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000107__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000107__1, gf__opts__1661000108__2) } else { var tmp1 any; var root_64 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = self; var arg_68 any = gf__x__1661000107__1; var arg_69 any = A_arbace_java_io_A_const_16; var arg_70 any = t.F_G__1661000084; if linked_65 == nil { tmp1 = ifn_66.Invoke_O_O_O_O__O(arg_67, arg_68, arg_69, arg_70) } else { tmp1 = linked_65.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_64, arg_67, arg_68, arg_69, arg_70) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000107__1, gf__opts__1661000108__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_New() *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Invoke_O_O_O__O(self, gf__x__1661000103__1, gf__opts__1661000104__2 any) any { var target_62 any = gf__x__1661000103__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_62 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_62) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_62, Lit_45, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000104__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_62).Make_output_stream_O__O(gf__opts__1661000104__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_A_New() *A_arbace_java_io_eval1661000091_fn__1661000112_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000078__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_New(); var tmp2 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class = fncls__73d; tmp2 = fncls__73d } else { tmp2 = fncls__73 }; G__1661000078__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_New_O(G__1661000078__2_); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Ctor_O(c__G__1661000078 any) { t.F_G__1661000078 = c__G__1661000078 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Invoke_O_O_O__O(self, gf__x__1661000117__1, gf__opts__1661000118__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000117__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000117__1, gf__opts__1661000118__2) } else { var tmp1 any; var root_74 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any = self; var arg_78 any = gf__x__1661000117__1; var arg_79 any = A_arbace_java_io_A_const_16; var arg_80 any = t.F_G__1661000078; if linked_75 == nil { tmp1 = ifn_76.Invoke_O_O_O_O__O(arg_77, arg_78, arg_79, arg_80) } else { tmp1 = linked_75.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_74, arg_77, arg_78, arg_79, arg_80) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000117__1, gf__opts__1661000118__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_New() *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Invoke_O_O_O__O(self, gf__x__1661000113__1, gf__opts__1661000114__2 any) any { var target_72 any = gf__x__1661000113__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_72 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_72) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_72, Lit_48, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000114__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_72).Make_reader_O__O(gf__opts__1661000114__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_A_New() *A_arbace_java_io_eval1661000091_fn__1661000122_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000080__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_New(); var tmp2 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class = fncls__83d; tmp2 = fncls__83d } else { tmp2 = fncls__83 }; G__1661000080__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_New_O(G__1661000080__2_); var tmp4 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class = fncls__91d; tmp4 = fncls__91d } else { tmp4 = fncls__91 }; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Ctor_O(c__G__1661000080 any) { t.F_G__1661000080 = c__G__1661000080 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Invoke_O_O_O__O(self, gf__x__1661000127__1, gf__opts__1661000128__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000127__1)); if jrt.J2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000127__1, gf__opts__1661000128__2) } else { var tmp1 any; var root_84 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_86 lang.IFn; if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = self; var arg_88 any = gf__x__1661000127__1; var arg_89 any = A_arbace_java_io_A_const_16; var arg_90 any = t.F_G__1661000080; if linked_85 == nil { tmp1 = ifn_86.Invoke_O_O_O_O__O(arg_87, arg_88, arg_89, arg_90) } else { tmp1 = linked_85.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_84, arg_87, arg_88, arg_89, arg_90) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000127__1, gf__opts__1661000128__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_New() *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Invoke_O_O_O__O(self, gf__x__1661000123__1, gf__opts__1661000124__2 any) any { var target_82 any = gf__x__1661000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_82 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_82) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_82, Lit_51, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000124__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_82).Make_writer_O__O(gf__opts__1661000124__2) } }
















func A_arbace_java_io_reader_A_New() *A_arbace_java_io_reader_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_reader_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_java_io_reader_A) Ctor() {}
//line :89:1
func (t *A_arbace_java_io_reader_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {















	var target_92 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_92); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_92) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_92); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_93 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_94 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_93, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_95 lang.IFn; if linked_94 == nil { ifn_95 = lang.IFn_Cast(root_93) } else { ifn_95 = nil }; var arg_96 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_97 any = opts__1; if linked_94 == nil { tmp4 = ifn_95.Invoke_O_O__O(arg_96, arg_97) } else { tmp4 = linked_94.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_93, arg_96, arg_97) } } else { tmp4 = nil }; return tmp3.Make_reader_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_98 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_102 any = opts__1; if linked_99 == nil { tmp6 = ifn_100.Invoke_O_O__O(arg_101, arg_102) } else { tmp6 = linked_99.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_98, arg_101, arg_102) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_92, tmp6)
	} }
func A_arbace_java_io_writer_A_New() *A_arbace_java_io_writer_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_writer_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_java_io_writer_A) Ctor() {}
//line :107:1
func (t *A_arbace_java_io_writer_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_103 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_103); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_103) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_103); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_104 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_105 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_104, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_106 lang.IFn; if linked_105 == nil { ifn_106 = lang.IFn_Cast(root_104) } else { ifn_106 = nil }; var arg_107 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_108 any = opts__1; if linked_105 == nil { tmp4 = ifn_106.Invoke_O_O__O(arg_107, arg_108) } else { tmp4 = linked_105.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_104, arg_107, arg_108) } } else { tmp4 = nil }; return tmp3.Make_writer_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_20.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_109 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_110 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_109, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_111 lang.IFn; if linked_110 == nil { ifn_111 = lang.IFn_Cast(root_109) } else { ifn_111 = nil }; var arg_112 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_113 any = opts__1; if linked_110 == nil { tmp6 = ifn_111.Invoke_O_O__O(arg_112, arg_113) } else { tmp6 = linked_110.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_109, arg_112, arg_113) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_103, tmp6)
	} }
func A_arbace_java_io_input_stream_A_New() *A_arbace_java_io_input_stream_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_input_stream_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_java_io_input_stream_A) Ctor() {}
//line :124:1
func (t *A_arbace_java_io_input_stream_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_114 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_114); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_114) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_114); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_115 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_119 any = opts__1; if linked_116 == nil { tmp4 = ifn_117.Invoke_O_O__O(arg_118, arg_119) } else { tmp4 = linked_116.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_115, arg_118, arg_119) } } else { tmp4 = nil }; return tmp3.Make_input_stream_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_120 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_121 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_120, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_122 lang.IFn; if linked_121 == nil { ifn_122 = lang.IFn_Cast(root_120) } else { ifn_122 = nil }; var arg_123 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_124 any = opts__1; if linked_121 == nil { tmp6 = ifn_122.Invoke_O_O__O(arg_123, arg_124) } else { tmp6 = linked_121.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_120, arg_123, arg_124) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_114, tmp6)
	} }
func A_arbace_java_io_output_stream_A_New() *A_arbace_java_io_output_stream_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_output_stream_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_java_io_output_stream_A) Ctor() {}
//line :141:1
func (t *A_arbace_java_io_output_stream_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_125 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_125); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_125) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_125); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_126 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_130 any = opts__1; if linked_127 == nil { tmp4 = ifn_128.Invoke_O_O__O(arg_129, arg_130) } else { tmp4 = linked_127.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_126, arg_129, arg_130) } } else { tmp4 = nil }; return tmp3.Make_output_stream_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_131 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_132 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_131, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_133 lang.IFn; if linked_132 == nil { ifn_133 = lang.IFn_Cast(root_131) } else { ifn_133 = nil }; var arg_134 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_135 any = opts__1; if linked_132 == nil { tmp6 = ifn_133.Invoke_O_O__O(arg_134, arg_135) } else { tmp6 = linked_132.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_131, arg_134, arg_135) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_125, tmp6)
	} }
func A_arbace_java_io_append_QMARK__A_New() *A_arbace_java_io_append_QMARK__A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_append_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_java_io_append_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_java_io_append_QMARK__A) Invoke_O_O__O(self, opts__0 any) any {
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_java_io_A_const_23.Invoke_O__O(opts__0))).Ref()
}
func A_arbace_java_io_encoding_A_New() *A_arbace_java_io_encoding_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_encoding_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_java_io_encoding_A) Ctor() {}
//line :161:1
func (t *A_arbace_java_io_encoding_A) Invoke_O_O__O(self, opts__0 any) any { var or__1927000174__auto____2 any = A_arbace_java_io_A_const_24.Invoke_O__O(opts__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return Lit_3 } }

func A_arbace_java_io_buffer_size_A_New() *A_arbace_java_io_buffer_size_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_buffer_size_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_java_io_buffer_size_A) Ctor() {}
//line :164:1
func (t *A_arbace_java_io_buffer_size_A) Invoke_O_O__O(self, opts__0 any) any { var or__1927000174__auto____2 any = A_arbace_java_io_A_const_25.Invoke_O__O(opts__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_java_io_A_const_26 } }


func A_arbace_java_io_fn__1661000144_A_New() *A_arbace_java_io_fn__1661000144_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000144_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_java_io_fn__1661000144_A) Ctor() {}
//line :168:1
func (t *A_arbace_java_io_fn__1661000144_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var target_136 any; var target_137 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_137); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_137) }; tmp1 = tmp2; if tmp1 { target_136 = A_arbace_java_io_IOFactory_A_Cast(target_137).Make_input_stream_O__O(opts__1) } else { target_136 = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_137, opts__1) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_136); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_136) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_136).Make_reader_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()).Invoke_O_O__O(target_136, opts__1) } }
func A_arbace_java_io_fn__1661000146_A_New() *A_arbace_java_io_fn__1661000146_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000146_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_java_io_fn__1661000146_A) Ctor() {}
//line :169:1
func (t *A_arbace_java_io_fn__1661000146_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var target_138 any; var target_139 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_139); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_139) }; tmp1 = tmp2; if tmp1 { target_138 = A_arbace_java_io_IOFactory_A_Cast(target_139).Make_output_stream_O__O(opts__1) } else { target_138 = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_139, opts__1) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_138); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_138) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_138).Make_writer_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_20.GetRawRoot__O()).Invoke_O_O__O(target_138, opts__1) } }
func A_arbace_java_io_fn__1661000148_A_New() *A_arbace_java_io_fn__1661000148_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000148_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_java_io_fn__1661000148_A) Ctor() {}
//line :170:1
func (t *A_arbace_java_io_fn__1661000148_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_57), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0), nil))))) }


func A_arbace_java_io_fn__1661000150_A_New() *A_arbace_java_io_fn__1661000150_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000150_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_java_io_fn__1661000150_A) Ctor() {}
//line :173:1
func (t *A_arbace_java_io_fn__1661000150_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0), nil))))) }



func A_arbace_java_io_inputstream__GT_reader_A_New() *A_arbace_java_io_inputstream__GT_reader_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_inputstream__GT_reader_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_java_io_inputstream__GT_reader_A) Ctor() {}
//line :177:1
func (t *A_arbace_java_io_inputstream__GT_reader_A) Invoke_O_O_O__O(self, is__0, opts__1 any) any {

	var target_148 any; var tmp1 jrt.InputStream_I = jrt.InputStream_Cast(is__0); var tmp2 any; var root_149 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_150 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_149, A_arbace_java_io_encoding_A_fn_class); var ifn_151 lang.IFn; if linked_150 == nil { ifn_151 = lang.IFn_Cast(root_149) } else { ifn_151 = nil }; var arg_152 any = opts__1; if linked_150 == nil { tmp2 = ifn_151.Invoke_O__O(arg_152) } else { tmp2 = linked_150.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_149, arg_152) }; target_148 = jrt.InputStreamReader_New_InputStream_String(tmp1, jrt.String_Cast(tmp2)); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_148); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_148) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_148).Make_reader_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()).Invoke_O_O__O(target_148, opts__1)
	} }
func A_arbace_java_io_outputstream__GT_writer_A_New() *A_arbace_java_io_outputstream__GT_writer_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_outputstream__GT_writer_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_java_io_outputstream__GT_writer_A) Ctor() {}
//line :181:1
func (t *A_arbace_java_io_outputstream__GT_writer_A) Invoke_O_O_O__O(self, os__0, opts__1 any) any {

	var target_153 any; var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(os__0); var tmp2 any; var root_154 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_154, A_arbace_java_io_encoding_A_fn_class); var ifn_156 lang.IFn; if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = opts__1; if linked_155 == nil { tmp2 = ifn_156.Invoke_O__O(arg_157) } else { tmp2 = linked_155.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_154, arg_157) }; target_153 = jrt.OutputStreamWriter_New_OutputStream_String(tmp1, jrt.String_Cast(tmp2)); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_153); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_153) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_153).Make_writer_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_20.GetRawRoot__O()).Invoke_O_O__O(target_153, opts__1)
	}
}


func A_arbace_java_io_eval1661000154_fn__1661000155_A_New() *A_arbace_java_io_eval1661000154_fn__1661000155_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000154_fn__1661000155_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Ctor() {}
//line :188:1
func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }





func A_arbace_java_io_eval1661000158_fn__1661000159_A_New() *A_arbace_java_io_eval1661000158_fn__1661000159_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000158_fn__1661000159_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Ctor() {}
//line :194:1
func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedInputStream_New_InputStream(jrt.InputStream_Cast(x__1)) }





func A_arbace_java_io_eval1661000162_fn__1661000163_A_New() *A_arbace_java_io_eval1661000162_fn__1661000163_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000162_fn__1661000163_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Ctor() {}
//line :200:1
func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedReader_New_Reader(jrt.Reader_Cast(x__1)) }




func A_arbace_java_io_eval1661000166_fn__1661000167_A_New() *A_arbace_java_io_eval1661000166_fn__1661000167_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000166_fn__1661000167_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Ctor() {}
//line :205:1
func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }




func A_arbace_java_io_eval1661000170_fn__1661000171_A_New() *A_arbace_java_io_eval1661000170_fn__1661000171_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000170_fn__1661000171_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Ctor() {}
//line :210:1
func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedWriter_New_Writer(jrt.Writer_Cast(x__1)) }




func A_arbace_java_io_eval1661000174_fn__1661000175_A_New() *A_arbace_java_io_eval1661000174_fn__1661000175_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000174_fn__1661000175_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Ctor() {}
//line :215:1
func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }




func A_arbace_java_io_eval1661000178_fn__1661000179_A_New() *A_arbace_java_io_eval1661000178_fn__1661000179_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000178_fn__1661000179_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Ctor() {}
//line :220:1
func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedOutputStream_New_OutputStream(jrt.OutputStream_Cast(x__1)) }





func A_arbace_java_io_eval1661000182_fn__1661000183_A_New() *A_arbace_java_io_eval1661000182_fn__1661000183_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000182_fn__1661000183_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Ctor() {}
//line :226:1
func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }





func A_arbace_java_io_eval1661000186_fn__1661000187_A_New() *A_arbace_java_io_eval1661000186_fn__1661000187_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000186_fn__1661000187_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Ctor() {}
//line :232:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_158 any = jrt.FileInputStream_New_File(jrt.File_Cast(x__1)); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_158); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_158) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_158).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_158, opts__2) } }
func A_arbace_java_io_eval1661000186_fn__1661000189_A_New() *A_arbace_java_io_eval1661000186_fn__1661000189_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000186_fn__1661000189_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Ctor() {}
//line :233:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_159 any; var tmp1 *jrt.File = jrt.File_Cast(x__1); var tmp2 any; var root_160 any = A_arbace_java_io_A_const_29.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_java_io_append_QMARK__A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = opts__2; if linked_161 == nil { tmp2 = ifn_162.Invoke_O__O(arg_163) } else { tmp2 = linked_161.(*A_arbace_java_io_append_QMARK__A).Invoke_O_O__O(root_160, arg_163) }; target_159 = jrt.FileOutputStream_New_File_Z(tmp1, jrt.NN(jrt.Boolean_Cast(tmp2)).BooleanValue__Z()); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_159); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_159) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_159).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_159, opts__2) } }




func A_arbace_java_io_eval1661000192_fn__1661000193_A_New() *A_arbace_java_io_eval1661000192_fn__1661000193_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000192_fn__1661000193_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Ctor() {}
//line :238:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any {
	var target_164 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_38, jrt.NN(jrt.URL_Cast(x__1)).GetProtocol__String().Ref()) { var tmp1 any; var target_165 any = x__1; var tmp2 bool; var tmp3 bool
		tmp3 = A_arbace_java_io_Coercions_A_InstanceOf(target_165); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_165) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_Coercions_A_Cast(target_165).As_file__O() } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_165) }
//line :240:1
		target_164 = jrt.FileInputStream_New_File(jrt.File_Cast(tmp1)) } else {

			target_164 = jrt.NN(jrt.URL_Cast(x__1)).OpenStream__InputStream() }
//line :239:1
	var tmp4 bool; var tmp5 bool; tmp5 = A_arbace_java_io_IOFactory_A_InstanceOf(target_164); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_164) }; tmp4 = tmp5; if tmp4 { return A_arbace_java_io_IOFactory_A_Cast(target_164).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_164, opts__2)
	}
}

func A_arbace_java_io_eval1661000192_fn__1661000195_A_New() *A_arbace_java_io_eval1661000192_fn__1661000195_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000192_fn__1661000195_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Ctor() {}
//line :243:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_38, jrt.NN(jrt.URL_Cast(x__1)).GetProtocol__String().Ref()) {
		var target_166 any; var target_167 any = x__1; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_167); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_167) }; tmp1 = tmp2; if tmp1 { target_166 = A_arbace_java_io_Coercions_A_Cast(target_167).As_file__O() } else { target_166 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_167) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_166); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_166) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_166).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_166, opts__2) } } else {
//line :244:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, nil, x__1, nil)))))
		}
}




func A_arbace_java_io_eval1661000198_fn__1661000199_A_New() *A_arbace_java_io_eval1661000198_fn__1661000199_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000198_fn__1661000199_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Ctor() {}
//line :251:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_168 any = jrt.NN(jrt.URI_Cast(x__1)).ToURL__URL().Ref(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_168); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_168) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_168).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_168, opts__2) } }
func A_arbace_java_io_eval1661000198_fn__1661000201_A_New() *A_arbace_java_io_eval1661000198_fn__1661000201_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000198_fn__1661000201_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Ctor() {}
//line :252:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_169 any = jrt.NN(jrt.URI_Cast(x__1)).ToURL__URL().Ref(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_169); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_169) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_169).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_169, opts__2) } }




func A_arbace_java_io_eval1661000204_fn__1661000205_A_New() *A_arbace_java_io_eval1661000204_fn__1661000205_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000204_fn__1661000205_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Ctor() {}
//line :257:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var target_170 any = lang.RT_ToUrl_String__URL_NoInit(jrt.String_Cast(x__1)).Ref(); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_java_io_IOFactory_A_InstanceOf(target_170); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_170) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_170).Make_input_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_170, opts__2) } }
//line :257:1
	return nil }(); if tmp4 != nil { if jrt.MalformedURLException_InstanceOf(tmp4) { var e__5 *jrt.MalformedURLException = jrt.MalformedURLException_Cast(tmp4); var target_171 any = jrt.File_New_String(jrt.String_Cast(x__1)); var tmp5 bool; var tmp6 bool; _ = e__5



		tmp6 = A_arbace_java_io_IOFactory_A_InstanceOf(target_171); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_171) }; tmp5 = tmp6; if tmp5 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_171).Make_input_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_171, opts__2) } } else {
//line :257:1
			panic(tmp4) } }; return tmp1 }




func A_arbace_java_io_eval1661000204_fn__1661000207_A_New() *A_arbace_java_io_eval1661000204_fn__1661000207_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000204_fn__1661000207_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Ctor() {}
//line :262:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var target_172 any = lang.RT_ToUrl_String__URL_NoInit(jrt.String_Cast(x__1)).Ref(); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_java_io_IOFactory_A_InstanceOf(target_172); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_172) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_172).Make_output_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_172, opts__2) } }
//line :262:1
	return nil }(); if tmp4 != nil { if jrt.MalformedURLException_InstanceOf(tmp4) { var err__5 *jrt.MalformedURLException = jrt.MalformedURLException_Cast(tmp4); var target_173 any = jrt.File_New_String(jrt.String_Cast(x__1)); var tmp5 bool; var tmp6 bool; _ = err__5



		tmp6 = A_arbace_java_io_IOFactory_A_InstanceOf(target_173); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_173) }; tmp5 = tmp6; if tmp5 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_173).Make_output_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_173, opts__2) } } else {
//line :262:1
			panic(tmp4) } }; return tmp1 }








func A_arbace_java_io_eval1661000210_fn__1661000211_A_New() *A_arbace_java_io_eval1661000210_fn__1661000211_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000210_fn__1661000211_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Ctor() {}
//line :271:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_174 any = jrt.Socket_Cast(x__1).GetInputStream__InputStream(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_174); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_174) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_174).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_174, opts__2) } }
func A_arbace_java_io_eval1661000210_fn__1661000213_A_New() *A_arbace_java_io_eval1661000210_fn__1661000213_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000210_fn__1661000213_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Ctor() {}
//line :272:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_175 any = jrt.Socket_Cast(x__1).GetOutputStream__OutputStream(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_175); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_175) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_175).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_175, opts__2) } }




func A_arbace_java_io_eval1661000216_fn__1661000217_A_New() *A_arbace_java_io_eval1661000216_fn__1661000217_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000216_fn__1661000217_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Ctor() {}
//line :277:1
func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_176 any = jrt.ByteArrayInputStream_New_B1(jrt.J2g_CastArray[*jrt.ByteArray](x__1, jrt.Prim_byte.ArrayClass())); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_176); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_176) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_176).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_176, opts__2) } }




func A_arbace_java_io_eval1661000220_fn__1661000221_A_New() *A_arbace_java_io_eval1661000220_fn__1661000221_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000220_fn__1661000221_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Ctor() {}
//line :282:1
func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_177 any = jrt.CharArrayReader_New_C1(jrt.J2g_CastArray[*jrt.CharArray](x__1, jrt.Prim_char.ArrayClass())); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_177); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_177) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_177).Make_reader_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()).Invoke_O_O__O(target_177, opts__2) } }








func A_arbace_java_io_eval1661000226_fn__1661000227_A_New() *A_arbace_java_io_eval1661000226_fn__1661000227_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000226_fn__1661000227_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Ctor() {}
//line :291:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1), nil))))) }


func A_arbace_java_io_eval1661000226_fn__1661000229_A_New() *A_arbace_java_io_eval1661000226_fn__1661000229_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000226_fn__1661000229_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Ctor() {}
//line :294:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_56), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1), nil))))) }








func A_arbace_java_io_eval1661000232_fn__1661000233_A_New() *A_arbace_java_io_eval1661000232_fn__1661000233_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000232_fn__1661000233_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Ctor() {}
//line :303:1
func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var tmp1 any; var root_186 any = A_arbace_java_io_A_const_30.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_type_A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = input__1; if linked_187 == nil { tmp1 = ifn_188.Invoke_O__O(arg_189) } else { tmp1 = linked_187.(*aot_arbace_core.A_arbace_core_type_A).Invoke_O_O__O(root_186, arg_189) }; var tmp2 any = tmp1; var tmp3 any; var root_190 any = A_arbace_java_io_A_const_30.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_type_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = output__2; if linked_191 == nil { tmp3 = ifn_192.Invoke_O__O(arg_193) } else { tmp3 = linked_191.(*aot_arbace_core.A_arbace_core_type_A).Invoke_O_O__O(root_190, arg_193) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }

func A_arbace_java_io_eval1661000236_fn__1661000237_A_New() *A_arbace_java_io_eval1661000236_fn__1661000237_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000236_fn__1661000237_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Ctor() {}
//line :305:1
func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_194 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_196 lang.IFn
																if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = jrt.Byte_TYPE.Ref(); var arg_198 any; var root_199 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_199, A_arbace_java_io_buffer_size_A_fn_class); var ifn_201 lang.IFn; if linked_200 == nil { ifn_201 = lang.IFn_Cast(root_199) } else { ifn_201 = nil }; var arg_202 any = opts__3; if linked_200 == nil { arg_198 = ifn_201.Invoke_O__O(arg_202) } else { arg_198 = linked_200.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_199, arg_202) }; if linked_195 == nil { buffer__4 = ifn_196.Invoke_O_O__O(arg_197, arg_198) } else { buffer__4 = linked_195.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_194, arg_197, arg_198) }
//line :305:1
L1: for { var size__5 int32 = jrt.InputStream_Cast(input__1).Read_B1__I(jrt.J2g_CastArray[*jrt.ByteArray](buffer__4, jrt.Prim_byte.ArrayClass()))



	if lang.Numbers_IsPos_J__Z_NoInit(int64(size__5)) {
		jrt.OutputStream_Cast(output__2).Write_B1_I_I__V(jrt.J2g_CastArray[*jrt.ByteArray](buffer__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), size__5)
		continue L1 } else {
//line :309:1
			return nil } } }; /*line :305:1*/panic("j2g: unreachable") }







func A_arbace_java_io_eval1661000240_fn__1661000241_A_New() *A_arbace_java_io_eval1661000240_fn__1661000241_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000240_fn__1661000241_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Ctor() {}
//line :313:1
func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_203 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_203, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_205 lang.IFn
																if linked_204 == nil { ifn_205 = lang.IFn_Cast(root_203) } else { ifn_205 = nil }; var arg_206 any = jrt.Character_TYPE.Ref(); var arg_207 any; var root_208 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_208, A_arbace_java_io_buffer_size_A_fn_class); var ifn_210 lang.IFn; if linked_209 == nil { ifn_210 = lang.IFn_Cast(root_208) } else { ifn_210 = nil }; var arg_211 any = opts__3; if linked_209 == nil { arg_207 = ifn_210.Invoke_O__O(arg_211) } else { arg_207 = linked_209.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_208, arg_211) }; if linked_204 == nil { buffer__4 = ifn_205.Invoke_O_O__O(arg_206, arg_207) } else { buffer__4 = linked_204.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_203, arg_206, arg_207) }
//line :313:1
	var in__5 any; var tmp1 jrt.InputStream_I = jrt.InputStream_Cast(input__1); var tmp2 any; var root_212 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, A_arbace_java_io_encoding_A_fn_class); var ifn_214 lang.IFn

	if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = opts__3; if linked_213 == nil { tmp2 = ifn_214.Invoke_O__O(arg_215) } else { tmp2 = linked_213.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_212, arg_215) }
//line :313:1
	in__5 = jrt.InputStreamReader_New_InputStream_String(tmp1, jrt.String_Cast(tmp2)); L1: for { var size__6 int32 = jrt.InputStreamReader_Cast(in__5).Read_C1_I_I__I(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), lang.RT_Alength_C1__I_NoInit(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass())))




		if lang.Numbers_IsPos_J__Z_NoInit(int64(size__6)) {
			jrt.Writer_Cast(output__2).Write_C1_I_I__V(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), size__6)
			continue L1 } else {
//line :318:1
				return nil } } }; /*line :313:1*/panic("j2g: unreachable") }








func A_arbace_java_io_eval1661000244_fn__1661000245_A_New() *A_arbace_java_io_eval1661000244_fn__1661000245_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000244_fn__1661000245_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Ctor() {}
//line :322:1
func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var out__4 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(input__1, out__4, opts__3)
//line :322:1
	return nil }();
	jrt.FileOutputStream_Cast(out__4).Close__V(); if /*line :322:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000248_fn__1661000249_A_New() *A_arbace_java_io_eval1661000248_fn__1661000249_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000248_fn__1661000249_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Ctor() {}
//line :326:1
func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_216 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_218 lang.IFn
																if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = jrt.Character_TYPE.Ref(); var arg_220 any; var root_221 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, A_arbace_java_io_buffer_size_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = opts__3; if linked_222 == nil { arg_220 = ifn_223.Invoke_O__O(arg_224) } else { arg_220 = linked_222.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_221, arg_224) }; if linked_217 == nil { buffer__4 = ifn_218.Invoke_O_O__O(arg_219, arg_220) } else { buffer__4 = linked_217.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_216, arg_219, arg_220) }
//line :326:1
	var out__5 any; var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(output__2); var tmp2 any; var root_225 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_225, A_arbace_java_io_encoding_A_fn_class); var ifn_227 lang.IFn

	if linked_226 == nil { ifn_227 = lang.IFn_Cast(root_225) } else { ifn_227 = nil }; var arg_228 any = opts__3; if linked_226 == nil { tmp2 = ifn_227.Invoke_O__O(arg_228) } else { tmp2 = linked_226.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_225, arg_228) }
//line :326:1
	out__5 = jrt.OutputStreamWriter_New_OutputStream_String(tmp1, jrt.String_Cast(tmp2)); L1: for { var size__6 int32 = jrt.Reader_Cast(input__1).Read_C1__I(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()))




		if lang.Numbers_IsPos_J__Z_NoInit(int64(size__6)) {

			jrt.OutputStreamWriter_Cast(out__5).Write_C1_I_I__V(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), size__6)
			continue L1 } else {
				jrt.OutputStreamWriter_Cast(out__5).Flush__V(); return nil } } }; /*line :326:1*/panic("j2g: unreachable") }










func A_arbace_java_io_eval1661000252_fn__1661000253_A_New() *A_arbace_java_io_eval1661000252_fn__1661000253_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000252_fn__1661000253_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Ctor() {}
//line :337:1
func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_229 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_229, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_231 lang.IFn
																if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = jrt.Character_TYPE.Ref(); var arg_233 any; var root_234 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, A_arbace_java_io_buffer_size_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any = opts__3; if linked_235 == nil { arg_233 = ifn_236.Invoke_O__O(arg_237) } else { arg_233 = linked_235.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_234, arg_237) }; if linked_230 == nil { buffer__4 = ifn_231.Invoke_O_O__O(arg_232, arg_233) } else { buffer__4 = linked_230.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_229, arg_232, arg_233) }
//line :337:1
L1: for { var size__5 int32 = jrt.Reader_Cast(input__1).Read_C1__I(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()))



	if lang.Numbers_IsPos_J__Z_NoInit(int64(size__5)) {
		jrt.Writer_Cast(output__2).Write_C1_I_I__V(jrt.J2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I_NoInit(0), size__5)
		continue L1 } else {
//line :341:1
			return nil } } }; /*line :337:1*/panic("j2g: unreachable") }







func A_arbace_java_io_eval1661000256_fn__1661000257_A_New() *A_arbace_java_io_eval1661000256_fn__1661000257_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000256_fn__1661000257_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Ctor() {}
//line :345:1
func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var out__4 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(input__1, out__4, opts__3)
//line :345:1
	return nil }();
	jrt.FileOutputStream_Cast(out__4).Close__V(); if /*line :345:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000260_fn__1661000261_A_New() *A_arbace_java_io_eval1661000260_fn__1661000261_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000260_fn__1661000261_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Ctor() {}
//line :349:1
func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(in__4, output__2, opts__3)
//line :349:1
	return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :349:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000264_fn__1661000265_A_New() *A_arbace_java_io_eval1661000264_fn__1661000265_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000264_fn__1661000265_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Ctor() {}
//line :353:1
func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(in__4, output__2, opts__3)
//line :353:1
	return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :353:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000268_fn__1661000269_A_New() *A_arbace_java_io_eval1661000268_fn__1661000269_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000268_fn__1661000269_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Ctor() {}
//line :357:1
func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__7 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	jrt.Long_ValueOf_J__Long_NoInit(jrt.InputStream_Cast(in__4).TransferTo_OutputStream__J(jrt.OutputStream_Cast(out__7)))
//line :357:1
	tmp1 = nil; return nil }()
	jrt.FileOutputStream_Cast(out__7).Close__V()
//line :357:1
	if tmp2 != nil { panic(tmp2) } }; return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :357:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }





func A_arbace_java_io_eval1661000272_fn__1661000273_A_New() *A_arbace_java_io_eval1661000272_fn__1661000273_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000272_fn__1661000273_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Ctor() {}
//line :363:1
func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000276_fn__1661000277_A_New() *A_arbace_java_io_eval1661000276_fn__1661000277_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000276_fn__1661000277_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Ctor() {}
//line :366:1
func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000280_fn__1661000281_A_New() *A_arbace_java_io_eval1661000280_fn__1661000281_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000280_fn__1661000281_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Ctor() {}
//line :369:1
func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000284_fn__1661000285_A_New() *A_arbace_java_io_eval1661000284_fn__1661000285_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000284_fn__1661000285_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Ctor() {}
//line :372:1
func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.J2g_CastArray[*jrt.CharArray](input__1, jrt.Prim_char.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000288_fn__1661000289_A_New() *A_arbace_java_io_eval1661000288_fn__1661000289_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000288_fn__1661000289_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Ctor() {}
//line :375:1
func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.J2g_CastArray[*jrt.CharArray](input__1, jrt.Prim_char.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000292_fn__1661000293_A_New() *A_arbace_java_io_eval1661000292_fn__1661000293_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000292_fn__1661000293_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Ctor() {}
//line :378:1
func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.J2g_CastArray[*jrt.CharArray](input__1, jrt.Prim_char.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000296_fn__1661000297_A_New() *A_arbace_java_io_eval1661000296_fn__1661000297_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000296_fn__1661000297_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Ctor() {}
//line :381:1
func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.J2g_CastArray[*jrt.ByteArray](input__1, jrt.Prim_byte.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000300_fn__1661000301_A_New() *A_arbace_java_io_eval1661000300_fn__1661000301_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000300_fn__1661000301_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Ctor() {}
//line :384:1
func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.J2g_CastArray[*jrt.ByteArray](input__1, jrt.Prim_byte.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000304_fn__1661000305_A_New() *A_arbace_java_io_eval1661000304_fn__1661000305_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000304_fn__1661000305_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Ctor() {}
//line :387:1
func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.J2g_CastArray[*jrt.ByteArray](input__1, jrt.Prim_byte.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_copy_A_New() *A_arbace_java_io_copy_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_copy_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_java_io_copy_A) Ctor() {}
//line :390:1
func (t *A_arbace_java_io_copy_A) DoInvoke_O_O_O_O__O(self, input__0, output__1, opts__2 any) any {














	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()); var tmp2 any; if jrt.J2g_Truth(opts__2) { var root_238 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_238, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_240 lang.IFn; if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_242 any = opts__2; if linked_239 == nil { tmp2 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { tmp2 = linked_239.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) } } else { tmp2 = nil }; return tmp1.Invoke_O_O_O__O(input__0, output__1, tmp2)
}
func A_arbace_java_io_as_relative_path_A_New() *A_arbace_java_io_as_relative_path_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_as_relative_path_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_java_io_as_relative_path_A) Ctor() {}
//line :407:1
func (t *A_arbace_java_io_as_relative_path_A) Invoke_O_O__O(self, x__0 any) any { var f__2 any; var target_243 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 =




	A_arbace_java_io_Coercions_A_InstanceOf(target_243); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_243) }; tmp1 = tmp2; if tmp1 { f__2 = A_arbace_java_io_Coercions_A_Cast(target_243).As_file__O() } else { f__2 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_243) }; if
	jrt.NN(jrt.File_Cast(f__2)).IsAbsolute__Z() { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, f__2, nil))))) } else {

		return jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref() } }

func A_arbace_java_io_file_A_New() *A_arbace_java_io_file_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_file_A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_java_io_file_A) Ctor() {}
//line :417:1
func (t *A_arbace_java_io_file_A) DoInvoke_O_O_O_O__O(self, parent__0, child__1, more__2 any) any {









	var root_244 any = A_arbace_java_io_A_const_34.GetRawRoot__O(); var linked_245 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_244, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_246 lang.IFn; if linked_245 == nil { ifn_246 = lang.IFn_Cast(root_244) } else { ifn_246 = nil }; var arg_247 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var arg_248 any; var root_250 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_250, A_arbace_java_io_file_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = parent__0; var arg_254 any = child__1; if linked_251 == nil { arg_248 = ifn_252.Invoke_O_O__O(arg_253, arg_254) } else { arg_248 = linked_251.(*A_arbace_java_io_file_A).Invoke_O_O_O__O(root_250, arg_253, arg_254) }; var arg_249 any = more__2; if linked_245 == nil { return ifn_246.Invoke_O_O_O__O(arg_247, arg_248, arg_249) } else { return linked_245.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_244, arg_247, arg_248, arg_249) } }
//line :417:1
func (t *A_arbace_java_io_file_A) Invoke_O_O_O__O(self, parent__0, child__1 any) any { var tmp1 any; var target_255 any = parent__0; var tmp2 bool; var tmp3 bool; tmp3 =







	A_arbace_java_io_Coercions_A_InstanceOf(target_255); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_255) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_Coercions_A_Cast(target_255).As_file__O() } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_255) }; var tmp4 /*line :417:1*/*jrt.File = jrt.File_Cast(tmp1); var tmp5 any; var root_256 any = A_arbace_java_io_A_const_36.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, A_arbace_java_io_as_relative_path_A_fn_class); var ifn_258 lang.IFn; if







	linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = child__1; if linked_257 == nil { tmp5 = ifn_258.Invoke_O__O(arg_259) } else { tmp5 = linked_257.(*A_arbace_java_io_as_relative_path_A).Invoke_O_O__O(root_256, arg_259) }; return /*line :417:1*/ jrt.File_New_File_String(tmp4, jrt.String_Cast(tmp5)) }
//line :417:1
func (t *A_arbace_java_io_file_A) Invoke_O_O__O(self, arg__0 any) any {





	var target_260 any = arg__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_260); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_260) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_Coercions_A_Cast(target_260).As_file__O() } else { return lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_260)
	}
}



func A_arbace_java_io_delete_file_A_New() *A_arbace_java_io_delete_file_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_delete_file_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_java_io_delete_file_A) Ctor() {}
//line :429:1
func (t *A_arbace_java_io_delete_file_A) DoInvoke_O_O_O__O(self, f__0, p__1661000311__1 any) any { var vec__1661000312__3 any = p__1661000311__1; var silently__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1661000312__3, lang.RT_IntCast_J__I_NoInit(0), nil); var or__1927000174__auto____5 bool; var tmp1 any; var root_261 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, A_arbace_java_io_file_A_fn_class); var ifn_263 lang.IFn; if



	linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = f__0; if linked_262 == nil { tmp1 = ifn_263.Invoke_O__O(arg_264) } else { tmp1 = linked_262.(*A_arbace_java_io_file_A).Invoke_O_O__O(root_261, arg_264) }; or__1927000174__auto____5 = jrt.NN(jrt.File_Cast(tmp1)).Delete__Z(); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 any = silently__4; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__0))))) } } }



func A_arbace_java_io_make_parents_A_New() *A_arbace_java_io_make_parents_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_make_parents_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_java_io_make_parents_A) Ctor() {}
//line :437:1
func (t *A_arbace_java_io_make_parents_A) DoInvoke_O_O_O__O(self, f__0, more__1 any) any { var temp__1927000414__auto____3 any; var tmp1 any; var root_265 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_267 lang.IFn; if




	linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var arg_269 any = f__0; var arg_270 any = more__1; if linked_266 == nil { tmp1 = ifn_267.Invoke_O_O_O__O(arg_268, arg_269, arg_270) } else { tmp1 = linked_266.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_265, arg_268, arg_269, arg_270) }; temp__1927000414__auto____3 = jrt.NN(jrt.File_Cast(tmp1)).GetParentFile__File().Ref(); if jrt.J2g_Truth(temp__1927000414__auto____3) { var parent__4 any = temp__1927000414__auto____3
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(parent__4)).Mkdirs__Z()).Ref() } else {
//line :442:1
			return nil } }


func A_arbace_java_io_resource_A_New() *A_arbace_java_io_resource_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_resource_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_java_io_resource_A) Ctor() {}
//line :445:1
func (t *A_arbace_java_io_resource_A) Invoke_O_O_O__O(self, n__0, loader__1 any) any {




	var tmp1 *jrt.Class = A_arbace_java_io_A_const_37; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(loader__1, tmp1, Lit_59, jrt.RefArrayOf(jrt.Object_class, n__0)) }
//line :445:1
func (t *A_arbace_java_io_resource_A) Invoke_O_O__O(self, n__0 any) any {



	var root_271 any = A_arbace_java_io_A_const_38.GetRawRoot__O(); var linked_272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_271, A_arbace_java_io_resource_A_fn_class); var ifn_273 lang.IFn; if linked_272 == nil { ifn_273 = lang.IFn_Cast(root_271) } else { ifn_273 = nil }; var arg_274 any = n__0; var tmp1 any = jrt.Thread_CurrentThread__Thread(); var tmp2 *jrt.Class = A_arbace_java_io_A_const_39; var arg_275 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_60, jrt.RefArrayOf(jrt.Object_class)); if linked_272 == nil { return ifn_273.Invoke_O_O__O(arg_274, arg_275) } else { return linked_272.(*A_arbace_java_io_resource_A).Invoke_O_O_O__O(root_271, arg_274, arg_275)
	}
}
































































































































type A_arbace_java_io_A struct{ jrt.Object }

var A_arbace_java_io_A_const_pool *jrt.RefArray

var A_arbace_java_io_A_const_0 *lang.Var

var A_arbace_java_io_A_const_1 any

var A_arbace_java_io_A_const_2 *lang.Var

var A_arbace_java_io_A_const_3 any

var A_arbace_java_io_A_const_4 *lang.Var

var A_arbace_java_io_A_const_5 *lang.Var

var A_arbace_java_io_A_const_6 *lang.Var

var A_arbace_java_io_A_const_7 *lang.Var

var A_arbace_java_io_A_const_8 any

var A_arbace_java_io_A_const_9 *lang.Var

var A_arbace_java_io_A_const_10 *jrt.Class

var A_arbace_java_io_A_const_11 *lang.Var

var A_arbace_java_io_A_const_12 *lang.Var

var A_arbace_java_io_A_const_13 any

var A_arbace_java_io_A_const_14 *lang.Var

var A_arbace_java_io_A_const_15 *lang.Var

var A_arbace_java_io_A_const_16 *jrt.Class

var A_arbace_java_io_A_const_17 *lang.Var

var A_arbace_java_io_A_const_18 *lang.Var

var A_arbace_java_io_A_const_19 *lang.Var

var A_arbace_java_io_A_const_20 *lang.Var

var A_arbace_java_io_A_const_21 *lang.Var

var A_arbace_java_io_A_const_22 *lang.Var

var A_arbace_java_io_A_const_23 *lang.Keyword

var A_arbace_java_io_A_const_24 *lang.Keyword

var A_arbace_java_io_A_const_25 *lang.Keyword

var A_arbace_java_io_A_const_26 any

var A_arbace_java_io_A_const_27 *lang.Var

var A_arbace_java_io_A_const_28 *lang.Var

var A_arbace_java_io_A_const_29 *lang.Var

var A_arbace_java_io_A_const_30 *lang.Var

var A_arbace_java_io_A_const_31 *lang.Var

var A_arbace_java_io_A_const_32 *lang.Var

var A_arbace_java_io_A_const_33 *lang.Var

var A_arbace_java_io_A_const_34 *lang.Var

var A_arbace_java_io_A_const_35 *lang.Var

var A_arbace_java_io_A_const_36 *lang.Var

var A_arbace_java_io_A_const_37 *jrt.Class

var A_arbace_java_io_A_const_38 *lang.Var

var A_arbace_java_io_A_const_39 *jrt.Class

var A_arbace_java_io_A_init jrt.ClassInit

func A_arbace_java_io_A_Init() { if !A_arbace_java_io_A_init.Done() { A_arbace_java_io_A_init.Run(A_arbace_java_io_A_clinit) } }

func A_arbace_java_io_A_clinit() { A_arbace_java_io_A_clinit_p0(); A_arbace_java_io_A_clinit_p1(); A_arbace_java_io_A_clinit_p2(); A_arbace_java_io_A_clinit_p3() }

func A_arbace_java_io_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_io_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 47); A_arbace_java_io_A_const_0 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[7]); A_arbace_java_io_A_const_1 = A_arbace_java_io_A_const_pool.A[8]; A_arbace_java_io_A_const_2 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[9]); A_arbace_java_io_A_const_3 = A_arbace_java_io_A_const_pool.A[10]; A_arbace_java_io_A_const_4 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[11]); A_arbace_java_io_A_const_5 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[12]); A_arbace_java_io_A_const_6 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[13]); A_arbace_java_io_A_const_7 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[14]); A_arbace_java_io_A_const_8 = A_arbace_java_io_A_const_pool.A[15]; A_arbace_java_io_A_const_9 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[16]); A_arbace_java_io_A_const_10 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[17]); A_arbace_java_io_A_const_11 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[18]) }

func A_arbace_java_io_A_clinit_p1() { A_arbace_java_io_A_const_12 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[19]); A_arbace_java_io_A_const_13 = A_arbace_java_io_A_const_pool.A[20]; A_arbace_java_io_A_const_14 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[21]); A_arbace_java_io_A_const_15 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[22]); A_arbace_java_io_A_const_16 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[23]); A_arbace_java_io_A_const_17 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[24]); A_arbace_java_io_A_const_18 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[25]); A_arbace_java_io_A_const_19 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[26]); A_arbace_java_io_A_const_20 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[27]); A_arbace_java_io_A_const_21 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[28]); A_arbace_java_io_A_const_22 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[29]); A_arbace_java_io_A_const_23 = lang.Keyword_Cast(A_arbace_java_io_A_const_pool.A[30]) }

func A_arbace_java_io_A_clinit_p2() { A_arbace_java_io_A_const_24 = lang.Keyword_Cast(A_arbace_java_io_A_const_pool.A[31]); A_arbace_java_io_A_const_25 = lang.Keyword_Cast(A_arbace_java_io_A_const_pool.A[32]); A_arbace_java_io_A_const_26 = A_arbace_java_io_A_const_pool.A[33]; A_arbace_java_io_A_const_27 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[34]); A_arbace_java_io_A_const_28 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[35]); A_arbace_java_io_A_const_29 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[36]); A_arbace_java_io_A_const_30 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[37]); A_arbace_java_io_A_const_31 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[38]); A_arbace_java_io_A_const_32 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[39]); A_arbace_java_io_A_const_33 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[40]); A_arbace_java_io_A_const_34 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[41]); A_arbace_java_io_A_const_35 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[42]) }

func A_arbace_java_io_A_clinit_p3() { A_arbace_java_io_A_const_36 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[43]); A_arbace_java_io_A_const_37 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[44]); A_arbace_java_io_A_const_38 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[45]); A_arbace_java_io_A_const_39 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[46]) }

func A_arbace_java_io_A_New() *A_arbace_java_io_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_A) Ctor() {}

func (t *A_arbace_java_io_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_A_class }

func (t *A_arbace_java_io_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_A); return ok }

func A_arbace_java_io_A_Cast(x any) *A_arbace_java_io_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_A_class)) }; return v }



type A_arbace_java_io_append_QMARK__A struct{ j2g_header uint64 }

var A_arbace_java_io_append_QMARK__A_fn_class *jrt.Class



type A_arbace_java_io_as_relative_path_A struct{ j2g_header uint64 }

var A_arbace_java_io_as_relative_path_A_fn_class *jrt.Class



type A_arbace_java_io_buffer_size_A struct{ j2g_header uint64 }

var A_arbace_java_io_buffer_size_A_fn_class *jrt.Class



type A_arbace_java_io_copy_A struct{ j2g_header uint64 }

var A_arbace_java_io_copy_A_fn_class *jrt.Class



type A_arbace_java_io_delete_file_A struct{ j2g_header uint64 }

var A_arbace_java_io_delete_file_A_fn_class *jrt.Class



type A_arbace_java_io_encoding_A struct{ j2g_header uint64 }

var A_arbace_java_io_encoding_A_fn_class *jrt.Class



type A_arbace_java_io_escaped_utf8_urlstring__GT_str_A struct{ j2g_header uint64 }

var A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000004_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000004_A_New() *A_arbace_java_io_eval1661000004_A { t := &A_arbace_java_io_eval1661000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000004_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000004_A_class }

func (t *A_arbace_java_io_eval1661000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000004_A); return ok }

func A_arbace_java_io_eval1661000004_A_Cast(x any) *A_arbace_java_io_eval1661000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000004_A_class)) }; return v }



type A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000008_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000008_A_New() *A_arbace_java_io_eval1661000008_A { t := &A_arbace_java_io_eval1661000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000008_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000008_A_class }

func (t *A_arbace_java_io_eval1661000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000008_A); return ok }

func A_arbace_java_io_eval1661000008_A_Cast(x any) *A_arbace_java_io_eval1661000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000008_A_class)) }; return v }



type A_arbace_java_io_eval1661000008_fn__1661000009_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000024_A_New() *A_arbace_java_io_eval1661000024_A { t := &A_arbace_java_io_eval1661000024_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000024_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_A_class }

func (t *A_arbace_java_io_eval1661000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_A); return ok }

func A_arbace_java_io_eval1661000024_A_Cast(x any) *A_arbace_java_io_eval1661000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000025_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A struct{ j2g_header uint64; F_G__1661000015 any }

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000033_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A struct{ j2g_header uint64; F_G__1661000017 any }

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000047_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000047_A_New() *A_arbace_java_io_eval1661000047_A { t := &A_arbace_java_io_eval1661000047_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000047_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000047_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000047_A_class }

func (t *A_arbace_java_io_eval1661000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000047_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000047_A); return ok }

func A_arbace_java_io_eval1661000047_A_Cast(x any) *A_arbace_java_io_eval1661000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000047_A_class)) }; return v }



type A_arbace_java_io_eval1661000047_fn__1661000048_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000047_fn__1661000050_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000053_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000053_A_New() *A_arbace_java_io_eval1661000053_A { t := &A_arbace_java_io_eval1661000053_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000053_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000053_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000053_A_class }

func (t *A_arbace_java_io_eval1661000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000053_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000053_A); return ok }

func A_arbace_java_io_eval1661000053_A_Cast(x any) *A_arbace_java_io_eval1661000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000053_A_class)) }; return v }



type A_arbace_java_io_eval1661000053_fn__1661000054_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000053_fn__1661000056_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000059_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000059_A_New() *A_arbace_java_io_eval1661000059_A { t := &A_arbace_java_io_eval1661000059_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000059_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000059_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000059_A_class }

func (t *A_arbace_java_io_eval1661000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000059_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000059_A); return ok }

func A_arbace_java_io_eval1661000059_A_Cast(x any) *A_arbace_java_io_eval1661000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000059_A_class)) }; return v }



type A_arbace_java_io_eval1661000059_fn__1661000060_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000059_fn__1661000062_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000065_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000065_A_New() *A_arbace_java_io_eval1661000065_A { t := &A_arbace_java_io_eval1661000065_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000065_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000065_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000065_A_class }

func (t *A_arbace_java_io_eval1661000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000065_A); return ok }

func A_arbace_java_io_eval1661000065_A_Cast(x any) *A_arbace_java_io_eval1661000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000065_A_class)) }; return v }



type A_arbace_java_io_eval1661000065_fn__1661000066_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000065_fn__1661000068_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000071_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000071_A_New() *A_arbace_java_io_eval1661000071_A { t := &A_arbace_java_io_eval1661000071_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000071_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000071_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000071_A_class }

func (t *A_arbace_java_io_eval1661000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000071_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000071_A); return ok }

func A_arbace_java_io_eval1661000071_A_Cast(x any) *A_arbace_java_io_eval1661000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000071_A_class)) }; return v }



type A_arbace_java_io_eval1661000071_fn__1661000072_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000071_fn__1661000074_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000091_A_New() *A_arbace_java_io_eval1661000091_A { t := &A_arbace_java_io_eval1661000091_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000091_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_A_class }

func (t *A_arbace_java_io_eval1661000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_A); return ok }

func A_arbace_java_io_eval1661000091_A_Cast(x any) *A_arbace_java_io_eval1661000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000092_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A struct{ j2g_header uint64; F_G__1661000082 any }

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000102_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A struct{ j2g_header uint64; F_G__1661000084 any }

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000112_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A struct{ j2g_header uint64; F_G__1661000078 any }

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000122_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A struct{ j2g_header uint64; F_G__1661000080 any }

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000154_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000154_A_New() *A_arbace_java_io_eval1661000154_A { t := &A_arbace_java_io_eval1661000154_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000154_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000154_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000154_A_class }

func (t *A_arbace_java_io_eval1661000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000154_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000154_A); return ok }

func A_arbace_java_io_eval1661000154_A_Cast(x any) *A_arbace_java_io_eval1661000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000154_A_class)) }; return v }



type A_arbace_java_io_eval1661000154_fn__1661000155_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000158_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000158_A_New() *A_arbace_java_io_eval1661000158_A { t := &A_arbace_java_io_eval1661000158_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000158_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000158_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000158_A_class }

func (t *A_arbace_java_io_eval1661000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000158_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000158_A); return ok }

func A_arbace_java_io_eval1661000158_A_Cast(x any) *A_arbace_java_io_eval1661000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000158_A_class)) }; return v }



type A_arbace_java_io_eval1661000158_fn__1661000159_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000162_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000162_A_New() *A_arbace_java_io_eval1661000162_A { t := &A_arbace_java_io_eval1661000162_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000162_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000162_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000162_A_class }

func (t *A_arbace_java_io_eval1661000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000162_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000162_A); return ok }

func A_arbace_java_io_eval1661000162_A_Cast(x any) *A_arbace_java_io_eval1661000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000162_A_class)) }; return v }



type A_arbace_java_io_eval1661000162_fn__1661000163_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000166_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000166_A_New() *A_arbace_java_io_eval1661000166_A { t := &A_arbace_java_io_eval1661000166_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000166_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000166_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000166_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000166_A_class }

func (t *A_arbace_java_io_eval1661000166_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000166_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000166_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000166_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000166_A); return ok }

func A_arbace_java_io_eval1661000166_A_Cast(x any) *A_arbace_java_io_eval1661000166_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000166_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000166_A_class)) }; return v }



type A_arbace_java_io_eval1661000166_fn__1661000167_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000170_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000170_A_New() *A_arbace_java_io_eval1661000170_A { t := &A_arbace_java_io_eval1661000170_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000170_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000170_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000170_A_class }

func (t *A_arbace_java_io_eval1661000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000170_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000170_A); return ok }

func A_arbace_java_io_eval1661000170_A_Cast(x any) *A_arbace_java_io_eval1661000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000170_A_class)) }; return v }



type A_arbace_java_io_eval1661000170_fn__1661000171_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000174_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000174_A_New() *A_arbace_java_io_eval1661000174_A { t := &A_arbace_java_io_eval1661000174_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000174_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000174_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000174_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000174_A_class }

func (t *A_arbace_java_io_eval1661000174_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000174_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000174_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000174_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000174_A); return ok }

func A_arbace_java_io_eval1661000174_A_Cast(x any) *A_arbace_java_io_eval1661000174_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000174_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000174_A_class)) }; return v }



type A_arbace_java_io_eval1661000174_fn__1661000175_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000178_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000178_A_New() *A_arbace_java_io_eval1661000178_A { t := &A_arbace_java_io_eval1661000178_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000178_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000178_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000178_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000178_A_class }

func (t *A_arbace_java_io_eval1661000178_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000178_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000178_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000178_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000178_A); return ok }

func A_arbace_java_io_eval1661000178_A_Cast(x any) *A_arbace_java_io_eval1661000178_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000178_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000178_A_class)) }; return v }



type A_arbace_java_io_eval1661000178_fn__1661000179_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000182_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000182_A_New() *A_arbace_java_io_eval1661000182_A { t := &A_arbace_java_io_eval1661000182_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000182_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000182_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000182_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000182_A_class }

func (t *A_arbace_java_io_eval1661000182_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000182_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000182_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000182_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000182_A); return ok }

func A_arbace_java_io_eval1661000182_A_Cast(x any) *A_arbace_java_io_eval1661000182_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000182_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000182_A_class)) }; return v }



type A_arbace_java_io_eval1661000182_fn__1661000183_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000186_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000186_A_New() *A_arbace_java_io_eval1661000186_A { t := &A_arbace_java_io_eval1661000186_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000186_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000186_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000186_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000186_A_class }

func (t *A_arbace_java_io_eval1661000186_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000186_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000186_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000186_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000186_A); return ok }

func A_arbace_java_io_eval1661000186_A_Cast(x any) *A_arbace_java_io_eval1661000186_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000186_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000186_A_class)) }; return v }



type A_arbace_java_io_eval1661000186_fn__1661000187_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000186_fn__1661000189_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000192_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000192_A_New() *A_arbace_java_io_eval1661000192_A { t := &A_arbace_java_io_eval1661000192_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000192_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000192_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000192_A_class }

func (t *A_arbace_java_io_eval1661000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000192_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000192_A); return ok }

func A_arbace_java_io_eval1661000192_A_Cast(x any) *A_arbace_java_io_eval1661000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000192_A_class)) }; return v }



type A_arbace_java_io_eval1661000192_fn__1661000193_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000192_fn__1661000195_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000198_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000198_A_New() *A_arbace_java_io_eval1661000198_A { t := &A_arbace_java_io_eval1661000198_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000198_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000198_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000198_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000198_A_class }

func (t *A_arbace_java_io_eval1661000198_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000198_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000198_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000198_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000198_A); return ok }

func A_arbace_java_io_eval1661000198_A_Cast(x any) *A_arbace_java_io_eval1661000198_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000198_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000198_A_class)) }; return v }



type A_arbace_java_io_eval1661000198_fn__1661000199_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000198_fn__1661000201_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000204_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000204_A_New() *A_arbace_java_io_eval1661000204_A { t := &A_arbace_java_io_eval1661000204_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000204_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000204_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000204_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000204_A_class }

func (t *A_arbace_java_io_eval1661000204_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000204_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000204_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000204_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000204_A); return ok }

func A_arbace_java_io_eval1661000204_A_Cast(x any) *A_arbace_java_io_eval1661000204_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000204_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000204_A_class)) }; return v }



type A_arbace_java_io_eval1661000204_fn__1661000205_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000204_fn__1661000207_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000210_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000210_A_New() *A_arbace_java_io_eval1661000210_A { t := &A_arbace_java_io_eval1661000210_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000210_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000210_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000210_A_class }

func (t *A_arbace_java_io_eval1661000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000210_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000210_A); return ok }

func A_arbace_java_io_eval1661000210_A_Cast(x any) *A_arbace_java_io_eval1661000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000210_A_class)) }; return v }



type A_arbace_java_io_eval1661000210_fn__1661000211_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000210_fn__1661000213_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000216_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000216_A_New() *A_arbace_java_io_eval1661000216_A { t := &A_arbace_java_io_eval1661000216_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000216_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000216_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000216_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000216_A_class }

func (t *A_arbace_java_io_eval1661000216_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000216_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000216_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000216_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000216_A); return ok }

func A_arbace_java_io_eval1661000216_A_Cast(x any) *A_arbace_java_io_eval1661000216_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000216_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000216_A_class)) }; return v }



type A_arbace_java_io_eval1661000216_fn__1661000217_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000220_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000220_A_New() *A_arbace_java_io_eval1661000220_A { t := &A_arbace_java_io_eval1661000220_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000220_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000220_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000220_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000220_A_class }

func (t *A_arbace_java_io_eval1661000220_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000220_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000220_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000220_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000220_A); return ok }

func A_arbace_java_io_eval1661000220_A_Cast(x any) *A_arbace_java_io_eval1661000220_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000220_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000220_A_class)) }; return v }



type A_arbace_java_io_eval1661000220_fn__1661000221_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000226_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000226_A_New() *A_arbace_java_io_eval1661000226_A { t := &A_arbace_java_io_eval1661000226_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000226_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000226_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000226_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000226_A_class }

func (t *A_arbace_java_io_eval1661000226_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000226_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000226_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000226_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000226_A); return ok }

func A_arbace_java_io_eval1661000226_A_Cast(x any) *A_arbace_java_io_eval1661000226_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000226_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000226_A_class)) }; return v }



type A_arbace_java_io_eval1661000226_fn__1661000227_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000226_fn__1661000229_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000232_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000232_A_New() *A_arbace_java_io_eval1661000232_A { t := &A_arbace_java_io_eval1661000232_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000232_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000232_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000232_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000232_A_class }

func (t *A_arbace_java_io_eval1661000232_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000232_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000232_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000232_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000232_A); return ok }

func A_arbace_java_io_eval1661000232_A_Cast(x any) *A_arbace_java_io_eval1661000232_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000232_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000232_A_class)) }; return v }



type A_arbace_java_io_eval1661000232_fn__1661000233_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000236_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000236_A_New() *A_arbace_java_io_eval1661000236_A { t := &A_arbace_java_io_eval1661000236_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000236_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000236_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000236_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000236_A_class }

func (t *A_arbace_java_io_eval1661000236_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000236_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000236_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000236_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000236_A); return ok }

func A_arbace_java_io_eval1661000236_A_Cast(x any) *A_arbace_java_io_eval1661000236_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000236_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000236_A_class)) }; return v }



type A_arbace_java_io_eval1661000236_fn__1661000237_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000240_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000240_A_New() *A_arbace_java_io_eval1661000240_A { t := &A_arbace_java_io_eval1661000240_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000240_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000240_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000240_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000240_A_class }

func (t *A_arbace_java_io_eval1661000240_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000240_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000240_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000240_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000240_A); return ok }

func A_arbace_java_io_eval1661000240_A_Cast(x any) *A_arbace_java_io_eval1661000240_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000240_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000240_A_class)) }; return v }



type A_arbace_java_io_eval1661000240_fn__1661000241_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000244_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000244_A_New() *A_arbace_java_io_eval1661000244_A { t := &A_arbace_java_io_eval1661000244_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000244_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000244_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000244_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000244_A_class }

func (t *A_arbace_java_io_eval1661000244_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000244_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000244_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000244_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000244_A); return ok }

func A_arbace_java_io_eval1661000244_A_Cast(x any) *A_arbace_java_io_eval1661000244_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000244_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000244_A_class)) }; return v }



type A_arbace_java_io_eval1661000244_fn__1661000245_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000248_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000248_A_New() *A_arbace_java_io_eval1661000248_A { t := &A_arbace_java_io_eval1661000248_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000248_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000248_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000248_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000248_A_class }

func (t *A_arbace_java_io_eval1661000248_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000248_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000248_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000248_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000248_A); return ok }

func A_arbace_java_io_eval1661000248_A_Cast(x any) *A_arbace_java_io_eval1661000248_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000248_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000248_A_class)) }; return v }



type A_arbace_java_io_eval1661000248_fn__1661000249_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000252_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000252_A_New() *A_arbace_java_io_eval1661000252_A { t := &A_arbace_java_io_eval1661000252_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000252_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000252_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000252_A_class }

func (t *A_arbace_java_io_eval1661000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000252_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000252_A); return ok }

func A_arbace_java_io_eval1661000252_A_Cast(x any) *A_arbace_java_io_eval1661000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000252_A_class)) }; return v }



type A_arbace_java_io_eval1661000252_fn__1661000253_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000256_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000256_A_New() *A_arbace_java_io_eval1661000256_A { t := &A_arbace_java_io_eval1661000256_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000256_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000256_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000256_A_class }

func (t *A_arbace_java_io_eval1661000256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000256_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000256_A); return ok }

func A_arbace_java_io_eval1661000256_A_Cast(x any) *A_arbace_java_io_eval1661000256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000256_A_class)) }; return v }



type A_arbace_java_io_eval1661000256_fn__1661000257_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000260_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000260_A_New() *A_arbace_java_io_eval1661000260_A { t := &A_arbace_java_io_eval1661000260_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000260_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000260_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000260_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000260_A_class }

func (t *A_arbace_java_io_eval1661000260_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000260_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000260_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000260_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000260_A); return ok }

func A_arbace_java_io_eval1661000260_A_Cast(x any) *A_arbace_java_io_eval1661000260_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000260_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000260_A_class)) }; return v }



type A_arbace_java_io_eval1661000260_fn__1661000261_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000264_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000264_A_New() *A_arbace_java_io_eval1661000264_A { t := &A_arbace_java_io_eval1661000264_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000264_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000264_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000264_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000264_A_class }

func (t *A_arbace_java_io_eval1661000264_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000264_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000264_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000264_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000264_A); return ok }

func A_arbace_java_io_eval1661000264_A_Cast(x any) *A_arbace_java_io_eval1661000264_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000264_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000264_A_class)) }; return v }



type A_arbace_java_io_eval1661000264_fn__1661000265_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000268_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000268_A_New() *A_arbace_java_io_eval1661000268_A { t := &A_arbace_java_io_eval1661000268_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000268_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000268_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000268_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000268_A_class }

func (t *A_arbace_java_io_eval1661000268_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000268_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000268_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000268_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000268_A); return ok }

func A_arbace_java_io_eval1661000268_A_Cast(x any) *A_arbace_java_io_eval1661000268_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000268_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000268_A_class)) }; return v }



type A_arbace_java_io_eval1661000268_fn__1661000269_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000272_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000272_A_New() *A_arbace_java_io_eval1661000272_A { t := &A_arbace_java_io_eval1661000272_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000272_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000272_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000272_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000272_A_class }

func (t *A_arbace_java_io_eval1661000272_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000272_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000272_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000272_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000272_A); return ok }

func A_arbace_java_io_eval1661000272_A_Cast(x any) *A_arbace_java_io_eval1661000272_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000272_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000272_A_class)) }; return v }



type A_arbace_java_io_eval1661000272_fn__1661000273_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000276_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000276_A_New() *A_arbace_java_io_eval1661000276_A { t := &A_arbace_java_io_eval1661000276_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000276_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000276_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000276_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000276_A_class }

func (t *A_arbace_java_io_eval1661000276_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000276_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000276_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000276_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000276_A); return ok }

func A_arbace_java_io_eval1661000276_A_Cast(x any) *A_arbace_java_io_eval1661000276_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000276_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000276_A_class)) }; return v }



type A_arbace_java_io_eval1661000276_fn__1661000277_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000280_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000280_A_New() *A_arbace_java_io_eval1661000280_A { t := &A_arbace_java_io_eval1661000280_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000280_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000280_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000280_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000280_A_class }

func (t *A_arbace_java_io_eval1661000280_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000280_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000280_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000280_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000280_A); return ok }

func A_arbace_java_io_eval1661000280_A_Cast(x any) *A_arbace_java_io_eval1661000280_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000280_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000280_A_class)) }; return v }



type A_arbace_java_io_eval1661000280_fn__1661000281_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000284_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000284_A_New() *A_arbace_java_io_eval1661000284_A { t := &A_arbace_java_io_eval1661000284_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000284_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000284_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000284_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000284_A_class }

func (t *A_arbace_java_io_eval1661000284_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000284_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000284_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000284_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000284_A); return ok }

func A_arbace_java_io_eval1661000284_A_Cast(x any) *A_arbace_java_io_eval1661000284_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000284_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000284_A_class)) }; return v }



type A_arbace_java_io_eval1661000284_fn__1661000285_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000288_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000288_A_New() *A_arbace_java_io_eval1661000288_A { t := &A_arbace_java_io_eval1661000288_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000288_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000288_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000288_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000288_A_class }

func (t *A_arbace_java_io_eval1661000288_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000288_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000288_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000288_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000288_A); return ok }

func A_arbace_java_io_eval1661000288_A_Cast(x any) *A_arbace_java_io_eval1661000288_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000288_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000288_A_class)) }; return v }



type A_arbace_java_io_eval1661000288_fn__1661000289_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000292_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000292_A_New() *A_arbace_java_io_eval1661000292_A { t := &A_arbace_java_io_eval1661000292_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000292_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000292_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000292_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000292_A_class }

func (t *A_arbace_java_io_eval1661000292_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000292_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000292_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000292_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000292_A); return ok }

func A_arbace_java_io_eval1661000292_A_Cast(x any) *A_arbace_java_io_eval1661000292_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000292_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000292_A_class)) }; return v }



type A_arbace_java_io_eval1661000292_fn__1661000293_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000296_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000296_A_New() *A_arbace_java_io_eval1661000296_A { t := &A_arbace_java_io_eval1661000296_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000296_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000296_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000296_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000296_A_class }

func (t *A_arbace_java_io_eval1661000296_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000296_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000296_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000296_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000296_A); return ok }

func A_arbace_java_io_eval1661000296_A_Cast(x any) *A_arbace_java_io_eval1661000296_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000296_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000296_A_class)) }; return v }



type A_arbace_java_io_eval1661000296_fn__1661000297_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000300_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000300_A_New() *A_arbace_java_io_eval1661000300_A { t := &A_arbace_java_io_eval1661000300_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000300_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000300_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000300_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000300_A_class }

func (t *A_arbace_java_io_eval1661000300_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000300_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000300_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000300_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000300_A); return ok }

func A_arbace_java_io_eval1661000300_A_Cast(x any) *A_arbace_java_io_eval1661000300_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000300_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000300_A_class)) }; return v }



type A_arbace_java_io_eval1661000300_fn__1661000301_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000304_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000304_A_New() *A_arbace_java_io_eval1661000304_A { t := &A_arbace_java_io_eval1661000304_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000304_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000304_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000304_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000304_A_class }

func (t *A_arbace_java_io_eval1661000304_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000304_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000304_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000304_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000304_A); return ok }

func A_arbace_java_io_eval1661000304_A_Cast(x any) *A_arbace_java_io_eval1661000304_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000304_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000304_A_class)) }; return v }



type A_arbace_java_io_eval1661000304_fn__1661000305_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class *jrt.Class



type A_arbace_java_io_file_A struct{ j2g_header uint64 }

var A_arbace_java_io_file_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000144_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000144_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000146_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000146_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000148_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000148_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000150_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000150_A_fn_class *jrt.Class



type A_arbace_java_io_input_stream_A struct{ j2g_header uint64 }

var A_arbace_java_io_input_stream_A_fn_class *jrt.Class



type A_arbace_java_io_inputstream__GT_reader_A struct{ j2g_header uint64 }

var A_arbace_java_io_inputstream__GT_reader_A_fn_class *jrt.Class



type A_arbace_java_io_make_parents_A struct{ j2g_header uint64 }

var A_arbace_java_io_make_parents_A_fn_class *jrt.Class



type A_arbace_java_io_output_stream_A struct{ j2g_header uint64 }

var A_arbace_java_io_output_stream_A_fn_class *jrt.Class



type A_arbace_java_io_outputstream__GT_writer_A struct{ j2g_header uint64 }

var A_arbace_java_io_outputstream__GT_writer_A_fn_class *jrt.Class



type A_arbace_java_io_reader_A struct{ j2g_header uint64 }

var A_arbace_java_io_reader_A_fn_class *jrt.Class



type A_arbace_java_io_resource_A struct{ j2g_header uint64 }

var A_arbace_java_io_resource_A_fn_class *jrt.Class



type A_arbace_java_io_writer_A struct{ j2g_header uint64 }

var A_arbace_java_io_writer_A_fn_class *jrt.Class
