//line aot_arbace_java_io.ae:1
package aot_arbace_java_io

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New() *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A { A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_Init(); t := &A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp36 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_java_io_A_Init(); tmp9 = A_arbace_java_io_A_const_3; tmp8.Invoke_O__O(tmp9); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_53)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_54)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_55)); var tmp13 *lang.Var; lang.RT_Init(); tmp13 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp13).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_56)); var tmp14 *lang.Var; lang.RT_Init(); tmp14 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp14).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_57)); var tmp15 *lang.Var; lang.RT_Init(); tmp15 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp15).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_58)); var tmp16 *lang.Var; lang.RT_Init(); tmp16 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp16).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_59)); var tmp17 *lang.Var; lang.RT_Init(); tmp17 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp17).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_60)); var tmp18 *lang.Var; lang.RT_Init(); tmp18 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp18).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_61)); var tmp19 *lang.Var; lang.RT_Init(); tmp19 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp19).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_62)); var tmp20 *lang.Var; lang.RT_Init(); tmp20 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp20).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_63)); var tmp21 *lang.Var; lang.RT_Init(); tmp21 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp21).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_64)); var tmp22 *lang.Var; lang.RT_Init(); tmp22 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp22).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_65)); var tmp23 *lang.Var; lang.RT_Init(); tmp23 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp23).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_66)); var tmp24 *lang.Var; lang.RT_Init(); tmp24 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp24).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_67)); var tmp25 *lang.Var; lang.RT_Init(); tmp25 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp25).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_68)); var tmp26 *lang.Var; lang.RT_Init(); tmp26 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp26).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_69)); var tmp27 *lang.Var; lang.RT_Init(); tmp27 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp27).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_70)); var tmp28 *lang.Var; lang.RT_Init(); tmp28 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp28).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_71)); var tmp29 *lang.Var; lang.RT_Init(); tmp29 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp29).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_72)); var tmp30 *lang.Var; lang.RT_Init(); tmp30 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp30).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_73)); var tmp31 *lang.Var; lang.RT_Init(); tmp31 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp31).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_74)); var tmp32 *lang.Var; lang.RT_Init(); tmp32 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp32).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_75)); var tmp33 *lang.Var; lang.RT_Init(); tmp33 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp33).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_76)); var tmp34 *lang.Var; lang.RT_Init(); tmp34 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp34).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_77)); var tmp35 *lang.Var; lang.RT_Init(); tmp35 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp35).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_78)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp36 != nil { panic(tmp36) }; return tmp3 }
//line :9:1
func A_arbace_java_io_eval1661000008_fn__1661000009_A_New() *A_arbace_java_io_eval1661000008_fn__1661000009_A { A_arbace_java_io_eval1661000008_fn__1661000009_A_Init(); t := &A_arbace_java_io_eval1661000008_fn__1661000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_java_io_A_Init(); tmp9 = A_arbace_java_io_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }




























func A_arbace_java_io_eval1661000024_fn__1661000025_A_New() *A_arbace_java_io_eval1661000024_fn__1661000025_A { A_arbace_java_io_eval1661000024_fn__1661000025_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000015__2_ any; var tmp1 any = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_New(); var tmp2 *jrt.Class; A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_Init(); tmp2 = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class; G__1661000015__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_New_O(G__1661000015__2_); var tmp4 *jrt.Class; A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_Init(); tmp4 = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_New_O(p0 any) *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A { A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Ctor_O(c__G__1661000015 any) { t.F_G__1661000015 = c__G__1661000015 }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Invoke_O_O__O(self, gf__x__1661000029__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__1661000029__1)); if jrt.A2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__1661000029__1) } else { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_10; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__1661000029__1, tmp3.Ref(), t.F_G__1661000015)).Invoke_O__O(gf__x__1661000029__1) } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_New() *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A { A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Invoke_O_O__O(self, gf__x__1661000026__1 any) any { var target_1 any = gf__x__1661000026__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_1 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_1, Lit_83, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_java_io_Coercions_A_Cast(target_1).As_file__O() } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_A_New() *A_arbace_java_io_eval1661000024_fn__1661000033_A { A_arbace_java_io_eval1661000024_fn__1661000033_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000017__2_ any; var tmp1 any = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_New(); var tmp2 *jrt.Class; A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_Init(); tmp2 = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class; G__1661000017__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_New_O(G__1661000017__2_); var tmp4 *jrt.Class; A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_Init(); tmp4 = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_New_O(p0 any) *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A { A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Ctor_O(c__G__1661000017 any) { t.F_G__1661000017 = c__G__1661000017 }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Invoke_O_O__O(self, gf__x__1661000037__1 any) any { var cache__231000236__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__1661000037__1)); if jrt.A2g_Truth(f__231000237__auto____3) { return lang.IFn_Cast(f__231000237__auto____3).Invoke_O__O(gf__x__1661000037__1) } else { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_10; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__1661000037__1, tmp3.Ref(), t.F_G__1661000017)).Invoke_O__O(gf__x__1661000037__1) } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_New() *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A { A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Invoke_O_O__O(self, gf__x__1661000034__1 any) any { var target_2 any = gf__x__1661000034__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_2 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_2, Lit_87, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_java_io_Coercions_A_Cast(target_2).As_url__O() } }




func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New() *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A { A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_Init(); t := &A_arbace_java_io_escaped_utf8_urlstring__GT_str_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Ctor() {}
//line :43:1
func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_11; return jrt.URLDecoder_Decode_String_String__String(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(s__0, Lit_50, Lit_51)), Lit_48).Ref()
}
func A_arbace_java_io_eval1661000047_fn__1661000048_A_New() *A_arbace_java_io_eval1661000047_fn__1661000048_A { A_arbace_java_io_eval1661000047_fn__1661000048_A_Init(); t := &A_arbace_java_io_eval1661000047_fn__1661000048_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :47:1
func A_arbace_java_io_eval1661000047_fn__1661000050_A_New() *A_arbace_java_io_eval1661000047_fn__1661000050_A { A_arbace_java_io_eval1661000047_fn__1661000050_A_Init(); t := &A_arbace_java_io_eval1661000047_fn__1661000050_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :47:1
func A_arbace_java_io_eval1661000053_fn__1661000054_A_New() *A_arbace_java_io_eval1661000053_fn__1661000054_A { A_arbace_java_io_eval1661000053_fn__1661000054_A_Init(); t := &A_arbace_java_io_eval1661000053_fn__1661000054_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Invoke_O_O__O(self, s__1 any) any { return jrt.File_New_String(jrt.String_Cast(s__1)) }
//line :47:1
func A_arbace_java_io_eval1661000053_fn__1661000056_A_New() *A_arbace_java_io_eval1661000053_fn__1661000056_A { A_arbace_java_io_eval1661000053_fn__1661000056_A_Init(); t := &A_arbace_java_io_eval1661000053_fn__1661000056_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Invoke_O_O__O(self, s__1 any) any {






	return lang.RT_ToUrl_String__URL(jrt.String_Cast(s__1)).Ref() }
//line :47:1
func A_arbace_java_io_eval1661000059_fn__1661000060_A_New() *A_arbace_java_io_eval1661000059_fn__1661000060_A { A_arbace_java_io_eval1661000059_fn__1661000060_A_Init(); t := &A_arbace_java_io_eval1661000059_fn__1661000060_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Invoke_O_O__O(self, f__1 any) any { return f__1 }
//line :47:1
func A_arbace_java_io_eval1661000059_fn__1661000062_A_New() *A_arbace_java_io_eval1661000059_fn__1661000062_A { A_arbace_java_io_eval1661000059_fn__1661000062_A_Init(); t := &A_arbace_java_io_eval1661000059_fn__1661000062_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Invoke_O_O__O(self, f__1 any) any {










	return lang.RT_ToUrl_File__URL(jrt.File_Cast(f__1)).Ref() }
//line :47:1
func A_arbace_java_io_eval1661000065_fn__1661000066_A_New() *A_arbace_java_io_eval1661000065_fn__1661000066_A { A_arbace_java_io_eval1661000065_fn__1661000066_A_Init(); t := &A_arbace_java_io_eval1661000065_fn__1661000066_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Invoke_O_O__O(self, u__1 any) any { return u__1 }
//line :47:1
func A_arbace_java_io_eval1661000065_fn__1661000068_A_New() *A_arbace_java_io_eval1661000065_fn__1661000068_A { A_arbace_java_io_eval1661000065_fn__1661000068_A_Init(); t := &A_arbace_java_io_eval1661000065_fn__1661000068_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Invoke_O_O__O(self, u__1 any) any {















	if lang.Util_Equiv_O_O__Z(Lit_35, jrt.NN(jrt.URL_Cast(u__1)).GetProtocol__String().Ref()) {
		var target_3 any; var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.String = jrt.NN(jrt.URL_Cast(u__1)).GetFile__String(); var tmp4 any; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_14; var tmp5 uint16 = jrt.NN(jrt.Character_Cast(tmp4)).CharValue__C(); var tmp6 uint16; jrt.File_Init(); tmp6 = jrt.File_separatorChar; target_3 = tmp2.Invoke_O__O(jrt.NN(tmp3).Replace_C_C__String(tmp5, tmp6).Ref()); var tmp7 bool; var tmp8 bool; tmp8 = A_arbace_java_io_Coercions_A_InstanceOf(target_3); if tmp8 { tmp8 = !lang.Compiler_AOT_IsDyn_O__Z(target_3) }; tmp7 = tmp8; if tmp7 { return A_arbace_java_io_Coercions_A_Cast(target_3).As_file__O() } else { var tmp9 *lang.Var; A_arbace_java_io_A_Init(); tmp9 = A_arbace_java_io_A_const_13; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(target_3) } } else {
//line :63:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_96, nil), jrt.RefArrayOf(jrt.Object_class, nil, u__1))))) } }
//line :47:1
func A_arbace_java_io_eval1661000071_fn__1661000072_A_New() *A_arbace_java_io_eval1661000071_fn__1661000072_A { A_arbace_java_io_eval1661000071_fn__1661000072_A_Init(); t := &A_arbace_java_io_eval1661000071_fn__1661000072_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Invoke_O_O__O(self, u__1 any) any {





















	return jrt.NN(jrt.URI_Cast(u__1)).ToURL__URL().Ref() }
//line :47:1
func A_arbace_java_io_eval1661000071_fn__1661000074_A_New() *A_arbace_java_io_eval1661000071_fn__1661000074_A { A_arbace_java_io_eval1661000071_fn__1661000074_A_Init(); t := &A_arbace_java_io_eval1661000071_fn__1661000074_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Invoke_O_O__O(self, u__1 any) any {






















	var target_4 any; var target_5 any = u__1; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_5); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_5) }; tmp1 = tmp2; if tmp1 { target_4 = A_arbace_java_io_Coercions_A_Cast(target_5).As_url__O() } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_15; target_4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(target_5) }; var tmp4 bool; var tmp5 bool; tmp5 = A_arbace_java_io_Coercions_A_InstanceOf(target_4); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_4) }; tmp4 = tmp5; if tmp4 { return A_arbace_java_io_Coercions_A_Cast(target_4).As_file__O() } else { var tmp6 *lang.Var; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_13; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(target_4)
	} }
func A_arbace_java_io_eval1661000091_fn__1661000092_A_New() *A_arbace_java_io_eval1661000091_fn__1661000092_A { A_arbace_java_io_eval1661000091_fn__1661000092_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000082__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_New(); var tmp2 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_Init(); tmp2 = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class; G__1661000082__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_New_O(G__1661000082__2_); var tmp4 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_Init(); tmp4 = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A { A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Ctor_O(c__G__1661000082 any) { t.F_G__1661000082 = c__G__1661000082 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Invoke_O_O_O__O(self, gf__x__1661000097__1, gf__opts__1661000098__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__1661000097__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000097__1, gf__opts__1661000098__2) } else { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_16; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__1661000097__1, tmp3.Ref(), t.F_G__1661000082)).Invoke_O_O__O(gf__x__1661000097__1, gf__opts__1661000098__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_New() *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A { A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Invoke_O_O_O__O(self, gf__x__1661000093__1, gf__opts__1661000094__2 any) any { var target_6 any = gf__x__1661000093__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_6 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_6) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_6, Lit_102, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000094__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_6).Make_input_stream_O__O(gf__opts__1661000094__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_A_New() *A_arbace_java_io_eval1661000091_fn__1661000102_A { A_arbace_java_io_eval1661000091_fn__1661000102_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000084__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_New(); var tmp2 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_Init(); tmp2 = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class; G__1661000084__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_New_O(G__1661000084__2_); var tmp4 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_Init(); tmp4 = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A { A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Ctor_O(c__G__1661000084 any) { t.F_G__1661000084 = c__G__1661000084 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Invoke_O_O_O__O(self, gf__x__1661000107__1, gf__opts__1661000108__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__1661000107__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000107__1, gf__opts__1661000108__2) } else { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_16; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__1661000107__1, tmp3.Ref(), t.F_G__1661000084)).Invoke_O_O__O(gf__x__1661000107__1, gf__opts__1661000108__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_New() *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A { A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Invoke_O_O_O__O(self, gf__x__1661000103__1, gf__opts__1661000104__2 any) any { var target_7 any = gf__x__1661000103__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_7 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_7) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_7, Lit_106, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000104__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_7).Make_output_stream_O__O(gf__opts__1661000104__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_A_New() *A_arbace_java_io_eval1661000091_fn__1661000112_A { A_arbace_java_io_eval1661000091_fn__1661000112_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000078__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_New(); var tmp2 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_Init(); tmp2 = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class; G__1661000078__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_New_O(G__1661000078__2_); var tmp4 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_Init(); tmp4 = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A { A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Ctor_O(c__G__1661000078 any) { t.F_G__1661000078 = c__G__1661000078 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Invoke_O_O_O__O(self, gf__x__1661000117__1, gf__opts__1661000118__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__1661000117__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000117__1, gf__opts__1661000118__2) } else { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_16; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__1661000117__1, tmp3.Ref(), t.F_G__1661000078)).Invoke_O_O__O(gf__x__1661000117__1, gf__opts__1661000118__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_New() *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A { A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Invoke_O_O_O__O(self, gf__x__1661000113__1, gf__opts__1661000114__2 any) any { var target_8 any = gf__x__1661000113__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_8 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_8) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_8, Lit_110, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000114__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_8).Make_reader_O__O(gf__opts__1661000114__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_A_New() *A_arbace_java_io_eval1661000091_fn__1661000122_A { A_arbace_java_io_eval1661000091_fn__1661000122_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Invoke_O_O__O(self, cache__231000238__auto____1 any) any { var G__1661000080__2_ any; var tmp1 any = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_New(); var tmp2 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_Init(); tmp2 = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class; G__1661000080__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var f__231000239__auto____3 any; var tmp3 any = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_New_O(G__1661000080__2_); var tmp4 *jrt.Class; A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_Init(); tmp4 = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class; f__231000239__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); lang.AFunction_Cast(f__231000239__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000238__auto____1)); return f__231000239__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A { A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Ctor_O(c__G__1661000080 any) { t.F_G__1661000080 = c__G__1661000080 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Invoke_O_O_O__O(self, gf__x__1661000127__1, gf__opts__1661000128__2 any) any { var cache__231000236__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000237__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000236__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class(gf__x__1661000127__1)); if jrt.A2g_Truth(f__231000237__auto____4) { return lang.IFn_Cast(f__231000237__auto____4).Invoke_O_O__O(gf__x__1661000127__1, gf__opts__1661000128__2) } else { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_16; return lang.IFn_Cast(tmp2.Invoke_O_O_O_O__O(self, gf__x__1661000127__1, tmp3.Ref(), t.F_G__1661000080)).Invoke_O_O__O(gf__x__1661000127__1, gf__opts__1661000128__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_New() *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A { A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Invoke_O_O_O__O(self, gf__x__1661000123__1, gf__opts__1661000124__2 any) any { var target_9 any = gf__x__1661000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_9 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z(target_9) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_9, Lit_114, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000124__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_9).Make_writer_O__O(gf__opts__1661000124__2) } }
















func A_arbace_java_io_reader_A_New() *A_arbace_java_io_reader_A { A_arbace_java_io_reader_A_Init(); t := &A_arbace_java_io_reader_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_java_io_reader_A) Ctor() {}
//line :89:1
func (t *A_arbace_java_io_reader_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {















	var target_10 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_10); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_10) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_10); var tmp4 any; if jrt.A2g_Truth(opts__1) { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_17; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_19; tmp4 = tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), opts__1) } else { tmp4 = nil }; return tmp3.Make_reader_O__O(tmp4) } else { var tmp8 *lang.Var; A_arbace_java_io_A_Init(); tmp8 = A_arbace_java_io_A_const_18; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; if jrt.A2g_Truth(opts__1) { var tmp11 *lang.Var; A_arbace_java_io_A_Init(); tmp11 = A_arbace_java_io_A_const_17; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_java_io_A_Init(); tmp13 = A_arbace_java_io_A_const_19; tmp10 = tmp12.Invoke_O_O__O(jrt.NN(tmp13).GetRawRoot__O(), opts__1) } else { tmp10 = nil }; return tmp9.Invoke_O_O__O(target_10, tmp10)
	} }
func A_arbace_java_io_writer_A_New() *A_arbace_java_io_writer_A { A_arbace_java_io_writer_A_Init(); t := &A_arbace_java_io_writer_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_java_io_writer_A) Ctor() {}
//line :107:1
func (t *A_arbace_java_io_writer_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_11 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_11); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_11) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_11); var tmp4 any; if jrt.A2g_Truth(opts__1) { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_17; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_19; tmp4 = tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), opts__1) } else { tmp4 = nil }; return tmp3.Make_writer_O__O(tmp4) } else { var tmp8 *lang.Var; A_arbace_java_io_A_Init(); tmp8 = A_arbace_java_io_A_const_20; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; if jrt.A2g_Truth(opts__1) { var tmp11 *lang.Var; A_arbace_java_io_A_Init(); tmp11 = A_arbace_java_io_A_const_17; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_java_io_A_Init(); tmp13 = A_arbace_java_io_A_const_19; tmp10 = tmp12.Invoke_O_O__O(jrt.NN(tmp13).GetRawRoot__O(), opts__1) } else { tmp10 = nil }; return tmp9.Invoke_O_O__O(target_11, tmp10)
	} }
func A_arbace_java_io_input_stream_A_New() *A_arbace_java_io_input_stream_A { A_arbace_java_io_input_stream_A_Init(); t := &A_arbace_java_io_input_stream_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_java_io_input_stream_A) Ctor() {}
//line :124:1
func (t *A_arbace_java_io_input_stream_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_12 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_12); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_12) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_12); var tmp4 any; if jrt.A2g_Truth(opts__1) { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_17; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_19; tmp4 = tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), opts__1) } else { tmp4 = nil }; return tmp3.Make_input_stream_O__O(tmp4) } else { var tmp8 *lang.Var; A_arbace_java_io_A_Init(); tmp8 = A_arbace_java_io_A_const_21; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; if jrt.A2g_Truth(opts__1) { var tmp11 *lang.Var; A_arbace_java_io_A_Init(); tmp11 = A_arbace_java_io_A_const_17; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_java_io_A_Init(); tmp13 = A_arbace_java_io_A_const_19; tmp10 = tmp12.Invoke_O_O__O(jrt.NN(tmp13).GetRawRoot__O(), opts__1) } else { tmp10 = nil }; return tmp9.Invoke_O_O__O(target_12, tmp10)
	} }
func A_arbace_java_io_output_stream_A_New() *A_arbace_java_io_output_stream_A { A_arbace_java_io_output_stream_A_Init(); t := &A_arbace_java_io_output_stream_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_java_io_output_stream_A) Ctor() {}
//line :141:1
func (t *A_arbace_java_io_output_stream_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_13 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_13); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_13) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_13); var tmp4 any; if jrt.A2g_Truth(opts__1) { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_17; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_19; tmp4 = tmp6.Invoke_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), opts__1) } else { tmp4 = nil }; return tmp3.Make_output_stream_O__O(tmp4) } else { var tmp8 *lang.Var; A_arbace_java_io_A_Init(); tmp8 = A_arbace_java_io_A_const_22; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any; if jrt.A2g_Truth(opts__1) { var tmp11 *lang.Var; A_arbace_java_io_A_Init(); tmp11 = A_arbace_java_io_A_const_17; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_java_io_A_Init(); tmp13 = A_arbace_java_io_A_const_19; tmp10 = tmp12.Invoke_O_O__O(jrt.NN(tmp13).GetRawRoot__O(), opts__1) } else { tmp10 = nil }; return tmp9.Invoke_O_O__O(target_13, tmp10)
	} }
func A_arbace_java_io_append_QMARK__A_New() *A_arbace_java_io_append_QMARK__A { A_arbace_java_io_append_QMARK__A_Init(); t := &A_arbace_java_io_append_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_java_io_append_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_java_io_append_QMARK__A) Invoke_O_O__O(self, opts__0 any) any {
	var tmp1 *lang.Keyword; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_23; return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp1).Invoke_O__O(opts__0))).Ref()
}
func A_arbace_java_io_encoding_A_New() *A_arbace_java_io_encoding_A { A_arbace_java_io_encoding_A_Init(); t := &A_arbace_java_io_encoding_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_java_io_encoding_A) Ctor() {}
//line :161:1
func (t *A_arbace_java_io_encoding_A) Invoke_O_O__O(self, opts__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword;
										A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_24; or__1927000174__auto____2 = jrt.NN(tmp1).Invoke_O__O(opts__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return Lit_48 } }

func A_arbace_java_io_buffer_size_A_New() *A_arbace_java_io_buffer_size_A { A_arbace_java_io_buffer_size_A_Init(); t := &A_arbace_java_io_buffer_size_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_java_io_buffer_size_A) Ctor() {}
//line :164:1
func (t *A_arbace_java_io_buffer_size_A) Invoke_O_O__O(self, opts__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword;
										A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_25; or__1927000174__auto____2 = jrt.NN(tmp1).Invoke_O__O(opts__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { A_arbace_java_io_A_Init(); return A_arbace_java_io_A_const_26 } }


func A_arbace_java_io_fn__1661000144_A_New() *A_arbace_java_io_fn__1661000144_A { A_arbace_java_io_fn__1661000144_A_Init(); t := &A_arbace_java_io_fn__1661000144_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_java_io_fn__1661000144_A) Ctor() {}
//line :168:1
func (t *A_arbace_java_io_fn__1661000144_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var target_14 any; var target_15 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_15); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_15) }; tmp1 = tmp2; if tmp1 { target_14 = A_arbace_java_io_IOFactory_A_Cast(target_15).Make_input_stream_O__O(opts__1) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_21; target_14 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_15, opts__1) }; var tmp4 bool; var tmp5 bool; tmp5 = A_arbace_java_io_IOFactory_A_InstanceOf(target_14); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_14) }; tmp4 = tmp5; if tmp4 { return A_arbace_java_io_IOFactory_A_Cast(target_14).Make_reader_O__O(opts__1) } else { var tmp6 *lang.Var; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_18; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(target_14, opts__1) } }
func A_arbace_java_io_fn__1661000146_A_New() *A_arbace_java_io_fn__1661000146_A { A_arbace_java_io_fn__1661000146_A_Init(); t := &A_arbace_java_io_fn__1661000146_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_java_io_fn__1661000146_A) Ctor() {}
//line :169:1
func (t *A_arbace_java_io_fn__1661000146_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var target_16 any; var target_17 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_17); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_17) }; tmp1 = tmp2; if tmp1 { target_16 = A_arbace_java_io_IOFactory_A_Cast(target_17).Make_output_stream_O__O(opts__1) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_22; target_16 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_17, opts__1) }; var tmp4 bool; var tmp5 bool; tmp5 = A_arbace_java_io_IOFactory_A_InstanceOf(target_16); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_16) }; tmp4 = tmp5; if tmp4 { return A_arbace_java_io_IOFactory_A_Cast(target_16).Make_writer_O__O(opts__1) } else { var tmp6 *lang.Var; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_20; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(target_16, opts__1) } }
func A_arbace_java_io_fn__1661000148_A_New() *A_arbace_java_io_fn__1661000148_A { A_arbace_java_io_fn__1661000148_A_Init(); t := &A_arbace_java_io_fn__1661000148_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_java_io_fn__1661000148_A) Ctor() {}
//line :170:1
func (t *A_arbace_java_io_fn__1661000148_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil, Lit_165); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_27; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0), nil))))) }


func A_arbace_java_io_fn__1661000150_A_New() *A_arbace_java_io_fn__1661000150_A { A_arbace_java_io_fn__1661000150_A_Init(); t := &A_arbace_java_io_fn__1661000150_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_java_io_fn__1661000150_A) Ctor() {}
//line :173:1
func (t *A_arbace_java_io_fn__1661000150_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil, Lit_167); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_27; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0), nil))))) }



func A_arbace_java_io_inputstream__GT_reader_A_New() *A_arbace_java_io_inputstream__GT_reader_A { A_arbace_java_io_inputstream__GT_reader_A_Init(); t := &A_arbace_java_io_inputstream__GT_reader_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_java_io_inputstream__GT_reader_A) Ctor() {}
//line :177:1
func (t *A_arbace_java_io_inputstream__GT_reader_A) Invoke_O_O_O__O(self, is__0, opts__1 any) any {

	var target_18 any; var tmp1 jrt.InputStream_I = jrt.InputStream_Cast(is__0); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_28; target_18 = jrt.InputStreamReader_New_InputStream_String(tmp1, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(opts__1))); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_18); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_18) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_18).Make_reader_O__O(opts__1) } else { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_18; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(target_18, opts__1)
	} }
func A_arbace_java_io_outputstream__GT_writer_A_New() *A_arbace_java_io_outputstream__GT_writer_A { A_arbace_java_io_outputstream__GT_writer_A_Init(); t := &A_arbace_java_io_outputstream__GT_writer_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_java_io_outputstream__GT_writer_A) Ctor() {}
//line :181:1
func (t *A_arbace_java_io_outputstream__GT_writer_A) Invoke_O_O_O__O(self, os__0, opts__1 any) any {

	var target_19 any; var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(os__0); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_28; target_19 = jrt.OutputStreamWriter_New_OutputStream_String(tmp1, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(opts__1))); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_19); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_19) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_19).Make_writer_O__O(opts__1) } else { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_20; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(target_19, opts__1)
	}
}


func A_arbace_java_io_eval1661000154_fn__1661000155_A_New() *A_arbace_java_io_eval1661000154_fn__1661000155_A { A_arbace_java_io_eval1661000154_fn__1661000155_A_Init(); t := &A_arbace_java_io_eval1661000154_fn__1661000155_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Ctor() {}
//line :188:1
func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }





func A_arbace_java_io_eval1661000158_fn__1661000159_A_New() *A_arbace_java_io_eval1661000158_fn__1661000159_A { A_arbace_java_io_eval1661000158_fn__1661000159_A_Init(); t := &A_arbace_java_io_eval1661000158_fn__1661000159_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Ctor() {}
//line :194:1
func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedInputStream_New_InputStream(jrt.InputStream_Cast(x__1)) }





func A_arbace_java_io_eval1661000162_fn__1661000163_A_New() *A_arbace_java_io_eval1661000162_fn__1661000163_A { A_arbace_java_io_eval1661000162_fn__1661000163_A_Init(); t := &A_arbace_java_io_eval1661000162_fn__1661000163_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Ctor() {}
//line :200:1
func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedReader_New_Reader(jrt.Reader_Cast(x__1)) }




func A_arbace_java_io_eval1661000166_fn__1661000167_A_New() *A_arbace_java_io_eval1661000166_fn__1661000167_A { A_arbace_java_io_eval1661000166_fn__1661000167_A_Init(); t := &A_arbace_java_io_eval1661000166_fn__1661000167_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Ctor() {}
//line :205:1
func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }




func A_arbace_java_io_eval1661000170_fn__1661000171_A_New() *A_arbace_java_io_eval1661000170_fn__1661000171_A { A_arbace_java_io_eval1661000170_fn__1661000171_A_Init(); t := &A_arbace_java_io_eval1661000170_fn__1661000171_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Ctor() {}
//line :210:1
func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedWriter_New_Writer(jrt.Writer_Cast(x__1)) }




func A_arbace_java_io_eval1661000174_fn__1661000175_A_New() *A_arbace_java_io_eval1661000174_fn__1661000175_A { A_arbace_java_io_eval1661000174_fn__1661000175_A_Init(); t := &A_arbace_java_io_eval1661000174_fn__1661000175_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Ctor() {}
//line :215:1
func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }




func A_arbace_java_io_eval1661000178_fn__1661000179_A_New() *A_arbace_java_io_eval1661000178_fn__1661000179_A { A_arbace_java_io_eval1661000178_fn__1661000179_A_Init(); t := &A_arbace_java_io_eval1661000178_fn__1661000179_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Ctor() {}
//line :220:1
func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedOutputStream_New_OutputStream(jrt.OutputStream_Cast(x__1)) }





func A_arbace_java_io_eval1661000182_fn__1661000183_A_New() *A_arbace_java_io_eval1661000182_fn__1661000183_A { A_arbace_java_io_eval1661000182_fn__1661000183_A_Init(); t := &A_arbace_java_io_eval1661000182_fn__1661000183_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Ctor() {}
//line :226:1
func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }





func A_arbace_java_io_eval1661000186_fn__1661000187_A_New() *A_arbace_java_io_eval1661000186_fn__1661000187_A { A_arbace_java_io_eval1661000186_fn__1661000187_A_Init(); t := &A_arbace_java_io_eval1661000186_fn__1661000187_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Ctor() {}
//line :232:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_20 any = jrt.FileInputStream_New_File(jrt.File_Cast(x__1)); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_20); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_20) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_20).Make_input_stream_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_21; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_20, opts__2) } }
func A_arbace_java_io_eval1661000186_fn__1661000189_A_New() *A_arbace_java_io_eval1661000186_fn__1661000189_A { A_arbace_java_io_eval1661000186_fn__1661000189_A_Init(); t := &A_arbace_java_io_eval1661000186_fn__1661000189_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Ctor() {}
//line :233:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_21 any; var tmp1 *jrt.File = jrt.File_Cast(x__1); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_29; target_21 = jrt.FileOutputStream_New_File_Z(tmp1, jrt.NN(jrt.Boolean_Cast(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(opts__2))).BooleanValue__Z()); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_21); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z(target_21) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_21).Make_output_stream_O__O(opts__2) } else { var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_22; return lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(target_21, opts__2) } }




func A_arbace_java_io_eval1661000192_fn__1661000193_A_New() *A_arbace_java_io_eval1661000192_fn__1661000193_A { A_arbace_java_io_eval1661000192_fn__1661000193_A_Init(); t := &A_arbace_java_io_eval1661000192_fn__1661000193_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Ctor() {}
//line :238:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any {
	var target_22 any
	if lang.Util_Equiv_O_O__Z(Lit_35, jrt.NN(jrt.URL_Cast(x__1)).GetProtocol__String().Ref()) { var tmp1 any; var target_23 any = x__1; var tmp2 bool; var tmp3 bool
		tmp3 = A_arbace_java_io_Coercions_A_InstanceOf(target_23); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_23) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_Coercions_A_Cast(target_23).As_file__O() } else { var tmp4 *lang.Var; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_13; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(target_23) }
//line :240:1
		target_22 = jrt.FileInputStream_New_File(jrt.File_Cast(tmp1)) } else {

			target_22 = jrt.NN(jrt.URL_Cast(x__1)).OpenStream__InputStream() }
//line :239:1
	var tmp5 bool; var tmp6 bool; tmp6 = A_arbace_java_io_IOFactory_A_InstanceOf(target_22); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z(target_22) }; tmp5 = tmp6; if tmp5 { return A_arbace_java_io_IOFactory_A_Cast(target_22).Make_input_stream_O__O(opts__2) } else { var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_21; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(target_22, opts__2)
	}
}

func A_arbace_java_io_eval1661000192_fn__1661000195_A_New() *A_arbace_java_io_eval1661000192_fn__1661000195_A { A_arbace_java_io_eval1661000192_fn__1661000195_A_Init(); t := &A_arbace_java_io_eval1661000192_fn__1661000195_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Ctor() {}
//line :243:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any {
	if lang.Util_Equiv_O_O__Z(Lit_35, jrt.NN(jrt.URL_Cast(x__1)).GetProtocol__String().Ref()) {
		var target_24 any; var target_25 any = x__1; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_25); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_25) }; tmp1 = tmp2; if tmp1 { target_24 = A_arbace_java_io_Coercions_A_Cast(target_25).As_file__O() } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_13; target_24 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(target_25) }; var tmp4 bool; var tmp5 bool; tmp5 = A_arbace_java_io_IOFactory_A_InstanceOf(target_24); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z(target_24) }; tmp4 = tmp5; if tmp4 { return A_arbace_java_io_IOFactory_A_Cast(target_24).Make_output_stream_O__O(opts__2) } else { var tmp6 *lang.Var; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_22; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(target_24, opts__2) } } else {
//line :244:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_127, nil, Lit_128), jrt.RefArrayOf(jrt.Object_class, nil, x__1, nil)))))
		}
}




func A_arbace_java_io_eval1661000198_fn__1661000199_A_New() *A_arbace_java_io_eval1661000198_fn__1661000199_A { A_arbace_java_io_eval1661000198_fn__1661000199_A_Init(); t := &A_arbace_java_io_eval1661000198_fn__1661000199_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Ctor() {}
//line :251:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_26 any = jrt.NN(jrt.URI_Cast(x__1)).ToURL__URL().Ref(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_26); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_26) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_26).Make_input_stream_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_21; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_26, opts__2) } }
func A_arbace_java_io_eval1661000198_fn__1661000201_A_New() *A_arbace_java_io_eval1661000198_fn__1661000201_A { A_arbace_java_io_eval1661000198_fn__1661000201_A_Init(); t := &A_arbace_java_io_eval1661000198_fn__1661000201_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Ctor() {}
//line :252:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_27 any = jrt.NN(jrt.URI_Cast(x__1)).ToURL__URL().Ref(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_27); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_27) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_27).Make_output_stream_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_22; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_27, opts__2) } }




func A_arbace_java_io_eval1661000204_fn__1661000205_A_New() *A_arbace_java_io_eval1661000204_fn__1661000205_A { A_arbace_java_io_eval1661000204_fn__1661000205_A_Init(); t := &A_arbace_java_io_eval1661000204_fn__1661000205_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Ctor() {}
//line :257:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var target_28 any = lang.RT_ToUrl_String__URL(jrt.String_Cast(x__1)).Ref(); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_java_io_IOFactory_A_InstanceOf(target_28); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_28) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_28).Make_input_stream_O__O(opts__2) } else { var tmp4 *lang.Var; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_21; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(target_28, opts__2) } }
//line :257:1
	return nil }(); if tmp5 != nil { if jrt.MalformedURLException_InstanceOf(tmp5) { var e__5 *jrt.MalformedURLException = jrt.MalformedURLException_Cast(tmp5); var target_29 any = jrt.File_New_String(jrt.String_Cast(x__1)); var tmp6 bool; var tmp7 bool; _ = e__5



		tmp7 = A_arbace_java_io_IOFactory_A_InstanceOf(target_29); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z(target_29) }; tmp6 = tmp7; if tmp6 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_29).Make_input_stream_O__O(opts__2) } else { var tmp8 *lang.Var; A_arbace_java_io_A_Init(); tmp8 = A_arbace_java_io_A_const_21; tmp1 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(target_29, opts__2) } } else {
//line :257:1
			panic(tmp5) } }; return tmp1 }




func A_arbace_java_io_eval1661000204_fn__1661000207_A_New() *A_arbace_java_io_eval1661000204_fn__1661000207_A { A_arbace_java_io_eval1661000204_fn__1661000207_A_Init(); t := &A_arbace_java_io_eval1661000204_fn__1661000207_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Ctor() {}
//line :262:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var target_30 any = lang.RT_ToUrl_String__URL(jrt.String_Cast(x__1)).Ref(); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_java_io_IOFactory_A_InstanceOf(target_30); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_30) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_30).Make_output_stream_O__O(opts__2) } else { var tmp4 *lang.Var; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_22; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(target_30, opts__2) } }
//line :262:1
	return nil }(); if tmp5 != nil { if jrt.MalformedURLException_InstanceOf(tmp5) { var err__5 *jrt.MalformedURLException = jrt.MalformedURLException_Cast(tmp5); var target_31 any = jrt.File_New_String(jrt.String_Cast(x__1)); var tmp6 bool; var tmp7 bool; _ = err__5



		tmp7 = A_arbace_java_io_IOFactory_A_InstanceOf(target_31); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z(target_31) }; tmp6 = tmp7; if tmp6 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_31).Make_output_stream_O__O(opts__2) } else { var tmp8 *lang.Var; A_arbace_java_io_A_Init(); tmp8 = A_arbace_java_io_A_const_22; tmp1 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(target_31, opts__2) } } else {
//line :262:1
			panic(tmp5) } }; return tmp1 }








func A_arbace_java_io_eval1661000210_fn__1661000211_A_New() *A_arbace_java_io_eval1661000210_fn__1661000211_A { A_arbace_java_io_eval1661000210_fn__1661000211_A_Init(); t := &A_arbace_java_io_eval1661000210_fn__1661000211_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Ctor() {}
//line :271:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_32 any = jrt.Socket_Cast(x__1).GetInputStream__InputStream(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_32); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_32) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_32).Make_input_stream_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_21; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_32, opts__2) } }
func A_arbace_java_io_eval1661000210_fn__1661000213_A_New() *A_arbace_java_io_eval1661000210_fn__1661000213_A { A_arbace_java_io_eval1661000210_fn__1661000213_A_Init(); t := &A_arbace_java_io_eval1661000210_fn__1661000213_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Ctor() {}
//line :272:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_33 any = jrt.Socket_Cast(x__1).GetOutputStream__OutputStream(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_33); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_33) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_33).Make_output_stream_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_22; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_33, opts__2) } }




func A_arbace_java_io_eval1661000216_fn__1661000217_A_New() *A_arbace_java_io_eval1661000216_fn__1661000217_A { A_arbace_java_io_eval1661000216_fn__1661000217_A_Init(); t := &A_arbace_java_io_eval1661000216_fn__1661000217_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Ctor() {}
//line :277:1
func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_34 any = jrt.ByteArrayInputStream_New_B1(jrt.A2g_CastArray[*jrt.ByteArray](x__1, jrt.Prim_byte.ArrayClass())); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_34); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_34) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_34).Make_input_stream_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_21; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_34, opts__2) } }




func A_arbace_java_io_eval1661000220_fn__1661000221_A_New() *A_arbace_java_io_eval1661000220_fn__1661000221_A { A_arbace_java_io_eval1661000220_fn__1661000221_A_Init(); t := &A_arbace_java_io_eval1661000220_fn__1661000221_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Ctor() {}
//line :282:1
func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_35 any = jrt.CharArrayReader_New_C1(jrt.A2g_CastArray[*jrt.CharArray](x__1, jrt.Prim_char.ArrayClass())); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_35); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_35) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_35).Make_reader_O__O(opts__2) } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_18; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(target_35, opts__2) } }








func A_arbace_java_io_eval1661000226_fn__1661000227_A_New() *A_arbace_java_io_eval1661000226_fn__1661000227_A { A_arbace_java_io_eval1661000226_fn__1661000227_A_Init(); t := &A_arbace_java_io_eval1661000226_fn__1661000227_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Ctor() {}
//line :291:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil, Lit_139); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_27; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1), nil))))) }


func A_arbace_java_io_eval1661000226_fn__1661000229_A_New() *A_arbace_java_io_eval1661000226_fn__1661000229_A { A_arbace_java_io_eval1661000226_fn__1661000229_A_Init(); t := &A_arbace_java_io_eval1661000226_fn__1661000229_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Ctor() {}
//line :294:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_138, nil, Lit_141); var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_27; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__1), nil))))) }








func A_arbace_java_io_eval1661000232_fn__1661000233_A_New() *A_arbace_java_io_eval1661000232_fn__1661000233_A { A_arbace_java_io_eval1661000232_fn__1661000233_A_Init(); t := &A_arbace_java_io_eval1661000232_fn__1661000233_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Ctor() {}
//line :303:1
func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_30; var tmp2 any = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(input__1); var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_30; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(output__2)) }

func A_arbace_java_io_eval1661000236_fn__1661000237_A_New() *A_arbace_java_io_eval1661000236_fn__1661000237_A { A_arbace_java_io_eval1661000236_fn__1661000237_A_Init(); t := &A_arbace_java_io_eval1661000236_fn__1661000237_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Ctor() {}
//line :305:1
func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var tmp1 *lang.Var
																A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; jrt.Byte_Init(); tmp3 = jrt.Byte_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_32; buffer__4 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(opts__3))
//line :305:1
L1: for { var size__5 int32 = jrt.InputStream_Cast(input__1).Read_B1__I(jrt.A2g_CastArray[*jrt.ByteArray](buffer__4, jrt.Prim_byte.ArrayClass()))



	if lang.Numbers_IsPos_J__Z(int64(size__5)) {
		jrt.OutputStream_Cast(output__2).Write_B1_I_I__V(jrt.A2g_CastArray[*jrt.ByteArray](buffer__4, jrt.Prim_byte.ArrayClass()), lang.RT_IntCast_J__I(0), size__5)
		continue L1 } else {
//line :309:1
			return nil } } }; /*line :305:1*/panic("a2g: unreachable") }







func A_arbace_java_io_eval1661000240_fn__1661000241_A_New() *A_arbace_java_io_eval1661000240_fn__1661000241_A { A_arbace_java_io_eval1661000240_fn__1661000241_A_Init(); t := &A_arbace_java_io_eval1661000240_fn__1661000241_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Ctor() {}
//line :313:1
func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var tmp1 *lang.Var
																A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; jrt.Character_Init(); tmp3 = jrt.Character_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_32; buffer__4 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(opts__3))
//line :313:1
	var in__5 any; var tmp6 jrt.InputStream_I = jrt.InputStream_Cast(input__1); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_28; in__5 = jrt.InputStreamReader_New_InputStream_String(tmp6, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(opts__3))); L1: for { var size__6 int32 = jrt.InputStreamReader_Cast(in__5).Read_C1_I_I__I(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I(0), lang.RT_Alength_C1__I(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass())))




		if lang.Numbers_IsPos_J__Z(int64(size__6)) {
			jrt.Writer_Cast(output__2).Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I(0), size__6)
			continue L1 } else {
//line :318:1
				return nil } } }; /*line :313:1*/panic("a2g: unreachable") }








func A_arbace_java_io_eval1661000244_fn__1661000245_A_New() *A_arbace_java_io_eval1661000244_fn__1661000245_A { A_arbace_java_io_eval1661000244_fn__1661000245_A_Init(); t := &A_arbace_java_io_eval1661000244_fn__1661000245_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Ctor() {}
//line :322:1
func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var out__4 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_33; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(input__1, out__4, opts__3) }
//line :322:1
	return nil }();
	jrt.FileOutputStream_Cast(out__4).Close__V(); if /*line :322:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }



func A_arbace_java_io_eval1661000248_fn__1661000249_A_New() *A_arbace_java_io_eval1661000248_fn__1661000249_A { A_arbace_java_io_eval1661000248_fn__1661000249_A_Init(); t := &A_arbace_java_io_eval1661000248_fn__1661000249_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Ctor() {}
//line :326:1
func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var tmp1 *lang.Var
																A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; jrt.Character_Init(); tmp3 = jrt.Character_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_32; buffer__4 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(opts__3))
//line :326:1
	var out__5 any; var tmp6 jrt.OutputStream_I = jrt.OutputStream_Cast(output__2); var tmp7 *lang.Var; A_arbace_java_io_A_Init(); tmp7 = A_arbace_java_io_A_const_28; out__5 = jrt.OutputStreamWriter_New_OutputStream_String(tmp6, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(opts__3))); L1: for { var size__6 int32 = jrt.Reader_Cast(input__1).Read_C1__I(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()))




		if lang.Numbers_IsPos_J__Z(int64(size__6)) {

			jrt.OutputStreamWriter_Cast(out__5).Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I(0), size__6)
			continue L1 } else {
				jrt.OutputStreamWriter_Cast(out__5).Flush__V(); return nil } } }; /*line :326:1*/panic("a2g: unreachable") }










func A_arbace_java_io_eval1661000252_fn__1661000253_A_New() *A_arbace_java_io_eval1661000252_fn__1661000253_A { A_arbace_java_io_eval1661000252_fn__1661000253_A_Init(); t := &A_arbace_java_io_eval1661000252_fn__1661000253_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Ctor() {}
//line :337:1
func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var tmp1 *lang.Var
																A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *jrt.Class; jrt.Character_Init(); tmp3 = jrt.Character_TYPE; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_32; buffer__4 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(opts__3))
//line :337:1
L1: for { var size__5 int32 = jrt.Reader_Cast(input__1).Read_C1__I(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()))



	if lang.Numbers_IsPos_J__Z(int64(size__5)) {
		jrt.Writer_Cast(output__2).Write_C1_I_I__V(jrt.A2g_CastArray[*jrt.CharArray](buffer__4, jrt.Prim_char.ArrayClass()), lang.RT_IntCast_J__I(0), size__5)
		continue L1 } else {
//line :341:1
			return nil } } }; /*line :337:1*/panic("a2g: unreachable") }







func A_arbace_java_io_eval1661000256_fn__1661000257_A_New() *A_arbace_java_io_eval1661000256_fn__1661000257_A { A_arbace_java_io_eval1661000256_fn__1661000257_A_Init(); t := &A_arbace_java_io_eval1661000256_fn__1661000257_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Ctor() {}
//line :345:1
func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var out__4 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_33; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(input__1, out__4, opts__3) }
//line :345:1
	return nil }();
	jrt.FileOutputStream_Cast(out__4).Close__V(); if /*line :345:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }



func A_arbace_java_io_eval1661000260_fn__1661000261_A_New() *A_arbace_java_io_eval1661000260_fn__1661000261_A { A_arbace_java_io_eval1661000260_fn__1661000261_A_Init(); t := &A_arbace_java_io_eval1661000260_fn__1661000261_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Ctor() {}
//line :349:1
func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_33; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(in__4, output__2, opts__3) }
//line :349:1
	return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :349:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }



func A_arbace_java_io_eval1661000264_fn__1661000265_A_New() *A_arbace_java_io_eval1661000264_fn__1661000265_A { A_arbace_java_io_eval1661000264_fn__1661000265_A_Init(); t := &A_arbace_java_io_eval1661000264_fn__1661000265_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Ctor() {}
//line :353:1
func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var tmp2 *lang.Var; A_arbace_java_io_A_Init(); tmp2 = A_arbace_java_io_A_const_33; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(in__4, output__2, opts__3) }
//line :353:1
	return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :353:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }



func A_arbace_java_io_eval1661000268_fn__1661000269_A_New() *A_arbace_java_io_eval1661000268_fn__1661000269_A { A_arbace_java_io_eval1661000268_fn__1661000269_A_Init(); t := &A_arbace_java_io_eval1661000268_fn__1661000269_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Ctor() {}
//line :357:1
func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__7 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	jrt.Long_ValueOf_J__Long(jrt.InputStream_Cast(in__4).TransferTo_OutputStream__J(jrt.OutputStream_Cast(out__7)))
//line :357:1
	tmp1 = nil; return nil }()
	jrt.FileOutputStream_Cast(out__7).Close__V()
//line :357:1
	if tmp2 != nil { panic(tmp2) } }; return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :357:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }





func A_arbace_java_io_eval1661000272_fn__1661000273_A_New() *A_arbace_java_io_eval1661000272_fn__1661000273_A { A_arbace_java_io_eval1661000272_fn__1661000273_A_Init(); t := &A_arbace_java_io_eval1661000272_fn__1661000273_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Ctor() {}
//line :363:1
func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000276_fn__1661000277_A_New() *A_arbace_java_io_eval1661000276_fn__1661000277_A { A_arbace_java_io_eval1661000276_fn__1661000277_A_Init(); t := &A_arbace_java_io_eval1661000276_fn__1661000277_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Ctor() {}
//line :366:1
func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000280_fn__1661000281_A_New() *A_arbace_java_io_eval1661000280_fn__1661000281_A { A_arbace_java_io_eval1661000280_fn__1661000281_A_Init(); t := &A_arbace_java_io_eval1661000280_fn__1661000281_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Ctor() {}
//line :369:1
func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000284_fn__1661000285_A_New() *A_arbace_java_io_eval1661000284_fn__1661000285_A { A_arbace_java_io_eval1661000284_fn__1661000285_A_Init(); t := &A_arbace_java_io_eval1661000284_fn__1661000285_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Ctor() {}
//line :372:1
func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.A2g_CastArray[*jrt.CharArray](input__1, jrt.Prim_char.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000288_fn__1661000289_A_New() *A_arbace_java_io_eval1661000288_fn__1661000289_A { A_arbace_java_io_eval1661000288_fn__1661000289_A_Init(); t := &A_arbace_java_io_eval1661000288_fn__1661000289_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Ctor() {}
//line :375:1
func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.A2g_CastArray[*jrt.CharArray](input__1, jrt.Prim_char.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000292_fn__1661000293_A_New() *A_arbace_java_io_eval1661000292_fn__1661000293_A { A_arbace_java_io_eval1661000292_fn__1661000293_A_Init(); t := &A_arbace_java_io_eval1661000292_fn__1661000293_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Ctor() {}
//line :378:1
func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.A2g_CastArray[*jrt.CharArray](input__1, jrt.Prim_char.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000296_fn__1661000297_A_New() *A_arbace_java_io_eval1661000296_fn__1661000297_A { A_arbace_java_io_eval1661000296_fn__1661000297_A_Init(); t := &A_arbace_java_io_eval1661000296_fn__1661000297_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Ctor() {}
//line :381:1
func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.A2g_CastArray[*jrt.ByteArray](input__1, jrt.Prim_byte.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000300_fn__1661000301_A_New() *A_arbace_java_io_eval1661000300_fn__1661000301_A { A_arbace_java_io_eval1661000300_fn__1661000301_A_Init(); t := &A_arbace_java_io_eval1661000300_fn__1661000301_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Ctor() {}
//line :384:1
func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.A2g_CastArray[*jrt.ByteArray](input__1, jrt.Prim_byte.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_eval1661000304_fn__1661000305_A_New() *A_arbace_java_io_eval1661000304_fn__1661000305_A { A_arbace_java_io_eval1661000304_fn__1661000305_A_Init(); t := &A_arbace_java_io_eval1661000304_fn__1661000305_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Ctor() {}
//line :387:1
func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.A2g_CastArray[*jrt.ByteArray](input__1, jrt.Prim_byte.ArrayClass())), output__2, opts__3)
}
func A_arbace_java_io_copy_A_New() *A_arbace_java_io_copy_A { A_arbace_java_io_copy_A_Init(); t := &A_arbace_java_io_copy_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_java_io_copy_A) Ctor() {}
//line :390:1
func (t *A_arbace_java_io_copy_A) DoInvoke_O_O_O_O__O(self, input__0, output__1, opts__2 any) any {














	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_33; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; if jrt.A2g_Truth(opts__2) { var tmp4 *lang.Var; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_17; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_19; tmp3 = tmp5.Invoke_O_O__O(jrt.NN(tmp6).GetRawRoot__O(), opts__2) } else { tmp3 = nil }; return tmp2.Invoke_O_O_O__O(input__0, output__1, tmp3)
}
func A_arbace_java_io_as_relative_path_A_New() *A_arbace_java_io_as_relative_path_A { A_arbace_java_io_as_relative_path_A_Init(); t := &A_arbace_java_io_as_relative_path_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_java_io_as_relative_path_A) Ctor() {}
//line :407:1
func (t *A_arbace_java_io_as_relative_path_A) Invoke_O_O__O(self, x__0 any) any { var f__2 any; var target_36 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 =




	A_arbace_java_io_Coercions_A_InstanceOf(target_36); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_36) }; tmp1 = tmp2; if tmp1 { f__2 = A_arbace_java_io_Coercions_A_Cast(target_36).As_file__O() } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_13; f__2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(target_36) }; if
	jrt.NN(jrt.File_Cast(f__2)).IsAbsolute__Z() { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_42), jrt.RefArrayOf(jrt.Object_class, f__2, nil))))) } else {

		return jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref() } }

func A_arbace_java_io_file_A_New() *A_arbace_java_io_file_A { A_arbace_java_io_file_A_Init(); t := &A_arbace_java_io_file_A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_java_io_file_A) Ctor() {}
//line :417:1
func (t *A_arbace_java_io_file_A) DoInvoke_O_O_O_O__O(self, parent__0, child__1, more__2 any) any {









	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_34; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_35; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_java_io_A_Init(); tmp5 = A_arbace_java_io_A_const_35; return tmp2.Invoke_O_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(parent__0, child__1), more__2) }
//line :417:1
func (t *A_arbace_java_io_file_A) Invoke_O_O_O__O(self, parent__0, child__1 any) any { var tmp1 any; var target_37 any = parent__0; var tmp2 bool; var tmp3 bool; tmp3 =







	A_arbace_java_io_Coercions_A_InstanceOf(target_37); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z(target_37) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_Coercions_A_Cast(target_37).As_file__O() } else { var tmp4 *lang.Var; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_13; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(target_37) }; var tmp5 /*line :417:1*/*jrt.File = jrt.File_Cast(tmp1); var tmp6 *lang.Var; A_arbace_java_io_A_Init(); tmp6 = A_arbace_java_io_A_const_36; return jrt.File_New_File_String(tmp5, jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(child__1))) }
//line :417:1
func (t *A_arbace_java_io_file_A) Invoke_O_O__O(self, arg__0 any) any {





	var target_38 any = arg__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_38); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z(target_38) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_Coercions_A_Cast(target_38).As_file__O() } else { var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_13; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(target_38)
	}
}



func A_arbace_java_io_delete_file_A_New() *A_arbace_java_io_delete_file_A { A_arbace_java_io_delete_file_A_Init(); t := &A_arbace_java_io_delete_file_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_java_io_delete_file_A) Ctor() {}
//line :429:1
func (t *A_arbace_java_io_delete_file_A) DoInvoke_O_O_O__O(self, f__0, p__1661000311__1 any) any { var vec__1661000312__3 any = p__1661000311__1; var silently__4 any = lang.RT_Nth_O_I_O__O(vec__1661000312__3, lang.RT_IntCast_J__I(0), nil); var or__1927000174__auto____5 bool; var tmp1 *lang.Var;



	A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_35; or__1927000174__auto____5 = jrt.NN(jrt.File_Cast(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__0))).Delete__Z(); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 any = silently__4; if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_46, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__0))))) } } }



func A_arbace_java_io_make_parents_A_New() *A_arbace_java_io_make_parents_A { A_arbace_java_io_make_parents_A_Init(); t := &A_arbace_java_io_make_parents_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_java_io_make_parents_A) Ctor() {}
//line :437:1
func (t *A_arbace_java_io_make_parents_A) DoInvoke_O_O_O__O(self, f__0, more__1 any) any { var temp__1927000414__auto____3 any; var tmp1 *lang.Var;




	A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_17; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_io_A_Init(); tmp3 = A_arbace_java_io_A_const_35; temp__1927000414__auto____3 = jrt.NN(jrt.File_Cast(tmp2.Invoke_O_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), f__0, more__1))).GetParentFile__File().Ref(); if jrt.A2g_Truth(temp__1927000414__auto____3) { var parent__4 any = temp__1927000414__auto____3
		return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.File_Cast(parent__4)).Mkdirs__Z()).Ref() } else {
//line :442:1
			return nil } }


func A_arbace_java_io_resource_A_New() *A_arbace_java_io_resource_A { A_arbace_java_io_resource_A_Init(); t := &A_arbace_java_io_resource_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_java_io_resource_A) Ctor() {}
//line :445:1
func (t *A_arbace_java_io_resource_A) Invoke_O_O_O__O(self, n__0, loader__1 any) any {




	var tmp1 *jrt.Class; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_37; var tmp2 *jrt.Class = tmp1; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(loader__1, tmp2, Lit_175, jrt.RefArrayOf(jrt.Object_class, n__0)) }
//line :445:1
func (t *A_arbace_java_io_resource_A) Invoke_O_O__O(self, n__0 any) any {



	var tmp1 *lang.Var; A_arbace_java_io_A_Init(); tmp1 = A_arbace_java_io_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = jrt.Thread_CurrentThread__Thread(); var tmp4 *jrt.Class; A_arbace_java_io_A_Init(); tmp4 = A_arbace_java_io_A_const_39; var tmp5 *jrt.Class = tmp4; return tmp2.Invoke_O_O__O(n__0, lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp3, tmp5, Lit_176, jrt.RefArrayOf(jrt.Object_class)))
}

































































































































type A_arbace_java_io_A struct{ jrt.Object }

var A_arbace_java_io_A_const_0 *lang.Var

var A_arbace_java_io_A_const_1 *lang.Var

var A_arbace_java_io_A_const_2 any

var A_arbace_java_io_A_const_3 any

var A_arbace_java_io_A_const_4 *lang.Var

var A_arbace_java_io_A_const_5 *lang.Var

var A_arbace_java_io_A_const_6 *lang.Var

var A_arbace_java_io_A_const_7 any

var A_arbace_java_io_A_const_8 *lang.Var

var A_arbace_java_io_A_const_9 *lang.Var

var A_arbace_java_io_A_const_10 *jrt.Class

var A_arbace_java_io_A_const_11 *lang.Var

var A_arbace_java_io_A_const_12 *lang.Var

var A_arbace_java_io_A_const_13 *lang.Var

var A_arbace_java_io_A_const_14 any

var A_arbace_java_io_A_const_15 *lang.Var

var A_arbace_java_io_A_const_16 *jrt.Class

var A_arbace_java_io_A_const_17 *lang.Var

var A_arbace_java_io_A_const_18 *lang.Var

var A_arbace_java_io_A_const_19 *lang.Var

var A_arbace_java_io_A_const_20 *lang.Var

var A_arbace_java_io_A_const_21 *lang.Var

var A_arbace_java_io_A_const_22 *lang.Var

var A_arbace_java_io_A_const_23 *lang.Keyword

var A_arbace_java_io_A_const_24 *lang.Keyword

var A_arbace_java_io_A_const_25 *lang.Keyword

var A_arbace_java_io_A_const_26 any

var A_arbace_java_io_A_const_27 *lang.Var

var A_arbace_java_io_A_const_28 *lang.Var

var A_arbace_java_io_A_const_29 *lang.Var

var A_arbace_java_io_A_const_30 *lang.Var

var A_arbace_java_io_A_const_31 *lang.Var

var A_arbace_java_io_A_const_32 *lang.Var

var A_arbace_java_io_A_const_33 *lang.Var

var A_arbace_java_io_A_const_34 *lang.Var

var A_arbace_java_io_A_const_35 *lang.Var

var A_arbace_java_io_A_const_36 *lang.Var

var A_arbace_java_io_A_const_37 *jrt.Class

var A_arbace_java_io_A_const_38 *lang.Var

var A_arbace_java_io_A_const_39 *jrt.Class

var A_arbace_java_io_A_init jrt.ClassInit

func A_arbace_java_io_A_Init() { if !A_arbace_java_io_A_init.Done() { A_arbace_java_io_A_init.Run(A_arbace_java_io_A_clinit) } }

func A_arbace_java_io_A_clinit() { A_arbace_java_io_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_java_io_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_java_io_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_java_io_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(); A_arbace_java_io_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_java_io_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_java_io_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_java_io_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_7)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_java_io_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_java_io_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_java_io_A_const_10 = lang.RT_ClassForNameNonLoading_String__Class(Lit_14); A_arbace_java_io_A_const_11 = lang.RT_Var_String_String__Var(Lit_3, Lit_15); A_arbace_java_io_A_const_12 = lang.RT_Var_String_String__Var(Lit_7, Lit_16); A_arbace_java_io_A_const_13 = lang.RT_Var_String_String__Var(Lit_7, Lit_17); A_arbace_java_io_A_const_14 = jrt.Character_ValueOf_C__Character(47).Ref(); A_arbace_java_io_A_const_15 = lang.RT_Var_String_String__Var(Lit_7, Lit_18); A_arbace_java_io_A_const_16 = lang.RT_ClassForNameNonLoading_String__Class(Lit_19); A_arbace_java_io_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_java_io_A_const_18 = lang.RT_Var_String_String__Var(Lit_7, Lit_21); A_arbace_java_io_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_java_io_A_const_20 = lang.RT_Var_String_String__Var(Lit_7, Lit_23); A_arbace_java_io_A_const_21 = lang.RT_Var_String_String__Var(Lit_7, Lit_24); A_arbace_java_io_A_const_22 = lang.RT_Var_String_String__Var(Lit_7, Lit_25); A_arbace_java_io_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_java_io_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_java_io_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_java_io_A_const_26 = jrt.Long_ValueOf_J__Long(1024).Ref(); A_arbace_java_io_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_java_io_A_const_28 = lang.RT_Var_String_String__Var(Lit_7, Lit_27); A_arbace_java_io_A_const_29 = lang.RT_Var_String_String__Var(Lit_7, Lit_30); A_arbace_java_io_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_java_io_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_java_io_A_const_32 = lang.RT_Var_String_String__Var(Lit_7, Lit_28); A_arbace_java_io_A_const_33 = lang.RT_Var_String_String__Var(Lit_7, Lit_33); A_arbace_java_io_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_java_io_A_const_35 = lang.RT_Var_String_String__Var(Lit_7, Lit_35); A_arbace_java_io_A_const_36 = lang.RT_Var_String_String__Var(Lit_7, Lit_36); A_arbace_java_io_A_const_37 = lang.RT_ClassForNameNonLoading_String__Class(Lit_37); A_arbace_java_io_A_const_38 = lang.RT_Var_String_String__Var(Lit_7, Lit_38); A_arbace_java_io_A_const_39 = lang.RT_ClassForNameNonLoading_String__Class(Lit_39) }

func A_arbace_java_io_A_New() *A_arbace_java_io_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_A) Ctor() {}

func (t *A_arbace_java_io_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_A_class }

func (t *A_arbace_java_io_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_A); return ok }

func A_arbace_java_io_A_Cast(x any) *A_arbace_java_io_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_A_class)) }; return v }



type A_arbace_java_io_append_QMARK__A struct{ jrt.Object }

func (t *A_arbace_java_io_append_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_append_QMARK__A_fn_class *jrt.Class

var A_arbace_java_io_append_QMARK__A_init jrt.ClassInit

func A_arbace_java_io_append_QMARK__A_Init() { if !A_arbace_java_io_append_QMARK__A_init.Done() { A_arbace_java_io_append_QMARK__A_init.Run(A_arbace_java_io_append_QMARK__A_clinit) } }

func A_arbace_java_io_append_QMARK__A_clinit() { A_arbace_java_io_append_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_40, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_append_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_append_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_java_io_append_QMARK__A_class }

func (t *A_arbace_java_io_append_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_append_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_append_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_append_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_append_QMARK__A); return ok }

func A_arbace_java_io_append_QMARK__A_Cast(x any) *A_arbace_java_io_append_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_append_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_append_QMARK__A_class)) }; return v }



type A_arbace_java_io_as_relative_path_A struct{ jrt.Object }

func (t *A_arbace_java_io_as_relative_path_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_as_relative_path_A_fn_class *jrt.Class

var A_arbace_java_io_as_relative_path_A_init jrt.ClassInit

func A_arbace_java_io_as_relative_path_A_Init() { if !A_arbace_java_io_as_relative_path_A_init.Done() { A_arbace_java_io_as_relative_path_A_init.Run(A_arbace_java_io_as_relative_path_A_clinit) } }

func A_arbace_java_io_as_relative_path_A_clinit() { A_arbace_java_io_as_relative_path_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_41, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_as_relative_path_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_as_relative_path_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_as_relative_path_A_class }

func (t *A_arbace_java_io_as_relative_path_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_as_relative_path_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_as_relative_path_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_as_relative_path_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_as_relative_path_A); return ok }

func A_arbace_java_io_as_relative_path_A_Cast(x any) *A_arbace_java_io_as_relative_path_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_as_relative_path_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_as_relative_path_A_class)) }; return v }



type A_arbace_java_io_buffer_size_A struct{ jrt.Object }

func (t *A_arbace_java_io_buffer_size_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_buffer_size_A_fn_class *jrt.Class

var A_arbace_java_io_buffer_size_A_init jrt.ClassInit

func A_arbace_java_io_buffer_size_A_Init() { if !A_arbace_java_io_buffer_size_A_init.Done() { A_arbace_java_io_buffer_size_A_init.Run(A_arbace_java_io_buffer_size_A_clinit) } }

func A_arbace_java_io_buffer_size_A_clinit() { A_arbace_java_io_buffer_size_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_43, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_buffer_size_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_buffer_size_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_buffer_size_A_class }

func (t *A_arbace_java_io_buffer_size_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_buffer_size_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_buffer_size_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_buffer_size_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_buffer_size_A); return ok }

func A_arbace_java_io_buffer_size_A_Cast(x any) *A_arbace_java_io_buffer_size_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_buffer_size_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_buffer_size_A_class)) }; return v }



type A_arbace_java_io_copy_A struct{ jrt.Object }

func (t *A_arbace_java_io_copy_A) Is_Compiler_AOTR2() {}

var A_arbace_java_io_copy_A_fn_class *jrt.Class

var A_arbace_java_io_copy_A_init jrt.ClassInit

func A_arbace_java_io_copy_A_Init() { if !A_arbace_java_io_copy_A_init.Done() { A_arbace_java_io_copy_A_init.Run(A_arbace_java_io_copy_A_clinit) } }

func A_arbace_java_io_copy_A_clinit() { A_arbace_java_io_copy_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_copy_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_copy_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_copy_A_class }

func (t *A_arbace_java_io_copy_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_copy_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_copy_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_copy_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_copy_A); return ok }

func A_arbace_java_io_copy_A_Cast(x any) *A_arbace_java_io_copy_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_copy_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_copy_A_class)) }; return v }



type A_arbace_java_io_delete_file_A struct{ jrt.Object }

func (t *A_arbace_java_io_delete_file_A) Is_Compiler_AOTR1() {}

var A_arbace_java_io_delete_file_A_fn_class *jrt.Class

var A_arbace_java_io_delete_file_A_init jrt.ClassInit

func A_arbace_java_io_delete_file_A_Init() { if !A_arbace_java_io_delete_file_A_init.Done() { A_arbace_java_io_delete_file_A_init.Run(A_arbace_java_io_delete_file_A_clinit) } }

func A_arbace_java_io_delete_file_A_clinit() { A_arbace_java_io_delete_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_delete_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_delete_file_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_delete_file_A_class }

func (t *A_arbace_java_io_delete_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_delete_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_delete_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_delete_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_delete_file_A); return ok }

func A_arbace_java_io_delete_file_A_Cast(x any) *A_arbace_java_io_delete_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_delete_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_delete_file_A_class)) }; return v }



type A_arbace_java_io_encoding_A struct{ jrt.Object }

func (t *A_arbace_java_io_encoding_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_encoding_A_fn_class *jrt.Class

var A_arbace_java_io_encoding_A_init jrt.ClassInit

func A_arbace_java_io_encoding_A_Init() { if !A_arbace_java_io_encoding_A_init.Done() { A_arbace_java_io_encoding_A_init.Run(A_arbace_java_io_encoding_A_clinit) } }

func A_arbace_java_io_encoding_A_clinit() { A_arbace_java_io_encoding_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_encoding_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_encoding_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_encoding_A_class }

func (t *A_arbace_java_io_encoding_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_encoding_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_encoding_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_encoding_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_encoding_A); return ok }

func A_arbace_java_io_encoding_A_Cast(x any) *A_arbace_java_io_encoding_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_encoding_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_encoding_A_class)) }; return v }



type A_arbace_java_io_escaped_utf8_urlstring__GT_str_A struct{ jrt.Object }

func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class *jrt.Class

var A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_init jrt.ClassInit

func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_Init() { if !A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_init.Done() { A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_init.Run(A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_clinit) } }

func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_clinit() { A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_class }

func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_escaped_utf8_urlstring__GT_str_A); return ok }

func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_Cast(x any) *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_escaped_utf8_urlstring__GT_str_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_class)) }; return v }



type A_arbace_java_io_eval1661000004_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000004_A_New() *A_arbace_java_io_eval1661000004_A { t := &A_arbace_java_io_eval1661000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000004_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000004_A_class }

func (t *A_arbace_java_io_eval1661000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000004_A); return ok }

func A_arbace_java_io_eval1661000004_A_Cast(x any) *A_arbace_java_io_eval1661000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000004_A_class)) }; return v }



type A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Is_Compiler_AOTF0() {}

var A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_Init() { if !A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_init.Done() { A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_init.Run(A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_clinit) } }

func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_clinit() { A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_class }

func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A); return ok }

func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_Cast(x any) *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_class)) }; return v }



type A_arbace_java_io_eval1661000008_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000008_A_New() *A_arbace_java_io_eval1661000008_A { t := &A_arbace_java_io_eval1661000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000008_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000008_A_class }

func (t *A_arbace_java_io_eval1661000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000008_A); return ok }

func A_arbace_java_io_eval1661000008_A_Cast(x any) *A_arbace_java_io_eval1661000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000008_A_class)) }; return v }



type A_arbace_java_io_eval1661000008_fn__1661000009_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Is_Compiler_AOTF0() {}

var A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000008_fn__1661000009_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000008_fn__1661000009_A_Init() { if !A_arbace_java_io_eval1661000008_fn__1661000009_A_init.Done() { A_arbace_java_io_eval1661000008_fn__1661000009_A_init.Run(A_arbace_java_io_eval1661000008_fn__1661000009_A_clinit) } }

func A_arbace_java_io_eval1661000008_fn__1661000009_A_clinit() { A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000008_fn__1661000009_A_class }

func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000008_fn__1661000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000008_fn__1661000009_A); return ok }

func A_arbace_java_io_eval1661000008_fn__1661000009_A_Cast(x any) *A_arbace_java_io_eval1661000008_fn__1661000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000008_fn__1661000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000008_fn__1661000009_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000024_A_New() *A_arbace_java_io_eval1661000024_A { t := &A_arbace_java_io_eval1661000024_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000024_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_A_class }

func (t *A_arbace_java_io_eval1661000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_A); return ok }

func A_arbace_java_io_eval1661000024_A_Cast(x any) *A_arbace_java_io_eval1661000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000025_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000025_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000024_fn__1661000025_A_Init() { if !A_arbace_java_io_eval1661000024_fn__1661000025_A_init.Done() { A_arbace_java_io_eval1661000024_fn__1661000025_A_init.Run(A_arbace_java_io_eval1661000024_fn__1661000025_A_clinit) } }

func A_arbace_java_io_eval1661000024_fn__1661000025_A_clinit() { A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_fn__1661000025_A_class }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_fn__1661000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000025_A); return ok }

func A_arbace_java_io_eval1661000024_fn__1661000025_A_Cast(x any) *A_arbace_java_io_eval1661000024_fn__1661000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_fn__1661000025_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A struct{ jrt.Object; F_G__1661000015 any }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_Init() { if !A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_init.Done() { A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_init.Run(A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_clinit) } }

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_clinit() { A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_81, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_class }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A); return ok }

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_Cast(x any) *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_Init() { if !A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_init.Done() { A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_init.Run(A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_clinit) } }

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_clinit() { A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_class }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A); return ok }

func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_Cast(x any) *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000033_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000033_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000024_fn__1661000033_A_Init() { if !A_arbace_java_io_eval1661000024_fn__1661000033_A_init.Done() { A_arbace_java_io_eval1661000024_fn__1661000033_A_init.Run(A_arbace_java_io_eval1661000024_fn__1661000033_A_clinit) } }

func A_arbace_java_io_eval1661000024_fn__1661000033_A_clinit() { A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_fn__1661000033_A_class }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_fn__1661000033_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000033_A); return ok }

func A_arbace_java_io_eval1661000024_fn__1661000033_A_Cast(x any) *A_arbace_java_io_eval1661000024_fn__1661000033_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000033_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_fn__1661000033_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A struct{ jrt.Object; F_G__1661000017 any }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_Init() { if !A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_init.Done() { A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_init.Run(A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_clinit) } }

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_clinit() { A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_85, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_class }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A); return ok }

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_Cast(x any) *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_Init() { if !A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_init.Done() { A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_init.Run(A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_clinit) } }

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_clinit() { A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_class }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A); return ok }

func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_Cast(x any) *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_class)) }; return v }



type A_arbace_java_io_eval1661000047_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000047_A_New() *A_arbace_java_io_eval1661000047_A { t := &A_arbace_java_io_eval1661000047_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000047_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000047_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000047_A_class }

func (t *A_arbace_java_io_eval1661000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000047_A); return ok }

func A_arbace_java_io_eval1661000047_A_Cast(x any) *A_arbace_java_io_eval1661000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000047_A_class)) }; return v }



type A_arbace_java_io_eval1661000047_fn__1661000048_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000047_fn__1661000048_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000047_fn__1661000048_A_Init() { if !A_arbace_java_io_eval1661000047_fn__1661000048_A_init.Done() { A_arbace_java_io_eval1661000047_fn__1661000048_A_init.Run(A_arbace_java_io_eval1661000047_fn__1661000048_A_clinit) } }

func A_arbace_java_io_eval1661000047_fn__1661000048_A_clinit() { A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000047_fn__1661000048_A_class }

func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000047_fn__1661000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000047_fn__1661000048_A); return ok }

func A_arbace_java_io_eval1661000047_fn__1661000048_A_Cast(x any) *A_arbace_java_io_eval1661000047_fn__1661000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000047_fn__1661000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000047_fn__1661000048_A_class)) }; return v }



type A_arbace_java_io_eval1661000047_fn__1661000050_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000047_fn__1661000050_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000047_fn__1661000050_A_Init() { if !A_arbace_java_io_eval1661000047_fn__1661000050_A_init.Done() { A_arbace_java_io_eval1661000047_fn__1661000050_A_init.Run(A_arbace_java_io_eval1661000047_fn__1661000050_A_clinit) } }

func A_arbace_java_io_eval1661000047_fn__1661000050_A_clinit() { A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_89, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000047_fn__1661000050_A_class }

func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000047_fn__1661000050_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000047_fn__1661000050_A); return ok }

func A_arbace_java_io_eval1661000047_fn__1661000050_A_Cast(x any) *A_arbace_java_io_eval1661000047_fn__1661000050_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000047_fn__1661000050_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000047_fn__1661000050_A_class)) }; return v }



type A_arbace_java_io_eval1661000053_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000053_A_New() *A_arbace_java_io_eval1661000053_A { t := &A_arbace_java_io_eval1661000053_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000053_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000053_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000053_A_class }

func (t *A_arbace_java_io_eval1661000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000053_A); return ok }

func A_arbace_java_io_eval1661000053_A_Cast(x any) *A_arbace_java_io_eval1661000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000053_A_class)) }; return v }



type A_arbace_java_io_eval1661000053_fn__1661000054_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000053_fn__1661000054_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000053_fn__1661000054_A_Init() { if !A_arbace_java_io_eval1661000053_fn__1661000054_A_init.Done() { A_arbace_java_io_eval1661000053_fn__1661000054_A_init.Run(A_arbace_java_io_eval1661000053_fn__1661000054_A_clinit) } }

func A_arbace_java_io_eval1661000053_fn__1661000054_A_clinit() { A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_90, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000053_fn__1661000054_A_class }

func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000053_fn__1661000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000053_fn__1661000054_A); return ok }

func A_arbace_java_io_eval1661000053_fn__1661000054_A_Cast(x any) *A_arbace_java_io_eval1661000053_fn__1661000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000053_fn__1661000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000053_fn__1661000054_A_class)) }; return v }



type A_arbace_java_io_eval1661000053_fn__1661000056_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000053_fn__1661000056_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000053_fn__1661000056_A_Init() { if !A_arbace_java_io_eval1661000053_fn__1661000056_A_init.Done() { A_arbace_java_io_eval1661000053_fn__1661000056_A_init.Run(A_arbace_java_io_eval1661000053_fn__1661000056_A_clinit) } }

func A_arbace_java_io_eval1661000053_fn__1661000056_A_clinit() { A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_91, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000053_fn__1661000056_A_class }

func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000053_fn__1661000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000053_fn__1661000056_A); return ok }

func A_arbace_java_io_eval1661000053_fn__1661000056_A_Cast(x any) *A_arbace_java_io_eval1661000053_fn__1661000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000053_fn__1661000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000053_fn__1661000056_A_class)) }; return v }



type A_arbace_java_io_eval1661000059_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000059_A_New() *A_arbace_java_io_eval1661000059_A { t := &A_arbace_java_io_eval1661000059_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000059_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000059_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000059_A_class }

func (t *A_arbace_java_io_eval1661000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000059_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000059_A); return ok }

func A_arbace_java_io_eval1661000059_A_Cast(x any) *A_arbace_java_io_eval1661000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000059_A_class)) }; return v }



type A_arbace_java_io_eval1661000059_fn__1661000060_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000059_fn__1661000060_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000059_fn__1661000060_A_Init() { if !A_arbace_java_io_eval1661000059_fn__1661000060_A_init.Done() { A_arbace_java_io_eval1661000059_fn__1661000060_A_init.Run(A_arbace_java_io_eval1661000059_fn__1661000060_A_clinit) } }

func A_arbace_java_io_eval1661000059_fn__1661000060_A_clinit() { A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_92, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000059_fn__1661000060_A_class }

func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000059_fn__1661000060_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000059_fn__1661000060_A); return ok }

func A_arbace_java_io_eval1661000059_fn__1661000060_A_Cast(x any) *A_arbace_java_io_eval1661000059_fn__1661000060_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000059_fn__1661000060_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000059_fn__1661000060_A_class)) }; return v }



type A_arbace_java_io_eval1661000059_fn__1661000062_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000059_fn__1661000062_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000059_fn__1661000062_A_Init() { if !A_arbace_java_io_eval1661000059_fn__1661000062_A_init.Done() { A_arbace_java_io_eval1661000059_fn__1661000062_A_init.Run(A_arbace_java_io_eval1661000059_fn__1661000062_A_clinit) } }

func A_arbace_java_io_eval1661000059_fn__1661000062_A_clinit() { A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_93, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000059_fn__1661000062_A_class }

func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000059_fn__1661000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000059_fn__1661000062_A); return ok }

func A_arbace_java_io_eval1661000059_fn__1661000062_A_Cast(x any) *A_arbace_java_io_eval1661000059_fn__1661000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000059_fn__1661000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000059_fn__1661000062_A_class)) }; return v }



type A_arbace_java_io_eval1661000065_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000065_A_New() *A_arbace_java_io_eval1661000065_A { t := &A_arbace_java_io_eval1661000065_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000065_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000065_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000065_A_class }

func (t *A_arbace_java_io_eval1661000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000065_A); return ok }

func A_arbace_java_io_eval1661000065_A_Cast(x any) *A_arbace_java_io_eval1661000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000065_A_class)) }; return v }



type A_arbace_java_io_eval1661000065_fn__1661000066_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000065_fn__1661000066_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000065_fn__1661000066_A_Init() { if !A_arbace_java_io_eval1661000065_fn__1661000066_A_init.Done() { A_arbace_java_io_eval1661000065_fn__1661000066_A_init.Run(A_arbace_java_io_eval1661000065_fn__1661000066_A_clinit) } }

func A_arbace_java_io_eval1661000065_fn__1661000066_A_clinit() { A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_94, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000065_fn__1661000066_A_class }

func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000065_fn__1661000066_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000065_fn__1661000066_A); return ok }

func A_arbace_java_io_eval1661000065_fn__1661000066_A_Cast(x any) *A_arbace_java_io_eval1661000065_fn__1661000066_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000065_fn__1661000066_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000065_fn__1661000066_A_class)) }; return v }



type A_arbace_java_io_eval1661000065_fn__1661000068_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000065_fn__1661000068_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000065_fn__1661000068_A_Init() { if !A_arbace_java_io_eval1661000065_fn__1661000068_A_init.Done() { A_arbace_java_io_eval1661000065_fn__1661000068_A_init.Run(A_arbace_java_io_eval1661000065_fn__1661000068_A_clinit) } }

func A_arbace_java_io_eval1661000065_fn__1661000068_A_clinit() { A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_95, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000065_fn__1661000068_A_class }

func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000065_fn__1661000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000065_fn__1661000068_A); return ok }

func A_arbace_java_io_eval1661000065_fn__1661000068_A_Cast(x any) *A_arbace_java_io_eval1661000065_fn__1661000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000065_fn__1661000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000065_fn__1661000068_A_class)) }; return v }



type A_arbace_java_io_eval1661000071_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000071_A_New() *A_arbace_java_io_eval1661000071_A { t := &A_arbace_java_io_eval1661000071_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000071_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000071_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000071_A_class }

func (t *A_arbace_java_io_eval1661000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000071_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000071_A); return ok }

func A_arbace_java_io_eval1661000071_A_Cast(x any) *A_arbace_java_io_eval1661000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000071_A_class)) }; return v }



type A_arbace_java_io_eval1661000071_fn__1661000072_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000071_fn__1661000072_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000071_fn__1661000072_A_Init() { if !A_arbace_java_io_eval1661000071_fn__1661000072_A_init.Done() { A_arbace_java_io_eval1661000071_fn__1661000072_A_init.Run(A_arbace_java_io_eval1661000071_fn__1661000072_A_clinit) } }

func A_arbace_java_io_eval1661000071_fn__1661000072_A_clinit() { A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_97, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000071_fn__1661000072_A_class }

func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000071_fn__1661000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000071_fn__1661000072_A); return ok }

func A_arbace_java_io_eval1661000071_fn__1661000072_A_Cast(x any) *A_arbace_java_io_eval1661000071_fn__1661000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000071_fn__1661000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000071_fn__1661000072_A_class)) }; return v }



type A_arbace_java_io_eval1661000071_fn__1661000074_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000071_fn__1661000074_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000071_fn__1661000074_A_Init() { if !A_arbace_java_io_eval1661000071_fn__1661000074_A_init.Done() { A_arbace_java_io_eval1661000071_fn__1661000074_A_init.Run(A_arbace_java_io_eval1661000071_fn__1661000074_A_clinit) } }

func A_arbace_java_io_eval1661000071_fn__1661000074_A_clinit() { A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_98, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000071_fn__1661000074_A_class }

func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000071_fn__1661000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000071_fn__1661000074_A); return ok }

func A_arbace_java_io_eval1661000071_fn__1661000074_A_Cast(x any) *A_arbace_java_io_eval1661000071_fn__1661000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000071_fn__1661000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000071_fn__1661000074_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000091_A_New() *A_arbace_java_io_eval1661000091_A { t := &A_arbace_java_io_eval1661000091_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000091_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_A_class }

func (t *A_arbace_java_io_eval1661000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_A); return ok }

func A_arbace_java_io_eval1661000091_A_Cast(x any) *A_arbace_java_io_eval1661000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000092_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000092_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000092_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000092_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000092_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000092_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000092_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_99, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000092_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000092_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000092_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000092_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000092_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000092_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000092_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A struct{ jrt.Object; F_G__1661000082 any }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_100, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_101, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000102_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000102_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000102_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000102_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000102_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000102_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000102_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_103, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000102_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000102_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000102_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000102_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000102_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000102_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000102_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A struct{ jrt.Object; F_G__1661000084 any }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_104, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_105, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000112_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000112_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000112_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000112_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000112_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000112_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000112_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_107, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000112_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000112_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000112_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000112_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000112_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000112_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000112_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A struct{ jrt.Object; F_G__1661000078 any }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_108, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_109, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000122_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000122_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000122_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000122_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000122_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000122_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000122_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_111, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000122_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000122_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000122_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000122_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A struct{ jrt.Object; F_G__1661000080 any }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_112, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_Init() { if !A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_init.Done() { A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_init.Run(A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_clinit) } }

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_clinit() { A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_113, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_class }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A); return ok }

func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_Cast(x any) *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_class)) }; return v }



type A_arbace_java_io_eval1661000154_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000154_A_New() *A_arbace_java_io_eval1661000154_A { t := &A_arbace_java_io_eval1661000154_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000154_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000154_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000154_A_class }

func (t *A_arbace_java_io_eval1661000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000154_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000154_A); return ok }

func A_arbace_java_io_eval1661000154_A_Cast(x any) *A_arbace_java_io_eval1661000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000154_A_class)) }; return v }



type A_arbace_java_io_eval1661000154_fn__1661000155_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000154_fn__1661000155_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000154_fn__1661000155_A_Init() { if !A_arbace_java_io_eval1661000154_fn__1661000155_A_init.Done() { A_arbace_java_io_eval1661000154_fn__1661000155_A_init.Run(A_arbace_java_io_eval1661000154_fn__1661000155_A_clinit) } }

func A_arbace_java_io_eval1661000154_fn__1661000155_A_clinit() { A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_115, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000154_fn__1661000155_A_class }

func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000154_fn__1661000155_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000154_fn__1661000155_A); return ok }

func A_arbace_java_io_eval1661000154_fn__1661000155_A_Cast(x any) *A_arbace_java_io_eval1661000154_fn__1661000155_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000154_fn__1661000155_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000154_fn__1661000155_A_class)) }; return v }



type A_arbace_java_io_eval1661000158_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000158_A_New() *A_arbace_java_io_eval1661000158_A { t := &A_arbace_java_io_eval1661000158_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000158_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000158_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000158_A_class }

func (t *A_arbace_java_io_eval1661000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000158_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000158_A); return ok }

func A_arbace_java_io_eval1661000158_A_Cast(x any) *A_arbace_java_io_eval1661000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000158_A_class)) }; return v }



type A_arbace_java_io_eval1661000158_fn__1661000159_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000158_fn__1661000159_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000158_fn__1661000159_A_Init() { if !A_arbace_java_io_eval1661000158_fn__1661000159_A_init.Done() { A_arbace_java_io_eval1661000158_fn__1661000159_A_init.Run(A_arbace_java_io_eval1661000158_fn__1661000159_A_clinit) } }

func A_arbace_java_io_eval1661000158_fn__1661000159_A_clinit() { A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_116, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000158_fn__1661000159_A_class }

func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000158_fn__1661000159_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000158_fn__1661000159_A); return ok }

func A_arbace_java_io_eval1661000158_fn__1661000159_A_Cast(x any) *A_arbace_java_io_eval1661000158_fn__1661000159_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000158_fn__1661000159_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000158_fn__1661000159_A_class)) }; return v }



type A_arbace_java_io_eval1661000162_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000162_A_New() *A_arbace_java_io_eval1661000162_A { t := &A_arbace_java_io_eval1661000162_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000162_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000162_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000162_A_class }

func (t *A_arbace_java_io_eval1661000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000162_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000162_A); return ok }

func A_arbace_java_io_eval1661000162_A_Cast(x any) *A_arbace_java_io_eval1661000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000162_A_class)) }; return v }



type A_arbace_java_io_eval1661000162_fn__1661000163_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000162_fn__1661000163_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000162_fn__1661000163_A_Init() { if !A_arbace_java_io_eval1661000162_fn__1661000163_A_init.Done() { A_arbace_java_io_eval1661000162_fn__1661000163_A_init.Run(A_arbace_java_io_eval1661000162_fn__1661000163_A_clinit) } }

func A_arbace_java_io_eval1661000162_fn__1661000163_A_clinit() { A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_117, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000162_fn__1661000163_A_class }

func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000162_fn__1661000163_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000162_fn__1661000163_A); return ok }

func A_arbace_java_io_eval1661000162_fn__1661000163_A_Cast(x any) *A_arbace_java_io_eval1661000162_fn__1661000163_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000162_fn__1661000163_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000162_fn__1661000163_A_class)) }; return v }



type A_arbace_java_io_eval1661000166_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000166_A_New() *A_arbace_java_io_eval1661000166_A { t := &A_arbace_java_io_eval1661000166_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000166_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000166_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000166_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000166_A_class }

func (t *A_arbace_java_io_eval1661000166_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000166_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000166_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000166_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000166_A); return ok }

func A_arbace_java_io_eval1661000166_A_Cast(x any) *A_arbace_java_io_eval1661000166_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000166_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000166_A_class)) }; return v }



type A_arbace_java_io_eval1661000166_fn__1661000167_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000166_fn__1661000167_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000166_fn__1661000167_A_Init() { if !A_arbace_java_io_eval1661000166_fn__1661000167_A_init.Done() { A_arbace_java_io_eval1661000166_fn__1661000167_A_init.Run(A_arbace_java_io_eval1661000166_fn__1661000167_A_clinit) } }

func A_arbace_java_io_eval1661000166_fn__1661000167_A_clinit() { A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_118, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000166_fn__1661000167_A_class }

func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000166_fn__1661000167_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000166_fn__1661000167_A); return ok }

func A_arbace_java_io_eval1661000166_fn__1661000167_A_Cast(x any) *A_arbace_java_io_eval1661000166_fn__1661000167_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000166_fn__1661000167_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000166_fn__1661000167_A_class)) }; return v }



type A_arbace_java_io_eval1661000170_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000170_A_New() *A_arbace_java_io_eval1661000170_A { t := &A_arbace_java_io_eval1661000170_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000170_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000170_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000170_A_class }

func (t *A_arbace_java_io_eval1661000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000170_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000170_A); return ok }

func A_arbace_java_io_eval1661000170_A_Cast(x any) *A_arbace_java_io_eval1661000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000170_A_class)) }; return v }



type A_arbace_java_io_eval1661000170_fn__1661000171_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000170_fn__1661000171_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000170_fn__1661000171_A_Init() { if !A_arbace_java_io_eval1661000170_fn__1661000171_A_init.Done() { A_arbace_java_io_eval1661000170_fn__1661000171_A_init.Run(A_arbace_java_io_eval1661000170_fn__1661000171_A_clinit) } }

func A_arbace_java_io_eval1661000170_fn__1661000171_A_clinit() { A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_119, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000170_fn__1661000171_A_class }

func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000170_fn__1661000171_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000170_fn__1661000171_A); return ok }

func A_arbace_java_io_eval1661000170_fn__1661000171_A_Cast(x any) *A_arbace_java_io_eval1661000170_fn__1661000171_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000170_fn__1661000171_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000170_fn__1661000171_A_class)) }; return v }



type A_arbace_java_io_eval1661000174_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000174_A_New() *A_arbace_java_io_eval1661000174_A { t := &A_arbace_java_io_eval1661000174_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000174_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000174_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000174_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000174_A_class }

func (t *A_arbace_java_io_eval1661000174_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000174_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000174_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000174_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000174_A); return ok }

func A_arbace_java_io_eval1661000174_A_Cast(x any) *A_arbace_java_io_eval1661000174_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000174_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000174_A_class)) }; return v }



type A_arbace_java_io_eval1661000174_fn__1661000175_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000174_fn__1661000175_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000174_fn__1661000175_A_Init() { if !A_arbace_java_io_eval1661000174_fn__1661000175_A_init.Done() { A_arbace_java_io_eval1661000174_fn__1661000175_A_init.Run(A_arbace_java_io_eval1661000174_fn__1661000175_A_clinit) } }

func A_arbace_java_io_eval1661000174_fn__1661000175_A_clinit() { A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_120, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000174_fn__1661000175_A_class }

func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000174_fn__1661000175_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000174_fn__1661000175_A); return ok }

func A_arbace_java_io_eval1661000174_fn__1661000175_A_Cast(x any) *A_arbace_java_io_eval1661000174_fn__1661000175_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000174_fn__1661000175_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000174_fn__1661000175_A_class)) }; return v }



type A_arbace_java_io_eval1661000178_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000178_A_New() *A_arbace_java_io_eval1661000178_A { t := &A_arbace_java_io_eval1661000178_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000178_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000178_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000178_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000178_A_class }

func (t *A_arbace_java_io_eval1661000178_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000178_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000178_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000178_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000178_A); return ok }

func A_arbace_java_io_eval1661000178_A_Cast(x any) *A_arbace_java_io_eval1661000178_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000178_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000178_A_class)) }; return v }



type A_arbace_java_io_eval1661000178_fn__1661000179_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000178_fn__1661000179_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000178_fn__1661000179_A_Init() { if !A_arbace_java_io_eval1661000178_fn__1661000179_A_init.Done() { A_arbace_java_io_eval1661000178_fn__1661000179_A_init.Run(A_arbace_java_io_eval1661000178_fn__1661000179_A_clinit) } }

func A_arbace_java_io_eval1661000178_fn__1661000179_A_clinit() { A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_121, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000178_fn__1661000179_A_class }

func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000178_fn__1661000179_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000178_fn__1661000179_A); return ok }

func A_arbace_java_io_eval1661000178_fn__1661000179_A_Cast(x any) *A_arbace_java_io_eval1661000178_fn__1661000179_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000178_fn__1661000179_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000178_fn__1661000179_A_class)) }; return v }



type A_arbace_java_io_eval1661000182_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000182_A_New() *A_arbace_java_io_eval1661000182_A { t := &A_arbace_java_io_eval1661000182_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000182_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000182_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000182_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000182_A_class }

func (t *A_arbace_java_io_eval1661000182_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000182_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000182_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000182_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000182_A); return ok }

func A_arbace_java_io_eval1661000182_A_Cast(x any) *A_arbace_java_io_eval1661000182_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000182_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000182_A_class)) }; return v }



type A_arbace_java_io_eval1661000182_fn__1661000183_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000182_fn__1661000183_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000182_fn__1661000183_A_Init() { if !A_arbace_java_io_eval1661000182_fn__1661000183_A_init.Done() { A_arbace_java_io_eval1661000182_fn__1661000183_A_init.Run(A_arbace_java_io_eval1661000182_fn__1661000183_A_clinit) } }

func A_arbace_java_io_eval1661000182_fn__1661000183_A_clinit() { A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_122, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000182_fn__1661000183_A_class }

func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000182_fn__1661000183_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000182_fn__1661000183_A); return ok }

func A_arbace_java_io_eval1661000182_fn__1661000183_A_Cast(x any) *A_arbace_java_io_eval1661000182_fn__1661000183_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000182_fn__1661000183_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000182_fn__1661000183_A_class)) }; return v }



type A_arbace_java_io_eval1661000186_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000186_A_New() *A_arbace_java_io_eval1661000186_A { t := &A_arbace_java_io_eval1661000186_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000186_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000186_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000186_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000186_A_class }

func (t *A_arbace_java_io_eval1661000186_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000186_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000186_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000186_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000186_A); return ok }

func A_arbace_java_io_eval1661000186_A_Cast(x any) *A_arbace_java_io_eval1661000186_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000186_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000186_A_class)) }; return v }



type A_arbace_java_io_eval1661000186_fn__1661000187_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000186_fn__1661000187_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000186_fn__1661000187_A_Init() { if !A_arbace_java_io_eval1661000186_fn__1661000187_A_init.Done() { A_arbace_java_io_eval1661000186_fn__1661000187_A_init.Run(A_arbace_java_io_eval1661000186_fn__1661000187_A_clinit) } }

func A_arbace_java_io_eval1661000186_fn__1661000187_A_clinit() { A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_123, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000186_fn__1661000187_A_class }

func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000186_fn__1661000187_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000186_fn__1661000187_A); return ok }

func A_arbace_java_io_eval1661000186_fn__1661000187_A_Cast(x any) *A_arbace_java_io_eval1661000186_fn__1661000187_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000186_fn__1661000187_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000186_fn__1661000187_A_class)) }; return v }



type A_arbace_java_io_eval1661000186_fn__1661000189_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000186_fn__1661000189_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000186_fn__1661000189_A_Init() { if !A_arbace_java_io_eval1661000186_fn__1661000189_A_init.Done() { A_arbace_java_io_eval1661000186_fn__1661000189_A_init.Run(A_arbace_java_io_eval1661000186_fn__1661000189_A_clinit) } }

func A_arbace_java_io_eval1661000186_fn__1661000189_A_clinit() { A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_124, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000186_fn__1661000189_A_class }

func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000186_fn__1661000189_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000186_fn__1661000189_A); return ok }

func A_arbace_java_io_eval1661000186_fn__1661000189_A_Cast(x any) *A_arbace_java_io_eval1661000186_fn__1661000189_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000186_fn__1661000189_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000186_fn__1661000189_A_class)) }; return v }



type A_arbace_java_io_eval1661000192_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000192_A_New() *A_arbace_java_io_eval1661000192_A { t := &A_arbace_java_io_eval1661000192_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000192_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000192_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000192_A_class }

func (t *A_arbace_java_io_eval1661000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000192_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000192_A); return ok }

func A_arbace_java_io_eval1661000192_A_Cast(x any) *A_arbace_java_io_eval1661000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000192_A_class)) }; return v }



type A_arbace_java_io_eval1661000192_fn__1661000193_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000192_fn__1661000193_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000192_fn__1661000193_A_Init() { if !A_arbace_java_io_eval1661000192_fn__1661000193_A_init.Done() { A_arbace_java_io_eval1661000192_fn__1661000193_A_init.Run(A_arbace_java_io_eval1661000192_fn__1661000193_A_clinit) } }

func A_arbace_java_io_eval1661000192_fn__1661000193_A_clinit() { A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000192_fn__1661000193_A_class }

func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000192_fn__1661000193_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000192_fn__1661000193_A); return ok }

func A_arbace_java_io_eval1661000192_fn__1661000193_A_Cast(x any) *A_arbace_java_io_eval1661000192_fn__1661000193_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000192_fn__1661000193_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000192_fn__1661000193_A_class)) }; return v }



type A_arbace_java_io_eval1661000192_fn__1661000195_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000192_fn__1661000195_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000192_fn__1661000195_A_Init() { if !A_arbace_java_io_eval1661000192_fn__1661000195_A_init.Done() { A_arbace_java_io_eval1661000192_fn__1661000195_A_init.Run(A_arbace_java_io_eval1661000192_fn__1661000195_A_clinit) } }

func A_arbace_java_io_eval1661000192_fn__1661000195_A_clinit() { A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000192_fn__1661000195_A_class }

func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000192_fn__1661000195_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000192_fn__1661000195_A); return ok }

func A_arbace_java_io_eval1661000192_fn__1661000195_A_Cast(x any) *A_arbace_java_io_eval1661000192_fn__1661000195_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000192_fn__1661000195_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000192_fn__1661000195_A_class)) }; return v }



type A_arbace_java_io_eval1661000198_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000198_A_New() *A_arbace_java_io_eval1661000198_A { t := &A_arbace_java_io_eval1661000198_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000198_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000198_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000198_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000198_A_class }

func (t *A_arbace_java_io_eval1661000198_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000198_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000198_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000198_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000198_A); return ok }

func A_arbace_java_io_eval1661000198_A_Cast(x any) *A_arbace_java_io_eval1661000198_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000198_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000198_A_class)) }; return v }



type A_arbace_java_io_eval1661000198_fn__1661000199_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000198_fn__1661000199_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000198_fn__1661000199_A_Init() { if !A_arbace_java_io_eval1661000198_fn__1661000199_A_init.Done() { A_arbace_java_io_eval1661000198_fn__1661000199_A_init.Run(A_arbace_java_io_eval1661000198_fn__1661000199_A_clinit) } }

func A_arbace_java_io_eval1661000198_fn__1661000199_A_clinit() { A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000198_fn__1661000199_A_class }

func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000198_fn__1661000199_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000198_fn__1661000199_A); return ok }

func A_arbace_java_io_eval1661000198_fn__1661000199_A_Cast(x any) *A_arbace_java_io_eval1661000198_fn__1661000199_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000198_fn__1661000199_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000198_fn__1661000199_A_class)) }; return v }



type A_arbace_java_io_eval1661000198_fn__1661000201_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000198_fn__1661000201_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000198_fn__1661000201_A_Init() { if !A_arbace_java_io_eval1661000198_fn__1661000201_A_init.Done() { A_arbace_java_io_eval1661000198_fn__1661000201_A_init.Run(A_arbace_java_io_eval1661000198_fn__1661000201_A_clinit) } }

func A_arbace_java_io_eval1661000198_fn__1661000201_A_clinit() { A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000198_fn__1661000201_A_class }

func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000198_fn__1661000201_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000198_fn__1661000201_A); return ok }

func A_arbace_java_io_eval1661000198_fn__1661000201_A_Cast(x any) *A_arbace_java_io_eval1661000198_fn__1661000201_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000198_fn__1661000201_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000198_fn__1661000201_A_class)) }; return v }



type A_arbace_java_io_eval1661000204_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000204_A_New() *A_arbace_java_io_eval1661000204_A { t := &A_arbace_java_io_eval1661000204_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000204_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000204_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000204_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000204_A_class }

func (t *A_arbace_java_io_eval1661000204_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000204_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000204_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000204_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000204_A); return ok }

func A_arbace_java_io_eval1661000204_A_Cast(x any) *A_arbace_java_io_eval1661000204_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000204_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000204_A_class)) }; return v }



type A_arbace_java_io_eval1661000204_fn__1661000205_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000204_fn__1661000205_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000204_fn__1661000205_A_Init() { if !A_arbace_java_io_eval1661000204_fn__1661000205_A_init.Done() { A_arbace_java_io_eval1661000204_fn__1661000205_A_init.Run(A_arbace_java_io_eval1661000204_fn__1661000205_A_clinit) } }

func A_arbace_java_io_eval1661000204_fn__1661000205_A_clinit() { A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_131, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000204_fn__1661000205_A_class }

func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000204_fn__1661000205_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000204_fn__1661000205_A); return ok }

func A_arbace_java_io_eval1661000204_fn__1661000205_A_Cast(x any) *A_arbace_java_io_eval1661000204_fn__1661000205_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000204_fn__1661000205_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000204_fn__1661000205_A_class)) }; return v }



type A_arbace_java_io_eval1661000204_fn__1661000207_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000204_fn__1661000207_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000204_fn__1661000207_A_Init() { if !A_arbace_java_io_eval1661000204_fn__1661000207_A_init.Done() { A_arbace_java_io_eval1661000204_fn__1661000207_A_init.Run(A_arbace_java_io_eval1661000204_fn__1661000207_A_clinit) } }

func A_arbace_java_io_eval1661000204_fn__1661000207_A_clinit() { A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000204_fn__1661000207_A_class }

func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000204_fn__1661000207_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000204_fn__1661000207_A); return ok }

func A_arbace_java_io_eval1661000204_fn__1661000207_A_Cast(x any) *A_arbace_java_io_eval1661000204_fn__1661000207_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000204_fn__1661000207_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000204_fn__1661000207_A_class)) }; return v }



type A_arbace_java_io_eval1661000210_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000210_A_New() *A_arbace_java_io_eval1661000210_A { t := &A_arbace_java_io_eval1661000210_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000210_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000210_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000210_A_class }

func (t *A_arbace_java_io_eval1661000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000210_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000210_A); return ok }

func A_arbace_java_io_eval1661000210_A_Cast(x any) *A_arbace_java_io_eval1661000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000210_A_class)) }; return v }



type A_arbace_java_io_eval1661000210_fn__1661000211_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000210_fn__1661000211_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000210_fn__1661000211_A_Init() { if !A_arbace_java_io_eval1661000210_fn__1661000211_A_init.Done() { A_arbace_java_io_eval1661000210_fn__1661000211_A_init.Run(A_arbace_java_io_eval1661000210_fn__1661000211_A_clinit) } }

func A_arbace_java_io_eval1661000210_fn__1661000211_A_clinit() { A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000210_fn__1661000211_A_class }

func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000210_fn__1661000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000210_fn__1661000211_A); return ok }

func A_arbace_java_io_eval1661000210_fn__1661000211_A_Cast(x any) *A_arbace_java_io_eval1661000210_fn__1661000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000210_fn__1661000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000210_fn__1661000211_A_class)) }; return v }



type A_arbace_java_io_eval1661000210_fn__1661000213_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000210_fn__1661000213_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000210_fn__1661000213_A_Init() { if !A_arbace_java_io_eval1661000210_fn__1661000213_A_init.Done() { A_arbace_java_io_eval1661000210_fn__1661000213_A_init.Run(A_arbace_java_io_eval1661000210_fn__1661000213_A_clinit) } }

func A_arbace_java_io_eval1661000210_fn__1661000213_A_clinit() { A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000210_fn__1661000213_A_class }

func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000210_fn__1661000213_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000210_fn__1661000213_A); return ok }

func A_arbace_java_io_eval1661000210_fn__1661000213_A_Cast(x any) *A_arbace_java_io_eval1661000210_fn__1661000213_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000210_fn__1661000213_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000210_fn__1661000213_A_class)) }; return v }



type A_arbace_java_io_eval1661000216_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000216_A_New() *A_arbace_java_io_eval1661000216_A { t := &A_arbace_java_io_eval1661000216_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000216_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000216_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000216_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000216_A_class }

func (t *A_arbace_java_io_eval1661000216_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000216_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000216_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000216_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000216_A); return ok }

func A_arbace_java_io_eval1661000216_A_Cast(x any) *A_arbace_java_io_eval1661000216_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000216_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000216_A_class)) }; return v }



type A_arbace_java_io_eval1661000216_fn__1661000217_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000216_fn__1661000217_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000216_fn__1661000217_A_Init() { if !A_arbace_java_io_eval1661000216_fn__1661000217_A_init.Done() { A_arbace_java_io_eval1661000216_fn__1661000217_A_init.Run(A_arbace_java_io_eval1661000216_fn__1661000217_A_clinit) } }

func A_arbace_java_io_eval1661000216_fn__1661000217_A_clinit() { A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000216_fn__1661000217_A_class }

func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000216_fn__1661000217_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000216_fn__1661000217_A); return ok }

func A_arbace_java_io_eval1661000216_fn__1661000217_A_Cast(x any) *A_arbace_java_io_eval1661000216_fn__1661000217_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000216_fn__1661000217_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000216_fn__1661000217_A_class)) }; return v }



type A_arbace_java_io_eval1661000220_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000220_A_New() *A_arbace_java_io_eval1661000220_A { t := &A_arbace_java_io_eval1661000220_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000220_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000220_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000220_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000220_A_class }

func (t *A_arbace_java_io_eval1661000220_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000220_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000220_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000220_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000220_A); return ok }

func A_arbace_java_io_eval1661000220_A_Cast(x any) *A_arbace_java_io_eval1661000220_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000220_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000220_A_class)) }; return v }



type A_arbace_java_io_eval1661000220_fn__1661000221_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000220_fn__1661000221_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000220_fn__1661000221_A_Init() { if !A_arbace_java_io_eval1661000220_fn__1661000221_A_init.Done() { A_arbace_java_io_eval1661000220_fn__1661000221_A_init.Run(A_arbace_java_io_eval1661000220_fn__1661000221_A_clinit) } }

func A_arbace_java_io_eval1661000220_fn__1661000221_A_clinit() { A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000220_fn__1661000221_A_class }

func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000220_fn__1661000221_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000220_fn__1661000221_A); return ok }

func A_arbace_java_io_eval1661000220_fn__1661000221_A_Cast(x any) *A_arbace_java_io_eval1661000220_fn__1661000221_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000220_fn__1661000221_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000220_fn__1661000221_A_class)) }; return v }



type A_arbace_java_io_eval1661000226_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000226_A_New() *A_arbace_java_io_eval1661000226_A { t := &A_arbace_java_io_eval1661000226_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000226_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000226_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000226_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000226_A_class }

func (t *A_arbace_java_io_eval1661000226_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000226_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000226_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000226_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000226_A); return ok }

func A_arbace_java_io_eval1661000226_A_Cast(x any) *A_arbace_java_io_eval1661000226_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000226_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000226_A_class)) }; return v }



type A_arbace_java_io_eval1661000226_fn__1661000227_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000226_fn__1661000227_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000226_fn__1661000227_A_Init() { if !A_arbace_java_io_eval1661000226_fn__1661000227_A_init.Done() { A_arbace_java_io_eval1661000226_fn__1661000227_A_init.Run(A_arbace_java_io_eval1661000226_fn__1661000227_A_clinit) } }

func A_arbace_java_io_eval1661000226_fn__1661000227_A_clinit() { A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000226_fn__1661000227_A_class }

func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000226_fn__1661000227_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000226_fn__1661000227_A); return ok }

func A_arbace_java_io_eval1661000226_fn__1661000227_A_Cast(x any) *A_arbace_java_io_eval1661000226_fn__1661000227_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000226_fn__1661000227_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000226_fn__1661000227_A_class)) }; return v }



type A_arbace_java_io_eval1661000226_fn__1661000229_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000226_fn__1661000229_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000226_fn__1661000229_A_Init() { if !A_arbace_java_io_eval1661000226_fn__1661000229_A_init.Done() { A_arbace_java_io_eval1661000226_fn__1661000229_A_init.Run(A_arbace_java_io_eval1661000226_fn__1661000229_A_clinit) } }

func A_arbace_java_io_eval1661000226_fn__1661000229_A_clinit() { A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_140, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000226_fn__1661000229_A_class }

func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000226_fn__1661000229_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000226_fn__1661000229_A); return ok }

func A_arbace_java_io_eval1661000226_fn__1661000229_A_Cast(x any) *A_arbace_java_io_eval1661000226_fn__1661000229_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000226_fn__1661000229_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000226_fn__1661000229_A_class)) }; return v }



type A_arbace_java_io_eval1661000232_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000232_A_New() *A_arbace_java_io_eval1661000232_A { t := &A_arbace_java_io_eval1661000232_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000232_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000232_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000232_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000232_A_class }

func (t *A_arbace_java_io_eval1661000232_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000232_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000232_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000232_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000232_A); return ok }

func A_arbace_java_io_eval1661000232_A_Cast(x any) *A_arbace_java_io_eval1661000232_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000232_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000232_A_class)) }; return v }



type A_arbace_java_io_eval1661000232_fn__1661000233_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000232_fn__1661000233_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000232_fn__1661000233_A_Init() { if !A_arbace_java_io_eval1661000232_fn__1661000233_A_init.Done() { A_arbace_java_io_eval1661000232_fn__1661000233_A_init.Run(A_arbace_java_io_eval1661000232_fn__1661000233_A_clinit) } }

func A_arbace_java_io_eval1661000232_fn__1661000233_A_clinit() { A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000232_fn__1661000233_A_class }

func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000232_fn__1661000233_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000232_fn__1661000233_A); return ok }

func A_arbace_java_io_eval1661000232_fn__1661000233_A_Cast(x any) *A_arbace_java_io_eval1661000232_fn__1661000233_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000232_fn__1661000233_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000232_fn__1661000233_A_class)) }; return v }



type A_arbace_java_io_eval1661000236_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000236_A_New() *A_arbace_java_io_eval1661000236_A { t := &A_arbace_java_io_eval1661000236_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000236_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000236_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000236_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000236_A_class }

func (t *A_arbace_java_io_eval1661000236_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000236_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000236_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000236_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000236_A); return ok }

func A_arbace_java_io_eval1661000236_A_Cast(x any) *A_arbace_java_io_eval1661000236_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000236_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000236_A_class)) }; return v }



type A_arbace_java_io_eval1661000236_fn__1661000237_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000236_fn__1661000237_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000236_fn__1661000237_A_Init() { if !A_arbace_java_io_eval1661000236_fn__1661000237_A_init.Done() { A_arbace_java_io_eval1661000236_fn__1661000237_A_init.Run(A_arbace_java_io_eval1661000236_fn__1661000237_A_clinit) } }

func A_arbace_java_io_eval1661000236_fn__1661000237_A_clinit() { A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000236_fn__1661000237_A_class }

func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000236_fn__1661000237_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000236_fn__1661000237_A); return ok }

func A_arbace_java_io_eval1661000236_fn__1661000237_A_Cast(x any) *A_arbace_java_io_eval1661000236_fn__1661000237_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000236_fn__1661000237_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000236_fn__1661000237_A_class)) }; return v }



type A_arbace_java_io_eval1661000240_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000240_A_New() *A_arbace_java_io_eval1661000240_A { t := &A_arbace_java_io_eval1661000240_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000240_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000240_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000240_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000240_A_class }

func (t *A_arbace_java_io_eval1661000240_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000240_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000240_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000240_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000240_A); return ok }

func A_arbace_java_io_eval1661000240_A_Cast(x any) *A_arbace_java_io_eval1661000240_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000240_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000240_A_class)) }; return v }



type A_arbace_java_io_eval1661000240_fn__1661000241_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000240_fn__1661000241_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000240_fn__1661000241_A_Init() { if !A_arbace_java_io_eval1661000240_fn__1661000241_A_init.Done() { A_arbace_java_io_eval1661000240_fn__1661000241_A_init.Run(A_arbace_java_io_eval1661000240_fn__1661000241_A_clinit) } }

func A_arbace_java_io_eval1661000240_fn__1661000241_A_clinit() { A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000240_fn__1661000241_A_class }

func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000240_fn__1661000241_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000240_fn__1661000241_A); return ok }

func A_arbace_java_io_eval1661000240_fn__1661000241_A_Cast(x any) *A_arbace_java_io_eval1661000240_fn__1661000241_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000240_fn__1661000241_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000240_fn__1661000241_A_class)) }; return v }



type A_arbace_java_io_eval1661000244_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000244_A_New() *A_arbace_java_io_eval1661000244_A { t := &A_arbace_java_io_eval1661000244_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000244_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000244_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000244_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000244_A_class }

func (t *A_arbace_java_io_eval1661000244_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000244_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000244_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000244_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000244_A); return ok }

func A_arbace_java_io_eval1661000244_A_Cast(x any) *A_arbace_java_io_eval1661000244_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000244_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000244_A_class)) }; return v }



type A_arbace_java_io_eval1661000244_fn__1661000245_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000244_fn__1661000245_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000244_fn__1661000245_A_Init() { if !A_arbace_java_io_eval1661000244_fn__1661000245_A_init.Done() { A_arbace_java_io_eval1661000244_fn__1661000245_A_init.Run(A_arbace_java_io_eval1661000244_fn__1661000245_A_clinit) } }

func A_arbace_java_io_eval1661000244_fn__1661000245_A_clinit() { A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000244_fn__1661000245_A_class }

func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000244_fn__1661000245_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000244_fn__1661000245_A); return ok }

func A_arbace_java_io_eval1661000244_fn__1661000245_A_Cast(x any) *A_arbace_java_io_eval1661000244_fn__1661000245_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000244_fn__1661000245_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000244_fn__1661000245_A_class)) }; return v }



type A_arbace_java_io_eval1661000248_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000248_A_New() *A_arbace_java_io_eval1661000248_A { t := &A_arbace_java_io_eval1661000248_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000248_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000248_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000248_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000248_A_class }

func (t *A_arbace_java_io_eval1661000248_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000248_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000248_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000248_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000248_A); return ok }

func A_arbace_java_io_eval1661000248_A_Cast(x any) *A_arbace_java_io_eval1661000248_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000248_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000248_A_class)) }; return v }



type A_arbace_java_io_eval1661000248_fn__1661000249_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000248_fn__1661000249_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000248_fn__1661000249_A_Init() { if !A_arbace_java_io_eval1661000248_fn__1661000249_A_init.Done() { A_arbace_java_io_eval1661000248_fn__1661000249_A_init.Run(A_arbace_java_io_eval1661000248_fn__1661000249_A_clinit) } }

func A_arbace_java_io_eval1661000248_fn__1661000249_A_clinit() { A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_146, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000248_fn__1661000249_A_class }

func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000248_fn__1661000249_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000248_fn__1661000249_A); return ok }

func A_arbace_java_io_eval1661000248_fn__1661000249_A_Cast(x any) *A_arbace_java_io_eval1661000248_fn__1661000249_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000248_fn__1661000249_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000248_fn__1661000249_A_class)) }; return v }



type A_arbace_java_io_eval1661000252_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000252_A_New() *A_arbace_java_io_eval1661000252_A { t := &A_arbace_java_io_eval1661000252_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000252_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000252_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000252_A_class }

func (t *A_arbace_java_io_eval1661000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000252_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000252_A); return ok }

func A_arbace_java_io_eval1661000252_A_Cast(x any) *A_arbace_java_io_eval1661000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000252_A_class)) }; return v }



type A_arbace_java_io_eval1661000252_fn__1661000253_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000252_fn__1661000253_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000252_fn__1661000253_A_Init() { if !A_arbace_java_io_eval1661000252_fn__1661000253_A_init.Done() { A_arbace_java_io_eval1661000252_fn__1661000253_A_init.Run(A_arbace_java_io_eval1661000252_fn__1661000253_A_clinit) } }

func A_arbace_java_io_eval1661000252_fn__1661000253_A_clinit() { A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_147, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000252_fn__1661000253_A_class }

func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000252_fn__1661000253_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000252_fn__1661000253_A); return ok }

func A_arbace_java_io_eval1661000252_fn__1661000253_A_Cast(x any) *A_arbace_java_io_eval1661000252_fn__1661000253_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000252_fn__1661000253_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000252_fn__1661000253_A_class)) }; return v }



type A_arbace_java_io_eval1661000256_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000256_A_New() *A_arbace_java_io_eval1661000256_A { t := &A_arbace_java_io_eval1661000256_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000256_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000256_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000256_A_class }

func (t *A_arbace_java_io_eval1661000256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000256_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000256_A); return ok }

func A_arbace_java_io_eval1661000256_A_Cast(x any) *A_arbace_java_io_eval1661000256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000256_A_class)) }; return v }



type A_arbace_java_io_eval1661000256_fn__1661000257_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000256_fn__1661000257_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000256_fn__1661000257_A_Init() { if !A_arbace_java_io_eval1661000256_fn__1661000257_A_init.Done() { A_arbace_java_io_eval1661000256_fn__1661000257_A_init.Run(A_arbace_java_io_eval1661000256_fn__1661000257_A_clinit) } }

func A_arbace_java_io_eval1661000256_fn__1661000257_A_clinit() { A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000256_fn__1661000257_A_class }

func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000256_fn__1661000257_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000256_fn__1661000257_A); return ok }

func A_arbace_java_io_eval1661000256_fn__1661000257_A_Cast(x any) *A_arbace_java_io_eval1661000256_fn__1661000257_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000256_fn__1661000257_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000256_fn__1661000257_A_class)) }; return v }



type A_arbace_java_io_eval1661000260_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000260_A_New() *A_arbace_java_io_eval1661000260_A { t := &A_arbace_java_io_eval1661000260_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000260_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000260_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000260_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000260_A_class }

func (t *A_arbace_java_io_eval1661000260_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000260_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000260_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000260_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000260_A); return ok }

func A_arbace_java_io_eval1661000260_A_Cast(x any) *A_arbace_java_io_eval1661000260_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000260_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000260_A_class)) }; return v }



type A_arbace_java_io_eval1661000260_fn__1661000261_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000260_fn__1661000261_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000260_fn__1661000261_A_Init() { if !A_arbace_java_io_eval1661000260_fn__1661000261_A_init.Done() { A_arbace_java_io_eval1661000260_fn__1661000261_A_init.Run(A_arbace_java_io_eval1661000260_fn__1661000261_A_clinit) } }

func A_arbace_java_io_eval1661000260_fn__1661000261_A_clinit() { A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000260_fn__1661000261_A_class }

func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000260_fn__1661000261_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000260_fn__1661000261_A); return ok }

func A_arbace_java_io_eval1661000260_fn__1661000261_A_Cast(x any) *A_arbace_java_io_eval1661000260_fn__1661000261_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000260_fn__1661000261_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000260_fn__1661000261_A_class)) }; return v }



type A_arbace_java_io_eval1661000264_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000264_A_New() *A_arbace_java_io_eval1661000264_A { t := &A_arbace_java_io_eval1661000264_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000264_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000264_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000264_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000264_A_class }

func (t *A_arbace_java_io_eval1661000264_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000264_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000264_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000264_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000264_A); return ok }

func A_arbace_java_io_eval1661000264_A_Cast(x any) *A_arbace_java_io_eval1661000264_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000264_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000264_A_class)) }; return v }



type A_arbace_java_io_eval1661000264_fn__1661000265_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000264_fn__1661000265_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000264_fn__1661000265_A_Init() { if !A_arbace_java_io_eval1661000264_fn__1661000265_A_init.Done() { A_arbace_java_io_eval1661000264_fn__1661000265_A_init.Run(A_arbace_java_io_eval1661000264_fn__1661000265_A_clinit) } }

func A_arbace_java_io_eval1661000264_fn__1661000265_A_clinit() { A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_150, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000264_fn__1661000265_A_class }

func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000264_fn__1661000265_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000264_fn__1661000265_A); return ok }

func A_arbace_java_io_eval1661000264_fn__1661000265_A_Cast(x any) *A_arbace_java_io_eval1661000264_fn__1661000265_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000264_fn__1661000265_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000264_fn__1661000265_A_class)) }; return v }



type A_arbace_java_io_eval1661000268_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000268_A_New() *A_arbace_java_io_eval1661000268_A { t := &A_arbace_java_io_eval1661000268_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000268_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000268_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000268_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000268_A_class }

func (t *A_arbace_java_io_eval1661000268_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000268_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000268_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000268_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000268_A); return ok }

func A_arbace_java_io_eval1661000268_A_Cast(x any) *A_arbace_java_io_eval1661000268_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000268_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000268_A_class)) }; return v }



type A_arbace_java_io_eval1661000268_fn__1661000269_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000268_fn__1661000269_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000268_fn__1661000269_A_Init() { if !A_arbace_java_io_eval1661000268_fn__1661000269_A_init.Done() { A_arbace_java_io_eval1661000268_fn__1661000269_A_init.Run(A_arbace_java_io_eval1661000268_fn__1661000269_A_clinit) } }

func A_arbace_java_io_eval1661000268_fn__1661000269_A_clinit() { A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_151, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000268_fn__1661000269_A_class }

func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000268_fn__1661000269_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000268_fn__1661000269_A); return ok }

func A_arbace_java_io_eval1661000268_fn__1661000269_A_Cast(x any) *A_arbace_java_io_eval1661000268_fn__1661000269_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000268_fn__1661000269_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000268_fn__1661000269_A_class)) }; return v }



type A_arbace_java_io_eval1661000272_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000272_A_New() *A_arbace_java_io_eval1661000272_A { t := &A_arbace_java_io_eval1661000272_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000272_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000272_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000272_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000272_A_class }

func (t *A_arbace_java_io_eval1661000272_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000272_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000272_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000272_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000272_A); return ok }

func A_arbace_java_io_eval1661000272_A_Cast(x any) *A_arbace_java_io_eval1661000272_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000272_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000272_A_class)) }; return v }



type A_arbace_java_io_eval1661000272_fn__1661000273_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000272_fn__1661000273_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000272_fn__1661000273_A_Init() { if !A_arbace_java_io_eval1661000272_fn__1661000273_A_init.Done() { A_arbace_java_io_eval1661000272_fn__1661000273_A_init.Run(A_arbace_java_io_eval1661000272_fn__1661000273_A_clinit) } }

func A_arbace_java_io_eval1661000272_fn__1661000273_A_clinit() { A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_152, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000272_fn__1661000273_A_class }

func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000272_fn__1661000273_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000272_fn__1661000273_A); return ok }

func A_arbace_java_io_eval1661000272_fn__1661000273_A_Cast(x any) *A_arbace_java_io_eval1661000272_fn__1661000273_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000272_fn__1661000273_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000272_fn__1661000273_A_class)) }; return v }



type A_arbace_java_io_eval1661000276_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000276_A_New() *A_arbace_java_io_eval1661000276_A { t := &A_arbace_java_io_eval1661000276_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000276_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000276_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000276_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000276_A_class }

func (t *A_arbace_java_io_eval1661000276_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000276_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000276_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000276_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000276_A); return ok }

func A_arbace_java_io_eval1661000276_A_Cast(x any) *A_arbace_java_io_eval1661000276_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000276_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000276_A_class)) }; return v }



type A_arbace_java_io_eval1661000276_fn__1661000277_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000276_fn__1661000277_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000276_fn__1661000277_A_Init() { if !A_arbace_java_io_eval1661000276_fn__1661000277_A_init.Done() { A_arbace_java_io_eval1661000276_fn__1661000277_A_init.Run(A_arbace_java_io_eval1661000276_fn__1661000277_A_clinit) } }

func A_arbace_java_io_eval1661000276_fn__1661000277_A_clinit() { A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_153, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000276_fn__1661000277_A_class }

func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000276_fn__1661000277_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000276_fn__1661000277_A); return ok }

func A_arbace_java_io_eval1661000276_fn__1661000277_A_Cast(x any) *A_arbace_java_io_eval1661000276_fn__1661000277_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000276_fn__1661000277_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000276_fn__1661000277_A_class)) }; return v }



type A_arbace_java_io_eval1661000280_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000280_A_New() *A_arbace_java_io_eval1661000280_A { t := &A_arbace_java_io_eval1661000280_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000280_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000280_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000280_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000280_A_class }

func (t *A_arbace_java_io_eval1661000280_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000280_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000280_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000280_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000280_A); return ok }

func A_arbace_java_io_eval1661000280_A_Cast(x any) *A_arbace_java_io_eval1661000280_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000280_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000280_A_class)) }; return v }



type A_arbace_java_io_eval1661000280_fn__1661000281_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000280_fn__1661000281_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000280_fn__1661000281_A_Init() { if !A_arbace_java_io_eval1661000280_fn__1661000281_A_init.Done() { A_arbace_java_io_eval1661000280_fn__1661000281_A_init.Run(A_arbace_java_io_eval1661000280_fn__1661000281_A_clinit) } }

func A_arbace_java_io_eval1661000280_fn__1661000281_A_clinit() { A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_154, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000280_fn__1661000281_A_class }

func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000280_fn__1661000281_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000280_fn__1661000281_A); return ok }

func A_arbace_java_io_eval1661000280_fn__1661000281_A_Cast(x any) *A_arbace_java_io_eval1661000280_fn__1661000281_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000280_fn__1661000281_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000280_fn__1661000281_A_class)) }; return v }



type A_arbace_java_io_eval1661000284_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000284_A_New() *A_arbace_java_io_eval1661000284_A { t := &A_arbace_java_io_eval1661000284_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000284_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000284_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000284_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000284_A_class }

func (t *A_arbace_java_io_eval1661000284_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000284_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000284_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000284_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000284_A); return ok }

func A_arbace_java_io_eval1661000284_A_Cast(x any) *A_arbace_java_io_eval1661000284_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000284_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000284_A_class)) }; return v }



type A_arbace_java_io_eval1661000284_fn__1661000285_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000284_fn__1661000285_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000284_fn__1661000285_A_Init() { if !A_arbace_java_io_eval1661000284_fn__1661000285_A_init.Done() { A_arbace_java_io_eval1661000284_fn__1661000285_A_init.Run(A_arbace_java_io_eval1661000284_fn__1661000285_A_clinit) } }

func A_arbace_java_io_eval1661000284_fn__1661000285_A_clinit() { A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_155, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000284_fn__1661000285_A_class }

func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000284_fn__1661000285_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000284_fn__1661000285_A); return ok }

func A_arbace_java_io_eval1661000284_fn__1661000285_A_Cast(x any) *A_arbace_java_io_eval1661000284_fn__1661000285_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000284_fn__1661000285_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000284_fn__1661000285_A_class)) }; return v }



type A_arbace_java_io_eval1661000288_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000288_A_New() *A_arbace_java_io_eval1661000288_A { t := &A_arbace_java_io_eval1661000288_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000288_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000288_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000288_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000288_A_class }

func (t *A_arbace_java_io_eval1661000288_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000288_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000288_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000288_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000288_A); return ok }

func A_arbace_java_io_eval1661000288_A_Cast(x any) *A_arbace_java_io_eval1661000288_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000288_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000288_A_class)) }; return v }



type A_arbace_java_io_eval1661000288_fn__1661000289_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000288_fn__1661000289_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000288_fn__1661000289_A_Init() { if !A_arbace_java_io_eval1661000288_fn__1661000289_A_init.Done() { A_arbace_java_io_eval1661000288_fn__1661000289_A_init.Run(A_arbace_java_io_eval1661000288_fn__1661000289_A_clinit) } }

func A_arbace_java_io_eval1661000288_fn__1661000289_A_clinit() { A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_156, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000288_fn__1661000289_A_class }

func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000288_fn__1661000289_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000288_fn__1661000289_A); return ok }

func A_arbace_java_io_eval1661000288_fn__1661000289_A_Cast(x any) *A_arbace_java_io_eval1661000288_fn__1661000289_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000288_fn__1661000289_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000288_fn__1661000289_A_class)) }; return v }



type A_arbace_java_io_eval1661000292_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000292_A_New() *A_arbace_java_io_eval1661000292_A { t := &A_arbace_java_io_eval1661000292_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000292_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000292_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000292_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000292_A_class }

func (t *A_arbace_java_io_eval1661000292_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000292_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000292_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000292_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000292_A); return ok }

func A_arbace_java_io_eval1661000292_A_Cast(x any) *A_arbace_java_io_eval1661000292_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000292_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000292_A_class)) }; return v }



type A_arbace_java_io_eval1661000292_fn__1661000293_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000292_fn__1661000293_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000292_fn__1661000293_A_Init() { if !A_arbace_java_io_eval1661000292_fn__1661000293_A_init.Done() { A_arbace_java_io_eval1661000292_fn__1661000293_A_init.Run(A_arbace_java_io_eval1661000292_fn__1661000293_A_clinit) } }

func A_arbace_java_io_eval1661000292_fn__1661000293_A_clinit() { A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_157, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000292_fn__1661000293_A_class }

func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000292_fn__1661000293_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000292_fn__1661000293_A); return ok }

func A_arbace_java_io_eval1661000292_fn__1661000293_A_Cast(x any) *A_arbace_java_io_eval1661000292_fn__1661000293_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000292_fn__1661000293_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000292_fn__1661000293_A_class)) }; return v }



type A_arbace_java_io_eval1661000296_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000296_A_New() *A_arbace_java_io_eval1661000296_A { t := &A_arbace_java_io_eval1661000296_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000296_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000296_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000296_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000296_A_class }

func (t *A_arbace_java_io_eval1661000296_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000296_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000296_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000296_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000296_A); return ok }

func A_arbace_java_io_eval1661000296_A_Cast(x any) *A_arbace_java_io_eval1661000296_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000296_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000296_A_class)) }; return v }



type A_arbace_java_io_eval1661000296_fn__1661000297_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000296_fn__1661000297_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000296_fn__1661000297_A_Init() { if !A_arbace_java_io_eval1661000296_fn__1661000297_A_init.Done() { A_arbace_java_io_eval1661000296_fn__1661000297_A_init.Run(A_arbace_java_io_eval1661000296_fn__1661000297_A_clinit) } }

func A_arbace_java_io_eval1661000296_fn__1661000297_A_clinit() { A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_158, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000296_fn__1661000297_A_class }

func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000296_fn__1661000297_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000296_fn__1661000297_A); return ok }

func A_arbace_java_io_eval1661000296_fn__1661000297_A_Cast(x any) *A_arbace_java_io_eval1661000296_fn__1661000297_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000296_fn__1661000297_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000296_fn__1661000297_A_class)) }; return v }



type A_arbace_java_io_eval1661000300_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000300_A_New() *A_arbace_java_io_eval1661000300_A { t := &A_arbace_java_io_eval1661000300_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000300_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000300_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000300_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000300_A_class }

func (t *A_arbace_java_io_eval1661000300_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000300_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000300_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000300_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000300_A); return ok }

func A_arbace_java_io_eval1661000300_A_Cast(x any) *A_arbace_java_io_eval1661000300_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000300_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000300_A_class)) }; return v }



type A_arbace_java_io_eval1661000300_fn__1661000301_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000300_fn__1661000301_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000300_fn__1661000301_A_Init() { if !A_arbace_java_io_eval1661000300_fn__1661000301_A_init.Done() { A_arbace_java_io_eval1661000300_fn__1661000301_A_init.Run(A_arbace_java_io_eval1661000300_fn__1661000301_A_clinit) } }

func A_arbace_java_io_eval1661000300_fn__1661000301_A_clinit() { A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_159, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000300_fn__1661000301_A_class }

func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000300_fn__1661000301_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000300_fn__1661000301_A); return ok }

func A_arbace_java_io_eval1661000300_fn__1661000301_A_Cast(x any) *A_arbace_java_io_eval1661000300_fn__1661000301_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000300_fn__1661000301_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000300_fn__1661000301_A_class)) }; return v }



type A_arbace_java_io_eval1661000304_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000304_A_New() *A_arbace_java_io_eval1661000304_A { t := &A_arbace_java_io_eval1661000304_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000304_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000304_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000304_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000304_A_class }

func (t *A_arbace_java_io_eval1661000304_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000304_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000304_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000304_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000304_A); return ok }

func A_arbace_java_io_eval1661000304_A_Cast(x any) *A_arbace_java_io_eval1661000304_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000304_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000304_A_class)) }; return v }



type A_arbace_java_io_eval1661000304_fn__1661000305_A struct{ jrt.Object }

func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Is_Compiler_AOTF3() {}

var A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class *jrt.Class

var A_arbace_java_io_eval1661000304_fn__1661000305_A_init jrt.ClassInit

func A_arbace_java_io_eval1661000304_fn__1661000305_A_Init() { if !A_arbace_java_io_eval1661000304_fn__1661000305_A_init.Done() { A_arbace_java_io_eval1661000304_fn__1661000305_A_init.Run(A_arbace_java_io_eval1661000304_fn__1661000305_A_clinit) } }

func A_arbace_java_io_eval1661000304_fn__1661000305_A_clinit() { A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_160, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000304_fn__1661000305_A_class }

func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000304_fn__1661000305_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000304_fn__1661000305_A); return ok }

func A_arbace_java_io_eval1661000304_fn__1661000305_A_Cast(x any) *A_arbace_java_io_eval1661000304_fn__1661000305_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000304_fn__1661000305_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000304_fn__1661000305_A_class)) }; return v }



type A_arbace_java_io_file_A struct{ jrt.Object }

func (t *A_arbace_java_io_file_A) Is_Compiler_AOTR2() {}

func (t *A_arbace_java_io_file_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_java_io_file_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_file_A_fn_class *jrt.Class

var A_arbace_java_io_file_A_init jrt.ClassInit

func A_arbace_java_io_file_A_Init() { if !A_arbace_java_io_file_A_init.Done() { A_arbace_java_io_file_A_init.Run(A_arbace_java_io_file_A_clinit) } }

func A_arbace_java_io_file_A_clinit() { A_arbace_java_io_file_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_161, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_file_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_file_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_file_A_class }

func (t *A_arbace_java_io_file_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_file_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_file_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_file_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_file_A); return ok }

func A_arbace_java_io_file_A_Cast(x any) *A_arbace_java_io_file_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_file_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_file_A_class)) }; return v }



type A_arbace_java_io_fn__1661000144_A struct{ jrt.Object }

func (t *A_arbace_java_io_fn__1661000144_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_fn__1661000144_A_fn_class *jrt.Class

var A_arbace_java_io_fn__1661000144_A_init jrt.ClassInit

func A_arbace_java_io_fn__1661000144_A_Init() { if !A_arbace_java_io_fn__1661000144_A_init.Done() { A_arbace_java_io_fn__1661000144_A_init.Run(A_arbace_java_io_fn__1661000144_A_clinit) } }

func A_arbace_java_io_fn__1661000144_A_clinit() { A_arbace_java_io_fn__1661000144_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_162, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_fn__1661000144_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_fn__1661000144_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_fn__1661000144_A_class }

func (t *A_arbace_java_io_fn__1661000144_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_fn__1661000144_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_fn__1661000144_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_fn__1661000144_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_fn__1661000144_A); return ok }

func A_arbace_java_io_fn__1661000144_A_Cast(x any) *A_arbace_java_io_fn__1661000144_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_fn__1661000144_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_fn__1661000144_A_class)) }; return v }



type A_arbace_java_io_fn__1661000146_A struct{ jrt.Object }

func (t *A_arbace_java_io_fn__1661000146_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_fn__1661000146_A_fn_class *jrt.Class

var A_arbace_java_io_fn__1661000146_A_init jrt.ClassInit

func A_arbace_java_io_fn__1661000146_A_Init() { if !A_arbace_java_io_fn__1661000146_A_init.Done() { A_arbace_java_io_fn__1661000146_A_init.Run(A_arbace_java_io_fn__1661000146_A_clinit) } }

func A_arbace_java_io_fn__1661000146_A_clinit() { A_arbace_java_io_fn__1661000146_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_163, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_fn__1661000146_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_fn__1661000146_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_fn__1661000146_A_class }

func (t *A_arbace_java_io_fn__1661000146_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_fn__1661000146_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_fn__1661000146_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_fn__1661000146_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_fn__1661000146_A); return ok }

func A_arbace_java_io_fn__1661000146_A_Cast(x any) *A_arbace_java_io_fn__1661000146_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_fn__1661000146_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_fn__1661000146_A_class)) }; return v }



type A_arbace_java_io_fn__1661000148_A struct{ jrt.Object }

func (t *A_arbace_java_io_fn__1661000148_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_fn__1661000148_A_fn_class *jrt.Class

var A_arbace_java_io_fn__1661000148_A_init jrt.ClassInit

func A_arbace_java_io_fn__1661000148_A_Init() { if !A_arbace_java_io_fn__1661000148_A_init.Done() { A_arbace_java_io_fn__1661000148_A_init.Run(A_arbace_java_io_fn__1661000148_A_clinit) } }

func A_arbace_java_io_fn__1661000148_A_clinit() { A_arbace_java_io_fn__1661000148_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_164, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_fn__1661000148_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_fn__1661000148_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_fn__1661000148_A_class }

func (t *A_arbace_java_io_fn__1661000148_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_fn__1661000148_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_fn__1661000148_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_fn__1661000148_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_fn__1661000148_A); return ok }

func A_arbace_java_io_fn__1661000148_A_Cast(x any) *A_arbace_java_io_fn__1661000148_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_fn__1661000148_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_fn__1661000148_A_class)) }; return v }



type A_arbace_java_io_fn__1661000150_A struct{ jrt.Object }

func (t *A_arbace_java_io_fn__1661000150_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_fn__1661000150_A_fn_class *jrt.Class

var A_arbace_java_io_fn__1661000150_A_init jrt.ClassInit

func A_arbace_java_io_fn__1661000150_A_Init() { if !A_arbace_java_io_fn__1661000150_A_init.Done() { A_arbace_java_io_fn__1661000150_A_init.Run(A_arbace_java_io_fn__1661000150_A_clinit) } }

func A_arbace_java_io_fn__1661000150_A_clinit() { A_arbace_java_io_fn__1661000150_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_166, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_fn__1661000150_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_fn__1661000150_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_fn__1661000150_A_class }

func (t *A_arbace_java_io_fn__1661000150_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_fn__1661000150_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_fn__1661000150_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_fn__1661000150_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_fn__1661000150_A); return ok }

func A_arbace_java_io_fn__1661000150_A_Cast(x any) *A_arbace_java_io_fn__1661000150_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_fn__1661000150_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_fn__1661000150_A_class)) }; return v }



type A_arbace_java_io_input_stream_A struct{ jrt.Object }

func (t *A_arbace_java_io_input_stream_A) Is_Compiler_AOTR1() {}

var A_arbace_java_io_input_stream_A_fn_class *jrt.Class

var A_arbace_java_io_input_stream_A_init jrt.ClassInit

func A_arbace_java_io_input_stream_A_Init() { if !A_arbace_java_io_input_stream_A_init.Done() { A_arbace_java_io_input_stream_A_init.Run(A_arbace_java_io_input_stream_A_clinit) } }

func A_arbace_java_io_input_stream_A_clinit() { A_arbace_java_io_input_stream_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_168, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_input_stream_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_input_stream_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_input_stream_A_class }

func (t *A_arbace_java_io_input_stream_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_input_stream_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_input_stream_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_input_stream_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_input_stream_A); return ok }

func A_arbace_java_io_input_stream_A_Cast(x any) *A_arbace_java_io_input_stream_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_input_stream_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_input_stream_A_class)) }; return v }



type A_arbace_java_io_inputstream__GT_reader_A struct{ jrt.Object }

func (t *A_arbace_java_io_inputstream__GT_reader_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_inputstream__GT_reader_A_fn_class *jrt.Class

var A_arbace_java_io_inputstream__GT_reader_A_init jrt.ClassInit

func A_arbace_java_io_inputstream__GT_reader_A_Init() { if !A_arbace_java_io_inputstream__GT_reader_A_init.Done() { A_arbace_java_io_inputstream__GT_reader_A_init.Run(A_arbace_java_io_inputstream__GT_reader_A_clinit) } }

func A_arbace_java_io_inputstream__GT_reader_A_clinit() { A_arbace_java_io_inputstream__GT_reader_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_169, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_inputstream__GT_reader_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_inputstream__GT_reader_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_inputstream__GT_reader_A_class }

func (t *A_arbace_java_io_inputstream__GT_reader_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_inputstream__GT_reader_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_inputstream__GT_reader_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_inputstream__GT_reader_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_inputstream__GT_reader_A); return ok }

func A_arbace_java_io_inputstream__GT_reader_A_Cast(x any) *A_arbace_java_io_inputstream__GT_reader_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_inputstream__GT_reader_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_inputstream__GT_reader_A_class)) }; return v }



type A_arbace_java_io_make_parents_A struct{ jrt.Object }

func (t *A_arbace_java_io_make_parents_A) Is_Compiler_AOTR1() {}

var A_arbace_java_io_make_parents_A_fn_class *jrt.Class

var A_arbace_java_io_make_parents_A_init jrt.ClassInit

func A_arbace_java_io_make_parents_A_Init() { if !A_arbace_java_io_make_parents_A_init.Done() { A_arbace_java_io_make_parents_A_init.Run(A_arbace_java_io_make_parents_A_clinit) } }

func A_arbace_java_io_make_parents_A_clinit() { A_arbace_java_io_make_parents_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_170, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_make_parents_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_make_parents_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_make_parents_A_class }

func (t *A_arbace_java_io_make_parents_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_make_parents_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_make_parents_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_make_parents_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_make_parents_A); return ok }

func A_arbace_java_io_make_parents_A_Cast(x any) *A_arbace_java_io_make_parents_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_make_parents_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_make_parents_A_class)) }; return v }



type A_arbace_java_io_output_stream_A struct{ jrt.Object }

func (t *A_arbace_java_io_output_stream_A) Is_Compiler_AOTR1() {}

var A_arbace_java_io_output_stream_A_fn_class *jrt.Class

var A_arbace_java_io_output_stream_A_init jrt.ClassInit

func A_arbace_java_io_output_stream_A_Init() { if !A_arbace_java_io_output_stream_A_init.Done() { A_arbace_java_io_output_stream_A_init.Run(A_arbace_java_io_output_stream_A_clinit) } }

func A_arbace_java_io_output_stream_A_clinit() { A_arbace_java_io_output_stream_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_171, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_output_stream_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_output_stream_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_output_stream_A_class }

func (t *A_arbace_java_io_output_stream_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_output_stream_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_output_stream_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_output_stream_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_output_stream_A); return ok }

func A_arbace_java_io_output_stream_A_Cast(x any) *A_arbace_java_io_output_stream_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_output_stream_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_output_stream_A_class)) }; return v }



type A_arbace_java_io_outputstream__GT_writer_A struct{ jrt.Object }

func (t *A_arbace_java_io_outputstream__GT_writer_A) Is_Compiler_AOTF2() {}

var A_arbace_java_io_outputstream__GT_writer_A_fn_class *jrt.Class

var A_arbace_java_io_outputstream__GT_writer_A_init jrt.ClassInit

func A_arbace_java_io_outputstream__GT_writer_A_Init() { if !A_arbace_java_io_outputstream__GT_writer_A_init.Done() { A_arbace_java_io_outputstream__GT_writer_A_init.Run(A_arbace_java_io_outputstream__GT_writer_A_clinit) } }

func A_arbace_java_io_outputstream__GT_writer_A_clinit() { A_arbace_java_io_outputstream__GT_writer_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_172, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_outputstream__GT_writer_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_outputstream__GT_writer_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_outputstream__GT_writer_A_class }

func (t *A_arbace_java_io_outputstream__GT_writer_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_outputstream__GT_writer_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_outputstream__GT_writer_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_outputstream__GT_writer_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_outputstream__GT_writer_A); return ok }

func A_arbace_java_io_outputstream__GT_writer_A_Cast(x any) *A_arbace_java_io_outputstream__GT_writer_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_outputstream__GT_writer_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_outputstream__GT_writer_A_class)) }; return v }



type A_arbace_java_io_reader_A struct{ jrt.Object }

func (t *A_arbace_java_io_reader_A) Is_Compiler_AOTR1() {}

var A_arbace_java_io_reader_A_fn_class *jrt.Class

var A_arbace_java_io_reader_A_init jrt.ClassInit

func A_arbace_java_io_reader_A_Init() { if !A_arbace_java_io_reader_A_init.Done() { A_arbace_java_io_reader_A_init.Run(A_arbace_java_io_reader_A_clinit) } }

func A_arbace_java_io_reader_A_clinit() { A_arbace_java_io_reader_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_173, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_reader_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_reader_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_reader_A_class }

func (t *A_arbace_java_io_reader_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_reader_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_reader_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_reader_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_reader_A); return ok }

func A_arbace_java_io_reader_A_Cast(x any) *A_arbace_java_io_reader_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_reader_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_reader_A_class)) }; return v }



type A_arbace_java_io_resource_A struct{ jrt.Object }

func (t *A_arbace_java_io_resource_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_java_io_resource_A) Is_Compiler_AOTF1() {}

var A_arbace_java_io_resource_A_fn_class *jrt.Class

var A_arbace_java_io_resource_A_init jrt.ClassInit

func A_arbace_java_io_resource_A_Init() { if !A_arbace_java_io_resource_A_init.Done() { A_arbace_java_io_resource_A_init.Run(A_arbace_java_io_resource_A_clinit) } }

func A_arbace_java_io_resource_A_clinit() { A_arbace_java_io_resource_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_174, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_io_resource_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_resource_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_resource_A_class }

func (t *A_arbace_java_io_resource_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_resource_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_resource_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_resource_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_resource_A); return ok }

func A_arbace_java_io_resource_A_Cast(x any) *A_arbace_java_io_resource_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_resource_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_resource_A_class)) }; return v }



type A_arbace_java_io_writer_A struct{ jrt.Object }

func (t *A_arbace_java_io_writer_A) Is_Compiler_AOTR1() {}

var A_arbace_java_io_writer_A_fn_class *jrt.Class

var A_arbace_java_io_writer_A_init jrt.ClassInit

func A_arbace_java_io_writer_A_Init() { if !A_arbace_java_io_writer_A_init.Done() { A_arbace_java_io_writer_A_init.Run(A_arbace_java_io_writer_A_clinit) } }

func A_arbace_java_io_writer_A_clinit() { A_arbace_java_io_writer_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_177, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_io_writer_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_writer_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_writer_A_class }

func (t *A_arbace_java_io_writer_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_writer_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_io_writer_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_writer_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_writer_A); return ok }

func A_arbace_java_io_writer_A_Cast(x any) *A_arbace_java_io_writer_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_writer_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_writer_A_class)) }; return v }
