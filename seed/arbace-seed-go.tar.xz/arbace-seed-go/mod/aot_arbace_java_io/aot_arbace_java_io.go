//line aot_arbace_java_io.ae:1
package aot_arbace_java_io

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New() *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_io_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io_A_const_1); lang.IFn_Cast(A_arbace_java_io_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_6)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_7)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_8)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_9)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_10)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_11)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_12)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_13)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_14)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_15)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_16)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_17)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_18)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_19)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_20)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_21)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_22)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_23)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_24)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_25)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_26)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_27)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_28)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_29)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_30)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_31)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_java_io_eval1661000008_fn__1661000009_A_New() *A_arbace_java_io_eval1661000008_fn__1661000009_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000008_fn__1661000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_io_eval1661000008_fn__1661000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_java_io_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_java_io_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_io_A_const_7.GetRawRoot__O(), A_arbace_java_io_A_const_8) }




























func A_arbace_java_io_eval1661000024_fn__1661000025_A_New() *A_arbace_java_io_eval1661000024_fn__1661000025_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1661000015__2_ any; var fnbody__21 any = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_New(); var tmp1 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_32, false, nil); A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class = fncls__20d; tmp1 = fncls__20d } else { tmp1 = fncls__20 }; G__1661000015__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__21, tmp1, nil); var f__231000283__auto____3 any; var fnbody__30 any = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_New_O(G__1661000015__2_); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_33, false, fnbody__30); A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_New_O(p0 any) *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Ctor_O(c__G__1661000015 any) { t.F_G__1661000015 = c__G__1661000015 }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A) Invoke_O_O__O(self, gf__x__1661000029__1 any) any { var cache__231000280__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000029__1)); if jrt.J2g_Truth(f__231000281__auto____3) { return lang.IFn_Cast(f__231000281__auto____3).Invoke_O__O(gf__x__1661000029__1) } else { var tmp1 any; var root_22 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any = self; var arg_26 any = gf__x__1661000029__1; var arg_27 any = A_arbace_java_io_A_const_10; var arg_28 any = t.F_G__1661000015; if linked_23 == nil { tmp1 = ifn_24.Invoke_O_O_O_O__O(arg_25, arg_26, arg_27, arg_28) } else { tmp1 = linked_23.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_22, arg_25, arg_26, arg_27, arg_28) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__x__1661000029__1) } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_New() *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A) Invoke_O_O__O(self, gf__x__1661000026__1 any) any { var target_19 any = gf__x__1661000026__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_19 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_19) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_19, Lit_34, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_java_io_Coercions_A_Cast(target_19).As_file__O() } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_A_New() *A_arbace_java_io_eval1661000024_fn__1661000033_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1661000017__2_ any; var fnbody__33 any = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_New(); var tmp1 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_35, false, nil); A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class = fncls__32d; tmp1 = fncls__32d } else { tmp1 = fncls__32 }; G__1661000017__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__33, tmp1, nil); var f__231000283__auto____3 any; var fnbody__42 any = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_New_O(G__1661000017__2_); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_36, false, fnbody__42); A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__42, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_New_O(p0 any) *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A{}; t.Ctor_O(p0); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Ctor_O(c__G__1661000017 any) { t.F_G__1661000017 = c__G__1661000017 }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A) Invoke_O_O__O(self, gf__x__1661000037__1 any) any { var cache__231000280__auto____2 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____3 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____2)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000037__1)); if jrt.J2g_Truth(f__231000281__auto____3) { return lang.IFn_Cast(f__231000281__auto____3).Invoke_O__O(gf__x__1661000037__1) } else { var tmp1 any; var root_34 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any = self; var arg_38 any = gf__x__1661000037__1; var arg_39 any = A_arbace_java_io_A_const_10; var arg_40 any = t.F_G__1661000017; if linked_35 == nil { tmp1 = ifn_36.Invoke_O_O_O_O__O(arg_37, arg_38, arg_39, arg_40) } else { tmp1 = linked_35.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_34, arg_37, arg_38, arg_39, arg_40) }; return lang.IFn_Cast(tmp1).Invoke_O__O(gf__x__1661000037__1) } }
//line :38:1
func A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_New() *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Ctor() {}
//line :38:1
func (t *A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A) Invoke_O_O__O(self, gf__x__1661000034__1 any) any { var target_31 any = gf__x__1661000034__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_31 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_31) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_31, Lit_37, jrt.RefArrayOf(jrt.Object_class)) } else { return A_arbace_java_io_Coercions_A_Cast(target_31).As_url__O() } }




func A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New() *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_escaped_utf8_urlstring__GT_str_A{}; t.Ctor(); return t }
//line :43:1
func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Ctor() {}
//line :43:1
func (t *A_arbace_java_io_escaped_utf8_urlstring__GT_str_A) Invoke_O_O__O(self, s__0 any) any {

	var tmp1 any; var root_43 any = A_arbace_java_io_A_const_11.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_45 lang.IFn
//line :44:1
	if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = s__0; var arg_47 any = Lit_4; var arg_48 any = Lit_5; if linked_44 == nil { tmp1 = ifn_45.Invoke_O_O_O__O(arg_46, arg_47, arg_48) } else { tmp1 = linked_44.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_43, arg_46, arg_47, arg_48) }
	return jrt.URLDecoder_Decode_String_String__String(jrt.String_Cast(tmp1), Lit_3).Ref()
}
func A_arbace_java_io_eval1661000047_fn__1661000048_A_New() *A_arbace_java_io_eval1661000047_fn__1661000048_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000047_fn__1661000048_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000048_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :47:1
func A_arbace_java_io_eval1661000047_fn__1661000050_A_New() *A_arbace_java_io_eval1661000047_fn__1661000050_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000047_fn__1661000050_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000047_fn__1661000050_A) Invoke_O_O__O(self, ___1 any) any { return nil }
//line :47:1
func A_arbace_java_io_eval1661000053_fn__1661000054_A_New() *A_arbace_java_io_eval1661000053_fn__1661000054_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000053_fn__1661000054_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000054_A) Invoke_O_O__O(self, s__1 any) any { return jrt.File_New_String(jrt.String_Cast(s__1)) }
//line :47:1
func A_arbace_java_io_eval1661000053_fn__1661000056_A_New() *A_arbace_java_io_eval1661000053_fn__1661000056_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000053_fn__1661000056_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000053_fn__1661000056_A) Invoke_O_O__O(self, s__1 any) any {






	return lang.RT_ToUrl_String__URL_NoInit(jrt.String_Cast(s__1)).Ref() }
//line :47:1
func A_arbace_java_io_eval1661000059_fn__1661000060_A_New() *A_arbace_java_io_eval1661000059_fn__1661000060_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000059_fn__1661000060_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000060_A) Invoke_O_O__O(self, f__1 any) any { return f__1 }
//line :47:1
func A_arbace_java_io_eval1661000059_fn__1661000062_A_New() *A_arbace_java_io_eval1661000059_fn__1661000062_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000059_fn__1661000062_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000059_fn__1661000062_A) Invoke_O_O__O(self, f__1 any) any {










	return lang.RT_ToUrl_File__URL_NoInit(jrt.File_Cast(f__1)).Ref() }
//line :47:1
func A_arbace_java_io_eval1661000065_fn__1661000066_A_New() *A_arbace_java_io_eval1661000065_fn__1661000066_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000065_fn__1661000066_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000066_A) Invoke_O_O__O(self, u__1 any) any { return u__1 }
//line :47:1
func A_arbace_java_io_eval1661000065_fn__1661000068_A_New() *A_arbace_java_io_eval1661000065_fn__1661000068_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000065_fn__1661000068_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000065_fn__1661000068_A) Invoke_O_O__O(self, u__1 any) any {















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_38, jrt.NN(jrt.URL_Cast(u__1)).GetProtocol__String().Ref()) {
		var target_49 any; var root_50 any = A_arbace_java_io_A_const_12.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = jrt.NN(jrt.NN(jrt.URL_Cast(u__1)).GetFile__String()).Replace_C_C__String(jrt.NN(jrt.Character_Cast(A_arbace_java_io_A_const_13)).CharValue__C(), jrt.File_separatorChar).Ref(); if linked_51 == nil { target_49 = ifn_52.Invoke_O__O(arg_53) } else { target_49 = linked_51.(*A_arbace_java_io_escaped_utf8_urlstring__GT_str_A).Invoke_O_O__O(root_50, arg_53) }; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_49); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_49) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_Coercions_A_Cast(target_49).As_file__O() } else { return lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_49) } } else {
//line :63:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_39, nil), jrt.RefArrayOf(jrt.Object_class, nil, u__1))))) } }
//line :47:1
func A_arbace_java_io_eval1661000071_fn__1661000072_A_New() *A_arbace_java_io_eval1661000071_fn__1661000072_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000071_fn__1661000072_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000072_A) Invoke_O_O__O(self, u__1 any) any {





















	return jrt.NN(jrt.URI_Cast(u__1)).ToURL__URL().Ref() }
//line :47:1
func A_arbace_java_io_eval1661000071_fn__1661000074_A_New() *A_arbace_java_io_eval1661000071_fn__1661000074_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000071_fn__1661000074_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Ctor() {}
//line :47:1
func (t *A_arbace_java_io_eval1661000071_fn__1661000074_A) Invoke_O_O__O(self, u__1 any) any {






















	var target_54 any; var target_55 any = u__1; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_55); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_55) }; tmp1 = tmp2; if tmp1 { target_54 = A_arbace_java_io_Coercions_A_Cast(target_55).As_url__O() } else { target_54 = lang.IFn_Cast(A_arbace_java_io_A_const_15.GetRawRoot__O()).Invoke_O__O(target_55) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_Coercions_A_InstanceOf(target_54); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_54) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_Coercions_A_Cast(target_54).As_file__O() } else { return lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_54)
	} }
func A_arbace_java_io_eval1661000091_fn__1661000092_A_New() *A_arbace_java_io_eval1661000091_fn__1661000092_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1661000082__2_ any; var fnbody__58 any = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_New(); var tmp1 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_40, false, nil); A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class = fncls__57d; tmp1 = fncls__57d } else { tmp1 = fncls__57 }; G__1661000082__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__58, tmp1, nil); var f__231000283__auto____3 any; var fnbody__67 any = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_New_O(G__1661000082__2_); var tmp2 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_41, false, fnbody__67); A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class = fncls__66d; tmp2 = fncls__66d } else { tmp2 = fncls__66 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__67, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Ctor_O(c__G__1661000082 any) { t.F_G__1661000082 = c__G__1661000082 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A) Invoke_O_O_O__O(self, gf__x__1661000097__1, gf__opts__1661000098__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000097__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__x__1661000097__1, gf__opts__1661000098__2) } else { var tmp1 any; var root_59 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_60 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_59, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_61 lang.IFn; if linked_60 == nil { ifn_61 = lang.IFn_Cast(root_59) } else { ifn_61 = nil }; var arg_62 any = self; var arg_63 any = gf__x__1661000097__1; var arg_64 any = A_arbace_java_io_A_const_16; var arg_65 any = t.F_G__1661000082; if linked_60 == nil { tmp1 = ifn_61.Invoke_O_O_O_O__O(arg_62, arg_63, arg_64, arg_65) } else { tmp1 = linked_60.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_59, arg_62, arg_63, arg_64, arg_65) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000097__1, gf__opts__1661000098__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_New() *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A) Invoke_O_O_O__O(self, gf__x__1661000093__1, gf__opts__1661000094__2 any) any { var target_56 any = gf__x__1661000093__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_56 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_56) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_56, Lit_42, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000094__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_56).Make_input_stream_O__O(gf__opts__1661000094__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_A_New() *A_arbace_java_io_eval1661000091_fn__1661000102_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1661000084__2_ any; var fnbody__70 any = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_New(); var tmp1 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_43, false, nil); A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class = fncls__69d; tmp1 = fncls__69d } else { tmp1 = fncls__69 }; G__1661000084__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__70, tmp1, nil); var f__231000283__auto____3 any; var fnbody__79 any = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_New_O(G__1661000084__2_); var tmp2 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, fnbody__79); A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class = fncls__78d; tmp2 = fncls__78d } else { tmp2 = fncls__78 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__79, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Ctor_O(c__G__1661000084 any) { t.F_G__1661000084 = c__G__1661000084 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A) Invoke_O_O_O__O(self, gf__x__1661000107__1, gf__opts__1661000108__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000107__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__x__1661000107__1, gf__opts__1661000108__2) } else { var tmp1 any; var root_71 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = self; var arg_75 any = gf__x__1661000107__1; var arg_76 any = A_arbace_java_io_A_const_16; var arg_77 any = t.F_G__1661000084; if linked_72 == nil { tmp1 = ifn_73.Invoke_O_O_O_O__O(arg_74, arg_75, arg_76, arg_77) } else { tmp1 = linked_72.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_71, arg_74, arg_75, arg_76, arg_77) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000107__1, gf__opts__1661000108__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_New() *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A) Invoke_O_O_O__O(self, gf__x__1661000103__1, gf__opts__1661000104__2 any) any { var target_68 any = gf__x__1661000103__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_68 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_68) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_68, Lit_45, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000104__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_68).Make_output_stream_O__O(gf__opts__1661000104__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_A_New() *A_arbace_java_io_eval1661000091_fn__1661000112_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1661000078__2_ any; var fnbody__82 any = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_New(); var tmp1 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, nil); A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class = fncls__81d; tmp1 = fncls__81d } else { tmp1 = fncls__81 }; G__1661000078__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__82, tmp1, nil); var f__231000283__auto____3 any; var fnbody__91 any = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_New_O(G__1661000078__2_); var tmp2 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__91); A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class = fncls__90d; tmp2 = fncls__90d } else { tmp2 = fncls__90 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__91, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Ctor_O(c__G__1661000078 any) { t.F_G__1661000078 = c__G__1661000078 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A) Invoke_O_O_O__O(self, gf__x__1661000117__1, gf__opts__1661000118__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000117__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__x__1661000117__1, gf__opts__1661000118__2) } else { var tmp1 any; var root_83 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = self; var arg_87 any = gf__x__1661000117__1; var arg_88 any = A_arbace_java_io_A_const_16; var arg_89 any = t.F_G__1661000078; if linked_84 == nil { tmp1 = ifn_85.Invoke_O_O_O_O__O(arg_86, arg_87, arg_88, arg_89) } else { tmp1 = linked_84.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_83, arg_86, arg_87, arg_88, arg_89) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000117__1, gf__opts__1661000118__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_New() *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A) Invoke_O_O_O__O(self, gf__x__1661000113__1, gf__opts__1661000114__2 any) any { var target_80 any = gf__x__1661000113__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_80 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_80) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_80, Lit_48, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000114__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_80).Make_reader_O__O(gf__opts__1661000114__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_A_New() *A_arbace_java_io_eval1661000091_fn__1661000122_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_A) Invoke_O_O__O(self, cache__231000282__auto____1 any) any { var G__1661000080__2_ any; var fnbody__94 any = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_New(); var tmp1 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class; if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class = fncls__93d; tmp1 = fncls__93d } else { tmp1 = fncls__93 }; G__1661000080__2_ = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__94, tmp1, nil); var f__231000283__auto____3 any; var fnbody__103 any = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_New_O(G__1661000080__2_); var tmp2 *jrt.Class; var fncls__102 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class; if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__103); A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class = fncls__102d; tmp2 = fncls__102d } else { tmp2 = fncls__102 }; f__231000283__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__103, tmp2, nil); lang.AFunction_Cast(f__231000283__auto____3).Self_AFunction().F___methodImplCache.Store(lang.MethodImplCache_Cast(cache__231000282__auto____1)); return f__231000283__auto____3 }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_New_O(p0 any) *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A{}; t.Ctor_O(p0); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Ctor_O(c__G__1661000080 any) { t.F_G__1661000080 = c__G__1661000080 }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A) Invoke_O_O_O__O(self, gf__x__1661000127__1, gf__opts__1661000128__2 any) any { var cache__231000280__auto____3 any = lang.AFunction_Cast(self).Self_AFunction().F___methodImplCache.Load().Ref(); var f__231000281__auto____4 any = jrt.NN(lang.MethodImplCache_Cast(cache__231000280__auto____3)).FnFor_Class__IFn(lang.Util_ClassOf_O__Class_NoInit(gf__x__1661000127__1)); if jrt.J2g_Truth(f__231000281__auto____4) { return lang.IFn_Cast(f__231000281__auto____4).Invoke_O_O__O(gf__x__1661000127__1, gf__opts__1661000128__2) } else { var tmp1 any; var root_95 any = A_arbace_java_io_A_const_9.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core__cache_protocol_fn_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = self; var arg_99 any = gf__x__1661000127__1; var arg_100 any = A_arbace_java_io_A_const_16; var arg_101 any = t.F_G__1661000080; if linked_96 == nil { tmp1 = ifn_97.Invoke_O_O_O_O__O(arg_98, arg_99, arg_100, arg_101) } else { tmp1 = linked_96.(*aot_arbace_core.A_arbace_core__cache_protocol_fn_A).Invoke_O_O_O_O_O__O(root_95, arg_98, arg_99, arg_100, arg_101) }; return lang.IFn_Cast(tmp1).Invoke_O_O__O(gf__x__1661000127__1, gf__opts__1661000128__2) } }
//line :72:1
func A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_New() *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Ctor() {}
//line :72:1
func (t *A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A) Invoke_O_O_O__O(self, gf__x__1661000123__1, gf__opts__1661000124__2 any) any { var target_92 any = gf__x__1661000123__1; var tmp1 bool; var tmp2 bool; tmp2 = !(target_92 == nil); if tmp2 { tmp2 = lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_92) }; tmp1 = tmp2; if tmp1 { return lang.Reflector_InvokeInstanceMethod_O_String_O1__O(target_92, Lit_51, jrt.RefArrayOf(jrt.Object_class, gf__opts__1661000124__2)) } else { return A_arbace_java_io_IOFactory_A_Cast(target_92).Make_writer_O__O(gf__opts__1661000124__2) } }
















func A_arbace_java_io_reader_A_New() *A_arbace_java_io_reader_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_reader_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_java_io_reader_A) Ctor() {}
//line :89:1
func (t *A_arbace_java_io_reader_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {















	var target_104 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_104); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_104) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_104); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_105 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_106 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_105, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_107 lang.IFn; if linked_106 == nil { ifn_107 = lang.IFn_Cast(root_105) } else { ifn_107 = nil }; var arg_108 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_109 any = opts__1; if linked_106 == nil { tmp4 = ifn_107.Invoke_O_O__O(arg_108, arg_109) } else { tmp4 = linked_106.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_105, arg_108, arg_109) } } else { tmp4 = nil }; return tmp3.Make_reader_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_110 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_111 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_110, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_112 lang.IFn; if linked_111 == nil { ifn_112 = lang.IFn_Cast(root_110) } else { ifn_112 = nil }; var arg_113 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_114 any = opts__1; if linked_111 == nil { tmp6 = ifn_112.Invoke_O_O__O(arg_113, arg_114) } else { tmp6 = linked_111.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_110, arg_113, arg_114) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_104, tmp6)
	} }
func A_arbace_java_io_writer_A_New() *A_arbace_java_io_writer_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_writer_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_java_io_writer_A) Ctor() {}
//line :107:1
func (t *A_arbace_java_io_writer_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_115 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_115); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_115) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_115); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_116 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_117 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_116, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_118 lang.IFn; if linked_117 == nil { ifn_118 = lang.IFn_Cast(root_116) } else { ifn_118 = nil }; var arg_119 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_120 any = opts__1; if linked_117 == nil { tmp4 = ifn_118.Invoke_O_O__O(arg_119, arg_120) } else { tmp4 = linked_117.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_116, arg_119, arg_120) } } else { tmp4 = nil }; return tmp3.Make_writer_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_20.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_121 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_125 any = opts__1; if linked_122 == nil { tmp6 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { tmp6 = linked_122.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_115, tmp6)
	} }
func A_arbace_java_io_input_stream_A_New() *A_arbace_java_io_input_stream_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_input_stream_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_java_io_input_stream_A) Ctor() {}
//line :124:1
func (t *A_arbace_java_io_input_stream_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_126 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_126); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_126) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_126); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_127 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_127, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_129 lang.IFn; if linked_128 == nil { ifn_129 = lang.IFn_Cast(root_127) } else { ifn_129 = nil }; var arg_130 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_131 any = opts__1; if linked_128 == nil { tmp4 = ifn_129.Invoke_O_O__O(arg_130, arg_131) } else { tmp4 = linked_128.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_127, arg_130, arg_131) } } else { tmp4 = nil }; return tmp3.Make_input_stream_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_132 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_132, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_134 lang.IFn; if linked_133 == nil { ifn_134 = lang.IFn_Cast(root_132) } else { ifn_134 = nil }; var arg_135 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_136 any = opts__1; if linked_133 == nil { tmp6 = ifn_134.Invoke_O_O__O(arg_135, arg_136) } else { tmp6 = linked_133.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_132, arg_135, arg_136) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_126, tmp6)
	} }
func A_arbace_java_io_output_stream_A_New() *A_arbace_java_io_output_stream_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_output_stream_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_java_io_output_stream_A) Ctor() {}
//line :141:1
func (t *A_arbace_java_io_output_stream_A) DoInvoke_O_O_O__O(self, x__0, opts__1 any) any {














	var target_137 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_137); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_137) }; tmp1 = tmp2; if tmp1 { var tmp3 A_arbace_java_io_IOFactory_A = A_arbace_java_io_IOFactory_A_Cast(target_137); var tmp4 any; if jrt.J2g_Truth(opts__1) { var root_138 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_142 any = opts__1; if linked_139 == nil { tmp4 = ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { tmp4 = linked_139.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_138, arg_141, arg_142) } } else { tmp4 = nil }; return tmp3.Make_output_stream_O__O(tmp4) } else { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()); var tmp6 any; if jrt.J2g_Truth(opts__1) { var root_143 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_143, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_145 lang.IFn; if linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_147 any = opts__1; if linked_144 == nil { tmp6 = ifn_145.Invoke_O_O__O(arg_146, arg_147) } else { tmp6 = linked_144.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_143, arg_146, arg_147) } } else { tmp6 = nil }; return tmp5.Invoke_O_O__O(target_137, tmp6)
	} }
func A_arbace_java_io_append_QMARK__A_New() *A_arbace_java_io_append_QMARK__A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_append_QMARK__A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_java_io_append_QMARK__A) Ctor() {}
//line :158:1
func (t *A_arbace_java_io_append_QMARK__A) Invoke_O_O__O(self, opts__0 any) any {
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_java_io_A_const_23.Invoke_O__O(opts__0))).Ref()
}
func A_arbace_java_io_encoding_A_New() *A_arbace_java_io_encoding_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_encoding_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_java_io_encoding_A) Ctor() {}
//line :161:1
func (t *A_arbace_java_io_encoding_A) Invoke_O_O__O(self, opts__0 any) any { var or__1927000174__auto____2 any = A_arbace_java_io_A_const_24.Invoke_O__O(opts__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return Lit_3 } }

func A_arbace_java_io_buffer_size_A_New() *A_arbace_java_io_buffer_size_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_buffer_size_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_java_io_buffer_size_A) Ctor() {}
//line :164:1
func (t *A_arbace_java_io_buffer_size_A) Invoke_O_O__O(self, opts__0 any) any { var or__1927000174__auto____2 any = A_arbace_java_io_A_const_25.Invoke_O__O(opts__0); if
										jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_java_io_A_const_26 } }


func A_arbace_java_io_fn__1661000144_A_New() *A_arbace_java_io_fn__1661000144_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000144_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_java_io_fn__1661000144_A) Ctor() {}
//line :168:1
func (t *A_arbace_java_io_fn__1661000144_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var target_148 any; var target_149 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_149); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_149) }; tmp1 = tmp2; if tmp1 { target_148 = A_arbace_java_io_IOFactory_A_Cast(target_149).Make_input_stream_O__O(opts__1) } else { target_148 = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_149, opts__1) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_148); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_148) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_148).Make_reader_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()).Invoke_O_O__O(target_148, opts__1) } }
func A_arbace_java_io_fn__1661000146_A_New() *A_arbace_java_io_fn__1661000146_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000146_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_java_io_fn__1661000146_A) Ctor() {}
//line :169:1
func (t *A_arbace_java_io_fn__1661000146_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { var target_150 any; var target_151 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_151); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_151) }; tmp1 = tmp2; if tmp1 { target_150 = A_arbace_java_io_IOFactory_A_Cast(target_151).Make_output_stream_O__O(opts__1) } else { target_150 = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_151, opts__1) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_150); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_150) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_150).Make_writer_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_20.GetRawRoot__O()).Invoke_O_O__O(target_150, opts__1) } }
func A_arbace_java_io_fn__1661000148_A_New() *A_arbace_java_io_fn__1661000148_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000148_A{}; t.Ctor(); return t }
//line :170:1
func (t *A_arbace_java_io_fn__1661000148_A) Ctor() {}
//line :170:1
func (t *A_arbace_java_io_fn__1661000148_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_57), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0), nil))))) }


func A_arbace_java_io_fn__1661000150_A_New() *A_arbace_java_io_fn__1661000150_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_fn__1661000150_A{}; t.Ctor(); return t }
//line :173:1
func (t *A_arbace_java_io_fn__1661000150_A) Ctor() {}
//line :173:1
func (t *A_arbace_java_io_fn__1661000150_A) Invoke_O_O_O__O(self, x__0, opts__1 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_58), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__0), nil))))) }



func A_arbace_java_io_inputstream__GT_reader_A_New() *A_arbace_java_io_inputstream__GT_reader_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_inputstream__GT_reader_A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_java_io_inputstream__GT_reader_A) Ctor() {}
//line :177:1
func (t *A_arbace_java_io_inputstream__GT_reader_A) Invoke_O_O_O__O(self, is__0, opts__1 any) any {

	var target_160 any; var tmp1 jrt.InputStream_I = jrt.InputStream_Cast(is__0); var tmp2 any; var root_161 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_162 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_161, A_arbace_java_io_encoding_A_fn_class); var ifn_163 lang.IFn; if linked_162 == nil { ifn_163 = lang.IFn_Cast(root_161) } else { ifn_163 = nil }; var arg_164 any = opts__1; if linked_162 == nil { tmp2 = ifn_163.Invoke_O__O(arg_164) } else { tmp2 = linked_162.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_161, arg_164) }; target_160 = jrt.InputStreamReader_New_InputStream_String(tmp1, jrt.String_Cast(tmp2)); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_160); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_160) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_160).Make_reader_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()).Invoke_O_O__O(target_160, opts__1)
	} }
func A_arbace_java_io_outputstream__GT_writer_A_New() *A_arbace_java_io_outputstream__GT_writer_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_outputstream__GT_writer_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_java_io_outputstream__GT_writer_A) Ctor() {}
//line :181:1
func (t *A_arbace_java_io_outputstream__GT_writer_A) Invoke_O_O_O__O(self, os__0, opts__1 any) any {

	var target_165 any; var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(os__0); var tmp2 any; var root_166 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_167 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_166, A_arbace_java_io_encoding_A_fn_class); var ifn_168 lang.IFn; if linked_167 == nil { ifn_168 = lang.IFn_Cast(root_166) } else { ifn_168 = nil }; var arg_169 any = opts__1; if linked_167 == nil { tmp2 = ifn_168.Invoke_O__O(arg_169) } else { tmp2 = linked_167.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_166, arg_169) }; target_165 = jrt.OutputStreamWriter_New_OutputStream_String(tmp1, jrt.String_Cast(tmp2)); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_165); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_165) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_165).Make_writer_O__O(opts__1) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_20.GetRawRoot__O()).Invoke_O_O__O(target_165, opts__1)
	}
}


func A_arbace_java_io_eval1661000154_fn__1661000155_A_New() *A_arbace_java_io_eval1661000154_fn__1661000155_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000154_fn__1661000155_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Ctor() {}
//line :188:1
func (t *A_arbace_java_io_eval1661000154_fn__1661000155_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }





func A_arbace_java_io_eval1661000158_fn__1661000159_A_New() *A_arbace_java_io_eval1661000158_fn__1661000159_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000158_fn__1661000159_A{}; t.Ctor(); return t }
//line :194:1
func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Ctor() {}
//line :194:1
func (t *A_arbace_java_io_eval1661000158_fn__1661000159_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedInputStream_New_InputStream(jrt.InputStream_Cast(x__1)) }





func A_arbace_java_io_eval1661000162_fn__1661000163_A_New() *A_arbace_java_io_eval1661000162_fn__1661000163_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000162_fn__1661000163_A{}; t.Ctor(); return t }
//line :200:1
func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Ctor() {}
//line :200:1
func (t *A_arbace_java_io_eval1661000162_fn__1661000163_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedReader_New_Reader(jrt.Reader_Cast(x__1)) }




func A_arbace_java_io_eval1661000166_fn__1661000167_A_New() *A_arbace_java_io_eval1661000166_fn__1661000167_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000166_fn__1661000167_A{}; t.Ctor(); return t }
//line :205:1
func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Ctor() {}
//line :205:1
func (t *A_arbace_java_io_eval1661000166_fn__1661000167_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }




func A_arbace_java_io_eval1661000170_fn__1661000171_A_New() *A_arbace_java_io_eval1661000170_fn__1661000171_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000170_fn__1661000171_A{}; t.Ctor(); return t }
//line :210:1
func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Ctor() {}
//line :210:1
func (t *A_arbace_java_io_eval1661000170_fn__1661000171_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedWriter_New_Writer(jrt.Writer_Cast(x__1)) }




func A_arbace_java_io_eval1661000174_fn__1661000175_A_New() *A_arbace_java_io_eval1661000174_fn__1661000175_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000174_fn__1661000175_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Ctor() {}
//line :215:1
func (t *A_arbace_java_io_eval1661000174_fn__1661000175_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }




func A_arbace_java_io_eval1661000178_fn__1661000179_A_New() *A_arbace_java_io_eval1661000178_fn__1661000179_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000178_fn__1661000179_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Ctor() {}
//line :220:1
func (t *A_arbace_java_io_eval1661000178_fn__1661000179_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return jrt.BufferedOutputStream_New_OutputStream(jrt.OutputStream_Cast(x__1)) }





func A_arbace_java_io_eval1661000182_fn__1661000183_A_New() *A_arbace_java_io_eval1661000182_fn__1661000183_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000182_fn__1661000183_A{}; t.Ctor(); return t }
//line :226:1
func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Ctor() {}
//line :226:1
func (t *A_arbace_java_io_eval1661000182_fn__1661000183_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { return x__1 }





func A_arbace_java_io_eval1661000186_fn__1661000187_A_New() *A_arbace_java_io_eval1661000186_fn__1661000187_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000186_fn__1661000187_A{}; t.Ctor(); return t }
//line :232:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Ctor() {}
//line :232:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000187_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_170 any = jrt.FileInputStream_New_File(jrt.File_Cast(x__1)); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_170); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_170) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_170).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_170, opts__2) } }
func A_arbace_java_io_eval1661000186_fn__1661000189_A_New() *A_arbace_java_io_eval1661000186_fn__1661000189_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000186_fn__1661000189_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Ctor() {}
//line :233:1
func (t *A_arbace_java_io_eval1661000186_fn__1661000189_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_171 any; var tmp1 jrt.File_I = jrt.File_Cast(x__1); var tmp2 any; var root_172 any = A_arbace_java_io_A_const_29.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, A_arbace_java_io_append_QMARK__A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = opts__2; if linked_173 == nil { tmp2 = ifn_174.Invoke_O__O(arg_175) } else { tmp2 = linked_173.(*A_arbace_java_io_append_QMARK__A).Invoke_O_O__O(root_172, arg_175) }; target_171 = jrt.FileOutputStream_New_File_Z(tmp1, jrt.NN(jrt.Boolean_Cast(tmp2)).BooleanValue__Z()); var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_171); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_171) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_171).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_171, opts__2) } }




func A_arbace_java_io_eval1661000192_fn__1661000193_A_New() *A_arbace_java_io_eval1661000192_fn__1661000193_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000192_fn__1661000193_A{}; t.Ctor(); return t }
//line :238:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Ctor() {}
//line :238:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000193_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any {
	var target_176 any
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_38, jrt.NN(jrt.URL_Cast(x__1)).GetProtocol__String().Ref()) { var tmp1 any; var target_177 any = x__1; var tmp2 bool; var tmp3 bool
		tmp3 = A_arbace_java_io_Coercions_A_InstanceOf(target_177); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_177) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_Coercions_A_Cast(target_177).As_file__O() } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_177) }
//line :240:1
		target_176 = jrt.FileInputStream_New_File(jrt.File_Cast(tmp1)) } else {

			target_176 = jrt.NN(jrt.URL_Cast(x__1)).OpenStream__InputStream() }
//line :239:1
	var tmp4 bool; var tmp5 bool; tmp5 = A_arbace_java_io_IOFactory_A_InstanceOf(target_176); if tmp5 { tmp5 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_176) }; tmp4 = tmp5; if tmp4 { return A_arbace_java_io_IOFactory_A_Cast(target_176).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_176, opts__2)
	}
}

func A_arbace_java_io_eval1661000192_fn__1661000195_A_New() *A_arbace_java_io_eval1661000192_fn__1661000195_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000192_fn__1661000195_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Ctor() {}
//line :243:1
func (t *A_arbace_java_io_eval1661000192_fn__1661000195_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any {
	if lang.Util_Equiv_O_O__Z_NoInit(Lit_38, jrt.NN(jrt.URL_Cast(x__1)).GetProtocol__String().Ref()) {
		var target_178 any; var target_179 any = x__1; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_179); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_179) }; tmp1 = tmp2; if tmp1 { target_178 = A_arbace_java_io_Coercions_A_Cast(target_179).As_file__O() } else { target_178 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_179) }; var tmp3 bool; var tmp4 bool; tmp4 = A_arbace_java_io_IOFactory_A_InstanceOf(target_178); if tmp4 { tmp4 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_178) }; tmp3 = tmp4; if tmp3 { return A_arbace_java_io_IOFactory_A_Cast(target_178).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_178, opts__2) } } else {
//line :244:1
			panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_52, nil, Lit_53), jrt.RefArrayOf(jrt.Object_class, nil, x__1, nil)))))
		}
}




func A_arbace_java_io_eval1661000198_fn__1661000199_A_New() *A_arbace_java_io_eval1661000198_fn__1661000199_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000198_fn__1661000199_A{}; t.Ctor(); return t }
//line :251:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Ctor() {}
//line :251:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000199_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_180 any = jrt.NN(jrt.URI_Cast(x__1)).ToURL__URL().Ref(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_180); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_180) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_180).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_180, opts__2) } }
func A_arbace_java_io_eval1661000198_fn__1661000201_A_New() *A_arbace_java_io_eval1661000198_fn__1661000201_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000198_fn__1661000201_A{}; t.Ctor(); return t }
//line :252:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Ctor() {}
//line :252:1
func (t *A_arbace_java_io_eval1661000198_fn__1661000201_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_181 any = jrt.NN(jrt.URI_Cast(x__1)).ToURL__URL().Ref(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_181); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_181) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_181).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_181, opts__2) } }




func A_arbace_java_io_eval1661000204_fn__1661000205_A_New() *A_arbace_java_io_eval1661000204_fn__1661000205_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000204_fn__1661000205_A{}; t.Ctor(); return t }
//line :257:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Ctor() {}
//line :257:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000205_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var target_182 any = lang.RT_ToUrl_String__URL_NoInit(jrt.String_Cast(x__1)).Ref(); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_java_io_IOFactory_A_InstanceOf(target_182); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_182) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_182).Make_input_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_182, opts__2) } }
//line :257:1
	return nil }(); if tmp4 != nil { if jrt.MalformedURLException_InstanceOf(tmp4) { var e__5 *jrt.MalformedURLException = jrt.MalformedURLException_Cast(tmp4); var target_183 any = jrt.File_New_String(jrt.String_Cast(x__1)); var tmp5 bool; var tmp6 bool; _ = e__5



		tmp6 = A_arbace_java_io_IOFactory_A_InstanceOf(target_183); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_183) }; tmp5 = tmp6; if tmp5 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_183).Make_input_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_183, opts__2) } } else {
//line :257:1
			panic(tmp4) } }; return tmp1 }




func A_arbace_java_io_eval1661000204_fn__1661000207_A_New() *A_arbace_java_io_eval1661000204_fn__1661000207_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000204_fn__1661000207_A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Ctor() {}
//line :262:1
func (t *A_arbace_java_io_eval1661000204_fn__1661000207_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	{ var target_184 any = lang.RT_ToUrl_String__URL_NoInit(jrt.String_Cast(x__1)).Ref(); var tmp2 bool; var tmp3 bool; tmp3 = A_arbace_java_io_IOFactory_A_InstanceOf(target_184); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_184) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_184).Make_output_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_184, opts__2) } }
//line :262:1
	return nil }(); if tmp4 != nil { if jrt.MalformedURLException_InstanceOf(tmp4) { var err__5 *jrt.MalformedURLException = jrt.MalformedURLException_Cast(tmp4); var target_185 any = jrt.File_New_String(jrt.String_Cast(x__1)); var tmp5 bool; var tmp6 bool; _ = err__5



		tmp6 = A_arbace_java_io_IOFactory_A_InstanceOf(target_185); if tmp6 { tmp6 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_185) }; tmp5 = tmp6; if tmp5 { tmp1 = A_arbace_java_io_IOFactory_A_Cast(target_185).Make_output_stream_O__O(opts__2) } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_185, opts__2) } } else {
//line :262:1
			panic(tmp4) } }; return tmp1 }








func A_arbace_java_io_eval1661000210_fn__1661000211_A_New() *A_arbace_java_io_eval1661000210_fn__1661000211_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000210_fn__1661000211_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Ctor() {}
//line :271:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000211_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_186 any = jrt.Socket_Cast(x__1).GetInputStream__InputStream(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_186); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_186) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_186).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_186, opts__2) } }
func A_arbace_java_io_eval1661000210_fn__1661000213_A_New() *A_arbace_java_io_eval1661000210_fn__1661000213_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000210_fn__1661000213_A{}; t.Ctor(); return t }
//line :272:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Ctor() {}
//line :272:1
func (t *A_arbace_java_io_eval1661000210_fn__1661000213_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_187 any = jrt.Socket_Cast(x__1).GetOutputStream__OutputStream(); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_187); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_187) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_187).Make_output_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_22.GetRawRoot__O()).Invoke_O_O__O(target_187, opts__2) } }




func A_arbace_java_io_eval1661000216_fn__1661000217_A_New() *A_arbace_java_io_eval1661000216_fn__1661000217_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000216_fn__1661000217_A{}; t.Ctor(); return t }
//line :277:1
func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Ctor() {}
//line :277:1
func (t *A_arbace_java_io_eval1661000216_fn__1661000217_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_188 any = jrt.ByteArrayInputStream_New_B1(jrt.ByteArray_Cast(x__1)); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_188); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_188) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_188).Make_input_stream_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_21.GetRawRoot__O()).Invoke_O_O__O(target_188, opts__2) } }




func A_arbace_java_io_eval1661000220_fn__1661000221_A_New() *A_arbace_java_io_eval1661000220_fn__1661000221_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000220_fn__1661000221_A{}; t.Ctor(); return t }
//line :282:1
func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Ctor() {}
//line :282:1
func (t *A_arbace_java_io_eval1661000220_fn__1661000221_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { var target_189 any = jrt.CharArrayReader_New_C1(jrt.CharArray_Cast(x__1)); var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_IOFactory_A_InstanceOf(target_189); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_189) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_IOFactory_A_Cast(target_189).Make_reader_O__O(opts__2) } else { return lang.IFn_Cast(A_arbace_java_io_A_const_19.GetRawRoot__O()).Invoke_O_O__O(target_189, opts__2) } }








func A_arbace_java_io_eval1661000226_fn__1661000227_A_New() *A_arbace_java_io_eval1661000226_fn__1661000227_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000226_fn__1661000227_A{}; t.Ctor(); return t }
//line :291:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Ctor() {}
//line :291:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000227_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1), nil))))) }


func A_arbace_java_io_eval1661000226_fn__1661000229_A_New() *A_arbace_java_io_eval1661000226_fn__1661000229_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000226_fn__1661000229_A{}; t.Ctor(); return t }
//line :294:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Ctor() {}
//line :294:1
func (t *A_arbace_java_io_eval1661000226_fn__1661000229_A) Invoke_O_O_O__O(self, x__1, opts__2 any) any { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_54, nil, Lit_56), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_java_io_A_const_27.GetRawRoot__O()).Invoke_O__O(x__1), nil))))) }








func A_arbace_java_io_eval1661000232_fn__1661000233_A_New() *A_arbace_java_io_eval1661000232_fn__1661000233_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000232_fn__1661000233_A{}; t.Ctor(); return t }
//line :303:1
func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Ctor() {}
//line :303:1
func (t *A_arbace_java_io_eval1661000232_fn__1661000233_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var tmp1 any; var root_198 any = A_arbace_java_io_A_const_30.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_type_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = input__1; if linked_199 == nil { tmp1 = ifn_200.Invoke_O__O(arg_201) } else { tmp1 = linked_199.(*aot_arbace_core.A_arbace_core_type_A).Invoke_O_O__O(root_198, arg_201) }; var tmp2 any = tmp1; var tmp3 any; var root_202 any = A_arbace_java_io_A_const_30.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_type_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = output__2; if linked_203 == nil { tmp3 = ifn_204.Invoke_O__O(arg_205) } else { tmp3 = linked_203.(*aot_arbace_core.A_arbace_core_type_A).Invoke_O_O__O(root_202, arg_205) }; return lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3) }

func A_arbace_java_io_eval1661000236_fn__1661000237_A_New() *A_arbace_java_io_eval1661000236_fn__1661000237_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000236_fn__1661000237_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Ctor() {}
//line :305:1
func (t *A_arbace_java_io_eval1661000236_fn__1661000237_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_206 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_208 lang.IFn
																if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = jrt.Byte_TYPE.Ref(); var arg_210 any; var root_211 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, A_arbace_java_io_buffer_size_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = opts__3; if linked_212 == nil { arg_210 = ifn_213.Invoke_O__O(arg_214) } else { arg_210 = linked_212.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_211, arg_214) }; if linked_207 == nil { buffer__4 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { buffer__4 = linked_207.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }
//line :305:1
L1: for { var size__5 int32 = jrt.InputStream_Cast(input__1).Read_B1__I(jrt.ByteArray_Cast(buffer__4))



	if lang.Numbers_IsPos_J__Z_NoInit(int64(size__5)) {
		jrt.OutputStream_Cast(output__2).Write_B1_I_I__V(jrt.ByteArray_Cast(buffer__4), lang.RT_IntCast_J__I_NoInit(0), size__5)
		continue L1 } else {
//line :309:1
			return nil } } }; /*line :305:1*/panic("j2g: unreachable") }







func A_arbace_java_io_eval1661000240_fn__1661000241_A_New() *A_arbace_java_io_eval1661000240_fn__1661000241_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000240_fn__1661000241_A{}; t.Ctor(); return t }
//line :313:1
func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Ctor() {}
//line :313:1
func (t *A_arbace_java_io_eval1661000240_fn__1661000241_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_215 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_217 lang.IFn
																if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = jrt.Character_TYPE.Ref(); var arg_219 any; var root_220 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_java_io_buffer_size_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = opts__3; if linked_221 == nil { arg_219 = ifn_222.Invoke_O__O(arg_223) } else { arg_219 = linked_221.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_220, arg_223) }; if linked_216 == nil { buffer__4 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { buffer__4 = linked_216.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }
//line :313:1
	var in__5 any; var tmp1 jrt.InputStream_I = jrt.InputStream_Cast(input__1); var tmp2 any; var root_224 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, A_arbace_java_io_encoding_A_fn_class); var ifn_226 lang.IFn

	if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = opts__3; if linked_225 == nil { tmp2 = ifn_226.Invoke_O__O(arg_227) } else { tmp2 = linked_225.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_224, arg_227) }
//line :313:1
	in__5 = jrt.InputStreamReader_New_InputStream_String(tmp1, jrt.String_Cast(tmp2)); L1: for { var size__6 int32 = jrt.InputStreamReader_Cast(in__5).Read_C1_I_I__I(jrt.CharArray_Cast(buffer__4), lang.RT_IntCast_J__I_NoInit(0), lang.RT_Alength_C1__I_NoInit(jrt.CharArray_Cast(buffer__4)))




		if lang.Numbers_IsPos_J__Z_NoInit(int64(size__6)) {
			jrt.Writer_Cast(output__2).Write_C1_I_I__V(jrt.CharArray_Cast(buffer__4), lang.RT_IntCast_J__I_NoInit(0), size__6)
			continue L1 } else {
//line :318:1
				return nil } } }; /*line :313:1*/panic("j2g: unreachable") }








func A_arbace_java_io_eval1661000244_fn__1661000245_A_New() *A_arbace_java_io_eval1661000244_fn__1661000245_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000244_fn__1661000245_A{}; t.Ctor(); return t }
//line :322:1
func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Ctor() {}
//line :322:1
func (t *A_arbace_java_io_eval1661000244_fn__1661000245_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var out__4 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(input__1, out__4, opts__3)
//line :322:1
	return nil }();
	jrt.FileOutputStream_Cast(out__4).Close__V(); if /*line :322:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000248_fn__1661000249_A_New() *A_arbace_java_io_eval1661000248_fn__1661000249_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000248_fn__1661000249_A{}; t.Ctor(); return t }
//line :326:1
func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Ctor() {}
//line :326:1
func (t *A_arbace_java_io_eval1661000248_fn__1661000249_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_228 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_230 lang.IFn
																if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = jrt.Character_TYPE.Ref(); var arg_232 any; var root_233 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, A_arbace_java_io_buffer_size_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = opts__3; if linked_234 == nil { arg_232 = ifn_235.Invoke_O__O(arg_236) } else { arg_232 = linked_234.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_233, arg_236) }; if linked_229 == nil { buffer__4 = ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { buffer__4 = linked_229.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_228, arg_231, arg_232) }
//line :326:1
	var out__5 any; var tmp1 jrt.OutputStream_I = jrt.OutputStream_Cast(output__2); var tmp2 any; var root_237 any = A_arbace_java_io_A_const_28.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, A_arbace_java_io_encoding_A_fn_class); var ifn_239 lang.IFn

	if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = opts__3; if linked_238 == nil { tmp2 = ifn_239.Invoke_O__O(arg_240) } else { tmp2 = linked_238.(*A_arbace_java_io_encoding_A).Invoke_O_O__O(root_237, arg_240) }
//line :326:1
	out__5 = jrt.OutputStreamWriter_New_OutputStream_String(tmp1, jrt.String_Cast(tmp2)); L1: for { var size__6 int32 = jrt.Reader_Cast(input__1).Read_C1__I(jrt.CharArray_Cast(buffer__4))




		if lang.Numbers_IsPos_J__Z_NoInit(int64(size__6)) {

			jrt.OutputStreamWriter_Cast(out__5).Write_C1_I_I__V(jrt.CharArray_Cast(buffer__4), lang.RT_IntCast_J__I_NoInit(0), size__6)
			continue L1 } else {
				jrt.OutputStreamWriter_Cast(out__5).Flush__V(); return nil } } }; /*line :326:1*/panic("j2g: unreachable") }










func A_arbace_java_io_eval1661000252_fn__1661000253_A_New() *A_arbace_java_io_eval1661000252_fn__1661000253_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000252_fn__1661000253_A{}; t.Ctor(); return t }
//line :337:1
func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Ctor() {}
//line :337:1
func (t *A_arbace_java_io_eval1661000252_fn__1661000253_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { { var buffer__4 any; var root_241 any = A_arbace_java_io_A_const_31.GetRawRoot__O(); var linked_242 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_241, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_243 lang.IFn
																if linked_242 == nil { ifn_243 = lang.IFn_Cast(root_241) } else { ifn_243 = nil }; var arg_244 any = jrt.Character_TYPE.Ref(); var arg_245 any; var root_246 any = A_arbace_java_io_A_const_32.GetRawRoot__O(); var linked_247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_246, A_arbace_java_io_buffer_size_A_fn_class); var ifn_248 lang.IFn; if linked_247 == nil { ifn_248 = lang.IFn_Cast(root_246) } else { ifn_248 = nil }; var arg_249 any = opts__3; if linked_247 == nil { arg_245 = ifn_248.Invoke_O__O(arg_249) } else { arg_245 = linked_247.(*A_arbace_java_io_buffer_size_A).Invoke_O_O__O(root_246, arg_249) }; if linked_242 == nil { buffer__4 = ifn_243.Invoke_O_O__O(arg_244, arg_245) } else { buffer__4 = linked_242.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_241, arg_244, arg_245) }
//line :337:1
L1: for { var size__5 int32 = jrt.Reader_Cast(input__1).Read_C1__I(jrt.CharArray_Cast(buffer__4))



	if lang.Numbers_IsPos_J__Z_NoInit(int64(size__5)) {
		jrt.Writer_Cast(output__2).Write_C1_I_I__V(jrt.CharArray_Cast(buffer__4), lang.RT_IntCast_J__I_NoInit(0), size__5)
		continue L1 } else {
//line :341:1
			return nil } } }; /*line :337:1*/panic("j2g: unreachable") }







func A_arbace_java_io_eval1661000256_fn__1661000257_A_New() *A_arbace_java_io_eval1661000256_fn__1661000257_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000256_fn__1661000257_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Ctor() {}
//line :345:1
func (t *A_arbace_java_io_eval1661000256_fn__1661000257_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var out__4 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(input__1, out__4, opts__3)
//line :345:1
	return nil }();
	jrt.FileOutputStream_Cast(out__4).Close__V(); if /*line :345:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000260_fn__1661000261_A_New() *A_arbace_java_io_eval1661000260_fn__1661000261_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000260_fn__1661000261_A{}; t.Ctor(); return t }
//line :349:1
func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Ctor() {}
//line :349:1
func (t *A_arbace_java_io_eval1661000260_fn__1661000261_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(in__4, output__2, opts__3)
//line :349:1
	return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :349:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000264_fn__1661000265_A_New() *A_arbace_java_io_eval1661000264_fn__1661000265_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000264_fn__1661000265_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Ctor() {}
//line :353:1
func (t *A_arbace_java_io_eval1661000264_fn__1661000265_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

	tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(in__4, output__2, opts__3)
//line :353:1
	return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :353:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }



func A_arbace_java_io_eval1661000268_fn__1661000269_A_New() *A_arbace_java_io_eval1661000268_fn__1661000269_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000268_fn__1661000269_A{}; t.Ctor(); return t }
//line :357:1
func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Ctor() {}
//line :357:1
func (t *A_arbace_java_io_eval1661000268_fn__1661000269_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any { var in__4 any = jrt.FileInputStream_New_File(jrt.File_Cast(input__1)); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__7 any = jrt.FileOutputStream_New_File(jrt.File_Cast(output__2)); tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	jrt.Long_ValueOf_J__Long_NoInit(jrt.InputStream_Cast(in__4).TransferTo_OutputStream__J(jrt.OutputStream_Cast(out__7)))
//line :357:1
	tmp1 = nil; return nil }()
	jrt.FileOutputStream_Cast(out__7).Close__V()
//line :357:1
	if tmp2 != nil { panic(tmp2) } }; return nil }();
	jrt.FileInputStream_Cast(in__4).Close__V(); if /*line :357:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }





func A_arbace_java_io_eval1661000272_fn__1661000273_A_New() *A_arbace_java_io_eval1661000272_fn__1661000273_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000272_fn__1661000273_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Ctor() {}
//line :363:1
func (t *A_arbace_java_io_eval1661000272_fn__1661000273_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000276_fn__1661000277_A_New() *A_arbace_java_io_eval1661000276_fn__1661000277_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000276_fn__1661000277_A{}; t.Ctor(); return t }
//line :366:1
func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Ctor() {}
//line :366:1
func (t *A_arbace_java_io_eval1661000276_fn__1661000277_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000280_fn__1661000281_A_New() *A_arbace_java_io_eval1661000280_fn__1661000281_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000280_fn__1661000281_A{}; t.Ctor(); return t }
//line :369:1
func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Ctor() {}
//line :369:1
func (t *A_arbace_java_io_eval1661000280_fn__1661000281_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.StringReader_New_String(jrt.String_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000284_fn__1661000285_A_New() *A_arbace_java_io_eval1661000284_fn__1661000285_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000284_fn__1661000285_A{}; t.Ctor(); return t }
//line :372:1
func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Ctor() {}
//line :372:1
func (t *A_arbace_java_io_eval1661000284_fn__1661000285_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.CharArray_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000288_fn__1661000289_A_New() *A_arbace_java_io_eval1661000288_fn__1661000289_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000288_fn__1661000289_A{}; t.Ctor(); return t }
//line :375:1
func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Ctor() {}
//line :375:1
func (t *A_arbace_java_io_eval1661000288_fn__1661000289_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.CharArray_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000292_fn__1661000293_A_New() *A_arbace_java_io_eval1661000292_fn__1661000293_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000292_fn__1661000293_A{}; t.Ctor(); return t }
//line :378:1
func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Ctor() {}
//line :378:1
func (t *A_arbace_java_io_eval1661000292_fn__1661000293_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.CharArrayReader_New_C1(jrt.CharArray_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000296_fn__1661000297_A_New() *A_arbace_java_io_eval1661000296_fn__1661000297_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000296_fn__1661000297_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Ctor() {}
//line :381:1
func (t *A_arbace_java_io_eval1661000296_fn__1661000297_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.ByteArray_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000300_fn__1661000301_A_New() *A_arbace_java_io_eval1661000300_fn__1661000301_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000300_fn__1661000301_A{}; t.Ctor(); return t }
//line :384:1
func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Ctor() {}
//line :384:1
func (t *A_arbace_java_io_eval1661000300_fn__1661000301_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.ByteArray_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_eval1661000304_fn__1661000305_A_New() *A_arbace_java_io_eval1661000304_fn__1661000305_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_eval1661000304_fn__1661000305_A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Ctor() {}
//line :387:1
func (t *A_arbace_java_io_eval1661000304_fn__1661000305_A) Invoke_O_O_O_O__O(self, input__1, output__2, opts__3 any) any {
	return lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(jrt.ByteArrayInputStream_New_B1(jrt.ByteArray_Cast(input__1)), output__2, opts__3)
}
func A_arbace_java_io_copy_A_New() *A_arbace_java_io_copy_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_copy_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_java_io_copy_A) Ctor() {}
//line :390:1
func (t *A_arbace_java_io_copy_A) DoInvoke_O_O_O_O__O(self, input__0, output__1, opts__2 any) any {














	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io_A_const_33.GetRawRoot__O()); var tmp2 any; if jrt.J2g_Truth(opts__2) { var root_250 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_250, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_252 lang.IFn; if linked_251 == nil { ifn_252 = lang.IFn_Cast(root_250) } else { ifn_252 = nil }; var arg_253 any = A_arbace_java_io_A_const_18.GetRawRoot__O(); var arg_254 any = opts__2; if linked_251 == nil { tmp2 = ifn_252.Invoke_O_O__O(arg_253, arg_254) } else { tmp2 = linked_251.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_250, arg_253, arg_254) } } else { tmp2 = nil }; return tmp1.Invoke_O_O_O__O(input__0, output__1, tmp2)
}
func A_arbace_java_io_as_relative_path_A_New() *A_arbace_java_io_as_relative_path_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_as_relative_path_A{}; t.Ctor(); return t }
//line :407:1
func (t *A_arbace_java_io_as_relative_path_A) Ctor() {}
//line :407:1
func (t *A_arbace_java_io_as_relative_path_A) Invoke_O_O__O(self, x__0 any) any { var f__2 any; var target_255 any = x__0; var tmp1 bool; var tmp2 bool; tmp2 =




	A_arbace_java_io_Coercions_A_InstanceOf(target_255); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_255) }; tmp1 = tmp2; if tmp1 { f__2 = A_arbace_java_io_Coercions_A_Cast(target_255).As_file__O() } else { f__2 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_255) }; if
	jrt.File_Cast(f__2).IsAbsolute__Z() { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, f__2, nil))))) } else {

		return jrt.File_Cast(f__2).GetPath__String().Ref() } }

func A_arbace_java_io_file_A_New() *A_arbace_java_io_file_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_file_A{}; t.Ctor(); return t }
//line :417:1
func (t *A_arbace_java_io_file_A) Ctor() {}
//line :417:1
func (t *A_arbace_java_io_file_A) DoInvoke_O_O_O_O__O(self, parent__0, child__1, more__2 any) any {









	var root_256 any = A_arbace_java_io_A_const_34.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var arg_260 any; var root_262 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var linked_263 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_262, A_arbace_java_io_file_A_fn_class); var ifn_264 lang.IFn; if linked_263 == nil { ifn_264 = lang.IFn_Cast(root_262) } else { ifn_264 = nil }; var arg_265 any = parent__0; var arg_266 any = child__1; if linked_263 == nil { arg_260 = ifn_264.Invoke_O_O__O(arg_265, arg_266) } else { arg_260 = linked_263.(*A_arbace_java_io_file_A).Invoke_O_O_O__O(root_262, arg_265, arg_266) }; var arg_261 any = more__2; if linked_257 == nil { return ifn_258.Invoke_O_O_O__O(arg_259, arg_260, arg_261) } else { return linked_257.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_256, arg_259, arg_260, arg_261) } }
//line :417:1
func (t *A_arbace_java_io_file_A) Invoke_O_O_O__O(self, parent__0, child__1 any) any { var tmp1 any; var target_267 any = parent__0; var tmp2 bool; var tmp3 bool; tmp3 =







	A_arbace_java_io_Coercions_A_InstanceOf(target_267); if tmp3 { tmp3 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_267) }; tmp2 = tmp3; if tmp2 { tmp1 = A_arbace_java_io_Coercions_A_Cast(target_267).As_file__O() } else { tmp1 = lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_267) }; var tmp4 jrt.File_I = /*line :417:1*/jrt.File_Cast(tmp1); var tmp5 any; var root_268 any = A_arbace_java_io_A_const_36.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, A_arbace_java_io_as_relative_path_A_fn_class); var ifn_270 lang.IFn; if







	linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = child__1; if linked_269 == nil { tmp5 = ifn_270.Invoke_O__O(arg_271) } else { tmp5 = linked_269.(*A_arbace_java_io_as_relative_path_A).Invoke_O_O__O(root_268, arg_271) }; return /*line :417:1*/ jrt.File_New_File_String(tmp4, jrt.String_Cast(tmp5)) }
//line :417:1
func (t *A_arbace_java_io_file_A) Invoke_O_O__O(self, arg__0 any) any {





	var target_272 any = arg__0; var tmp1 bool; var tmp2 bool; tmp2 = A_arbace_java_io_Coercions_A_InstanceOf(target_272); if tmp2 { tmp2 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_272) }; tmp1 = tmp2; if tmp1 { return A_arbace_java_io_Coercions_A_Cast(target_272).As_file__O() } else { return lang.IFn_Cast(A_arbace_java_io_A_const_14.GetRawRoot__O()).Invoke_O__O(target_272)
	}
}



func A_arbace_java_io_delete_file_A_New() *A_arbace_java_io_delete_file_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_delete_file_A{}; t.Ctor(); return t }
//line :429:1
func (t *A_arbace_java_io_delete_file_A) Ctor() {}
//line :429:1
func (t *A_arbace_java_io_delete_file_A) DoInvoke_O_O_O__O(self, f__0, p__1661000311__1 any) any { var vec__1661000312__3 any = p__1661000311__1; var silently__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1661000312__3, lang.RT_IntCast_J__I_NoInit(0), nil); var or__1927000174__auto____5 bool; var tmp1 any; var root_273 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, A_arbace_java_io_file_A_fn_class); var ifn_275 lang.IFn; if



	linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = f__0; if linked_274 == nil { tmp1 = ifn_275.Invoke_O__O(arg_276) } else { tmp1 = linked_274.(*A_arbace_java_io_file_A).Invoke_O_O__O(root_273, arg_276) }; or__1927000174__auto____5 = jrt.File_Cast(tmp1).Delete__Z(); if or__1927000174__auto____5 { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____5).Ref() } else { var or__1927000174__auto____6 any = silently__4; if jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { panic(jrt.Thrown(jrt.IOException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, nil, f__0))))) } } }



func A_arbace_java_io_make_parents_A_New() *A_arbace_java_io_make_parents_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_make_parents_A{}; t.Ctor(); return t }
//line :437:1
func (t *A_arbace_java_io_make_parents_A) Ctor() {}
//line :437:1
func (t *A_arbace_java_io_make_parents_A) DoInvoke_O_O_O__O(self, f__0, more__1 any) any { var temp__1927000414__auto____3 any; var tmp1 any; var root_277 any = A_arbace_java_io_A_const_17.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_279 lang.IFn; if




	linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = A_arbace_java_io_A_const_35.GetRawRoot__O(); var arg_281 any = f__0; var arg_282 any = more__1; if linked_278 == nil { tmp1 = ifn_279.Invoke_O_O_O__O(arg_280, arg_281, arg_282) } else { tmp1 = linked_278.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_277, arg_280, arg_281, arg_282) }; temp__1927000414__auto____3 = jrt.File_Cast(tmp1).GetParentFile__File(); if jrt.J2g_Truth(temp__1927000414__auto____3) { var parent__4 any = temp__1927000414__auto____3
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(parent__4).Mkdirs__Z()).Ref() } else {
//line :442:1
			return nil } }


func A_arbace_java_io_resource_A_New() *A_arbace_java_io_resource_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_resource_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_java_io_resource_A) Ctor() {}
//line :445:1
func (t *A_arbace_java_io_resource_A) Invoke_O_O_O__O(self, n__0, loader__1 any) any {




	var tmp1 *jrt.Class = A_arbace_java_io_A_const_37; return lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(loader__1, tmp1, Lit_59, jrt.RefArrayOf(jrt.Object_class, n__0)) }
//line :445:1
func (t *A_arbace_java_io_resource_A) Invoke_O_O__O(self, n__0 any) any {



	var root_283 any = A_arbace_java_io_A_const_38.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, A_arbace_java_io_resource_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = n__0; var tmp1 any = jrt.Thread_CurrentThread__Thread(); var tmp2 *jrt.Class = A_arbace_java_io_A_const_39; var arg_287 any = lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_60, jrt.RefArrayOf(jrt.Object_class)); if linked_284 == nil { return ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { return linked_284.(*A_arbace_java_io_resource_A).Invoke_O_O_O__O(root_283, arg_286, arg_287)
	}
}
































































































































type A_arbace_java_io_A struct{ jrt.Object }

var A_arbace_java_io_A_const_pool *jrt.RefArray

var A_arbace_java_io_A_const_0 *lang.Var

var A_arbace_java_io_A_const_1 any

var A_arbace_java_io_A_const_2 *lang.Var

var A_arbace_java_io_A_const_3 any

var A_arbace_java_io_A_const_4 *lang.Var

var A_arbace_java_io_A_const_5 *lang.Var

var A_arbace_java_io_A_const_6 *lang.Var

var A_arbace_java_io_A_const_7 *lang.Var

var A_arbace_java_io_A_const_8 any

var A_arbace_java_io_A_const_9 *lang.Var

var A_arbace_java_io_A_const_10 *jrt.Class

var A_arbace_java_io_A_const_11 *lang.Var

var A_arbace_java_io_A_const_12 *lang.Var

var A_arbace_java_io_A_const_13 any

var A_arbace_java_io_A_const_14 *lang.Var

var A_arbace_java_io_A_const_15 *lang.Var

var A_arbace_java_io_A_const_16 *jrt.Class

var A_arbace_java_io_A_const_17 *lang.Var

var A_arbace_java_io_A_const_18 *lang.Var

var A_arbace_java_io_A_const_19 *lang.Var

var A_arbace_java_io_A_const_20 *lang.Var

var A_arbace_java_io_A_const_21 *lang.Var

var A_arbace_java_io_A_const_22 *lang.Var

var A_arbace_java_io_A_const_23 *lang.Keyword

var A_arbace_java_io_A_const_24 *lang.Keyword

var A_arbace_java_io_A_const_25 *lang.Keyword

var A_arbace_java_io_A_const_26 any

var A_arbace_java_io_A_const_27 *lang.Var

var A_arbace_java_io_A_const_28 *lang.Var

var A_arbace_java_io_A_const_29 *lang.Var

var A_arbace_java_io_A_const_30 *lang.Var

var A_arbace_java_io_A_const_31 *lang.Var

var A_arbace_java_io_A_const_32 *lang.Var

var A_arbace_java_io_A_const_33 *lang.Var

var A_arbace_java_io_A_const_34 *lang.Var

var A_arbace_java_io_A_const_35 *lang.Var

var A_arbace_java_io_A_const_36 *lang.Var

var A_arbace_java_io_A_const_37 *jrt.Class

var A_arbace_java_io_A_const_38 *lang.Var

var A_arbace_java_io_A_const_39 *jrt.Class

var A_arbace_java_io_A_init jrt.ClassInit

func A_arbace_java_io_A_Init() { if !A_arbace_java_io_A_init.Done() { A_arbace_java_io_A_init.Run(A_arbace_java_io_A_clinit) } }

func A_arbace_java_io_A_clinit() { A_arbace_java_io_A_clinit_p0(); A_arbace_java_io_A_clinit_p1(); A_arbace_java_io_A_clinit_p2(); A_arbace_java_io_A_clinit_p3() }

func A_arbace_java_io_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_io_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 47); A_arbace_java_io_A_const_0 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[7]); A_arbace_java_io_A_const_1 = A_arbace_java_io_A_const_pool.A[8]; A_arbace_java_io_A_const_2 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[9]); A_arbace_java_io_A_const_3 = A_arbace_java_io_A_const_pool.A[10]; A_arbace_java_io_A_const_4 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[11]); A_arbace_java_io_A_const_5 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[12]); A_arbace_java_io_A_const_6 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[13]); A_arbace_java_io_A_const_7 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[14]); A_arbace_java_io_A_const_8 = A_arbace_java_io_A_const_pool.A[15]; A_arbace_java_io_A_const_9 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[16]); A_arbace_java_io_A_const_10 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[17]); A_arbace_java_io_A_const_11 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[18]) }

func A_arbace_java_io_A_clinit_p1() { A_arbace_java_io_A_const_12 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[19]); A_arbace_java_io_A_const_13 = A_arbace_java_io_A_const_pool.A[20]; A_arbace_java_io_A_const_14 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[21]); A_arbace_java_io_A_const_15 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[22]); A_arbace_java_io_A_const_16 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[23]); A_arbace_java_io_A_const_17 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[24]); A_arbace_java_io_A_const_18 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[25]); A_arbace_java_io_A_const_19 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[26]); A_arbace_java_io_A_const_20 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[27]); A_arbace_java_io_A_const_21 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[28]); A_arbace_java_io_A_const_22 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[29]); A_arbace_java_io_A_const_23 = lang.Keyword_Cast(A_arbace_java_io_A_const_pool.A[30]) }

func A_arbace_java_io_A_clinit_p2() { A_arbace_java_io_A_const_24 = lang.Keyword_Cast(A_arbace_java_io_A_const_pool.A[31]); A_arbace_java_io_A_const_25 = lang.Keyword_Cast(A_arbace_java_io_A_const_pool.A[32]); A_arbace_java_io_A_const_26 = A_arbace_java_io_A_const_pool.A[33]; A_arbace_java_io_A_const_27 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[34]); A_arbace_java_io_A_const_28 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[35]); A_arbace_java_io_A_const_29 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[36]); A_arbace_java_io_A_const_30 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[37]); A_arbace_java_io_A_const_31 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[38]); A_arbace_java_io_A_const_32 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[39]); A_arbace_java_io_A_const_33 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[40]); A_arbace_java_io_A_const_34 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[41]); A_arbace_java_io_A_const_35 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[42]) }

func A_arbace_java_io_A_clinit_p3() { A_arbace_java_io_A_const_36 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[43]); A_arbace_java_io_A_const_37 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[44]); A_arbace_java_io_A_const_38 = lang.Var_Cast(A_arbace_java_io_A_const_pool.A[45]); A_arbace_java_io_A_const_39 = jrt.Class_Cast(A_arbace_java_io_A_const_pool.A[46]) }

func A_arbace_java_io_A_New() *A_arbace_java_io_A { A_arbace_java_io_A_Init(); t := &A_arbace_java_io_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_A) Ctor() {}

func (t *A_arbace_java_io_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_A_class }

func (t *A_arbace_java_io_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_A); return ok }

func A_arbace_java_io_A_Cast(x any) *A_arbace_java_io_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_A_class)) }; return v }



type A_arbace_java_io_append_QMARK__A struct{ j2g_header uint64 }

var A_arbace_java_io_append_QMARK__A_fn_class *jrt.Class



type A_arbace_java_io_as_relative_path_A struct{ j2g_header uint64 }

var A_arbace_java_io_as_relative_path_A_fn_class *jrt.Class



type A_arbace_java_io_buffer_size_A struct{ j2g_header uint64 }

var A_arbace_java_io_buffer_size_A_fn_class *jrt.Class



type A_arbace_java_io_copy_A struct{ j2g_header uint64 }

var A_arbace_java_io_copy_A_fn_class *jrt.Class



type A_arbace_java_io_delete_file_A struct{ j2g_header uint64 }

var A_arbace_java_io_delete_file_A_fn_class *jrt.Class



type A_arbace_java_io_encoding_A struct{ j2g_header uint64 }

var A_arbace_java_io_encoding_A_fn_class *jrt.Class



type A_arbace_java_io_escaped_utf8_urlstring__GT_str_A struct{ j2g_header uint64 }

var A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000004_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000004_A_New() *A_arbace_java_io_eval1661000004_A { t := &A_arbace_java_io_eval1661000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000004_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000004_A_class }

func (t *A_arbace_java_io_eval1661000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000004_A); return ok }

func A_arbace_java_io_eval1661000004_A_Cast(x any) *A_arbace_java_io_eval1661000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000004_A_class)) }; return v }



type A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000008_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000008_A_New() *A_arbace_java_io_eval1661000008_A { t := &A_arbace_java_io_eval1661000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000008_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000008_A_class }

func (t *A_arbace_java_io_eval1661000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000008_A); return ok }

func A_arbace_java_io_eval1661000008_A_Cast(x any) *A_arbace_java_io_eval1661000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000008_A_class)) }; return v }



type A_arbace_java_io_eval1661000008_fn__1661000009_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000024_A_New() *A_arbace_java_io_eval1661000024_A { t := &A_arbace_java_io_eval1661000024_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000024_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000024_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000024_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000024_A_class }

func (t *A_arbace_java_io_eval1661000024_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000024_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000024_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000024_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000024_A); return ok }

func A_arbace_java_io_eval1661000024_A_Cast(x any) *A_arbace_java_io_eval1661000024_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000024_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000024_A_class)) }; return v }



type A_arbace_java_io_eval1661000024_fn__1661000025_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A struct{ j2g_header uint64; F_G__1661000015 any }

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000033_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A struct{ j2g_header uint64; F_G__1661000017 any }

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000047_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000047_A_New() *A_arbace_java_io_eval1661000047_A { t := &A_arbace_java_io_eval1661000047_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000047_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000047_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000047_A_class }

func (t *A_arbace_java_io_eval1661000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000047_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000047_A); return ok }

func A_arbace_java_io_eval1661000047_A_Cast(x any) *A_arbace_java_io_eval1661000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000047_A_class)) }; return v }



type A_arbace_java_io_eval1661000047_fn__1661000048_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000047_fn__1661000050_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000053_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000053_A_New() *A_arbace_java_io_eval1661000053_A { t := &A_arbace_java_io_eval1661000053_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000053_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000053_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000053_A_class }

func (t *A_arbace_java_io_eval1661000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000053_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000053_A); return ok }

func A_arbace_java_io_eval1661000053_A_Cast(x any) *A_arbace_java_io_eval1661000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000053_A_class)) }; return v }



type A_arbace_java_io_eval1661000053_fn__1661000054_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000053_fn__1661000056_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000059_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000059_A_New() *A_arbace_java_io_eval1661000059_A { t := &A_arbace_java_io_eval1661000059_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000059_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000059_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000059_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000059_A_class }

func (t *A_arbace_java_io_eval1661000059_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000059_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000059_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000059_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000059_A); return ok }

func A_arbace_java_io_eval1661000059_A_Cast(x any) *A_arbace_java_io_eval1661000059_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000059_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000059_A_class)) }; return v }



type A_arbace_java_io_eval1661000059_fn__1661000060_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000059_fn__1661000062_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000065_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000065_A_New() *A_arbace_java_io_eval1661000065_A { t := &A_arbace_java_io_eval1661000065_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000065_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000065_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000065_A_class }

func (t *A_arbace_java_io_eval1661000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000065_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000065_A); return ok }

func A_arbace_java_io_eval1661000065_A_Cast(x any) *A_arbace_java_io_eval1661000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000065_A_class)) }; return v }



type A_arbace_java_io_eval1661000065_fn__1661000066_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000065_fn__1661000068_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000071_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000071_A_New() *A_arbace_java_io_eval1661000071_A { t := &A_arbace_java_io_eval1661000071_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000071_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000071_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000071_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000071_A_class }

func (t *A_arbace_java_io_eval1661000071_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000071_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000071_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000071_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000071_A); return ok }

func A_arbace_java_io_eval1661000071_A_Cast(x any) *A_arbace_java_io_eval1661000071_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000071_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000071_A_class)) }; return v }



type A_arbace_java_io_eval1661000071_fn__1661000072_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000071_fn__1661000074_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000091_A_New() *A_arbace_java_io_eval1661000091_A { t := &A_arbace_java_io_eval1661000091_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000091_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000091_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000091_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000091_A_class }

func (t *A_arbace_java_io_eval1661000091_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000091_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000091_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000091_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000091_A); return ok }

func A_arbace_java_io_eval1661000091_A_Cast(x any) *A_arbace_java_io_eval1661000091_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000091_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000091_A_class)) }; return v }



type A_arbace_java_io_eval1661000091_fn__1661000092_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A struct{ j2g_header uint64; F_G__1661000082 any }

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000102_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A struct{ j2g_header uint64; F_G__1661000084 any }

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000112_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A struct{ j2g_header uint64; F_G__1661000078 any }

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000122_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A struct{ j2g_header uint64; F_G__1661000080 any }

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000154_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000154_A_New() *A_arbace_java_io_eval1661000154_A { t := &A_arbace_java_io_eval1661000154_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000154_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000154_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000154_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000154_A_class }

func (t *A_arbace_java_io_eval1661000154_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000154_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000154_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000154_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000154_A); return ok }

func A_arbace_java_io_eval1661000154_A_Cast(x any) *A_arbace_java_io_eval1661000154_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000154_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000154_A_class)) }; return v }



type A_arbace_java_io_eval1661000154_fn__1661000155_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000158_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000158_A_New() *A_arbace_java_io_eval1661000158_A { t := &A_arbace_java_io_eval1661000158_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000158_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000158_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000158_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000158_A_class }

func (t *A_arbace_java_io_eval1661000158_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000158_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000158_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000158_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000158_A); return ok }

func A_arbace_java_io_eval1661000158_A_Cast(x any) *A_arbace_java_io_eval1661000158_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000158_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000158_A_class)) }; return v }



type A_arbace_java_io_eval1661000158_fn__1661000159_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000162_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000162_A_New() *A_arbace_java_io_eval1661000162_A { t := &A_arbace_java_io_eval1661000162_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000162_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000162_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000162_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000162_A_class }

func (t *A_arbace_java_io_eval1661000162_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000162_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000162_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000162_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000162_A); return ok }

func A_arbace_java_io_eval1661000162_A_Cast(x any) *A_arbace_java_io_eval1661000162_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000162_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000162_A_class)) }; return v }



type A_arbace_java_io_eval1661000162_fn__1661000163_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000166_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000166_A_New() *A_arbace_java_io_eval1661000166_A { t := &A_arbace_java_io_eval1661000166_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000166_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000166_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000166_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000166_A_class }

func (t *A_arbace_java_io_eval1661000166_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000166_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000166_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000166_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000166_A); return ok }

func A_arbace_java_io_eval1661000166_A_Cast(x any) *A_arbace_java_io_eval1661000166_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000166_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000166_A_class)) }; return v }



type A_arbace_java_io_eval1661000166_fn__1661000167_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000170_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000170_A_New() *A_arbace_java_io_eval1661000170_A { t := &A_arbace_java_io_eval1661000170_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000170_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000170_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000170_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000170_A_class }

func (t *A_arbace_java_io_eval1661000170_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000170_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000170_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000170_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000170_A); return ok }

func A_arbace_java_io_eval1661000170_A_Cast(x any) *A_arbace_java_io_eval1661000170_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000170_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000170_A_class)) }; return v }



type A_arbace_java_io_eval1661000170_fn__1661000171_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000174_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000174_A_New() *A_arbace_java_io_eval1661000174_A { t := &A_arbace_java_io_eval1661000174_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000174_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000174_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000174_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000174_A_class }

func (t *A_arbace_java_io_eval1661000174_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000174_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000174_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000174_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000174_A); return ok }

func A_arbace_java_io_eval1661000174_A_Cast(x any) *A_arbace_java_io_eval1661000174_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000174_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000174_A_class)) }; return v }



type A_arbace_java_io_eval1661000174_fn__1661000175_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000178_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000178_A_New() *A_arbace_java_io_eval1661000178_A { t := &A_arbace_java_io_eval1661000178_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000178_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000178_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000178_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000178_A_class }

func (t *A_arbace_java_io_eval1661000178_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000178_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000178_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000178_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000178_A); return ok }

func A_arbace_java_io_eval1661000178_A_Cast(x any) *A_arbace_java_io_eval1661000178_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000178_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000178_A_class)) }; return v }



type A_arbace_java_io_eval1661000178_fn__1661000179_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000182_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000182_A_New() *A_arbace_java_io_eval1661000182_A { t := &A_arbace_java_io_eval1661000182_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000182_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000182_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000182_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000182_A_class }

func (t *A_arbace_java_io_eval1661000182_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000182_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000182_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000182_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000182_A); return ok }

func A_arbace_java_io_eval1661000182_A_Cast(x any) *A_arbace_java_io_eval1661000182_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000182_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000182_A_class)) }; return v }



type A_arbace_java_io_eval1661000182_fn__1661000183_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000186_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000186_A_New() *A_arbace_java_io_eval1661000186_A { t := &A_arbace_java_io_eval1661000186_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000186_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000186_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000186_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000186_A_class }

func (t *A_arbace_java_io_eval1661000186_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000186_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000186_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000186_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000186_A); return ok }

func A_arbace_java_io_eval1661000186_A_Cast(x any) *A_arbace_java_io_eval1661000186_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000186_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000186_A_class)) }; return v }



type A_arbace_java_io_eval1661000186_fn__1661000187_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000186_fn__1661000189_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000192_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000192_A_New() *A_arbace_java_io_eval1661000192_A { t := &A_arbace_java_io_eval1661000192_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000192_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000192_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000192_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000192_A_class }

func (t *A_arbace_java_io_eval1661000192_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000192_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000192_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000192_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000192_A); return ok }

func A_arbace_java_io_eval1661000192_A_Cast(x any) *A_arbace_java_io_eval1661000192_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000192_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000192_A_class)) }; return v }



type A_arbace_java_io_eval1661000192_fn__1661000193_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000192_fn__1661000195_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000198_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000198_A_New() *A_arbace_java_io_eval1661000198_A { t := &A_arbace_java_io_eval1661000198_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000198_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000198_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000198_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000198_A_class }

func (t *A_arbace_java_io_eval1661000198_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000198_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000198_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000198_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000198_A); return ok }

func A_arbace_java_io_eval1661000198_A_Cast(x any) *A_arbace_java_io_eval1661000198_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000198_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000198_A_class)) }; return v }



type A_arbace_java_io_eval1661000198_fn__1661000199_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000198_fn__1661000201_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000204_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000204_A_New() *A_arbace_java_io_eval1661000204_A { t := &A_arbace_java_io_eval1661000204_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000204_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000204_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000204_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000204_A_class }

func (t *A_arbace_java_io_eval1661000204_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000204_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000204_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000204_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000204_A); return ok }

func A_arbace_java_io_eval1661000204_A_Cast(x any) *A_arbace_java_io_eval1661000204_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000204_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000204_A_class)) }; return v }



type A_arbace_java_io_eval1661000204_fn__1661000205_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000204_fn__1661000207_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000210_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000210_A_New() *A_arbace_java_io_eval1661000210_A { t := &A_arbace_java_io_eval1661000210_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000210_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000210_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000210_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000210_A_class }

func (t *A_arbace_java_io_eval1661000210_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000210_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000210_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000210_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000210_A); return ok }

func A_arbace_java_io_eval1661000210_A_Cast(x any) *A_arbace_java_io_eval1661000210_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000210_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000210_A_class)) }; return v }



type A_arbace_java_io_eval1661000210_fn__1661000211_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000210_fn__1661000213_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000216_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000216_A_New() *A_arbace_java_io_eval1661000216_A { t := &A_arbace_java_io_eval1661000216_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000216_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000216_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000216_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000216_A_class }

func (t *A_arbace_java_io_eval1661000216_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000216_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000216_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000216_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000216_A); return ok }

func A_arbace_java_io_eval1661000216_A_Cast(x any) *A_arbace_java_io_eval1661000216_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000216_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000216_A_class)) }; return v }



type A_arbace_java_io_eval1661000216_fn__1661000217_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000220_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000220_A_New() *A_arbace_java_io_eval1661000220_A { t := &A_arbace_java_io_eval1661000220_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000220_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000220_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000220_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000220_A_class }

func (t *A_arbace_java_io_eval1661000220_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000220_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000220_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000220_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000220_A); return ok }

func A_arbace_java_io_eval1661000220_A_Cast(x any) *A_arbace_java_io_eval1661000220_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000220_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000220_A_class)) }; return v }



type A_arbace_java_io_eval1661000220_fn__1661000221_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000226_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000226_A_New() *A_arbace_java_io_eval1661000226_A { t := &A_arbace_java_io_eval1661000226_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000226_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000226_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000226_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000226_A_class }

func (t *A_arbace_java_io_eval1661000226_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000226_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000226_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000226_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000226_A); return ok }

func A_arbace_java_io_eval1661000226_A_Cast(x any) *A_arbace_java_io_eval1661000226_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000226_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000226_A_class)) }; return v }



type A_arbace_java_io_eval1661000226_fn__1661000227_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000226_fn__1661000229_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000232_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000232_A_New() *A_arbace_java_io_eval1661000232_A { t := &A_arbace_java_io_eval1661000232_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000232_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000232_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000232_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000232_A_class }

func (t *A_arbace_java_io_eval1661000232_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000232_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000232_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000232_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000232_A); return ok }

func A_arbace_java_io_eval1661000232_A_Cast(x any) *A_arbace_java_io_eval1661000232_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000232_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000232_A_class)) }; return v }



type A_arbace_java_io_eval1661000232_fn__1661000233_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000236_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000236_A_New() *A_arbace_java_io_eval1661000236_A { t := &A_arbace_java_io_eval1661000236_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000236_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000236_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000236_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000236_A_class }

func (t *A_arbace_java_io_eval1661000236_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000236_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000236_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000236_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000236_A); return ok }

func A_arbace_java_io_eval1661000236_A_Cast(x any) *A_arbace_java_io_eval1661000236_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000236_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000236_A_class)) }; return v }



type A_arbace_java_io_eval1661000236_fn__1661000237_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000240_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000240_A_New() *A_arbace_java_io_eval1661000240_A { t := &A_arbace_java_io_eval1661000240_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000240_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000240_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000240_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000240_A_class }

func (t *A_arbace_java_io_eval1661000240_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000240_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000240_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000240_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000240_A); return ok }

func A_arbace_java_io_eval1661000240_A_Cast(x any) *A_arbace_java_io_eval1661000240_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000240_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000240_A_class)) }; return v }



type A_arbace_java_io_eval1661000240_fn__1661000241_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000244_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000244_A_New() *A_arbace_java_io_eval1661000244_A { t := &A_arbace_java_io_eval1661000244_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000244_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000244_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000244_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000244_A_class }

func (t *A_arbace_java_io_eval1661000244_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000244_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000244_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000244_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000244_A); return ok }

func A_arbace_java_io_eval1661000244_A_Cast(x any) *A_arbace_java_io_eval1661000244_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000244_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000244_A_class)) }; return v }



type A_arbace_java_io_eval1661000244_fn__1661000245_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000248_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000248_A_New() *A_arbace_java_io_eval1661000248_A { t := &A_arbace_java_io_eval1661000248_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000248_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000248_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000248_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000248_A_class }

func (t *A_arbace_java_io_eval1661000248_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000248_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000248_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000248_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000248_A); return ok }

func A_arbace_java_io_eval1661000248_A_Cast(x any) *A_arbace_java_io_eval1661000248_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000248_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000248_A_class)) }; return v }



type A_arbace_java_io_eval1661000248_fn__1661000249_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000252_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000252_A_New() *A_arbace_java_io_eval1661000252_A { t := &A_arbace_java_io_eval1661000252_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000252_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000252_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000252_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000252_A_class }

func (t *A_arbace_java_io_eval1661000252_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000252_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000252_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000252_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000252_A); return ok }

func A_arbace_java_io_eval1661000252_A_Cast(x any) *A_arbace_java_io_eval1661000252_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000252_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000252_A_class)) }; return v }



type A_arbace_java_io_eval1661000252_fn__1661000253_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000256_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000256_A_New() *A_arbace_java_io_eval1661000256_A { t := &A_arbace_java_io_eval1661000256_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000256_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000256_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000256_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000256_A_class }

func (t *A_arbace_java_io_eval1661000256_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000256_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000256_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000256_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000256_A); return ok }

func A_arbace_java_io_eval1661000256_A_Cast(x any) *A_arbace_java_io_eval1661000256_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000256_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000256_A_class)) }; return v }



type A_arbace_java_io_eval1661000256_fn__1661000257_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000260_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000260_A_New() *A_arbace_java_io_eval1661000260_A { t := &A_arbace_java_io_eval1661000260_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000260_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000260_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000260_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000260_A_class }

func (t *A_arbace_java_io_eval1661000260_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000260_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000260_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000260_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000260_A); return ok }

func A_arbace_java_io_eval1661000260_A_Cast(x any) *A_arbace_java_io_eval1661000260_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000260_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000260_A_class)) }; return v }



type A_arbace_java_io_eval1661000260_fn__1661000261_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000264_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000264_A_New() *A_arbace_java_io_eval1661000264_A { t := &A_arbace_java_io_eval1661000264_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000264_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000264_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000264_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000264_A_class }

func (t *A_arbace_java_io_eval1661000264_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000264_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000264_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000264_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000264_A); return ok }

func A_arbace_java_io_eval1661000264_A_Cast(x any) *A_arbace_java_io_eval1661000264_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000264_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000264_A_class)) }; return v }



type A_arbace_java_io_eval1661000264_fn__1661000265_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000268_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000268_A_New() *A_arbace_java_io_eval1661000268_A { t := &A_arbace_java_io_eval1661000268_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000268_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000268_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000268_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000268_A_class }

func (t *A_arbace_java_io_eval1661000268_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000268_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000268_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000268_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000268_A); return ok }

func A_arbace_java_io_eval1661000268_A_Cast(x any) *A_arbace_java_io_eval1661000268_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000268_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000268_A_class)) }; return v }



type A_arbace_java_io_eval1661000268_fn__1661000269_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000272_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000272_A_New() *A_arbace_java_io_eval1661000272_A { t := &A_arbace_java_io_eval1661000272_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000272_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000272_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000272_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000272_A_class }

func (t *A_arbace_java_io_eval1661000272_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000272_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000272_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000272_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000272_A); return ok }

func A_arbace_java_io_eval1661000272_A_Cast(x any) *A_arbace_java_io_eval1661000272_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000272_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000272_A_class)) }; return v }



type A_arbace_java_io_eval1661000272_fn__1661000273_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000276_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000276_A_New() *A_arbace_java_io_eval1661000276_A { t := &A_arbace_java_io_eval1661000276_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000276_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000276_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000276_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000276_A_class }

func (t *A_arbace_java_io_eval1661000276_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000276_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000276_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000276_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000276_A); return ok }

func A_arbace_java_io_eval1661000276_A_Cast(x any) *A_arbace_java_io_eval1661000276_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000276_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000276_A_class)) }; return v }



type A_arbace_java_io_eval1661000276_fn__1661000277_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000280_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000280_A_New() *A_arbace_java_io_eval1661000280_A { t := &A_arbace_java_io_eval1661000280_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000280_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000280_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000280_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000280_A_class }

func (t *A_arbace_java_io_eval1661000280_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000280_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000280_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000280_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000280_A); return ok }

func A_arbace_java_io_eval1661000280_A_Cast(x any) *A_arbace_java_io_eval1661000280_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000280_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000280_A_class)) }; return v }



type A_arbace_java_io_eval1661000280_fn__1661000281_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000284_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000284_A_New() *A_arbace_java_io_eval1661000284_A { t := &A_arbace_java_io_eval1661000284_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000284_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000284_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000284_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000284_A_class }

func (t *A_arbace_java_io_eval1661000284_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000284_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000284_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000284_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000284_A); return ok }

func A_arbace_java_io_eval1661000284_A_Cast(x any) *A_arbace_java_io_eval1661000284_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000284_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000284_A_class)) }; return v }



type A_arbace_java_io_eval1661000284_fn__1661000285_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000288_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000288_A_New() *A_arbace_java_io_eval1661000288_A { t := &A_arbace_java_io_eval1661000288_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000288_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000288_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000288_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000288_A_class }

func (t *A_arbace_java_io_eval1661000288_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000288_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000288_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000288_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000288_A); return ok }

func A_arbace_java_io_eval1661000288_A_Cast(x any) *A_arbace_java_io_eval1661000288_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000288_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000288_A_class)) }; return v }



type A_arbace_java_io_eval1661000288_fn__1661000289_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000292_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000292_A_New() *A_arbace_java_io_eval1661000292_A { t := &A_arbace_java_io_eval1661000292_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000292_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000292_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000292_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000292_A_class }

func (t *A_arbace_java_io_eval1661000292_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000292_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000292_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000292_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000292_A); return ok }

func A_arbace_java_io_eval1661000292_A_Cast(x any) *A_arbace_java_io_eval1661000292_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000292_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000292_A_class)) }; return v }



type A_arbace_java_io_eval1661000292_fn__1661000293_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000296_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000296_A_New() *A_arbace_java_io_eval1661000296_A { t := &A_arbace_java_io_eval1661000296_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000296_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000296_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000296_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000296_A_class }

func (t *A_arbace_java_io_eval1661000296_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000296_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000296_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000296_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000296_A); return ok }

func A_arbace_java_io_eval1661000296_A_Cast(x any) *A_arbace_java_io_eval1661000296_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000296_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000296_A_class)) }; return v }



type A_arbace_java_io_eval1661000296_fn__1661000297_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000300_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000300_A_New() *A_arbace_java_io_eval1661000300_A { t := &A_arbace_java_io_eval1661000300_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000300_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000300_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000300_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000300_A_class }

func (t *A_arbace_java_io_eval1661000300_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000300_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000300_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000300_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000300_A); return ok }

func A_arbace_java_io_eval1661000300_A_Cast(x any) *A_arbace_java_io_eval1661000300_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000300_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000300_A_class)) }; return v }



type A_arbace_java_io_eval1661000300_fn__1661000301_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class *jrt.Class



type A_arbace_java_io_eval1661000304_A struct{ jrt.Object }

func A_arbace_java_io_eval1661000304_A_New() *A_arbace_java_io_eval1661000304_A { t := &A_arbace_java_io_eval1661000304_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io_eval1661000304_A) Ctor() {}

func (t *A_arbace_java_io_eval1661000304_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io_eval1661000304_A) GetClass__Class() *jrt.Class { return A_arbace_java_io_eval1661000304_A_class }

func (t *A_arbace_java_io_eval1661000304_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io_eval1661000304_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io_eval1661000304_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io_eval1661000304_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io_eval1661000304_A); return ok }

func A_arbace_java_io_eval1661000304_A_Cast(x any) *A_arbace_java_io_eval1661000304_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io_eval1661000304_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_eval1661000304_A_class)) }; return v }



type A_arbace_java_io_eval1661000304_fn__1661000305_A struct{ j2g_header uint64 }

var A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class *jrt.Class



type A_arbace_java_io_file_A struct{ j2g_header uint64 }

var A_arbace_java_io_file_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000144_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000144_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000146_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000146_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000148_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000148_A_fn_class *jrt.Class



type A_arbace_java_io_fn__1661000150_A struct{ j2g_header uint64 }

var A_arbace_java_io_fn__1661000150_A_fn_class *jrt.Class



type A_arbace_java_io_input_stream_A struct{ j2g_header uint64 }

var A_arbace_java_io_input_stream_A_fn_class *jrt.Class



type A_arbace_java_io_inputstream__GT_reader_A struct{ j2g_header uint64 }

var A_arbace_java_io_inputstream__GT_reader_A_fn_class *jrt.Class



type A_arbace_java_io_make_parents_A struct{ j2g_header uint64 }

var A_arbace_java_io_make_parents_A_fn_class *jrt.Class



type A_arbace_java_io_output_stream_A struct{ j2g_header uint64 }

var A_arbace_java_io_output_stream_A_fn_class *jrt.Class



type A_arbace_java_io_outputstream__GT_writer_A struct{ j2g_header uint64 }

var A_arbace_java_io_outputstream__GT_writer_A_fn_class *jrt.Class



type A_arbace_java_io_reader_A struct{ j2g_header uint64 }

var A_arbace_java_io_reader_A_fn_class *jrt.Class



type A_arbace_java_io_resource_A struct{ j2g_header uint64 }

var A_arbace_java_io_resource_A_fn_class *jrt.Class



type A_arbace_java_io_writer_A struct{ j2g_header uint64 }

var A_arbace_java_io_writer_A_fn_class *jrt.Class
