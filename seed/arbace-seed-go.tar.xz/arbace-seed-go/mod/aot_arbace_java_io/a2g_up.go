//line a2g_up.ae:1
package aot_arbace_java_io

import "arbace/lang"


func Up_Namespace_AReference(p *lang.Namespace) lang.AReference_I { if p == nil { return nil }; return p }

func Up_Symbol_IObj(p *lang.Symbol) lang.IObj { if p == nil { return nil }; return p }

func Up_Var_IFn(p *lang.Var) lang.IFn { if p == nil { return nil }; return p }

func Up_Var_IRef(p *lang.Var) lang.IRef { if p == nil { return nil }; return p }
