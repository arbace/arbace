//line aot_arbace_java_io_IOFactory.ae:1
package aot_arbace_java_io

import "arbace/jrt"




type A_arbace_java_io_IOFactory_A interface{ jrt.Object_I; Is_A_arbace_java_io_IOFactory_A(); Make_reader_O__O(p0 any) any; Make_writer_O__O(p0 any) any; Make_input_stream_O__O(p0 any) any; Make_output_stream_O__O(p0 any) any }

func A_arbace_java_io_IOFactory_A_InstanceOf(x any) bool { _, ok := x.(A_arbace_java_io_IOFactory_A); if !ok && x != nil && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_java_io_IOFactory_A_class) } }; return ok }

func A_arbace_java_io_IOFactory_A_Cast(x any) A_arbace_java_io_IOFactory_A { if x == nil { return nil }; v, ok := x.(A_arbace_java_io_IOFactory_A); if ok && jrt.IsDynamic(x) { d, dyn := x.(jrt.Dynamic); if dyn { ok = d.DynImplements(A_arbace_java_io_IOFactory_A_class) } }; if !ok { panic(jrt.ClassCast(x, A_arbace_java_io_IOFactory_A_class)) }; return v }
