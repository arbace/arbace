//line aot_arbace_java_io__init.ae:1
package aot_arbace_java_io

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_io__init_A_Load__O() any { A_arbace_java_io__init_A_Init(); jrt.StartCheck(); A_arbace_java_io__init_A_Unit0__O(); A_arbace_java_io__init_A_Unit1__O(); A_arbace_java_io__init_A_Unit2__O(); A_arbace_java_io__init_A_Unit3__O(); A_arbace_java_io__init_A_Unit4__O(); A_arbace_java_io__init_A_Unit5__O(); A_arbace_java_io__init_A_Unit6__O(); A_arbace_java_io__init_A_Unit7__O(); A_arbace_java_io__init_A_Unit8__O(); A_arbace_java_io__init_A_Unit9__O(); A_arbace_java_io__init_A_Unit10__O(); A_arbace_java_io__init_A_Unit11__O(); A_arbace_java_io__init_A_Unit12__O(); A_arbace_java_io__init_A_Unit13__O(); A_arbace_java_io__init_A_Unit14__O(); A_arbace_java_io__init_A_Unit15__O(); A_arbace_java_io__init_A_Unit16__O(); A_arbace_java_io__init_A_Unit17__O(); A_arbace_java_io__init_A_Unit18__O(); A_arbace_java_io__init_A_Unit19__O(); A_arbace_java_io__init_A_Unit20__O(); A_arbace_java_io__init_A_Unit21__O(); A_arbace_java_io__init_A_Unit22__O(); A_arbace_java_io__init_A_Unit23__O(); A_arbace_java_io__init_A_Unit24__O(); A_arbace_java_io__init_A_Unit25__O(); A_arbace_java_io__init_A_Unit26__O(); A_arbace_java_io__init_A_Unit27__O(); A_arbace_java_io__init_A_Unit28__O(); A_arbace_java_io__init_A_Unit29__O(); A_arbace_java_io__init_A_Unit30__O(); A_arbace_java_io__init_A_Unit31__O(); A_arbace_java_io__init_A_Unit32__O(); A_arbace_java_io__init_A_Unit33__O(); A_arbace_java_io__init_A_Unit34__O(); A_arbace_java_io__init_A_Unit35__O(); A_arbace_java_io__init_A_Unit36__O(); A_arbace_java_io__init_A_Unit37__O(); A_arbace_java_io__init_A_Unit38__O(); A_arbace_java_io__init_A_Unit39__O(); A_arbace_java_io__init_A_Unit40__O(); A_arbace_java_io__init_A_Unit41__O(); A_arbace_java_io__init_A_Unit42__O(); A_arbace_java_io__init_A_Unit43__O(); A_arbace_java_io__init_A_Unit44__O(); A_arbace_java_io__init_A_Unit45__O(); A_arbace_java_io__init_A_Unit46__O(); A_arbace_java_io__init_A_Unit47__O(); A_arbace_java_io__init_A_Unit48__O(); A_arbace_java_io__init_A_Unit49__O(); A_arbace_java_io__init_A_Unit50__O(); A_arbace_java_io__init_A_Unit51__O(); A_arbace_java_io__init_A_Unit52__O(); A_arbace_java_io__init_A_Unit53__O(); A_arbace_java_io__init_A_Unit54__O(); A_arbace_java_io__init_A_Unit55__O(); A_arbace_java_io__init_A_Unit56__O(); A_arbace_java_io__init_A_Unit57__O(); A_arbace_java_io__init_A_Unit58__O(); A_arbace_java_io__init_A_Unit59__O(); A_arbace_java_io__init_A_Unit60__O(); A_arbace_java_io__init_A_Unit61__O(); A_arbace_java_io__init_A_Unit62__O(); A_arbace_java_io__init_A_Unit63__O(); A_arbace_java_io__init_A_Unit64__O(); A_arbace_java_io__init_A_Unit65__O(); A_arbace_java_io__init_A_Unit66__O(); A_arbace_java_io__init_A_Unit67__O(); A_arbace_java_io__init_A_Unit68__O(); A_arbace_java_io__init_A_Unit69__O(); A_arbace_java_io__init_A_Unit70__O(); A_arbace_java_io__init_A_Unit71__O(); A_arbace_java_io__init_A_Unit72__O(); A_arbace_java_io__init_A_Unit73__O(); A_arbace_java_io__init_A_Unit74__O(); A_arbace_java_io__init_A_Unit75__O(); A_arbace_java_io__init_A_Unit76__O(); A_arbace_java_io__init_A_Unit77__O(); A_arbace_java_io__init_A_Unit78__O(); return nil }



func A_arbace_java_io__init_A_Unit0__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_java_io__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io__init_A_const_1) }
//line :9:1
func A_arbace_java_io__init_A_Unit1__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_2)) }
//line :9:1
func A_arbace_java_io__init_A_Unit2__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_java_io__init_A_Unit3__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1)).Equals_O__Z(A_arbace_java_io__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_java_io_eval1661000008_fn__1661000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }















func A_arbace_java_io__init_A_Unit4__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); return A_arbace_java_io__init_A_const_4.Set_O__O(jrt.Boolean_FALSE.Ref()) }

func A_arbace_java_io__init_A_Unit5__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_5; var tmp2 any; var root_3 any = A_arbace_java_io__init_A_const_6.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_5 lang.IFn; if



	linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any; var root_7 any = A_arbace_java_io__init_A_const_7.GetRawRoot__O(); var linked_8 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_7, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_9 lang.IFn; if linked_8 == nil { ifn_9 = lang.IFn_Cast(root_7) } else { ifn_9 = nil }; var arg_10 any = jrt.Byte_TYPE.Ref(); var arg_11 any = A_arbace_java_io__init_A_const_8; if linked_8 == nil { arg_6 = ifn_9.Invoke_O_O__O(arg_10, arg_11) } else { arg_6 = linked_8.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_7, arg_10, arg_11) }; if linked_4 == nil { tmp2 = ifn_5.Invoke_O__O(arg_6) } else { tmp2 = linked_4.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_3, arg_6) }; /*line :27:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_io__init_A_const_5; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_9)); return A_arbace_java_io__init_A_const_5 }





func A_arbace_java_io__init_A_Unit6__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_10; var tmp2 any; var root_12 any = A_arbace_java_io__init_A_const_6.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_14 lang.IFn; if


	linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any; var root_16 any = A_arbace_java_io__init_A_const_7.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = jrt.Character_TYPE.Ref(); var arg_20 any = A_arbace_java_io__init_A_const_8; if linked_17 == nil { arg_15 = ifn_18.Invoke_O_O__O(arg_19, arg_20) } else { arg_15 = linked_17.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_16, arg_19, arg_20) }; if linked_13 == nil { tmp2 = ifn_14.Invoke_O__O(arg_15) } else { tmp2 = linked_13.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_12, arg_15) }; /*line :33:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_io__init_A_const_10; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_11)); return A_arbace_java_io__init_A_const_10 }




func A_arbace_java_io__init_A_Unit7__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_13)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_12; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_14)); A_arbace_java_io__init_A_const_12.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_12 } }
//line :38:1
func A_arbace_java_io__init_A_Unit8__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_15 }
//line :38:1
func A_arbace_java_io__init_A_Unit9__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_64) }
//line :38:1
func A_arbace_java_io__init_A_Unit10__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_12, A_arbace_java_io__init_A_const_20) }
//line :38:1
func A_arbace_java_io__init_A_Unit11__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_23; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_25; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_12; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_28; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 any; var root_46 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_50 any; var root_51 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_java_io__init_A_const_33; var arg_55 any; var root_56 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = A_arbace_java_io__init_A_const_34; var arg_60 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12)); if linked_57 == nil { arg_55 = ifn_58.Invoke_O_O__O(arg_59, arg_60) } else { arg_55 = linked_57.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_56, arg_59, arg_60) }; if linked_52 == nil { arg_50 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { arg_50 = linked_52.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; if linked_47 == nil { tmp13 = ifn_48.Invoke_O_O__O(arg_49, arg_50) } else { tmp13 = linked_47.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_46, arg_49, arg_50) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_java_io_eval1661000024_fn__1661000025_A_New(); var tmp16 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class = fncls__61d; tmp16 = fncls__61d } else { tmp16 = fncls__61 }; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 any; var root_62 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_66 any; var root_67 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_java_io__init_A_const_36; var arg_71 any; var root_72 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = A_arbace_java_io__init_A_const_37; var arg_76 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12)); if linked_73 == nil { arg_71 = ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { arg_71 = linked_73.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) }; if linked_68 == nil { arg_66 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { arg_66 = linked_68.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; if linked_63 == nil { tmp18 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { tmp18 = linked_63.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_java_io_eval1661000024_fn__1661000033_A_New(); var tmp21 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class = fncls__77d; tmp21 = fncls__77d } else { tmp21 = fncls__77 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil))))) }
//line :38:1
func A_arbace_java_io__init_A_Unit12__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var root_78 any = A_arbace_java_io__init_A_const_38.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); if linked_79 == nil { return ifn_80.Invoke_O__O(arg_81) } else { return linked_79.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_78, arg_81) } }
//line :38:1
func A_arbace_java_io__init_A_Unit13__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_39 }




func A_arbace_java_io__init_A_Unit14__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_40; var tmp2 any = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_41)); return A_arbace_java_io__init_A_const_40 }



func A_arbace_java_io__init_A_Unit15__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_43; var tmp4 any = A_arbace_java_io_eval1661000047_fn__1661000048_A_New(); var tmp5 *jrt.Class; var fncls__89 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class; if fncls__89 == nil { var fncls__89d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class = fncls__89d; tmp5 = fncls__89d } else { tmp5 = fncls__89 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_java_io__init_A_const_44; var tmp8 any = A_arbace_java_io_eval1661000047_fn__1661000050_A_New(); var tmp9 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class = fncls__90d; tmp9 = fncls__90d } else { tmp9 = fncls__90 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit16__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 any = A_arbace_java_io_eval1661000053_fn__1661000054_A_New(); var tmp6 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class; if fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class = fncls__97d; tmp6 = fncls__97d } else { tmp6 = fncls__97 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 any = A_arbace_java_io_eval1661000053_fn__1661000056_A_New(); var tmp10 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class; if fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class = fncls__98d; tmp10 = fncls__98d } else { tmp10 = fncls__98 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit17__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 any = A_arbace_java_io_eval1661000059_fn__1661000060_A_New(); var tmp6 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class = fncls__105d; tmp6 = fncls__105d } else { tmp6 = fncls__105 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 any = A_arbace_java_io_eval1661000059_fn__1661000062_A_New(); var tmp10 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class = fncls__106d; tmp10 = fncls__106d } else { tmp10 = fncls__106 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit18__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 any = A_arbace_java_io_eval1661000065_fn__1661000066_A_New(); var tmp6 *jrt.Class; var fncls__113 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class; if fncls__113 == nil { var fncls__113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class = fncls__113d; tmp6 = fncls__113d } else { tmp6 = fncls__113 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 any = A_arbace_java_io_eval1661000065_fn__1661000068_A_New(); var tmp10 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class = fncls__114d; tmp10 = fncls__114d } else { tmp10 = fncls__114 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit19__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 any = A_arbace_java_io_eval1661000071_fn__1661000072_A_New(); var tmp6 *jrt.Class; var fncls__121 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class; if fncls__121 == nil { var fncls__121d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class = fncls__121d; tmp6 = fncls__121d } else { tmp6 = fncls__121 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 any = A_arbace_java_io_eval1661000071_fn__1661000074_A_New(); var tmp10 *jrt.Class; var fncls__122 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class; if fncls__122 == nil { var fncls__122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class = fncls__122d; tmp10 = fncls__122d } else { tmp10 = fncls__122 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
























func A_arbace_java_io__init_A_Unit20__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_50)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_49; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_49; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_51)); A_arbace_java_io__init_A_const_49.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_49 } }
//line :72:1
func A_arbace_java_io__init_A_Unit21__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_52 }
//line :72:1
func A_arbace_java_io__init_A_Unit22__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_78) }
//line :72:1
func A_arbace_java_io__init_A_Unit23__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_49, A_arbace_java_io__init_A_const_53) }
//line :72:1
func A_arbace_java_io__init_A_Unit24__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_54; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_55; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_49; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_56; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 any; var root_148 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_149 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_148, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_150 lang.IFn; if linked_149 == nil { ifn_150 = lang.IFn_Cast(root_148) } else { ifn_150 = nil }; var arg_151 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_152 any; var root_153 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_154 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_153, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_155 lang.IFn; if linked_154 == nil { ifn_155 = lang.IFn_Cast(root_153) } else { ifn_155 = nil }; var arg_156 any = A_arbace_java_io__init_A_const_57; var arg_157 any; var root_158 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = A_arbace_java_io__init_A_const_58; var arg_162 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_159 == nil { arg_157 = ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { arg_157 = linked_159.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) }; if linked_154 == nil { arg_152 = ifn_155.Invoke_O_O__O(arg_156, arg_157) } else { arg_152 = linked_154.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_153, arg_156, arg_157) }; if linked_149 == nil { tmp13 = ifn_150.Invoke_O_O__O(arg_151, arg_152) } else { tmp13 = linked_149.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_148, arg_151, arg_152) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_java_io_eval1661000091_fn__1661000092_A_New(); var tmp16 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class = fncls__163d; tmp16 = fncls__163d } else { tmp16 = fncls__163 }; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 any; var root_164 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_168 any; var root_169 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = A_arbace_java_io__init_A_const_59; var arg_173 any; var root_174 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = A_arbace_java_io__init_A_const_60; var arg_178 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_175 == nil { arg_173 = ifn_176.Invoke_O_O__O(arg_177, arg_178) } else { arg_173 = linked_175.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_174, arg_177, arg_178) }; if linked_170 == nil { arg_168 = ifn_171.Invoke_O_O__O(arg_172, arg_173) } else { arg_168 = linked_170.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_169, arg_172, arg_173) }; if linked_165 == nil { tmp18 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { tmp18 = linked_165.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_java_io_eval1661000091_fn__1661000102_A_New(); var tmp21 *jrt.Class; var fncls__179 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class; if fncls__179 == nil { var fncls__179d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class = fncls__179d; tmp21 = fncls__179d } else { tmp21 = fncls__179 }; var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 any; var root_180 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_184 any; var root_185 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = A_arbace_java_io__init_A_const_61; var arg_189 any; var root_190 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_java_io__init_A_const_62; var arg_194 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_191 == nil { arg_189 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { arg_189 = linked_191.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if linked_186 == nil { arg_184 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { arg_184 = linked_186.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; if linked_181 == nil { tmp23 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { tmp23 = linked_181.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_java_io_eval1661000091_fn__1661000112_A_New(); var tmp26 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class; if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class = fncls__195d; tmp26 = fncls__195d } else { tmp26 = fncls__195 }; var tmp27 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var tmp28 any; var root_196 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_200 any; var root_201 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any = A_arbace_java_io__init_A_const_63; var arg_205 any; var root_206 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = A_arbace_java_io__init_A_const_64; var arg_210 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_207 == nil { arg_205 = ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { arg_205 = linked_207.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) }; if linked_202 == nil { arg_200 = ifn_203.Invoke_O_O__O(arg_204, arg_205) } else { arg_200 = linked_202.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_201, arg_204, arg_205) }; if linked_197 == nil { tmp28 = ifn_198.Invoke_O_O__O(arg_199, arg_200) } else { tmp28 = linked_197.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_196, arg_199, arg_200) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_java_io_eval1661000091_fn__1661000122_A_New(); var tmp31 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class = fncls__211d; tmp31 = fncls__211d } else { tmp31 = fncls__211 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, tmp22, tmp24, tmp27, tmp29, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil))))) }
//line :72:1
func A_arbace_java_io__init_A_Unit25__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var root_212 any = A_arbace_java_io__init_A_const_38.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_212, arg_215) } }
//line :72:1
func A_arbace_java_io__init_A_Unit26__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_65 }
















func A_arbace_java_io__init_A_Unit27__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_66; var tmp2 any = A_arbace_java_io_reader_A_New(); var tmp3 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_java_io_reader_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, true); A_arbace_java_io_reader_A_fn_class = fncls__216d; tmp3 = fncls__216d } else { tmp3 = fncls__216 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_67)); return A_arbace_java_io__init_A_const_66 }

















func A_arbace_java_io__init_A_Unit28__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_68; var tmp2 any = A_arbace_java_io_writer_A_New(); var tmp3 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_java_io_writer_A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, true); A_arbace_java_io_writer_A_fn_class = fncls__217d; tmp3 = fncls__217d } else { tmp3 = fncls__217 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_69)); return A_arbace_java_io__init_A_const_68 }
















func A_arbace_java_io__init_A_Unit29__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_70; var tmp2 any = A_arbace_java_io_input_stream_A_New(); var tmp3 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_java_io_input_stream_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, true); A_arbace_java_io_input_stream_A_fn_class = fncls__218d; tmp3 = fncls__218d } else { tmp3 = fncls__218 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_71)); return A_arbace_java_io__init_A_const_70 }
















func A_arbace_java_io__init_A_Unit30__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_72; var tmp2 any = A_arbace_java_io_output_stream_A_New(); var tmp3 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_java_io_output_stream_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, true); A_arbace_java_io_output_stream_A_fn_class = fncls__219d; tmp3 = fncls__219d } else { tmp3 = fncls__219 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_73)); return A_arbace_java_io__init_A_const_72 }
















func A_arbace_java_io__init_A_Unit31__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_74; var tmp2 any = A_arbace_java_io_append_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_java_io_append_QMARK__A_fn_class; if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_java_io_append_QMARK__A_fn_class = fncls__220d; tmp3 = fncls__220d } else { tmp3 = fncls__220 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_75)); return A_arbace_java_io__init_A_const_74 }


func A_arbace_java_io__init_A_Unit32__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_76; var tmp2 any = A_arbace_java_io_encoding_A_New(); var tmp3 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_java_io_encoding_A_fn_class; if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_java_io_encoding_A_fn_class = fncls__221d; tmp3 = fncls__221d } else { tmp3 = fncls__221 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_77)); return A_arbace_java_io__init_A_const_76 }


func A_arbace_java_io__init_A_Unit33__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_78; var tmp2 any = A_arbace_java_io_buffer_size_A_New(); var tmp3 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_java_io_buffer_size_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_java_io_buffer_size_A_fn_class = fncls__222d; tmp3 = fncls__222d } else { tmp3 = fncls__222 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_79)); return A_arbace_java_io__init_A_const_78 }


func A_arbace_java_io__init_A_Unit34__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_80; var tmp2 any = A_arbace_java_io__init_A_const_81; var tmp3 any = A_arbace_java_io_fn__1661000144_A_New(); var tmp4 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_java_io_fn__1661000144_A_fn_class; if
						fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_java_io_fn__1661000144_A_fn_class = fncls__223d; tmp4 = fncls__223d } else { tmp4 = fncls__223 }; var tmp5 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_java_io__init_A_const_82; var tmp7 any = A_arbace_java_io_fn__1661000146_A_New(); var tmp8 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_java_io_fn__1661000146_A_fn_class; if

	fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_java_io_fn__1661000146_A_fn_class = fncls__224d; tmp8 = fncls__224d } else { tmp8 = fncls__224 }; var tmp9 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_83; var tmp11 any = A_arbace_java_io_fn__1661000148_A_New(); var tmp12 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_java_io_fn__1661000148_A_fn_class; if


	fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_java_io_fn__1661000148_A_fn_class = fncls__225d; tmp12 = fncls__225d } else { tmp12 = fncls__225 }; var tmp13 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 any = A_arbace_java_io__init_A_const_84; var tmp15 any = A_arbace_java_io_fn__1661000150_A_New(); var tmp16 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_java_io_fn__1661000150_A_fn_class; if





	fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_java_io_fn__1661000150_A_fn_class = fncls__226d; tmp16 = fncls__226d } else { tmp16 = fncls__226 }; /*line :167:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp9, tmp10, tmp13, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)))); var tmp17 *lang.Var = A_arbace_java_io__init_A_const_80; tmp17.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_85)); return A_arbace_java_io__init_A_const_80 }









func A_arbace_java_io__init_A_Unit35__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_86; var tmp2 any = A_arbace_java_io_inputstream__GT_reader_A_New(); var tmp3 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_java_io_inputstream__GT_reader_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_java_io_inputstream__GT_reader_A_fn_class = fncls__227d; tmp3 = fncls__227d } else { tmp3 = fncls__227 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_87)); return A_arbace_java_io__init_A_const_86 }



func A_arbace_java_io__init_A_Unit36__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_88; var tmp2 any = A_arbace_java_io_outputstream__GT_writer_A_New(); var tmp3 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_java_io_outputstream__GT_writer_A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_java_io_outputstream__GT_writer_A_fn_class = fncls__228d; tmp3 = fncls__228d } else { tmp3 = fncls__228 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_89)); return A_arbace_java_io__init_A_const_88 }



func A_arbace_java_io__init_A_Unit37__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_90; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000154_fn__1661000155_A_New(); var tmp8 *jrt.Class; var fncls__243 *jrt.Class = A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class; if


	fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class = fncls__243d; tmp8 = fncls__243d } else { tmp8 = fncls__243 }; var tmp9 any = /*line :185:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit38__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_91; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000158_fn__1661000159_A_New(); var tmp8 *jrt.Class; var fncls__258 *jrt.Class = A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class; if


	fncls__258 == nil { var fncls__258d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class = fncls__258d; tmp8 = fncls__258d } else { tmp8 = fncls__258 }; var tmp9 any = /*line :191:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit39__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_92; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_265 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_267 lang.IFn; if

	linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_269 any = A_arbace_java_io__init_A_const_81; var arg_270 any; var tmp5 any = A_arbace_java_io_eval1661000162_fn__1661000163_A_New(); var tmp6 *jrt.Class; var fncls__271 *jrt.Class = A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class; if
	fncls__271 == nil { var fncls__271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class = fncls__271d; tmp6 = fncls__271d } else { tmp6 = fncls__271 }; arg_270 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :199:1*/ linked_266 == nil { tmp4 = ifn_267.Invoke_O_O_O__O(arg_268, arg_269, arg_270) } else { tmp4 = linked_266.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_265, arg_268, arg_269, arg_270) }; return /*line :197:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit40__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_93; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_278 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_280 lang.IFn; if

	linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_282 any = A_arbace_java_io__init_A_const_81; var arg_283 any; var tmp5 any = A_arbace_java_io_eval1661000166_fn__1661000167_A_New(); var tmp6 *jrt.Class; var fncls__284 *jrt.Class = A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class; if
	fncls__284 == nil { var fncls__284d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class = fncls__284d; tmp6 = fncls__284d } else { tmp6 = fncls__284 }; arg_283 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :204:1*/ linked_279 == nil { tmp4 = ifn_280.Invoke_O_O_O__O(arg_281, arg_282, arg_283) } else { tmp4 = linked_279.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_278, arg_281, arg_282, arg_283) }; return /*line :202:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit41__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_94; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_291 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_293 lang.IFn; if

	linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_295 any = A_arbace_java_io__init_A_const_82; var arg_296 any; var tmp5 any = A_arbace_java_io_eval1661000170_fn__1661000171_A_New(); var tmp6 *jrt.Class; var fncls__297 *jrt.Class = A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class; if
	fncls__297 == nil { var fncls__297d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class = fncls__297d; tmp6 = fncls__297d } else { tmp6 = fncls__297 }; arg_296 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :209:1*/ linked_292 == nil { tmp4 = ifn_293.Invoke_O_O_O__O(arg_294, arg_295, arg_296) } else { tmp4 = linked_292.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_291, arg_294, arg_295, arg_296) }; return /*line :207:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit42__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_95; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_304 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_306 lang.IFn; if

	linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_308 any = A_arbace_java_io__init_A_const_82; var arg_309 any; var tmp5 any = A_arbace_java_io_eval1661000174_fn__1661000175_A_New(); var tmp6 *jrt.Class; var fncls__310 *jrt.Class = A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class; if
	fncls__310 == nil { var fncls__310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class = fncls__310d; tmp6 = fncls__310d } else { tmp6 = fncls__310 }; arg_309 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :214:1*/ linked_305 == nil { tmp4 = ifn_306.Invoke_O_O_O__O(arg_307, arg_308, arg_309) } else { tmp4 = linked_305.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_304, arg_307, arg_308, arg_309) }; return /*line :212:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit43__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_96; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 any = A_arbace_java_io_eval1661000178_fn__1661000179_A_New(); var tmp8 *jrt.Class; var fncls__325 *jrt.Class = A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class; if


	fncls__325 == nil { var fncls__325d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class = fncls__325d; tmp8 = fncls__325d } else { tmp8 = fncls__325 }; var tmp9 any = /*line :217:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit44__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_97; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 any = A_arbace_java_io_eval1661000182_fn__1661000183_A_New(); var tmp8 *jrt.Class; var fncls__340 *jrt.Class = A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class; if


	fncls__340 == nil { var fncls__340d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class = fncls__340d; tmp8 = fncls__340d } else { tmp8 = fncls__340 }; var tmp9 any = /*line :223:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit45__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000186_fn__1661000187_A_New(); var tmp8 *jrt.Class; var fncls__355 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class; if


	fncls__355 == nil { var fncls__355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class = fncls__355d; tmp8 = fncls__355d } else { tmp8 = fncls__355 }; var tmp9 any = /*line :229:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000186_fn__1661000189_A_New(); var tmp12 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class; if



	fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class = fncls__356d; tmp12 = fncls__356d } else { tmp12 = fncls__356 }; return /*line :229:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit46__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000192_fn__1661000193_A_New(); var tmp8 *jrt.Class; var fncls__371 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class; if


	fncls__371 == nil { var fncls__371d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class = fncls__371d; tmp8 = fncls__371d } else { tmp8 = fncls__371 }; var tmp9 any = /*line :235:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000192_fn__1661000195_A_New(); var tmp12 *jrt.Class; var fncls__372 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class; if







	fncls__372 == nil { var fncls__372d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class = fncls__372d; tmp12 = fncls__372d } else { tmp12 = fncls__372 }; return /*line :235:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }












func A_arbace_java_io__init_A_Unit47__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000198_fn__1661000199_A_New(); var tmp8 *jrt.Class; var fncls__387 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class; if


	fncls__387 == nil { var fncls__387d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class = fncls__387d; tmp8 = fncls__387d } else { tmp8 = fncls__387 }; var tmp9 any = /*line :248:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000198_fn__1661000201_A_New(); var tmp12 *jrt.Class; var fncls__388 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class; if



	fncls__388 == nil { var fncls__388d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class = fncls__388d; tmp12 = fncls__388d } else { tmp12 = fncls__388 }; return /*line :248:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit48__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000204_fn__1661000205_A_New(); var tmp8 *jrt.Class; var fncls__403 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class; if


	fncls__403 == nil { var fncls__403d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class = fncls__403d; tmp8 = fncls__403d } else { tmp8 = fncls__403 }; var tmp9 any = /*line :254:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000204_fn__1661000207_A_New(); var tmp12 *jrt.Class; var fncls__404 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class; if







	fncls__404 == nil { var fncls__404d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class = fncls__404d; tmp12 = fncls__404d } else { tmp12 = fncls__404 }; return /*line :254:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }













func A_arbace_java_io__init_A_Unit49__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_98; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000210_fn__1661000211_A_New(); var tmp8 *jrt.Class; var fncls__419 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class; if


	fncls__419 == nil { var fncls__419d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class = fncls__419d; tmp8 = fncls__419d } else { tmp8 = fncls__419 }; var tmp9 any = /*line :268:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000210_fn__1661000213_A_New(); var tmp12 *jrt.Class; var fncls__420 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class; if



	fncls__420 == nil { var fncls__420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class = fncls__420d; tmp12 = fncls__420d } else { tmp12 = fncls__420 }; return /*line :268:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit50__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_5.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_427 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_428 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_427, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_429 lang.IFn; if

	linked_428 == nil { ifn_429 = lang.IFn_Cast(root_427) } else { ifn_429 = nil }; var arg_430 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_431 any = A_arbace_java_io__init_A_const_83; var arg_432 any; var tmp5 any = A_arbace_java_io_eval1661000216_fn__1661000217_A_New(); var tmp6 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class; if
	fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class = fncls__433d; tmp6 = fncls__433d } else { tmp6 = fncls__433 }; arg_432 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :276:1*/ linked_428 == nil { tmp4 = ifn_429.Invoke_O_O_O__O(arg_430, arg_431, arg_432) } else { tmp4 = linked_428.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_427, arg_430, arg_431, arg_432) }; return /*line :274:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit51__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_10.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_440 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_441 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_440, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_442 lang.IFn; if

	linked_441 == nil { ifn_442 = lang.IFn_Cast(root_440) } else { ifn_442 = nil }; var arg_443 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_444 any = A_arbace_java_io__init_A_const_81; var arg_445 any; var tmp5 any = A_arbace_java_io_eval1661000220_fn__1661000221_A_New(); var tmp6 *jrt.Class; var fncls__446 *jrt.Class = A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class; if
	fncls__446 == nil { var fncls__446d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class = fncls__446d; tmp6 = fncls__446d } else { tmp6 = fncls__446 }; arg_445 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :281:1*/ linked_441 == nil { tmp4 = ifn_442.Invoke_O_O_O__O(arg_443, arg_444, arg_445) } else { tmp4 = linked_441.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_440, arg_443, arg_444, arg_445) }; return /*line :279:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit52__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_99; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_49.GetRawRoot__O(), A_arbace_java_io__init_A_const_80.GetRawRoot__O()) }



func A_arbace_java_io__init_A_Unit53__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp4 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp5 any = A_arbace_java_io__init_A_const_81; var tmp6 any = A_arbace_java_io_eval1661000226_fn__1661000227_A_New(); var tmp7 *jrt.Class; var fncls__467 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class; if


	fncls__467 == nil { var fncls__467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class = fncls__467d; tmp7 = fncls__467d } else { tmp7 = fncls__467 }; var tmp8 any = /*line :288:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_java_io__init_A_const_82; var tmp10 any = A_arbace_java_io_eval1661000226_fn__1661000229_A_New(); var tmp11 *jrt.Class; var fncls__468 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class; if





	fncls__468 == nil { var fncls__468d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class = fncls__468d; tmp11 = fncls__468d } else { tmp11 = fncls__468 }; return /*line :288:1*/ tmp1.Invoke_O_O_O__O(nil, tmp2, tmp3.Invoke_O_O_O_O_O__O(tmp4, tmp5, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))) }









func A_arbace_java_io__init_A_Unit54__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_101)); v__1927000386__auto____1 = A_arbace_java_io__init_A_const_100; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_469 any = A_arbace_java_io__init_A_const_102.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = v__1927000386__auto____1; if linked_470 == nil { tmp3 = ifn_471.Invoke_O__O(arg_472) } else { tmp3 = linked_470.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_469, arg_472) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_java_io__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_105)); var tmp5 *lang.Var = A_arbace_java_io__init_A_const_100; var tmp6 *jrt.String = Lit_118; var tmp7 any = A_arbace_java_io_eval1661000232_fn__1661000233_A_New(); var tmp8 *jrt.Class
						var fncls__473 /*line :298:1*/*jrt.Class = A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class




	if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class = fncls__473d; tmp8 = fncls__473d } else { tmp8 = fncls__473 }
//line :298:1
	var tmp9 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_103; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_104)); return A_arbace_java_io__init_A_const_100 } }






func A_arbace_java_io__init_A_Unit55__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_106; var tmp3 any = A_arbace_java_io_eval1661000236_fn__1661000237_A_New(); var tmp4 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class = fncls__474d; tmp4 = fncls__474d } else { tmp4 = fncls__474 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_java_io__init_A_Unit56__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_107; var tmp3 any = A_arbace_java_io_eval1661000240_fn__1661000241_A_New(); var tmp4 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class = fncls__475d; tmp4 = fncls__475d } else { tmp4 = fncls__475 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_java_io__init_A_Unit57__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_108; var tmp3 any = A_arbace_java_io_eval1661000244_fn__1661000245_A_New(); var tmp4 *jrt.Class; var fncls__476 *jrt.Class = A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class; if fncls__476 == nil { var fncls__476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class = fncls__476d; tmp4 = fncls__476d } else { tmp4 = fncls__476 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit58__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_109; var tmp3 any = A_arbace_java_io_eval1661000248_fn__1661000249_A_New(); var tmp4 *jrt.Class; var fncls__477 *jrt.Class = A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class; if fncls__477 == nil { var fncls__477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class = fncls__477d; tmp4 = fncls__477d } else { tmp4 = fncls__477 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_java_io__init_A_Unit59__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_110; var tmp3 any = A_arbace_java_io_eval1661000252_fn__1661000253_A_New(); var tmp4 *jrt.Class; var fncls__478 *jrt.Class = A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class; if fncls__478 == nil { var fncls__478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class = fncls__478d; tmp4 = fncls__478d } else { tmp4 = fncls__478 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_java_io__init_A_Unit60__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_111; var tmp3 any = A_arbace_java_io_eval1661000256_fn__1661000257_A_New(); var tmp4 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class; if fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class = fncls__479d; tmp4 = fncls__479d } else { tmp4 = fncls__479 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit61__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_112; var tmp3 any = A_arbace_java_io_eval1661000260_fn__1661000261_A_New(); var tmp4 *jrt.Class; var fncls__480 *jrt.Class = A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class; if fncls__480 == nil { var fncls__480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class = fncls__480d; tmp4 = fncls__480d } else { tmp4 = fncls__480 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit62__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_113; var tmp3 any = A_arbace_java_io_eval1661000264_fn__1661000265_A_New(); var tmp4 *jrt.Class; var fncls__481 *jrt.Class = A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class; if fncls__481 == nil { var fncls__481d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class = fncls__481d; tmp4 = fncls__481d } else { tmp4 = fncls__481 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit63__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_114; var tmp3 any = A_arbace_java_io_eval1661000268_fn__1661000269_A_New(); var tmp4 *jrt.Class; var fncls__482 *jrt.Class = A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class; if fncls__482 == nil { var fncls__482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class = fncls__482d; tmp4 = fncls__482d } else { tmp4 = fncls__482 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_java_io__init_A_Unit64__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_115; var tmp3 any = A_arbace_java_io_eval1661000272_fn__1661000273_A_New(); var tmp4 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class = fncls__483d; tmp4 = fncls__483d } else { tmp4 = fncls__483 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit65__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_116; var tmp3 any = A_arbace_java_io_eval1661000276_fn__1661000277_A_New(); var tmp4 *jrt.Class; var fncls__484 *jrt.Class = A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class; if fncls__484 == nil { var fncls__484d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class = fncls__484d; tmp4 = fncls__484d } else { tmp4 = fncls__484 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit66__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_117; var tmp3 any = A_arbace_java_io_eval1661000280_fn__1661000281_A_New(); var tmp4 *jrt.Class; var fncls__485 *jrt.Class = A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class; if fncls__485 == nil { var fncls__485d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class = fncls__485d; tmp4 = fncls__485d } else { tmp4 = fncls__485 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit67__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 any = A_arbace_java_io_eval1661000284_fn__1661000285_A_New(); var tmp4 *jrt.Class; var fncls__486 *jrt.Class = A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class; if fncls__486 == nil { var fncls__486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class = fncls__486d; tmp4 = fncls__486d } else { tmp4 = fncls__486 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit68__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 any = A_arbace_java_io_eval1661000288_fn__1661000289_A_New(); var tmp4 *jrt.Class; var fncls__487 *jrt.Class = A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class; if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class = fncls__487d; tmp4 = fncls__487d } else { tmp4 = fncls__487 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit69__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 any = A_arbace_java_io_eval1661000292_fn__1661000293_A_New(); var tmp4 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class; if fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class = fncls__488d; tmp4 = fncls__488d } else { tmp4 = fncls__488 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit70__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 any = A_arbace_java_io_eval1661000296_fn__1661000297_A_New(); var tmp4 *jrt.Class; var fncls__489 *jrt.Class = A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class; if fncls__489 == nil { var fncls__489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class = fncls__489d; tmp4 = fncls__489d } else { tmp4 = fncls__489 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit71__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 any = A_arbace_java_io_eval1661000300_fn__1661000301_A_New(); var tmp4 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class = fncls__490d; tmp4 = fncls__490d } else { tmp4 = fncls__490 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit72__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 any = A_arbace_java_io_eval1661000304_fn__1661000305_A_New(); var tmp4 *jrt.Class; var fncls__491 *jrt.Class = A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class; if fncls__491 == nil { var fncls__491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class = fncls__491d; tmp4 = fncls__491d } else { tmp4 = fncls__491 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit73__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_118; var tmp2 any = A_arbace_java_io_copy_A_New(); var tmp3 *jrt.Class; var fncls__492 *jrt.Class = A_arbace_java_io_copy_A_fn_class; if fncls__492 == nil { var fncls__492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, true); A_arbace_java_io_copy_A_fn_class = fncls__492d; tmp3 = fncls__492d } else { tmp3 = fncls__492 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_119)); return A_arbace_java_io__init_A_const_118 }
















func A_arbace_java_io__init_A_Unit74__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_120; var tmp2 any = A_arbace_java_io_as_relative_path_A_New(); var tmp3 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_java_io_as_relative_path_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_java_io_as_relative_path_A_fn_class = fncls__493d; tmp3 = fncls__493d } else { tmp3 = fncls__493 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_121)); return A_arbace_java_io__init_A_const_120 }









func A_arbace_java_io__init_A_Unit75__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_122; var tmp2 any = A_arbace_java_io_file_A_New(); var tmp3 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_java_io_file_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, true); A_arbace_java_io_file_A_fn_class = fncls__494d; tmp3 = fncls__494d } else { tmp3 = fncls__494 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_123)); return A_arbace_java_io__init_A_const_122 }











func A_arbace_java_io__init_A_Unit76__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_124; var tmp2 any = A_arbace_java_io_delete_file_A_New(); var tmp3 *jrt.Class; var fncls__495 *jrt.Class = A_arbace_java_io_delete_file_A_fn_class; if fncls__495 == nil { var fncls__495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, true); A_arbace_java_io_delete_file_A_fn_class = fncls__495d; tmp3 = fncls__495d } else { tmp3 = fncls__495 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_125)); return A_arbace_java_io__init_A_const_124 }







func A_arbace_java_io__init_A_Unit77__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_126; var tmp2 any = A_arbace_java_io_make_parents_A_New(); var tmp3 *jrt.Class; var fncls__496 *jrt.Class = A_arbace_java_io_make_parents_A_fn_class; if fncls__496 == nil { var fncls__496d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, true); A_arbace_java_io_make_parents_A_fn_class = fncls__496d; tmp3 = fncls__496d } else { tmp3 = fncls__496 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_127)); return A_arbace_java_io__init_A_const_126 }







func A_arbace_java_io__init_A_Unit78__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(445, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_128; var tmp2 any = A_arbace_java_io_resource_A_New(); var tmp3 *jrt.Class; var fncls__497 *jrt.Class = A_arbace_java_io_resource_A_fn_class; if fncls__497 == nil { var fncls__497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_java_io_resource_A_fn_class = fncls__497d; tmp3 = fncls__497d } else { tmp3 = fncls__497 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_129)); return A_arbace_java_io__init_A_const_128 }



type A_arbace_java_io__init_A struct{ jrt.Object }

var A_arbace_java_io__init_A_const_pool *jrt.RefArray

var A_arbace_java_io__init_A_const_0 *lang.Var

var A_arbace_java_io__init_A_const_1 any

var A_arbace_java_io__init_A_const_2 any

var A_arbace_java_io__init_A_const_3 any

var A_arbace_java_io__init_A_const_4 *lang.Var

var A_arbace_java_io__init_A_const_5 *lang.Var

var A_arbace_java_io__init_A_const_6 *lang.Var

var A_arbace_java_io__init_A_const_7 *lang.Var

var A_arbace_java_io__init_A_const_8 any

var A_arbace_java_io__init_A_const_9 any

var A_arbace_java_io__init_A_const_10 *lang.Var

var A_arbace_java_io__init_A_const_11 any

var A_arbace_java_io__init_A_const_12 *lang.Var

var A_arbace_java_io__init_A_const_13 any

var A_arbace_java_io__init_A_const_14 any

var A_arbace_java_io__init_A_const_15 *jrt.Class

var A_arbace_java_io__init_A_const_16 *lang.Var

var A_arbace_java_io__init_A_const_17 *lang.Var

var A_arbace_java_io__init_A_const_18 *lang.Keyword

var A_arbace_java_io__init_A_const_19 *lang.Var

var A_arbace_java_io__init_A_const_20 any

var A_arbace_java_io__init_A_const_21 *lang.Var

var A_arbace_java_io__init_A_const_22 *lang.Var

var A_arbace_java_io__init_A_const_23 any

var A_arbace_java_io__init_A_const_24 *lang.Keyword

var A_arbace_java_io__init_A_const_25 any

var A_arbace_java_io__init_A_const_26 *lang.Keyword

var A_arbace_java_io__init_A_const_27 *lang.Keyword

var A_arbace_java_io__init_A_const_28 any

var A_arbace_java_io__init_A_const_29 *lang.Keyword

var A_arbace_java_io__init_A_const_30 *lang.Var

var A_arbace_java_io__init_A_const_31 *lang.Var

var A_arbace_java_io__init_A_const_32 *lang.Var

var A_arbace_java_io__init_A_const_33 any

var A_arbace_java_io__init_A_const_34 any

var A_arbace_java_io__init_A_const_35 *lang.Keyword

var A_arbace_java_io__init_A_const_36 any

var A_arbace_java_io__init_A_const_37 any

var A_arbace_java_io__init_A_const_38 *lang.Var

var A_arbace_java_io__init_A_const_39 any

var A_arbace_java_io__init_A_const_40 *lang.Var

var A_arbace_java_io__init_A_const_41 any

var A_arbace_java_io__init_A_const_42 *lang.Var

var A_arbace_java_io__init_A_const_43 *lang.Keyword

var A_arbace_java_io__init_A_const_44 *lang.Keyword

var A_arbace_java_io__init_A_const_45 *jrt.Class

var A_arbace_java_io__init_A_const_46 *jrt.Class

var A_arbace_java_io__init_A_const_47 *jrt.Class

var A_arbace_java_io__init_A_const_48 *jrt.Class

var A_arbace_java_io__init_A_const_49 *lang.Var

var A_arbace_java_io__init_A_const_50 any

var A_arbace_java_io__init_A_const_51 any

var A_arbace_java_io__init_A_const_52 *jrt.Class

var A_arbace_java_io__init_A_const_53 any

var A_arbace_java_io__init_A_const_54 any

var A_arbace_java_io__init_A_const_55 any

var A_arbace_java_io__init_A_const_56 any

var A_arbace_java_io__init_A_const_57 any

var A_arbace_java_io__init_A_const_58 any

var A_arbace_java_io__init_A_const_59 any

var A_arbace_java_io__init_A_const_60 any

var A_arbace_java_io__init_A_const_61 any

var A_arbace_java_io__init_A_const_62 any

var A_arbace_java_io__init_A_const_63 any

var A_arbace_java_io__init_A_const_64 any

var A_arbace_java_io__init_A_const_65 any

var A_arbace_java_io__init_A_const_66 *lang.Var

var A_arbace_java_io__init_A_const_67 any

var A_arbace_java_io__init_A_const_68 *lang.Var

var A_arbace_java_io__init_A_const_69 any

var A_arbace_java_io__init_A_const_70 *lang.Var

var A_arbace_java_io__init_A_const_71 any

var A_arbace_java_io__init_A_const_72 *lang.Var

var A_arbace_java_io__init_A_const_73 any

var A_arbace_java_io__init_A_const_74 *lang.Var

var A_arbace_java_io__init_A_const_75 any

var A_arbace_java_io__init_A_const_76 *lang.Var

var A_arbace_java_io__init_A_const_77 any

var A_arbace_java_io__init_A_const_78 *lang.Var

var A_arbace_java_io__init_A_const_79 any

var A_arbace_java_io__init_A_const_80 *lang.Var

var A_arbace_java_io__init_A_const_81 *lang.Keyword

var A_arbace_java_io__init_A_const_82 *lang.Keyword

var A_arbace_java_io__init_A_const_83 *lang.Keyword

var A_arbace_java_io__init_A_const_84 *lang.Keyword

var A_arbace_java_io__init_A_const_85 any

var A_arbace_java_io__init_A_const_86 *lang.Var

var A_arbace_java_io__init_A_const_87 any

var A_arbace_java_io__init_A_const_88 *lang.Var

var A_arbace_java_io__init_A_const_89 any

var A_arbace_java_io__init_A_const_90 *jrt.Class

var A_arbace_java_io__init_A_const_91 *jrt.Class

var A_arbace_java_io__init_A_const_92 *jrt.Class

var A_arbace_java_io__init_A_const_93 *jrt.Class

var A_arbace_java_io__init_A_const_94 *jrt.Class

var A_arbace_java_io__init_A_const_95 *jrt.Class

var A_arbace_java_io__init_A_const_96 *jrt.Class

var A_arbace_java_io__init_A_const_97 *jrt.Class

var A_arbace_java_io__init_A_const_98 *jrt.Class

var A_arbace_java_io__init_A_const_99 *jrt.Class

var A_arbace_java_io__init_A_const_100 *lang.Var

var A_arbace_java_io__init_A_const_101 any

var A_arbace_java_io__init_A_const_102 *lang.Var

var A_arbace_java_io__init_A_const_103 *lang.Keyword

var A_arbace_java_io__init_A_const_104 *lang.Var

var A_arbace_java_io__init_A_const_105 any

var A_arbace_java_io__init_A_const_106 any

var A_arbace_java_io__init_A_const_107 any

var A_arbace_java_io__init_A_const_108 any

var A_arbace_java_io__init_A_const_109 any

var A_arbace_java_io__init_A_const_110 any

var A_arbace_java_io__init_A_const_111 any

var A_arbace_java_io__init_A_const_112 any

var A_arbace_java_io__init_A_const_113 any

var A_arbace_java_io__init_A_const_114 any

var A_arbace_java_io__init_A_const_115 any

var A_arbace_java_io__init_A_const_116 any

var A_arbace_java_io__init_A_const_117 any

var A_arbace_java_io__init_A_const_118 *lang.Var

var A_arbace_java_io__init_A_const_119 any

var A_arbace_java_io__init_A_const_120 *lang.Var

var A_arbace_java_io__init_A_const_121 any

var A_arbace_java_io__init_A_const_122 *lang.Var

var A_arbace_java_io__init_A_const_123 any

var A_arbace_java_io__init_A_const_124 *lang.Var

var A_arbace_java_io__init_A_const_125 any

var A_arbace_java_io__init_A_const_126 *lang.Var

var A_arbace_java_io__init_A_const_127 any

var A_arbace_java_io__init_A_const_128 *lang.Var

var A_arbace_java_io__init_A_const_129 any

var A_arbace_java_io__init_A_init jrt.ClassInit

func A_arbace_java_io__init_A_Init() { if !A_arbace_java_io__init_A_init.Done() { A_arbace_java_io__init_A_init.Run(A_arbace_java_io__init_A_clinit) } }

func A_arbace_java_io__init_A_clinit() { A_arbace_java_io__init_A_clinit_p0(); A_arbace_java_io__init_A_clinit_p1(); A_arbace_java_io__init_A_clinit_p2(); A_arbace_java_io__init_A_clinit_p3(); A_arbace_java_io__init_A_clinit_p4(); A_arbace_java_io__init_A_clinit_p5(); A_arbace_java_io__init_A_clinit_p6(); A_arbace_java_io__init_A_clinit_p7(); A_arbace_java_io__init_A_clinit_p8(); A_arbace_java_io__init_A_clinit_p9() }

func A_arbace_java_io__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_io__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_61, 175); A_arbace_java_io__init_A_const_0 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[45]); A_arbace_java_io__init_A_const_1 = A_arbace_java_io__init_A_const_pool.A[46]; A_arbace_java_io__init_A_const_2 = A_arbace_java_io__init_A_const_pool.A[47]; A_arbace_java_io__init_A_const_3 = A_arbace_java_io__init_A_const_pool.A[48]; A_arbace_java_io__init_A_const_4 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[49]); A_arbace_java_io__init_A_const_5 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[50]); A_arbace_java_io__init_A_const_6 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[51]); A_arbace_java_io__init_A_const_7 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[52]); A_arbace_java_io__init_A_const_8 = A_arbace_java_io__init_A_const_pool.A[53]; A_arbace_java_io__init_A_const_9 = A_arbace_java_io__init_A_const_pool.A[54]; A_arbace_java_io__init_A_const_10 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[55]); A_arbace_java_io__init_A_const_11 = A_arbace_java_io__init_A_const_pool.A[56] }

func A_arbace_java_io__init_A_clinit_p1() { A_arbace_java_io__init_A_const_12 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[57]); A_arbace_java_io__init_A_const_13 = A_arbace_java_io__init_A_const_pool.A[58]; A_arbace_java_io__init_A_const_14 = A_arbace_java_io__init_A_const_pool.A[59]; A_arbace_java_io__init_A_const_15 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[60]); A_arbace_java_io__init_A_const_16 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[61]); A_arbace_java_io__init_A_const_17 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[62]); A_arbace_java_io__init_A_const_18 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[63]); A_arbace_java_io__init_A_const_19 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[64]); A_arbace_java_io__init_A_const_20 = A_arbace_java_io__init_A_const_pool.A[65]; A_arbace_java_io__init_A_const_21 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[66]); A_arbace_java_io__init_A_const_22 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[67]); A_arbace_java_io__init_A_const_23 = A_arbace_java_io__init_A_const_pool.A[68]; A_arbace_java_io__init_A_const_24 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[69]) }

func A_arbace_java_io__init_A_clinit_p2() { A_arbace_java_io__init_A_const_25 = A_arbace_java_io__init_A_const_pool.A[70]; A_arbace_java_io__init_A_const_26 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[71]); A_arbace_java_io__init_A_const_27 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[72]); A_arbace_java_io__init_A_const_28 = A_arbace_java_io__init_A_const_pool.A[73]; A_arbace_java_io__init_A_const_29 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[74]); A_arbace_java_io__init_A_const_30 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[75]); A_arbace_java_io__init_A_const_31 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[76]); A_arbace_java_io__init_A_const_32 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[77]); A_arbace_java_io__init_A_const_33 = A_arbace_java_io__init_A_const_pool.A[78]; A_arbace_java_io__init_A_const_34 = A_arbace_java_io__init_A_const_pool.A[79]; A_arbace_java_io__init_A_const_35 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[80]); A_arbace_java_io__init_A_const_36 = A_arbace_java_io__init_A_const_pool.A[81]; A_arbace_java_io__init_A_const_37 = A_arbace_java_io__init_A_const_pool.A[82] }

func A_arbace_java_io__init_A_clinit_p3() { A_arbace_java_io__init_A_const_38 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[83]); A_arbace_java_io__init_A_const_39 = A_arbace_java_io__init_A_const_pool.A[84]; A_arbace_java_io__init_A_const_40 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[85]); A_arbace_java_io__init_A_const_41 = A_arbace_java_io__init_A_const_pool.A[86]; A_arbace_java_io__init_A_const_42 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[87]); A_arbace_java_io__init_A_const_43 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[88]); A_arbace_java_io__init_A_const_44 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[89]); A_arbace_java_io__init_A_const_45 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[90]); A_arbace_java_io__init_A_const_46 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[91]); A_arbace_java_io__init_A_const_47 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[92]); A_arbace_java_io__init_A_const_48 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[93]); A_arbace_java_io__init_A_const_49 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[94]) }

func A_arbace_java_io__init_A_clinit_p4() { A_arbace_java_io__init_A_const_50 = A_arbace_java_io__init_A_const_pool.A[95]; A_arbace_java_io__init_A_const_51 = A_arbace_java_io__init_A_const_pool.A[96]; A_arbace_java_io__init_A_const_52 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[97]); A_arbace_java_io__init_A_const_53 = A_arbace_java_io__init_A_const_pool.A[98]; A_arbace_java_io__init_A_const_54 = A_arbace_java_io__init_A_const_pool.A[99]; A_arbace_java_io__init_A_const_55 = A_arbace_java_io__init_A_const_pool.A[100]; A_arbace_java_io__init_A_const_56 = A_arbace_java_io__init_A_const_pool.A[101]; A_arbace_java_io__init_A_const_57 = A_arbace_java_io__init_A_const_pool.A[102]; A_arbace_java_io__init_A_const_58 = A_arbace_java_io__init_A_const_pool.A[103]; A_arbace_java_io__init_A_const_59 = A_arbace_java_io__init_A_const_pool.A[104]; A_arbace_java_io__init_A_const_60 = A_arbace_java_io__init_A_const_pool.A[105]; A_arbace_java_io__init_A_const_61 = A_arbace_java_io__init_A_const_pool.A[106]; A_arbace_java_io__init_A_const_62 = A_arbace_java_io__init_A_const_pool.A[107]; A_arbace_java_io__init_A_const_63 = A_arbace_java_io__init_A_const_pool.A[108]; A_arbace_java_io__init_A_const_64 = A_arbace_java_io__init_A_const_pool.A[109] }

func A_arbace_java_io__init_A_clinit_p5() { A_arbace_java_io__init_A_const_65 = A_arbace_java_io__init_A_const_pool.A[110]; A_arbace_java_io__init_A_const_66 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[111]); A_arbace_java_io__init_A_const_67 = A_arbace_java_io__init_A_const_pool.A[112]; A_arbace_java_io__init_A_const_68 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[113]); A_arbace_java_io__init_A_const_69 = A_arbace_java_io__init_A_const_pool.A[114]; A_arbace_java_io__init_A_const_70 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[115]); A_arbace_java_io__init_A_const_71 = A_arbace_java_io__init_A_const_pool.A[116]; A_arbace_java_io__init_A_const_72 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[117]); A_arbace_java_io__init_A_const_73 = A_arbace_java_io__init_A_const_pool.A[118]; A_arbace_java_io__init_A_const_74 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[119]); A_arbace_java_io__init_A_const_75 = A_arbace_java_io__init_A_const_pool.A[120]; A_arbace_java_io__init_A_const_76 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[121]); A_arbace_java_io__init_A_const_77 = A_arbace_java_io__init_A_const_pool.A[122] }

func A_arbace_java_io__init_A_clinit_p6() { A_arbace_java_io__init_A_const_78 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[123]); A_arbace_java_io__init_A_const_79 = A_arbace_java_io__init_A_const_pool.A[124]; A_arbace_java_io__init_A_const_80 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[125]); A_arbace_java_io__init_A_const_81 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[126]); A_arbace_java_io__init_A_const_82 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[127]); A_arbace_java_io__init_A_const_83 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[128]); A_arbace_java_io__init_A_const_84 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[129]); A_arbace_java_io__init_A_const_85 = A_arbace_java_io__init_A_const_pool.A[130]; A_arbace_java_io__init_A_const_86 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[131]); A_arbace_java_io__init_A_const_87 = A_arbace_java_io__init_A_const_pool.A[132]; A_arbace_java_io__init_A_const_88 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[133]); A_arbace_java_io__init_A_const_89 = A_arbace_java_io__init_A_const_pool.A[134]; A_arbace_java_io__init_A_const_90 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[135]) }

func A_arbace_java_io__init_A_clinit_p7() { A_arbace_java_io__init_A_const_91 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[136]); A_arbace_java_io__init_A_const_92 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[137]); A_arbace_java_io__init_A_const_93 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[138]); A_arbace_java_io__init_A_const_94 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[139]); A_arbace_java_io__init_A_const_95 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[140]); A_arbace_java_io__init_A_const_96 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[141]); A_arbace_java_io__init_A_const_97 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[142]); A_arbace_java_io__init_A_const_98 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[143]); A_arbace_java_io__init_A_const_99 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[144]); A_arbace_java_io__init_A_const_100 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[145]); A_arbace_java_io__init_A_const_101 = A_arbace_java_io__init_A_const_pool.A[146]; A_arbace_java_io__init_A_const_102 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[147]) }

func A_arbace_java_io__init_A_clinit_p8() { A_arbace_java_io__init_A_const_103 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[148]); A_arbace_java_io__init_A_const_104 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[149]); A_arbace_java_io__init_A_const_105 = A_arbace_java_io__init_A_const_pool.A[150]; A_arbace_java_io__init_A_const_106 = A_arbace_java_io__init_A_const_pool.A[151]; A_arbace_java_io__init_A_const_107 = A_arbace_java_io__init_A_const_pool.A[152]; A_arbace_java_io__init_A_const_108 = A_arbace_java_io__init_A_const_pool.A[153]; A_arbace_java_io__init_A_const_109 = A_arbace_java_io__init_A_const_pool.A[154]; A_arbace_java_io__init_A_const_110 = A_arbace_java_io__init_A_const_pool.A[155]; A_arbace_java_io__init_A_const_111 = A_arbace_java_io__init_A_const_pool.A[156]; A_arbace_java_io__init_A_const_112 = A_arbace_java_io__init_A_const_pool.A[157]; A_arbace_java_io__init_A_const_113 = A_arbace_java_io__init_A_const_pool.A[158]; A_arbace_java_io__init_A_const_114 = A_arbace_java_io__init_A_const_pool.A[159]; A_arbace_java_io__init_A_const_115 = A_arbace_java_io__init_A_const_pool.A[160]; A_arbace_java_io__init_A_const_116 = A_arbace_java_io__init_A_const_pool.A[161]; A_arbace_java_io__init_A_const_117 = A_arbace_java_io__init_A_const_pool.A[162] }

func A_arbace_java_io__init_A_clinit_p9() { A_arbace_java_io__init_A_const_118 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[163]); A_arbace_java_io__init_A_const_119 = A_arbace_java_io__init_A_const_pool.A[164]; A_arbace_java_io__init_A_const_120 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[165]); A_arbace_java_io__init_A_const_121 = A_arbace_java_io__init_A_const_pool.A[166]; A_arbace_java_io__init_A_const_122 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[167]); A_arbace_java_io__init_A_const_123 = A_arbace_java_io__init_A_const_pool.A[168]; A_arbace_java_io__init_A_const_124 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[169]); A_arbace_java_io__init_A_const_125 = A_arbace_java_io__init_A_const_pool.A[170]; A_arbace_java_io__init_A_const_126 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[171]); A_arbace_java_io__init_A_const_127 = A_arbace_java_io__init_A_const_pool.A[172]; A_arbace_java_io__init_A_const_128 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[173]); A_arbace_java_io__init_A_const_129 = A_arbace_java_io__init_A_const_pool.A[174] }

func A_arbace_java_io__init_A_New() *A_arbace_java_io__init_A { A_arbace_java_io__init_A_Init(); t := &A_arbace_java_io__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io__init_A) Ctor() {}

func (t *A_arbace_java_io__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_io__init_A_class }

func (t *A_arbace_java_io__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io__init_A); return ok }

func A_arbace_java_io__init_A_Cast(x any) *A_arbace_java_io__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io__init_A_class)) }; return v }
