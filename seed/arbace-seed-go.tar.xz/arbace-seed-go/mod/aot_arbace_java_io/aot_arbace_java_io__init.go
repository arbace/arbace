//line aot_arbace_java_io__init.ae:1
package aot_arbace_java_io

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_io__init_A_Load__O() any { A_arbace_java_io__init_A_Init(); jrt.StartCheck(); A_arbace_java_io__init_A_Unit0__O(); A_arbace_java_io__init_A_Unit1__O(); A_arbace_java_io__init_A_Unit2__O(); A_arbace_java_io__init_A_Unit3__O(); A_arbace_java_io__init_A_Unit4__O(); A_arbace_java_io__init_A_Unit5__O(); A_arbace_java_io__init_A_Unit6__O(); A_arbace_java_io__init_A_Unit7__O(); A_arbace_java_io__init_A_Unit8__O(); A_arbace_java_io__init_A_Unit9__O(); A_arbace_java_io__init_A_Unit10__O(); A_arbace_java_io__init_A_Unit11__O(); A_arbace_java_io__init_A_Unit12__O(); A_arbace_java_io__init_A_Unit13__O(); A_arbace_java_io__init_A_Unit14__O(); A_arbace_java_io__init_A_Unit15__O(); A_arbace_java_io__init_A_Unit16__O(); A_arbace_java_io__init_A_Unit17__O(); A_arbace_java_io__init_A_Unit18__O(); A_arbace_java_io__init_A_Unit19__O(); A_arbace_java_io__init_A_Unit20__O(); A_arbace_java_io__init_A_Unit21__O(); A_arbace_java_io__init_A_Unit22__O(); A_arbace_java_io__init_A_Unit23__O(); A_arbace_java_io__init_A_Unit24__O(); A_arbace_java_io__init_A_Unit25__O(); A_arbace_java_io__init_A_Unit26__O(); A_arbace_java_io__init_A_Unit27__O(); A_arbace_java_io__init_A_Unit28__O(); A_arbace_java_io__init_A_Unit29__O(); A_arbace_java_io__init_A_Unit30__O(); A_arbace_java_io__init_A_Unit31__O(); A_arbace_java_io__init_A_Unit32__O(); A_arbace_java_io__init_A_Unit33__O(); A_arbace_java_io__init_A_Unit34__O(); A_arbace_java_io__init_A_Unit35__O(); A_arbace_java_io__init_A_Unit36__O(); A_arbace_java_io__init_A_Unit37__O(); A_arbace_java_io__init_A_Unit38__O(); A_arbace_java_io__init_A_Unit39__O(); A_arbace_java_io__init_A_Unit40__O(); A_arbace_java_io__init_A_Unit41__O(); A_arbace_java_io__init_A_Unit42__O(); A_arbace_java_io__init_A_Unit43__O(); A_arbace_java_io__init_A_Unit44__O(); A_arbace_java_io__init_A_Unit45__O(); A_arbace_java_io__init_A_Unit46__O(); A_arbace_java_io__init_A_Unit47__O(); A_arbace_java_io__init_A_Unit48__O(); A_arbace_java_io__init_A_Unit49__O(); A_arbace_java_io__init_A_Unit50__O(); A_arbace_java_io__init_A_Unit51__O(); A_arbace_java_io__init_A_Unit52__O(); A_arbace_java_io__init_A_Unit53__O(); A_arbace_java_io__init_A_Unit54__O(); A_arbace_java_io__init_A_Unit55__O(); A_arbace_java_io__init_A_Unit56__O(); A_arbace_java_io__init_A_Unit57__O(); A_arbace_java_io__init_A_Unit58__O(); A_arbace_java_io__init_A_Unit59__O(); A_arbace_java_io__init_A_Unit60__O(); A_arbace_java_io__init_A_Unit61__O(); A_arbace_java_io__init_A_Unit62__O(); A_arbace_java_io__init_A_Unit63__O(); A_arbace_java_io__init_A_Unit64__O(); A_arbace_java_io__init_A_Unit65__O(); A_arbace_java_io__init_A_Unit66__O(); A_arbace_java_io__init_A_Unit67__O(); A_arbace_java_io__init_A_Unit68__O(); A_arbace_java_io__init_A_Unit69__O(); A_arbace_java_io__init_A_Unit70__O(); A_arbace_java_io__init_A_Unit71__O(); A_arbace_java_io__init_A_Unit72__O(); A_arbace_java_io__init_A_Unit73__O(); A_arbace_java_io__init_A_Unit74__O(); A_arbace_java_io__init_A_Unit75__O(); A_arbace_java_io__init_A_Unit76__O(); A_arbace_java_io__init_A_Unit77__O(); A_arbace_java_io__init_A_Unit78__O(); return nil }



func A_arbace_java_io__init_A_Unit0__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_java_io__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io__init_A_const_1) }
//line :9:1
func A_arbace_java_io__init_A_Unit1__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_2)) }
//line :9:1
func A_arbace_java_io__init_A_Unit2__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_java_io__init_A_Unit3__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1)).Equals_O__Z(A_arbace_java_io__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_java_io_eval1661000008_fn__1661000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }















func A_arbace_java_io__init_A_Unit4__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); return A_arbace_java_io__init_A_const_4.Set_O__O(jrt.Boolean_FALSE.Ref()) }

func A_arbace_java_io__init_A_Unit5__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_5; var tmp2 any; var root_8 any = A_arbace_java_io__init_A_const_6.GetRawRoot__O(); var linked_9 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_8, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_10 lang.IFn; if



	linked_9 == nil { ifn_10 = lang.IFn_Cast(root_8) } else { ifn_10 = nil }; var arg_11 any; var root_3 any = A_arbace_java_io__init_A_const_7.GetRawRoot__O(); var linked_4 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_5 lang.IFn; if linked_4 == nil { ifn_5 = lang.IFn_Cast(root_3) } else { ifn_5 = nil }; var arg_6 any = jrt.Byte_TYPE.Ref(); var arg_7 any = A_arbace_java_io__init_A_const_8; if linked_4 == nil { arg_11 = ifn_5.Invoke_O_O__O(arg_6, arg_7) } else { arg_11 = linked_4.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_3, arg_6, arg_7) }; if linked_9 == nil { tmp2 = ifn_10.Invoke_O__O(arg_11) } else { tmp2 = linked_9.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_8, arg_11) }; /*line :27:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_io__init_A_const_5; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_9)); return A_arbace_java_io__init_A_const_5 }





func A_arbace_java_io__init_A_Unit6__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_10; var tmp2 any; var root_17 any = A_arbace_java_io__init_A_const_6.GetRawRoot__O(); var linked_18 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_17, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_19 lang.IFn; if


	linked_18 == nil { ifn_19 = lang.IFn_Cast(root_17) } else { ifn_19 = nil }; var arg_20 any; var root_12 any = A_arbace_java_io__init_A_const_7.GetRawRoot__O(); var linked_13 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_12, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_14 lang.IFn; if linked_13 == nil { ifn_14 = lang.IFn_Cast(root_12) } else { ifn_14 = nil }; var arg_15 any = jrt.Character_TYPE.Ref(); var arg_16 any = A_arbace_java_io__init_A_const_8; if linked_13 == nil { arg_20 = ifn_14.Invoke_O_O__O(arg_15, arg_16) } else { arg_20 = linked_13.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_12, arg_15, arg_16) }; if linked_18 == nil { tmp2 = ifn_19.Invoke_O__O(arg_20) } else { tmp2 = linked_18.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_17, arg_20) }; /*line :33:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_io__init_A_const_10; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_11)); return A_arbace_java_io__init_A_const_10 }




func A_arbace_java_io__init_A_Unit7__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_13)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_12; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_14)); A_arbace_java_io__init_A_const_12.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_12 } }
//line :38:1
func A_arbace_java_io__init_A_Unit8__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_15 }
//line :38:1
func A_arbace_java_io__init_A_Unit9__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_64) }
//line :38:1
func A_arbace_java_io__init_A_Unit10__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_12, A_arbace_java_io__init_A_const_20) }
//line :38:1
func A_arbace_java_io__init_A_Unit11__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_23; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_25; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_12; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_28; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 any; var root_38 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_42 any; var root_33 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_34 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_33, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_35 lang.IFn; if linked_34 == nil { ifn_35 = lang.IFn_Cast(root_33) } else { ifn_35 = nil }; var arg_36 any = A_arbace_java_io__init_A_const_33; var arg_37 any; var root_28 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_java_io__init_A_const_34; var arg_32 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12)); if linked_29 == nil { arg_37 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { arg_37 = linked_29.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; if linked_34 == nil { arg_42 = ifn_35.Invoke_O_O__O(arg_36, arg_37) } else { arg_42 = linked_34.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_33, arg_36, arg_37) }; if linked_39 == nil { tmp13 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { tmp13 = linked_39.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_java_io_eval1661000024_fn__1661000025_A_New(); var tmp16 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class = fncls__43d; tmp16 = fncls__43d } else { tmp16 = fncls__43 }; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 any; var root_54 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_55 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_54, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_56 lang.IFn; if linked_55 == nil { ifn_56 = lang.IFn_Cast(root_54) } else { ifn_56 = nil }; var arg_57 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_58 any; var root_49 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = A_arbace_java_io__init_A_const_36; var arg_53 any; var root_44 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_45 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_44, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_46 lang.IFn; if linked_45 == nil { ifn_46 = lang.IFn_Cast(root_44) } else { ifn_46 = nil }; var arg_47 any = A_arbace_java_io__init_A_const_37; var arg_48 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12)); if linked_45 == nil { arg_53 = ifn_46.Invoke_O_O__O(arg_47, arg_48) } else { arg_53 = linked_45.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_44, arg_47, arg_48) }; if linked_50 == nil { arg_58 = ifn_51.Invoke_O_O__O(arg_52, arg_53) } else { arg_58 = linked_50.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_49, arg_52, arg_53) }; if linked_55 == nil { tmp18 = ifn_56.Invoke_O_O__O(arg_57, arg_58) } else { tmp18 = linked_55.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_54, arg_57, arg_58) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_java_io_eval1661000024_fn__1661000033_A_New(); var tmp21 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class = fncls__59d; tmp21 = fncls__59d } else { tmp21 = fncls__59 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil))))) }
//line :38:1
func A_arbace_java_io__init_A_Unit12__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var root_78 any = A_arbace_java_io__init_A_const_38.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); if linked_79 == nil { return ifn_80.Invoke_O__O(arg_81) } else { return linked_79.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_78, arg_81) } }
//line :38:1
func A_arbace_java_io__init_A_Unit13__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_39 }




func A_arbace_java_io__init_A_Unit14__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_40; var tmp2 any = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New(); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_41)); return A_arbace_java_io__init_A_const_40 }



func A_arbace_java_io__init_A_Unit15__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_43; var tmp4 any = A_arbace_java_io_eval1661000047_fn__1661000048_A_New(); var tmp5 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class; if fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class = fncls__83d; tmp5 = fncls__83d } else { tmp5 = fncls__83 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_java_io__init_A_const_44; var tmp8 any = A_arbace_java_io_eval1661000047_fn__1661000050_A_New(); var tmp9 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class; if fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class = fncls__84d; tmp9 = fncls__84d } else { tmp9 = fncls__84 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit16__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 any = A_arbace_java_io_eval1661000053_fn__1661000054_A_New(); var tmp6 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class = fncls__91d; tmp6 = fncls__91d } else { tmp6 = fncls__91 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 any = A_arbace_java_io_eval1661000053_fn__1661000056_A_New(); var tmp10 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class = fncls__92d; tmp10 = fncls__92d } else { tmp10 = fncls__92 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit17__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 any = A_arbace_java_io_eval1661000059_fn__1661000060_A_New(); var tmp6 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class; if fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class = fncls__99d; tmp6 = fncls__99d } else { tmp6 = fncls__99 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 any = A_arbace_java_io_eval1661000059_fn__1661000062_A_New(); var tmp10 *jrt.Class; var fncls__100 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class; if fncls__100 == nil { var fncls__100d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class = fncls__100d; tmp10 = fncls__100d } else { tmp10 = fncls__100 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit18__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 any = A_arbace_java_io_eval1661000065_fn__1661000066_A_New(); var tmp6 *jrt.Class; var fncls__107 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class; if fncls__107 == nil { var fncls__107d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class = fncls__107d; tmp6 = fncls__107d } else { tmp6 = fncls__107 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 any = A_arbace_java_io_eval1661000065_fn__1661000068_A_New(); var tmp10 *jrt.Class; var fncls__108 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class; if fncls__108 == nil { var fncls__108d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class = fncls__108d; tmp10 = fncls__108d } else { tmp10 = fncls__108 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit19__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 any = A_arbace_java_io_eval1661000071_fn__1661000072_A_New(); var tmp6 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class = fncls__115d; tmp6 = fncls__115d } else { tmp6 = fncls__115 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 any = A_arbace_java_io_eval1661000071_fn__1661000074_A_New(); var tmp10 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class = fncls__116d; tmp10 = fncls__116d } else { tmp10 = fncls__116 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
























func A_arbace_java_io__init_A_Unit20__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_50)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_49; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_49; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_51)); A_arbace_java_io__init_A_const_49.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_49 } }
//line :72:1
func A_arbace_java_io__init_A_Unit21__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_52 }
//line :72:1
func A_arbace_java_io__init_A_Unit22__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_78) }
//line :72:1
func A_arbace_java_io__init_A_Unit23__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_49, A_arbace_java_io__init_A_const_53) }
//line :72:1
func A_arbace_java_io__init_A_Unit24__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_54; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_55; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_49; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_56; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 any; var root_140 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_144 any; var root_135 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_136 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_135, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_137 lang.IFn; if linked_136 == nil { ifn_137 = lang.IFn_Cast(root_135) } else { ifn_137 = nil }; var arg_138 any = A_arbace_java_io__init_A_const_57; var arg_139 any; var root_130 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = A_arbace_java_io__init_A_const_58; var arg_134 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_131 == nil { arg_139 = ifn_132.Invoke_O_O__O(arg_133, arg_134) } else { arg_139 = linked_131.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_130, arg_133, arg_134) }; if linked_136 == nil { arg_144 = ifn_137.Invoke_O_O__O(arg_138, arg_139) } else { arg_144 = linked_136.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_135, arg_138, arg_139) }; if linked_141 == nil { tmp13 = ifn_142.Invoke_O_O__O(arg_143, arg_144) } else { tmp13 = linked_141.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_140, arg_143, arg_144) }; var tmp14 any = tmp13; var tmp15 any = A_arbace_java_io_eval1661000091_fn__1661000092_A_New(); var tmp16 *jrt.Class; var fncls__145 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class; if fncls__145 == nil { var fncls__145d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class = fncls__145d; tmp16 = fncls__145d } else { tmp16 = fncls__145 }; var tmp17 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var tmp18 any; var root_156 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_160 any; var root_151 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_153 lang.IFn; if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = A_arbace_java_io__init_A_const_59; var arg_155 any; var root_146 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = A_arbace_java_io__init_A_const_60; var arg_150 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_147 == nil { arg_155 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { arg_155 = linked_147.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) }; if linked_152 == nil { arg_160 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { arg_160 = linked_152.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }; if linked_157 == nil { tmp18 = ifn_158.Invoke_O_O__O(arg_159, arg_160) } else { tmp18 = linked_157.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_156, arg_159, arg_160) }; var tmp19 any = tmp18; var tmp20 any = A_arbace_java_io_eval1661000091_fn__1661000102_A_New(); var tmp21 *jrt.Class; var fncls__161 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class; if fncls__161 == nil { var fncls__161d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class = fncls__161d; tmp21 = fncls__161d } else { tmp21 = fncls__161 }; var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 any; var root_172 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_176 any; var root_167 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = A_arbace_java_io__init_A_const_61; var arg_171 any; var root_162 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_163 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_162, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_164 lang.IFn; if linked_163 == nil { ifn_164 = lang.IFn_Cast(root_162) } else { ifn_164 = nil }; var arg_165 any = A_arbace_java_io__init_A_const_62; var arg_166 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_163 == nil { arg_171 = ifn_164.Invoke_O_O__O(arg_165, arg_166) } else { arg_171 = linked_163.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_162, arg_165, arg_166) }; if linked_168 == nil { arg_176 = ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { arg_176 = linked_168.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) }; if linked_173 == nil { tmp23 = ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { tmp23 = linked_173.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) }; var tmp24 any = tmp23; var tmp25 any = A_arbace_java_io_eval1661000091_fn__1661000112_A_New(); var tmp26 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class = fncls__177d; tmp26 = fncls__177d } else { tmp26 = fncls__177 }; var tmp27 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var tmp28 any; var root_188 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_188, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_190 lang.IFn; if linked_189 == nil { ifn_190 = lang.IFn_Cast(root_188) } else { ifn_190 = nil }; var arg_191 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_192 any; var root_183 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = A_arbace_java_io__init_A_const_63; var arg_187 any; var root_178 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = A_arbace_java_io__init_A_const_64; var arg_182 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_179 == nil { arg_187 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { arg_187 = linked_179.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }; if linked_184 == nil { arg_192 = ifn_185.Invoke_O_O__O(arg_186, arg_187) } else { arg_192 = linked_184.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_183, arg_186, arg_187) }; if linked_189 == nil { tmp28 = ifn_190.Invoke_O_O__O(arg_191, arg_192) } else { tmp28 = linked_189.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_188, arg_191, arg_192) }; var tmp29 any = tmp28; var tmp30 any = A_arbace_java_io_eval1661000091_fn__1661000122_A_New(); var tmp31 *jrt.Class; var fncls__193 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class; if fncls__193 == nil { var fncls__193d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class = fncls__193d; tmp31 = fncls__193d } else { tmp31 = fncls__193 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, tmp22, tmp24, tmp27, tmp29, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil))))) }
//line :72:1
func A_arbace_java_io__init_A_Unit25__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var root_212 any = A_arbace_java_io__init_A_const_38.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); if linked_213 == nil { return ifn_214.Invoke_O__O(arg_215) } else { return linked_213.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_212, arg_215) } }
//line :72:1
func A_arbace_java_io__init_A_Unit26__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_65 }
















func A_arbace_java_io__init_A_Unit27__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_66; var tmp2 any = A_arbace_java_io_reader_A_New(); var tmp3 *jrt.Class; var fncls__216 *jrt.Class = A_arbace_java_io_reader_A_fn_class; if fncls__216 == nil { var fncls__216d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, true); A_arbace_java_io_reader_A_fn_class = fncls__216d; tmp3 = fncls__216d } else { tmp3 = fncls__216 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_67)); return A_arbace_java_io__init_A_const_66 }

















func A_arbace_java_io__init_A_Unit28__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_68; var tmp2 any = A_arbace_java_io_writer_A_New(); var tmp3 *jrt.Class; var fncls__217 *jrt.Class = A_arbace_java_io_writer_A_fn_class; if fncls__217 == nil { var fncls__217d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, true); A_arbace_java_io_writer_A_fn_class = fncls__217d; tmp3 = fncls__217d } else { tmp3 = fncls__217 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_69)); return A_arbace_java_io__init_A_const_68 }
















func A_arbace_java_io__init_A_Unit29__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_70; var tmp2 any = A_arbace_java_io_input_stream_A_New(); var tmp3 *jrt.Class; var fncls__218 *jrt.Class = A_arbace_java_io_input_stream_A_fn_class; if fncls__218 == nil { var fncls__218d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, true); A_arbace_java_io_input_stream_A_fn_class = fncls__218d; tmp3 = fncls__218d } else { tmp3 = fncls__218 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_71)); return A_arbace_java_io__init_A_const_70 }
















func A_arbace_java_io__init_A_Unit30__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_72; var tmp2 any = A_arbace_java_io_output_stream_A_New(); var tmp3 *jrt.Class; var fncls__219 *jrt.Class = A_arbace_java_io_output_stream_A_fn_class; if fncls__219 == nil { var fncls__219d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, true); A_arbace_java_io_output_stream_A_fn_class = fncls__219d; tmp3 = fncls__219d } else { tmp3 = fncls__219 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_73)); return A_arbace_java_io__init_A_const_72 }
















func A_arbace_java_io__init_A_Unit31__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_74; var tmp2 any = A_arbace_java_io_append_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__220 *jrt.Class = A_arbace_java_io_append_QMARK__A_fn_class; if fncls__220 == nil { var fncls__220d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_java_io_append_QMARK__A_fn_class = fncls__220d; tmp3 = fncls__220d } else { tmp3 = fncls__220 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_75)); return A_arbace_java_io__init_A_const_74 }


func A_arbace_java_io__init_A_Unit32__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_76; var tmp2 any = A_arbace_java_io_encoding_A_New(); var tmp3 *jrt.Class; var fncls__221 *jrt.Class = A_arbace_java_io_encoding_A_fn_class; if fncls__221 == nil { var fncls__221d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_java_io_encoding_A_fn_class = fncls__221d; tmp3 = fncls__221d } else { tmp3 = fncls__221 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_77)); return A_arbace_java_io__init_A_const_76 }


func A_arbace_java_io__init_A_Unit33__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_78; var tmp2 any = A_arbace_java_io_buffer_size_A_New(); var tmp3 *jrt.Class; var fncls__222 *jrt.Class = A_arbace_java_io_buffer_size_A_fn_class; if fncls__222 == nil { var fncls__222d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_java_io_buffer_size_A_fn_class = fncls__222d; tmp3 = fncls__222d } else { tmp3 = fncls__222 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_79)); return A_arbace_java_io__init_A_const_78 }


func A_arbace_java_io__init_A_Unit34__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_80; var tmp2 any = A_arbace_java_io__init_A_const_81; var tmp3 any = A_arbace_java_io_fn__1661000144_A_New(); var tmp4 *jrt.Class; var fncls__223 *jrt.Class = A_arbace_java_io_fn__1661000144_A_fn_class; if
						fncls__223 == nil { var fncls__223d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_java_io_fn__1661000144_A_fn_class = fncls__223d; tmp4 = fncls__223d } else { tmp4 = fncls__223 }; var tmp5 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_java_io__init_A_const_82; var tmp7 any = A_arbace_java_io_fn__1661000146_A_New(); var tmp8 *jrt.Class; var fncls__224 *jrt.Class = A_arbace_java_io_fn__1661000146_A_fn_class; if

	fncls__224 == nil { var fncls__224d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_java_io_fn__1661000146_A_fn_class = fncls__224d; tmp8 = fncls__224d } else { tmp8 = fncls__224 }; var tmp9 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_83; var tmp11 any = A_arbace_java_io_fn__1661000148_A_New(); var tmp12 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_java_io_fn__1661000148_A_fn_class; if


	fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_java_io_fn__1661000148_A_fn_class = fncls__225d; tmp12 = fncls__225d } else { tmp12 = fncls__225 }; var tmp13 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 any = A_arbace_java_io__init_A_const_84; var tmp15 any = A_arbace_java_io_fn__1661000150_A_New(); var tmp16 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_java_io_fn__1661000150_A_fn_class; if





	fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_java_io_fn__1661000150_A_fn_class = fncls__226d; tmp16 = fncls__226d } else { tmp16 = fncls__226 }; /*line :167:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp9, tmp10, tmp13, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)))); var tmp17 *lang.Var = A_arbace_java_io__init_A_const_80; tmp17.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_85)); return A_arbace_java_io__init_A_const_80 }









func A_arbace_java_io__init_A_Unit35__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_86; var tmp2 any = A_arbace_java_io_inputstream__GT_reader_A_New(); var tmp3 *jrt.Class; var fncls__227 *jrt.Class = A_arbace_java_io_inputstream__GT_reader_A_fn_class; if fncls__227 == nil { var fncls__227d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_java_io_inputstream__GT_reader_A_fn_class = fncls__227d; tmp3 = fncls__227d } else { tmp3 = fncls__227 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_87)); return A_arbace_java_io__init_A_const_86 }



func A_arbace_java_io__init_A_Unit36__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_88; var tmp2 any = A_arbace_java_io_outputstream__GT_writer_A_New(); var tmp3 *jrt.Class; var fncls__228 *jrt.Class = A_arbace_java_io_outputstream__GT_writer_A_fn_class; if fncls__228 == nil { var fncls__228d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_java_io_outputstream__GT_writer_A_fn_class = fncls__228d; tmp3 = fncls__228d } else { tmp3 = fncls__228 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_89)); return A_arbace_java_io__init_A_const_88 }



func A_arbace_java_io__init_A_Unit37__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_90; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000154_fn__1661000155_A_New(); var tmp8 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class; if


	fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class = fncls__229d; tmp8 = fncls__229d } else { tmp8 = fncls__229 }; var tmp9 any = /*line :185:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit38__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_91; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000158_fn__1661000159_A_New(); var tmp8 *jrt.Class; var fncls__244 *jrt.Class = A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class; if


	fncls__244 == nil { var fncls__244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class = fncls__244d; tmp8 = fncls__244d } else { tmp8 = fncls__244 }; var tmp9 any = /*line :191:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit39__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_92; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_260 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_262 lang.IFn; if

	linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_264 any = A_arbace_java_io__init_A_const_81; var arg_265 any; var tmp5 any = A_arbace_java_io_eval1661000162_fn__1661000163_A_New(); var tmp6 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class; if
	fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class = fncls__259d; tmp6 = fncls__259d } else { tmp6 = fncls__259 }; arg_265 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :199:1*/ linked_261 == nil { tmp4 = ifn_262.Invoke_O_O_O__O(arg_263, arg_264, arg_265) } else { tmp4 = linked_261.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_260, arg_263, arg_264, arg_265) }; return /*line :197:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit40__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_93; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_273 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_275 lang.IFn; if

	linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_277 any = A_arbace_java_io__init_A_const_81; var arg_278 any; var tmp5 any = A_arbace_java_io_eval1661000166_fn__1661000167_A_New(); var tmp6 *jrt.Class; var fncls__272 *jrt.Class = A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class; if
	fncls__272 == nil { var fncls__272d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class = fncls__272d; tmp6 = fncls__272d } else { tmp6 = fncls__272 }; arg_278 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :204:1*/ linked_274 == nil { tmp4 = ifn_275.Invoke_O_O_O__O(arg_276, arg_277, arg_278) } else { tmp4 = linked_274.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_273, arg_276, arg_277, arg_278) }; return /*line :202:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit41__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_94; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_286 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_288 lang.IFn; if

	linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_290 any = A_arbace_java_io__init_A_const_82; var arg_291 any; var tmp5 any = A_arbace_java_io_eval1661000170_fn__1661000171_A_New(); var tmp6 *jrt.Class; var fncls__285 *jrt.Class = A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class; if
	fncls__285 == nil { var fncls__285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class = fncls__285d; tmp6 = fncls__285d } else { tmp6 = fncls__285 }; arg_291 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :209:1*/ linked_287 == nil { tmp4 = ifn_288.Invoke_O_O_O__O(arg_289, arg_290, arg_291) } else { tmp4 = linked_287.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_286, arg_289, arg_290, arg_291) }; return /*line :207:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit42__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_95; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_299 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_301 lang.IFn; if

	linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_303 any = A_arbace_java_io__init_A_const_82; var arg_304 any; var tmp5 any = A_arbace_java_io_eval1661000174_fn__1661000175_A_New(); var tmp6 *jrt.Class; var fncls__298 *jrt.Class = A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class; if
	fncls__298 == nil { var fncls__298d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class = fncls__298d; tmp6 = fncls__298d } else { tmp6 = fncls__298 }; arg_304 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :214:1*/ linked_300 == nil { tmp4 = ifn_301.Invoke_O_O_O__O(arg_302, arg_303, arg_304) } else { tmp4 = linked_300.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_299, arg_302, arg_303, arg_304) }; return /*line :212:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit43__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_96; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 any = A_arbace_java_io_eval1661000178_fn__1661000179_A_New(); var tmp8 *jrt.Class; var fncls__311 *jrt.Class = A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class; if


	fncls__311 == nil { var fncls__311d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class = fncls__311d; tmp8 = fncls__311d } else { tmp8 = fncls__311 }; var tmp9 any = /*line :217:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit44__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_97; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 any = A_arbace_java_io_eval1661000182_fn__1661000183_A_New(); var tmp8 *jrt.Class; var fncls__326 *jrt.Class = A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class; if


	fncls__326 == nil { var fncls__326d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class = fncls__326d; tmp8 = fncls__326d } else { tmp8 = fncls__326 }; var tmp9 any = /*line :223:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit45__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000186_fn__1661000187_A_New(); var tmp8 *jrt.Class; var fncls__341 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class; if


	fncls__341 == nil { var fncls__341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class = fncls__341d; tmp8 = fncls__341d } else { tmp8 = fncls__341 }; var tmp9 any = /*line :229:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000186_fn__1661000189_A_New(); var tmp12 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class; if



	fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class = fncls__342d; tmp12 = fncls__342d } else { tmp12 = fncls__342 }; return /*line :229:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit46__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000192_fn__1661000193_A_New(); var tmp8 *jrt.Class; var fncls__357 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class; if


	fncls__357 == nil { var fncls__357d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class = fncls__357d; tmp8 = fncls__357d } else { tmp8 = fncls__357 }; var tmp9 any = /*line :235:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000192_fn__1661000195_A_New(); var tmp12 *jrt.Class; var fncls__358 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class; if







	fncls__358 == nil { var fncls__358d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class = fncls__358d; tmp12 = fncls__358d } else { tmp12 = fncls__358 }; return /*line :235:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }












func A_arbace_java_io__init_A_Unit47__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000198_fn__1661000199_A_New(); var tmp8 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class; if


	fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class = fncls__373d; tmp8 = fncls__373d } else { tmp8 = fncls__373 }; var tmp9 any = /*line :248:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000198_fn__1661000201_A_New(); var tmp12 *jrt.Class; var fncls__374 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class; if



	fncls__374 == nil { var fncls__374d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class = fncls__374d; tmp12 = fncls__374d } else { tmp12 = fncls__374 }; return /*line :248:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit48__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000204_fn__1661000205_A_New(); var tmp8 *jrt.Class; var fncls__389 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class; if


	fncls__389 == nil { var fncls__389d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class = fncls__389d; tmp8 = fncls__389d } else { tmp8 = fncls__389 }; var tmp9 any = /*line :254:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000204_fn__1661000207_A_New(); var tmp12 *jrt.Class; var fncls__390 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class; if







	fncls__390 == nil { var fncls__390d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class = fncls__390d; tmp12 = fncls__390d } else { tmp12 = fncls__390 }; return /*line :254:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }













func A_arbace_java_io__init_A_Unit49__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_98; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000210_fn__1661000211_A_New(); var tmp8 *jrt.Class; var fncls__405 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class; if


	fncls__405 == nil { var fncls__405d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class = fncls__405d; tmp8 = fncls__405d } else { tmp8 = fncls__405 }; var tmp9 any = /*line :268:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000210_fn__1661000213_A_New(); var tmp12 *jrt.Class; var fncls__406 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class; if



	fncls__406 == nil { var fncls__406d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class = fncls__406d; tmp12 = fncls__406d } else { tmp12 = fncls__406 }; return /*line :268:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit50__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_5.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_422 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_422, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_424 lang.IFn; if

	linked_423 == nil { ifn_424 = lang.IFn_Cast(root_422) } else { ifn_424 = nil }; var arg_425 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_426 any = A_arbace_java_io__init_A_const_83; var arg_427 any; var tmp5 any = A_arbace_java_io_eval1661000216_fn__1661000217_A_New(); var tmp6 *jrt.Class; var fncls__421 *jrt.Class = A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class; if
	fncls__421 == nil { var fncls__421d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class = fncls__421d; tmp6 = fncls__421d } else { tmp6 = fncls__421 }; arg_427 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :276:1*/ linked_423 == nil { tmp4 = ifn_424.Invoke_O_O_O__O(arg_425, arg_426, arg_427) } else { tmp4 = linked_423.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_422, arg_425, arg_426, arg_427) }; return /*line :274:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit51__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_10.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_435 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_437 lang.IFn; if

	linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_439 any = A_arbace_java_io__init_A_const_81; var arg_440 any; var tmp5 any = A_arbace_java_io_eval1661000220_fn__1661000221_A_New(); var tmp6 *jrt.Class; var fncls__434 *jrt.Class = A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class; if
	fncls__434 == nil { var fncls__434d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class = fncls__434d; tmp6 = fncls__434d } else { tmp6 = fncls__434 }; arg_440 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if /*line :281:1*/ linked_436 == nil { tmp4 = ifn_437.Invoke_O_O_O__O(arg_438, arg_439, arg_440) } else { tmp4 = linked_436.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_435, arg_438, arg_439, arg_440) }; return /*line :279:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit52__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_99; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_49.GetRawRoot__O(), A_arbace_java_io__init_A_const_80.GetRawRoot__O()) }



func A_arbace_java_io__init_A_Unit53__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp4 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp5 any = A_arbace_java_io__init_A_const_81; var tmp6 any = A_arbace_java_io_eval1661000226_fn__1661000227_A_New(); var tmp7 *jrt.Class; var fncls__453 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class; if


	fncls__453 == nil { var fncls__453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class = fncls__453d; tmp7 = fncls__453d } else { tmp7 = fncls__453 }; var tmp8 any = /*line :288:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_java_io__init_A_const_82; var tmp10 any = A_arbace_java_io_eval1661000226_fn__1661000229_A_New(); var tmp11 *jrt.Class; var fncls__454 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class; if





	fncls__454 == nil { var fncls__454d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class = fncls__454d; tmp11 = fncls__454d } else { tmp11 = fncls__454 }; return /*line :288:1*/ tmp1.Invoke_O_O_O__O(nil, tmp2, tmp3.Invoke_O_O_O_O_O__O(tmp4, tmp5, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))) }









func A_arbace_java_io__init_A_Unit54__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_101)); v__1927000386__auto____1 = A_arbace_java_io__init_A_const_100; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_469 any = A_arbace_java_io__init_A_const_102.GetRawRoot__O(); var linked_470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_469, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_471 lang.IFn; if linked_470 == nil { ifn_471 = lang.IFn_Cast(root_469) } else { ifn_471 = nil }; var arg_472 any = v__1927000386__auto____1; if linked_470 == nil { tmp3 = ifn_471.Invoke_O__O(arg_472) } else { tmp3 = linked_470.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_469, arg_472) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_java_io__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_105)); var tmp5 *lang.Var = A_arbace_java_io__init_A_const_100; var tmp6 *jrt.String = Lit_118; var tmp7 any = A_arbace_java_io_eval1661000232_fn__1661000233_A_New(); var tmp8 *jrt.Class
						var fncls__473 /*line :298:1*/*jrt.Class = A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class




	if fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class = fncls__473d; tmp8 = fncls__473d } else { tmp8 = fncls__473 }
//line :298:1
	var tmp9 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_103; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_104)); return A_arbace_java_io__init_A_const_100 } }






func A_arbace_java_io__init_A_Unit55__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_106; var tmp3 any = A_arbace_java_io_eval1661000236_fn__1661000237_A_New(); var tmp4 *jrt.Class; var fncls__474 *jrt.Class = A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class; if fncls__474 == nil { var fncls__474d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class = fncls__474d; tmp4 = fncls__474d } else { tmp4 = fncls__474 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_java_io__init_A_Unit56__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_107; var tmp3 any = A_arbace_java_io_eval1661000240_fn__1661000241_A_New(); var tmp4 *jrt.Class; var fncls__475 *jrt.Class = A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class; if fncls__475 == nil { var fncls__475d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class = fncls__475d; tmp4 = fncls__475d } else { tmp4 = fncls__475 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_java_io__init_A_Unit57__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_108; var tmp3 any = A_arbace_java_io_eval1661000244_fn__1661000245_A_New(); var tmp4 *jrt.Class; var fncls__476 *jrt.Class = A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class; if fncls__476 == nil { var fncls__476d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class = fncls__476d; tmp4 = fncls__476d } else { tmp4 = fncls__476 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit58__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_109; var tmp3 any = A_arbace_java_io_eval1661000248_fn__1661000249_A_New(); var tmp4 *jrt.Class; var fncls__477 *jrt.Class = A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class; if fncls__477 == nil { var fncls__477d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class = fncls__477d; tmp4 = fncls__477d } else { tmp4 = fncls__477 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_java_io__init_A_Unit59__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_110; var tmp3 any = A_arbace_java_io_eval1661000252_fn__1661000253_A_New(); var tmp4 *jrt.Class; var fncls__478 *jrt.Class = A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class; if fncls__478 == nil { var fncls__478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class = fncls__478d; tmp4 = fncls__478d } else { tmp4 = fncls__478 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_java_io__init_A_Unit60__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_111; var tmp3 any = A_arbace_java_io_eval1661000256_fn__1661000257_A_New(); var tmp4 *jrt.Class; var fncls__479 *jrt.Class = A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class; if fncls__479 == nil { var fncls__479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class = fncls__479d; tmp4 = fncls__479d } else { tmp4 = fncls__479 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit61__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_112; var tmp3 any = A_arbace_java_io_eval1661000260_fn__1661000261_A_New(); var tmp4 *jrt.Class; var fncls__480 *jrt.Class = A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class; if fncls__480 == nil { var fncls__480d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class = fncls__480d; tmp4 = fncls__480d } else { tmp4 = fncls__480 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit62__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_113; var tmp3 any = A_arbace_java_io_eval1661000264_fn__1661000265_A_New(); var tmp4 *jrt.Class; var fncls__481 *jrt.Class = A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class; if fncls__481 == nil { var fncls__481d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class = fncls__481d; tmp4 = fncls__481d } else { tmp4 = fncls__481 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit63__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_114; var tmp3 any = A_arbace_java_io_eval1661000268_fn__1661000269_A_New(); var tmp4 *jrt.Class; var fncls__482 *jrt.Class = A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class; if fncls__482 == nil { var fncls__482d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class = fncls__482d; tmp4 = fncls__482d } else { tmp4 = fncls__482 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_java_io__init_A_Unit64__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_115; var tmp3 any = A_arbace_java_io_eval1661000272_fn__1661000273_A_New(); var tmp4 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class; if fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class = fncls__483d; tmp4 = fncls__483d } else { tmp4 = fncls__483 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit65__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_116; var tmp3 any = A_arbace_java_io_eval1661000276_fn__1661000277_A_New(); var tmp4 *jrt.Class; var fncls__484 *jrt.Class = A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class; if fncls__484 == nil { var fncls__484d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class = fncls__484d; tmp4 = fncls__484d } else { tmp4 = fncls__484 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit66__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_117; var tmp3 any = A_arbace_java_io_eval1661000280_fn__1661000281_A_New(); var tmp4 *jrt.Class; var fncls__485 *jrt.Class = A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class; if fncls__485 == nil { var fncls__485d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class = fncls__485d; tmp4 = fncls__485d } else { tmp4 = fncls__485 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit67__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 any = A_arbace_java_io_eval1661000284_fn__1661000285_A_New(); var tmp4 *jrt.Class; var fncls__486 *jrt.Class = A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class; if fncls__486 == nil { var fncls__486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class = fncls__486d; tmp4 = fncls__486d } else { tmp4 = fncls__486 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit68__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 any = A_arbace_java_io_eval1661000288_fn__1661000289_A_New(); var tmp4 *jrt.Class; var fncls__487 *jrt.Class = A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class; if fncls__487 == nil { var fncls__487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class = fncls__487d; tmp4 = fncls__487d } else { tmp4 = fncls__487 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit69__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 any = A_arbace_java_io_eval1661000292_fn__1661000293_A_New(); var tmp4 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class; if fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class = fncls__488d; tmp4 = fncls__488d } else { tmp4 = fncls__488 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit70__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 any = A_arbace_java_io_eval1661000296_fn__1661000297_A_New(); var tmp4 *jrt.Class; var fncls__489 *jrt.Class = A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class; if fncls__489 == nil { var fncls__489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class = fncls__489d; tmp4 = fncls__489d } else { tmp4 = fncls__489 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit71__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 any = A_arbace_java_io_eval1661000300_fn__1661000301_A_New(); var tmp4 *jrt.Class; var fncls__490 *jrt.Class = A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class; if fncls__490 == nil { var fncls__490d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class = fncls__490d; tmp4 = fncls__490d } else { tmp4 = fncls__490 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit72__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 any = A_arbace_java_io_eval1661000304_fn__1661000305_A_New(); var tmp4 *jrt.Class; var fncls__491 *jrt.Class = A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class; if fncls__491 == nil { var fncls__491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class = fncls__491d; tmp4 = fncls__491d } else { tmp4 = fncls__491 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit73__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_118; var tmp2 any = A_arbace_java_io_copy_A_New(); var tmp3 *jrt.Class; var fncls__492 *jrt.Class = A_arbace_java_io_copy_A_fn_class; if fncls__492 == nil { var fncls__492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, true); A_arbace_java_io_copy_A_fn_class = fncls__492d; tmp3 = fncls__492d } else { tmp3 = fncls__492 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_119)); return A_arbace_java_io__init_A_const_118 }
















func A_arbace_java_io__init_A_Unit74__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_120; var tmp2 any = A_arbace_java_io_as_relative_path_A_New(); var tmp3 *jrt.Class; var fncls__493 *jrt.Class = A_arbace_java_io_as_relative_path_A_fn_class; if fncls__493 == nil { var fncls__493d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_java_io_as_relative_path_A_fn_class = fncls__493d; tmp3 = fncls__493d } else { tmp3 = fncls__493 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_121)); return A_arbace_java_io__init_A_const_120 }









func A_arbace_java_io__init_A_Unit75__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_122; var tmp2 any = A_arbace_java_io_file_A_New(); var tmp3 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_java_io_file_A_fn_class; if fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, true); A_arbace_java_io_file_A_fn_class = fncls__494d; tmp3 = fncls__494d } else { tmp3 = fncls__494 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_123)); return A_arbace_java_io__init_A_const_122 }











func A_arbace_java_io__init_A_Unit76__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_124; var tmp2 any = A_arbace_java_io_delete_file_A_New(); var tmp3 *jrt.Class; var fncls__495 *jrt.Class = A_arbace_java_io_delete_file_A_fn_class; if fncls__495 == nil { var fncls__495d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, true); A_arbace_java_io_delete_file_A_fn_class = fncls__495d; tmp3 = fncls__495d } else { tmp3 = fncls__495 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_125)); return A_arbace_java_io__init_A_const_124 }







func A_arbace_java_io__init_A_Unit77__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_126; var tmp2 any = A_arbace_java_io_make_parents_A_New(); var tmp3 *jrt.Class; var fncls__496 *jrt.Class = A_arbace_java_io_make_parents_A_fn_class; if fncls__496 == nil { var fncls__496d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, true); A_arbace_java_io_make_parents_A_fn_class = fncls__496d; tmp3 = fncls__496d } else { tmp3 = fncls__496 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_127)); return A_arbace_java_io__init_A_const_126 }







func A_arbace_java_io__init_A_Unit78__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(445, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_128; var tmp2 any = A_arbace_java_io_resource_A_New(); var tmp3 *jrt.Class; var fncls__497 *jrt.Class = A_arbace_java_io_resource_A_fn_class; if fncls__497 == nil { var fncls__497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_java_io_resource_A_fn_class = fncls__497d; tmp3 = fncls__497d } else { tmp3 = fncls__497 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_129)); return A_arbace_java_io__init_A_const_128 }



type A_arbace_java_io__init_A struct{ jrt.Object }

var A_arbace_java_io__init_A_const_pool *jrt.RefArray

var A_arbace_java_io__init_A_const_0 *lang.Var

var A_arbace_java_io__init_A_const_1 any

var A_arbace_java_io__init_A_const_2 any

var A_arbace_java_io__init_A_const_3 any

var A_arbace_java_io__init_A_const_4 *lang.Var

var A_arbace_java_io__init_A_const_5 *lang.Var

var A_arbace_java_io__init_A_const_6 *lang.Var

var A_arbace_java_io__init_A_const_7 *lang.Var

var A_arbace_java_io__init_A_const_8 any

var A_arbace_java_io__init_A_const_9 any

var A_arbace_java_io__init_A_const_10 *lang.Var

var A_arbace_java_io__init_A_const_11 any

var A_arbace_java_io__init_A_const_12 *lang.Var

var A_arbace_java_io__init_A_const_13 any

var A_arbace_java_io__init_A_const_14 any

var A_arbace_java_io__init_A_const_15 *jrt.Class

var A_arbace_java_io__init_A_const_16 *lang.Var

var A_arbace_java_io__init_A_const_17 *lang.Var

var A_arbace_java_io__init_A_const_18 *lang.Keyword

var A_arbace_java_io__init_A_const_19 *lang.Var

var A_arbace_java_io__init_A_const_20 any

var A_arbace_java_io__init_A_const_21 *lang.Var

var A_arbace_java_io__init_A_const_22 *lang.Var

var A_arbace_java_io__init_A_const_23 any

var A_arbace_java_io__init_A_const_24 *lang.Keyword

var A_arbace_java_io__init_A_const_25 any

var A_arbace_java_io__init_A_const_26 *lang.Keyword

var A_arbace_java_io__init_A_const_27 *lang.Keyword

var A_arbace_java_io__init_A_const_28 any

var A_arbace_java_io__init_A_const_29 *lang.Keyword

var A_arbace_java_io__init_A_const_30 *lang.Var

var A_arbace_java_io__init_A_const_31 *lang.Var

var A_arbace_java_io__init_A_const_32 *lang.Var

var A_arbace_java_io__init_A_const_33 any

var A_arbace_java_io__init_A_const_34 any

var A_arbace_java_io__init_A_const_35 *lang.Keyword

var A_arbace_java_io__init_A_const_36 any

var A_arbace_java_io__init_A_const_37 any

var A_arbace_java_io__init_A_const_38 *lang.Var

var A_arbace_java_io__init_A_const_39 any

var A_arbace_java_io__init_A_const_40 *lang.Var

var A_arbace_java_io__init_A_const_41 any

var A_arbace_java_io__init_A_const_42 *lang.Var

var A_arbace_java_io__init_A_const_43 *lang.Keyword

var A_arbace_java_io__init_A_const_44 *lang.Keyword

var A_arbace_java_io__init_A_const_45 *jrt.Class

var A_arbace_java_io__init_A_const_46 *jrt.Class

var A_arbace_java_io__init_A_const_47 *jrt.Class

var A_arbace_java_io__init_A_const_48 *jrt.Class

var A_arbace_java_io__init_A_const_49 *lang.Var

var A_arbace_java_io__init_A_const_50 any

var A_arbace_java_io__init_A_const_51 any

var A_arbace_java_io__init_A_const_52 *jrt.Class

var A_arbace_java_io__init_A_const_53 any

var A_arbace_java_io__init_A_const_54 any

var A_arbace_java_io__init_A_const_55 any

var A_arbace_java_io__init_A_const_56 any

var A_arbace_java_io__init_A_const_57 any

var A_arbace_java_io__init_A_const_58 any

var A_arbace_java_io__init_A_const_59 any

var A_arbace_java_io__init_A_const_60 any

var A_arbace_java_io__init_A_const_61 any

var A_arbace_java_io__init_A_const_62 any

var A_arbace_java_io__init_A_const_63 any

var A_arbace_java_io__init_A_const_64 any

var A_arbace_java_io__init_A_const_65 any

var A_arbace_java_io__init_A_const_66 *lang.Var

var A_arbace_java_io__init_A_const_67 any

var A_arbace_java_io__init_A_const_68 *lang.Var

var A_arbace_java_io__init_A_const_69 any

var A_arbace_java_io__init_A_const_70 *lang.Var

var A_arbace_java_io__init_A_const_71 any

var A_arbace_java_io__init_A_const_72 *lang.Var

var A_arbace_java_io__init_A_const_73 any

var A_arbace_java_io__init_A_const_74 *lang.Var

var A_arbace_java_io__init_A_const_75 any

var A_arbace_java_io__init_A_const_76 *lang.Var

var A_arbace_java_io__init_A_const_77 any

var A_arbace_java_io__init_A_const_78 *lang.Var

var A_arbace_java_io__init_A_const_79 any

var A_arbace_java_io__init_A_const_80 *lang.Var

var A_arbace_java_io__init_A_const_81 *lang.Keyword

var A_arbace_java_io__init_A_const_82 *lang.Keyword

var A_arbace_java_io__init_A_const_83 *lang.Keyword

var A_arbace_java_io__init_A_const_84 *lang.Keyword

var A_arbace_java_io__init_A_const_85 any

var A_arbace_java_io__init_A_const_86 *lang.Var

var A_arbace_java_io__init_A_const_87 any

var A_arbace_java_io__init_A_const_88 *lang.Var

var A_arbace_java_io__init_A_const_89 any

var A_arbace_java_io__init_A_const_90 *jrt.Class

var A_arbace_java_io__init_A_const_91 *jrt.Class

var A_arbace_java_io__init_A_const_92 *jrt.Class

var A_arbace_java_io__init_A_const_93 *jrt.Class

var A_arbace_java_io__init_A_const_94 *jrt.Class

var A_arbace_java_io__init_A_const_95 *jrt.Class

var A_arbace_java_io__init_A_const_96 *jrt.Class

var A_arbace_java_io__init_A_const_97 *jrt.Class

var A_arbace_java_io__init_A_const_98 *jrt.Class

var A_arbace_java_io__init_A_const_99 *jrt.Class

var A_arbace_java_io__init_A_const_100 *lang.Var

var A_arbace_java_io__init_A_const_101 any

var A_arbace_java_io__init_A_const_102 *lang.Var

var A_arbace_java_io__init_A_const_103 *lang.Keyword

var A_arbace_java_io__init_A_const_104 *lang.Var

var A_arbace_java_io__init_A_const_105 any

var A_arbace_java_io__init_A_const_106 any

var A_arbace_java_io__init_A_const_107 any

var A_arbace_java_io__init_A_const_108 any

var A_arbace_java_io__init_A_const_109 any

var A_arbace_java_io__init_A_const_110 any

var A_arbace_java_io__init_A_const_111 any

var A_arbace_java_io__init_A_const_112 any

var A_arbace_java_io__init_A_const_113 any

var A_arbace_java_io__init_A_const_114 any

var A_arbace_java_io__init_A_const_115 any

var A_arbace_java_io__init_A_const_116 any

var A_arbace_java_io__init_A_const_117 any

var A_arbace_java_io__init_A_const_118 *lang.Var

var A_arbace_java_io__init_A_const_119 any

var A_arbace_java_io__init_A_const_120 *lang.Var

var A_arbace_java_io__init_A_const_121 any

var A_arbace_java_io__init_A_const_122 *lang.Var

var A_arbace_java_io__init_A_const_123 any

var A_arbace_java_io__init_A_const_124 *lang.Var

var A_arbace_java_io__init_A_const_125 any

var A_arbace_java_io__init_A_const_126 *lang.Var

var A_arbace_java_io__init_A_const_127 any

var A_arbace_java_io__init_A_const_128 *lang.Var

var A_arbace_java_io__init_A_const_129 any

var A_arbace_java_io__init_A_init jrt.ClassInit

func A_arbace_java_io__init_A_Init() { if !A_arbace_java_io__init_A_init.Done() { A_arbace_java_io__init_A_init.Run(A_arbace_java_io__init_A_clinit) } }

func A_arbace_java_io__init_A_clinit() { A_arbace_java_io__init_A_clinit_p0(); A_arbace_java_io__init_A_clinit_p1(); A_arbace_java_io__init_A_clinit_p2(); A_arbace_java_io__init_A_clinit_p3(); A_arbace_java_io__init_A_clinit_p4(); A_arbace_java_io__init_A_clinit_p5(); A_arbace_java_io__init_A_clinit_p6(); A_arbace_java_io__init_A_clinit_p7(); A_arbace_java_io__init_A_clinit_p8(); A_arbace_java_io__init_A_clinit_p9() }

func A_arbace_java_io__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_io__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_61, 175); A_arbace_java_io__init_A_const_0 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[45]); A_arbace_java_io__init_A_const_1 = A_arbace_java_io__init_A_const_pool.A[46]; A_arbace_java_io__init_A_const_2 = A_arbace_java_io__init_A_const_pool.A[47]; A_arbace_java_io__init_A_const_3 = A_arbace_java_io__init_A_const_pool.A[48]; A_arbace_java_io__init_A_const_4 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[49]); A_arbace_java_io__init_A_const_5 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[50]); A_arbace_java_io__init_A_const_6 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[51]); A_arbace_java_io__init_A_const_7 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[52]); A_arbace_java_io__init_A_const_8 = A_arbace_java_io__init_A_const_pool.A[53]; A_arbace_java_io__init_A_const_9 = A_arbace_java_io__init_A_const_pool.A[54]; A_arbace_java_io__init_A_const_10 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[55]); A_arbace_java_io__init_A_const_11 = A_arbace_java_io__init_A_const_pool.A[56] }

func A_arbace_java_io__init_A_clinit_p1() { A_arbace_java_io__init_A_const_12 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[57]); A_arbace_java_io__init_A_const_13 = A_arbace_java_io__init_A_const_pool.A[58]; A_arbace_java_io__init_A_const_14 = A_arbace_java_io__init_A_const_pool.A[59]; A_arbace_java_io__init_A_const_15 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[60]); A_arbace_java_io__init_A_const_16 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[61]); A_arbace_java_io__init_A_const_17 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[62]); A_arbace_java_io__init_A_const_18 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[63]); A_arbace_java_io__init_A_const_19 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[64]); A_arbace_java_io__init_A_const_20 = A_arbace_java_io__init_A_const_pool.A[65]; A_arbace_java_io__init_A_const_21 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[66]); A_arbace_java_io__init_A_const_22 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[67]); A_arbace_java_io__init_A_const_23 = A_arbace_java_io__init_A_const_pool.A[68]; A_arbace_java_io__init_A_const_24 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[69]) }

func A_arbace_java_io__init_A_clinit_p2() { A_arbace_java_io__init_A_const_25 = A_arbace_java_io__init_A_const_pool.A[70]; A_arbace_java_io__init_A_const_26 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[71]); A_arbace_java_io__init_A_const_27 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[72]); A_arbace_java_io__init_A_const_28 = A_arbace_java_io__init_A_const_pool.A[73]; A_arbace_java_io__init_A_const_29 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[74]); A_arbace_java_io__init_A_const_30 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[75]); A_arbace_java_io__init_A_const_31 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[76]); A_arbace_java_io__init_A_const_32 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[77]); A_arbace_java_io__init_A_const_33 = A_arbace_java_io__init_A_const_pool.A[78]; A_arbace_java_io__init_A_const_34 = A_arbace_java_io__init_A_const_pool.A[79]; A_arbace_java_io__init_A_const_35 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[80]); A_arbace_java_io__init_A_const_36 = A_arbace_java_io__init_A_const_pool.A[81]; A_arbace_java_io__init_A_const_37 = A_arbace_java_io__init_A_const_pool.A[82] }

func A_arbace_java_io__init_A_clinit_p3() { A_arbace_java_io__init_A_const_38 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[83]); A_arbace_java_io__init_A_const_39 = A_arbace_java_io__init_A_const_pool.A[84]; A_arbace_java_io__init_A_const_40 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[85]); A_arbace_java_io__init_A_const_41 = A_arbace_java_io__init_A_const_pool.A[86]; A_arbace_java_io__init_A_const_42 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[87]); A_arbace_java_io__init_A_const_43 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[88]); A_arbace_java_io__init_A_const_44 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[89]); A_arbace_java_io__init_A_const_45 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[90]); A_arbace_java_io__init_A_const_46 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[91]); A_arbace_java_io__init_A_const_47 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[92]); A_arbace_java_io__init_A_const_48 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[93]); A_arbace_java_io__init_A_const_49 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[94]) }

func A_arbace_java_io__init_A_clinit_p4() { A_arbace_java_io__init_A_const_50 = A_arbace_java_io__init_A_const_pool.A[95]; A_arbace_java_io__init_A_const_51 = A_arbace_java_io__init_A_const_pool.A[96]; A_arbace_java_io__init_A_const_52 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[97]); A_arbace_java_io__init_A_const_53 = A_arbace_java_io__init_A_const_pool.A[98]; A_arbace_java_io__init_A_const_54 = A_arbace_java_io__init_A_const_pool.A[99]; A_arbace_java_io__init_A_const_55 = A_arbace_java_io__init_A_const_pool.A[100]; A_arbace_java_io__init_A_const_56 = A_arbace_java_io__init_A_const_pool.A[101]; A_arbace_java_io__init_A_const_57 = A_arbace_java_io__init_A_const_pool.A[102]; A_arbace_java_io__init_A_const_58 = A_arbace_java_io__init_A_const_pool.A[103]; A_arbace_java_io__init_A_const_59 = A_arbace_java_io__init_A_const_pool.A[104]; A_arbace_java_io__init_A_const_60 = A_arbace_java_io__init_A_const_pool.A[105]; A_arbace_java_io__init_A_const_61 = A_arbace_java_io__init_A_const_pool.A[106]; A_arbace_java_io__init_A_const_62 = A_arbace_java_io__init_A_const_pool.A[107]; A_arbace_java_io__init_A_const_63 = A_arbace_java_io__init_A_const_pool.A[108]; A_arbace_java_io__init_A_const_64 = A_arbace_java_io__init_A_const_pool.A[109] }

func A_arbace_java_io__init_A_clinit_p5() { A_arbace_java_io__init_A_const_65 = A_arbace_java_io__init_A_const_pool.A[110]; A_arbace_java_io__init_A_const_66 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[111]); A_arbace_java_io__init_A_const_67 = A_arbace_java_io__init_A_const_pool.A[112]; A_arbace_java_io__init_A_const_68 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[113]); A_arbace_java_io__init_A_const_69 = A_arbace_java_io__init_A_const_pool.A[114]; A_arbace_java_io__init_A_const_70 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[115]); A_arbace_java_io__init_A_const_71 = A_arbace_java_io__init_A_const_pool.A[116]; A_arbace_java_io__init_A_const_72 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[117]); A_arbace_java_io__init_A_const_73 = A_arbace_java_io__init_A_const_pool.A[118]; A_arbace_java_io__init_A_const_74 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[119]); A_arbace_java_io__init_A_const_75 = A_arbace_java_io__init_A_const_pool.A[120]; A_arbace_java_io__init_A_const_76 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[121]); A_arbace_java_io__init_A_const_77 = A_arbace_java_io__init_A_const_pool.A[122] }

func A_arbace_java_io__init_A_clinit_p6() { A_arbace_java_io__init_A_const_78 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[123]); A_arbace_java_io__init_A_const_79 = A_arbace_java_io__init_A_const_pool.A[124]; A_arbace_java_io__init_A_const_80 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[125]); A_arbace_java_io__init_A_const_81 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[126]); A_arbace_java_io__init_A_const_82 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[127]); A_arbace_java_io__init_A_const_83 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[128]); A_arbace_java_io__init_A_const_84 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[129]); A_arbace_java_io__init_A_const_85 = A_arbace_java_io__init_A_const_pool.A[130]; A_arbace_java_io__init_A_const_86 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[131]); A_arbace_java_io__init_A_const_87 = A_arbace_java_io__init_A_const_pool.A[132]; A_arbace_java_io__init_A_const_88 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[133]); A_arbace_java_io__init_A_const_89 = A_arbace_java_io__init_A_const_pool.A[134]; A_arbace_java_io__init_A_const_90 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[135]) }

func A_arbace_java_io__init_A_clinit_p7() { A_arbace_java_io__init_A_const_91 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[136]); A_arbace_java_io__init_A_const_92 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[137]); A_arbace_java_io__init_A_const_93 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[138]); A_arbace_java_io__init_A_const_94 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[139]); A_arbace_java_io__init_A_const_95 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[140]); A_arbace_java_io__init_A_const_96 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[141]); A_arbace_java_io__init_A_const_97 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[142]); A_arbace_java_io__init_A_const_98 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[143]); A_arbace_java_io__init_A_const_99 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[144]); A_arbace_java_io__init_A_const_100 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[145]); A_arbace_java_io__init_A_const_101 = A_arbace_java_io__init_A_const_pool.A[146]; A_arbace_java_io__init_A_const_102 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[147]) }

func A_arbace_java_io__init_A_clinit_p8() { A_arbace_java_io__init_A_const_103 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[148]); A_arbace_java_io__init_A_const_104 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[149]); A_arbace_java_io__init_A_const_105 = A_arbace_java_io__init_A_const_pool.A[150]; A_arbace_java_io__init_A_const_106 = A_arbace_java_io__init_A_const_pool.A[151]; A_arbace_java_io__init_A_const_107 = A_arbace_java_io__init_A_const_pool.A[152]; A_arbace_java_io__init_A_const_108 = A_arbace_java_io__init_A_const_pool.A[153]; A_arbace_java_io__init_A_const_109 = A_arbace_java_io__init_A_const_pool.A[154]; A_arbace_java_io__init_A_const_110 = A_arbace_java_io__init_A_const_pool.A[155]; A_arbace_java_io__init_A_const_111 = A_arbace_java_io__init_A_const_pool.A[156]; A_arbace_java_io__init_A_const_112 = A_arbace_java_io__init_A_const_pool.A[157]; A_arbace_java_io__init_A_const_113 = A_arbace_java_io__init_A_const_pool.A[158]; A_arbace_java_io__init_A_const_114 = A_arbace_java_io__init_A_const_pool.A[159]; A_arbace_java_io__init_A_const_115 = A_arbace_java_io__init_A_const_pool.A[160]; A_arbace_java_io__init_A_const_116 = A_arbace_java_io__init_A_const_pool.A[161]; A_arbace_java_io__init_A_const_117 = A_arbace_java_io__init_A_const_pool.A[162] }

func A_arbace_java_io__init_A_clinit_p9() { A_arbace_java_io__init_A_const_118 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[163]); A_arbace_java_io__init_A_const_119 = A_arbace_java_io__init_A_const_pool.A[164]; A_arbace_java_io__init_A_const_120 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[165]); A_arbace_java_io__init_A_const_121 = A_arbace_java_io__init_A_const_pool.A[166]; A_arbace_java_io__init_A_const_122 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[167]); A_arbace_java_io__init_A_const_123 = A_arbace_java_io__init_A_const_pool.A[168]; A_arbace_java_io__init_A_const_124 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[169]); A_arbace_java_io__init_A_const_125 = A_arbace_java_io__init_A_const_pool.A[170]; A_arbace_java_io__init_A_const_126 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[171]); A_arbace_java_io__init_A_const_127 = A_arbace_java_io__init_A_const_pool.A[172]; A_arbace_java_io__init_A_const_128 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[173]); A_arbace_java_io__init_A_const_129 = A_arbace_java_io__init_A_const_pool.A[174] }

func A_arbace_java_io__init_A_New() *A_arbace_java_io__init_A { A_arbace_java_io__init_A_Init(); t := &A_arbace_java_io__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io__init_A) Ctor() {}

func (t *A_arbace_java_io__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_io__init_A_class }

func (t *A_arbace_java_io__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io__init_A); return ok }

func A_arbace_java_io__init_A_Cast(x any) *A_arbace_java_io__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io__init_A_class)) }; return v }
