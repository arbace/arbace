//line aot_arbace_java_io__init.ae:1
package aot_arbace_java_io

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_io__init_A_Load__O() any { A_arbace_java_io__init_A_Init(); jrt.StartCheck(); A_arbace_java_io__init_A_Unit0__O(); A_arbace_java_io__init_A_Unit1__O(); A_arbace_java_io__init_A_Unit2__O(); A_arbace_java_io__init_A_Unit3__O(); A_arbace_java_io__init_A_Unit4__O(); A_arbace_java_io__init_A_Unit5__O(); A_arbace_java_io__init_A_Unit6__O(); A_arbace_java_io__init_A_Unit7__O(); A_arbace_java_io__init_A_Unit8__O(); A_arbace_java_io__init_A_Unit9__O(); A_arbace_java_io__init_A_Unit10__O(); A_arbace_java_io__init_A_Unit11__O(); A_arbace_java_io__init_A_Unit12__O(); A_arbace_java_io__init_A_Unit13__O(); A_arbace_java_io__init_A_Unit14__O(); A_arbace_java_io__init_A_Unit15__O(); A_arbace_java_io__init_A_Unit16__O(); A_arbace_java_io__init_A_Unit17__O(); A_arbace_java_io__init_A_Unit18__O(); A_arbace_java_io__init_A_Unit19__O(); A_arbace_java_io__init_A_Unit20__O(); A_arbace_java_io__init_A_Unit21__O(); A_arbace_java_io__init_A_Unit22__O(); A_arbace_java_io__init_A_Unit23__O(); A_arbace_java_io__init_A_Unit24__O(); A_arbace_java_io__init_A_Unit25__O(); A_arbace_java_io__init_A_Unit26__O(); A_arbace_java_io__init_A_Unit27__O(); A_arbace_java_io__init_A_Unit28__O(); A_arbace_java_io__init_A_Unit29__O(); A_arbace_java_io__init_A_Unit30__O(); A_arbace_java_io__init_A_Unit31__O(); A_arbace_java_io__init_A_Unit32__O(); A_arbace_java_io__init_A_Unit33__O(); A_arbace_java_io__init_A_Unit34__O(); A_arbace_java_io__init_A_Unit35__O(); A_arbace_java_io__init_A_Unit36__O(); A_arbace_java_io__init_A_Unit37__O(); A_arbace_java_io__init_A_Unit38__O(); A_arbace_java_io__init_A_Unit39__O(); A_arbace_java_io__init_A_Unit40__O(); A_arbace_java_io__init_A_Unit41__O(); A_arbace_java_io__init_A_Unit42__O(); A_arbace_java_io__init_A_Unit43__O(); A_arbace_java_io__init_A_Unit44__O(); A_arbace_java_io__init_A_Unit45__O(); A_arbace_java_io__init_A_Unit46__O(); A_arbace_java_io__init_A_Unit47__O(); A_arbace_java_io__init_A_Unit48__O(); A_arbace_java_io__init_A_Unit49__O(); A_arbace_java_io__init_A_Unit50__O(); A_arbace_java_io__init_A_Unit51__O(); A_arbace_java_io__init_A_Unit52__O(); A_arbace_java_io__init_A_Unit53__O(); A_arbace_java_io__init_A_Unit54__O(); A_arbace_java_io__init_A_Unit55__O(); A_arbace_java_io__init_A_Unit56__O(); A_arbace_java_io__init_A_Unit57__O(); A_arbace_java_io__init_A_Unit58__O(); A_arbace_java_io__init_A_Unit59__O(); A_arbace_java_io__init_A_Unit60__O(); A_arbace_java_io__init_A_Unit61__O(); A_arbace_java_io__init_A_Unit62__O(); A_arbace_java_io__init_A_Unit63__O(); A_arbace_java_io__init_A_Unit64__O(); A_arbace_java_io__init_A_Unit65__O(); A_arbace_java_io__init_A_Unit66__O(); A_arbace_java_io__init_A_Unit67__O(); A_arbace_java_io__init_A_Unit68__O(); A_arbace_java_io__init_A_Unit69__O(); A_arbace_java_io__init_A_Unit70__O(); A_arbace_java_io__init_A_Unit71__O(); A_arbace_java_io__init_A_Unit72__O(); A_arbace_java_io__init_A_Unit73__O(); A_arbace_java_io__init_A_Unit74__O(); A_arbace_java_io__init_A_Unit75__O(); A_arbace_java_io__init_A_Unit76__O(); A_arbace_java_io__init_A_Unit77__O(); A_arbace_java_io__init_A_Unit78__O(); return nil }



func A_arbace_java_io__init_A_Unit0__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_java_io__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io__init_A_const_1) }
//line :9:1
func A_arbace_java_io__init_A_Unit1__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_2)) }
//line :9:1
func A_arbace_java_io__init_A_Unit2__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 any = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_62, false); A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_java_io__init_A_Unit3__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1)).Equals_O__Z(A_arbace_java_io__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_java_io_eval1661000008_fn__1661000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_63, false); A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }















func A_arbace_java_io__init_A_Unit4__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); return A_arbace_java_io__init_A_const_4.Set_O__O(jrt.Boolean_FALSE.Ref()) }

func A_arbace_java_io__init_A_Unit5__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_5; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_java_io__init_A_const_6.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_io__init_A_const_8.GetRawRoot__O()).Invoke_O_O__O(jrt.Byte_TYPE.Ref(), A_arbace_java_io__init_A_const_9))); var tmp2 *lang.Var = A_arbace_java_io__init_A_const_5; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_7)); return A_arbace_java_io__init_A_const_5 }





func A_arbace_java_io__init_A_Unit6__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_10; tmp1.BindRoot_O__V(lang.IFn_Cast(A_arbace_java_io__init_A_const_6.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_io__init_A_const_8.GetRawRoot__O()).Invoke_O_O__O(jrt.Character_TYPE.Ref(), A_arbace_java_io__init_A_const_9))); var tmp2 *lang.Var = A_arbace_java_io__init_A_const_10; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_11)); return A_arbace_java_io__init_A_const_10 }




func A_arbace_java_io__init_A_Unit7__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_13)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_12; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_14)); A_arbace_java_io__init_A_const_12.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_12 } }
//line :38:1
func A_arbace_java_io__init_A_Unit8__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_15 }
//line :38:1
func A_arbace_java_io__init_A_Unit9__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_64) }
//line :38:1
func A_arbace_java_io__init_A_Unit10__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_12, A_arbace_java_io__init_A_const_20) }
//line :38:1
func A_arbace_java_io__init_A_Unit11__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_23; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_25; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_12; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_28; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_32.GetRawRoot__O()); var tmp14 any = A_arbace_java_io__init_A_const_33; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_22.GetRawRoot__O()); var tmp16 any = A_arbace_java_io__init_A_const_34; var tmp17 any = lang.IFn_Cast(A_arbace_java_io__init_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_io__init_A_const_31.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12))))); var tmp18 any = A_arbace_java_io_eval1661000024_fn__1661000025_A_New(); var tmp19 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_65, false); A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class = fncls__3d; tmp19 = fncls__3d } else { tmp19 = fncls__3 }; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_32.GetRawRoot__O()); var tmp22 any = A_arbace_java_io__init_A_const_36; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_22.GetRawRoot__O()); var tmp24 any = A_arbace_java_io__init_A_const_37; var tmp25 any = lang.IFn_Cast(A_arbace_java_io__init_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_io__init_A_const_31.Get__O(), tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O__O(tmp24, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12))))); var tmp26 any = A_arbace_java_io_eval1661000024_fn__1661000033_A_New(); var tmp27 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_66, false); A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class = fncls__4d; tmp27 = fncls__4d } else { tmp27 = fncls__4 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp20, tmp25, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil))))) }
//line :38:1
func A_arbace_java_io__init_A_Unit12__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return lang.IFn_Cast(A_arbace_java_io__init_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io__init_A_const_12.GetRawRoot__O()) }
//line :38:1
func A_arbace_java_io__init_A_Unit13__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_39 }




func A_arbace_java_io__init_A_Unit14__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_40; var tmp2 any = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_67, false); A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_41)); return A_arbace_java_io__init_A_const_40 }



func A_arbace_java_io__init_A_Unit15__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_43; var tmp4 any = A_arbace_java_io_eval1661000047_fn__1661000048_A_New(); var tmp5 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_68, false); A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class = fncls__6d; tmp5 = fncls__6d } else { tmp5 = fncls__6 }; var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = A_arbace_java_io__init_A_const_44; var tmp8 any = A_arbace_java_io_eval1661000047_fn__1661000050_A_New(); var tmp9 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_69, false); A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class = fncls__7d; tmp9 = fncls__7d } else { tmp9 = fncls__7 }; return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit16__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 any = A_arbace_java_io_eval1661000053_fn__1661000054_A_New(); var tmp6 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_70, false); A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class = fncls__8d; tmp6 = fncls__8d } else { tmp6 = fncls__8 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 any = A_arbace_java_io_eval1661000053_fn__1661000056_A_New(); var tmp10 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_71, false); A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class = fncls__9d; tmp10 = fncls__9d } else { tmp10 = fncls__9 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit17__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 any = A_arbace_java_io_eval1661000059_fn__1661000060_A_New(); var tmp6 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_72, false); A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class = fncls__10d; tmp6 = fncls__10d } else { tmp6 = fncls__10 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 any = A_arbace_java_io_eval1661000059_fn__1661000062_A_New(); var tmp10 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_73, false); A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class = fncls__11d; tmp10 = fncls__11d } else { tmp10 = fncls__11 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit18__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 any = A_arbace_java_io_eval1661000065_fn__1661000066_A_New(); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 any = A_arbace_java_io_eval1661000065_fn__1661000068_A_New(); var tmp10 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class = fncls__13d; tmp10 = fncls__13d } else { tmp10 = fncls__13 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
//line :47:1
func A_arbace_java_io__init_A_Unit19__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 any = A_arbace_java_io_eval1661000071_fn__1661000072_A_New(); var tmp6 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class = fncls__14d; tmp6 = fncls__14d } else { tmp6 = fncls__14 }; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 any = A_arbace_java_io_eval1661000071_fn__1661000074_A_New(); var tmp10 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_77, false); A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class = fncls__15d; tmp10 = fncls__15d } else { tmp10 = fncls__15 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)))) }
























func A_arbace_java_io__init_A_Unit20__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_50)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_49; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_49; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_51)); A_arbace_java_io__init_A_const_49.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_49 } }
//line :72:1
func A_arbace_java_io__init_A_Unit21__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_52 }
//line :72:1
func A_arbace_java_io__init_A_Unit22__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_78) }
//line :72:1
func A_arbace_java_io__init_A_Unit23__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_49, A_arbace_java_io__init_A_const_53) }
//line :72:1
func A_arbace_java_io__init_A_Unit24__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_54; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_55; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_49; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_56; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_32.GetRawRoot__O()); var tmp14 any = A_arbace_java_io__init_A_const_57; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_22.GetRawRoot__O()); var tmp16 any = A_arbace_java_io__init_A_const_58; var tmp17 any = lang.IFn_Cast(A_arbace_java_io__init_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_io__init_A_const_31.Get__O(), tmp13.Invoke_O_O__O(tmp14, tmp15.Invoke_O_O__O(tmp16, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49))))); var tmp18 any = A_arbace_java_io_eval1661000091_fn__1661000092_A_New(); var tmp19 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class = fncls__16d; tmp19 = fncls__16d } else { tmp19 = fncls__16 }; var tmp20 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_32.GetRawRoot__O()); var tmp22 any = A_arbace_java_io__init_A_const_59; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_22.GetRawRoot__O()); var tmp24 any = A_arbace_java_io__init_A_const_60; var tmp25 any = lang.IFn_Cast(A_arbace_java_io__init_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_io__init_A_const_31.Get__O(), tmp21.Invoke_O_O__O(tmp22, tmp23.Invoke_O_O__O(tmp24, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49))))); var tmp26 any = A_arbace_java_io_eval1661000091_fn__1661000102_A_New(); var tmp27 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class = fncls__17d; tmp27 = fncls__17d } else { tmp27 = fncls__17 }; var tmp28 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp26, tmp27, nil); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_32.GetRawRoot__O()); var tmp30 any = A_arbace_java_io__init_A_const_61; var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_22.GetRawRoot__O()); var tmp32 any = A_arbace_java_io__init_A_const_62; var tmp33 any = lang.IFn_Cast(A_arbace_java_io__init_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_io__init_A_const_31.Get__O(), tmp29.Invoke_O_O__O(tmp30, tmp31.Invoke_O_O__O(tmp32, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49))))); var tmp34 any = A_arbace_java_io_eval1661000091_fn__1661000112_A_New(); var tmp35 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class = fncls__18d; tmp35 = fncls__18d } else { tmp35 = fncls__18 }; var tmp36 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_32.GetRawRoot__O()); var tmp38 any = A_arbace_java_io__init_A_const_63; var tmp39 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_22.GetRawRoot__O()); var tmp40 any = A_arbace_java_io__init_A_const_64; var tmp41 any = lang.IFn_Cast(A_arbace_java_io__init_A_const_30.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_io__init_A_const_31.Get__O(), tmp37.Invoke_O_O__O(tmp38, tmp39.Invoke_O_O__O(tmp40, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49))))); var tmp42 any = A_arbace_java_io_eval1661000091_fn__1661000122_A_New(); var tmp43 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class = fncls__19d; tmp43 = fncls__19d } else { tmp43 = fncls__19 }; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp20, tmp25, tmp28, tmp33, tmp36, tmp41, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp42, tmp43, nil))))) }
//line :72:1
func A_arbace_java_io__init_A_Unit25__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return lang.IFn_Cast(A_arbace_java_io__init_A_const_38.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io__init_A_const_49.GetRawRoot__O()) }
//line :72:1
func A_arbace_java_io__init_A_Unit26__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_65 }
















func A_arbace_java_io__init_A_Unit27__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_66; var tmp2 any = A_arbace_java_io_reader_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_java_io_reader_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, true); A_arbace_java_io_reader_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_67)); return A_arbace_java_io__init_A_const_66 }

















func A_arbace_java_io__init_A_Unit28__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_68; var tmp2 any = A_arbace_java_io_writer_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_java_io_writer_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, true); A_arbace_java_io_writer_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_69)); return A_arbace_java_io__init_A_const_68 }
















func A_arbace_java_io__init_A_Unit29__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_70; var tmp2 any = A_arbace_java_io_input_stream_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_java_io_input_stream_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, true); A_arbace_java_io_input_stream_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_71)); return A_arbace_java_io__init_A_const_70 }
















func A_arbace_java_io__init_A_Unit30__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_72; var tmp2 any = A_arbace_java_io_output_stream_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_java_io_output_stream_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_86, true); A_arbace_java_io_output_stream_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_73)); return A_arbace_java_io__init_A_const_72 }
















func A_arbace_java_io__init_A_Unit31__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_74; var tmp2 any = A_arbace_java_io_append_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_java_io_append_QMARK__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_87, false); A_arbace_java_io_append_QMARK__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_75)); return A_arbace_java_io__init_A_const_74 }


func A_arbace_java_io__init_A_Unit32__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_76; var tmp2 any = A_arbace_java_io_encoding_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_java_io_encoding_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_java_io_encoding_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_77)); return A_arbace_java_io__init_A_const_76 }


func A_arbace_java_io__init_A_Unit33__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_78; var tmp2 any = A_arbace_java_io_buffer_size_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_java_io_buffer_size_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_java_io_buffer_size_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_79)); return A_arbace_java_io__init_A_const_78 }


func A_arbace_java_io__init_A_Unit34__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_80; var tmp2 any = A_arbace_java_io__init_A_const_81; var tmp3 any = A_arbace_java_io_fn__1661000144_A_New(); var tmp4 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_java_io_fn__1661000144_A_fn_class; if
						fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_java_io_fn__1661000144_A_fn_class = fncls__27d; tmp4 = fncls__27d } else { tmp4 = fncls__27 }; var tmp5 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any = A_arbace_java_io__init_A_const_82; var tmp7 any = A_arbace_java_io_fn__1661000146_A_New(); var tmp8 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_java_io_fn__1661000146_A_fn_class; if

	fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_java_io_fn__1661000146_A_fn_class = fncls__28d; tmp8 = fncls__28d } else { tmp8 = fncls__28 }; var tmp9 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_83; var tmp11 any = A_arbace_java_io_fn__1661000148_A_New(); var tmp12 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_java_io_fn__1661000148_A_fn_class; if


	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_java_io_fn__1661000148_A_fn_class = fncls__29d; tmp12 = fncls__29d } else { tmp12 = fncls__29 }; var tmp13 any = /*line :167:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 any = A_arbace_java_io__init_A_const_84; var tmp15 any = A_arbace_java_io_fn__1661000150_A_New(); var tmp16 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_java_io_fn__1661000150_A_fn_class; if





	fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_java_io_fn__1661000150_A_fn_class = fncls__30d; tmp16 = fncls__30d } else { tmp16 = fncls__30 }; /*line :167:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp9, tmp10, tmp13, tmp14, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil)))); var tmp17 *lang.Var = A_arbace_java_io__init_A_const_80; tmp17.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_85)); return A_arbace_java_io__init_A_const_80 }









func A_arbace_java_io__init_A_Unit35__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_86; var tmp2 any = A_arbace_java_io_inputstream__GT_reader_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_java_io_inputstream__GT_reader_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_java_io_inputstream__GT_reader_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_87)); return A_arbace_java_io__init_A_const_86 }



func A_arbace_java_io__init_A_Unit36__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_88; var tmp2 any = A_arbace_java_io_outputstream__GT_writer_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_java_io_outputstream__GT_writer_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_java_io_outputstream__GT_writer_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_89)); return A_arbace_java_io__init_A_const_88 }



func A_arbace_java_io__init_A_Unit37__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_90; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000154_fn__1661000155_A_New(); var tmp8 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class; if


	fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class = fncls__33d; tmp8 = fncls__33d } else { tmp8 = fncls__33 }; var tmp9 any = /*line :185:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit38__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_91; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000158_fn__1661000159_A_New(); var tmp8 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class; if


	fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class = fncls__34d; tmp8 = fncls__34d } else { tmp8 = fncls__34 }; var tmp9 any = /*line :191:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit39__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_92; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_81; var tmp7 any = A_arbace_java_io_eval1661000162_fn__1661000163_A_New(); var tmp8 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class; if


	fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class = fncls__35d; tmp8 = fncls__35d } else { tmp8 = fncls__35 }; return /*line :197:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))) }




func A_arbace_java_io__init_A_Unit40__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_93; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_81; var tmp7 any = A_arbace_java_io_eval1661000166_fn__1661000167_A_New(); var tmp8 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class; if


	fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_99, false); A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class = fncls__36d; tmp8 = fncls__36d } else { tmp8 = fncls__36 }; return /*line :202:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))) }




func A_arbace_java_io__init_A_Unit41__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_94; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_82; var tmp7 any = A_arbace_java_io_eval1661000170_fn__1661000171_A_New(); var tmp8 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class; if


	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_100, false); A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class = fncls__37d; tmp8 = fncls__37d } else { tmp8 = fncls__37 }; return /*line :207:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))) }




func A_arbace_java_io__init_A_Unit42__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_95; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_82; var tmp7 any = A_arbace_java_io_eval1661000174_fn__1661000175_A_New(); var tmp8 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class; if


	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_101, false); A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class = fncls__38d; tmp8 = fncls__38d } else { tmp8 = fncls__38 }; return /*line :212:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))) }




func A_arbace_java_io__init_A_Unit43__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_96; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 any = A_arbace_java_io_eval1661000178_fn__1661000179_A_New(); var tmp8 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class; if


	fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_102, false); A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class = fncls__39d; tmp8 = fncls__39d } else { tmp8 = fncls__39 }; var tmp9 any = /*line :217:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit44__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_97; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 any = A_arbace_java_io_eval1661000182_fn__1661000183_A_New(); var tmp8 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class; if


	fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_103, false); A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class = fncls__40d; tmp8 = fncls__40d } else { tmp8 = fncls__40 }; var tmp9 any = /*line :223:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit45__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000186_fn__1661000187_A_New(); var tmp8 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class; if


	fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_104, false); A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class = fncls__41d; tmp8 = fncls__41d } else { tmp8 = fncls__41 }; var tmp9 any = /*line :229:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000186_fn__1661000189_A_New(); var tmp12 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class; if



	fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class = fncls__42d; tmp12 = fncls__42d } else { tmp12 = fncls__42 }; return /*line :229:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit46__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000192_fn__1661000193_A_New(); var tmp8 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class; if


	fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class = fncls__43d; tmp8 = fncls__43d } else { tmp8 = fncls__43 }; var tmp9 any = /*line :235:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000192_fn__1661000195_A_New(); var tmp12 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class; if







	fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_107, false); A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class = fncls__44d; tmp12 = fncls__44d } else { tmp12 = fncls__44 }; return /*line :235:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }












func A_arbace_java_io__init_A_Unit47__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000198_fn__1661000199_A_New(); var tmp8 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class; if


	fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class = fncls__45d; tmp8 = fncls__45d } else { tmp8 = fncls__45 }; var tmp9 any = /*line :248:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000198_fn__1661000201_A_New(); var tmp12 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class; if



	fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_109, false); A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class = fncls__46d; tmp12 = fncls__46d } else { tmp12 = fncls__46 }; return /*line :248:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit48__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000204_fn__1661000205_A_New(); var tmp8 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class; if


	fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class = fncls__47d; tmp8 = fncls__47d } else { tmp8 = fncls__47 }; var tmp9 any = /*line :254:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000204_fn__1661000207_A_New(); var tmp12 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class; if







	fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class = fncls__48d; tmp12 = fncls__48d } else { tmp12 = fncls__48 }; return /*line :254:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }













func A_arbace_java_io__init_A_Unit49__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_98; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000210_fn__1661000211_A_New(); var tmp8 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class; if


	fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class = fncls__49d; tmp8 = fncls__49d } else { tmp8 = fncls__49 }; var tmp9 any = /*line :268:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 any = A_arbace_java_io_eval1661000210_fn__1661000213_A_New(); var tmp12 *jrt.Class; var fncls__50 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class; if



	fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_113, false); A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class = fncls__50d; tmp12 = fncls__50d } else { tmp12 = fncls__50 }; return /*line :268:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil))) }





func A_arbace_java_io__init_A_Unit50__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_5.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 any = A_arbace_java_io_eval1661000216_fn__1661000217_A_New(); var tmp8 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class; if


	fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class = fncls__51d; tmp8 = fncls__51d } else { tmp8 = fncls__51 }; return /*line :274:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))) }




func A_arbace_java_io__init_A_Unit51__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_10.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_81; var tmp7 any = A_arbace_java_io_eval1661000220_fn__1661000221_A_New(); var tmp8 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class; if


	fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class = fncls__52d; tmp8 = fncls__52d } else { tmp8 = fncls__52 }; return /*line :279:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O__O(tmp5, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil))) }




func A_arbace_java_io__init_A_Unit52__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_99; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_49.GetRawRoot__O(), A_arbace_java_io__init_A_const_80.GetRawRoot__O()) }



func A_arbace_java_io__init_A_Unit53__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp4 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp5 any = A_arbace_java_io__init_A_const_81; var tmp6 any = A_arbace_java_io_eval1661000226_fn__1661000227_A_New(); var tmp7 *jrt.Class; var fncls__53 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class; if


	fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class = fncls__53d; tmp7 = fncls__53d } else { tmp7 = fncls__53 }; var tmp8 any = /*line :288:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_java_io__init_A_const_82; var tmp10 any = A_arbace_java_io_eval1661000226_fn__1661000229_A_New(); var tmp11 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class; if





	fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_117, false); A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class = fncls__54d; tmp11 = fncls__54d } else { tmp11 = fncls__54 }; return /*line :288:1*/ tmp1.Invoke_O_O_O__O(nil, tmp2, tmp3.Invoke_O_O_O_O_O__O(tmp4, tmp5, tmp8, tmp9, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil))) }









func A_arbace_java_io__init_A_Unit54__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_101)); v__1927000386__auto____1 = A_arbace_java_io__init_A_const_100; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { tmp2 = lang.MultiFn_InstanceOf(lang.IFn_Cast(A_arbace_java_io__init_A_const_102.GetRawRoot__O()).Invoke_O__O(v__1927000386__auto____1)) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp3 *lang.Var = A_arbace_java_io__init_A_const_100; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_105)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_100; var tmp5 *jrt.String = Lit_118; var tmp6 any = A_arbace_java_io_eval1661000232_fn__1661000233_A_New(); var tmp7 *jrt.Class
						var fncls__55 /*line :298:1*/*jrt.Class = A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class




	if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class = fncls__55d; tmp7 = fncls__55d } else { tmp7 = fncls__55 }
//line :298:1
	var tmp8 lang.IFn = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp9 any = A_arbace_java_io__init_A_const_103; tmp4.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp5, tmp8, tmp9, A_arbace_java_io__init_A_const_104)); return A_arbace_java_io__init_A_const_100 } }






func A_arbace_java_io__init_A_Unit55__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_106; var tmp3 any = A_arbace_java_io_eval1661000236_fn__1661000237_A_New(); var tmp4 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_120, false); A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class = fncls__56d; tmp4 = fncls__56d } else { tmp4 = fncls__56 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_java_io__init_A_Unit56__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_107; var tmp3 any = A_arbace_java_io_eval1661000240_fn__1661000241_A_New(); var tmp4 *jrt.Class; var fncls__57 *jrt.Class = A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class; if fncls__57 == nil { var fncls__57d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class = fncls__57d; tmp4 = fncls__57d } else { tmp4 = fncls__57 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }








func A_arbace_java_io__init_A_Unit57__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_108; var tmp3 any = A_arbace_java_io_eval1661000244_fn__1661000245_A_New(); var tmp4 *jrt.Class; var fncls__58 *jrt.Class = A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class; if fncls__58 == nil { var fncls__58d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class = fncls__58d; tmp4 = fncls__58d } else { tmp4 = fncls__58 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit58__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_109; var tmp3 any = A_arbace_java_io_eval1661000248_fn__1661000249_A_New(); var tmp4 *jrt.Class; var fncls__59 *jrt.Class = A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class; if fncls__59 == nil { var fncls__59d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class = fncls__59d; tmp4 = fncls__59d } else { tmp4 = fncls__59 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }










func A_arbace_java_io__init_A_Unit59__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_110; var tmp3 any = A_arbace_java_io_eval1661000252_fn__1661000253_A_New(); var tmp4 *jrt.Class; var fncls__60 *jrt.Class = A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class; if fncls__60 == nil { var fncls__60d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class = fncls__60d; tmp4 = fncls__60d } else { tmp4 = fncls__60 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }







func A_arbace_java_io__init_A_Unit60__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_111; var tmp3 any = A_arbace_java_io_eval1661000256_fn__1661000257_A_New(); var tmp4 *jrt.Class; var fncls__61 *jrt.Class = A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class; if fncls__61 == nil { var fncls__61d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class = fncls__61d; tmp4 = fncls__61d } else { tmp4 = fncls__61 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit61__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_112; var tmp3 any = A_arbace_java_io_eval1661000260_fn__1661000261_A_New(); var tmp4 *jrt.Class; var fncls__62 *jrt.Class = A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class; if fncls__62 == nil { var fncls__62d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class = fncls__62d; tmp4 = fncls__62d } else { tmp4 = fncls__62 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit62__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_113; var tmp3 any = A_arbace_java_io_eval1661000264_fn__1661000265_A_New(); var tmp4 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class = fncls__63d; tmp4 = fncls__63d } else { tmp4 = fncls__63 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }



func A_arbace_java_io__init_A_Unit63__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_114; var tmp3 any = A_arbace_java_io_eval1661000268_fn__1661000269_A_New(); var tmp4 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class = fncls__64d; tmp4 = fncls__64d } else { tmp4 = fncls__64 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }





func A_arbace_java_io__init_A_Unit64__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_115; var tmp3 any = A_arbace_java_io_eval1661000272_fn__1661000273_A_New(); var tmp4 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class; if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class = fncls__65d; tmp4 = fncls__65d } else { tmp4 = fncls__65 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit65__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_116; var tmp3 any = A_arbace_java_io_eval1661000276_fn__1661000277_A_New(); var tmp4 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class; if fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_130, false); A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class = fncls__66d; tmp4 = fncls__66d } else { tmp4 = fncls__66 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit66__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_117; var tmp3 any = A_arbace_java_io_eval1661000280_fn__1661000281_A_New(); var tmp4 *jrt.Class; var fncls__67 *jrt.Class = A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class; if fncls__67 == nil { var fncls__67d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_131, false); A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class = fncls__67d; tmp4 = fncls__67d } else { tmp4 = fncls__67 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit67__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 any = A_arbace_java_io_eval1661000284_fn__1661000285_A_New(); var tmp4 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class = fncls__68d; tmp4 = fncls__68d } else { tmp4 = fncls__68 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit68__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 any = A_arbace_java_io_eval1661000288_fn__1661000289_A_New(); var tmp4 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class = fncls__69d; tmp4 = fncls__69d } else { tmp4 = fncls__69 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit69__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 any = A_arbace_java_io_eval1661000292_fn__1661000293_A_New(); var tmp4 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class = fncls__70d; tmp4 = fncls__70d } else { tmp4 = fncls__70 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit70__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 any = A_arbace_java_io_eval1661000296_fn__1661000297_A_New(); var tmp4 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class = fncls__71d; tmp4 = fncls__71d } else { tmp4 = fncls__71 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit71__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 any = A_arbace_java_io_eval1661000300_fn__1661000301_A_New(); var tmp4 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class = fncls__72d; tmp4 = fncls__72d } else { tmp4 = fncls__72 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit72__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 any = A_arbace_java_io_eval1661000304_fn__1661000305_A_New(); var tmp4 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class; if fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class = fncls__73d; tmp4 = fncls__73d } else { tmp4 = fncls__73 }; return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)).Ref() }


func A_arbace_java_io__init_A_Unit73__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_118; var tmp2 any = A_arbace_java_io_copy_A_New(); var tmp3 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_java_io_copy_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, true); A_arbace_java_io_copy_A_fn_class = fncls__74d; tmp3 = fncls__74d } else { tmp3 = fncls__74 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_119)); return A_arbace_java_io__init_A_const_118 }
















func A_arbace_java_io__init_A_Unit74__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_120; var tmp2 any = A_arbace_java_io_as_relative_path_A_New(); var tmp3 *jrt.Class; var fncls__75 *jrt.Class = A_arbace_java_io_as_relative_path_A_fn_class; if fncls__75 == nil { var fncls__75d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_java_io_as_relative_path_A_fn_class = fncls__75d; tmp3 = fncls__75d } else { tmp3 = fncls__75 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_121)); return A_arbace_java_io__init_A_const_120 }









func A_arbace_java_io__init_A_Unit75__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_122; var tmp2 any = A_arbace_java_io_file_A_New(); var tmp3 *jrt.Class; var fncls__76 *jrt.Class = A_arbace_java_io_file_A_fn_class; if fncls__76 == nil { var fncls__76d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, true); A_arbace_java_io_file_A_fn_class = fncls__76d; tmp3 = fncls__76d } else { tmp3 = fncls__76 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_123)); return A_arbace_java_io__init_A_const_122 }











func A_arbace_java_io__init_A_Unit76__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_124; var tmp2 any = A_arbace_java_io_delete_file_A_New(); var tmp3 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_java_io_delete_file_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, true); A_arbace_java_io_delete_file_A_fn_class = fncls__77d; tmp3 = fncls__77d } else { tmp3 = fncls__77 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_125)); return A_arbace_java_io__init_A_const_124 }







func A_arbace_java_io__init_A_Unit77__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_126; var tmp2 any = A_arbace_java_io_make_parents_A_New(); var tmp3 *jrt.Class; var fncls__78 *jrt.Class = A_arbace_java_io_make_parents_A_fn_class; if fncls__78 == nil { var fncls__78d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, true); A_arbace_java_io_make_parents_A_fn_class = fncls__78d; tmp3 = fncls__78d } else { tmp3 = fncls__78 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 1)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_127)); return A_arbace_java_io__init_A_const_126 }







func A_arbace_java_io__init_A_Unit78__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(445, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_128; var tmp2 any = A_arbace_java_io_resource_A_New(); var tmp3 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_java_io_resource_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_143, false); A_arbace_java_io_resource_A_fn_class = fncls__79d; tmp3 = fncls__79d } else { tmp3 = fncls__79 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_129)); return A_arbace_java_io__init_A_const_128 }



type A_arbace_java_io__init_A struct{ jrt.Object }

var A_arbace_java_io__init_A_const_pool *jrt.RefArray

var A_arbace_java_io__init_A_const_0 *lang.Var

var A_arbace_java_io__init_A_const_1 any

var A_arbace_java_io__init_A_const_2 any

var A_arbace_java_io__init_A_const_3 any

var A_arbace_java_io__init_A_const_4 *lang.Var

var A_arbace_java_io__init_A_const_5 *lang.Var

var A_arbace_java_io__init_A_const_6 *lang.Var

var A_arbace_java_io__init_A_const_7 any

var A_arbace_java_io__init_A_const_8 *lang.Var

var A_arbace_java_io__init_A_const_9 any

var A_arbace_java_io__init_A_const_10 *lang.Var

var A_arbace_java_io__init_A_const_11 any

var A_arbace_java_io__init_A_const_12 *lang.Var

var A_arbace_java_io__init_A_const_13 any

var A_arbace_java_io__init_A_const_14 any

var A_arbace_java_io__init_A_const_15 *jrt.Class

var A_arbace_java_io__init_A_const_16 *lang.Var

var A_arbace_java_io__init_A_const_17 *lang.Var

var A_arbace_java_io__init_A_const_18 *lang.Keyword

var A_arbace_java_io__init_A_const_19 *lang.Var

var A_arbace_java_io__init_A_const_20 any

var A_arbace_java_io__init_A_const_21 *lang.Var

var A_arbace_java_io__init_A_const_22 *lang.Var

var A_arbace_java_io__init_A_const_23 any

var A_arbace_java_io__init_A_const_24 *lang.Keyword

var A_arbace_java_io__init_A_const_25 any

var A_arbace_java_io__init_A_const_26 *lang.Keyword

var A_arbace_java_io__init_A_const_27 *lang.Keyword

var A_arbace_java_io__init_A_const_28 any

var A_arbace_java_io__init_A_const_29 *lang.Keyword

var A_arbace_java_io__init_A_const_30 *lang.Var

var A_arbace_java_io__init_A_const_31 *lang.Var

var A_arbace_java_io__init_A_const_32 *lang.Var

var A_arbace_java_io__init_A_const_33 any

var A_arbace_java_io__init_A_const_34 any

var A_arbace_java_io__init_A_const_35 *lang.Keyword

var A_arbace_java_io__init_A_const_36 any

var A_arbace_java_io__init_A_const_37 any

var A_arbace_java_io__init_A_const_38 *lang.Var

var A_arbace_java_io__init_A_const_39 any

var A_arbace_java_io__init_A_const_40 *lang.Var

var A_arbace_java_io__init_A_const_41 any

var A_arbace_java_io__init_A_const_42 *lang.Var

var A_arbace_java_io__init_A_const_43 *lang.Keyword

var A_arbace_java_io__init_A_const_44 *lang.Keyword

var A_arbace_java_io__init_A_const_45 *jrt.Class

var A_arbace_java_io__init_A_const_46 *jrt.Class

var A_arbace_java_io__init_A_const_47 *jrt.Class

var A_arbace_java_io__init_A_const_48 *jrt.Class

var A_arbace_java_io__init_A_const_49 *lang.Var

var A_arbace_java_io__init_A_const_50 any

var A_arbace_java_io__init_A_const_51 any

var A_arbace_java_io__init_A_const_52 *jrt.Class

var A_arbace_java_io__init_A_const_53 any

var A_arbace_java_io__init_A_const_54 any

var A_arbace_java_io__init_A_const_55 any

var A_arbace_java_io__init_A_const_56 any

var A_arbace_java_io__init_A_const_57 any

var A_arbace_java_io__init_A_const_58 any

var A_arbace_java_io__init_A_const_59 any

var A_arbace_java_io__init_A_const_60 any

var A_arbace_java_io__init_A_const_61 any

var A_arbace_java_io__init_A_const_62 any

var A_arbace_java_io__init_A_const_63 any

var A_arbace_java_io__init_A_const_64 any

var A_arbace_java_io__init_A_const_65 any

var A_arbace_java_io__init_A_const_66 *lang.Var

var A_arbace_java_io__init_A_const_67 any

var A_arbace_java_io__init_A_const_68 *lang.Var

var A_arbace_java_io__init_A_const_69 any

var A_arbace_java_io__init_A_const_70 *lang.Var

var A_arbace_java_io__init_A_const_71 any

var A_arbace_java_io__init_A_const_72 *lang.Var

var A_arbace_java_io__init_A_const_73 any

var A_arbace_java_io__init_A_const_74 *lang.Var

var A_arbace_java_io__init_A_const_75 any

var A_arbace_java_io__init_A_const_76 *lang.Var

var A_arbace_java_io__init_A_const_77 any

var A_arbace_java_io__init_A_const_78 *lang.Var

var A_arbace_java_io__init_A_const_79 any

var A_arbace_java_io__init_A_const_80 *lang.Var

var A_arbace_java_io__init_A_const_81 *lang.Keyword

var A_arbace_java_io__init_A_const_82 *lang.Keyword

var A_arbace_java_io__init_A_const_83 *lang.Keyword

var A_arbace_java_io__init_A_const_84 *lang.Keyword

var A_arbace_java_io__init_A_const_85 any

var A_arbace_java_io__init_A_const_86 *lang.Var

var A_arbace_java_io__init_A_const_87 any

var A_arbace_java_io__init_A_const_88 *lang.Var

var A_arbace_java_io__init_A_const_89 any

var A_arbace_java_io__init_A_const_90 *jrt.Class

var A_arbace_java_io__init_A_const_91 *jrt.Class

var A_arbace_java_io__init_A_const_92 *jrt.Class

var A_arbace_java_io__init_A_const_93 *jrt.Class

var A_arbace_java_io__init_A_const_94 *jrt.Class

var A_arbace_java_io__init_A_const_95 *jrt.Class

var A_arbace_java_io__init_A_const_96 *jrt.Class

var A_arbace_java_io__init_A_const_97 *jrt.Class

var A_arbace_java_io__init_A_const_98 *jrt.Class

var A_arbace_java_io__init_A_const_99 *jrt.Class

var A_arbace_java_io__init_A_const_100 *lang.Var

var A_arbace_java_io__init_A_const_101 any

var A_arbace_java_io__init_A_const_102 *lang.Var

var A_arbace_java_io__init_A_const_103 *lang.Keyword

var A_arbace_java_io__init_A_const_104 *lang.Var

var A_arbace_java_io__init_A_const_105 any

var A_arbace_java_io__init_A_const_106 any

var A_arbace_java_io__init_A_const_107 any

var A_arbace_java_io__init_A_const_108 any

var A_arbace_java_io__init_A_const_109 any

var A_arbace_java_io__init_A_const_110 any

var A_arbace_java_io__init_A_const_111 any

var A_arbace_java_io__init_A_const_112 any

var A_arbace_java_io__init_A_const_113 any

var A_arbace_java_io__init_A_const_114 any

var A_arbace_java_io__init_A_const_115 any

var A_arbace_java_io__init_A_const_116 any

var A_arbace_java_io__init_A_const_117 any

var A_arbace_java_io__init_A_const_118 *lang.Var

var A_arbace_java_io__init_A_const_119 any

var A_arbace_java_io__init_A_const_120 *lang.Var

var A_arbace_java_io__init_A_const_121 any

var A_arbace_java_io__init_A_const_122 *lang.Var

var A_arbace_java_io__init_A_const_123 any

var A_arbace_java_io__init_A_const_124 *lang.Var

var A_arbace_java_io__init_A_const_125 any

var A_arbace_java_io__init_A_const_126 *lang.Var

var A_arbace_java_io__init_A_const_127 any

var A_arbace_java_io__init_A_const_128 *lang.Var

var A_arbace_java_io__init_A_const_129 any

var A_arbace_java_io__init_A_init jrt.ClassInit

func A_arbace_java_io__init_A_Init() { if !A_arbace_java_io__init_A_init.Done() { A_arbace_java_io__init_A_init.Run(A_arbace_java_io__init_A_clinit) } }

func A_arbace_java_io__init_A_clinit() { A_arbace_java_io__init_A_clinit_p0(); A_arbace_java_io__init_A_clinit_p1(); A_arbace_java_io__init_A_clinit_p2(); A_arbace_java_io__init_A_clinit_p3(); A_arbace_java_io__init_A_clinit_p4(); A_arbace_java_io__init_A_clinit_p5(); A_arbace_java_io__init_A_clinit_p6(); A_arbace_java_io__init_A_clinit_p7(); A_arbace_java_io__init_A_clinit_p8(); A_arbace_java_io__init_A_clinit_p9() }

func A_arbace_java_io__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_io__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_61, 175); A_arbace_java_io__init_A_const_0 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[45]); A_arbace_java_io__init_A_const_1 = A_arbace_java_io__init_A_const_pool.A[46]; A_arbace_java_io__init_A_const_2 = A_arbace_java_io__init_A_const_pool.A[47]; A_arbace_java_io__init_A_const_3 = A_arbace_java_io__init_A_const_pool.A[48]; A_arbace_java_io__init_A_const_4 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[49]); A_arbace_java_io__init_A_const_5 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[50]); A_arbace_java_io__init_A_const_6 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[51]); A_arbace_java_io__init_A_const_7 = A_arbace_java_io__init_A_const_pool.A[52]; A_arbace_java_io__init_A_const_8 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[53]); A_arbace_java_io__init_A_const_9 = A_arbace_java_io__init_A_const_pool.A[54]; A_arbace_java_io__init_A_const_10 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[55]); A_arbace_java_io__init_A_const_11 = A_arbace_java_io__init_A_const_pool.A[56] }

func A_arbace_java_io__init_A_clinit_p1() { A_arbace_java_io__init_A_const_12 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[57]); A_arbace_java_io__init_A_const_13 = A_arbace_java_io__init_A_const_pool.A[58]; A_arbace_java_io__init_A_const_14 = A_arbace_java_io__init_A_const_pool.A[59]; A_arbace_java_io__init_A_const_15 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[60]); A_arbace_java_io__init_A_const_16 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[61]); A_arbace_java_io__init_A_const_17 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[62]); A_arbace_java_io__init_A_const_18 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[63]); A_arbace_java_io__init_A_const_19 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[64]); A_arbace_java_io__init_A_const_20 = A_arbace_java_io__init_A_const_pool.A[65]; A_arbace_java_io__init_A_const_21 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[66]); A_arbace_java_io__init_A_const_22 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[67]); A_arbace_java_io__init_A_const_23 = A_arbace_java_io__init_A_const_pool.A[68]; A_arbace_java_io__init_A_const_24 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[69]) }

func A_arbace_java_io__init_A_clinit_p2() { A_arbace_java_io__init_A_const_25 = A_arbace_java_io__init_A_const_pool.A[70]; A_arbace_java_io__init_A_const_26 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[71]); A_arbace_java_io__init_A_const_27 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[72]); A_arbace_java_io__init_A_const_28 = A_arbace_java_io__init_A_const_pool.A[73]; A_arbace_java_io__init_A_const_29 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[74]); A_arbace_java_io__init_A_const_30 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[75]); A_arbace_java_io__init_A_const_31 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[76]); A_arbace_java_io__init_A_const_32 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[77]); A_arbace_java_io__init_A_const_33 = A_arbace_java_io__init_A_const_pool.A[78]; A_arbace_java_io__init_A_const_34 = A_arbace_java_io__init_A_const_pool.A[79]; A_arbace_java_io__init_A_const_35 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[80]); A_arbace_java_io__init_A_const_36 = A_arbace_java_io__init_A_const_pool.A[81]; A_arbace_java_io__init_A_const_37 = A_arbace_java_io__init_A_const_pool.A[82] }

func A_arbace_java_io__init_A_clinit_p3() { A_arbace_java_io__init_A_const_38 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[83]); A_arbace_java_io__init_A_const_39 = A_arbace_java_io__init_A_const_pool.A[84]; A_arbace_java_io__init_A_const_40 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[85]); A_arbace_java_io__init_A_const_41 = A_arbace_java_io__init_A_const_pool.A[86]; A_arbace_java_io__init_A_const_42 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[87]); A_arbace_java_io__init_A_const_43 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[88]); A_arbace_java_io__init_A_const_44 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[89]); A_arbace_java_io__init_A_const_45 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[90]); A_arbace_java_io__init_A_const_46 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[91]); A_arbace_java_io__init_A_const_47 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[92]); A_arbace_java_io__init_A_const_48 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[93]); A_arbace_java_io__init_A_const_49 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[94]) }

func A_arbace_java_io__init_A_clinit_p4() { A_arbace_java_io__init_A_const_50 = A_arbace_java_io__init_A_const_pool.A[95]; A_arbace_java_io__init_A_const_51 = A_arbace_java_io__init_A_const_pool.A[96]; A_arbace_java_io__init_A_const_52 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[97]); A_arbace_java_io__init_A_const_53 = A_arbace_java_io__init_A_const_pool.A[98]; A_arbace_java_io__init_A_const_54 = A_arbace_java_io__init_A_const_pool.A[99]; A_arbace_java_io__init_A_const_55 = A_arbace_java_io__init_A_const_pool.A[100]; A_arbace_java_io__init_A_const_56 = A_arbace_java_io__init_A_const_pool.A[101]; A_arbace_java_io__init_A_const_57 = A_arbace_java_io__init_A_const_pool.A[102]; A_arbace_java_io__init_A_const_58 = A_arbace_java_io__init_A_const_pool.A[103]; A_arbace_java_io__init_A_const_59 = A_arbace_java_io__init_A_const_pool.A[104]; A_arbace_java_io__init_A_const_60 = A_arbace_java_io__init_A_const_pool.A[105]; A_arbace_java_io__init_A_const_61 = A_arbace_java_io__init_A_const_pool.A[106]; A_arbace_java_io__init_A_const_62 = A_arbace_java_io__init_A_const_pool.A[107]; A_arbace_java_io__init_A_const_63 = A_arbace_java_io__init_A_const_pool.A[108]; A_arbace_java_io__init_A_const_64 = A_arbace_java_io__init_A_const_pool.A[109] }

func A_arbace_java_io__init_A_clinit_p5() { A_arbace_java_io__init_A_const_65 = A_arbace_java_io__init_A_const_pool.A[110]; A_arbace_java_io__init_A_const_66 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[111]); A_arbace_java_io__init_A_const_67 = A_arbace_java_io__init_A_const_pool.A[112]; A_arbace_java_io__init_A_const_68 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[113]); A_arbace_java_io__init_A_const_69 = A_arbace_java_io__init_A_const_pool.A[114]; A_arbace_java_io__init_A_const_70 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[115]); A_arbace_java_io__init_A_const_71 = A_arbace_java_io__init_A_const_pool.A[116]; A_arbace_java_io__init_A_const_72 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[117]); A_arbace_java_io__init_A_const_73 = A_arbace_java_io__init_A_const_pool.A[118]; A_arbace_java_io__init_A_const_74 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[119]); A_arbace_java_io__init_A_const_75 = A_arbace_java_io__init_A_const_pool.A[120]; A_arbace_java_io__init_A_const_76 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[121]); A_arbace_java_io__init_A_const_77 = A_arbace_java_io__init_A_const_pool.A[122] }

func A_arbace_java_io__init_A_clinit_p6() { A_arbace_java_io__init_A_const_78 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[123]); A_arbace_java_io__init_A_const_79 = A_arbace_java_io__init_A_const_pool.A[124]; A_arbace_java_io__init_A_const_80 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[125]); A_arbace_java_io__init_A_const_81 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[126]); A_arbace_java_io__init_A_const_82 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[127]); A_arbace_java_io__init_A_const_83 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[128]); A_arbace_java_io__init_A_const_84 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[129]); A_arbace_java_io__init_A_const_85 = A_arbace_java_io__init_A_const_pool.A[130]; A_arbace_java_io__init_A_const_86 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[131]); A_arbace_java_io__init_A_const_87 = A_arbace_java_io__init_A_const_pool.A[132]; A_arbace_java_io__init_A_const_88 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[133]); A_arbace_java_io__init_A_const_89 = A_arbace_java_io__init_A_const_pool.A[134]; A_arbace_java_io__init_A_const_90 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[135]) }

func A_arbace_java_io__init_A_clinit_p7() { A_arbace_java_io__init_A_const_91 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[136]); A_arbace_java_io__init_A_const_92 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[137]); A_arbace_java_io__init_A_const_93 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[138]); A_arbace_java_io__init_A_const_94 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[139]); A_arbace_java_io__init_A_const_95 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[140]); A_arbace_java_io__init_A_const_96 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[141]); A_arbace_java_io__init_A_const_97 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[142]); A_arbace_java_io__init_A_const_98 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[143]); A_arbace_java_io__init_A_const_99 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[144]); A_arbace_java_io__init_A_const_100 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[145]); A_arbace_java_io__init_A_const_101 = A_arbace_java_io__init_A_const_pool.A[146]; A_arbace_java_io__init_A_const_102 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[147]) }

func A_arbace_java_io__init_A_clinit_p8() { A_arbace_java_io__init_A_const_103 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[148]); A_arbace_java_io__init_A_const_104 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[149]); A_arbace_java_io__init_A_const_105 = A_arbace_java_io__init_A_const_pool.A[150]; A_arbace_java_io__init_A_const_106 = A_arbace_java_io__init_A_const_pool.A[151]; A_arbace_java_io__init_A_const_107 = A_arbace_java_io__init_A_const_pool.A[152]; A_arbace_java_io__init_A_const_108 = A_arbace_java_io__init_A_const_pool.A[153]; A_arbace_java_io__init_A_const_109 = A_arbace_java_io__init_A_const_pool.A[154]; A_arbace_java_io__init_A_const_110 = A_arbace_java_io__init_A_const_pool.A[155]; A_arbace_java_io__init_A_const_111 = A_arbace_java_io__init_A_const_pool.A[156]; A_arbace_java_io__init_A_const_112 = A_arbace_java_io__init_A_const_pool.A[157]; A_arbace_java_io__init_A_const_113 = A_arbace_java_io__init_A_const_pool.A[158]; A_arbace_java_io__init_A_const_114 = A_arbace_java_io__init_A_const_pool.A[159]; A_arbace_java_io__init_A_const_115 = A_arbace_java_io__init_A_const_pool.A[160]; A_arbace_java_io__init_A_const_116 = A_arbace_java_io__init_A_const_pool.A[161]; A_arbace_java_io__init_A_const_117 = A_arbace_java_io__init_A_const_pool.A[162] }

func A_arbace_java_io__init_A_clinit_p9() { A_arbace_java_io__init_A_const_118 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[163]); A_arbace_java_io__init_A_const_119 = A_arbace_java_io__init_A_const_pool.A[164]; A_arbace_java_io__init_A_const_120 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[165]); A_arbace_java_io__init_A_const_121 = A_arbace_java_io__init_A_const_pool.A[166]; A_arbace_java_io__init_A_const_122 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[167]); A_arbace_java_io__init_A_const_123 = A_arbace_java_io__init_A_const_pool.A[168]; A_arbace_java_io__init_A_const_124 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[169]); A_arbace_java_io__init_A_const_125 = A_arbace_java_io__init_A_const_pool.A[170]; A_arbace_java_io__init_A_const_126 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[171]); A_arbace_java_io__init_A_const_127 = A_arbace_java_io__init_A_const_pool.A[172]; A_arbace_java_io__init_A_const_128 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[173]); A_arbace_java_io__init_A_const_129 = A_arbace_java_io__init_A_const_pool.A[174] }

func A_arbace_java_io__init_A_New() *A_arbace_java_io__init_A { A_arbace_java_io__init_A_Init(); t := &A_arbace_java_io__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io__init_A) Ctor() {}

func (t *A_arbace_java_io__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_io__init_A_class }

func (t *A_arbace_java_io__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io__init_A); return ok }

func A_arbace_java_io__init_A_Cast(x any) *A_arbace_java_io__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io__init_A_class)) }; return v }
