//line aot_arbace_java_io__init.ae:1
package aot_arbace_java_io

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_java_io__init_A_Load__O() any { A_arbace_java_io__init_A_Init(); jrt.StartCheck(); A_arbace_java_io__init_A_Unit0__O(); A_arbace_java_io__init_A_Unit1__O(); A_arbace_java_io__init_A_Unit2__O(); A_arbace_java_io__init_A_Unit3__O(); A_arbace_java_io__init_A_Unit4__O(); A_arbace_java_io__init_A_Unit5__O(); A_arbace_java_io__init_A_Unit6__O(); A_arbace_java_io__init_A_Unit7__O(); A_arbace_java_io__init_A_Unit8__O(); A_arbace_java_io__init_A_Unit9__O(); A_arbace_java_io__init_A_Unit10__O(); A_arbace_java_io__init_A_Unit11__O(); A_arbace_java_io__init_A_Unit12__O(); A_arbace_java_io__init_A_Unit13__O(); A_arbace_java_io__init_A_Unit14__O(); A_arbace_java_io__init_A_Unit15__O(); A_arbace_java_io__init_A_Unit16__O(); A_arbace_java_io__init_A_Unit17__O(); A_arbace_java_io__init_A_Unit18__O(); A_arbace_java_io__init_A_Unit19__O(); A_arbace_java_io__init_A_Unit20__O(); A_arbace_java_io__init_A_Unit21__O(); A_arbace_java_io__init_A_Unit22__O(); A_arbace_java_io__init_A_Unit23__O(); A_arbace_java_io__init_A_Unit24__O(); A_arbace_java_io__init_A_Unit25__O(); A_arbace_java_io__init_A_Unit26__O(); A_arbace_java_io__init_A_Unit27__O(); A_arbace_java_io__init_A_Unit28__O(); A_arbace_java_io__init_A_Unit29__O(); A_arbace_java_io__init_A_Unit30__O(); A_arbace_java_io__init_A_Unit31__O(); A_arbace_java_io__init_A_Unit32__O(); A_arbace_java_io__init_A_Unit33__O(); A_arbace_java_io__init_A_Unit34__O(); A_arbace_java_io__init_A_Unit35__O(); A_arbace_java_io__init_A_Unit36__O(); A_arbace_java_io__init_A_Unit37__O(); A_arbace_java_io__init_A_Unit38__O(); A_arbace_java_io__init_A_Unit39__O(); A_arbace_java_io__init_A_Unit40__O(); A_arbace_java_io__init_A_Unit41__O(); A_arbace_java_io__init_A_Unit42__O(); A_arbace_java_io__init_A_Unit43__O(); A_arbace_java_io__init_A_Unit44__O(); A_arbace_java_io__init_A_Unit45__O(); A_arbace_java_io__init_A_Unit46__O(); A_arbace_java_io__init_A_Unit47__O(); A_arbace_java_io__init_A_Unit48__O(); A_arbace_java_io__init_A_Unit49__O(); A_arbace_java_io__init_A_Unit50__O(); A_arbace_java_io__init_A_Unit51__O(); A_arbace_java_io__init_A_Unit52__O(); A_arbace_java_io__init_A_Unit53__O(); A_arbace_java_io__init_A_Unit54__O(); A_arbace_java_io__init_A_Unit55__O(); A_arbace_java_io__init_A_Unit56__O(); A_arbace_java_io__init_A_Unit57__O(); A_arbace_java_io__init_A_Unit58__O(); A_arbace_java_io__init_A_Unit59__O(); A_arbace_java_io__init_A_Unit60__O(); A_arbace_java_io__init_A_Unit61__O(); A_arbace_java_io__init_A_Unit62__O(); A_arbace_java_io__init_A_Unit63__O(); A_arbace_java_io__init_A_Unit64__O(); A_arbace_java_io__init_A_Unit65__O(); A_arbace_java_io__init_A_Unit66__O(); A_arbace_java_io__init_A_Unit67__O(); A_arbace_java_io__init_A_Unit68__O(); A_arbace_java_io__init_A_Unit69__O(); A_arbace_java_io__init_A_Unit70__O(); A_arbace_java_io__init_A_Unit71__O(); A_arbace_java_io__init_A_Unit72__O(); A_arbace_java_io__init_A_Unit73__O(); A_arbace_java_io__init_A_Unit74__O(); A_arbace_java_io__init_A_Unit75__O(); A_arbace_java_io__init_A_Unit76__O(); A_arbace_java_io__init_A_Unit77__O(); A_arbace_java_io__init_A_Unit78__O(); return nil }



func A_arbace_java_io__init_A_Unit0__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return lang.IFn_Cast(A_arbace_java_io__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_io__init_A_const_1) }
//line :9:1
func A_arbace_java_io__init_A_Unit1__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_2)) }
//line :9:1
func A_arbace_java_io__init_A_Unit2__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_62, false, nil); A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :9:1
func A_arbace_java_io__init_A_Unit3__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_java_io__init_A_const_1)).Equals_O__Z(A_arbace_java_io__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_java_io_eval1661000008_fn__1661000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_63, false, nil); A_arbace_java_io_eval1661000008_fn__1661000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }















func A_arbace_java_io__init_A_Unit4__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(25, 1); return A_arbace_java_io__init_A_const_4.Set_O__O(jrt.Boolean_FALSE.Ref()) }

func A_arbace_java_io__init_A_Unit5__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(27, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_5; var tmp2 any; var root_5 any = A_arbace_java_io__init_A_const_6.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_7 lang.IFn; if



	linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any; var root_9 any = A_arbace_java_io__init_A_const_7.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = jrt.Byte_TYPE.Ref(); var arg_13 any = A_arbace_java_io__init_A_const_8; if linked_10 == nil { arg_8 = ifn_11.Invoke_O_O__O(arg_12, arg_13) } else { arg_8 = linked_10.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_9, arg_12, arg_13) }; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_5, arg_8) }; /*line :27:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_io__init_A_const_5; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_9)); return A_arbace_java_io__init_A_const_5 }





func A_arbace_java_io__init_A_Unit6__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(33, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_10; var tmp2 any; var root_14 any = A_arbace_java_io__init_A_const_6.GetRawRoot__O(); var linked_15 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_14, aot_arbace_core.A_arbace_core_class_A_fn_class); var ifn_16 lang.IFn; if


	linked_15 == nil { ifn_16 = lang.IFn_Cast(root_14) } else { ifn_16 = nil }; var arg_17 any; var root_18 any = A_arbace_java_io__init_A_const_7.GetRawRoot__O(); var linked_19 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_18, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_20 lang.IFn; if linked_19 == nil { ifn_20 = lang.IFn_Cast(root_18) } else { ifn_20 = nil }; var arg_21 any = jrt.Character_TYPE.Ref(); var arg_22 any = A_arbace_java_io__init_A_const_8; if linked_19 == nil { arg_17 = ifn_20.Invoke_O_O__O(arg_21, arg_22) } else { arg_17 = linked_19.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_18, arg_21, arg_22) }; if linked_15 == nil { tmp2 = ifn_16.Invoke_O__O(arg_17) } else { tmp2 = linked_15.(*aot_arbace_core.A_arbace_core_class_A).Invoke_O_O__O(root_14, arg_17) }; /*line :33:1*/tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_java_io__init_A_const_10; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_11)); return A_arbace_java_io__init_A_const_10 }




func A_arbace_java_io__init_A_Unit7__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_12; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_13)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_12; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_12; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_14)); A_arbace_java_io__init_A_const_12.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_12 } }
//line :38:1
func A_arbace_java_io__init_A_Unit8__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_15 }
//line :38:1
func A_arbace_java_io__init_A_Unit9__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_64) }
//line :38:1
func A_arbace_java_io__init_A_Unit10__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_12, A_arbace_java_io__init_A_const_20) }
//line :38:1
func A_arbace_java_io__init_A_Unit11__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_23; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_25; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_12; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_28; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 any; var root_48 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_52 any; var root_53 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_java_io__init_A_const_33; var arg_57 any; var root_58 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = A_arbace_java_io__init_A_const_34; var arg_62 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12)); if linked_59 == nil { arg_57 = ifn_60.Invoke_O_O__O(arg_61, arg_62) } else { arg_57 = linked_59.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_58, arg_61, arg_62) }; if linked_54 == nil { arg_52 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { arg_52 = linked_54.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; if linked_49 == nil { tmp13 = ifn_50.Invoke_O_O__O(arg_51, arg_52) } else { tmp13 = linked_49.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_48, arg_51, arg_52) }; var tmp14 any = tmp13; var tmp15 *lang.Compiler_AOTFn; var fnbody__64 any = A_arbace_java_io_eval1661000024_fn__1661000025_A_New(); var tmp16 *jrt.Class; var fncls__63 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class; if fncls__63 == nil { var fncls__63d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_65, false, nil); A_arbace_java_io_eval1661000024_fn__1661000025_A_fn_class = fncls__63d; tmp16 = fncls__63d } else { tmp16 = fncls__63 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__64, tmp16, nil); var tmp17 any = tmp15.Ref(); var tmp18 any; var root_65 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_66 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_65, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_67 lang.IFn; if linked_66 == nil { ifn_67 = lang.IFn_Cast(root_65) } else { ifn_67 = nil }; var arg_68 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_69 any; var root_70 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_72 lang.IFn; if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any = A_arbace_java_io__init_A_const_36; var arg_74 any; var root_75 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = A_arbace_java_io__init_A_const_37; var arg_79 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_12)); if linked_76 == nil { arg_74 = ifn_77.Invoke_O_O__O(arg_78, arg_79) } else { arg_74 = linked_76.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_75, arg_78, arg_79) }; if linked_71 == nil { arg_69 = ifn_72.Invoke_O_O__O(arg_73, arg_74) } else { arg_69 = linked_71.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_70, arg_73, arg_74) }; if linked_66 == nil { tmp18 = ifn_67.Invoke_O_O__O(arg_68, arg_69) } else { tmp18 = linked_66.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_65, arg_68, arg_69) }; var tmp19 any = tmp18; var tmp20 *lang.Compiler_AOTFn; var fnbody__81 any = A_arbace_java_io_eval1661000024_fn__1661000033_A_New(); var tmp21 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class; if fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_66, false, nil); A_arbace_java_io_eval1661000024_fn__1661000033_A_fn_class = fncls__80d; tmp21 = fncls__80d } else { tmp21 = fncls__80 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__81, tmp21, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, tmp20.Ref())))) }
//line :38:1
func A_arbace_java_io__init_A_Unit12__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var root_82 any = A_arbace_java_io__init_A_const_38.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); if linked_83 == nil { return ifn_84.Invoke_O__O(arg_85) } else { return linked_83.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_82, arg_85) } }
//line :38:1
func A_arbace_java_io__init_A_Unit13__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); return A_arbace_java_io__init_A_const_39 }




func A_arbace_java_io__init_A_Unit14__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(43, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_40; var tmp2 *lang.Compiler_AOTFn; var fnbody__87 any = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_New(); var tmp3 *jrt.Class; var fncls__86 *jrt.Class = A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class; if fncls__86 == nil { var fncls__86d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_67, false, nil); A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_fn_class = fncls__86d; tmp3 = fncls__86d } else { tmp3 = fncls__86 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__87, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_41)); return A_arbace_java_io__init_A_const_40 }



func A_arbace_java_io__init_A_Unit15__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_43; var tmp4 *lang.Compiler_AOTFn; var fnbody__95 any = A_arbace_java_io_eval1661000047_fn__1661000048_A_New(); var tmp5 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_68, false, nil); A_arbace_java_io_eval1661000047_fn__1661000048_A_fn_class = fncls__94d; tmp5 = fncls__94d } else { tmp5 = fncls__94 }; tmp4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__95, tmp5, nil); var tmp6 any = tmp4.Ref(); var tmp7 any = A_arbace_java_io__init_A_const_44; var tmp8 *lang.Compiler_AOTFn; var fnbody__97 any = A_arbace_java_io_eval1661000047_fn__1661000050_A_New(); var tmp9 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_69, false, nil); A_arbace_java_io_eval1661000047_fn__1661000050_A_fn_class = fncls__96d; tmp9 = fncls__96d } else { tmp9 = fncls__96 }; tmp8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__97, tmp9, nil); return tmp1.Invoke_O_O_O__O(nil, tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7, tmp8.Ref()))) }
//line :47:1
func A_arbace_java_io__init_A_Unit16__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 *lang.Compiler_AOTFn; var fnbody__105 any = A_arbace_java_io_eval1661000053_fn__1661000054_A_New(); var tmp6 *jrt.Class; var fncls__104 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class; if fncls__104 == nil { var fncls__104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_70, false, nil); A_arbace_java_io_eval1661000053_fn__1661000054_A_fn_class = fncls__104d; tmp6 = fncls__104d } else { tmp6 = fncls__104 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__105, tmp6, nil); var tmp7 any = tmp5.Ref(); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 *lang.Compiler_AOTFn; var fnbody__107 any = A_arbace_java_io_eval1661000053_fn__1661000056_A_New(); var tmp10 *jrt.Class; var fncls__106 *jrt.Class = A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class; if fncls__106 == nil { var fncls__106d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_71, false, nil); A_arbace_java_io_eval1661000053_fn__1661000056_A_fn_class = fncls__106d; tmp10 = fncls__106d } else { tmp10 = fncls__106 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__107, tmp10, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp9.Ref()))) }
//line :47:1
func A_arbace_java_io__init_A_Unit17__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_43; var tmp5 *lang.Compiler_AOTFn; var fnbody__115 any = A_arbace_java_io_eval1661000059_fn__1661000060_A_New(); var tmp6 *jrt.Class; var fncls__114 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class; if fncls__114 == nil { var fncls__114d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_72, false, nil); A_arbace_java_io_eval1661000059_fn__1661000060_A_fn_class = fncls__114d; tmp6 = fncls__114d } else { tmp6 = fncls__114 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__115, tmp6, nil); var tmp7 any = tmp5.Ref(); var tmp8 any = A_arbace_java_io__init_A_const_44; var tmp9 *lang.Compiler_AOTFn; var fnbody__117 any = A_arbace_java_io_eval1661000059_fn__1661000062_A_New(); var tmp10 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_73, false, nil); A_arbace_java_io_eval1661000059_fn__1661000062_A_fn_class = fncls__116d; tmp10 = fncls__116d } else { tmp10 = fncls__116 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__117, tmp10, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp9.Ref()))) }
//line :47:1
func A_arbace_java_io__init_A_Unit18__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 *lang.Compiler_AOTFn; var fnbody__125 any = A_arbace_java_io_eval1661000065_fn__1661000066_A_New(); var tmp6 *jrt.Class; var fncls__124 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class; if fncls__124 == nil { var fncls__124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_74, false, nil); A_arbace_java_io_eval1661000065_fn__1661000066_A_fn_class = fncls__124d; tmp6 = fncls__124d } else { tmp6 = fncls__124 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__125, tmp6, nil); var tmp7 any = tmp5.Ref(); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 *lang.Compiler_AOTFn; var fnbody__127 any = A_arbace_java_io_eval1661000065_fn__1661000068_A_New(); var tmp10 *jrt.Class; var fncls__126 *jrt.Class = A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class; if fncls__126 == nil { var fncls__126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_java_io_eval1661000065_fn__1661000068_A_fn_class = fncls__126d; tmp10 = fncls__126d } else { tmp10 = fncls__126 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__127, tmp10, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp9.Ref()))) }
//line :47:1
func A_arbace_java_io__init_A_Unit19__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(47, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_12.GetRawRoot__O(); var tmp4 any = A_arbace_java_io__init_A_const_44; var tmp5 *lang.Compiler_AOTFn; var fnbody__135 any = A_arbace_java_io_eval1661000071_fn__1661000072_A_New(); var tmp6 *jrt.Class; var fncls__134 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class; if fncls__134 == nil { var fncls__134d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_java_io_eval1661000071_fn__1661000072_A_fn_class = fncls__134d; tmp6 = fncls__134d } else { tmp6 = fncls__134 }; tmp5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__135, tmp6, nil); var tmp7 any = tmp5.Ref(); var tmp8 any = A_arbace_java_io__init_A_const_43; var tmp9 *lang.Compiler_AOTFn; var fnbody__137 any = A_arbace_java_io_eval1661000071_fn__1661000074_A_New(); var tmp10 *jrt.Class; var fncls__136 *jrt.Class = A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class; if fncls__136 == nil { var fncls__136d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_77, false, nil); A_arbace_java_io_eval1661000071_fn__1661000074_A_fn_class = fncls__136d; tmp10 = fncls__136d } else { tmp10 = fncls__136 }; tmp9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__137, tmp10, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp7, tmp8, tmp9.Ref()))) }
























func A_arbace_java_io__init_A_Unit20__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_50)); v__1927001498__auto____1 = A_arbace_java_io__init_A_const_49; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_java_io__init_A_const_49; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_51)); A_arbace_java_io__init_A_const_49.BindRoot_O__V(lang.PersistentArrayMap_EMPTY.Ref()); return A_arbace_java_io__init_A_const_49 } }
//line :72:1
func A_arbace_java_io__init_A_Unit21__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_52 }
//line :72:1
func A_arbace_java_io__init_A_Unit22__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_16.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; return tmp1.Invoke_O_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_17.GetRawRoot__O(), A_arbace_java_io__init_A_const_18, Lit_78) }
//line :72:1
func A_arbace_java_io__init_A_Unit23__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_19.Invoke_O_O__O(A_arbace_java_io__init_A_const_49, A_arbace_java_io__init_A_const_53) }
//line :72:1
func A_arbace_java_io__init_A_Unit24__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_21.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49; var tmp3 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_54; var tmp6 any = A_arbace_java_io__init_A_const_24; var tmp7 any = A_arbace_java_io__init_A_const_55; var tmp8 any = A_arbace_java_io__init_A_const_26; var tmp9 any = A_arbace_java_io__init_A_const_49; var tmp10 any = A_arbace_java_io__init_A_const_27; var tmp11 any = A_arbace_java_io__init_A_const_56; var tmp12 any = A_arbace_java_io__init_A_const_29; var tmp13 any; var root_163 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_167 any; var root_168 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = A_arbace_java_io__init_A_const_57; var arg_172 any; var root_173 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any = A_arbace_java_io__init_A_const_58; var arg_177 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_174 == nil { arg_172 = ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { arg_172 = linked_174.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) }; if linked_169 == nil { arg_167 = ifn_170.Invoke_O_O__O(arg_171, arg_172) } else { arg_167 = linked_169.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_168, arg_171, arg_172) }; if linked_164 == nil { tmp13 = ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { tmp13 = linked_164.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; var tmp14 any = tmp13; var tmp15 *lang.Compiler_AOTFn; var fnbody__179 any = A_arbace_java_io_eval1661000091_fn__1661000092_A_New(); var tmp16 *jrt.Class; var fncls__178 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class; if fncls__178 == nil { var fncls__178d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); A_arbace_java_io_eval1661000091_fn__1661000092_A_fn_class = fncls__178d; tmp16 = fncls__178d } else { tmp16 = fncls__178 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__179, tmp16, nil); var tmp17 any = tmp15.Ref(); var tmp18 any; var root_180 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_184 any; var root_185 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = A_arbace_java_io__init_A_const_59; var arg_189 any; var root_190 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = A_arbace_java_io__init_A_const_60; var arg_194 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_191 == nil { arg_189 = ifn_192.Invoke_O_O__O(arg_193, arg_194) } else { arg_189 = linked_191.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_190, arg_193, arg_194) }; if linked_186 == nil { arg_184 = ifn_187.Invoke_O_O__O(arg_188, arg_189) } else { arg_184 = linked_186.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_185, arg_188, arg_189) }; if linked_181 == nil { tmp18 = ifn_182.Invoke_O_O__O(arg_183, arg_184) } else { tmp18 = linked_181.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_180, arg_183, arg_184) }; var tmp19 any = tmp18; var tmp20 *lang.Compiler_AOTFn; var fnbody__196 any = A_arbace_java_io_eval1661000091_fn__1661000102_A_New(); var tmp21 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class; if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_80, false, nil); A_arbace_java_io_eval1661000091_fn__1661000102_A_fn_class = fncls__195d; tmp21 = fncls__195d } else { tmp21 = fncls__195 }; tmp20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__196, tmp21, nil); var tmp22 any = tmp20.Ref(); var tmp23 any; var root_197 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_199 lang.IFn; if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_201 any; var root_202 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = A_arbace_java_io__init_A_const_61; var arg_206 any; var root_207 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = A_arbace_java_io__init_A_const_62; var arg_211 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_208 == nil { arg_206 = ifn_209.Invoke_O_O__O(arg_210, arg_211) } else { arg_206 = linked_208.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_207, arg_210, arg_211) }; if linked_203 == nil { arg_201 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { arg_201 = linked_203.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }; if linked_198 == nil { tmp23 = ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { tmp23 = linked_198.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }; var tmp24 any = tmp23; var tmp25 *lang.Compiler_AOTFn; var fnbody__213 any = A_arbace_java_io_eval1661000091_fn__1661000112_A_New(); var tmp26 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_java_io_eval1661000091_fn__1661000112_A_fn_class = fncls__212d; tmp26 = fncls__212d } else { tmp26 = fncls__212 }; tmp25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__213, tmp26, nil); var tmp27 any = tmp25.Ref(); var tmp28 any; var root_214 any = A_arbace_java_io__init_A_const_30.GetRawRoot__O(); var linked_215 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_214, aot_arbace_core.A_arbace_core_intern_A_fn_class); var ifn_216 lang.IFn; if linked_215 == nil { ifn_216 = lang.IFn_Cast(root_214) } else { ifn_216 = nil }; var arg_217 any = A_arbace_java_io__init_A_const_31.Get__O(); var arg_218 any; var root_219 any = A_arbace_java_io__init_A_const_32.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_221 lang.IFn; if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any = A_arbace_java_io__init_A_const_63; var arg_223 any; var root_224 any = A_arbace_java_io__init_A_const_22.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = A_arbace_java_io__init_A_const_64; var arg_228 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_java_io__init_A_const_35, A_arbace_java_io__init_A_const_49)); if linked_225 == nil { arg_223 = ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { arg_223 = linked_225.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) }; if linked_220 == nil { arg_218 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { arg_218 = linked_220.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }; if linked_215 == nil { tmp28 = ifn_216.Invoke_O_O__O(arg_217, arg_218) } else { tmp28 = linked_215.(*aot_arbace_core.A_arbace_core_intern_A).Invoke_O_O_O__O(root_214, arg_217, arg_218) }; var tmp29 any = tmp28; var tmp30 *lang.Compiler_AOTFn; var fnbody__230 any = A_arbace_java_io_eval1661000091_fn__1661000122_A_New(); var tmp31 *jrt.Class; var fncls__229 *jrt.Class = A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class; if fncls__229 == nil { var fncls__229d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_java_io_eval1661000091_fn__1661000122_A_fn_class = fncls__229d; tmp31 = fncls__229d } else { tmp31 = fncls__229 }; tmp30 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__230, tmp31, nil); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O_O_O_O_O__O(tmp5, tmp6, tmp7, tmp8, tmp9, tmp10, tmp11, tmp12, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp14, tmp17, tmp19, tmp22, tmp24, tmp27, tmp29, tmp30.Ref())))) }
//line :72:1
func A_arbace_java_io__init_A_Unit25__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); var root_231 any = A_arbace_java_io__init_A_const_38.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core__reset_methods_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); if linked_232 == nil { return ifn_233.Invoke_O__O(arg_234) } else { return linked_232.(*aot_arbace_core.A_arbace_core__reset_methods_A).Invoke_O_O__O(root_231, arg_234) } }
//line :72:1
func A_arbace_java_io__init_A_Unit26__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(72, 1); return A_arbace_java_io__init_A_const_65 }
















func A_arbace_java_io__init_A_Unit27__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(89, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_66; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__236 any = A_arbace_java_io_reader_A_New(); var tmp3 *jrt.Class; var fncls__235 *jrt.Class = A_arbace_java_io_reader_A_fn_class; if fncls__235 == nil { var fncls__235d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, true, nil); A_arbace_java_io_reader_A_fn_class = fncls__235d; tmp3 = fncls__235d } else { tmp3 = fncls__235 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__236, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_67)); return A_arbace_java_io__init_A_const_66 }

















func A_arbace_java_io__init_A_Unit28__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_68; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__238 any = A_arbace_java_io_writer_A_New(); var tmp3 *jrt.Class; var fncls__237 *jrt.Class = A_arbace_java_io_writer_A_fn_class; if fncls__237 == nil { var fncls__237d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_84, true, nil); A_arbace_java_io_writer_A_fn_class = fncls__237d; tmp3 = fncls__237d } else { tmp3 = fncls__237 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__238, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_69)); return A_arbace_java_io__init_A_const_68 }
















func A_arbace_java_io__init_A_Unit29__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(124, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_70; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__240 any = A_arbace_java_io_input_stream_A_New(); var tmp3 *jrt.Class; var fncls__239 *jrt.Class = A_arbace_java_io_input_stream_A_fn_class; if fncls__239 == nil { var fncls__239d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, true, nil); A_arbace_java_io_input_stream_A_fn_class = fncls__239d; tmp3 = fncls__239d } else { tmp3 = fncls__239 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__240, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_71)); return A_arbace_java_io__init_A_const_70 }
















func A_arbace_java_io__init_A_Unit30__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_72; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__242 any = A_arbace_java_io_output_stream_A_New(); var tmp3 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_java_io_output_stream_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_86, true, nil); A_arbace_java_io_output_stream_A_fn_class = fncls__241d; tmp3 = fncls__241d } else { tmp3 = fncls__241 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__242, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_73)); return A_arbace_java_io__init_A_const_72 }
















func A_arbace_java_io__init_A_Unit31__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(158, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_74; var tmp2 *lang.Compiler_AOTFn; var fnbody__244 any = A_arbace_java_io_append_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__243 *jrt.Class = A_arbace_java_io_append_QMARK__A_fn_class; if fncls__243 == nil { var fncls__243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_87, false, nil); A_arbace_java_io_append_QMARK__A_fn_class = fncls__243d; tmp3 = fncls__243d } else { tmp3 = fncls__243 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__244, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_75)); return A_arbace_java_io__init_A_const_74 }


func A_arbace_java_io__init_A_Unit32__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(161, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_76; var tmp2 *lang.Compiler_AOTFn; var fnbody__246 any = A_arbace_java_io_encoding_A_New(); var tmp3 *jrt.Class; var fncls__245 *jrt.Class = A_arbace_java_io_encoding_A_fn_class; if fncls__245 == nil { var fncls__245d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_88, false, nil); A_arbace_java_io_encoding_A_fn_class = fncls__245d; tmp3 = fncls__245d } else { tmp3 = fncls__245 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__246, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_77)); return A_arbace_java_io__init_A_const_76 }


func A_arbace_java_io__init_A_Unit33__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(164, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_78; var tmp2 *lang.Compiler_AOTFn; var fnbody__248 any = A_arbace_java_io_buffer_size_A_New(); var tmp3 *jrt.Class; var fncls__247 *jrt.Class = A_arbace_java_io_buffer_size_A_fn_class; if fncls__247 == nil { var fncls__247d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_java_io_buffer_size_A_fn_class = fncls__247d; tmp3 = fncls__247d } else { tmp3 = fncls__247 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__248, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_79)); return A_arbace_java_io__init_A_const_78 }


func A_arbace_java_io__init_A_Unit34__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(167, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_80; var tmp2 any = A_arbace_java_io__init_A_const_81; var tmp3 *lang.Compiler_AOTFn; var fnbody__250 any = A_arbace_java_io_fn__1661000144_A_New(); var tmp4 *jrt.Class; var fncls__249 *jrt.Class = A_arbace_java_io_fn__1661000144_A_fn_class; if
						fncls__249 == nil { var fncls__249d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_java_io_fn__1661000144_A_fn_class = fncls__249d; tmp4 = fncls__249d } else { tmp4 = fncls__249 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__250, tmp4, nil); var tmp5 any = /*line :167:1*/tmp3.Ref(); var tmp6 any = A_arbace_java_io__init_A_const_82; var tmp7 *lang.Compiler_AOTFn; var fnbody__252 any = A_arbace_java_io_fn__1661000146_A_New(); var tmp8 *jrt.Class; var fncls__251 *jrt.Class = A_arbace_java_io_fn__1661000146_A_fn_class; if

	fncls__251 == nil { var fncls__251d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, nil); A_arbace_java_io_fn__1661000146_A_fn_class = fncls__251d; tmp8 = fncls__251d } else { tmp8 = fncls__251 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__252, tmp8, nil); var tmp9 any = /*line :167:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_83; var tmp11 *lang.Compiler_AOTFn; var fnbody__254 any = A_arbace_java_io_fn__1661000148_A_New(); var tmp12 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_java_io_fn__1661000148_A_fn_class; if


	fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_java_io_fn__1661000148_A_fn_class = fncls__253d; tmp12 = fncls__253d } else { tmp12 = fncls__253 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__254, tmp12, nil); var tmp13 any = /*line :167:1*/tmp11.Ref(); var tmp14 any = A_arbace_java_io__init_A_const_84; var tmp15 *lang.Compiler_AOTFn; var fnbody__256 any = A_arbace_java_io_fn__1661000150_A_New(); var tmp16 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_java_io_fn__1661000150_A_fn_class; if





	fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, nil); A_arbace_java_io_fn__1661000150_A_fn_class = fncls__255d; tmp16 = fncls__255d } else { tmp16 = fncls__255 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__256, tmp16, nil); /*line :167:1*/tmp1.BindRoot_O__V(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp5, tmp6, tmp9, tmp10, tmp13, tmp14, tmp15.Ref()))); var tmp17 *lang.Var = A_arbace_java_io__init_A_const_80; tmp17.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_85)); return A_arbace_java_io__init_A_const_80 }









func A_arbace_java_io__init_A_Unit35__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(177, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_86; var tmp2 *lang.Compiler_AOTFn; var fnbody__258 any = A_arbace_java_io_inputstream__GT_reader_A_New(); var tmp3 *jrt.Class; var fncls__257 *jrt.Class = A_arbace_java_io_inputstream__GT_reader_A_fn_class; if fncls__257 == nil { var fncls__257d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, nil); A_arbace_java_io_inputstream__GT_reader_A_fn_class = fncls__257d; tmp3 = fncls__257d } else { tmp3 = fncls__257 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__258, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_87)); return A_arbace_java_io__init_A_const_86 }



func A_arbace_java_io__init_A_Unit36__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(181, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_88; var tmp2 *lang.Compiler_AOTFn; var fnbody__260 any = A_arbace_java_io_outputstream__GT_writer_A_New(); var tmp3 *jrt.Class; var fncls__259 *jrt.Class = A_arbace_java_io_outputstream__GT_writer_A_fn_class; if fncls__259 == nil { var fncls__259d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_95, false, nil); A_arbace_java_io_outputstream__GT_writer_A_fn_class = fncls__259d; tmp3 = fncls__259d } else { tmp3 = fncls__259 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__260, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_89)); return A_arbace_java_io__init_A_const_88 }



func A_arbace_java_io__init_A_Unit37__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(185, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_90; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__276 any = A_arbace_java_io_eval1661000154_fn__1661000155_A_New(); var tmp8 *jrt.Class; var fncls__275 *jrt.Class = A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class; if


	fncls__275 == nil { var fncls__275d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, nil); A_arbace_java_io_eval1661000154_fn__1661000155_A_fn_class = fncls__275d; tmp8 = fncls__275d } else { tmp8 = fncls__275 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__276, tmp8, nil); var tmp9 any = /*line :185:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit38__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(191, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_91; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__292 any = A_arbace_java_io_eval1661000158_fn__1661000159_A_New(); var tmp8 *jrt.Class; var fncls__291 *jrt.Class = A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class; if


	fncls__291 == nil { var fncls__291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_97, false, nil); A_arbace_java_io_eval1661000158_fn__1661000159_A_fn_class = fncls__291d; tmp8 = fncls__291d } else { tmp8 = fncls__291 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__292, tmp8, nil); var tmp9 any = /*line :191:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_81; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_86.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit39__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(197, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_92; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_299 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_300 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_299, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_301 lang.IFn; if

	linked_300 == nil { ifn_301 = lang.IFn_Cast(root_299) } else { ifn_301 = nil }; var arg_302 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_303 any = A_arbace_java_io__init_A_const_81; var arg_304 any; var fnbody__306 any = A_arbace_java_io_eval1661000162_fn__1661000163_A_New(); var tmp5 *jrt.Class; var fncls__305 *jrt.Class = A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class; if
	fncls__305 == nil { var fncls__305d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_java_io_eval1661000162_fn__1661000163_A_fn_class = fncls__305d; tmp5 = fncls__305d } else { tmp5 = fncls__305 }; arg_304 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__306, tmp5, nil); if /*line :199:1*/ linked_300 == nil { tmp4 = ifn_301.Invoke_O_O_O__O(arg_302, arg_303, arg_304) } else { tmp4 = linked_300.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_299, arg_302, arg_303, arg_304) }; return /*line :197:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit40__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(202, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_93; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_313 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_314 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_313, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_315 lang.IFn; if

	linked_314 == nil { ifn_315 = lang.IFn_Cast(root_313) } else { ifn_315 = nil }; var arg_316 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_317 any = A_arbace_java_io__init_A_const_81; var arg_318 any; var fnbody__320 any = A_arbace_java_io_eval1661000166_fn__1661000167_A_New(); var tmp5 *jrt.Class; var fncls__319 *jrt.Class = A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class; if
	fncls__319 == nil { var fncls__319d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_99, false, nil); A_arbace_java_io_eval1661000166_fn__1661000167_A_fn_class = fncls__319d; tmp5 = fncls__319d } else { tmp5 = fncls__319 }; arg_318 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__320, tmp5, nil); if /*line :204:1*/ linked_314 == nil { tmp4 = ifn_315.Invoke_O_O_O__O(arg_316, arg_317, arg_318) } else { tmp4 = linked_314.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_313, arg_316, arg_317, arg_318) }; return /*line :202:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit41__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(207, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_94; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_327 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_329 lang.IFn; if

	linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_331 any = A_arbace_java_io__init_A_const_82; var arg_332 any; var fnbody__334 any = A_arbace_java_io_eval1661000170_fn__1661000171_A_New(); var tmp5 *jrt.Class; var fncls__333 *jrt.Class = A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class; if
	fncls__333 == nil { var fncls__333d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_100, false, nil); A_arbace_java_io_eval1661000170_fn__1661000171_A_fn_class = fncls__333d; tmp5 = fncls__333d } else { tmp5 = fncls__333 }; arg_332 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__334, tmp5, nil); if /*line :209:1*/ linked_328 == nil { tmp4 = ifn_329.Invoke_O_O_O__O(arg_330, arg_331, arg_332) } else { tmp4 = linked_328.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_327, arg_330, arg_331, arg_332) }; return /*line :207:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit42__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(212, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_95; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_341 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_343 lang.IFn; if

	linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_345 any = A_arbace_java_io__init_A_const_82; var arg_346 any; var fnbody__348 any = A_arbace_java_io_eval1661000174_fn__1661000175_A_New(); var tmp5 *jrt.Class; var fncls__347 *jrt.Class = A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class; if
	fncls__347 == nil { var fncls__347d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_101, false, nil); A_arbace_java_io_eval1661000174_fn__1661000175_A_fn_class = fncls__347d; tmp5 = fncls__347d } else { tmp5 = fncls__347 }; arg_346 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__348, tmp5, nil); if /*line :214:1*/ linked_342 == nil { tmp4 = ifn_343.Invoke_O_O_O__O(arg_344, arg_345, arg_346) } else { tmp4 = linked_342.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_341, arg_344, arg_345, arg_346) }; return /*line :212:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit43__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(217, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_96; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 *lang.Compiler_AOTFn; var fnbody__364 any = A_arbace_java_io_eval1661000178_fn__1661000179_A_New(); var tmp8 *jrt.Class; var fncls__363 *jrt.Class = A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class; if


	fncls__363 == nil { var fncls__363d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_102, false, nil); A_arbace_java_io_eval1661000178_fn__1661000179_A_fn_class = fncls__363d; tmp8 = fncls__363d } else { tmp8 = fncls__363 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__364, tmp8, nil); var tmp9 any = /*line :217:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit44__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(223, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_97; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_84; var tmp7 *lang.Compiler_AOTFn; var fnbody__380 any = A_arbace_java_io_eval1661000182_fn__1661000183_A_New(); var tmp8 *jrt.Class; var fncls__379 *jrt.Class = A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class; if


	fncls__379 == nil { var fncls__379d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_103, false, nil); A_arbace_java_io_eval1661000182_fn__1661000183_A_fn_class = fncls__379d; tmp8 = fncls__379d } else { tmp8 = fncls__379 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__380, tmp8, nil); var tmp9 any = /*line :223:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_82; return tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_88.GetRawRoot__O())) }





func A_arbace_java_io__init_A_Unit45__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(229, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_46; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__396 any = A_arbace_java_io_eval1661000186_fn__1661000187_A_New(); var tmp8 *jrt.Class; var fncls__395 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class; if


	fncls__395 == nil { var fncls__395d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_104, false, nil); A_arbace_java_io_eval1661000186_fn__1661000187_A_fn_class = fncls__395d; tmp8 = fncls__395d } else { tmp8 = fncls__395 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__396, tmp8, nil); var tmp9 any = /*line :229:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 *lang.Compiler_AOTFn; var fnbody__398 any = A_arbace_java_io_eval1661000186_fn__1661000189_A_New(); var tmp12 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class; if



	fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_105, false, nil); A_arbace_java_io_eval1661000186_fn__1661000189_A_fn_class = fncls__397d; tmp12 = fncls__397d } else { tmp12 = fncls__397 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__398, tmp12, nil); return /*line :229:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, tmp11.Ref())) }





func A_arbace_java_io__init_A_Unit46__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(235, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_47; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__414 any = A_arbace_java_io_eval1661000192_fn__1661000193_A_New(); var tmp8 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class; if


	fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_java_io_eval1661000192_fn__1661000193_A_fn_class = fncls__413d; tmp8 = fncls__413d } else { tmp8 = fncls__413 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__414, tmp8, nil); var tmp9 any = /*line :235:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 *lang.Compiler_AOTFn; var fnbody__416 any = A_arbace_java_io_eval1661000192_fn__1661000195_A_New(); var tmp12 *jrt.Class; var fncls__415 *jrt.Class = A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class; if







	fncls__415 == nil { var fncls__415d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_107, false, nil); A_arbace_java_io_eval1661000192_fn__1661000195_A_fn_class = fncls__415d; tmp12 = fncls__415d } else { tmp12 = fncls__415 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__416, tmp12, nil); return /*line :235:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, tmp11.Ref())) }












func A_arbace_java_io__init_A_Unit47__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(248, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_48; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__432 any = A_arbace_java_io_eval1661000198_fn__1661000199_A_New(); var tmp8 *jrt.Class; var fncls__431 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class; if


	fncls__431 == nil { var fncls__431d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_108, false, nil); A_arbace_java_io_eval1661000198_fn__1661000199_A_fn_class = fncls__431d; tmp8 = fncls__431d } else { tmp8 = fncls__431 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__432, tmp8, nil); var tmp9 any = /*line :248:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 *lang.Compiler_AOTFn; var fnbody__434 any = A_arbace_java_io_eval1661000198_fn__1661000201_A_New(); var tmp12 *jrt.Class; var fncls__433 *jrt.Class = A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class; if



	fncls__433 == nil { var fncls__433d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_109, false, nil); A_arbace_java_io_eval1661000198_fn__1661000201_A_fn_class = fncls__433d; tmp12 = fncls__433d } else { tmp12 = fncls__433 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__434, tmp12, nil); return /*line :248:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, tmp11.Ref())) }





func A_arbace_java_io__init_A_Unit48__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(254, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_45; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__450 any = A_arbace_java_io_eval1661000204_fn__1661000205_A_New(); var tmp8 *jrt.Class; var fncls__449 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class; if


	fncls__449 == nil { var fncls__449d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); A_arbace_java_io_eval1661000204_fn__1661000205_A_fn_class = fncls__449d; tmp8 = fncls__449d } else { tmp8 = fncls__449 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__450, tmp8, nil); var tmp9 any = /*line :254:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 *lang.Compiler_AOTFn; var fnbody__452 any = A_arbace_java_io_eval1661000204_fn__1661000207_A_New(); var tmp12 *jrt.Class; var fncls__451 *jrt.Class = A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class; if







	fncls__451 == nil { var fncls__451d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, nil); A_arbace_java_io_eval1661000204_fn__1661000207_A_fn_class = fncls__451d; tmp12 = fncls__451d } else { tmp12 = fncls__451 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__452, tmp12, nil); return /*line :254:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, tmp11.Ref())) }













func A_arbace_java_io__init_A_Unit49__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(268, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_98; var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp5 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp6 any = A_arbace_java_io__init_A_const_83; var tmp7 *lang.Compiler_AOTFn; var fnbody__468 any = A_arbace_java_io_eval1661000210_fn__1661000211_A_New(); var tmp8 *jrt.Class; var fncls__467 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class; if


	fncls__467 == nil { var fncls__467d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, nil); A_arbace_java_io_eval1661000210_fn__1661000211_A_fn_class = fncls__467d; tmp8 = fncls__467d } else { tmp8 = fncls__467 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__468, tmp8, nil); var tmp9 any = /*line :268:1*/tmp7.Ref(); var tmp10 any = A_arbace_java_io__init_A_const_84; var tmp11 *lang.Compiler_AOTFn; var fnbody__470 any = A_arbace_java_io_eval1661000210_fn__1661000213_A_New(); var tmp12 *jrt.Class; var fncls__469 *jrt.Class = A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class; if



	fncls__469 == nil { var fncls__469d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_113, false, nil); A_arbace_java_io_eval1661000210_fn__1661000213_A_fn_class = fncls__469d; tmp12 = fncls__469d } else { tmp12 = fncls__469 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__470, tmp12, nil); return /*line :268:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4.Invoke_O_O_O_O_O__O(tmp5, tmp6, tmp9, tmp10, tmp11.Ref())) }





func A_arbace_java_io__init_A_Unit50__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(274, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_5.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_477 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_478 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_477, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_479 lang.IFn; if

	linked_478 == nil { ifn_479 = lang.IFn_Cast(root_477) } else { ifn_479 = nil }; var arg_480 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_481 any = A_arbace_java_io__init_A_const_83; var arg_482 any; var fnbody__484 any = A_arbace_java_io_eval1661000216_fn__1661000217_A_New(); var tmp5 *jrt.Class; var fncls__483 *jrt.Class = A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class; if
	fncls__483 == nil { var fncls__483d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, nil); A_arbace_java_io_eval1661000216_fn__1661000217_A_fn_class = fncls__483d; tmp5 = fncls__483d } else { tmp5 = fncls__483 }; arg_482 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__484, tmp5, nil); if /*line :276:1*/ linked_478 == nil { tmp4 = ifn_479.Invoke_O_O_O__O(arg_480, arg_481, arg_482) } else { tmp4 = linked_478.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_477, arg_480, arg_481, arg_482) }; return /*line :274:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit51__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(279, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_10.GetRawRoot__O(); var tmp3 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp4 any; var root_491 any = A_arbace_java_io__init_A_const_17.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_493 lang.IFn; if

	linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var arg_495 any = A_arbace_java_io__init_A_const_81; var arg_496 any; var fnbody__498 any = A_arbace_java_io_eval1661000220_fn__1661000221_A_New(); var tmp5 *jrt.Class; var fncls__497 *jrt.Class = A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class; if
	fncls__497 == nil { var fncls__497d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_115, false, nil); A_arbace_java_io_eval1661000220_fn__1661000221_A_fn_class = fncls__497d; tmp5 = fncls__497d } else { tmp5 = fncls__497 }; arg_496 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__498, tmp5, nil); if /*line :281:1*/ linked_492 == nil { tmp4 = ifn_493.Invoke_O_O_O__O(arg_494, arg_495, arg_496) } else { tmp4 = linked_492.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_491, arg_494, arg_495, arg_496) }; return /*line :279:1*/ tmp1.Invoke_O_O_O__O(tmp2, tmp3, tmp4) }




func A_arbace_java_io__init_A_Unit52__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(284, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_99; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_io__init_A_const_49.GetRawRoot__O(), A_arbace_java_io__init_A_const_80.GetRawRoot__O()) }



func A_arbace_java_io__init_A_Unit53__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(288, 1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_42.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_49.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_io__init_A_const_17.GetRawRoot__O()); var tmp4 any = A_arbace_java_io__init_A_const_80.GetRawRoot__O(); var tmp5 any = A_arbace_java_io__init_A_const_81; var tmp6 *lang.Compiler_AOTFn; var fnbody__520 any = A_arbace_java_io_eval1661000226_fn__1661000227_A_New(); var tmp7 *jrt.Class; var fncls__519 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class; if


	fncls__519 == nil { var fncls__519d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_116, false, nil); A_arbace_java_io_eval1661000226_fn__1661000227_A_fn_class = fncls__519d; tmp7 = fncls__519d } else { tmp7 = fncls__519 }; tmp6 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__520, tmp7, nil); var tmp8 any = /*line :288:1*/tmp6.Ref(); var tmp9 any = A_arbace_java_io__init_A_const_82; var tmp10 *lang.Compiler_AOTFn; var fnbody__522 any = A_arbace_java_io_eval1661000226_fn__1661000229_A_New(); var tmp11 *jrt.Class; var fncls__521 *jrt.Class = A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class; if





	fncls__521 == nil { var fncls__521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_117, false, nil); A_arbace_java_io_eval1661000226_fn__1661000229_A_fn_class = fncls__521d; tmp11 = fncls__521d } else { tmp11 = fncls__521 }; tmp10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__522, tmp11, nil); return /*line :288:1*/ tmp1.Invoke_O_O_O__O(nil, tmp2, tmp3.Invoke_O_O_O_O_O__O(tmp4, tmp5, tmp8, tmp9, tmp10.Ref())) }









func A_arbace_java_io__init_A_Unit54__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(298, 1); var v__1927000386__auto____1 any; var tmp1 *lang.Var = A_arbace_java_io__init_A_const_100; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_101)); v__1927000386__auto____1 = A_arbace_java_io__init_A_const_100; var tmp2 bool; var and__1927000168__auto____2 bool = jrt.NN(lang.Var_Cast(v__1927000386__auto____1)).HasRoot__Z(); if and__1927000168__auto____2 { var tmp3 any; var root_523 any = A_arbace_java_io__init_A_const_102.GetRawRoot__O(); var linked_524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_523, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_525 lang.IFn; if linked_524 == nil { ifn_525 = lang.IFn_Cast(root_523) } else { ifn_525 = nil }; var arg_526 any = v__1927000386__auto____1; if linked_524 == nil { tmp3 = ifn_525.Invoke_O__O(arg_526) } else { tmp3 = linked_524.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_523, arg_526) }; tmp2 = lang.MultiFn_InstanceOf(tmp3) } else { tmp2 = and__1927000168__auto____2 }; if tmp2 { return nil } else { var tmp4 *lang.Var = A_arbace_java_io__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_105)); var tmp5 *lang.Var = A_arbace_java_io__init_A_const_100; var tmp6 *jrt.String = Lit_118; var tmp7 *lang.Compiler_AOTFn; var fnbody__528 any = A_arbace_java_io_eval1661000232_fn__1661000233_A_New(); var tmp8 *jrt.Class
						var fncls__527 /*line :298:1*/*jrt.Class = A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class




	if fncls__527 == nil { var fncls__527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_119, false, nil); A_arbace_java_io_eval1661000232_fn__1661000233_A_fn_class = fncls__527d; tmp8 = fncls__527d } else { tmp8 = fncls__527 }; tmp7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__528, tmp8, nil)
//line :298:1
	var tmp9 lang.IFn = Up_Compiler_AOTFn_IFn(tmp7); var tmp10 any = A_arbace_java_io__init_A_const_103; tmp5.BindRoot_O__V(lang.MultiFn_New_String_IFn_O_IRef(tmp6, tmp9, tmp10, A_arbace_java_io__init_A_const_104)); return A_arbace_java_io__init_A_const_100 } }






func A_arbace_java_io__init_A_Unit55__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(305, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_106; var tmp3 *lang.Compiler_AOTFn; var fnbody__530 any = A_arbace_java_io_eval1661000236_fn__1661000237_A_New(); var tmp4 *jrt.Class; var fncls__529 *jrt.Class = A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class; if fncls__529 == nil { var fncls__529d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_120, false, nil); A_arbace_java_io_eval1661000236_fn__1661000237_A_fn_class = fncls__529d; tmp4 = fncls__529d } else { tmp4 = fncls__529 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__530, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_java_io__init_A_Unit56__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(313, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_107; var tmp3 *lang.Compiler_AOTFn; var fnbody__532 any = A_arbace_java_io_eval1661000240_fn__1661000241_A_New(); var tmp4 *jrt.Class; var fncls__531 *jrt.Class = A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class; if fncls__531 == nil { var fncls__531d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, nil); A_arbace_java_io_eval1661000240_fn__1661000241_A_fn_class = fncls__531d; tmp4 = fncls__531d } else { tmp4 = fncls__531 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__532, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }








func A_arbace_java_io__init_A_Unit57__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(322, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_108; var tmp3 *lang.Compiler_AOTFn; var fnbody__534 any = A_arbace_java_io_eval1661000244_fn__1661000245_A_New(); var tmp4 *jrt.Class; var fncls__533 *jrt.Class = A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class; if fncls__533 == nil { var fncls__533d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, nil); A_arbace_java_io_eval1661000244_fn__1661000245_A_fn_class = fncls__533d; tmp4 = fncls__533d } else { tmp4 = fncls__533 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__534, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_java_io__init_A_Unit58__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(326, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_109; var tmp3 *lang.Compiler_AOTFn; var fnbody__536 any = A_arbace_java_io_eval1661000248_fn__1661000249_A_New(); var tmp4 *jrt.Class; var fncls__535 *jrt.Class = A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class; if fncls__535 == nil { var fncls__535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_123, false, nil); A_arbace_java_io_eval1661000248_fn__1661000249_A_fn_class = fncls__535d; tmp4 = fncls__535d } else { tmp4 = fncls__535 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__536, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }










func A_arbace_java_io__init_A_Unit59__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(337, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_110; var tmp3 *lang.Compiler_AOTFn; var fnbody__538 any = A_arbace_java_io_eval1661000252_fn__1661000253_A_New(); var tmp4 *jrt.Class; var fncls__537 *jrt.Class = A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class; if fncls__537 == nil { var fncls__537d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, nil); A_arbace_java_io_eval1661000252_fn__1661000253_A_fn_class = fncls__537d; tmp4 = fncls__537d } else { tmp4 = fncls__537 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__538, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }







func A_arbace_java_io__init_A_Unit60__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(345, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_111; var tmp3 *lang.Compiler_AOTFn; var fnbody__540 any = A_arbace_java_io_eval1661000256_fn__1661000257_A_New(); var tmp4 *jrt.Class; var fncls__539 *jrt.Class = A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class; if fncls__539 == nil { var fncls__539d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, nil); A_arbace_java_io_eval1661000256_fn__1661000257_A_fn_class = fncls__539d; tmp4 = fncls__539d } else { tmp4 = fncls__539 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__540, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_java_io__init_A_Unit61__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(349, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_112; var tmp3 *lang.Compiler_AOTFn; var fnbody__542 any = A_arbace_java_io_eval1661000260_fn__1661000261_A_New(); var tmp4 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, nil); A_arbace_java_io_eval1661000260_fn__1661000261_A_fn_class = fncls__541d; tmp4 = fncls__541d } else { tmp4 = fncls__541 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__542, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_java_io__init_A_Unit62__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(353, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_113; var tmp3 *lang.Compiler_AOTFn; var fnbody__544 any = A_arbace_java_io_eval1661000264_fn__1661000265_A_New(); var tmp4 *jrt.Class; var fncls__543 *jrt.Class = A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class; if fncls__543 == nil { var fncls__543d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, nil); A_arbace_java_io_eval1661000264_fn__1661000265_A_fn_class = fncls__543d; tmp4 = fncls__543d } else { tmp4 = fncls__543 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__544, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }



func A_arbace_java_io__init_A_Unit63__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(357, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_114; var tmp3 *lang.Compiler_AOTFn; var fnbody__546 any = A_arbace_java_io_eval1661000268_fn__1661000269_A_New(); var tmp4 *jrt.Class; var fncls__545 *jrt.Class = A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class; if fncls__545 == nil { var fncls__545d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_java_io_eval1661000268_fn__1661000269_A_fn_class = fncls__545d; tmp4 = fncls__545d } else { tmp4 = fncls__545 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__546, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }





func A_arbace_java_io__init_A_Unit64__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(363, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_115; var tmp3 *lang.Compiler_AOTFn; var fnbody__548 any = A_arbace_java_io_eval1661000272_fn__1661000273_A_New(); var tmp4 *jrt.Class; var fncls__547 *jrt.Class = A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class; if fncls__547 == nil { var fncls__547d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, nil); A_arbace_java_io_eval1661000272_fn__1661000273_A_fn_class = fncls__547d; tmp4 = fncls__547d } else { tmp4 = fncls__547 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__548, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit65__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(366, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_116; var tmp3 *lang.Compiler_AOTFn; var fnbody__550 any = A_arbace_java_io_eval1661000276_fn__1661000277_A_New(); var tmp4 *jrt.Class; var fncls__549 *jrt.Class = A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class; if fncls__549 == nil { var fncls__549d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_130, false, nil); A_arbace_java_io_eval1661000276_fn__1661000277_A_fn_class = fncls__549d; tmp4 = fncls__549d } else { tmp4 = fncls__549 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__550, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit66__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(369, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = A_arbace_java_io__init_A_const_117; var tmp3 *lang.Compiler_AOTFn; var fnbody__552 any = A_arbace_java_io_eval1661000280_fn__1661000281_A_New(); var tmp4 *jrt.Class; var fncls__551 *jrt.Class = A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class; if fncls__551 == nil { var fncls__551d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_131, false, nil); A_arbace_java_io_eval1661000280_fn__1661000281_A_fn_class = fncls__551d; tmp4 = fncls__551d } else { tmp4 = fncls__551 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__552, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit67__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(372, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 *lang.Compiler_AOTFn; var fnbody__554 any = A_arbace_java_io_eval1661000284_fn__1661000285_A_New(); var tmp4 *jrt.Class; var fncls__553 *jrt.Class = A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class; if fncls__553 == nil { var fncls__553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, nil); A_arbace_java_io_eval1661000284_fn__1661000285_A_fn_class = fncls__553d; tmp4 = fncls__553d } else { tmp4 = fncls__553 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__554, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit68__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(375, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 *lang.Compiler_AOTFn; var fnbody__556 any = A_arbace_java_io_eval1661000288_fn__1661000289_A_New(); var tmp4 *jrt.Class; var fncls__555 *jrt.Class = A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class; if fncls__555 == nil { var fncls__555d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_java_io_eval1661000288_fn__1661000289_A_fn_class = fncls__555d; tmp4 = fncls__555d } else { tmp4 = fncls__555 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__556, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit69__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(378, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_10.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 *lang.Compiler_AOTFn; var fnbody__558 any = A_arbace_java_io_eval1661000292_fn__1661000293_A_New(); var tmp4 *jrt.Class; var fncls__557 *jrt.Class = A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class; if fncls__557 == nil { var fncls__557d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, nil); A_arbace_java_io_eval1661000292_fn__1661000293_A_fn_class = fncls__557d; tmp4 = fncls__557d } else { tmp4 = fncls__557 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__558, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit70__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(381, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_96); var tmp3 *lang.Compiler_AOTFn; var fnbody__560 any = A_arbace_java_io_eval1661000296_fn__1661000297_A_New(); var tmp4 *jrt.Class; var fncls__559 *jrt.Class = A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class; if fncls__559 == nil { var fncls__559d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, nil); A_arbace_java_io_eval1661000296_fn__1661000297_A_fn_class = fncls__559d; tmp4 = fncls__559d } else { tmp4 = fncls__559 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__560, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit71__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(384, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_94); var tmp3 *lang.Compiler_AOTFn; var fnbody__562 any = A_arbace_java_io_eval1661000300_fn__1661000301_A_New(); var tmp4 *jrt.Class; var fncls__561 *jrt.Class = A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class; if fncls__561 == nil { var fncls__561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_136, false, nil); A_arbace_java_io_eval1661000300_fn__1661000301_A_fn_class = fncls__561d; tmp4 = fncls__561d } else { tmp4 = fncls__561 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__562, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit72__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(387, 1); var tmp1 *lang.MultiFn = lang.MultiFn_Cast(A_arbace_java_io__init_A_const_100.GetRawRoot__O()); var tmp2 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_java_io__init_A_const_5.GetRawRoot__O(), A_arbace_java_io__init_A_const_46); var tmp3 *lang.Compiler_AOTFn; var fnbody__564 any = A_arbace_java_io_eval1661000304_fn__1661000305_A_New(); var tmp4 *jrt.Class; var fncls__563 *jrt.Class = A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class; if fncls__563 == nil { var fncls__563d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_137, false, nil); A_arbace_java_io_eval1661000304_fn__1661000305_A_fn_class = fncls__563d; tmp4 = fncls__563d } else { tmp4 = fncls__563 }; tmp3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__564, tmp4, nil); return jrt.NN(tmp1).AddMethod_O_IFn__MultiFn(tmp2, Up_Compiler_AOTFn_IFn(tmp3)).Ref() }


func A_arbace_java_io__init_A_Unit73__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(390, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_118; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__566 any = A_arbace_java_io_copy_A_New(); var tmp3 *jrt.Class; var fncls__565 *jrt.Class = A_arbace_java_io_copy_A_fn_class; if fncls__565 == nil { var fncls__565d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, true, nil); A_arbace_java_io_copy_A_fn_class = fncls__565d; tmp3 = fncls__565d } else { tmp3 = fncls__565 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__566, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_118; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_119)); return A_arbace_java_io__init_A_const_118 }
















func A_arbace_java_io__init_A_Unit74__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(407, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_120; var tmp2 *lang.Compiler_AOTFn; var fnbody__568 any = A_arbace_java_io_as_relative_path_A_New(); var tmp3 *jrt.Class; var fncls__567 *jrt.Class = A_arbace_java_io_as_relative_path_A_fn_class; if fncls__567 == nil { var fncls__567d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, nil); A_arbace_java_io_as_relative_path_A_fn_class = fncls__567d; tmp3 = fncls__567d } else { tmp3 = fncls__567 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__568, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_120; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_121)); return A_arbace_java_io__init_A_const_120 }









func A_arbace_java_io__init_A_Unit75__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(417, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_122; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__570 any = A_arbace_java_io_file_A_New(); var tmp3 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_java_io_file_A_fn_class; if fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_140, true, nil); A_arbace_java_io_file_A_fn_class = fncls__569d; tmp3 = fncls__569d } else { tmp3 = fncls__569 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__570, tmp3, nil, 2); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_122; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_123)); return A_arbace_java_io__init_A_const_122 }











func A_arbace_java_io__init_A_Unit76__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(429, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_124; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__572 any = A_arbace_java_io_delete_file_A_New(); var tmp3 *jrt.Class; var fncls__571 *jrt.Class = A_arbace_java_io_delete_file_A_fn_class; if fncls__571 == nil { var fncls__571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_141, true, nil); A_arbace_java_io_delete_file_A_fn_class = fncls__571d; tmp3 = fncls__571d } else { tmp3 = fncls__571 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__572, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_124; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_125)); return A_arbace_java_io__init_A_const_124 }







func A_arbace_java_io__init_A_Unit77__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(437, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_126; var tmp2 *lang.Compiler_AOTRestFn; var fnbody__574 any = A_arbace_java_io_make_parents_A_New(); var tmp3 *jrt.Class; var fncls__573 *jrt.Class = A_arbace_java_io_make_parents_A_fn_class; if fncls__573 == nil { var fncls__573d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_142, true, nil); A_arbace_java_io_make_parents_A_fn_class = fncls__573d; tmp3 = fncls__573d } else { tmp3 = fncls__573 }; tmp2 = lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(fnbody__574, tmp3, nil, 1); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_126; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_127)); return A_arbace_java_io__init_A_const_126 }







func A_arbace_java_io__init_A_Unit78__O() any { A_arbace_java_io__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(445, 1); var tmp1 *lang.Var = A_arbace_java_io__init_A_const_128; var tmp2 *lang.Compiler_AOTFn; var fnbody__576 any = A_arbace_java_io_resource_A_New(); var tmp3 *jrt.Class; var fncls__575 *jrt.Class = A_arbace_java_io_resource_A_fn_class; if fncls__575 == nil { var fncls__575d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_143, false, nil); A_arbace_java_io_resource_A_fn_class = fncls__575d; tmp3 = fncls__575d } else { tmp3 = fncls__575 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__576, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_java_io__init_A_const_128; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_java_io__init_A_const_129)); return A_arbace_java_io__init_A_const_128 }



type A_arbace_java_io__init_A struct{ jrt.Object }

var A_arbace_java_io__init_A_const_pool *jrt.RefArray

var A_arbace_java_io__init_A_const_0 *lang.Var

var A_arbace_java_io__init_A_const_1 any

var A_arbace_java_io__init_A_const_2 any

var A_arbace_java_io__init_A_const_3 any

var A_arbace_java_io__init_A_const_4 *lang.Var

var A_arbace_java_io__init_A_const_5 *lang.Var

var A_arbace_java_io__init_A_const_6 *lang.Var

var A_arbace_java_io__init_A_const_7 *lang.Var

var A_arbace_java_io__init_A_const_8 any

var A_arbace_java_io__init_A_const_9 any

var A_arbace_java_io__init_A_const_10 *lang.Var

var A_arbace_java_io__init_A_const_11 any

var A_arbace_java_io__init_A_const_12 *lang.Var

var A_arbace_java_io__init_A_const_13 any

var A_arbace_java_io__init_A_const_14 any

var A_arbace_java_io__init_A_const_15 *jrt.Class

var A_arbace_java_io__init_A_const_16 *lang.Var

var A_arbace_java_io__init_A_const_17 *lang.Var

var A_arbace_java_io__init_A_const_18 *lang.Keyword

var A_arbace_java_io__init_A_const_19 *lang.Var

var A_arbace_java_io__init_A_const_20 any

var A_arbace_java_io__init_A_const_21 *lang.Var

var A_arbace_java_io__init_A_const_22 *lang.Var

var A_arbace_java_io__init_A_const_23 any

var A_arbace_java_io__init_A_const_24 *lang.Keyword

var A_arbace_java_io__init_A_const_25 any

var A_arbace_java_io__init_A_const_26 *lang.Keyword

var A_arbace_java_io__init_A_const_27 *lang.Keyword

var A_arbace_java_io__init_A_const_28 any

var A_arbace_java_io__init_A_const_29 *lang.Keyword

var A_arbace_java_io__init_A_const_30 *lang.Var

var A_arbace_java_io__init_A_const_31 *lang.Var

var A_arbace_java_io__init_A_const_32 *lang.Var

var A_arbace_java_io__init_A_const_33 any

var A_arbace_java_io__init_A_const_34 any

var A_arbace_java_io__init_A_const_35 *lang.Keyword

var A_arbace_java_io__init_A_const_36 any

var A_arbace_java_io__init_A_const_37 any

var A_arbace_java_io__init_A_const_38 *lang.Var

var A_arbace_java_io__init_A_const_39 any

var A_arbace_java_io__init_A_const_40 *lang.Var

var A_arbace_java_io__init_A_const_41 any

var A_arbace_java_io__init_A_const_42 *lang.Var

var A_arbace_java_io__init_A_const_43 *lang.Keyword

var A_arbace_java_io__init_A_const_44 *lang.Keyword

var A_arbace_java_io__init_A_const_45 *jrt.Class

var A_arbace_java_io__init_A_const_46 *jrt.Class

var A_arbace_java_io__init_A_const_47 *jrt.Class

var A_arbace_java_io__init_A_const_48 *jrt.Class

var A_arbace_java_io__init_A_const_49 *lang.Var

var A_arbace_java_io__init_A_const_50 any

var A_arbace_java_io__init_A_const_51 any

var A_arbace_java_io__init_A_const_52 *jrt.Class

var A_arbace_java_io__init_A_const_53 any

var A_arbace_java_io__init_A_const_54 any

var A_arbace_java_io__init_A_const_55 any

var A_arbace_java_io__init_A_const_56 any

var A_arbace_java_io__init_A_const_57 any

var A_arbace_java_io__init_A_const_58 any

var A_arbace_java_io__init_A_const_59 any

var A_arbace_java_io__init_A_const_60 any

var A_arbace_java_io__init_A_const_61 any

var A_arbace_java_io__init_A_const_62 any

var A_arbace_java_io__init_A_const_63 any

var A_arbace_java_io__init_A_const_64 any

var A_arbace_java_io__init_A_const_65 any

var A_arbace_java_io__init_A_const_66 *lang.Var

var A_arbace_java_io__init_A_const_67 any

var A_arbace_java_io__init_A_const_68 *lang.Var

var A_arbace_java_io__init_A_const_69 any

var A_arbace_java_io__init_A_const_70 *lang.Var

var A_arbace_java_io__init_A_const_71 any

var A_arbace_java_io__init_A_const_72 *lang.Var

var A_arbace_java_io__init_A_const_73 any

var A_arbace_java_io__init_A_const_74 *lang.Var

var A_arbace_java_io__init_A_const_75 any

var A_arbace_java_io__init_A_const_76 *lang.Var

var A_arbace_java_io__init_A_const_77 any

var A_arbace_java_io__init_A_const_78 *lang.Var

var A_arbace_java_io__init_A_const_79 any

var A_arbace_java_io__init_A_const_80 *lang.Var

var A_arbace_java_io__init_A_const_81 *lang.Keyword

var A_arbace_java_io__init_A_const_82 *lang.Keyword

var A_arbace_java_io__init_A_const_83 *lang.Keyword

var A_arbace_java_io__init_A_const_84 *lang.Keyword

var A_arbace_java_io__init_A_const_85 any

var A_arbace_java_io__init_A_const_86 *lang.Var

var A_arbace_java_io__init_A_const_87 any

var A_arbace_java_io__init_A_const_88 *lang.Var

var A_arbace_java_io__init_A_const_89 any

var A_arbace_java_io__init_A_const_90 *jrt.Class

var A_arbace_java_io__init_A_const_91 *jrt.Class

var A_arbace_java_io__init_A_const_92 *jrt.Class

var A_arbace_java_io__init_A_const_93 *jrt.Class

var A_arbace_java_io__init_A_const_94 *jrt.Class

var A_arbace_java_io__init_A_const_95 *jrt.Class

var A_arbace_java_io__init_A_const_96 *jrt.Class

var A_arbace_java_io__init_A_const_97 *jrt.Class

var A_arbace_java_io__init_A_const_98 *jrt.Class

var A_arbace_java_io__init_A_const_99 *jrt.Class

var A_arbace_java_io__init_A_const_100 *lang.Var

var A_arbace_java_io__init_A_const_101 any

var A_arbace_java_io__init_A_const_102 *lang.Var

var A_arbace_java_io__init_A_const_103 *lang.Keyword

var A_arbace_java_io__init_A_const_104 *lang.Var

var A_arbace_java_io__init_A_const_105 any

var A_arbace_java_io__init_A_const_106 any

var A_arbace_java_io__init_A_const_107 any

var A_arbace_java_io__init_A_const_108 any

var A_arbace_java_io__init_A_const_109 any

var A_arbace_java_io__init_A_const_110 any

var A_arbace_java_io__init_A_const_111 any

var A_arbace_java_io__init_A_const_112 any

var A_arbace_java_io__init_A_const_113 any

var A_arbace_java_io__init_A_const_114 any

var A_arbace_java_io__init_A_const_115 any

var A_arbace_java_io__init_A_const_116 any

var A_arbace_java_io__init_A_const_117 any

var A_arbace_java_io__init_A_const_118 *lang.Var

var A_arbace_java_io__init_A_const_119 any

var A_arbace_java_io__init_A_const_120 *lang.Var

var A_arbace_java_io__init_A_const_121 any

var A_arbace_java_io__init_A_const_122 *lang.Var

var A_arbace_java_io__init_A_const_123 any

var A_arbace_java_io__init_A_const_124 *lang.Var

var A_arbace_java_io__init_A_const_125 any

var A_arbace_java_io__init_A_const_126 *lang.Var

var A_arbace_java_io__init_A_const_127 any

var A_arbace_java_io__init_A_const_128 *lang.Var

var A_arbace_java_io__init_A_const_129 any

var A_arbace_java_io__init_A_init jrt.ClassInit

func A_arbace_java_io__init_A_Init() { if !A_arbace_java_io__init_A_init.Done() { A_arbace_java_io__init_A_init.Run(A_arbace_java_io__init_A_clinit) } }

func A_arbace_java_io__init_A_clinit() { A_arbace_java_io__init_A_clinit_p0(); A_arbace_java_io__init_A_clinit_p1(); A_arbace_java_io__init_A_clinit_p2(); A_arbace_java_io__init_A_clinit_p3(); A_arbace_java_io__init_A_clinit_p4(); A_arbace_java_io__init_A_clinit_p5(); A_arbace_java_io__init_A_clinit_p6(); A_arbace_java_io__init_A_clinit_p7(); A_arbace_java_io__init_A_clinit_p8(); A_arbace_java_io__init_A_clinit_p9() }

func A_arbace_java_io__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_io__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_61, 175); A_arbace_java_io__init_A_const_0 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[45]); A_arbace_java_io__init_A_const_1 = A_arbace_java_io__init_A_const_pool.A[46]; A_arbace_java_io__init_A_const_2 = A_arbace_java_io__init_A_const_pool.A[47]; A_arbace_java_io__init_A_const_3 = A_arbace_java_io__init_A_const_pool.A[48]; A_arbace_java_io__init_A_const_4 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[49]); A_arbace_java_io__init_A_const_5 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[50]); A_arbace_java_io__init_A_const_6 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[51]); A_arbace_java_io__init_A_const_7 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[52]); A_arbace_java_io__init_A_const_8 = A_arbace_java_io__init_A_const_pool.A[53]; A_arbace_java_io__init_A_const_9 = A_arbace_java_io__init_A_const_pool.A[54]; A_arbace_java_io__init_A_const_10 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[55]); A_arbace_java_io__init_A_const_11 = A_arbace_java_io__init_A_const_pool.A[56] }

func A_arbace_java_io__init_A_clinit_p1() { A_arbace_java_io__init_A_const_12 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[57]); A_arbace_java_io__init_A_const_13 = A_arbace_java_io__init_A_const_pool.A[58]; A_arbace_java_io__init_A_const_14 = A_arbace_java_io__init_A_const_pool.A[59]; A_arbace_java_io__init_A_const_15 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[60]); A_arbace_java_io__init_A_const_16 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[61]); A_arbace_java_io__init_A_const_17 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[62]); A_arbace_java_io__init_A_const_18 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[63]); A_arbace_java_io__init_A_const_19 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[64]); A_arbace_java_io__init_A_const_20 = A_arbace_java_io__init_A_const_pool.A[65]; A_arbace_java_io__init_A_const_21 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[66]); A_arbace_java_io__init_A_const_22 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[67]); A_arbace_java_io__init_A_const_23 = A_arbace_java_io__init_A_const_pool.A[68]; A_arbace_java_io__init_A_const_24 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[69]) }

func A_arbace_java_io__init_A_clinit_p2() { A_arbace_java_io__init_A_const_25 = A_arbace_java_io__init_A_const_pool.A[70]; A_arbace_java_io__init_A_const_26 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[71]); A_arbace_java_io__init_A_const_27 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[72]); A_arbace_java_io__init_A_const_28 = A_arbace_java_io__init_A_const_pool.A[73]; A_arbace_java_io__init_A_const_29 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[74]); A_arbace_java_io__init_A_const_30 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[75]); A_arbace_java_io__init_A_const_31 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[76]); A_arbace_java_io__init_A_const_32 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[77]); A_arbace_java_io__init_A_const_33 = A_arbace_java_io__init_A_const_pool.A[78]; A_arbace_java_io__init_A_const_34 = A_arbace_java_io__init_A_const_pool.A[79]; A_arbace_java_io__init_A_const_35 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[80]); A_arbace_java_io__init_A_const_36 = A_arbace_java_io__init_A_const_pool.A[81]; A_arbace_java_io__init_A_const_37 = A_arbace_java_io__init_A_const_pool.A[82] }

func A_arbace_java_io__init_A_clinit_p3() { A_arbace_java_io__init_A_const_38 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[83]); A_arbace_java_io__init_A_const_39 = A_arbace_java_io__init_A_const_pool.A[84]; A_arbace_java_io__init_A_const_40 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[85]); A_arbace_java_io__init_A_const_41 = A_arbace_java_io__init_A_const_pool.A[86]; A_arbace_java_io__init_A_const_42 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[87]); A_arbace_java_io__init_A_const_43 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[88]); A_arbace_java_io__init_A_const_44 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[89]); A_arbace_java_io__init_A_const_45 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[90]); A_arbace_java_io__init_A_const_46 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[91]); A_arbace_java_io__init_A_const_47 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[92]); A_arbace_java_io__init_A_const_48 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[93]); A_arbace_java_io__init_A_const_49 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[94]) }

func A_arbace_java_io__init_A_clinit_p4() { A_arbace_java_io__init_A_const_50 = A_arbace_java_io__init_A_const_pool.A[95]; A_arbace_java_io__init_A_const_51 = A_arbace_java_io__init_A_const_pool.A[96]; A_arbace_java_io__init_A_const_52 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[97]); A_arbace_java_io__init_A_const_53 = A_arbace_java_io__init_A_const_pool.A[98]; A_arbace_java_io__init_A_const_54 = A_arbace_java_io__init_A_const_pool.A[99]; A_arbace_java_io__init_A_const_55 = A_arbace_java_io__init_A_const_pool.A[100]; A_arbace_java_io__init_A_const_56 = A_arbace_java_io__init_A_const_pool.A[101]; A_arbace_java_io__init_A_const_57 = A_arbace_java_io__init_A_const_pool.A[102]; A_arbace_java_io__init_A_const_58 = A_arbace_java_io__init_A_const_pool.A[103]; A_arbace_java_io__init_A_const_59 = A_arbace_java_io__init_A_const_pool.A[104]; A_arbace_java_io__init_A_const_60 = A_arbace_java_io__init_A_const_pool.A[105]; A_arbace_java_io__init_A_const_61 = A_arbace_java_io__init_A_const_pool.A[106]; A_arbace_java_io__init_A_const_62 = A_arbace_java_io__init_A_const_pool.A[107]; A_arbace_java_io__init_A_const_63 = A_arbace_java_io__init_A_const_pool.A[108]; A_arbace_java_io__init_A_const_64 = A_arbace_java_io__init_A_const_pool.A[109] }

func A_arbace_java_io__init_A_clinit_p5() { A_arbace_java_io__init_A_const_65 = A_arbace_java_io__init_A_const_pool.A[110]; A_arbace_java_io__init_A_const_66 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[111]); A_arbace_java_io__init_A_const_67 = A_arbace_java_io__init_A_const_pool.A[112]; A_arbace_java_io__init_A_const_68 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[113]); A_arbace_java_io__init_A_const_69 = A_arbace_java_io__init_A_const_pool.A[114]; A_arbace_java_io__init_A_const_70 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[115]); A_arbace_java_io__init_A_const_71 = A_arbace_java_io__init_A_const_pool.A[116]; A_arbace_java_io__init_A_const_72 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[117]); A_arbace_java_io__init_A_const_73 = A_arbace_java_io__init_A_const_pool.A[118]; A_arbace_java_io__init_A_const_74 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[119]); A_arbace_java_io__init_A_const_75 = A_arbace_java_io__init_A_const_pool.A[120]; A_arbace_java_io__init_A_const_76 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[121]); A_arbace_java_io__init_A_const_77 = A_arbace_java_io__init_A_const_pool.A[122] }

func A_arbace_java_io__init_A_clinit_p6() { A_arbace_java_io__init_A_const_78 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[123]); A_arbace_java_io__init_A_const_79 = A_arbace_java_io__init_A_const_pool.A[124]; A_arbace_java_io__init_A_const_80 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[125]); A_arbace_java_io__init_A_const_81 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[126]); A_arbace_java_io__init_A_const_82 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[127]); A_arbace_java_io__init_A_const_83 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[128]); A_arbace_java_io__init_A_const_84 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[129]); A_arbace_java_io__init_A_const_85 = A_arbace_java_io__init_A_const_pool.A[130]; A_arbace_java_io__init_A_const_86 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[131]); A_arbace_java_io__init_A_const_87 = A_arbace_java_io__init_A_const_pool.A[132]; A_arbace_java_io__init_A_const_88 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[133]); A_arbace_java_io__init_A_const_89 = A_arbace_java_io__init_A_const_pool.A[134]; A_arbace_java_io__init_A_const_90 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[135]) }

func A_arbace_java_io__init_A_clinit_p7() { A_arbace_java_io__init_A_const_91 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[136]); A_arbace_java_io__init_A_const_92 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[137]); A_arbace_java_io__init_A_const_93 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[138]); A_arbace_java_io__init_A_const_94 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[139]); A_arbace_java_io__init_A_const_95 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[140]); A_arbace_java_io__init_A_const_96 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[141]); A_arbace_java_io__init_A_const_97 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[142]); A_arbace_java_io__init_A_const_98 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[143]); A_arbace_java_io__init_A_const_99 = jrt.Class_Cast(A_arbace_java_io__init_A_const_pool.A[144]); A_arbace_java_io__init_A_const_100 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[145]); A_arbace_java_io__init_A_const_101 = A_arbace_java_io__init_A_const_pool.A[146]; A_arbace_java_io__init_A_const_102 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[147]) }

func A_arbace_java_io__init_A_clinit_p8() { A_arbace_java_io__init_A_const_103 = lang.Keyword_Cast(A_arbace_java_io__init_A_const_pool.A[148]); A_arbace_java_io__init_A_const_104 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[149]); A_arbace_java_io__init_A_const_105 = A_arbace_java_io__init_A_const_pool.A[150]; A_arbace_java_io__init_A_const_106 = A_arbace_java_io__init_A_const_pool.A[151]; A_arbace_java_io__init_A_const_107 = A_arbace_java_io__init_A_const_pool.A[152]; A_arbace_java_io__init_A_const_108 = A_arbace_java_io__init_A_const_pool.A[153]; A_arbace_java_io__init_A_const_109 = A_arbace_java_io__init_A_const_pool.A[154]; A_arbace_java_io__init_A_const_110 = A_arbace_java_io__init_A_const_pool.A[155]; A_arbace_java_io__init_A_const_111 = A_arbace_java_io__init_A_const_pool.A[156]; A_arbace_java_io__init_A_const_112 = A_arbace_java_io__init_A_const_pool.A[157]; A_arbace_java_io__init_A_const_113 = A_arbace_java_io__init_A_const_pool.A[158]; A_arbace_java_io__init_A_const_114 = A_arbace_java_io__init_A_const_pool.A[159]; A_arbace_java_io__init_A_const_115 = A_arbace_java_io__init_A_const_pool.A[160]; A_arbace_java_io__init_A_const_116 = A_arbace_java_io__init_A_const_pool.A[161]; A_arbace_java_io__init_A_const_117 = A_arbace_java_io__init_A_const_pool.A[162] }

func A_arbace_java_io__init_A_clinit_p9() { A_arbace_java_io__init_A_const_118 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[163]); A_arbace_java_io__init_A_const_119 = A_arbace_java_io__init_A_const_pool.A[164]; A_arbace_java_io__init_A_const_120 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[165]); A_arbace_java_io__init_A_const_121 = A_arbace_java_io__init_A_const_pool.A[166]; A_arbace_java_io__init_A_const_122 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[167]); A_arbace_java_io__init_A_const_123 = A_arbace_java_io__init_A_const_pool.A[168]; A_arbace_java_io__init_A_const_124 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[169]); A_arbace_java_io__init_A_const_125 = A_arbace_java_io__init_A_const_pool.A[170]; A_arbace_java_io__init_A_const_126 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[171]); A_arbace_java_io__init_A_const_127 = A_arbace_java_io__init_A_const_pool.A[172]; A_arbace_java_io__init_A_const_128 = lang.Var_Cast(A_arbace_java_io__init_A_const_pool.A[173]); A_arbace_java_io__init_A_const_129 = A_arbace_java_io__init_A_const_pool.A[174] }

func A_arbace_java_io__init_A_New() *A_arbace_java_io__init_A { A_arbace_java_io__init_A_Init(); t := &A_arbace_java_io__init_A{}; t.Ctor(); return t }

func (t *A_arbace_java_io__init_A) Ctor() {}

func (t *A_arbace_java_io__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_io__init_A) GetClass__Class() *jrt.Class { return A_arbace_java_io__init_A_class }

func (t *A_arbace_java_io__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_io__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_io__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_io__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_io__init_A); return ok }

func A_arbace_java_io__init_A_Cast(x any) *A_arbace_java_io__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_io__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_io__init_A_class)) }; return v }
