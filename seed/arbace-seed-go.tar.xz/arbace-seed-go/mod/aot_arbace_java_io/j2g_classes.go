//line j2g_classes.ae:1
package aot_arbace_java_io

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_java_io_append_QMARK__A_class, Name: "arbace.java.io$append_QMARK_", Modifiers: 25, Simple: "append_QMARK_", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_append_QMARK__A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_as_relative_path_A_class, Name: "arbace.java.io$as_relative_path", Modifiers: 25, Simple: "as_relative_path", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_as_relative_path_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_buffer_size_A_class, Name: "arbace.java.io$buffer_size", Modifiers: 25, Simple: "buffer_size", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_buffer_size_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_copy_A_class, Name: "arbace.java.io$copy", Modifiers: 25, Simple: "copy", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_copy_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_delete_file_A_class, Name: "arbace.java.io$delete_file", Modifiers: 25, Simple: "delete_file", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_delete_file_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_encoding_A_class, Name: "arbace.java.io$encoding", Modifiers: 25, Simple: "encoding", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_encoding_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_class, Name: "arbace.java.io$escaped_utf8_urlstring__GT_str", Modifiers: 25, Simple: "escaped_utf8_urlstring__GT_str", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_escaped_utf8_urlstring__GT_str_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_class, Name: "arbace.java.io$eval1661000004$loading__1927001464__auto____1661000005", Modifiers: 25, Simple: "loading__1927001464__auto____1661000005", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000008_fn__1661000009_A_class, Name: "arbace.java.io$eval1661000008$fn__1661000009", Modifiers: 25, Simple: "fn__1661000009", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000008_fn__1661000009_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000024_fn__1661000025_A_class, Name: "arbace.java.io$eval1661000024$fn__1661000025", Modifiers: 25, Simple: "fn__1661000025", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_fn__1661000025_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000024_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_class, Name: "arbace.java.io$eval1661000024$fn__1661000025$G__1661000014__1661000030", Modifiers: 25, Simple: "G__1661000014__1661000030", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000024_fn__1661000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_class, Name: "arbace.java.io$eval1661000024$fn__1661000025$G__1661000015__1661000027", Modifiers: 25, Simple: "G__1661000015__1661000027", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000024_fn__1661000025_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000024_fn__1661000033_A_class, Name: "arbace.java.io$eval1661000024$fn__1661000033", Modifiers: 25, Simple: "fn__1661000033", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_fn__1661000033_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000024_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_class, Name: "arbace.java.io$eval1661000024$fn__1661000033$G__1661000016__1661000038", Modifiers: 25, Simple: "G__1661000016__1661000038", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000024_fn__1661000033_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_class, Name: "arbace.java.io$eval1661000024$fn__1661000033$G__1661000017__1661000035", Modifiers: 25, Simple: "G__1661000017__1661000035", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000024_fn__1661000033_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000047_fn__1661000048_A_class, Name: "arbace.java.io$eval1661000047$fn__1661000048", Modifiers: 25, Simple: "fn__1661000048", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000047_fn__1661000048_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000047_fn__1661000050_A_class, Name: "arbace.java.io$eval1661000047$fn__1661000050", Modifiers: 25, Simple: "fn__1661000050", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000047_fn__1661000050_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000047_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000053_fn__1661000054_A_class, Name: "arbace.java.io$eval1661000053$fn__1661000054", Modifiers: 25, Simple: "fn__1661000054", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000053_fn__1661000054_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000053_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000053_fn__1661000056_A_class, Name: "arbace.java.io$eval1661000053$fn__1661000056", Modifiers: 25, Simple: "fn__1661000056", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000053_fn__1661000056_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000053_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000059_fn__1661000060_A_class, Name: "arbace.java.io$eval1661000059$fn__1661000060", Modifiers: 25, Simple: "fn__1661000060", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000059_fn__1661000060_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000059_fn__1661000062_A_class, Name: "arbace.java.io$eval1661000059$fn__1661000062", Modifiers: 25, Simple: "fn__1661000062", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000059_fn__1661000062_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000059_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000065_fn__1661000066_A_class, Name: "arbace.java.io$eval1661000065$fn__1661000066", Modifiers: 25, Simple: "fn__1661000066", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000065_fn__1661000066_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000065_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000065_fn__1661000068_A_class, Name: "arbace.java.io$eval1661000065$fn__1661000068", Modifiers: 25, Simple: "fn__1661000068", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000065_fn__1661000068_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000065_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000071_fn__1661000072_A_class, Name: "arbace.java.io$eval1661000071$fn__1661000072", Modifiers: 25, Simple: "fn__1661000072", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000071_fn__1661000072_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000071_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000071_fn__1661000074_A_class, Name: "arbace.java.io$eval1661000071$fn__1661000074", Modifiers: 25, Simple: "fn__1661000074", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000071_fn__1661000074_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000071_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000092_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000092", Modifiers: 25, Simple: "fn__1661000092", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000092_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000092$G__1661000081__1661000099", Modifiers: 25, Simple: "G__1661000081__1661000099", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000092$G__1661000082__1661000095", Modifiers: 25, Simple: "G__1661000082__1661000095", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000092_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000102_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000102", Modifiers: 25, Simple: "fn__1661000102", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000102_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000102$G__1661000083__1661000109", Modifiers: 25, Simple: "G__1661000083__1661000109", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000102_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000102$G__1661000084__1661000105", Modifiers: 25, Simple: "G__1661000084__1661000105", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000102_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000112_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000112", Modifiers: 25, Simple: "fn__1661000112", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000112_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000112$G__1661000077__1661000119", Modifiers: 25, Simple: "G__1661000077__1661000119", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000112_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000112$G__1661000078__1661000115", Modifiers: 25, Simple: "G__1661000078__1661000115", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000112_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000122_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000122", Modifiers: 25, Simple: "fn__1661000122", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000122_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000122$G__1661000079__1661000129", Modifiers: 25, Simple: "G__1661000079__1661000129", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_class, Name: "arbace.java.io$eval1661000091$fn__1661000122$G__1661000080__1661000125", Modifiers: 25, Simple: "G__1661000080__1661000125", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000091_fn__1661000122_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000154_fn__1661000155_A_class, Name: "arbace.java.io$eval1661000154$fn__1661000155", Modifiers: 25, Simple: "fn__1661000155", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000154_fn__1661000155_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000154_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000158_fn__1661000159_A_class, Name: "arbace.java.io$eval1661000158$fn__1661000159", Modifiers: 25, Simple: "fn__1661000159", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000158_fn__1661000159_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000158_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000162_fn__1661000163_A_class, Name: "arbace.java.io$eval1661000162$fn__1661000163", Modifiers: 25, Simple: "fn__1661000163", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000162_fn__1661000163_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000162_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000166_fn__1661000167_A_class, Name: "arbace.java.io$eval1661000166$fn__1661000167", Modifiers: 25, Simple: "fn__1661000167", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000166_fn__1661000167_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000166_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000170_fn__1661000171_A_class, Name: "arbace.java.io$eval1661000170$fn__1661000171", Modifiers: 25, Simple: "fn__1661000171", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000170_fn__1661000171_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000170_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000174_fn__1661000175_A_class, Name: "arbace.java.io$eval1661000174$fn__1661000175", Modifiers: 25, Simple: "fn__1661000175", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000174_fn__1661000175_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000174_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000178_fn__1661000179_A_class, Name: "arbace.java.io$eval1661000178$fn__1661000179", Modifiers: 25, Simple: "fn__1661000179", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000178_fn__1661000179_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000178_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000182_fn__1661000183_A_class, Name: "arbace.java.io$eval1661000182$fn__1661000183", Modifiers: 25, Simple: "fn__1661000183", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000182_fn__1661000183_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000182_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000186_fn__1661000187_A_class, Name: "arbace.java.io$eval1661000186$fn__1661000187", Modifiers: 25, Simple: "fn__1661000187", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000186_fn__1661000187_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000186_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000186_fn__1661000189_A_class, Name: "arbace.java.io$eval1661000186$fn__1661000189", Modifiers: 25, Simple: "fn__1661000189", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000186_fn__1661000189_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000186_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000192_fn__1661000193_A_class, Name: "arbace.java.io$eval1661000192$fn__1661000193", Modifiers: 25, Simple: "fn__1661000193", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000192_fn__1661000193_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000192_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000192_fn__1661000195_A_class, Name: "arbace.java.io$eval1661000192$fn__1661000195", Modifiers: 25, Simple: "fn__1661000195", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000192_fn__1661000195_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000192_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000198_fn__1661000199_A_class, Name: "arbace.java.io$eval1661000198$fn__1661000199", Modifiers: 25, Simple: "fn__1661000199", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000198_fn__1661000199_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000198_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000198_fn__1661000201_A_class, Name: "arbace.java.io$eval1661000198$fn__1661000201", Modifiers: 25, Simple: "fn__1661000201", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000198_fn__1661000201_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000198_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000204_fn__1661000205_A_class, Name: "arbace.java.io$eval1661000204$fn__1661000205", Modifiers: 25, Simple: "fn__1661000205", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000204_fn__1661000205_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000204_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000204_fn__1661000207_A_class, Name: "arbace.java.io$eval1661000204$fn__1661000207", Modifiers: 25, Simple: "fn__1661000207", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000204_fn__1661000207_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000204_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000210_fn__1661000211_A_class, Name: "arbace.java.io$eval1661000210$fn__1661000211", Modifiers: 25, Simple: "fn__1661000211", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000210_fn__1661000211_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000210_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000210_fn__1661000213_A_class, Name: "arbace.java.io$eval1661000210$fn__1661000213", Modifiers: 25, Simple: "fn__1661000213", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000210_fn__1661000213_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000210_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000216_fn__1661000217_A_class, Name: "arbace.java.io$eval1661000216$fn__1661000217", Modifiers: 25, Simple: "fn__1661000217", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000216_fn__1661000217_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000216_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000220_fn__1661000221_A_class, Name: "arbace.java.io$eval1661000220$fn__1661000221", Modifiers: 25, Simple: "fn__1661000221", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000220_fn__1661000221_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000220_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000226_fn__1661000227_A_class, Name: "arbace.java.io$eval1661000226$fn__1661000227", Modifiers: 25, Simple: "fn__1661000227", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000226_fn__1661000227_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000226_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000226_fn__1661000229_A_class, Name: "arbace.java.io$eval1661000226$fn__1661000229", Modifiers: 25, Simple: "fn__1661000229", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000226_fn__1661000229_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000226_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000232_fn__1661000233_A_class, Name: "arbace.java.io$eval1661000232$fn__1661000233", Modifiers: 25, Simple: "fn__1661000233", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000232_fn__1661000233_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000232_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000236_fn__1661000237_A_class, Name: "arbace.java.io$eval1661000236$fn__1661000237", Modifiers: 25, Simple: "fn__1661000237", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000236_fn__1661000237_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000236_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000240_fn__1661000241_A_class, Name: "arbace.java.io$eval1661000240$fn__1661000241", Modifiers: 25, Simple: "fn__1661000241", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000240_fn__1661000241_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000240_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000244_fn__1661000245_A_class, Name: "arbace.java.io$eval1661000244$fn__1661000245", Modifiers: 25, Simple: "fn__1661000245", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000244_fn__1661000245_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000244_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000248_fn__1661000249_A_class, Name: "arbace.java.io$eval1661000248$fn__1661000249", Modifiers: 25, Simple: "fn__1661000249", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000248_fn__1661000249_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000248_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000252_fn__1661000253_A_class, Name: "arbace.java.io$eval1661000252$fn__1661000253", Modifiers: 25, Simple: "fn__1661000253", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000252_fn__1661000253_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000252_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000256_fn__1661000257_A_class, Name: "arbace.java.io$eval1661000256$fn__1661000257", Modifiers: 25, Simple: "fn__1661000257", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000256_fn__1661000257_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000256_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000260_fn__1661000261_A_class, Name: "arbace.java.io$eval1661000260$fn__1661000261", Modifiers: 25, Simple: "fn__1661000261", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000260_fn__1661000261_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000260_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000264_fn__1661000265_A_class, Name: "arbace.java.io$eval1661000264$fn__1661000265", Modifiers: 25, Simple: "fn__1661000265", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000264_fn__1661000265_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000264_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000268_fn__1661000269_A_class, Name: "arbace.java.io$eval1661000268$fn__1661000269", Modifiers: 25, Simple: "fn__1661000269", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000268_fn__1661000269_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000268_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000272_fn__1661000273_A_class, Name: "arbace.java.io$eval1661000272$fn__1661000273", Modifiers: 25, Simple: "fn__1661000273", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000272_fn__1661000273_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000272_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000276_fn__1661000277_A_class, Name: "arbace.java.io$eval1661000276$fn__1661000277", Modifiers: 25, Simple: "fn__1661000277", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000276_fn__1661000277_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000276_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000280_fn__1661000281_A_class, Name: "arbace.java.io$eval1661000280$fn__1661000281", Modifiers: 25, Simple: "fn__1661000281", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000280_fn__1661000281_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000280_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000284_fn__1661000285_A_class, Name: "arbace.java.io$eval1661000284$fn__1661000285", Modifiers: 25, Simple: "fn__1661000285", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000284_fn__1661000285_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000284_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000288_fn__1661000289_A_class, Name: "arbace.java.io$eval1661000288$fn__1661000289", Modifiers: 25, Simple: "fn__1661000289", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000288_fn__1661000289_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000288_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000292_fn__1661000293_A_class, Name: "arbace.java.io$eval1661000292$fn__1661000293", Modifiers: 25, Simple: "fn__1661000293", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000292_fn__1661000293_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000292_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000296_fn__1661000297_A_class, Name: "arbace.java.io$eval1661000296$fn__1661000297", Modifiers: 25, Simple: "fn__1661000297", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000296_fn__1661000297_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000296_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000300_fn__1661000301_A_class, Name: "arbace.java.io$eval1661000300$fn__1661000301", Modifiers: 25, Simple: "fn__1661000301", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000300_fn__1661000301_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000300_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_eval1661000304_fn__1661000305_A_class, Name: "arbace.java.io$eval1661000304$fn__1661000305", Modifiers: 25, Simple: "fn__1661000305", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000304_fn__1661000305_A", Source: "io.ae", Declaring: &A_arbace_java_io_eval1661000304_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_file_A_class, Name: "arbace.java.io$file", Modifiers: 25, Simple: "file", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_file_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_fn__1661000144_A_class, Name: "arbace.java.io$fn__1661000144", Modifiers: 25, Simple: "fn__1661000144", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_fn__1661000144_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_fn__1661000146_A_class, Name: "arbace.java.io$fn__1661000146", Modifiers: 25, Simple: "fn__1661000146", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_fn__1661000146_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_fn__1661000148_A_class, Name: "arbace.java.io$fn__1661000148", Modifiers: 25, Simple: "fn__1661000148", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_fn__1661000148_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_fn__1661000150_A_class, Name: "arbace.java.io$fn__1661000150", Modifiers: 25, Simple: "fn__1661000150", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_fn__1661000150_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_input_stream_A_class, Name: "arbace.java.io$input_stream", Modifiers: 25, Simple: "input_stream", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_input_stream_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_inputstream__GT_reader_A_class, Name: "arbace.java.io$inputstream__GT_reader", Modifiers: 25, Simple: "inputstream__GT_reader", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_inputstream__GT_reader_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_make_parents_A_class, Name: "arbace.java.io$make_parents", Modifiers: 25, Simple: "make_parents", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_make_parents_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_output_stream_A_class, Name: "arbace.java.io$output_stream", Modifiers: 25, Simple: "output_stream", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_output_stream_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_outputstream__GT_writer_A_class, Name: "arbace.java.io$outputstream__GT_writer", Modifiers: 25, Simple: "outputstream__GT_writer", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_outputstream__GT_writer_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_reader_A_class, Name: "arbace.java.io$reader", Modifiers: 25, Simple: "reader", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_reader_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_resource_A_class, Name: "arbace.java.io$resource", Modifiers: 25, Simple: "resource", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_resource_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_io_writer_A_class, Name: "arbace.java.io$writer", Modifiers: 25, Simple: "writer", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_writer_A", Source: "io.ae", Declaring: &A_arbace_java_io_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_java_io_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_A_New()}; return nil }

var A_arbace_java_io_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_A_new}

var A_arbace_java_io_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_io.A_arbace_java_io_A"})

func init() { i := A_arbace_java_io_A_class.Info(); i.IsInstance = A_arbace_java_io_A_InstanceOf; i.Init = A_arbace_java_io_A_Init; i.Table = A_arbace_java_io_A_members }

var A_arbace_java_io_append_QMARK__A_class *jrt.Class

var A_arbace_java_io_as_relative_path_A_class *jrt.Class

var A_arbace_java_io_buffer_size_A_class *jrt.Class

var A_arbace_java_io_copy_A_class *jrt.Class

var A_arbace_java_io_delete_file_A_class *jrt.Class

var A_arbace_java_io_encoding_A_class *jrt.Class

var A_arbace_java_io_escaped_utf8_urlstring__GT_str_A_class *jrt.Class

func A_arbace_java_io_eval1661000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000004_A_New()}; return nil }

var A_arbace_java_io_eval1661000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000004_A_new}

var A_arbace_java_io_eval1661000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000004", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000004_A"})

func init() { i := A_arbace_java_io_eval1661000004_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000004_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000004_A_members }

var A_arbace_java_io_eval1661000004_loading__1927001464__auto____1661000005_A_class *jrt.Class

func A_arbace_java_io_eval1661000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000008_A_New()}; return nil }

var A_arbace_java_io_eval1661000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000008_A_new}

var A_arbace_java_io_eval1661000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000008", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000008_A"})

func init() { i := A_arbace_java_io_eval1661000008_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000008_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000008_A_members }

var A_arbace_java_io_eval1661000008_fn__1661000009_A_class *jrt.Class

func A_arbace_java_io_eval1661000024_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000024_A_New()}; return nil }

var A_arbace_java_io_eval1661000024_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000024_A_new}

var A_arbace_java_io_eval1661000024_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000024", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000024", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000024_A"})

func init() { i := A_arbace_java_io_eval1661000024_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000024_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000024_A_members }

var A_arbace_java_io_eval1661000024_fn__1661000025_A_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000014__1661000030_A_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000025_G__1661000015__1661000027_A_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000033_A_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000016__1661000038_A_class *jrt.Class

var A_arbace_java_io_eval1661000024_fn__1661000033_G__1661000017__1661000035_A_class *jrt.Class

func A_arbace_java_io_eval1661000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000047_A_New()}; return nil }

var A_arbace_java_io_eval1661000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000047_A_new}

var A_arbace_java_io_eval1661000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000047", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000047_A"})

func init() { i := A_arbace_java_io_eval1661000047_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000047_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000047_A_members }

var A_arbace_java_io_eval1661000047_fn__1661000048_A_class *jrt.Class

var A_arbace_java_io_eval1661000047_fn__1661000050_A_class *jrt.Class

func A_arbace_java_io_eval1661000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000053_A_New()}; return nil }

var A_arbace_java_io_eval1661000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000053_A_new}

var A_arbace_java_io_eval1661000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000053", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000053_A"})

func init() { i := A_arbace_java_io_eval1661000053_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000053_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000053_A_members }

var A_arbace_java_io_eval1661000053_fn__1661000054_A_class *jrt.Class

var A_arbace_java_io_eval1661000053_fn__1661000056_A_class *jrt.Class

func A_arbace_java_io_eval1661000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000059_A_New()}; return nil }

var A_arbace_java_io_eval1661000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000059_A_new}

var A_arbace_java_io_eval1661000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000059", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000059_A"})

func init() { i := A_arbace_java_io_eval1661000059_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000059_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000059_A_members }

var A_arbace_java_io_eval1661000059_fn__1661000060_A_class *jrt.Class

var A_arbace_java_io_eval1661000059_fn__1661000062_A_class *jrt.Class

func A_arbace_java_io_eval1661000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000065_A_New()}; return nil }

var A_arbace_java_io_eval1661000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000065_A_new}

var A_arbace_java_io_eval1661000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000065", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000065_A"})

func init() { i := A_arbace_java_io_eval1661000065_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000065_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000065_A_members }

var A_arbace_java_io_eval1661000065_fn__1661000066_A_class *jrt.Class

var A_arbace_java_io_eval1661000065_fn__1661000068_A_class *jrt.Class

func A_arbace_java_io_eval1661000071_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000071_A_New()}; return nil }

var A_arbace_java_io_eval1661000071_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000071_A_new}

var A_arbace_java_io_eval1661000071_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000071", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000071", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000071_A"})

func init() { i := A_arbace_java_io_eval1661000071_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000071_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000071_A_members }

var A_arbace_java_io_eval1661000071_fn__1661000072_A_class *jrt.Class

var A_arbace_java_io_eval1661000071_fn__1661000074_A_class *jrt.Class

func A_arbace_java_io_eval1661000091_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000091_A_New()}; return nil }

var A_arbace_java_io_eval1661000091_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000091_A_new}

var A_arbace_java_io_eval1661000091_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000091", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000091", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000091_A"})

func init() { i := A_arbace_java_io_eval1661000091_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000091_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000091_A_members }

var A_arbace_java_io_eval1661000091_fn__1661000092_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000081__1661000099_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000092_G__1661000082__1661000095_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000102_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000083__1661000109_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000102_G__1661000084__1661000105_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000112_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000077__1661000119_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000112_G__1661000078__1661000115_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000122_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000079__1661000129_A_class *jrt.Class

var A_arbace_java_io_eval1661000091_fn__1661000122_G__1661000080__1661000125_A_class *jrt.Class

func A_arbace_java_io_eval1661000154_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000154_A_New()}; return nil }

var A_arbace_java_io_eval1661000154_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000154_A_new}

var A_arbace_java_io_eval1661000154_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000154", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000154", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000154_A"})

func init() { i := A_arbace_java_io_eval1661000154_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000154_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000154_A_members }

var A_arbace_java_io_eval1661000154_fn__1661000155_A_class *jrt.Class

func A_arbace_java_io_eval1661000158_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000158_A_New()}; return nil }

var A_arbace_java_io_eval1661000158_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000158_A_new}

var A_arbace_java_io_eval1661000158_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000158", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000158", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000158_A"})

func init() { i := A_arbace_java_io_eval1661000158_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000158_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000158_A_members }

var A_arbace_java_io_eval1661000158_fn__1661000159_A_class *jrt.Class

func A_arbace_java_io_eval1661000162_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000162_A_New()}; return nil }

var A_arbace_java_io_eval1661000162_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000162_A_new}

var A_arbace_java_io_eval1661000162_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000162", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000162", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000162_A"})

func init() { i := A_arbace_java_io_eval1661000162_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000162_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000162_A_members }

var A_arbace_java_io_eval1661000162_fn__1661000163_A_class *jrt.Class

func A_arbace_java_io_eval1661000166_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000166_A_New()}; return nil }

var A_arbace_java_io_eval1661000166_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000166_A_new}

var A_arbace_java_io_eval1661000166_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000166", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000166", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000166_A"})

func init() { i := A_arbace_java_io_eval1661000166_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000166_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000166_A_members }

var A_arbace_java_io_eval1661000166_fn__1661000167_A_class *jrt.Class

func A_arbace_java_io_eval1661000170_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000170_A_New()}; return nil }

var A_arbace_java_io_eval1661000170_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000170_A_new}

var A_arbace_java_io_eval1661000170_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000170", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000170", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000170_A"})

func init() { i := A_arbace_java_io_eval1661000170_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000170_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000170_A_members }

var A_arbace_java_io_eval1661000170_fn__1661000171_A_class *jrt.Class

func A_arbace_java_io_eval1661000174_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000174_A_New()}; return nil }

var A_arbace_java_io_eval1661000174_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000174_A_new}

var A_arbace_java_io_eval1661000174_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000174", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000174", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000174_A"})

func init() { i := A_arbace_java_io_eval1661000174_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000174_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000174_A_members }

var A_arbace_java_io_eval1661000174_fn__1661000175_A_class *jrt.Class

func A_arbace_java_io_eval1661000178_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000178_A_New()}; return nil }

var A_arbace_java_io_eval1661000178_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000178_A_new}

var A_arbace_java_io_eval1661000178_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000178", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000178", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000178_A"})

func init() { i := A_arbace_java_io_eval1661000178_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000178_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000178_A_members }

var A_arbace_java_io_eval1661000178_fn__1661000179_A_class *jrt.Class

func A_arbace_java_io_eval1661000182_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000182_A_New()}; return nil }

var A_arbace_java_io_eval1661000182_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000182_A_new}

var A_arbace_java_io_eval1661000182_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000182", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000182", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000182_A"})

func init() { i := A_arbace_java_io_eval1661000182_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000182_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000182_A_members }

var A_arbace_java_io_eval1661000182_fn__1661000183_A_class *jrt.Class

func A_arbace_java_io_eval1661000186_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000186_A_New()}; return nil }

var A_arbace_java_io_eval1661000186_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000186_A_new}

var A_arbace_java_io_eval1661000186_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000186", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000186", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000186_A"})

func init() { i := A_arbace_java_io_eval1661000186_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000186_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000186_A_members }

var A_arbace_java_io_eval1661000186_fn__1661000187_A_class *jrt.Class

var A_arbace_java_io_eval1661000186_fn__1661000189_A_class *jrt.Class

func A_arbace_java_io_eval1661000192_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000192_A_New()}; return nil }

var A_arbace_java_io_eval1661000192_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000192_A_new}

var A_arbace_java_io_eval1661000192_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000192", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000192", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000192_A"})

func init() { i := A_arbace_java_io_eval1661000192_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000192_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000192_A_members }

var A_arbace_java_io_eval1661000192_fn__1661000193_A_class *jrt.Class

var A_arbace_java_io_eval1661000192_fn__1661000195_A_class *jrt.Class

func A_arbace_java_io_eval1661000198_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000198_A_New()}; return nil }

var A_arbace_java_io_eval1661000198_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000198_A_new}

var A_arbace_java_io_eval1661000198_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000198", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000198", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000198_A"})

func init() { i := A_arbace_java_io_eval1661000198_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000198_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000198_A_members }

var A_arbace_java_io_eval1661000198_fn__1661000199_A_class *jrt.Class

var A_arbace_java_io_eval1661000198_fn__1661000201_A_class *jrt.Class

func A_arbace_java_io_eval1661000204_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000204_A_New()}; return nil }

var A_arbace_java_io_eval1661000204_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000204_A_new}

var A_arbace_java_io_eval1661000204_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000204", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000204", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000204_A"})

func init() { i := A_arbace_java_io_eval1661000204_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000204_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000204_A_members }

var A_arbace_java_io_eval1661000204_fn__1661000205_A_class *jrt.Class

var A_arbace_java_io_eval1661000204_fn__1661000207_A_class *jrt.Class

func A_arbace_java_io_eval1661000210_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000210_A_New()}; return nil }

var A_arbace_java_io_eval1661000210_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000210_A_new}

var A_arbace_java_io_eval1661000210_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000210", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000210", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000210_A"})

func init() { i := A_arbace_java_io_eval1661000210_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000210_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000210_A_members }

var A_arbace_java_io_eval1661000210_fn__1661000211_A_class *jrt.Class

var A_arbace_java_io_eval1661000210_fn__1661000213_A_class *jrt.Class

func A_arbace_java_io_eval1661000216_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000216_A_New()}; return nil }

var A_arbace_java_io_eval1661000216_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000216_A_new}

var A_arbace_java_io_eval1661000216_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000216", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000216", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000216_A"})

func init() { i := A_arbace_java_io_eval1661000216_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000216_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000216_A_members }

var A_arbace_java_io_eval1661000216_fn__1661000217_A_class *jrt.Class

func A_arbace_java_io_eval1661000220_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000220_A_New()}; return nil }

var A_arbace_java_io_eval1661000220_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000220_A_new}

var A_arbace_java_io_eval1661000220_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000220", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000220", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000220_A"})

func init() { i := A_arbace_java_io_eval1661000220_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000220_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000220_A_members }

var A_arbace_java_io_eval1661000220_fn__1661000221_A_class *jrt.Class

func A_arbace_java_io_eval1661000226_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000226_A_New()}; return nil }

var A_arbace_java_io_eval1661000226_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000226_A_new}

var A_arbace_java_io_eval1661000226_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000226", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000226", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000226_A"})

func init() { i := A_arbace_java_io_eval1661000226_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000226_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000226_A_members }

var A_arbace_java_io_eval1661000226_fn__1661000227_A_class *jrt.Class

var A_arbace_java_io_eval1661000226_fn__1661000229_A_class *jrt.Class

func A_arbace_java_io_eval1661000232_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000232_A_New()}; return nil }

var A_arbace_java_io_eval1661000232_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000232_A_new}

var A_arbace_java_io_eval1661000232_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000232", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000232", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000232_A"})

func init() { i := A_arbace_java_io_eval1661000232_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000232_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000232_A_members }

var A_arbace_java_io_eval1661000232_fn__1661000233_A_class *jrt.Class

func A_arbace_java_io_eval1661000236_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000236_A_New()}; return nil }

var A_arbace_java_io_eval1661000236_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000236_A_new}

var A_arbace_java_io_eval1661000236_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000236", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000236", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000236_A"})

func init() { i := A_arbace_java_io_eval1661000236_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000236_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000236_A_members }

var A_arbace_java_io_eval1661000236_fn__1661000237_A_class *jrt.Class

func A_arbace_java_io_eval1661000240_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000240_A_New()}; return nil }

var A_arbace_java_io_eval1661000240_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000240_A_new}

var A_arbace_java_io_eval1661000240_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000240", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000240", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000240_A"})

func init() { i := A_arbace_java_io_eval1661000240_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000240_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000240_A_members }

var A_arbace_java_io_eval1661000240_fn__1661000241_A_class *jrt.Class

func A_arbace_java_io_eval1661000244_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000244_A_New()}; return nil }

var A_arbace_java_io_eval1661000244_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000244_A_new}

var A_arbace_java_io_eval1661000244_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000244", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000244", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000244_A"})

func init() { i := A_arbace_java_io_eval1661000244_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000244_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000244_A_members }

var A_arbace_java_io_eval1661000244_fn__1661000245_A_class *jrt.Class

func A_arbace_java_io_eval1661000248_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000248_A_New()}; return nil }

var A_arbace_java_io_eval1661000248_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000248_A_new}

var A_arbace_java_io_eval1661000248_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000248", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000248", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000248_A"})

func init() { i := A_arbace_java_io_eval1661000248_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000248_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000248_A_members }

var A_arbace_java_io_eval1661000248_fn__1661000249_A_class *jrt.Class

func A_arbace_java_io_eval1661000252_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000252_A_New()}; return nil }

var A_arbace_java_io_eval1661000252_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000252_A_new}

var A_arbace_java_io_eval1661000252_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000252", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000252", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000252_A"})

func init() { i := A_arbace_java_io_eval1661000252_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000252_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000252_A_members }

var A_arbace_java_io_eval1661000252_fn__1661000253_A_class *jrt.Class

func A_arbace_java_io_eval1661000256_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000256_A_New()}; return nil }

var A_arbace_java_io_eval1661000256_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000256_A_new}

var A_arbace_java_io_eval1661000256_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000256", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000256", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000256_A"})

func init() { i := A_arbace_java_io_eval1661000256_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000256_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000256_A_members }

var A_arbace_java_io_eval1661000256_fn__1661000257_A_class *jrt.Class

func A_arbace_java_io_eval1661000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000260_A_New()}; return nil }

var A_arbace_java_io_eval1661000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000260_A_new}

var A_arbace_java_io_eval1661000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000260", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000260_A"})

func init() { i := A_arbace_java_io_eval1661000260_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000260_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000260_A_members }

var A_arbace_java_io_eval1661000260_fn__1661000261_A_class *jrt.Class

func A_arbace_java_io_eval1661000264_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000264_A_New()}; return nil }

var A_arbace_java_io_eval1661000264_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000264_A_new}

var A_arbace_java_io_eval1661000264_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000264", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000264", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000264_A"})

func init() { i := A_arbace_java_io_eval1661000264_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000264_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000264_A_members }

var A_arbace_java_io_eval1661000264_fn__1661000265_A_class *jrt.Class

func A_arbace_java_io_eval1661000268_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000268_A_New()}; return nil }

var A_arbace_java_io_eval1661000268_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000268_A_new}

var A_arbace_java_io_eval1661000268_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000268", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000268", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000268_A"})

func init() { i := A_arbace_java_io_eval1661000268_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000268_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000268_A_members }

var A_arbace_java_io_eval1661000268_fn__1661000269_A_class *jrt.Class

func A_arbace_java_io_eval1661000272_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000272_A_New()}; return nil }

var A_arbace_java_io_eval1661000272_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000272_A_new}

var A_arbace_java_io_eval1661000272_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000272", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000272", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000272_A"})

func init() { i := A_arbace_java_io_eval1661000272_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000272_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000272_A_members }

var A_arbace_java_io_eval1661000272_fn__1661000273_A_class *jrt.Class

func A_arbace_java_io_eval1661000276_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000276_A_New()}; return nil }

var A_arbace_java_io_eval1661000276_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000276_A_new}

var A_arbace_java_io_eval1661000276_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000276", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000276", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000276_A"})

func init() { i := A_arbace_java_io_eval1661000276_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000276_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000276_A_members }

var A_arbace_java_io_eval1661000276_fn__1661000277_A_class *jrt.Class

func A_arbace_java_io_eval1661000280_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000280_A_New()}; return nil }

var A_arbace_java_io_eval1661000280_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000280_A_new}

var A_arbace_java_io_eval1661000280_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000280", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000280", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000280_A"})

func init() { i := A_arbace_java_io_eval1661000280_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000280_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000280_A_members }

var A_arbace_java_io_eval1661000280_fn__1661000281_A_class *jrt.Class

func A_arbace_java_io_eval1661000284_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000284_A_New()}; return nil }

var A_arbace_java_io_eval1661000284_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000284_A_new}

var A_arbace_java_io_eval1661000284_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000284", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000284", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000284_A"})

func init() { i := A_arbace_java_io_eval1661000284_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000284_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000284_A_members }

var A_arbace_java_io_eval1661000284_fn__1661000285_A_class *jrt.Class

func A_arbace_java_io_eval1661000288_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000288_A_New()}; return nil }

var A_arbace_java_io_eval1661000288_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000288_A_new}

var A_arbace_java_io_eval1661000288_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000288", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000288", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000288_A"})

func init() { i := A_arbace_java_io_eval1661000288_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000288_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000288_A_members }

var A_arbace_java_io_eval1661000288_fn__1661000289_A_class *jrt.Class

func A_arbace_java_io_eval1661000292_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000292_A_New()}; return nil }

var A_arbace_java_io_eval1661000292_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000292_A_new}

var A_arbace_java_io_eval1661000292_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000292", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000292", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000292_A"})

func init() { i := A_arbace_java_io_eval1661000292_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000292_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000292_A_members }

var A_arbace_java_io_eval1661000292_fn__1661000293_A_class *jrt.Class

func A_arbace_java_io_eval1661000296_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000296_A_New()}; return nil }

var A_arbace_java_io_eval1661000296_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000296_A_new}

var A_arbace_java_io_eval1661000296_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000296", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000296", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000296_A"})

func init() { i := A_arbace_java_io_eval1661000296_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000296_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000296_A_members }

var A_arbace_java_io_eval1661000296_fn__1661000297_A_class *jrt.Class

func A_arbace_java_io_eval1661000300_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000300_A_New()}; return nil }

var A_arbace_java_io_eval1661000300_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000300_A_new}

var A_arbace_java_io_eval1661000300_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000300", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000300", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000300_A"})

func init() { i := A_arbace_java_io_eval1661000300_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000300_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000300_A_members }

var A_arbace_java_io_eval1661000300_fn__1661000301_A_class *jrt.Class

func A_arbace_java_io_eval1661000304_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io_eval1661000304_A_New()}; return nil }

var A_arbace_java_io_eval1661000304_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_io_eval1661000304_A_new}

var A_arbace_java_io_eval1661000304_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io$eval1661000304", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_io_A_class, Simple: "eval1661000304", Go: "arbace/aot_arbace_java_io.A_arbace_java_io_eval1661000304_A"})

func init() { i := A_arbace_java_io_eval1661000304_A_class.Info(); i.IsInstance = A_arbace_java_io_eval1661000304_A_InstanceOf; i.Table = A_arbace_java_io_eval1661000304_A_members }

var A_arbace_java_io_eval1661000304_fn__1661000305_A_class *jrt.Class

var A_arbace_java_io_file_A_class *jrt.Class

var A_arbace_java_io_fn__1661000144_A_class *jrt.Class

var A_arbace_java_io_fn__1661000146_A_class *jrt.Class

var A_arbace_java_io_fn__1661000148_A_class *jrt.Class

var A_arbace_java_io_fn__1661000150_A_class *jrt.Class

var A_arbace_java_io_input_stream_A_class *jrt.Class

var A_arbace_java_io_inputstream__GT_reader_A_class *jrt.Class

var A_arbace_java_io_make_parents_A_class *jrt.Class

var A_arbace_java_io_output_stream_A_class *jrt.Class

var A_arbace_java_io_outputstream__GT_writer_A_class *jrt.Class

var A_arbace_java_io_reader_A_class *jrt.Class

var A_arbace_java_io_resource_A_class *jrt.Class

var A_arbace_java_io_writer_A_class *jrt.Class

func A_arbace_java_io_Coercions_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_java_io_Coercions_A).As_file__O(); case 1: return this.(A_arbace_java_io_Coercions_A).As_url__O()}; return nil }

var A_arbace_java_io_Coercions_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 as_file ()Ljava.lang.Object;\nM1025 as_url ()Ljava.lang.Object;", Invoke: A_arbace_java_io_Coercions_A_invoke}

var A_arbace_java_io_Coercions_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io.Coercions", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_java_io.A_arbace_java_io_Coercions_A"})

func init() { i := A_arbace_java_io_Coercions_A_class.Info(); i.IsInstance = A_arbace_java_io_Coercions_A_InstanceOf; i.Table = A_arbace_java_io_Coercions_A_members }

func A_arbace_java_io_IOFactory_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(A_arbace_java_io_IOFactory_A).Make_input_stream_O__O(args[0]); case 1: return this.(A_arbace_java_io_IOFactory_A).Make_output_stream_O__O(args[0]); case 2: return this.(A_arbace_java_io_IOFactory_A).Make_reader_O__O(args[0]); case 3: return this.(A_arbace_java_io_IOFactory_A).Make_writer_O__O(args[0])}; return nil }

var A_arbace_java_io_IOFactory_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1025 make_input_stream (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 make_output_stream (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 make_reader (Ljava.lang.Object;)Ljava.lang.Object;\nM1025 make_writer (Ljava.lang.Object;)Ljava.lang.Object;", Invoke: A_arbace_java_io_IOFactory_A_invoke}

var A_arbace_java_io_IOFactory_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io.IOFactory", Modifiers: 1537, Kind: jrt.KindInterface, Go: "arbace/aot_arbace_java_io.A_arbace_java_io_IOFactory_A"})

func init() { i := A_arbace_java_io_IOFactory_A_class.Info(); i.IsInstance = A_arbace_java_io_IOFactory_A_InstanceOf; i.Table = A_arbace_java_io_IOFactory_A_members }

func A_arbace_java_io__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_java_io__init_A_Load__O()}; return nil }

func A_arbace_java_io__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_io__init_A_New()}; return nil }

var A_arbace_java_io__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_java_io__init_A_invoke, New: A_arbace_java_io__init_A_new}

var A_arbace_java_io__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.io__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_io.A_arbace_java_io__init_A", Source: "io.ae"})

func init() { i := A_arbace_java_io__init_A_class.Info(); i.IsInstance = A_arbace_java_io__init_A_InstanceOf; i.Init = A_arbace_java_io__init_A_Init; i.Table = A_arbace_java_io__init_A_members }
