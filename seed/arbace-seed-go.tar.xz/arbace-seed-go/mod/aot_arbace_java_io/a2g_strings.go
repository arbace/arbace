//line a2g_strings.ae:1
package aot_arbace_java_io

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("require")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("commute")

var Lit_5 *jrt.String = jrt.Intern("deref")

var Lit_6 *jrt.String = jrt.Intern("conj")

var Lit_7 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_8 *jrt.String = jrt.Intern("author")

var Lit_9 *jrt.String = jrt.Intern("Stuart Sierra, Chas Emerick, Stuart Halloway")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("This file defines polymorphic I/O utility functions for Clojure.")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("-cache-protocol-fn")

var Lit_14 *jrt.String = jrt.Intern("arbace.java.io.Coercions")

var Lit_15 *jrt.String = jrt.Intern("replace")

var Lit_16 *jrt.String = jrt.Intern("escaped-utf8-urlstring->str")

var Lit_17 *jrt.String = jrt.Intern("as-file")

var Lit_18 *jrt.String = jrt.Intern("as-url")

var Lit_19 *jrt.String = jrt.Intern("arbace.java.io.IOFactory")

var Lit_20 *jrt.String = jrt.Intern("apply")

var Lit_21 *jrt.String = jrt.Intern("make-reader")

var Lit_22 *jrt.String = jrt.Intern("hash-map")

var Lit_23 *jrt.String = jrt.Intern("make-writer")

var Lit_24 *jrt.String = jrt.Intern("make-input-stream")

var Lit_25 *jrt.String = jrt.Intern("make-output-stream")

var Lit_26 *jrt.String = jrt.Intern("append")

var Lit_27 *jrt.String = jrt.Intern("encoding")

var Lit_28 *jrt.String = jrt.Intern("buffer-size")

var Lit_29 *jrt.String = jrt.Intern("pr-str")

var Lit_30 *jrt.String = jrt.Intern("append?")

var Lit_31 *jrt.String = jrt.Intern("type")

var Lit_32 *jrt.String = jrt.Intern("make-array")

var Lit_33 *jrt.String = jrt.Intern("do-copy")

var Lit_34 *jrt.String = jrt.Intern("reduce")

var Lit_35 *jrt.String = jrt.Intern("file")

var Lit_36 *jrt.String = jrt.Intern("as-relative-path")

var Lit_37 *jrt.String = jrt.Intern("java.lang.ClassLoader")

var Lit_38 *jrt.String = jrt.Intern("resource")

var Lit_39 *jrt.String = jrt.Intern("java.lang.Thread")

var Lit_40 *jrt.String = jrt.Intern("arbace.java.io$append_QMARK_")

var Lit_41 *jrt.String = jrt.Intern("arbace.java.io$as_relative_path")

var Lit_42 *jrt.String = jrt.Intern(" is not a relative path")

var Lit_43 *jrt.String = jrt.Intern("arbace.java.io$buffer_size")

var Lit_44 *jrt.String = jrt.Intern("arbace.java.io$copy")

var Lit_45 *jrt.String = jrt.Intern("arbace.java.io$delete_file")

var Lit_46 *jrt.String = jrt.Intern("Couldn't delete ")

var Lit_47 *jrt.String = jrt.Intern("arbace.java.io$encoding")

var Lit_48 *jrt.String = jrt.Intern("UTF-8")

var Lit_49 *jrt.String = jrt.Intern("arbace.java.io$escaped_utf8_urlstring__GT_str")

var Lit_50 *jrt.String = jrt.Intern("+")

var Lit_51 *jrt.String = jrt.Intern("%2B")

var Lit_52 *jrt.String = jrt.Intern("arbace.java.io$eval1661000004$loading__1927001464__auto____1661000005")

var Lit_53 *jrt.String = jrt.Intern("java.io.Reader")

var Lit_54 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_55 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_56 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_57 *jrt.String = jrt.Intern("java.io.BufferedReader")

var Lit_58 *jrt.String = jrt.Intern("java.io.File")

var Lit_59 *jrt.String = jrt.Intern("java.io.OutputStream")

var Lit_60 *jrt.String = jrt.Intern("java.io.OutputStreamWriter")

var Lit_61 *jrt.String = jrt.Intern("java.io.BufferedWriter")

var Lit_62 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_63 *jrt.String = jrt.Intern("java.io.FileInputStream")

var Lit_64 *jrt.String = jrt.Intern("java.io.FileOutputStream")

var Lit_65 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_66 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_67 *jrt.String = jrt.Intern("java.io.ByteArrayInputStream")

var Lit_68 *jrt.String = jrt.Intern("java.io.BufferedInputStream")

var Lit_69 *jrt.String = jrt.Intern("java.io.BufferedOutputStream")

var Lit_70 *jrt.String = jrt.Intern("java.io.CharArrayReader")

var Lit_71 *jrt.String = jrt.Intern("java.io.Closeable")

var Lit_72 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_73 *jrt.String = jrt.Intern("java.net.URI")

var Lit_74 *jrt.String = jrt.Intern("java.net.URL")

var Lit_75 *jrt.String = jrt.Intern("java.net.MalformedURLException")

var Lit_76 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_77 *jrt.String = jrt.Intern("java.net.URLDecoder")

var Lit_78 *jrt.String = jrt.Intern("java.net.URLEncoder")

var Lit_79 *jrt.String = jrt.Intern("arbace.java.io$eval1661000008$fn__1661000009")

var Lit_80 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000025")

var Lit_81 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000025$G__1661000014__1661000030")

var Lit_82 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000025$G__1661000015__1661000027")

var Lit_83 *jrt.String = jrt.Intern("as_file")

var Lit_84 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000033")

var Lit_85 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000033$G__1661000016__1661000038")

var Lit_86 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000033$G__1661000017__1661000035")

var Lit_87 *jrt.String = jrt.Intern("as_url")

var Lit_88 *jrt.String = jrt.Intern("arbace.java.io$eval1661000047$fn__1661000048")

var Lit_89 *jrt.String = jrt.Intern("arbace.java.io$eval1661000047$fn__1661000050")

var Lit_90 *jrt.String = jrt.Intern("arbace.java.io$eval1661000053$fn__1661000054")

var Lit_91 *jrt.String = jrt.Intern("arbace.java.io$eval1661000053$fn__1661000056")

var Lit_92 *jrt.String = jrt.Intern("arbace.java.io$eval1661000059$fn__1661000060")

var Lit_93 *jrt.String = jrt.Intern("arbace.java.io$eval1661000059$fn__1661000062")

var Lit_94 *jrt.String = jrt.Intern("arbace.java.io$eval1661000065$fn__1661000066")

var Lit_95 *jrt.String = jrt.Intern("arbace.java.io$eval1661000065$fn__1661000068")

var Lit_96 *jrt.String = jrt.Intern("Not a file: ")

var Lit_97 *jrt.String = jrt.Intern("arbace.java.io$eval1661000071$fn__1661000072")

var Lit_98 *jrt.String = jrt.Intern("arbace.java.io$eval1661000071$fn__1661000074")

var Lit_99 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000092")

var Lit_100 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000092$G__1661000081__1661000099")

var Lit_101 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000092$G__1661000082__1661000095")

var Lit_102 *jrt.String = jrt.Intern("make_input_stream")

var Lit_103 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000102")

var Lit_104 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000102$G__1661000083__1661000109")

var Lit_105 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000102$G__1661000084__1661000105")

var Lit_106 *jrt.String = jrt.Intern("make_output_stream")

var Lit_107 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000112")

var Lit_108 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000112$G__1661000077__1661000119")

var Lit_109 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000112$G__1661000078__1661000115")

var Lit_110 *jrt.String = jrt.Intern("make_reader")

var Lit_111 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000122")

var Lit_112 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000122$G__1661000079__1661000129")

var Lit_113 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000122$G__1661000080__1661000125")

var Lit_114 *jrt.String = jrt.Intern("make_writer")

var Lit_115 *jrt.String = jrt.Intern("arbace.java.io$eval1661000154$fn__1661000155")

var Lit_116 *jrt.String = jrt.Intern("arbace.java.io$eval1661000158$fn__1661000159")

var Lit_117 *jrt.String = jrt.Intern("arbace.java.io$eval1661000162$fn__1661000163")

var Lit_118 *jrt.String = jrt.Intern("arbace.java.io$eval1661000166$fn__1661000167")

var Lit_119 *jrt.String = jrt.Intern("arbace.java.io$eval1661000170$fn__1661000171")

var Lit_120 *jrt.String = jrt.Intern("arbace.java.io$eval1661000174$fn__1661000175")

var Lit_121 *jrt.String = jrt.Intern("arbace.java.io$eval1661000178$fn__1661000179")

var Lit_122 *jrt.String = jrt.Intern("arbace.java.io$eval1661000182$fn__1661000183")

var Lit_123 *jrt.String = jrt.Intern("arbace.java.io$eval1661000186$fn__1661000187")

var Lit_124 *jrt.String = jrt.Intern("arbace.java.io$eval1661000186$fn__1661000189")

var Lit_125 *jrt.String = jrt.Intern("arbace.java.io$eval1661000192$fn__1661000193")

var Lit_126 *jrt.String = jrt.Intern("arbace.java.io$eval1661000192$fn__1661000195")

var Lit_127 *jrt.String = jrt.Intern("Can not write to non-file URL <")

var Lit_128 *jrt.String = jrt.Intern(">")

var Lit_129 *jrt.String = jrt.Intern("arbace.java.io$eval1661000198$fn__1661000199")

var Lit_130 *jrt.String = jrt.Intern("arbace.java.io$eval1661000198$fn__1661000201")

var Lit_131 *jrt.String = jrt.Intern("arbace.java.io$eval1661000204$fn__1661000205")

var Lit_132 *jrt.String = jrt.Intern("arbace.java.io$eval1661000204$fn__1661000207")

var Lit_133 *jrt.String = jrt.Intern("arbace.java.io$eval1661000210$fn__1661000211")

var Lit_134 *jrt.String = jrt.Intern("arbace.java.io$eval1661000210$fn__1661000213")

var Lit_135 *jrt.String = jrt.Intern("arbace.java.io$eval1661000216$fn__1661000217")

var Lit_136 *jrt.String = jrt.Intern("arbace.java.io$eval1661000220$fn__1661000221")

var Lit_137 *jrt.String = jrt.Intern("arbace.java.io$eval1661000226$fn__1661000227")

var Lit_138 *jrt.String = jrt.Intern("Cannot open <")

var Lit_139 *jrt.String = jrt.Intern("> as a Reader.")

var Lit_140 *jrt.String = jrt.Intern("arbace.java.io$eval1661000226$fn__1661000229")

var Lit_141 *jrt.String = jrt.Intern("> as a Writer.")

var Lit_142 *jrt.String = jrt.Intern("arbace.java.io$eval1661000232$fn__1661000233")

var Lit_143 *jrt.String = jrt.Intern("arbace.java.io$eval1661000236$fn__1661000237")

var Lit_144 *jrt.String = jrt.Intern("arbace.java.io$eval1661000240$fn__1661000241")

var Lit_145 *jrt.String = jrt.Intern("arbace.java.io$eval1661000244$fn__1661000245")

var Lit_146 *jrt.String = jrt.Intern("arbace.java.io$eval1661000248$fn__1661000249")

var Lit_147 *jrt.String = jrt.Intern("arbace.java.io$eval1661000252$fn__1661000253")

var Lit_148 *jrt.String = jrt.Intern("arbace.java.io$eval1661000256$fn__1661000257")

var Lit_149 *jrt.String = jrt.Intern("arbace.java.io$eval1661000260$fn__1661000261")

var Lit_150 *jrt.String = jrt.Intern("arbace.java.io$eval1661000264$fn__1661000265")

var Lit_151 *jrt.String = jrt.Intern("arbace.java.io$eval1661000268$fn__1661000269")

var Lit_152 *jrt.String = jrt.Intern("arbace.java.io$eval1661000272$fn__1661000273")

var Lit_153 *jrt.String = jrt.Intern("arbace.java.io$eval1661000276$fn__1661000277")

var Lit_154 *jrt.String = jrt.Intern("arbace.java.io$eval1661000280$fn__1661000281")

var Lit_155 *jrt.String = jrt.Intern("arbace.java.io$eval1661000284$fn__1661000285")

var Lit_156 *jrt.String = jrt.Intern("arbace.java.io$eval1661000288$fn__1661000289")

var Lit_157 *jrt.String = jrt.Intern("arbace.java.io$eval1661000292$fn__1661000293")

var Lit_158 *jrt.String = jrt.Intern("arbace.java.io$eval1661000296$fn__1661000297")

var Lit_159 *jrt.String = jrt.Intern("arbace.java.io$eval1661000300$fn__1661000301")

var Lit_160 *jrt.String = jrt.Intern("arbace.java.io$eval1661000304$fn__1661000305")

var Lit_161 *jrt.String = jrt.Intern("arbace.java.io$file")

var Lit_162 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000144")

var Lit_163 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000146")

var Lit_164 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000148")

var Lit_165 *jrt.String = jrt.Intern("> as an InputStream.")

var Lit_166 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000150")

var Lit_167 *jrt.String = jrt.Intern("> as an OutputStream.")

var Lit_168 *jrt.String = jrt.Intern("arbace.java.io$input_stream")

var Lit_169 *jrt.String = jrt.Intern("arbace.java.io$inputstream__GT_reader")

var Lit_170 *jrt.String = jrt.Intern("arbace.java.io$make_parents")

var Lit_171 *jrt.String = jrt.Intern("arbace.java.io$output_stream")

var Lit_172 *jrt.String = jrt.Intern("arbace.java.io$outputstream__GT_writer")

var Lit_173 *jrt.String = jrt.Intern("arbace.java.io$reader")

var Lit_174 *jrt.String = jrt.Intern("arbace.java.io$resource")

var Lit_175 *jrt.String = jrt.Intern("getResource")

var Lit_176 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_177 *jrt.String = jrt.Intern("arbace.java.io$writer")

var Lit_178 *jrt.String = jrt.Intern("in-ns")

var Lit_179 *jrt.String = jrt.Intern("*warn-on-reflection*")

var Lit_180 *jrt.String = jrt.Intern("byte-array-type")

var Lit_181 *jrt.String = jrt.Intern("class")

var Lit_182 *jrt.String = jrt.Intern("Type object for a Java primitive byte array.")

var Lit_183 *jrt.String = jrt.Intern("private")

var Lit_184 *jrt.String = jrt.Intern("line")

var Lit_185 *jrt.String = jrt.Intern("column")

var Lit_186 *jrt.String = jrt.Intern("arbace/java/io.ae")

var Lit_187 *jrt.String = jrt.Intern("char-array-type")

var Lit_188 *jrt.String = jrt.Intern("Type object for a Java primitive char array.")

var Lit_189 *jrt.String = jrt.Intern("Coercions")

var Lit_190 *jrt.String = jrt.Intern("added")

var Lit_191 *jrt.String = jrt.Intern("1.2")

var Lit_192 *jrt.String = jrt.Intern("alter-meta!")

var Lit_193 *jrt.String = jrt.Intern("assoc")

var Lit_194 *jrt.String = jrt.Intern("assert-same-protocol")

var Lit_195 *jrt.String = jrt.Intern("Coerce argument to a file.")

var Lit_196 *jrt.String = jrt.Intern("arglists")

var Lit_197 *jrt.String = jrt.Intern("x")

var Lit_198 *jrt.String = jrt.Intern("Coerce argument to a URL.")

var Lit_199 *jrt.String = jrt.Intern("alter-var-root")

var Lit_200 *jrt.String = jrt.Intern("merge")

var Lit_201 *jrt.String = jrt.Intern("on")

var Lit_202 *jrt.String = jrt.Intern("on-interface")

var Lit_203 *jrt.String = jrt.Intern("Coerce between various 'resource-namish' things.")

var Lit_204 *jrt.String = jrt.Intern("sigs")

var Lit_205 *jrt.String = jrt.Intern("tag")

var Lit_206 *jrt.String = jrt.Intern("name")

var Lit_207 *jrt.String = jrt.Intern("var")

var Lit_208 *jrt.String = jrt.Intern("method-map")

var Lit_209 *jrt.String = jrt.Intern("method-builders")

var Lit_210 *jrt.String = jrt.Intern("intern")

var Lit_211 *jrt.String = jrt.Intern("*ns*")

var Lit_212 *jrt.String = jrt.Intern("with-meta")

var Lit_213 *jrt.String = jrt.Intern("protocol")

var Lit_214 *jrt.String = jrt.Intern("-reset-methods")

var Lit_215 *jrt.String = jrt.Intern("s")

var Lit_216 *jrt.String = jrt.Intern("extend")

var Lit_217 *jrt.String = jrt.Intern("java.lang.String")

var Lit_218 *jrt.String = jrt.Intern("IOFactory")

var Lit_219 *jrt.String = jrt.Intern("Creates a BufferedReader. See also IOFactory docs.")

var Lit_220 *jrt.String = jrt.Intern("opts")

var Lit_221 *jrt.String = jrt.Intern("Creates a BufferedWriter. See also IOFactory docs.")

var Lit_222 *jrt.String = jrt.Intern("Creates a BufferedInputStream. See also IOFactory docs.")

var Lit_223 *jrt.String = jrt.Intern("Creates a BufferedOutputStream. See also IOFactory docs.")

var Lit_224 *jrt.String = jrt.Intern("Factory functions that create ready-to-use, buffered versions of\n   the various Java I/O stream types, on top of anything that can\n   be unequivocally converted to the requested kind of stream.\n\n   Common options include\n\n     :append    true to open stream in append mode\n     :encoding  string name of encoding to use, e.g. \"UTF-8\".\n\n   Callers should generally prefer the higher level API provided by\n   reader, writer, input-stream, and output-stream.")

var Lit_225 *jrt.String = jrt.Intern("reader")

var Lit_226 *jrt.String = jrt.Intern("&")

var Lit_227 *jrt.String = jrt.Intern("Attempts to coerce its argument into an open java.io.Reader.\n   Default implementations always return a java.io.BufferedReader.\n\n   Default implementations are provided for Reader, BufferedReader,\n   InputStream, File, URI, URL, Socket, byte arrays, character arrays,\n   and String.\n\n   If argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the Reader is properly\n   closed.")

var Lit_228 *jrt.String = jrt.Intern("writer")

var Lit_229 *jrt.String = jrt.Intern("Attempts to coerce its argument into an open java.io.Writer.\n   Default implementations always return a java.io.BufferedWriter.\n\n   Default implementations are provided for Writer, BufferedWriter,\n   OutputStream, File, URI, URL, Socket, and String.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the Writer is properly\n   closed.")

var Lit_230 *jrt.String = jrt.Intern("input-stream")

var Lit_231 *jrt.String = jrt.Intern("Attempts to coerce its argument into an open java.io.InputStream.\n   Default implementations always return a java.io.BufferedInputStream.\n\n   Default implementations are defined for InputStream, File, URI, URL,\n   Socket, byte array, and String arguments.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the InputStream is properly\n   closed.")

var Lit_232 *jrt.String = jrt.Intern("output-stream")

var Lit_233 *jrt.String = jrt.Intern("Attempts to coerce its argument into an open java.io.OutputStream.\n   Default implementations always return a java.io.BufferedOutputStream.\n\n   Default implementations are defined for OutputStream, File, URI, URL,\n   Socket, and String arguments.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the OutputStream is\n   properly closed.")

var Lit_234 *jrt.String = jrt.Intern("java.lang.Boolean")

var Lit_235 *jrt.String = jrt.Intern("default-streams-impl")

var Lit_236 *jrt.String = jrt.Intern("inputstream->reader")

var Lit_237 *jrt.String = jrt.Intern("is")

var Lit_238 *jrt.String = jrt.Intern("InputStream")

var Lit_239 *jrt.String = jrt.Intern("outputstream->writer")

var Lit_240 *jrt.String = jrt.Intern("os")

var Lit_241 *jrt.String = jrt.Intern("OutputStream")

var Lit_242 *jrt.String = jrt.Intern("java.lang.Object")

var Lit_243 *jrt.String = jrt.Intern("Internal helper for copy")

var Lit_244 *jrt.String = jrt.Intern("input")

var Lit_245 *jrt.String = jrt.Intern("output")

var Lit_246 *jrt.String = jrt.Intern("default")

var Lit_247 *jrt.String = jrt.Intern("global-hierarchy")

var Lit_248 *jrt.String = jrt.Intern("copy")

var Lit_249 *jrt.String = jrt.Intern("Copies input to output.  Returns nil or throws IOException.\n  Input may be an InputStream, Reader, File, byte[], char[], or String.\n  Output may be an OutputStream, Writer, or File.\n\n  Options are key/value pairs and may be one of\n\n    :buffer-size  buffer size to use, default is 1024.\n    :encoding     encoding to use if converting between\n                  byte and char streams.\n\n  Does not close any streams except those it opens itself\n  (on a File).")

var Lit_250 *jrt.String = jrt.Intern("Take an as-file-able thing and return a string if it is\n   a relative path, else IllegalArgumentException.")

var Lit_251 *jrt.String = jrt.Intern("arg")

var Lit_252 *jrt.String = jrt.Intern("parent")

var Lit_253 *jrt.String = jrt.Intern("child")

var Lit_254 *jrt.String = jrt.Intern("more")

var Lit_255 *jrt.String = jrt.Intern("Returns a java.io.File, passing each arg to as-file.  Multiple-arg\n   versions treat the first argument as parent and subsequent args as\n   children relative to the parent.")

var Lit_256 *jrt.String = jrt.Intern("delete-file")

var Lit_257 *jrt.String = jrt.Intern("f")

var Lit_258 *jrt.String = jrt.Intern("silently")

var Lit_259 *jrt.String = jrt.Intern("Delete file f. If silently is nil or false, raise an exception on failure, else return the value of silently.")

var Lit_260 *jrt.String = jrt.Intern("make-parents")

var Lit_261 *jrt.String = jrt.Intern("Given the same arg(s) as for file, creates all parent directories of\n   the file they represent.")

var Lit_262 *jrt.String = jrt.Intern("n")

var Lit_263 *jrt.String = jrt.Intern("loader")

var Lit_264 *jrt.String = jrt.Intern("ClassLoader")

var Lit_265 *jrt.String = jrt.Intern("Returns the URL for a named resource. Use the context class loader\n   if no loader is specified.")
