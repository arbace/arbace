//line a2g_frames.ae:1
package aot_arbace_java_io

import "arbace/jrt"


func init() { jrt.RegisterFrames([]jrt.FrameInfo{{"arbace/aot_arbace_java_io.A_arbace_java_io_Coercions_A_As_file__O", "arbace.java.io.Coercions", "as_file", 0}, {"arbace/aot_arbace_java_io.A_arbace_java_io_Coercions_A_As_url__O", "arbace.java.io.Coercions", "as_url", 0}, {"arbace/aot_arbace_java_io.A_arbace_java_io_IOFactory_A_Make_reader_O__O", "arbace.java.io.IOFactory", "make_reader", 0}, {"arbace/aot_arbace_java_io.A_arbace_java_io_IOFactory_A_Make_writer_O__O", "arbace.java.io.IOFactory", "make_writer", 0}, {"arbace/aot_arbace_java_io.A_arbace_java_io_IOFactory_A_Make_input_stream_O__O", "arbace.java.io.IOFactory", "make_input_stream", 0}, {"arbace/aot_arbace_java_io.A_arbace_java_io_IOFactory_A_Make_output_stream_O__O", "arbace.java.io.IOFactory", "make_output_stream", 0}}) }
