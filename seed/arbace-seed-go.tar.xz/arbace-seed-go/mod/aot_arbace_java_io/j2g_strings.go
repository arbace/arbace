//line j2g_strings.ae:1
package aot_arbace_java_io

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn6,authorkn3,dockn6,appendkn8,encodingkn11,buffer-sizev11,arbace.core5,referv11,arbace.core7,requireR0,R1,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn14,arbace.java.iom4,R2,s44,Stuart Sierra, Chas Emerick, Stuart HallowayR3,s64,This file defines polymorphic I/O utility functions for Clojure.v11,arbace.core13,*loaded-libs*v11,arbace.core18,-cache-protocol-fnC24,arbace.java.io.Coercionsv13,arbace.string7,replacev14,arbace.java.io27,escaped-utf8-urlstring->strv14,arbace.java.io7,as-filec47,v14,arbace.java.io6,as-urlC24,arbace.java.io.IOFactoryv11,arbace.core5,applyv14,arbace.java.io11,make-readerv11,arbace.core8,hash-mapv14,arbace.java.io11,make-writerv14,arbace.java.io17,make-input-streamv14,arbace.java.io18,make-output-streamR4,R5,R6,l1024,v11,arbace.core6,pr-strv14,arbace.java.io8,encodingv14,arbace.java.io7,append?v11,arbace.core4,typev11,arbace.core10,make-arrayv14,arbace.java.io11,buffer-sizev14,arbace.java.io7,do-copyv11,arbace.core6,reducev14,arbace.java.io4,filev14,arbace.java.io16,as-relative-pathC21,java.lang.ClassLoaderv14,arbace.java.io8,resourceC16,java.lang.Thread")

var Lit_1 *jrt.String = jrt.Intern(" is not a relative path")

var Lit_2 *jrt.String = jrt.Intern("Couldn't delete ")

var Lit_3 *jrt.String = jrt.Intern("UTF-8")

var Lit_4 *jrt.String = jrt.Intern("+")

var Lit_5 *jrt.String = jrt.Intern("%2B")

var Lit_6 *jrt.String = jrt.Intern("java.io.Reader")

var Lit_7 *jrt.String = jrt.Intern("java.io.InputStream")

var Lit_8 *jrt.String = jrt.Intern("java.io.InputStreamReader")

var Lit_9 *jrt.String = jrt.Intern("java.io.PushbackReader")

var Lit_10 *jrt.String = jrt.Intern("java.io.BufferedReader")

var Lit_11 *jrt.String = jrt.Intern("java.io.File")

var Lit_12 *jrt.String = jrt.Intern("java.io.OutputStream")

var Lit_13 *jrt.String = jrt.Intern("java.io.OutputStreamWriter")

var Lit_14 *jrt.String = jrt.Intern("java.io.BufferedWriter")

var Lit_15 *jrt.String = jrt.Intern("java.io.Writer")

var Lit_16 *jrt.String = jrt.Intern("java.io.FileInputStream")

var Lit_17 *jrt.String = jrt.Intern("java.io.FileOutputStream")

var Lit_18 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_19 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_20 *jrt.String = jrt.Intern("java.io.ByteArrayInputStream")

var Lit_21 *jrt.String = jrt.Intern("java.io.BufferedInputStream")

var Lit_22 *jrt.String = jrt.Intern("java.io.BufferedOutputStream")

var Lit_23 *jrt.String = jrt.Intern("java.io.CharArrayReader")

var Lit_24 *jrt.String = jrt.Intern("java.io.Closeable")

var Lit_25 *jrt.String = jrt.Intern("arbace.lang.RT")

var Lit_26 *jrt.String = jrt.Intern("java.net.URI")

var Lit_27 *jrt.String = jrt.Intern("java.net.URL")

var Lit_28 *jrt.String = jrt.Intern("java.net.MalformedURLException")

var Lit_29 *jrt.String = jrt.Intern("java.net.Socket")

var Lit_30 *jrt.String = jrt.Intern("java.net.URLDecoder")

var Lit_31 *jrt.String = jrt.Intern("java.net.URLEncoder")

var Lit_32 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000025$G__1661000015__1661000027")

var Lit_33 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000025$G__1661000014__1661000030")

var Lit_34 *jrt.String = jrt.Intern("as_file")

var Lit_35 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000033$G__1661000017__1661000035")

var Lit_36 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000033$G__1661000016__1661000038")

var Lit_37 *jrt.String = jrt.Intern("as_url")

var Lit_38 *jrt.String = jrt.Intern("file")

var Lit_39 *jrt.String = jrt.Intern("Not a file: ")

var Lit_40 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000092$G__1661000082__1661000095")

var Lit_41 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000092$G__1661000081__1661000099")

var Lit_42 *jrt.String = jrt.Intern("make_input_stream")

var Lit_43 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000102$G__1661000084__1661000105")

var Lit_44 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000102$G__1661000083__1661000109")

var Lit_45 *jrt.String = jrt.Intern("make_output_stream")

var Lit_46 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000112$G__1661000078__1661000115")

var Lit_47 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000112$G__1661000077__1661000119")

var Lit_48 *jrt.String = jrt.Intern("make_reader")

var Lit_49 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000122$G__1661000080__1661000125")

var Lit_50 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000122$G__1661000079__1661000129")

var Lit_51 *jrt.String = jrt.Intern("make_writer")

var Lit_52 *jrt.String = jrt.Intern("Can not write to non-file URL <")

var Lit_53 *jrt.String = jrt.Intern(">")

var Lit_54 *jrt.String = jrt.Intern("Cannot open <")

var Lit_55 *jrt.String = jrt.Intern("> as a Reader.")

var Lit_56 *jrt.String = jrt.Intern("> as a Writer.")

var Lit_57 *jrt.String = jrt.Intern("> as an InputStream.")

var Lit_58 *jrt.String = jrt.Intern("> as an OutputStream.")

var Lit_59 *jrt.String = jrt.Intern("getResource")

var Lit_60 *jrt.String = jrt.Intern("getContextClassLoader")

var Lit_61 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn7,privatekn4,linekn6,columnkn4,filekn5,addedkn8,arglistsyn1,xkn2,onyn24,arbace.java.io.Coercionskn12,on-interfacekn4,sigskn7,as-filekn3,tagyn12,java.io.Filekn4,namekn6,as-urlyn12,java.net.URLkn3,varkn10,method-mapkn15,method-builderskn8,protocolyn1,syn4,optsyn24,arbace.java.io.IOFactorykn11,make-readerkn11,make-writerkn17,make-input-streamkn18,make-output-streamyn1,&yn11,InputStreamyn12,OutputStreamyn5,inputyn6,outputkn7,defaultyn3,argyn6,parentyn5,childyn4,moreyn1,fyn8,silentlyyn1,nyn11,ClassLoaderv11,arbace.core5,in-nsMyn14,arbace.java.iom4,R0,s44,Stuart Sierra, Chas Emerick, Stuart HallowayR1,s64,This file defines polymorphic I/O utility functions for Clojure.m4,R0,s44,Stuart Sierra, Chas Emerick, Stuart HallowayR1,s64,This file defines polymorphic I/O utility functions for Clojure.R2,v11,arbace.core20,*warn-on-reflection*v14,arbace.java.io15,byte-array-typev11,arbace.core5,classm10,R1,s44,Type object for a Java primitive byte array.R3,TR4,i27,R5,i1,R6,s17,arbace/java/io.aev11,arbace.core10,make-arrayl0,v14,arbace.java.io15,char-array-typem10,R1,s44,Type object for a Java primitive char array.R3,TR4,i33,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io9,Coercionsm8,R7,s3,1.2R4,i38,R5,i1,R6,s17,arbace/java/io.aem8,R7,s3,1.2R4,i38,R5,i1,R6,s17,arbace/java/io.aeC24,arbace.java.io.Coercionsv11,arbace.core11,alter-meta!v11,arbace.core5,assocR1,v11,arbace.core20,assert-same-protocolL2,Myn7,as-filem4,R1,s26,Coerce argument to a file.R8,L1,V1,R9,Myn6,as-urlm4,R1,s25,Coerce argument to a URL.R8,L1,V1,R9,v11,arbace.core14,alter-var-rootv11,arbace.core5,mergem6,R10,R11,R12,C24,arbace.java.io.CoercionsR1,s48,Coerce between various 'resource-namish' things.R13,m4,R14,m10,R15,R16,R7,s3,1.2R17,Myn7,as-filem4,R1,s26,Coerce argument to a file.R8,L1,V1,R9,R8,L1,V1,R9,R1,s26,Coerce argument to a file.R18,m10,R15,R19,R7,s3,1.2R17,Myn6,as-urlm4,R1,s25,Coerce argument to a URL.R8,L1,V1,R9,R8,L1,V1,R9,R1,s25,Coerce argument to a URL.R20,R21,m4,R14,R14,R18,R18,R22,v11,arbace.core6,internv11,arbace.core4,*ns*v11,arbace.core9,with-metaMyn7,as-filem4,R1,s26,Coerce argument to a file.R8,L1,V1,R9,m10,R15,R16,R7,s3,1.2R17,Myn7,as-filem4,R1,s26,Coerce argument to a file.R8,L1,V1,R9,R8,L1,V1,R9,R1,s26,Coerce argument to a file.R23,Myn6,as-urlm4,R1,s25,Coerce argument to a URL.R8,L1,V1,R9,m10,R15,R19,R7,s3,1.2R17,Myn6,as-urlm4,R1,s25,Coerce argument to a URL.R8,L1,V1,R9,R8,L1,V1,R9,R1,s25,Coerce argument to a URL.v11,arbace.core14,-reset-methodsMyn9,Coercionsm2,R7,s3,1.2v14,arbace.java.io27,escaped-utf8-urlstring->strm10,R3,TR8,L1,V1,R24,R4,i43,R5,i1,R6,s17,arbace/java/io.aev11,arbace.core6,extendR14,R18,C16,java.lang.StringC12,java.io.FileC12,java.net.URLC12,java.net.URIv14,arbace.java.io9,IOFactorym8,R7,s3,1.2R4,i72,R5,i1,R6,s17,arbace/java/io.aem8,R7,s3,1.2R4,i72,R5,i1,R6,s17,arbace/java/io.aeC24,arbace.java.io.IOFactoryL4,Myn11,make-readerm4,R1,s50,Creates a BufferedReader. See also IOFactory docs.R8,L1,V2,R9,R25,Myn11,make-writerm4,R1,s50,Creates a BufferedWriter. See also IOFactory docs.R8,L1,V2,R9,R25,Myn17,make-input-streamm4,R1,s55,Creates a BufferedInputStream. See also IOFactory docs.R8,L1,V2,R9,R25,Myn18,make-output-streamm4,R1,s56,Creates a BufferedOutputStream. See also IOFactory docs.R8,L1,V2,R9,R25,m6,R10,R26,R12,C24,arbace.java.io.IOFactoryR1,s455,Factory functions that create ready-to-use, buffered versions of\n   the various Java I/O stream types, on top of anything that can\n   be unequivocally converted to the requested kind of stream.\n\n   Common options include\n\n     :append    true to open stream in append mode\n     :encoding  string name of encoding to use, e.g. \"UTF-8\".\n\n   Callers should generally prefer the higher level API provided by\n   reader, writer, input-stream, and output-stream.m8,R27,m10,R7,s3,1.2R15,nR17,Myn11,make-readerm4,R1,s50,Creates a BufferedReader. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s50,Creates a BufferedReader. See also IOFactory docs.R28,m10,R7,s3,1.2R15,nR17,Myn11,make-writerm4,R1,s50,Creates a BufferedWriter. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s50,Creates a BufferedWriter. See also IOFactory docs.R29,m10,R7,s3,1.2R15,nR17,Myn17,make-input-streamm4,R1,s55,Creates a BufferedInputStream. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s55,Creates a BufferedInputStream. See also IOFactory docs.R30,m10,R7,s3,1.2R15,nR17,Myn18,make-output-streamm4,R1,s56,Creates a BufferedOutputStream. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s56,Creates a BufferedOutputStream. See also IOFactory docs.m8,R28,R28,R27,R27,R29,R29,R30,R30,Myn17,make-input-streamm4,R1,s55,Creates a BufferedInputStream. See also IOFactory docs.R8,L1,V2,R9,R25,m10,R7,s3,1.2R15,nR17,Myn17,make-input-streamm4,R1,s55,Creates a BufferedInputStream. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s55,Creates a BufferedInputStream. See also IOFactory docs.Myn18,make-output-streamm4,R1,s56,Creates a BufferedOutputStream. See also IOFactory docs.R8,L1,V2,R9,R25,m10,R7,s3,1.2R15,nR17,Myn18,make-output-streamm4,R1,s56,Creates a BufferedOutputStream. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s56,Creates a BufferedOutputStream. See also IOFactory docs.Myn11,make-readerm4,R1,s50,Creates a BufferedReader. See also IOFactory docs.R8,L1,V2,R9,R25,m10,R7,s3,1.2R15,nR17,Myn11,make-readerm4,R1,s50,Creates a BufferedReader. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s50,Creates a BufferedReader. See also IOFactory docs.Myn11,make-writerm4,R1,s50,Creates a BufferedWriter. See also IOFactory docs.R8,L1,V2,R9,R25,m10,R7,s3,1.2R15,nR17,Myn11,make-writerm4,R1,s50,Creates a BufferedWriter. See also IOFactory docs.R8,L1,V2,R9,R25,R8,L1,V2,R9,R25,R1,s50,Creates a BufferedWriter. See also IOFactory docs.Myn9,IOFactorym2,R7,s3,1.2v14,arbace.java.io6,readerm14,R15,C14,java.io.ReaderR8,L1,V3,R9,R31,R25,R1,s527,Attempts to coerce its argument into an open java.io.Reader.\n   Default implementations always return a java.io.BufferedReader.\n\n   Default implementations are provided for Reader, BufferedReader,\n   InputStream, File, URI, URL, Socket, byte arrays, character arrays,\n   and String.\n\n   If argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the Reader is properly\n   closed.R7,s3,1.2R4,i89,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io6,writerm14,R15,C14,java.io.WriterR8,L1,V3,R9,R31,R25,R1,s498,Attempts to coerce its argument into an open java.io.Writer.\n   Default implementations always return a java.io.BufferedWriter.\n\n   Default implementations are provided for Writer, BufferedWriter,\n   OutputStream, File, URI, URL, Socket, and String.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the Writer is properly\n   closed.R7,s3,1.2R4,i107,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io12,input-streamm14,R15,C19,java.io.InputStreamR8,L1,V3,R9,R31,R25,R1,s509,Attempts to coerce its argument into an open java.io.InputStream.\n   Default implementations always return a java.io.BufferedInputStream.\n\n   Default implementations are defined for InputStream, File, URI, URL,\n   Socket, byte array, and String arguments.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the InputStream is properly\n   closed.R7,s3,1.2R4,i124,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io13,output-streamm14,R15,C20,java.io.OutputStreamR8,L1,V3,R9,R31,R25,R1,s501,Attempts to coerce its argument into an open java.io.OutputStream.\n   Default implementations always return a java.io.BufferedOutputStream.\n\n   Default implementations are defined for OutputStream, File, URI, URL,\n   Socket, and String arguments.\n\n   If the argument is a String, it tries to resolve it first as a URI, then\n   as a local file name.  URIs with a 'file' protocol are converted to\n   local file names.\n\n   Should be used inside with-open to ensure the OutputStream is\n   properly closed.R7,s3,1.2R4,i141,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io7,append?m12,R15,C17,java.lang.BooleanR3,TR8,L1,V1,R25,R4,i158,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io8,encodingm12,R15,C16,java.lang.StringR3,TR8,L1,V1,R25,R4,i161,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io11,buffer-sizem10,R3,TR8,L1,V1,R25,R4,i164,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io20,default-streams-implR27,R28,R29,R30,m6,R4,i167,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io19,inputstream->readerm10,R3,TR8,L1,V2,Myn2,ism2,R15,R32,R25,R4,i177,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io20,outputstream->writerm10,R3,TR8,L1,V2,Myn2,osm2,R15,R33,R25,R4,i181,R5,i1,R6,s17,arbace/java/io.aeC27,java.io.BufferedInputStreamC19,java.io.InputStreamC14,java.io.ReaderC22,java.io.BufferedReaderC14,java.io.WriterC22,java.io.BufferedWriterC20,java.io.OutputStreamC28,java.io.BufferedOutputStreamC15,java.net.SocketC16,java.lang.Objectv14,arbace.java.io7,do-copym12,R1,s24,Internal helper for copyR3,TR8,ML1,V3,R34,R35,R25,m4,R4,i301,R5,i17,R4,i298,R5,i1,R6,s17,arbace/java/io.aev11,arbace.core5,derefR36,v11,arbace.core16,global-hierarchym12,R1,s24,Internal helper for copyR3,TR8,ML1,V3,R34,R35,R25,m4,R4,i301,R5,i17,R4,i298,R5,i1,R6,s17,arbace/java/io.aeV2,C19,java.io.InputStreamC20,java.io.OutputStreamV2,C19,java.io.InputStreamC14,java.io.WriterV2,C19,java.io.InputStreamC12,java.io.FileV2,C14,java.io.ReaderC20,java.io.OutputStreamV2,C14,java.io.ReaderC14,java.io.WriterV2,C14,java.io.ReaderC12,java.io.FileV2,C12,java.io.FileC20,java.io.OutputStreamV2,C12,java.io.FileC14,java.io.WriterV2,C12,java.io.FileC12,java.io.FileV2,C16,java.lang.StringC20,java.io.OutputStreamV2,C16,java.lang.StringC14,java.io.WriterV2,C16,java.lang.StringC12,java.io.Filev14,arbace.java.io4,copym12,R8,L1,V4,R34,R35,R31,R25,R1,s457,Copies input to output.  Returns nil or throws IOException.\n  Input may be an InputStream, Reader, File, byte[], char[], or String.\n  Output may be an OutputStream, Writer, or File.\n\n  Options are key/value pairs and may be one of\n\n    :buffer-size  buffer size to use, default is 1024.\n    :encoding     encoding to use if converting between\n                  byte and char streams.\n\n  Does not close any streams except those it opens itself\n  (on a File).R7,s3,1.2R4,i390,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io16,as-relative-pathm14,R15,C16,java.lang.StringR8,L1,V1,R9,R1,s106,Take an as-file-able thing and return a string if it is\n   a relative path, else IllegalArgumentException.R7,s3,1.2R4,i407,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io4,filem14,R15,C12,java.io.FileR8,L3,V1,R37,V2,R38,R39,V4,R38,R39,R31,R40,R1,s172,Returns a java.io.File, passing each arg to as-file.  Multiple-arg\n   versions treat the first argument as parent and subsequent args as\n   children relative to the parent.R7,s3,1.2R4,i417,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io11,delete-filem12,R8,L1,V3,R41,R31,V1,R42,R1,s109,Delete file f. If silently is nil or false, raise an exception on failure, else return the value of silently.R7,s3,1.2R4,i429,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io12,make-parentsm12,R8,L1,V3,R41,R31,R40,R1,s96,Given the same arg(s) as for file, creates all parent directories of\n   the file they represent.R7,s3,1.2R4,i437,R5,i1,R6,s17,arbace/java/io.aev14,arbace.java.io8,resourcem14,R15,C12,java.net.URLR8,L2,V1,R43,V2,R43,Myn6,loaderm2,R15,R44,R1,s96,Returns the URL for a named resource. Use the context class loader\n   if no loader is specified.R7,s3,1.2R4,i445,R5,i1,R6,s17,arbace/java/io.ae")

var Lit_62 *jrt.String = jrt.Intern("arbace.java.io$eval1661000004$loading__1927001464__auto____1661000005")

var Lit_63 *jrt.String = jrt.Intern("arbace.java.io$eval1661000008$fn__1661000009")

var Lit_64 *jrt.String = jrt.Intern("Coerce between various 'resource-namish' things.")

var Lit_65 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000025")

var Lit_66 *jrt.String = jrt.Intern("arbace.java.io$eval1661000024$fn__1661000033")

var Lit_67 *jrt.String = jrt.Intern("arbace.java.io$escaped_utf8_urlstring__GT_str")

var Lit_68 *jrt.String = jrt.Intern("arbace.java.io$eval1661000047$fn__1661000048")

var Lit_69 *jrt.String = jrt.Intern("arbace.java.io$eval1661000047$fn__1661000050")

var Lit_70 *jrt.String = jrt.Intern("arbace.java.io$eval1661000053$fn__1661000054")

var Lit_71 *jrt.String = jrt.Intern("arbace.java.io$eval1661000053$fn__1661000056")

var Lit_72 *jrt.String = jrt.Intern("arbace.java.io$eval1661000059$fn__1661000060")

var Lit_73 *jrt.String = jrt.Intern("arbace.java.io$eval1661000059$fn__1661000062")

var Lit_74 *jrt.String = jrt.Intern("arbace.java.io$eval1661000065$fn__1661000066")

var Lit_75 *jrt.String = jrt.Intern("arbace.java.io$eval1661000065$fn__1661000068")

var Lit_76 *jrt.String = jrt.Intern("arbace.java.io$eval1661000071$fn__1661000072")

var Lit_77 *jrt.String = jrt.Intern("arbace.java.io$eval1661000071$fn__1661000074")

var Lit_78 *jrt.String = jrt.Intern("Factory functions that create ready-to-use, buffered versions of\n   the various Java I/O stream types, on top of anything that can\n   be unequivocally converted to the requested kind of stream.\n\n   Common options include\n\n     :append    true to open stream in append mode\n     :encoding  string name of encoding to use, e.g. \"UTF-8\".\n\n   Callers should generally prefer the higher level API provided by\n   reader, writer, input-stream, and output-stream.")

var Lit_79 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000092")

var Lit_80 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000102")

var Lit_81 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000112")

var Lit_82 *jrt.String = jrt.Intern("arbace.java.io$eval1661000091$fn__1661000122")

var Lit_83 *jrt.String = jrt.Intern("arbace.java.io$reader")

var Lit_84 *jrt.String = jrt.Intern("arbace.java.io$writer")

var Lit_85 *jrt.String = jrt.Intern("arbace.java.io$input_stream")

var Lit_86 *jrt.String = jrt.Intern("arbace.java.io$output_stream")

var Lit_87 *jrt.String = jrt.Intern("arbace.java.io$append_QMARK_")

var Lit_88 *jrt.String = jrt.Intern("arbace.java.io$encoding")

var Lit_89 *jrt.String = jrt.Intern("arbace.java.io$buffer_size")

var Lit_90 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000144")

var Lit_91 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000146")

var Lit_92 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000148")

var Lit_93 *jrt.String = jrt.Intern("arbace.java.io$fn__1661000150")

var Lit_94 *jrt.String = jrt.Intern("arbace.java.io$inputstream__GT_reader")

var Lit_95 *jrt.String = jrt.Intern("arbace.java.io$outputstream__GT_writer")

var Lit_96 *jrt.String = jrt.Intern("arbace.java.io$eval1661000154$fn__1661000155")

var Lit_97 *jrt.String = jrt.Intern("arbace.java.io$eval1661000158$fn__1661000159")

var Lit_98 *jrt.String = jrt.Intern("arbace.java.io$eval1661000162$fn__1661000163")

var Lit_99 *jrt.String = jrt.Intern("arbace.java.io$eval1661000166$fn__1661000167")

var Lit_100 *jrt.String = jrt.Intern("arbace.java.io$eval1661000170$fn__1661000171")

var Lit_101 *jrt.String = jrt.Intern("arbace.java.io$eval1661000174$fn__1661000175")

var Lit_102 *jrt.String = jrt.Intern("arbace.java.io$eval1661000178$fn__1661000179")

var Lit_103 *jrt.String = jrt.Intern("arbace.java.io$eval1661000182$fn__1661000183")

var Lit_104 *jrt.String = jrt.Intern("arbace.java.io$eval1661000186$fn__1661000187")

var Lit_105 *jrt.String = jrt.Intern("arbace.java.io$eval1661000186$fn__1661000189")

var Lit_106 *jrt.String = jrt.Intern("arbace.java.io$eval1661000192$fn__1661000193")

var Lit_107 *jrt.String = jrt.Intern("arbace.java.io$eval1661000192$fn__1661000195")

var Lit_108 *jrt.String = jrt.Intern("arbace.java.io$eval1661000198$fn__1661000199")

var Lit_109 *jrt.String = jrt.Intern("arbace.java.io$eval1661000198$fn__1661000201")

var Lit_110 *jrt.String = jrt.Intern("arbace.java.io$eval1661000204$fn__1661000205")

var Lit_111 *jrt.String = jrt.Intern("arbace.java.io$eval1661000204$fn__1661000207")

var Lit_112 *jrt.String = jrt.Intern("arbace.java.io$eval1661000210$fn__1661000211")

var Lit_113 *jrt.String = jrt.Intern("arbace.java.io$eval1661000210$fn__1661000213")

var Lit_114 *jrt.String = jrt.Intern("arbace.java.io$eval1661000216$fn__1661000217")

var Lit_115 *jrt.String = jrt.Intern("arbace.java.io$eval1661000220$fn__1661000221")

var Lit_116 *jrt.String = jrt.Intern("arbace.java.io$eval1661000226$fn__1661000227")

var Lit_117 *jrt.String = jrt.Intern("arbace.java.io$eval1661000226$fn__1661000229")

var Lit_118 *jrt.String = jrt.Intern("do-copy")

var Lit_119 *jrt.String = jrt.Intern("arbace.java.io$eval1661000232$fn__1661000233")

var Lit_120 *jrt.String = jrt.Intern("arbace.java.io$eval1661000236$fn__1661000237")

var Lit_121 *jrt.String = jrt.Intern("arbace.java.io$eval1661000240$fn__1661000241")

var Lit_122 *jrt.String = jrt.Intern("arbace.java.io$eval1661000244$fn__1661000245")

var Lit_123 *jrt.String = jrt.Intern("arbace.java.io$eval1661000248$fn__1661000249")

var Lit_124 *jrt.String = jrt.Intern("arbace.java.io$eval1661000252$fn__1661000253")

var Lit_125 *jrt.String = jrt.Intern("arbace.java.io$eval1661000256$fn__1661000257")

var Lit_126 *jrt.String = jrt.Intern("arbace.java.io$eval1661000260$fn__1661000261")

var Lit_127 *jrt.String = jrt.Intern("arbace.java.io$eval1661000264$fn__1661000265")

var Lit_128 *jrt.String = jrt.Intern("arbace.java.io$eval1661000268$fn__1661000269")

var Lit_129 *jrt.String = jrt.Intern("arbace.java.io$eval1661000272$fn__1661000273")

var Lit_130 *jrt.String = jrt.Intern("arbace.java.io$eval1661000276$fn__1661000277")

var Lit_131 *jrt.String = jrt.Intern("arbace.java.io$eval1661000280$fn__1661000281")

var Lit_132 *jrt.String = jrt.Intern("arbace.java.io$eval1661000284$fn__1661000285")

var Lit_133 *jrt.String = jrt.Intern("arbace.java.io$eval1661000288$fn__1661000289")

var Lit_134 *jrt.String = jrt.Intern("arbace.java.io$eval1661000292$fn__1661000293")

var Lit_135 *jrt.String = jrt.Intern("arbace.java.io$eval1661000296$fn__1661000297")

var Lit_136 *jrt.String = jrt.Intern("arbace.java.io$eval1661000300$fn__1661000301")

var Lit_137 *jrt.String = jrt.Intern("arbace.java.io$eval1661000304$fn__1661000305")

var Lit_138 *jrt.String = jrt.Intern("arbace.java.io$copy")

var Lit_139 *jrt.String = jrt.Intern("arbace.java.io$as_relative_path")

var Lit_140 *jrt.String = jrt.Intern("arbace.java.io$file")

var Lit_141 *jrt.String = jrt.Intern("arbace.java.io$delete_file")

var Lit_142 *jrt.String = jrt.Intern("arbace.java.io$make_parents")

var Lit_143 *jrt.String = jrt.Intern("arbace.java.io$resource")
