//line j2g_strings.ae:1
package aot_arbace_java_shell

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn14,arbace.java.iokn4,onlyyn7,as-fileyn4,copykn4,linekn6,columnkn6,authorkn3,docys11,arbace.core7,bindingys17,arbace.java.shell8,*sh-dir*ys17,arbace.java.shell8,*sh-env*kn7,out-enckn6,in-enckn3,dirkn3,envkn8,encodingkn5,byteskn2,inkn4,exitkn3,outkn3,errv11,arbace.core5,referR0,v11,arbace.core3,useV3,R1,R2,ML2,R3,R4,m4,R5,i14,R6,i31,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn17,arbace.java.shellm4,R7,s29,Chris Houser, Stuart HallowayR8,s79,Conveniently launch a sub-process providing its stdin and\ncollecting its stdoutv11,arbace.core3,seqv11,arbace.core6,concatv11,arbace.core4,listR9,v11,arbace.core5,applyv11,arbace.core6,vectorR10,R9,R11,v11,arbace.core10,make-arrayv11,arbace.core1,+v11,arbace.core3,mapv11,arbace.core5,countR12,R13,R14,v17,arbace.java.shell8,*sh-dir*R15,v17,arbace.java.shell8,*sh-env*v11,arbace.core10,split-withv11,arbace.core7,string?v11,arbace.core5,mergev11,arbace.core8,hash-mapv11,arbace.core4,map?v11,arbace.core10,into-arrayC16,java.lang.Stringv11,arbace.core4,namev14,arbace.java.io4,copyR16,v17,arbace.java.shell16,stream-to-stringR17,v17,arbace.java.shell15,stream-to-bytesv17,arbace.java.shell10,parse-argsC17,java.lang.Runtimev17,arbace.java.shell14,as-env-stringsv14,arbace.java.io7,as-filev11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstR18,v11,arbace.core11,future-callv17,arbace.java.shell13,stream-to-encR19,R20,R21,")

var Lit_1 *jrt.String = jrt.Intern("arbace.java.shell$as_env_strings$fn__1651000028")

var Lit_2 *jrt.String = jrt.Intern("=")

var Lit_3 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_4 *jrt.String = jrt.Intern("java.io.StringWriter")

var Lit_5 *jrt.String = jrt.Intern("java.nio.charset.Charset")

var Lit_6 *jrt.String = jrt.Intern("UTF-8")

var Lit_7 *jrt.String = jrt.Intern("exec")

var Lit_8 *jrt.String = jrt.Intern("arbace.java.shell$sh$fn__1651000042")

var Lit_9 *jrt.String = jrt.Intern("arbace.java.shell$sh$fn__1651000044")

var Lit_10 *jrt.String = jrt.Intern("arbace.java.shell$sh$fn__1651000046")

var Lit_11 *jrt.String = jrt.Intern("kn6,authorkn3,docyn11,arbace.corekn7,dynamickn4,linekn6,columnkn4,filekn8,arglistsyn3,diryn1,&yn5,formskn5,addedyn3,envkn7,privateyn4,typeyn2,xsyn4,argskn3,tagyn3,argyn2,inyn3,encyn6,streamv11,arbace.core5,in-nsMyn17,arbace.java.shellm4,R0,s29,Chris Houser, Stuart HallowayR1,s79,Conveniently launch a sub-process providing its stdin and\ncollecting its stdoutm4,R0,s29,Chris Houser, Stuart HallowayR1,s79,Conveniently launch a sub-process providing its stdin and\ncollecting its stdoutR2,v17,arbace.java.shell8,*sh-dir*m8,R3,TR4,i18,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell8,*sh-env*m8,R3,TR4,i19,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell11,with-sh-dirm12,R7,L1,V3,R8,R9,R10,R1,s55,Sets the directory for use with sh, see sh for details.R11,s3,1.2R4,i21,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell11,with-sh-envm12,R7,L1,V3,R12,R9,R10,R1,s57,Sets the environment for use with sh, see sh for details.R11,s3,1.2R4,i28,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell7,aconcatm12,R13,TR7,L1,V3,R14,R9,R15,R1,s34,Concatenates arrays of given type.R4,i35,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell10,parse-argsm10,R13,TR7,L1,V1,R16,R4,i45,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell14,as-env-stringsm14,R17,s19,[Ljava.lang.String;R13,TR7,L1,V1,R18,R1,s65,Helper so that callers can pass a Clojure map for the :env to sh.R4,i52,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell15,stream-to-bytesm10,R13,TR7,L1,V1,R19,R4,i60,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell16,stream-to-stringm10,R13,TR7,L2,V1,R19,V2,R19,R20,R4,i66,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell13,stream-to-encm10,R13,TR7,L1,V2,R21,R20,R4,i73,R5,i1,R6,s20,arbace/java/shell.aev17,arbace.java.shell2,shm12,R7,L1,V2,R9,R16,R1,s1530,Passes the given strings to Runtime.exec() to launch a sub-process.\n\n  Options are\n\n  :in      may be given followed by any legal input source for\n           arbace.java.io/copy, e.g. InputStream, Reader, File, byte[],\n           or String, to be fed to the sub-process's stdin.\n  :in-enc  option may be given followed by a String, used as a character\n           encoding name (for example \"UTF-8\" or \"ISO-8859-1\") to\n           convert the input string specified by the :in option to the\n           sub-process's stdin.  Defaults to UTF-8.\n           If the :in option provides a byte array, then the bytes are passed\n           unencoded, and this option is ignored.\n  :out-enc option may be given followed by :bytes or a String. If a\n           String is given, it will be used as a character encoding\n           name (for example \"UTF-8\" or \"ISO-8859-1\") to convert\n           the sub-process's stdout to a String which is returned.\n           If :bytes is given, the sub-process's stdout will be stored\n           in a byte array and returned.  Defaults to UTF-8.\n  :env     override the process env with a map (or the underlying Java\n           String[] if you are a masochist).\n  :dir     override the process dir with a String or java.io.File.\n\n  You can bind :env or :dir for multiple operations using with-sh-env\n  and with-sh-dir.\n\n  sh returns a map of\n    :exit => sub-process's exit code\n    :out  => sub-process's stdout (as byte[] or String)\n    :err  => sub-process's stderr (String via platform default encoding)R11,s3,1.2R4,i79,R5,i1,R6,s20,arbace/java/shell.ae")

var Lit_12 *jrt.String = jrt.Intern("arbace.java.shell$eval1651000004$loading__1927001464__auto____1651000005")

var Lit_13 *jrt.String = jrt.Intern("arbace.java.shell$eval1651000008$fn__1651000009")

var Lit_14 *jrt.String = jrt.Intern("arbace.java.shell$with_sh_dir")

var Lit_15 *jrt.String = jrt.Intern("arbace.java.shell$with_sh_env")

var Lit_16 *jrt.String = jrt.Intern("arbace.java.shell$aconcat")

var Lit_17 *jrt.String = jrt.Intern("arbace.java.shell$parse_args")

var Lit_18 *jrt.String = jrt.Intern("arbace.java.shell$as_env_strings")

var Lit_19 *jrt.String = jrt.Intern("arbace.java.shell$stream_to_bytes")

var Lit_20 *jrt.String = jrt.Intern("arbace.java.shell$stream_to_string")

var Lit_21 *jrt.String = jrt.Intern("arbace.java.shell$stream_to_enc")

var Lit_22 *jrt.String = jrt.Intern("arbace.java.shell$sh")
