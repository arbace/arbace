//line a2g_classes.ae:1
package aot_arbace_java_shell

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_java_shell_aconcat_A_class, Name: "arbace.java.shell$aconcat", Modifiers: 25, Simple: "aconcat", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_aconcat_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR1_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_as_env_strings_A_class, Name: "arbace.java.shell$as_env_strings", Modifiers: 25, Simple: "as_env_strings", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_as_env_strings_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_as_env_strings_fn__1651000028_A_class, Name: "arbace.java.shell$as_env_strings$fn__1651000028", Modifiers: 25, Simple: "fn__1651000028", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_as_env_strings_fn__1651000028_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_as_env_strings_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class, Name: "arbace.java.shell$eval1651000004$loading__1927001464__auto____1651000005", Modifiers: 25, Simple: "loading__1927001464__auto____1651000005", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_eval1651000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_eval1651000008_fn__1651000009_A_class, Name: "arbace.java.shell$eval1651000008$fn__1651000009", Modifiers: 25, Simple: "fn__1651000009", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000008_fn__1651000009_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_eval1651000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_parse_args_A_class, Name: "arbace.java.shell$parse_args", Modifiers: 25, Simple: "parse_args", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_parse_args_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_sh_A_class, Name: "arbace.java.shell$sh", Modifiers: 25, Simple: "sh", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_sh_fn__1651000042_A_class, Name: "arbace.java.shell$sh$fn__1651000042", Modifiers: 25, Simple: "fn__1651000042", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_fn__1651000042_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_sh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_sh_fn__1651000044_A_class, Name: "arbace.java.shell$sh$fn__1651000044", Modifiers: 25, Simple: "fn__1651000044", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_fn__1651000044_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_sh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_sh_fn__1651000046_A_class, Name: "arbace.java.shell$sh$fn__1651000046", Modifiers: 25, Simple: "fn__1651000046", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_fn__1651000046_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_sh_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_stream_to_bytes_A_class, Name: "arbace.java.shell$stream_to_bytes", Modifiers: 25, Simple: "stream_to_bytes", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_stream_to_bytes_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_stream_to_enc_A_class, Name: "arbace.java.shell$stream_to_enc", Modifiers: 25, Simple: "stream_to_enc", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_stream_to_enc_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_stream_to_string_A_class, Name: "arbace.java.shell$stream_to_string", Modifiers: 25, Simple: "stream_to_string", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_stream_to_string_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_with_sh_dir_A_class, Name: "arbace.java.shell$with_sh_dir", Modifiers: 25, Simple: "with_sh_dir", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_with_sh_dir_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}, jrt.CodeDecl{Out: &A_arbace_java_shell_with_sh_env_A_class, Name: "arbace.java.shell$with_sh_env", Modifiers: 25, Simple: "with_sh_env", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_with_sh_env_A", Source: "shell.ae", Declaring: &A_arbace_java_shell_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR3_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_java_shell_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_A_New()}; return nil }

var A_arbace_java_shell_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_shell_A_new}

var A_arbace_java_shell_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_A"})

func init() { i := A_arbace_java_shell_A_class.Info(); i.IsInstance = A_arbace_java_shell_A_InstanceOf; i.Init = A_arbace_java_shell_A_Init; i.Table = A_arbace_java_shell_A_members }

var A_arbace_java_shell_aconcat_A_class *jrt.Class

var A_arbace_java_shell_as_env_strings_A_class *jrt.Class

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_class *jrt.Class

func A_arbace_java_shell_eval1651000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_eval1651000004_A_New()}; return nil }

var A_arbace_java_shell_eval1651000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_shell_eval1651000004_A_new}

var A_arbace_java_shell_eval1651000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$eval1651000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_shell_A_class, Simple: "eval1651000004", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000004_A"})

func init() { i := A_arbace_java_shell_eval1651000004_A_class.Info(); i.IsInstance = A_arbace_java_shell_eval1651000004_A_InstanceOf; i.Table = A_arbace_java_shell_eval1651000004_A_members }

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class *jrt.Class

func A_arbace_java_shell_eval1651000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_eval1651000008_A_New()}; return nil }

var A_arbace_java_shell_eval1651000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_shell_eval1651000008_A_new}

var A_arbace_java_shell_eval1651000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$eval1651000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_shell_A_class, Simple: "eval1651000008", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000008_A"})

func init() { i := A_arbace_java_shell_eval1651000008_A_class.Info(); i.IsInstance = A_arbace_java_shell_eval1651000008_A_InstanceOf; i.Table = A_arbace_java_shell_eval1651000008_A_members }

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_class *jrt.Class

var A_arbace_java_shell_parse_args_A_class *jrt.Class

var A_arbace_java_shell_sh_A_class *jrt.Class

var A_arbace_java_shell_sh_fn__1651000042_A_class *jrt.Class

var A_arbace_java_shell_sh_fn__1651000044_A_class *jrt.Class

var A_arbace_java_shell_sh_fn__1651000046_A_class *jrt.Class

var A_arbace_java_shell_stream_to_bytes_A_class *jrt.Class

var A_arbace_java_shell_stream_to_enc_A_class *jrt.Class

var A_arbace_java_shell_stream_to_string_A_class *jrt.Class

var A_arbace_java_shell_with_sh_dir_A_class *jrt.Class

var A_arbace_java_shell_with_sh_env_A_class *jrt.Class

func A_arbace_java_shell__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_java_shell__init_A_Load__O()}; return nil }

func A_arbace_java_shell__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell__init_A_New()}; return nil }

var A_arbace_java_shell__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_java_shell__init_A_invoke, New: A_arbace_java_shell__init_A_new}

var A_arbace_java_shell__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell__init_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell__init_A_class.Info(); i.IsInstance = A_arbace_java_shell__init_A_InstanceOf; i.Init = A_arbace_java_shell__init_A_Init; i.Table = A_arbace_java_shell__init_A_members }
