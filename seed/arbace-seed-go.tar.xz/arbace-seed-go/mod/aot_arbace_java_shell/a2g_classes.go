//line a2g_classes.ae:1
package aot_arbace_java_shell

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_java_shell_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_A_New()}; return nil }

var A_arbace_java_shell_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_shell_A_new}

var A_arbace_java_shell_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_A"})

func init() { i := A_arbace_java_shell_A_class.Info(); i.IsInstance = A_arbace_java_shell_A_InstanceOf; i.Init = A_arbace_java_shell_A_Init; i.Table = A_arbace_java_shell_A_members; jrt.RegisterGoType(A_arbace_java_shell_A_class, reflect.TypeFor[A_arbace_java_shell_A]()) }

func A_arbace_java_shell_aconcat_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_aconcat_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_java_shell_aconcat_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_aconcat_A_New()}; return nil }

func A_arbace_java_shell_aconcat_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_aconcat_A_fn_class)}; return nil }

var A_arbace_java_shell_aconcat_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_aconcat_A_invoke, New: A_arbace_java_shell_aconcat_A_new, Get: A_arbace_java_shell_aconcat_A_get}

var A_arbace_java_shell_aconcat_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$aconcat", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_java_shell_A_class, Simple: "aconcat", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_aconcat_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_aconcat_A_class.Info(); i.IsInstance = A_arbace_java_shell_aconcat_A_InstanceOf; i.Init = A_arbace_java_shell_aconcat_A_Init; i.Table = A_arbace_java_shell_aconcat_A_members; jrt.RegisterGoType(A_arbace_java_shell_aconcat_A_class, reflect.TypeFor[A_arbace_java_shell_aconcat_A]()) }

func A_arbace_java_shell_as_env_strings_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_as_env_strings_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_java_shell_as_env_strings_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_as_env_strings_A_New()}; return nil }

func A_arbace_java_shell_as_env_strings_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_as_env_strings_A_fn_class)}; return nil }

var A_arbace_java_shell_as_env_strings_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_as_env_strings_A_invoke, New: A_arbace_java_shell_as_env_strings_A_new, Get: A_arbace_java_shell_as_env_strings_A_get}

var A_arbace_java_shell_as_env_strings_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$as_env_strings", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_java_shell_A_class, Simple: "as_env_strings", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_as_env_strings_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_as_env_strings_A_class.Info(); i.IsInstance = A_arbace_java_shell_as_env_strings_A_InstanceOf; i.Init = A_arbace_java_shell_as_env_strings_A_Init; i.Table = A_arbace_java_shell_as_env_strings_A_members; jrt.RegisterGoType(A_arbace_java_shell_as_env_strings_A_class, reflect.TypeFor[A_arbace_java_shell_as_env_strings_A]()) }

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_as_env_strings_fn__1651000028_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_as_env_strings_fn__1651000028_A_New()}; return nil }

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class)}; return nil }

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_as_env_strings_fn__1651000028_A_invoke, New: A_arbace_java_shell_as_env_strings_fn__1651000028_A_new, Get: A_arbace_java_shell_as_env_strings_fn__1651000028_A_get}

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$as_env_strings$fn__1651000028", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_java_shell_as_env_strings_A_class, Simple: "fn__1651000028", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_as_env_strings_fn__1651000028_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_as_env_strings_fn__1651000028_A_class.Info(); i.IsInstance = A_arbace_java_shell_as_env_strings_fn__1651000028_A_InstanceOf; i.Init = A_arbace_java_shell_as_env_strings_fn__1651000028_A_Init; i.Table = A_arbace_java_shell_as_env_strings_fn__1651000028_A_members; jrt.RegisterGoType(A_arbace_java_shell_as_env_strings_fn__1651000028_A_class, reflect.TypeFor[A_arbace_java_shell_as_env_strings_fn__1651000028_A]()) }

func A_arbace_java_shell_eval1651000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_eval1651000004_A_New()}; return nil }

var A_arbace_java_shell_eval1651000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_shell_eval1651000004_A_new}

var A_arbace_java_shell_eval1651000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$eval1651000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_shell_A_class, Simple: "eval1651000004", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000004_A"})

func init() { i := A_arbace_java_shell_eval1651000004_A_class.Info(); i.IsInstance = A_arbace_java_shell_eval1651000004_A_InstanceOf; i.Table = A_arbace_java_shell_eval1651000004_A_members; jrt.RegisterGoType(A_arbace_java_shell_eval1651000004_A_class, reflect.TypeFor[A_arbace_java_shell_eval1651000004_A]()) }

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_New()}; return nil }

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_fn_class)}; return nil }

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_invoke, New: A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_new, Get: A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_get}

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$eval1651000004$loading__1927001464__auto____1651000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_java_shell_eval1651000004_A_class, Simple: "loading__1927001464__auto____1651000005", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class.Info(); i.IsInstance = A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_InstanceOf; i.Init = A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_Init; i.Table = A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_members; jrt.RegisterGoType(A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class, reflect.TypeFor[A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A]()) }

func A_arbace_java_shell_eval1651000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_eval1651000008_A_New()}; return nil }

var A_arbace_java_shell_eval1651000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_java_shell_eval1651000008_A_new}

var A_arbace_java_shell_eval1651000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$eval1651000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_java_shell_A_class, Simple: "eval1651000008", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000008_A"})

func init() { i := A_arbace_java_shell_eval1651000008_A_class.Info(); i.IsInstance = A_arbace_java_shell_eval1651000008_A_InstanceOf; i.Table = A_arbace_java_shell_eval1651000008_A_members; jrt.RegisterGoType(A_arbace_java_shell_eval1651000008_A_class, reflect.TypeFor[A_arbace_java_shell_eval1651000008_A]()) }

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_eval1651000008_fn__1651000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_eval1651000008_fn__1651000009_A_New()}; return nil }

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_eval1651000008_fn__1651000009_A_fn_class)}; return nil }

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_eval1651000008_fn__1651000009_A_invoke, New: A_arbace_java_shell_eval1651000008_fn__1651000009_A_new, Get: A_arbace_java_shell_eval1651000008_fn__1651000009_A_get}

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$eval1651000008$fn__1651000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_java_shell_eval1651000008_A_class, Simple: "fn__1651000009", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_eval1651000008_fn__1651000009_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_eval1651000008_fn__1651000009_A_class.Info(); i.IsInstance = A_arbace_java_shell_eval1651000008_fn__1651000009_A_InstanceOf; i.Init = A_arbace_java_shell_eval1651000008_fn__1651000009_A_Init; i.Table = A_arbace_java_shell_eval1651000008_fn__1651000009_A_members; jrt.RegisterGoType(A_arbace_java_shell_eval1651000008_fn__1651000009_A_class, reflect.TypeFor[A_arbace_java_shell_eval1651000008_fn__1651000009_A]()) }

func A_arbace_java_shell_parse_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_parse_args_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_java_shell_parse_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_parse_args_A_New()}; return nil }

func A_arbace_java_shell_parse_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_parse_args_A_fn_class)}; return nil }

var A_arbace_java_shell_parse_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_parse_args_A_invoke, New: A_arbace_java_shell_parse_args_A_new, Get: A_arbace_java_shell_parse_args_A_get}

var A_arbace_java_shell_parse_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$parse_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_java_shell_A_class, Simple: "parse_args", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_parse_args_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_parse_args_A_class.Info(); i.IsInstance = A_arbace_java_shell_parse_args_A_InstanceOf; i.Init = A_arbace_java_shell_parse_args_A_Init; i.Table = A_arbace_java_shell_parse_args_A_members; jrt.RegisterGoType(A_arbace_java_shell_parse_args_A_class, reflect.TypeFor[A_arbace_java_shell_parse_args_A]()) }

func A_arbace_java_shell_sh_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_sh_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_java_shell_sh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_sh_A_New()}; return nil }

func A_arbace_java_shell_sh_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_sh_A_fn_class)}; return nil }

var A_arbace_java_shell_sh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_sh_A_invoke, New: A_arbace_java_shell_sh_A_new, Get: A_arbace_java_shell_sh_A_get}

var A_arbace_java_shell_sh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$sh", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_java_shell_A_class, Simple: "sh", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_sh_A_class.Info(); i.IsInstance = A_arbace_java_shell_sh_A_InstanceOf; i.Init = A_arbace_java_shell_sh_A_Init; i.Table = A_arbace_java_shell_sh_A_members; jrt.RegisterGoType(A_arbace_java_shell_sh_A_class, reflect.TypeFor[A_arbace_java_shell_sh_A]()) }

func A_arbace_java_shell_sh_fn__1651000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_sh_fn__1651000042_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_java_shell_sh_fn__1651000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_java_shell_sh_fn__1651000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_sh_fn__1651000042_A_fn_class)}; return nil }

var A_arbace_java_shell_sh_fn__1651000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_sh_fn__1651000042_A_invoke, New: A_arbace_java_shell_sh_fn__1651000042_A_new, Get: A_arbace_java_shell_sh_fn__1651000042_A_get}

var A_arbace_java_shell_sh_fn__1651000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$sh$fn__1651000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_java_shell_sh_A_class, Simple: "fn__1651000042", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_fn__1651000042_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_sh_fn__1651000042_A_class.Info(); i.IsInstance = A_arbace_java_shell_sh_fn__1651000042_A_InstanceOf; i.Init = A_arbace_java_shell_sh_fn__1651000042_A_Init; i.Table = A_arbace_java_shell_sh_fn__1651000042_A_members; jrt.RegisterGoType(A_arbace_java_shell_sh_fn__1651000042_A_class, reflect.TypeFor[A_arbace_java_shell_sh_fn__1651000042_A]()) }

func A_arbace_java_shell_sh_fn__1651000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_sh_fn__1651000044_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_java_shell_sh_fn__1651000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_java_shell_sh_fn__1651000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_sh_fn__1651000044_A_fn_class)}; return nil }

var A_arbace_java_shell_sh_fn__1651000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_sh_fn__1651000044_A_invoke, New: A_arbace_java_shell_sh_fn__1651000044_A_new, Get: A_arbace_java_shell_sh_fn__1651000044_A_get}

var A_arbace_java_shell_sh_fn__1651000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$sh$fn__1651000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_java_shell_sh_A_class, Simple: "fn__1651000044", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_fn__1651000044_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_sh_fn__1651000044_A_class.Info(); i.IsInstance = A_arbace_java_shell_sh_fn__1651000044_A_InstanceOf; i.Init = A_arbace_java_shell_sh_fn__1651000044_A_Init; i.Table = A_arbace_java_shell_sh_fn__1651000044_A_members; jrt.RegisterGoType(A_arbace_java_shell_sh_fn__1651000044_A_class, reflect.TypeFor[A_arbace_java_shell_sh_fn__1651000044_A]()) }

func A_arbace_java_shell_sh_fn__1651000046_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_sh_fn__1651000046_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_java_shell_sh_fn__1651000046_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_sh_fn__1651000046_A_New_O(args[0])}; return nil }

func A_arbace_java_shell_sh_fn__1651000046_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_sh_fn__1651000046_A_fn_class)}; return nil }

var A_arbace_java_shell_sh_fn__1651000046_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_sh_fn__1651000046_A_invoke, New: A_arbace_java_shell_sh_fn__1651000046_A_new, Get: A_arbace_java_shell_sh_fn__1651000046_A_get}

var A_arbace_java_shell_sh_fn__1651000046_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$sh$fn__1651000046", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_java_shell_sh_A_class, Simple: "fn__1651000046", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_sh_fn__1651000046_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_sh_fn__1651000046_A_class.Info(); i.IsInstance = A_arbace_java_shell_sh_fn__1651000046_A_InstanceOf; i.Init = A_arbace_java_shell_sh_fn__1651000046_A_Init; i.Table = A_arbace_java_shell_sh_fn__1651000046_A_members; jrt.RegisterGoType(A_arbace_java_shell_sh_fn__1651000046_A_class, reflect.TypeFor[A_arbace_java_shell_sh_fn__1651000046_A]()) }

func A_arbace_java_shell_stream_to_bytes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_stream_to_bytes_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_java_shell_stream_to_bytes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_stream_to_bytes_A_New()}; return nil }

func A_arbace_java_shell_stream_to_bytes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_stream_to_bytes_A_fn_class)}; return nil }

var A_arbace_java_shell_stream_to_bytes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_stream_to_bytes_A_invoke, New: A_arbace_java_shell_stream_to_bytes_A_new, Get: A_arbace_java_shell_stream_to_bytes_A_get}

var A_arbace_java_shell_stream_to_bytes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$stream_to_bytes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_java_shell_A_class, Simple: "stream_to_bytes", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_stream_to_bytes_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_stream_to_bytes_A_class.Info(); i.IsInstance = A_arbace_java_shell_stream_to_bytes_A_InstanceOf; i.Init = A_arbace_java_shell_stream_to_bytes_A_Init; i.Table = A_arbace_java_shell_stream_to_bytes_A_members; jrt.RegisterGoType(A_arbace_java_shell_stream_to_bytes_A_class, reflect.TypeFor[A_arbace_java_shell_stream_to_bytes_A]()) }

func A_arbace_java_shell_stream_to_enc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_stream_to_enc_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_java_shell_stream_to_enc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_stream_to_enc_A_New()}; return nil }

func A_arbace_java_shell_stream_to_enc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_stream_to_enc_A_fn_class)}; return nil }

var A_arbace_java_shell_stream_to_enc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_stream_to_enc_A_invoke, New: A_arbace_java_shell_stream_to_enc_A_new, Get: A_arbace_java_shell_stream_to_enc_A_get}

var A_arbace_java_shell_stream_to_enc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$stream_to_enc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_java_shell_A_class, Simple: "stream_to_enc", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_stream_to_enc_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_stream_to_enc_A_class.Info(); i.IsInstance = A_arbace_java_shell_stream_to_enc_A_InstanceOf; i.Init = A_arbace_java_shell_stream_to_enc_A_Init; i.Table = A_arbace_java_shell_stream_to_enc_A_members; jrt.RegisterGoType(A_arbace_java_shell_stream_to_enc_A_class, reflect.TypeFor[A_arbace_java_shell_stream_to_enc_A]()) }

func A_arbace_java_shell_stream_to_string_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_java_shell_stream_to_string_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_stream_to_string_A_New()}; return nil }

func A_arbace_java_shell_stream_to_string_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_stream_to_string_A_fn_class)}; return nil }

var A_arbace_java_shell_stream_to_string_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_stream_to_string_A_invoke, New: A_arbace_java_shell_stream_to_string_A_new, Get: A_arbace_java_shell_stream_to_string_A_get}

var A_arbace_java_shell_stream_to_string_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$stream_to_string", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_java_shell_A_class, Simple: "stream_to_string", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_stream_to_string_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_stream_to_string_A_class.Info(); i.IsInstance = A_arbace_java_shell_stream_to_string_A_InstanceOf; i.Init = A_arbace_java_shell_stream_to_string_A_Init; i.Table = A_arbace_java_shell_stream_to_string_A_members; jrt.RegisterGoType(A_arbace_java_shell_stream_to_string_A_class, reflect.TypeFor[A_arbace_java_shell_stream_to_string_A]()) }

func A_arbace_java_shell_with_sh_dir_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_with_sh_dir_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_java_shell_with_sh_dir_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_with_sh_dir_A_New()}; return nil }

func A_arbace_java_shell_with_sh_dir_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_with_sh_dir_A_fn_class)}; return nil }

var A_arbace_java_shell_with_sh_dir_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_with_sh_dir_A_invoke, New: A_arbace_java_shell_with_sh_dir_A_new, Get: A_arbace_java_shell_with_sh_dir_A_get}

var A_arbace_java_shell_with_sh_dir_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$with_sh_dir", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_java_shell_A_class, Simple: "with_sh_dir", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_with_sh_dir_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_with_sh_dir_A_class.Info(); i.IsInstance = A_arbace_java_shell_with_sh_dir_A_InstanceOf; i.Init = A_arbace_java_shell_with_sh_dir_A_Init; i.Table = A_arbace_java_shell_with_sh_dir_A_members; jrt.RegisterGoType(A_arbace_java_shell_with_sh_dir_A_class, reflect.TypeFor[A_arbace_java_shell_with_sh_dir_A]()) }

func A_arbace_java_shell_with_sh_env_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_java_shell_with_sh_env_A).DoInvoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_java_shell_with_sh_env_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell_with_sh_env_A_New()}; return nil }

func A_arbace_java_shell_with_sh_env_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_java_shell_with_sh_env_A_fn_class)}; return nil }

var A_arbace_java_shell_with_sh_env_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_java_shell_with_sh_env_A_invoke, New: A_arbace_java_shell_with_sh_env_A_new, Get: A_arbace_java_shell_with_sh_env_A_get}

var A_arbace_java_shell_with_sh_env_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell$with_sh_env", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR3_class}, Declaring: A_arbace_java_shell_A_class, Simple: "with_sh_env", Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell_with_sh_env_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell_with_sh_env_A_class.Info(); i.IsInstance = A_arbace_java_shell_with_sh_env_A_InstanceOf; i.Init = A_arbace_java_shell_with_sh_env_A_Init; i.Table = A_arbace_java_shell_with_sh_env_A_members; jrt.RegisterGoType(A_arbace_java_shell_with_sh_env_A_class, reflect.TypeFor[A_arbace_java_shell_with_sh_env_A]()) }

func A_arbace_java_shell__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_java_shell__init_A_Load__O(); case 1: return A_arbace_java_shell__init_A_Unit0__O(); case 2: return A_arbace_java_shell__init_A_Unit1__O(); case 3: return A_arbace_java_shell__init_A_Unit10__O(); case 4: return A_arbace_java_shell__init_A_Unit11__O(); case 5: return A_arbace_java_shell__init_A_Unit12__O(); case 6: return A_arbace_java_shell__init_A_Unit13__O(); case 7: return A_arbace_java_shell__init_A_Unit14__O(); case 8: return A_arbace_java_shell__init_A_Unit15__O(); case 9: return A_arbace_java_shell__init_A_Unit16__O(); case 10: return A_arbace_java_shell__init_A_Unit17__O(); case 11: return A_arbace_java_shell__init_A_Unit18__O(); case 12: return A_arbace_java_shell__init_A_Unit19__O(); case 13: return A_arbace_java_shell__init_A_Unit2__O(); case 14: return A_arbace_java_shell__init_A_Unit3__O(); case 15: return A_arbace_java_shell__init_A_Unit4__O(); case 16: return A_arbace_java_shell__init_A_Unit5__O(); case 17: return A_arbace_java_shell__init_A_Unit6__O(); case 18: return A_arbace_java_shell__init_A_Unit7__O(); case 19: return A_arbace_java_shell__init_A_Unit8__O(); case 20: return A_arbace_java_shell__init_A_Unit9__O()}; return nil }

func A_arbace_java_shell__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_java_shell__init_A_New()}; return nil }

var A_arbace_java_shell__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_java_shell__init_A_invoke, New: A_arbace_java_shell__init_A_new}

var A_arbace_java_shell__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.java.shell__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_java_shell.A_arbace_java_shell__init_A", Source: "shell.ae"})

func init() { i := A_arbace_java_shell__init_A_class.Info(); i.IsInstance = A_arbace_java_shell__init_A_InstanceOf; i.Init = A_arbace_java_shell__init_A_Init; i.Table = A_arbace_java_shell__init_A_members; jrt.RegisterGoType(A_arbace_java_shell__init_A_class, reflect.TypeFor[A_arbace_java_shell__init_A]()) }
