//line a2g_strings.ae:1
package aot_arbace_java_shell

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("use")

var Lit_3 *jrt.String = jrt.Intern("arbace.java.io")

var Lit_4 *jrt.String = jrt.Intern("only")

var Lit_5 *jrt.String = jrt.Intern("as-file")

var Lit_6 *jrt.String = jrt.Intern("copy")

var Lit_7 *jrt.String = jrt.Intern("line")

var Lit_8 *jrt.String = jrt.Intern("column")

var Lit_9 *jrt.String = jrt.Intern("commute")

var Lit_10 *jrt.String = jrt.Intern("deref")

var Lit_11 *jrt.String = jrt.Intern("conj")

var Lit_12 *jrt.String = jrt.Intern("arbace.java.shell")

var Lit_13 *jrt.String = jrt.Intern("author")

var Lit_14 *jrt.String = jrt.Intern("Chris Houser, Stuart Halloway")

var Lit_15 *jrt.String = jrt.Intern("doc")

var Lit_16 *jrt.String = jrt.Intern("Conveniently launch a sub-process providing its stdin and\ncollecting its stdout")

var Lit_17 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_18 *jrt.String = jrt.Intern("seq")

var Lit_19 *jrt.String = jrt.Intern("concat")

var Lit_20 *jrt.String = jrt.Intern("list")

var Lit_21 *jrt.String = jrt.Intern("binding")

var Lit_22 *jrt.String = jrt.Intern("apply")

var Lit_23 *jrt.String = jrt.Intern("vector")

var Lit_24 *jrt.String = jrt.Intern("*sh-dir*")

var Lit_25 *jrt.String = jrt.Intern("*sh-env*")

var Lit_26 *jrt.String = jrt.Intern("make-array")

var Lit_27 *jrt.String = jrt.Intern("+")

var Lit_28 *jrt.String = jrt.Intern("map")

var Lit_29 *jrt.String = jrt.Intern("count")

var Lit_30 *jrt.String = jrt.Intern("out-enc")

var Lit_31 *jrt.String = jrt.Intern("in-enc")

var Lit_32 *jrt.String = jrt.Intern("dir")

var Lit_33 *jrt.String = jrt.Intern("env")

var Lit_34 *jrt.String = jrt.Intern("split-with")

var Lit_35 *jrt.String = jrt.Intern("string?")

var Lit_36 *jrt.String = jrt.Intern("merge")

var Lit_37 *jrt.String = jrt.Intern("hash-map")

var Lit_38 *jrt.String = jrt.Intern("map?")

var Lit_39 *jrt.String = jrt.Intern("into-array")

var Lit_40 *jrt.String = jrt.Intern("java.lang.String")

var Lit_41 *jrt.String = jrt.Intern("name")

var Lit_42 *jrt.String = jrt.Intern("encoding")

var Lit_43 *jrt.String = jrt.Intern("stream-to-string")

var Lit_44 *jrt.String = jrt.Intern("bytes")

var Lit_45 *jrt.String = jrt.Intern("stream-to-bytes")

var Lit_46 *jrt.String = jrt.Intern("parse-args")

var Lit_47 *jrt.String = jrt.Intern("java.lang.Runtime")

var Lit_48 *jrt.String = jrt.Intern("as-env-strings")

var Lit_49 *jrt.String = jrt.Intern("next")

var Lit_50 *jrt.String = jrt.Intern("to-array")

var Lit_51 *jrt.String = jrt.Intern("first")

var Lit_52 *jrt.String = jrt.Intern("in")

var Lit_53 *jrt.String = jrt.Intern("future-call")

var Lit_54 *jrt.String = jrt.Intern("exit")

var Lit_55 *jrt.String = jrt.Intern("out")

var Lit_56 *jrt.String = jrt.Intern("err")

var Lit_57 *jrt.String = jrt.Intern("stream-to-enc")

var Lit_58 *jrt.String = jrt.Intern("arbace.java.shell$aconcat")

var Lit_59 *jrt.String = jrt.Intern("arbace.java.shell$as_env_strings")

var Lit_60 *jrt.String = jrt.Intern("arbace.java.shell$as_env_strings$fn__1651000028")

var Lit_61 *jrt.String = jrt.Intern("=")

var Lit_62 *jrt.String = jrt.Intern("arbace.java.shell$eval1651000004$loading__1927001464__auto____1651000005")

var Lit_63 *jrt.String = jrt.Intern("java.io.ByteArrayOutputStream")

var Lit_64 *jrt.String = jrt.Intern("java.io.StringWriter")

var Lit_65 *jrt.String = jrt.Intern("java.nio.charset.Charset")

var Lit_66 *jrt.String = jrt.Intern("arbace.java.shell$eval1651000008$fn__1651000009")

var Lit_67 *jrt.String = jrt.Intern("arbace.java.shell$parse_args")

var Lit_68 *jrt.String = jrt.Intern("UTF-8")

var Lit_69 *jrt.String = jrt.Intern("arbace.java.shell$sh")

var Lit_70 *jrt.String = jrt.Intern("exec")

var Lit_71 *jrt.String = jrt.Intern("arbace.java.shell$sh$fn__1651000042")

var Lit_72 *jrt.String = jrt.Intern("arbace.java.shell$sh$fn__1651000044")

var Lit_73 *jrt.String = jrt.Intern("arbace.java.shell$sh$fn__1651000046")

var Lit_74 *jrt.String = jrt.Intern("arbace.java.shell$stream_to_bytes")

var Lit_75 *jrt.String = jrt.Intern("arbace.java.shell$stream_to_enc")

var Lit_76 *jrt.String = jrt.Intern("arbace.java.shell$stream_to_string")

var Lit_77 *jrt.String = jrt.Intern("arbace.java.shell$with_sh_dir")

var Lit_78 *jrt.String = jrt.Intern("arbace.java.shell$with_sh_env")

var Lit_79 *jrt.String = jrt.Intern("in-ns")

var Lit_80 *jrt.String = jrt.Intern("dynamic")

var Lit_81 *jrt.String = jrt.Intern("file")

var Lit_82 *jrt.String = jrt.Intern("arbace/java/shell.ae")

var Lit_83 *jrt.String = jrt.Intern("with-sh-dir")

var Lit_84 *jrt.String = jrt.Intern("arglists")

var Lit_85 *jrt.String = jrt.Intern("&")

var Lit_86 *jrt.String = jrt.Intern("forms")

var Lit_87 *jrt.String = jrt.Intern("Sets the directory for use with sh, see sh for details.")

var Lit_88 *jrt.String = jrt.Intern("added")

var Lit_89 *jrt.String = jrt.Intern("1.2")

var Lit_90 *jrt.String = jrt.Intern("with-sh-env")

var Lit_91 *jrt.String = jrt.Intern("Sets the environment for use with sh, see sh for details.")

var Lit_92 *jrt.String = jrt.Intern("aconcat")

var Lit_93 *jrt.String = jrt.Intern("private")

var Lit_94 *jrt.String = jrt.Intern("type")

var Lit_95 *jrt.String = jrt.Intern("xs")

var Lit_96 *jrt.String = jrt.Intern("Concatenates arrays of given type.")

var Lit_97 *jrt.String = jrt.Intern("args")

var Lit_98 *jrt.String = jrt.Intern("tag")

var Lit_99 *jrt.String = jrt.Intern("[Ljava.lang.String;")

var Lit_100 *jrt.String = jrt.Intern("arg")

var Lit_101 *jrt.String = jrt.Intern("Helper so that callers can pass a Clojure map for the :env to sh.")

var Lit_102 *jrt.String = jrt.Intern("enc")

var Lit_103 *jrt.String = jrt.Intern("stream")

var Lit_104 *jrt.String = jrt.Intern("sh")

var Lit_105 *jrt.String = jrt.Intern("Passes the given strings to Runtime.exec() to launch a sub-process.\n\n  Options are\n\n  :in      may be given followed by any legal input source for\n           arbace.java.io/copy, e.g. InputStream, Reader, File, byte[],\n           or String, to be fed to the sub-process's stdin.\n  :in-enc  option may be given followed by a String, used as a character\n           encoding name (for example \"UTF-8\" or \"ISO-8859-1\") to\n           convert the input string specified by the :in option to the\n           sub-process's stdin.  Defaults to UTF-8.\n           If the :in option provides a byte array, then the bytes are passed\n           unencoded, and this option is ignored.\n  :out-enc option may be given followed by :bytes or a String. If a\n           String is given, it will be used as a character encoding\n           name (for example \"UTF-8\" or \"ISO-8859-1\") to convert\n           the sub-process's stdout to a String which is returned.\n           If :bytes is given, the sub-process's stdout will be stored\n           in a byte array and returned.  Defaults to UTF-8.\n  :env     override the process env with a map (or the underlying Java\n           String[] if you are a masochist).\n  :dir     override the process dir with a String or java.io.File.\n\n  You can bind :env or :dir for multiple operations using with-sh-env\n  and with-sh-dir.\n\n  sh returns a map of\n    :exit => sub-process's exit code\n    :out  => sub-process's stdout (as byte[] or String)\n    :err  => sub-process's stderr (String via platform default encoding)")
