//line aot_arbace_java_shell.ae:1
package aot_arbace_java_shell

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_New() *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_shell_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_1); lang.IFn_Cast(A_arbace_java_shell_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_java_shell_eval1651000008_fn__1651000009_A_New() *A_arbace_java_shell_eval1651000008_fn__1651000009_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_eval1651000008_fn__1651000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_4.GetRawRoot__O()); var tmp2 any; var root_9 any = A_arbace_java_shell_A_const_5.GetRawRoot__O(); var linked_10 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_9, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_11 lang.IFn; if linked_10 == nil { ifn_11 = lang.IFn_Cast(root_9) } else { ifn_11 = nil }; var arg_12 any = A_arbace_java_shell_A_const_6; if linked_10 == nil { tmp2 = ifn_11.Invoke_O__O(arg_12) } else { tmp2 = linked_10.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_9, arg_12) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_shell_A_const_7.GetRawRoot__O(), A_arbace_java_shell_A_const_8) }











func A_arbace_java_shell_with_sh_dir_A_New() *A_arbace_java_shell_with_sh_dir_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_with_sh_dir_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) Ctor() {}
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, dir__2, forms__3 any) any { var root_39 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_40 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_39, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_41 lang.IFn; if linked_40 == nil { ifn_41 = lang.IFn_Cast(root_39) } else { ifn_41 = nil }; var arg_42 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_12); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()); var tmp4 any; var root_28 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = A_arbace_java_shell_A_const_14.GetRawRoot__O(); var arg_32 any; var root_24 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any; var root_19 any = A_arbace_java_shell_A_const_10.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_15); var arg_23 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(dir__2); if linked_20 == nil { arg_27 = ifn_21.Invoke_O_O__O(arg_22, arg_23) } else { arg_27 = linked_20.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_19, arg_22, arg_23) }; if linked_25 == nil { arg_32 = ifn_26.Invoke_O__O(arg_27) } else { arg_32 = linked_25.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_24, arg_27) }; if linked_29 == nil { tmp4 = ifn_30.Invoke_O_O__O(arg_31, arg_32) } else { tmp4 = linked_29.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_28, arg_31, arg_32) }; arg_42 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), forms__3); if linked_40 == nil { return ifn_41.Invoke_O__O(arg_42) } else { return linked_40.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_39, arg_42) } }






func A_arbace_java_shell_with_sh_env_A_New() *A_arbace_java_shell_with_sh_env_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_with_sh_env_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) Ctor() {}
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, env__2, forms__3 any) any { var root_63 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_16); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()); var tmp4 any; var root_52 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = A_arbace_java_shell_A_const_14.GetRawRoot__O(); var arg_56 any; var root_48 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any; var root_43 any = A_arbace_java_shell_A_const_10.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_17); var arg_47 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(env__2); if linked_44 == nil { arg_51 = ifn_45.Invoke_O_O__O(arg_46, arg_47) } else { arg_51 = linked_44.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_43, arg_46, arg_47) }; if linked_49 == nil { arg_56 = ifn_50.Invoke_O__O(arg_51) } else { arg_56 = linked_49.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_48, arg_51) }; if linked_53 == nil { tmp4 = ifn_54.Invoke_O_O__O(arg_55, arg_56) } else { tmp4 = linked_53.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_52, arg_55, arg_56) }; arg_66 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), forms__3); if linked_64 == nil { return ifn_65.Invoke_O__O(arg_66) } else { return linked_64.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_63, arg_66) } }






func A_arbace_java_shell_aconcat_A_New() *A_arbace_java_shell_aconcat_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_aconcat_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) Ctor() {}
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) DoInvoke_O_O_O__O(self, type__0, xs__1 any) any { var target__3 any; var root_77 any = A_arbace_java_shell_A_const_18.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_79 lang.IFn; if


	linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = type__0; var arg_81 any; var root_72 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = A_arbace_java_shell_A_const_19.GetRawRoot__O(); var arg_76 any; var root_67 any = A_arbace_java_shell_A_const_20.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_69 lang.IFn; if linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = A_arbace_java_shell_A_const_21.GetRawRoot__O(); var arg_71 any = xs__1; if linked_68 == nil { arg_76 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { arg_76 = linked_68.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; if linked_73 == nil { arg_81 = ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { arg_81 = linked_73.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) }; if linked_78 == nil { target__3 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { target__3 = linked_78.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; var i__4 int64 = 0; var idx__5 int64 = 0; L1:
//line :35:1
	for { var temp__1927000414__auto____6 any = lang.RT_Nth_O_I_O__O_NoInit(xs__1, lang.RT_IntCast_J__I_NoInit(i__4), nil)




		if jrt.J2g_Truth(temp__1927000414__auto____6) { var a__7 any = temp__1927000414__auto____6
			jrt.System_Arraycopy_O_I_O_I_I__V(a__7, lang.RT_IntCast_J__I_NoInit(0), target__3, lang.RT_IntCast_J__I_NoInit(idx__5), lang.RT_Count_O__I_NoInit(a__7))
			i__4, idx__5 = lang.Numbers_Inc_J__J_NoInit(i__4), lang.Numbers_Add_J_J__J_NoInit(idx__5, int64(lang.RT_Count_O__I_NoInit(a__7))); continue L1 }
//line :35:1
		break L1 }; return target__3 }









func A_arbace_java_shell_parse_args_A_New() *A_arbace_java_shell_parse_args_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_parse_args_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Ctor() {}
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Invoke_O_O__O(self, args__0 any) any { var default_encoding__2 any = Lit_6; var tmp1 any = A_arbace_java_shell_A_const_22; var tmp2 any = A_arbace_java_shell_A_const_23; var tmp3 any = A_arbace_java_shell_A_const_24; var tmp4 any = A_arbace_java_shell_A_const_25.Get__O(); var tmp5 any = A_arbace_java_shell_A_const_26; var default_opts__3 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, default_encoding__2, tmp2, default_encoding__2, tmp3, tmp4, tmp5, A_arbace_java_shell_A_const_27.Get__O())); var vec__1651000023__4 any; var root_82 any = A_arbace_java_shell_A_const_28.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_84 lang.IFn; if



	linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_java_shell_A_const_29.GetRawRoot__O(); var arg_86 any = args__0; if linked_83 == nil { vec__1651000023__4 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { vec__1651000023__4 = linked_83.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; var cmd__5 any = /*line :45:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1651000023__4, lang.RT_IntCast_J__I_NoInit(0), nil); var opts__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000023__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_92 any = A_arbace_java_shell_A_const_30.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_94 lang.IFn; if




	linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = default_opts__3; var arg_96 any; var root_87 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = A_arbace_java_shell_A_const_31.GetRawRoot__O(); var arg_91 any = opts__6; if linked_88 == nil { arg_96 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { arg_96 = linked_88.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }; if linked_93 == nil { tmp6 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { tmp6 = linked_93.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }; return /*line :45:1*/ lang.Tuple_Create_O_O__IPersistentVector(cmd__5, tmp6) }






func A_arbace_java_shell_as_env_strings_A_New() *A_arbace_java_shell_as_env_strings_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_as_env_strings_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Ctor() {}
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Invoke_O_O__O(self, arg__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(arg__0, nil) { return nil } else { var tmp1 any; var root_97 any = A_arbace_java_shell_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_99 lang.IFn

		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = arg__0; if linked_98 == nil { tmp1 = ifn_99.Invoke_O__O(arg_100) } else { tmp1 = linked_98.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_97, arg_100) }
//line :55:1
		if jrt.J2g_Truth(tmp1) {

			var root_111 any = A_arbace_java_shell_A_const_33.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = A_arbace_java_shell_A_const_34; var arg_115 any; var root_106 any = A_arbace_java_shell_A_const_20.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var tmp2 any = A_arbace_java_shell_as_env_strings_fn__1651000028_A_New(); var tmp3 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class = fncls__105d; tmp3 = fncls__105d } else { tmp3 = fncls__105 }; arg_109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_110 any = arg__0; if linked_107 == nil { arg_115 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { arg_115 = linked_107.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; if linked_112 == nil { return ifn_113.Invoke_O_O__O(arg_114, arg_115) } else { return linked_112.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_111, arg_114, arg_115) } } else {
//line :55:1
				if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) { return arg__0 } else { return nil
				} } } }
func A_arbace_java_shell_as_env_strings_fn__1651000028_A_New() *A_arbace_java_shell_as_env_strings_fn__1651000028_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_as_env_strings_fn__1651000028_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Ctor() {}
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Invoke_O_O__O(self, p__1651000027__1 any) any { var vec__1651000029__2 any = p__1651000027__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000029__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000029__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_101 any = A_arbace_java_shell_A_const_35.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = k__3; if linked_102 == nil { tmp2 = ifn_103.Invoke_O__O(arg_104) } else { tmp2 = linked_102.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_101, arg_104) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, v__4)).Ref() }


func A_arbace_java_shell_stream_to_bytes_A_New() *A_arbace_java_shell_stream_to_bytes_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_bytes_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Ctor() {}
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Invoke_O_O__O(self, in__0 any) any { var bout__2 any = jrt.ByteArrayOutputStream_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()).Invoke_O_O__O(in__0, bout__2)
	tmp1 = jrt.NN(jrt.ByteArrayOutputStream_Cast(bout__2)).ToByteArray__B1().Ref()
//line :60:1
	return nil }();

	jrt.NN(jrt.ByteArrayOutputStream_Cast(bout__2)).Close__V(); if /*line :60:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_java_shell_stream_to_string_A_New() *A_arbace_java_shell_stream_to_string_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_string_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Ctor() {}
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O_O__O(self, in__0, enc__1 any) any { var bout__3 any = jrt.StringWriter_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()).Invoke_O_O_O_O__O(in__0, bout__3, A_arbace_java_shell_A_const_37, enc__1)
	tmp1 = jrt.NN(jrt.StringWriter_Cast(bout__3)).ToString__String().Ref()
//line :66:1
	return nil }();


	jrt.NN(jrt.StringWriter_Cast(bout__3)).Close__V(); if /*line :66:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O__O(self, in__0 any) any {
	var root_128 any = A_arbace_java_shell_A_const_38.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_128, A_arbace_java_shell_stream_to_string_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = in__0; var arg_132 any = jrt.Charset_DefaultCharset__Charset().Name__String().Ref(); if linked_129 == nil { return ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { return linked_129.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O_O__O(root_128, arg_131, arg_132)
	}
}



func A_arbace_java_shell_stream_to_enc_A_New() *A_arbace_java_shell_stream_to_enc_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_enc_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Ctor() {}
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Invoke_O_O_O__O(self, stream__0, enc__1 any) any {

	if lang.Util_Equiv_O_O__Z_NoInit(enc__1, A_arbace_java_shell_A_const_39) {
		var root_133 any = A_arbace_java_shell_A_const_40.GetRawRoot__O(); var linked_134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_133, A_arbace_java_shell_stream_to_bytes_A_fn_class); var ifn_135 lang.IFn; if linked_134 == nil { ifn_135 = lang.IFn_Cast(root_133) } else { ifn_135 = nil }; var arg_136 any = stream__0; if linked_134 == nil { return ifn_135.Invoke_O__O(arg_136) } else { return linked_134.(*A_arbace_java_shell_stream_to_bytes_A).Invoke_O_O__O(root_133, arg_136) } } else {
			var root_137 any = A_arbace_java_shell_A_const_38.GetRawRoot__O(); var linked_138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_137, A_arbace_java_shell_stream_to_string_A_fn_class); var ifn_139 lang.IFn; if linked_138 == nil { ifn_139 = lang.IFn_Cast(root_137) } else { ifn_139 = nil }; var arg_140 any = stream__0; var arg_141 any = enc__1; if linked_138 == nil { return ifn_139.Invoke_O_O__O(arg_140, arg_141) } else { return linked_138.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O_O__O(root_137, arg_140, arg_141)
			} } }
func A_arbace_java_shell_sh_A_New() *A_arbace_java_shell_sh_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_java_shell_sh_A) Ctor() {}
//line :79:1
func (t *A_arbace_java_shell_sh_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1651000037__2 any; var root_142 any = A_arbace_java_shell_A_const_41.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, A_arbace_java_shell_parse_args_A_fn_class); var ifn_144 lang.IFn; if
































	linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = args__0; if linked_143 == nil { vec__1651000037__2 = ifn_144.Invoke_O__O(arg_145) } else { vec__1651000037__2 = linked_143.(*A_arbace_java_shell_parse_args_A).Invoke_O_O__O(root_142, arg_145) }; var cmd__3 any = /*line :79:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1651000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var opts__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); var proc__5 any; var tmp1 any = jrt.Runtime_GetRuntime__Runtime().Ref(); var tmp2 *jrt.Class = A_arbace_java_shell_A_const_42; var tmp3 any; var root_146 any = A_arbace_java_shell_A_const_33.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_148 lang.IFn; if


































	linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = cmd__3; if linked_147 == nil { tmp3 = ifn_148.Invoke_O__O(arg_149) } else { tmp3 = linked_147.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O__O(root_146, arg_149) }; var tmp4 any = tmp3; var tmp5 any; var root_150 any = /*line :113:1*/A_arbace_java_shell_A_const_43.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, A_arbace_java_shell_as_env_strings_A_fn_class); var ifn_152 lang.IFn; if

	linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_java_shell_A_const_26.Invoke_O__O(opts__4); if linked_151 == nil { tmp5 = ifn_152.Invoke_O__O(arg_153) } else { tmp5 = linked_151.(*A_arbace_java_shell_as_env_strings_A).Invoke_O_O__O(root_150, arg_153) }; var tmp6 any = tmp5; var tmp7 any; var target_154 any = /*line :113:1*/A_arbace_java_shell_A_const_24.Invoke_O__O(opts__4); var tmp8 bool; var tmp9 bool; tmp9 =


	aot_arbace_java_io.A_arbace_java_io_Coercions_A_InstanceOf(target_154); if tmp9 { tmp9 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_154) }; tmp8 = tmp9; if tmp8 { tmp7 = aot_arbace_java_io.A_arbace_java_io_Coercions_A_Cast(target_154).As_file__O() } else { tmp7 = lang.IFn_Cast(A_arbace_java_shell_A_const_44.GetRawRoot__O()).Invoke_O__O(target_154) }; proc__5 = /*line :113:1*/lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_7, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7)); var map__1651000040__6 any = opts__4; var map__1651000040__7 any; if /*line :112:1*/ lang.ISeq_InstanceOf(map__1651000040__6) { var tmp10 any; var root_155 any = A_arbace_java_shell_A_const_45.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = map__1651000040__6; if linked_156 == nil { tmp10 = ifn_157.Invoke_O__O(arg_158) } else { tmp10 = linked_156.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_155, arg_158) }; if jrt.J2g_Truth(tmp10) { var tmp11 any; var root_159 any = A_arbace_java_shell_A_const_46.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = map__1651000040__6; if linked_160 == nil { tmp11 = ifn_161.Invoke_O__O(arg_162) } else { tmp11 = linked_160.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_159, arg_162) }; map__1651000040__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp11, jrt.Object_class.ArrayClass())).Ref() } else { var tmp12 any; var root_163 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = map__1651000040__6; if linked_164 == nil { tmp12 = ifn_165.Invoke_O__O(arg_166) } else { tmp12 = linked_164.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_163, arg_166) }; if jrt.J2g_Truth(tmp12) { var root_167 any = A_arbace_java_shell_A_const_47.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any = map__1651000040__6; if linked_168 == nil { map__1651000040__7 = ifn_169.Invoke_O__O(arg_170) } else { map__1651000040__7 = linked_168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_167, arg_170) } } else { map__1651000040__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1651000040__7 = map__1651000040__6 }; var in__8 any = /*line :79:1*/lang.RT_Get_O_O__O_NoInit(map__1651000040__7, A_arbace_java_shell_A_const_48); var in_enc__9 any = lang.RT_Get_O_O__O_NoInit(map__1651000040__7, A_arbace_java_shell_A_const_23); var out_enc__10 any = lang.RT_Get_O_O__O_NoInit(map__1651000040__7, A_arbace_java_shell_A_const_22); if






































	jrt.J2g_Truth(in__8) {
		var root_206 any = A_arbace_java_shell_A_const_49.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var tmp13 any = A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(proc__5, in_enc__9, in__8); var tmp14 *jrt.Class; var fncls__205 *jrt.Class = A_arbace_java_shell_sh_fn__1651000042_A_fn_class; if fncls__205 == nil { var fncls__205d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_java_shell_sh_fn__1651000042_A_fn_class = fncls__205d; tmp14 = fncls__205d } else { tmp14 = fncls__205 }; arg_209 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); if linked_207 == nil { ifn_208.Invoke_O__O(arg_209) } else { linked_207.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_206, arg_209) } } else {


			jrt.Process_Cast(proc__5).GetOutputStream__OutputStream().Close__V() }; var stdout__11 any = /*line :79:1*/jrt.Process_Cast(proc__5).GetInputStream__InputStream(); var tmp15 any; tmp28 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var stderr__14 any = jrt.Process_Cast(proc__5).GetErrorStream__InputStream(); tmp27 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__17 any; var root_177 any = A_arbace_java_shell_A_const_49.GetRawRoot__O(); var linked_178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_177, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_179 lang.IFn













































				if linked_178 == nil { ifn_179 = lang.IFn_Cast(root_177) } else { ifn_179 = nil }; var arg_180 any; var tmp16 any = A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(stdout__11, out_enc__10); var tmp17 *jrt.Class; var fncls__176 *jrt.Class = A_arbace_java_shell_sh_fn__1651000044_A_fn_class; if fncls__176 == nil { var fncls__176d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_java_shell_sh_fn__1651000044_A_fn_class = fncls__176d; tmp17 = fncls__176d } else { tmp17 = fncls__176 }; arg_180 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); if linked_178 == nil { out__17 = ifn_179.Invoke_O__O(arg_180) } else { out__17 = linked_178.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_177, arg_180) }
//line :79:1
				var err__18 any; var root_186 any = A_arbace_java_shell_A_const_49.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_188 lang.IFn














































				if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any; var tmp18 any = A_arbace_java_shell_sh_fn__1651000046_A_New_O(stderr__14); var tmp19 *jrt.Class; var fncls__185 *jrt.Class = A_arbace_java_shell_sh_fn__1651000046_A_fn_class; if fncls__185 == nil { var fncls__185d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_java_shell_sh_fn__1651000046_A_fn_class = fncls__185d; tmp19 = fncls__185d } else { tmp19 = fncls__185 }; arg_189 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp18, tmp19, nil); if linked_187 == nil { err__18 = ifn_188.Invoke_O__O(arg_189) } else { err__18 = linked_187.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_186, arg_189) }
//line :79:1
				var exit_code__19 int32 = jrt.Process_Cast(proc__5).WaitFor__I(); var tmp20 any = A_arbace_java_shell_A_const_51; var tmp21 any = jrt.Integer_ValueOf_I__Integer_NoInit(exit_code__19).Ref(); var tmp22 any = A_arbace_java_shell_A_const_52; var tmp23 any; var root_190 any = A_arbace_java_shell_A_const_5.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_192 lang.IFn













































				if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = out__17; if linked_191 == nil { tmp23 = ifn_192.Invoke_O__O(arg_193) } else { tmp23 = linked_191.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_190, arg_193) }
//line :79:1
				var tmp24 any = tmp23; var tmp25 any = A_arbace_java_shell_A_const_53; var tmp26 any; var root_194 any = A_arbace_java_shell_A_const_5.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_196 lang.IFn













































				if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = err__18; if linked_195 == nil { tmp26 = ifn_196.Invoke_O__O(arg_197) } else { tmp26 = linked_195.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_194, arg_197) }
//line :79:1
				tmp15 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp21, tmp22, tmp24, tmp25, tmp26)) }; return nil }()











































				jrt.InputStream_Cast(stderr__14).Close__V()
//line :79:1
				if tmp27 != nil { panic(tmp27) } }; return nil }();











































	jrt.InputStream_Cast(stdout__11).Close__V(); if /*line :79:1*/ tmp28 != nil { panic(tmp28) }; return tmp15 }







































func A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_java_shell_sh_fn__1651000042_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Ctor_O_O_O(c__proc, c__in_enc, c__in any) { t.F_proc = c__proc; t.F_in_enc = c__in_enc; t.F_in = c__in }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Invoke_O__O(self any) any { var os__1 any; var tmp1 any; var t_ any = t.F_proc;
										t.F_proc = nil; tmp1 = t_; os__1 = jrt.Process_Cast(tmp1).GetOutputStream__OutputStream(); var tmp2 any; tmp8 := /*line :119:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()); var tmp4 any; var t__2 any = t.F_in; t.F_in = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any = A_arbace_java_shell_A_const_37; var tmp7 any; var t__3 any = t.F_in_enc; t.F_in_enc = nil; tmp7 = t__3; tmp2 = tmp3.Invoke_O_O_O_O__O(tmp5, os__1, tmp6, tmp7) }
//line :119:1
		return nil }();
	jrt.OutputStream_Cast(os__1).Close__V(); if /*line :119:1*/ tmp8 != nil { panic(tmp8) }; return tmp2 }





func A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(p0, p1 any) *A_arbace_java_shell_sh_fn__1651000044_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Ctor_O_O(c__stdout, c__out_enc any) { t.F_stdout = c__stdout; t.F_out_enc = c__out_enc }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Invoke_O__O(self any) any { var root_171 any = A_arbace_java_shell_A_const_50.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, A_arbace_java_shell_stream_to_enc_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var t_ any = t.F_stdout; t.F_stdout = nil; arg_174 = t_; var arg_175 any; var t__2 any = t.F_out_enc; t.F_out_enc = nil; arg_175 = t__2; if linked_172 == nil { return ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { return linked_172.(*A_arbace_java_shell_stream_to_enc_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) } }
func A_arbace_java_shell_sh_fn__1651000046_A_New_O(p0 any) *A_arbace_java_shell_sh_fn__1651000046_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000046_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Ctor_O(c__stderr any) { t.F_stderr = c__stderr }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Invoke_O__O(self any) any { var root_181 any = A_arbace_java_shell_A_const_38.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, A_arbace_java_shell_stream_to_string_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any; var t_ any = t.F_stderr; t.F_stderr = nil; arg_184 = t_; if linked_182 == nil { return ifn_183.Invoke_O__O(arg_184) } else { return linked_182.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O__O(root_181, arg_184) } }












type A_arbace_java_shell_A struct{ jrt.Object }

var A_arbace_java_shell_A_const_pool *jrt.RefArray

var A_arbace_java_shell_A_const_0 *lang.Var

var A_arbace_java_shell_A_const_1 any

var A_arbace_java_shell_A_const_2 *lang.Var

var A_arbace_java_shell_A_const_3 any

var A_arbace_java_shell_A_const_4 *lang.Var

var A_arbace_java_shell_A_const_5 *lang.Var

var A_arbace_java_shell_A_const_6 *lang.Var

var A_arbace_java_shell_A_const_7 *lang.Var

var A_arbace_java_shell_A_const_8 any

var A_arbace_java_shell_A_const_9 *lang.Var

var A_arbace_java_shell_A_const_10 *lang.Var

var A_arbace_java_shell_A_const_11 *lang.Var

var A_arbace_java_shell_A_const_12 any

var A_arbace_java_shell_A_const_13 *lang.Var

var A_arbace_java_shell_A_const_14 *lang.Var

var A_arbace_java_shell_A_const_15 any

var A_arbace_java_shell_A_const_16 any

var A_arbace_java_shell_A_const_17 any

var A_arbace_java_shell_A_const_18 *lang.Var

var A_arbace_java_shell_A_const_19 *lang.Var

var A_arbace_java_shell_A_const_20 *lang.Var

var A_arbace_java_shell_A_const_21 *lang.Var

var A_arbace_java_shell_A_const_22 *lang.Keyword

var A_arbace_java_shell_A_const_23 *lang.Keyword

var A_arbace_java_shell_A_const_24 *lang.Keyword

var A_arbace_java_shell_A_const_25 *lang.Var

var A_arbace_java_shell_A_const_26 *lang.Keyword

var A_arbace_java_shell_A_const_27 *lang.Var

var A_arbace_java_shell_A_const_28 *lang.Var

var A_arbace_java_shell_A_const_29 *lang.Var

var A_arbace_java_shell_A_const_30 *lang.Var

var A_arbace_java_shell_A_const_31 *lang.Var

var A_arbace_java_shell_A_const_32 *lang.Var

var A_arbace_java_shell_A_const_33 *lang.Var

var A_arbace_java_shell_A_const_34 *jrt.Class

var A_arbace_java_shell_A_const_35 *lang.Var

var A_arbace_java_shell_A_const_36 *lang.Var

var A_arbace_java_shell_A_const_37 *lang.Keyword

var A_arbace_java_shell_A_const_38 *lang.Var

var A_arbace_java_shell_A_const_39 *lang.Keyword

var A_arbace_java_shell_A_const_40 *lang.Var

var A_arbace_java_shell_A_const_41 *lang.Var

var A_arbace_java_shell_A_const_42 *jrt.Class

var A_arbace_java_shell_A_const_43 *lang.Var

var A_arbace_java_shell_A_const_44 *lang.Var

var A_arbace_java_shell_A_const_45 *lang.Var

var A_arbace_java_shell_A_const_46 *lang.Var

var A_arbace_java_shell_A_const_47 *lang.Var

var A_arbace_java_shell_A_const_48 *lang.Keyword

var A_arbace_java_shell_A_const_49 *lang.Var

var A_arbace_java_shell_A_const_50 *lang.Var

var A_arbace_java_shell_A_const_51 *lang.Keyword

var A_arbace_java_shell_A_const_52 *lang.Keyword

var A_arbace_java_shell_A_const_53 *lang.Keyword

var A_arbace_java_shell_A_init jrt.ClassInit

func A_arbace_java_shell_A_Init() { if !A_arbace_java_shell_A_init.Done() { A_arbace_java_shell_A_init.Run(A_arbace_java_shell_A_clinit) } }

func A_arbace_java_shell_A_clinit() { A_arbace_java_shell_A_clinit_p0(); A_arbace_java_shell_A_clinit_p1(); A_arbace_java_shell_A_clinit_p2(); A_arbace_java_shell_A_clinit_p3(); A_arbace_java_shell_A_clinit_p4() }

func A_arbace_java_shell_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_shell_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 76); A_arbace_java_shell_A_const_0 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[22]); A_arbace_java_shell_A_const_1 = A_arbace_java_shell_A_const_pool.A[23]; A_arbace_java_shell_A_const_2 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[24]); A_arbace_java_shell_A_const_3 = A_arbace_java_shell_A_const_pool.A[25]; A_arbace_java_shell_A_const_4 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[26]); A_arbace_java_shell_A_const_5 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[27]); A_arbace_java_shell_A_const_6 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[28]); A_arbace_java_shell_A_const_7 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[29]); A_arbace_java_shell_A_const_8 = A_arbace_java_shell_A_const_pool.A[30]; A_arbace_java_shell_A_const_9 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[31]); A_arbace_java_shell_A_const_10 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[32]); A_arbace_java_shell_A_const_11 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[33]) }

func A_arbace_java_shell_A_clinit_p1() { A_arbace_java_shell_A_const_12 = A_arbace_java_shell_A_const_pool.A[34]; A_arbace_java_shell_A_const_13 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[35]); A_arbace_java_shell_A_const_14 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[36]); A_arbace_java_shell_A_const_15 = A_arbace_java_shell_A_const_pool.A[37]; A_arbace_java_shell_A_const_16 = A_arbace_java_shell_A_const_pool.A[38]; A_arbace_java_shell_A_const_17 = A_arbace_java_shell_A_const_pool.A[39]; A_arbace_java_shell_A_const_18 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[40]); A_arbace_java_shell_A_const_19 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[41]); A_arbace_java_shell_A_const_20 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[42]); A_arbace_java_shell_A_const_21 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[43]); A_arbace_java_shell_A_const_22 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[44]); A_arbace_java_shell_A_const_23 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[45]); A_arbace_java_shell_A_const_24 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[46]) }

func A_arbace_java_shell_A_clinit_p2() { A_arbace_java_shell_A_const_25 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[47]); A_arbace_java_shell_A_const_26 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[48]); A_arbace_java_shell_A_const_27 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[49]); A_arbace_java_shell_A_const_28 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[50]); A_arbace_java_shell_A_const_29 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[51]); A_arbace_java_shell_A_const_30 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[52]); A_arbace_java_shell_A_const_31 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[53]); A_arbace_java_shell_A_const_32 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[54]); A_arbace_java_shell_A_const_33 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[55]); A_arbace_java_shell_A_const_34 = jrt.Class_Cast(A_arbace_java_shell_A_const_pool.A[56]); A_arbace_java_shell_A_const_35 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[57]); A_arbace_java_shell_A_const_36 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[58]) }

func A_arbace_java_shell_A_clinit_p3() { A_arbace_java_shell_A_const_37 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[59]); A_arbace_java_shell_A_const_38 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[60]); A_arbace_java_shell_A_const_39 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[61]); A_arbace_java_shell_A_const_40 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[62]); A_arbace_java_shell_A_const_41 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[63]); A_arbace_java_shell_A_const_42 = jrt.Class_Cast(A_arbace_java_shell_A_const_pool.A[64]); A_arbace_java_shell_A_const_43 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[65]); A_arbace_java_shell_A_const_44 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[66]); A_arbace_java_shell_A_const_45 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[67]); A_arbace_java_shell_A_const_46 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[68]); A_arbace_java_shell_A_const_47 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[69]); A_arbace_java_shell_A_const_48 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[70]) }

func A_arbace_java_shell_A_clinit_p4() { A_arbace_java_shell_A_const_49 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[71]); A_arbace_java_shell_A_const_50 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[72]); A_arbace_java_shell_A_const_51 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[73]); A_arbace_java_shell_A_const_52 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[74]); A_arbace_java_shell_A_const_53 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[75]) }

func A_arbace_java_shell_A_New() *A_arbace_java_shell_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_A) Ctor() {}

func (t *A_arbace_java_shell_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_A_class }

func (t *A_arbace_java_shell_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_A); return ok }

func A_arbace_java_shell_A_Cast(x any) *A_arbace_java_shell_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_A_class)) }; return v }



type A_arbace_java_shell_aconcat_A struct{ j2g_header uint64 }

var A_arbace_java_shell_aconcat_A_fn_class *jrt.Class



type A_arbace_java_shell_as_env_strings_A struct{ j2g_header uint64 }

var A_arbace_java_shell_as_env_strings_A_fn_class *jrt.Class



type A_arbace_java_shell_as_env_strings_fn__1651000028_A struct{ j2g_header uint64 }

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class *jrt.Class



type A_arbace_java_shell_eval1651000004_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000004_A_New() *A_arbace_java_shell_eval1651000004_A { t := &A_arbace_java_shell_eval1651000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000004_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000004_A_class }

func (t *A_arbace_java_shell_eval1651000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000004_A); return ok }

func A_arbace_java_shell_eval1651000004_A_Cast(x any) *A_arbace_java_shell_eval1651000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000004_A_class)) }; return v }



type A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A struct{ j2g_header uint64 }

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_fn_class *jrt.Class



type A_arbace_java_shell_eval1651000008_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000008_A_New() *A_arbace_java_shell_eval1651000008_A { t := &A_arbace_java_shell_eval1651000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000008_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000008_A_class }

func (t *A_arbace_java_shell_eval1651000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000008_A); return ok }

func A_arbace_java_shell_eval1651000008_A_Cast(x any) *A_arbace_java_shell_eval1651000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000008_A_class)) }; return v }



type A_arbace_java_shell_eval1651000008_fn__1651000009_A struct{ j2g_header uint64 }

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_fn_class *jrt.Class



type A_arbace_java_shell_parse_args_A struct{ j2g_header uint64 }

var A_arbace_java_shell_parse_args_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_A struct{ j2g_header uint64 }

var A_arbace_java_shell_sh_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000042_A struct{ j2g_header uint64; F_proc, F_in_enc, F_in any }

var A_arbace_java_shell_sh_fn__1651000042_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000044_A struct{ j2g_header uint64; F_stdout, F_out_enc any }

var A_arbace_java_shell_sh_fn__1651000044_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000046_A struct{ j2g_header uint64; F_stderr any }

var A_arbace_java_shell_sh_fn__1651000046_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_bytes_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_bytes_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_enc_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_enc_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_string_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_string_A_fn_class *jrt.Class



type A_arbace_java_shell_with_sh_dir_A struct{ j2g_header uint64 }

var A_arbace_java_shell_with_sh_dir_A_fn_class *jrt.Class



type A_arbace_java_shell_with_sh_env_A struct{ j2g_header uint64 }

var A_arbace_java_shell_with_sh_env_A_fn_class *jrt.Class
