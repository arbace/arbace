//line aot_arbace_java_shell.ae:1
package aot_arbace_java_shell

import (
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_New() *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A { A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_Init(); t := &A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp13 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_java_shell_A_Init(); tmp4 = A_arbace_java_shell_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_java_shell_A_Init(); tmp6 = A_arbace_java_shell_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_1; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_3; tmp8.Invoke_O__O(tmp9); var tmp10 *lang.Var; lang.RT_Init(); tmp10 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp10).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_63)); var tmp11 *lang.Var; lang.RT_Init(); tmp11 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp11).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_64)); var tmp12 *lang.Var; lang.RT_Init(); tmp12 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp12).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_65)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp13 != nil { panic(tmp13) }; return tmp3 }
//line :9:1
func A_arbace_java_shell_eval1651000008_fn__1651000009_A_New() *A_arbace_java_shell_eval1651000008_fn__1651000009_A { A_arbace_java_shell_eval1651000008_fn__1651000009_A_Init(); t := &A_arbace_java_shell_eval1651000008_fn__1651000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_java_shell_A_Init(); tmp5 = A_arbace_java_shell_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }











func A_arbace_java_shell_with_sh_dir_A_New() *A_arbace_java_shell_with_sh_dir_A { A_arbace_java_shell_with_sh_dir_A_Init(); t := &A_arbace_java_shell_with_sh_dir_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) Ctor() {}
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, dir__2, forms__3 any) any { var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_10; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_java_shell_A_Init(); tmp5 = A_arbace_java_shell_A_const_11; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_12; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_11; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_java_shell_A_Init(); tmp11 = A_arbace_java_shell_A_const_13; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_java_shell_A_Init(); tmp13 = A_arbace_java_shell_A_const_14; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_java_shell_A_Init(); tmp15 = A_arbace_java_shell_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_java_shell_A_Init(); tmp17 = A_arbace_java_shell_A_const_10; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_java_shell_A_Init(); tmp19 = A_arbace_java_shell_A_const_11; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_java_shell_A_Init(); tmp21 = A_arbace_java_shell_A_const_15; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_java_shell_A_Init(); tmp23 = A_arbace_java_shell_A_const_11; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(dir__2))))), forms__3)) }






func A_arbace_java_shell_with_sh_env_A_New() *A_arbace_java_shell_with_sh_env_A { A_arbace_java_shell_with_sh_env_A_Init(); t := &A_arbace_java_shell_with_sh_env_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) Ctor() {}
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, env__2, forms__3 any) any { var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_10; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_java_shell_A_Init(); tmp5 = A_arbace_java_shell_A_const_11; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_16; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_11; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_java_shell_A_Init(); tmp11 = A_arbace_java_shell_A_const_13; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_java_shell_A_Init(); tmp13 = A_arbace_java_shell_A_const_14; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_java_shell_A_Init(); tmp15 = A_arbace_java_shell_A_const_9; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_java_shell_A_Init(); tmp17 = A_arbace_java_shell_A_const_10; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_java_shell_A_Init(); tmp19 = A_arbace_java_shell_A_const_11; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_java_shell_A_Init(); tmp21 = A_arbace_java_shell_A_const_17; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_java_shell_A_Init(); tmp23 = A_arbace_java_shell_A_const_11; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(env__2))))), forms__3)) }






func A_arbace_java_shell_aconcat_A_New() *A_arbace_java_shell_aconcat_A { A_arbace_java_shell_aconcat_A_Init(); t := &A_arbace_java_shell_aconcat_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) Ctor() {}
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) DoInvoke_O_O_O__O(self, type__0, xs__1 any) any { var target__3 any; var tmp1 *lang.Var;


	A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_java_shell_A_Init(); tmp5 = A_arbace_java_shell_A_const_19; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_20; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_21; target__3 = tmp2.Invoke_O_O__O(type__0, tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O_O__O(jrt.NN(tmp9).GetRawRoot__O(), xs__1))); var i__4 int64 = 0; var idx__5 int64 = 0; L1:
//line :35:1
	for { var temp__1927000414__auto____6 any = lang.RT_Nth_O_I_O__O(xs__1, lang.RT_IntCast_J__I(i__4), nil)




		if jrt.A2g_Truth(temp__1927000414__auto____6) { var a__7 any = temp__1927000414__auto____6
			jrt.System_Arraycopy_O_I_O_I_I__V(a__7, lang.RT_IntCast_J__I(0), target__3, lang.RT_IntCast_J__I(idx__5), lang.RT_Count_O__I(a__7))
			i__4, idx__5 = lang.Numbers_Inc_J__J(i__4), lang.Numbers_Add_J_J__J(idx__5, int64(lang.RT_Count_O__I(a__7))); continue L1 }
//line :35:1
		break L1 }; return target__3 }









func A_arbace_java_shell_parse_args_A_New() *A_arbace_java_shell_parse_args_A { A_arbace_java_shell_parse_args_A_Init(); t := &A_arbace_java_shell_parse_args_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Ctor() {}
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Invoke_O_O__O(self, args__0 any) any { var default_encoding__2 any = Lit_68; var default_opts__3 any; var tmp1 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_22; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_23; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp5 = A_arbace_java_shell_A_const_24; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_25; var tmp8 any = jrt.NN(tmp7).Get__O(); var tmp9 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_26; var tmp10 any = tmp9.Ref(); var tmp11 *lang.Var; A_arbace_java_shell_A_Init(); tmp11 = A_arbace_java_shell_A_const_27; default_opts__3 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, default_encoding__2, tmp4, default_encoding__2, tmp6, tmp8, tmp10, jrt.NN(tmp11).Get__O())); var vec__1651000023__4 any; var tmp12 *lang.Var;



	A_arbace_java_shell_A_Init(); tmp12 = A_arbace_java_shell_A_const_28; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_java_shell_A_Init(); tmp14 = A_arbace_java_shell_A_const_29; vec__1651000023__4 = tmp13.Invoke_O_O__O(jrt.NN(tmp14).GetRawRoot__O(), args__0); var cmd__5 any = /*line :45:1*/lang.RT_Nth_O_I_O__O(vec__1651000023__4, lang.RT_IntCast_J__I(0), nil); var opts__6 any = lang.RT_Nth_O_I_O__O(vec__1651000023__4, lang.RT_IntCast_J__I(1), nil); var tmp15 *lang.Var; A_arbace_java_shell_A_Init(); tmp15 = A_arbace_java_shell_A_const_30; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_java_shell_A_Init(); tmp17 = A_arbace_java_shell_A_const_13; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_java_shell_A_Init(); tmp19 = A_arbace_java_shell_A_const_31; return lang.Tuple_Create_O_O__IPersistentVector(cmd__5, tmp16.Invoke_O_O__O(default_opts__3, tmp18.Invoke_O_O__O(jrt.NN(tmp19).GetRawRoot__O(), opts__6))) }






func A_arbace_java_shell_as_env_strings_A_New() *A_arbace_java_shell_as_env_strings_A { A_arbace_java_shell_as_env_strings_A_Init(); t := &A_arbace_java_shell_as_env_strings_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Ctor() {}
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Invoke_O_O__O(self, arg__0 any) any {


	if lang.Util_Identical_O_O__Z(arg__0, nil) { return nil } else { var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(arg__0)) {

		var tmp2 *lang.Var; A_arbace_java_shell_A_Init(); tmp2 = A_arbace_java_shell_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.Class; A_arbace_java_shell_A_Init(); tmp4 = A_arbace_java_shell_A_const_34; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_java_shell_A_Init(); tmp6 = A_arbace_java_shell_A_const_20; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_java_shell_as_env_strings_fn__1651000028_A_New(); var tmp9 *jrt.Class; A_arbace_java_shell_as_env_strings_fn__1651000028_A_Init(); tmp9 = A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class; return tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), arg__0)) } else {
//line :55:1
			var tmp10 *jrt.Boolean; jrt.Boolean_Init(); tmp10 = jrt.Boolean_TRUE; if jrt.A2g_Truth(tmp10.Ref()) { return arg__0 } else { return nil
			} } } }
func A_arbace_java_shell_as_env_strings_fn__1651000028_A_New() *A_arbace_java_shell_as_env_strings_fn__1651000028_A { A_arbace_java_shell_as_env_strings_fn__1651000028_A_Init(); t := &A_arbace_java_shell_as_env_strings_fn__1651000028_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Ctor() {}
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Invoke_O_O__O(self, p__1651000027__1 any) any { var vec__1651000029__2 any = p__1651000027__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1651000029__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1651000029__2, lang.RT_IntCast_J__I(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_61, nil); var tmp2 *lang.Var; A_arbace_java_shell_A_Init(); tmp2 = A_arbace_java_shell_A_const_35; return lang.Compiler_AOT_StrConcat_String1_O1__String(tmp1, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(k__3), nil, v__4)).Ref() }


func A_arbace_java_shell_stream_to_bytes_A_New() *A_arbace_java_shell_stream_to_bytes_A { A_arbace_java_shell_stream_to_bytes_A_Init(); t := &A_arbace_java_shell_stream_to_bytes_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Ctor() {}
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Invoke_O_O__O(self, in__0 any) any { var bout__2 any = jrt.ByteArrayOutputStream_New(); var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	{ var tmp2 *lang.Var; A_arbace_java_shell_A_Init(); tmp2 = A_arbace_java_shell_A_const_36; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(in__0, bout__2)
		tmp1 = jrt.NN(jrt.ByteArrayOutputStream_Cast(bout__2)).ToByteArray__B1().Ref() }
//line :60:1
	return nil }();

	jrt.NN(jrt.ByteArrayOutputStream_Cast(bout__2)).Close__V(); if /*line :60:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }





func A_arbace_java_shell_stream_to_string_A_New() *A_arbace_java_shell_stream_to_string_A { A_arbace_java_shell_stream_to_string_A_Init(); t := &A_arbace_java_shell_stream_to_string_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Ctor() {}
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O_O__O(self, in__0, enc__1 any) any { var bout__3 any = jrt.StringWriter_New(); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	{ var tmp2 *lang.Var; A_arbace_java_shell_A_Init(); tmp2 = A_arbace_java_shell_A_const_36; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp4 = A_arbace_java_shell_A_const_37; tmp3.Invoke_O_O_O_O__O(in__0, bout__3, tmp4.Ref(), enc__1)
		tmp1 = jrt.NN(jrt.StringWriter_Cast(bout__3)).ToString__String().Ref() }
//line :66:1
	return nil }();


	jrt.NN(jrt.StringWriter_Cast(bout__3)).Close__V(); if /*line :66:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O__O(self, in__0 any) any {
	var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_38; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(in__0, jrt.Charset_DefaultCharset__Charset().Name__String().Ref())
}




func A_arbace_java_shell_stream_to_enc_A_New() *A_arbace_java_shell_stream_to_enc_A { A_arbace_java_shell_stream_to_enc_A_Init(); t := &A_arbace_java_shell_stream_to_enc_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Ctor() {}
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Invoke_O_O_O__O(self, stream__0, enc__1 any) any {

	var tmp1 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_39; if lang.Util_Equiv_O_O__Z(enc__1, tmp1.Ref()) {
		var tmp2 *lang.Var; A_arbace_java_shell_A_Init(); tmp2 = A_arbace_java_shell_A_const_40; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(stream__0) } else {
			var tmp3 *lang.Var; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_38; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(stream__0, enc__1)
		} }
func A_arbace_java_shell_sh_A_New() *A_arbace_java_shell_sh_A { A_arbace_java_shell_sh_A_Init(); t := &A_arbace_java_shell_sh_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_java_shell_sh_A) Ctor() {}
//line :79:1
func (t *A_arbace_java_shell_sh_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1651000037__2 any; var tmp1 *lang.Var;
































	A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_41; vec__1651000037__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(args__0); var cmd__3 any = /*line :79:1*/lang.RT_Nth_O_I_O__O(vec__1651000037__2, lang.RT_IntCast_J__I(0), nil); var opts__4 any = lang.RT_Nth_O_I_O__O(vec__1651000037__2, lang.RT_IntCast_J__I(1), nil); var proc__5 any; var tmp2 any = jrt.Runtime_GetRuntime__Runtime().Ref(); var tmp3 *jrt.Class;

































	A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_42; var tmp4 *jrt.Class = tmp3; var tmp5 *lang.Var; A_arbace_java_shell_A_Init(); tmp5 = A_arbace_java_shell_A_const_33; var tmp6 any = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(cmd__3); var tmp7 *lang.Var; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_43; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp9 = A_arbace_java_shell_A_const_26; var tmp10 any = tmp8.Invoke_O__O(jrt.NN(tmp9).Invoke_O__O(opts__4)); var tmp11 any; var target_1 any; var tmp12 *lang.Keyword;


	A_arbace_java_shell_A_Init(); tmp12 = A_arbace_java_shell_A_const_24; target_1 = jrt.NN(tmp12).Invoke_O__O(opts__4); var tmp13 bool; var tmp14 bool; tmp14 = aot_arbace_java_io.A_arbace_java_io_Coercions_A_InstanceOf(target_1); if tmp14 { tmp14 = !lang.Compiler_AOT_IsDyn_O__Z(target_1) }; tmp13 = tmp14; if tmp13 { tmp11 = aot_arbace_java_io.A_arbace_java_io_Coercions_A_Cast(target_1).As_file__O() } else { var tmp15 *lang.Var; A_arbace_java_shell_A_Init(); tmp15 = A_arbace_java_shell_A_const_44; tmp11 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(target_1) }; proc__5 = /*line :113:1*/lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp2, tmp4, Lit_70, jrt.RefArrayOf(jrt.Object_class, tmp6, tmp10, tmp11)); var map__1651000040__6 any = opts__4; var map__1651000040__7 any; if /*line :112:1*/ lang.ISeq_InstanceOf(map__1651000040__6) { var tmp16 *lang.Var; A_arbace_java_shell_A_Init(); tmp16 = A_arbace_java_shell_A_const_45; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(map__1651000040__6)) { var tmp17 *lang.Var; A_arbace_java_shell_A_Init(); tmp17 = A_arbace_java_shell_A_const_46; map__1651000040__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(map__1651000040__6), jrt.Object_class.ArrayClass())).Ref() } else { var tmp18 *lang.Var; A_arbace_java_shell_A_Init(); tmp18 = A_arbace_java_shell_A_const_9; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(map__1651000040__6)) { var tmp19 *lang.Var; A_arbace_java_shell_A_Init(); tmp19 = A_arbace_java_shell_A_const_47; map__1651000040__7 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(map__1651000040__6) } else { lang.PersistentArrayMap_Init(); map__1651000040__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1651000040__7 = map__1651000040__6 }; var in__8 any; var tmp20 /*line :79:1*/*lang.Keyword;
































	A_arbace_java_shell_A_Init(); tmp20 = A_arbace_java_shell_A_const_48; in__8 = lang.RT_Get_O_O__O(map__1651000040__7, tmp20.Ref()); var in_enc__9 any; var tmp21 /*line :79:1*/*lang.Keyword;
































	A_arbace_java_shell_A_Init(); tmp21 = A_arbace_java_shell_A_const_23; in_enc__9 = lang.RT_Get_O_O__O(map__1651000040__7, tmp21.Ref()); var out_enc__10 any; var tmp22 /*line :79:1*/*lang.Keyword;
































	A_arbace_java_shell_A_Init(); tmp22 = A_arbace_java_shell_A_const_22; out_enc__10 = lang.RT_Get_O_O__O(map__1651000040__7, tmp22.Ref()); if





	jrt.A2g_Truth(in__8) {
		var tmp23 *lang.Var; A_arbace_java_shell_A_Init(); tmp23 = A_arbace_java_shell_A_const_49; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 any = A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(proc__5, in_enc__9, in__8); var tmp26 *jrt.Class; A_arbace_java_shell_sh_fn__1651000042_A_Init(); tmp26 = A_arbace_java_shell_sh_fn__1651000042_A_fn_class; tmp24.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil)) } else {


			jrt.Process_Cast(proc__5).GetOutputStream__OutputStream().Close__V() }; var stdout__11 any = /*line :79:1*/jrt.Process_Cast(proc__5).GetInputStream__InputStream(); var tmp27 any; tmp47 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var stderr__14 any = jrt.Process_Cast(proc__5).GetErrorStream__InputStream(); tmp46 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__17 any; var tmp28 *lang.Var













































				A_arbace_java_shell_A_Init(); tmp28 = A_arbace_java_shell_A_const_49; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any = A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(stdout__11, out_enc__10); var tmp31 *jrt.Class; A_arbace_java_shell_sh_fn__1651000044_A_Init(); tmp31 = A_arbace_java_shell_sh_fn__1651000044_A_fn_class; out__17 = tmp29.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp30, tmp31, nil))
//line :79:1
				var err__18 any; var tmp32 *lang.Var














































				A_arbace_java_shell_A_Init(); tmp32 = A_arbace_java_shell_A_const_49; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any = A_arbace_java_shell_sh_fn__1651000046_A_New_O(stderr__14); var tmp35 *jrt.Class; A_arbace_java_shell_sh_fn__1651000046_A_Init(); tmp35 = A_arbace_java_shell_sh_fn__1651000046_A_fn_class; err__18 = tmp33.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp34, tmp35, nil))
//line :79:1
				var exit_code__19 int32 = jrt.Process_Cast(proc__5).WaitFor__I(); var tmp36 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp36 = A_arbace_java_shell_A_const_50; var tmp37 any = tmp36.Ref(); var tmp38 any = jrt.Integer_ValueOf_I__Integer(exit_code__19).Ref(); var tmp39 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp39 = A_arbace_java_shell_A_const_51; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Var; A_arbace_java_shell_A_Init(); tmp41 = A_arbace_java_shell_A_const_5; var tmp42 any = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(out__17); var tmp43 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp43 = A_arbace_java_shell_A_const_52; var tmp44 any = tmp43.Ref(); var tmp45 *lang.Var; A_arbace_java_shell_A_Init(); tmp45 = A_arbace_java_shell_A_const_5; tmp27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp38, tmp40, tmp42, tmp44, lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(err__18))) }; return nil }()











































				jrt.InputStream_Cast(stderr__14).Close__V()
//line :79:1
				if tmp46 != nil { panic(tmp46) } }; return nil }();











































	jrt.InputStream_Cast(stdout__11).Close__V(); if /*line :79:1*/ tmp47 != nil { panic(tmp47) }; return tmp27 }







































func A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_java_shell_sh_fn__1651000042_A { A_arbace_java_shell_sh_fn__1651000042_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Ctor_O_O_O(c__proc, c__in_enc, c__in any) { t.F_proc = c__proc; t.F_in_enc = c__in_enc; t.F_in = c__in }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Invoke_O__O(self any) any { var os__1 any; var tmp1 any; var t_ any = t.F_proc;
										t.F_proc = nil; tmp1 = t_; os__1 = jrt.Process_Cast(tmp1).GetOutputStream__OutputStream(); var tmp2 any; tmp10 := /*line :119:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp3 *lang.Var; A_arbace_java_shell_A_Init(); tmp3 = A_arbace_java_shell_A_const_36; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_in; t.F_in = nil; tmp5 = t__2; var tmp6 any = tmp5; var tmp7 *lang.Keyword; A_arbace_java_shell_A_Init(); tmp7 = A_arbace_java_shell_A_const_37; var tmp8 any = tmp7.Ref(); var tmp9 any; var t__3 any = t.F_in_enc; t.F_in_enc = nil; tmp9 = t__3; tmp2 = tmp4.Invoke_O_O_O_O__O(tmp6, os__1, tmp8, tmp9) }
//line :119:1
		return nil }();
	jrt.OutputStream_Cast(os__1).Close__V(); if /*line :119:1*/ tmp10 != nil { panic(tmp10) }; return tmp2 }





func A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(p0, p1 any) *A_arbace_java_shell_sh_fn__1651000044_A { A_arbace_java_shell_sh_fn__1651000044_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Ctor_O_O(c__stdout, c__out_enc any) { t.F_stdout = c__stdout; t.F_out_enc = c__out_enc }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_53; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_stdout; t.F_stdout = nil; tmp3 = t_; var tmp4 any = tmp3; var tmp5 any; var t__2 any = t.F_out_enc; t.F_out_enc = nil; tmp5 = t__2; return tmp2.Invoke_O_O__O(tmp4, tmp5) }
func A_arbace_java_shell_sh_fn__1651000046_A_New_O(p0 any) *A_arbace_java_shell_sh_fn__1651000046_A { A_arbace_java_shell_sh_fn__1651000046_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000046_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Ctor_O(c__stderr any) { t.F_stderr = c__stderr }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_java_shell_A_Init(); tmp1 = A_arbace_java_shell_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var t_ any = t.F_stderr; t.F_stderr = nil; tmp3 = t_; return tmp2.Invoke_O__O(tmp3) }












type A_arbace_java_shell_A struct{ jrt.Object }

var A_arbace_java_shell_A_const_0 *lang.Var

var A_arbace_java_shell_A_const_1 *lang.Var

var A_arbace_java_shell_A_const_2 any

var A_arbace_java_shell_A_const_3 any

var A_arbace_java_shell_A_const_4 *lang.Var

var A_arbace_java_shell_A_const_5 *lang.Var

var A_arbace_java_shell_A_const_6 *lang.Var

var A_arbace_java_shell_A_const_7 any

var A_arbace_java_shell_A_const_8 *lang.Var

var A_arbace_java_shell_A_const_9 *lang.Var

var A_arbace_java_shell_A_const_10 *lang.Var

var A_arbace_java_shell_A_const_11 *lang.Var

var A_arbace_java_shell_A_const_12 any

var A_arbace_java_shell_A_const_13 *lang.Var

var A_arbace_java_shell_A_const_14 *lang.Var

var A_arbace_java_shell_A_const_15 any

var A_arbace_java_shell_A_const_16 any

var A_arbace_java_shell_A_const_17 any

var A_arbace_java_shell_A_const_18 *lang.Var

var A_arbace_java_shell_A_const_19 *lang.Var

var A_arbace_java_shell_A_const_20 *lang.Var

var A_arbace_java_shell_A_const_21 *lang.Var

var A_arbace_java_shell_A_const_22 *lang.Keyword

var A_arbace_java_shell_A_const_23 *lang.Keyword

var A_arbace_java_shell_A_const_24 *lang.Keyword

var A_arbace_java_shell_A_const_25 *lang.Var

var A_arbace_java_shell_A_const_26 *lang.Keyword

var A_arbace_java_shell_A_const_27 *lang.Var

var A_arbace_java_shell_A_const_28 *lang.Var

var A_arbace_java_shell_A_const_29 *lang.Var

var A_arbace_java_shell_A_const_30 *lang.Var

var A_arbace_java_shell_A_const_31 *lang.Var

var A_arbace_java_shell_A_const_32 *lang.Var

var A_arbace_java_shell_A_const_33 *lang.Var

var A_arbace_java_shell_A_const_34 *jrt.Class

var A_arbace_java_shell_A_const_35 *lang.Var

var A_arbace_java_shell_A_const_36 *lang.Var

var A_arbace_java_shell_A_const_37 *lang.Keyword

var A_arbace_java_shell_A_const_38 *lang.Var

var A_arbace_java_shell_A_const_39 *lang.Keyword

var A_arbace_java_shell_A_const_40 *lang.Var

var A_arbace_java_shell_A_const_41 *lang.Var

var A_arbace_java_shell_A_const_42 *jrt.Class

var A_arbace_java_shell_A_const_43 *lang.Var

var A_arbace_java_shell_A_const_44 *lang.Var

var A_arbace_java_shell_A_const_45 *lang.Var

var A_arbace_java_shell_A_const_46 *lang.Var

var A_arbace_java_shell_A_const_47 *lang.Var

var A_arbace_java_shell_A_const_48 *lang.Keyword

var A_arbace_java_shell_A_const_49 *lang.Var

var A_arbace_java_shell_A_const_50 *lang.Keyword

var A_arbace_java_shell_A_const_51 *lang.Keyword

var A_arbace_java_shell_A_const_52 *lang.Keyword

var A_arbace_java_shell_A_const_53 *lang.Var

var A_arbace_java_shell_A_init jrt.ClassInit

func A_arbace_java_shell_A_Init() { if !A_arbace_java_shell_A_init.Done() { A_arbace_java_shell_A_init.Run(A_arbace_java_shell_A_clinit) } }

func A_arbace_java_shell_A_clinit() { A_arbace_java_shell_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_java_shell_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_java_shell_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_java_shell_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_7).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), jrt.Integer_ValueOf_I__Integer(31).Ref())))); A_arbace_java_shell_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_java_shell_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_java_shell_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_java_shell_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_13).Ref(), Lit_14, lang.RT_Keyword_String_String__Keyword(nil, Lit_15).Ref(), Lit_16))); A_arbace_java_shell_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_java_shell_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_java_shell_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_java_shell_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_java_shell_A_const_12 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_21).Ref(); A_arbace_java_shell_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_java_shell_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_java_shell_A_const_15 = lang.Symbol_Intern_String_String__Symbol(Lit_12, Lit_24).Ref(); A_arbace_java_shell_A_const_16 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_21).Ref(); A_arbace_java_shell_A_const_17 = lang.Symbol_Intern_String_String__Symbol(Lit_12, Lit_25).Ref(); A_arbace_java_shell_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_java_shell_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_java_shell_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_java_shell_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_java_shell_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_30); A_arbace_java_shell_A_const_23 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_java_shell_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_java_shell_A_const_25 = lang.RT_Var_String_String__Var(Lit_12, Lit_24); A_arbace_java_shell_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_java_shell_A_const_27 = lang.RT_Var_String_String__Var(Lit_12, Lit_25); A_arbace_java_shell_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_java_shell_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_java_shell_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_java_shell_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_java_shell_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_java_shell_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_java_shell_A_const_34 = lang.RT_ClassForNameNonLoading_String__Class(Lit_40); A_arbace_java_shell_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_java_shell_A_const_36 = lang.RT_Var_String_String__Var(Lit_3, Lit_6); A_arbace_java_shell_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_java_shell_A_const_38 = lang.RT_Var_String_String__Var(Lit_12, Lit_43); A_arbace_java_shell_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_java_shell_A_const_40 = lang.RT_Var_String_String__Var(Lit_12, Lit_45); A_arbace_java_shell_A_const_41 = lang.RT_Var_String_String__Var(Lit_12, Lit_46); A_arbace_java_shell_A_const_42 = lang.RT_ClassForNameNonLoading_String__Class(Lit_47); A_arbace_java_shell_A_const_43 = lang.RT_Var_String_String__Var(Lit_12, Lit_48); A_arbace_java_shell_A_const_44 = lang.RT_Var_String_String__Var(Lit_3, Lit_5); A_arbace_java_shell_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_49); A_arbace_java_shell_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_java_shell_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_java_shell_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_java_shell_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_java_shell_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_java_shell_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_java_shell_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_java_shell_A_const_53 = lang.RT_Var_String_String__Var(Lit_12, Lit_57) }

func A_arbace_java_shell_A_New() *A_arbace_java_shell_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_A) Ctor() {}

func (t *A_arbace_java_shell_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_A_class }

func (t *A_arbace_java_shell_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_A); return ok }

func A_arbace_java_shell_A_Cast(x any) *A_arbace_java_shell_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_A_class)) }; return v }



type A_arbace_java_shell_aconcat_A struct{ jrt.Object }

func (t *A_arbace_java_shell_aconcat_A) Is_Compiler_AOTR1() {}

var A_arbace_java_shell_aconcat_A_fn_class *jrt.Class

var A_arbace_java_shell_aconcat_A_init jrt.ClassInit

func A_arbace_java_shell_aconcat_A_Init() { if !A_arbace_java_shell_aconcat_A_init.Done() { A_arbace_java_shell_aconcat_A_init.Run(A_arbace_java_shell_aconcat_A_clinit) } }

func A_arbace_java_shell_aconcat_A_clinit() { A_arbace_java_shell_aconcat_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_shell_aconcat_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_aconcat_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_aconcat_A_class }

func (t *A_arbace_java_shell_aconcat_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_aconcat_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_aconcat_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_aconcat_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_aconcat_A); return ok }

func A_arbace_java_shell_aconcat_A_Cast(x any) *A_arbace_java_shell_aconcat_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_aconcat_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_aconcat_A_class)) }; return v }



type A_arbace_java_shell_as_env_strings_A struct{ jrt.Object }

func (t *A_arbace_java_shell_as_env_strings_A) Is_Compiler_AOTF1() {}

var A_arbace_java_shell_as_env_strings_A_fn_class *jrt.Class

var A_arbace_java_shell_as_env_strings_A_init jrt.ClassInit

func A_arbace_java_shell_as_env_strings_A_Init() { if !A_arbace_java_shell_as_env_strings_A_init.Done() { A_arbace_java_shell_as_env_strings_A_init.Run(A_arbace_java_shell_as_env_strings_A_clinit) } }

func A_arbace_java_shell_as_env_strings_A_clinit() { A_arbace_java_shell_as_env_strings_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_as_env_strings_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_as_env_strings_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_as_env_strings_A_class }

func (t *A_arbace_java_shell_as_env_strings_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_as_env_strings_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_as_env_strings_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_as_env_strings_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_as_env_strings_A); return ok }

func A_arbace_java_shell_as_env_strings_A_Cast(x any) *A_arbace_java_shell_as_env_strings_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_as_env_strings_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_as_env_strings_A_class)) }; return v }



type A_arbace_java_shell_as_env_strings_fn__1651000028_A struct{ jrt.Object }

func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Is_Compiler_AOTF1() {}

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class *jrt.Class

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_init jrt.ClassInit

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_Init() { if !A_arbace_java_shell_as_env_strings_fn__1651000028_A_init.Done() { A_arbace_java_shell_as_env_strings_fn__1651000028_A_init.Run(A_arbace_java_shell_as_env_strings_fn__1651000028_A_clinit) } }

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_clinit() { A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_as_env_strings_fn__1651000028_A_class }

func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_as_env_strings_fn__1651000028_A); return ok }

func A_arbace_java_shell_as_env_strings_fn__1651000028_A_Cast(x any) *A_arbace_java_shell_as_env_strings_fn__1651000028_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_as_env_strings_fn__1651000028_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_as_env_strings_fn__1651000028_A_class)) }; return v }



type A_arbace_java_shell_eval1651000004_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000004_A_New() *A_arbace_java_shell_eval1651000004_A { t := &A_arbace_java_shell_eval1651000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000004_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000004_A_class }

func (t *A_arbace_java_shell_eval1651000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000004_A); return ok }

func A_arbace_java_shell_eval1651000004_A_Cast(x any) *A_arbace_java_shell_eval1651000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000004_A_class)) }; return v }



type A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A struct{ jrt.Object }

func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Is_Compiler_AOTF0() {}

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_fn_class *jrt.Class

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_init jrt.ClassInit

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_Init() { if !A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_init.Done() { A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_init.Run(A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_clinit) } }

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_clinit() { A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class }

func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A); return ok }

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_Cast(x any) *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_class)) }; return v }



type A_arbace_java_shell_eval1651000008_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000008_A_New() *A_arbace_java_shell_eval1651000008_A { t := &A_arbace_java_shell_eval1651000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000008_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000008_A_class }

func (t *A_arbace_java_shell_eval1651000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000008_A); return ok }

func A_arbace_java_shell_eval1651000008_A_Cast(x any) *A_arbace_java_shell_eval1651000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000008_A_class)) }; return v }



type A_arbace_java_shell_eval1651000008_fn__1651000009_A struct{ jrt.Object }

func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Is_Compiler_AOTF0() {}

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_fn_class *jrt.Class

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_init jrt.ClassInit

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_Init() { if !A_arbace_java_shell_eval1651000008_fn__1651000009_A_init.Done() { A_arbace_java_shell_eval1651000008_fn__1651000009_A_init.Run(A_arbace_java_shell_eval1651000008_fn__1651000009_A_clinit) } }

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_clinit() { A_arbace_java_shell_eval1651000008_fn__1651000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000008_fn__1651000009_A_class }

func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000008_fn__1651000009_A); return ok }

func A_arbace_java_shell_eval1651000008_fn__1651000009_A_Cast(x any) *A_arbace_java_shell_eval1651000008_fn__1651000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000008_fn__1651000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000008_fn__1651000009_A_class)) }; return v }



type A_arbace_java_shell_parse_args_A struct{ jrt.Object }

func (t *A_arbace_java_shell_parse_args_A) Is_Compiler_AOTF1() {}

var A_arbace_java_shell_parse_args_A_fn_class *jrt.Class

var A_arbace_java_shell_parse_args_A_init jrt.ClassInit

func A_arbace_java_shell_parse_args_A_Init() { if !A_arbace_java_shell_parse_args_A_init.Done() { A_arbace_java_shell_parse_args_A_init.Run(A_arbace_java_shell_parse_args_A_clinit) } }

func A_arbace_java_shell_parse_args_A_clinit() { A_arbace_java_shell_parse_args_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_parse_args_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_parse_args_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_parse_args_A_class }

func (t *A_arbace_java_shell_parse_args_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_parse_args_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_parse_args_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_parse_args_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_parse_args_A); return ok }

func A_arbace_java_shell_parse_args_A_Cast(x any) *A_arbace_java_shell_parse_args_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_parse_args_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_parse_args_A_class)) }; return v }



type A_arbace_java_shell_sh_A struct{ jrt.Object }

func (t *A_arbace_java_shell_sh_A) Is_Compiler_AOTR0() {}

var A_arbace_java_shell_sh_A_fn_class *jrt.Class

var A_arbace_java_shell_sh_A_init jrt.ClassInit

func A_arbace_java_shell_sh_A_Init() { if !A_arbace_java_shell_sh_A_init.Done() { A_arbace_java_shell_sh_A_init.Run(A_arbace_java_shell_sh_A_clinit) } }

func A_arbace_java_shell_sh_A_clinit() { A_arbace_java_shell_sh_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_shell_sh_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_sh_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_sh_A_class }

func (t *A_arbace_java_shell_sh_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_sh_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_sh_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_sh_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_sh_A); return ok }

func A_arbace_java_shell_sh_A_Cast(x any) *A_arbace_java_shell_sh_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_sh_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_sh_A_class)) }; return v }



type A_arbace_java_shell_sh_fn__1651000042_A struct{ jrt.Object; F_proc, F_in_enc, F_in any }

func (t *A_arbace_java_shell_sh_fn__1651000042_A) Is_Compiler_AOTF0() {}

var A_arbace_java_shell_sh_fn__1651000042_A_fn_class *jrt.Class

var A_arbace_java_shell_sh_fn__1651000042_A_init jrt.ClassInit

func A_arbace_java_shell_sh_fn__1651000042_A_Init() { if !A_arbace_java_shell_sh_fn__1651000042_A_init.Done() { A_arbace_java_shell_sh_fn__1651000042_A_init.Run(A_arbace_java_shell_sh_fn__1651000042_A_clinit) } }

func A_arbace_java_shell_sh_fn__1651000042_A_clinit() { A_arbace_java_shell_sh_fn__1651000042_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_sh_fn__1651000042_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_sh_fn__1651000042_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_sh_fn__1651000042_A_class }

func (t *A_arbace_java_shell_sh_fn__1651000042_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_sh_fn__1651000042_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_sh_fn__1651000042_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_sh_fn__1651000042_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_sh_fn__1651000042_A); return ok }

func A_arbace_java_shell_sh_fn__1651000042_A_Cast(x any) *A_arbace_java_shell_sh_fn__1651000042_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_sh_fn__1651000042_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_sh_fn__1651000042_A_class)) }; return v }



type A_arbace_java_shell_sh_fn__1651000044_A struct{ jrt.Object; F_stdout, F_out_enc any }

func (t *A_arbace_java_shell_sh_fn__1651000044_A) Is_Compiler_AOTF0() {}

var A_arbace_java_shell_sh_fn__1651000044_A_fn_class *jrt.Class

var A_arbace_java_shell_sh_fn__1651000044_A_init jrt.ClassInit

func A_arbace_java_shell_sh_fn__1651000044_A_Init() { if !A_arbace_java_shell_sh_fn__1651000044_A_init.Done() { A_arbace_java_shell_sh_fn__1651000044_A_init.Run(A_arbace_java_shell_sh_fn__1651000044_A_clinit) } }

func A_arbace_java_shell_sh_fn__1651000044_A_clinit() { A_arbace_java_shell_sh_fn__1651000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_sh_fn__1651000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_sh_fn__1651000044_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_sh_fn__1651000044_A_class }

func (t *A_arbace_java_shell_sh_fn__1651000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_sh_fn__1651000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_sh_fn__1651000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_sh_fn__1651000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_sh_fn__1651000044_A); return ok }

func A_arbace_java_shell_sh_fn__1651000044_A_Cast(x any) *A_arbace_java_shell_sh_fn__1651000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_sh_fn__1651000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_sh_fn__1651000044_A_class)) }; return v }



type A_arbace_java_shell_sh_fn__1651000046_A struct{ jrt.Object; F_stderr any }

func (t *A_arbace_java_shell_sh_fn__1651000046_A) Is_Compiler_AOTF0() {}

var A_arbace_java_shell_sh_fn__1651000046_A_fn_class *jrt.Class

var A_arbace_java_shell_sh_fn__1651000046_A_init jrt.ClassInit

func A_arbace_java_shell_sh_fn__1651000046_A_Init() { if !A_arbace_java_shell_sh_fn__1651000046_A_init.Done() { A_arbace_java_shell_sh_fn__1651000046_A_init.Run(A_arbace_java_shell_sh_fn__1651000046_A_clinit) } }

func A_arbace_java_shell_sh_fn__1651000046_A_clinit() { A_arbace_java_shell_sh_fn__1651000046_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_sh_fn__1651000046_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_sh_fn__1651000046_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_sh_fn__1651000046_A_class }

func (t *A_arbace_java_shell_sh_fn__1651000046_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_sh_fn__1651000046_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_sh_fn__1651000046_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_sh_fn__1651000046_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_sh_fn__1651000046_A); return ok }

func A_arbace_java_shell_sh_fn__1651000046_A_Cast(x any) *A_arbace_java_shell_sh_fn__1651000046_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_sh_fn__1651000046_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_sh_fn__1651000046_A_class)) }; return v }



type A_arbace_java_shell_stream_to_bytes_A struct{ jrt.Object }

func (t *A_arbace_java_shell_stream_to_bytes_A) Is_Compiler_AOTF1() {}

var A_arbace_java_shell_stream_to_bytes_A_fn_class *jrt.Class

var A_arbace_java_shell_stream_to_bytes_A_init jrt.ClassInit

func A_arbace_java_shell_stream_to_bytes_A_Init() { if !A_arbace_java_shell_stream_to_bytes_A_init.Done() { A_arbace_java_shell_stream_to_bytes_A_init.Run(A_arbace_java_shell_stream_to_bytes_A_clinit) } }

func A_arbace_java_shell_stream_to_bytes_A_clinit() { A_arbace_java_shell_stream_to_bytes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_stream_to_bytes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_stream_to_bytes_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_stream_to_bytes_A_class }

func (t *A_arbace_java_shell_stream_to_bytes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_stream_to_bytes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_stream_to_bytes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_stream_to_bytes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_stream_to_bytes_A); return ok }

func A_arbace_java_shell_stream_to_bytes_A_Cast(x any) *A_arbace_java_shell_stream_to_bytes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_stream_to_bytes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_stream_to_bytes_A_class)) }; return v }



type A_arbace_java_shell_stream_to_enc_A struct{ jrt.Object }

func (t *A_arbace_java_shell_stream_to_enc_A) Is_Compiler_AOTF2() {}

var A_arbace_java_shell_stream_to_enc_A_fn_class *jrt.Class

var A_arbace_java_shell_stream_to_enc_A_init jrt.ClassInit

func A_arbace_java_shell_stream_to_enc_A_Init() { if !A_arbace_java_shell_stream_to_enc_A_init.Done() { A_arbace_java_shell_stream_to_enc_A_init.Run(A_arbace_java_shell_stream_to_enc_A_clinit) } }

func A_arbace_java_shell_stream_to_enc_A_clinit() { A_arbace_java_shell_stream_to_enc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_stream_to_enc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_stream_to_enc_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_stream_to_enc_A_class }

func (t *A_arbace_java_shell_stream_to_enc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_stream_to_enc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_stream_to_enc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_stream_to_enc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_stream_to_enc_A); return ok }

func A_arbace_java_shell_stream_to_enc_A_Cast(x any) *A_arbace_java_shell_stream_to_enc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_stream_to_enc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_stream_to_enc_A_class)) }; return v }



type A_arbace_java_shell_stream_to_string_A struct{ jrt.Object }

func (t *A_arbace_java_shell_stream_to_string_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_java_shell_stream_to_string_A) Is_Compiler_AOTF1() {}

var A_arbace_java_shell_stream_to_string_A_fn_class *jrt.Class

var A_arbace_java_shell_stream_to_string_A_init jrt.ClassInit

func A_arbace_java_shell_stream_to_string_A_Init() { if !A_arbace_java_shell_stream_to_string_A_init.Done() { A_arbace_java_shell_stream_to_string_A_init.Run(A_arbace_java_shell_stream_to_string_A_clinit) } }

func A_arbace_java_shell_stream_to_string_A_clinit() { A_arbace_java_shell_stream_to_string_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_76, lang.Compiler_AOTFn_class) }

func (t *A_arbace_java_shell_stream_to_string_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_stream_to_string_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_stream_to_string_A_class }

func (t *A_arbace_java_shell_stream_to_string_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_stream_to_string_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_stream_to_string_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_stream_to_string_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_stream_to_string_A); return ok }

func A_arbace_java_shell_stream_to_string_A_Cast(x any) *A_arbace_java_shell_stream_to_string_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_stream_to_string_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_stream_to_string_A_class)) }; return v }



type A_arbace_java_shell_with_sh_dir_A struct{ jrt.Object }

func (t *A_arbace_java_shell_with_sh_dir_A) Is_Compiler_AOTR3() {}

var A_arbace_java_shell_with_sh_dir_A_fn_class *jrt.Class

var A_arbace_java_shell_with_sh_dir_A_init jrt.ClassInit

func A_arbace_java_shell_with_sh_dir_A_Init() { if !A_arbace_java_shell_with_sh_dir_A_init.Done() { A_arbace_java_shell_with_sh_dir_A_init.Run(A_arbace_java_shell_with_sh_dir_A_clinit) } }

func A_arbace_java_shell_with_sh_dir_A_clinit() { A_arbace_java_shell_with_sh_dir_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_shell_with_sh_dir_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_with_sh_dir_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_with_sh_dir_A_class }

func (t *A_arbace_java_shell_with_sh_dir_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_with_sh_dir_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_with_sh_dir_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_with_sh_dir_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_with_sh_dir_A); return ok }

func A_arbace_java_shell_with_sh_dir_A_Cast(x any) *A_arbace_java_shell_with_sh_dir_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_with_sh_dir_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_with_sh_dir_A_class)) }; return v }



type A_arbace_java_shell_with_sh_env_A struct{ jrt.Object }

func (t *A_arbace_java_shell_with_sh_env_A) Is_Compiler_AOTR3() {}

var A_arbace_java_shell_with_sh_env_A_fn_class *jrt.Class

var A_arbace_java_shell_with_sh_env_A_init jrt.ClassInit

func A_arbace_java_shell_with_sh_env_A_Init() { if !A_arbace_java_shell_with_sh_env_A_init.Done() { A_arbace_java_shell_with_sh_env_A_init.Run(A_arbace_java_shell_with_sh_env_A_clinit) } }

func A_arbace_java_shell_with_sh_env_A_clinit() { A_arbace_java_shell_with_sh_env_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_java_shell_with_sh_env_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_with_sh_env_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_with_sh_env_A_class }

func (t *A_arbace_java_shell_with_sh_env_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_with_sh_env_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_java_shell_with_sh_env_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_with_sh_env_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_with_sh_env_A); return ok }

func A_arbace_java_shell_with_sh_env_A_Cast(x any) *A_arbace_java_shell_with_sh_env_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_with_sh_env_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_with_sh_env_A_class)) }; return v }
