//line aot_arbace_java_shell.ae:1
package aot_arbace_java_shell

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)
func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_New() *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_shell_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_1); lang.IFn_Cast(A_arbace_java_shell_A_const_2.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_3); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_3)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_4)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_java_shell_eval1651000008_fn__1651000009_A_New() *A_arbace_java_shell_eval1651000008_fn__1651000009_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_eval1651000008_fn__1651000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_4.GetRawRoot__O()); var tmp2 any; var root_15 any = A_arbace_java_shell_A_const_5.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_17 lang.IFn; if linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_java_shell_A_const_6; if linked_16 == nil { tmp2 = ifn_17.Invoke_O__O(arg_18) } else { tmp2 = linked_16.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_15, arg_18) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_java_shell_A_const_7.GetRawRoot__O(), A_arbace_java_shell_A_const_8) }











func A_arbace_java_shell_with_sh_dir_A_New() *A_arbace_java_shell_with_sh_dir_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_with_sh_dir_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) Ctor() {}
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, dir__2, forms__3 any) any { var root_19 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_12); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()); var tmp4 any; var root_29 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_30 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_29, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_31 lang.IFn; if linked_30 == nil { ifn_31 = lang.IFn_Cast(root_29) } else { ifn_31 = nil }; var arg_32 any = A_arbace_java_shell_A_const_14.GetRawRoot__O(); var arg_33 any; var root_34 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_35 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_34, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_36 lang.IFn; if linked_35 == nil { ifn_36 = lang.IFn_Cast(root_34) } else { ifn_36 = nil }; var arg_37 any; var root_38 any = A_arbace_java_shell_A_const_10.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_38, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_40 lang.IFn; if linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_15); var arg_42 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(dir__2); if linked_39 == nil { arg_37 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { arg_37 = linked_39.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; if linked_35 == nil { arg_33 = ifn_36.Invoke_O__O(arg_37) } else { arg_33 = linked_35.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_34, arg_37) }; if linked_30 == nil { tmp4 = ifn_31.Invoke_O_O__O(arg_32, arg_33) } else { tmp4 = linked_30.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_29, arg_32, arg_33) }; arg_22 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), forms__3); if linked_20 == nil { return ifn_21.Invoke_O__O(arg_22) } else { return linked_20.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_19, arg_22) } }






func A_arbace_java_shell_with_sh_env_A_New() *A_arbace_java_shell_with_sh_env_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_with_sh_env_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) Ctor() {}
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, env__2, forms__3 any) any { var root_43 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_16); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()); var tmp4 any; var root_53 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = A_arbace_java_shell_A_const_14.GetRawRoot__O(); var arg_57 any; var root_58 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_60 lang.IFn; if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any; var root_62 any = A_arbace_java_shell_A_const_10.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_64 lang.IFn; if linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_17); var arg_66 any = lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(env__2); if linked_63 == nil { arg_61 = ifn_64.Invoke_O_O__O(arg_65, arg_66) } else { arg_61 = linked_63.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_62, arg_65, arg_66) }; if linked_59 == nil { arg_57 = ifn_60.Invoke_O__O(arg_61) } else { arg_57 = linked_59.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_58, arg_61) }; if linked_54 == nil { tmp4 = ifn_55.Invoke_O_O__O(arg_56, arg_57) } else { tmp4 = linked_54.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_53, arg_56, arg_57) }; arg_46 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), forms__3); if linked_44 == nil { return ifn_45.Invoke_O__O(arg_46) } else { return linked_44.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_43, arg_46) } }






func A_arbace_java_shell_aconcat_A_New() *A_arbace_java_shell_aconcat_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_aconcat_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) Ctor() {}
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) DoInvoke_O_O_O__O(self, type__0, xs__1 any) any { var target__3 any; var root_67 any = A_arbace_java_shell_A_const_18.GetRawRoot__O(); var linked_68 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_67, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_69 lang.IFn; if


	linked_68 == nil { ifn_69 = lang.IFn_Cast(root_67) } else { ifn_69 = nil }; var arg_70 any = type__0; var arg_71 any; var root_72 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_73 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_72, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_74 lang.IFn; if linked_73 == nil { ifn_74 = lang.IFn_Cast(root_72) } else { ifn_74 = nil }; var arg_75 any = A_arbace_java_shell_A_const_19.GetRawRoot__O(); var arg_76 any; var root_77 any = A_arbace_java_shell_A_const_20.GetRawRoot__O(); var linked_78 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_77, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_79 lang.IFn; if linked_78 == nil { ifn_79 = lang.IFn_Cast(root_77) } else { ifn_79 = nil }; var arg_80 any = A_arbace_java_shell_A_const_21.GetRawRoot__O(); var arg_81 any = xs__1; if linked_78 == nil { arg_76 = ifn_79.Invoke_O_O__O(arg_80, arg_81) } else { arg_76 = linked_78.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_77, arg_80, arg_81) }; if linked_73 == nil { arg_71 = ifn_74.Invoke_O_O__O(arg_75, arg_76) } else { arg_71 = linked_73.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_72, arg_75, arg_76) }; if linked_68 == nil { target__3 = ifn_69.Invoke_O_O__O(arg_70, arg_71) } else { target__3 = linked_68.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_67, arg_70, arg_71) }; var i__4 int64 = 0; var idx__5 int64 = 0; L1:
//line :35:1
	for { var temp__1927000414__auto____6 any = lang.RT_Nth_O_I_O__O_NoInit(xs__1, lang.RT_IntCast_J__I_NoInit(i__4), nil)




		if jrt.J2g_Truth(temp__1927000414__auto____6) { var a__7 any = temp__1927000414__auto____6
			jrt.System_Arraycopy_O_I_O_I_I__V(a__7, lang.RT_IntCast_J__I_NoInit(0), target__3, lang.RT_IntCast_J__I_NoInit(idx__5), lang.RT_Count_O__I_NoInit(a__7))
			i__4, idx__5 = lang.Numbers_Inc_J__J_NoInit(i__4), lang.Numbers_Add_J_J__J_NoInit(idx__5, int64(lang.RT_Count_O__I_NoInit(a__7))); continue L1 }
//line :35:1
		break L1 }; return target__3 }









func A_arbace_java_shell_parse_args_A_New() *A_arbace_java_shell_parse_args_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_parse_args_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Ctor() {}
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Invoke_O_O__O(self, args__0 any) any { var default_encoding__2 any = Lit_6; var tmp1 any = A_arbace_java_shell_A_const_22; var tmp2 any = A_arbace_java_shell_A_const_23; var tmp3 any = A_arbace_java_shell_A_const_24; var tmp4 any = A_arbace_java_shell_A_const_25.Get__O(); var tmp5 any = A_arbace_java_shell_A_const_26; var default_opts__3 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, default_encoding__2, tmp2, default_encoding__2, tmp3, tmp4, tmp5, A_arbace_java_shell_A_const_27.Get__O())); var vec__1651000023__4 any; var root_82 any = A_arbace_java_shell_A_const_28.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_84 lang.IFn; if



	linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = A_arbace_java_shell_A_const_29.GetRawRoot__O(); var arg_86 any = args__0; if linked_83 == nil { vec__1651000023__4 = ifn_84.Invoke_O_O__O(arg_85, arg_86) } else { vec__1651000023__4 = linked_83.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_82, arg_85, arg_86) }; var cmd__5 any = /*line :45:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1651000023__4, lang.RT_IntCast_J__I_NoInit(0), nil); var opts__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000023__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_87 any = A_arbace_java_shell_A_const_30.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_89 lang.IFn; if




	linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = default_opts__3; var arg_91 any; var root_92 any = A_arbace_java_shell_A_const_13.GetRawRoot__O(); var linked_93 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_92, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_94 lang.IFn; if linked_93 == nil { ifn_94 = lang.IFn_Cast(root_92) } else { ifn_94 = nil }; var arg_95 any = A_arbace_java_shell_A_const_31.GetRawRoot__O(); var arg_96 any = opts__6; if linked_93 == nil { arg_91 = ifn_94.Invoke_O_O__O(arg_95, arg_96) } else { arg_91 = linked_93.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_92, arg_95, arg_96) }; if linked_88 == nil { tmp6 = ifn_89.Invoke_O_O__O(arg_90, arg_91) } else { tmp6 = linked_88.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_87, arg_90, arg_91) }; return /*line :45:1*/ lang.Tuple_Create_O_O__IPersistentVector(cmd__5, tmp6) }






func A_arbace_java_shell_as_env_strings_A_New() *A_arbace_java_shell_as_env_strings_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_as_env_strings_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Ctor() {}
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Invoke_O_O__O(self, arg__0 any) any {


	if lang.Util_Identical_O_O__Z_NoInit(arg__0, nil) { return nil } else { var tmp1 any; var root_97 any = A_arbace_java_shell_A_const_32.GetRawRoot__O(); var linked_98 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_97, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_99 lang.IFn

		if linked_98 == nil { ifn_99 = lang.IFn_Cast(root_97) } else { ifn_99 = nil }; var arg_100 any = arg__0; if linked_98 == nil { tmp1 = ifn_99.Invoke_O__O(arg_100) } else { tmp1 = linked_98.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_97, arg_100) }
//line :55:1
		if jrt.J2g_Truth(tmp1) {

			var root_101 any = A_arbace_java_shell_A_const_33.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = A_arbace_java_shell_A_const_34; var arg_105 any; var root_106 any = A_arbace_java_shell_A_const_20.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var fnbody__116 any = A_arbace_java_shell_as_env_strings_fn__1651000028_A_New(); var tmp2 *jrt.Class; var fncls__115 *jrt.Class = A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class; if fncls__115 == nil { var fncls__115d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_1, false, nil); A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class = fncls__115d; tmp2 = fncls__115d } else { tmp2 = fncls__115 }; arg_109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__116, tmp2, nil); var arg_110 any = arg__0; if linked_107 == nil { arg_105 = ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { arg_105 = linked_107.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_106, arg_109, arg_110) }; if linked_102 == nil { return ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { return linked_102.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_101, arg_104, arg_105) } } else {
//line :55:1
				if jrt.J2g_Truth(jrt.Boolean_TRUE.Ref()) { return arg__0 } else { return nil
				} } } }
func A_arbace_java_shell_as_env_strings_fn__1651000028_A_New() *A_arbace_java_shell_as_env_strings_fn__1651000028_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_as_env_strings_fn__1651000028_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Ctor() {}
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Invoke_O_O__O(self, p__1651000027__1 any) any { var vec__1651000029__2 any = p__1651000027__1; var k__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000029__2, lang.RT_IntCast_J__I_NoInit(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000029__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil); var tmp2 any; var root_111 any = A_arbace_java_shell_A_const_35.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any = k__3; if linked_112 == nil { tmp2 = ifn_113.Invoke_O__O(arg_114) } else { tmp2 = linked_112.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_111, arg_114) }; return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp2, nil, v__4)).Ref() }


func A_arbace_java_shell_stream_to_bytes_A_New() *A_arbace_java_shell_stream_to_bytes_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_bytes_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Ctor() {}
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Invoke_O_O__O(self, in__0 any) any { var bout__2 any = jrt.ByteArrayOutputStream_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()).Invoke_O_O__O(in__0, bout__2)
	tmp1 = jrt.ByteArrayOutputStream_Cast(bout__2).ToByteArray__B1().Ref()
//line :60:1
	return nil }();

	jrt.ByteArrayOutputStream_Cast(bout__2).Close__V(); if /*line :60:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_java_shell_stream_to_string_A_New() *A_arbace_java_shell_stream_to_string_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_string_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Ctor() {}
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O_O__O(self, in__0, enc__1 any) any { var bout__3 any = jrt.StringWriter_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()).Invoke_O_O_O_O__O(in__0, bout__3, A_arbace_java_shell_A_const_37, enc__1)
	tmp1 = jrt.StringWriter_Cast(bout__3).ToString__String().Ref()
//line :66:1
	return nil }();


	jrt.StringWriter_Cast(bout__3).Close__V(); if /*line :66:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O__O(self, in__0 any) any {
	var root_129 any = A_arbace_java_shell_A_const_38.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, A_arbace_java_shell_stream_to_string_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = in__0; var arg_133 any = jrt.Charset_DefaultCharset__Charset().Name__String().Ref(); if linked_130 == nil { return ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { return linked_130.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O_O__O(root_129, arg_132, arg_133)
	}
}



func A_arbace_java_shell_stream_to_enc_A_New() *A_arbace_java_shell_stream_to_enc_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_enc_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Ctor() {}
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Invoke_O_O_O__O(self, stream__0, enc__1 any) any {

	if lang.Util_Equiv_O_O__Z_NoInit(enc__1, A_arbace_java_shell_A_const_39) {
		var root_134 any = A_arbace_java_shell_A_const_40.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, A_arbace_java_shell_stream_to_bytes_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = stream__0; if linked_135 == nil { return ifn_136.Invoke_O__O(arg_137) } else { return linked_135.(*A_arbace_java_shell_stream_to_bytes_A).Invoke_O_O__O(root_134, arg_137) } } else {
			var root_138 any = A_arbace_java_shell_A_const_38.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, A_arbace_java_shell_stream_to_string_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = stream__0; var arg_142 any = enc__1; if linked_139 == nil { return ifn_140.Invoke_O_O__O(arg_141, arg_142) } else { return linked_139.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O_O__O(root_138, arg_141, arg_142)
			} } }
func A_arbace_java_shell_sh_A_New() *A_arbace_java_shell_sh_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_java_shell_sh_A) Ctor() {}
//line :79:1
func (t *A_arbace_java_shell_sh_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1651000037__2 any; var root_143 any = A_arbace_java_shell_A_const_41.GetRawRoot__O(); var linked_144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_143, A_arbace_java_shell_parse_args_A_fn_class); var ifn_145 lang.IFn; if
































	linked_144 == nil { ifn_145 = lang.IFn_Cast(root_143) } else { ifn_145 = nil }; var arg_146 any = args__0; if linked_144 == nil { vec__1651000037__2 = ifn_145.Invoke_O__O(arg_146) } else { vec__1651000037__2 = linked_144.(*A_arbace_java_shell_parse_args_A).Invoke_O_O__O(root_143, arg_146) }; var cmd__3 any = /*line :79:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1651000037__2, lang.RT_IntCast_J__I_NoInit(0), nil); var opts__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1651000037__2, lang.RT_IntCast_J__I_NoInit(1), nil); var proc__5 any; var tmp1 any = jrt.Runtime_GetRuntime__Runtime().Ref(); var tmp2 *jrt.Class = A_arbace_java_shell_A_const_42; var tmp3 any; var root_147 any = A_arbace_java_shell_A_const_33.GetRawRoot__O(); var linked_148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_147, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_149 lang.IFn; if


































	linked_148 == nil { ifn_149 = lang.IFn_Cast(root_147) } else { ifn_149 = nil }; var arg_150 any = cmd__3; if linked_148 == nil { tmp3 = ifn_149.Invoke_O__O(arg_150) } else { tmp3 = linked_148.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O__O(root_147, arg_150) }; var tmp4 any = tmp3; var tmp5 any; var root_151 any = /*line :113:1*/A_arbace_java_shell_A_const_43.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, A_arbace_java_shell_as_env_strings_A_fn_class); var ifn_153 lang.IFn; if

	linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = A_arbace_java_shell_A_const_26.Invoke_O__O(opts__4); if linked_152 == nil { tmp5 = ifn_153.Invoke_O__O(arg_154) } else { tmp5 = linked_152.(*A_arbace_java_shell_as_env_strings_A).Invoke_O_O__O(root_151, arg_154) }; var tmp6 any = tmp5; var tmp7 any; var target_155 any = /*line :113:1*/A_arbace_java_shell_A_const_24.Invoke_O__O(opts__4); var tmp8 bool; var tmp9 bool; tmp9 =


	aot_arbace_java_io.A_arbace_java_io_Coercions_A_InstanceOf(target_155); if tmp9 { tmp9 = !lang.Compiler_AOT_IsDyn_O__Z_NoInit(target_155) }; tmp8 = tmp9; if tmp8 { tmp7 = aot_arbace_java_io.A_arbace_java_io_Coercions_A_Cast(target_155).As_file__O() } else { tmp7 = lang.IFn_Cast(A_arbace_java_shell_A_const_44.GetRawRoot__O()).Invoke_O__O(target_155) }; proc__5 = /*line :113:1*/lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_7, jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, tmp7)); var map__1651000040__6 any = opts__4; var map__1651000040__7 any; if /*line :112:1*/ lang.ISeq_InstanceOf(map__1651000040__6) { var tmp10 any; var root_156 any = A_arbace_java_shell_A_const_45.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_158 lang.IFn; if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = map__1651000040__6; if linked_157 == nil { tmp10 = ifn_158.Invoke_O__O(arg_159) } else { tmp10 = linked_157.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_156, arg_159) }; if jrt.J2g_Truth(tmp10) { var tmp11 any; var root_160 any = A_arbace_java_shell_A_const_46.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_162 lang.IFn; if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = map__1651000040__6; if linked_161 == nil { tmp11 = ifn_162.Invoke_O__O(arg_163) } else { tmp11 = linked_161.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_160, arg_163) }; map__1651000040__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp11)).Ref() } else { var tmp12 any; var root_164 any = A_arbace_java_shell_A_const_9.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = map__1651000040__6; if linked_165 == nil { tmp12 = ifn_166.Invoke_O__O(arg_167) } else { tmp12 = linked_165.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_164, arg_167) }; if jrt.J2g_Truth(tmp12) { var root_168 any = A_arbace_java_shell_A_const_47.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_170 lang.IFn; if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = map__1651000040__6; if linked_169 == nil { map__1651000040__7 = ifn_170.Invoke_O__O(arg_171) } else { map__1651000040__7 = linked_169.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_168, arg_171) } } else { map__1651000040__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1651000040__7 = map__1651000040__6 }; var in__8 any = /*line :79:1*/lang.RT_Get_O_O__O_NoInit(map__1651000040__7, A_arbace_java_shell_A_const_48); var in_enc__9 any = lang.RT_Get_O_O__O_NoInit(map__1651000040__7, A_arbace_java_shell_A_const_23); var out_enc__10 any = lang.RT_Get_O_O__O_NoInit(map__1651000040__7, A_arbace_java_shell_A_const_22); if






































	jrt.J2g_Truth(in__8) {
		var root_201 any = A_arbace_java_shell_A_const_49.GetRawRoot__O(); var linked_202 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_201, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_203 lang.IFn; if linked_202 == nil { ifn_203 = lang.IFn_Cast(root_201) } else { ifn_203 = nil }; var arg_204 any; var fnbody__213 any = A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(proc__5, in_enc__9, in__8); var tmp13 *jrt.Class; var fncls__212 *jrt.Class = A_arbace_java_shell_sh_fn__1651000042_A_fn_class; if fncls__212 == nil { var fncls__212d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_8, false, fnbody__213); A_arbace_java_shell_sh_fn__1651000042_A_fn_class = fncls__212d; tmp13 = fncls__212d } else { tmp13 = fncls__212 }; arg_204 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__213, tmp13, nil); if linked_202 == nil { ifn_203.Invoke_O__O(arg_204) } else { linked_202.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_201, arg_204) } } else {


			jrt.Process_Cast(proc__5).GetOutputStream__OutputStream().Close__V() }; var stdout__11 any = /*line :79:1*/jrt.Process_Cast(proc__5).GetInputStream__InputStream(); var tmp14 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var stderr__14 any = jrt.Process_Cast(proc__5).GetErrorStream__InputStream(); tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__17 any; var root_172 any = A_arbace_java_shell_A_const_49.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_174 lang.IFn













































				if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any; var fnbody__182 any = A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(stdout__11, out_enc__10); var tmp15 *jrt.Class; var fncls__181 *jrt.Class = A_arbace_java_shell_sh_fn__1651000044_A_fn_class; if fncls__181 == nil { var fncls__181d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_9, false, fnbody__182); A_arbace_java_shell_sh_fn__1651000044_A_fn_class = fncls__181d; tmp15 = fncls__181d } else { tmp15 = fncls__181 }; arg_175 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__182, tmp15, nil); if linked_173 == nil { out__17 = ifn_174.Invoke_O__O(arg_175) } else { out__17 = linked_173.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_172, arg_175) }
//line :79:1
				var err__18 any; var root_183 any = A_arbace_java_shell_A_const_49.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_future_call_A_fn_class); var ifn_185 lang.IFn














































				if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any; var fnbody__192 any = A_arbace_java_shell_sh_fn__1651000046_A_New_O(stderr__14); var tmp16 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_java_shell_sh_fn__1651000046_A_fn_class; if fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_10, false, fnbody__192); A_arbace_java_shell_sh_fn__1651000046_A_fn_class = fncls__191d; tmp16 = fncls__191d } else { tmp16 = fncls__191 }; arg_186 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__192, tmp16, nil); if linked_184 == nil { err__18 = ifn_185.Invoke_O__O(arg_186) } else { err__18 = linked_184.(*aot_arbace_core.A_arbace_core_future_call_A).Invoke_O_O__O(root_183, arg_186) }
//line :79:1
				var exit_code__19 int32 = jrt.Process_Cast(proc__5).WaitFor__I(); var tmp17 any = A_arbace_java_shell_A_const_51; var tmp18 any = jrt.Integer_ValueOf_I__Integer_NoInit(exit_code__19).Ref(); var tmp19 any = A_arbace_java_shell_A_const_52; var tmp20 any; var root_193 any = A_arbace_java_shell_A_const_5.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_195 lang.IFn













































				if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = out__17; if linked_194 == nil { tmp20 = ifn_195.Invoke_O__O(arg_196) } else { tmp20 = linked_194.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_193, arg_196) }
//line :79:1
				var tmp21 any = tmp20; var tmp22 any = A_arbace_java_shell_A_const_53; var tmp23 any; var root_197 any = A_arbace_java_shell_A_const_5.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_199 lang.IFn













































				if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = err__18; if linked_198 == nil { tmp23 = ifn_199.Invoke_O__O(arg_200) } else { tmp23 = linked_198.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_197, arg_200) }
//line :79:1
				tmp14 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp17, tmp18, tmp19, tmp21, tmp22, tmp23)) }; return nil }()











































				jrt.InputStream_Cast(stderr__14).Close__V()
//line :79:1
				if tmp24 != nil { panic(tmp24) } }; return nil }();











































	jrt.InputStream_Cast(stdout__11).Close__V(); if /*line :79:1*/ tmp25 != nil { panic(tmp25) }; return tmp14 }







































func A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_java_shell_sh_fn__1651000042_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Ctor_O_O_O(c__proc, c__in_enc, c__in any) { t.F_proc = c__proc; t.F_in_enc = c__in_enc; t.F_in = c__in }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Invoke_O__O(self any) any { var os__1 any; var tmp1 any; var t_ any = t.F_proc;
										t.F_proc = nil; tmp1 = t_; os__1 = jrt.Process_Cast(tmp1).GetOutputStream__OutputStream(); var tmp2 any; tmp8 := /*line :119:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()); var tmp4 any; var t__2 any = t.F_in; t.F_in = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any = A_arbace_java_shell_A_const_37; var tmp7 any; var t__3 any = t.F_in_enc; t.F_in_enc = nil; tmp7 = t__3; tmp2 = tmp3.Invoke_O_O_O_O__O(tmp5, os__1, tmp6, tmp7) }
//line :119:1
		return nil }();
	jrt.OutputStream_Cast(os__1).Close__V(); if /*line :119:1*/ tmp8 != nil { panic(tmp8) }; return tmp2 }





func A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(p0, p1 any) *A_arbace_java_shell_sh_fn__1651000044_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Ctor_O_O(c__stdout, c__out_enc any) { t.F_stdout = c__stdout; t.F_out_enc = c__out_enc }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Invoke_O__O(self any) any { var root_176 any = A_arbace_java_shell_A_const_50.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, A_arbace_java_shell_stream_to_enc_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var t_ any = t.F_stdout; t.F_stdout = nil; arg_179 = t_; var arg_180 any; var t__2 any = t.F_out_enc; t.F_out_enc = nil; arg_180 = t__2; if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*A_arbace_java_shell_stream_to_enc_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } }
func A_arbace_java_shell_sh_fn__1651000046_A_New_O(p0 any) *A_arbace_java_shell_sh_fn__1651000046_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000046_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Ctor_O(c__stderr any) { t.F_stderr = c__stderr }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Invoke_O__O(self any) any { var root_187 any = A_arbace_java_shell_A_const_38.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, A_arbace_java_shell_stream_to_string_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any; var t_ any = t.F_stderr; t.F_stderr = nil; arg_190 = t_; if linked_188 == nil { return ifn_189.Invoke_O__O(arg_190) } else { return linked_188.(*A_arbace_java_shell_stream_to_string_A).Invoke_O_O__O(root_187, arg_190) } }












type A_arbace_java_shell_A struct{ jrt.Object }

var A_arbace_java_shell_A_const_pool *jrt.RefArray

var A_arbace_java_shell_A_const_0 *lang.Var

var A_arbace_java_shell_A_const_1 any

var A_arbace_java_shell_A_const_2 *lang.Var

var A_arbace_java_shell_A_const_3 any

var A_arbace_java_shell_A_const_4 *lang.Var

var A_arbace_java_shell_A_const_5 *lang.Var

var A_arbace_java_shell_A_const_6 *lang.Var

var A_arbace_java_shell_A_const_7 *lang.Var

var A_arbace_java_shell_A_const_8 any

var A_arbace_java_shell_A_const_9 *lang.Var

var A_arbace_java_shell_A_const_10 *lang.Var

var A_arbace_java_shell_A_const_11 *lang.Var

var A_arbace_java_shell_A_const_12 any

var A_arbace_java_shell_A_const_13 *lang.Var

var A_arbace_java_shell_A_const_14 *lang.Var

var A_arbace_java_shell_A_const_15 any

var A_arbace_java_shell_A_const_16 any

var A_arbace_java_shell_A_const_17 any

var A_arbace_java_shell_A_const_18 *lang.Var

var A_arbace_java_shell_A_const_19 *lang.Var

var A_arbace_java_shell_A_const_20 *lang.Var

var A_arbace_java_shell_A_const_21 *lang.Var

var A_arbace_java_shell_A_const_22 *lang.Keyword

var A_arbace_java_shell_A_const_23 *lang.Keyword

var A_arbace_java_shell_A_const_24 *lang.Keyword

var A_arbace_java_shell_A_const_25 *lang.Var

var A_arbace_java_shell_A_const_26 *lang.Keyword

var A_arbace_java_shell_A_const_27 *lang.Var

var A_arbace_java_shell_A_const_28 *lang.Var

var A_arbace_java_shell_A_const_29 *lang.Var

var A_arbace_java_shell_A_const_30 *lang.Var

var A_arbace_java_shell_A_const_31 *lang.Var

var A_arbace_java_shell_A_const_32 *lang.Var

var A_arbace_java_shell_A_const_33 *lang.Var

var A_arbace_java_shell_A_const_34 *jrt.Class

var A_arbace_java_shell_A_const_35 *lang.Var

var A_arbace_java_shell_A_const_36 *lang.Var

var A_arbace_java_shell_A_const_37 *lang.Keyword

var A_arbace_java_shell_A_const_38 *lang.Var

var A_arbace_java_shell_A_const_39 *lang.Keyword

var A_arbace_java_shell_A_const_40 *lang.Var

var A_arbace_java_shell_A_const_41 *lang.Var

var A_arbace_java_shell_A_const_42 *jrt.Class

var A_arbace_java_shell_A_const_43 *lang.Var

var A_arbace_java_shell_A_const_44 *lang.Var

var A_arbace_java_shell_A_const_45 *lang.Var

var A_arbace_java_shell_A_const_46 *lang.Var

var A_arbace_java_shell_A_const_47 *lang.Var

var A_arbace_java_shell_A_const_48 *lang.Keyword

var A_arbace_java_shell_A_const_49 *lang.Var

var A_arbace_java_shell_A_const_50 *lang.Var

var A_arbace_java_shell_A_const_51 *lang.Keyword

var A_arbace_java_shell_A_const_52 *lang.Keyword

var A_arbace_java_shell_A_const_53 *lang.Keyword

var A_arbace_java_shell_A_init jrt.ClassInit

func A_arbace_java_shell_A_Init() { if !A_arbace_java_shell_A_init.Done() { A_arbace_java_shell_A_init.Run(A_arbace_java_shell_A_clinit) } }

func A_arbace_java_shell_A_clinit() { A_arbace_java_shell_A_clinit_p0(); A_arbace_java_shell_A_clinit_p1(); A_arbace_java_shell_A_clinit_p2(); A_arbace_java_shell_A_clinit_p3(); A_arbace_java_shell_A_clinit_p4() }

func A_arbace_java_shell_A_clinit_p0() { jrt.StartCheck(); A_arbace_java_shell_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 76); A_arbace_java_shell_A_const_0 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[22]); A_arbace_java_shell_A_const_1 = A_arbace_java_shell_A_const_pool.A[23]; A_arbace_java_shell_A_const_2 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[24]); A_arbace_java_shell_A_const_3 = A_arbace_java_shell_A_const_pool.A[25]; A_arbace_java_shell_A_const_4 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[26]); A_arbace_java_shell_A_const_5 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[27]); A_arbace_java_shell_A_const_6 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[28]); A_arbace_java_shell_A_const_7 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[29]); A_arbace_java_shell_A_const_8 = A_arbace_java_shell_A_const_pool.A[30]; A_arbace_java_shell_A_const_9 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[31]); A_arbace_java_shell_A_const_10 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[32]); A_arbace_java_shell_A_const_11 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[33]) }

func A_arbace_java_shell_A_clinit_p1() { A_arbace_java_shell_A_const_12 = A_arbace_java_shell_A_const_pool.A[34]; A_arbace_java_shell_A_const_13 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[35]); A_arbace_java_shell_A_const_14 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[36]); A_arbace_java_shell_A_const_15 = A_arbace_java_shell_A_const_pool.A[37]; A_arbace_java_shell_A_const_16 = A_arbace_java_shell_A_const_pool.A[38]; A_arbace_java_shell_A_const_17 = A_arbace_java_shell_A_const_pool.A[39]; A_arbace_java_shell_A_const_18 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[40]); A_arbace_java_shell_A_const_19 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[41]); A_arbace_java_shell_A_const_20 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[42]); A_arbace_java_shell_A_const_21 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[43]); A_arbace_java_shell_A_const_22 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[44]); A_arbace_java_shell_A_const_23 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[45]); A_arbace_java_shell_A_const_24 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[46]) }

func A_arbace_java_shell_A_clinit_p2() { A_arbace_java_shell_A_const_25 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[47]); A_arbace_java_shell_A_const_26 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[48]); A_arbace_java_shell_A_const_27 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[49]); A_arbace_java_shell_A_const_28 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[50]); A_arbace_java_shell_A_const_29 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[51]); A_arbace_java_shell_A_const_30 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[52]); A_arbace_java_shell_A_const_31 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[53]); A_arbace_java_shell_A_const_32 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[54]); A_arbace_java_shell_A_const_33 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[55]); A_arbace_java_shell_A_const_34 = jrt.Class_Cast(A_arbace_java_shell_A_const_pool.A[56]); A_arbace_java_shell_A_const_35 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[57]); A_arbace_java_shell_A_const_36 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[58]) }

func A_arbace_java_shell_A_clinit_p3() { A_arbace_java_shell_A_const_37 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[59]); A_arbace_java_shell_A_const_38 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[60]); A_arbace_java_shell_A_const_39 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[61]); A_arbace_java_shell_A_const_40 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[62]); A_arbace_java_shell_A_const_41 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[63]); A_arbace_java_shell_A_const_42 = jrt.Class_Cast(A_arbace_java_shell_A_const_pool.A[64]); A_arbace_java_shell_A_const_43 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[65]); A_arbace_java_shell_A_const_44 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[66]); A_arbace_java_shell_A_const_45 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[67]); A_arbace_java_shell_A_const_46 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[68]); A_arbace_java_shell_A_const_47 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[69]); A_arbace_java_shell_A_const_48 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[70]) }

func A_arbace_java_shell_A_clinit_p4() { A_arbace_java_shell_A_const_49 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[71]); A_arbace_java_shell_A_const_50 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[72]); A_arbace_java_shell_A_const_51 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[73]); A_arbace_java_shell_A_const_52 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[74]); A_arbace_java_shell_A_const_53 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[75]) }

func A_arbace_java_shell_A_New() *A_arbace_java_shell_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_A) Ctor() {}

func (t *A_arbace_java_shell_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_A_class }

func (t *A_arbace_java_shell_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_A); return ok }

func A_arbace_java_shell_A_Cast(x any) *A_arbace_java_shell_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_A_class)) }; return v }



type A_arbace_java_shell_aconcat_A struct{ j2g_header uint64 }

var A_arbace_java_shell_aconcat_A_fn_class *jrt.Class



type A_arbace_java_shell_as_env_strings_A struct{ j2g_header uint64 }

var A_arbace_java_shell_as_env_strings_A_fn_class *jrt.Class



type A_arbace_java_shell_as_env_strings_fn__1651000028_A struct{ j2g_header uint64 }

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class *jrt.Class



type A_arbace_java_shell_eval1651000004_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000004_A_New() *A_arbace_java_shell_eval1651000004_A { t := &A_arbace_java_shell_eval1651000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000004_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000004_A_class }

func (t *A_arbace_java_shell_eval1651000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000004_A); return ok }

func A_arbace_java_shell_eval1651000004_A_Cast(x any) *A_arbace_java_shell_eval1651000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000004_A_class)) }; return v }



type A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A struct{ j2g_header uint64 }

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_fn_class *jrt.Class



type A_arbace_java_shell_eval1651000008_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000008_A_New() *A_arbace_java_shell_eval1651000008_A { t := &A_arbace_java_shell_eval1651000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000008_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000008_A_class }

func (t *A_arbace_java_shell_eval1651000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000008_A); return ok }

func A_arbace_java_shell_eval1651000008_A_Cast(x any) *A_arbace_java_shell_eval1651000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000008_A_class)) }; return v }



type A_arbace_java_shell_eval1651000008_fn__1651000009_A struct{ j2g_header uint64 }

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_fn_class *jrt.Class



type A_arbace_java_shell_parse_args_A struct{ j2g_header uint64 }

var A_arbace_java_shell_parse_args_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_A struct{ j2g_header uint64 }

var A_arbace_java_shell_sh_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000042_A struct{ j2g_header uint64; F_proc, F_in_enc, F_in any }

var A_arbace_java_shell_sh_fn__1651000042_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000044_A struct{ j2g_header uint64; F_stdout, F_out_enc any }

var A_arbace_java_shell_sh_fn__1651000044_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000046_A struct{ j2g_header uint64; F_stderr any }

var A_arbace_java_shell_sh_fn__1651000046_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_bytes_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_bytes_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_enc_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_enc_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_string_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_string_A_fn_class *jrt.Class



type A_arbace_java_shell_with_sh_dir_A struct{ j2g_header uint64 }

var A_arbace_java_shell_with_sh_dir_A_fn_class *jrt.Class



type A_arbace_java_shell_with_sh_env_A struct{ j2g_header uint64 }

var A_arbace_java_shell_with_sh_env_A_fn_class *jrt.Class
