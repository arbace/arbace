//line aot_arbace_java_shell.ae:1
package aot_arbace_java_shell

import (
	"arbace/aot_arbace_java_io"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_New() *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_java_shell_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_2); lang.IFn_Cast(A_arbace_java_shell_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_3); { var tmp4 *lang.Var; lang.RT_Init(); tmp4 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp4).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_3)); var tmp5 *lang.Var; lang.RT_Init(); tmp5 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp5).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_4)); var tmp6 *lang.Var; lang.RT_Init(); tmp6 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp6).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_5)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :9:1
func A_arbace_java_shell_eval1651000008_fn__1651000009_A_New() *A_arbace_java_shell_eval1651000008_fn__1651000009_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_eval1651000008_fn__1651000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_java_shell_eval1651000008_fn__1651000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_java_shell_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_8), A_arbace_java_shell_A_const_6.GetRawRoot__O(), A_arbace_java_shell_A_const_7) }











func A_arbace_java_shell_with_sh_dir_A_New() *A_arbace_java_shell_with_sh_dir_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_with_sh_dir_A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) Ctor() {}
//line :21:1
func (t *A_arbace_java_shell_with_sh_dir_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, dir__2, forms__3 any) any { return lang.IFn_Cast(A_arbace_java_shell_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_12), lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_shell_A_const_14.GetRawRoot__O(), lang.IFn_Cast(A_arbace_java_shell_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_15), lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(dir__2))))), forms__3)) }






func A_arbace_java_shell_with_sh_env_A_New() *A_arbace_java_shell_with_sh_env_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_with_sh_env_A{}; t.Ctor(); return t }
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) Ctor() {}
//line :28:1
func (t *A_arbace_java_shell_with_sh_env_A) DoInvoke_O_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, env__2, forms__3 any) any { return lang.IFn_Cast(A_arbace_java_shell_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_16), lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_shell_A_const_14.GetRawRoot__O(), lang.IFn_Cast(A_arbace_java_shell_A_const_9.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_10.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_17), lang.IFn_Cast(A_arbace_java_shell_A_const_11.GetRawRoot__O()).Invoke_O__O(env__2))))), forms__3)) }






func A_arbace_java_shell_aconcat_A_New() *A_arbace_java_shell_aconcat_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_aconcat_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) Ctor() {}
//line :35:1
func (t *A_arbace_java_shell_aconcat_A) DoInvoke_O_O_O__O(self, type__0, xs__1 any) any { var target__3 any = lang.IFn_Cast(A_arbace_java_shell_A_const_18.GetRawRoot__O()).Invoke_O_O__O(type__0, lang.IFn_Cast(A_arbace_java_shell_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_shell_A_const_19.GetRawRoot__O(), lang.IFn_Cast(A_arbace_java_shell_A_const_20.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_shell_A_const_21.GetRawRoot__O(), xs__1))); var i__4 int64 = 0; var idx__5 int64 = 0; L1: for { var temp__1927000414__auto____6 any = lang.RT_Nth_O_I_O__O(xs__1, lang.RT_IntCast_J__I(i__4), nil)




	if jrt.J2g_Truth(temp__1927000414__auto____6) { var a__7 any = temp__1927000414__auto____6
		jrt.System_Arraycopy_O_I_O_I_I__V(a__7, lang.RT_IntCast_J__I(0), target__3, lang.RT_IntCast_J__I(idx__5), lang.RT_Count_O__I(a__7))
		i__4, idx__5 = lang.Numbers_Inc_J__J(i__4), lang.Numbers_Add_J_J__J(idx__5, int64(lang.RT_Count_O__I(a__7))); continue L1 }
//line :35:1
	break L1 }; return target__3 }









func A_arbace_java_shell_parse_args_A_New() *A_arbace_java_shell_parse_args_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_parse_args_A{}; t.Ctor(); return t }
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Ctor() {}
//line :45:1
func (t *A_arbace_java_shell_parse_args_A) Invoke_O_O__O(self, args__0 any) any { var default_encoding__2 any = Lit_6; var tmp1 any = A_arbace_java_shell_A_const_22; var tmp2 any = A_arbace_java_shell_A_const_23; var tmp3 any = A_arbace_java_shell_A_const_24; var tmp4 any = A_arbace_java_shell_A_const_25.Get__O(); var tmp5 any = A_arbace_java_shell_A_const_26; var default_opts__3 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, default_encoding__2, tmp2, default_encoding__2, tmp3, tmp4, tmp5, A_arbace_java_shell_A_const_27.Get__O())); var vec__1651000023__4 any = lang.IFn_Cast(A_arbace_java_shell_A_const_28.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_shell_A_const_29.GetRawRoot__O(), args__0); var cmd__5 any = lang.RT_Nth_O_I_O__O(vec__1651000023__4, lang.RT_IntCast_J__I(0), nil); var opts__6 any = lang.RT_Nth_O_I_O__O(vec__1651000023__4, lang.RT_IntCast_J__I(1), nil); return lang.Tuple_Create_O_O__IPersistentVector(cmd__5, lang.IFn_Cast(A_arbace_java_shell_A_const_30.GetRawRoot__O()).Invoke_O_O__O(default_opts__3, lang.IFn_Cast(A_arbace_java_shell_A_const_13.GetRawRoot__O()).Invoke_O_O__O(A_arbace_java_shell_A_const_31.GetRawRoot__O(), opts__6))) }






func A_arbace_java_shell_as_env_strings_A_New() *A_arbace_java_shell_as_env_strings_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_as_env_strings_A{}; t.Ctor(); return t }
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Ctor() {}
//line :52:1
func (t *A_arbace_java_shell_as_env_strings_A) Invoke_O_O__O(self, arg__0 any) any {


	if lang.Util_Identical_O_O__Z(arg__0, nil) { return nil } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_shell_A_const_32.GetRawRoot__O()).Invoke_O__O(arg__0)) {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_java_shell_A_const_34; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_20.GetRawRoot__O()); var tmp4 any = A_arbace_java_shell_as_env_strings_fn__1651000028_A_New(); var tmp5 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_1, false); A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class = fncls__1d; tmp5 = fncls__1d } else { tmp5 = fncls__1 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), arg__0)) } else {
//line :55:1
			var tmp6 *jrt.Boolean; jrt.Boolean_Init(); tmp6 = jrt.Boolean_TRUE; if jrt.J2g_Truth(tmp6.Ref()) { return arg__0 } else { return nil
			} } } }
func A_arbace_java_shell_as_env_strings_fn__1651000028_A_New() *A_arbace_java_shell_as_env_strings_fn__1651000028_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_as_env_strings_fn__1651000028_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Ctor() {}
//line :57:1
func (t *A_arbace_java_shell_as_env_strings_fn__1651000028_A) Invoke_O_O__O(self, p__1651000027__1 any) any { var vec__1651000029__2 any = p__1651000027__1; var k__3 any = lang.RT_Nth_O_I_O__O(vec__1651000029__2, lang.RT_IntCast_J__I(0), nil); var v__4 any = lang.RT_Nth_O_I_O__O(vec__1651000029__2, lang.RT_IntCast_J__I(1), nil); return lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_2, nil), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_java_shell_A_const_35.GetRawRoot__O()).Invoke_O__O(k__3), nil, v__4)).Ref() }


func A_arbace_java_shell_stream_to_bytes_A_New() *A_arbace_java_shell_stream_to_bytes_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_bytes_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Ctor() {}
//line :60:1
func (t *A_arbace_java_shell_stream_to_bytes_A) Invoke_O_O__O(self, in__0 any) any { var bout__2 any = jrt.ByteArrayOutputStream_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)


	lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()).Invoke_O_O__O(in__0, bout__2)
	tmp1 = jrt.NN(jrt.ByteArrayOutputStream_Cast(bout__2)).ToByteArray__B1().Ref()
//line :60:1
	return nil }();

	jrt.NN(jrt.ByteArrayOutputStream_Cast(bout__2)).Close__V(); if /*line :60:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }





func A_arbace_java_shell_stream_to_string_A_New() *A_arbace_java_shell_stream_to_string_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_string_A{}; t.Ctor(); return t }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Ctor() {}
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O_O__O(self, in__0, enc__1 any) any { var bout__3 any = jrt.StringWriter_New(); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



	lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()).Invoke_O_O_O_O__O(in__0, bout__3, A_arbace_java_shell_A_const_37, enc__1)
	tmp1 = jrt.NN(jrt.StringWriter_Cast(bout__3)).ToString__String().Ref()
//line :66:1
	return nil }();


	jrt.NN(jrt.StringWriter_Cast(bout__3)).Close__V(); if /*line :66:1*/ tmp2 != nil { panic(tmp2) }; return tmp1 }
//line :66:1
func (t *A_arbace_java_shell_stream_to_string_A) Invoke_O_O__O(self, in__0 any) any {
	return lang.IFn_Cast(A_arbace_java_shell_A_const_38.GetRawRoot__O()).Invoke_O_O__O(in__0, jrt.Charset_DefaultCharset__Charset().Name__String().Ref())
}




func A_arbace_java_shell_stream_to_enc_A_New() *A_arbace_java_shell_stream_to_enc_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_stream_to_enc_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Ctor() {}
//line :73:1
func (t *A_arbace_java_shell_stream_to_enc_A) Invoke_O_O_O__O(self, stream__0, enc__1 any) any {

	if lang.Util_Equiv_O_O__Z(enc__1, A_arbace_java_shell_A_const_39) {
		return lang.IFn_Cast(A_arbace_java_shell_A_const_40.GetRawRoot__O()).Invoke_O__O(stream__0) } else {
			return lang.IFn_Cast(A_arbace_java_shell_A_const_38.GetRawRoot__O()).Invoke_O_O__O(stream__0, enc__1)
		} }
func A_arbace_java_shell_sh_A_New() *A_arbace_java_shell_sh_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_java_shell_sh_A) Ctor() {}
//line :79:1
func (t *A_arbace_java_shell_sh_A) DoInvoke_O_O__O(self, args__0 any) any { var vec__1651000037__2 any = lang.IFn_Cast(A_arbace_java_shell_A_const_41.GetRawRoot__O()).Invoke_O__O(args__0); var cmd__3 any = lang.RT_Nth_O_I_O__O(vec__1651000037__2, lang.RT_IntCast_J__I(0), nil); var opts__4 any = lang.RT_Nth_O_I_O__O(vec__1651000037__2, lang.RT_IntCast_J__I(1), nil); var proc__5 any; var tmp1 any = jrt.Runtime_GetRuntime__Runtime().Ref(); var tmp2 *jrt.Class = A_arbace_java_shell_A_const_42; var tmp3 any = lang.IFn_Cast(A_arbace_java_shell_A_const_33.GetRawRoot__O()).Invoke_O__O(cmd__3); var tmp4 any = lang.IFn_Cast(A_arbace_java_shell_A_const_43.GetRawRoot__O()).Invoke_O__O(A_arbace_java_shell_A_const_26.Invoke_O__O(opts__4)); var tmp5 any; var target_2 any = A_arbace_java_shell_A_const_24.Invoke_O__O(opts__4); var tmp6 bool; var tmp7 bool; tmp7 =




































	aot_arbace_java_io.A_arbace_java_io_Coercions_A_InstanceOf(target_2); if tmp7 { tmp7 = !lang.Compiler_AOT_IsDyn_O__Z(target_2) }; tmp6 = tmp7; if tmp6 { tmp5 = aot_arbace_java_io.A_arbace_java_io_Coercions_A_Cast(target_2).As_file__O() } else { tmp5 = lang.IFn_Cast(A_arbace_java_shell_A_const_44.GetRawRoot__O()).Invoke_O__O(target_2) }; proc__5 = /*line :113:1*/lang.Reflector_InvokeInstanceMethodOfClass_O_Class_String_O1__O(tmp1, tmp2, Lit_7, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5)); var map__1651000040__6 any = opts__4; var map__1651000040__7 any; if /*line :112:1*/ lang.ISeq_InstanceOf(map__1651000040__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_shell_A_const_45.GetRawRoot__O()).Invoke_O__O(map__1651000040__6)) { map__1651000040__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_java_shell_A_const_46.GetRawRoot__O()).Invoke_O__O(map__1651000040__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_java_shell_A_const_9.GetRawRoot__O()).Invoke_O__O(map__1651000040__6)) { map__1651000040__7 = lang.IFn_Cast(A_arbace_java_shell_A_const_47.GetRawRoot__O()).Invoke_O__O(map__1651000040__6) } else { lang.PersistentArrayMap_Init(); map__1651000040__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1651000040__7 = map__1651000040__6 }; var in__8 any = /*line :79:1*/lang.RT_Get_O_O__O(map__1651000040__7, A_arbace_java_shell_A_const_48); var in_enc__9 any = lang.RT_Get_O_O__O(map__1651000040__7, A_arbace_java_shell_A_const_23); var out_enc__10 any = lang.RT_Get_O_O__O(map__1651000040__7, A_arbace_java_shell_A_const_22); if






































	jrt.J2g_Truth(in__8) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_49.GetRawRoot__O()); var tmp9 any = A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(proc__5, in_enc__9, in__8); var tmp10 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_java_shell_sh_fn__1651000042_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_java_shell_sh_fn__1651000042_A_fn_class = fncls__3d; tmp10 = fncls__3d } else { tmp10 = fncls__3 }; tmp8.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil)) } else {


			jrt.Process_Cast(proc__5).GetOutputStream__OutputStream().Close__V() }; var stdout__11 any = /*line :79:1*/jrt.Process_Cast(proc__5).GetInputStream__InputStream(); var tmp11 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var stderr__14 any = jrt.Process_Cast(proc__5).GetErrorStream__InputStream(); tmp23 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var out__17 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_49.GetRawRoot__O()); var tmp13 any = A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(stdout__11, out_enc__10); var tmp14 *jrt.Class
				var fncls__4 /*line :79:1*/*jrt.Class = A_arbace_java_shell_sh_fn__1651000044_A_fn_class













































				if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_java_shell_sh_fn__1651000044_A_fn_class = fncls__4d; tmp14 = fncls__4d } else { tmp14 = fncls__4 }; out__17 = tmp12.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil))
//line :79:1
				var err__18 any; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_49.GetRawRoot__O()); var tmp16 any = A_arbace_java_shell_sh_fn__1651000046_A_New_O(stderr__14); var tmp17 *jrt.Class
				var fncls__5 /*line :79:1*/*jrt.Class = A_arbace_java_shell_sh_fn__1651000046_A_fn_class














































				if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_java_shell_sh_fn__1651000046_A_fn_class = fncls__5d; tmp17 = fncls__5d } else { tmp17 = fncls__5 }; err__18 = tmp15.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil))
//line :79:1
				var exit_code__19 int32 = jrt.Process_Cast(proc__5).WaitFor__I(); var tmp18 any = A_arbace_java_shell_A_const_50; var tmp19 any = jrt.Integer_ValueOf_I__Integer(exit_code__19).Ref(); var tmp20 any = A_arbace_java_shell_A_const_51; var tmp21 any = lang.IFn_Cast(A_arbace_java_shell_A_const_5.GetRawRoot__O()).Invoke_O__O(out__17); var tmp22 any = A_arbace_java_shell_A_const_52; tmp11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, tmp19, tmp20, tmp21, tmp22, lang.IFn_Cast(A_arbace_java_shell_A_const_5.GetRawRoot__O()).Invoke_O__O(err__18))) }; return nil }()











































				jrt.InputStream_Cast(stderr__14).Close__V()
//line :79:1
				if tmp23 != nil { panic(tmp23) } }; return nil }();











































	jrt.InputStream_Cast(stdout__11).Close__V(); if /*line :79:1*/ tmp24 != nil { panic(tmp24) }; return tmp11 }







































func A_arbace_java_shell_sh_fn__1651000042_A_New_O_O_O(p0, p1, p2 any) *A_arbace_java_shell_sh_fn__1651000042_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000042_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Ctor_O_O_O(c__proc, c__in_enc, c__in any) { t.F_proc = c__proc; t.F_in_enc = c__in_enc; t.F_in = c__in }
//line :119:1
func (t *A_arbace_java_shell_sh_fn__1651000042_A) Invoke_O__O(self any) any { var os__1 any; var tmp1 any; var t_ any = t.F_proc;
										t.F_proc = nil; tmp1 = t_; os__1 = jrt.Process_Cast(tmp1).GetOutputStream__OutputStream(); var tmp2 any; tmp8 := /*line :119:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

		{ var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_36.GetRawRoot__O()); var tmp4 any; var t__2 any = t.F_in; t.F_in = nil; tmp4 = t__2; var tmp5 any = tmp4; var tmp6 any = A_arbace_java_shell_A_const_37; var tmp7 any; var t__3 any = t.F_in_enc; t.F_in_enc = nil; tmp7 = t__3; tmp2 = tmp3.Invoke_O_O_O_O__O(tmp5, os__1, tmp6, tmp7) }
//line :119:1
		return nil }();
	jrt.OutputStream_Cast(os__1).Close__V(); if /*line :119:1*/ tmp8 != nil { panic(tmp8) }; return tmp2 }





func A_arbace_java_shell_sh_fn__1651000044_A_New_O_O(p0, p1 any) *A_arbace_java_shell_sh_fn__1651000044_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000044_A{}; t.Ctor_O_O(p0, p1); return t }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Ctor_O_O(c__stdout, c__out_enc any) { t.F_stdout = c__stdout; t.F_out_enc = c__out_enc }
//line :125:1
func (t *A_arbace_java_shell_sh_fn__1651000044_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_53.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_stdout; t.F_stdout = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_out_enc; t.F_out_enc = nil; tmp4 = t__2; return tmp1.Invoke_O_O__O(tmp3, tmp4) }
func A_arbace_java_shell_sh_fn__1651000046_A_New_O(p0 any) *A_arbace_java_shell_sh_fn__1651000046_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_sh_fn__1651000046_A{}; t.Ctor_O(p0); return t }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Ctor_O(c__stderr any) { t.F_stderr = c__stderr }
//line :126:1
func (t *A_arbace_java_shell_sh_fn__1651000046_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_java_shell_A_const_38.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_stderr; t.F_stderr = nil; tmp2 = t_; return tmp1.Invoke_O__O(tmp2) }












type A_arbace_java_shell_A struct{ jrt.Object }

var A_arbace_java_shell_A_const_pool *jrt.RefArray

var A_arbace_java_shell_A_const_0 *lang.Var

var A_arbace_java_shell_A_const_1 *lang.Var

var A_arbace_java_shell_A_const_2 any

var A_arbace_java_shell_A_const_3 any

var A_arbace_java_shell_A_const_4 *lang.Var

var A_arbace_java_shell_A_const_5 *lang.Var

var A_arbace_java_shell_A_const_6 *lang.Var

var A_arbace_java_shell_A_const_7 any

var A_arbace_java_shell_A_const_8 *lang.Var

var A_arbace_java_shell_A_const_9 *lang.Var

var A_arbace_java_shell_A_const_10 *lang.Var

var A_arbace_java_shell_A_const_11 *lang.Var

var A_arbace_java_shell_A_const_12 any

var A_arbace_java_shell_A_const_13 *lang.Var

var A_arbace_java_shell_A_const_14 *lang.Var

var A_arbace_java_shell_A_const_15 any

var A_arbace_java_shell_A_const_16 any

var A_arbace_java_shell_A_const_17 any

var A_arbace_java_shell_A_const_18 *lang.Var

var A_arbace_java_shell_A_const_19 *lang.Var

var A_arbace_java_shell_A_const_20 *lang.Var

var A_arbace_java_shell_A_const_21 *lang.Var

var A_arbace_java_shell_A_const_22 *lang.Keyword

var A_arbace_java_shell_A_const_23 *lang.Keyword

var A_arbace_java_shell_A_const_24 *lang.Keyword

var A_arbace_java_shell_A_const_25 *lang.Var

var A_arbace_java_shell_A_const_26 *lang.Keyword

var A_arbace_java_shell_A_const_27 *lang.Var

var A_arbace_java_shell_A_const_28 *lang.Var

var A_arbace_java_shell_A_const_29 *lang.Var

var A_arbace_java_shell_A_const_30 *lang.Var

var A_arbace_java_shell_A_const_31 *lang.Var

var A_arbace_java_shell_A_const_32 *lang.Var

var A_arbace_java_shell_A_const_33 *lang.Var

var A_arbace_java_shell_A_const_34 *jrt.Class

var A_arbace_java_shell_A_const_35 *lang.Var

var A_arbace_java_shell_A_const_36 *lang.Var

var A_arbace_java_shell_A_const_37 *lang.Keyword

var A_arbace_java_shell_A_const_38 *lang.Var

var A_arbace_java_shell_A_const_39 *lang.Keyword

var A_arbace_java_shell_A_const_40 *lang.Var

var A_arbace_java_shell_A_const_41 *lang.Var

var A_arbace_java_shell_A_const_42 *jrt.Class

var A_arbace_java_shell_A_const_43 *lang.Var

var A_arbace_java_shell_A_const_44 *lang.Var

var A_arbace_java_shell_A_const_45 *lang.Var

var A_arbace_java_shell_A_const_46 *lang.Var

var A_arbace_java_shell_A_const_47 *lang.Var

var A_arbace_java_shell_A_const_48 *lang.Keyword

var A_arbace_java_shell_A_const_49 *lang.Var

var A_arbace_java_shell_A_const_50 *lang.Keyword

var A_arbace_java_shell_A_const_51 *lang.Keyword

var A_arbace_java_shell_A_const_52 *lang.Keyword

var A_arbace_java_shell_A_const_53 *lang.Var

var A_arbace_java_shell_A_init jrt.ClassInit

func A_arbace_java_shell_A_Init() { if !A_arbace_java_shell_A_init.Done() { A_arbace_java_shell_A_init.Run(A_arbace_java_shell_A_clinit) } }

func A_arbace_java_shell_A_clinit() { A_arbace_java_shell_A_clinit_p0(); A_arbace_java_shell_A_clinit_p1(); A_arbace_java_shell_A_clinit_p2(); A_arbace_java_shell_A_clinit_p3(); A_arbace_java_shell_A_clinit_p4() }

func A_arbace_java_shell_A_clinit_p0() { A_arbace_java_shell_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 76); A_arbace_java_shell_A_const_0 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[22]); A_arbace_java_shell_A_const_1 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[23]); A_arbace_java_shell_A_const_2 = A_arbace_java_shell_A_const_pool.A[24]; A_arbace_java_shell_A_const_3 = A_arbace_java_shell_A_const_pool.A[25]; A_arbace_java_shell_A_const_4 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[26]); A_arbace_java_shell_A_const_5 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[27]); A_arbace_java_shell_A_const_6 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[28]); A_arbace_java_shell_A_const_7 = A_arbace_java_shell_A_const_pool.A[29]; A_arbace_java_shell_A_const_8 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[30]); A_arbace_java_shell_A_const_9 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[31]); A_arbace_java_shell_A_const_10 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[32]); A_arbace_java_shell_A_const_11 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[33]) }

func A_arbace_java_shell_A_clinit_p1() { A_arbace_java_shell_A_const_12 = A_arbace_java_shell_A_const_pool.A[34]; A_arbace_java_shell_A_const_13 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[35]); A_arbace_java_shell_A_const_14 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[36]); A_arbace_java_shell_A_const_15 = A_arbace_java_shell_A_const_pool.A[37]; A_arbace_java_shell_A_const_16 = A_arbace_java_shell_A_const_pool.A[38]; A_arbace_java_shell_A_const_17 = A_arbace_java_shell_A_const_pool.A[39]; A_arbace_java_shell_A_const_18 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[40]); A_arbace_java_shell_A_const_19 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[41]); A_arbace_java_shell_A_const_20 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[42]); A_arbace_java_shell_A_const_21 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[43]); A_arbace_java_shell_A_const_22 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[44]); A_arbace_java_shell_A_const_23 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[45]); A_arbace_java_shell_A_const_24 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[46]) }

func A_arbace_java_shell_A_clinit_p2() { A_arbace_java_shell_A_const_25 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[47]); A_arbace_java_shell_A_const_26 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[48]); A_arbace_java_shell_A_const_27 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[49]); A_arbace_java_shell_A_const_28 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[50]); A_arbace_java_shell_A_const_29 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[51]); A_arbace_java_shell_A_const_30 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[52]); A_arbace_java_shell_A_const_31 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[53]); A_arbace_java_shell_A_const_32 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[54]); A_arbace_java_shell_A_const_33 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[55]); A_arbace_java_shell_A_const_34 = jrt.Class_Cast(A_arbace_java_shell_A_const_pool.A[56]); A_arbace_java_shell_A_const_35 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[57]); A_arbace_java_shell_A_const_36 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[58]) }

func A_arbace_java_shell_A_clinit_p3() { A_arbace_java_shell_A_const_37 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[59]); A_arbace_java_shell_A_const_38 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[60]); A_arbace_java_shell_A_const_39 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[61]); A_arbace_java_shell_A_const_40 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[62]); A_arbace_java_shell_A_const_41 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[63]); A_arbace_java_shell_A_const_42 = jrt.Class_Cast(A_arbace_java_shell_A_const_pool.A[64]); A_arbace_java_shell_A_const_43 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[65]); A_arbace_java_shell_A_const_44 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[66]); A_arbace_java_shell_A_const_45 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[67]); A_arbace_java_shell_A_const_46 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[68]); A_arbace_java_shell_A_const_47 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[69]); A_arbace_java_shell_A_const_48 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[70]) }

func A_arbace_java_shell_A_clinit_p4() { A_arbace_java_shell_A_const_49 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[71]); A_arbace_java_shell_A_const_50 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[72]); A_arbace_java_shell_A_const_51 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[73]); A_arbace_java_shell_A_const_52 = lang.Keyword_Cast(A_arbace_java_shell_A_const_pool.A[74]); A_arbace_java_shell_A_const_53 = lang.Var_Cast(A_arbace_java_shell_A_const_pool.A[75]) }

func A_arbace_java_shell_A_New() *A_arbace_java_shell_A { A_arbace_java_shell_A_Init(); t := &A_arbace_java_shell_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_A) Ctor() {}

func (t *A_arbace_java_shell_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_A_class }

func (t *A_arbace_java_shell_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_A); return ok }

func A_arbace_java_shell_A_Cast(x any) *A_arbace_java_shell_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_A_class)) }; return v }



type A_arbace_java_shell_aconcat_A struct{ j2g_header uint64 }

var A_arbace_java_shell_aconcat_A_fn_class *jrt.Class



type A_arbace_java_shell_as_env_strings_A struct{ j2g_header uint64 }

var A_arbace_java_shell_as_env_strings_A_fn_class *jrt.Class



type A_arbace_java_shell_as_env_strings_fn__1651000028_A struct{ j2g_header uint64 }

var A_arbace_java_shell_as_env_strings_fn__1651000028_A_fn_class *jrt.Class



type A_arbace_java_shell_eval1651000004_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000004_A_New() *A_arbace_java_shell_eval1651000004_A { t := &A_arbace_java_shell_eval1651000004_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000004_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000004_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000004_A_class }

func (t *A_arbace_java_shell_eval1651000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000004_A); return ok }

func A_arbace_java_shell_eval1651000004_A_Cast(x any) *A_arbace_java_shell_eval1651000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000004_A_class)) }; return v }



type A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A struct{ j2g_header uint64 }

var A_arbace_java_shell_eval1651000004_loading__1927001464__auto____1651000005_A_fn_class *jrt.Class



type A_arbace_java_shell_eval1651000008_A struct{ jrt.Object }

func A_arbace_java_shell_eval1651000008_A_New() *A_arbace_java_shell_eval1651000008_A { t := &A_arbace_java_shell_eval1651000008_A{}; t.Ctor(); return t }

func (t *A_arbace_java_shell_eval1651000008_A) Ctor() {}

func (t *A_arbace_java_shell_eval1651000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_java_shell_eval1651000008_A) GetClass__Class() *jrt.Class { return A_arbace_java_shell_eval1651000008_A_class }

func (t *A_arbace_java_shell_eval1651000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_java_shell_eval1651000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_java_shell_eval1651000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_java_shell_eval1651000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_java_shell_eval1651000008_A); return ok }

func A_arbace_java_shell_eval1651000008_A_Cast(x any) *A_arbace_java_shell_eval1651000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_java_shell_eval1651000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_java_shell_eval1651000008_A_class)) }; return v }



type A_arbace_java_shell_eval1651000008_fn__1651000009_A struct{ j2g_header uint64 }

var A_arbace_java_shell_eval1651000008_fn__1651000009_A_fn_class *jrt.Class



type A_arbace_java_shell_parse_args_A struct{ j2g_header uint64 }

var A_arbace_java_shell_parse_args_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_A struct{ j2g_header uint64 }

var A_arbace_java_shell_sh_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000042_A struct{ j2g_header uint64; F_proc, F_in_enc, F_in any }

var A_arbace_java_shell_sh_fn__1651000042_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000044_A struct{ j2g_header uint64; F_stdout, F_out_enc any }

var A_arbace_java_shell_sh_fn__1651000044_A_fn_class *jrt.Class



type A_arbace_java_shell_sh_fn__1651000046_A struct{ j2g_header uint64; F_stderr any }

var A_arbace_java_shell_sh_fn__1651000046_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_bytes_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_bytes_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_enc_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_enc_A_fn_class *jrt.Class



type A_arbace_java_shell_stream_to_string_A struct{ j2g_header uint64 }

var A_arbace_java_shell_stream_to_string_A_fn_class *jrt.Class



type A_arbace_java_shell_with_sh_dir_A struct{ j2g_header uint64 }

var A_arbace_java_shell_with_sh_dir_A_fn_class *jrt.Class



type A_arbace_java_shell_with_sh_env_A struct{ j2g_header uint64 }

var A_arbace_java_shell_with_sh_env_A_fn_class *jrt.Class
