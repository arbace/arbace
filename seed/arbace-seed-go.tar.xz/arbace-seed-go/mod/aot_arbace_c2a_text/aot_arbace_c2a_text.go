//line aot_arbace_c2a_text.ae:1
package aot_arbace_c2a_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_New() *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A { A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_Init(); t := &A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_3; tmp3 = tmp8.Invoke_O__O(tmp9) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp10 != nil { panic(tmp10) }; return tmp3 }
//line :1:1
func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_New() *A_arbace_c2a_text_eval1948000008_fn__1948000009_A { A_arbace_c2a_text_eval1948000008_fn__1948000009_A_Init(); t := &A_arbace_c2a_text_eval1948000008_fn__1948000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_5; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_8; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_6; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_7; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }
















func A_arbace_c2a_text_fail_A_New() *A_arbace_c2a_text_fail_A { A_arbace_c2a_text_fail_A_Init(); t := &A_arbace_c2a_text_fail_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c2a_text_fail_A) Ctor() {}
//line :18:1
func (t *A_arbace_c2a_text_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, msg__2 any) any { var line__4 int64; var tmp1 *lang.Var;
											A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_c2a_text_fail_fn__1948000013_A_New(); var tmp4 *jrt.Class; A_arbace_c2a_text_fail_fn__1948000013_A_Init(); tmp4 = A_arbace_c2a_text_fail_fn__1948000013_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_12; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_13; var tmp9 any = tmp8; line__4 = lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O_O__O(s__0, tmp9, lang.Numbers_Min_O_J__O(i__1, int64(lang.RT_Count_O__I(s__0)))))))); var tmp10 /*line :18:1*/*lang.Var; A_arbace_c2a_text_A_Init(); tmp10 = A_arbace_c2a_text_A_const_10; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_64, nil, Lit_65), jrt.RefArrayOf(jrt.Object_class, msg__2, nil, jrt.Long_ValueOf_J__Long(line__4).Ref(), nil)).Ref(); var tmp13 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp13 = A_arbace_c2a_text_A_const_14; var tmp14 any = tmp13.Ref(); var tmp15 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_15; var tmp16 any = tmp15.Ref(); panic(jrt.Thrown(jrt.Throwable_Cast(tmp11.Invoke_O_O__O(tmp12, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp14, i__1, tmp16, jrt.Long_ValueOf_J__Long(line__4).Ref())))))) }
func A_arbace_c2a_text_fail_fn__1948000013_A_New() *A_arbace_c2a_text_fail_fn__1948000013_A { A_arbace_c2a_text_fail_fn__1948000013_A_Init(); t := &A_arbace_c2a_text_fail_fn__1948000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Invoke_O_O__O(self, p1__1948000012_SHARP___1 any) any { var tmp1 any; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_11; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp1, p1__1948000012_SHARP___1)).Ref() }


func A_arbace_c2a_text_ws_QMARK__A_New() *A_arbace_c2a_text_ws_QMARK__A { A_arbace_c2a_text_ws_QMARK__A_Init(); t := &A_arbace_c2a_text_ws_QMARK__A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2a_text_ws_QMARK__A) Ctor() {}
//line :22:1
func (t *A_arbace_c2a_text_ws_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 bool = jrt.Character_IsWhitespace_C__Z(lang.RT_CharCast_O__C(c__0)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { var tmp1 any; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_16; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(c__0, tmp1)).Ref() } }

func A_arbace_c2a_text_terminating_QMARK__A_New() *A_arbace_c2a_text_terminating_QMARK__A { A_arbace_c2a_text_terminating_QMARK__A_Init(); t := &A_arbace_c2a_text_terminating_QMARK__A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_c2a_text_terminating_QMARK__A) Ctor() {}
//line :24:1
func (t *A_arbace_c2a_text_terminating_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;



	A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_17; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var G__1948000017__3_ any = c__0; switch lang.Util_Hash_O__I(G__1948000017__3_) { case 34: var tmp2 any; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp2) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 40: var tmp3 any; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_19; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp3) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 41: var tmp4 any; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_20; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp4) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 59: var tmp5 any; A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_21; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp5) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 64: var tmp6 any; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_22; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp6) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 91: var tmp7 any; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_23; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp7) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 92: var tmp8 any; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_24; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp8) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 93: var tmp9 any; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_25; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp9) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 94: var tmp10 any; A_arbace_c2a_text_A_Init(); tmp10 = A_arbace_c2a_text_A_const_26; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp10) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 96: var tmp11 any; A_arbace_c2a_text_A_Init(); tmp11 = A_arbace_c2a_text_A_const_27; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp11) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 123: var tmp12 any; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_28; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp12) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 125: var tmp13 any; A_arbace_c2a_text_A_Init(); tmp13 = A_arbace_c2a_text_A_const_29; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp13) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 126: var tmp14 any; A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_30; if lang.Util_Equiv_O_O__Z(G__1948000017__3_, tmp14) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } }

func A_arbace_c2a_text_at_A_New() *A_arbace_c2a_text_at_A { A_arbace_c2a_text_at_A_Init(); t := &A_arbace_c2a_text_at_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_c2a_text_at_A) Ctor() {}
//line :30:1
func (t *A_arbace_c2a_text_at_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if lang.Numbers_Lt_O_J__Z(i__1, int64(lang.RT_Count_O__I(s__0))) { return jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__1))).Ref() } else { return nil } }

func A_arbace_c2a_text_line_end_A_New() *A_arbace_c2a_text_line_end_A { A_arbace_c2a_text_line_end_A_Init(); t := &A_arbace_c2a_text_line_end_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_c2a_text_line_end_A) Ctor() {}
//line :32:1
func (t *A_arbace_c2a_text_line_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String_I__I(Lit_72, lang.RT_IntCast_O__I(i__1)); if
											lang.Numbers_IsNeg_J__Z(int64(j__3)) { return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(s__0)).Ref() } else { return jrt.Integer_ValueOf_I__Integer(j__3).Ref() } }

func A_arbace_c2a_text_token_end_A_New() *A_arbace_c2a_text_token_end_A { A_arbace_c2a_text_token_end_A_Init(); t := &A_arbace_c2a_text_token_end_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_c2a_text_token_end_A) Ctor() {}
//line :35:1
func (t *A_arbace_c2a_text_token_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var j__4 any = i__1; L1: for {



	var tmp1 any; var and__1927000168__auto____5 bool = lang.Numbers_Lt_O_J__Z(j__4, int64(n__3)); if and__1927000168__auto____5 { var tmp2 *lang.Var; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_32; tmp1 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))).Ref())) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.A2g_Truth(tmp1) { j__4 = lang.Numbers_Inc_O__Number(j__4); continue L1 } else { return j__4 } } }; /*line :35:1*/panic("a2g: unreachable") }





func A_arbace_c2a_text_string_end_A_New() *A_arbace_c2a_text_string_end_A { A_arbace_c2a_text_string_end_A_Init(); t := &A_arbace_c2a_text_string_end_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_c2a_text_string_end_A) Ctor() {}
//line :41:1
func (t *A_arbace_c2a_text_string_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var j__4 any = lang.Numbers_Inc_O__Number(i__1); L1: for {




	if lang.Numbers_Gte_O_J__Z(j__4, int64(n__3)) { var tmp1 *lang.Var; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_85) } else { var tmp2 any; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_24; if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))) {
		j__4 = lang.Numbers_Add_O_J__Number(j__4, 2); continue L1 } else {
//line :46:1
			var tmp3 any; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(tmp3)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))) {

				return lang.Numbers_Inc_O__Number(j__4) } else {
//line :46:1
					var tmp4 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_34; if tmp4 != nil {


						j__4 = lang.Numbers_Inc_O__Number(j__4); continue L1 } else {
//line :46:1
							return nil } } } } } }; /*line :41:1*/panic("a2g: unreachable") }









func A_arbace_c2a_text_char_end_A_New() *A_arbace_c2a_text_char_end_A { A_arbace_c2a_text_char_end_A_Init(); t := &A_arbace_c2a_text_char_end_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_c2a_text_char_end_A) Ctor() {}
//line :51:1
func (t *A_arbace_c2a_text_char_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any {



	if lang.Numbers_Gte_O_J__Z(lang.Numbers_Inc_O__Number(i__1), int64(lang.RT_Count_O__I(s__0))) { var tmp1 *lang.Var; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_53) }
	var tmp2 *lang.Var; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_35; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))
}


func A_arbace_c2a_text_skip_ws_A_New() *A_arbace_c2a_text_skip_ws_A { A_arbace_c2a_text_skip_ws_A_Init(); t := &A_arbace_c2a_text_skip_ws_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_c2a_text_skip_ws_A) Ctor() {}
//line :60:1
func (t *A_arbace_c2a_text_skip_ws_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var i__4 any = i__1; L1: for {





	if lang.Numbers_Gte_O_J__Z(i__4, int64(n__3)) { return i__4 } else { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__4)); var tmp1 *lang.Var


		A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(c__5).Ref())) { i__4 = lang.Numbers_Inc_O__Number(i__4); continue L1 } else { var tmp2 any; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_21; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp2)).CharValue__C()) {
			var tmp3 *lang.Var; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_40; i__4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); continue L1 } else {
//line :69:1
				var tmp4 bool; var and__1927000168__auto____6 bool; var tmp5 any

				A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_36; and__1927000168__auto____6 = lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp5)).CharValue__C()); if and__1927000168__auto____6 { var tmp6 any; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_37; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_38; tmp4 = lang.Util_Equiv_O_O__Z(tmp7, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp4 = and__1927000168__auto____6 }
//line :69:1
				if tmp4 {

					var tmp9 *lang.Var; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_40; i__4 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); continue L1 } else {
//line :69:1
						var tmp10 bool; var and__1927000168__auto____6_2 bool; var tmp11 any


						A_arbace_c2a_text_A_Init(); tmp11 = A_arbace_c2a_text_A_const_36; and__1927000168__auto____6_2 = lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp11)).CharValue__C()); if and__1927000168__auto____6_2 { var tmp12 any; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_39; var tmp13 any = tmp12; var tmp14 *lang.Var; A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_38; tmp10 = lang.Util_Equiv_O_O__Z(tmp13, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp10 = and__1927000168__auto____6_2 }
//line :69:1
						if tmp10 {


							var tmp15 *lang.Var; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_41; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_c2a_text_A_Init(); tmp17 = A_arbace_c2a_text_A_const_42; i__4 = tmp16.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__4, 2))); continue L1 } else {
//line :69:1
								var tmp18 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp18 = A_arbace_c2a_text_A_const_34; if tmp18 != nil { return i__4 } else { return nil } } } } } } } }; /*line :60:1*/panic("a2g: unreachable") }
















func A_arbace_c2a_text_coll_end_A_New() *A_arbace_c2a_text_coll_end_A { A_arbace_c2a_text_coll_end_A_Init(); t := &A_arbace_c2a_text_coll_end_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_c2a_text_coll_end_A) Ctor() {}
//line :77:1
func (t *A_arbace_c2a_text_coll_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var close__3 any; var tmp1 *lang.Var


	A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_43; close__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__1))).Ref())
//line :77:1
	var j__4 any; var tmp2 *lang.Var



	A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_42; j__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))
//line :77:1
L1: for { var c__5 any; var tmp3 *lang.Var




	A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_38; c__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__0, j__4)
	if lang.Util_Identical_O_O__Z(c__5, nil) { var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_56, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref()) } else { if lang.Util_Equiv_O_O__Z(c__5, close__3) {
		return lang.Numbers_Inc_O__Number(j__4) } else {
//line :83:1
			var tmp5 any; A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_44; if jrt.A2g_Truth(lang.IFn_Cast(tmp5).Invoke_O__O(c__5)) {

				var tmp6 *lang.Var; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref()) } else {
//line :83:1
					var tmp7 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_34; if tmp7 != nil {


						var tmp8 *lang.Var; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_42; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_c2a_text_A_Init(); tmp10 = A_arbace_c2a_text_A_const_41; j__4 = tmp9.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(s__0, j__4)); continue L1 } else {
//line :83:1
							return nil } } } } } }; /*line :77:1*/panic("a2g: unreachable") }










func A_arbace_c2a_text_next_form_end_A_New() *A_arbace_c2a_text_next_form_end_A { A_arbace_c2a_text_next_form_end_A_Init(); t := &A_arbace_c2a_text_next_form_end_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_c2a_text_next_form_end_A) Ctor() {}
//line :88:1
func (t *A_arbace_c2a_text_next_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 *lang.Var;
											A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_42; j__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); if
											lang.Numbers_Gte_O_J__Z(j__3, int64(lang.RT_Count_O__I(s__0))) { var tmp2 *lang.Var; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_68) }; var tmp3 /*line :91:1*/*lang.Var; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_41; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__0, j__3) }

func A_arbace_c2a_text_form_end_A_New() *A_arbace_c2a_text_form_end_A { A_arbace_c2a_text_form_end_A_Init(); t := &A_arbace_c2a_text_form_end_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_c2a_text_form_end_A) Ctor() {}
//line :93:1
func (t *A_arbace_c2a_text_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var c__3 any; var tmp1 *lang.Var;


	A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_38; c__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var G__1948000027__4_ any = c__3; switch
	lang.Util_Hash_O__I(G__1948000027__4_) { case 0: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, nil) {
		var tmp2 *lang.Var; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_68) }
//line :97:1
	case 34: var tmp3 any; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp3) {


		var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_45; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 35: var tmp5 any; A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_36; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp5) { var d__5 any; var tmp6 *lang.Var








		A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_38; d__5 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))
//line :97:1
		var G__1948000028__6_ any = d__5









		switch lang.Util_Hash_O__I(G__1948000028__6_) { case 0: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, nil) {
			var tmp7 *lang.Var; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_69) }
//line :107:1
		case 33: var tmp8 any; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_37; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp8) {






			var tmp9 *lang.Var; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_46; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_c2a_text_A_Init(); tmp11 = A_arbace_c2a_text_A_const_40; return tmp10.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1)) }
//line :107:1
		case 34: var tmp12 any; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp12) {


			var tmp13 *lang.Var; A_arbace_c2a_text_A_Init(); tmp13 = A_arbace_c2a_text_A_const_45; return lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :107:1
		case 35: var tmp14 any; A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_36; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp14) {








			var tmp15 *lang.Var; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_35; return lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2)) }
//line :107:1
		case 39: var tmp16 any; A_arbace_c2a_text_A_Init(); tmp16 = A_arbace_c2a_text_A_const_47; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp16) {



			var tmp17 *lang.Var; A_arbace_c2a_text_A_Init(); tmp17 = A_arbace_c2a_text_A_const_46; return lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2)) }
//line :107:1
		case 40: var tmp18 any; A_arbace_c2a_text_A_Init(); tmp18 = A_arbace_c2a_text_A_const_19; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp18) {

			var tmp19 *lang.Var; A_arbace_c2a_text_A_Init(); tmp19 = A_arbace_c2a_text_A_const_48; return lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :107:1
		case 58: var tmp20 any; A_arbace_c2a_text_A_Init(); tmp20 = A_arbace_c2a_text_A_const_49; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp20) { var j__7 any; var tmp21 *lang.Var









			A_arbace_c2a_text_A_Init(); tmp21 = A_arbace_c2a_text_A_const_42; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_c2a_text_A_Init(); tmp23 = A_arbace_c2a_text_A_const_35; j__7 = tmp22.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)))
			var tmp24 any; A_arbace_c2a_text_A_Init(); tmp24 = A_arbace_c2a_text_A_const_28; var tmp25 any = tmp24; var tmp26 *lang.Var; A_arbace_c2a_text_A_Init(); tmp26 = A_arbace_c2a_text_A_const_38; if lang.Util_Equiv_O_O__Z(tmp25, lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O__O(s__0, j__7)) { } else { var tmp27 *lang.Var; A_arbace_c2a_text_A_Init(); tmp27 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_70) }
			var tmp28 *lang.Var; A_arbace_c2a_text_A_Init(); tmp28 = A_arbace_c2a_text_A_const_48; return lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O_O__O(s__0, j__7) }
//line :107:1
		case 61: var tmp29 any; A_arbace_c2a_text_A_Init(); tmp29 = A_arbace_c2a_text_A_const_50; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp29) {



			var tmp30 *lang.Var; A_arbace_c2a_text_A_Init(); tmp30 = A_arbace_c2a_text_A_const_46; return lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2)) }
//line :107:1
		case 63: var tmp31 any; A_arbace_c2a_text_A_Init(); tmp31 = A_arbace_c2a_text_A_const_51; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp31) {







			var tmp32 *lang.Var; A_arbace_c2a_text_A_Init(); tmp32 = A_arbace_c2a_text_A_const_48; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_c2a_text_A_Init(); tmp34 = A_arbace_c2a_text_A_const_52; return tmp33.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1)) }
//line :107:1
		case 94: var tmp35 any; A_arbace_c2a_text_A_Init(); tmp35 = A_arbace_c2a_text_A_const_26; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp35) {




			var tmp36 *lang.Var; A_arbace_c2a_text_A_Init(); tmp36 = A_arbace_c2a_text_A_const_46; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Var; A_arbace_c2a_text_A_Init(); tmp38 = A_arbace_c2a_text_A_const_46; return tmp37.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))) }
//line :107:1
		case 95: var tmp39 any; A_arbace_c2a_text_A_Init(); tmp39 = A_arbace_c2a_text_A_const_39; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp39) {





			var tmp40 *lang.Var; A_arbace_c2a_text_A_Init(); tmp40 = A_arbace_c2a_text_A_const_46; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Var; A_arbace_c2a_text_A_Init(); tmp42 = A_arbace_c2a_text_A_const_46; return tmp41.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))) }
//line :107:1
		case 123: var tmp43 any; A_arbace_c2a_text_A_Init(); tmp43 = A_arbace_c2a_text_A_const_28; if lang.Util_Equiv_O_O__Z(G__1948000028__6_, tmp43) {

			var tmp44 *lang.Var; A_arbace_c2a_text_A_Init(); tmp44 = A_arbace_c2a_text_A_const_48; return lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :107:1
		default:
		}












		var tmp45 *lang.Var; A_arbace_c2a_text_A_Init(); tmp45 = A_arbace_c2a_text_A_const_46; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 *lang.Var; A_arbace_c2a_text_A_Init(); tmp47 = A_arbace_c2a_text_A_const_35; return tmp46.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))) }
//line :97:1
	case 39: var tmp48 any; A_arbace_c2a_text_A_Init(); tmp48 = A_arbace_c2a_text_A_const_47; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp48) {




		var tmp49 *lang.Var; A_arbace_c2a_text_A_Init(); tmp49 = A_arbace_c2a_text_A_const_46; return lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :97:1
	case 40: var tmp50 any; A_arbace_c2a_text_A_Init(); tmp50 = A_arbace_c2a_text_A_const_19; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp50) {

		var tmp51 *lang.Var; A_arbace_c2a_text_A_Init(); tmp51 = A_arbace_c2a_text_A_const_48; return lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 41: var tmp52 any; A_arbace_c2a_text_A_Init(); tmp52 = A_arbace_c2a_text_A_const_20; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp52) {







		var tmp53 *lang.Var; A_arbace_c2a_text_A_Init(); tmp53 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 64: var tmp54 any; A_arbace_c2a_text_A_Init(); tmp54 = A_arbace_c2a_text_A_const_22; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp54) {




		var tmp55 *lang.Var; A_arbace_c2a_text_A_Init(); tmp55 = A_arbace_c2a_text_A_const_46; return lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :97:1
	case 91: var tmp56 any; A_arbace_c2a_text_A_Init(); tmp56 = A_arbace_c2a_text_A_const_23; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp56) {

		var tmp57 *lang.Var; A_arbace_c2a_text_A_Init(); tmp57 = A_arbace_c2a_text_A_const_48; return lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 92: var tmp58 any; A_arbace_c2a_text_A_Init(); tmp58 = A_arbace_c2a_text_A_const_24; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp58) {



		var tmp59 *lang.Var; A_arbace_c2a_text_A_Init(); tmp59 = A_arbace_c2a_text_A_const_53; return lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 93: var tmp60 any; A_arbace_c2a_text_A_Init(); tmp60 = A_arbace_c2a_text_A_const_25; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp60) {







		var tmp61 *lang.Var; A_arbace_c2a_text_A_Init(); tmp61 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 94: var tmp62 any; A_arbace_c2a_text_A_Init(); tmp62 = A_arbace_c2a_text_A_const_26; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp62) {






		var tmp63 *lang.Var; A_arbace_c2a_text_A_Init(); tmp63 = A_arbace_c2a_text_A_const_46; var tmp64 lang.IFn = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()); var tmp65 *lang.Var; A_arbace_c2a_text_A_Init(); tmp65 = A_arbace_c2a_text_A_const_46; return tmp64.Invoke_O_O__O(s__0, lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))) }
//line :97:1
	case 96: var tmp66 any; A_arbace_c2a_text_A_Init(); tmp66 = A_arbace_c2a_text_A_const_27; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp66) {




		var tmp67 *lang.Var; A_arbace_c2a_text_A_Init(); tmp67 = A_arbace_c2a_text_A_const_46; return lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :97:1
	case 123: var tmp68 any; A_arbace_c2a_text_A_Init(); tmp68 = A_arbace_c2a_text_A_const_28; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp68) {

		var tmp69 *lang.Var; A_arbace_c2a_text_A_Init(); tmp69 = A_arbace_c2a_text_A_const_48; return lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 125: var tmp70 any; A_arbace_c2a_text_A_Init(); tmp70 = A_arbace_c2a_text_A_const_29; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp70) {







		var tmp71 *lang.Var; A_arbace_c2a_text_A_Init(); tmp71 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_57, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 126: var tmp72 any; A_arbace_c2a_text_A_Init(); tmp72 = A_arbace_c2a_text_A_const_30; if lang.Util_Equiv_O_O__Z(G__1948000027__4_, tmp72) {





		var tmp73 *lang.Var; A_arbace_c2a_text_A_Init(); tmp73 = A_arbace_c2a_text_A_const_46; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 jrt.Number_I; var tmp76 any; A_arbace_c2a_text_A_Init(); tmp76 = A_arbace_c2a_text_A_const_22; var tmp77 any = tmp76; var tmp78 *lang.Var; A_arbace_c2a_text_A_Init(); tmp78 = A_arbace_c2a_text_A_const_38; if lang.Util_Equiv_O_O__Z(tmp77, lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))) { tmp75 = lang.Numbers_Add_O_J__Number(i__1, 2) } else { tmp75 = lang.Numbers_Inc_O__Number(i__1) }; return tmp74.Invoke_O_O__O(s__0, tmp75) }
//line :97:1
	default:}; var tmp79 /*line :122:1*/*lang.Var; A_arbace_c2a_text_A_Init(); tmp79 = A_arbace_c2a_text_A_const_35; return lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }



func A_arbace_c2a_text_cond_open_A_New() *A_arbace_c2a_text_cond_open_A { A_arbace_c2a_text_cond_open_A_Init(); t := &A_arbace_c2a_text_cond_open_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_c2a_text_cond_open_A) Ctor() {}
//line :126:1
func (t *A_arbace_c2a_text_cond_open_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 any = A_arbace_c2a_text_cond_open_fn__1948000030_A_New_O_O(i__1, s__0); var tmp2 *jrt.Class;



	A_arbace_c2a_text_cond_open_fn__1948000030_A_Init(); tmp2 = A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var tmp3 any;

	A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_19; var tmp4 any = tmp3; var tmp5 *lang.Var; A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_38; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)) { } else { var tmp6 *lang.Var; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_59) }; return j__3 }
//line :130:1
func A_arbace_c2a_text_cond_open_fn__1948000030_A_New_O_O(p0, p1 any) *A_arbace_c2a_text_cond_open_fn__1948000030_A { A_arbace_c2a_text_cond_open_fn__1948000030_A_Init(); t := &A_arbace_c2a_text_cond_open_fn__1948000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Ctor_O_O(c__i, c__s any) { t.F_i = c__i; t.F_s = c__s }
//line :130:1
func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_22; var tmp2 any = tmp1; var tmp3 *lang.Var; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_38; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = t.F_s; if lang.Util_Equiv_O_O__Z(tmp2, tmp4.Invoke_O_O__O(tmp5, lang.Numbers_Add_O_J__Number(t.F_i, 2))) { var tmp6 any; var t_ any = t.F_i; t.F_i = nil; tmp6 = t_; j__1 = lang.Numbers_Add_O_J__Number(tmp6, 3) } else { var tmp7 any; var t__2 any = t.F_i; t.F_i = nil; tmp7 = t__2; j__1 = lang.Numbers_Add_O_J__Number(tmp7, 2) }; L1: for {
											var tmp8 any; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(lang.RT_Count_O__I(t.F_s))); if and__1927000168__auto____2 { var tmp9 *lang.Var; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_17; var tmp10 *jrt.String = jrt.String_Cast(t.F_s); tmp8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(tmp10).CharAt_I__C(lang.RT_IntCast_O__I(j__1))).Ref()) } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.A2g_Truth(tmp8) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; /*line :130:1*/panic("a2g: unreachable") }




func A_arbace_c2a_text_branches_A_New() *A_arbace_c2a_text_branches_A { A_arbace_c2a_text_branches_A_Init(); t := &A_arbace_c2a_text_branches_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_c2a_text_branches_A) Ctor() {}
//line :135:1
func (t *A_arbace_c2a_text_branches_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var j__3 any; var tmp1 *lang.Var



	A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_42; j__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))
//line :135:1
	var bs__4 any; lang.PersistentVector_Init(); bs__4 = lang.PersistentVector_EMPTY.Ref(); L1: for {




		var tmp2 any; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_20; var tmp3 any = tmp2; var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_38; if lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)) { return bs__4 } else { var fe__5 any; var tmp5 *lang.Var

			A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_41; fe__5 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)
//line :140:1
			var feature__6 any; var tmp6 *lang.Var


			A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_12; feature__6 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__3, fe__5)
//line :140:1
			var v__7 any; var tmp7 *lang.Var



			A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_42; v__7 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O_O__O(s__0, fe__5)
			var tmp8 *lang.Var; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(feature__6, Lit_49)) { } else { var tmp9 *lang.Var; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__3, Lit_50) }
			var tmp10 any; A_arbace_c2a_text_A_Init(); tmp10 = A_arbace_c2a_text_A_const_20; var tmp11 any = tmp10; var tmp12 *lang.Var; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_38; if lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(s__0, v__7)) { var tmp13 *lang.Var; A_arbace_c2a_text_A_Init(); tmp13 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__7, Lit_51) }
//line :140:1
			var ve__8 any; var tmp14 *lang.Var






			A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_41; ve__8 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(s__0, v__7)
			var tmp15 *lang.Var; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_42; var tmp16 any = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O__O(s__0, ve__8); var tmp17 *lang.Var; A_arbace_c2a_text_A_Init(); tmp17 = A_arbace_c2a_text_A_const_6; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_c2a_text_A_Init(); tmp19 = A_arbace_c2a_text_A_const_55; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_c2a_text_A_Init(); tmp21 = A_arbace_c2a_text_A_const_12; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_c2a_text_A_Init(); tmp23 = A_arbace_c2a_text_A_const_56; j__3, bs__4 = tmp16, tmp18.Invoke_O_O__O(bs__4, lang.Tuple_Create_O_O_O__IPersistentVector(tmp20.Invoke_O__O(tmp22.Invoke_O_O__O(feature__6, tmp23)), v__7, ve__8)); continue L1 } } }; /*line :135:1*/panic("a2g: unreachable") }
















func A_arbace_c2a_text_selected_A_New() *A_arbace_c2a_text_selected_A { A_arbace_c2a_text_selected_A_Init(); t := &A_arbace_c2a_text_selected_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_c2a_text_selected_A) Ctor() {}
//line :152:1
func (t *A_arbace_c2a_text_selected_A) Invoke_O_O_O_O_O__O(self, s__0, i__1, features__2, depth__3 any) any { var splice_QMARK___5 bool; var tmp1 any;




	A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_22; var tmp2 any = tmp1; var tmp3 *lang.Var; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_38; splice_QMARK___5 = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))); var open__6 any; var tmp4 /*line :152:1*/*lang.Var;





	A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_52; open__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var vec__1948000034__7 any; var tmp5 /*line :152:1*/*lang.Var;






	A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_57; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_9; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_c2a_text_selected_fn__1948000038_A_New_O(features__2); var tmp10 *jrt.Class; A_arbace_c2a_text_selected_fn__1948000038_A_Init(); tmp10 = A_arbace_c2a_text_selected_fn__1948000038_A_fn_class; var tmp11 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var tmp12 *lang.Var; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_62; vec__1948000034__7 = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(s__0, open__6))); var ___8 any = /*line :152:1*/lang.RT_Nth_O_I_O__O(vec__1948000034__7, lang.RT_IntCast_J__I(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O(vec__1948000034__7, lang.RT_IntCast_J__I(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O(vec__1948000034__7, lang.RT_IntCast_J__I(2), nil); var tmp13 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8; if and__1927000168__auto____11 {








		tmp13 = lang.Numbers_IsZero_O__Z(depth__3) } else { tmp13 = and__1927000168__auto____11 }; if tmp13 {
			var tmp14 *lang.Var; A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_33; lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_79) }; if
	lang.Util_Identical_O_O__Z(v__9, nil) { return Lit_80 } else { var tmp15 *lang.Var; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(splice_QMARK___5).Ref())) {
		var tmp16 *lang.Var; A_arbace_c2a_text_A_Init(); tmp16 = A_arbace_c2a_text_A_const_58; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_c2a_text_A_Init(); tmp18 = A_arbace_c2a_text_A_const_12; return tmp17.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__9, ve__10), features__2) } else {
//line :163:1
			var tmp19 any; A_arbace_c2a_text_A_Init(); tmp19 = A_arbace_c2a_text_A_const_59; var tmp20 lang.IFn = lang.IFn_Cast(tmp19); var tmp21 *lang.Var; A_arbace_c2a_text_A_Init(); tmp21 = A_arbace_c2a_text_A_const_38; if jrt.A2g_Truth(tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(s__0, v__9))) {

				var tmp22 *lang.Var; A_arbace_c2a_text_A_Init(); tmp22 = A_arbace_c2a_text_A_const_58; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_c2a_text_A_Init(); tmp24 = A_arbace_c2a_text_A_const_12; return tmp23.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Inc_O__Number(v__9), lang.Numbers_Dec_O__Number(ve__10)), features__2) } else {
//line :163:1
					var tmp25 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp25 = A_arbace_c2a_text_A_const_34; if tmp25 != nil {


						var tmp26 *lang.Var; A_arbace_c2a_text_A_Init(); tmp26 = A_arbace_c2a_text_A_const_33; return lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__9, Lit_81) } else {
//line :163:1
							return nil } } } } }
//line :159:1
func A_arbace_c2a_text_selected_fn__1948000038_A_New_O(p0 any) *A_arbace_c2a_text_selected_fn__1948000038_A { A_arbace_c2a_text_selected_fn__1948000038_A_Init(); t := &A_arbace_c2a_text_selected_fn__1948000038_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Ctor_O(c__features any) { t.F_features = c__features }
//line :159:1
func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Invoke_O_O__O(self, p__1948000037__1 any) any { var vec__1948000039__2 any = p__1948000037__1; var f__3 any = lang.RT_Nth_O_I_O__O(vec__1948000039__2, lang.RT_IntCast_J__I(0), nil); var or__1927000174__auto____4 any; var tmp1 *lang.Var; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_60; or__1927000174__auto____4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_features, f__3); if jrt.A2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { var tmp2 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_61; return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(f__3, tmp2.Ref())).Ref() } }








func A_arbace_c2a_text_resolve_conditionals_A_New() *A_arbace_c2a_text_resolve_conditionals_A { A_arbace_c2a_text_resolve_conditionals_A_Init(); t := &A_arbace_c2a_text_resolve_conditionals_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_c2a_text_resolve_conditionals_A) Ctor() {}
//line :168:1
func (t *A_arbace_c2a_text_resolve_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any {





	{ var tmp1 *lang.Var; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_31; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_64; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_76))) { return s__0 } else { var n__3 int32 = lang.RT_Count_O__I(s__0); var sb__4 any = jrt.StringBuilder_New(); var i__5 any = lang.RT_Box_J__Number(0); var depth__6 int64 = 0; L1: for {



		if lang.Numbers_Gte_O_J__Z(i__5, int64(n__3)) {
			var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_63; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(sb__4) } else {
//line :178:1
				var c__7 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__5)); var copy__8 any; var tmp5 any = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_New_O_O_O(i__5, sb__4, s__0); var tmp6 *jrt.Class


				A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_Init(); tmp6 = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class; copy__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil)
//line :178:1
				var G__1948000050__9_ uint16 = c__7



				switch lang.Util_Hash_O__I(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref()) { case 34: var tmp7 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp8 any; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_O_O__Z(tmp7, tmp8) {
					var tmp9 lang.IFn = lang.IFn_Cast(copy__8); var tmp10 *lang.Var; A_arbace_c2a_text_A_Init(); tmp10 = A_arbace_c2a_text_A_const_45; i__5, depth__6 = tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 35: var tmp11 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp12 any; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_36; if lang.Util_Equiv_O_O__Z(tmp11, tmp12) { var G__1948000051__10_ any; var tmp13 *lang.Var





					A_arbace_c2a_text_A_Init(); tmp13 = A_arbace_c2a_text_A_const_38; G__1948000051__10_ = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__5)); switch lang.Util_Hash_O__I(G__1948000051__10_) { case 33: var tmp14 any; A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_37; if lang.Util_Equiv_O_O__Z(G__1948000051__10_, tmp14) {

						var tmp15 lang.IFn = lang.IFn_Cast(copy__8); var tmp16 *lang.Var; A_arbace_c2a_text_A_Init(); tmp16 = A_arbace_c2a_text_A_const_40; i__5, depth__6 = tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :188:1
					case 34: var tmp17 any; A_arbace_c2a_text_A_Init(); tmp17 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_O_O__Z(G__1948000051__10_, tmp17) {
						var tmp18 lang.IFn = lang.IFn_Cast(copy__8); var tmp19 *lang.Var; A_arbace_c2a_text_A_Init(); tmp19 = A_arbace_c2a_text_A_const_45; i__5, depth__6 = tmp18.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__5))), depth__6; continue L1 }
//line :188:1
					case 63: var tmp20 any; A_arbace_c2a_text_A_Init(); tmp20 = A_arbace_c2a_text_A_const_51; if lang.Util_Equiv_O_O__Z(G__1948000051__10_, tmp20) { var e__11 any; var tmp21 *lang.Var


						A_arbace_c2a_text_A_Init(); tmp21 = A_arbace_c2a_text_A_const_41; e__11 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)
						var tmp22 *jrt.StringBuilder = jrt.StringBuilder_Cast(sb__4); var tmp23 *lang.Var; A_arbace_c2a_text_A_Init(); tmp23 = A_arbace_c2a_text_A_const_65; jrt.NN(tmp22).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O_O_O_O__O(s__0, i__5, features__1, jrt.Long_ValueOf_J__Long(depth__6).Ref())))
						i__5, depth__6 = e__11, depth__6; continue L1 }
//line :188:1
					default:
					}




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), depth__6; continue L1 }
//line :182:1
				case 40: var tmp24 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp25 any; A_arbace_c2a_text_A_Init(); tmp25 = A_arbace_c2a_text_A_const_19; if lang.Util_Equiv_O_O__Z(tmp24, tmp25) {



					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Inc_J__J(depth__6); continue L1 }
//line :182:1
				case 41: var tmp26 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp27 any; A_arbace_c2a_text_A_Init(); tmp27 = A_arbace_c2a_text_A_const_20; if lang.Util_Equiv_O_O__Z(tmp26, tmp27) {




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(depth__6)); continue L1 }
//line :182:1
				case 59: var tmp28 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp29 any; A_arbace_c2a_text_A_Init(); tmp29 = A_arbace_c2a_text_A_const_21; if lang.Util_Equiv_O_O__Z(tmp28, tmp29) {

					var tmp30 lang.IFn = lang.IFn_Cast(copy__8); var tmp31 *lang.Var; A_arbace_c2a_text_A_Init(); tmp31 = A_arbace_c2a_text_A_const_40; i__5, depth__6 = tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 91: var tmp32 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp33 any; A_arbace_c2a_text_A_Init(); tmp33 = A_arbace_c2a_text_A_const_23; if lang.Util_Equiv_O_O__Z(tmp32, tmp33) {



					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Inc_J__J(depth__6); continue L1 }
//line :182:1
				case 92: var tmp34 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp35 any; A_arbace_c2a_text_A_Init(); tmp35 = A_arbace_c2a_text_A_const_24; if lang.Util_Equiv_O_O__Z(tmp34, tmp35) {


					var tmp36 lang.IFn = lang.IFn_Cast(copy__8); var tmp37 *lang.Var; A_arbace_c2a_text_A_Init(); tmp37 = A_arbace_c2a_text_A_const_53; i__5, depth__6 = tmp36.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 93: var tmp38 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp39 any; A_arbace_c2a_text_A_Init(); tmp39 = A_arbace_c2a_text_A_const_25; if lang.Util_Equiv_O_O__Z(tmp38, tmp39) {




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(depth__6)); continue L1 }
//line :182:1
				case 123: var tmp40 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp41 any; A_arbace_c2a_text_A_Init(); tmp41 = A_arbace_c2a_text_A_const_28; if lang.Util_Equiv_O_O__Z(tmp40, tmp41) {



					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Inc_J__J(depth__6); continue L1 }
//line :182:1
				case 125: var tmp42 any = jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(); var tmp43 any; A_arbace_c2a_text_A_Init(); tmp43 = A_arbace_c2a_text_A_const_29; if lang.Util_Equiv_O_O__Z(tmp42, tmp43) {




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(depth__6)); continue L1 }
//line :182:1
				default:
				}











				var tmp44 lang.IFn = lang.IFn_Cast(copy__8); var tmp45 any; var tmp46 *lang.Var; A_arbace_c2a_text_A_Init(); tmp46 = A_arbace_c2a_text_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(c__7).Ref())) { tmp45 = lang.Numbers_Inc_O__Number(i__5) } else { var tmp47 *lang.Var; A_arbace_c2a_text_A_Init(); tmp47 = A_arbace_c2a_text_A_const_35; tmp45 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O_O__O(s__0, i__5) }; i__5, depth__6 = tmp44.Invoke_O__O(tmp45), depth__6; continue L1 } } } }
//line :168:1
	panic("a2g: unreachable") }
//line :168:1
func (t *A_arbace_c2a_text_resolve_conditionals_A) Invoke_O_O__O(self, s__0 any) any {



	var tmp1 *lang.Var; A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_58; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_66; return tmp2.Invoke_O_O__O(s__0, tmp3)
}







func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A { A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_Init(); t := &A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :181:1
func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :181:1
func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Invoke_O_O__O(self, j__1 any) any { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I(t.F_i), lang.RT_IntCast_O__I(j__1)); return j__1 }

















func A_arbace_c2a_text_code_tokens_A_New() *A_arbace_c2a_text_code_tokens_A { A_arbace_c2a_text_code_tokens_A_Init(); t := &A_arbace_c2a_text_code_tokens_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_c2a_text_code_tokens_A) Ctor() {}
//line :199:1
func (t *A_arbace_c2a_text_code_tokens_A) Invoke_O_O__O(self, s__0 any) any { { var n__2 int32 = lang.RT_Count_O__I(s__0); var i__3 any = lang.RT_Box_J__Number(0); var out__4 any; var tmp1 *lang.Var




	A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_67; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentVector; lang.PersistentVector_Init(); tmp3 = lang.PersistentVector_EMPTY; out__4 = tmp2.Invoke_O__O(tmp3.Ref())
//line :199:1
L1: for {





	if lang.Numbers_Gte_O_J__Z(i__3, int64(n__2)) {
		var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_68; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(out__4) } else {
//line :205:1
			var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__3)); var tmp5 any


			A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp5)).CharValue__C()) {
				var tmp6 *lang.Var; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_45; i__3, out__4 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
					var tmp7 any; A_arbace_c2a_text_A_Init(); tmp7 = A_arbace_c2a_text_A_const_21; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp7)).CharValue__C()) {

						var tmp8 *lang.Var; A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_40; i__3, out__4 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
							var tmp9 any; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_24; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp9)).CharValue__C()) {


								var tmp10 *lang.Var; A_arbace_c2a_text_A_Init(); tmp10 = A_arbace_c2a_text_A_const_53; i__3, out__4 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
									var tmp11 any; A_arbace_c2a_text_A_Init(); tmp11 = A_arbace_c2a_text_A_const_36; if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(tmp11)).CharValue__C()) { var G__1948000054__6_ any; var tmp12 *lang.Var



										A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_38; G__1948000054__6_ = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__3)); switch lang.Util_Hash_O__I(G__1948000054__6_) { case 33: var tmp13 any; A_arbace_c2a_text_A_Init(); tmp13 = A_arbace_c2a_text_A_const_37; if lang.Util_Equiv_O_O__Z(G__1948000054__6_, tmp13) {

											var tmp14 *lang.Var; A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_40; i__3, out__4 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 }
//line :212:1
										case 34: var tmp15 any; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_O_O__Z(G__1948000054__6_, tmp15) {
											var tmp16 *lang.Var; A_arbace_c2a_text_A_Init(); tmp16 = A_arbace_c2a_text_A_const_45; i__3, out__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__3)), out__4; continue L1 }
//line :212:1
										default:
										}

										i__3, out__4 = lang.Numbers_Inc_O__Number(i__3), out__4; continue L1 } else {
//line :208:1
											var tmp17 *lang.Var; A_arbace_c2a_text_A_Init(); tmp17 = A_arbace_c2a_text_A_const_32; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(c__5).Ref())) {







												i__3, out__4 = lang.Numbers_Inc_O__Number(i__3), out__4; continue L1 } else {
//line :208:1
													var tmp18 any; A_arbace_c2a_text_A_Init(); tmp18 = A_arbace_c2a_text_A_const_69; var tmp19 lang.IFn = lang.IFn_Cast(tmp18); if jrt.A2g_Truth(tmp19.Invoke_O__O(jrt.Character_ValueOf_C__Character(c__5).Ref())) {








														i__3, out__4 = lang.Numbers_Inc_O__Number(i__3), out__4; continue L1 } else {
//line :208:1
															var tmp20 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp20 = A_arbace_c2a_text_A_const_34; if tmp20 != nil { var e__6 any; var tmp21 *lang.Var









																A_arbace_c2a_text_A_Init(); tmp21 = A_arbace_c2a_text_A_const_35; e__6 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O_O__O(s__0, i__3); var tmp22 *lang.Var; A_arbace_c2a_text_A_Init(); tmp22 = A_arbace_c2a_text_A_const_70; i__3, out__4 = e__6, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O__O(out__4, lang.Tuple_Create_O_O__IPersistentVector(i__3, e__6)); continue L1 } else {
//line :208:1
																	return nil } } } } } } } } } }; /*line :199:1*/panic("a2g: unreachable") }




















func A_arbace_c2a_text_list_spans_A_New() *A_arbace_c2a_text_list_spans_A { A_arbace_c2a_text_list_spans_A_Init(); t := &A_arbace_c2a_text_list_spans_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_c2a_text_list_spans_A) Ctor() {}
//line :220:1
func (t *A_arbace_c2a_text_list_spans_A) Invoke_O_O_O__O(self, s__0, pred__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var i__4 any = lang.RT_Box_J__Number(0); var out__5 any; lang.PersistentVector_Init(); out__5 = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_O_J__Z(i__4, int64(n__3)) { return out__5 } else { var c__6 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__4)); var tmp1 any


		A_arbace_c2a_text_A_Init(); tmp1 = A_arbace_c2a_text_A_const_18; if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(tmp1)).CharValue__C()) {
			var tmp2 *lang.Var; A_arbace_c2a_text_A_Init(); tmp2 = A_arbace_c2a_text_A_const_45; i__4, out__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
				var tmp3 any; A_arbace_c2a_text_A_Init(); tmp3 = A_arbace_c2a_text_A_const_21; if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(tmp3)).CharValue__C()) {

					var tmp4 *lang.Var; A_arbace_c2a_text_A_Init(); tmp4 = A_arbace_c2a_text_A_const_40; i__4, out__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
						var tmp5 any; A_arbace_c2a_text_A_Init(); tmp5 = A_arbace_c2a_text_A_const_24; if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(tmp5)).CharValue__C()) {


							var tmp6 *lang.Var; A_arbace_c2a_text_A_Init(); tmp6 = A_arbace_c2a_text_A_const_53; i__4, out__5 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
								var tmp7 bool; var and__1927000168__auto____7 bool; var tmp8 any



								A_arbace_c2a_text_A_Init(); tmp8 = A_arbace_c2a_text_A_const_36; and__1927000168__auto____7 = lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(tmp8)).CharValue__C()); if and__1927000168__auto____7 { var tmp9 any; A_arbace_c2a_text_A_Init(); tmp9 = A_arbace_c2a_text_A_const_18; var tmp10 any = tmp9; var tmp11 *lang.Var; A_arbace_c2a_text_A_Init(); tmp11 = A_arbace_c2a_text_A_const_38; tmp7 = lang.Util_Equiv_O_O__Z(tmp10, lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp7 = and__1927000168__auto____7 }
//line :228:1
								if tmp7 {



									var tmp12 *lang.Var; A_arbace_c2a_text_A_Init(); tmp12 = A_arbace_c2a_text_A_const_45; i__4, out__5 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4)), out__5; continue L1 } else {
//line :228:1
										var tmp13 bool; var and__1927000168__auto____7_2 bool; var tmp14 any




										A_arbace_c2a_text_A_Init(); tmp14 = A_arbace_c2a_text_A_const_36; and__1927000168__auto____7_2 = lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(tmp14)).CharValue__C()); if and__1927000168__auto____7_2 { var tmp15 any; A_arbace_c2a_text_A_Init(); tmp15 = A_arbace_c2a_text_A_const_37; var tmp16 any = tmp15; var tmp17 *lang.Var; A_arbace_c2a_text_A_Init(); tmp17 = A_arbace_c2a_text_A_const_38; tmp13 = lang.Util_Equiv_O_O__Z(tmp16, lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp13 = and__1927000168__auto____7_2 }
//line :228:1
										if tmp13 {




											var tmp18 *lang.Var; A_arbace_c2a_text_A_Init(); tmp18 = A_arbace_c2a_text_A_const_40; i__4, out__5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
												var tmp19 any; A_arbace_c2a_text_A_Init(); tmp19 = A_arbace_c2a_text_A_const_19; if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(tmp19)).CharValue__C()) { var h__7 any; var tmp20 *lang.Var






													A_arbace_c2a_text_A_Init(); tmp20 = A_arbace_c2a_text_A_const_42; h__7 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))
//line :228:1
													var head__8 any; var tmp21 any; var and__1927000168__auto____8 bool = lang.Numbers_Lt_O_J__Z(h__7, int64(n__3))







													if and__1927000168__auto____8 { var tmp22 *lang.Var; A_arbace_c2a_text_A_Init(); tmp22 = A_arbace_c2a_text_A_const_31; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_c2a_text_A_Init(); tmp24 = A_arbace_c2a_text_A_const_32; tmp21 = tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(h__7))).Ref())) } else { tmp21 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() }; if jrt.A2g_Truth(tmp21) {
														var tmp25 *lang.Var; A_arbace_c2a_text_A_Init(); tmp25 = A_arbace_c2a_text_A_const_12; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_c2a_text_A_Init(); tmp27 = A_arbace_c2a_text_A_const_35; head__8 = tmp26.Invoke_O_O_O__O(s__0, h__7, lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O_O__O(s__0, h__7)) } else {
//line :236:1
															head__8 = nil
														}
													var tmp28 any; var and__1927000168__auto____9 any = head__8; if jrt.A2g_Truth(and__1927000168__auto____9) { tmp28 = lang.IFn_Cast(pred__1).Invoke_O__O(head__8) } else { tmp28 = and__1927000168__auto____9 }; if jrt.A2g_Truth(tmp28) { var e__9 any; var tmp29 *lang.Var
														A_arbace_c2a_text_A_Init(); tmp29 = A_arbace_c2a_text_A_const_41; e__9 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); var tmp30 *lang.Var; A_arbace_c2a_text_A_Init(); tmp30 = A_arbace_c2a_text_A_const_6; i__4, out__5 = e__9, lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O__O(out__5, lang.Tuple_Create_O_O__IPersistentVector(i__4, e__9)); continue L1 } else {
															i__4, out__5 = lang.Numbers_Inc_O__Number(i__4), out__5; continue L1 } } else {
//line :228:1
																var tmp31 *lang.Keyword; A_arbace_c2a_text_A_Init(); tmp31 = A_arbace_c2a_text_A_const_34; if tmp31 != nil {












																	i__4, out__5 = lang.Numbers_Inc_O__Number(i__4), out__5; continue L1 } else {
//line :228:1
																		return nil } } } } } } } } } }; /*line :220:1*/panic("a2g: unreachable") }







type A_arbace_c2a_text_A struct{ jrt.Object }

var A_arbace_c2a_text_A_const_0 *lang.Var

var A_arbace_c2a_text_A_const_1 *lang.Var

var A_arbace_c2a_text_A_const_2 any

var A_arbace_c2a_text_A_const_3 any

var A_arbace_c2a_text_A_const_4 *lang.Var

var A_arbace_c2a_text_A_const_5 *lang.Var

var A_arbace_c2a_text_A_const_6 *lang.Var

var A_arbace_c2a_text_A_const_7 any

var A_arbace_c2a_text_A_const_8 *lang.Var

var A_arbace_c2a_text_A_const_9 *lang.Var

var A_arbace_c2a_text_A_const_10 *lang.Var

var A_arbace_c2a_text_A_const_11 any

var A_arbace_c2a_text_A_const_12 *lang.Var

var A_arbace_c2a_text_A_const_13 any

var A_arbace_c2a_text_A_const_14 *lang.Keyword

var A_arbace_c2a_text_A_const_15 *lang.Keyword

var A_arbace_c2a_text_A_const_16 any

var A_arbace_c2a_text_A_const_17 *lang.Var

var A_arbace_c2a_text_A_const_18 any

var A_arbace_c2a_text_A_const_19 any

var A_arbace_c2a_text_A_const_20 any

var A_arbace_c2a_text_A_const_21 any

var A_arbace_c2a_text_A_const_22 any

var A_arbace_c2a_text_A_const_23 any

var A_arbace_c2a_text_A_const_24 any

var A_arbace_c2a_text_A_const_25 any

var A_arbace_c2a_text_A_const_26 any

var A_arbace_c2a_text_A_const_27 any

var A_arbace_c2a_text_A_const_28 any

var A_arbace_c2a_text_A_const_29 any

var A_arbace_c2a_text_A_const_30 any

var A_arbace_c2a_text_A_const_31 *lang.Var

var A_arbace_c2a_text_A_const_32 *lang.Var

var A_arbace_c2a_text_A_const_33 *lang.Var

var A_arbace_c2a_text_A_const_34 *lang.Keyword

var A_arbace_c2a_text_A_const_35 *lang.Var

var A_arbace_c2a_text_A_const_36 any

var A_arbace_c2a_text_A_const_37 any

var A_arbace_c2a_text_A_const_38 *lang.Var

var A_arbace_c2a_text_A_const_39 any

var A_arbace_c2a_text_A_const_40 *lang.Var

var A_arbace_c2a_text_A_const_41 *lang.Var

var A_arbace_c2a_text_A_const_42 *lang.Var

var A_arbace_c2a_text_A_const_43 *lang.Var

var A_arbace_c2a_text_A_const_44 any

var A_arbace_c2a_text_A_const_45 *lang.Var

var A_arbace_c2a_text_A_const_46 *lang.Var

var A_arbace_c2a_text_A_const_47 any

var A_arbace_c2a_text_A_const_48 *lang.Var

var A_arbace_c2a_text_A_const_49 any

var A_arbace_c2a_text_A_const_50 any

var A_arbace_c2a_text_A_const_51 any

var A_arbace_c2a_text_A_const_52 *lang.Var

var A_arbace_c2a_text_A_const_53 *lang.Var

var A_arbace_c2a_text_A_const_54 *lang.Var

var A_arbace_c2a_text_A_const_55 *lang.Var

var A_arbace_c2a_text_A_const_56 any

var A_arbace_c2a_text_A_const_57 *lang.Var

var A_arbace_c2a_text_A_const_58 *lang.Var

var A_arbace_c2a_text_A_const_59 any

var A_arbace_c2a_text_A_const_60 *lang.Var

var A_arbace_c2a_text_A_const_61 *lang.Keyword

var A_arbace_c2a_text_A_const_62 *lang.Var

var A_arbace_c2a_text_A_const_63 *lang.Var

var A_arbace_c2a_text_A_const_64 *lang.Var

var A_arbace_c2a_text_A_const_65 *lang.Var

var A_arbace_c2a_text_A_const_66 any

var A_arbace_c2a_text_A_const_67 *lang.Var

var A_arbace_c2a_text_A_const_68 *lang.Var

var A_arbace_c2a_text_A_const_69 any

var A_arbace_c2a_text_A_const_70 *lang.Var

var A_arbace_c2a_text_A_init jrt.ClassInit

func A_arbace_c2a_text_A_Init() { if !A_arbace_c2a_text_A_init.Done() { A_arbace_c2a_text_A_init.Run(A_arbace_c2a_text_A_clinit) } }

func A_arbace_c2a_text_A_clinit() { A_arbace_c2a_text_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_c2a_text_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_c2a_text_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_text_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_c2a_text_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_6); A_arbace_c2a_text_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_7); A_arbace_c2a_text_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_c2a_text_A_const_7 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_c2a_text_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_c2a_text_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_c2a_text_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_c2a_text_A_const_11 = jrt.Character_ValueOf_C__Character(10).Ref(); A_arbace_c2a_text_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_c2a_text_A_const_13 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_c2a_text_A_const_14 = lang.RT_Keyword_String_String__Keyword(nil, Lit_16); A_arbace_c2a_text_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_17); A_arbace_c2a_text_A_const_16 = jrt.Character_ValueOf_C__Character(44).Ref(); A_arbace_c2a_text_A_const_17 = lang.RT_Var_String_String__Var(Lit_9, Lit_18); A_arbace_c2a_text_A_const_18 = jrt.Character_ValueOf_C__Character(34).Ref(); A_arbace_c2a_text_A_const_19 = jrt.Character_ValueOf_C__Character(40).Ref(); A_arbace_c2a_text_A_const_20 = jrt.Character_ValueOf_C__Character(41).Ref(); A_arbace_c2a_text_A_const_21 = jrt.Character_ValueOf_C__Character(59).Ref(); A_arbace_c2a_text_A_const_22 = jrt.Character_ValueOf_C__Character(64).Ref(); A_arbace_c2a_text_A_const_23 = jrt.Character_ValueOf_C__Character(91).Ref(); A_arbace_c2a_text_A_const_24 = jrt.Character_ValueOf_C__Character(92).Ref(); A_arbace_c2a_text_A_const_25 = jrt.Character_ValueOf_C__Character(93).Ref(); A_arbace_c2a_text_A_const_26 = jrt.Character_ValueOf_C__Character(94).Ref(); A_arbace_c2a_text_A_const_27 = jrt.Character_ValueOf_C__Character(96).Ref(); A_arbace_c2a_text_A_const_28 = jrt.Character_ValueOf_C__Character(123).Ref(); A_arbace_c2a_text_A_const_29 = jrt.Character_ValueOf_C__Character(125).Ref(); A_arbace_c2a_text_A_const_30 = jrt.Character_ValueOf_C__Character(126).Ref(); A_arbace_c2a_text_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_c2a_text_A_const_32 = lang.RT_Var_String_String__Var(Lit_9, Lit_20); A_arbace_c2a_text_A_const_33 = lang.RT_Var_String_String__Var(Lit_9, Lit_21); A_arbace_c2a_text_A_const_34 = lang.RT_Keyword_String_String__Keyword(nil, Lit_22); A_arbace_c2a_text_A_const_35 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); A_arbace_c2a_text_A_const_36 = jrt.Character_ValueOf_C__Character(35).Ref(); A_arbace_c2a_text_A_const_37 = jrt.Character_ValueOf_C__Character(33).Ref(); A_arbace_c2a_text_A_const_38 = lang.RT_Var_String_String__Var(Lit_9, Lit_24); A_arbace_c2a_text_A_const_39 = jrt.Character_ValueOf_C__Character(95).Ref(); A_arbace_c2a_text_A_const_40 = lang.RT_Var_String_String__Var(Lit_9, Lit_25); A_arbace_c2a_text_A_const_41 = lang.RT_Var_String_String__Var(Lit_9, Lit_26); A_arbace_c2a_text_A_const_42 = lang.RT_Var_String_String__Var(Lit_9, Lit_27); A_arbace_c2a_text_A_const_43 = lang.RT_Var_String_String__Var(Lit_9, Lit_28); A_arbace_c2a_text_A_const_44 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(41).Ref(), jrt.Character_ValueOf_C__Character(93).Ref(), jrt.Character_ValueOf_C__Character(125).Ref())).Ref(); A_arbace_c2a_text_A_const_45 = lang.RT_Var_String_String__Var(Lit_9, Lit_29); A_arbace_c2a_text_A_const_46 = lang.RT_Var_String_String__Var(Lit_9, Lit_30); A_arbace_c2a_text_A_const_47 = jrt.Character_ValueOf_C__Character(39).Ref(); A_arbace_c2a_text_A_const_48 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); A_arbace_c2a_text_A_const_49 = jrt.Character_ValueOf_C__Character(58).Ref(); A_arbace_c2a_text_A_const_50 = jrt.Character_ValueOf_C__Character(61).Ref(); A_arbace_c2a_text_A_const_51 = jrt.Character_ValueOf_C__Character(63).Ref(); A_arbace_c2a_text_A_const_52 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); A_arbace_c2a_text_A_const_53 = lang.RT_Var_String_String__Var(Lit_9, Lit_33); A_arbace_c2a_text_A_const_54 = lang.RT_Var_String_String__Var(Lit_3, Lit_34); A_arbace_c2a_text_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_c2a_text_A_const_56 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_c2a_text_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_c2a_text_A_const_58 = lang.RT_Var_String_String__Var(Lit_9, Lit_37); A_arbace_c2a_text_A_const_59 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(40).Ref(), jrt.Character_ValueOf_C__Character(91).Ref())).Ref(); A_arbace_c2a_text_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_c2a_text_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_39); A_arbace_c2a_text_A_const_62 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); A_arbace_c2a_text_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_5); A_arbace_c2a_text_A_const_64 = lang.RT_Var_String_String__Var(Lit_3, Lit_41); A_arbace_c2a_text_A_const_65 = lang.RT_Var_String_String__Var(Lit_9, Lit_42); A_arbace_c2a_text_A_const_66 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref())).Ref(); A_arbace_c2a_text_A_const_67 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_c2a_text_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_c2a_text_A_const_69 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(96).Ref(), jrt.Character_ValueOf_C__Character(39).Ref())).Ref(); A_arbace_c2a_text_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_46) }

func A_arbace_c2a_text_A_New() *A_arbace_c2a_text_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text_A) Ctor() {}

func (t *A_arbace_c2a_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_A_class }

func (t *A_arbace_c2a_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_A); return ok }

func A_arbace_c2a_text_A_Cast(x any) *A_arbace_c2a_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_A_class)) }; return v }



type A_arbace_c2a_text_at_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_at_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_at_A_fn_class *jrt.Class

var A_arbace_c2a_text_at_A_init jrt.ClassInit

func A_arbace_c2a_text_at_A_Init() { if !A_arbace_c2a_text_at_A_init.Done() { A_arbace_c2a_text_at_A_init.Run(A_arbace_c2a_text_at_A_clinit) } }

func A_arbace_c2a_text_at_A_clinit() { A_arbace_c2a_text_at_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_at_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_at_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_at_A_class }

func (t *A_arbace_c2a_text_at_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_at_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_at_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_at_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_at_A); return ok }

func A_arbace_c2a_text_at_A_Cast(x any) *A_arbace_c2a_text_at_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_at_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_at_A_class)) }; return v }



type A_arbace_c2a_text_branches_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_branches_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_branches_A_fn_class *jrt.Class

var A_arbace_c2a_text_branches_A_init jrt.ClassInit

func A_arbace_c2a_text_branches_A_Init() { if !A_arbace_c2a_text_branches_A_init.Done() { A_arbace_c2a_text_branches_A_init.Run(A_arbace_c2a_text_branches_A_clinit) } }

func A_arbace_c2a_text_branches_A_clinit() { A_arbace_c2a_text_branches_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_branches_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_branches_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_branches_A_class }

func (t *A_arbace_c2a_text_branches_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_branches_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_branches_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_branches_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_branches_A); return ok }

func A_arbace_c2a_text_branches_A_Cast(x any) *A_arbace_c2a_text_branches_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_branches_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_branches_A_class)) }; return v }



type A_arbace_c2a_text_char_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_char_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_char_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_char_end_A_init jrt.ClassInit

func A_arbace_c2a_text_char_end_A_Init() { if !A_arbace_c2a_text_char_end_A_init.Done() { A_arbace_c2a_text_char_end_A_init.Run(A_arbace_c2a_text_char_end_A_clinit) } }

func A_arbace_c2a_text_char_end_A_clinit() { A_arbace_c2a_text_char_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_char_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_char_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_char_end_A_class }

func (t *A_arbace_c2a_text_char_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_char_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_char_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_char_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_char_end_A); return ok }

func A_arbace_c2a_text_char_end_A_Cast(x any) *A_arbace_c2a_text_char_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_char_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_char_end_A_class)) }; return v }



type A_arbace_c2a_text_code_tokens_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_code_tokens_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_code_tokens_A_fn_class *jrt.Class

var A_arbace_c2a_text_code_tokens_A_init jrt.ClassInit

func A_arbace_c2a_text_code_tokens_A_Init() { if !A_arbace_c2a_text_code_tokens_A_init.Done() { A_arbace_c2a_text_code_tokens_A_init.Run(A_arbace_c2a_text_code_tokens_A_clinit) } }

func A_arbace_c2a_text_code_tokens_A_clinit() { A_arbace_c2a_text_code_tokens_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_code_tokens_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_code_tokens_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_code_tokens_A_class }

func (t *A_arbace_c2a_text_code_tokens_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_code_tokens_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_code_tokens_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_code_tokens_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_code_tokens_A); return ok }

func A_arbace_c2a_text_code_tokens_A_Cast(x any) *A_arbace_c2a_text_code_tokens_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_code_tokens_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_code_tokens_A_class)) }; return v }



type A_arbace_c2a_text_coll_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_coll_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_coll_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_coll_end_A_init jrt.ClassInit

func A_arbace_c2a_text_coll_end_A_Init() { if !A_arbace_c2a_text_coll_end_A_init.Done() { A_arbace_c2a_text_coll_end_A_init.Run(A_arbace_c2a_text_coll_end_A_clinit) } }

func A_arbace_c2a_text_coll_end_A_clinit() { A_arbace_c2a_text_coll_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_coll_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_coll_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_coll_end_A_class }

func (t *A_arbace_c2a_text_coll_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_coll_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_coll_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_coll_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_coll_end_A); return ok }

func A_arbace_c2a_text_coll_end_A_Cast(x any) *A_arbace_c2a_text_coll_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_coll_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_coll_end_A_class)) }; return v }



type A_arbace_c2a_text_cond_open_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_cond_open_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_cond_open_A_fn_class *jrt.Class

var A_arbace_c2a_text_cond_open_A_init jrt.ClassInit

func A_arbace_c2a_text_cond_open_A_Init() { if !A_arbace_c2a_text_cond_open_A_init.Done() { A_arbace_c2a_text_cond_open_A_init.Run(A_arbace_c2a_text_cond_open_A_clinit) } }

func A_arbace_c2a_text_cond_open_A_clinit() { A_arbace_c2a_text_cond_open_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_cond_open_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_cond_open_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_cond_open_A_class }

func (t *A_arbace_c2a_text_cond_open_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_cond_open_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_cond_open_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_cond_open_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_cond_open_A); return ok }

func A_arbace_c2a_text_cond_open_A_Cast(x any) *A_arbace_c2a_text_cond_open_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_cond_open_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_cond_open_A_class)) }; return v }



type A_arbace_c2a_text_cond_open_fn__1948000030_A struct{ jrt.Object; F_i, F_s any }

func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class *jrt.Class

var A_arbace_c2a_text_cond_open_fn__1948000030_A_init jrt.ClassInit

func A_arbace_c2a_text_cond_open_fn__1948000030_A_Init() { if !A_arbace_c2a_text_cond_open_fn__1948000030_A_init.Done() { A_arbace_c2a_text_cond_open_fn__1948000030_A_init.Run(A_arbace_c2a_text_cond_open_fn__1948000030_A_clinit) } }

func A_arbace_c2a_text_cond_open_fn__1948000030_A_clinit() { A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_cond_open_fn__1948000030_A_class }

func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_cond_open_fn__1948000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_cond_open_fn__1948000030_A); return ok }

func A_arbace_c2a_text_cond_open_fn__1948000030_A_Cast(x any) *A_arbace_c2a_text_cond_open_fn__1948000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_cond_open_fn__1948000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_cond_open_fn__1948000030_A_class)) }; return v }



type A_arbace_c2a_text_eval1948000004_A struct{ jrt.Object }

func A_arbace_c2a_text_eval1948000004_A_New() *A_arbace_c2a_text_eval1948000004_A { t := &A_arbace_c2a_text_eval1948000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text_eval1948000004_A) Ctor() {}

func (t *A_arbace_c2a_text_eval1948000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_eval1948000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_eval1948000004_A_class }

func (t *A_arbace_c2a_text_eval1948000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_eval1948000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_eval1948000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_eval1948000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_eval1948000004_A); return ok }

func A_arbace_c2a_text_eval1948000004_A_Cast(x any) *A_arbace_c2a_text_eval1948000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_eval1948000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_eval1948000004_A_class)) }; return v }



type A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_fn_class *jrt.Class

var A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_init jrt.ClassInit

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_Init() { if !A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_init.Done() { A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_init.Run(A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_clinit) } }

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_clinit() { A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class }

func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A); return ok }

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_Cast(x any) *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class)) }; return v }



type A_arbace_c2a_text_eval1948000008_A struct{ jrt.Object }

func A_arbace_c2a_text_eval1948000008_A_New() *A_arbace_c2a_text_eval1948000008_A { t := &A_arbace_c2a_text_eval1948000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text_eval1948000008_A) Ctor() {}

func (t *A_arbace_c2a_text_eval1948000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_eval1948000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_eval1948000008_A_class }

func (t *A_arbace_c2a_text_eval1948000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_eval1948000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_eval1948000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_eval1948000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_eval1948000008_A); return ok }

func A_arbace_c2a_text_eval1948000008_A_Cast(x any) *A_arbace_c2a_text_eval1948000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_eval1948000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_eval1948000008_A_class)) }; return v }



type A_arbace_c2a_text_eval1948000008_fn__1948000009_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Is_Compiler_AOTF0() {}

var A_arbace_c2a_text_eval1948000008_fn__1948000009_A_fn_class *jrt.Class

var A_arbace_c2a_text_eval1948000008_fn__1948000009_A_init jrt.ClassInit

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_Init() { if !A_arbace_c2a_text_eval1948000008_fn__1948000009_A_init.Done() { A_arbace_c2a_text_eval1948000008_fn__1948000009_A_init.Run(A_arbace_c2a_text_eval1948000008_fn__1948000009_A_clinit) } }

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_clinit() { A_arbace_c2a_text_eval1948000008_fn__1948000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class }

func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_eval1948000008_fn__1948000009_A); return ok }

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_Cast(x any) *A_arbace_c2a_text_eval1948000008_fn__1948000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_eval1948000008_fn__1948000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class)) }; return v }



type A_arbace_c2a_text_fail_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_fail_A) Is_Compiler_AOTF3() {}

var A_arbace_c2a_text_fail_A_fn_class *jrt.Class

var A_arbace_c2a_text_fail_A_init jrt.ClassInit

func A_arbace_c2a_text_fail_A_Init() { if !A_arbace_c2a_text_fail_A_init.Done() { A_arbace_c2a_text_fail_A_init.Run(A_arbace_c2a_text_fail_A_clinit) } }

func A_arbace_c2a_text_fail_A_clinit() { A_arbace_c2a_text_fail_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_fail_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_fail_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_fail_A_class }

func (t *A_arbace_c2a_text_fail_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_fail_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_fail_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_fail_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_fail_A); return ok }

func A_arbace_c2a_text_fail_A_Cast(x any) *A_arbace_c2a_text_fail_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_fail_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_fail_A_class)) }; return v }



type A_arbace_c2a_text_fail_fn__1948000013_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_fail_fn__1948000013_A_fn_class *jrt.Class

var A_arbace_c2a_text_fail_fn__1948000013_A_init jrt.ClassInit

func A_arbace_c2a_text_fail_fn__1948000013_A_Init() { if !A_arbace_c2a_text_fail_fn__1948000013_A_init.Done() { A_arbace_c2a_text_fail_fn__1948000013_A_init.Run(A_arbace_c2a_text_fail_fn__1948000013_A_clinit) } }

func A_arbace_c2a_text_fail_fn__1948000013_A_clinit() { A_arbace_c2a_text_fail_fn__1948000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_fail_fn__1948000013_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_fail_fn__1948000013_A_class }

func (t *A_arbace_c2a_text_fail_fn__1948000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_fail_fn__1948000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_fail_fn__1948000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_fail_fn__1948000013_A); return ok }

func A_arbace_c2a_text_fail_fn__1948000013_A_Cast(x any) *A_arbace_c2a_text_fail_fn__1948000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_fail_fn__1948000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_fail_fn__1948000013_A_class)) }; return v }



type A_arbace_c2a_text_form_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_form_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_form_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_form_end_A_init jrt.ClassInit

func A_arbace_c2a_text_form_end_A_Init() { if !A_arbace_c2a_text_form_end_A_init.Done() { A_arbace_c2a_text_form_end_A_init.Run(A_arbace_c2a_text_form_end_A_clinit) } }

func A_arbace_c2a_text_form_end_A_clinit() { A_arbace_c2a_text_form_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_form_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_form_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_form_end_A_class }

func (t *A_arbace_c2a_text_form_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_form_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_form_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_form_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_form_end_A); return ok }

func A_arbace_c2a_text_form_end_A_Cast(x any) *A_arbace_c2a_text_form_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_form_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_form_end_A_class)) }; return v }



type A_arbace_c2a_text_line_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_line_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_line_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_line_end_A_init jrt.ClassInit

func A_arbace_c2a_text_line_end_A_Init() { if !A_arbace_c2a_text_line_end_A_init.Done() { A_arbace_c2a_text_line_end_A_init.Run(A_arbace_c2a_text_line_end_A_clinit) } }

func A_arbace_c2a_text_line_end_A_clinit() { A_arbace_c2a_text_line_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_line_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_line_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_line_end_A_class }

func (t *A_arbace_c2a_text_line_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_line_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_line_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_line_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_line_end_A); return ok }

func A_arbace_c2a_text_line_end_A_Cast(x any) *A_arbace_c2a_text_line_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_line_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_line_end_A_class)) }; return v }



type A_arbace_c2a_text_list_spans_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_list_spans_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_list_spans_A_fn_class *jrt.Class

var A_arbace_c2a_text_list_spans_A_init jrt.ClassInit

func A_arbace_c2a_text_list_spans_A_Init() { if !A_arbace_c2a_text_list_spans_A_init.Done() { A_arbace_c2a_text_list_spans_A_init.Run(A_arbace_c2a_text_list_spans_A_clinit) } }

func A_arbace_c2a_text_list_spans_A_clinit() { A_arbace_c2a_text_list_spans_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_list_spans_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_list_spans_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_list_spans_A_class }

func (t *A_arbace_c2a_text_list_spans_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_list_spans_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_list_spans_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_list_spans_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_list_spans_A); return ok }

func A_arbace_c2a_text_list_spans_A_Cast(x any) *A_arbace_c2a_text_list_spans_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_list_spans_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_list_spans_A_class)) }; return v }



type A_arbace_c2a_text_next_form_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_next_form_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_next_form_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_next_form_end_A_init jrt.ClassInit

func A_arbace_c2a_text_next_form_end_A_Init() { if !A_arbace_c2a_text_next_form_end_A_init.Done() { A_arbace_c2a_text_next_form_end_A_init.Run(A_arbace_c2a_text_next_form_end_A_clinit) } }

func A_arbace_c2a_text_next_form_end_A_clinit() { A_arbace_c2a_text_next_form_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_74, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_next_form_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_next_form_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_next_form_end_A_class }

func (t *A_arbace_c2a_text_next_form_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_next_form_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_next_form_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_next_form_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_next_form_end_A); return ok }

func A_arbace_c2a_text_next_form_end_A_Cast(x any) *A_arbace_c2a_text_next_form_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_next_form_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_next_form_end_A_class)) }; return v }



type A_arbace_c2a_text_resolve_conditionals_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_resolve_conditionals_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_c2a_text_resolve_conditionals_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_resolve_conditionals_A_fn_class *jrt.Class

var A_arbace_c2a_text_resolve_conditionals_A_init jrt.ClassInit

func A_arbace_c2a_text_resolve_conditionals_A_Init() { if !A_arbace_c2a_text_resolve_conditionals_A_init.Done() { A_arbace_c2a_text_resolve_conditionals_A_init.Run(A_arbace_c2a_text_resolve_conditionals_A_clinit) } }

func A_arbace_c2a_text_resolve_conditionals_A_clinit() { A_arbace_c2a_text_resolve_conditionals_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_resolve_conditionals_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_resolve_conditionals_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_resolve_conditionals_A_class }

func (t *A_arbace_c2a_text_resolve_conditionals_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_resolve_conditionals_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_resolve_conditionals_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_resolve_conditionals_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_resolve_conditionals_A); return ok }

func A_arbace_c2a_text_resolve_conditionals_A_Cast(x any) *A_arbace_c2a_text_resolve_conditionals_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_resolve_conditionals_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_resolve_conditionals_A_class)) }; return v }



type A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A struct{ jrt.Object; F_i, F_sb, F_s any }

func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class *jrt.Class

var A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_init jrt.ClassInit

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_Init() { if !A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_init.Done() { A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_init.Run(A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_clinit) } }

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_clinit() { A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class }

func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A); return ok }

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_Cast(x any) *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class)) }; return v }



type A_arbace_c2a_text_selected_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_selected_A) Is_Compiler_AOTF4() {}

var A_arbace_c2a_text_selected_A_fn_class *jrt.Class

var A_arbace_c2a_text_selected_A_init jrt.ClassInit

func A_arbace_c2a_text_selected_A_Init() { if !A_arbace_c2a_text_selected_A_init.Done() { A_arbace_c2a_text_selected_A_init.Run(A_arbace_c2a_text_selected_A_clinit) } }

func A_arbace_c2a_text_selected_A_clinit() { A_arbace_c2a_text_selected_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_selected_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_selected_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_selected_A_class }

func (t *A_arbace_c2a_text_selected_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_selected_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_selected_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_selected_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_selected_A); return ok }

func A_arbace_c2a_text_selected_A_Cast(x any) *A_arbace_c2a_text_selected_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_selected_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_selected_A_class)) }; return v }



type A_arbace_c2a_text_selected_fn__1948000038_A struct{ jrt.Object; F_features any }

func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_selected_fn__1948000038_A_fn_class *jrt.Class

var A_arbace_c2a_text_selected_fn__1948000038_A_init jrt.ClassInit

func A_arbace_c2a_text_selected_fn__1948000038_A_Init() { if !A_arbace_c2a_text_selected_fn__1948000038_A_init.Done() { A_arbace_c2a_text_selected_fn__1948000038_A_init.Run(A_arbace_c2a_text_selected_fn__1948000038_A_clinit) } }

func A_arbace_c2a_text_selected_fn__1948000038_A_clinit() { A_arbace_c2a_text_selected_fn__1948000038_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_82, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_selected_fn__1948000038_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_selected_fn__1948000038_A_class }

func (t *A_arbace_c2a_text_selected_fn__1948000038_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_selected_fn__1948000038_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_selected_fn__1948000038_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_selected_fn__1948000038_A); return ok }

func A_arbace_c2a_text_selected_fn__1948000038_A_Cast(x any) *A_arbace_c2a_text_selected_fn__1948000038_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_selected_fn__1948000038_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_selected_fn__1948000038_A_class)) }; return v }



type A_arbace_c2a_text_skip_ws_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_skip_ws_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_skip_ws_A_fn_class *jrt.Class

var A_arbace_c2a_text_skip_ws_A_init jrt.ClassInit

func A_arbace_c2a_text_skip_ws_A_Init() { if !A_arbace_c2a_text_skip_ws_A_init.Done() { A_arbace_c2a_text_skip_ws_A_init.Run(A_arbace_c2a_text_skip_ws_A_clinit) } }

func A_arbace_c2a_text_skip_ws_A_clinit() { A_arbace_c2a_text_skip_ws_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_83, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_skip_ws_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_skip_ws_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_skip_ws_A_class }

func (t *A_arbace_c2a_text_skip_ws_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_skip_ws_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_skip_ws_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_skip_ws_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_skip_ws_A); return ok }

func A_arbace_c2a_text_skip_ws_A_Cast(x any) *A_arbace_c2a_text_skip_ws_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_skip_ws_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_skip_ws_A_class)) }; return v }



type A_arbace_c2a_text_string_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_string_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_string_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_string_end_A_init jrt.ClassInit

func A_arbace_c2a_text_string_end_A_Init() { if !A_arbace_c2a_text_string_end_A_init.Done() { A_arbace_c2a_text_string_end_A_init.Run(A_arbace_c2a_text_string_end_A_clinit) } }

func A_arbace_c2a_text_string_end_A_clinit() { A_arbace_c2a_text_string_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_84, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_string_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_string_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_string_end_A_class }

func (t *A_arbace_c2a_text_string_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_string_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_string_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_string_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_string_end_A); return ok }

func A_arbace_c2a_text_string_end_A_Cast(x any) *A_arbace_c2a_text_string_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_string_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_string_end_A_class)) }; return v }



type A_arbace_c2a_text_terminating_QMARK__A struct{ jrt.Object }

func (t *A_arbace_c2a_text_terminating_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_terminating_QMARK__A_fn_class *jrt.Class

var A_arbace_c2a_text_terminating_QMARK__A_init jrt.ClassInit

func A_arbace_c2a_text_terminating_QMARK__A_Init() { if !A_arbace_c2a_text_terminating_QMARK__A_init.Done() { A_arbace_c2a_text_terminating_QMARK__A_init.Run(A_arbace_c2a_text_terminating_QMARK__A_clinit) } }

func A_arbace_c2a_text_terminating_QMARK__A_clinit() { A_arbace_c2a_text_terminating_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_86, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_terminating_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_terminating_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_terminating_QMARK__A_class }

func (t *A_arbace_c2a_text_terminating_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_terminating_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_terminating_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_terminating_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_terminating_QMARK__A); return ok }

func A_arbace_c2a_text_terminating_QMARK__A_Cast(x any) *A_arbace_c2a_text_terminating_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_terminating_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_terminating_QMARK__A_class)) }; return v }



type A_arbace_c2a_text_token_end_A struct{ jrt.Object }

func (t *A_arbace_c2a_text_token_end_A) Is_Compiler_AOTF2() {}

var A_arbace_c2a_text_token_end_A_fn_class *jrt.Class

var A_arbace_c2a_text_token_end_A_init jrt.ClassInit

func A_arbace_c2a_text_token_end_A_Init() { if !A_arbace_c2a_text_token_end_A_init.Done() { A_arbace_c2a_text_token_end_A_init.Run(A_arbace_c2a_text_token_end_A_clinit) } }

func A_arbace_c2a_text_token_end_A_clinit() { A_arbace_c2a_text_token_end_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_87, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_token_end_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_token_end_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_token_end_A_class }

func (t *A_arbace_c2a_text_token_end_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_token_end_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_token_end_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_token_end_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_token_end_A); return ok }

func A_arbace_c2a_text_token_end_A_Cast(x any) *A_arbace_c2a_text_token_end_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_token_end_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_token_end_A_class)) }; return v }



type A_arbace_c2a_text_ws_QMARK__A struct{ jrt.Object }

func (t *A_arbace_c2a_text_ws_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_c2a_text_ws_QMARK__A_fn_class *jrt.Class

var A_arbace_c2a_text_ws_QMARK__A_init jrt.ClassInit

func A_arbace_c2a_text_ws_QMARK__A_Init() { if !A_arbace_c2a_text_ws_QMARK__A_init.Done() { A_arbace_c2a_text_ws_QMARK__A_init.Run(A_arbace_c2a_text_ws_QMARK__A_clinit) } }

func A_arbace_c2a_text_ws_QMARK__A_clinit() { A_arbace_c2a_text_ws_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_88, lang.Compiler_AOTFn_class) }

func (t *A_arbace_c2a_text_ws_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_ws_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_ws_QMARK__A_class }

func (t *A_arbace_c2a_text_ws_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_ws_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_ws_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_ws_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_ws_QMARK__A); return ok }

func A_arbace_c2a_text_ws_QMARK__A_Cast(x any) *A_arbace_c2a_text_ws_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_ws_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_ws_QMARK__A_class)) }; return v }
