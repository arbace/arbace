//line aot_arbace_c2a_text.ae:1
package aot_arbace_c2a_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_New() *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_c2a_text_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_text_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_c2a_text_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_text_A_const_3); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_New() *A_arbace_c2a_text_eval1948000008_fn__1948000009_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_eval1948000008_fn__1948000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_c2a_text_eval1948000008_fn__1948000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_c2a_text_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_5.GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_text_A_const_8), A_arbace_c2a_text_A_const_6.GetRawRoot__O(), A_arbace_c2a_text_A_const_7) }
















func A_arbace_c2a_text_fail_A_New() *A_arbace_c2a_text_fail_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_fail_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_c2a_text_fail_A) Ctor() {}
//line :18:1
func (t *A_arbace_c2a_text_fail_A) Invoke_O_O_O_O__O(self, s__0, i__1, msg__2 any) any { var line__4 int64; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_9.GetRawRoot__O()); var tmp2 any = A_arbace_c2a_text_fail_fn__1948000013_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_c2a_text_fail_fn__1948000013_A_fn_class; if
											fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_c2a_text_fail_fn__1948000013_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_12.GetRawRoot__O()); var tmp5 any = A_arbace_c2a_text_A_const_13; line__4 = lang.Numbers_Inc_J__J(int64(lang.RT_Count_O__I(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), tmp4.Invoke_O_O_O__O(s__0, tmp5, lang.Numbers_Min_O_J__O(i__1, int64(lang.RT_Count_O__I(s__0)))))))); var tmp6 any = A_arbace_c2a_text_A_const_14; var tmp7 any = A_arbace_c2a_text_A_const_15; /*line :18:1*/panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_c2a_text_A_const_10.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_10, nil, Lit_11), jrt.RefArrayOf(jrt.Object_class, msg__2, nil, jrt.Long_ValueOf_J__Long(line__4).Ref(), nil)).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp6, i__1, tmp7, jrt.Long_ValueOf_J__Long(line__4).Ref())))))) }
func A_arbace_c2a_text_fail_fn__1948000013_A_New() *A_arbace_c2a_text_fail_fn__1948000013_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_fail_fn__1948000013_A{}; t.Ctor(); return t }
//line :19:1
func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Ctor() {}
//line :19:1
func (t *A_arbace_c2a_text_fail_fn__1948000013_A) Invoke_O_O__O(self, p1__1948000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(A_arbace_c2a_text_A_const_11, p1__1948000012_SHARP___1)).Ref() }


func A_arbace_c2a_text_ws_QMARK__A_New() *A_arbace_c2a_text_ws_QMARK__A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_ws_QMARK__A{}; t.Ctor(); return t }
//line :22:1
func (t *A_arbace_c2a_text_ws_QMARK__A) Ctor() {}
//line :22:1
func (t *A_arbace_c2a_text_ws_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 bool = jrt.Character_IsWhitespace_C__Z(lang.RT_CharCast_O__C(c__0)); if or__1927000174__auto____2 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____2).Ref() } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(c__0, A_arbace_c2a_text_A_const_16)).Ref() } }

func A_arbace_c2a_text_terminating_QMARK__A_New() *A_arbace_c2a_text_terminating_QMARK__A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_terminating_QMARK__A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_c2a_text_terminating_QMARK__A) Ctor() {}
//line :24:1
func (t *A_arbace_c2a_text_terminating_QMARK__A) Invoke_O_O__O(self, c__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_17.GetRawRoot__O()).Invoke_O__O(c__0); if



	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var G__1948000017__3_ any = c__0; switch lang.Util_Hash_O__I(G__1948000017__3_) { case 34: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_18) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 40: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_19) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 41: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_20) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 59: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_21) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 64: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_22) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 91: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_23) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 92: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_24) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 93: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_25) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 94: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_26) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 96: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_27) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 123: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_28) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 125: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_29) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; case 126: if lang.Util_Equiv_O_O__Z(G__1948000017__3_, A_arbace_c2a_text_A_const_30) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() }; default:}; jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } }

func A_arbace_c2a_text_at_A_New() *A_arbace_c2a_text_at_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_at_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_c2a_text_at_A) Ctor() {}
//line :30:1
func (t *A_arbace_c2a_text_at_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { if lang.Numbers_Lt_O_J__Z(i__1, int64(lang.RT_Count_O__I(s__0))) { return jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__1))).Ref() } else { return nil } }

func A_arbace_c2a_text_line_end_A_New() *A_arbace_c2a_text_line_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_line_end_A{}; t.Ctor(); return t }
//line :32:1
func (t *A_arbace_c2a_text_line_end_A) Ctor() {}
//line :32:1
func (t *A_arbace_c2a_text_line_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 int32 = jrt.NN(jrt.String_Cast(s__0)).IndexOf_String_I__I(Lit_15, lang.RT_IntCast_O__I(i__1)); if
											lang.Numbers_IsNeg_J__Z(int64(j__3)) { return jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(s__0)).Ref() } else { return jrt.Integer_ValueOf_I__Integer(j__3).Ref() } }

func A_arbace_c2a_text_token_end_A_New() *A_arbace_c2a_text_token_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_token_end_A{}; t.Ctor(); return t }
//line :35:1
func (t *A_arbace_c2a_text_token_end_A) Ctor() {}
//line :35:1
func (t *A_arbace_c2a_text_token_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var j__4 any = i__1; L1: for {



	var tmp1 any; var and__1927000168__auto____5 bool = lang.Numbers_Lt_O_J__Z(j__4, int64(n__3)); if and__1927000168__auto____5 { tmp1 = lang.IFn_Cast(A_arbace_c2a_text_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))).Ref())) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____5).Ref() }; if jrt.J2g_Truth(tmp1) { j__4 = lang.Numbers_Inc_O__Number(j__4); continue L1 } else { return j__4 } } }; /*line :35:1*/panic("j2g: unreachable") }





func A_arbace_c2a_text_string_end_A_New() *A_arbace_c2a_text_string_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_string_end_A{}; t.Ctor(); return t }
//line :41:1
func (t *A_arbace_c2a_text_string_end_A) Ctor() {}
//line :41:1
func (t *A_arbace_c2a_text_string_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var j__4 any = lang.Numbers_Inc_O__Number(i__1); L1: for {




	if lang.Numbers_Gte_O_J__Z(j__4, int64(n__3)) { return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_22) } else { if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_24)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))) {
		j__4 = lang.Numbers_Add_O_J__Number(j__4, 2); continue L1 } else {
//line :46:1
			if lang.Util_Equiv_C_C__Z(jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_18)).CharValue__C(), jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(j__4))) {

				return lang.Numbers_Inc_O__Number(j__4) } else {
//line :46:1
					if A_arbace_c2a_text_A_const_34 != nil {


						j__4 = lang.Numbers_Inc_O__Number(j__4); continue L1 } else {
//line :46:1
							return nil } } } } } }; /*line :41:1*/panic("j2g: unreachable") }









func A_arbace_c2a_text_char_end_A_New() *A_arbace_c2a_text_char_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_char_end_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_c2a_text_char_end_A) Ctor() {}
//line :51:1
func (t *A_arbace_c2a_text_char_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any {



	if lang.Numbers_Gte_O_J__Z(lang.Numbers_Inc_O__Number(i__1), int64(lang.RT_Count_O__I(s__0))) { lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_4) }
	return lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))
}


func A_arbace_c2a_text_skip_ws_A_New() *A_arbace_c2a_text_skip_ws_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_skip_ws_A{}; t.Ctor(); return t }
//line :60:1
func (t *A_arbace_c2a_text_skip_ws_A) Ctor() {}
//line :60:1
func (t *A_arbace_c2a_text_skip_ws_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var i__4 any = i__1; L1: for {





	if lang.Numbers_Gte_O_J__Z(i__4, int64(n__3)) { return i__4 } else { var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__4))


		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_17.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(c__5).Ref())) { i__4 = lang.Numbers_Inc_O__Number(i__4); continue L1 } else { if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_21)).CharValue__C()) {
			i__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); continue L1 } else {
//line :69:1
				var tmp1 bool; var and__1927000168__auto____6 bool = lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_36)).CharValue__C())

				if and__1927000168__auto____6 { var tmp2 any = A_arbace_c2a_text_A_const_37; tmp1 = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp1 = and__1927000168__auto____6 }
//line :69:1
				if tmp1 {

					i__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4); continue L1 } else {
//line :69:1
						var tmp3 bool; var and__1927000168__auto____6_2 bool = lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_36)).CharValue__C())


						if and__1927000168__auto____6_2 { var tmp4 any = A_arbace_c2a_text_A_const_39; tmp3 = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp3 = and__1927000168__auto____6_2 }
//line :69:1
						if tmp3 {


							i__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__4, 2))); continue L1 } else {
//line :69:1
								if A_arbace_c2a_text_A_const_34 != nil { return i__4 } else { return nil } } } } } } } }; /*line :60:1*/panic("j2g: unreachable") }
















func A_arbace_c2a_text_coll_end_A_New() *A_arbace_c2a_text_coll_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_coll_end_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_c2a_text_coll_end_A) Ctor() {}
//line :77:1
func (t *A_arbace_c2a_text_coll_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var close__3 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_43.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__1))).Ref()); var j__4 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)); L1: for { var c__5 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__4)





	if lang.Util_Identical_O_O__Z(c__5, nil) { return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_5, nil), jrt.RefArrayOf(jrt.Object_class, nil, close__3)).Ref()) } else { if lang.Util_Equiv_O_O__Z(c__5, close__3) {
		return lang.Numbers_Inc_O__Number(j__4) } else {
//line :83:1
			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_44).Invoke_O__O(c__5)) {

				return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__4, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__5)).Ref()) } else {
//line :83:1
					if A_arbace_c2a_text_A_const_34 != nil {


						j__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, j__4)); continue L1 } else {
//line :83:1
							return nil } } } } } }; /*line :77:1*/panic("j2g: unreachable") }










func A_arbace_c2a_text_next_form_end_A_New() *A_arbace_c2a_text_next_form_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_next_form_end_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_c2a_text_next_form_end_A) Ctor() {}
//line :88:1
func (t *A_arbace_c2a_text_next_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); if

	lang.Numbers_Gte_O_J__Z(j__3, int64(lang.RT_Count_O__I(s__0))) { lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_12) }; return /*line :91:1*/ lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3) }

func A_arbace_c2a_text_form_end_A_New() *A_arbace_c2a_text_form_end_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_form_end_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_c2a_text_form_end_A) Ctor() {}
//line :93:1
func (t *A_arbace_c2a_text_form_end_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var c__3 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var G__1948000027__4_ any = c__3; switch



	lang.Util_Hash_O__I(G__1948000027__4_) { case 0: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, nil) {
		return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_12) }
//line :97:1
	case 34: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_18) {


		return lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 35: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_36) { var d__5 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))
		var G__1948000028__6_ any = d__5








		switch lang.Util_Hash_O__I(G__1948000028__6_) { case 0: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, nil) {
			return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_13) }
//line :107:1
		case 33: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_37) {






			return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1)) }
//line :107:1
		case 34: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_18) {


			return lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :107:1
		case 35: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_36) {








			return lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2)) }
//line :107:1
		case 39: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_47) {



			return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2)) }
//line :107:1
		case 40: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_19) {

			return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :107:1
		case 58: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_49) { var j__7 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)))
			var tmp1 any = A_arbace_c2a_text_A_const_28









			if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__7)) { } else { lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_14) }
			return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, j__7) }
//line :107:1
		case 61: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_50) {



			return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2)) }
//line :107:1
		case 63: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_51) {







			return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_52.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1)) }
//line :107:1
		case 94: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_26) {




			return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))) }
//line :107:1
		case 95: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_39) {





			return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))) }
//line :107:1
		case 123: if lang.Util_Equiv_O_O__Z(G__1948000028__6_, A_arbace_c2a_text_A_const_28) {

			return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :107:1
		default:
		}












		return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))) }
//line :97:1
	case 39: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_47) {




		return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :97:1
	case 40: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_19) {

		return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 41: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_20) {







		return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 64: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_22) {




		return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :97:1
	case 91: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_23) {

		return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 92: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_24) {



		return lang.IFn_Cast(A_arbace_c2a_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 93: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_25) {







		return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 94: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_26) {






		return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))) }
//line :97:1
	case 96: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_27) {




		return lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)) }
//line :97:1
	case 123: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_28) {

		return lang.IFn_Cast(A_arbace_c2a_text_A_const_48.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }
//line :97:1
	case 125: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_29) {







		return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_6, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__3)).Ref()) }
//line :97:1
	case 126: if lang.Util_Equiv_O_O__Z(G__1948000027__4_, A_arbace_c2a_text_A_const_30) {





		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_46.GetRawRoot__O()); var tmp3 jrt.Number_I; var tmp4 any = A_arbace_c2a_text_A_const_22; if lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1))) { tmp3 = lang.Numbers_Add_O_J__Number(i__1, 2) } else { tmp3 = lang.Numbers_Inc_O__Number(i__1) }; return tmp2.Invoke_O_O__O(s__0, tmp3) }
//line :97:1
	default:}; return /*line :122:1*/ lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1) }



func A_arbace_c2a_text_cond_open_A_New() *A_arbace_c2a_text_cond_open_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_cond_open_A{}; t.Ctor(); return t }
//line :126:1
func (t *A_arbace_c2a_text_cond_open_A) Ctor() {}
//line :126:1
func (t *A_arbace_c2a_text_cond_open_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { var j__3 any; var tmp1 any = A_arbace_c2a_text_cond_open_fn__1948000030_A_New_O_O(i__1, s__0); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class; if



	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; j__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O(); var tmp3 any = A_arbace_c2a_text_A_const_19; if

	lang.Util_Equiv_O_O__Z(tmp3, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)) { } else { lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_8) }; return j__3 }
//line :130:1
func A_arbace_c2a_text_cond_open_fn__1948000030_A_New_O_O(p0, p1 any) *A_arbace_c2a_text_cond_open_fn__1948000030_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_cond_open_fn__1948000030_A{}; t.Ctor_O_O(p0, p1); return t }
//line :130:1
func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Ctor_O_O(c__i, c__s any) { t.F_i = c__i; t.F_s = c__s }
//line :130:1
func (t *A_arbace_c2a_text_cond_open_fn__1948000030_A) Invoke_O__O(self any) any { { var j__1 any; var tmp1 any = A_arbace_c2a_text_A_const_22; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()); var tmp3 any = t.F_s; if lang.Util_Equiv_O_O__Z(tmp1, tmp2.Invoke_O_O__O(tmp3, lang.Numbers_Add_O_J__Number(t.F_i, 2))) { var tmp4 any; var t_ any = t.F_i; t.F_i = nil; tmp4 = t_; j__1 = lang.Numbers_Add_O_J__Number(tmp4, 3) } else { var tmp5 any; var t__2 any = t.F_i; t.F_i = nil; tmp5 = t__2; j__1 = lang.Numbers_Add_O_J__Number(tmp5, 2) }; L1: for {
											var tmp6 any; var and__1927000168__auto____2 bool = lang.Numbers_Lt_O_J__Z(j__1, int64(lang.RT_Count_O__I(t.F_s))); if and__1927000168__auto____2 { var tmp7 *jrt.String = jrt.String_Cast(t.F_s); tmp6 = lang.IFn_Cast(A_arbace_c2a_text_A_const_17.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(tmp7).CharAt_I__C(lang.RT_IntCast_O__I(j__1))).Ref()) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.J2g_Truth(tmp6) { j__1 = lang.Numbers_Inc_O__Number(j__1); continue L1 } else { return j__1 } } }; /*line :130:1*/panic("j2g: unreachable") }




func A_arbace_c2a_text_branches_A_New() *A_arbace_c2a_text_branches_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_branches_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_c2a_text_branches_A) Ctor() {}
//line :135:1
func (t *A_arbace_c2a_text_branches_A) Invoke_O_O_O__O(self, s__0, i__1 any) any { { var j__3 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__1)); var bs__4 any; lang.PersistentVector_Init(); bs__4 = lang.PersistentVector_EMPTY.Ref(); L1: for {




	var tmp1 any = A_arbace_c2a_text_A_const_20; if lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3)) { return bs__4 } else { var fe__5 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, j__3); var feature__6 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__3, fe__5); var v__7 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, fe__5)




		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_54.GetRawRoot__O()).Invoke_O_O__O(feature__6, Lit_1)) { } else { lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, j__3, Lit_2) }
		var tmp2 any = A_arbace_c2a_text_A_const_20; if lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, v__7)) { lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__7, Lit_3) }
//line :140:1
		var ve__8 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, v__7)







		j__3, bs__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, ve__8), lang.IFn_Cast(A_arbace_c2a_text_A_const_6.GetRawRoot__O()).Invoke_O_O__O(bs__4, lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_c2a_text_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_12.GetRawRoot__O()).Invoke_O_O__O(feature__6, A_arbace_c2a_text_A_const_56)), v__7, ve__8)); continue L1 } } }; /*line :135:1*/panic("j2g: unreachable") }
















func A_arbace_c2a_text_selected_A_New() *A_arbace_c2a_text_selected_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_selected_A{}; t.Ctor(); return t }
//line :152:1
func (t *A_arbace_c2a_text_selected_A) Ctor() {}
//line :152:1
func (t *A_arbace_c2a_text_selected_A) Invoke_O_O_O_O_O__O(self, s__0, i__1, features__2, depth__3 any) any { var tmp1 any = A_arbace_c2a_text_A_const_22; var splice_QMARK___5 bool = lang.Util_Equiv_O_O__Z(tmp1, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Add_O_J__Number(i__1, 2))); var open__6 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_52.GetRawRoot__O()).Invoke_O_O__O(s__0, i__1); var vec__1948000034__7 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_57.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_9.GetRawRoot__O()); var tmp4 any = A_arbace_c2a_text_selected_fn__1948000038_A_New_O(features__2); var tmp5 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_c2a_text_selected_fn__1948000038_A_fn_class; if






	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_c2a_text_selected_fn__1948000038_A_fn_class = fncls__6d; tmp5 = fncls__6d } else { tmp5 = fncls__6 }; vec__1948000034__7 = tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_c2a_text_A_const_62.GetRawRoot__O()).Invoke_O_O__O(s__0, open__6))); var ___8 any = /*line :152:1*/lang.RT_Nth_O_I_O__O(vec__1948000034__7, lang.RT_IntCast_J__I(0), nil); var v__9 any = lang.RT_Nth_O_I_O__O(vec__1948000034__7, lang.RT_IntCast_J__I(1), nil); var ve__10 any = lang.RT_Nth_O_I_O__O(vec__1948000034__7, lang.RT_IntCast_J__I(2), nil); var tmp6 bool; var and__1927000168__auto____11 bool = splice_QMARK___5; _ = ___8; if and__1927000168__auto____11 {








		tmp6 = lang.Numbers_IsZero_O__Z(depth__3) } else { tmp6 = and__1927000168__auto____11 }; if tmp6 {
			lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, i__1, Lit_19) }; if
	lang.Util_Identical_O_O__Z(v__9, nil) { return Lit_20 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(splice_QMARK___5).Ref())) {
		return lang.IFn_Cast(A_arbace_c2a_text_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__9, ve__10), features__2) } else {
//line :163:1
			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_59); if jrt.J2g_Truth(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, v__9))) {

				return lang.IFn_Cast(A_arbace_c2a_text_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, lang.Numbers_Inc_O__Number(v__9), lang.Numbers_Dec_O__Number(ve__10)), features__2) } else {
//line :163:1
					if A_arbace_c2a_text_A_const_34 != nil {


						return lang.IFn_Cast(A_arbace_c2a_text_A_const_33.GetRawRoot__O()).Invoke_O_O_O__O(s__0, v__9, Lit_21) } else {
//line :163:1
							return nil } } } } }
//line :159:1
func A_arbace_c2a_text_selected_fn__1948000038_A_New_O(p0 any) *A_arbace_c2a_text_selected_fn__1948000038_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_selected_fn__1948000038_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Ctor_O(c__features any) { t.F_features = c__features }
//line :159:1
func (t *A_arbace_c2a_text_selected_fn__1948000038_A) Invoke_O_O__O(self, p__1948000037__1 any) any { var vec__1948000039__2 any = p__1948000037__1; var f__3 any = lang.RT_Nth_O_I_O__O(vec__1948000039__2, lang.RT_IntCast_J__I(0), nil); var or__1927000174__auto____4 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_60.GetRawRoot__O()).Invoke_O_O__O(t.F_features, f__3); if jrt.J2g_Truth(or__1927000174__auto____4) { return or__1927000174__auto____4 } else { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(f__3, A_arbace_c2a_text_A_const_61)).Ref() } }








func A_arbace_c2a_text_resolve_conditionals_A_New() *A_arbace_c2a_text_resolve_conditionals_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_resolve_conditionals_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_c2a_text_resolve_conditionals_A) Ctor() {}
//line :168:1
func (t *A_arbace_c2a_text_resolve_conditionals_A) Invoke_O_O_O__O(self, s__0, features__1 any) any {





	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_64.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_16))) { return s__0 } else { var n__3 int32 = lang.RT_Count_O__I(s__0); var sb__4 any = jrt.StringBuilder_New(); var i__5 any = lang.RT_Box_J__Number(0); var depth__6 int64 = 0; L1: for {



		if lang.Numbers_Gte_O_J__Z(i__5, int64(n__3)) {
			return lang.IFn_Cast(A_arbace_c2a_text_A_const_63.GetRawRoot__O()).Invoke_O__O(sb__4) } else {
//line :178:1
				var c__7 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__5)); var copy__8 any; var tmp1 any = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_New_O_O_O(i__5, sb__4, s__0); var tmp2 *jrt.Class
				var fncls__7 /*line :178:1*/*jrt.Class = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class


				if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_17, false); A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; copy__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :178:1
				var G__1948000050__9_ uint16 = c__7



				switch lang.Util_Hash_O__I(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref()) { case 34: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_18) {
					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 35: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_36) { var G__1948000051__10_ any = lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__5))





					switch lang.Util_Hash_O__I(G__1948000051__10_) { case 33: if lang.Util_Equiv_O_O__Z(G__1948000051__10_, A_arbace_c2a_text_A_const_37) {

						i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :188:1
					case 34: if lang.Util_Equiv_O_O__Z(G__1948000051__10_, A_arbace_c2a_text_A_const_18) {
						i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__5))), depth__6; continue L1 }
//line :188:1
					case 63: if lang.Util_Equiv_O_O__Z(G__1948000051__10_, A_arbace_c2a_text_A_const_51) { var e__11 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)



						jrt.NN(jrt.StringBuilder_Cast(sb__4)).Append_String__StringBuilder(jrt.String_Cast(lang.IFn_Cast(A_arbace_c2a_text_A_const_65.GetRawRoot__O()).Invoke_O_O_O_O__O(s__0, i__5, features__1, jrt.Long_ValueOf_J__Long(depth__6).Ref())))
						i__5, depth__6 = e__11, depth__6; continue L1 }
//line :188:1
					default:
					}




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), depth__6; continue L1 }
//line :182:1
				case 40: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_19) {



					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Inc_J__J(depth__6); continue L1 }
//line :182:1
				case 41: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_20) {




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(depth__6)); continue L1 }
//line :182:1
				case 59: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_21) {

					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 91: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_23) {



					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Inc_J__J(depth__6); continue L1 }
//line :182:1
				case 92: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_24) {


					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5)), depth__6; continue L1 }
//line :182:1
				case 93: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_25) {




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(depth__6)); continue L1 }
//line :182:1
				case 123: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_28) {



					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Inc_J__J(depth__6); continue L1 }
//line :182:1
				case 125: if lang.Util_Equiv_O_O__Z(jrt.Character_ValueOf_C__Character(G__1948000050__9_).Ref(), A_arbace_c2a_text_A_const_29) {




					i__5, depth__6 = lang.IFn_Cast(copy__8).Invoke_O__O(lang.Numbers_Inc_O__Number(i__5)), lang.Numbers_Max_J_J__J(0, lang.Numbers_Dec_J__J(depth__6)); continue L1 }
//line :182:1
				default:
				}











				var tmp3 lang.IFn = lang.IFn_Cast(copy__8); var tmp4 any; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(c__7).Ref())) { tmp4 = lang.Numbers_Inc_O__Number(i__5) } else { tmp4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, i__5) }; i__5, depth__6 = tmp3.Invoke_O__O(tmp4), depth__6; continue L1 } } }
//line :168:1
	panic("j2g: unreachable") }
//line :168:1
func (t *A_arbace_c2a_text_resolve_conditionals_A) Invoke_O_O__O(self, s__0 any) any {



	return lang.IFn_Cast(A_arbace_c2a_text_A_const_58.GetRawRoot__O()).Invoke_O_O__O(s__0, A_arbace_c2a_text_A_const_66)
}







func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_New_O_O_O(p0, p1, p2 any) *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :181:1
func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Ctor_O_O_O(c__i, c__sb, c__s any) { t.F_i = c__i; t.F_sb = c__sb; t.F_s = c__s }
//line :181:1
func (t *A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A) Invoke_O_O__O(self, j__1 any) any { var tmp1 *jrt.StringBuilder = jrt.StringBuilder_Cast(t.F_sb); var tmp2 jrt.CharSequence = jrt.CharSequence_Cast(t.F_s); jrt.NN(tmp1).Append_CharSequence_I_I__StringBuilder(tmp2, lang.RT_IntCast_O__I(t.F_i), lang.RT_IntCast_O__I(j__1)); return j__1 }

















func A_arbace_c2a_text_code_tokens_A_New() *A_arbace_c2a_text_code_tokens_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_code_tokens_A{}; t.Ctor(); return t }
//line :199:1
func (t *A_arbace_c2a_text_code_tokens_A) Ctor() {}
//line :199:1
func (t *A_arbace_c2a_text_code_tokens_A) Invoke_O_O__O(self, s__0 any) any { { var n__2 int32 = lang.RT_Count_O__I(s__0); var i__3 any = lang.RT_Box_J__Number(0); var out__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_67.GetRawRoot__O()); var tmp2 *lang.PersistentVector




	lang.PersistentVector_Init(); tmp2 = lang.PersistentVector_EMPTY; out__4 = tmp1.Invoke_O__O(tmp2.Ref())
//line :199:1
L1: for {





	if lang.Numbers_Gte_O_J__Z(i__3, int64(n__2)) {
		return lang.IFn_Cast(A_arbace_c2a_text_A_const_68.GetRawRoot__O()).Invoke_O__O(out__4) } else {
//line :205:1
			var c__5 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__3))


			if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_18)).CharValue__C()) {
				i__3, out__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
					if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_21)).CharValue__C()) {

						i__3, out__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
							if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_24)).CharValue__C()) {


								i__3, out__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 } else {
//line :208:1
									if lang.Util_Equiv_C_C__Z(c__5, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_36)).CharValue__C()) { var G__1948000054__6_ any = lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__3))



										switch lang.Util_Hash_O__I(G__1948000054__6_) { case 33: if lang.Util_Equiv_O_O__Z(G__1948000054__6_, A_arbace_c2a_text_A_const_37) {

											i__3, out__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3), out__4; continue L1 }
//line :212:1
										case 34: if lang.Util_Equiv_O_O__Z(G__1948000054__6_, A_arbace_c2a_text_A_const_18) {
											i__3, out__4 = lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__3)), out__4; continue L1 }
//line :212:1
										default:
										}

										i__3, out__4 = lang.Numbers_Inc_O__Number(i__3), out__4; continue L1 } else {
//line :208:1
											if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_c2a_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(c__5).Ref())) {







												i__3, out__4 = lang.Numbers_Inc_O__Number(i__3), out__4; continue L1 } else {
//line :208:1
													var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_c2a_text_A_const_69); if jrt.J2g_Truth(tmp3.Invoke_O__O(jrt.Character_ValueOf_C__Character(c__5).Ref())) {








														i__3, out__4 = lang.Numbers_Inc_O__Number(i__3), out__4; continue L1 } else {
//line :208:1
															if A_arbace_c2a_text_A_const_34 != nil { var e__6 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, i__3)









																i__3, out__4 = e__6, lang.IFn_Cast(A_arbace_c2a_text_A_const_70.GetRawRoot__O()).Invoke_O_O__O(out__4, lang.Tuple_Create_O_O__IPersistentVector(i__3, e__6)); continue L1 } else {
//line :208:1
																	return nil } } } } } } } } } }; /*line :199:1*/panic("j2g: unreachable") }




















func A_arbace_c2a_text_list_spans_A_New() *A_arbace_c2a_text_list_spans_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_list_spans_A{}; t.Ctor(); return t }
//line :220:1
func (t *A_arbace_c2a_text_list_spans_A) Ctor() {}
//line :220:1
func (t *A_arbace_c2a_text_list_spans_A) Invoke_O_O_O__O(self, s__0, pred__1 any) any { { var n__3 int32 = lang.RT_Count_O__I(s__0); var i__4 any = lang.RT_Box_J__Number(0); var out__5 any; lang.PersistentVector_Init(); out__5 = lang.PersistentVector_EMPTY.Ref(); L1: for {




	if lang.Numbers_Gte_O_J__Z(i__4, int64(n__3)) { return out__5 } else { var c__6 uint16 = jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(i__4))


		if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_18)).CharValue__C()) {
			i__4, out__5 = lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
				if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_21)).CharValue__C()) {

					i__4, out__5 = lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
						if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_24)).CharValue__C()) {


							i__4, out__5 = lang.IFn_Cast(A_arbace_c2a_text_A_const_53.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
								var tmp1 bool; var and__1927000168__auto____7 bool = lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_36)).CharValue__C())



								if and__1927000168__auto____7 { var tmp2 any = A_arbace_c2a_text_A_const_18; tmp1 = lang.Util_Equiv_O_O__Z(tmp2, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp1 = and__1927000168__auto____7 }
//line :228:1
								if tmp1 {



									i__4, out__5 = lang.IFn_Cast(A_arbace_c2a_text_A_const_45.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4)), out__5; continue L1 } else {
//line :228:1
										var tmp3 bool; var and__1927000168__auto____7_2 bool = lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_36)).CharValue__C())




										if and__1927000168__auto____7_2 { var tmp4 any = A_arbace_c2a_text_A_const_37; tmp3 = lang.Util_Equiv_O_O__Z(tmp4, lang.IFn_Cast(A_arbace_c2a_text_A_const_38.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4))) } else { tmp3 = and__1927000168__auto____7_2 }
//line :228:1
										if tmp3 {




											i__4, out__5 = lang.IFn_Cast(A_arbace_c2a_text_A_const_40.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4), out__5; continue L1 } else {
//line :228:1
												if lang.Util_Equiv_C_C__Z(c__6, jrt.NN(jrt.Character_Cast(A_arbace_c2a_text_A_const_19)).CharValue__C()) { var h__7 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_42.GetRawRoot__O()).Invoke_O_O__O(s__0, lang.Numbers_Inc_O__Number(i__4)); var head__8 any; var tmp5 any; var and__1927000168__auto____8 bool = lang.Numbers_Lt_O_J__Z(h__7, int64(n__3))







													if and__1927000168__auto____8 { tmp5 = lang.IFn_Cast(A_arbace_c2a_text_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_c2a_text_A_const_32.GetRawRoot__O()).Invoke_O__O(jrt.Character_ValueOf_C__Character(jrt.NN(jrt.String_Cast(s__0)).CharAt_I__C(lang.RT_IntCast_O__I(h__7))).Ref())) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() }; if jrt.J2g_Truth(tmp5) {
														head__8 = lang.IFn_Cast(A_arbace_c2a_text_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(s__0, h__7, lang.IFn_Cast(A_arbace_c2a_text_A_const_35.GetRawRoot__O()).Invoke_O_O__O(s__0, h__7)) } else {
//line :236:1
															head__8 = nil
														}
													var tmp6 any; var and__1927000168__auto____9 any = head__8; if jrt.J2g_Truth(and__1927000168__auto____9) { tmp6 = lang.IFn_Cast(pred__1).Invoke_O__O(head__8) } else { tmp6 = and__1927000168__auto____9 }; if jrt.J2g_Truth(tmp6) { var e__9 any = lang.IFn_Cast(A_arbace_c2a_text_A_const_41.GetRawRoot__O()).Invoke_O_O__O(s__0, i__4)
														i__4, out__5 = e__9, lang.IFn_Cast(A_arbace_c2a_text_A_const_6.GetRawRoot__O()).Invoke_O_O__O(out__5, lang.Tuple_Create_O_O__IPersistentVector(i__4, e__9)); continue L1 } else {
															i__4, out__5 = lang.Numbers_Inc_O__Number(i__4), out__5; continue L1 } } else {
//line :228:1
																if A_arbace_c2a_text_A_const_34 != nil {












																	i__4, out__5 = lang.Numbers_Inc_O__Number(i__4), out__5; continue L1 } else {
//line :228:1
																		return nil } } } } } } } } } }; /*line :220:1*/panic("j2g: unreachable") }







type A_arbace_c2a_text_A struct{ jrt.Object }

var A_arbace_c2a_text_A_const_pool *jrt.RefArray

var A_arbace_c2a_text_A_const_0 *lang.Var

var A_arbace_c2a_text_A_const_1 *lang.Var

var A_arbace_c2a_text_A_const_2 any

var A_arbace_c2a_text_A_const_3 any

var A_arbace_c2a_text_A_const_4 *lang.Var

var A_arbace_c2a_text_A_const_5 *lang.Var

var A_arbace_c2a_text_A_const_6 *lang.Var

var A_arbace_c2a_text_A_const_7 any

var A_arbace_c2a_text_A_const_8 *lang.Var

var A_arbace_c2a_text_A_const_9 *lang.Var

var A_arbace_c2a_text_A_const_10 *lang.Var

var A_arbace_c2a_text_A_const_11 any

var A_arbace_c2a_text_A_const_12 *lang.Var

var A_arbace_c2a_text_A_const_13 any

var A_arbace_c2a_text_A_const_14 *lang.Keyword

var A_arbace_c2a_text_A_const_15 *lang.Keyword

var A_arbace_c2a_text_A_const_16 any

var A_arbace_c2a_text_A_const_17 *lang.Var

var A_arbace_c2a_text_A_const_18 any

var A_arbace_c2a_text_A_const_19 any

var A_arbace_c2a_text_A_const_20 any

var A_arbace_c2a_text_A_const_21 any

var A_arbace_c2a_text_A_const_22 any

var A_arbace_c2a_text_A_const_23 any

var A_arbace_c2a_text_A_const_24 any

var A_arbace_c2a_text_A_const_25 any

var A_arbace_c2a_text_A_const_26 any

var A_arbace_c2a_text_A_const_27 any

var A_arbace_c2a_text_A_const_28 any

var A_arbace_c2a_text_A_const_29 any

var A_arbace_c2a_text_A_const_30 any

var A_arbace_c2a_text_A_const_31 *lang.Var

var A_arbace_c2a_text_A_const_32 *lang.Var

var A_arbace_c2a_text_A_const_33 *lang.Var

var A_arbace_c2a_text_A_const_34 *lang.Keyword

var A_arbace_c2a_text_A_const_35 *lang.Var

var A_arbace_c2a_text_A_const_36 any

var A_arbace_c2a_text_A_const_37 any

var A_arbace_c2a_text_A_const_38 *lang.Var

var A_arbace_c2a_text_A_const_39 any

var A_arbace_c2a_text_A_const_40 *lang.Var

var A_arbace_c2a_text_A_const_41 *lang.Var

var A_arbace_c2a_text_A_const_42 *lang.Var

var A_arbace_c2a_text_A_const_43 *lang.Var

var A_arbace_c2a_text_A_const_44 any

var A_arbace_c2a_text_A_const_45 *lang.Var

var A_arbace_c2a_text_A_const_46 *lang.Var

var A_arbace_c2a_text_A_const_47 any

var A_arbace_c2a_text_A_const_48 *lang.Var

var A_arbace_c2a_text_A_const_49 any

var A_arbace_c2a_text_A_const_50 any

var A_arbace_c2a_text_A_const_51 any

var A_arbace_c2a_text_A_const_52 *lang.Var

var A_arbace_c2a_text_A_const_53 *lang.Var

var A_arbace_c2a_text_A_const_54 *lang.Var

var A_arbace_c2a_text_A_const_55 *lang.Var

var A_arbace_c2a_text_A_const_56 any

var A_arbace_c2a_text_A_const_57 *lang.Var

var A_arbace_c2a_text_A_const_58 *lang.Var

var A_arbace_c2a_text_A_const_59 any

var A_arbace_c2a_text_A_const_60 *lang.Var

var A_arbace_c2a_text_A_const_61 *lang.Keyword

var A_arbace_c2a_text_A_const_62 *lang.Var

var A_arbace_c2a_text_A_const_63 *lang.Var

var A_arbace_c2a_text_A_const_64 *lang.Var

var A_arbace_c2a_text_A_const_65 *lang.Var

var A_arbace_c2a_text_A_const_66 any

var A_arbace_c2a_text_A_const_67 *lang.Var

var A_arbace_c2a_text_A_const_68 *lang.Var

var A_arbace_c2a_text_A_const_69 any

var A_arbace_c2a_text_A_const_70 *lang.Var

var A_arbace_c2a_text_A_init jrt.ClassInit

func A_arbace_c2a_text_A_Init() { if !A_arbace_c2a_text_A_init.Done() { A_arbace_c2a_text_A_init.Run(A_arbace_c2a_text_A_clinit) } }

func A_arbace_c2a_text_A_clinit() { A_arbace_c2a_text_A_clinit_p0(); A_arbace_c2a_text_A_clinit_p1(); A_arbace_c2a_text_A_clinit_p2(); A_arbace_c2a_text_A_clinit_p3(); A_arbace_c2a_text_A_clinit_p4(); A_arbace_c2a_text_A_clinit_p5() }

func A_arbace_c2a_text_A_clinit_p0() { A_arbace_c2a_text_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 81); A_arbace_c2a_text_A_const_0 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[10]); A_arbace_c2a_text_A_const_1 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[11]); A_arbace_c2a_text_A_const_2 = A_arbace_c2a_text_A_const_pool.A[12]; A_arbace_c2a_text_A_const_3 = A_arbace_c2a_text_A_const_pool.A[13]; A_arbace_c2a_text_A_const_4 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[14]); A_arbace_c2a_text_A_const_5 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[15]); A_arbace_c2a_text_A_const_6 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[16]); A_arbace_c2a_text_A_const_7 = A_arbace_c2a_text_A_const_pool.A[17]; A_arbace_c2a_text_A_const_8 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[18]); A_arbace_c2a_text_A_const_9 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[19]); A_arbace_c2a_text_A_const_10 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[20]); A_arbace_c2a_text_A_const_11 = A_arbace_c2a_text_A_const_pool.A[21] }

func A_arbace_c2a_text_A_clinit_p1() { A_arbace_c2a_text_A_const_12 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[22]); A_arbace_c2a_text_A_const_13 = A_arbace_c2a_text_A_const_pool.A[23]; A_arbace_c2a_text_A_const_14 = lang.Keyword_Cast(A_arbace_c2a_text_A_const_pool.A[24]); A_arbace_c2a_text_A_const_15 = lang.Keyword_Cast(A_arbace_c2a_text_A_const_pool.A[25]); A_arbace_c2a_text_A_const_16 = A_arbace_c2a_text_A_const_pool.A[26]; A_arbace_c2a_text_A_const_17 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[27]); A_arbace_c2a_text_A_const_18 = A_arbace_c2a_text_A_const_pool.A[28]; A_arbace_c2a_text_A_const_19 = A_arbace_c2a_text_A_const_pool.A[29]; A_arbace_c2a_text_A_const_20 = A_arbace_c2a_text_A_const_pool.A[30]; A_arbace_c2a_text_A_const_21 = A_arbace_c2a_text_A_const_pool.A[31]; A_arbace_c2a_text_A_const_22 = A_arbace_c2a_text_A_const_pool.A[32]; A_arbace_c2a_text_A_const_23 = A_arbace_c2a_text_A_const_pool.A[33]; A_arbace_c2a_text_A_const_24 = A_arbace_c2a_text_A_const_pool.A[34]; A_arbace_c2a_text_A_const_25 = A_arbace_c2a_text_A_const_pool.A[35] }

func A_arbace_c2a_text_A_clinit_p2() { A_arbace_c2a_text_A_const_26 = A_arbace_c2a_text_A_const_pool.A[36]; A_arbace_c2a_text_A_const_27 = A_arbace_c2a_text_A_const_pool.A[37]; A_arbace_c2a_text_A_const_28 = A_arbace_c2a_text_A_const_pool.A[38]; A_arbace_c2a_text_A_const_29 = A_arbace_c2a_text_A_const_pool.A[39]; A_arbace_c2a_text_A_const_30 = A_arbace_c2a_text_A_const_pool.A[40]; A_arbace_c2a_text_A_const_31 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[41]); A_arbace_c2a_text_A_const_32 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[42]); A_arbace_c2a_text_A_const_33 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[43]); A_arbace_c2a_text_A_const_34 = lang.Keyword_Cast(A_arbace_c2a_text_A_const_pool.A[44]); A_arbace_c2a_text_A_const_35 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[45]); A_arbace_c2a_text_A_const_36 = A_arbace_c2a_text_A_const_pool.A[46]; A_arbace_c2a_text_A_const_37 = A_arbace_c2a_text_A_const_pool.A[47]; A_arbace_c2a_text_A_const_38 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[48]); A_arbace_c2a_text_A_const_39 = A_arbace_c2a_text_A_const_pool.A[49] }

func A_arbace_c2a_text_A_clinit_p3() { A_arbace_c2a_text_A_const_40 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[50]); A_arbace_c2a_text_A_const_41 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[51]); A_arbace_c2a_text_A_const_42 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[52]); A_arbace_c2a_text_A_const_43 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[53]); A_arbace_c2a_text_A_const_44 = A_arbace_c2a_text_A_const_pool.A[54]; A_arbace_c2a_text_A_const_45 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[55]); A_arbace_c2a_text_A_const_46 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[56]); A_arbace_c2a_text_A_const_47 = A_arbace_c2a_text_A_const_pool.A[57]; A_arbace_c2a_text_A_const_48 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[58]); A_arbace_c2a_text_A_const_49 = A_arbace_c2a_text_A_const_pool.A[59]; A_arbace_c2a_text_A_const_50 = A_arbace_c2a_text_A_const_pool.A[60]; A_arbace_c2a_text_A_const_51 = A_arbace_c2a_text_A_const_pool.A[61]; A_arbace_c2a_text_A_const_52 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[62]) }

func A_arbace_c2a_text_A_clinit_p4() { A_arbace_c2a_text_A_const_53 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[63]); A_arbace_c2a_text_A_const_54 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[64]); A_arbace_c2a_text_A_const_55 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[65]); A_arbace_c2a_text_A_const_56 = A_arbace_c2a_text_A_const_pool.A[66]; A_arbace_c2a_text_A_const_57 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[67]); A_arbace_c2a_text_A_const_58 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[68]); A_arbace_c2a_text_A_const_59 = A_arbace_c2a_text_A_const_pool.A[69]; A_arbace_c2a_text_A_const_60 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[70]); A_arbace_c2a_text_A_const_61 = lang.Keyword_Cast(A_arbace_c2a_text_A_const_pool.A[71]); A_arbace_c2a_text_A_const_62 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[72]); A_arbace_c2a_text_A_const_63 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[73]); A_arbace_c2a_text_A_const_64 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[74]) }

func A_arbace_c2a_text_A_clinit_p5() { A_arbace_c2a_text_A_const_65 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[75]); A_arbace_c2a_text_A_const_66 = A_arbace_c2a_text_A_const_pool.A[76]; A_arbace_c2a_text_A_const_67 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[77]); A_arbace_c2a_text_A_const_68 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[78]); A_arbace_c2a_text_A_const_69 = A_arbace_c2a_text_A_const_pool.A[79]; A_arbace_c2a_text_A_const_70 = lang.Var_Cast(A_arbace_c2a_text_A_const_pool.A[80]) }

func A_arbace_c2a_text_A_New() *A_arbace_c2a_text_A { A_arbace_c2a_text_A_Init(); t := &A_arbace_c2a_text_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text_A) Ctor() {}

func (t *A_arbace_c2a_text_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_A_class }

func (t *A_arbace_c2a_text_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_A); return ok }

func A_arbace_c2a_text_A_Cast(x any) *A_arbace_c2a_text_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_A_class)) }; return v }



type A_arbace_c2a_text_at_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_at_A_fn_class *jrt.Class



type A_arbace_c2a_text_branches_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_branches_A_fn_class *jrt.Class



type A_arbace_c2a_text_char_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_char_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_code_tokens_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_code_tokens_A_fn_class *jrt.Class



type A_arbace_c2a_text_coll_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_coll_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_cond_open_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_cond_open_A_fn_class *jrt.Class



type A_arbace_c2a_text_cond_open_fn__1948000030_A struct{ j2g_header uint64; F_i, F_s any }

var A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class *jrt.Class



type A_arbace_c2a_text_eval1948000004_A struct{ jrt.Object }

func A_arbace_c2a_text_eval1948000004_A_New() *A_arbace_c2a_text_eval1948000004_A { t := &A_arbace_c2a_text_eval1948000004_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text_eval1948000004_A) Ctor() {}

func (t *A_arbace_c2a_text_eval1948000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_eval1948000004_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_eval1948000004_A_class }

func (t *A_arbace_c2a_text_eval1948000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_eval1948000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_eval1948000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_eval1948000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_eval1948000004_A); return ok }

func A_arbace_c2a_text_eval1948000004_A_Cast(x any) *A_arbace_c2a_text_eval1948000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_eval1948000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_eval1948000004_A_class)) }; return v }



type A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_fn_class *jrt.Class



type A_arbace_c2a_text_eval1948000008_A struct{ jrt.Object }

func A_arbace_c2a_text_eval1948000008_A_New() *A_arbace_c2a_text_eval1948000008_A { t := &A_arbace_c2a_text_eval1948000008_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text_eval1948000008_A) Ctor() {}

func (t *A_arbace_c2a_text_eval1948000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text_eval1948000008_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text_eval1948000008_A_class }

func (t *A_arbace_c2a_text_eval1948000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text_eval1948000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_c2a_text_eval1948000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text_eval1948000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text_eval1948000008_A); return ok }

func A_arbace_c2a_text_eval1948000008_A_Cast(x any) *A_arbace_c2a_text_eval1948000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text_eval1948000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text_eval1948000008_A_class)) }; return v }



type A_arbace_c2a_text_eval1948000008_fn__1948000009_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_eval1948000008_fn__1948000009_A_fn_class *jrt.Class



type A_arbace_c2a_text_fail_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_fail_A_fn_class *jrt.Class



type A_arbace_c2a_text_fail_fn__1948000013_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_fail_fn__1948000013_A_fn_class *jrt.Class



type A_arbace_c2a_text_form_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_form_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_line_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_line_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_list_spans_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_list_spans_A_fn_class *jrt.Class



type A_arbace_c2a_text_next_form_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_next_form_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_resolve_conditionals_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_resolve_conditionals_A_fn_class *jrt.Class



type A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A struct{ j2g_header uint64; F_i, F_sb, F_s any }

var A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class *jrt.Class



type A_arbace_c2a_text_selected_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_selected_A_fn_class *jrt.Class



type A_arbace_c2a_text_selected_fn__1948000038_A struct{ j2g_header uint64; F_features any }

var A_arbace_c2a_text_selected_fn__1948000038_A_fn_class *jrt.Class



type A_arbace_c2a_text_skip_ws_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_skip_ws_A_fn_class *jrt.Class



type A_arbace_c2a_text_string_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_string_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_terminating_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2a_text_terminating_QMARK__A_fn_class *jrt.Class



type A_arbace_c2a_text_token_end_A struct{ j2g_header uint64 }

var A_arbace_c2a_text_token_end_A_fn_class *jrt.Class



type A_arbace_c2a_text_ws_QMARK__A struct{ j2g_header uint64 }

var A_arbace_c2a_text_ws_QMARK__A_fn_class *jrt.Class
