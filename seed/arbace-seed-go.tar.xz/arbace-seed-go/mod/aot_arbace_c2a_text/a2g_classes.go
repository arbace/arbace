//line a2g_classes.ae:1
package aot_arbace_c2a_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_c2a_text_at_A_class, Name: "arbace.c2a.text$at", Modifiers: 25, Simple: "at", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_at_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_branches_A_class, Name: "arbace.c2a.text$branches", Modifiers: 25, Simple: "branches", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_branches_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_char_end_A_class, Name: "arbace.c2a.text$char_end", Modifiers: 25, Simple: "char_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_char_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_code_tokens_A_class, Name: "arbace.c2a.text$code_tokens", Modifiers: 25, Simple: "code_tokens", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_code_tokens_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_coll_end_A_class, Name: "arbace.c2a.text$coll_end", Modifiers: 25, Simple: "coll_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_coll_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_cond_open_A_class, Name: "arbace.c2a.text$cond_open", Modifiers: 25, Simple: "cond_open", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_cond_open_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_cond_open_fn__1948000030_A_class, Name: "arbace.c2a.text$cond_open$fn__1948000030", Modifiers: 25, Simple: "fn__1948000030", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_cond_open_fn__1948000030_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_cond_open_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class, Name: "arbace.c2a.text$eval1948000004$loading__1927001464__auto____1948000005", Modifiers: 25, Simple: "loading__1927001464__auto____1948000005", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_eval1948000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class, Name: "arbace.c2a.text$eval1948000008$fn__1948000009", Modifiers: 25, Simple: "fn__1948000009", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000008_fn__1948000009_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_eval1948000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_fail_A_class, Name: "arbace.c2a.text$fail", Modifiers: 25, Simple: "fail", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_fail_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_fail_fn__1948000013_A_class, Name: "arbace.c2a.text$fail$fn__1948000013", Modifiers: 25, Simple: "fn__1948000013", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_fail_fn__1948000013_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_fail_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_form_end_A_class, Name: "arbace.c2a.text$form_end", Modifiers: 25, Simple: "form_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_form_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_line_end_A_class, Name: "arbace.c2a.text$line_end", Modifiers: 25, Simple: "line_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_line_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_list_spans_A_class, Name: "arbace.c2a.text$list_spans", Modifiers: 25, Simple: "list_spans", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_list_spans_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_next_form_end_A_class, Name: "arbace.c2a.text$next_form_end", Modifiers: 25, Simple: "next_form_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_next_form_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_resolve_conditionals_A_class, Name: "arbace.c2a.text$resolve_conditionals", Modifiers: 25, Simple: "resolve_conditionals", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_resolve_conditionals_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class, Name: "arbace.c2a.text$resolve_conditionals$copy__1948000048", Modifiers: 25, Simple: "copy__1948000048", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_resolve_conditionals_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_selected_A_class, Name: "arbace.c2a.text$selected", Modifiers: 25, Simple: "selected", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_selected_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_selected_fn__1948000038_A_class, Name: "arbace.c2a.text$selected$fn__1948000038", Modifiers: 25, Simple: "fn__1948000038", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_selected_fn__1948000038_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_selected_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_skip_ws_A_class, Name: "arbace.c2a.text$skip_ws", Modifiers: 25, Simple: "skip_ws", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_skip_ws_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_string_end_A_class, Name: "arbace.c2a.text$string_end", Modifiers: 25, Simple: "string_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_string_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_terminating_QMARK__A_class, Name: "arbace.c2a.text$terminating_QMARK_", Modifiers: 25, Simple: "terminating_QMARK_", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_terminating_QMARK__A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_token_end_A_class, Name: "arbace.c2a.text$token_end", Modifiers: 25, Simple: "token_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_token_end_A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_c2a_text_ws_QMARK__A_class, Name: "arbace.c2a.text$ws_QMARK_", Modifiers: 25, Simple: "ws_QMARK_", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_ws_QMARK__A", Source: "text.ae", Declaring: &A_arbace_c2a_text_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_c2a_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_A_New()}; return nil }

var A_arbace_c2a_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_text_A_new}

var A_arbace_c2a_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_A"})

func init() { i := A_arbace_c2a_text_A_class.Info(); i.IsInstance = A_arbace_c2a_text_A_InstanceOf; i.Init = A_arbace_c2a_text_A_Init; i.Table = A_arbace_c2a_text_A_members }

var A_arbace_c2a_text_at_A_class *jrt.Class

var A_arbace_c2a_text_branches_A_class *jrt.Class

var A_arbace_c2a_text_char_end_A_class *jrt.Class

var A_arbace_c2a_text_code_tokens_A_class *jrt.Class

var A_arbace_c2a_text_coll_end_A_class *jrt.Class

var A_arbace_c2a_text_cond_open_A_class *jrt.Class

var A_arbace_c2a_text_cond_open_fn__1948000030_A_class *jrt.Class

func A_arbace_c2a_text_eval1948000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_eval1948000004_A_New()}; return nil }

var A_arbace_c2a_text_eval1948000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_text_eval1948000004_A_new}

var A_arbace_c2a_text_eval1948000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$eval1948000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_text_A_class, Simple: "eval1948000004", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000004_A"})

func init() { i := A_arbace_c2a_text_eval1948000004_A_class.Info(); i.IsInstance = A_arbace_c2a_text_eval1948000004_A_InstanceOf; i.Table = A_arbace_c2a_text_eval1948000004_A_members }

var A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class *jrt.Class

func A_arbace_c2a_text_eval1948000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_eval1948000008_A_New()}; return nil }

var A_arbace_c2a_text_eval1948000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_text_eval1948000008_A_new}

var A_arbace_c2a_text_eval1948000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$eval1948000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_text_A_class, Simple: "eval1948000008", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000008_A"})

func init() { i := A_arbace_c2a_text_eval1948000008_A_class.Info(); i.IsInstance = A_arbace_c2a_text_eval1948000008_A_InstanceOf; i.Table = A_arbace_c2a_text_eval1948000008_A_members }

var A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class *jrt.Class

var A_arbace_c2a_text_fail_A_class *jrt.Class

var A_arbace_c2a_text_fail_fn__1948000013_A_class *jrt.Class

var A_arbace_c2a_text_form_end_A_class *jrt.Class

var A_arbace_c2a_text_line_end_A_class *jrt.Class

var A_arbace_c2a_text_list_spans_A_class *jrt.Class

var A_arbace_c2a_text_next_form_end_A_class *jrt.Class

var A_arbace_c2a_text_resolve_conditionals_A_class *jrt.Class

var A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class *jrt.Class

var A_arbace_c2a_text_selected_A_class *jrt.Class

var A_arbace_c2a_text_selected_fn__1948000038_A_class *jrt.Class

var A_arbace_c2a_text_skip_ws_A_class *jrt.Class

var A_arbace_c2a_text_string_end_A_class *jrt.Class

var A_arbace_c2a_text_terminating_QMARK__A_class *jrt.Class

var A_arbace_c2a_text_token_end_A_class *jrt.Class

var A_arbace_c2a_text_ws_QMARK__A_class *jrt.Class

func A_arbace_c2a_text__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_text__init_A_Load__O()}; return nil }

func A_arbace_c2a_text__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text__init_A_New()}; return nil }

var A_arbace_c2a_text__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_text__init_A_invoke, New: A_arbace_c2a_text__init_A_new}

var A_arbace_c2a_text__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text__init_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text__init_A_class.Info(); i.IsInstance = A_arbace_c2a_text__init_A_InstanceOf; i.Init = A_arbace_c2a_text__init_A_Init; i.Table = A_arbace_c2a_text__init_A_members }
