//line a2g_classes.ae:1
package aot_arbace_c2a_text

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_c2a_text_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_A_New()}; return nil }

var A_arbace_c2a_text_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_text_A_new}

var A_arbace_c2a_text_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_A"})

func init() { i := A_arbace_c2a_text_A_class.Info(); i.IsInstance = A_arbace_c2a_text_A_InstanceOf; i.Init = A_arbace_c2a_text_A_Init; i.Table = A_arbace_c2a_text_A_members; jrt.RegisterGoType(A_arbace_c2a_text_A_class, reflect.TypeFor[A_arbace_c2a_text_A]()) }

func A_arbace_c2a_text_at_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_at_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_at_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_at_A_New()}; return nil }

func A_arbace_c2a_text_at_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_at_A_fn_class)}; return nil }

var A_arbace_c2a_text_at_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_at_A_invoke, New: A_arbace_c2a_text_at_A_new, Get: A_arbace_c2a_text_at_A_get}

var A_arbace_c2a_text_at_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$at", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "at", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_at_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_at_A_class.Info(); i.IsInstance = A_arbace_c2a_text_at_A_InstanceOf; i.Init = A_arbace_c2a_text_at_A_Init; i.Table = A_arbace_c2a_text_at_A_members; jrt.RegisterGoType(A_arbace_c2a_text_at_A_class, reflect.TypeFor[A_arbace_c2a_text_at_A]()) }

func A_arbace_c2a_text_branches_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_branches_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_branches_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_branches_A_New()}; return nil }

func A_arbace_c2a_text_branches_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_branches_A_fn_class)}; return nil }

var A_arbace_c2a_text_branches_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_branches_A_invoke, New: A_arbace_c2a_text_branches_A_new, Get: A_arbace_c2a_text_branches_A_get}

var A_arbace_c2a_text_branches_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$branches", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "branches", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_branches_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_branches_A_class.Info(); i.IsInstance = A_arbace_c2a_text_branches_A_InstanceOf; i.Init = A_arbace_c2a_text_branches_A_Init; i.Table = A_arbace_c2a_text_branches_A_members; jrt.RegisterGoType(A_arbace_c2a_text_branches_A_class, reflect.TypeFor[A_arbace_c2a_text_branches_A]()) }

func A_arbace_c2a_text_char_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_char_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_char_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_char_end_A_New()}; return nil }

func A_arbace_c2a_text_char_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_char_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_char_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_char_end_A_invoke, New: A_arbace_c2a_text_char_end_A_new, Get: A_arbace_c2a_text_char_end_A_get}

var A_arbace_c2a_text_char_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$char_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "char_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_char_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_char_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_char_end_A_InstanceOf; i.Init = A_arbace_c2a_text_char_end_A_Init; i.Table = A_arbace_c2a_text_char_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_char_end_A_class, reflect.TypeFor[A_arbace_c2a_text_char_end_A]()) }

func A_arbace_c2a_text_code_tokens_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_code_tokens_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_code_tokens_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_code_tokens_A_New()}; return nil }

func A_arbace_c2a_text_code_tokens_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_code_tokens_A_fn_class)}; return nil }

var A_arbace_c2a_text_code_tokens_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_code_tokens_A_invoke, New: A_arbace_c2a_text_code_tokens_A_new, Get: A_arbace_c2a_text_code_tokens_A_get}

var A_arbace_c2a_text_code_tokens_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$code_tokens", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "code_tokens", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_code_tokens_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_code_tokens_A_class.Info(); i.IsInstance = A_arbace_c2a_text_code_tokens_A_InstanceOf; i.Init = A_arbace_c2a_text_code_tokens_A_Init; i.Table = A_arbace_c2a_text_code_tokens_A_members; jrt.RegisterGoType(A_arbace_c2a_text_code_tokens_A_class, reflect.TypeFor[A_arbace_c2a_text_code_tokens_A]()) }

func A_arbace_c2a_text_coll_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_coll_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_coll_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_coll_end_A_New()}; return nil }

func A_arbace_c2a_text_coll_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_coll_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_coll_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_coll_end_A_invoke, New: A_arbace_c2a_text_coll_end_A_new, Get: A_arbace_c2a_text_coll_end_A_get}

var A_arbace_c2a_text_coll_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$coll_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "coll_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_coll_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_coll_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_coll_end_A_InstanceOf; i.Init = A_arbace_c2a_text_coll_end_A_Init; i.Table = A_arbace_c2a_text_coll_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_coll_end_A_class, reflect.TypeFor[A_arbace_c2a_text_coll_end_A]()) }

func A_arbace_c2a_text_cond_open_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_cond_open_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_cond_open_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_cond_open_A_New()}; return nil }

func A_arbace_c2a_text_cond_open_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_cond_open_A_fn_class)}; return nil }

var A_arbace_c2a_text_cond_open_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_cond_open_A_invoke, New: A_arbace_c2a_text_cond_open_A_new, Get: A_arbace_c2a_text_cond_open_A_get}

var A_arbace_c2a_text_cond_open_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$cond_open", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "cond_open", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_cond_open_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_cond_open_A_class.Info(); i.IsInstance = A_arbace_c2a_text_cond_open_A_InstanceOf; i.Init = A_arbace_c2a_text_cond_open_A_Init; i.Table = A_arbace_c2a_text_cond_open_A_members; jrt.RegisterGoType(A_arbace_c2a_text_cond_open_A_class, reflect.TypeFor[A_arbace_c2a_text_cond_open_A]()) }

func A_arbace_c2a_text_cond_open_fn__1948000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_cond_open_fn__1948000030_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_text_cond_open_fn__1948000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_cond_open_fn__1948000030_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_cond_open_fn__1948000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_cond_open_fn__1948000030_A_fn_class)}; return nil }

var A_arbace_c2a_text_cond_open_fn__1948000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_cond_open_fn__1948000030_A_invoke, New: A_arbace_c2a_text_cond_open_fn__1948000030_A_new, Get: A_arbace_c2a_text_cond_open_fn__1948000030_A_get}

var A_arbace_c2a_text_cond_open_fn__1948000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$cond_open$fn__1948000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_text_cond_open_A_class, Simple: "fn__1948000030", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_cond_open_fn__1948000030_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_cond_open_fn__1948000030_A_class.Info(); i.IsInstance = A_arbace_c2a_text_cond_open_fn__1948000030_A_InstanceOf; i.Init = A_arbace_c2a_text_cond_open_fn__1948000030_A_Init; i.Table = A_arbace_c2a_text_cond_open_fn__1948000030_A_members; jrt.RegisterGoType(A_arbace_c2a_text_cond_open_fn__1948000030_A_class, reflect.TypeFor[A_arbace_c2a_text_cond_open_fn__1948000030_A]()) }

func A_arbace_c2a_text_eval1948000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_eval1948000004_A_New()}; return nil }

var A_arbace_c2a_text_eval1948000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_text_eval1948000004_A_new}

var A_arbace_c2a_text_eval1948000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$eval1948000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_text_A_class, Simple: "eval1948000004", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000004_A"})

func init() { i := A_arbace_c2a_text_eval1948000004_A_class.Info(); i.IsInstance = A_arbace_c2a_text_eval1948000004_A_InstanceOf; i.Table = A_arbace_c2a_text_eval1948000004_A_members; jrt.RegisterGoType(A_arbace_c2a_text_eval1948000004_A_class, reflect.TypeFor[A_arbace_c2a_text_eval1948000004_A]()) }

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_New()}; return nil }

func A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_fn_class)}; return nil }

var A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_invoke, New: A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_new, Get: A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_get}

var A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$eval1948000004$loading__1927001464__auto____1948000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_text_eval1948000004_A_class, Simple: "loading__1927001464__auto____1948000005", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class.Info(); i.IsInstance = A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_InstanceOf; i.Init = A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_Init; i.Table = A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_members; jrt.RegisterGoType(A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_class, reflect.TypeFor[A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A]()) }

func A_arbace_c2a_text_eval1948000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_eval1948000008_A_New()}; return nil }

var A_arbace_c2a_text_eval1948000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_c2a_text_eval1948000008_A_new}

var A_arbace_c2a_text_eval1948000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$eval1948000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_c2a_text_A_class, Simple: "eval1948000008", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000008_A"})

func init() { i := A_arbace_c2a_text_eval1948000008_A_class.Info(); i.IsInstance = A_arbace_c2a_text_eval1948000008_A_InstanceOf; i.Table = A_arbace_c2a_text_eval1948000008_A_members; jrt.RegisterGoType(A_arbace_c2a_text_eval1948000008_A_class, reflect.TypeFor[A_arbace_c2a_text_eval1948000008_A]()) }

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_eval1948000008_fn__1948000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_eval1948000008_fn__1948000009_A_New()}; return nil }

func A_arbace_c2a_text_eval1948000008_fn__1948000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_eval1948000008_fn__1948000009_A_fn_class)}; return nil }

var A_arbace_c2a_text_eval1948000008_fn__1948000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_eval1948000008_fn__1948000009_A_invoke, New: A_arbace_c2a_text_eval1948000008_fn__1948000009_A_new, Get: A_arbace_c2a_text_eval1948000008_fn__1948000009_A_get}

var A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$eval1948000008$fn__1948000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_c2a_text_eval1948000008_A_class, Simple: "fn__1948000009", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_eval1948000008_fn__1948000009_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class.Info(); i.IsInstance = A_arbace_c2a_text_eval1948000008_fn__1948000009_A_InstanceOf; i.Init = A_arbace_c2a_text_eval1948000008_fn__1948000009_A_Init; i.Table = A_arbace_c2a_text_eval1948000008_fn__1948000009_A_members; jrt.RegisterGoType(A_arbace_c2a_text_eval1948000008_fn__1948000009_A_class, reflect.TypeFor[A_arbace_c2a_text_eval1948000008_fn__1948000009_A]()) }

func A_arbace_c2a_text_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_fail_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_c2a_text_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_fail_A_New()}; return nil }

func A_arbace_c2a_text_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_fail_A_fn_class)}; return nil }

var A_arbace_c2a_text_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_fail_A_invoke, New: A_arbace_c2a_text_fail_A_new, Get: A_arbace_c2a_text_fail_A_get}

var A_arbace_c2a_text_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "fail", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_fail_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_fail_A_class.Info(); i.IsInstance = A_arbace_c2a_text_fail_A_InstanceOf; i.Init = A_arbace_c2a_text_fail_A_Init; i.Table = A_arbace_c2a_text_fail_A_members; jrt.RegisterGoType(A_arbace_c2a_text_fail_A_class, reflect.TypeFor[A_arbace_c2a_text_fail_A]()) }

func A_arbace_c2a_text_fail_fn__1948000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_fail_fn__1948000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_fail_fn__1948000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_fail_fn__1948000013_A_New()}; return nil }

func A_arbace_c2a_text_fail_fn__1948000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_fail_fn__1948000013_A_fn_class)}; return nil }

var A_arbace_c2a_text_fail_fn__1948000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_fail_fn__1948000013_A_invoke, New: A_arbace_c2a_text_fail_fn__1948000013_A_new, Get: A_arbace_c2a_text_fail_fn__1948000013_A_get}

var A_arbace_c2a_text_fail_fn__1948000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$fail$fn__1948000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_fail_A_class, Simple: "fn__1948000013", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_fail_fn__1948000013_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_fail_fn__1948000013_A_class.Info(); i.IsInstance = A_arbace_c2a_text_fail_fn__1948000013_A_InstanceOf; i.Init = A_arbace_c2a_text_fail_fn__1948000013_A_Init; i.Table = A_arbace_c2a_text_fail_fn__1948000013_A_members; jrt.RegisterGoType(A_arbace_c2a_text_fail_fn__1948000013_A_class, reflect.TypeFor[A_arbace_c2a_text_fail_fn__1948000013_A]()) }

func A_arbace_c2a_text_form_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_form_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_form_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_form_end_A_New()}; return nil }

func A_arbace_c2a_text_form_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_form_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_form_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_form_end_A_invoke, New: A_arbace_c2a_text_form_end_A_new, Get: A_arbace_c2a_text_form_end_A_get}

var A_arbace_c2a_text_form_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$form_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "form_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_form_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_form_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_form_end_A_InstanceOf; i.Init = A_arbace_c2a_text_form_end_A_Init; i.Table = A_arbace_c2a_text_form_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_form_end_A_class, reflect.TypeFor[A_arbace_c2a_text_form_end_A]()) }

func A_arbace_c2a_text_line_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_line_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_line_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_line_end_A_New()}; return nil }

func A_arbace_c2a_text_line_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_line_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_line_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_line_end_A_invoke, New: A_arbace_c2a_text_line_end_A_new, Get: A_arbace_c2a_text_line_end_A_get}

var A_arbace_c2a_text_line_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$line_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "line_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_line_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_line_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_line_end_A_InstanceOf; i.Init = A_arbace_c2a_text_line_end_A_Init; i.Table = A_arbace_c2a_text_line_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_line_end_A_class, reflect.TypeFor[A_arbace_c2a_text_line_end_A]()) }

func A_arbace_c2a_text_list_spans_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_list_spans_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_list_spans_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_list_spans_A_New()}; return nil }

func A_arbace_c2a_text_list_spans_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_list_spans_A_fn_class)}; return nil }

var A_arbace_c2a_text_list_spans_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_list_spans_A_invoke, New: A_arbace_c2a_text_list_spans_A_new, Get: A_arbace_c2a_text_list_spans_A_get}

var A_arbace_c2a_text_list_spans_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$list_spans", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "list_spans", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_list_spans_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_list_spans_A_class.Info(); i.IsInstance = A_arbace_c2a_text_list_spans_A_InstanceOf; i.Init = A_arbace_c2a_text_list_spans_A_Init; i.Table = A_arbace_c2a_text_list_spans_A_members; jrt.RegisterGoType(A_arbace_c2a_text_list_spans_A_class, reflect.TypeFor[A_arbace_c2a_text_list_spans_A]()) }

func A_arbace_c2a_text_next_form_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_next_form_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_next_form_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_next_form_end_A_New()}; return nil }

func A_arbace_c2a_text_next_form_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_next_form_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_next_form_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_next_form_end_A_invoke, New: A_arbace_c2a_text_next_form_end_A_new, Get: A_arbace_c2a_text_next_form_end_A_get}

var A_arbace_c2a_text_next_form_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$next_form_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "next_form_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_next_form_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_next_form_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_next_form_end_A_InstanceOf; i.Init = A_arbace_c2a_text_next_form_end_A_Init; i.Table = A_arbace_c2a_text_next_form_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_next_form_end_A_class, reflect.TypeFor[A_arbace_c2a_text_next_form_end_A]()) }

func A_arbace_c2a_text_resolve_conditionals_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_resolve_conditionals_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_c2a_text_resolve_conditionals_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_resolve_conditionals_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_resolve_conditionals_A_New()}; return nil }

func A_arbace_c2a_text_resolve_conditionals_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_resolve_conditionals_A_fn_class)}; return nil }

var A_arbace_c2a_text_resolve_conditionals_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_resolve_conditionals_A_invoke, New: A_arbace_c2a_text_resolve_conditionals_A_new, Get: A_arbace_c2a_text_resolve_conditionals_A_get}

var A_arbace_c2a_text_resolve_conditionals_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$resolve_conditionals", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "resolve_conditionals", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_resolve_conditionals_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_resolve_conditionals_A_class.Info(); i.IsInstance = A_arbace_c2a_text_resolve_conditionals_A_InstanceOf; i.Init = A_arbace_c2a_text_resolve_conditionals_A_Init; i.Table = A_arbace_c2a_text_resolve_conditionals_A_members; jrt.RegisterGoType(A_arbace_c2a_text_resolve_conditionals_A_class, reflect.TypeFor[A_arbace_c2a_text_resolve_conditionals_A]()) }

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_fn_class)}; return nil }

var A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_invoke, New: A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_new, Get: A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_get}

var A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$resolve_conditionals$copy__1948000048", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_resolve_conditionals_A_class, Simple: "copy__1948000048", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class.Info(); i.IsInstance = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_InstanceOf; i.Init = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_Init; i.Table = A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_members; jrt.RegisterGoType(A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A_class, reflect.TypeFor[A_arbace_c2a_text_resolve_conditionals_copy__1948000048_A]()) }

func A_arbace_c2a_text_selected_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_selected_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_c2a_text_selected_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_selected_A_New()}; return nil }

func A_arbace_c2a_text_selected_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_selected_A_fn_class)}; return nil }

var A_arbace_c2a_text_selected_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_selected_A_invoke, New: A_arbace_c2a_text_selected_A_new, Get: A_arbace_c2a_text_selected_A_get}

var A_arbace_c2a_text_selected_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$selected", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "selected", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_selected_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_selected_A_class.Info(); i.IsInstance = A_arbace_c2a_text_selected_A_InstanceOf; i.Init = A_arbace_c2a_text_selected_A_Init; i.Table = A_arbace_c2a_text_selected_A_members; jrt.RegisterGoType(A_arbace_c2a_text_selected_A_class, reflect.TypeFor[A_arbace_c2a_text_selected_A]()) }

func A_arbace_c2a_text_selected_fn__1948000038_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_selected_fn__1948000038_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_selected_fn__1948000038_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_selected_fn__1948000038_A_New_O(args[0])}; return nil }

func A_arbace_c2a_text_selected_fn__1948000038_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_selected_fn__1948000038_A_fn_class)}; return nil }

var A_arbace_c2a_text_selected_fn__1948000038_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_selected_fn__1948000038_A_invoke, New: A_arbace_c2a_text_selected_fn__1948000038_A_new, Get: A_arbace_c2a_text_selected_fn__1948000038_A_get}

var A_arbace_c2a_text_selected_fn__1948000038_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$selected$fn__1948000038", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_selected_A_class, Simple: "fn__1948000038", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_selected_fn__1948000038_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_selected_fn__1948000038_A_class.Info(); i.IsInstance = A_arbace_c2a_text_selected_fn__1948000038_A_InstanceOf; i.Init = A_arbace_c2a_text_selected_fn__1948000038_A_Init; i.Table = A_arbace_c2a_text_selected_fn__1948000038_A_members; jrt.RegisterGoType(A_arbace_c2a_text_selected_fn__1948000038_A_class, reflect.TypeFor[A_arbace_c2a_text_selected_fn__1948000038_A]()) }

func A_arbace_c2a_text_skip_ws_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_skip_ws_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_skip_ws_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_skip_ws_A_New()}; return nil }

func A_arbace_c2a_text_skip_ws_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_skip_ws_A_fn_class)}; return nil }

var A_arbace_c2a_text_skip_ws_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_skip_ws_A_invoke, New: A_arbace_c2a_text_skip_ws_A_new, Get: A_arbace_c2a_text_skip_ws_A_get}

var A_arbace_c2a_text_skip_ws_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$skip_ws", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "skip_ws", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_skip_ws_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_skip_ws_A_class.Info(); i.IsInstance = A_arbace_c2a_text_skip_ws_A_InstanceOf; i.Init = A_arbace_c2a_text_skip_ws_A_Init; i.Table = A_arbace_c2a_text_skip_ws_A_members; jrt.RegisterGoType(A_arbace_c2a_text_skip_ws_A_class, reflect.TypeFor[A_arbace_c2a_text_skip_ws_A]()) }

func A_arbace_c2a_text_string_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_string_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_string_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_string_end_A_New()}; return nil }

func A_arbace_c2a_text_string_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_string_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_string_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_string_end_A_invoke, New: A_arbace_c2a_text_string_end_A_new, Get: A_arbace_c2a_text_string_end_A_get}

var A_arbace_c2a_text_string_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$string_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "string_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_string_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_string_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_string_end_A_InstanceOf; i.Init = A_arbace_c2a_text_string_end_A_Init; i.Table = A_arbace_c2a_text_string_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_string_end_A_class, reflect.TypeFor[A_arbace_c2a_text_string_end_A]()) }

func A_arbace_c2a_text_terminating_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_terminating_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_terminating_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_terminating_QMARK__A_New()}; return nil }

func A_arbace_c2a_text_terminating_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_terminating_QMARK__A_fn_class)}; return nil }

var A_arbace_c2a_text_terminating_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_terminating_QMARK__A_invoke, New: A_arbace_c2a_text_terminating_QMARK__A_new, Get: A_arbace_c2a_text_terminating_QMARK__A_get}

var A_arbace_c2a_text_terminating_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$terminating_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "terminating_QMARK_", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_terminating_QMARK__A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_terminating_QMARK__A_class.Info(); i.IsInstance = A_arbace_c2a_text_terminating_QMARK__A_InstanceOf; i.Init = A_arbace_c2a_text_terminating_QMARK__A_Init; i.Table = A_arbace_c2a_text_terminating_QMARK__A_members; jrt.RegisterGoType(A_arbace_c2a_text_terminating_QMARK__A_class, reflect.TypeFor[A_arbace_c2a_text_terminating_QMARK__A]()) }

func A_arbace_c2a_text_token_end_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_token_end_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_c2a_text_token_end_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_token_end_A_New()}; return nil }

func A_arbace_c2a_text_token_end_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_token_end_A_fn_class)}; return nil }

var A_arbace_c2a_text_token_end_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_token_end_A_invoke, New: A_arbace_c2a_text_token_end_A_new, Get: A_arbace_c2a_text_token_end_A_get}

var A_arbace_c2a_text_token_end_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$token_end", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "token_end", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_token_end_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_token_end_A_class.Info(); i.IsInstance = A_arbace_c2a_text_token_end_A_InstanceOf; i.Init = A_arbace_c2a_text_token_end_A_Init; i.Table = A_arbace_c2a_text_token_end_A_members; jrt.RegisterGoType(A_arbace_c2a_text_token_end_A_class, reflect.TypeFor[A_arbace_c2a_text_token_end_A]()) }

func A_arbace_c2a_text_ws_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_c2a_text_ws_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_c2a_text_ws_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text_ws_QMARK__A_New()}; return nil }

func A_arbace_c2a_text_ws_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_c2a_text_ws_QMARK__A_fn_class)}; return nil }

var A_arbace_c2a_text_ws_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_c2a_text_ws_QMARK__A_invoke, New: A_arbace_c2a_text_ws_QMARK__A_new, Get: A_arbace_c2a_text_ws_QMARK__A_get}

var A_arbace_c2a_text_ws_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text$ws_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_c2a_text_A_class, Simple: "ws_QMARK_", Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text_ws_QMARK__A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text_ws_QMARK__A_class.Info(); i.IsInstance = A_arbace_c2a_text_ws_QMARK__A_InstanceOf; i.Init = A_arbace_c2a_text_ws_QMARK__A_Init; i.Table = A_arbace_c2a_text_ws_QMARK__A_members; jrt.RegisterGoType(A_arbace_c2a_text_ws_QMARK__A_class, reflect.TypeFor[A_arbace_c2a_text_ws_QMARK__A]()) }

func A_arbace_c2a_text__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_c2a_text__init_A_Load__O(); case 1: return A_arbace_c2a_text__init_A_Unit0__O(); case 2: return A_arbace_c2a_text__init_A_Unit1__O(); case 3: return A_arbace_c2a_text__init_A_Unit10__O(); case 4: return A_arbace_c2a_text__init_A_Unit11__O(); case 5: return A_arbace_c2a_text__init_A_Unit12__O(); case 6: return A_arbace_c2a_text__init_A_Unit13__O(); case 7: return A_arbace_c2a_text__init_A_Unit14__O(); case 8: return A_arbace_c2a_text__init_A_Unit15__O(); case 9: return A_arbace_c2a_text__init_A_Unit16__O(); case 10: return A_arbace_c2a_text__init_A_Unit17__O(); case 11: return A_arbace_c2a_text__init_A_Unit18__O(); case 12: return A_arbace_c2a_text__init_A_Unit19__O(); case 13: return A_arbace_c2a_text__init_A_Unit2__O(); case 14: return A_arbace_c2a_text__init_A_Unit20__O(); case 15: return A_arbace_c2a_text__init_A_Unit21__O(); case 16: return A_arbace_c2a_text__init_A_Unit22__O(); case 17: return A_arbace_c2a_text__init_A_Unit23__O(); case 18: return A_arbace_c2a_text__init_A_Unit24__O(); case 19: return A_arbace_c2a_text__init_A_Unit25__O(); case 20: return A_arbace_c2a_text__init_A_Unit3__O(); case 21: return A_arbace_c2a_text__init_A_Unit4__O(); case 22: return A_arbace_c2a_text__init_A_Unit5__O(); case 23: return A_arbace_c2a_text__init_A_Unit6__O(); case 24: return A_arbace_c2a_text__init_A_Unit7__O(); case 25: return A_arbace_c2a_text__init_A_Unit8__O(); case 26: return A_arbace_c2a_text__init_A_Unit9__O()}; return nil }

func A_arbace_c2a_text__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_c2a_text__init_A_New()}; return nil }

var A_arbace_c2a_text__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_c2a_text__init_A_invoke, New: A_arbace_c2a_text__init_A_new}

var A_arbace_c2a_text__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.c2a.text__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_c2a_text.A_arbace_c2a_text__init_A", Source: "text.ae"})

func init() { i := A_arbace_c2a_text__init_A_class.Info(); i.IsInstance = A_arbace_c2a_text__init_A_InstanceOf; i.Init = A_arbace_c2a_text__init_A_Init; i.Table = A_arbace_c2a_text__init_A_members; jrt.RegisterGoType(A_arbace_c2a_text__init_A_class, reflect.TypeFor[A_arbace_c2a_text__init_A]()) }
