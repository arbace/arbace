//line a2g_strings.ae:1
package aot_arbace_c2a_text

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("commute")

var Lit_7 *jrt.String = jrt.Intern("deref")

var Lit_8 *jrt.String = jrt.Intern("conj")

var Lit_9 *jrt.String = jrt.Intern("arbace.c2a.text")

var Lit_10 *jrt.String = jrt.Intern("doc")

var Lit_11 *jrt.String = jrt.Intern("Clojure source text, read lexically as the reader would, for c2a's rules: they rewrite text\n  and keep everything else (layout, comments) as it is. The scanner knows the reader's\n  lexical syntax (doc/C2A.md, \"How it reads\"): strings, regex literals, character literals,\n  comments (`;`, `#!`), discarded forms (`#_`), dispatch macros, tagged literals, metadata,\n  the quoting macros and tokens (symbols, keywords, numbers), which run until whitespace or a\n  terminating macro character, as LispReader's do. It does not build forms: it finds where\n  they begin and end.\n\n  - `form-end`: the end of the form beginning at an index;\n  - `resolve-conditionals`: reader conditionals (`#?`, `#?@`) replaced by their selected\n    branch's text, for a .cljc file becoming a .ae file (which the reader reads without\n    conditionals);\n  - `code-tokens`: the spans of the tokens outside strings, comments and character literals,\n    for rules that rewrite symbols; `list-spans`: the spans of the lists a token heads.")

var Lit_12 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_13 *jrt.String = jrt.Intern("filter")

var Lit_14 *jrt.String = jrt.Intern("ex-info")

var Lit_15 *jrt.String = jrt.Intern("subs")

var Lit_16 *jrt.String = jrt.Intern("index")

var Lit_17 *jrt.String = jrt.Intern("line")

var Lit_18 *jrt.String = jrt.Intern("ws?")

var Lit_19 *jrt.String = jrt.Intern("not")

var Lit_20 *jrt.String = jrt.Intern("terminating?")

var Lit_21 *jrt.String = jrt.Intern("fail")

var Lit_22 *jrt.String = jrt.Intern("else")

var Lit_23 *jrt.String = jrt.Intern("token-end")

var Lit_24 *jrt.String = jrt.Intern("at")

var Lit_25 *jrt.String = jrt.Intern("line-end")

var Lit_26 *jrt.String = jrt.Intern("form-end")

var Lit_27 *jrt.String = jrt.Intern("skip-ws")

var Lit_28 *jrt.String = jrt.Intern("closer")

var Lit_29 *jrt.String = jrt.Intern("string-end")

var Lit_30 *jrt.String = jrt.Intern("next-form-end")

var Lit_31 *jrt.String = jrt.Intern("coll-end")

var Lit_32 *jrt.String = jrt.Intern("cond-open")

var Lit_33 *jrt.String = jrt.Intern("char-end")

var Lit_34 *jrt.String = jrt.Intern("starts-with?")

var Lit_35 *jrt.String = jrt.Intern("keyword")

var Lit_36 *jrt.String = jrt.Intern("first")

var Lit_37 *jrt.String = jrt.Intern("resolve-conditionals")

var Lit_38 *jrt.String = jrt.Intern("contains?")

var Lit_39 *jrt.String = jrt.Intern("default")

var Lit_40 *jrt.String = jrt.Intern("branches")

var Lit_41 *jrt.String = jrt.Intern("includes?")

var Lit_42 *jrt.String = jrt.Intern("selected")

var Lit_43 *jrt.String = jrt.Intern("clj")

var Lit_44 *jrt.String = jrt.Intern("transient")

var Lit_45 *jrt.String = jrt.Intern("persistent!")

var Lit_46 *jrt.String = jrt.Intern("conj!")

var Lit_47 *jrt.String = jrt.Intern("arbace.c2a.text$at")

var Lit_48 *jrt.String = jrt.Intern("arbace.c2a.text$branches")

var Lit_49 *jrt.String = jrt.Intern(":")

var Lit_50 *jrt.String = jrt.Intern("Feature should be a keyword")

var Lit_51 *jrt.String = jrt.Intern("read-cond requires an even number of forms")

var Lit_52 *jrt.String = jrt.Intern("arbace.c2a.text$char_end")

var Lit_53 *jrt.String = jrt.Intern("EOF while reading a character")

var Lit_54 *jrt.String = jrt.Intern("arbace.c2a.text$code_tokens")

var Lit_55 *jrt.String = jrt.Intern("arbace.c2a.text$coll_end")

var Lit_56 *jrt.String = jrt.Intern("EOF while reading, expected ")

var Lit_57 *jrt.String = jrt.Intern("Unmatched delimiter: ")

var Lit_58 *jrt.String = jrt.Intern("arbace.c2a.text$cond_open")

var Lit_59 *jrt.String = jrt.Intern("read-cond body must be a list")

var Lit_60 *jrt.String = jrt.Intern("arbace.c2a.text$cond_open$fn__1948000030")

var Lit_61 *jrt.String = jrt.Intern("arbace.c2a.text$eval1948000004$loading__1927001464__auto____1948000005")

var Lit_62 *jrt.String = jrt.Intern("arbace.c2a.text$eval1948000008$fn__1948000009")

var Lit_63 *jrt.String = jrt.Intern("arbace.c2a.text$fail")

var Lit_64 *jrt.String = jrt.Intern(" (line ")

var Lit_65 *jrt.String = jrt.Intern(")")

var Lit_66 *jrt.String = jrt.Intern("arbace.c2a.text$fail$fn__1948000013")

var Lit_67 *jrt.String = jrt.Intern("arbace.c2a.text$form_end")

var Lit_68 *jrt.String = jrt.Intern("EOF while reading")

var Lit_69 *jrt.String = jrt.Intern("EOF while reading a dispatch macro")

var Lit_70 *jrt.String = jrt.Intern("Namespaced map must specify a map")

var Lit_71 *jrt.String = jrt.Intern("arbace.c2a.text$line_end")

var Lit_72 *jrt.String = jrt.Intern("\n")

var Lit_73 *jrt.String = jrt.Intern("arbace.c2a.text$list_spans")

var Lit_74 *jrt.String = jrt.Intern("arbace.c2a.text$next_form_end")

var Lit_75 *jrt.String = jrt.Intern("arbace.c2a.text$resolve_conditionals")

var Lit_76 *jrt.String = jrt.Intern("#?")

var Lit_77 *jrt.String = jrt.Intern("arbace.c2a.text$resolve_conditionals$copy__1948000048")

var Lit_78 *jrt.String = jrt.Intern("arbace.c2a.text$selected")

var Lit_79 *jrt.String = jrt.Intern("Reader conditional splicing not allowed at the top level.")

var Lit_80 *jrt.String = jrt.Intern("")

var Lit_81 *jrt.String = jrt.Intern("Spliced form list in read-conditional must implement java.util.List")

var Lit_82 *jrt.String = jrt.Intern("arbace.c2a.text$selected$fn__1948000038")

var Lit_83 *jrt.String = jrt.Intern("arbace.c2a.text$skip_ws")

var Lit_84 *jrt.String = jrt.Intern("arbace.c2a.text$string_end")

var Lit_85 *jrt.String = jrt.Intern("EOF while reading a string")

var Lit_86 *jrt.String = jrt.Intern("arbace.c2a.text$terminating_QMARK_")

var Lit_87 *jrt.String = jrt.Intern("arbace.c2a.text$token_end")

var Lit_88 *jrt.String = jrt.Intern("arbace.c2a.text$ws_QMARK_")

var Lit_89 *jrt.String = jrt.Intern("in-ns")

var Lit_90 *jrt.String = jrt.Intern("private")

var Lit_91 *jrt.String = jrt.Intern("arglists")

var Lit_92 *jrt.String = jrt.Intern("s")

var Lit_93 *jrt.String = jrt.Intern("tag")

var Lit_94 *jrt.String = jrt.Intern("String")

var Lit_95 *jrt.String = jrt.Intern("i")

var Lit_96 *jrt.String = jrt.Intern("msg")

var Lit_97 *jrt.String = jrt.Intern("column")

var Lit_98 *jrt.String = jrt.Intern("file")

var Lit_99 *jrt.String = jrt.Intern("arbace/c2a/text.ae")

var Lit_100 *jrt.String = jrt.Intern("c")

var Lit_101 *jrt.String = jrt.Intern("Whether c ends a token: whitespace or a terminating macro character of LispReader (`#`\n  and `'` are not: they may occur inside a symbol).")

var Lit_102 *jrt.String = jrt.Intern("The end of the token beginning at i.")

var Lit_103 *jrt.String = jrt.Intern("The end of the string (or regex) literal whose opening quote is at i.")

var Lit_104 *jrt.String = jrt.Intern("The end of the character literal whose backslash is at i: the character after it, then a\n  token's characters (`\\newline`, `\\u0041`).")

var Lit_105 *jrt.String = jrt.Intern("declared")

var Lit_106 *jrt.String = jrt.Intern("The index of the next form at or after i: whitespace, commas, comments (`;`, `#!`) and\n  discarded forms (`#_`) skipped.")

var Lit_107 *jrt.String = jrt.Intern("The end of the collection whose opening delimiter is at i.")

var Lit_108 *jrt.String = jrt.Intern("The end of the form beginning at i (not whitespace).")

var Lit_109 *jrt.String = jrt.Intern("The index of the list of the reader conditional at i (`#?` or `#?@`, then whitespace, as\n  ConditionalReader allows).")

var Lit_110 *jrt.String = jrt.Intern("The branches of the reader conditional whose list opens at i: [feature value-start\n  value-end] for each.")

var Lit_111 *jrt.String = jrt.Intern("features")

var Lit_112 *jrt.String = jrt.Intern("depth")

var Lit_113 *jrt.String = jrt.Intern("The text a reader conditional at i reads as, for the platform features: the first branch\n  whose feature is one of them or :default (as LispReader chooses), with its own conditionals\n  resolved; spliced (`#?@`), the contents of its list or vector; none: empty.")

var Lit_114 *jrt.String = jrt.Intern("Source text s with each reader conditional replaced by the text it reads as on a platform\n  with the features (a set of keywords, Arbace's #{:clj}): its selected branch, verbatim\n  (spliced: the contents of its list), or nothing. Everything else is kept as it is.")

var Lit_115 *jrt.String = jrt.Intern("code-tokens")

var Lit_116 *jrt.String = jrt.Intern("The [start end] spans of the tokens of s (symbols, keywords, numbers, the tags of tagged\n  literals) outside strings, regex and character literals and comments, in order.")

var Lit_117 *jrt.String = jrt.Intern("list-spans")

var Lit_118 *jrt.String = jrt.Intern("pred")

var Lit_119 *jrt.String = jrt.Intern("The [start end] spans of the lists of s whose head token satisfies pred.")
