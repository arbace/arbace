//line aot_arbace_c2a_text__init.ae:1
package aot_arbace_c2a_text

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_c2a_text__init_A_Unit0__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_c2a_text__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_c2a_text__init_A_const_1) }
//line :1:1
func A_arbace_c2a_text__init_A_Unit1__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_c2a_text__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_2)) }
//line :1:1
func A_arbace_c2a_text__init_A_Unit2__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_Init(); tmp2 = A_arbace_c2a_text_eval1948000004_loading__1927001464__auto____1948000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_c2a_text__init_A_Unit3__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_c2a_text__init_A_const_1)).Equals_O__Z(A_arbace_c2a_text__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_c2a_text_eval1948000008_fn__1948000009_A_New(); var tmp2 *jrt.Class; A_arbace_c2a_text_eval1948000008_fn__1948000009_A_Init(); tmp2 = A_arbace_c2a_text_eval1948000008_fn__1948000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_c2a_text__init_A_Load__O() any { A_arbace_c2a_text__init_A_Init(); A_arbace_c2a_text__init_A_Unit0__O(); A_arbace_c2a_text__init_A_Unit1__O(); A_arbace_c2a_text__init_A_Unit2__O(); A_arbace_c2a_text__init_A_Unit3__O(); A_arbace_c2a_text__init_A_Unit4__O(); A_arbace_c2a_text__init_A_Unit5__O(); A_arbace_c2a_text__init_A_Unit6__O(); A_arbace_c2a_text__init_A_Unit7__O(); A_arbace_c2a_text__init_A_Unit8__O(); A_arbace_c2a_text__init_A_Unit9__O(); A_arbace_c2a_text__init_A_Unit10__O(); A_arbace_c2a_text__init_A_Unit11__O(); A_arbace_c2a_text__init_A_Unit12__O(); A_arbace_c2a_text__init_A_Unit13__O(); A_arbace_c2a_text__init_A_Unit14__O(); A_arbace_c2a_text__init_A_Unit15__O(); A_arbace_c2a_text__init_A_Unit16__O(); A_arbace_c2a_text__init_A_Unit17__O(); A_arbace_c2a_text__init_A_Unit18__O(); A_arbace_c2a_text__init_A_Unit19__O(); A_arbace_c2a_text__init_A_Unit20__O(); A_arbace_c2a_text__init_A_Unit21__O(); A_arbace_c2a_text__init_A_Unit22__O(); A_arbace_c2a_text__init_A_Unit23__O(); A_arbace_c2a_text__init_A_Unit24__O(); A_arbace_c2a_text__init_A_Unit25__O(); return nil }












func A_arbace_c2a_text__init_A_Unit4__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_4; var tmp2 any = A_arbace_c2a_text_fail_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_fail_A_Init(); tmp3 = A_arbace_c2a_text_fail_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_5)); return A_arbace_c2a_text__init_A_const_4.Ref() }



func A_arbace_c2a_text__init_A_Unit5__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_6; var tmp2 any = A_arbace_c2a_text_ws_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_ws_QMARK__A_Init(); tmp3 = A_arbace_c2a_text_ws_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_7)); return A_arbace_c2a_text__init_A_const_6.Ref() }

func A_arbace_c2a_text__init_A_Unit6__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_8; var tmp2 any = A_arbace_c2a_text_terminating_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_terminating_QMARK__A_Init(); tmp3 = A_arbace_c2a_text_terminating_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_9)); return A_arbace_c2a_text__init_A_const_8.Ref() }





func A_arbace_c2a_text__init_A_Unit7__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_10; var tmp2 any = A_arbace_c2a_text_at_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_at_A_Init(); tmp3 = A_arbace_c2a_text_at_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_11)); return A_arbace_c2a_text__init_A_const_10.Ref() }

func A_arbace_c2a_text__init_A_Unit8__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(32, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_12; var tmp2 any = A_arbace_c2a_text_line_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_line_end_A_Init(); tmp3 = A_arbace_c2a_text_line_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_13)); return A_arbace_c2a_text__init_A_const_12.Ref() }


func A_arbace_c2a_text__init_A_Unit9__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(35, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_14; var tmp2 any = A_arbace_c2a_text_token_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_token_end_A_Init(); tmp3 = A_arbace_c2a_text_token_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_15)); return A_arbace_c2a_text__init_A_const_14.Ref() }





func A_arbace_c2a_text__init_A_Unit10__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(41, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_16; var tmp2 any = A_arbace_c2a_text_string_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_string_end_A_Init(); tmp3 = A_arbace_c2a_text_string_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_17)); return A_arbace_c2a_text__init_A_const_16.Ref() }









func A_arbace_c2a_text__init_A_Unit11__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(51, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_18; var tmp2 any = A_arbace_c2a_text_char_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_char_end_A_Init(); tmp3 = A_arbace_c2a_text_char_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_19)); return A_arbace_c2a_text__init_A_const_18.Ref() }






func A_arbace_c2a_text__init_A_Unit12__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_20; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_21)); return A_arbace_c2a_text__init_A_const_20.Ref() }
//line :58:1
func A_arbace_c2a_text__init_A_Unit13__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(58, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_22; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_23)); return A_arbace_c2a_text__init_A_const_22.Ref() }

func A_arbace_c2a_text__init_A_Unit14__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(60, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_24; var tmp2 any = A_arbace_c2a_text_skip_ws_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_skip_ws_A_Init(); tmp3 = A_arbace_c2a_text_skip_ws_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_25)); return A_arbace_c2a_text__init_A_const_24.Ref() }














func A_arbace_c2a_text__init_A_Unit15__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); jrt.NN(A_arbace_c2a_text__init_A_const_26).BindRoot_O__V(A_arbace_c2a_text__init_A_const_27); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_26; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_28)); return A_arbace_c2a_text__init_A_const_26.Ref() }

func A_arbace_c2a_text__init_A_Unit16__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_29; var tmp2 any = A_arbace_c2a_text_coll_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_coll_end_A_Init(); tmp3 = A_arbace_c2a_text_coll_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_30)); return A_arbace_c2a_text__init_A_const_29.Ref() }










func A_arbace_c2a_text__init_A_Unit17__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(88, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_31; var tmp2 any = A_arbace_c2a_text_next_form_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_next_form_end_A_Init(); tmp3 = A_arbace_c2a_text_next_form_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_32)); return A_arbace_c2a_text__init_A_const_31.Ref() }




func A_arbace_c2a_text__init_A_Unit18__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(93, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_20; var tmp2 any = A_arbace_c2a_text_form_end_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_form_end_A_Init(); tmp3 = A_arbace_c2a_text_form_end_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_33)); return A_arbace_c2a_text__init_A_const_20.Ref() }
































func A_arbace_c2a_text__init_A_Unit19__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(126, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_22; var tmp2 any = A_arbace_c2a_text_cond_open_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_cond_open_A_Init(); tmp3 = A_arbace_c2a_text_cond_open_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_34)); return A_arbace_c2a_text__init_A_const_22.Ref() }








func A_arbace_c2a_text__init_A_Unit20__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_35; var tmp2 any = A_arbace_c2a_text_branches_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_branches_A_Init(); tmp3 = A_arbace_c2a_text_branches_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_36)); return A_arbace_c2a_text__init_A_const_35.Ref() }














func A_arbace_c2a_text__init_A_Unit21__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_37; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_38)); return A_arbace_c2a_text__init_A_const_37.Ref() }

func A_arbace_c2a_text__init_A_Unit22__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_39; var tmp2 any = A_arbace_c2a_text_selected_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_selected_A_Init(); tmp3 = A_arbace_c2a_text_selected_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_39; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_40)); return A_arbace_c2a_text__init_A_const_39.Ref() }















func A_arbace_c2a_text__init_A_Unit23__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(168, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_37; var tmp2 any = A_arbace_c2a_text_resolve_conditionals_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_resolve_conditionals_A_Init(); tmp3 = A_arbace_c2a_text_resolve_conditionals_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_41)); return A_arbace_c2a_text__init_A_const_37.Ref() }






























func A_arbace_c2a_text__init_A_Unit24__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(199, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_42; var tmp2 any = A_arbace_c2a_text_code_tokens_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_code_tokens_A_Init(); tmp3 = A_arbace_c2a_text_code_tokens_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_43)); return A_arbace_c2a_text__init_A_const_42.Ref() }




















func A_arbace_c2a_text__init_A_Unit25__O() any { A_arbace_c2a_text__init_A_Init(); lang.Compiler_AOT_At_I_I__V(220, 1); var tmp1 *lang.Var = A_arbace_c2a_text__init_A_const_44; var tmp2 any = A_arbace_c2a_text_list_spans_A_New(); var tmp3 *jrt.Class; A_arbace_c2a_text_list_spans_A_Init(); tmp3 = A_arbace_c2a_text_list_spans_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_c2a_text__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_c2a_text__init_A_const_45)); return A_arbace_c2a_text__init_A_const_44.Ref() }



type A_arbace_c2a_text__init_A struct{ jrt.Object }

var A_arbace_c2a_text__init_A_const_0 *lang.Var

var A_arbace_c2a_text__init_A_const_1 any

var A_arbace_c2a_text__init_A_const_2 any

var A_arbace_c2a_text__init_A_const_3 any

var A_arbace_c2a_text__init_A_const_4 *lang.Var

var A_arbace_c2a_text__init_A_const_5 any

var A_arbace_c2a_text__init_A_const_6 *lang.Var

var A_arbace_c2a_text__init_A_const_7 any

var A_arbace_c2a_text__init_A_const_8 *lang.Var

var A_arbace_c2a_text__init_A_const_9 any

var A_arbace_c2a_text__init_A_const_10 *lang.Var

var A_arbace_c2a_text__init_A_const_11 any

var A_arbace_c2a_text__init_A_const_12 *lang.Var

var A_arbace_c2a_text__init_A_const_13 any

var A_arbace_c2a_text__init_A_const_14 *lang.Var

var A_arbace_c2a_text__init_A_const_15 any

var A_arbace_c2a_text__init_A_const_16 *lang.Var

var A_arbace_c2a_text__init_A_const_17 any

var A_arbace_c2a_text__init_A_const_18 *lang.Var

var A_arbace_c2a_text__init_A_const_19 any

var A_arbace_c2a_text__init_A_const_20 *lang.Var

var A_arbace_c2a_text__init_A_const_21 any

var A_arbace_c2a_text__init_A_const_22 *lang.Var

var A_arbace_c2a_text__init_A_const_23 any

var A_arbace_c2a_text__init_A_const_24 *lang.Var

var A_arbace_c2a_text__init_A_const_25 any

var A_arbace_c2a_text__init_A_const_26 *lang.Var

var A_arbace_c2a_text__init_A_const_27 any

var A_arbace_c2a_text__init_A_const_28 any

var A_arbace_c2a_text__init_A_const_29 *lang.Var

var A_arbace_c2a_text__init_A_const_30 any

var A_arbace_c2a_text__init_A_const_31 *lang.Var

var A_arbace_c2a_text__init_A_const_32 any

var A_arbace_c2a_text__init_A_const_33 any

var A_arbace_c2a_text__init_A_const_34 any

var A_arbace_c2a_text__init_A_const_35 *lang.Var

var A_arbace_c2a_text__init_A_const_36 any

var A_arbace_c2a_text__init_A_const_37 *lang.Var

var A_arbace_c2a_text__init_A_const_38 any

var A_arbace_c2a_text__init_A_const_39 *lang.Var

var A_arbace_c2a_text__init_A_const_40 any

var A_arbace_c2a_text__init_A_const_41 any

var A_arbace_c2a_text__init_A_const_42 *lang.Var

var A_arbace_c2a_text__init_A_const_43 any

var A_arbace_c2a_text__init_A_const_44 *lang.Var

var A_arbace_c2a_text__init_A_const_45 any

var A_arbace_c2a_text__init_A_init jrt.ClassInit

func A_arbace_c2a_text__init_A_Init() { if !A_arbace_c2a_text__init_A_init.Done() { A_arbace_c2a_text__init_A_init.Run(A_arbace_c2a_text__init_A_clinit) } }

func A_arbace_c2a_text__init_A_clinit() { A_arbace_c2a_text__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_c2a_text__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11))); A_arbace_c2a_text__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_11)); A_arbace_c2a_text__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_c2a_text__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_9, Lit_21); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_c2a_text__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_9, Lit_18); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_c2a_text__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_9, Lit_20); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_c2a_text__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_101, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_9, Lit_24); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_c2a_text__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_9, Lit_25); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_c2a_text__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_9, Lit_23); A_arbace_c2a_text__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_102, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_9, Lit_29); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_c2a_text__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_103, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_9, Lit_33); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_c2a_text__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_104, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(51).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_9, Lit_26); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_c2a_text__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_9, Lit_32); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_c2a_text__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(58).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_9, Lit_27); A_arbace_c2a_text__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_106, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(60).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_9, Lit_28); A_arbace_c2a_text__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, jrt.Character_ValueOf_C__Character(40).Ref(), jrt.Character_ValueOf_C__Character(41).Ref(), jrt.Character_ValueOf_C__Character(91).Ref(), jrt.Character_ValueOf_C__Character(93).Ref(), jrt.Character_ValueOf_C__Character(123).Ref(), jrt.Character_ValueOf_C__Character(125).Ref())); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_c2a_text__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(75).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_9, Lit_31); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_c2a_text__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_107, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_9, Lit_30); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_c2a_text__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(88).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_108, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(93).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_c2a_text__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_109, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(126).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_9, Lit_40); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_c2a_text__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_110, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(135).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_9, Lit_37); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_c2a_text__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_39 = lang.RT_Var_String_String__Var(Lit_9, Lit_42); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_c2a_text__init_A_const_40 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_113, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(152).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref()), lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_114, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(168).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_9, Lit_115); A_arbace_c2a_text__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_116, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(199).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)); A_arbace_c2a_text__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_9, Lit_117); A_arbace_c2a_text__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_91).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_92)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_93).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_94).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_118).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_10).Ref(), Lit_119, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), jrt.Integer_ValueOf_I__Integer(220).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), Lit_99)) }

func A_arbace_c2a_text__init_A_New() *A_arbace_c2a_text__init_A { A_arbace_c2a_text__init_A_Init(); t := &A_arbace_c2a_text__init_A{}; t.Ctor(); return t }

func (t *A_arbace_c2a_text__init_A) Ctor() {}

func (t *A_arbace_c2a_text__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_c2a_text__init_A) GetClass__Class() *jrt.Class { return A_arbace_c2a_text__init_A_class }

func (t *A_arbace_c2a_text__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_c2a_text__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_c2a_text__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_c2a_text__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_c2a_text__init_A); return ok }

func A_arbace_c2a_text__init_A_Cast(x any) *A_arbace_c2a_text__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_c2a_text__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_c2a_text__init_A_class)) }; return v }
