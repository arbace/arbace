//line aot_arbace_spec_test_alpha__init.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_spec_test_alpha__init_A_Load__O() any { A_arbace_spec_test_alpha__init_A_Init(); A_arbace_spec_test_alpha__init_A_Unit0__O(); A_arbace_spec_test_alpha__init_A_Unit1__O(); A_arbace_spec_test_alpha__init_A_Unit2__O(); A_arbace_spec_test_alpha__init_A_Unit3__O(); A_arbace_spec_test_alpha__init_A_Unit4__O(); A_arbace_spec_test_alpha__init_A_Unit5__O(); A_arbace_spec_test_alpha__init_A_Unit6__O(); A_arbace_spec_test_alpha__init_A_Unit7__O(); A_arbace_spec_test_alpha__init_A_Unit8__O(); A_arbace_spec_test_alpha__init_A_Unit9__O(); A_arbace_spec_test_alpha__init_A_Unit10__O(); A_arbace_spec_test_alpha__init_A_Unit11__O(); A_arbace_spec_test_alpha__init_A_Unit12__O(); A_arbace_spec_test_alpha__init_A_Unit13__O(); A_arbace_spec_test_alpha__init_A_Unit14__O(); A_arbace_spec_test_alpha__init_A_Unit15__O(); A_arbace_spec_test_alpha__init_A_Unit16__O(); A_arbace_spec_test_alpha__init_A_Unit17__O(); A_arbace_spec_test_alpha__init_A_Unit18__O(); A_arbace_spec_test_alpha__init_A_Unit19__O(); A_arbace_spec_test_alpha__init_A_Unit20__O(); A_arbace_spec_test_alpha__init_A_Unit21__O(); A_arbace_spec_test_alpha__init_A_Unit22__O(); A_arbace_spec_test_alpha__init_A_Unit23__O(); A_arbace_spec_test_alpha__init_A_Unit24__O(); A_arbace_spec_test_alpha__init_A_Unit25__O(); A_arbace_spec_test_alpha__init_A_Unit26__O(); A_arbace_spec_test_alpha__init_A_Unit27__O(); A_arbace_spec_test_alpha__init_A_Unit28__O(); A_arbace_spec_test_alpha__init_A_Unit29__O(); A_arbace_spec_test_alpha__init_A_Unit30__O(); A_arbace_spec_test_alpha__init_A_Unit31__O(); A_arbace_spec_test_alpha__init_A_Unit32__O(); A_arbace_spec_test_alpha__init_A_Unit33__O(); A_arbace_spec_test_alpha__init_A_Unit34__O(); A_arbace_spec_test_alpha__init_A_Unit35__O(); A_arbace_spec_test_alpha__init_A_Unit36__O(); A_arbace_spec_test_alpha__init_A_Unit37__O(); A_arbace_spec_test_alpha__init_A_Unit38__O(); A_arbace_spec_test_alpha__init_A_Unit39__O(); A_arbace_spec_test_alpha__init_A_Unit40__O(); A_arbace_spec_test_alpha__init_A_Unit41__O(); A_arbace_spec_test_alpha__init_A_Unit42__O(); A_arbace_spec_test_alpha__init_A_Unit43__O(); A_arbace_spec_test_alpha__init_A_Unit44__O(); A_arbace_spec_test_alpha__init_A_Unit45__O(); A_arbace_spec_test_alpha__init_A_Unit46__O(); A_arbace_spec_test_alpha__init_A_Unit47__O(); A_arbace_spec_test_alpha__init_A_Unit48__O(); A_arbace_spec_test_alpha__init_A_Unit49__O(); A_arbace_spec_test_alpha__init_A_Unit50__O(); A_arbace_spec_test_alpha__init_A_Unit51__O(); A_arbace_spec_test_alpha__init_A_Unit52__O(); A_arbace_spec_test_alpha__init_A_Unit53__O(); A_arbace_spec_test_alpha__init_A_Unit54__O(); A_arbace_spec_test_alpha__init_A_Unit55__O(); return nil }







func A_arbace_spec_test_alpha__init_A_Unit0__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); return lang.IFn_Cast(A_arbace_spec_test_alpha__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha__init_A_const_1) }
//line :13:1
func A_arbace_spec_test_alpha__init_A_Unit1__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 any = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_34, false); A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :13:1
func A_arbace_spec_test_alpha__init_A_Unit2__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_spec_test_alpha__init_A_const_1)).Equals_O__Z(A_arbace_spec_test_alpha__init_A_const_2) { return nil } else { var tmp1 any = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_35, false); A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }







func A_arbace_spec_test_alpha__init_A_Unit3__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); return lang.IFn_Cast(A_arbace_spec_test_alpha__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha__init_A_const_3) }
func A_arbace_spec_test_alpha__init_A_Unit4__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); return lang.IFn_Cast(A_arbace_spec_test_alpha__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha__init_A_const_4) }
func A_arbace_spec_test_alpha__init_A_Unit5__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); return lang.IFn_Cast(A_arbace_spec_test_alpha__init_A_const_5.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha__init_A_const_6, A_arbace_spec_test_alpha__init_A_const_7) }

func A_arbace_spec_test_alpha__init_A_Unit6__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_8; var tmp2 any = A_arbace_spec_test_alpha_throwable_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_36, false); A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_8; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_9)); return A_arbace_spec_test_alpha__init_A_const_8 }



func A_arbace_spec_test_alpha__init_A_Unit7__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_10; var tmp2 any = A_arbace_spec_test_alpha___GT_sym_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_spec_test_alpha___GT_sym_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_37, false); A_arbace_spec_test_alpha___GT_sym_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_10; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_11)); return A_arbace_spec_test_alpha__init_A_const_10 }



func A_arbace_spec_test_alpha__init_A_Unit8__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_12; var tmp2 any = A_arbace_spec_test_alpha___GT_var_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_spec_test_alpha___GT_var_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_38, false); A_arbace_spec_test_alpha___GT_var_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_13)); return A_arbace_spec_test_alpha__init_A_const_12 }








func A_arbace_spec_test_alpha__init_A_Unit9__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_14; var tmp2 any = A_arbace_spec_test_alpha_collectionize_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_spec_test_alpha_collectionize_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_39, false); A_arbace_spec_test_alpha_collectionize_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_15)); return A_arbace_spec_test_alpha__init_A_const_14 }





func A_arbace_spec_test_alpha__init_A_Unit10__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_16; var tmp2 any = A_arbace_spec_test_alpha_enumerate_namespace_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_40, false); A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_17)); return A_arbace_spec_test_alpha__init_A_const_16 }














func A_arbace_spec_test_alpha__init_A_Unit11__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_18; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; tmp1.BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_spec_test_alpha__init_A_const_18; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_19)); return A_arbace_spec_test_alpha__init_A_const_18.SetDynamic_Z__Var(true).Ref() }



func A_arbace_spec_test_alpha__init_A_Unit12__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_20; var tmp2 any = A_arbace_spec_test_alpha_fn_spec_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_41, false); A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_21)); return A_arbace_spec_test_alpha__init_A_const_20 }




func A_arbace_spec_test_alpha__init_A_Unit13__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_22; var tmp2 any = A_arbace_spec_test_alpha_with_instrument_disabled_A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_42, true); A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_23)); return A_arbace_spec_test_alpha__init_A_const_22 }
//line :72:1
func A_arbace_spec_test_alpha__init_A_Unit14__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); A_arbace_spec_test_alpha__init_A_const_22.SetMacro__V(); return nil }
//line :72:1
func A_arbace_spec_test_alpha__init_A_Unit15__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); return A_arbace_spec_test_alpha__init_A_const_22 }





func A_arbace_spec_test_alpha__init_A_Unit16__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_24; var tmp2 any = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_43, false); A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_25)); return A_arbace_spec_test_alpha__init_A_const_24 }


func A_arbace_spec_test_alpha__init_A_Unit17__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_26; var tmp2 any = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_44, false); A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_27)); return A_arbace_spec_test_alpha__init_A_const_26 }





























func A_arbace_spec_test_alpha__init_A_Unit18__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_28; var tmp2 any = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_45, false); A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_29)); return A_arbace_spec_test_alpha__init_A_const_28 }
















func A_arbace_spec_test_alpha__init_A_Unit19__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_30; var tmp2 any = A_arbace_spec_test_alpha_spec_checking_fn_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_46, false); A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_31)); return A_arbace_spec_test_alpha__init_A_const_30 }































func A_arbace_spec_test_alpha__init_A_Unit20__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_32; var tmp2 any = A_arbace_spec_test_alpha_no_fspec_A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_spec_test_alpha_no_fspec_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_47, false); A_arbace_spec_test_alpha_no_fspec_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_33)); return A_arbace_spec_test_alpha__init_A_const_32 }




func A_arbace_spec_test_alpha__init_A_Unit21__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_34; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_35)); v__1927001498__auto____1 = A_arbace_spec_test_alpha__init_A_const_34; if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_spec_test_alpha__init_A_const_34; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_37)); var tmp3 *lang.Var = A_arbace_spec_test_alpha__init_A_const_34; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha__init_A_const_36.GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; tmp3.BindRoot_O__V(tmp4.Invoke_O__O(tmp5.Ref())); return A_arbace_spec_test_alpha__init_A_const_34 } }

func A_arbace_spec_test_alpha__init_A_Unit22__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_38; var tmp2 any = A_arbace_spec_test_alpha_find_varargs_decl_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_48, false); A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_38; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_39)); return A_arbace_spec_test_alpha__init_A_const_38 }








func A_arbace_spec_test_alpha__init_A_Unit23__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(176, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_40; var tmp2 any = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_49, false); A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_40; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_41)); return A_arbace_spec_test_alpha__init_A_const_40 }


func A_arbace_spec_test_alpha__init_A_Unit24__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(179, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_42; var tmp2 any = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_50, false); A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_42; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_43)); return A_arbace_spec_test_alpha__init_A_const_42 }











func A_arbace_spec_test_alpha__init_A_Unit25__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_44; var tmp2 any = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_51, false); A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_44; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_45)); return A_arbace_spec_test_alpha__init_A_const_44 }





func A_arbace_spec_test_alpha__init_A_Unit26__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(197, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_46; var tmp2 any = A_arbace_spec_test_alpha_build_kwargs_body_A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_52, false); A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_46; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_47)); return A_arbace_spec_test_alpha__init_A_const_46 }









func A_arbace_spec_test_alpha__init_A_Unit27__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(207, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_48; var tmp2 any = A_arbace_spec_test_alpha_build_varargs_body_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_spec_test_alpha_build_varargs_body_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_53, false); A_arbace_spec_test_alpha_build_varargs_body_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_48; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_49)); return A_arbace_spec_test_alpha__init_A_const_48 }








func A_arbace_spec_test_alpha__init_A_Unit28__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(216, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_50; var tmp2 any = A_arbace_spec_test_alpha_build_fixed_args_body_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_54, false); A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_50; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_51)); return A_arbace_spec_test_alpha__init_A_const_50 }







func A_arbace_spec_test_alpha__init_A_Unit29__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(224, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_52; var tmp2 any = A_arbace_spec_test_alpha_build_flattener_code_A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_spec_test_alpha_build_flattener_code_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_55, false); A_arbace_spec_test_alpha_build_flattener_code_A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_52; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_53)); return A_arbace_spec_test_alpha__init_A_const_52 }














func A_arbace_spec_test_alpha__init_A_Unit30__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); return nil }















func A_arbace_spec_test_alpha__init_A_Unit31__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_54; var tmp2 any = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_56, false); A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_54; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_55)); return A_arbace_spec_test_alpha__init_A_const_54 }










func A_arbace_spec_test_alpha__init_A_Unit32__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(266, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_56; var tmp2 any = A_arbace_spec_test_alpha_instrument_choose_fn_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_57, false); A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_57)); return A_arbace_spec_test_alpha__init_A_const_56 }






func A_arbace_spec_test_alpha__init_A_Unit33__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(273, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_58; var tmp2 any = A_arbace_spec_test_alpha_instrument_choose_spec_A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_59)); return A_arbace_spec_test_alpha__init_A_const_58 }




func A_arbace_spec_test_alpha__init_A_Unit34__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_60; var tmp2 any = A_arbace_spec_test_alpha_instrument_1_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_spec_test_alpha_instrument_1_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_59, false); A_arbace_spec_test_alpha_instrument_1_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_61)); return A_arbace_spec_test_alpha__init_A_const_60 }

















func A_arbace_spec_test_alpha__init_A_Unit35__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(296, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_62; var tmp2 any = A_arbace_spec_test_alpha_unstrument_1_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_spec_test_alpha_unstrument_1_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_60, false); A_arbace_spec_test_alpha_unstrument_1_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_63)); return A_arbace_spec_test_alpha__init_A_const_62 }









func A_arbace_spec_test_alpha__init_A_Unit36__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(306, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_64; var tmp2 any = A_arbace_spec_test_alpha_opt_syms_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_spec_test_alpha_opt_syms_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_61, false); A_arbace_spec_test_alpha_opt_syms_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_65)); return A_arbace_spec_test_alpha__init_A_const_64 }




func A_arbace_spec_test_alpha__init_A_Unit37__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(311, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_66; var tmp2 any = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_62, false); A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_66; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_67)); return A_arbace_spec_test_alpha__init_A_const_66 }




func A_arbace_spec_test_alpha__init_A_Unit38__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(316, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_68; var tmp2 any = A_arbace_spec_test_alpha_instrumentable_syms_A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_63, false); A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_68; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_69)); return A_arbace_spec_test_alpha__init_A_const_68 }










func A_arbace_spec_test_alpha__init_A_Unit39__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(327, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_70; var tmp2 any = A_arbace_spec_test_alpha_instrument_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_spec_test_alpha_instrument_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_64, false); A_arbace_spec_test_alpha_instrument_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_71)); return A_arbace_spec_test_alpha__init_A_const_70 }
















































func A_arbace_spec_test_alpha__init_A_Unit40__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(376, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_72; var tmp2 any = A_arbace_spec_test_alpha_unstrument_A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_spec_test_alpha_unstrument_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_65, false); A_arbace_spec_test_alpha_unstrument_A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_73)); return A_arbace_spec_test_alpha__init_A_const_72 }















func A_arbace_spec_test_alpha__init_A_Unit41__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_74; var tmp2 any = A_arbace_spec_test_alpha_explain_check_A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_spec_test_alpha_explain_check_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_spec_test_alpha_explain_check_A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_75)); return A_arbace_spec_test_alpha__init_A_const_74 }









func A_arbace_spec_test_alpha__init_A_Unit42__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(402, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_76; var tmp2 any = A_arbace_spec_test_alpha_check_call_A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_spec_test_alpha_check_call_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_spec_test_alpha_check_call_A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_77)); return A_arbace_spec_test_alpha__init_A_const_76 }
















func A_arbace_spec_test_alpha__init_A_Unit43__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(419, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_78; var tmp2 any = A_arbace_spec_test_alpha_quick_check_A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_spec_test_alpha_quick_check_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_spec_test_alpha_quick_check_A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_79)); return A_arbace_spec_test_alpha__init_A_const_78 }








func A_arbace_spec_test_alpha__init_A_Unit44__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(428, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_80; var tmp2 any = A_arbace_spec_test_alpha_make_check_result_A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_spec_test_alpha_make_check_result_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_spec_test_alpha_make_check_result_A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_80; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_81)); return A_arbace_spec_test_alpha__init_A_const_80 }











func A_arbace_spec_test_alpha__init_A_Unit45__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(440, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_82; var tmp2 any = A_arbace_spec_test_alpha_check_1_A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_spec_test_alpha_check_1_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_spec_test_alpha_check_1_A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_82; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_83)); return A_arbace_spec_test_alpha__init_A_const_82 }




















func A_arbace_spec_test_alpha__init_A_Unit46__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(461, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_84; var tmp2 any = A_arbace_spec_test_alpha_sym__GT_check_map_A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_85)); return A_arbace_spec_test_alpha__init_A_const_84 }






func A_arbace_spec_test_alpha__init_A_Unit47__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(468, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_86; var tmp2 any = A_arbace_spec_test_alpha_validate_check_opts_A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_spec_test_alpha_validate_check_opts_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_72, false); A_arbace_spec_test_alpha_validate_check_opts_A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_87)); return A_arbace_spec_test_alpha__init_A_const_86 }



func A_arbace_spec_test_alpha__init_A_Unit48__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(472, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_88; var tmp2 any = A_arbace_spec_test_alpha_check_fn_A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_spec_test_alpha_check_fn_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_73, false); A_arbace_spec_test_alpha_check_fn_A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_89)); return A_arbace_spec_test_alpha__init_A_const_88 }







func A_arbace_spec_test_alpha__init_A_Unit49__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(480, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_90; var tmp2 any = A_arbace_spec_test_alpha_checkable_syms_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_spec_test_alpha_checkable_syms_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_74, false); A_arbace_spec_test_alpha_checkable_syms_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_91)); return A_arbace_spec_test_alpha__init_A_const_90 }








func A_arbace_spec_test_alpha__init_A_Unit50__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(489, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_92; var tmp2 any = A_arbace_spec_test_alpha_check_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_spec_test_alpha_check_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_75, false); A_arbace_spec_test_alpha_check_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_93)); return A_arbace_spec_test_alpha__init_A_const_92 }










































func A_arbace_spec_test_alpha__init_A_Unit51__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(532, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_94; var tmp2 any = A_arbace_spec_test_alpha_failure_type_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_spec_test_alpha_failure_type_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_spec_test_alpha_failure_type_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_95)); return A_arbace_spec_test_alpha__init_A_const_94 }



func A_arbace_spec_test_alpha__init_A_Unit52__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(536, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_96; var tmp2 any = A_arbace_spec_test_alpha_unwrap_failure_A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_spec_test_alpha_unwrap_failure_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_77, false); A_arbace_spec_test_alpha_unwrap_failure_A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_96; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_97)); return A_arbace_spec_test_alpha__init_A_const_96 }





func A_arbace_spec_test_alpha__init_A_Unit53__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(542, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_98; var tmp2 any = A_arbace_spec_test_alpha_result_type_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_spec_test_alpha_result_type_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_78, false); A_arbace_spec_test_alpha_result_type_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_98; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_99)); return A_arbace_spec_test_alpha__init_A_const_98 }












func A_arbace_spec_test_alpha__init_A_Unit54__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(555, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_100; var tmp2 any = A_arbace_spec_test_alpha_abbrev_result_A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_spec_test_alpha_abbrev_result_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_79, false); A_arbace_spec_test_alpha_abbrev_result_A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_100; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_101)); return A_arbace_spec_test_alpha__init_A_const_100 }









func A_arbace_spec_test_alpha__init_A_Unit55__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(565, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_102; var tmp2 any = A_arbace_spec_test_alpha_summarize_results_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_spec_test_alpha_summarize_results_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_spec_test_alpha_summarize_results_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_102; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_103)); return A_arbace_spec_test_alpha__init_A_const_102 }



type A_arbace_spec_test_alpha__init_A struct{ jrt.Object }

var A_arbace_spec_test_alpha__init_A_const_pool *jrt.RefArray

var A_arbace_spec_test_alpha__init_A_const_0 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_1 any

var A_arbace_spec_test_alpha__init_A_const_2 any

var A_arbace_spec_test_alpha__init_A_const_3 any

var A_arbace_spec_test_alpha__init_A_const_4 any

var A_arbace_spec_test_alpha__init_A_const_5 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_6 any

var A_arbace_spec_test_alpha__init_A_const_7 any

var A_arbace_spec_test_alpha__init_A_const_8 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_9 any

var A_arbace_spec_test_alpha__init_A_const_10 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_11 any

var A_arbace_spec_test_alpha__init_A_const_12 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_13 any

var A_arbace_spec_test_alpha__init_A_const_14 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_15 any

var A_arbace_spec_test_alpha__init_A_const_16 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_17 any

var A_arbace_spec_test_alpha__init_A_const_18 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_19 any

var A_arbace_spec_test_alpha__init_A_const_20 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_21 any

var A_arbace_spec_test_alpha__init_A_const_22 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_23 any

var A_arbace_spec_test_alpha__init_A_const_24 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_25 any

var A_arbace_spec_test_alpha__init_A_const_26 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_27 any

var A_arbace_spec_test_alpha__init_A_const_28 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_29 any

var A_arbace_spec_test_alpha__init_A_const_30 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_31 any

var A_arbace_spec_test_alpha__init_A_const_32 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_33 any

var A_arbace_spec_test_alpha__init_A_const_34 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_35 any

var A_arbace_spec_test_alpha__init_A_const_36 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_37 any

var A_arbace_spec_test_alpha__init_A_const_38 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_39 any

var A_arbace_spec_test_alpha__init_A_const_40 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_41 any

var A_arbace_spec_test_alpha__init_A_const_42 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_43 any

var A_arbace_spec_test_alpha__init_A_const_44 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_45 any

var A_arbace_spec_test_alpha__init_A_const_46 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_47 any

var A_arbace_spec_test_alpha__init_A_const_48 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_49 any

var A_arbace_spec_test_alpha__init_A_const_50 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_51 any

var A_arbace_spec_test_alpha__init_A_const_52 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_53 any

var A_arbace_spec_test_alpha__init_A_const_54 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_55 any

var A_arbace_spec_test_alpha__init_A_const_56 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_57 any

var A_arbace_spec_test_alpha__init_A_const_58 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_59 any

var A_arbace_spec_test_alpha__init_A_const_60 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_61 any

var A_arbace_spec_test_alpha__init_A_const_62 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_63 any

var A_arbace_spec_test_alpha__init_A_const_64 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_65 any

var A_arbace_spec_test_alpha__init_A_const_66 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_67 any

var A_arbace_spec_test_alpha__init_A_const_68 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_69 any

var A_arbace_spec_test_alpha__init_A_const_70 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_71 any

var A_arbace_spec_test_alpha__init_A_const_72 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_73 any

var A_arbace_spec_test_alpha__init_A_const_74 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_75 any

var A_arbace_spec_test_alpha__init_A_const_76 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_77 any

var A_arbace_spec_test_alpha__init_A_const_78 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_79 any

var A_arbace_spec_test_alpha__init_A_const_80 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_81 any

var A_arbace_spec_test_alpha__init_A_const_82 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_83 any

var A_arbace_spec_test_alpha__init_A_const_84 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_85 any

var A_arbace_spec_test_alpha__init_A_const_86 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_87 any

var A_arbace_spec_test_alpha__init_A_const_88 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_89 any

var A_arbace_spec_test_alpha__init_A_const_90 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_91 any

var A_arbace_spec_test_alpha__init_A_const_92 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_93 any

var A_arbace_spec_test_alpha__init_A_const_94 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_95 any

var A_arbace_spec_test_alpha__init_A_const_96 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_97 any

var A_arbace_spec_test_alpha__init_A_const_98 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_99 any

var A_arbace_spec_test_alpha__init_A_const_100 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_101 any

var A_arbace_spec_test_alpha__init_A_const_102 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_103 any

var A_arbace_spec_test_alpha__init_A_init jrt.ClassInit

func A_arbace_spec_test_alpha__init_A_Init() { if !A_arbace_spec_test_alpha__init_A_init.Done() { A_arbace_spec_test_alpha__init_A_init.Run(A_arbace_spec_test_alpha__init_A_clinit) } }

func A_arbace_spec_test_alpha__init_A_clinit() { A_arbace_spec_test_alpha__init_A_clinit_p0(); A_arbace_spec_test_alpha__init_A_clinit_p1(); A_arbace_spec_test_alpha__init_A_clinit_p2(); A_arbace_spec_test_alpha__init_A_clinit_p3(); A_arbace_spec_test_alpha__init_A_clinit_p4(); A_arbace_spec_test_alpha__init_A_clinit_p5(); A_arbace_spec_test_alpha__init_A_clinit_p6(); A_arbace_spec_test_alpha__init_A_clinit_p7() }

func A_arbace_spec_test_alpha__init_A_clinit_p0() { A_arbace_spec_test_alpha__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_33, 154); A_arbace_spec_test_alpha__init_A_const_0 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[50]); A_arbace_spec_test_alpha__init_A_const_1 = A_arbace_spec_test_alpha__init_A_const_pool.A[51]; A_arbace_spec_test_alpha__init_A_const_2 = A_arbace_spec_test_alpha__init_A_const_pool.A[52]; A_arbace_spec_test_alpha__init_A_const_3 = A_arbace_spec_test_alpha__init_A_const_pool.A[53]; A_arbace_spec_test_alpha__init_A_const_4 = A_arbace_spec_test_alpha__init_A_const_pool.A[54]; A_arbace_spec_test_alpha__init_A_const_5 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[55]); A_arbace_spec_test_alpha__init_A_const_6 = A_arbace_spec_test_alpha__init_A_const_pool.A[56]; A_arbace_spec_test_alpha__init_A_const_7 = A_arbace_spec_test_alpha__init_A_const_pool.A[57]; A_arbace_spec_test_alpha__init_A_const_8 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[58]); A_arbace_spec_test_alpha__init_A_const_9 = A_arbace_spec_test_alpha__init_A_const_pool.A[59]; A_arbace_spec_test_alpha__init_A_const_10 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[60]); A_arbace_spec_test_alpha__init_A_const_11 = A_arbace_spec_test_alpha__init_A_const_pool.A[61]; A_arbace_spec_test_alpha__init_A_const_12 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[62]) }

func A_arbace_spec_test_alpha__init_A_clinit_p1() { A_arbace_spec_test_alpha__init_A_const_13 = A_arbace_spec_test_alpha__init_A_const_pool.A[63]; A_arbace_spec_test_alpha__init_A_const_14 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[64]); A_arbace_spec_test_alpha__init_A_const_15 = A_arbace_spec_test_alpha__init_A_const_pool.A[65]; A_arbace_spec_test_alpha__init_A_const_16 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[66]); A_arbace_spec_test_alpha__init_A_const_17 = A_arbace_spec_test_alpha__init_A_const_pool.A[67]; A_arbace_spec_test_alpha__init_A_const_18 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[68]); A_arbace_spec_test_alpha__init_A_const_19 = A_arbace_spec_test_alpha__init_A_const_pool.A[69]; A_arbace_spec_test_alpha__init_A_const_20 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[70]); A_arbace_spec_test_alpha__init_A_const_21 = A_arbace_spec_test_alpha__init_A_const_pool.A[71]; A_arbace_spec_test_alpha__init_A_const_22 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[72]); A_arbace_spec_test_alpha__init_A_const_23 = A_arbace_spec_test_alpha__init_A_const_pool.A[73]; A_arbace_spec_test_alpha__init_A_const_24 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[74]); A_arbace_spec_test_alpha__init_A_const_25 = A_arbace_spec_test_alpha__init_A_const_pool.A[75] }

func A_arbace_spec_test_alpha__init_A_clinit_p2() { A_arbace_spec_test_alpha__init_A_const_26 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[76]); A_arbace_spec_test_alpha__init_A_const_27 = A_arbace_spec_test_alpha__init_A_const_pool.A[77]; A_arbace_spec_test_alpha__init_A_const_28 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[78]); A_arbace_spec_test_alpha__init_A_const_29 = A_arbace_spec_test_alpha__init_A_const_pool.A[79]; A_arbace_spec_test_alpha__init_A_const_30 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[80]); A_arbace_spec_test_alpha__init_A_const_31 = A_arbace_spec_test_alpha__init_A_const_pool.A[81]; A_arbace_spec_test_alpha__init_A_const_32 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[82]); A_arbace_spec_test_alpha__init_A_const_33 = A_arbace_spec_test_alpha__init_A_const_pool.A[83]; A_arbace_spec_test_alpha__init_A_const_34 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[84]); A_arbace_spec_test_alpha__init_A_const_35 = A_arbace_spec_test_alpha__init_A_const_pool.A[85]; A_arbace_spec_test_alpha__init_A_const_36 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[86]); A_arbace_spec_test_alpha__init_A_const_37 = A_arbace_spec_test_alpha__init_A_const_pool.A[87]; A_arbace_spec_test_alpha__init_A_const_38 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[88]) }

func A_arbace_spec_test_alpha__init_A_clinit_p3() { A_arbace_spec_test_alpha__init_A_const_39 = A_arbace_spec_test_alpha__init_A_const_pool.A[89]; A_arbace_spec_test_alpha__init_A_const_40 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[90]); A_arbace_spec_test_alpha__init_A_const_41 = A_arbace_spec_test_alpha__init_A_const_pool.A[91]; A_arbace_spec_test_alpha__init_A_const_42 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[92]); A_arbace_spec_test_alpha__init_A_const_43 = A_arbace_spec_test_alpha__init_A_const_pool.A[93]; A_arbace_spec_test_alpha__init_A_const_44 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[94]); A_arbace_spec_test_alpha__init_A_const_45 = A_arbace_spec_test_alpha__init_A_const_pool.A[95]; A_arbace_spec_test_alpha__init_A_const_46 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[96]); A_arbace_spec_test_alpha__init_A_const_47 = A_arbace_spec_test_alpha__init_A_const_pool.A[97]; A_arbace_spec_test_alpha__init_A_const_48 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[98]); A_arbace_spec_test_alpha__init_A_const_49 = A_arbace_spec_test_alpha__init_A_const_pool.A[99]; A_arbace_spec_test_alpha__init_A_const_50 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[100]); A_arbace_spec_test_alpha__init_A_const_51 = A_arbace_spec_test_alpha__init_A_const_pool.A[101] }

func A_arbace_spec_test_alpha__init_A_clinit_p4() { A_arbace_spec_test_alpha__init_A_const_52 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[102]); A_arbace_spec_test_alpha__init_A_const_53 = A_arbace_spec_test_alpha__init_A_const_pool.A[103]; A_arbace_spec_test_alpha__init_A_const_54 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[104]); A_arbace_spec_test_alpha__init_A_const_55 = A_arbace_spec_test_alpha__init_A_const_pool.A[105]; A_arbace_spec_test_alpha__init_A_const_56 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[106]); A_arbace_spec_test_alpha__init_A_const_57 = A_arbace_spec_test_alpha__init_A_const_pool.A[107]; A_arbace_spec_test_alpha__init_A_const_58 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[108]); A_arbace_spec_test_alpha__init_A_const_59 = A_arbace_spec_test_alpha__init_A_const_pool.A[109]; A_arbace_spec_test_alpha__init_A_const_60 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[110]); A_arbace_spec_test_alpha__init_A_const_61 = A_arbace_spec_test_alpha__init_A_const_pool.A[111]; A_arbace_spec_test_alpha__init_A_const_62 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[112]); A_arbace_spec_test_alpha__init_A_const_63 = A_arbace_spec_test_alpha__init_A_const_pool.A[113]; A_arbace_spec_test_alpha__init_A_const_64 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[114]) }

func A_arbace_spec_test_alpha__init_A_clinit_p5() { A_arbace_spec_test_alpha__init_A_const_65 = A_arbace_spec_test_alpha__init_A_const_pool.A[115]; A_arbace_spec_test_alpha__init_A_const_66 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[116]); A_arbace_spec_test_alpha__init_A_const_67 = A_arbace_spec_test_alpha__init_A_const_pool.A[117]; A_arbace_spec_test_alpha__init_A_const_68 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[118]); A_arbace_spec_test_alpha__init_A_const_69 = A_arbace_spec_test_alpha__init_A_const_pool.A[119]; A_arbace_spec_test_alpha__init_A_const_70 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[120]); A_arbace_spec_test_alpha__init_A_const_71 = A_arbace_spec_test_alpha__init_A_const_pool.A[121]; A_arbace_spec_test_alpha__init_A_const_72 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[122]); A_arbace_spec_test_alpha__init_A_const_73 = A_arbace_spec_test_alpha__init_A_const_pool.A[123]; A_arbace_spec_test_alpha__init_A_const_74 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[124]); A_arbace_spec_test_alpha__init_A_const_75 = A_arbace_spec_test_alpha__init_A_const_pool.A[125]; A_arbace_spec_test_alpha__init_A_const_76 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[126]); A_arbace_spec_test_alpha__init_A_const_77 = A_arbace_spec_test_alpha__init_A_const_pool.A[127] }

func A_arbace_spec_test_alpha__init_A_clinit_p6() { A_arbace_spec_test_alpha__init_A_const_78 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[128]); A_arbace_spec_test_alpha__init_A_const_79 = A_arbace_spec_test_alpha__init_A_const_pool.A[129]; A_arbace_spec_test_alpha__init_A_const_80 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[130]); A_arbace_spec_test_alpha__init_A_const_81 = A_arbace_spec_test_alpha__init_A_const_pool.A[131]; A_arbace_spec_test_alpha__init_A_const_82 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[132]); A_arbace_spec_test_alpha__init_A_const_83 = A_arbace_spec_test_alpha__init_A_const_pool.A[133]; A_arbace_spec_test_alpha__init_A_const_84 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[134]); A_arbace_spec_test_alpha__init_A_const_85 = A_arbace_spec_test_alpha__init_A_const_pool.A[135]; A_arbace_spec_test_alpha__init_A_const_86 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[136]); A_arbace_spec_test_alpha__init_A_const_87 = A_arbace_spec_test_alpha__init_A_const_pool.A[137]; A_arbace_spec_test_alpha__init_A_const_88 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[138]); A_arbace_spec_test_alpha__init_A_const_89 = A_arbace_spec_test_alpha__init_A_const_pool.A[139]; A_arbace_spec_test_alpha__init_A_const_90 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[140]) }

func A_arbace_spec_test_alpha__init_A_clinit_p7() { A_arbace_spec_test_alpha__init_A_const_91 = A_arbace_spec_test_alpha__init_A_const_pool.A[141]; A_arbace_spec_test_alpha__init_A_const_92 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[142]); A_arbace_spec_test_alpha__init_A_const_93 = A_arbace_spec_test_alpha__init_A_const_pool.A[143]; A_arbace_spec_test_alpha__init_A_const_94 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[144]); A_arbace_spec_test_alpha__init_A_const_95 = A_arbace_spec_test_alpha__init_A_const_pool.A[145]; A_arbace_spec_test_alpha__init_A_const_96 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[146]); A_arbace_spec_test_alpha__init_A_const_97 = A_arbace_spec_test_alpha__init_A_const_pool.A[147]; A_arbace_spec_test_alpha__init_A_const_98 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[148]); A_arbace_spec_test_alpha__init_A_const_99 = A_arbace_spec_test_alpha__init_A_const_pool.A[149]; A_arbace_spec_test_alpha__init_A_const_100 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[150]); A_arbace_spec_test_alpha__init_A_const_101 = A_arbace_spec_test_alpha__init_A_const_pool.A[151]; A_arbace_spec_test_alpha__init_A_const_102 = lang.Var_Cast(A_arbace_spec_test_alpha__init_A_const_pool.A[152]); A_arbace_spec_test_alpha__init_A_const_103 = A_arbace_spec_test_alpha__init_A_const_pool.A[153] }

func A_arbace_spec_test_alpha__init_A_New() *A_arbace_spec_test_alpha__init_A { A_arbace_spec_test_alpha__init_A_Init(); t := &A_arbace_spec_test_alpha__init_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha__init_A) Ctor() {}

func (t *A_arbace_spec_test_alpha__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha__init_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha__init_A_class }

func (t *A_arbace_spec_test_alpha__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha__init_A); return ok }

func A_arbace_spec_test_alpha__init_A_Cast(x any) *A_arbace_spec_test_alpha__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha__init_A_class)) }; return v }
