//line aot_arbace_spec_test_alpha__init.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_spec_test_alpha__init_A_Load__O() any { A_arbace_spec_test_alpha__init_A_Init(); A_arbace_spec_test_alpha__init_A_Unit0__O(); A_arbace_spec_test_alpha__init_A_Unit1__O(); A_arbace_spec_test_alpha__init_A_Unit2__O(); A_arbace_spec_test_alpha__init_A_Unit3__O(); A_arbace_spec_test_alpha__init_A_Unit4__O(); A_arbace_spec_test_alpha__init_A_Unit5__O(); A_arbace_spec_test_alpha__init_A_Unit6__O(); A_arbace_spec_test_alpha__init_A_Unit7__O(); A_arbace_spec_test_alpha__init_A_Unit8__O(); A_arbace_spec_test_alpha__init_A_Unit9__O(); A_arbace_spec_test_alpha__init_A_Unit10__O(); A_arbace_spec_test_alpha__init_A_Unit11__O(); A_arbace_spec_test_alpha__init_A_Unit12__O(); A_arbace_spec_test_alpha__init_A_Unit13__O(); A_arbace_spec_test_alpha__init_A_Unit14__O(); A_arbace_spec_test_alpha__init_A_Unit15__O(); A_arbace_spec_test_alpha__init_A_Unit16__O(); A_arbace_spec_test_alpha__init_A_Unit17__O(); A_arbace_spec_test_alpha__init_A_Unit18__O(); A_arbace_spec_test_alpha__init_A_Unit19__O(); A_arbace_spec_test_alpha__init_A_Unit20__O(); A_arbace_spec_test_alpha__init_A_Unit21__O(); A_arbace_spec_test_alpha__init_A_Unit22__O(); A_arbace_spec_test_alpha__init_A_Unit23__O(); A_arbace_spec_test_alpha__init_A_Unit24__O(); A_arbace_spec_test_alpha__init_A_Unit25__O(); A_arbace_spec_test_alpha__init_A_Unit26__O(); A_arbace_spec_test_alpha__init_A_Unit27__O(); A_arbace_spec_test_alpha__init_A_Unit28__O(); A_arbace_spec_test_alpha__init_A_Unit29__O(); A_arbace_spec_test_alpha__init_A_Unit30__O(); A_arbace_spec_test_alpha__init_A_Unit31__O(); A_arbace_spec_test_alpha__init_A_Unit32__O(); A_arbace_spec_test_alpha__init_A_Unit33__O(); A_arbace_spec_test_alpha__init_A_Unit34__O(); A_arbace_spec_test_alpha__init_A_Unit35__O(); A_arbace_spec_test_alpha__init_A_Unit36__O(); A_arbace_spec_test_alpha__init_A_Unit37__O(); A_arbace_spec_test_alpha__init_A_Unit38__O(); A_arbace_spec_test_alpha__init_A_Unit39__O(); A_arbace_spec_test_alpha__init_A_Unit40__O(); A_arbace_spec_test_alpha__init_A_Unit41__O(); A_arbace_spec_test_alpha__init_A_Unit42__O(); A_arbace_spec_test_alpha__init_A_Unit43__O(); A_arbace_spec_test_alpha__init_A_Unit44__O(); A_arbace_spec_test_alpha__init_A_Unit45__O(); A_arbace_spec_test_alpha__init_A_Unit46__O(); A_arbace_spec_test_alpha__init_A_Unit47__O(); A_arbace_spec_test_alpha__init_A_Unit48__O(); A_arbace_spec_test_alpha__init_A_Unit49__O(); A_arbace_spec_test_alpha__init_A_Unit50__O(); A_arbace_spec_test_alpha__init_A_Unit51__O(); A_arbace_spec_test_alpha__init_A_Unit52__O(); A_arbace_spec_test_alpha__init_A_Unit53__O(); A_arbace_spec_test_alpha__init_A_Unit54__O(); A_arbace_spec_test_alpha__init_A_Unit55__O(); return nil }







func A_arbace_spec_test_alpha__init_A_Unit0__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); return lang.IFn_Cast(jrt.NN(A_arbace_spec_test_alpha__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha__init_A_const_1) }
//line :13:1
func A_arbace_spec_test_alpha__init_A_Unit1__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 any = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_New(); var tmp2 *jrt.Class; A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_Init(); tmp2 = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :13:1
func A_arbace_spec_test_alpha__init_A_Unit2__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_spec_test_alpha__init_A_const_1)).Equals_O__Z(A_arbace_spec_test_alpha__init_A_const_2) { return nil } else { var tmp1 any = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_New(); var tmp2 *jrt.Class; A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_Init(); tmp2 = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }







func A_arbace_spec_test_alpha__init_A_Unit3__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); return lang.IFn_Cast(jrt.NN(A_arbace_spec_test_alpha__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha__init_A_const_3) }
func A_arbace_spec_test_alpha__init_A_Unit4__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(22, 1); return lang.IFn_Cast(jrt.NN(A_arbace_spec_test_alpha__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha__init_A_const_4) }
func A_arbace_spec_test_alpha__init_A_Unit5__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); return lang.IFn_Cast(jrt.NN(A_arbace_spec_test_alpha__init_A_const_5).GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha__init_A_const_6, A_arbace_spec_test_alpha__init_A_const_7) }

func A_arbace_spec_test_alpha__init_A_Unit6__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(25, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_8; var tmp2 any = A_arbace_spec_test_alpha_throwable_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_throwable_QMARK__A_Init(); tmp3 = A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_9)); return A_arbace_spec_test_alpha__init_A_const_8.Ref() }



func A_arbace_spec_test_alpha__init_A_Unit7__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(29, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_10; var tmp2 any = A_arbace_spec_test_alpha___GT_sym_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha___GT_sym_A_Init(); tmp3 = A_arbace_spec_test_alpha___GT_sym_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_11)); return A_arbace_spec_test_alpha__init_A_const_10.Ref() }



func A_arbace_spec_test_alpha__init_A_Unit8__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_12; var tmp2 any = A_arbace_spec_test_alpha___GT_var_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha___GT_var_A_Init(); tmp3 = A_arbace_spec_test_alpha___GT_var_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_13)); return A_arbace_spec_test_alpha__init_A_const_12.Ref() }








func A_arbace_spec_test_alpha__init_A_Unit9__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(42, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_14; var tmp2 any = A_arbace_spec_test_alpha_collectionize_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_collectionize_A_Init(); tmp3 = A_arbace_spec_test_alpha_collectionize_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_15)); return A_arbace_spec_test_alpha__init_A_const_14.Ref() }





func A_arbace_spec_test_alpha__init_A_Unit10__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(48, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_16; var tmp2 any = A_arbace_spec_test_alpha_enumerate_namespace_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_enumerate_namespace_A_Init(); tmp3 = A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_17)); return A_arbace_spec_test_alpha__init_A_const_16.Ref() }














func A_arbace_spec_test_alpha__init_A_Unit11__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(63, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_18; var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; jrt.NN(tmp1).BindRoot_O__V(tmp2.Ref()); var tmp3 *lang.Var = A_arbace_spec_test_alpha__init_A_const_18; jrt.NN(tmp3).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_19)); return jrt.NN(A_arbace_spec_test_alpha__init_A_const_18).SetDynamic_Z__Var(true).Ref() }



func A_arbace_spec_test_alpha__init_A_Unit12__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(67, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_20; var tmp2 any = A_arbace_spec_test_alpha_fn_spec_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_fn_spec_QMARK__A_Init(); tmp3 = A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_21)); return A_arbace_spec_test_alpha__init_A_const_20.Ref() }




func A_arbace_spec_test_alpha__init_A_Unit13__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_22; var tmp2 any = A_arbace_spec_test_alpha_with_instrument_disabled_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_with_instrument_disabled_A_Init(); tmp3 = A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_23)); return A_arbace_spec_test_alpha__init_A_const_22.Ref() }
//line :72:1
func A_arbace_spec_test_alpha__init_A_Unit14__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); jrt.NN(A_arbace_spec_test_alpha__init_A_const_22).SetMacro__V(); return nil }
//line :72:1
func A_arbace_spec_test_alpha__init_A_Unit15__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(72, 1); return A_arbace_spec_test_alpha__init_A_const_22.Ref() }





func A_arbace_spec_test_alpha__init_A_Unit16__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(78, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_24; var tmp2 any = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_thunk_frame_QMARK__A_Init(); tmp3 = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_25)); return A_arbace_spec_test_alpha__init_A_const_24.Ref() }


func A_arbace_spec_test_alpha__init_A_Unit17__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(81, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_26; var tmp2 any = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_interpret_stack_trace_element_A_Init(); tmp3 = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_27)); return A_arbace_spec_test_alpha__init_A_const_26.Ref() }





























func A_arbace_spec_test_alpha__init_A_Unit18__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(111, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_28; var tmp2 any = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_Init(); tmp3 = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_29)); return A_arbace_spec_test_alpha__init_A_const_28.Ref() }
















func A_arbace_spec_test_alpha__init_A_Unit19__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(128, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_30; var tmp2 any = A_arbace_spec_test_alpha_spec_checking_fn_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_spec_checking_fn_A_Init(); tmp3 = A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_30; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_31)); return A_arbace_spec_test_alpha__init_A_const_30.Ref() }































func A_arbace_spec_test_alpha__init_A_Unit20__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(160, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_32; var tmp2 any = A_arbace_spec_test_alpha_no_fspec_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_no_fspec_A_Init(); tmp3 = A_arbace_spec_test_alpha_no_fspec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_33)); return A_arbace_spec_test_alpha__init_A_const_32.Ref() }




func A_arbace_spec_test_alpha__init_A_Unit21__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var v__1927001498__auto____1 any; var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_34; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_35)); v__1927001498__auto____1 = A_arbace_spec_test_alpha__init_A_const_34.Ref(); if jrt.NN(lang.Var_Cast(v__1927001498__auto____1)).HasRoot__Z() { return nil } else { var tmp2 *lang.Var = A_arbace_spec_test_alpha__init_A_const_34; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_37)); var tmp3 *lang.Var = A_arbace_spec_test_alpha__init_A_const_34; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_spec_test_alpha__init_A_const_36).GetRawRoot__O()); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; jrt.NN(tmp3).BindRoot_O__V(tmp4.Invoke_O__O(tmp5.Ref())); return A_arbace_spec_test_alpha__init_A_const_34.Ref() } }

func A_arbace_spec_test_alpha__init_A_Unit22__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(167, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_38; var tmp2 any = A_arbace_spec_test_alpha_find_varargs_decl_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_find_varargs_decl_A_Init(); tmp3 = A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_39)); return A_arbace_spec_test_alpha__init_A_const_38.Ref() }








func A_arbace_spec_test_alpha__init_A_Unit23__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(176, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_40; var tmp2 any = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_has_kwargs_QMARK__A_Init(); tmp3 = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_41)); return A_arbace_spec_test_alpha__init_A_const_40.Ref() }


func A_arbace_spec_test_alpha__init_A_Unit24__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(179, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_42; var tmp2 any = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_kwargs__GT_kvs_A_Init(); tmp3 = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_43)); return A_arbace_spec_test_alpha__init_A_const_42.Ref() }











func A_arbace_spec_test_alpha__init_A_Unit25__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(191, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_44; var tmp2 any = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_gen_fixed_args_syms_A_Init(); tmp3 = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_44; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_45)); return A_arbace_spec_test_alpha__init_A_const_44.Ref() }





func A_arbace_spec_test_alpha__init_A_Unit26__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(197, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_46; var tmp2 any = A_arbace_spec_test_alpha_build_kwargs_body_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_build_kwargs_body_A_Init(); tmp3 = A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_47)); return A_arbace_spec_test_alpha__init_A_const_46.Ref() }









func A_arbace_spec_test_alpha__init_A_Unit27__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(207, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_48; var tmp2 any = A_arbace_spec_test_alpha_build_varargs_body_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_build_varargs_body_A_Init(); tmp3 = A_arbace_spec_test_alpha_build_varargs_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_49)); return A_arbace_spec_test_alpha__init_A_const_48.Ref() }








func A_arbace_spec_test_alpha__init_A_Unit28__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(216, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_50; var tmp2 any = A_arbace_spec_test_alpha_build_fixed_args_body_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_build_fixed_args_body_A_Init(); tmp3 = A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_51)); return A_arbace_spec_test_alpha__init_A_const_50.Ref() }







func A_arbace_spec_test_alpha__init_A_Unit29__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(224, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_52; var tmp2 any = A_arbace_spec_test_alpha_build_flattener_code_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_build_flattener_code_A_Init(); tmp3 = A_arbace_spec_test_alpha_build_flattener_code_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_53)); return A_arbace_spec_test_alpha__init_A_const_52.Ref() }














func A_arbace_spec_test_alpha__init_A_Unit30__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(239, 1); return nil }















func A_arbace_spec_test_alpha__init_A_Unit31__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(255, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_54; var tmp2 any = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_Init(); tmp3 = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_55)); return A_arbace_spec_test_alpha__init_A_const_54.Ref() }










func A_arbace_spec_test_alpha__init_A_Unit32__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(266, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_56; var tmp2 any = A_arbace_spec_test_alpha_instrument_choose_fn_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_instrument_choose_fn_A_Init(); tmp3 = A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_57)); return A_arbace_spec_test_alpha__init_A_const_56.Ref() }






func A_arbace_spec_test_alpha__init_A_Unit33__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(273, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_58; var tmp2 any = A_arbace_spec_test_alpha_instrument_choose_spec_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_instrument_choose_spec_A_Init(); tmp3 = A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_59)); return A_arbace_spec_test_alpha__init_A_const_58.Ref() }




func A_arbace_spec_test_alpha__init_A_Unit34__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(278, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_60; var tmp2 any = A_arbace_spec_test_alpha_instrument_1_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_instrument_1_A_Init(); tmp3 = A_arbace_spec_test_alpha_instrument_1_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_61)); return A_arbace_spec_test_alpha__init_A_const_60.Ref() }

















func A_arbace_spec_test_alpha__init_A_Unit35__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(296, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_62; var tmp2 any = A_arbace_spec_test_alpha_unstrument_1_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_unstrument_1_A_Init(); tmp3 = A_arbace_spec_test_alpha_unstrument_1_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_63)); return A_arbace_spec_test_alpha__init_A_const_62.Ref() }









func A_arbace_spec_test_alpha__init_A_Unit36__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(306, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_64; var tmp2 any = A_arbace_spec_test_alpha_opt_syms_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_opt_syms_A_Init(); tmp3 = A_arbace_spec_test_alpha_opt_syms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_65)); return A_arbace_spec_test_alpha__init_A_const_64.Ref() }




func A_arbace_spec_test_alpha__init_A_Unit37__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(311, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_66; var tmp2 any = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_Init(); tmp3 = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_66; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_67)); return A_arbace_spec_test_alpha__init_A_const_66.Ref() }




func A_arbace_spec_test_alpha__init_A_Unit38__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(316, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_68; var tmp2 any = A_arbace_spec_test_alpha_instrumentable_syms_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_instrumentable_syms_A_Init(); tmp3 = A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_68; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_69)); return A_arbace_spec_test_alpha__init_A_const_68.Ref() }










func A_arbace_spec_test_alpha__init_A_Unit39__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(327, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_70; var tmp2 any = A_arbace_spec_test_alpha_instrument_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_instrument_A_Init(); tmp3 = A_arbace_spec_test_alpha_instrument_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_70; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_71)); return A_arbace_spec_test_alpha__init_A_const_70.Ref() }
















































func A_arbace_spec_test_alpha__init_A_Unit40__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(376, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_72; var tmp2 any = A_arbace_spec_test_alpha_unstrument_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_unstrument_A_Init(); tmp3 = A_arbace_spec_test_alpha_unstrument_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_72; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_73)); return A_arbace_spec_test_alpha__init_A_const_72.Ref() }















func A_arbace_spec_test_alpha__init_A_Unit41__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(392, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_74; var tmp2 any = A_arbace_spec_test_alpha_explain_check_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_explain_check_A_Init(); tmp3 = A_arbace_spec_test_alpha_explain_check_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_74; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_75)); return A_arbace_spec_test_alpha__init_A_const_74.Ref() }









func A_arbace_spec_test_alpha__init_A_Unit42__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(402, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_76; var tmp2 any = A_arbace_spec_test_alpha_check_call_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_check_call_A_Init(); tmp3 = A_arbace_spec_test_alpha_check_call_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_76; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_77)); return A_arbace_spec_test_alpha__init_A_const_76.Ref() }
















func A_arbace_spec_test_alpha__init_A_Unit43__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(419, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_78; var tmp2 any = A_arbace_spec_test_alpha_quick_check_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_quick_check_A_Init(); tmp3 = A_arbace_spec_test_alpha_quick_check_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_78; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_79)); return A_arbace_spec_test_alpha__init_A_const_78.Ref() }








func A_arbace_spec_test_alpha__init_A_Unit44__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(428, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_80; var tmp2 any = A_arbace_spec_test_alpha_make_check_result_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_make_check_result_A_Init(); tmp3 = A_arbace_spec_test_alpha_make_check_result_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_80; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_81)); return A_arbace_spec_test_alpha__init_A_const_80.Ref() }











func A_arbace_spec_test_alpha__init_A_Unit45__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(440, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_82; var tmp2 any = A_arbace_spec_test_alpha_check_1_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_check_1_A_Init(); tmp3 = A_arbace_spec_test_alpha_check_1_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_82; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_83)); return A_arbace_spec_test_alpha__init_A_const_82.Ref() }




















func A_arbace_spec_test_alpha__init_A_Unit46__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(461, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_84; var tmp2 any = A_arbace_spec_test_alpha_sym__GT_check_map_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_sym__GT_check_map_A_Init(); tmp3 = A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_84; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_85)); return A_arbace_spec_test_alpha__init_A_const_84.Ref() }






func A_arbace_spec_test_alpha__init_A_Unit47__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(468, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_86; var tmp2 any = A_arbace_spec_test_alpha_validate_check_opts_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_validate_check_opts_A_Init(); tmp3 = A_arbace_spec_test_alpha_validate_check_opts_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_86; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_87)); return A_arbace_spec_test_alpha__init_A_const_86.Ref() }



func A_arbace_spec_test_alpha__init_A_Unit48__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(472, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_88; var tmp2 any = A_arbace_spec_test_alpha_check_fn_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_check_fn_A_Init(); tmp3 = A_arbace_spec_test_alpha_check_fn_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_88; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_89)); return A_arbace_spec_test_alpha__init_A_const_88.Ref() }







func A_arbace_spec_test_alpha__init_A_Unit49__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(480, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_90; var tmp2 any = A_arbace_spec_test_alpha_checkable_syms_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_checkable_syms_A_Init(); tmp3 = A_arbace_spec_test_alpha_checkable_syms_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_90; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_91)); return A_arbace_spec_test_alpha__init_A_const_90.Ref() }








func A_arbace_spec_test_alpha__init_A_Unit50__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(489, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_92; var tmp2 any = A_arbace_spec_test_alpha_check_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_check_A_Init(); tmp3 = A_arbace_spec_test_alpha_check_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_92; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_93)); return A_arbace_spec_test_alpha__init_A_const_92.Ref() }










































func A_arbace_spec_test_alpha__init_A_Unit51__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(532, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_94; var tmp2 any = A_arbace_spec_test_alpha_failure_type_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_failure_type_A_Init(); tmp3 = A_arbace_spec_test_alpha_failure_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_94; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_95)); return A_arbace_spec_test_alpha__init_A_const_94.Ref() }



func A_arbace_spec_test_alpha__init_A_Unit52__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(536, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_96; var tmp2 any = A_arbace_spec_test_alpha_unwrap_failure_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_unwrap_failure_A_Init(); tmp3 = A_arbace_spec_test_alpha_unwrap_failure_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_96; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_97)); return A_arbace_spec_test_alpha__init_A_const_96.Ref() }





func A_arbace_spec_test_alpha__init_A_Unit53__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(542, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_98; var tmp2 any = A_arbace_spec_test_alpha_result_type_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_result_type_A_Init(); tmp3 = A_arbace_spec_test_alpha_result_type_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_98; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_99)); return A_arbace_spec_test_alpha__init_A_const_98.Ref() }












func A_arbace_spec_test_alpha__init_A_Unit54__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(555, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_100; var tmp2 any = A_arbace_spec_test_alpha_abbrev_result_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_abbrev_result_A_Init(); tmp3 = A_arbace_spec_test_alpha_abbrev_result_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_100; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_101)); return A_arbace_spec_test_alpha__init_A_const_100.Ref() }









func A_arbace_spec_test_alpha__init_A_Unit55__O() any { A_arbace_spec_test_alpha__init_A_Init(); lang.Compiler_AOT_At_I_I__V(565, 1); var tmp1 *lang.Var = A_arbace_spec_test_alpha__init_A_const_102; var tmp2 any = A_arbace_spec_test_alpha_summarize_results_A_New(); var tmp3 *jrt.Class; A_arbace_spec_test_alpha_summarize_results_A_Init(); tmp3 = A_arbace_spec_test_alpha_summarize_results_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_spec_test_alpha__init_A_const_102; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_spec_test_alpha__init_A_const_103)); return A_arbace_spec_test_alpha__init_A_const_102.Ref() }



type A_arbace_spec_test_alpha__init_A struct{ jrt.Object }

var A_arbace_spec_test_alpha__init_A_const_0 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_1 any

var A_arbace_spec_test_alpha__init_A_const_2 any

var A_arbace_spec_test_alpha__init_A_const_3 any

var A_arbace_spec_test_alpha__init_A_const_4 any

var A_arbace_spec_test_alpha__init_A_const_5 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_6 any

var A_arbace_spec_test_alpha__init_A_const_7 any

var A_arbace_spec_test_alpha__init_A_const_8 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_9 any

var A_arbace_spec_test_alpha__init_A_const_10 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_11 any

var A_arbace_spec_test_alpha__init_A_const_12 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_13 any

var A_arbace_spec_test_alpha__init_A_const_14 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_15 any

var A_arbace_spec_test_alpha__init_A_const_16 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_17 any

var A_arbace_spec_test_alpha__init_A_const_18 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_19 any

var A_arbace_spec_test_alpha__init_A_const_20 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_21 any

var A_arbace_spec_test_alpha__init_A_const_22 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_23 any

var A_arbace_spec_test_alpha__init_A_const_24 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_25 any

var A_arbace_spec_test_alpha__init_A_const_26 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_27 any

var A_arbace_spec_test_alpha__init_A_const_28 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_29 any

var A_arbace_spec_test_alpha__init_A_const_30 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_31 any

var A_arbace_spec_test_alpha__init_A_const_32 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_33 any

var A_arbace_spec_test_alpha__init_A_const_34 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_35 any

var A_arbace_spec_test_alpha__init_A_const_36 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_37 any

var A_arbace_spec_test_alpha__init_A_const_38 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_39 any

var A_arbace_spec_test_alpha__init_A_const_40 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_41 any

var A_arbace_spec_test_alpha__init_A_const_42 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_43 any

var A_arbace_spec_test_alpha__init_A_const_44 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_45 any

var A_arbace_spec_test_alpha__init_A_const_46 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_47 any

var A_arbace_spec_test_alpha__init_A_const_48 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_49 any

var A_arbace_spec_test_alpha__init_A_const_50 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_51 any

var A_arbace_spec_test_alpha__init_A_const_52 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_53 any

var A_arbace_spec_test_alpha__init_A_const_54 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_55 any

var A_arbace_spec_test_alpha__init_A_const_56 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_57 any

var A_arbace_spec_test_alpha__init_A_const_58 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_59 any

var A_arbace_spec_test_alpha__init_A_const_60 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_61 any

var A_arbace_spec_test_alpha__init_A_const_62 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_63 any

var A_arbace_spec_test_alpha__init_A_const_64 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_65 any

var A_arbace_spec_test_alpha__init_A_const_66 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_67 any

var A_arbace_spec_test_alpha__init_A_const_68 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_69 any

var A_arbace_spec_test_alpha__init_A_const_70 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_71 any

var A_arbace_spec_test_alpha__init_A_const_72 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_73 any

var A_arbace_spec_test_alpha__init_A_const_74 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_75 any

var A_arbace_spec_test_alpha__init_A_const_76 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_77 any

var A_arbace_spec_test_alpha__init_A_const_78 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_79 any

var A_arbace_spec_test_alpha__init_A_const_80 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_81 any

var A_arbace_spec_test_alpha__init_A_const_82 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_83 any

var A_arbace_spec_test_alpha__init_A_const_84 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_85 any

var A_arbace_spec_test_alpha__init_A_const_86 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_87 any

var A_arbace_spec_test_alpha__init_A_const_88 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_89 any

var A_arbace_spec_test_alpha__init_A_const_90 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_91 any

var A_arbace_spec_test_alpha__init_A_const_92 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_93 any

var A_arbace_spec_test_alpha__init_A_const_94 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_95 any

var A_arbace_spec_test_alpha__init_A_const_96 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_97 any

var A_arbace_spec_test_alpha__init_A_const_98 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_99 any

var A_arbace_spec_test_alpha__init_A_const_100 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_101 any

var A_arbace_spec_test_alpha__init_A_const_102 *lang.Var

var A_arbace_spec_test_alpha__init_A_const_103 any

var A_arbace_spec_test_alpha__init_A_init jrt.ClassInit

func A_arbace_spec_test_alpha__init_A_Init() { if !A_arbace_spec_test_alpha__init_A_init.Done() { A_arbace_spec_test_alpha__init_A_init.Run(A_arbace_spec_test_alpha__init_A_clinit) } }

func A_arbace_spec_test_alpha__init_A_clinit() { A_arbace_spec_test_alpha__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_262); A_arbace_spec_test_alpha__init_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref(); A_arbace_spec_test_alpha__init_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_spec_test_alpha__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(); A_arbace_spec_test_alpha__init_A_const_4 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref(); A_arbace_spec_test_alpha__init_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_263); A_arbace_spec_test_alpha__init_A_const_6 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_264).Ref(); A_arbace_spec_test_alpha__init_A_const_7 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_146).Ref(); A_arbace_spec_test_alpha__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_17, Lit_148); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_spec_test_alpha__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(25).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_17, Lit_19); A_arbace_spec_test_alpha__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_17, Lit_268); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_spec_test_alpha__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_269).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_17, Lit_27); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_spec_test_alpha__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_17, Lit_270); A_arbace_spec_test_alpha__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_271).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_273, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_17, Lit_40); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_274).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_spec_test_alpha__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(63).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267, lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_275)); A_arbace_spec_test_alpha__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_17, Lit_276); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_spec_test_alpha__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_277).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_278, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(67).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_17, Lit_279); A_arbace_spec_test_alpha__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_280).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_281, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(72).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_17, Lit_57); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_spec_test_alpha__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(78).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_17, Lit_67); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_spec_test_alpha__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_282).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_52).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_50).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_51).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_283, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(81).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_17, Lit_71); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_spec_test_alpha__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_284).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_285, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(111).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_30 = lang.RT_Var_String_String__Var(Lit_17, Lit_61); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_spec_test_alpha__init_A_const_31 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_286).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_287).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_288, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_17, Lit_85); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_spec_test_alpha__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(160).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_17, Lit_121); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_spec_test_alpha__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(165).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_289); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_spec_test_alpha__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(165).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_17, Lit_92); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_spec_test_alpha__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_291, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(167).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_17, Lit_109); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_spec_test_alpha__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(176).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_17, Lit_102); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_spec_test_alpha__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_292, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(179).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_44 = lang.RT_Var_String_String__Var(Lit_17, Lit_101); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_spec_test_alpha__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_293, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(191).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_17, Lit_104); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_spec_test_alpha__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_286).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_294, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(197).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_17, Lit_105); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_spec_test_alpha__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_286).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_295, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(207).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_17, Lit_107); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_spec_test_alpha__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_286).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_290).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_296, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(216).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_17, Lit_110); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_spec_test_alpha__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_297, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(224).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_17, Lit_120); var tmp64 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp65 *jrt.Boolean; jrt.Boolean_Init(); tmp65 = jrt.Boolean_TRUE; var tmp66 any = tmp65.Ref(); A_arbace_spec_test_alpha__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_124).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_298, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(255).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_17, Lit_119); var tmp67 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp68 *jrt.Boolean; jrt.Boolean_Init(); tmp68 = jrt.Boolean_TRUE; var tmp69 any = tmp68.Ref(); A_arbace_spec_test_alpha__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp67, tmp69, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_299).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_112).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_43).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_300, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(266).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_17, Lit_118); var tmp70 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp71 *jrt.Boolean; jrt.Boolean_Init(); tmp71 = jrt.Boolean_TRUE; var tmp72 any = tmp71.Ref(); A_arbace_spec_test_alpha__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp70, tmp72, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_154).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_301).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_84).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_302, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(273).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_17, Lit_138); var tmp73 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp74 *jrt.Boolean; jrt.Boolean_Init(); tmp74 = jrt.Boolean_TRUE; var tmp75 any = tmp74.Ref(); A_arbace_spec_test_alpha__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp73, tmp75, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(278).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_17, Lit_140); var tmp76 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp77 *jrt.Boolean; jrt.Boolean_Init(); tmp77 = jrt.Boolean_TRUE; var tmp78 any = tmp77.Ref(); A_arbace_spec_test_alpha__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp76, tmp78, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(296).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_17, Lit_303); var tmp79 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp80 *jrt.Boolean; jrt.Boolean_Init(); tmp80 = jrt.Boolean_TRUE; var tmp81 any = tmp80.Ref(); A_arbace_spec_test_alpha__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp79, tmp81, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_304, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(306).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_66 = lang.RT_Var_String_String__Var(Lit_17, Lit_133); var tmp82 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp83 *jrt.Boolean; jrt.Boolean_Init(); tmp83 = jrt.Boolean_TRUE; var tmp84 any = tmp83.Ref(); A_arbace_spec_test_alpha__init_A_const_67 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp82, tmp84, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(311).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_68 = lang.RT_Var_String_String__Var(Lit_17, Lit_135); A_arbace_spec_test_alpha__init_A_const_69 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_305, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(316).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_70 = lang.RT_Var_String_String__Var(Lit_17, Lit_78); A_arbace_spec_test_alpha__init_A_const_71 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_307, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(327).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_72 = lang.RT_Var_String_String__Var(Lit_17, Lit_141); A_arbace_spec_test_alpha__init_A_const_73 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_308, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(376).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_74 = lang.RT_Var_String_String__Var(Lit_17, Lit_145); var tmp85 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp86 *jrt.Boolean; jrt.Boolean_Init(); tmp86 = jrt.Boolean_TRUE; var tmp87 any = tmp86.Ref(); A_arbace_spec_test_alpha__init_A_const_75 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp85, tmp87, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_309).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(392).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_76 = lang.RT_Var_String_String__Var(Lit_17, Lit_151); var tmp88 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp89 *jrt.Boolean; jrt.Boolean_Init(); tmp89 = jrt.Boolean_TRUE; var tmp90 any = tmp89.Ref(); A_arbace_spec_test_alpha__init_A_const_77 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp88, tmp90, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_310).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_311, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(402).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_78 = lang.RT_Var_String_String__Var(Lit_17, Lit_152); var tmp91 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp92 *jrt.Boolean; jrt.Boolean_Init(); tmp92 = jrt.Boolean_TRUE; var tmp93 any = tmp92.Ref(); A_arbace_spec_test_alpha__init_A_const_79 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp91, tmp93, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_310).Ref(), lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref(), lang.RT_Keyword_String_String__Keyword(Lit_146, Lit_132).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(419).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_80 = lang.RT_Var_String_String__Var(Lit_17, Lit_160); var tmp94 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp95 *jrt.Boolean; jrt.Boolean_Init(); tmp95 = jrt.Boolean_TRUE; var tmp96 any = tmp95.Ref(); A_arbace_spec_test_alpha__init_A_const_81 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp94, tmp96, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_312).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_313).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_314, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(428).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_82 = lang.RT_Var_String_String__Var(Lit_17, Lit_163); var tmp97 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp98 *jrt.Boolean; jrt.Boolean_Init(); tmp98 = jrt.Boolean_TRUE; var tmp99 any = tmp98.Ref(); A_arbace_spec_test_alpha__init_A_const_83 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp97, tmp99, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_158).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()))), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(440).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_84 = lang.RT_Var_String_String__Var(Lit_17, Lit_168); var tmp100 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp101 *jrt.Boolean; jrt.Boolean_Init(); tmp101 = jrt.Boolean_TRUE; var tmp102 any = tmp101.Ref(); A_arbace_spec_test_alpha__init_A_const_85 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp100, tmp102, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(461).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_86 = lang.RT_Var_String_String__Var(Lit_17, Lit_164); var tmp103 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp104 *jrt.Boolean; jrt.Boolean_Init(); tmp104 = jrt.Boolean_TRUE; var tmp105 any = tmp104.Ref(); A_arbace_spec_test_alpha__init_A_const_87 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp103, tmp105, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(468).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_88 = lang.RT_Var_String_String__Var(Lit_17, Lit_165); A_arbace_spec_test_alpha__init_A_const_89 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_157).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_315, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(472).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_90 = lang.RT_Var_String_String__Var(Lit_17, Lit_166); A_arbace_spec_test_alpha__init_A_const_91 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_316, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(480).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_92 = lang.RT_Var_String_String__Var(Lit_17, Lit_169); A_arbace_spec_test_alpha__init_A_const_93 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_306).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_317, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(489).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_94 = lang.RT_Var_String_String__Var(Lit_17, Lit_171); var tmp106 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp107 *jrt.Boolean; jrt.Boolean_Init(); tmp107 = jrt.Boolean_TRUE; var tmp108 any = tmp107.Ref(); A_arbace_spec_test_alpha__init_A_const_95 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp106, tmp108, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(532).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_96 = lang.RT_Var_String_String__Var(Lit_17, Lit_175); var tmp109 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp110 *jrt.Boolean; jrt.Boolean_Init(); tmp110 = jrt.Boolean_TRUE; var tmp111 any = tmp110.Ref(); A_arbace_spec_test_alpha__init_A_const_97 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp109, tmp111, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(536).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_98 = lang.RT_Var_String_String__Var(Lit_17, Lit_178); var tmp112 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_265).Ref(); var tmp113 *jrt.Boolean; jrt.Boolean_Init(); tmp113 = jrt.Boolean_TRUE; var tmp114 any = tmp113.Ref(); A_arbace_spec_test_alpha__init_A_const_99 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp112, tmp114, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_34).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_318, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(542).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_100 = lang.RT_Var_String_String__Var(Lit_17, Lit_183); A_arbace_spec_test_alpha__init_A_const_101 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_266).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_319, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(555).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)); A_arbace_spec_test_alpha__init_A_const_102 = lang.RT_Var_String_String__Var(Lit_17, Lit_182); A_arbace_spec_test_alpha__init_A_const_103 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_124).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_320).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_320).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_321).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_272).Ref(), Lit_322, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(565).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_50).Ref(), Lit_267)) }

func A_arbace_spec_test_alpha__init_A_New() *A_arbace_spec_test_alpha__init_A { A_arbace_spec_test_alpha__init_A_Init(); t := &A_arbace_spec_test_alpha__init_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha__init_A) Ctor() {}

func (t *A_arbace_spec_test_alpha__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha__init_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha__init_A_class }

func (t *A_arbace_spec_test_alpha__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha__init_A); return ok }

func A_arbace_spec_test_alpha__init_A_Cast(x any) *A_arbace_spec_test_alpha__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha__init_A_class)) }; return v }
