//line a2g_classes.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_spec_test_alpha_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_A_New()}; return nil }

var A_arbace_spec_test_alpha_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_test_alpha_A_new}

var A_arbace_spec_test_alpha_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_A"})

func init() { i := A_arbace_spec_test_alpha_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_A_Init; i.Table = A_arbace_spec_test_alpha_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_A]()) }

func A_arbace_spec_test_alpha___GT_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha___GT_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha___GT_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha___GT_sym_A_New()}; return nil }

func A_arbace_spec_test_alpha___GT_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha___GT_sym_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha___GT_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha___GT_sym_A_invoke, New: A_arbace_spec_test_alpha___GT_sym_A_new, Get: A_arbace_spec_test_alpha___GT_sym_A_get}

var A_arbace_spec_test_alpha___GT_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$__GT_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "__GT_sym", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha___GT_sym_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha___GT_sym_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha___GT_sym_A_InstanceOf; i.Init = A_arbace_spec_test_alpha___GT_sym_A_Init; i.Table = A_arbace_spec_test_alpha___GT_sym_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha___GT_sym_A_class, reflect.TypeFor[A_arbace_spec_test_alpha___GT_sym_A]()) }

func A_arbace_spec_test_alpha___GT_var_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha___GT_var_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha___GT_var_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha___GT_var_A_New()}; return nil }

func A_arbace_spec_test_alpha___GT_var_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha___GT_var_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha___GT_var_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha___GT_var_A_invoke, New: A_arbace_spec_test_alpha___GT_var_A_new, Get: A_arbace_spec_test_alpha___GT_var_A_get}

var A_arbace_spec_test_alpha___GT_var_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$__GT_var", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "__GT_var", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha___GT_var_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha___GT_var_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha___GT_var_A_InstanceOf; i.Init = A_arbace_spec_test_alpha___GT_var_A_Init; i.Table = A_arbace_spec_test_alpha___GT_var_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha___GT_var_A_class, reflect.TypeFor[A_arbace_spec_test_alpha___GT_var_A]()) }

func A_arbace_spec_test_alpha_abbrev_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_abbrev_result_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_abbrev_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_abbrev_result_A_New()}; return nil }

func A_arbace_spec_test_alpha_abbrev_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_abbrev_result_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_abbrev_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_abbrev_result_A_invoke, New: A_arbace_spec_test_alpha_abbrev_result_A_new, Get: A_arbace_spec_test_alpha_abbrev_result_A_get}

var A_arbace_spec_test_alpha_abbrev_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$abbrev_result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "abbrev_result", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_abbrev_result_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_abbrev_result_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_abbrev_result_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_abbrev_result_A_Init; i.Table = A_arbace_spec_test_alpha_abbrev_result_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_abbrev_result_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_abbrev_result_A]()) }

func A_arbace_spec_test_alpha_build_fixed_args_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_build_fixed_args_body_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_build_fixed_args_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_build_fixed_args_body_A_New()}; return nil }

func A_arbace_spec_test_alpha_build_fixed_args_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_build_fixed_args_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_build_fixed_args_body_A_invoke, New: A_arbace_spec_test_alpha_build_fixed_args_body_A_new, Get: A_arbace_spec_test_alpha_build_fixed_args_body_A_get}

var A_arbace_spec_test_alpha_build_fixed_args_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$build_fixed_args_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "build_fixed_args_body", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_fixed_args_body_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_build_fixed_args_body_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_build_fixed_args_body_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_build_fixed_args_body_A_Init; i.Table = A_arbace_spec_test_alpha_build_fixed_args_body_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_build_fixed_args_body_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_build_fixed_args_body_A]()) }

func A_arbace_spec_test_alpha_build_flattener_code_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_build_flattener_code_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_build_flattener_code_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_build_flattener_code_A_New()}; return nil }

func A_arbace_spec_test_alpha_build_flattener_code_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_build_flattener_code_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_build_flattener_code_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_build_flattener_code_A_invoke, New: A_arbace_spec_test_alpha_build_flattener_code_A_new, Get: A_arbace_spec_test_alpha_build_flattener_code_A_get}

var A_arbace_spec_test_alpha_build_flattener_code_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$build_flattener_code", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "build_flattener_code", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_flattener_code_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_build_flattener_code_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_build_flattener_code_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_build_flattener_code_A_Init; i.Table = A_arbace_spec_test_alpha_build_flattener_code_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_build_flattener_code_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_build_flattener_code_A]()) }

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(args[0])}; return nil }

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_invoke, New: A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_new, Get: A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_get}

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$build_flattener_code$fn__107000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_build_flattener_code_A_class, Simple: "fn__107000074", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_Init; i.Table = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A]()) }

func A_arbace_spec_test_alpha_build_kwargs_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_build_kwargs_body_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_build_kwargs_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_build_kwargs_body_A_New()}; return nil }

func A_arbace_spec_test_alpha_build_kwargs_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_build_kwargs_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_build_kwargs_body_A_invoke, New: A_arbace_spec_test_alpha_build_kwargs_body_A_new, Get: A_arbace_spec_test_alpha_build_kwargs_body_A_get}

var A_arbace_spec_test_alpha_build_kwargs_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$build_kwargs_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "build_kwargs_body", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_kwargs_body_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_build_kwargs_body_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_build_kwargs_body_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_build_kwargs_body_A_Init; i.Table = A_arbace_spec_test_alpha_build_kwargs_body_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_build_kwargs_body_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_build_kwargs_body_A]()) }

func A_arbace_spec_test_alpha_build_varargs_body_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_build_varargs_body_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_build_varargs_body_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_build_varargs_body_A_New()}; return nil }

func A_arbace_spec_test_alpha_build_varargs_body_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_build_varargs_body_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_build_varargs_body_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_build_varargs_body_A_invoke, New: A_arbace_spec_test_alpha_build_varargs_body_A_new, Get: A_arbace_spec_test_alpha_build_varargs_body_A_get}

var A_arbace_spec_test_alpha_build_varargs_body_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$build_varargs_body", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "build_varargs_body", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_varargs_body_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_build_varargs_body_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_build_varargs_body_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_build_varargs_body_A_Init; i.Table = A_arbace_spec_test_alpha_build_varargs_body_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_build_varargs_body_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_build_varargs_body_A]()) }

func A_arbace_spec_test_alpha_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_check_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_spec_test_alpha_check_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_spec_test_alpha_check_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_check_A_New()}; return nil }

func A_arbace_spec_test_alpha_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_check_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_check_A_invoke, New: A_arbace_spec_test_alpha_check_A_new, Get: A_arbace_spec_test_alpha_check_A_get}

var A_arbace_spec_test_alpha_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "check", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_check_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_check_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_check_A_Init; i.Table = A_arbace_spec_test_alpha_check_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_check_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_check_A]()) }

func A_arbace_spec_test_alpha_check_fn__107000127_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_check_fn__107000127_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_check_fn__107000127_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(args[0])}; return nil }

func A_arbace_spec_test_alpha_check_fn__107000127_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_check_fn__107000127_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_check_fn__107000127_A_invoke, New: A_arbace_spec_test_alpha_check_fn__107000127_A_new, Get: A_arbace_spec_test_alpha_check_fn__107000127_A_get}

var A_arbace_spec_test_alpha_check_fn__107000127_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$check$fn__107000127", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_check_A_class, Simple: "fn__107000127", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_fn__107000127_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_check_fn__107000127_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_check_fn__107000127_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_check_fn__107000127_A_Init; i.Table = A_arbace_spec_test_alpha_check_fn__107000127_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_check_fn__107000127_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_check_fn__107000127_A]()) }

func A_arbace_spec_test_alpha_check_1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_check_1_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_check_1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_check_1_A_New()}; return nil }

func A_arbace_spec_test_alpha_check_1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_check_1_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_check_1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_check_1_A_invoke, New: A_arbace_spec_test_alpha_check_1_A_new, Get: A_arbace_spec_test_alpha_check_1_A_get}

var A_arbace_spec_test_alpha_check_1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$check_1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "check_1", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_1_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_check_1_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_check_1_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_check_1_A_Init; i.Table = A_arbace_spec_test_alpha_check_1_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_check_1_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_check_1_A]()) }

func A_arbace_spec_test_alpha_check_call_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_check_call_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_check_call_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_check_call_A_New()}; return nil }

func A_arbace_spec_test_alpha_check_call_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_check_call_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_check_call_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_check_call_A_invoke, New: A_arbace_spec_test_alpha_check_call_A_new, Get: A_arbace_spec_test_alpha_check_call_A_get}

var A_arbace_spec_test_alpha_check_call_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$check_call", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "check_call", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_call_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_check_call_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_check_call_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_check_call_A_Init; i.Table = A_arbace_spec_test_alpha_check_call_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_check_call_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_check_call_A]()) }

func A_arbace_spec_test_alpha_check_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_check_fn_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_spec_test_alpha_check_fn_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_check_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_check_fn_A_New()}; return nil }

func A_arbace_spec_test_alpha_check_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_check_fn_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_check_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_check_fn_A_invoke, New: A_arbace_spec_test_alpha_check_fn_A_new, Get: A_arbace_spec_test_alpha_check_fn_A_get}

var A_arbace_spec_test_alpha_check_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$check_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "check_fn", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_fn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_check_fn_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_check_fn_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_check_fn_A_Init; i.Table = A_arbace_spec_test_alpha_check_fn_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_check_fn_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_check_fn_A]()) }

func A_arbace_spec_test_alpha_checkable_syms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_checkable_syms_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_spec_test_alpha_checkable_syms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_checkable_syms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_checkable_syms_A_New()}; return nil }

func A_arbace_spec_test_alpha_checkable_syms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_checkable_syms_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_checkable_syms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_checkable_syms_A_invoke, New: A_arbace_spec_test_alpha_checkable_syms_A_new, Get: A_arbace_spec_test_alpha_checkable_syms_A_get}

var A_arbace_spec_test_alpha_checkable_syms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$checkable_syms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "checkable_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_checkable_syms_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_checkable_syms_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_checkable_syms_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_checkable_syms_A_Init; i.Table = A_arbace_spec_test_alpha_checkable_syms_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_checkable_syms_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_checkable_syms_A]()) }

func A_arbace_spec_test_alpha_collectionize_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_collectionize_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_collectionize_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_collectionize_A_New()}; return nil }

func A_arbace_spec_test_alpha_collectionize_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_collectionize_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_collectionize_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_collectionize_A_invoke, New: A_arbace_spec_test_alpha_collectionize_A_new, Get: A_arbace_spec_test_alpha_collectionize_A_get}

var A_arbace_spec_test_alpha_collectionize_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$collectionize", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "collectionize", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_collectionize_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_collectionize_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_collectionize_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_collectionize_A_Init; i.Table = A_arbace_spec_test_alpha_collectionize_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_collectionize_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_collectionize_A]()) }

func A_arbace_spec_test_alpha_enumerate_namespace_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_enumerate_namespace_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_enumerate_namespace_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_enumerate_namespace_A_New()}; return nil }

func A_arbace_spec_test_alpha_enumerate_namespace_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_enumerate_namespace_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_enumerate_namespace_A_invoke, New: A_arbace_spec_test_alpha_enumerate_namespace_A_new, Get: A_arbace_spec_test_alpha_enumerate_namespace_A_get}

var A_arbace_spec_test_alpha_enumerate_namespace_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$enumerate_namespace", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "enumerate_namespace", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_enumerate_namespace_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_enumerate_namespace_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_enumerate_namespace_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_enumerate_namespace_A_Init; i.Table = A_arbace_spec_test_alpha_enumerate_namespace_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_enumerate_namespace_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_enumerate_namespace_A]()) }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New()}; return nil }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_invoke, New: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_new, Get: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_get}

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$enumerate_namespace$fn__107000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_enumerate_namespace_A_class, Simple: "fn__107000020", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_Init; i.Table = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A]()) }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(args[0])}; return nil }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_invoke, New: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_new, Get: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_get}

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$enumerate_namespace$fn__107000020$fn__107000021", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class, Simple: "fn__107000021", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_Init; i.Table = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A]()) }

func A_arbace_spec_test_alpha_eval107000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_eval107000002_A_New()}; return nil }

var A_arbace_spec_test_alpha_eval107000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_test_alpha_eval107000002_A_new}

var A_arbace_spec_test_alpha_eval107000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$eval107000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "eval107000002", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000002_A"})

func init() { i := A_arbace_spec_test_alpha_eval107000002_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_eval107000002_A_InstanceOf; i.Table = A_arbace_spec_test_alpha_eval107000002_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_eval107000002_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_eval107000002_A]()) }

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_New()}; return nil }

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_invoke, New: A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_new, Get: A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_get}

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$eval107000002$loading__1927001464__auto____107000003", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_eval107000002_A_class, Simple: "loading__1927001464__auto____107000003", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_Init; i.Table = A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A]()) }

func A_arbace_spec_test_alpha_eval107000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_eval107000006_A_New()}; return nil }

var A_arbace_spec_test_alpha_eval107000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_test_alpha_eval107000006_A_new}

var A_arbace_spec_test_alpha_eval107000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$eval107000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "eval107000006", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000006_A"})

func init() { i := A_arbace_spec_test_alpha_eval107000006_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_eval107000006_A_InstanceOf; i.Table = A_arbace_spec_test_alpha_eval107000006_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_eval107000006_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_eval107000006_A]()) }

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_eval107000006_fn__107000007_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_New()}; return nil }

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_invoke, New: A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_new, Get: A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_get}

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$eval107000006$fn__107000007", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_eval107000006_A_class, Simple: "fn__107000007", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000006_fn__107000007_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_Init; i.Table = A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_eval107000006_fn__107000007_A]()) }

func A_arbace_spec_test_alpha_explain_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_explain_check_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_test_alpha_explain_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_explain_check_A_New()}; return nil }

func A_arbace_spec_test_alpha_explain_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_explain_check_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_explain_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_explain_check_A_invoke, New: A_arbace_spec_test_alpha_explain_check_A_new, Get: A_arbace_spec_test_alpha_explain_check_A_get}

var A_arbace_spec_test_alpha_explain_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$explain_check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "explain_check", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_explain_check_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_explain_check_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_explain_check_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_explain_check_A_Init; i.Table = A_arbace_spec_test_alpha_explain_check_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_explain_check_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_explain_check_A]()) }

func A_arbace_spec_test_alpha_failure_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_failure_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_failure_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_failure_type_A_New()}; return nil }

func A_arbace_spec_test_alpha_failure_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_failure_type_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_failure_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_failure_type_A_invoke, New: A_arbace_spec_test_alpha_failure_type_A_new, Get: A_arbace_spec_test_alpha_failure_type_A_get}

var A_arbace_spec_test_alpha_failure_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$failure_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "failure_type", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_failure_type_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_failure_type_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_failure_type_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_failure_type_A_Init; i.Table = A_arbace_spec_test_alpha_failure_type_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_failure_type_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_failure_type_A]()) }

func A_arbace_spec_test_alpha_find_varargs_decl_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_find_varargs_decl_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_find_varargs_decl_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_find_varargs_decl_A_New()}; return nil }

func A_arbace_spec_test_alpha_find_varargs_decl_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_find_varargs_decl_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_find_varargs_decl_A_invoke, New: A_arbace_spec_test_alpha_find_varargs_decl_A_new, Get: A_arbace_spec_test_alpha_find_varargs_decl_A_get}

var A_arbace_spec_test_alpha_find_varargs_decl_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$find_varargs_decl", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "find_varargs_decl", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_find_varargs_decl_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_find_varargs_decl_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_find_varargs_decl_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_find_varargs_decl_A_Init; i.Table = A_arbace_spec_test_alpha_find_varargs_decl_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_find_varargs_decl_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_find_varargs_decl_A]()) }

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_fn_spec_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_fn_spec_QMARK__A_New()}; return nil }

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_fn_spec_QMARK__A_invoke, New: A_arbace_spec_test_alpha_fn_spec_QMARK__A_new, Get: A_arbace_spec_test_alpha_fn_spec_QMARK__A_get}

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$fn_spec_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "fn_spec_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_fn_spec_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_fn_spec_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_fn_spec_QMARK__A_InstanceOf; i.Init = A_arbace_spec_test_alpha_fn_spec_QMARK__A_Init; i.Table = A_arbace_spec_test_alpha_fn_spec_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_fn_spec_QMARK__A_class, reflect.TypeFor[A_arbace_spec_test_alpha_fn_spec_QMARK__A]()) }

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_fn_spec_name_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_New()}; return nil }

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_invoke, New: A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_new, Get: A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_get}

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$fn_spec_name_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "fn_spec_name_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_fn_spec_name_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_InstanceOf; i.Init = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_Init; i.Table = A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class, reflect.TypeFor[A_arbace_spec_test_alpha_fn_spec_name_QMARK__A]()) }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_gen_fixed_args_syms_A_New()}; return nil }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_gen_fixed_args_syms_A_invoke, New: A_arbace_spec_test_alpha_gen_fixed_args_syms_A_new, Get: A_arbace_spec_test_alpha_gen_fixed_args_syms_A_get}

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$gen_fixed_args_syms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "gen_fixed_args_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_gen_fixed_args_syms_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_Init; i.Table = A_arbace_spec_test_alpha_gen_fixed_args_syms_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_gen_fixed_args_syms_A]()) }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New()}; return nil }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_invoke, New: A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_new, Get: A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_get}

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$gen_fixed_args_syms$fn__107000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class, Simple: "fn__107000068", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_Init; i.Table = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A]()) }

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_has_kwargs_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_has_kwargs_QMARK__A_New()}; return nil }

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_has_kwargs_QMARK__A_invoke, New: A_arbace_spec_test_alpha_has_kwargs_QMARK__A_new, Get: A_arbace_spec_test_alpha_has_kwargs_QMARK__A_get}

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$has_kwargs_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "has_kwargs_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_has_kwargs_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_InstanceOf; i.Init = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_Init; i.Table = A_arbace_spec_test_alpha_has_kwargs_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class, reflect.TypeFor[A_arbace_spec_test_alpha_has_kwargs_QMARK__A]()) }

func A_arbace_spec_test_alpha_instrument_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_instrument_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_spec_test_alpha_instrument_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_spec_test_alpha_instrument_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_instrument_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_instrument_A_New()}; return nil }

func A_arbace_spec_test_alpha_instrument_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_instrument_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_instrument_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_instrument_A_invoke, New: A_arbace_spec_test_alpha_instrument_A_new, Get: A_arbace_spec_test_alpha_instrument_A_get}

var A_arbace_spec_test_alpha_instrument_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$instrument", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "instrument", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_instrument_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_instrument_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_instrument_A_Init; i.Table = A_arbace_spec_test_alpha_instrument_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_instrument_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_instrument_A]()) }

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_instrument_fn__107000097_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(args[0])}; return nil }

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_instrument_fn__107000097_A_invoke, New: A_arbace_spec_test_alpha_instrument_fn__107000097_A_new, Get: A_arbace_spec_test_alpha_instrument_fn__107000097_A_get}

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$instrument$fn__107000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_instrument_A_class, Simple: "fn__107000097", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_fn__107000097_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_instrument_fn__107000097_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_instrument_fn__107000097_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_instrument_fn__107000097_A_Init; i.Table = A_arbace_spec_test_alpha_instrument_fn__107000097_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_instrument_fn__107000097_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_instrument_fn__107000097_A]()) }

func A_arbace_spec_test_alpha_instrument_1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_instrument_1_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_instrument_1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_instrument_1_A_New()}; return nil }

func A_arbace_spec_test_alpha_instrument_1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_instrument_1_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_instrument_1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_instrument_1_A_invoke, New: A_arbace_spec_test_alpha_instrument_1_A_new, Get: A_arbace_spec_test_alpha_instrument_1_A_get}

var A_arbace_spec_test_alpha_instrument_1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$instrument_1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "instrument_1", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_1_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_instrument_1_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_instrument_1_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_instrument_1_A_Init; i.Table = A_arbace_spec_test_alpha_instrument_1_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_instrument_1_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_instrument_1_A]()) }

func A_arbace_spec_test_alpha_instrument_choose_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_instrument_choose_fn_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_spec_test_alpha_instrument_choose_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_instrument_choose_fn_A_New()}; return nil }

func A_arbace_spec_test_alpha_instrument_choose_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_instrument_choose_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_instrument_choose_fn_A_invoke, New: A_arbace_spec_test_alpha_instrument_choose_fn_A_new, Get: A_arbace_spec_test_alpha_instrument_choose_fn_A_get}

var A_arbace_spec_test_alpha_instrument_choose_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$instrument_choose_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "instrument_choose_fn", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_choose_fn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_instrument_choose_fn_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_instrument_choose_fn_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_instrument_choose_fn_A_Init; i.Table = A_arbace_spec_test_alpha_instrument_choose_fn_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_instrument_choose_fn_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_instrument_choose_fn_A]()) }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_instrument_choose_spec_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_instrument_choose_spec_A_New()}; return nil }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_instrument_choose_spec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_instrument_choose_spec_A_invoke, New: A_arbace_spec_test_alpha_instrument_choose_spec_A_new, Get: A_arbace_spec_test_alpha_instrument_choose_spec_A_get}

var A_arbace_spec_test_alpha_instrument_choose_spec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$instrument_choose_spec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "instrument_choose_spec", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_choose_spec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_instrument_choose_spec_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_instrument_choose_spec_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_instrument_choose_spec_A_Init; i.Table = A_arbace_spec_test_alpha_instrument_choose_spec_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_instrument_choose_spec_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_instrument_choose_spec_A]()) }

func A_arbace_spec_test_alpha_instrumentable_syms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_instrumentable_syms_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_spec_test_alpha_instrumentable_syms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_instrumentable_syms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_instrumentable_syms_A_New()}; return nil }

func A_arbace_spec_test_alpha_instrumentable_syms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_instrumentable_syms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_instrumentable_syms_A_invoke, New: A_arbace_spec_test_alpha_instrumentable_syms_A_new, Get: A_arbace_spec_test_alpha_instrumentable_syms_A_get}

var A_arbace_spec_test_alpha_instrumentable_syms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$instrumentable_syms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "instrumentable_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrumentable_syms_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_instrumentable_syms_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_instrumentable_syms_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_instrumentable_syms_A_Init; i.Table = A_arbace_spec_test_alpha_instrumentable_syms_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_instrumentable_syms_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_instrumentable_syms_A]()) }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_interpret_stack_trace_element_A_New()}; return nil }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_interpret_stack_trace_element_A_invoke, New: A_arbace_spec_test_alpha_interpret_stack_trace_element_A_new, Get: A_arbace_spec_test_alpha_interpret_stack_trace_element_A_get}

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$interpret_stack_trace_element", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "interpret_stack_trace_element", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_interpret_stack_trace_element_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_Init; i.Table = A_arbace_spec_test_alpha_interpret_stack_trace_element_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_interpret_stack_trace_element_A]()) }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New()}; return nil }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_invoke, New: A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_new, Get: A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_get}

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$interpret_stack_trace_element$degensym__107000043", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class, Simple: "degensym__107000043", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_Init; i.Table = A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A]()) }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New()}; return nil }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_invoke, New: A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_new, Get: A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_get}

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$interpret_stack_trace_element$demunge__107000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class, Simple: "demunge__107000041", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_Init; i.Table = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A]()) }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_kwargs__GT_kvs_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_kwargs__GT_kvs_A_New()}; return nil }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_kwargs__GT_kvs_A_invoke, New: A_arbace_spec_test_alpha_kwargs__GT_kvs_A_new, Get: A_arbace_spec_test_alpha_kwargs__GT_kvs_A_get}

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$kwargs__GT_kvs", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "kwargs__GT_kvs", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_kwargs__GT_kvs_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_Init; i.Table = A_arbace_spec_test_alpha_kwargs__GT_kvs_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_kwargs__GT_kvs_A]()) }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New()}; return nil }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_invoke, New: A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_new, Get: A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_get}

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$kwargs__GT_kvs$fn__107000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class, Simple: "fn__107000065", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_Init; i.Table = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A]()) }

func A_arbace_spec_test_alpha_make_check_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_make_check_result_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_make_check_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_make_check_result_A_New()}; return nil }

func A_arbace_spec_test_alpha_make_check_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_make_check_result_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_make_check_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_make_check_result_A_invoke, New: A_arbace_spec_test_alpha_make_check_result_A_new, Get: A_arbace_spec_test_alpha_make_check_result_A_get}

var A_arbace_spec_test_alpha_make_check_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$make_check_result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "make_check_result", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_make_check_result_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_make_check_result_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_make_check_result_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_make_check_result_A_Init; i.Table = A_arbace_spec_test_alpha_make_check_result_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_make_check_result_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_make_check_result_A]()) }

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_New()}; return nil }

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_invoke, New: A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_new, Get: A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_get}

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$maybe_wrap_kvs_emulation", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "maybe_wrap_kvs_emulation", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_Init; i.Table = A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A]()) }

func A_arbace_spec_test_alpha_no_fspec_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_no_fspec_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_no_fspec_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_no_fspec_A_New()}; return nil }

func A_arbace_spec_test_alpha_no_fspec_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_no_fspec_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_no_fspec_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_no_fspec_A_invoke, New: A_arbace_spec_test_alpha_no_fspec_A_new, Get: A_arbace_spec_test_alpha_no_fspec_A_get}

var A_arbace_spec_test_alpha_no_fspec_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$no_fspec", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "no_fspec", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_no_fspec_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_no_fspec_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_no_fspec_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_no_fspec_A_Init; i.Table = A_arbace_spec_test_alpha_no_fspec_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_no_fspec_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_no_fspec_A]()) }

func A_arbace_spec_test_alpha_opt_syms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_opt_syms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_opt_syms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_opt_syms_A_New()}; return nil }

func A_arbace_spec_test_alpha_opt_syms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_opt_syms_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_opt_syms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_opt_syms_A_invoke, New: A_arbace_spec_test_alpha_opt_syms_A_new, Get: A_arbace_spec_test_alpha_opt_syms_A_get}

var A_arbace_spec_test_alpha_opt_syms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$opt_syms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "opt_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_opt_syms_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_opt_syms_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_opt_syms_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_opt_syms_A_Init; i.Table = A_arbace_spec_test_alpha_opt_syms_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_opt_syms_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_opt_syms_A]()) }

func A_arbace_spec_test_alpha_quick_check_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_quick_check_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_quick_check_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_quick_check_A_New()}; return nil }

func A_arbace_spec_test_alpha_quick_check_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_quick_check_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_quick_check_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_quick_check_A_invoke, New: A_arbace_spec_test_alpha_quick_check_A_new, Get: A_arbace_spec_test_alpha_quick_check_A_get}

var A_arbace_spec_test_alpha_quick_check_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$quick_check", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "quick_check", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_quick_check_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_quick_check_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_quick_check_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_quick_check_A_Init; i.Table = A_arbace_spec_test_alpha_quick_check_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_quick_check_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_quick_check_A]()) }

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_quick_check_fn__107000111_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_quick_check_fn__107000111_A_invoke, New: A_arbace_spec_test_alpha_quick_check_fn__107000111_A_new, Get: A_arbace_spec_test_alpha_quick_check_fn__107000111_A_get}

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$quick_check$fn__107000111", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_quick_check_A_class, Simple: "fn__107000111", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_quick_check_fn__107000111_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_Init; i.Table = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_quick_check_fn__107000111_A]()) }

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_quick_check_fn__107000113_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_quick_check_fn__107000113_A_invoke, New: A_arbace_spec_test_alpha_quick_check_fn__107000113_A_new, Get: A_arbace_spec_test_alpha_quick_check_fn__107000113_A_get}

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$quick_check$fn__107000113", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_quick_check_A_class, Simple: "fn__107000113", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_quick_check_fn__107000113_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_Init; i.Table = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_quick_check_fn__107000113_A]()) }

func A_arbace_spec_test_alpha_result_type_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_result_type_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_result_type_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_result_type_A_New()}; return nil }

func A_arbace_spec_test_alpha_result_type_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_result_type_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_result_type_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_result_type_A_invoke, New: A_arbace_spec_test_alpha_result_type_A_new, Get: A_arbace_spec_test_alpha_result_type_A_get}

var A_arbace_spec_test_alpha_result_type_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$result_type", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "result_type", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_result_type_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_result_type_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_result_type_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_result_type_A_Init; i.Table = A_arbace_spec_test_alpha_result_type_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_result_type_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_result_type_A]()) }

func A_arbace_spec_test_alpha_spec_checking_fn_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_spec_checking_fn_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_spec_checking_fn_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_spec_checking_fn_A_New()}; return nil }

func A_arbace_spec_test_alpha_spec_checking_fn_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_spec_checking_fn_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_spec_checking_fn_A_invoke, New: A_arbace_spec_test_alpha_spec_checking_fn_A_new, Get: A_arbace_spec_test_alpha_spec_checking_fn_A_get}

var A_arbace_spec_test_alpha_spec_checking_fn_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$spec_checking_fn", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "spec_checking_fn", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_spec_checking_fn_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_spec_checking_fn_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_spec_checking_fn_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_spec_checking_fn_A_Init; i.Table = A_arbace_spec_test_alpha_spec_checking_fn_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_spec_checking_fn_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_spec_checking_fn_A]()) }

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A).Invoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New()}; return nil }

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_invoke, New: A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_new, Get: A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_get}

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$spec_checking_fn$conform_BANG___107000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF5_class}, Declaring: A_arbace_spec_test_alpha_spec_checking_fn_A_class, Simple: "conform_BANG___107000052", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_Init; i.Table = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A]()) }

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_invoke, New: A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_new, Get: A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_get}

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$spec_checking_fn$fn__107000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_spec_test_alpha_spec_checking_fn_A_class, Simple: "fn__107000054", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_Init; i.Table = A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A]()) }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_New()}; return nil }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_invoke, New: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_new, Get: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_get}

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$stacktrace_relevant_to_instrument", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "stacktrace_relevant_to_instrument", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_Init; i.Table = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A]()) }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New()}; return nil }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_invoke, New: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_new, Get: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_get}

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$stacktrace_relevant_to_instrument$plumbing_QMARK___107000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class, Simple: "plumbing_QMARK___107000047", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_Init; i.Table = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A]()) }

func A_arbace_spec_test_alpha_summarize_results_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_summarize_results_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_spec_test_alpha_summarize_results_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_summarize_results_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_summarize_results_A_New()}; return nil }

func A_arbace_spec_test_alpha_summarize_results_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_summarize_results_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_summarize_results_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_summarize_results_A_invoke, New: A_arbace_spec_test_alpha_summarize_results_A_new, Get: A_arbace_spec_test_alpha_summarize_results_A_get}

var A_arbace_spec_test_alpha_summarize_results_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$summarize_results", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "summarize_results", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_summarize_results_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_summarize_results_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_summarize_results_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_summarize_results_A_Init; i.Table = A_arbace_spec_test_alpha_summarize_results_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_summarize_results_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_summarize_results_A]()) }

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_summarize_results_fn__107000134_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(args[0])}; return nil }

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_invoke, New: A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_new, Get: A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_get}

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$summarize_results$fn__107000134", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_spec_test_alpha_summarize_results_A_class, Simple: "fn__107000134", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_summarize_results_fn__107000134_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_Init; i.Table = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_summarize_results_fn__107000134_A]()) }

func A_arbace_spec_test_alpha_sym__GT_check_map_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_sym__GT_check_map_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_sym__GT_check_map_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_sym__GT_check_map_A_New()}; return nil }

func A_arbace_spec_test_alpha_sym__GT_check_map_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_sym__GT_check_map_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_sym__GT_check_map_A_invoke, New: A_arbace_spec_test_alpha_sym__GT_check_map_A_new, Get: A_arbace_spec_test_alpha_sym__GT_check_map_A_get}

var A_arbace_spec_test_alpha_sym__GT_check_map_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$sym__GT_check_map", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "sym__GT_check_map", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_sym__GT_check_map_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_sym__GT_check_map_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_sym__GT_check_map_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_sym__GT_check_map_A_Init; i.Table = A_arbace_spec_test_alpha_sym__GT_check_map_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_sym__GT_check_map_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_sym__GT_check_map_A]()) }

func A_arbace_spec_test_alpha_throwable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_throwable_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_throwable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_throwable_QMARK__A_New()}; return nil }

func A_arbace_spec_test_alpha_throwable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_throwable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_throwable_QMARK__A_invoke, New: A_arbace_spec_test_alpha_throwable_QMARK__A_new, Get: A_arbace_spec_test_alpha_throwable_QMARK__A_get}

var A_arbace_spec_test_alpha_throwable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$throwable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "throwable_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_throwable_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_throwable_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_throwable_QMARK__A_InstanceOf; i.Init = A_arbace_spec_test_alpha_throwable_QMARK__A_Init; i.Table = A_arbace_spec_test_alpha_throwable_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_throwable_QMARK__A_class, reflect.TypeFor[A_arbace_spec_test_alpha_throwable_QMARK__A]()) }

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_thunk_frame_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_thunk_frame_QMARK__A_New()}; return nil }

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_thunk_frame_QMARK__A_invoke, New: A_arbace_spec_test_alpha_thunk_frame_QMARK__A_new, Get: A_arbace_spec_test_alpha_thunk_frame_QMARK__A_get}

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$thunk_frame_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "thunk_frame_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_thunk_frame_QMARK__A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_InstanceOf; i.Init = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_Init; i.Table = A_arbace_spec_test_alpha_thunk_frame_QMARK__A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class, reflect.TypeFor[A_arbace_spec_test_alpha_thunk_frame_QMARK__A]()) }

func A_arbace_spec_test_alpha_unstrument_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_unstrument_A).Invoke_O__O(args[0]); case 1: return this.(*A_arbace_spec_test_alpha_unstrument_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_unstrument_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_unstrument_A_New()}; return nil }

func A_arbace_spec_test_alpha_unstrument_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_unstrument_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_unstrument_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_unstrument_A_invoke, New: A_arbace_spec_test_alpha_unstrument_A_new, Get: A_arbace_spec_test_alpha_unstrument_A_get}

var A_arbace_spec_test_alpha_unstrument_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$unstrument", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "unstrument", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_unstrument_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_unstrument_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_unstrument_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_unstrument_A_Init; i.Table = A_arbace_spec_test_alpha_unstrument_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_unstrument_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_unstrument_A]()) }

func A_arbace_spec_test_alpha_unstrument_1_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_unstrument_1_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_unstrument_1_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_unstrument_1_A_New()}; return nil }

func A_arbace_spec_test_alpha_unstrument_1_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_unstrument_1_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_unstrument_1_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_unstrument_1_A_invoke, New: A_arbace_spec_test_alpha_unstrument_1_A_new, Get: A_arbace_spec_test_alpha_unstrument_1_A_get}

var A_arbace_spec_test_alpha_unstrument_1_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$unstrument_1", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "unstrument_1", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_unstrument_1_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_unstrument_1_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_unstrument_1_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_unstrument_1_A_Init; i.Table = A_arbace_spec_test_alpha_unstrument_1_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_unstrument_1_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_unstrument_1_A]()) }

func A_arbace_spec_test_alpha_unwrap_failure_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_unwrap_failure_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_unwrap_failure_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_unwrap_failure_A_New()}; return nil }

func A_arbace_spec_test_alpha_unwrap_failure_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_unwrap_failure_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_unwrap_failure_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_unwrap_failure_A_invoke, New: A_arbace_spec_test_alpha_unwrap_failure_A_new, Get: A_arbace_spec_test_alpha_unwrap_failure_A_get}

var A_arbace_spec_test_alpha_unwrap_failure_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$unwrap_failure", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "unwrap_failure", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_unwrap_failure_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_unwrap_failure_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_unwrap_failure_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_unwrap_failure_A_Init; i.Table = A_arbace_spec_test_alpha_unwrap_failure_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_unwrap_failure_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_unwrap_failure_A]()) }

func A_arbace_spec_test_alpha_validate_check_opts_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_validate_check_opts_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_spec_test_alpha_validate_check_opts_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_validate_check_opts_A_New()}; return nil }

func A_arbace_spec_test_alpha_validate_check_opts_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_validate_check_opts_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_validate_check_opts_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_validate_check_opts_A_invoke, New: A_arbace_spec_test_alpha_validate_check_opts_A_new, Get: A_arbace_spec_test_alpha_validate_check_opts_A_get}

var A_arbace_spec_test_alpha_validate_check_opts_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$validate_check_opts", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "validate_check_opts", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_validate_check_opts_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_validate_check_opts_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_validate_check_opts_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_validate_check_opts_A_Init; i.Table = A_arbace_spec_test_alpha_validate_check_opts_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_validate_check_opts_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_validate_check_opts_A]()) }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_spec_test_alpha_with_instrument_disabled_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_with_instrument_disabled_A_New()}; return nil }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class)}; return nil }

var A_arbace_spec_test_alpha_with_instrument_disabled_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_spec_test_alpha_with_instrument_disabled_A_invoke, New: A_arbace_spec_test_alpha_with_instrument_disabled_A_new, Get: A_arbace_spec_test_alpha_with_instrument_disabled_A_get}

var A_arbace_spec_test_alpha_with_instrument_disabled_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$with_instrument_disabled", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "with_instrument_disabled", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_with_instrument_disabled_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha_with_instrument_disabled_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_with_instrument_disabled_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_with_instrument_disabled_A_Init; i.Table = A_arbace_spec_test_alpha_with_instrument_disabled_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha_with_instrument_disabled_A_class, reflect.TypeFor[A_arbace_spec_test_alpha_with_instrument_disabled_A]()) }

func A_arbace_spec_test_alpha__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha__init_A_Load__O(); case 1: return A_arbace_spec_test_alpha__init_A_Unit0__O(); case 2: return A_arbace_spec_test_alpha__init_A_Unit1__O(); case 3: return A_arbace_spec_test_alpha__init_A_Unit10__O(); case 4: return A_arbace_spec_test_alpha__init_A_Unit11__O(); case 5: return A_arbace_spec_test_alpha__init_A_Unit12__O(); case 6: return A_arbace_spec_test_alpha__init_A_Unit13__O(); case 7: return A_arbace_spec_test_alpha__init_A_Unit14__O(); case 8: return A_arbace_spec_test_alpha__init_A_Unit15__O(); case 9: return A_arbace_spec_test_alpha__init_A_Unit16__O(); case 10: return A_arbace_spec_test_alpha__init_A_Unit17__O(); case 11: return A_arbace_spec_test_alpha__init_A_Unit18__O(); case 12: return A_arbace_spec_test_alpha__init_A_Unit19__O(); case 13: return A_arbace_spec_test_alpha__init_A_Unit2__O(); case 14: return A_arbace_spec_test_alpha__init_A_Unit20__O(); case 15: return A_arbace_spec_test_alpha__init_A_Unit21__O(); case 16: return A_arbace_spec_test_alpha__init_A_Unit22__O(); case 17: return A_arbace_spec_test_alpha__init_A_Unit23__O(); case 18: return A_arbace_spec_test_alpha__init_A_Unit24__O(); case 19: return A_arbace_spec_test_alpha__init_A_Unit25__O(); case 20: return A_arbace_spec_test_alpha__init_A_Unit26__O(); case 21: return A_arbace_spec_test_alpha__init_A_Unit27__O(); case 22: return A_arbace_spec_test_alpha__init_A_Unit28__O(); case 23: return A_arbace_spec_test_alpha__init_A_Unit29__O(); case 24: return A_arbace_spec_test_alpha__init_A_Unit3__O(); case 25: return A_arbace_spec_test_alpha__init_A_Unit30__O(); case 26: return A_arbace_spec_test_alpha__init_A_Unit31__O(); case 27: return A_arbace_spec_test_alpha__init_A_Unit32__O(); case 28: return A_arbace_spec_test_alpha__init_A_Unit33__O(); case 29: return A_arbace_spec_test_alpha__init_A_Unit34__O(); case 30: return A_arbace_spec_test_alpha__init_A_Unit35__O(); case 31: return A_arbace_spec_test_alpha__init_A_Unit36__O(); case 32: return A_arbace_spec_test_alpha__init_A_Unit37__O(); case 33: return A_arbace_spec_test_alpha__init_A_Unit38__O(); case 34: return A_arbace_spec_test_alpha__init_A_Unit39__O(); case 35: return A_arbace_spec_test_alpha__init_A_Unit4__O(); case 36: return A_arbace_spec_test_alpha__init_A_Unit40__O(); case 37: return A_arbace_spec_test_alpha__init_A_Unit41__O(); case 38: return A_arbace_spec_test_alpha__init_A_Unit42__O(); case 39: return A_arbace_spec_test_alpha__init_A_Unit43__O(); case 40: return A_arbace_spec_test_alpha__init_A_Unit44__O(); case 41: return A_arbace_spec_test_alpha__init_A_Unit45__O(); case 42: return A_arbace_spec_test_alpha__init_A_Unit46__O(); case 43: return A_arbace_spec_test_alpha__init_A_Unit47__O(); case 44: return A_arbace_spec_test_alpha__init_A_Unit48__O(); case 45: return A_arbace_spec_test_alpha__init_A_Unit49__O(); case 46: return A_arbace_spec_test_alpha__init_A_Unit5__O(); case 47: return A_arbace_spec_test_alpha__init_A_Unit50__O(); case 48: return A_arbace_spec_test_alpha__init_A_Unit51__O(); case 49: return A_arbace_spec_test_alpha__init_A_Unit52__O(); case 50: return A_arbace_spec_test_alpha__init_A_Unit53__O(); case 51: return A_arbace_spec_test_alpha__init_A_Unit54__O(); case 52: return A_arbace_spec_test_alpha__init_A_Unit55__O(); case 53: return A_arbace_spec_test_alpha__init_A_Unit6__O(); case 54: return A_arbace_spec_test_alpha__init_A_Unit7__O(); case 55: return A_arbace_spec_test_alpha__init_A_Unit8__O(); case 56: return A_arbace_spec_test_alpha__init_A_Unit9__O()}; return nil }

func A_arbace_spec_test_alpha__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha__init_A_New()}; return nil }

var A_arbace_spec_test_alpha__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_spec_test_alpha__init_A_invoke, New: A_arbace_spec_test_alpha__init_A_new}

var A_arbace_spec_test_alpha__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha__init_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha__init_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha__init_A_InstanceOf; i.Init = A_arbace_spec_test_alpha__init_A_Init; i.Table = A_arbace_spec_test_alpha__init_A_members; jrt.RegisterGoType(A_arbace_spec_test_alpha__init_A_class, reflect.TypeFor[A_arbace_spec_test_alpha__init_A]()) }
