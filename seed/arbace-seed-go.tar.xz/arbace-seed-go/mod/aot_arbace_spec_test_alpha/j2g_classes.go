//line j2g_classes.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_spec_test_alpha___GT_sym_A_class, Name: "arbace.spec.test.alpha$__GT_sym", Modifiers: 25, Simple: "__GT_sym", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha___GT_sym_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha___GT_var_A_class, Name: "arbace.spec.test.alpha$__GT_var", Modifiers: 25, Simple: "__GT_var", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha___GT_var_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_abbrev_result_A_class, Name: "arbace.spec.test.alpha$abbrev_result", Modifiers: 25, Simple: "abbrev_result", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_abbrev_result_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_build_fixed_args_body_A_class, Name: "arbace.spec.test.alpha$build_fixed_args_body", Modifiers: 25, Simple: "build_fixed_args_body", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_fixed_args_body_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_build_flattener_code_A_class, Name: "arbace.spec.test.alpha$build_flattener_code", Modifiers: 25, Simple: "build_flattener_code", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_flattener_code_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class, Name: "arbace.spec.test.alpha$build_flattener_code$fn__107000074", Modifiers: 25, Simple: "fn__107000074", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_build_flattener_code_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_build_kwargs_body_A_class, Name: "arbace.spec.test.alpha$build_kwargs_body", Modifiers: 25, Simple: "build_kwargs_body", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_kwargs_body_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_build_varargs_body_A_class, Name: "arbace.spec.test.alpha$build_varargs_body", Modifiers: 25, Simple: "build_varargs_body", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_build_varargs_body_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_check_A_class, Name: "arbace.spec.test.alpha$check", Modifiers: 25, Simple: "check", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_check_fn__107000127_A_class, Name: "arbace.spec.test.alpha$check$fn__107000127", Modifiers: 25, Simple: "fn__107000127", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_fn__107000127_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_check_1_A_class, Name: "arbace.spec.test.alpha$check_1", Modifiers: 25, Simple: "check_1", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_1_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_check_call_A_class, Name: "arbace.spec.test.alpha$check_call", Modifiers: 25, Simple: "check_call", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_call_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_check_fn_A_class, Name: "arbace.spec.test.alpha$check_fn", Modifiers: 25, Simple: "check_fn", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_check_fn_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_checkable_syms_A_class, Name: "arbace.spec.test.alpha$checkable_syms", Modifiers: 25, Simple: "checkable_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_checkable_syms_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_collectionize_A_class, Name: "arbace.spec.test.alpha$collectionize", Modifiers: 25, Simple: "collectionize", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_collectionize_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_enumerate_namespace_A_class, Name: "arbace.spec.test.alpha$enumerate_namespace", Modifiers: 25, Simple: "enumerate_namespace", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_enumerate_namespace_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class, Name: "arbace.spec.test.alpha$enumerate_namespace$fn__107000020", Modifiers: 25, Simple: "fn__107000020", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_enumerate_namespace_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class, Name: "arbace.spec.test.alpha$enumerate_namespace$fn__107000020$fn__107000021", Modifiers: 25, Simple: "fn__107000021", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class, Name: "arbace.spec.test.alpha$eval107000002$loading__1927001464__auto____107000003", Modifiers: 25, Simple: "loading__1927001464__auto____107000003", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_eval107000002_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class, Name: "arbace.spec.test.alpha$eval107000006$fn__107000007", Modifiers: 25, Simple: "fn__107000007", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000006_fn__107000007_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_eval107000006_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_explain_check_A_class, Name: "arbace.spec.test.alpha$explain_check", Modifiers: 25, Simple: "explain_check", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_explain_check_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_failure_type_A_class, Name: "arbace.spec.test.alpha$failure_type", Modifiers: 25, Simple: "failure_type", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_failure_type_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_find_varargs_decl_A_class, Name: "arbace.spec.test.alpha$find_varargs_decl", Modifiers: 25, Simple: "find_varargs_decl", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_find_varargs_decl_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_fn_spec_QMARK__A_class, Name: "arbace.spec.test.alpha$fn_spec_QMARK_", Modifiers: 25, Simple: "fn_spec_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_fn_spec_QMARK__A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class, Name: "arbace.spec.test.alpha$fn_spec_name_QMARK_", Modifiers: 25, Simple: "fn_spec_name_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_fn_spec_name_QMARK__A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class, Name: "arbace.spec.test.alpha$gen_fixed_args_syms", Modifiers: 25, Simple: "gen_fixed_args_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_gen_fixed_args_syms_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class, Name: "arbace.spec.test.alpha$gen_fixed_args_syms$fn__107000068", Modifiers: 25, Simple: "fn__107000068", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class, Name: "arbace.spec.test.alpha$has_kwargs_QMARK_", Modifiers: 25, Simple: "has_kwargs_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_has_kwargs_QMARK__A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_instrument_A_class, Name: "arbace.spec.test.alpha$instrument", Modifiers: 25, Simple: "instrument", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_instrument_fn__107000097_A_class, Name: "arbace.spec.test.alpha$instrument$fn__107000097", Modifiers: 25, Simple: "fn__107000097", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_fn__107000097_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_instrument_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_instrument_1_A_class, Name: "arbace.spec.test.alpha$instrument_1", Modifiers: 25, Simple: "instrument_1", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_1_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_instrument_choose_fn_A_class, Name: "arbace.spec.test.alpha$instrument_choose_fn", Modifiers: 25, Simple: "instrument_choose_fn", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_choose_fn_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF4_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_instrument_choose_spec_A_class, Name: "arbace.spec.test.alpha$instrument_choose_spec", Modifiers: 25, Simple: "instrument_choose_spec", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrument_choose_spec_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_instrumentable_syms_A_class, Name: "arbace.spec.test.alpha$instrumentable_syms", Modifiers: 25, Simple: "instrumentable_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_instrumentable_syms_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class, Name: "arbace.spec.test.alpha$interpret_stack_trace_element", Modifiers: 25, Simple: "interpret_stack_trace_element", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_interpret_stack_trace_element_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class, Name: "arbace.spec.test.alpha$interpret_stack_trace_element$degensym__107000043", Modifiers: 25, Simple: "degensym__107000043", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class, Name: "arbace.spec.test.alpha$interpret_stack_trace_element$demunge__107000041", Modifiers: 25, Simple: "demunge__107000041", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class, Name: "arbace.spec.test.alpha$kwargs__GT_kvs", Modifiers: 25, Simple: "kwargs__GT_kvs", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_kwargs__GT_kvs_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class, Name: "arbace.spec.test.alpha$kwargs__GT_kvs$fn__107000065", Modifiers: 25, Simple: "fn__107000065", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_make_check_result_A_class, Name: "arbace.spec.test.alpha$make_check_result", Modifiers: 25, Simple: "make_check_result", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_make_check_result_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class, Name: "arbace.spec.test.alpha$maybe_wrap_kvs_emulation", Modifiers: 25, Simple: "maybe_wrap_kvs_emulation", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_no_fspec_A_class, Name: "arbace.spec.test.alpha$no_fspec", Modifiers: 25, Simple: "no_fspec", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_no_fspec_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_opt_syms_A_class, Name: "arbace.spec.test.alpha$opt_syms", Modifiers: 25, Simple: "opt_syms", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_opt_syms_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_quick_check_A_class, Name: "arbace.spec.test.alpha$quick_check", Modifiers: 25, Simple: "quick_check", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_quick_check_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class, Name: "arbace.spec.test.alpha$quick_check$fn__107000111", Modifiers: 25, Simple: "fn__107000111", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_quick_check_fn__107000111_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_quick_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class, Name: "arbace.spec.test.alpha$quick_check$fn__107000113", Modifiers: 25, Simple: "fn__107000113", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_quick_check_fn__107000113_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_quick_check_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_result_type_A_class, Name: "arbace.spec.test.alpha$result_type", Modifiers: 25, Simple: "result_type", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_result_type_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_spec_checking_fn_A_class, Name: "arbace.spec.test.alpha$spec_checking_fn", Modifiers: 25, Simple: "spec_checking_fn", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_spec_checking_fn_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class, Name: "arbace.spec.test.alpha$spec_checking_fn$conform_BANG___107000052", Modifiers: 25, Simple: "conform_BANG___107000052", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_spec_checking_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF5_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class, Name: "arbace.spec.test.alpha$spec_checking_fn$fn__107000054", Modifiers: 25, Simple: "fn__107000054", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_spec_checking_fn_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class, Name: "arbace.spec.test.alpha$stacktrace_relevant_to_instrument", Modifiers: 25, Simple: "stacktrace_relevant_to_instrument", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class, Name: "arbace.spec.test.alpha$stacktrace_relevant_to_instrument$plumbing_QMARK___107000047", Modifiers: 25, Simple: "plumbing_QMARK___107000047", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_summarize_results_A_class, Name: "arbace.spec.test.alpha$summarize_results", Modifiers: 25, Simple: "summarize_results", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_summarize_results_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class, Name: "arbace.spec.test.alpha$summarize_results$fn__107000134", Modifiers: 25, Simple: "fn__107000134", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_summarize_results_fn__107000134_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_summarize_results_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_sym__GT_check_map_A_class, Name: "arbace.spec.test.alpha$sym__GT_check_map", Modifiers: 25, Simple: "sym__GT_check_map", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_sym__GT_check_map_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_throwable_QMARK__A_class, Name: "arbace.spec.test.alpha$throwable_QMARK_", Modifiers: 25, Simple: "throwable_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_throwable_QMARK__A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class, Name: "arbace.spec.test.alpha$thunk_frame_QMARK_", Modifiers: 25, Simple: "thunk_frame_QMARK_", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_thunk_frame_QMARK__A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_unstrument_A_class, Name: "arbace.spec.test.alpha$unstrument", Modifiers: 25, Simple: "unstrument", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_unstrument_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_unstrument_1_A_class, Name: "arbace.spec.test.alpha$unstrument_1", Modifiers: 25, Simple: "unstrument_1", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_unstrument_1_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_unwrap_failure_A_class, Name: "arbace.spec.test.alpha$unwrap_failure", Modifiers: 25, Simple: "unwrap_failure", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_unwrap_failure_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_validate_check_opts_A_class, Name: "arbace.spec.test.alpha$validate_check_opts", Modifiers: 25, Simple: "validate_check_opts", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_validate_check_opts_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_spec_test_alpha_with_instrument_disabled_A_class, Name: "arbace.spec.test.alpha$with_instrument_disabled", Modifiers: 25, Simple: "with_instrument_disabled", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_with_instrument_disabled_A", Source: "alpha.ae", Declaring: &A_arbace_spec_test_alpha_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_spec_test_alpha_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_A_New()}; return nil }

var A_arbace_spec_test_alpha_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_test_alpha_A_new}

var A_arbace_spec_test_alpha_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_A"})

func init() { i := A_arbace_spec_test_alpha_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_A_InstanceOf; i.Init = A_arbace_spec_test_alpha_A_Init; i.Table = A_arbace_spec_test_alpha_A_members }

var A_arbace_spec_test_alpha___GT_sym_A_class *jrt.Class

var A_arbace_spec_test_alpha___GT_var_A_class *jrt.Class

var A_arbace_spec_test_alpha_abbrev_result_A_class *jrt.Class

var A_arbace_spec_test_alpha_build_fixed_args_body_A_class *jrt.Class

var A_arbace_spec_test_alpha_build_flattener_code_A_class *jrt.Class

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class *jrt.Class

var A_arbace_spec_test_alpha_build_kwargs_body_A_class *jrt.Class

var A_arbace_spec_test_alpha_build_varargs_body_A_class *jrt.Class

var A_arbace_spec_test_alpha_check_A_class *jrt.Class

var A_arbace_spec_test_alpha_check_fn__107000127_A_class *jrt.Class

var A_arbace_spec_test_alpha_check_1_A_class *jrt.Class

var A_arbace_spec_test_alpha_check_call_A_class *jrt.Class

var A_arbace_spec_test_alpha_check_fn_A_class *jrt.Class

var A_arbace_spec_test_alpha_checkable_syms_A_class *jrt.Class

var A_arbace_spec_test_alpha_collectionize_A_class *jrt.Class

var A_arbace_spec_test_alpha_enumerate_namespace_A_class *jrt.Class

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class *jrt.Class

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class *jrt.Class

func A_arbace_spec_test_alpha_eval107000002_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_eval107000002_A_New()}; return nil }

var A_arbace_spec_test_alpha_eval107000002_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_test_alpha_eval107000002_A_new}

var A_arbace_spec_test_alpha_eval107000002_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$eval107000002", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "eval107000002", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000002_A"})

func init() { i := A_arbace_spec_test_alpha_eval107000002_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_eval107000002_A_InstanceOf; i.Table = A_arbace_spec_test_alpha_eval107000002_A_members }

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class *jrt.Class

func A_arbace_spec_test_alpha_eval107000006_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha_eval107000006_A_New()}; return nil }

var A_arbace_spec_test_alpha_eval107000006_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_spec_test_alpha_eval107000006_A_new}

var A_arbace_spec_test_alpha_eval107000006_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha$eval107000006", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_spec_test_alpha_A_class, Simple: "eval107000006", Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha_eval107000006_A"})

func init() { i := A_arbace_spec_test_alpha_eval107000006_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha_eval107000006_A_InstanceOf; i.Table = A_arbace_spec_test_alpha_eval107000006_A_members }

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class *jrt.Class

var A_arbace_spec_test_alpha_explain_check_A_class *jrt.Class

var A_arbace_spec_test_alpha_failure_type_A_class *jrt.Class

var A_arbace_spec_test_alpha_find_varargs_decl_A_class *jrt.Class

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_class *jrt.Class

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class *jrt.Class

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class *jrt.Class

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class *jrt.Class

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_A_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_1_A_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_choose_fn_A_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_choose_spec_A_class *jrt.Class

var A_arbace_spec_test_alpha_instrumentable_syms_A_class *jrt.Class

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class *jrt.Class

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class *jrt.Class

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class *jrt.Class

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class *jrt.Class

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class *jrt.Class

var A_arbace_spec_test_alpha_make_check_result_A_class *jrt.Class

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class *jrt.Class

var A_arbace_spec_test_alpha_no_fspec_A_class *jrt.Class

var A_arbace_spec_test_alpha_opt_syms_A_class *jrt.Class

var A_arbace_spec_test_alpha_quick_check_A_class *jrt.Class

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class *jrt.Class

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class *jrt.Class

var A_arbace_spec_test_alpha_result_type_A_class *jrt.Class

var A_arbace_spec_test_alpha_spec_checking_fn_A_class *jrt.Class

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class *jrt.Class

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class *jrt.Class

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class *jrt.Class

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class *jrt.Class

var A_arbace_spec_test_alpha_summarize_results_A_class *jrt.Class

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class *jrt.Class

var A_arbace_spec_test_alpha_sym__GT_check_map_A_class *jrt.Class

var A_arbace_spec_test_alpha_throwable_QMARK__A_class *jrt.Class

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class *jrt.Class

var A_arbace_spec_test_alpha_unstrument_A_class *jrt.Class

var A_arbace_spec_test_alpha_unstrument_1_A_class *jrt.Class

var A_arbace_spec_test_alpha_unwrap_failure_A_class *jrt.Class

var A_arbace_spec_test_alpha_validate_check_opts_A_class *jrt.Class

var A_arbace_spec_test_alpha_with_instrument_disabled_A_class *jrt.Class

func A_arbace_spec_test_alpha__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha__init_A_Load__O()}; return nil }

func A_arbace_spec_test_alpha__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_spec_test_alpha__init_A_New()}; return nil }

var A_arbace_spec_test_alpha__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_spec_test_alpha__init_A_invoke, New: A_arbace_spec_test_alpha__init_A_new}

var A_arbace_spec_test_alpha__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.spec.test.alpha__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_spec_test_alpha.A_arbace_spec_test_alpha__init_A", Source: "alpha.ae"})

func init() { i := A_arbace_spec_test_alpha__init_A_class.Info(); i.IsInstance = A_arbace_spec_test_alpha__init_A_InstanceOf; i.Init = A_arbace_spec_test_alpha__init_A_Init; i.Table = A_arbace_spec_test_alpha__init_A_members }
