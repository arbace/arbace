//line j2g_strings.ae:1
package aot_arbace_spec_test_alpha

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn7,excludeyn4,testyn13,arbace.pprintkn2,asyn2,ppyn17,arbace.spec.alphayn1,syn21,arbace.spec.gen.alphayn3,genyn13,arbace.stringyn3,stryn22,arbace.spec.test.alphakn4,argskn3,retys11,arbace.core7,bindingys22,arbace.spec.test.alpha20,*instrument-enabled*yn12,invokeStaticyn6,invokekn4,filekn4,linekn6,methodkn5,classkn9,var-scopekn8,local-fnkn6,thunk?ys22,arbace.spec.test.alpha16,spec-checking-fnys11,arbace.core5,applyks17,arbace.spec.alpha7,invalidks22,arbace.spec.test.alpha6,callerks17,arbace.spec.alpha2,fnks17,arbace.spec.alpha4,argsks17,arbace.spec.alpha7,failurekn10,instrumentkn3,varkn4,speckn8,no-fspecyn1,&ys11,arbace.core5,derefyn3,varys22,arbace.spec.test.alpha11,kwargs->kvsys11,arbace.core2,fnyn25,--KVS--EMULATION--THUNK--kn7,defaultyn4,argskn6,columnkn3,genkn4,stubkn7,replacekn5,macrokn3,rawkn7,wrappedkn8,arglistsyn6,every?yn6,ident?yn4,keysyn4,optsks22,arbace.spec.test.alpha4,argsks22,arbace.spec.test.alpha3,valkn12,check-failedkn2,fnks22,arbace.spec.test.check4,optskn9,num-testskn6,resultks22,arbace.spec.test.check3,retkn3,symkn7,failurekn6,shrunkkn1,skn1,fkn1,vyn4,speckn5,no-fnkn12,no-args-speckn12,check-passedkn11,check-threwkn5,totalv11,arbace.core7,requirev11,arbace.core5,referR0,R1,V1,R2,V3,R3,R4,R5,V3,R6,R4,R7,V3,R8,R4,R9,V3,R10,R4,R11,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjR12,v11,arbace.core13,*loaded-libs*v17,arbace.spec.alpha5,->symv11,arbace.core4,var?v11,arbace.core7,symbol?v11,arbace.core7,resolvev11,arbace.core6,pr-strv11,arbace.core4,listv11,arbace.core4,intov11,arbace.core6,mapcatv22,arbace.spec.test.alpha13,collectionizev11,arbace.core3,mapv11,arbace.core6,symbolv11,arbace.core4,namev11,arbace.core4,keysv11,arbace.core10,ns-internsR13,R14,v11,arbace.core3,seqv11,arbace.core6,concatR15,v11,arbace.core5,applyv11,arbace.core6,vectorR16,v13,arbace.string9,includes?v11,arbace.core9,contains?v13,arbace.string7,replacep4,--.*v11,arbace.core5,mergeS2,R17,R18,v13,arbace.string5,splitv11,arbace.core3,strp2,\\$l3,R19,R20,R21,R22,R23,R24,R25,v22,arbace.spec.test.alpha12,thunk-frame?v11,arbace.core4,nextv11,arbace.core8,to-arrayv11,arbace.core5,firstS2,R26,R27,v11,arbace.core8,sequencev11,arbace.core4,compv11,arbace.core6,filterv11,arbace.core10,drop-whilev11,arbace.core22,StackTraceElement->vecv22,arbace.spec.test.alpha29,interpret-stack-trace-elementv17,arbace.spec.alpha7,conformR28,v11,arbace.core7,ex-infov22,arbace.spec.test.alpha33,stacktrace-relevant-to-instrumentv11,arbace.core5,assocR29,v11,arbace.core6,dissocv17,arbace.spec.alpha13,explain-data*R30,R31,R32,R33,v22,arbace.spec.test.alpha20,*instrument-enabled*v11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv17,arbace.spec.alpha10,maybe-specR34,R35,R36,v11,arbace.core6,secondv11,arbace.core10,split-withv11,arbace.core10,complementS1,R37,v11,arbace.core4,map?v11,arbace.core4,somev22,arbace.spec.test.alpha17,find-varargs-declv11,arbace.core5,even?v11,arbace.core7,butlastv11,arbace.core9,reduce-kvv11,arbace.core4,consv11,arbace.core4,lastv11,arbace.core3,vecv11,arbace.core6,gensymv11,arbace.core10,take-whileS1,R37,v22,arbace.spec.test.alpha19,gen-fixed-args-symsR37,R27,R38,R39,R40,R37,R27,R41,R41,R42,v22,arbace.spec.test.alpha17,build-kwargs-bodyv22,arbace.spec.test.alpha18,build-varargs-bodyR43,v22,arbace.spec.test.alpha21,build-fixed-args-bodyML1,V2,R37,R44,m4,R20,i237,R45,i22,v22,arbace.spec.test.alpha11,has-kwargs?v22,arbace.spec.test.alpha20,build-flattener-codev11,arbace.core4,evalR46,R47,R48,v21,arbace.spec.gen.alpha8,generatev17,arbace.spec.alpha3,genR49,v17,arbace.spec.alpha8,get-specR50,R51,v22,arbace.spec.test.alpha22,instrument-choose-specv22,arbace.spec.test.alpha8,no-fspecv22,arbace.spec.test.alpha20,instrument-choose-fnv22,arbace.spec.test.alpha16,spec-checking-fnv22,arbace.spec.test.alpha24,maybe-wrap-kvs-emulationv22,arbace.spec.test.alpha5,->symv22,arbace.spec.test.alpha17,instrumented-varsv11,arbace.core7,sort-byv11,arbace.core5,countR52,v11,arbace.core14,alter-var-rootv11,arbace.core5,swap!v11,arbace.core10,constantlyv11,arbace.core6,reducev11,arbace.core3,notv11,arbace.core6,every?v11,arbace.core6,ident?ML3,R53,R54,ML2,R55,ML2,R46,R56,m4,R20,i321,R45,i35,m4,R20,i321,R45,i29,m4,R20,i321,R45,i14,v22,arbace.spec.test.alpha13,fn-spec-name?v17,arbace.spec.alpha8,registryv22,arbace.spec.test.alpha19,instrumentable-symsv11,arbace.core8,distinctv11,arbace.core6,removev22,arbace.spec.test.alpha12,instrument-1v11,arbace.core4,nil?v22,arbace.spec.test.alpha10,instrumentv22,arbace.spec.test.alpha12,unstrument-1v22,arbace.spec.test.alpha10,unstrumentv17,arbace.spec.alpha6,valid?R57,R58,R59,v22,arbace.spec.test.alpha13,explain-checkR60,R61,R62,v22,arbace.spec.test.alpha10,throwable?R63,v21,arbace.spec.gen.alpha8,for-all*v22,arbace.spec.test.alpha10,check-callv21,arbace.spec.gen.alpha11,quick-checkv11,arbace.core8,identityR64,R65,v11,arbace.core5,true?R66,R67,R68,R69,R70,v17,arbace.spec.alpha9,spec-implv22,arbace.spec.test.alpha11,quick-checkv22,arbace.spec.test.alpha17,make-check-resultR71,m2,R32,R72,m2,R32,R73,ML3,R53,R54,ML2,R55,ML2,R46,R56,m4,R20,i470,R45,i32,m4,R20,i470,R45,i26,m4,R20,i470,R45,i11,v22,arbace.spec.test.alpha7,check-1v22,arbace.spec.test.alpha19,validate-check-optsv22,arbace.spec.test.alpha8,check-fnv22,arbace.spec.test.alpha14,checkable-symsv11,arbace.core4,pmapv22,arbace.spec.test.alpha14,sym->check-mapv22,arbace.spec.test.alpha5,checkv11,arbace.core7,ex-datav22,arbace.spec.test.alpha12,failure-typeR74,R75,v11,arbace.core6,updatev22,arbace.spec.test.alpha14,unwrap-failurev17,arbace.spec.alpha8,describev13,arbace.pprint6,pprintv22,arbace.spec.test.alpha11,result-typev11,arbace.core4,fnilR76,v11,arbace.core3,incl0,m2,R76,l0,v22,arbace.spec.test.alpha17,summarize-resultsv22,arbace.spec.test.alpha13,abbrev-result")

var Lit_1 *jrt.String = jrt.Intern(" does not name a var")

var Lit_2 *jrt.String = jrt.Intern("inner")

var Lit_3 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_flattener_code$fn__107000074")

var Lit_4 *jrt.String = jrt.Intern("kwargs")

var Lit_5 *jrt.String = jrt.Intern("restargs")

var Lit_6 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check$fn__107000127")

var Lit_7 *jrt.String = jrt.Intern("No fn to spec")

var Lit_8 *jrt.String = jrt.Intern("No :args spec")

var Lit_9 *jrt.String = jrt.Intern("arbace.spec.test.alpha$enumerate_namespace$fn__107000020")

var Lit_10 *jrt.String = jrt.Intern("arbace.spec.test.alpha$enumerate_namespace$fn__107000020$fn__107000021")

var Lit_11 *jrt.String = jrt.Intern("Specification-based check failed")

var Lit_12 *jrt.String = jrt.Intern("arbace.spec.test.alpha$gen_fixed_args_syms$fn__107000068")

var Lit_13 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument$fn__107000097")

var Lit_14 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_15 *jrt.String = jrt.Intern("instrument :gen expects ident keys")

var Lit_16 *jrt.String = jrt.Intern("\n")

var Lit_17 *jrt.String = jrt.Intern("arbace.spec.test.alpha$interpret_stack_trace_element$demunge__107000041")

var Lit_18 *jrt.String = jrt.Intern("arbace.spec.test.alpha$interpret_stack_trace_element$degensym__107000043")

var Lit_19 *jrt.String = jrt.Intern("")

var Lit_20 *jrt.String = jrt.Intern("arbace.spec.test.alpha$kwargs__GT_kvs$fn__107000065")

var Lit_21 *jrt.String = jrt.Intern("Fn at ")

var Lit_22 *jrt.String = jrt.Intern(" is not spec'ed.")

var Lit_23 *jrt.String = jrt.Intern("arbace.spec.test.alpha$quick_check$fn__107000111")

var Lit_24 *jrt.String = jrt.Intern("arbace.spec.test.alpha$quick_check$fn__107000113")

var Lit_25 *jrt.String = jrt.Intern("arbace.spec.test.alpha$spec_checking_fn$conform_BANG___107000052")

var Lit_26 *jrt.String = jrt.Intern("arbace.spec.test.alpha$spec_checking_fn$fn__107000054")

var Lit_27 *jrt.String = jrt.Intern("Call to ")

var Lit_28 *jrt.String = jrt.Intern(" did not conform to spec.")

var Lit_29 *jrt.String = jrt.Intern("arbace.spec.test.alpha$stacktrace_relevant_to_instrument$plumbing_QMARK___107000047")

var Lit_30 *jrt.String = jrt.Intern("arbace.spec.test.alpha$summarize_results$fn__107000134")

var Lit_31 *jrt.String = jrt.Intern("--KVS--EMULATION--THUNK--")

var Lit_32 *jrt.String = jrt.Intern("check :gen expects ident keys")

var Lit_33 *jrt.String = jrt.Intern("yn22,arbace.spec.test.alphayn11,arbace.coreyn22,arbace.spec.test.checkyn3,stckn7,privatekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn6,s-or-vyn14,ns-sym-or-symskn3,dockn7,dynamicyn1,myn1,&yn4,bodyyn1,syn3,clsyn6,methodyn4,fileyn4,lineyn5,elemsyn7,fn-nameyn1,fyn7,fn-specyn1,vyn4,specyn7,arglistyn8,arglistsyn4,argsyn3,symyn4,overkn3,genkn4,keysyn4,stubyn7,replaceyn9,overrideskn4,specyn4,optsyn11,sym-or-symsyn4,roleyn5,specsyn3,genks22,arbace.spec.test.check4,optsyn9,check-symyn14,test-check-retyn3,retyn13,check-resultsyn14,summary-resultv11,arbace.core5,in-nsR0,R1,R2,R0,v11,arbace.core5,aliasR3,R2,v22,arbace.spec.test.alpha10,throwable?m10,R4,TR5,L1,V1,R6,R7,i25,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha5,->symm8,R5,L1,V1,R6,R7,i29,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha5,->varm10,R4,TR5,L1,V1,R10,R7,i33,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha13,collectionizem10,R4,TR5,L1,V1,R6,R7,i42,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha19,enumerate-namespacem10,R5,L1,V1,R11,R12,s119,Given a symbol naming an ns, or a collection of such symbols,\nreturns the set of all symbols naming vars in those nses.R7,i48,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha20,*instrument-enabled*m12,R13,TR4,TR7,i63,R8,i1,R9,s25,arbace/spec/test/alpha.aeR12,s48,if false, instrumented fns call straight throughv22,arbace.spec.test.alpha8,fn-spec?m12,R4,TR5,L1,V1,R14,R12,s50,Fn-spec must include at least :args or :ret specs.R7,i67,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha24,with-instrument-disabledm10,R5,L1,V2,R15,R16,R12,s56,Disables instrument's checking of calls, within a scope.R7,i72,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha12,thunk-frame?m10,R4,TR5,L1,V1,R17,R7,i78,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha29,interpret-stack-trace-elementm12,R4,TR5,L1,V1,V4,R18,R19,R20,R21,R12,s552,Given the vector-of-syms form of a stacktrace element produced\nby e.g. Throwable->map, returns a map form that adds some keys\nguessing the original Clojure names. Returns a map with\n\n  :class         class name symbol from stack trace\n  :method        method symbol from stack trace\n  :file          filename from stack trace\n  :line          line number from stack trace\n  :var-scope     optional Clojure var symbol scoping fn def\n  :local-fn      optional local Clojure symbol scoping fn def\n\nFor non-Clojure fns, :scope and :local-fn will be absent.R7,i81,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha33,stacktrace-relevant-to-instrumentm12,R4,TR5,L1,V1,R22,R12,s186,Takes a coll of stack trace elements (as returned by\nStackTraceElement->vec) and returns a coll of maps as per\ninterpret-stack-trace-element that are relevant to a\nfailure in instrument.R7,i111,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha16,spec-checking-fnm12,R4,TR5,L1,V3,R23,R24,R25,R12,s258,Takes a function name, a function f, and an fspec and returns a thunk that\n  first conforms the arguments given then calls f with those arguments if\n  the conform succeeds. Otherwise, an exception is thrown containing information\n  about the conform failure.R7,i128,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha8,no-fspecm10,R4,TR5,L1,V2,R26,R27,R7,i160,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha17,instrumented-varsm8,R4,TR7,i165,R8,i1,R9,s25,arbace/spec/test/alpha.aev11,arbace.core4,atomm8,R4,TR7,i165,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha17,find-varargs-declm12,R4,TR5,L1,V1,R28,R12,s74,Takes an arglist and returns the restargs binding form if found, else nil.R7,i167,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha11,has-kwargs?m10,R4,TR5,L1,V1,R29,R7,i176,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha11,kwargs->kvsm12,R4,TR5,L1,V1,R30,R12,s202,Takes the restargs of a kwargs function call and checks for a trailing element.\n  If found, that element is flattened into a sequence of key->value pairs and\n  concatenated onto the preceding arguments.R7,i179,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha19,gen-fixed-args-symsm12,R4,TR5,L1,V1,R28,R12,s89,Takes an arglist and generates a vector of names corresponding to the fixed\n  args found.R7,i191,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha17,build-kwargs-bodym12,R4,TR5,L1,V2,R23,R28,R12,s193,Takes a function name fn-name and arglist and returns code for a function body that\n  handles kwargs by calling fn-name with any fixed followed by its restargs transformed\n  from kwargs to kvs.R7,i197,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha18,build-varargs-bodym12,R4,TR5,L1,V2,R23,R28,R12,s167,Takes a function name fn-name and arglist and returns code for a function body that\n  handles varargs by calling fn-name with any fixed args followed by its rest args.R7,i207,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha21,build-fixed-args-bodym12,R4,TR5,L1,V2,R23,R28,R12,s144,Takes a function name fn-name and arglist and returns code for a function body that\n  handles fixed args by calling fn-name with its fixed args.R7,i216,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha20,build-flattener-codem12,R4,TR5,L1,V1,R29,R12,s187,Takes argslists and generates code for a HOF that given a function, returns a forwarding thunk\n  of analogous arglists that ensures that kwargs are passed as kvs to the original function.R7,i224,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha24,maybe-wrap-kvs-emulationm12,R4,TR5,L1,V2,R24,R29,R12,s204,Takes an argslist and function f and returns f except when arglists\n  contains a kwargs binding, else wraps f with a forwarding thunk that\n  flattens a trailing map into kvs if present in the kwargs call.R7,i255,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha20,instrument-choose-fnm12,R4,TR5,L1,V4,R24,R27,R31,m4,R32,R33,R34,V2,R35,R36,R12,s22,Helper for instrument.R7,i266,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha22,instrument-choose-specm12,R4,TR5,L1,V3,R27,R31,m2,R37,R38,R12,s21,Helper for instrumentR7,i273,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha12,instrument-1m10,R4,TR5,L1,V2,R17,R39,R7,i278,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha12,unstrument-1m10,R4,TR5,L1,V1,R17,R7,i296,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha8,opt-symsm12,R4,TR5,L1,V1,R39,R12,s58,Returns set of symbols referenced by 'instrument' opts mapR7,i306,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha13,fn-spec-name?m10,R4,TR5,L1,V1,R17,R7,i311,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha19,instrumentable-symsm10,R5,L2,V0,V1,R39,R12,s86,Given an opts map as per instrument, returns the set of syms\nthat can be instrumented.R7,i316,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha10,instrumentm10,R5,L3,V0,V1,R40,V2,R40,R39,R12,s1458,Instruments the vars named by sym-or-syms, a symbol or collection\nof symbols, or all instrumentable vars if sym-or-syms is not\nspecified.\n\nIf a var has an :args fn-spec, sets the var's root binding to a\nfn that checks arg conformance (throwing an exception on failure)\nbefore delegating to the original fn.\n\nThe opts map can be used to override registered specs, and/or to\nreplace fn implementations entirely. Opts for symbols not included\nin sym-or-syms are ignored. This facilitates sharing a common\noptions map across many different calls to instrument.\n\nThe opts map may have the following keys:\n\n  :spec     a map from var-name symbols to override specs\n  :stub     a set of var-name symbols to be replaced by stubs\n  :gen      a map from spec names to generator overrides\n  :replace  a map from var-name symbols to replacement fns\n\n:spec overrides registered fn-specs with specs your provide. Use\n:spec overrides to provide specs for libraries that do not have\nthem, or to constrain your own use of a fn to a subset of its\nspec'ed contract.\n\n:stub replaces a fn with a stub that checks :args, then uses the\n:ret spec to generate a return value.\n\n:gen overrides are used only for :stub generation.\n\n:replace replaces a fn with a fn that checks args conformance, then\ninvokes the fn you provide, enabling arbitrary stubbing and mocking.\n\n:spec can be used in combination with :stub or :replace.\n\nReturns a collection of syms naming the vars instrumented.R7,i327,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha10,unstrumentm10,R5,L2,V0,V1,R40,R12,s187,Undoes instrument on the vars named by sym-or-syms, specified\nas in instrument. With no args, unstruments all instrumented vars.\nReturns a collection of syms naming the vars unstrumented.R7,i376,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha13,explain-checkm10,R4,TR5,L1,V4,R30,R27,R26,R41,R7,i392,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha10,check-callm12,R4,TR5,L1,V3,R24,R42,R30,R12,s100,Returns true if call passes specs, otherwise *returns* an exception\nwith explain-data + ::s/failure.R7,i402,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha11,quick-checkm10,R4,TR5,L1,V3,R24,R42,m4,R43,R33,R39,R44,R7,i419,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha17,make-check-resultm12,R4,TR5,L1,V3,R45,R27,R46,R12,s23,Builds spec result map.R7,i428,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha7,check-1m10,R4,TR5,L1,V2,m2,R34,V4,R17,R24,R26,R27,R39,R7,i440,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha14,sym->check-mapm10,R4,TR5,L1,V1,R17,R7,i461,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha19,validate-check-optsm10,R4,TR5,L1,V1,R39,R7,i468,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha8,check-fnm10,R5,L2,V2,R24,R27,V3,R24,R27,R39,R12,s87,Runs generative tests for fn f using spec and opts. See\n'check' for options and return.R7,i472,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha14,checkable-symsm10,R5,L2,V0,V1,R39,R12,s76,Given an opts map as per check, returns the set of syms that\ncan be checked.R7,i480,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha5,checkm10,R5,L3,V0,V1,R40,V2,R40,R39,R12,s1157,Run generative tests for spec conformance on vars named by\nsym-or-syms, a symbol or collection of symbols. If sym-or-syms\nis not specified, check all checkable vars.\n\nThe opts map includes the following optional keys, where stc\naliases arbace.spec.test.check: \n\n::stc/opts  opts to flow through test.check/quick-check\n:gen        map from spec names to generator overrides\n\nThe ::stc/opts include :num-tests in addition to the keys\ndocumented by test.check. Generator overrides are passed to\nspec/gen when generating function args.\n\nReturns a lazy sequence of check result maps with the following\nkeys\n\n:spec       the spec tested\n:sym        optional symbol naming the var tested\n:failure    optional test failure\n::stc/ret   optional value returned by test.check/quick-check\n\nThe value for :failure can be any exception. Exceptions thrown by\nspec itself will have an ::s/failure value in ex-data:\n\n:check-failed   at least one checked return did not conform\n:no-args-spec   no :args spec provided\n:no-fn          no fn provided\n:no-fspec       no fspec provided\n:no-gen         unable to generate :args\n:instrument     invalid args detected by instrument\nR7,i489,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha12,failure-typem10,R4,TR5,L1,V1,R6,R7,i532,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha14,unwrap-failurem10,R4,TR5,L1,V1,R6,R7,i536,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha11,result-typem12,R4,TR5,L1,V1,R47,R12,s208,Returns the type of the check result. This can be any of the\n::s/failure keywords documented in 'check', or:\n\n  :check-passed   all checked fn returns conformed\n  :check-threw    checked fn threw an exceptionR7,i542,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha13,abbrev-resultm10,R5,L1,V1,R6,R12,s78,Given a check result, returns an abbreviated version\nsuitable for summary use.R7,i555,R8,i1,R9,s25,arbace/spec/test/alpha.aev22,arbace.spec.test.alpha17,summarize-resultsm10,R5,L2,V1,R48,V2,R48,R49,R12,s238,Given a collection of check-results, e.g. from 'check', pretty\nprints the summary-result (default abbrev-result) of each.\n\nReturns a map with :total, the total number of results, plus a\nkey with a count for each different :type of result.R7,i565,R8,i1,R9,s25,arbace/spec/test/alpha.ae")

var Lit_34 *jrt.String = jrt.Intern("arbace.spec.test.alpha$eval107000002$loading__1927001464__auto____107000003")

var Lit_35 *jrt.String = jrt.Intern("arbace.spec.test.alpha$eval107000006$fn__107000007")

var Lit_36 *jrt.String = jrt.Intern("arbace.spec.test.alpha$throwable_QMARK_")

var Lit_37 *jrt.String = jrt.Intern("arbace.spec.test.alpha$__GT_sym")

var Lit_38 *jrt.String = jrt.Intern("arbace.spec.test.alpha$__GT_var")

var Lit_39 *jrt.String = jrt.Intern("arbace.spec.test.alpha$collectionize")

var Lit_40 *jrt.String = jrt.Intern("arbace.spec.test.alpha$enumerate_namespace")

var Lit_41 *jrt.String = jrt.Intern("arbace.spec.test.alpha$fn_spec_QMARK_")

var Lit_42 *jrt.String = jrt.Intern("arbace.spec.test.alpha$with_instrument_disabled")

var Lit_43 *jrt.String = jrt.Intern("arbace.spec.test.alpha$thunk_frame_QMARK_")

var Lit_44 *jrt.String = jrt.Intern("arbace.spec.test.alpha$interpret_stack_trace_element")

var Lit_45 *jrt.String = jrt.Intern("arbace.spec.test.alpha$stacktrace_relevant_to_instrument")

var Lit_46 *jrt.String = jrt.Intern("arbace.spec.test.alpha$spec_checking_fn")

var Lit_47 *jrt.String = jrt.Intern("arbace.spec.test.alpha$no_fspec")

var Lit_48 *jrt.String = jrt.Intern("arbace.spec.test.alpha$find_varargs_decl")

var Lit_49 *jrt.String = jrt.Intern("arbace.spec.test.alpha$has_kwargs_QMARK_")

var Lit_50 *jrt.String = jrt.Intern("arbace.spec.test.alpha$kwargs__GT_kvs")

var Lit_51 *jrt.String = jrt.Intern("arbace.spec.test.alpha$gen_fixed_args_syms")

var Lit_52 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_kwargs_body")

var Lit_53 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_varargs_body")

var Lit_54 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_fixed_args_body")

var Lit_55 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_flattener_code")

var Lit_56 *jrt.String = jrt.Intern("arbace.spec.test.alpha$maybe_wrap_kvs_emulation")

var Lit_57 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument_choose_fn")

var Lit_58 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument_choose_spec")

var Lit_59 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument_1")

var Lit_60 *jrt.String = jrt.Intern("arbace.spec.test.alpha$unstrument_1")

var Lit_61 *jrt.String = jrt.Intern("arbace.spec.test.alpha$opt_syms")

var Lit_62 *jrt.String = jrt.Intern("arbace.spec.test.alpha$fn_spec_name_QMARK_")

var Lit_63 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrumentable_syms")

var Lit_64 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument")

var Lit_65 *jrt.String = jrt.Intern("arbace.spec.test.alpha$unstrument")

var Lit_66 *jrt.String = jrt.Intern("arbace.spec.test.alpha$explain_check")

var Lit_67 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check_call")

var Lit_68 *jrt.String = jrt.Intern("arbace.spec.test.alpha$quick_check")

var Lit_69 *jrt.String = jrt.Intern("arbace.spec.test.alpha$make_check_result")

var Lit_70 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check_1")

var Lit_71 *jrt.String = jrt.Intern("arbace.spec.test.alpha$sym__GT_check_map")

var Lit_72 *jrt.String = jrt.Intern("arbace.spec.test.alpha$validate_check_opts")

var Lit_73 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check_fn")

var Lit_74 *jrt.String = jrt.Intern("arbace.spec.test.alpha$checkable_syms")

var Lit_75 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check")

var Lit_76 *jrt.String = jrt.Intern("arbace.spec.test.alpha$failure_type")

var Lit_77 *jrt.String = jrt.Intern("arbace.spec.test.alpha$unwrap_failure")

var Lit_78 *jrt.String = jrt.Intern("arbace.spec.test.alpha$result_type")

var Lit_79 *jrt.String = jrt.Intern("arbace.spec.test.alpha$abbrev_result")

var Lit_80 *jrt.String = jrt.Intern("arbace.spec.test.alpha$summarize_results")
