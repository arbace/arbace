//line a2g_strings.ae:1
package aot_arbace_spec_test_alpha

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("exclude")

var Lit_4 *jrt.String = jrt.Intern("test")

var Lit_5 *jrt.String = jrt.Intern("arbace.pprint")

var Lit_6 *jrt.String = jrt.Intern("as")

var Lit_7 *jrt.String = jrt.Intern("pp")

var Lit_8 *jrt.String = jrt.Intern("arbace.spec.alpha")

var Lit_9 *jrt.String = jrt.Intern("s")

var Lit_10 *jrt.String = jrt.Intern("arbace.spec.gen.alpha")

var Lit_11 *jrt.String = jrt.Intern("gen")

var Lit_12 *jrt.String = jrt.Intern("arbace.string")

var Lit_13 *jrt.String = jrt.Intern("str")

var Lit_14 *jrt.String = jrt.Intern("commute")

var Lit_15 *jrt.String = jrt.Intern("deref")

var Lit_16 *jrt.String = jrt.Intern("conj")

var Lit_17 *jrt.String = jrt.Intern("arbace.spec.test.alpha")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("->sym")

var Lit_20 *jrt.String = jrt.Intern("var?")

var Lit_21 *jrt.String = jrt.Intern("symbol?")

var Lit_22 *jrt.String = jrt.Intern("resolve")

var Lit_23 *jrt.String = jrt.Intern("pr-str")

var Lit_24 *jrt.String = jrt.Intern("list")

var Lit_25 *jrt.String = jrt.Intern("into")

var Lit_26 *jrt.String = jrt.Intern("mapcat")

var Lit_27 *jrt.String = jrt.Intern("collectionize")

var Lit_28 *jrt.String = jrt.Intern("map")

var Lit_29 *jrt.String = jrt.Intern("symbol")

var Lit_30 *jrt.String = jrt.Intern("name")

var Lit_31 *jrt.String = jrt.Intern("keys")

var Lit_32 *jrt.String = jrt.Intern("ns-interns")

var Lit_33 *jrt.String = jrt.Intern("args")

var Lit_34 *jrt.String = jrt.Intern("ret")

var Lit_35 *jrt.String = jrt.Intern("seq")

var Lit_36 *jrt.String = jrt.Intern("concat")

var Lit_37 *jrt.String = jrt.Intern("binding")

var Lit_38 *jrt.String = jrt.Intern("apply")

var Lit_39 *jrt.String = jrt.Intern("vector")

var Lit_40 *jrt.String = jrt.Intern("*instrument-enabled*")

var Lit_41 *jrt.String = jrt.Intern("includes?")

var Lit_42 *jrt.String = jrt.Intern("contains?")

var Lit_43 *jrt.String = jrt.Intern("replace")

var Lit_44 *jrt.String = jrt.Intern("--.*")

var Lit_45 *jrt.String = jrt.Intern("merge")

var Lit_46 *jrt.String = jrt.Intern("invokeStatic")

var Lit_47 *jrt.String = jrt.Intern("invoke")

var Lit_48 *jrt.String = jrt.Intern("split")

var Lit_49 *jrt.String = jrt.Intern("\\$")

var Lit_50 *jrt.String = jrt.Intern("file")

var Lit_51 *jrt.String = jrt.Intern("line")

var Lit_52 *jrt.String = jrt.Intern("method")

var Lit_53 *jrt.String = jrt.Intern("class")

var Lit_54 *jrt.String = jrt.Intern("var-scope")

var Lit_55 *jrt.String = jrt.Intern("local-fn")

var Lit_56 *jrt.String = jrt.Intern("thunk?")

var Lit_57 *jrt.String = jrt.Intern("thunk-frame?")

var Lit_58 *jrt.String = jrt.Intern("next")

var Lit_59 *jrt.String = jrt.Intern("to-array")

var Lit_60 *jrt.String = jrt.Intern("first")

var Lit_61 *jrt.String = jrt.Intern("spec-checking-fn")

var Lit_62 *jrt.String = jrt.Intern("sequence")

var Lit_63 *jrt.String = jrt.Intern("comp")

var Lit_64 *jrt.String = jrt.Intern("filter")

var Lit_65 *jrt.String = jrt.Intern("drop-while")

var Lit_66 *jrt.String = jrt.Intern("StackTraceElement->vec")

var Lit_67 *jrt.String = jrt.Intern("interpret-stack-trace-element")

var Lit_68 *jrt.String = jrt.Intern("conform")

var Lit_69 *jrt.String = jrt.Intern("invalid")

var Lit_70 *jrt.String = jrt.Intern("ex-info")

var Lit_71 *jrt.String = jrt.Intern("stacktrace-relevant-to-instrument")

var Lit_72 *jrt.String = jrt.Intern("assoc")

var Lit_73 *jrt.String = jrt.Intern("caller")

var Lit_74 *jrt.String = jrt.Intern("dissoc")

var Lit_75 *jrt.String = jrt.Intern("explain-data*")

var Lit_76 *jrt.String = jrt.Intern("fn")

var Lit_77 *jrt.String = jrt.Intern("failure")

var Lit_78 *jrt.String = jrt.Intern("instrument")

var Lit_79 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_80 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_81 *jrt.String = jrt.Intern("hash-map")

var Lit_82 *jrt.String = jrt.Intern("maybe-spec")

var Lit_83 *jrt.String = jrt.Intern("var")

var Lit_84 *jrt.String = jrt.Intern("spec")

var Lit_85 *jrt.String = jrt.Intern("no-fspec")

var Lit_86 *jrt.String = jrt.Intern("second")

var Lit_87 *jrt.String = jrt.Intern("split-with")

var Lit_88 *jrt.String = jrt.Intern("complement")

var Lit_89 *jrt.String = jrt.Intern("&")

var Lit_90 *jrt.String = jrt.Intern("map?")

var Lit_91 *jrt.String = jrt.Intern("some")

var Lit_92 *jrt.String = jrt.Intern("find-varargs-decl")

var Lit_93 *jrt.String = jrt.Intern("even?")

var Lit_94 *jrt.String = jrt.Intern("butlast")

var Lit_95 *jrt.String = jrt.Intern("reduce-kv")

var Lit_96 *jrt.String = jrt.Intern("cons")

var Lit_97 *jrt.String = jrt.Intern("last")

var Lit_98 *jrt.String = jrt.Intern("vec")

var Lit_99 *jrt.String = jrt.Intern("gensym")

var Lit_100 *jrt.String = jrt.Intern("take-while")

var Lit_101 *jrt.String = jrt.Intern("gen-fixed-args-syms")

var Lit_102 *jrt.String = jrt.Intern("kwargs->kvs")

var Lit_103 *jrt.String = jrt.Intern("--KVS--EMULATION--THUNK--")

var Lit_104 *jrt.String = jrt.Intern("build-kwargs-body")

var Lit_105 *jrt.String = jrt.Intern("build-varargs-body")

var Lit_106 *jrt.String = jrt.Intern("default")

var Lit_107 *jrt.String = jrt.Intern("build-fixed-args-body")

var Lit_108 *jrt.String = jrt.Intern("column")

var Lit_109 *jrt.String = jrt.Intern("has-kwargs?")

var Lit_110 *jrt.String = jrt.Intern("build-flattener-code")

var Lit_111 *jrt.String = jrt.Intern("eval")

var Lit_112 *jrt.String = jrt.Intern("stub")

var Lit_113 *jrt.String = jrt.Intern("generate")

var Lit_114 *jrt.String = jrt.Intern("macro")

var Lit_115 *jrt.String = jrt.Intern("get-spec")

var Lit_116 *jrt.String = jrt.Intern("raw")

var Lit_117 *jrt.String = jrt.Intern("wrapped")

var Lit_118 *jrt.String = jrt.Intern("instrument-choose-spec")

var Lit_119 *jrt.String = jrt.Intern("instrument-choose-fn")

var Lit_120 *jrt.String = jrt.Intern("maybe-wrap-kvs-emulation")

var Lit_121 *jrt.String = jrt.Intern("instrumented-vars")

var Lit_122 *jrt.String = jrt.Intern("sort-by")

var Lit_123 *jrt.String = jrt.Intern("count")

var Lit_124 *jrt.String = jrt.Intern("arglists")

var Lit_125 *jrt.String = jrt.Intern("alter-var-root")

var Lit_126 *jrt.String = jrt.Intern("swap!")

var Lit_127 *jrt.String = jrt.Intern("constantly")

var Lit_128 *jrt.String = jrt.Intern("reduce")

var Lit_129 *jrt.String = jrt.Intern("not")

var Lit_130 *jrt.String = jrt.Intern("every?")

var Lit_131 *jrt.String = jrt.Intern("ident?")

var Lit_132 *jrt.String = jrt.Intern("opts")

var Lit_133 *jrt.String = jrt.Intern("fn-spec-name?")

var Lit_134 *jrt.String = jrt.Intern("registry")

var Lit_135 *jrt.String = jrt.Intern("instrumentable-syms")

var Lit_136 *jrt.String = jrt.Intern("distinct")

var Lit_137 *jrt.String = jrt.Intern("remove")

var Lit_138 *jrt.String = jrt.Intern("instrument-1")

var Lit_139 *jrt.String = jrt.Intern("nil?")

var Lit_140 *jrt.String = jrt.Intern("unstrument-1")

var Lit_141 *jrt.String = jrt.Intern("unstrument")

var Lit_142 *jrt.String = jrt.Intern("valid?")

var Lit_143 *jrt.String = jrt.Intern("val")

var Lit_144 *jrt.String = jrt.Intern("check-failed")

var Lit_145 *jrt.String = jrt.Intern("explain-check")

var Lit_146 *jrt.String = jrt.Intern("arbace.spec.test.check")

var Lit_147 *jrt.String = jrt.Intern("num-tests")

var Lit_148 *jrt.String = jrt.Intern("throwable?")

var Lit_149 *jrt.String = jrt.Intern("result")

var Lit_150 *jrt.String = jrt.Intern("for-all*")

var Lit_151 *jrt.String = jrt.Intern("check-call")

var Lit_152 *jrt.String = jrt.Intern("quick-check")

var Lit_153 *jrt.String = jrt.Intern("identity")

var Lit_154 *jrt.String = jrt.Intern("sym")

var Lit_155 *jrt.String = jrt.Intern("true?")

var Lit_156 *jrt.String = jrt.Intern("shrunk")

var Lit_157 *jrt.String = jrt.Intern("f")

var Lit_158 *jrt.String = jrt.Intern("v")

var Lit_159 *jrt.String = jrt.Intern("spec-impl")

var Lit_160 *jrt.String = jrt.Intern("make-check-result")

var Lit_161 *jrt.String = jrt.Intern("no-fn")

var Lit_162 *jrt.String = jrt.Intern("no-args-spec")

var Lit_163 *jrt.String = jrt.Intern("check-1")

var Lit_164 *jrt.String = jrt.Intern("validate-check-opts")

var Lit_165 *jrt.String = jrt.Intern("check-fn")

var Lit_166 *jrt.String = jrt.Intern("checkable-syms")

var Lit_167 *jrt.String = jrt.Intern("pmap")

var Lit_168 *jrt.String = jrt.Intern("sym->check-map")

var Lit_169 *jrt.String = jrt.Intern("check")

var Lit_170 *jrt.String = jrt.Intern("ex-data")

var Lit_171 *jrt.String = jrt.Intern("failure-type")

var Lit_172 *jrt.String = jrt.Intern("check-passed")

var Lit_173 *jrt.String = jrt.Intern("check-threw")

var Lit_174 *jrt.String = jrt.Intern("update")

var Lit_175 *jrt.String = jrt.Intern("unwrap-failure")

var Lit_176 *jrt.String = jrt.Intern("describe")

var Lit_177 *jrt.String = jrt.Intern("pprint")

var Lit_178 *jrt.String = jrt.Intern("result-type")

var Lit_179 *jrt.String = jrt.Intern("fnil")

var Lit_180 *jrt.String = jrt.Intern("total")

var Lit_181 *jrt.String = jrt.Intern("inc")

var Lit_182 *jrt.String = jrt.Intern("summarize-results")

var Lit_183 *jrt.String = jrt.Intern("abbrev-result")

var Lit_184 *jrt.String = jrt.Intern("arbace.spec.test.alpha$__GT_sym")

var Lit_185 *jrt.String = jrt.Intern("arbace.spec.test.alpha$__GT_var")

var Lit_186 *jrt.String = jrt.Intern(" does not name a var")

var Lit_187 *jrt.String = jrt.Intern("arbace.spec.test.alpha$abbrev_result")

var Lit_188 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_fixed_args_body")

var Lit_189 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_flattener_code")

var Lit_190 *jrt.String = jrt.Intern("inner")

var Lit_191 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_flattener_code$fn__107000074")

var Lit_192 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_kwargs_body")

var Lit_193 *jrt.String = jrt.Intern("kwargs")

var Lit_194 *jrt.String = jrt.Intern("arbace.spec.test.alpha$build_varargs_body")

var Lit_195 *jrt.String = jrt.Intern("restargs")

var Lit_196 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check")

var Lit_197 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check$fn__107000127")

var Lit_198 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check_1")

var Lit_199 *jrt.String = jrt.Intern("No fn to spec")

var Lit_200 *jrt.String = jrt.Intern("No :args spec")

var Lit_201 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check_call")

var Lit_202 *jrt.String = jrt.Intern("arbace.spec.test.alpha$check_fn")

var Lit_203 *jrt.String = jrt.Intern("arbace.spec.test.alpha$checkable_syms")

var Lit_204 *jrt.String = jrt.Intern("arbace.spec.test.alpha$collectionize")

var Lit_205 *jrt.String = jrt.Intern("arbace.spec.test.alpha$enumerate_namespace")

var Lit_206 *jrt.String = jrt.Intern("arbace.spec.test.alpha$enumerate_namespace$fn__107000020")

var Lit_207 *jrt.String = jrt.Intern("arbace.spec.test.alpha$enumerate_namespace$fn__107000020$fn__107000021")

var Lit_208 *jrt.String = jrt.Intern("arbace.spec.test.alpha$eval107000002$loading__1927001464__auto____107000003")

var Lit_209 *jrt.String = jrt.Intern("arbace.spec.test.alpha$eval107000006$fn__107000007")

var Lit_210 *jrt.String = jrt.Intern("arbace.spec.test.alpha$explain_check")

var Lit_211 *jrt.String = jrt.Intern("Specification-based check failed")

var Lit_212 *jrt.String = jrt.Intern("arbace.spec.test.alpha$failure_type")

var Lit_213 *jrt.String = jrt.Intern("arbace.spec.test.alpha$find_varargs_decl")

var Lit_214 *jrt.String = jrt.Intern("arbace.spec.test.alpha$fn_spec_QMARK_")

var Lit_215 *jrt.String = jrt.Intern("arbace.spec.test.alpha$fn_spec_name_QMARK_")

var Lit_216 *jrt.String = jrt.Intern("arbace.spec.test.alpha$gen_fixed_args_syms")

var Lit_217 *jrt.String = jrt.Intern("arbace.spec.test.alpha$gen_fixed_args_syms$fn__107000068")

var Lit_218 *jrt.String = jrt.Intern("arbace.spec.test.alpha$has_kwargs_QMARK_")

var Lit_219 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument")

var Lit_220 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument$fn__107000097")

var Lit_221 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument_1")

var Lit_222 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument_choose_fn")

var Lit_223 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrument_choose_spec")

var Lit_224 *jrt.String = jrt.Intern("arbace.spec.test.alpha$instrumentable_syms")

var Lit_225 *jrt.String = jrt.Intern("Assert failed: ")

var Lit_226 *jrt.String = jrt.Intern("instrument :gen expects ident keys")

var Lit_227 *jrt.String = jrt.Intern("\n")

var Lit_228 *jrt.String = jrt.Intern("arbace.spec.test.alpha$interpret_stack_trace_element")

var Lit_229 *jrt.String = jrt.Intern("arbace.spec.test.alpha$interpret_stack_trace_element$degensym__107000043")

var Lit_230 *jrt.String = jrt.Intern("")

var Lit_231 *jrt.String = jrt.Intern("arbace.spec.test.alpha$interpret_stack_trace_element$demunge__107000041")

var Lit_232 *jrt.String = jrt.Intern("arbace.spec.test.alpha$kwargs__GT_kvs")

var Lit_233 *jrt.String = jrt.Intern("arbace.spec.test.alpha$kwargs__GT_kvs$fn__107000065")

var Lit_234 *jrt.String = jrt.Intern("arbace.spec.test.alpha$make_check_result")

var Lit_235 *jrt.String = jrt.Intern("arbace.spec.test.alpha$maybe_wrap_kvs_emulation")

var Lit_236 *jrt.String = jrt.Intern("arbace.spec.test.alpha$no_fspec")

var Lit_237 *jrt.String = jrt.Intern("Fn at ")

var Lit_238 *jrt.String = jrt.Intern(" is not spec'ed.")

var Lit_239 *jrt.String = jrt.Intern("arbace.spec.test.alpha$opt_syms")

var Lit_240 *jrt.String = jrt.Intern("arbace.spec.test.alpha$quick_check")

var Lit_241 *jrt.String = jrt.Intern("arbace.spec.test.alpha$quick_check$fn__107000111")

var Lit_242 *jrt.String = jrt.Intern("arbace.spec.test.alpha$quick_check$fn__107000113")

var Lit_243 *jrt.String = jrt.Intern("arbace.spec.test.alpha$result_type")

var Lit_244 *jrt.String = jrt.Intern("arbace.spec.test.alpha$spec_checking_fn")

var Lit_245 *jrt.String = jrt.Intern("arbace.spec.test.alpha$spec_checking_fn$conform_BANG___107000052")

var Lit_246 *jrt.String = jrt.Intern("Call to ")

var Lit_247 *jrt.String = jrt.Intern(" did not conform to spec.")

var Lit_248 *jrt.String = jrt.Intern("arbace.spec.test.alpha$spec_checking_fn$fn__107000054")

var Lit_249 *jrt.String = jrt.Intern("arbace.spec.test.alpha$stacktrace_relevant_to_instrument")

var Lit_250 *jrt.String = jrt.Intern("arbace.spec.test.alpha$stacktrace_relevant_to_instrument$plumbing_QMARK___107000047")

var Lit_251 *jrt.String = jrt.Intern("arbace.spec.test.alpha$summarize_results")

var Lit_252 *jrt.String = jrt.Intern("arbace.spec.test.alpha$summarize_results$fn__107000134")

var Lit_253 *jrt.String = jrt.Intern("arbace.spec.test.alpha$sym__GT_check_map")

var Lit_254 *jrt.String = jrt.Intern("arbace.spec.test.alpha$throwable_QMARK_")

var Lit_255 *jrt.String = jrt.Intern("arbace.spec.test.alpha$thunk_frame_QMARK_")

var Lit_256 *jrt.String = jrt.Intern("arbace.spec.test.alpha$unstrument")

var Lit_257 *jrt.String = jrt.Intern("arbace.spec.test.alpha$unstrument_1")

var Lit_258 *jrt.String = jrt.Intern("arbace.spec.test.alpha$unwrap_failure")

var Lit_259 *jrt.String = jrt.Intern("arbace.spec.test.alpha$validate_check_opts")

var Lit_260 *jrt.String = jrt.Intern("check :gen expects ident keys")

var Lit_261 *jrt.String = jrt.Intern("arbace.spec.test.alpha$with_instrument_disabled")

var Lit_262 *jrt.String = jrt.Intern("in-ns")

var Lit_263 *jrt.String = jrt.Intern("alias")

var Lit_264 *jrt.String = jrt.Intern("stc")

var Lit_265 *jrt.String = jrt.Intern("private")

var Lit_266 *jrt.String = jrt.Intern("x")

var Lit_267 *jrt.String = jrt.Intern("arbace/spec/test/alpha.ae")

var Lit_268 *jrt.String = jrt.Intern("->var")

var Lit_269 *jrt.String = jrt.Intern("s-or-v")

var Lit_270 *jrt.String = jrt.Intern("enumerate-namespace")

var Lit_271 *jrt.String = jrt.Intern("ns-sym-or-syms")

var Lit_272 *jrt.String = jrt.Intern("doc")

var Lit_273 *jrt.String = jrt.Intern("Given a symbol naming an ns, or a collection of such symbols,\nreturns the set of all symbols naming vars in those nses.")

var Lit_274 *jrt.String = jrt.Intern("dynamic")

var Lit_275 *jrt.String = jrt.Intern("if false, instrumented fns call straight through")

var Lit_276 *jrt.String = jrt.Intern("fn-spec?")

var Lit_277 *jrt.String = jrt.Intern("m")

var Lit_278 *jrt.String = jrt.Intern("Fn-spec must include at least :args or :ret specs.")

var Lit_279 *jrt.String = jrt.Intern("with-instrument-disabled")

var Lit_280 *jrt.String = jrt.Intern("body")

var Lit_281 *jrt.String = jrt.Intern("Disables instrument's checking of calls, within a scope.")

var Lit_282 *jrt.String = jrt.Intern("cls")

var Lit_283 *jrt.String = jrt.Intern("Given the vector-of-syms form of a stacktrace element produced\nby e.g. Throwable->map, returns a map form that adds some keys\nguessing the original Clojure names. Returns a map with\n\n  :class         class name symbol from stack trace\n  :method        method symbol from stack trace\n  :file          filename from stack trace\n  :line          line number from stack trace\n  :var-scope     optional Clojure var symbol scoping fn def\n  :local-fn      optional local Clojure symbol scoping fn def\n\nFor non-Clojure fns, :scope and :local-fn will be absent.")

var Lit_284 *jrt.String = jrt.Intern("elems")

var Lit_285 *jrt.String = jrt.Intern("Takes a coll of stack trace elements (as returned by\nStackTraceElement->vec) and returns a coll of maps as per\ninterpret-stack-trace-element that are relevant to a\nfailure in instrument.")

var Lit_286 *jrt.String = jrt.Intern("fn-name")

var Lit_287 *jrt.String = jrt.Intern("fn-spec")

var Lit_288 *jrt.String = jrt.Intern("Takes a function name, a function f, and an fspec and returns a thunk that\n  first conforms the arguments given then calls f with those arguments if\n  the conform succeeds. Otherwise, an exception is thrown containing information\n  about the conform failure.")

var Lit_289 *jrt.String = jrt.Intern("atom")

var Lit_290 *jrt.String = jrt.Intern("arglist")

var Lit_291 *jrt.String = jrt.Intern("Takes an arglist and returns the restargs binding form if found, else nil.")

var Lit_292 *jrt.String = jrt.Intern("Takes the restargs of a kwargs function call and checks for a trailing element.\n  If found, that element is flattened into a sequence of key->value pairs and\n  concatenated onto the preceding arguments.")

var Lit_293 *jrt.String = jrt.Intern("Takes an arglist and generates a vector of names corresponding to the fixed\n  args found.")

var Lit_294 *jrt.String = jrt.Intern("Takes a function name fn-name and arglist and returns code for a function body that\n  handles kwargs by calling fn-name with any fixed followed by its restargs transformed\n  from kwargs to kvs.")

var Lit_295 *jrt.String = jrt.Intern("Takes a function name fn-name and arglist and returns code for a function body that\n  handles varargs by calling fn-name with any fixed args followed by its rest args.")

var Lit_296 *jrt.String = jrt.Intern("Takes a function name fn-name and arglist and returns code for a function body that\n  handles fixed args by calling fn-name with its fixed args.")

var Lit_297 *jrt.String = jrt.Intern("Takes argslists and generates code for a HOF that given a function, returns a forwarding thunk\n  of analogous arglists that ensures that kwargs are passed as kvs to the original function.")

var Lit_298 *jrt.String = jrt.Intern("Takes an argslist and function f and returns f except when arglists\n  contains a kwargs binding, else wraps f with a forwarding thunk that\n  flattens a trailing map into kvs if present in the kwargs call.")

var Lit_299 *jrt.String = jrt.Intern("over")

var Lit_300 *jrt.String = jrt.Intern("Helper for instrument.")

var Lit_301 *jrt.String = jrt.Intern("overrides")

var Lit_302 *jrt.String = jrt.Intern("Helper for instrument")

var Lit_303 *jrt.String = jrt.Intern("opt-syms")

var Lit_304 *jrt.String = jrt.Intern("Returns set of symbols referenced by 'instrument' opts map")

var Lit_305 *jrt.String = jrt.Intern("Given an opts map as per instrument, returns the set of syms\nthat can be instrumented.")

var Lit_306 *jrt.String = jrt.Intern("sym-or-syms")

var Lit_307 *jrt.String = jrt.Intern("Instruments the vars named by sym-or-syms, a symbol or collection\nof symbols, or all instrumentable vars if sym-or-syms is not\nspecified.\n\nIf a var has an :args fn-spec, sets the var's root binding to a\nfn that checks arg conformance (throwing an exception on failure)\nbefore delegating to the original fn.\n\nThe opts map can be used to override registered specs, and/or to\nreplace fn implementations entirely. Opts for symbols not included\nin sym-or-syms are ignored. This facilitates sharing a common\noptions map across many different calls to instrument.\n\nThe opts map may have the following keys:\n\n  :spec     a map from var-name symbols to override specs\n  :stub     a set of var-name symbols to be replaced by stubs\n  :gen      a map from spec names to generator overrides\n  :replace  a map from var-name symbols to replacement fns\n\n:spec overrides registered fn-specs with specs your provide. Use\n:spec overrides to provide specs for libraries that do not have\nthem, or to constrain your own use of a fn to a subset of its\nspec'ed contract.\n\n:stub replaces a fn with a stub that checks :args, then uses the\n:ret spec to generate a return value.\n\n:gen overrides are used only for :stub generation.\n\n:replace replaces a fn with a fn that checks args conformance, then\ninvokes the fn you provide, enabling arbitrary stubbing and mocking.\n\n:spec can be used in combination with :stub or :replace.\n\nReturns a collection of syms naming the vars instrumented.")

var Lit_308 *jrt.String = jrt.Intern("Undoes instrument on the vars named by sym-or-syms, specified\nas in instrument. With no args, unstruments all instrumented vars.\nReturns a collection of syms naming the vars unstrumented.")

var Lit_309 *jrt.String = jrt.Intern("role")

var Lit_310 *jrt.String = jrt.Intern("specs")

var Lit_311 *jrt.String = jrt.Intern("Returns true if call passes specs, otherwise *returns* an exception\nwith explain-data + ::s/failure.")

var Lit_312 *jrt.String = jrt.Intern("check-sym")

var Lit_313 *jrt.String = jrt.Intern("test-check-ret")

var Lit_314 *jrt.String = jrt.Intern("Builds spec result map.")

var Lit_315 *jrt.String = jrt.Intern("Runs generative tests for fn f using spec and opts. See\n'check' for options and return.")

var Lit_316 *jrt.String = jrt.Intern("Given an opts map as per check, returns the set of syms that\ncan be checked.")

var Lit_317 *jrt.String = jrt.Intern("Run generative tests for spec conformance on vars named by\nsym-or-syms, a symbol or collection of symbols. If sym-or-syms\nis not specified, check all checkable vars.\n\nThe opts map includes the following optional keys, where stc\naliases arbace.spec.test.check: \n\n::stc/opts  opts to flow through test.check/quick-check\n:gen        map from spec names to generator overrides\n\nThe ::stc/opts include :num-tests in addition to the keys\ndocumented by test.check. Generator overrides are passed to\nspec/gen when generating function args.\n\nReturns a lazy sequence of check result maps with the following\nkeys\n\n:spec       the spec tested\n:sym        optional symbol naming the var tested\n:failure    optional test failure\n::stc/ret   optional value returned by test.check/quick-check\n\nThe value for :failure can be any exception. Exceptions thrown by\nspec itself will have an ::s/failure value in ex-data:\n\n:check-failed   at least one checked return did not conform\n:no-args-spec   no :args spec provided\n:no-fn          no fn provided\n:no-fspec       no fspec provided\n:no-gen         unable to generate :args\n:instrument     invalid args detected by instrument\n")

var Lit_318 *jrt.String = jrt.Intern("Returns the type of the check result. This can be any of the\n::s/failure keywords documented in 'check', or:\n\n  :check-passed   all checked fn returns conformed\n  :check-threw    checked fn threw an exception")

var Lit_319 *jrt.String = jrt.Intern("Given a check result, returns an abbreviated version\nsuitable for summary use.")

var Lit_320 *jrt.String = jrt.Intern("check-results")

var Lit_321 *jrt.String = jrt.Intern("summary-result")

var Lit_322 *jrt.String = jrt.Intern("Given a collection of check-results, e.g. from 'check', pretty\nprints the summary-result (default abbrev-result) of each.\n\nReturns a map with :total, the total number of results, plus a\nkey with a count for each different :type of result.")
