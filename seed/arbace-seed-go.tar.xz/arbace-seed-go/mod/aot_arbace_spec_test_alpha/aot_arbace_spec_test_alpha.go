//line aot_arbace_spec_test_alpha.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)






func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_New() *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A { A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_Init(); t := &A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp20 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_2; var tmp7 any = tmp6; var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_3; var tmp9 any = tmp8.Ref(); var tmp10 any; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_4; tmp5.Invoke_O_O_O__O(tmp7, tmp9, tmp10); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_0; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_7; var tmp18 any = tmp17; var tmp19 any; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_8; tmp3 = tmp12.Invoke_O_O_O_O__O(tmp14, tmp16, tmp18, tmp19) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp20 != nil { panic(tmp20) }; return tmp3 }
//line :13:1
func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_New() *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A { A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_Init(); t := &A_arbace_spec_test_alpha_eval107000006_fn__107000007_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_10; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_13; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_11; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_12; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }











func A_arbace_spec_test_alpha_throwable_QMARK__A_New() *A_arbace_spec_test_alpha_throwable_QMARK__A { A_arbace_spec_test_alpha_throwable_QMARK__A_Init(); t := &A_arbace_spec_test_alpha_throwable_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean(jrt.Throwable_InstanceOf(x__0)).Ref() }



func A_arbace_spec_test_alpha___GT_sym_A_New() *A_arbace_spec_test_alpha___GT_sym_A { A_arbace_spec_test_alpha___GT_sym_A_Init(); t := &A_arbace_spec_test_alpha___GT_sym_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_spec_test_alpha___GT_sym_A) Ctor() {}
//line :29:1
func (t *A_arbace_spec_test_alpha___GT_sym_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_14; return lang.IFn_Cast(tmp2.Invoke_O__O(tmp3.Ref())).Invoke_O__O(x__0)
}
func A_arbace_spec_test_alpha___GT_var_A_New() *A_arbace_spec_test_alpha___GT_var_A { A_arbace_spec_test_alpha___GT_var_A_Init(); t := &A_arbace_spec_test_alpha___GT_var_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_spec_test_alpha___GT_var_A) Ctor() {}
//line :33:1
func (t *A_arbace_spec_test_alpha___GT_var_A) Invoke_O_O__O(self, s_or_v__0 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s_or_v__0)) { return s_or_v__0 } else { var v__2 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var

		A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_16; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s_or_v__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_17; v__2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s_or_v__0) } else { v__2 = and__1927000168__auto____2 }
		var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_15; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(v__2)) { return v__2 } else { var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_186); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_18; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp5, jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(s_or_v__0), nil)))))
		}
	}
}
func A_arbace_spec_test_alpha_collectionize_A_New() *A_arbace_spec_test_alpha_collectionize_A { A_arbace_spec_test_alpha_collectionize_A_Init(); t := &A_arbace_spec_test_alpha_collectionize_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_spec_test_alpha_collectionize_A) Ctor() {}
//line :42:1
func (t *A_arbace_spec_test_alpha_collectionize_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_16; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) {
		var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_19; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :44:1
			return x__0
		}
}

func A_arbace_spec_test_alpha_enumerate_namespace_A_New() *A_arbace_spec_test_alpha_enumerate_namespace_A { A_arbace_spec_test_alpha_enumerate_namespace_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Invoke_O_O__O(self, ns_sym_or_syms__0 any) any {



	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_21; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New(); var tmp8 *jrt.Class; A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_Init(); tmp8 = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class; var tmp9 any = tmp6.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_22; return tmp2.Invoke_O_O_O__O(tmp4, tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(ns_sym_or_syms__0))
}
func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New() *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A { A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Ctor() {}
//line :54:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Invoke_O_O__O(self, ns_sym__1 any) any {
	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_23; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(ns_sym__1); var tmp4 *jrt.Class; A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_Init(); tmp4 = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_26; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_27; return tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(ns_sym__1))) }
func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(p0 any) *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A { A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Ctor_O(c__ns_sym any) { t.F_ns_sym = c__ns_sym }
//line :56:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Invoke_O_O__O(self, name_sym__1 any) any {
	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_25; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_ns_sym); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_25; return tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(name_sym__1))
}








func A_arbace_spec_test_alpha_fn_spec_QMARK__A_New() *A_arbace_spec_test_alpha_fn_spec_QMARK__A { A_arbace_spec_test_alpha_fn_spec_QMARK__A_Init(); t := &A_arbace_spec_test_alpha_fn_spec_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Keyword;


	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_28; or__1927000174__auto____2 = jrt.NN(tmp1).Invoke_O__O(m__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_29; return jrt.NN(tmp2).Invoke_O__O(m__0) } }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_New() *A_arbace_spec_test_alpha_with_instrument_disabled_A { A_arbace_spec_test_alpha_with_instrument_disabled_A_Init(); t := &A_arbace_spec_test_alpha_with_instrument_disabled_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) Ctor() {}
//line :72:1
func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_30; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_31; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_19; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_32; var tmp8 any = tmp6.Invoke_O__O(tmp7); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_19; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_33; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_34; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_30; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_31; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_19; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 any; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_35; var tmp22 any = tmp20.Invoke_O__O(tmp21); var tmp23 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_19; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O__O(tmp14, tmp16.Invoke_O__O(tmp18.Invoke_O_O__O(tmp22, lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(nil))))), body__2)) }





func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_New() *A_arbace_spec_test_alpha_thunk_frame_QMARK__A { A_arbace_spec_test_alpha_thunk_frame_QMARK__A_Init(); t := &A_arbace_spec_test_alpha_thunk_frame_QMARK__A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Ctor() {}
//line :78:1
func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Invoke_O_O__O(self, s__0 any) any {
	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_36; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_103)
}
func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_A { A_arbace_spec_test_alpha_interpret_stack_trace_element_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Ctor() {}
//line :81:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Invoke_O_O__O(self, p__107000034__0 any) any { var vec__107000035__2 any = p__107000034__0; var cls__3 any = lang.RT_Nth_O_I_O__O(vec__107000035__2, lang.RT_IntCast_J__I(0), nil); var method__4 any = lang.RT_Nth_O_I_O__O(vec__107000035__2, lang.RT_IntCast_J__I(1), nil); var file__5 any = lang.RT_Nth_O_I_O__O(vec__107000035__2, lang.RT_IntCast_J__I(2), nil); var line__6 any = lang.RT_Nth_O_I_O__O(vec__107000035__2, lang.RT_IntCast_J__I(3), nil); var clojure_QMARK___7 any; var tmp1 *lang.Var;













	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_37; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_41; clojure_QMARK___7 = tmp2.Invoke_O_O__O(tmp3, method__4); var demunge__8 any; var tmp4 any = /*line :81:1*/A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New(); var tmp5 *jrt.Class;













	A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_Init(); tmp5 = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class; demunge__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var degensym__9 any; var tmp6 any = /*line :81:1*/A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New(); var tmp7 *jrt.Class;













	A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_Init(); tmp7 = A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class; degensym__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var vec__107000038__10 any; if


	jrt.A2g_Truth(clojure_QMARK___7) {

		var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_23; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_42; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_43; var tmp13 any = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(cls__3); var tmp14 any; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_44; var tmp15 any = tmp14; var tmp16 any; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_45; vec__107000038__10 = tmp9.Invoke_O_O__O(demunge__8, tmp11.Invoke_O_O_O__O(tmp13, tmp15, tmp16)) } else {
//line :98:1
			vec__107000038__10 = nil }; var ns_sym__11 any = /*line :81:1*/lang.RT_Nth_O_I_O__O(vec__107000038__10, lang.RT_IntCast_J__I(0), nil); var name_sym__12 any = lang.RT_Nth_O_I_O__O(vec__107000038__10, lang.RT_IntCast_J__I(1), nil); var local__13 any = lang.RT_Nth_O_I_O__O(vec__107000038__10, lang.RT_IntCast_J__I(2), nil); var tmp17 *lang.Var;



















	A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_40; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_46; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_47; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_48; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp25 = A_arbace_spec_test_alpha_A_const_49; var tmp26 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, file__5, tmp22, line__6, tmp24, method__4, tmp25.Ref(), cls__3)); var tmp27 lang.IPersistentMap; var tmp28 any; var and__1927000168__auto____14 any = ns_sym__11; if



	jrt.A2g_Truth(and__1927000168__auto____14) { tmp28 = name_sym__12 } else { tmp28 = and__1927000168__auto____14 }; if jrt.A2g_Truth(tmp28) { var tmp29 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp29 = A_arbace_spec_test_alpha_A_const_50; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp31 = A_arbace_spec_test_alpha_A_const_24; tmp27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp30, lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O_O__O(ns_sym__11, name_sym__12))) } else { tmp27 = nil }; var tmp32 any = tmp27; var tmp33 lang.IPersistentMap; if

	jrt.A2g_Truth(local__13) { var tmp34 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp34 = A_arbace_spec_test_alpha_A_const_51; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp36 = A_arbace_spec_test_alpha_A_const_24; var tmp37 any = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(degensym__9).Invoke_O__O(local__13)); var tmp38 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp38 = A_arbace_spec_test_alpha_A_const_52; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp40 = A_arbace_spec_test_alpha_A_const_53; tmp33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp35, tmp37, tmp39, lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(local__13))) } else { tmp33 = nil }; return /*line :101:1*/ tmp18.Invoke_O_O_O__O(tmp26, tmp32, tmp33) }
//line :95:1
func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A { A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Ctor() {}
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Invoke_O_O__O(self, p1__107000033_SHARP___1 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_39; return tmp2.Invoke_O_O_O__O(p1__107000033_SHARP___1, tmp3, Lit_230) }
//line :95:1
func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A { A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Ctor() {}
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Invoke_O_O__O(self, p1__107000032_SHARP___1 any) any {
	return lang.Compiler_Demunge_String__String(jrt.String_Cast(p1__107000032_SHARP___1)).Ref()
}













func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_New() *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A { A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_Init(); t := &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Ctor() {}
//line :111:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Invoke_O_O__O(self, elems__0 any) any { var plumbing_QMARK___2 any; var tmp1 any = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New(); var tmp2 *jrt.Class;





	A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_Init(); tmp2 = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class; plumbing_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 /*line :122:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_58; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_59; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_23; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_62; var tmp10 any = tmp8.Invoke_O__O(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_23; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_63; var tmp14 any = tmp12.Invoke_O__O(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_60; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_50; var tmp18 any = tmp16.Invoke_O__O(tmp17.Ref()); var tmp19 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_61; return tmp4.Invoke_O_O__O(tmp6.Invoke_O_O_O_O__O(tmp10, tmp14, tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(plumbing_QMARK___2)), elems__0) }
//line :117:1
func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New() *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A { A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_Init(); t := &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Ctor() {}
//line :117:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Invoke_O_O__O(self, p__107000046__1 any) any { var map__107000048__2 any = p__107000046__1; var map__107000048__3 any; if lang.ISeq_InstanceOf(map__107000048__2) { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__107000048__2)) { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_55; map__107000048__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__107000048__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__107000048__2)) { var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_56; map__107000048__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__107000048__2) } else { lang.PersistentArrayMap_Init(); map__107000048__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000048__3 = map__107000048__2 }; var var_scope__4 any; var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_50; var_scope__4 = lang.RT_Get_O_O__O(map__107000048__3, tmp5.Ref()); var thunk_QMARK___5 any; var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_52; thunk_QMARK___5 = lang.RT_Get_O_O__O(map__107000048__3, tmp6.Ref()); var or__1927000174__auto____6 any = thunk_QMARK___5; if
																		jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
																			var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_37; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_57; return tmp8.Invoke_O_O__O(tmp9, var_scope__4) } }








func A_arbace_spec_test_alpha_spec_checking_fn_A_New() *A_arbace_spec_test_alpha_spec_checking_fn_A { A_arbace_spec_test_alpha_spec_checking_fn_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Ctor() {}
//line :128:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Invoke_O_O_O_O__O(self, fn_name__0, f__1, fn_spec__2 any) any { var fn_spec__4 any; var tmp1 *lang.Var;





	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_80; fn_spec__4 = lang.IFn_Cast(tmp2.Invoke_O__O(tmp3.Ref())).Invoke_O__O(fn_spec__2); var conform_BANG___5 any; var tmp4 any = /*line :128:1*/A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New(); var tmp5 *jrt.Class;






	A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_Init(); tmp5 = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class; conform_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp6 any =















	A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(fn_name__0, f__1, conform_BANG___5, fn_spec__4); var tmp7 *jrt.Class; A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_Init(); tmp7 = A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp6, tmp7, nil, 0) }
//line :135:1
func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New() *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A { A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Ctor() {}
//line :135:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Invoke_O_O_O_O_O_O__O(self, fn_name__1, role__2, spec__3, data__4, args__5 any) any { var conformed__6 any; var tmp1 *lang.Var;
																					A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_64; conformed__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(spec__3, data__4); var tmp2 /*line :137:1*/*lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_65; if lang.Util_Equiv_O_O__Z(tmp2.Ref(), conformed__6) { var caller__7 any; var tmp3 *lang.Var
																						A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_56; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_67; caller__7 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(jrt.Thread_CurrentThread__Thread().GetStackTrace__StackTraceElement1().Ref()))
//line :137:1
		var ed__8 any; var tmp6 *lang.Var



		A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_40; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_68; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_71; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.PersistentVector; lang.PersistentVector_Init(); tmp12 = lang.PersistentVector_EMPTY; var tmp13 any = tmp12.Ref(); var tmp14 *lang.PersistentVector; lang.PersistentVector_Init(); tmp14 = lang.PersistentVector_EMPTY; var tmp15 any = tmp14.Ref(); var tmp16 *lang.PersistentVector; lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; var tmp17 any = tmp11.Invoke_O_O_O_O_O__O(spec__3, tmp13, tmp15, tmp16.Ref(), data__4); var tmp18 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_72; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_73; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp22 = A_arbace_spec_test_alpha_A_const_74; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp24 = A_arbace_spec_test_alpha_A_const_75; var tmp25 any = tmp9.Invoke_O_O_O_O_O_O_O__O(tmp17, tmp19, fn_name__1, tmp21, args__5, tmp23, tmp24.Ref()); var tmp26 lang.IPersistentMap



		if jrt.A2g_Truth(caller__7) { var tmp27 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp27 = A_arbace_spec_test_alpha_A_const_69; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp29 = A_arbace_spec_test_alpha_A_const_70; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp31 = A_arbace_spec_test_alpha_A_const_49; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp33 = A_arbace_spec_test_alpha_A_const_48; tmp26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30.Invoke_O_O_O__O(caller__7, tmp32, tmp33.Ref()))) } else { tmp26 = nil }
//line :141:1
		ed__8 = tmp7.Invoke_O_O__O(tmp25, tmp26)
//line :137:1
		var tmp34 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp34 = A_arbace_spec_test_alpha_A_const_66; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_246, nil, Lit_247), jrt.RefArrayOf(jrt.Object_class, nil, fn_name__1, nil)).Ref(), ed__8)))) } else { return conformed__6 } }













func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A { A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :151:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) Ctor_O_O_O_O(c__fn_name, c__f, c__conform_BANG_, c__fn_spec any) { t.F_fn_name = c__fn_name; t.F_f = c__f; t.F_conform_BANG_ = c__conform_BANG_; t.F_fn_spec = c__fn_spec }
//line :151:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) DoInvoke_O_O__O(self, args__1 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_76; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) {
		var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_78; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_79; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_76; tmp3.Invoke_O__O(tmp5.Invoke_O_O__O(tmp6.Ref(), nil))
//line :153:1
		var tmp7 any; tmp24 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			{ var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_28; if jrt.A2g_Truth(jrt.NN(tmp8).Invoke_O__O(t.F_fn_spec)) { var tmp9 lang.IFn = lang.IFn_Cast(t.F_conform_BANG_); var tmp10 any = t.F_fn_name; var tmp11 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_28; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_28; tmp9.Invoke_O_O_O_O_O__O(tmp10, tmp12, jrt.NN(tmp13).Invoke_O__O(t.F_fn_spec), args__1, args__1) }
				var tmp14 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_78; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_79; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_76; var tmp19 any = tmp18.Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; tmp15.Invoke_O__O(tmp17.Invoke_O_O__O(tmp19, tmp20.Ref())); tmp22 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
					{ var tmp21 lang.IFn = lang.IFn_Cast(t.F_f); tmp7 = tmp21.ApplyTo_ISeq__O(lang.ISeq_Cast(args__1)) }
//line :156:1
					return nil }(); var tmp23 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_77; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke__O()
//line :153:1
				if tmp22 != nil { panic(tmp22) } }; return nil }(); var tmp25 *lang.Var
		A_arbace_spec_test_alpha_A_Init(); tmp25 = A_arbace_spec_test_alpha_A_const_77; lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke__O()
//line :153:1
		if tmp24 != nil { panic(tmp24) }; return tmp7 } else {




			var tmp26 lang.IFn = lang.IFn_Cast(t.F_f); return tmp26.ApplyTo_ISeq__O(lang.ISeq_Cast(args__1))
		} }
func A_arbace_spec_test_alpha_no_fspec_A_New() *A_arbace_spec_test_alpha_no_fspec_A { A_arbace_spec_test_alpha_no_fspec_A_Init(); t := &A_arbace_spec_test_alpha_no_fspec_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_spec_test_alpha_no_fspec_A) Ctor() {}
//line :160:1
func (t *A_arbace_spec_test_alpha_no_fspec_A) Invoke_O_O_O__O(self, v__0, spec__1 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_66; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_237, nil, Lit_238), jrt.RefArrayOf(jrt.Object_class, nil, v__0, nil)).Ref(); var tmp4 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_81; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_82; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_74; var tmp9 any = tmp8.Ref(); var tmp10 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_83; return tmp2.Invoke_O_O__O(tmp3, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, v__0, tmp7, spec__1, tmp9, tmp10.Ref())))
}



func A_arbace_spec_test_alpha_find_varargs_decl_A_New() *A_arbace_spec_test_alpha_find_varargs_decl_A { A_arbace_spec_test_alpha_find_varargs_decl_A_Init(); t := &A_arbace_spec_test_alpha_find_varargs_decl_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Ctor() {}
//line :167:1
func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Invoke_O_O__O(self, arglist__0 any) any { var vec__107000060__2 any; var tmp1 *lang.Var;


	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_84; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_85; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_86; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_87; vec__107000060__2 = tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6.Invoke_O__O(tmp7), arglist__0)); var ___3 any = /*line :167:1*/lang.RT_Nth_O_I_O__O(vec__107000060__2, lang.RT_IntCast_J__I(0), nil); var decl__4 any = lang.RT_Nth_O_I_O__O(vec__107000060__2, lang.RT_IntCast_J__I(1), nil); var restargs__5 any = vec__107000060__2; var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z(2, int64(lang.RT_Count_O__I(restargs__5))); _ = ___3; if and__1927000168__auto____6 {





		return decl__4 } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____6).Ref() } }


func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_New() *A_arbace_spec_test_alpha_has_kwargs_QMARK__A { A_arbace_spec_test_alpha_has_kwargs_QMARK__A_Init(); t := &A_arbace_spec_test_alpha_has_kwargs_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Invoke_O_O__O(self, arglists__0 any) any {
	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_88; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_89; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_90; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(jrt.NN(tmp5).GetRawRoot__O(), arglists__0))
}
func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_New() *A_arbace_spec_test_alpha_kwargs__GT_kvs_A { A_arbace_spec_test_alpha_kwargs__GT_kvs_A_Init(); t := &A_arbace_spec_test_alpha_kwargs__GT_kvs_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Ctor() {}
//line :179:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Invoke_O_O__O(self, args__0 any) any {




	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_91; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(args__0)).Ref())) { return args__0 } else {

		var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_31; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_92; var tmp5 any = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(args__0); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_93; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New(); var tmp9 *jrt.Class; A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_Init(); tmp9 = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class; var tmp10 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var tmp11 *lang.PersistentList_EmptyList; lang.PersistentList_Init(); tmp11 = lang.PersistentList_EMPTY; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_95; return tmp3.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O_O__O(tmp10, tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(args__0))) } }
func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New() *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A { A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_Init(); t := &A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Ctor() {}
//line :187:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Invoke_O_O_O_O__O(self, acc__1, k__2, v__3 any) any { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_94; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_94; return tmp2.Invoke_O_O__O(k__2, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(v__3, acc__1)) }



func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_New() *A_arbace_spec_test_alpha_gen_fixed_args_syms_A { A_arbace_spec_test_alpha_gen_fixed_args_syms_A_Init(); t := &A_arbace_spec_test_alpha_gen_fixed_args_syms_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Ctor() {}
//line :191:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Invoke_O_O__O(self, arglist__0 any) any {



	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_96; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_23; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New(); var tmp6 *jrt.Class; A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_Init(); tmp6 = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_98; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_86; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_99; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp7, tmp9.Invoke_O_O__O(tmp11.Invoke_O__O(tmp12), arglist__0))) }
//line :195:1
func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New() *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A { A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_Init(); t := &A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Ctor() {}
//line :195:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Invoke_O_O__O(self, ___1 any) any { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_97; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O() }

func A_arbace_spec_test_alpha_build_kwargs_body_A_New() *A_arbace_spec_test_alpha_build_kwargs_body_A { A_arbace_spec_test_alpha_build_kwargs_body_A_Init(); t := &A_arbace_spec_test_alpha_build_kwargs_body_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Ctor() {}
//line :197:1
func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var alias__3 any; var tmp1 *lang.Var;




	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_97; alias__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_193); var head_args__4 any; var tmp2 /*line :197:1*/*lang.Var;





	A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_100; head_args__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(arglist__1); var tmp3 /*line :204:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_11; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_101; var tmp8 any = tmp6.Invoke_O_O_O__O(head_args__4, tmp7, alias__3); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_31; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_19; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_102; var tmp16 any = tmp14.Invoke_O__O(tmp15); var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_19; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(fn_name__0); var tmp19 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_19; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_30; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_31; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp25 = A_arbace_spec_test_alpha_A_const_19; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp27 = A_arbace_spec_test_alpha_A_const_30; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp29 = A_arbace_spec_test_alpha_A_const_31; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp31 = A_arbace_spec_test_alpha_A_const_19; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 any; A_arbace_spec_test_alpha_A_Init(); tmp33 = A_arbace_spec_test_alpha_A_const_103; var tmp34 any = tmp32.Invoke_O__O(tmp33); var tmp35 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp35 = A_arbace_spec_test_alpha_A_const_19; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp37 = A_arbace_spec_test_alpha_A_const_30; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp39 = A_arbace_spec_test_alpha_A_const_31; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp41 = A_arbace_spec_test_alpha_A_const_19; var tmp42 lang.IFn = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()); var tmp43 any; A_arbace_spec_test_alpha_A_Init(); tmp43 = A_arbace_spec_test_alpha_A_const_104; var tmp44 any = tmp42.Invoke_O__O(tmp43); var tmp45 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp45 = A_arbace_spec_test_alpha_A_const_19; var tmp46 lang.IFn = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()); var tmp47 any; A_arbace_spec_test_alpha_A_Init(); tmp47 = A_arbace_spec_test_alpha_A_const_105; var tmp48 any = tmp26.Invoke_O__O(tmp28.Invoke_O__O(tmp30.Invoke_O_O__O(tmp34, tmp36.Invoke_O__O(tmp38.Invoke_O__O(tmp40.Invoke_O_O__O(tmp44, tmp46.Invoke_O__O(tmp47))))))); var tmp49 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp49 = A_arbace_spec_test_alpha_A_const_19; return tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O_O_O__O(tmp16, tmp18, head_args__4, tmp20.Invoke_O__O(tmp22.Invoke_O__O(tmp24.Invoke_O_O__O(tmp48, lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(alias__3))))))) }


func A_arbace_spec_test_alpha_build_varargs_body_A_New() *A_arbace_spec_test_alpha_build_varargs_body_A { A_arbace_spec_test_alpha_build_varargs_body_A_Init(); t := &A_arbace_spec_test_alpha_build_varargs_body_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Ctor() {}
//line :207:1
func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var head_args__3 any; var tmp1 *lang.Var;



	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_100; head_args__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(arglist__1); var alias__4 any; var tmp2 /*line :207:1*/*lang.Var;




	A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_97; alias__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(Lit_195); var tmp3 /*line :213:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_19; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_11; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_106; var tmp8 any = tmp6.Invoke_O_O_O__O(head_args__3, tmp7, alias__4); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_31; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_19; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_107; var tmp16 any = tmp14.Invoke_O__O(tmp15); var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_19; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(fn_name__0); var tmp19 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_19; return tmp4.Invoke_O_O__O(tmp8, tmp10.Invoke_O__O(tmp12.Invoke_O_O_O_O__O(tmp16, tmp18, head_args__3, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(alias__4)))) }


func A_arbace_spec_test_alpha_build_fixed_args_body_A_New() *A_arbace_spec_test_alpha_build_fixed_args_body_A { A_arbace_spec_test_alpha_build_fixed_args_body_A_Init(); t := &A_arbace_spec_test_alpha_build_fixed_args_body_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Ctor() {}
//line :216:1
func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var arglist__3 any; var tmp1 *lang.Var;



	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_100; arglist__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(arglist__1); var tmp2 /*line :221:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_19; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_30; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_31; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_19; return tmp3.Invoke_O_O__O(arglist__3, tmp5.Invoke_O__O(tmp7.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(fn_name__0), arglist__3))) }


func A_arbace_spec_test_alpha_build_flattener_code_A_New() *A_arbace_spec_test_alpha_build_flattener_code_A { A_arbace_spec_test_alpha_build_flattener_code_A_Init(); t := &A_arbace_spec_test_alpha_build_flattener_code_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Ctor() {}
//line :224:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Invoke_O_O__O(self, arglists__0 any) any { var closed_over_name__2 any; var tmp1 *lang.Var;



	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_97; closed_over_name__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(Lit_190); var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_30; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_31; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_19; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_108; var tmp9 any = tmp7.Invoke_O__O(tmp8); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_19; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_33; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_34; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_30; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_31; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_19; var tmp21 any = tmp11.Invoke_O__O(tmp13.Invoke_O_O__O(tmp15, tmp17.Invoke_O__O(tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(closed_over_name__2))))); var tmp22 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp22 = A_arbace_spec_test_alpha_A_const_19; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp24 = A_arbace_spec_test_alpha_A_const_30; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp26 = A_arbace_spec_test_alpha_A_const_31; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp28 = A_arbace_spec_test_alpha_A_const_19; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 any; A_arbace_spec_test_alpha_A_Init(); tmp30 = A_arbace_spec_test_alpha_A_const_109; var tmp31 any = tmp29.Invoke_O__O(tmp30); var tmp32 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp32 = A_arbace_spec_test_alpha_A_const_19; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 any; A_arbace_spec_test_alpha_A_Init(); tmp34 = A_arbace_spec_test_alpha_A_const_110; var tmp35 any = tmp33.Invoke_O__O(tmp34); var tmp36 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp36 = A_arbace_spec_test_alpha_A_const_23; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 any = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(closed_over_name__2); var tmp39 *jrt.Class; A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_Init(); tmp39 = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class; var tmp40 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp38, tmp39, nil); var tmp41 any; var or__1927000174__auto____3 any = arglists__0; if







	jrt.A2g_Truth(or__1927000174__auto____3) { tmp41 = or__1927000174__auto____3 } else { A_arbace_spec_test_alpha_A_Init(); tmp41 = A_arbace_spec_test_alpha_A_const_115 }; return /*line :228:1*/ tmp3.Invoke_O__O(tmp5.Invoke_O_O_O__O(tmp9, tmp21, tmp23.Invoke_O__O(tmp25.Invoke_O__O(tmp27.Invoke_O_O_O__O(tmp31, tmp35, tmp37.Invoke_O_O__O(tmp40, tmp41)))))) }


func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(p0 any) *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A { A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_Init(); t := &A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Ctor_O(c__closed_over_name any) { t.F_closed_over_name = c__closed_over_name }
//line :231:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Invoke_O_O__O(self, arglist__1 any) any { var varargs_decl__2 any; var tmp1 *lang.Var;
														A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_90; varargs_decl__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(arglist__1); var tmp2 /*line :233:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_88; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(varargs_decl__2)) { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_111; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(t.F_closed_over_name, arglist__1) } else { if jrt.A2g_Truth(varargs_decl__2) {
															var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_112; return lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O__O(t.F_closed_over_name, arglist__1) } else {
//line :233:1
			var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_113; if tmp5 != nil {

				var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_114; return lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O__O(t.F_closed_over_name, arglist__1) } else {
//line :233:1
					return nil } } } }





















func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_New() *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A { A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_Init(); t := &A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Ctor() {}
//line :255:1
func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Invoke_O_O_O__O(self, f__0, arglists__1 any) any {




	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_116; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(arglists__1)) { var flattener_code__3 any; var tmp2 *lang.Var
		A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_117; flattener_code__3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(arglists__1)
//line :260:1
		var kvs_emu__4 any; var tmp3 *lang.Var

		A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_118; kvs_emu__4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(flattener_code__3)
		return lang.IFn_Cast(kvs_emu__4).Invoke_O__O(f__0) } else {
//line :260:1
			return f__0
		}
}



func A_arbace_spec_test_alpha_instrument_choose_fn_A_New() *A_arbace_spec_test_alpha_instrument_choose_fn_A { A_arbace_spec_test_alpha_instrument_choose_fn_A_Init(); t := &A_arbace_spec_test_alpha_instrument_choose_fn_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Ctor() {}
//line :266:1
func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Invoke_O_O_O_O_O__O(self, f__0, spec__1, sym__2, p__107000078__3 any) any { var map__107000079__5 any = p__107000078__3; var map__107000079__6 any; if lang.ISeq_InstanceOf(map__107000079__5) { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__107000079__5)) { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_55; map__107000079__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__107000079__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__107000079__5)) { var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_56; map__107000079__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__107000079__5) } else { lang.PersistentArrayMap_Init(); map__107000079__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000079__6 = map__107000079__5 }; var over__7 any; var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_119; over__7 = lang.RT_Get_O_O__O(map__107000079__6, tmp5.Ref()); var stub__8 any; var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_120; stub__8 = lang.RT_Get_O_O__O(map__107000079__6, tmp6.Ref()); var replace__9 any; var tmp7 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_121; replace__9 = lang.RT_Get_O_O__O(map__107000079__6, tmp7.Ref()); var tmp8 /*line :269:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_89; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet(jrt.RefArrayOf(jrt.Object_class, sym__2)), stub__8)) {
																	var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_122; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_123; return tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(spec__1, over__7)) } else {
																		return lang.RT_Get_O_O_O__O(replace__9, sym__2, f__0) } }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_New() *A_arbace_spec_test_alpha_instrument_choose_spec_A { A_arbace_spec_test_alpha_instrument_choose_spec_A_Init(); t := &A_arbace_spec_test_alpha_instrument_choose_spec_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Ctor() {}
//line :273:1
func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Invoke_O_O_O_O__O(self, spec__0, sym__1, p__107000082__2 any) any { var map__107000083__4 any = p__107000082__2; var map__107000083__5 any; if lang.ISeq_InstanceOf(map__107000083__4) { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__107000083__4)) { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_55; map__107000083__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__107000083__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__107000083__4)) { var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_56; map__107000083__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__107000083__4) } else { lang.PersistentArrayMap_Init(); map__107000083__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000083__5 = map__107000083__4 }; var overrides__6 any; var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_82; overrides__6 = lang.RT_Get_O_O__O(map__107000083__5, tmp5.Ref()); return /*line :276:1*/ lang.RT_Get_O_O_O__O(overrides__6, sym__1, spec__0) }

func A_arbace_spec_test_alpha_instrument_1_A_New() *A_arbace_spec_test_alpha_instrument_1_A { A_arbace_spec_test_alpha_instrument_1_A_Init(); t := &A_arbace_spec_test_alpha_instrument_1_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_spec_test_alpha_instrument_1_A) Ctor() {}
//line :278:1
func (t *A_arbace_spec_test_alpha_instrument_1_A) Invoke_O_O_O__O(self, s__0, opts__1 any) any { var temp__1927000414__auto____3 any; var tmp1 *lang.Var;

	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_17; temp__1927000414__auto____3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; var tmp2 *lang.Keyword
		A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_124; var tmp3 *lang.Keyword = tmp2; if jrt.A2g_Truth(jrt.NN(tmp3).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__4))) { return nil } else { var spec__5 any; var tmp4 *lang.Var
			A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_125; spec__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(v__4)
//line :281:1
			var map__107000086__6 any; var tmp5 *lang.Var

			A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_10; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_134; map__107000086__6 = lang.RT_Get_O_O__O(tmp6.Invoke_O__O(jrt.NN(tmp7).GetRawRoot__O()), v__4)
//line :281:1
			var map__107000086__7 any
			if lang.ISeq_InstanceOf(map__107000086__6) { var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(map__107000086__6)) { var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_55; map__107000086__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(map__107000086__6), jrt.Object_class.ArrayClass())).Ref() } else { var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__107000086__6)) { var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_56; map__107000086__7 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(map__107000086__6) } else { lang.PersistentArrayMap_Init(); map__107000086__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000086__7 = map__107000086__6 }
//line :281:1
			var raw__8 any; var tmp12 *lang.Keyword
			A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_126; raw__8 = lang.RT_Get_O_O__O(map__107000086__7, tmp12.Ref())
//line :281:1
			var wrapped__9 any; var tmp13 *lang.Keyword
			A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_127; wrapped__9 = lang.RT_Get_O_O__O(map__107000086__7, tmp13.Ref())
//line :281:1
			var current__10 any; var tmp14 *lang.Var
			A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_10; current__10 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(v__4)
//line :281:1
			var to_wrap__11 any



			if lang.Util_Equiv_O_O__Z(wrapped__9, current__10) { to_wrap__11 = raw__8 } else { to_wrap__11 = current__10 }
//line :281:1
			var ospec__12 any; var or__1927000174__auto____12 any; var tmp15 *lang.Var




			A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_128; or__1927000174__auto____12 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O_O_O__O(spec__5, s__0, opts__1); if jrt.A2g_Truth(or__1927000174__auto____12) { ospec__12 = or__1927000174__auto____12 } else { var tmp16 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_129; panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O_O__O(v__4, spec__5)))) }
//line :281:1
			var ofn__13 any; var tmp17 *lang.Var






			A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_130; ofn__13 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O_O_O__O(to_wrap__11, ospec__12, s__0, opts__1)
//line :281:1
			var checked__14 any; var tmp18 *lang.Var







			A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_131; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_133; checked__14 = tmp19.Invoke_O_O_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(v__4), ofn__13, ospec__12)
//line :281:1
			var arglists__15 any; var tmp21 *lang.Var








			A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_30; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_135; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp25 = A_arbace_spec_test_alpha_A_const_136; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp27 = A_arbace_spec_test_alpha_A_const_137; var tmp28 *lang.Keyword = tmp27; arglists__15 = tmp22.Invoke_O__O(tmp24.Invoke_O_O__O(tmp26, jrt.NN(tmp28).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__4))))
//line :281:1
			var wrapped__16 any; var tmp29 *lang.Var









			A_arbace_spec_test_alpha_A_Init(); tmp29 = A_arbace_spec_test_alpha_A_const_132; wrapped__16 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O__O(checked__14, arglists__15)
			var tmp30 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp30 = A_arbace_spec_test_alpha_A_const_138; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp32 = A_arbace_spec_test_alpha_A_const_140; tmp31.Invoke_O_O__O(v__4, lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(wrapped__16))
			var tmp33 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp33 = A_arbace_spec_test_alpha_A_const_139; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp35 = A_arbace_spec_test_alpha_A_const_134; var tmp36 any = jrt.NN(tmp35).GetRawRoot__O(); var tmp37 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp37 = A_arbace_spec_test_alpha_A_const_68; var tmp38 any = jrt.NN(tmp37).GetRawRoot__O(); var tmp39 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp39 = A_arbace_spec_test_alpha_A_const_126; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp41 = A_arbace_spec_test_alpha_A_const_127; tmp34.Invoke_O_O_O_O__O(tmp36, tmp38, v__4, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, to_wrap__11, tmp41.Ref(), wrapped__16)))
			var tmp42 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp42 = A_arbace_spec_test_alpha_A_const_133; return lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(v__4) } } else {
//line :280:1
				return nil } }















func A_arbace_spec_test_alpha_unstrument_1_A_New() *A_arbace_spec_test_alpha_unstrument_1_A { A_arbace_spec_test_alpha_unstrument_1_A_Init(); t := &A_arbace_spec_test_alpha_unstrument_1_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_spec_test_alpha_unstrument_1_A) Ctor() {}
//line :296:1
func (t *A_arbace_spec_test_alpha_unstrument_1_A) Invoke_O_O__O(self, s__0 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Var;

	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_17; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var tmp2 *lang.Var
		A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_10; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_134; temp__1927000414__auto____4 = lang.RT_Get_O_O__O(tmp3.Invoke_O__O(jrt.NN(tmp4).GetRawRoot__O()), v__3); if jrt.A2g_Truth(temp__1927000414__auto____4) { var map__107000089__5 any = temp__1927000414__auto____4; var map__107000089__6 any; if lang.ISeq_InstanceOf(map__107000089__5) { var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(map__107000089__5)) { var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_55; map__107000089__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(map__107000089__5), jrt.Object_class.ArrayClass())).Ref() } else { var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(map__107000089__5)) { var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_56; map__107000089__6 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(map__107000089__5) } else { lang.PersistentArrayMap_Init(); map__107000089__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000089__6 = map__107000089__5 }; var raw__7 any; var tmp9 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_126; raw__7 = lang.RT_Get_O_O__O(map__107000089__6, tmp9.Ref()); var wrapped__8 any; var tmp10 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_127; wrapped__8 = lang.RT_Get_O_O__O(map__107000089__6, tmp10.Ref())
			var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_139; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_134; var tmp14 any = jrt.NN(tmp13).GetRawRoot__O(); var tmp15 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_70; tmp12.Invoke_O_O_O__O(tmp14, jrt.NN(tmp15).GetRawRoot__O(), v__3)
//line :299:1
			var current__9 any; var tmp16 *lang.Var

			A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_10; current__9 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(v__3)
			if lang.Util_Equiv_O_O__Z(wrapped__8, current__9) {
				var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_138; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_140; tmp18.Invoke_O_O__O(v__3, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(raw__7))
				var tmp20 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_133; return lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(v__3) } else {
//line :302:1
					return nil } } else {
//line :299:1
						return nil } } else {
//line :298:1
							return nil } }







func A_arbace_spec_test_alpha_opt_syms_A_New() *A_arbace_spec_test_alpha_opt_syms_A { A_arbace_spec_test_alpha_opt_syms_A_Init(); t := &A_arbace_spec_test_alpha_opt_syms_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_spec_test_alpha_opt_syms_A) Ctor() {}
//line :306:1
func (t *A_arbace_spec_test_alpha_opt_syms_A) Invoke_O_O__O(self, opts__0 any) any {


	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_141; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_20; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp5 = lang.PersistentHashSet_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_120; var tmp8 any = jrt.NN(tmp7).Invoke_O__O(opts__0); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_26; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_121; var tmp12 any = tmp10.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(opts__0)); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_26; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_82; return tmp2.Invoke_O_O_O__O(tmp4, tmp6, lang.Tuple_Create_O_O_O__IPersistentVector(tmp8, tmp12, tmp14.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(opts__0))))
}
func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_New() *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A { A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_Init(); t := &A_arbace_spec_test_alpha_fn_spec_name_QMARK__A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Ctor() {}
//line :311:1
func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var;

	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_16; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); if jrt.A2g_Truth(and__1927000168__auto____2) {
		var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_142; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var G__107000093__3_ any; var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_17; G__107000093__3_ = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(s__0); var G__107000093__4_ any; if lang.Util_Identical_O_O__Z(G__107000093__3_, nil) { G__107000093__4_ = nil } else { G__107000093__4_ = lang.RT_Meta_O__IPersistentMap(G__107000093__3_) }; if lang.Util_Identical_O_O__Z(G__107000093__4_, nil) { tmp4 = nil } else { var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_124; tmp4 = jrt.NN(tmp6).Invoke_O__O(G__107000093__4_) }; return tmp3.Invoke_O__O(tmp4) } else {
//line :313:1
			return and__1927000168__auto____2 } }


func A_arbace_spec_test_alpha_instrumentable_syms_A_New() *A_arbace_spec_test_alpha_instrumentable_syms_A { A_arbace_spec_test_alpha_instrumentable_syms_A_Init(); t := &A_arbace_spec_test_alpha_instrumentable_syms_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Ctor() {}
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Invoke_O_O__O(self, opts__0 any) any {




	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_143; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_144; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_26; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_119; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(opts__0)))) { } else { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_225, Lit_226, Lit_227, nil); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_18; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_145; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp10.Invoke_O__O(tmp11))).Ref()))) }
	var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_141; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_20; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp16 = lang.PersistentHashSet_EMPTY; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_60; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_146; var tmp21 any = jrt.NN(tmp20).GetRawRoot__O(); var tmp22 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp22 = A_arbace_spec_test_alpha_A_const_26; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp24 = A_arbace_spec_test_alpha_A_const_147; var tmp25 any = tmp19.Invoke_O_O__O(tmp21, tmp23.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke__O())); var tmp26 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp26 = A_arbace_spec_test_alpha_A_const_26; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp28 = A_arbace_spec_test_alpha_A_const_82; var tmp29 any = tmp27.Invoke_O__O(jrt.NN(tmp28).Invoke_O__O(opts__0)); var tmp30 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp30 = A_arbace_spec_test_alpha_A_const_120; var tmp31 any = jrt.NN(tmp30).Invoke_O__O(opts__0); var tmp32 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp32 = A_arbace_spec_test_alpha_A_const_26; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp34 = A_arbace_spec_test_alpha_A_const_121; return tmp13.Invoke_O_O_O__O(tmp15, tmp17, lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp25, tmp29, tmp31, tmp33.Invoke_O__O(jrt.NN(tmp34).Invoke_O__O(opts__0)))) }
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_148; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(nil)
}






func A_arbace_spec_test_alpha_instrument_A_New() *A_arbace_spec_test_alpha_instrument_A { A_arbace_spec_test_alpha_instrument_A_Init(); t := &A_arbace_spec_test_alpha_instrument_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Ctor() {}
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O_O_O__O(self, sym_or_syms__0, opts__1 any) any { var lockee__1927000360__auto____3 any; var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_134; lockee__1927000360__auto____3 = jrt.NN(tmp1).GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____6); var tmp2 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








































	{ var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_20; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_59; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_60; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_148; var tmp12 any = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(opts__1)); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_149; var tmp14 any = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke__O(); var tmp15 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_23; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any = A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(opts__1); var tmp18 *jrt.Class; A_arbace_spec_test_alpha_instrument_fn__107000097_A_Init(); tmp18 = A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class; var tmp19 any = tmp16.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil)); var tmp20 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_150; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp22 = A_arbace_spec_test_alpha_A_const_152; var tmp23 any = tmp8.Invoke_O_O_O_O__O(tmp12, tmp14, tmp19, tmp21.Invoke_O__O(jrt.NN(tmp22).GetRawRoot__O())); var tmp24 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp24 = A_arbace_spec_test_alpha_A_const_22; tmp2 = tmp4.Invoke_O_O_O__O(tmp6, tmp23, lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(sym_or_syms__0)) }
//line :327:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____6); if tmp25 != nil { panic(tmp25) }; return tmp2 }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O_O__O(self, sym_or_syms__0 any) any {





































	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_153; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(sym_or_syms__0, nil) }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O__O(self any) any {




































	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_153; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_148; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O())
}






func A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(p0 any) *A_arbace_spec_test_alpha_instrument_fn__107000097_A { A_arbace_spec_test_alpha_instrument_fn__107000097_A_Init(); t := &A_arbace_spec_test_alpha_instrument_fn__107000097_A{}; t.Ctor_O(p0); return t }
//line :372:1
func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :372:1
func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Invoke_O_O__O(self, p1__107000096_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_151; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__107000096_SHARP___1, t.F_opts) }



func A_arbace_spec_test_alpha_unstrument_A_New() *A_arbace_spec_test_alpha_unstrument_A { A_arbace_spec_test_alpha_unstrument_A_Init(); t := &A_arbace_spec_test_alpha_unstrument_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Ctor() {}
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Invoke_O_O__O(self, sym_or_syms__0 any) any { var lockee__1927000360__auto____2 any; var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_134; lockee__1927000360__auto____2 = jrt.NN(tmp1).GetRawRoot__O(); var locklocal__1927000361__auto____5 any = lockee__1927000360__auto____2; lang.Compiler_Evaluator_MonitorEnter_O__V(locklocal__1927000361__auto____5); var tmp2 any; tmp22 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_20; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.PersistentVector; lang.PersistentVector_Init(); tmp5 = lang.PersistentVector_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_59; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_60; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_16; var tmp12 any = tmp10.Invoke_O__O(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_23; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_154; var tmp16 any = tmp14.Invoke_O__O(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_150; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_152; var tmp20 any = tmp8.Invoke_O_O_O__O(tmp12, tmp16, tmp18.Invoke_O__O(jrt.NN(tmp19).GetRawRoot__O())); var tmp21 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_22; tmp2 = tmp4.Invoke_O_O_O__O(tmp6, tmp20, lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(sym_or_syms__0)) }
//line :376:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V(locklocal__1927000361__auto____5); if tmp22 != nil { panic(tmp22) }; return tmp2 }
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Invoke_O__O(self any) any {



	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_155; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_23; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_133; var tmp6 any = jrt.NN(tmp5).GetRawRoot__O(); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_26; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_10; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_134; return tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp6, tmp8.Invoke_O__O(tmp10.Invoke_O__O(jrt.NN(tmp11).GetRawRoot__O()))))
}










func A_arbace_spec_test_alpha_explain_check_A_New() *A_arbace_spec_test_alpha_explain_check_A { A_arbace_spec_test_alpha_explain_check_A_Init(); t := &A_arbace_spec_test_alpha_explain_check_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_spec_test_alpha_explain_check_A) Ctor() {}
//line :392:1
func (t *A_arbace_spec_test_alpha_explain_check_A) Invoke_O_O_O_O_O__O(self, args__0, spec__1, v__2, role__3 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_66; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Var

	A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_156; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O_O_O__O(spec__1, v__2, nil)) { tmp3 = nil } else {
		var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_68; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_71; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = lang.Tuple_Create_O__IPersistentVector(role__3); var tmp10 *lang.PersistentVector; lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; var tmp11 any = tmp10.Ref(); var tmp12 *lang.PersistentVector; lang.PersistentVector_Init(); tmp12 = lang.PersistentVector_EMPTY; var tmp13 any = tmp8.Invoke_O_O_O_O_O__O(spec__1, tmp9, tmp11, tmp12.Ref(), v__2); var tmp14 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_157; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_158; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_74; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp20 = A_arbace_spec_test_alpha_A_const_159; tmp3 = tmp6.Invoke_O_O_O_O_O_O_O__O(tmp13, tmp15, args__0, tmp17, v__2, tmp19, tmp20.Ref()) }
//line :394:1
	return tmp2.Invoke_O_O__O(Lit_211, tmp3)
}






func A_arbace_spec_test_alpha_check_call_A_New() *A_arbace_spec_test_alpha_check_call_A { A_arbace_spec_test_alpha_check_call_A_Init(); t := &A_arbace_spec_test_alpha_check_call_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_spec_test_alpha_check_call_A) Ctor() {}
//line :402:1
func (t *A_arbace_spec_test_alpha_check_call_A) Invoke_O_O_O_O__O(self, f__0, specs__1, args__2 any) any { var cargs__4 any; var tmp1 *lang.Keyword;



	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_28; if jrt.A2g_Truth(jrt.NN(tmp1).Invoke_O__O(specs__1)) { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_64; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_28; cargs__4 = tmp3.Invoke_O_O__O(jrt.NN(tmp4).Invoke_O__O(specs__1), args__2) } else { cargs__4 = nil }; var tmp5 /*line :407:1*/*lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_65; if lang.Util_Equiv_O_O__Z(cargs__4, tmp5.Ref()) {
		var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_160; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_28; var tmp9 any = jrt.NN(tmp8).Invoke_O__O(specs__1); var tmp10 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_28; return tmp7.Invoke_O_O_O_O__O(args__2, tmp9, args__2, tmp10.Ref()) } else {
//line :407:1
			var ret__5 any; var tmp11 *lang.Var

			A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_33; ret__5 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O__O(f__0, args__2)
//line :407:1
			var cret__6 any; var tmp12 *lang.Keyword


			A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_29; if jrt.A2g_Truth(jrt.NN(tmp12).Invoke_O__O(specs__1)) { var tmp13 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_64; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_29; cret__6 = tmp14.Invoke_O_O__O(jrt.NN(tmp15).Invoke_O__O(specs__1), ret__5) } else { cret__6 = nil }
			var tmp16 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_65; if lang.Util_Equiv_O_O__Z(cret__6, tmp16.Ref()) {
				var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_160; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_29; var tmp20 any = jrt.NN(tmp19).Invoke_O__O(specs__1); var tmp21 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_29; return tmp18.Invoke_O_O_O_O__O(args__2, tmp20, ret__5, tmp21.Ref()) } else {
					var tmp22 any; var and__1927000168__auto____7 any; var tmp23 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_28; and__1927000168__auto____7 = jrt.NN(tmp23).Invoke_O__O(specs__1); if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp24 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp24 = A_arbace_spec_test_alpha_A_const_29; and__1927000168__auto____8 = jrt.NN(tmp24).Invoke_O__O(specs__1); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp25 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp25 = A_arbace_spec_test_alpha_A_const_161; tmp22 = jrt.NN(tmp25).Invoke_O__O(specs__1) } else { tmp22 = and__1927000168__auto____8 } } else { tmp22 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp22) {
						var tmp26 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp26 = A_arbace_spec_test_alpha_A_const_156; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp28 = A_arbace_spec_test_alpha_A_const_161; var tmp29 any = jrt.NN(tmp28).Invoke_O__O(specs__1); var tmp30 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp30 = A_arbace_spec_test_alpha_A_const_28; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp32 = A_arbace_spec_test_alpha_A_const_29; if jrt.A2g_Truth(tmp27.Invoke_O_O__O(tmp29, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, cargs__4, tmp32.Ref(), cret__6)))) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else {

							var tmp33 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp33 = A_arbace_spec_test_alpha_A_const_160; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp35 = A_arbace_spec_test_alpha_A_const_161; var tmp36 any = jrt.NN(tmp35).Invoke_O__O(specs__1); var tmp37 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp37 = A_arbace_spec_test_alpha_A_const_28; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp39 = A_arbace_spec_test_alpha_A_const_29; var tmp40 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp38, cargs__4, tmp39.Ref(), cret__6)); var tmp41 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp41 = A_arbace_spec_test_alpha_A_const_161; return tmp34.Invoke_O_O_O_O__O(args__2, tmp36, tmp40, tmp41.Ref()) } } else {
//line :413:1
								jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } } }





func A_arbace_spec_test_alpha_quick_check_A_New() *A_arbace_spec_test_alpha_quick_check_A { A_arbace_spec_test_alpha_quick_check_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_spec_test_alpha_quick_check_A) Ctor() {}
//line :419:1
func (t *A_arbace_spec_test_alpha_quick_check_A) Invoke_O_O_O_O__O(self, f__0, specs__1, p__107000104__2 any) any { var map__107000105__4 any = p__107000104__2; var map__107000105__5 any; if lang.ISeq_InstanceOf(map__107000105__4) { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__107000105__4)) { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_55; map__107000105__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__107000105__4), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__107000105__4)) { var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_56; map__107000105__5 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__107000105__4) } else { lang.PersistentArrayMap_Init(); map__107000105__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000105__5 = map__107000105__4 }; var gen__6 any; var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_119; gen__6 = lang.RT_Get_O_O__O(map__107000105__5, tmp5.Ref()); var opts__7 any; var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_162; opts__7 = lang.RT_Get_O_O__O(map__107000105__5, tmp6.Ref()); var default__107000109__8 int64 = 1000; var map__107000107__9 any = opts__7; var map__107000107__10 any; if

	lang.ISeq_InstanceOf(map__107000107__9) { var tmp7 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(map__107000107__9)) { var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_55; map__107000107__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(map__107000107__9), jrt.Object_class.ArrayClass())).Ref() } else { var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(map__107000107__9)) { var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_56; map__107000107__10 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(map__107000107__9) } else { lang.PersistentArrayMap_Init(); map__107000107__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000107__10 = map__107000107__9 }; var num_tests__11 any; var tmp11 /*line :419:1*/*lang.Keyword;

	A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_163; var tmp12 any = tmp11.Ref(); num_tests__11 = lang.RT_Get_O_O_O__O(map__107000107__10, tmp12, jrt.Long_ValueOf_J__Long(default__107000109__8).Ref()); var g__12 any; var tmp13 any = /*line :419:1*/A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(gen__6, specs__1); var tmp14 *jrt.Class;


	A_arbace_spec_test_alpha_quick_check_fn__107000111_A_Init(); tmp14 = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class; g__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil).Invoke__O(); var tmp15 /*line :423:1*/*lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_164; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(g__12)) { var tmp16 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_165; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16.Ref(), g__12)) } else { var prop__13 any; var tmp17 *lang.Var

		A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_166; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 any = lang.Tuple_Create_O__IPersistentVector(g__12); var tmp20 any = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(f__0, specs__1); var tmp21 *jrt.Class; A_arbace_spec_test_alpha_quick_check_fn__107000113_A_Init(); tmp21 = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class; prop__13 = tmp18.Invoke_O_O__O(tmp19, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil))
		var tmp22 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp22 = A_arbace_spec_test_alpha_A_const_33; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp24 = A_arbace_spec_test_alpha_A_const_168; var tmp25 any = jrt.NN(tmp24).GetRawRoot__O(); var tmp26 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp26 = A_arbace_spec_test_alpha_A_const_21; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp28 = A_arbace_spec_test_alpha_A_const_169; return tmp23.Invoke_O_O_O_O__O(tmp25, num_tests__11, prop__13, tmp27.Invoke_O_O__O(jrt.NN(tmp28).GetRawRoot__O(), opts__7)) } }
//line :422:1
func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(p0, p1 any) *A_arbace_spec_test_alpha_quick_check_fn__107000111_A { A_arbace_spec_test_alpha_quick_check_fn__107000111_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_fn__107000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :422:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Ctor_O_O(c__gen, c__specs any) { t.F_gen = c__gen; t.F_specs = c__specs }
//line :422:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Invoke_O__O(self any) any { var tmp1 any; tmp9 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_123; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_28; var tmp5 *lang.Keyword = tmp4; var tmp6 any; var t_ any = t.F_specs; t.F_specs = nil; tmp6 = t_; var tmp7 any = jrt.NN(tmp5).Invoke_O__O(tmp6); var tmp8 any; var t__2 any = t.F_gen; t.F_gen = nil; tmp8 = t__2; tmp1 = tmp3.Invoke_O_O__O(tmp7, tmp8) }; return nil }(); if tmp9 != nil { if true { var t__3 jrt.Throwable_I = tmp9; tmp1 = t__3 } }; return tmp1 }


func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(p0, p1 any) *A_arbace_spec_test_alpha_quick_check_fn__107000113_A { A_arbace_spec_test_alpha_quick_check_fn__107000113_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_fn__107000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :425:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Ctor_O_O(c__f, c__specs any) { t.F_f = c__f; t.F_specs = c__specs }
//line :425:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Invoke_O_O__O(self, p1__107000103_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_167; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(t.F_f, t.F_specs, p1__107000103_SHARP___1) }


func A_arbace_spec_test_alpha_make_check_result_A_New() *A_arbace_spec_test_alpha_make_check_result_A { A_arbace_spec_test_alpha_make_check_result_A_Init(); t := &A_arbace_spec_test_alpha_make_check_result_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_spec_test_alpha_make_check_result_A) Ctor() {}
//line :428:1
func (t *A_arbace_spec_test_alpha_make_check_result_A) Invoke_O_O_O_O__O(self, check_sym__0, spec__1, test_check_ret__2 any) any {


	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_40; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_82; var tmp4 any = tmp3.Ref(); var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_170; var tmp6 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, spec__1, tmp5.Ref(), test_check_ret__2)); var tmp7 lang.IPersistentMap

	if jrt.A2g_Truth(check_sym__0) { var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_171; tmp7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp8.Ref(), check_sym__0)) } else { tmp7 = nil }
//line :431:1
	var tmp9 any = tmp7; var tmp10 lang.IPersistentMap; var temp__1927000414__auto____4 any; var tmp11 *lang.Keyword



	A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_165; temp__1927000414__auto____4 = jrt.NN(tmp11).Invoke_O__O(test_check_ret__2); if jrt.A2g_Truth(temp__1927000414__auto____4) { var result__5 any = temp__1927000414__auto____4; var tmp12 *lang.Var
		A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_172; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(result__5)) { tmp10 = nil } else { var tmp13 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_173; tmp10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13.Ref(), result__5)) } } else {
//line :435:1
			tmp10 = nil }
//line :431:1
	var tmp14 any = tmp10; var tmp15 lang.IPersistentMap; var temp__1927000414__auto____4_2 any; var tmp16 *lang.Keyword





	A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_174; temp__1927000414__auto____4_2 = jrt.NN(tmp16).Invoke_O__O(test_check_ret__2); if jrt.A2g_Truth(temp__1927000414__auto____4_2) { var shrunk__5 any = temp__1927000414__auto____4_2; var tmp17 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_173; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_165; tmp15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp18, jrt.NN(tmp19).Invoke_O__O(shrunk__5))) } else { tmp15 = nil }
//line :431:1
	return tmp2.Invoke_O_O_O_O__O(tmp6, tmp9, tmp14, tmp15)
}







func A_arbace_spec_test_alpha_check_1_A_New() *A_arbace_spec_test_alpha_check_1_A { A_arbace_spec_test_alpha_check_1_A_Init(); t := &A_arbace_spec_test_alpha_check_1_A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_spec_test_alpha_check_1_A) Ctor() {}
//line :440:1
func (t *A_arbace_spec_test_alpha_check_1_A) Invoke_O_O_O__O(self, p__107000117__0, opts__1 any) any { var map__107000118__3 any = p__107000117__0; var map__107000118__4 any; if lang.ISeq_InstanceOf(map__107000118__3) { var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_54; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__107000118__3)) { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_55; map__107000118__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__107000118__3), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__107000118__3)) { var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_56; map__107000118__4 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__107000118__3) } else { lang.PersistentArrayMap_Init(); map__107000118__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000118__4 = map__107000118__3 }; var s__5 any; var tmp5 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_175; s__5 = lang.RT_Get_O_O__O(map__107000118__4, tmp5.Ref()); var f__6 any; var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_176; f__6 = lang.RT_Get_O_O__O(map__107000118__4, tmp6.Ref()); var v__7 any; var tmp7 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_177; v__7 = lang.RT_Get_O_O__O(map__107000118__4, tmp7.Ref()); var spec__8 any; var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_82; spec__8 = lang.RT_Get_O_O__O(map__107000118__4, tmp8.Ref()); var re_inst_QMARK___9 any; var and__1927000168__auto____9 any = v__7; if

	jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_30; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_155; and__1927000168__auto____10 = tmp10.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(s__5)); if jrt.A2g_Truth(and__1927000168__auto____10) { jrt.Boolean_Init(); re_inst_QMARK___9 = jrt.Boolean_TRUE.Ref() } else { re_inst_QMARK___9 = and__1927000168__auto____10 } } else { re_inst_QMARK___9 = and__1927000168__auto____9 }; var f__10 any; var or__1927000174__auto____10 any = f__6; if
	jrt.A2g_Truth(or__1927000174__auto____10) { f__10 = or__1927000174__auto____10 } else { if jrt.A2g_Truth(v__7) { var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_10; f__10 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(v__7) } else { f__10 = nil } }; var specd__11 any; var tmp13 /*line :440:1*/*lang.Var;



	A_arbace_spec_test_alpha_A_Init(); tmp13 = A_arbace_spec_test_alpha_A_const_178; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; A_arbace_spec_test_alpha_A_Init(); tmp15 = A_arbace_spec_test_alpha_A_const_181; specd__11 = tmp14.Invoke_O_O_O_O__O(tmp15, spec__8, nil, nil); var tmp16 any; tmp41 := /*line :440:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		{ var tmp17 any; var or__1927000174__auto____14 bool = lang.Util_Identical_O_O__Z(f__10, nil)
			if or__1927000174__auto____14 { tmp17 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____14).Ref() } else { var G__107000120__15_ any = v__7; var G__107000120__16_ any; if lang.Util_Identical_O_O__Z(G__107000120__15_, nil) { G__107000120__16_ = nil } else { G__107000120__16_ = lang.RT_Meta_O__IPersistentMap(G__107000120__15_) }; if lang.Util_Identical_O_O__Z(G__107000120__16_, nil) { tmp17 = nil } else { var tmp18 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_124; tmp17 = jrt.NN(tmp18).Invoke_O__O(G__107000120__16_) } }
//line :446:1
			if jrt.A2g_Truth(tmp17) { var tmp19 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_173; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_66; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any; A_arbace_spec_test_alpha_A_Init(); tmp23 = A_arbace_spec_test_alpha_A_const_182; var tmp24 any = tmp22.Invoke_O_O__O(Lit_199, tmp23); var tmp25 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp25 = A_arbace_spec_test_alpha_A_const_171; var tmp26 any = tmp25.Ref(); var tmp27 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp27 = A_arbace_spec_test_alpha_A_const_82; tmp16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, tmp24, tmp26, s__5, tmp27.Ref(), spec__8)) } else { var tmp28 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp28 = A_arbace_spec_test_alpha_A_const_28; if jrt.A2g_Truth(jrt.NN(tmp28).Invoke_O__O(specd__11)) { var tcret__14 any; var tmp29 *lang.Var





				A_arbace_spec_test_alpha_A_Init(); tmp29 = A_arbace_spec_test_alpha_A_const_179; tcret__14 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O_O_O__O(f__10, specd__11, opts__1)
				var tmp30 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp30 = A_arbace_spec_test_alpha_A_const_180; tmp16 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O_O_O__O(s__5, spec__8, tcret__14) } else {
//line :446:1
					var tmp31 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp31 = A_arbace_spec_test_alpha_A_const_113; if tmp31 != nil { var tmp32 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp32 = A_arbace_spec_test_alpha_A_const_173; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp34 = A_arbace_spec_test_alpha_A_const_66; var tmp35 lang.IFn = lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()); var tmp36 any; A_arbace_spec_test_alpha_A_Init(); tmp36 = A_arbace_spec_test_alpha_A_const_183; var tmp37 any = tmp35.Invoke_O_O__O(Lit_200, tmp36); var tmp38 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp38 = A_arbace_spec_test_alpha_A_const_171; var tmp39 any = tmp38.Ref(); var tmp40 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp40 = A_arbace_spec_test_alpha_A_const_82; tmp16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp37, tmp39, s__5, tmp40.Ref(), spec__8)) } else { tmp16 = nil } } } }
//line :440:1
		return nil }(); if


















	jrt.A2g_Truth(re_inst_QMARK___9) { var tmp42 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp42 = A_arbace_spec_test_alpha_A_const_153; lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(s__5) }; if /*line :440:1*/ tmp41 != nil { panic(tmp41) }; return tmp16 }




















func A_arbace_spec_test_alpha_sym__GT_check_map_A_New() *A_arbace_spec_test_alpha_sym__GT_check_map_A { A_arbace_spec_test_alpha_sym__GT_check_map_A_Init(); t := &A_arbace_spec_test_alpha_sym__GT_check_map_A{}; t.Ctor(); return t }
//line :461:1
func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Ctor() {}
//line :461:1
func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Invoke_O_O__O(self, s__0 any) any { var v__2 any; var tmp1 *lang.Var;

	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_17; v__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__0); var tmp2 /*line :461:1*/*lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_175; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_177; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_82; var tmp7 any = tmp6.Ref(); var tmp8 any; if




	jrt.A2g_Truth(v__2) { var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_125; tmp8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(v__2) } else { tmp8 = nil }; return /*line :461:1*/ lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, s__0, tmp5, v__2, tmp7, tmp8)) }






func A_arbace_spec_test_alpha_validate_check_opts_A_New() *A_arbace_spec_test_alpha_validate_check_opts_A { A_arbace_spec_test_alpha_validate_check_opts_A_Init(); t := &A_arbace_spec_test_alpha_validate_check_opts_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Ctor() {}
//line :468:1
func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Invoke_O_O__O(self, opts__0 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_143; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_144; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp5 = A_arbace_spec_test_alpha_A_const_26; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp7 = A_arbace_spec_test_alpha_A_const_119; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(tmp4, tmp6.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(opts__0)))) { return nil } else { var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_225, Lit_260, Lit_227, nil); var tmp9 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp9 = A_arbace_spec_test_alpha_A_const_18; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; A_arbace_spec_test_alpha_A_Init(); tmp11 = A_arbace_spec_test_alpha_A_const_184; panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, tmp10.Invoke_O__O(tmp11))).Ref())))
	} }
func A_arbace_spec_test_alpha_check_fn_A_New() *A_arbace_spec_test_alpha_check_fn_A { A_arbace_spec_test_alpha_check_fn_A_Init(); t := &A_arbace_spec_test_alpha_check_fn_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Ctor() {}
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Invoke_O_O_O_O__O(self, f__0, spec__1, opts__2 any) any {




	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_186; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(opts__2)
	var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_185; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_176; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_82; return tmp3.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, f__0, tmp6.Ref(), spec__1)), opts__2) }
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Invoke_O_O_O__O(self, f__0, spec__1 any) any {


	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_187; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(f__0, spec__1, nil)
}



func A_arbace_spec_test_alpha_checkable_syms_A_New() *A_arbace_spec_test_alpha_checkable_syms_A { A_arbace_spec_test_alpha_checkable_syms_A_Init(); t := &A_arbace_spec_test_alpha_checkable_syms_A{}; t.Ctor(); return t }
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Ctor() {}
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Invoke_O_O__O(self, opts__0 any) any {




	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_186; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(opts__0)
	var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_141; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_20; var tmp5 any = jrt.NN(tmp4).GetRawRoot__O(); var tmp6 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp6 = lang.PersistentHashSet_EMPTY; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_60; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_146; var tmp11 any = jrt.NN(tmp10).GetRawRoot__O(); var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_26; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_147; var tmp15 any = tmp9.Invoke_O_O__O(tmp11, tmp13.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke__O())); var tmp16 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_26; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp18 = A_arbace_spec_test_alpha_A_const_82; return tmp3.Invoke_O_O_O__O(tmp5, tmp7, lang.Tuple_Create_O_O__IPersistentVector(tmp15, tmp17.Invoke_O__O(jrt.NN(tmp18).Invoke_O__O(opts__0)))) }
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Invoke_O__O(self any) any {


	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_188; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(nil)
}




func A_arbace_spec_test_alpha_check_A_New() *A_arbace_spec_test_alpha_check_A { A_arbace_spec_test_alpha_check_A_Init(); t := &A_arbace_spec_test_alpha_check_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Ctor() {}
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O_O_O__O(self, sym_or_syms__0, opts__1 any) any {





































	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_189; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(opts__1); var tmp4 *jrt.Class; A_arbace_spec_test_alpha_check_fn__107000127_A_Init(); tmp4 = A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_60; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_188; var tmp9 any = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(opts__1); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_22; return tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp9, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(sym_or_syms__0))) }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O_O__O(self, sym_or_syms__0 any) any {

































	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_191; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(sym_or_syms__0, nil) }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O__O(self any) any {
































	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_191; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_188; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke__O())
}



func A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(p0 any) *A_arbace_spec_test_alpha_check_fn__107000127_A { A_arbace_spec_test_alpha_check_fn__107000127_A_Init(); t := &A_arbace_spec_test_alpha_check_fn__107000127_A{}; t.Ctor_O(p0); return t }
//line :527:1
func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :527:1
func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Invoke_O_O__O(self, p1__107000126_SHARP___1 any) any {
	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_185; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_190; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__107000126_SHARP___1), t.F_opts)
}


func A_arbace_spec_test_alpha_failure_type_A_New() *A_arbace_spec_test_alpha_failure_type_A { A_arbace_spec_test_alpha_failure_type_A_Init(); t := &A_arbace_spec_test_alpha_failure_type_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_spec_test_alpha_failure_type_A) Ctor() {}
//line :532:1
func (t *A_arbace_spec_test_alpha_failure_type_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_74; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_192; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(x__0))
}
func A_arbace_spec_test_alpha_unwrap_failure_A_New() *A_arbace_spec_test_alpha_unwrap_failure_A { A_arbace_spec_test_alpha_unwrap_failure_A_Init(); t := &A_arbace_spec_test_alpha_unwrap_failure_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Ctor() {}
//line :536:1
func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_193; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0)) {
		var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_192; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :538:1
			return x__0
		}
}

func A_arbace_spec_test_alpha_result_type_A_New() *A_arbace_spec_test_alpha_result_type_A { A_arbace_spec_test_alpha_result_type_A_Init(); t := &A_arbace_spec_test_alpha_result_type_A{}; t.Ctor(); return t }
//line :542:1
func (t *A_arbace_spec_test_alpha_result_type_A) Ctor() {}
//line :542:1
func (t *A_arbace_spec_test_alpha_result_type_A) Invoke_O_O__O(self, ret__0 any) any { var failure__2 any; var tmp1 *lang.Keyword;






	A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_173; failure__2 = jrt.NN(tmp1).Invoke_O__O(ret__0); if
	lang.Util_Identical_O_O__Z(failure__2, nil) { A_arbace_spec_test_alpha_A_Init(); return A_arbace_spec_test_alpha_A_const_194.Ref() } else { var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_193; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(failure__2)) {

		var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_193; return lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(failure__2) } else {
//line :550:1
			var tmp4 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_113; if tmp4 != nil { A_arbace_spec_test_alpha_A_Init(); return A_arbace_spec_test_alpha_A_const_195.Ref() } else { return nil } } } }




func A_arbace_spec_test_alpha_abbrev_result_A_New() *A_arbace_spec_test_alpha_abbrev_result_A { A_arbace_spec_test_alpha_abbrev_result_A_Init(); t := &A_arbace_spec_test_alpha_abbrev_result_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_spec_test_alpha_abbrev_result_A) Ctor() {}
//line :555:1
func (t *A_arbace_spec_test_alpha_abbrev_result_A) Invoke_O_O__O(self, x__0 any) any {



	var tmp1 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_173; if jrt.A2g_Truth(jrt.NN(tmp1).Invoke_O__O(x__0)) {


		var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_196; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_196; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_70; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_170; var tmp9 any = tmp7.Invoke_O_O__O(x__0, tmp8.Ref()); var tmp10 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_82; var tmp11 any = tmp10.Ref(); var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_198; var tmp13 any = tmp5.Invoke_O_O_O__O(tmp9, tmp11, jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_173; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_197; return tmp3.Invoke_O_O_O__O(tmp13, tmp15, jrt.NN(tmp16).GetRawRoot__O()) } else {
			var tmp17 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp17 = A_arbace_spec_test_alpha_A_const_70; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp19 = A_arbace_spec_test_alpha_A_const_82; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp21 = A_arbace_spec_test_alpha_A_const_170; return tmp18.Invoke_O_O_O__O(x__0, tmp20, tmp21.Ref())
		} }
func A_arbace_spec_test_alpha_summarize_results_A_New() *A_arbace_spec_test_alpha_summarize_results_A { A_arbace_spec_test_alpha_summarize_results_A_Init(); t := &A_arbace_spec_test_alpha_summarize_results_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Ctor() {}
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Invoke_O_O_O__O(self, check_results__0, summary_result__1 any) any {







	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_141; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(summary_result__1); var tmp4 *jrt.Class; A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_Init(); tmp4 = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_205; return tmp2.Invoke_O_O_O__O(tmp5, tmp6, check_results__0) }
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Invoke_O_O__O(self, check_results__0 any) any {





	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_206; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp3 = A_arbace_spec_test_alpha_A_const_207; return tmp2.Invoke_O_O__O(check_results__0, jrt.NN(tmp3).GetRawRoot__O())
}

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(p0 any) *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A { A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_Init(); t := &A_arbace_spec_test_alpha_summarize_results_fn__107000134_A{}; t.Ctor_O(p0); return t }
//line :574:1
func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Ctor_O(c__summary_result any) { t.F_summary_result = c__summary_result }
//line :574:1
func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Invoke_O_O_O__O(self, summary__1, result__2 any) any {
	var tmp1 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp1 = A_arbace_spec_test_alpha_A_const_199; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_summary_result).Invoke_O__O(result__2))


	var tmp2 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp2 = A_arbace_spec_test_alpha_A_const_196; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp4 = A_arbace_spec_test_alpha_A_const_196; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_spec_test_alpha_A_Init(); tmp6 = A_arbace_spec_test_alpha_A_const_202; var tmp7 any = tmp6.Ref(); var tmp8 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp8 = A_arbace_spec_test_alpha_A_const_203; var tmp9 any = tmp5.Invoke_O_O_O__O(summary__1, tmp7, jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp10 = A_arbace_spec_test_alpha_A_const_200; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(result__2); var tmp12 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp12 = A_arbace_spec_test_alpha_A_const_201; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_spec_test_alpha_A_Init(); tmp14 = A_arbace_spec_test_alpha_A_const_203; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 any; A_arbace_spec_test_alpha_A_Init(); tmp16 = A_arbace_spec_test_alpha_A_const_204; return tmp3.Invoke_O_O_O__O(tmp9, tmp11, tmp13.Invoke_O_O__O(tmp15, tmp16))
}


type A_arbace_spec_test_alpha_A struct{ jrt.Object }

var A_arbace_spec_test_alpha_A_const_0 *lang.Var

var A_arbace_spec_test_alpha_A_const_1 *lang.Var

var A_arbace_spec_test_alpha_A_const_2 any

var A_arbace_spec_test_alpha_A_const_3 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_4 any

var A_arbace_spec_test_alpha_A_const_5 any

var A_arbace_spec_test_alpha_A_const_6 any

var A_arbace_spec_test_alpha_A_const_7 any

var A_arbace_spec_test_alpha_A_const_8 any

var A_arbace_spec_test_alpha_A_const_9 *lang.Var

var A_arbace_spec_test_alpha_A_const_10 *lang.Var

var A_arbace_spec_test_alpha_A_const_11 *lang.Var

var A_arbace_spec_test_alpha_A_const_12 any

var A_arbace_spec_test_alpha_A_const_13 *lang.Var

var A_arbace_spec_test_alpha_A_const_14 *lang.Var

var A_arbace_spec_test_alpha_A_const_15 *lang.Var

var A_arbace_spec_test_alpha_A_const_16 *lang.Var

var A_arbace_spec_test_alpha_A_const_17 *lang.Var

var A_arbace_spec_test_alpha_A_const_18 *lang.Var

var A_arbace_spec_test_alpha_A_const_19 *lang.Var

var A_arbace_spec_test_alpha_A_const_20 *lang.Var

var A_arbace_spec_test_alpha_A_const_21 *lang.Var

var A_arbace_spec_test_alpha_A_const_22 *lang.Var

var A_arbace_spec_test_alpha_A_const_23 *lang.Var

var A_arbace_spec_test_alpha_A_const_24 *lang.Var

var A_arbace_spec_test_alpha_A_const_25 *lang.Var

var A_arbace_spec_test_alpha_A_const_26 *lang.Var

var A_arbace_spec_test_alpha_A_const_27 *lang.Var

var A_arbace_spec_test_alpha_A_const_28 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_29 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_30 *lang.Var

var A_arbace_spec_test_alpha_A_const_31 *lang.Var

var A_arbace_spec_test_alpha_A_const_32 any

var A_arbace_spec_test_alpha_A_const_33 *lang.Var

var A_arbace_spec_test_alpha_A_const_34 *lang.Var

var A_arbace_spec_test_alpha_A_const_35 any

var A_arbace_spec_test_alpha_A_const_36 *lang.Var

var A_arbace_spec_test_alpha_A_const_37 *lang.Var

var A_arbace_spec_test_alpha_A_const_38 *lang.Var

var A_arbace_spec_test_alpha_A_const_39 any

var A_arbace_spec_test_alpha_A_const_40 *lang.Var

var A_arbace_spec_test_alpha_A_const_41 any

var A_arbace_spec_test_alpha_A_const_42 *lang.Var

var A_arbace_spec_test_alpha_A_const_43 *lang.Var

var A_arbace_spec_test_alpha_A_const_44 any

var A_arbace_spec_test_alpha_A_const_45 any

var A_arbace_spec_test_alpha_A_const_46 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_47 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_48 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_49 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_50 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_51 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_52 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_53 *lang.Var

var A_arbace_spec_test_alpha_A_const_54 *lang.Var

var A_arbace_spec_test_alpha_A_const_55 *lang.Var

var A_arbace_spec_test_alpha_A_const_56 *lang.Var

var A_arbace_spec_test_alpha_A_const_57 any

var A_arbace_spec_test_alpha_A_const_58 *lang.Var

var A_arbace_spec_test_alpha_A_const_59 *lang.Var

var A_arbace_spec_test_alpha_A_const_60 *lang.Var

var A_arbace_spec_test_alpha_A_const_61 *lang.Var

var A_arbace_spec_test_alpha_A_const_62 *lang.Var

var A_arbace_spec_test_alpha_A_const_63 *lang.Var

var A_arbace_spec_test_alpha_A_const_64 *lang.Var

var A_arbace_spec_test_alpha_A_const_65 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_66 *lang.Var

var A_arbace_spec_test_alpha_A_const_67 *lang.Var

var A_arbace_spec_test_alpha_A_const_68 *lang.Var

var A_arbace_spec_test_alpha_A_const_69 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_70 *lang.Var

var A_arbace_spec_test_alpha_A_const_71 *lang.Var

var A_arbace_spec_test_alpha_A_const_72 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_73 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_74 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_75 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_76 *lang.Var

var A_arbace_spec_test_alpha_A_const_77 *lang.Var

var A_arbace_spec_test_alpha_A_const_78 *lang.Var

var A_arbace_spec_test_alpha_A_const_79 *lang.Var

var A_arbace_spec_test_alpha_A_const_80 *lang.Var

var A_arbace_spec_test_alpha_A_const_81 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_82 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_83 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_84 *lang.Var

var A_arbace_spec_test_alpha_A_const_85 *lang.Var

var A_arbace_spec_test_alpha_A_const_86 *lang.Var

var A_arbace_spec_test_alpha_A_const_87 any

var A_arbace_spec_test_alpha_A_const_88 *lang.Var

var A_arbace_spec_test_alpha_A_const_89 *lang.Var

var A_arbace_spec_test_alpha_A_const_90 *lang.Var

var A_arbace_spec_test_alpha_A_const_91 *lang.Var

var A_arbace_spec_test_alpha_A_const_92 *lang.Var

var A_arbace_spec_test_alpha_A_const_93 *lang.Var

var A_arbace_spec_test_alpha_A_const_94 *lang.Var

var A_arbace_spec_test_alpha_A_const_95 *lang.Var

var A_arbace_spec_test_alpha_A_const_96 *lang.Var

var A_arbace_spec_test_alpha_A_const_97 *lang.Var

var A_arbace_spec_test_alpha_A_const_98 *lang.Var

var A_arbace_spec_test_alpha_A_const_99 any

var A_arbace_spec_test_alpha_A_const_100 *lang.Var

var A_arbace_spec_test_alpha_A_const_101 any

var A_arbace_spec_test_alpha_A_const_102 any

var A_arbace_spec_test_alpha_A_const_103 any

var A_arbace_spec_test_alpha_A_const_104 any

var A_arbace_spec_test_alpha_A_const_105 any

var A_arbace_spec_test_alpha_A_const_106 any

var A_arbace_spec_test_alpha_A_const_107 any

var A_arbace_spec_test_alpha_A_const_108 any

var A_arbace_spec_test_alpha_A_const_109 any

var A_arbace_spec_test_alpha_A_const_110 any

var A_arbace_spec_test_alpha_A_const_111 *lang.Var

var A_arbace_spec_test_alpha_A_const_112 *lang.Var

var A_arbace_spec_test_alpha_A_const_113 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_114 *lang.Var

var A_arbace_spec_test_alpha_A_const_115 any

var A_arbace_spec_test_alpha_A_const_116 *lang.Var

var A_arbace_spec_test_alpha_A_const_117 *lang.Var

var A_arbace_spec_test_alpha_A_const_118 *lang.Var

var A_arbace_spec_test_alpha_A_const_119 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_120 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_121 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_122 *lang.Var

var A_arbace_spec_test_alpha_A_const_123 *lang.Var

var A_arbace_spec_test_alpha_A_const_124 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_125 *lang.Var

var A_arbace_spec_test_alpha_A_const_126 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_127 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_128 *lang.Var

var A_arbace_spec_test_alpha_A_const_129 *lang.Var

var A_arbace_spec_test_alpha_A_const_130 *lang.Var

var A_arbace_spec_test_alpha_A_const_131 *lang.Var

var A_arbace_spec_test_alpha_A_const_132 *lang.Var

var A_arbace_spec_test_alpha_A_const_133 *lang.Var

var A_arbace_spec_test_alpha_A_const_134 *lang.Var

var A_arbace_spec_test_alpha_A_const_135 *lang.Var

var A_arbace_spec_test_alpha_A_const_136 *lang.Var

var A_arbace_spec_test_alpha_A_const_137 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_138 *lang.Var

var A_arbace_spec_test_alpha_A_const_139 *lang.Var

var A_arbace_spec_test_alpha_A_const_140 *lang.Var

var A_arbace_spec_test_alpha_A_const_141 *lang.Var

var A_arbace_spec_test_alpha_A_const_142 *lang.Var

var A_arbace_spec_test_alpha_A_const_143 *lang.Var

var A_arbace_spec_test_alpha_A_const_144 *lang.Var

var A_arbace_spec_test_alpha_A_const_145 any

var A_arbace_spec_test_alpha_A_const_146 *lang.Var

var A_arbace_spec_test_alpha_A_const_147 *lang.Var

var A_arbace_spec_test_alpha_A_const_148 *lang.Var

var A_arbace_spec_test_alpha_A_const_149 *lang.Var

var A_arbace_spec_test_alpha_A_const_150 *lang.Var

var A_arbace_spec_test_alpha_A_const_151 *lang.Var

var A_arbace_spec_test_alpha_A_const_152 *lang.Var

var A_arbace_spec_test_alpha_A_const_153 *lang.Var

var A_arbace_spec_test_alpha_A_const_154 *lang.Var

var A_arbace_spec_test_alpha_A_const_155 *lang.Var

var A_arbace_spec_test_alpha_A_const_156 *lang.Var

var A_arbace_spec_test_alpha_A_const_157 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_158 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_159 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_160 *lang.Var

var A_arbace_spec_test_alpha_A_const_161 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_162 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_163 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_164 *lang.Var

var A_arbace_spec_test_alpha_A_const_165 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_166 *lang.Var

var A_arbace_spec_test_alpha_A_const_167 *lang.Var

var A_arbace_spec_test_alpha_A_const_168 *lang.Var

var A_arbace_spec_test_alpha_A_const_169 *lang.Var

var A_arbace_spec_test_alpha_A_const_170 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_171 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_172 *lang.Var

var A_arbace_spec_test_alpha_A_const_173 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_174 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_175 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_176 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_177 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_178 *lang.Var

var A_arbace_spec_test_alpha_A_const_179 *lang.Var

var A_arbace_spec_test_alpha_A_const_180 *lang.Var

var A_arbace_spec_test_alpha_A_const_181 any

var A_arbace_spec_test_alpha_A_const_182 any

var A_arbace_spec_test_alpha_A_const_183 any

var A_arbace_spec_test_alpha_A_const_184 any

var A_arbace_spec_test_alpha_A_const_185 *lang.Var

var A_arbace_spec_test_alpha_A_const_186 *lang.Var

var A_arbace_spec_test_alpha_A_const_187 *lang.Var

var A_arbace_spec_test_alpha_A_const_188 *lang.Var

var A_arbace_spec_test_alpha_A_const_189 *lang.Var

var A_arbace_spec_test_alpha_A_const_190 *lang.Var

var A_arbace_spec_test_alpha_A_const_191 *lang.Var

var A_arbace_spec_test_alpha_A_const_192 *lang.Var

var A_arbace_spec_test_alpha_A_const_193 *lang.Var

var A_arbace_spec_test_alpha_A_const_194 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_195 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_196 *lang.Var

var A_arbace_spec_test_alpha_A_const_197 *lang.Var

var A_arbace_spec_test_alpha_A_const_198 *lang.Var

var A_arbace_spec_test_alpha_A_const_199 *lang.Var

var A_arbace_spec_test_alpha_A_const_200 *lang.Var

var A_arbace_spec_test_alpha_A_const_201 *lang.Var

var A_arbace_spec_test_alpha_A_const_202 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_203 *lang.Var

var A_arbace_spec_test_alpha_A_const_204 any

var A_arbace_spec_test_alpha_A_const_205 any

var A_arbace_spec_test_alpha_A_const_206 *lang.Var

var A_arbace_spec_test_alpha_A_const_207 *lang.Var

var A_arbace_spec_test_alpha_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_A_Init() { if !A_arbace_spec_test_alpha_A_init.Done() { A_arbace_spec_test_alpha_A_init.Run(A_arbace_spec_test_alpha_A_clinit) } }

func A_arbace_spec_test_alpha_A_clinit() { A_arbace_spec_test_alpha_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_spec_test_alpha_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_spec_test_alpha_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_spec_test_alpha_A_const_3 = lang.RT_Keyword_String_String__Keyword(nil, Lit_3); A_arbace_spec_test_alpha_A_const_4 = lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_4).Ref()); A_arbace_spec_test_alpha_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_spec_test_alpha_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_spec_test_alpha_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_spec_test_alpha_A_const_8 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_spec_test_alpha_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_spec_test_alpha_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_spec_test_alpha_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_spec_test_alpha_A_const_12 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref(); A_arbace_spec_test_alpha_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_spec_test_alpha_A_const_14 = lang.RT_Var_String_String__Var(Lit_8, Lit_19); A_arbace_spec_test_alpha_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_spec_test_alpha_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_21); A_arbace_spec_test_alpha_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_spec_test_alpha_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_spec_test_alpha_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_spec_test_alpha_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_spec_test_alpha_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_spec_test_alpha_A_const_22 = lang.RT_Var_String_String__Var(Lit_17, Lit_27); A_arbace_spec_test_alpha_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_spec_test_alpha_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_spec_test_alpha_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_spec_test_alpha_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_spec_test_alpha_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_spec_test_alpha_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_spec_test_alpha_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_spec_test_alpha_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_spec_test_alpha_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_spec_test_alpha_A_const_32 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_37).Ref(); A_arbace_spec_test_alpha_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_spec_test_alpha_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_spec_test_alpha_A_const_35 = lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_40).Ref(); A_arbace_spec_test_alpha_A_const_36 = lang.RT_Var_String_String__Var(Lit_12, Lit_41); A_arbace_spec_test_alpha_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_spec_test_alpha_A_const_38 = lang.RT_Var_String_String__Var(Lit_12, Lit_43); A_arbace_spec_test_alpha_A_const_39 = jrt.Pattern_Compile_String__Pattern(Lit_44).Ref(); A_arbace_spec_test_alpha_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_spec_test_alpha_A_const_41 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_46).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_47).Ref())).Ref(); A_arbace_spec_test_alpha_A_const_42 = lang.RT_Var_String_String__Var(Lit_12, Lit_48); A_arbace_spec_test_alpha_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_spec_test_alpha_A_const_44 = jrt.Pattern_Compile_String__Pattern(Lit_49).Ref(); A_arbace_spec_test_alpha_A_const_45 = jrt.Long_ValueOf_J__Long(3).Ref(); A_arbace_spec_test_alpha_A_const_46 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_spec_test_alpha_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_51); A_arbace_spec_test_alpha_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_spec_test_alpha_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_spec_test_alpha_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_spec_test_alpha_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_spec_test_alpha_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_spec_test_alpha_A_const_53 = lang.RT_Var_String_String__Var(Lit_17, Lit_57); A_arbace_spec_test_alpha_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_spec_test_alpha_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_spec_test_alpha_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_spec_test_alpha_A_const_57 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref())).Ref(); A_arbace_spec_test_alpha_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_spec_test_alpha_A_const_59 = lang.RT_Var_String_String__Var(Lit_0, Lit_63); A_arbace_spec_test_alpha_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_spec_test_alpha_A_const_61 = lang.RT_Var_String_String__Var(Lit_0, Lit_65); A_arbace_spec_test_alpha_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_spec_test_alpha_A_const_63 = lang.RT_Var_String_String__Var(Lit_17, Lit_67); A_arbace_spec_test_alpha_A_const_64 = lang.RT_Var_String_String__Var(Lit_8, Lit_68); A_arbace_spec_test_alpha_A_const_65 = lang.RT_Keyword_String_String__Keyword(Lit_8, Lit_69); A_arbace_spec_test_alpha_A_const_66 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_spec_test_alpha_A_const_67 = lang.RT_Var_String_String__Var(Lit_17, Lit_71); A_arbace_spec_test_alpha_A_const_68 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_spec_test_alpha_A_const_69 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_73); A_arbace_spec_test_alpha_A_const_70 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_spec_test_alpha_A_const_71 = lang.RT_Var_String_String__Var(Lit_8, Lit_75); A_arbace_spec_test_alpha_A_const_72 = lang.RT_Keyword_String_String__Keyword(Lit_8, Lit_76); A_arbace_spec_test_alpha_A_const_73 = lang.RT_Keyword_String_String__Keyword(Lit_8, Lit_33); A_arbace_spec_test_alpha_A_const_74 = lang.RT_Keyword_String_String__Keyword(Lit_8, Lit_77); A_arbace_spec_test_alpha_A_const_75 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_spec_test_alpha_A_const_76 = lang.RT_Var_String_String__Var(Lit_17, Lit_40); A_arbace_spec_test_alpha_A_const_77 = lang.RT_Var_String_String__Var(Lit_0, Lit_79); A_arbace_spec_test_alpha_A_const_78 = lang.RT_Var_String_String__Var(Lit_0, Lit_80); A_arbace_spec_test_alpha_A_const_79 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_spec_test_alpha_A_const_80 = lang.RT_Var_String_String__Var(Lit_8, Lit_82); A_arbace_spec_test_alpha_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); A_arbace_spec_test_alpha_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_84); A_arbace_spec_test_alpha_A_const_83 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_spec_test_alpha_A_const_84 = lang.RT_Var_String_String__Var(Lit_0, Lit_86); A_arbace_spec_test_alpha_A_const_85 = lang.RT_Var_String_String__Var(Lit_0, Lit_87); A_arbace_spec_test_alpha_A_const_86 = lang.RT_Var_String_String__Var(Lit_0, Lit_88); A_arbace_spec_test_alpha_A_const_87 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())).Ref(); A_arbace_spec_test_alpha_A_const_88 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_spec_test_alpha_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_91); A_arbace_spec_test_alpha_A_const_90 = lang.RT_Var_String_String__Var(Lit_17, Lit_92); A_arbace_spec_test_alpha_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_93); A_arbace_spec_test_alpha_A_const_92 = lang.RT_Var_String_String__Var(Lit_0, Lit_94); A_arbace_spec_test_alpha_A_const_93 = lang.RT_Var_String_String__Var(Lit_0, Lit_95); A_arbace_spec_test_alpha_A_const_94 = lang.RT_Var_String_String__Var(Lit_0, Lit_96); A_arbace_spec_test_alpha_A_const_95 = lang.RT_Var_String_String__Var(Lit_0, Lit_97); A_arbace_spec_test_alpha_A_const_96 = lang.RT_Var_String_String__Var(Lit_0, Lit_98); A_arbace_spec_test_alpha_A_const_97 = lang.RT_Var_String_String__Var(Lit_0, Lit_99); A_arbace_spec_test_alpha_A_const_98 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_spec_test_alpha_A_const_99 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref())).Ref(); A_arbace_spec_test_alpha_A_const_100 = lang.RT_Var_String_String__Var(Lit_17, Lit_101); A_arbace_spec_test_alpha_A_const_101 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(); A_arbace_spec_test_alpha_A_const_102 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_spec_test_alpha_A_const_103 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_15).Ref(); A_arbace_spec_test_alpha_A_const_104 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_83).Ref(); A_arbace_spec_test_alpha_A_const_105 = lang.Symbol_Intern_String_String__Symbol(Lit_17, Lit_102).Ref(); A_arbace_spec_test_alpha_A_const_106 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(); A_arbace_spec_test_alpha_A_const_107 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_38).Ref(); A_arbace_spec_test_alpha_A_const_108 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_76).Ref(); A_arbace_spec_test_alpha_A_const_109 = lang.Symbol_Intern_String_String__Symbol(Lit_0, Lit_76).Ref(); A_arbace_spec_test_alpha_A_const_110 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_103).Ref(); A_arbace_spec_test_alpha_A_const_111 = lang.RT_Var_String_String__Var(Lit_17, Lit_104); A_arbace_spec_test_alpha_A_const_112 = lang.RT_Var_String_String__Var(Lit_17, Lit_105); A_arbace_spec_test_alpha_A_const_113 = lang.RT_Keyword_String_String__Keyword(nil, Lit_106); A_arbace_spec_test_alpha_A_const_114 = lang.RT_Var_String_String__Var(Lit_17, Lit_107); A_arbace_spec_test_alpha_A_const_115 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_89).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref()))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(237).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(22).Ref()))); A_arbace_spec_test_alpha_A_const_116 = lang.RT_Var_String_String__Var(Lit_17, Lit_109); A_arbace_spec_test_alpha_A_const_117 = lang.RT_Var_String_String__Var(Lit_17, Lit_110); A_arbace_spec_test_alpha_A_const_118 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_spec_test_alpha_A_const_119 = lang.RT_Keyword_String_String__Keyword(nil, Lit_11); A_arbace_spec_test_alpha_A_const_120 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_spec_test_alpha_A_const_121 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_spec_test_alpha_A_const_122 = lang.RT_Var_String_String__Var(Lit_10, Lit_113); A_arbace_spec_test_alpha_A_const_123 = lang.RT_Var_String_String__Var(Lit_8, Lit_11); A_arbace_spec_test_alpha_A_const_124 = lang.RT_Keyword_String_String__Keyword(nil, Lit_114); A_arbace_spec_test_alpha_A_const_125 = lang.RT_Var_String_String__Var(Lit_8, Lit_115); A_arbace_spec_test_alpha_A_const_126 = lang.RT_Keyword_String_String__Keyword(nil, Lit_116); A_arbace_spec_test_alpha_A_const_127 = lang.RT_Keyword_String_String__Keyword(nil, Lit_117); A_arbace_spec_test_alpha_A_const_128 = lang.RT_Var_String_String__Var(Lit_17, Lit_118); A_arbace_spec_test_alpha_A_const_129 = lang.RT_Var_String_String__Var(Lit_17, Lit_85); A_arbace_spec_test_alpha_A_const_130 = lang.RT_Var_String_String__Var(Lit_17, Lit_119); A_arbace_spec_test_alpha_A_const_131 = lang.RT_Var_String_String__Var(Lit_17, Lit_61); A_arbace_spec_test_alpha_A_const_132 = lang.RT_Var_String_String__Var(Lit_17, Lit_120); A_arbace_spec_test_alpha_A_const_133 = lang.RT_Var_String_String__Var(Lit_17, Lit_19); A_arbace_spec_test_alpha_A_const_134 = lang.RT_Var_String_String__Var(Lit_17, Lit_121); A_arbace_spec_test_alpha_A_const_135 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_spec_test_alpha_A_const_136 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_spec_test_alpha_A_const_137 = lang.RT_Keyword_String_String__Keyword(nil, Lit_124); A_arbace_spec_test_alpha_A_const_138 = lang.RT_Var_String_String__Var(Lit_0, Lit_125); A_arbace_spec_test_alpha_A_const_139 = lang.RT_Var_String_String__Var(Lit_0, Lit_126); A_arbace_spec_test_alpha_A_const_140 = lang.RT_Var_String_String__Var(Lit_0, Lit_127); A_arbace_spec_test_alpha_A_const_141 = lang.RT_Var_String_String__Var(Lit_0, Lit_128); A_arbace_spec_test_alpha_A_const_142 = lang.RT_Var_String_String__Var(Lit_0, Lit_129); A_arbace_spec_test_alpha_A_const_143 = lang.RT_Var_String_String__Var(Lit_0, Lit_130); A_arbace_spec_test_alpha_A_const_144 = lang.RT_Var_String_String__Var(Lit_0, Lit_131); A_arbace_spec_test_alpha_A_const_145 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(321).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(35).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(321).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(29).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(321).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(14).Ref()))); A_arbace_spec_test_alpha_A_const_146 = lang.RT_Var_String_String__Var(Lit_17, Lit_133); A_arbace_spec_test_alpha_A_const_147 = lang.RT_Var_String_String__Var(Lit_8, Lit_134); A_arbace_spec_test_alpha_A_const_148 = lang.RT_Var_String_String__Var(Lit_17, Lit_135); A_arbace_spec_test_alpha_A_const_149 = lang.RT_Var_String_String__Var(Lit_0, Lit_136); A_arbace_spec_test_alpha_A_const_150 = lang.RT_Var_String_String__Var(Lit_0, Lit_137); A_arbace_spec_test_alpha_A_const_151 = lang.RT_Var_String_String__Var(Lit_17, Lit_138); A_arbace_spec_test_alpha_A_const_152 = lang.RT_Var_String_String__Var(Lit_0, Lit_139); A_arbace_spec_test_alpha_A_const_153 = lang.RT_Var_String_String__Var(Lit_17, Lit_78); A_arbace_spec_test_alpha_A_const_154 = lang.RT_Var_String_String__Var(Lit_17, Lit_140); A_arbace_spec_test_alpha_A_const_155 = lang.RT_Var_String_String__Var(Lit_17, Lit_141); A_arbace_spec_test_alpha_A_const_156 = lang.RT_Var_String_String__Var(Lit_8, Lit_142); A_arbace_spec_test_alpha_A_const_157 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_33); A_arbace_spec_test_alpha_A_const_158 = lang.RT_Keyword_String_String__Keyword(Lit_17, Lit_143); A_arbace_spec_test_alpha_A_const_159 = lang.RT_Keyword_String_String__Keyword(nil, Lit_144); A_arbace_spec_test_alpha_A_const_160 = lang.RT_Var_String_String__Var(Lit_17, Lit_145); A_arbace_spec_test_alpha_A_const_161 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_spec_test_alpha_A_const_162 = lang.RT_Keyword_String_String__Keyword(Lit_146, Lit_132); A_arbace_spec_test_alpha_A_const_163 = lang.RT_Keyword_String_String__Keyword(nil, Lit_147); A_arbace_spec_test_alpha_A_const_164 = lang.RT_Var_String_String__Var(Lit_17, Lit_148); A_arbace_spec_test_alpha_A_const_165 = lang.RT_Keyword_String_String__Keyword(nil, Lit_149); A_arbace_spec_test_alpha_A_const_166 = lang.RT_Var_String_String__Var(Lit_10, Lit_150); A_arbace_spec_test_alpha_A_const_167 = lang.RT_Var_String_String__Var(Lit_17, Lit_151); A_arbace_spec_test_alpha_A_const_168 = lang.RT_Var_String_String__Var(Lit_10, Lit_152); A_arbace_spec_test_alpha_A_const_169 = lang.RT_Var_String_String__Var(Lit_0, Lit_153); A_arbace_spec_test_alpha_A_const_170 = lang.RT_Keyword_String_String__Keyword(Lit_146, Lit_34); A_arbace_spec_test_alpha_A_const_171 = lang.RT_Keyword_String_String__Keyword(nil, Lit_154); A_arbace_spec_test_alpha_A_const_172 = lang.RT_Var_String_String__Var(Lit_0, Lit_155); A_arbace_spec_test_alpha_A_const_173 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_spec_test_alpha_A_const_174 = lang.RT_Keyword_String_String__Keyword(nil, Lit_156); A_arbace_spec_test_alpha_A_const_175 = lang.RT_Keyword_String_String__Keyword(nil, Lit_9); A_arbace_spec_test_alpha_A_const_176 = lang.RT_Keyword_String_String__Keyword(nil, Lit_157); A_arbace_spec_test_alpha_A_const_177 = lang.RT_Keyword_String_String__Keyword(nil, Lit_158); A_arbace_spec_test_alpha_A_const_178 = lang.RT_Var_String_String__Var(Lit_8, Lit_159); A_arbace_spec_test_alpha_A_const_179 = lang.RT_Var_String_String__Var(Lit_17, Lit_152); A_arbace_spec_test_alpha_A_const_180 = lang.RT_Var_String_String__Var(Lit_17, Lit_160); A_arbace_spec_test_alpha_A_const_181 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_84).Ref(); A_arbace_spec_test_alpha_A_const_182 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_8, Lit_77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref())); A_arbace_spec_test_alpha_A_const_183 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(Lit_8, Lit_77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref())); A_arbace_spec_test_alpha_A_const_184 = lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_130).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_131).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_31).Ref(), lang.IObj_Cast(lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_11).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_132).Ref())))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(470).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(470).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref()))))))).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_51).Ref(), jrt.Integer_ValueOf_I__Integer(470).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_108).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref()))); A_arbace_spec_test_alpha_A_const_185 = lang.RT_Var_String_String__Var(Lit_17, Lit_163); A_arbace_spec_test_alpha_A_const_186 = lang.RT_Var_String_String__Var(Lit_17, Lit_164); A_arbace_spec_test_alpha_A_const_187 = lang.RT_Var_String_String__Var(Lit_17, Lit_165); A_arbace_spec_test_alpha_A_const_188 = lang.RT_Var_String_String__Var(Lit_17, Lit_166); A_arbace_spec_test_alpha_A_const_189 = lang.RT_Var_String_String__Var(Lit_0, Lit_167); A_arbace_spec_test_alpha_A_const_190 = lang.RT_Var_String_String__Var(Lit_17, Lit_168); A_arbace_spec_test_alpha_A_const_191 = lang.RT_Var_String_String__Var(Lit_17, Lit_169); A_arbace_spec_test_alpha_A_const_192 = lang.RT_Var_String_String__Var(Lit_0, Lit_170); A_arbace_spec_test_alpha_A_const_193 = lang.RT_Var_String_String__Var(Lit_17, Lit_171); A_arbace_spec_test_alpha_A_const_194 = lang.RT_Keyword_String_String__Keyword(nil, Lit_172); A_arbace_spec_test_alpha_A_const_195 = lang.RT_Keyword_String_String__Keyword(nil, Lit_173); A_arbace_spec_test_alpha_A_const_196 = lang.RT_Var_String_String__Var(Lit_0, Lit_174); A_arbace_spec_test_alpha_A_const_197 = lang.RT_Var_String_String__Var(Lit_17, Lit_175); A_arbace_spec_test_alpha_A_const_198 = lang.RT_Var_String_String__Var(Lit_8, Lit_176); A_arbace_spec_test_alpha_A_const_199 = lang.RT_Var_String_String__Var(Lit_5, Lit_177); A_arbace_spec_test_alpha_A_const_200 = lang.RT_Var_String_String__Var(Lit_17, Lit_178); A_arbace_spec_test_alpha_A_const_201 = lang.RT_Var_String_String__Var(Lit_0, Lit_179); A_arbace_spec_test_alpha_A_const_202 = lang.RT_Keyword_String_String__Keyword(nil, Lit_180); A_arbace_spec_test_alpha_A_const_203 = lang.RT_Var_String_String__Var(Lit_0, Lit_181); A_arbace_spec_test_alpha_A_const_204 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_spec_test_alpha_A_const_205 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_180).Ref(), jrt.Long_ValueOf_J__Long(0).Ref())); A_arbace_spec_test_alpha_A_const_206 = lang.RT_Var_String_String__Var(Lit_17, Lit_182); A_arbace_spec_test_alpha_A_const_207 = lang.RT_Var_String_String__Var(Lit_17, Lit_183) }

func A_arbace_spec_test_alpha_A_New() *A_arbace_spec_test_alpha_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_A_class }

func (t *A_arbace_spec_test_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_A); return ok }

func A_arbace_spec_test_alpha_A_Cast(x any) *A_arbace_spec_test_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_A_class)) }; return v }



type A_arbace_spec_test_alpha___GT_sym_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha___GT_sym_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha___GT_sym_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha___GT_sym_A_init jrt.ClassInit

func A_arbace_spec_test_alpha___GT_sym_A_Init() { if !A_arbace_spec_test_alpha___GT_sym_A_init.Done() { A_arbace_spec_test_alpha___GT_sym_A_init.Run(A_arbace_spec_test_alpha___GT_sym_A_clinit) } }

func A_arbace_spec_test_alpha___GT_sym_A_clinit() { A_arbace_spec_test_alpha___GT_sym_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_184, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha___GT_sym_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha___GT_sym_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha___GT_sym_A_class }

func (t *A_arbace_spec_test_alpha___GT_sym_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha___GT_sym_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha___GT_sym_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha___GT_sym_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha___GT_sym_A); return ok }

func A_arbace_spec_test_alpha___GT_sym_A_Cast(x any) *A_arbace_spec_test_alpha___GT_sym_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha___GT_sym_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha___GT_sym_A_class)) }; return v }



type A_arbace_spec_test_alpha___GT_var_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha___GT_var_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha___GT_var_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha___GT_var_A_init jrt.ClassInit

func A_arbace_spec_test_alpha___GT_var_A_Init() { if !A_arbace_spec_test_alpha___GT_var_A_init.Done() { A_arbace_spec_test_alpha___GT_var_A_init.Run(A_arbace_spec_test_alpha___GT_var_A_clinit) } }

func A_arbace_spec_test_alpha___GT_var_A_clinit() { A_arbace_spec_test_alpha___GT_var_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_185, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha___GT_var_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha___GT_var_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha___GT_var_A_class }

func (t *A_arbace_spec_test_alpha___GT_var_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha___GT_var_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha___GT_var_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha___GT_var_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha___GT_var_A); return ok }

func A_arbace_spec_test_alpha___GT_var_A_Cast(x any) *A_arbace_spec_test_alpha___GT_var_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha___GT_var_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha___GT_var_A_class)) }; return v }



type A_arbace_spec_test_alpha_abbrev_result_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_abbrev_result_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_abbrev_result_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_abbrev_result_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_abbrev_result_A_Init() { if !A_arbace_spec_test_alpha_abbrev_result_A_init.Done() { A_arbace_spec_test_alpha_abbrev_result_A_init.Run(A_arbace_spec_test_alpha_abbrev_result_A_clinit) } }

func A_arbace_spec_test_alpha_abbrev_result_A_clinit() { A_arbace_spec_test_alpha_abbrev_result_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_187, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_abbrev_result_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_abbrev_result_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_abbrev_result_A_class }

func (t *A_arbace_spec_test_alpha_abbrev_result_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_abbrev_result_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_abbrev_result_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_abbrev_result_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_abbrev_result_A); return ok }

func A_arbace_spec_test_alpha_abbrev_result_A_Cast(x any) *A_arbace_spec_test_alpha_abbrev_result_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_abbrev_result_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_abbrev_result_A_class)) }; return v }



type A_arbace_spec_test_alpha_build_fixed_args_body_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_build_fixed_args_body_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_build_fixed_args_body_A_Init() { if !A_arbace_spec_test_alpha_build_fixed_args_body_A_init.Done() { A_arbace_spec_test_alpha_build_fixed_args_body_A_init.Run(A_arbace_spec_test_alpha_build_fixed_args_body_A_clinit) } }

func A_arbace_spec_test_alpha_build_fixed_args_body_A_clinit() { A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_188, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_build_fixed_args_body_A_class }

func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_build_fixed_args_body_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_build_fixed_args_body_A); return ok }

func A_arbace_spec_test_alpha_build_fixed_args_body_A_Cast(x any) *A_arbace_spec_test_alpha_build_fixed_args_body_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_build_fixed_args_body_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_build_fixed_args_body_A_class)) }; return v }



type A_arbace_spec_test_alpha_build_flattener_code_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_build_flattener_code_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_build_flattener_code_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_build_flattener_code_A_Init() { if !A_arbace_spec_test_alpha_build_flattener_code_A_init.Done() { A_arbace_spec_test_alpha_build_flattener_code_A_init.Run(A_arbace_spec_test_alpha_build_flattener_code_A_clinit) } }

func A_arbace_spec_test_alpha_build_flattener_code_A_clinit() { A_arbace_spec_test_alpha_build_flattener_code_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_189, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_build_flattener_code_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_build_flattener_code_A_class }

func (t *A_arbace_spec_test_alpha_build_flattener_code_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_build_flattener_code_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_build_flattener_code_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_build_flattener_code_A); return ok }

func A_arbace_spec_test_alpha_build_flattener_code_A_Cast(x any) *A_arbace_spec_test_alpha_build_flattener_code_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_build_flattener_code_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_build_flattener_code_A_class)) }; return v }



type A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A struct{ jrt.Object; F_closed_over_name any }

func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_Init() { if !A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_init.Done() { A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_init.Run(A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_clinit) } }

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_clinit() { A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_191, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class }

func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A); return ok }

func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_Cast(x any) *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_class)) }; return v }



type A_arbace_spec_test_alpha_build_kwargs_body_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_build_kwargs_body_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_build_kwargs_body_A_Init() { if !A_arbace_spec_test_alpha_build_kwargs_body_A_init.Done() { A_arbace_spec_test_alpha_build_kwargs_body_A_init.Run(A_arbace_spec_test_alpha_build_kwargs_body_A_clinit) } }

func A_arbace_spec_test_alpha_build_kwargs_body_A_clinit() { A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_192, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_build_kwargs_body_A_class }

func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_build_kwargs_body_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_build_kwargs_body_A); return ok }

func A_arbace_spec_test_alpha_build_kwargs_body_A_Cast(x any) *A_arbace_spec_test_alpha_build_kwargs_body_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_build_kwargs_body_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_build_kwargs_body_A_class)) }; return v }



type A_arbace_spec_test_alpha_build_varargs_body_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_build_varargs_body_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_build_varargs_body_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_build_varargs_body_A_Init() { if !A_arbace_spec_test_alpha_build_varargs_body_A_init.Done() { A_arbace_spec_test_alpha_build_varargs_body_A_init.Run(A_arbace_spec_test_alpha_build_varargs_body_A_clinit) } }

func A_arbace_spec_test_alpha_build_varargs_body_A_clinit() { A_arbace_spec_test_alpha_build_varargs_body_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_194, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_build_varargs_body_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_build_varargs_body_A_class }

func (t *A_arbace_spec_test_alpha_build_varargs_body_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_build_varargs_body_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_build_varargs_body_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_build_varargs_body_A); return ok }

func A_arbace_spec_test_alpha_build_varargs_body_A_Cast(x any) *A_arbace_spec_test_alpha_build_varargs_body_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_build_varargs_body_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_build_varargs_body_A_class)) }; return v }



type A_arbace_spec_test_alpha_check_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_check_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_spec_test_alpha_check_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_spec_test_alpha_check_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_check_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_check_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_check_A_Init() { if !A_arbace_spec_test_alpha_check_A_init.Done() { A_arbace_spec_test_alpha_check_A_init.Run(A_arbace_spec_test_alpha_check_A_clinit) } }

func A_arbace_spec_test_alpha_check_A_clinit() { A_arbace_spec_test_alpha_check_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_196, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_check_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_check_A_class }

func (t *A_arbace_spec_test_alpha_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_check_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_check_A); return ok }

func A_arbace_spec_test_alpha_check_A_Cast(x any) *A_arbace_spec_test_alpha_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_check_A_class)) }; return v }



type A_arbace_spec_test_alpha_check_fn__107000127_A struct{ jrt.Object; F_opts any }

func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_check_fn__107000127_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_check_fn__107000127_A_Init() { if !A_arbace_spec_test_alpha_check_fn__107000127_A_init.Done() { A_arbace_spec_test_alpha_check_fn__107000127_A_init.Run(A_arbace_spec_test_alpha_check_fn__107000127_A_clinit) } }

func A_arbace_spec_test_alpha_check_fn__107000127_A_clinit() { A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_197, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_check_fn__107000127_A_class }

func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_check_fn__107000127_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_check_fn__107000127_A); return ok }

func A_arbace_spec_test_alpha_check_fn__107000127_A_Cast(x any) *A_arbace_spec_test_alpha_check_fn__107000127_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_check_fn__107000127_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_check_fn__107000127_A_class)) }; return v }



type A_arbace_spec_test_alpha_check_1_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_check_1_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_check_1_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_check_1_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_check_1_A_Init() { if !A_arbace_spec_test_alpha_check_1_A_init.Done() { A_arbace_spec_test_alpha_check_1_A_init.Run(A_arbace_spec_test_alpha_check_1_A_clinit) } }

func A_arbace_spec_test_alpha_check_1_A_clinit() { A_arbace_spec_test_alpha_check_1_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_198, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_check_1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_check_1_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_check_1_A_class }

func (t *A_arbace_spec_test_alpha_check_1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_check_1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_check_1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_check_1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_check_1_A); return ok }

func A_arbace_spec_test_alpha_check_1_A_Cast(x any) *A_arbace_spec_test_alpha_check_1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_check_1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_check_1_A_class)) }; return v }



type A_arbace_spec_test_alpha_check_call_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_check_call_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_test_alpha_check_call_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_check_call_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_check_call_A_Init() { if !A_arbace_spec_test_alpha_check_call_A_init.Done() { A_arbace_spec_test_alpha_check_call_A_init.Run(A_arbace_spec_test_alpha_check_call_A_clinit) } }

func A_arbace_spec_test_alpha_check_call_A_clinit() { A_arbace_spec_test_alpha_check_call_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_201, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_check_call_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_check_call_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_check_call_A_class }

func (t *A_arbace_spec_test_alpha_check_call_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_check_call_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_check_call_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_check_call_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_check_call_A); return ok }

func A_arbace_spec_test_alpha_check_call_A_Cast(x any) *A_arbace_spec_test_alpha_check_call_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_check_call_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_check_call_A_class)) }; return v }



type A_arbace_spec_test_alpha_check_fn_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_check_fn_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_spec_test_alpha_check_fn_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_check_fn_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_check_fn_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_check_fn_A_Init() { if !A_arbace_spec_test_alpha_check_fn_A_init.Done() { A_arbace_spec_test_alpha_check_fn_A_init.Run(A_arbace_spec_test_alpha_check_fn_A_clinit) } }

func A_arbace_spec_test_alpha_check_fn_A_clinit() { A_arbace_spec_test_alpha_check_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_202, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_check_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_check_fn_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_check_fn_A_class }

func (t *A_arbace_spec_test_alpha_check_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_check_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_check_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_check_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_check_fn_A); return ok }

func A_arbace_spec_test_alpha_check_fn_A_Cast(x any) *A_arbace_spec_test_alpha_check_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_check_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_check_fn_A_class)) }; return v }



type A_arbace_spec_test_alpha_checkable_syms_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_checkable_syms_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_spec_test_alpha_checkable_syms_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_checkable_syms_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_checkable_syms_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_checkable_syms_A_Init() { if !A_arbace_spec_test_alpha_checkable_syms_A_init.Done() { A_arbace_spec_test_alpha_checkable_syms_A_init.Run(A_arbace_spec_test_alpha_checkable_syms_A_clinit) } }

func A_arbace_spec_test_alpha_checkable_syms_A_clinit() { A_arbace_spec_test_alpha_checkable_syms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_203, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_checkable_syms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_checkable_syms_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_checkable_syms_A_class }

func (t *A_arbace_spec_test_alpha_checkable_syms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_checkable_syms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_checkable_syms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_checkable_syms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_checkable_syms_A); return ok }

func A_arbace_spec_test_alpha_checkable_syms_A_Cast(x any) *A_arbace_spec_test_alpha_checkable_syms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_checkable_syms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_checkable_syms_A_class)) }; return v }



type A_arbace_spec_test_alpha_collectionize_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_collectionize_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_collectionize_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_collectionize_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_collectionize_A_Init() { if !A_arbace_spec_test_alpha_collectionize_A_init.Done() { A_arbace_spec_test_alpha_collectionize_A_init.Run(A_arbace_spec_test_alpha_collectionize_A_clinit) } }

func A_arbace_spec_test_alpha_collectionize_A_clinit() { A_arbace_spec_test_alpha_collectionize_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_204, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_collectionize_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_collectionize_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_collectionize_A_class }

func (t *A_arbace_spec_test_alpha_collectionize_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_collectionize_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_collectionize_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_collectionize_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_collectionize_A); return ok }

func A_arbace_spec_test_alpha_collectionize_A_Cast(x any) *A_arbace_spec_test_alpha_collectionize_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_collectionize_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_collectionize_A_class)) }; return v }



type A_arbace_spec_test_alpha_enumerate_namespace_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_enumerate_namespace_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_enumerate_namespace_A_Init() { if !A_arbace_spec_test_alpha_enumerate_namespace_A_init.Done() { A_arbace_spec_test_alpha_enumerate_namespace_A_init.Run(A_arbace_spec_test_alpha_enumerate_namespace_A_clinit) } }

func A_arbace_spec_test_alpha_enumerate_namespace_A_clinit() { A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_205, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_enumerate_namespace_A_class }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_enumerate_namespace_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_enumerate_namespace_A); return ok }

func A_arbace_spec_test_alpha_enumerate_namespace_A_Cast(x any) *A_arbace_spec_test_alpha_enumerate_namespace_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_enumerate_namespace_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_enumerate_namespace_A_class)) }; return v }



type A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_Init() { if !A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_init.Done() { A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_init.Run(A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_clinit) } }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_clinit() { A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_206, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A); return ok }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_Cast(x any) *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_class)) }; return v }



type A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A struct{ jrt.Object; F_ns_sym any }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_Init() { if !A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_init.Done() { A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_init.Run(A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_clinit) } }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_clinit() { A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_207, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A); return ok }

func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_Cast(x any) *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000002_A struct{ jrt.Object }

func A_arbace_spec_test_alpha_eval107000002_A_New() *A_arbace_spec_test_alpha_eval107000002_A { t := &A_arbace_spec_test_alpha_eval107000002_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_eval107000002_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_eval107000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000002_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000002_A_class }

func (t *A_arbace_spec_test_alpha_eval107000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000002_A); return ok }

func A_arbace_spec_test_alpha_eval107000002_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000002_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_Init() { if !A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_init.Done() { A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_init.Run(A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_clinit) } }

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_clinit() { A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_208, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class }

func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A); return ok }

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000006_A struct{ jrt.Object }

func A_arbace_spec_test_alpha_eval107000006_A_New() *A_arbace_spec_test_alpha_eval107000006_A { t := &A_arbace_spec_test_alpha_eval107000006_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_eval107000006_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_eval107000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000006_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000006_A_class }

func (t *A_arbace_spec_test_alpha_eval107000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000006_A); return ok }

func A_arbace_spec_test_alpha_eval107000006_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000006_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000006_fn__107000007_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_Init() { if !A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_init.Done() { A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_init.Run(A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_clinit) } }

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_clinit() { A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_209, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class }

func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000006_fn__107000007_A); return ok }

func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000006_fn__107000007_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_class)) }; return v }



type A_arbace_spec_test_alpha_explain_check_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_explain_check_A) Is_Compiler_AOTF4() {}

var A_arbace_spec_test_alpha_explain_check_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_explain_check_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_explain_check_A_Init() { if !A_arbace_spec_test_alpha_explain_check_A_init.Done() { A_arbace_spec_test_alpha_explain_check_A_init.Run(A_arbace_spec_test_alpha_explain_check_A_clinit) } }

func A_arbace_spec_test_alpha_explain_check_A_clinit() { A_arbace_spec_test_alpha_explain_check_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_210, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_explain_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_explain_check_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_explain_check_A_class }

func (t *A_arbace_spec_test_alpha_explain_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_explain_check_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_explain_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_explain_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_explain_check_A); return ok }

func A_arbace_spec_test_alpha_explain_check_A_Cast(x any) *A_arbace_spec_test_alpha_explain_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_explain_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_explain_check_A_class)) }; return v }



type A_arbace_spec_test_alpha_failure_type_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_failure_type_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_failure_type_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_failure_type_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_failure_type_A_Init() { if !A_arbace_spec_test_alpha_failure_type_A_init.Done() { A_arbace_spec_test_alpha_failure_type_A_init.Run(A_arbace_spec_test_alpha_failure_type_A_clinit) } }

func A_arbace_spec_test_alpha_failure_type_A_clinit() { A_arbace_spec_test_alpha_failure_type_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_212, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_failure_type_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_failure_type_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_failure_type_A_class }

func (t *A_arbace_spec_test_alpha_failure_type_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_failure_type_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_failure_type_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_failure_type_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_failure_type_A); return ok }

func A_arbace_spec_test_alpha_failure_type_A_Cast(x any) *A_arbace_spec_test_alpha_failure_type_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_failure_type_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_failure_type_A_class)) }; return v }



type A_arbace_spec_test_alpha_find_varargs_decl_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_find_varargs_decl_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_find_varargs_decl_A_Init() { if !A_arbace_spec_test_alpha_find_varargs_decl_A_init.Done() { A_arbace_spec_test_alpha_find_varargs_decl_A_init.Run(A_arbace_spec_test_alpha_find_varargs_decl_A_clinit) } }

func A_arbace_spec_test_alpha_find_varargs_decl_A_clinit() { A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_213, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_find_varargs_decl_A_class }

func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_find_varargs_decl_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_find_varargs_decl_A); return ok }

func A_arbace_spec_test_alpha_find_varargs_decl_A_Cast(x any) *A_arbace_spec_test_alpha_find_varargs_decl_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_find_varargs_decl_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_find_varargs_decl_A_class)) }; return v }



type A_arbace_spec_test_alpha_fn_spec_QMARK__A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_init jrt.ClassInit

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_Init() { if !A_arbace_spec_test_alpha_fn_spec_QMARK__A_init.Done() { A_arbace_spec_test_alpha_fn_spec_QMARK__A_init.Run(A_arbace_spec_test_alpha_fn_spec_QMARK__A_clinit) } }

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_clinit() { A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_214, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_fn_spec_QMARK__A_class }

func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_fn_spec_QMARK__A); return ok }

func A_arbace_spec_test_alpha_fn_spec_QMARK__A_Cast(x any) *A_arbace_spec_test_alpha_fn_spec_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_fn_spec_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_fn_spec_QMARK__A_class)) }; return v }



type A_arbace_spec_test_alpha_fn_spec_name_QMARK__A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_init jrt.ClassInit

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_Init() { if !A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_init.Done() { A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_init.Run(A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_clinit) } }

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_clinit() { A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_215, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class }

func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_fn_spec_name_QMARK__A); return ok }

func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_Cast(x any) *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_fn_spec_name_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_class)) }; return v }



type A_arbace_spec_test_alpha_gen_fixed_args_syms_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_Init() { if !A_arbace_spec_test_alpha_gen_fixed_args_syms_A_init.Done() { A_arbace_spec_test_alpha_gen_fixed_args_syms_A_init.Run(A_arbace_spec_test_alpha_gen_fixed_args_syms_A_clinit) } }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_clinit() { A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_216, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_A); return ok }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_Cast(x any) *A_arbace_spec_test_alpha_gen_fixed_args_syms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_gen_fixed_args_syms_A_class)) }; return v }



type A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_Init() { if !A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_init.Done() { A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_init.Run(A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_clinit) } }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_clinit() { A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_217, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A); return ok }

func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_Cast(x any) *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_class)) }; return v }



type A_arbace_spec_test_alpha_has_kwargs_QMARK__A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_init jrt.ClassInit

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_Init() { if !A_arbace_spec_test_alpha_has_kwargs_QMARK__A_init.Done() { A_arbace_spec_test_alpha_has_kwargs_QMARK__A_init.Run(A_arbace_spec_test_alpha_has_kwargs_QMARK__A_clinit) } }

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_clinit() { A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_218, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class }

func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_has_kwargs_QMARK__A); return ok }

func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_Cast(x any) *A_arbace_spec_test_alpha_has_kwargs_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_has_kwargs_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_has_kwargs_QMARK__A_class)) }; return v }



type A_arbace_spec_test_alpha_instrument_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_instrument_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_spec_test_alpha_instrument_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_spec_test_alpha_instrument_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_instrument_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_instrument_A_Init() { if !A_arbace_spec_test_alpha_instrument_A_init.Done() { A_arbace_spec_test_alpha_instrument_A_init.Run(A_arbace_spec_test_alpha_instrument_A_clinit) } }

func A_arbace_spec_test_alpha_instrument_A_clinit() { A_arbace_spec_test_alpha_instrument_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_219, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_instrument_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_instrument_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_instrument_A_class }

func (t *A_arbace_spec_test_alpha_instrument_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_instrument_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_instrument_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_instrument_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_instrument_A); return ok }

func A_arbace_spec_test_alpha_instrument_A_Cast(x any) *A_arbace_spec_test_alpha_instrument_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_instrument_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_instrument_A_class)) }; return v }



type A_arbace_spec_test_alpha_instrument_fn__107000097_A struct{ jrt.Object; F_opts any }

func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_Init() { if !A_arbace_spec_test_alpha_instrument_fn__107000097_A_init.Done() { A_arbace_spec_test_alpha_instrument_fn__107000097_A_init.Run(A_arbace_spec_test_alpha_instrument_fn__107000097_A_clinit) } }

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_clinit() { A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_220, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_instrument_fn__107000097_A_class }

func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_instrument_fn__107000097_A); return ok }

func A_arbace_spec_test_alpha_instrument_fn__107000097_A_Cast(x any) *A_arbace_spec_test_alpha_instrument_fn__107000097_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_instrument_fn__107000097_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_instrument_fn__107000097_A_class)) }; return v }



type A_arbace_spec_test_alpha_instrument_1_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_instrument_1_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_instrument_1_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_1_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_instrument_1_A_Init() { if !A_arbace_spec_test_alpha_instrument_1_A_init.Done() { A_arbace_spec_test_alpha_instrument_1_A_init.Run(A_arbace_spec_test_alpha_instrument_1_A_clinit) } }

func A_arbace_spec_test_alpha_instrument_1_A_clinit() { A_arbace_spec_test_alpha_instrument_1_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_221, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_instrument_1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_instrument_1_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_instrument_1_A_class }

func (t *A_arbace_spec_test_alpha_instrument_1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_instrument_1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_instrument_1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_instrument_1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_instrument_1_A); return ok }

func A_arbace_spec_test_alpha_instrument_1_A_Cast(x any) *A_arbace_spec_test_alpha_instrument_1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_instrument_1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_instrument_1_A_class)) }; return v }



type A_arbace_spec_test_alpha_instrument_choose_fn_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Is_Compiler_AOTF4() {}

var A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_choose_fn_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_instrument_choose_fn_A_Init() { if !A_arbace_spec_test_alpha_instrument_choose_fn_A_init.Done() { A_arbace_spec_test_alpha_instrument_choose_fn_A_init.Run(A_arbace_spec_test_alpha_instrument_choose_fn_A_clinit) } }

func A_arbace_spec_test_alpha_instrument_choose_fn_A_clinit() { A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_222, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_instrument_choose_fn_A_class }

func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_instrument_choose_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_instrument_choose_fn_A); return ok }

func A_arbace_spec_test_alpha_instrument_choose_fn_A_Cast(x any) *A_arbace_spec_test_alpha_instrument_choose_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_instrument_choose_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_instrument_choose_fn_A_class)) }; return v }



type A_arbace_spec_test_alpha_instrument_choose_spec_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_instrument_choose_spec_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_instrument_choose_spec_A_Init() { if !A_arbace_spec_test_alpha_instrument_choose_spec_A_init.Done() { A_arbace_spec_test_alpha_instrument_choose_spec_A_init.Run(A_arbace_spec_test_alpha_instrument_choose_spec_A_clinit) } }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_clinit() { A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_223, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_instrument_choose_spec_A_class }

func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_instrument_choose_spec_A); return ok }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_Cast(x any) *A_arbace_spec_test_alpha_instrument_choose_spec_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_instrument_choose_spec_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_instrument_choose_spec_A_class)) }; return v }



type A_arbace_spec_test_alpha_instrumentable_syms_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_instrumentable_syms_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_instrumentable_syms_A_Init() { if !A_arbace_spec_test_alpha_instrumentable_syms_A_init.Done() { A_arbace_spec_test_alpha_instrumentable_syms_A_init.Run(A_arbace_spec_test_alpha_instrumentable_syms_A_clinit) } }

func A_arbace_spec_test_alpha_instrumentable_syms_A_clinit() { A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_224, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_instrumentable_syms_A_class }

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_instrumentable_syms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_instrumentable_syms_A); return ok }

func A_arbace_spec_test_alpha_instrumentable_syms_A_Cast(x any) *A_arbace_spec_test_alpha_instrumentable_syms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_instrumentable_syms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_instrumentable_syms_A_class)) }; return v }



type A_arbace_spec_test_alpha_interpret_stack_trace_element_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_Init() { if !A_arbace_spec_test_alpha_interpret_stack_trace_element_A_init.Done() { A_arbace_spec_test_alpha_interpret_stack_trace_element_A_init.Run(A_arbace_spec_test_alpha_interpret_stack_trace_element_A_clinit) } }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_clinit() { A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_228, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_A); return ok }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_Cast(x any) *A_arbace_spec_test_alpha_interpret_stack_trace_element_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_interpret_stack_trace_element_A_class)) }; return v }



type A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_Init() { if !A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_init.Done() { A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_init.Run(A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_clinit) } }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_clinit() { A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_229, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A); return ok }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_Cast(x any) *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_class)) }; return v }



type A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_Init() { if !A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_init.Done() { A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_init.Run(A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_clinit) } }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_clinit() { A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_231, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A); return ok }

func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_Cast(x any) *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_class)) }; return v }



type A_arbace_spec_test_alpha_kwargs__GT_kvs_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_Init() { if !A_arbace_spec_test_alpha_kwargs__GT_kvs_A_init.Done() { A_arbace_spec_test_alpha_kwargs__GT_kvs_A_init.Run(A_arbace_spec_test_alpha_kwargs__GT_kvs_A_clinit) } }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_clinit() { A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_232, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_kwargs__GT_kvs_A); return ok }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_Cast(x any) *A_arbace_spec_test_alpha_kwargs__GT_kvs_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_kwargs__GT_kvs_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_kwargs__GT_kvs_A_class)) }; return v }



type A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_Init() { if !A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_init.Done() { A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_init.Run(A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_clinit) } }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_clinit() { A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_233, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A); return ok }

func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_Cast(x any) *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_class)) }; return v }



type A_arbace_spec_test_alpha_make_check_result_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_make_check_result_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_test_alpha_make_check_result_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_make_check_result_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_make_check_result_A_Init() { if !A_arbace_spec_test_alpha_make_check_result_A_init.Done() { A_arbace_spec_test_alpha_make_check_result_A_init.Run(A_arbace_spec_test_alpha_make_check_result_A_clinit) } }

func A_arbace_spec_test_alpha_make_check_result_A_clinit() { A_arbace_spec_test_alpha_make_check_result_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_234, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_make_check_result_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_make_check_result_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_make_check_result_A_class }

func (t *A_arbace_spec_test_alpha_make_check_result_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_make_check_result_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_make_check_result_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_make_check_result_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_make_check_result_A); return ok }

func A_arbace_spec_test_alpha_make_check_result_A_Cast(x any) *A_arbace_spec_test_alpha_make_check_result_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_make_check_result_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_make_check_result_A_class)) }; return v }



type A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_Init() { if !A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_init.Done() { A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_init.Run(A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_clinit) } }

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_clinit() { A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_235, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class }

func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A); return ok }

func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_Cast(x any) *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_class)) }; return v }



type A_arbace_spec_test_alpha_no_fspec_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_no_fspec_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_no_fspec_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_no_fspec_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_no_fspec_A_Init() { if !A_arbace_spec_test_alpha_no_fspec_A_init.Done() { A_arbace_spec_test_alpha_no_fspec_A_init.Run(A_arbace_spec_test_alpha_no_fspec_A_clinit) } }

func A_arbace_spec_test_alpha_no_fspec_A_clinit() { A_arbace_spec_test_alpha_no_fspec_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_236, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_no_fspec_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_no_fspec_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_no_fspec_A_class }

func (t *A_arbace_spec_test_alpha_no_fspec_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_no_fspec_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_no_fspec_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_no_fspec_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_no_fspec_A); return ok }

func A_arbace_spec_test_alpha_no_fspec_A_Cast(x any) *A_arbace_spec_test_alpha_no_fspec_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_no_fspec_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_no_fspec_A_class)) }; return v }



type A_arbace_spec_test_alpha_opt_syms_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_opt_syms_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_opt_syms_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_opt_syms_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_opt_syms_A_Init() { if !A_arbace_spec_test_alpha_opt_syms_A_init.Done() { A_arbace_spec_test_alpha_opt_syms_A_init.Run(A_arbace_spec_test_alpha_opt_syms_A_clinit) } }

func A_arbace_spec_test_alpha_opt_syms_A_clinit() { A_arbace_spec_test_alpha_opt_syms_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_239, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_opt_syms_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_opt_syms_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_opt_syms_A_class }

func (t *A_arbace_spec_test_alpha_opt_syms_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_opt_syms_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_opt_syms_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_opt_syms_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_opt_syms_A); return ok }

func A_arbace_spec_test_alpha_opt_syms_A_Cast(x any) *A_arbace_spec_test_alpha_opt_syms_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_opt_syms_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_opt_syms_A_class)) }; return v }



type A_arbace_spec_test_alpha_quick_check_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_quick_check_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_test_alpha_quick_check_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_quick_check_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_quick_check_A_Init() { if !A_arbace_spec_test_alpha_quick_check_A_init.Done() { A_arbace_spec_test_alpha_quick_check_A_init.Run(A_arbace_spec_test_alpha_quick_check_A_clinit) } }

func A_arbace_spec_test_alpha_quick_check_A_clinit() { A_arbace_spec_test_alpha_quick_check_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_240, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_quick_check_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_quick_check_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_quick_check_A_class }

func (t *A_arbace_spec_test_alpha_quick_check_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_quick_check_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_quick_check_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_quick_check_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_quick_check_A); return ok }

func A_arbace_spec_test_alpha_quick_check_A_Cast(x any) *A_arbace_spec_test_alpha_quick_check_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_quick_check_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_quick_check_A_class)) }; return v }



type A_arbace_spec_test_alpha_quick_check_fn__107000111_A struct{ jrt.Object; F_gen, F_specs any }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_Init() { if !A_arbace_spec_test_alpha_quick_check_fn__107000111_A_init.Done() { A_arbace_spec_test_alpha_quick_check_fn__107000111_A_init.Run(A_arbace_spec_test_alpha_quick_check_fn__107000111_A_clinit) } }

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_clinit() { A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_241, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_quick_check_fn__107000111_A); return ok }

func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_Cast(x any) *A_arbace_spec_test_alpha_quick_check_fn__107000111_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_quick_check_fn__107000111_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_quick_check_fn__107000111_A_class)) }; return v }



type A_arbace_spec_test_alpha_quick_check_fn__107000113_A struct{ jrt.Object; F_f, F_specs any }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_Init() { if !A_arbace_spec_test_alpha_quick_check_fn__107000113_A_init.Done() { A_arbace_spec_test_alpha_quick_check_fn__107000113_A_init.Run(A_arbace_spec_test_alpha_quick_check_fn__107000113_A_clinit) } }

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_clinit() { A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_242, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_quick_check_fn__107000113_A); return ok }

func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_Cast(x any) *A_arbace_spec_test_alpha_quick_check_fn__107000113_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_quick_check_fn__107000113_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_quick_check_fn__107000113_A_class)) }; return v }



type A_arbace_spec_test_alpha_result_type_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_result_type_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_result_type_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_result_type_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_result_type_A_Init() { if !A_arbace_spec_test_alpha_result_type_A_init.Done() { A_arbace_spec_test_alpha_result_type_A_init.Run(A_arbace_spec_test_alpha_result_type_A_clinit) } }

func A_arbace_spec_test_alpha_result_type_A_clinit() { A_arbace_spec_test_alpha_result_type_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_243, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_result_type_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_result_type_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_result_type_A_class }

func (t *A_arbace_spec_test_alpha_result_type_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_result_type_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_result_type_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_result_type_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_result_type_A); return ok }

func A_arbace_spec_test_alpha_result_type_A_Cast(x any) *A_arbace_spec_test_alpha_result_type_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_result_type_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_result_type_A_class)) }; return v }



type A_arbace_spec_test_alpha_spec_checking_fn_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Is_Compiler_AOTF3() {}

var A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_spec_checking_fn_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_spec_checking_fn_A_Init() { if !A_arbace_spec_test_alpha_spec_checking_fn_A_init.Done() { A_arbace_spec_test_alpha_spec_checking_fn_A_init.Run(A_arbace_spec_test_alpha_spec_checking_fn_A_clinit) } }

func A_arbace_spec_test_alpha_spec_checking_fn_A_clinit() { A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_244, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_spec_checking_fn_A_class }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_spec_checking_fn_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_spec_checking_fn_A); return ok }

func A_arbace_spec_test_alpha_spec_checking_fn_A_Cast(x any) *A_arbace_spec_test_alpha_spec_checking_fn_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_spec_checking_fn_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_spec_checking_fn_A_class)) }; return v }



type A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Is_Compiler_AOTF5() {}

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_Init() { if !A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_init.Done() { A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_init.Run(A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_clinit) } }

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_clinit() { A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_245, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A); return ok }

func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_Cast(x any) *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_class)) }; return v }



type A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A struct{ jrt.Object; F_fn_name, F_f, F_conform_BANG_, F_fn_spec any }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) Is_Compiler_AOTR0() {}

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_Init() { if !A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_init.Done() { A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_init.Run(A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_clinit) } }

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_clinit() { A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_248, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A); return ok }

func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_Cast(x any) *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_class)) }; return v }



type A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_Init() { if !A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_init.Done() { A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_init.Run(A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_clinit) } }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_clinit() { A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_249, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A); return ok }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_Cast(x any) *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_class)) }; return v }



type A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_Init() { if !A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_init.Done() { A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_init.Run(A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_clinit) } }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_clinit() { A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_250, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A); return ok }

func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_Cast(x any) *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_class)) }; return v }



type A_arbace_spec_test_alpha_summarize_results_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_summarize_results_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_spec_test_alpha_summarize_results_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_summarize_results_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_summarize_results_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_summarize_results_A_Init() { if !A_arbace_spec_test_alpha_summarize_results_A_init.Done() { A_arbace_spec_test_alpha_summarize_results_A_init.Run(A_arbace_spec_test_alpha_summarize_results_A_clinit) } }

func A_arbace_spec_test_alpha_summarize_results_A_clinit() { A_arbace_spec_test_alpha_summarize_results_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_summarize_results_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_summarize_results_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_summarize_results_A_class }

func (t *A_arbace_spec_test_alpha_summarize_results_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_summarize_results_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_summarize_results_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_summarize_results_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_summarize_results_A); return ok }

func A_arbace_spec_test_alpha_summarize_results_A_Cast(x any) *A_arbace_spec_test_alpha_summarize_results_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_summarize_results_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_summarize_results_A_class)) }; return v }



type A_arbace_spec_test_alpha_summarize_results_fn__107000134_A struct{ jrt.Object; F_summary_result any }

func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Is_Compiler_AOTF2() {}

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_Init() { if !A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_init.Done() { A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_init.Run(A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_clinit) } }

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_clinit() { A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class }

func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_summarize_results_fn__107000134_A); return ok }

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_Cast(x any) *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_summarize_results_fn__107000134_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_class)) }; return v }



type A_arbace_spec_test_alpha_sym__GT_check_map_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_sym__GT_check_map_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_sym__GT_check_map_A_Init() { if !A_arbace_spec_test_alpha_sym__GT_check_map_A_init.Done() { A_arbace_spec_test_alpha_sym__GT_check_map_A_init.Run(A_arbace_spec_test_alpha_sym__GT_check_map_A_clinit) } }

func A_arbace_spec_test_alpha_sym__GT_check_map_A_clinit() { A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_253, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_sym__GT_check_map_A_class }

func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_sym__GT_check_map_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_sym__GT_check_map_A); return ok }

func A_arbace_spec_test_alpha_sym__GT_check_map_A_Cast(x any) *A_arbace_spec_test_alpha_sym__GT_check_map_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_sym__GT_check_map_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_sym__GT_check_map_A_class)) }; return v }



type A_arbace_spec_test_alpha_throwable_QMARK__A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_throwable_QMARK__A_init jrt.ClassInit

func A_arbace_spec_test_alpha_throwable_QMARK__A_Init() { if !A_arbace_spec_test_alpha_throwable_QMARK__A_init.Done() { A_arbace_spec_test_alpha_throwable_QMARK__A_init.Run(A_arbace_spec_test_alpha_throwable_QMARK__A_clinit) } }

func A_arbace_spec_test_alpha_throwable_QMARK__A_clinit() { A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_throwable_QMARK__A_class }

func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_throwable_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_throwable_QMARK__A); return ok }

func A_arbace_spec_test_alpha_throwable_QMARK__A_Cast(x any) *A_arbace_spec_test_alpha_throwable_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_throwable_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_throwable_QMARK__A_class)) }; return v }



type A_arbace_spec_test_alpha_thunk_frame_QMARK__A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_init jrt.ClassInit

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_Init() { if !A_arbace_spec_test_alpha_thunk_frame_QMARK__A_init.Done() { A_arbace_spec_test_alpha_thunk_frame_QMARK__A_init.Run(A_arbace_spec_test_alpha_thunk_frame_QMARK__A_clinit) } }

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_clinit() { A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class }

func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_thunk_frame_QMARK__A); return ok }

func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_Cast(x any) *A_arbace_spec_test_alpha_thunk_frame_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_thunk_frame_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_thunk_frame_QMARK__A_class)) }; return v }



type A_arbace_spec_test_alpha_unstrument_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_unstrument_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_spec_test_alpha_unstrument_A) Is_Compiler_AOTF0() {}

var A_arbace_spec_test_alpha_unstrument_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_unstrument_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_unstrument_A_Init() { if !A_arbace_spec_test_alpha_unstrument_A_init.Done() { A_arbace_spec_test_alpha_unstrument_A_init.Run(A_arbace_spec_test_alpha_unstrument_A_clinit) } }

func A_arbace_spec_test_alpha_unstrument_A_clinit() { A_arbace_spec_test_alpha_unstrument_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_256, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_unstrument_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_unstrument_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_unstrument_A_class }

func (t *A_arbace_spec_test_alpha_unstrument_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_unstrument_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_unstrument_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_unstrument_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_unstrument_A); return ok }

func A_arbace_spec_test_alpha_unstrument_A_Cast(x any) *A_arbace_spec_test_alpha_unstrument_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_unstrument_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_unstrument_A_class)) }; return v }



type A_arbace_spec_test_alpha_unstrument_1_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_unstrument_1_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_unstrument_1_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_unstrument_1_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_unstrument_1_A_Init() { if !A_arbace_spec_test_alpha_unstrument_1_A_init.Done() { A_arbace_spec_test_alpha_unstrument_1_A_init.Run(A_arbace_spec_test_alpha_unstrument_1_A_clinit) } }

func A_arbace_spec_test_alpha_unstrument_1_A_clinit() { A_arbace_spec_test_alpha_unstrument_1_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_257, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_unstrument_1_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_unstrument_1_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_unstrument_1_A_class }

func (t *A_arbace_spec_test_alpha_unstrument_1_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_unstrument_1_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_unstrument_1_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_unstrument_1_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_unstrument_1_A); return ok }

func A_arbace_spec_test_alpha_unstrument_1_A_Cast(x any) *A_arbace_spec_test_alpha_unstrument_1_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_unstrument_1_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_unstrument_1_A_class)) }; return v }



type A_arbace_spec_test_alpha_unwrap_failure_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_unwrap_failure_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_unwrap_failure_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_unwrap_failure_A_Init() { if !A_arbace_spec_test_alpha_unwrap_failure_A_init.Done() { A_arbace_spec_test_alpha_unwrap_failure_A_init.Run(A_arbace_spec_test_alpha_unwrap_failure_A_clinit) } }

func A_arbace_spec_test_alpha_unwrap_failure_A_clinit() { A_arbace_spec_test_alpha_unwrap_failure_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_258, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_unwrap_failure_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_unwrap_failure_A_class }

func (t *A_arbace_spec_test_alpha_unwrap_failure_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_unwrap_failure_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_unwrap_failure_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_unwrap_failure_A); return ok }

func A_arbace_spec_test_alpha_unwrap_failure_A_Cast(x any) *A_arbace_spec_test_alpha_unwrap_failure_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_unwrap_failure_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_unwrap_failure_A_class)) }; return v }



type A_arbace_spec_test_alpha_validate_check_opts_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Is_Compiler_AOTF1() {}

var A_arbace_spec_test_alpha_validate_check_opts_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_validate_check_opts_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_validate_check_opts_A_Init() { if !A_arbace_spec_test_alpha_validate_check_opts_A_init.Done() { A_arbace_spec_test_alpha_validate_check_opts_A_init.Run(A_arbace_spec_test_alpha_validate_check_opts_A_clinit) } }

func A_arbace_spec_test_alpha_validate_check_opts_A_clinit() { A_arbace_spec_test_alpha_validate_check_opts_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_validate_check_opts_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_validate_check_opts_A_class }

func (t *A_arbace_spec_test_alpha_validate_check_opts_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_validate_check_opts_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_validate_check_opts_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_validate_check_opts_A); return ok }

func A_arbace_spec_test_alpha_validate_check_opts_A_Cast(x any) *A_arbace_spec_test_alpha_validate_check_opts_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_validate_check_opts_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_validate_check_opts_A_class)) }; return v }



type A_arbace_spec_test_alpha_with_instrument_disabled_A struct{ jrt.Object }

func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) Is_Compiler_AOTR2() {}

var A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class *jrt.Class

var A_arbace_spec_test_alpha_with_instrument_disabled_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_with_instrument_disabled_A_Init() { if !A_arbace_spec_test_alpha_with_instrument_disabled_A_init.Done() { A_arbace_spec_test_alpha_with_instrument_disabled_A_init.Run(A_arbace_spec_test_alpha_with_instrument_disabled_A_clinit) } }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_clinit() { A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_with_instrument_disabled_A_class }

func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_with_instrument_disabled_A); return ok }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_Cast(x any) *A_arbace_spec_test_alpha_with_instrument_disabled_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_with_instrument_disabled_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_with_instrument_disabled_A_class)) }; return v }
