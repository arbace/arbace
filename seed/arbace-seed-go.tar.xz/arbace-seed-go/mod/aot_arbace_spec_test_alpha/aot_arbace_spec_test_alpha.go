//line aot_arbace_spec_test_alpha.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_pprint"
	"arbace/aot_arbace_spec_alpha"
	"arbace/aot_arbace_spec_gen_alpha"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_New() *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_test_alpha_A_const_6, A_arbace_spec_test_alpha_A_const_7, A_arbace_spec_test_alpha_A_const_8); tmp2 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_test_alpha_A_const_1, A_arbace_spec_test_alpha_A_const_2, A_arbace_spec_test_alpha_A_const_3, A_arbace_spec_test_alpha_A_const_4); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :13:1
func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_New() *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_eval107000006_fn__107000007_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_9.GetRawRoot__O()); var tmp2 any; var root_14 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_15 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_14, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_16 lang.IFn; if linked_15 == nil { ifn_16 = lang.IFn_Cast(root_14) } else { ifn_16 = nil }; var arg_17 any = A_arbace_spec_test_alpha_A_const_11; if linked_15 == nil { tmp2 = ifn_16.Invoke_O__O(arg_17) } else { tmp2 = linked_15.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_14, arg_17) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_spec_test_alpha_A_const_12.GetRawRoot__O(), A_arbace_spec_test_alpha_A_const_13) }











func A_arbace_spec_test_alpha_throwable_QMARK__A_New() *A_arbace_spec_test_alpha_throwable_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_throwable_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Throwable_InstanceOf(x__0)).Ref() }



func A_arbace_spec_test_alpha___GT_sym_A_New() *A_arbace_spec_test_alpha___GT_sym_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha___GT_sym_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_spec_test_alpha___GT_sym_A) Ctor() {}
//line :29:1
func (t *A_arbace_spec_test_alpha___GT_sym_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 any; var root_24 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_25 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_24, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_26 lang.IFn; if linked_25 == nil { ifn_26 = lang.IFn_Cast(root_24) } else { ifn_26 = nil }; var arg_27 any = A_arbace_spec_test_alpha_A_const_14; if linked_25 == nil { tmp1 = ifn_26.Invoke_O__O(arg_27) } else { tmp1 = linked_25.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_24, arg_27) }; return lang.IFn_Cast(tmp1).Invoke_O__O(x__0)
}
func A_arbace_spec_test_alpha___GT_var_A_New() *A_arbace_spec_test_alpha___GT_var_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha___GT_var_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_spec_test_alpha___GT_var_A) Ctor() {}
//line :33:1
func (t *A_arbace_spec_test_alpha___GT_var_A) Invoke_O_O__O(self, s_or_v__0 any) any {

	var tmp1 any; var root_28 any = A_arbace_spec_test_alpha_A_const_15.GetRawRoot__O(); var linked_29 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_28, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_30 lang.IFn; if linked_29 == nil { ifn_30 = lang.IFn_Cast(root_28) } else { ifn_30 = nil }; var arg_31 any = s_or_v__0; if linked_29 == nil { tmp1 = ifn_30.Invoke_O__O(arg_31) } else { tmp1 = linked_29.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_28, arg_31) }; if jrt.J2g_Truth(tmp1) { return s_or_v__0 } else { var v__2 any; var and__1927000168__auto____2 any; var root_32 any = A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_34 lang.IFn

		if linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = s_or_v__0; if linked_33 == nil { and__1927000168__auto____2 = ifn_34.Invoke_O__O(arg_35) } else { and__1927000168__auto____2 = linked_33.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_32, arg_35) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var root_36 any = A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = s_or_v__0; if linked_37 == nil { v__2 = ifn_38.Invoke_O__O(arg_39) } else { v__2 = linked_37.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_36, arg_39) } } else { v__2 = and__1927000168__auto____2 }
		var tmp2 any; var root_40 any = A_arbace_spec_test_alpha_A_const_15.GetRawRoot__O(); var linked_41 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_40, aot_arbace_core.A_arbace_core_var_QMARK__A_fn_class); var ifn_42 lang.IFn; if linked_41 == nil { ifn_42 = lang.IFn_Cast(root_40) } else { ifn_42 = nil }; var arg_43 any = v__2; if linked_41 == nil { tmp2 = ifn_42.Invoke_O__O(arg_43) } else { tmp2 = linked_41.(*aot_arbace_core.A_arbace_core_var_QMARK__A).Invoke_O_O__O(root_40, arg_43) }; if jrt.J2g_Truth(tmp2) { return v__2 } else { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_18.GetRawRoot__O()).Invoke_O__O(s_or_v__0), nil)))))
		}
	}
}
func A_arbace_spec_test_alpha_collectionize_A_New() *A_arbace_spec_test_alpha_collectionize_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_collectionize_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_spec_test_alpha_collectionize_A) Ctor() {}
//line :42:1
func (t *A_arbace_spec_test_alpha_collectionize_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 any; var root_48 any = A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O(); var linked_49 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_48, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_50 lang.IFn; if linked_49 == nil { ifn_50 = lang.IFn_Cast(root_48) } else { ifn_50 = nil }; var arg_51 any = x__0; if linked_49 == nil { tmp1 = ifn_50.Invoke_O__O(arg_51) } else { tmp1 = linked_49.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_48, arg_51) }; if jrt.J2g_Truth(tmp1) {
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :44:1
			return x__0
		}
}

func A_arbace_spec_test_alpha_enumerate_namespace_A_New() *A_arbace_spec_test_alpha_enumerate_namespace_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Invoke_O_O__O(self, ns_sym_or_syms__0 any) any {



	var root_88 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var linked_89 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_88, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_90 lang.IFn; if linked_89 == nil { ifn_90 = lang.IFn_Cast(root_88) } else { ifn_90 = nil }; var arg_91 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_92 any; var root_80 any = A_arbace_spec_test_alpha_A_const_21.GetRawRoot__O(); var linked_81 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_80, aot_arbace_core.A_arbace_core_mapcat_A_fn_class); var ifn_82 lang.IFn

	if linked_81 == nil { ifn_82 = lang.IFn_Cast(root_80) } else { ifn_82 = nil }; var arg_83 any; var tmp1 any = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New(); var tmp2 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class = fncls__79d; tmp2 = fncls__79d } else { tmp2 = fncls__79 }; arg_83 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_81 == nil { arg_92 = ifn_82.Invoke_O__O(arg_83) } else { arg_92 = linked_81.(*aot_arbace_core.A_arbace_core_mapcat_A).Invoke_O_O__O(root_80, arg_83) }
//line :52:1
	var arg_93 any; var root_84 any = A_arbace_spec_test_alpha_A_const_27.GetRawRoot__O(); var linked_85 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_84, A_arbace_spec_test_alpha_collectionize_A_fn_class); var ifn_86 lang.IFn






	if linked_85 == nil { ifn_86 = lang.IFn_Cast(root_84) } else { ifn_86 = nil }; var arg_87 any = ns_sym_or_syms__0; if linked_85 == nil { arg_93 = ifn_86.Invoke_O__O(arg_87) } else { arg_93 = linked_85.(*A_arbace_spec_test_alpha_collectionize_A).Invoke_O_O__O(root_84, arg_87) }
//line :52:1
	if linked_89 == nil { return ifn_90.Invoke_O_O_O__O(arg_91, arg_92, arg_93) } else { return linked_89.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_88, arg_91, arg_92, arg_93)
	} }
func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New() *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Ctor() {}
//line :54:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Invoke_O_O__O(self, ns_sym__1 any) any {
	var root_74 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_76 lang.IFn; if linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var tmp1 any = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(ns_sym__1); var tmp2 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class
	if fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class = fncls__65d; tmp2 = fncls__65d } else { tmp2 = fncls__65 }; arg_77 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :55:1
	var arg_78 any; var root_70 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_71 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_70, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_72 lang.IFn


	if linked_71 == nil { ifn_72 = lang.IFn_Cast(root_70) } else { ifn_72 = nil }; var arg_73 any; var root_66 any = A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_ns_interns_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any = ns_sym__1; if linked_67 == nil { arg_73 = ifn_68.Invoke_O__O(arg_69) } else { arg_73 = linked_67.(*aot_arbace_core.A_arbace_core_ns_interns_A).Invoke_O_O__O(root_66, arg_69) }; if linked_71 == nil { arg_78 = ifn_72.Invoke_O__O(arg_73) } else { arg_78 = linked_71.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_70, arg_73) }
//line :55:1
	if linked_75 == nil { return ifn_76.Invoke_O_O__O(arg_77, arg_78) } else { return linked_75.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_74, arg_77, arg_78) } }
func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(p0 any) *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Ctor_O(c__ns_sym any) { t.F_ns_sym = c__ns_sym }
//line :56:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Invoke_O_O__O(self, name_sym__1 any) any {
	var root_60 any = A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_52 any = A_arbace_spec_test_alpha_A_const_24.GetRawRoot__O(); var linked_53 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_52, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_54 lang.IFn; if linked_53 == nil { ifn_54 = lang.IFn_Cast(root_52) } else { ifn_54 = nil }; var arg_55 any = t.F_ns_sym; if linked_53 == nil { arg_63 = ifn_54.Invoke_O__O(arg_55) } else { arg_63 = linked_53.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_52, arg_55) }; var arg_64 any; var root_56 any = A_arbace_spec_test_alpha_A_const_24.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_58 lang.IFn; if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = name_sym__1; if linked_57 == nil { arg_64 = ifn_58.Invoke_O__O(arg_59) } else { arg_64 = linked_57.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_56, arg_59) }; if linked_61 == nil { return ifn_62.Invoke_O_O__O(arg_63, arg_64) } else { return linked_61.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_60, arg_63, arg_64)
	}
}







func A_arbace_spec_test_alpha_fn_spec_QMARK__A_New() *A_arbace_spec_test_alpha_fn_spec_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_fn_spec_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var or__1927000174__auto____2 any = A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(m__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(m__0) } }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_New() *A_arbace_spec_test_alpha_with_instrument_disabled_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_with_instrument_disabled_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) Ctor() {}
//line :72:1
func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { var root_114 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_114, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_116 lang.IFn; if linked_115 == nil { ifn_116 = lang.IFn_Cast(root_114) } else { ifn_116 = nil }; var arg_117 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_32); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp4 any; var root_103 any = A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = A_arbace_spec_test_alpha_A_const_34.GetRawRoot__O(); var arg_107 any; var root_99 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any; var root_94 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_35); var arg_98 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(nil); if linked_95 == nil { arg_102 = ifn_96.Invoke_O_O__O(arg_97, arg_98) } else { arg_102 = linked_95.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_94, arg_97, arg_98) }; if linked_100 == nil { arg_107 = ifn_101.Invoke_O__O(arg_102) } else { arg_107 = linked_100.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_99, arg_102) }; if linked_104 == nil { tmp4 = ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { tmp4 = linked_104.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_103, arg_106, arg_107) }; arg_117 = tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4), body__2); if linked_115 == nil { return ifn_116.Invoke_O__O(arg_117) } else { return linked_115.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_114, arg_117) } }





func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_New() *A_arbace_spec_test_alpha_thunk_frame_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_thunk_frame_QMARK__A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Ctor() {}
//line :78:1
func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Invoke_O_O__O(self, s__0 any) any {
	var root_118 any = A_arbace_spec_test_alpha_A_const_36.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_118, aot_arbace_string.A_arbace_string_includes_QMARK__A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = s__0; var arg_122 any = Lit_31; if linked_119 == nil { return ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { return linked_119.(*aot_arbace_string.A_arbace_string_includes_QMARK__A).Invoke_O_O_O__O(root_118, arg_121, arg_122)
	} }
func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Ctor() {}
//line :81:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Invoke_O_O__O(self, p__107000034__0 any) any { var vec__107000035__2 any = p__107000034__0; var cls__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(0), nil); var method__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(1), nil); var file__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(2), nil); var line__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(3), nil); var clojure_QMARK___7 any; var root_123 any = A_arbace_spec_test_alpha_A_const_37.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_125 lang.IFn; if













	linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = A_arbace_spec_test_alpha_A_const_38; var arg_127 any = method__4; if linked_124 == nil { clojure_QMARK___7 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { clojure_QMARK___7 = linked_124.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; var demunge__8 any; var tmp1 any = /*line :81:1*/A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New(); var tmp2 *jrt.Class; var fncls__128 *jrt.Class = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class; if













	fncls__128 == nil { var fncls__128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class = fncls__128d; tmp2 = fncls__128d } else { tmp2 = fncls__128 }; demunge__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var degensym__9 any; var tmp3 any = /*line :81:1*/A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New(); var tmp4 *jrt.Class; var fncls__135 *jrt.Class = A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class; if













	fncls__135 == nil { var fncls__135d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class = fncls__135d; tmp4 = fncls__135d } else { tmp4 = fncls__135 }; degensym__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var vec__107000038__10 any; if


	jrt.J2g_Truth(clojure_QMARK___7) {

		var root_146 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = demunge__8; var arg_150 any; var root_140 any = A_arbace_spec_test_alpha_A_const_41.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_142 lang.IFn
//line :99:1
		if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any; var root_136 any = A_arbace_spec_test_alpha_A_const_42.GetRawRoot__O(); var linked_137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_136, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_138 lang.IFn; if linked_137 == nil { ifn_138 = lang.IFn_Cast(root_136) } else { ifn_138 = nil }; var arg_139 any = cls__3; if linked_137 == nil { arg_143 = ifn_138.Invoke_O__O(arg_139) } else { arg_143 = linked_137.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_136, arg_139) }; var arg_144 any = A_arbace_spec_test_alpha_A_const_43; var arg_145 any = A_arbace_spec_test_alpha_A_const_44; if linked_141 == nil { arg_150 = ifn_142.Invoke_O_O_O__O(arg_143, arg_144, arg_145) } else { arg_150 = linked_141.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O_O__O(root_140, arg_143, arg_144, arg_145) }
		if linked_147 == nil { vec__107000038__10 = ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { vec__107000038__10 = linked_147.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } else {
//line :98:1
			vec__107000038__10 = nil }; var ns_sym__11 any = /*line :81:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__107000038__10, lang.RT_IntCast_J__I_NoInit(0), nil); var name_sym__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000038__10, lang.RT_IntCast_J__I_NoInit(1), nil); var local__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000038__10, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_45.GetRawRoot__O()); var tmp6 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_46, file__5, A_arbace_spec_test_alpha_A_const_47, line__6, A_arbace_spec_test_alpha_A_const_48, method__4, A_arbace_spec_test_alpha_A_const_49, cls__3)); var tmp7 lang.IPersistentMap; var tmp8 any; var and__1927000168__auto____14 any = ns_sym__11; if























	jrt.J2g_Truth(and__1927000168__auto____14) { tmp8 = name_sym__12 } else { tmp8 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp8) { var tmp9 any = A_arbace_spec_test_alpha_A_const_50; var tmp10 any; var root_151 any = A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O(); var linked_152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_151, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_153 lang.IFn
		if linked_152 == nil { ifn_153 = lang.IFn_Cast(root_151) } else { ifn_153 = nil }; var arg_154 any = ns_sym__11; var arg_155 any = name_sym__12; if linked_152 == nil { tmp10 = ifn_153.Invoke_O_O__O(arg_154, arg_155) } else { tmp10 = linked_152.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O_O__O(root_151, arg_154, arg_155) }
//line :105:1
		tmp7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, tmp10)) } else { tmp7 = nil }; var tmp11 any = tmp7; var tmp12 lang.IPersistentMap; if

	jrt.J2g_Truth(local__13) { var tmp13 any = A_arbace_spec_test_alpha_A_const_51; var tmp14 any; var root_156 any = A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O(); var linked_157 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_156, aot_arbace_core.A_arbace_core_symbol_A_fn_class); var ifn_158 lang.IFn
		if linked_157 == nil { ifn_158 = lang.IFn_Cast(root_156) } else { ifn_158 = nil }; var arg_159 any = lang.IFn_Cast(degensym__9).Invoke_O__O(local__13); if linked_157 == nil { tmp14 = ifn_158.Invoke_O__O(arg_159) } else { tmp14 = linked_157.(*aot_arbace_core.A_arbace_core_symbol_A).Invoke_O_O__O(root_156, arg_159) }
//line :107:1
		var tmp15 any = tmp14; var tmp16 any = A_arbace_spec_test_alpha_A_const_52; var tmp17 any; var root_160 any = A_arbace_spec_test_alpha_A_const_53.GetRawRoot__O(); var linked_161 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_160, A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class); var ifn_162 lang.IFn

		if linked_161 == nil { ifn_162 = lang.IFn_Cast(root_160) } else { ifn_162 = nil }; var arg_163 any = local__13; if linked_161 == nil { tmp17 = ifn_162.Invoke_O__O(arg_163) } else { tmp17 = linked_161.(*A_arbace_spec_test_alpha_thunk_frame_QMARK__A).Invoke_O_O__O(root_160, arg_163) }
//line :107:1
		tmp12 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, tmp16, tmp17)) } else { tmp12 = nil }; return /*line :101:1*/ tmp5.Invoke_O_O_O__O(tmp6, tmp11, tmp12) }
//line :95:1
func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Ctor() {}
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Invoke_O_O__O(self, p1__107000033_SHARP___1 any) any {

	var root_129 any = A_arbace_spec_test_alpha_A_const_39.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_string.A_arbace_string_replace_A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = p1__107000033_SHARP___1; var arg_133 any = A_arbace_spec_test_alpha_A_const_40; var arg_134 any = Lit_19; if linked_130 == nil { return ifn_131.Invoke_O_O_O__O(arg_132, arg_133, arg_134) } else { return linked_130.(*aot_arbace_string.A_arbace_string_replace_A).Invoke_O_O_O_O__O(root_129, arg_132, arg_133, arg_134) } }
//line :95:1
func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Ctor() {}
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Invoke_O_O__O(self, p1__107000032_SHARP___1 any) any {
	return lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(p1__107000032_SHARP___1)).Ref()
}













func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_New() *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Ctor() {}
//line :111:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Invoke_O_O__O(self, elems__0 any) any { var plumbing_QMARK___2 any; var tmp1 any = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New(); var tmp2 *jrt.Class; var fncls__191 *jrt.Class = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class; if





	fncls__191 == nil { var fncls__191d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class = fncls__191d; tmp2 = fncls__191d } else { tmp2 = fncls__191 }; plumbing_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var root_215 any =




	A_arbace_spec_test_alpha_A_const_58.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_sequence_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_59.GetRawRoot__O()); var tmp4 any; var root_192 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_193 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_192, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_194 lang.IFn; if linked_193 == nil { ifn_194 = lang.IFn_Cast(root_192) } else { ifn_194 = nil }; var arg_195 any = A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O(); if linked_193 == nil { tmp4 = ifn_194.Invoke_O__O(arg_195) } else { tmp4 = linked_193.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_192, arg_195) }; var tmp5 any = tmp4; var tmp6 any; var root_196 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_198 lang.IFn; if
	linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_spec_test_alpha_A_const_61.GetRawRoot__O(); if linked_197 == nil { tmp6 = ifn_198.Invoke_O__O(arg_199) } else { tmp6 = linked_197.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_196, arg_199) }; var tmp7 any = tmp6; var tmp8 any; var root_200 any = /*line :122:1*/A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_202 lang.IFn; if

	linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = A_arbace_spec_test_alpha_A_const_50; if linked_201 == nil { tmp8 = ifn_202.Invoke_O__O(arg_203) } else { tmp8 = linked_201.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_200, arg_203) }; var tmp9 any = tmp8; var tmp10 any; var root_204 any = /*line :122:1*/A_arbace_spec_test_alpha_A_const_63.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_drop_while_A_fn_class); var ifn_206 lang.IFn; if


	linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = plumbing_QMARK___2; if linked_205 == nil { tmp10 = ifn_206.Invoke_O__O(arg_207) } else { tmp10 = linked_205.(*aot_arbace_core.A_arbace_core_drop_while_A).Invoke_O_O__O(root_204, arg_207) }; arg_218 = /*line :122:1*/tmp3.Invoke_O_O_O_O__O(tmp5, tmp7, tmp9, tmp10); var arg_219 any = elems__0; if linked_216 == nil { return ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { return linked_216.(*aot_arbace_core.A_arbace_core_sequence_A).Invoke_O_O_O__O(root_215, arg_218, arg_219) } }
//line :117:1
func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New() *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Ctor() {}
//line :117:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Invoke_O_O__O(self, p__107000046__1 any) any { var map__107000048__2 any = p__107000046__1; var map__107000048__3 any; if lang.ISeq_InstanceOf(map__107000048__2) { var tmp1 any; var root_170 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = map__107000048__2; if linked_171 == nil { tmp1 = ifn_172.Invoke_O__O(arg_173) } else { tmp1 = linked_171.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_170, arg_173) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_174 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = map__107000048__2; if linked_175 == nil { tmp2 = ifn_176.Invoke_O__O(arg_177) } else { tmp2 = linked_175.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_174, arg_177) }; map__107000048__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_178 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = map__107000048__2; if linked_179 == nil { tmp3 = ifn_180.Invoke_O__O(arg_181) } else { tmp3 = linked_179.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_178, arg_181) }; if jrt.J2g_Truth(tmp3) { var root_182 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any = map__107000048__2; if linked_183 == nil { map__107000048__3 = ifn_184.Invoke_O__O(arg_185) } else { map__107000048__3 = linked_183.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_182, arg_185) } } else { map__107000048__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000048__3 = map__107000048__2 }; var var_scope__4 any = lang.RT_Get_O_O__O_NoInit(map__107000048__3, A_arbace_spec_test_alpha_A_const_50); var thunk_QMARK___5 any = lang.RT_Get_O_O__O_NoInit(map__107000048__3, A_arbace_spec_test_alpha_A_const_52); var or__1927000174__auto____6 any = thunk_QMARK___5; if
																		jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
																			var root_186 any = A_arbace_spec_test_alpha_A_const_37.GetRawRoot__O(); var linked_187 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_186, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_188 lang.IFn; if linked_187 == nil { ifn_188 = lang.IFn_Cast(root_186) } else { ifn_188 = nil }; var arg_189 any = A_arbace_spec_test_alpha_A_const_57; var arg_190 any = var_scope__4; if linked_187 == nil { return ifn_188.Invoke_O_O__O(arg_189, arg_190) } else { return linked_187.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_186, arg_189, arg_190) } } }








func A_arbace_spec_test_alpha_spec_checking_fn_A_New() *A_arbace_spec_test_alpha_spec_checking_fn_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Ctor() {}
//line :128:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Invoke_O_O_O_O__O(self, fn_name__0, f__1, fn_spec__2 any) any { var fn_spec__4 any; var tmp1 any; var root_220 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_222 lang.IFn; if





	linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = A_arbace_spec_test_alpha_A_const_64; if linked_221 == nil { tmp1 = ifn_222.Invoke_O__O(arg_223) } else { tmp1 = linked_221.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_220, arg_223) }; fn_spec__4 = lang.IFn_Cast(tmp1).Invoke_O__O(fn_spec__2); var conform_BANG___5 any; var tmp2 any = /*line :128:1*/A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New(); var tmp3 *jrt.Class; var fncls__271 *jrt.Class = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class; if






	fncls__271 == nil { var fncls__271d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class = fncls__271d; tmp3 = fncls__271d } else { tmp3 = fncls__271 }; conform_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 any =















	A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(fn_name__0, f__1, conform_BANG___5, fn_spec__4); var tmp5 *jrt.Class; var fncls__296 *jrt.Class = A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class; if fncls__296 == nil { var fncls__296d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, true); A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class = fncls__296d; tmp5 = fncls__296d } else { tmp5 = fncls__296 }; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp4, tmp5, nil, 0) }
//line :135:1
func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New() *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Ctor() {}
//line :135:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Invoke_O_O_O_O_O_O__O(self, fn_name__1, role__2, spec__3, data__4, args__5 any) any { var conformed__6 any; var root_224 any = A_arbace_spec_test_alpha_A_const_65.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A_fn_class); var ifn_226 lang.IFn; if
																					linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = spec__3; var arg_228 any = data__4; if linked_225 == nil { conformed__6 = ifn_226.Invoke_O_O__O(arg_227, arg_228) } else { conformed__6 = linked_225.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A).Invoke_O_O_O__O(root_224, arg_227, arg_228) }; if
																					lang.Util_Equiv_O_O__Z_NoInit(A_arbace_spec_test_alpha_A_const_66, conformed__6) { var caller__7 any; var root_233 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_235 lang.IFn
																						if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any; var root_229 any = A_arbace_spec_test_alpha_A_const_67.GetRawRoot__O(); var linked_230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_229, A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class); var ifn_231 lang.IFn; if linked_230 == nil { ifn_231 = lang.IFn_Cast(root_229) } else { ifn_231 = nil }; var arg_232 any = jrt.Thread_CurrentThread__Thread().GetStackTrace__StackTraceElement1().Ref(); if linked_230 == nil { arg_236 = ifn_231.Invoke_O__O(arg_232) } else { arg_236 = linked_230.(*A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A).Invoke_O_O__O(root_229, arg_232) }; if linked_234 == nil { caller__7 = ifn_235.Invoke_O__O(arg_236) } else { caller__7 = linked_234.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_233, arg_236) }
//line :137:1
		var ed__8 any; var root_261 any = A_arbace_spec_test_alpha_A_const_45.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_263 lang.IFn



		if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_68.GetRawRoot__O()); var tmp2 any; var root_237 any = A_arbace_spec_test_alpha_A_const_69.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_data_STAR__A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = spec__3; var arg_241 any = lang.PersistentVector_EMPTY.Ref(); var arg_242 any = lang.PersistentVector_EMPTY.Ref(); var arg_243 any = lang.PersistentVector_EMPTY.Ref(); var arg_244 any = data__4; if linked_238 == nil { tmp2 = ifn_239.Invoke_O_O_O_O_O__O(arg_240, arg_241, arg_242, arg_243, arg_244) } else { tmp2 = linked_238.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_data_STAR__A).Invoke_O_O_O_O_O_O__O(root_237, arg_240, arg_241, arg_242, arg_243, arg_244) }; arg_264 = tmp1.Invoke_O_O_O_O_O_O_O__O(tmp2, A_arbace_spec_test_alpha_A_const_70, fn_name__1, A_arbace_spec_test_alpha_A_const_71, args__5, A_arbace_spec_test_alpha_A_const_72, A_arbace_spec_test_alpha_A_const_73); var arg_265 any



		if jrt.J2g_Truth(caller__7) { var tmp3 any = A_arbace_spec_test_alpha_A_const_74; arg_265 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_75.GetRawRoot__O()).Invoke_O_O_O__O(caller__7, A_arbace_spec_test_alpha_A_const_49, A_arbace_spec_test_alpha_A_const_48))) } else { arg_265 = nil }
//line :141:1
		if linked_262 == nil { ed__8 = ifn_263.Invoke_O_O__O(arg_264, arg_265) } else { ed__8 = linked_262.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_261, arg_264, arg_265) }
//line :137:1
		var tmp4 any; var root_266 any = A_arbace_spec_test_alpha_A_const_76.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_268 lang.IFn









		if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, fn_name__1, nil)).Ref(); var arg_270 any = ed__8; if linked_267 == nil { tmp4 = ifn_268.Invoke_O_O__O(arg_269, arg_270) } else { tmp4 = linked_267.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_266, arg_269, arg_270) }
//line :137:1
		panic(jrt.Thrown(jrt.Throwable_Cast(tmp4))) } else { return conformed__6 } }













func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :151:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) Ctor_O_O_O_O(c__fn_name, c__f, c__conform_BANG_, c__fn_spec any) { t.F_fn_name = c__fn_name; t.F_f = c__f; t.F_conform_BANG_ = c__conform_BANG_; t.F_fn_spec = c__fn_spec }
//line :151:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) DoInvoke_O_O__O(self, args__1 any) any {

	if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_77.Get__O()) {
		var root_283 any = A_arbace_spec_test_alpha_A_const_79.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_285 lang.IFn; if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_80.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_77, nil); if linked_284 == nil { ifn_285.Invoke_O__O(arg_286) } else { linked_284.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_283, arg_286) }
//line :153:1
		var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(t.F_fn_spec)) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_conform_BANG_); var tmp3 any = t.F_fn_name; var tmp4 any = A_arbace_spec_test_alpha_A_const_28; tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(t.F_fn_spec), args__1, args__1) }
			{ var root_292 any = A_arbace_spec_test_alpha_A_const_79.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_80.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_77, jrt.Boolean_TRUE.Ref()); if linked_293 == nil { ifn_294.Invoke_O__O(arg_295) } else { linked_293.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_292, arg_295) }; tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
				{ var tmp5 lang.IFn = lang.IFn_Cast(t.F_f); tmp1 = tmp5.ApplyTo_ISeq__O(lang.ISeq_Cast(args__1)) }
//line :156:1
				return nil }(); var root_272 any = A_arbace_spec_test_alpha_A_const_78.GetRawRoot__O(); var linked_273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_272, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_274 lang.IFn; if linked_273 == nil { ifn_274 = lang.IFn_Cast(root_272) } else { ifn_274 = nil }; if linked_273 == nil { ifn_274.Invoke__O() } else { linked_273.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_272) }
//line :153:1
				if tmp6 != nil { panic(tmp6) } }; return nil }(); var root_275 any = A_arbace_spec_test_alpha_A_const_78.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_277 lang.IFn
		if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; if linked_276 == nil { ifn_277.Invoke__O() } else { linked_276.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_275) }
//line :153:1
		if tmp7 != nil { panic(tmp7) }; return tmp1 } else {




			var tmp8 lang.IFn = lang.IFn_Cast(t.F_f); return tmp8.ApplyTo_ISeq__O(lang.ISeq_Cast(args__1))
		} }
func A_arbace_spec_test_alpha_no_fspec_A_New() *A_arbace_spec_test_alpha_no_fspec_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_no_fspec_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_spec_test_alpha_no_fspec_A) Ctor() {}
//line :160:1
func (t *A_arbace_spec_test_alpha_no_fspec_A) Invoke_O_O_O__O(self, v__0, spec__1 any) any {

	var root_297 any = A_arbace_spec_test_alpha_A_const_76.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22), jrt.RefArrayOf(jrt.Object_class, nil, v__0, nil)).Ref(); var arg_301 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_81, v__0, A_arbace_spec_test_alpha_A_const_82, spec__1, A_arbace_spec_test_alpha_A_const_72, A_arbace_spec_test_alpha_A_const_83)); if linked_298 == nil { return ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { return linked_298.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_297, arg_300, arg_301)
	}
}


func A_arbace_spec_test_alpha_find_varargs_decl_A_New() *A_arbace_spec_test_alpha_find_varargs_decl_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_find_varargs_decl_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Ctor() {}
//line :167:1
func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Invoke_O_O__O(self, arglist__0 any) any { var vec__107000060__2 any; var root_311 any = A_arbace_spec_test_alpha_A_const_84.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_313 lang.IFn; if


	linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var root_306 any = A_arbace_spec_test_alpha_A_const_85.GetRawRoot__O(); var linked_307 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_306, aot_arbace_core.A_arbace_core_split_with_A_fn_class); var ifn_308 lang.IFn; if
	linked_307 == nil { ifn_308 = lang.IFn_Cast(root_306) } else { ifn_308 = nil }; var arg_309 any; var root_302 any = A_arbace_spec_test_alpha_A_const_86.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_304 lang.IFn; if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = A_arbace_spec_test_alpha_A_const_87; if linked_303 == nil { arg_309 = ifn_304.Invoke_O__O(arg_305) } else { arg_309 = linked_303.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_302, arg_305) }; var arg_310 any = arglist__0; if linked_307 == nil { arg_314 = ifn_308.Invoke_O_O__O(arg_309, arg_310) } else { arg_314 = linked_307.(*aot_arbace_core.A_arbace_core_split_with_A).Invoke_O_O_O__O(root_306, arg_309, arg_310) }; if /*line :170:1*/ linked_312 == nil { vec__107000060__2 = ifn_313.Invoke_O__O(arg_314) } else { vec__107000060__2 = linked_312.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_311, arg_314) }; var ___3 any = /*line :167:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__107000060__2, lang.RT_IntCast_J__I_NoInit(0), nil); var decl__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000060__2, lang.RT_IntCast_J__I_NoInit(1), nil); var restargs__5 any = vec__107000060__2; var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(restargs__5))); _ = ___3; if and__1927000168__auto____6 {





		return decl__4 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } }


func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_New() *A_arbace_spec_test_alpha_has_kwargs_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_has_kwargs_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Invoke_O_O__O(self, arglists__0 any) any {
	var root_320 any = A_arbace_spec_test_alpha_A_const_88.GetRawRoot__O(); var linked_321 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_320, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_322 lang.IFn; if linked_321 == nil { ifn_322 = lang.IFn_Cast(root_320) } else { ifn_322 = nil }; var arg_323 any; var root_315 any = A_arbace_spec_test_alpha_A_const_89.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = A_arbace_spec_test_alpha_A_const_90.GetRawRoot__O(); var arg_319 any = arglists__0; if linked_316 == nil { arg_323 = ifn_317.Invoke_O_O__O(arg_318, arg_319) } else { arg_323 = linked_316.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_315, arg_318, arg_319) }; if linked_321 == nil { return ifn_322.Invoke_O__O(arg_323) } else { return linked_321.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_320, arg_323)
	} }
func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_New() *A_arbace_spec_test_alpha_kwargs__GT_kvs_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_kwargs__GT_kvs_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Ctor() {}
//line :179:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Invoke_O_O__O(self, args__0 any) any {




	var tmp1 any; var root_324 any = A_arbace_spec_test_alpha_A_const_91.GetRawRoot__O(); var linked_325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_324, aot_arbace_core.A_arbace_core_even_QMARK__A_fn_class); var ifn_326 lang.IFn; if linked_325 == nil { ifn_326 = lang.IFn_Cast(root_324) } else { ifn_326 = nil }; var arg_327 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__0)).Ref(); if linked_325 == nil { tmp1 = ifn_326.Invoke_O__O(arg_327) } else { tmp1 = linked_325.(*aot_arbace_core.A_arbace_core_even_QMARK__A).Invoke_O_O__O(root_324, arg_327) }; if jrt.J2g_Truth(tmp1) { return args__0 } else {

		var root_353 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_355 lang.IFn; if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var root_328 any = A_arbace_spec_test_alpha_A_const_92.GetRawRoot__O(); var linked_329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_328, aot_arbace_core.A_arbace_core_butlast__1927000056_A_fn_class); var ifn_330 lang.IFn; if linked_329 == nil { ifn_330 = lang.IFn_Cast(root_328) } else { ifn_330 = nil }; var arg_331 any = args__0; if linked_329 == nil { arg_356 = ifn_330.Invoke_O__O(arg_331) } else { arg_356 = linked_329.(*aot_arbace_core.A_arbace_core_butlast__1927000056_A).Invoke_O_O__O(root_328, arg_331) }; var arg_357 any; var root_347 any = A_arbace_spec_test_alpha_A_const_93.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_reduce_kv_A_fn_class); var ifn_349 lang.IFn
		if linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any; var tmp2 any = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New(); var tmp3 *jrt.Class; var fncls__342 *jrt.Class = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class; if fncls__342 == nil { var fncls__342d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class = fncls__342d; tmp3 = fncls__342d } else { tmp3 = fncls__342 }; arg_350 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_351 any = lang.PersistentList_EMPTY.Ref(); var arg_352 any; var root_343 any = A_arbace_spec_test_alpha_A_const_95.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_345 lang.IFn

		if linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any = args__0; if linked_344 == nil { arg_352 = ifn_345.Invoke_O__O(arg_346) } else { arg_352 = linked_344.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_343, arg_346) }
//line :187:1
		if linked_348 == nil { arg_357 = ifn_349.Invoke_O_O_O__O(arg_350, arg_351, arg_352) } else { arg_357 = linked_348.(*aot_arbace_core.A_arbace_core_reduce_kv_A).Invoke_O_O_O_O__O(root_347, arg_350, arg_351, arg_352) }
//line :186:1
		if linked_354 == nil { return ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { return linked_354.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) } } }
func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New() *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Ctor() {}
//line :187:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Invoke_O_O_O_O__O(self, acc__1, k__2, v__3 any) any { var root_337 any = A_arbace_spec_test_alpha_A_const_94.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = k__2; var arg_341 any; var root_332 any = A_arbace_spec_test_alpha_A_const_94.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any = v__3; var arg_336 any = acc__1; if linked_333 == nil { arg_341 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { arg_341 = linked_333.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }; if linked_338 == nil { return ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { return linked_338.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) } }



func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_New() *A_arbace_spec_test_alpha_gen_fixed_args_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_gen_fixed_args_syms_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Ctor() {}
//line :191:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Invoke_O_O__O(self, arglist__0 any) any {



	var root_376 any = A_arbace_spec_test_alpha_A_const_96.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any; var root_371 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_373 lang.IFn; if linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any; var tmp1 any = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New(); var tmp2 *jrt.Class; var fncls__361 *jrt.Class = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class; if fncls__361 == nil { var fncls__361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class = fncls__361d; tmp2 = fncls__361d } else { tmp2 = fncls__361 }; arg_374 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_375 any; var root_366 any = A_arbace_spec_test_alpha_A_const_98.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_take_while_A_fn_class); var ifn_368 lang.IFn; if linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any; var root_362 any = A_arbace_spec_test_alpha_A_const_86.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_complement_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any = A_arbace_spec_test_alpha_A_const_99; if linked_363 == nil { arg_369 = ifn_364.Invoke_O__O(arg_365) } else { arg_369 = linked_363.(*aot_arbace_core.A_arbace_core_complement_A).Invoke_O_O__O(root_362, arg_365) }; var arg_370 any = arglist__0; if linked_367 == nil { arg_375 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { arg_375 = linked_367.(*aot_arbace_core.A_arbace_core_take_while_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; if linked_372 == nil { arg_379 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { arg_379 = linked_372.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; if linked_377 == nil { return ifn_378.Invoke_O__O(arg_379) } else { return linked_377.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_376, arg_379) } }
//line :195:1
func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New() *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Ctor() {}
//line :195:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Invoke_O_O__O(self, ___1 any) any { var root_358 any = A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_360 lang.IFn; if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; if linked_359 == nil { return ifn_360.Invoke__O() } else { return linked_359.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O__O(root_358) } }

func A_arbace_spec_test_alpha_build_kwargs_body_A_New() *A_arbace_spec_test_alpha_build_kwargs_body_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_kwargs_body_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Ctor() {}
//line :197:1
func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var alias__3 any; var root_380 any = A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_382 lang.IFn; if




	linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = Lit_4; if linked_381 == nil { alias__3 = ifn_382.Invoke_O__O(arg_383) } else { alias__3 = linked_381.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_380, arg_383) }; var head_args__4 any; var root_384 any = /*line :197:1*/A_arbace_spec_test_alpha_A_const_100.GetRawRoot__O(); var linked_385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_384, A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class); var ifn_386 lang.IFn; if





	linked_385 == nil { ifn_386 = lang.IFn_Cast(root_384) } else { ifn_386 = nil }; var arg_387 any = arglist__1; if linked_385 == nil { head_args__4 = ifn_386.Invoke_O__O(arg_387) } else { head_args__4 = linked_385.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_A).Invoke_O_O__O(root_384, arg_387) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(head_args__4, A_arbace_spec_test_alpha_A_const_101, alias__3); var tmp3 any; var root_428 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_428, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_430 lang.IFn; if linked_429 == nil { ifn_430 = lang.IFn_Cast(root_428) } else { ifn_430 = nil }; var arg_431 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_102); var tmp6 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(fn_name__0); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp8 any; var root_417 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any; var root_412 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_414 lang.IFn; if linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp10 any; var root_408 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any; var root_403 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_103); var arg_407 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp12 any; var root_399 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_400 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_399, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_401 lang.IFn; if linked_400 == nil { ifn_401 = lang.IFn_Cast(root_399) } else { ifn_401 = nil }; var arg_402 any; var root_394 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_396 lang.IFn; if linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_104); var arg_398 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_105); if linked_395 == nil { arg_402 = ifn_396.Invoke_O_O__O(arg_397, arg_398) } else { arg_402 = linked_395.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_394, arg_397, arg_398) }; if linked_400 == nil { tmp12 = ifn_401.Invoke_O__O(arg_402) } else { tmp12 = linked_400.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_399, arg_402) }; arg_407 = tmp11.Invoke_O__O(tmp12); if linked_404 == nil { arg_411 = ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { arg_411 = linked_404.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_403, arg_406, arg_407) }; if linked_409 == nil { tmp10 = ifn_410.Invoke_O__O(arg_411) } else { tmp10 = linked_409.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_408, arg_411) }; arg_415 = tmp9.Invoke_O__O(tmp10); var arg_416 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(alias__3); if linked_413 == nil { arg_420 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { arg_420 = linked_413.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) }; if linked_418 == nil { tmp8 = ifn_419.Invoke_O__O(arg_420) } else { tmp8 = linked_418.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_417, arg_420) }; arg_431 = tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, head_args__4, tmp7.Invoke_O__O(tmp8)); if linked_429 == nil { tmp3 = ifn_430.Invoke_O__O(arg_431) } else { tmp3 = linked_429.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_428, arg_431) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }


func A_arbace_spec_test_alpha_build_varargs_body_A_New() *A_arbace_spec_test_alpha_build_varargs_body_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_varargs_body_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Ctor() {}
//line :207:1
func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var head_args__3 any; var root_432 any = A_arbace_spec_test_alpha_A_const_100.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class); var ifn_434 lang.IFn; if



	linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = arglist__1; if linked_433 == nil { head_args__3 = ifn_434.Invoke_O__O(arg_435) } else { head_args__3 = linked_433.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_A).Invoke_O_O__O(root_432, arg_435) }; var alias__4 any; var root_436 any = /*line :207:1*/A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O(); var linked_437 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_436, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_438 lang.IFn; if




	linked_437 == nil { ifn_438 = lang.IFn_Cast(root_436) } else { ifn_438 = nil }; var arg_439 any = Lit_5; if linked_437 == nil { alias__4 = ifn_438.Invoke_O__O(arg_439) } else { alias__4 = linked_437.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_436, arg_439) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(head_args__3, A_arbace_spec_test_alpha_A_const_106, alias__4); var tmp3 any; var root_453 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_454 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_453, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_455 lang.IFn; if linked_454 == nil { ifn_455 = lang.IFn_Cast(root_453) } else { ifn_455 = nil }; var arg_456 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_107), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(fn_name__0), head_args__3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(alias__4)); if linked_454 == nil { tmp3 = ifn_455.Invoke_O__O(arg_456) } else { tmp3 = linked_454.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_453, arg_456) }; return tmp1.Invoke_O_O__O(tmp2, tmp3) }


func A_arbace_spec_test_alpha_build_fixed_args_body_A_New() *A_arbace_spec_test_alpha_build_fixed_args_body_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_fixed_args_body_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Ctor() {}
//line :216:1
func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var arglist__3 any; var root_457 any = A_arbace_spec_test_alpha_A_const_100.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class); var ifn_459 lang.IFn; if



	linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = arglist__1; if linked_458 == nil { arglist__3 = ifn_459.Invoke_O__O(arg_460) } else { arglist__3 = linked_458.(*A_arbace_spec_test_alpha_gen_fixed_args_syms_A).Invoke_O_O__O(root_457, arg_460) }; var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp2 any; var root_466 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_467 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_466, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_468 lang.IFn; if linked_467 == nil { ifn_468 = lang.IFn_Cast(root_466) } else { ifn_468 = nil }; var arg_469 any; var root_461 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_462 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_461, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_463 lang.IFn; if linked_462 == nil { ifn_463 = lang.IFn_Cast(root_461) } else { ifn_463 = nil }; var arg_464 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(fn_name__0); var arg_465 any = arglist__3; if linked_462 == nil { arg_469 = ifn_463.Invoke_O_O__O(arg_464, arg_465) } else { arg_469 = linked_462.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_461, arg_464, arg_465) }; if linked_467 == nil { tmp2 = ifn_468.Invoke_O__O(arg_469) } else { tmp2 = linked_467.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_466, arg_469) }; return tmp1.Invoke_O_O__O(arglist__3, tmp2) }


func A_arbace_spec_test_alpha_build_flattener_code_A_New() *A_arbace_spec_test_alpha_build_flattener_code_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_flattener_code_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Ctor() {}
//line :224:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Invoke_O_O__O(self, arglists__0 any) any { var closed_over_name__2 any; var root_470 any = A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O(); var linked_471 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_470, aot_arbace_core.A_arbace_core_gensym_A_fn_class); var ifn_472 lang.IFn; if



	linked_471 == nil { ifn_472 = lang.IFn_Cast(root_470) } else { ifn_472 = nil }; var arg_473 any = Lit_2; if linked_471 == nil { closed_over_name__2 = ifn_472.Invoke_O__O(arg_473) } else { closed_over_name__2 = linked_471.(*aot_arbace_core.A_arbace_core_gensym_A).Invoke_O_O__O(root_470, arg_473) }; var root_532 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_108); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp4 any; var root_482 any = A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var arg_485 any = A_arbace_spec_test_alpha_A_const_34.GetRawRoot__O(); var arg_486 any; var root_478 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_478, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_480 lang.IFn; if linked_479 == nil { ifn_480 = lang.IFn_Cast(root_478) } else { ifn_480 = nil }; var arg_481 any; var root_474 any = A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(closed_over_name__2); if linked_475 == nil { arg_481 = ifn_476.Invoke_O__O(arg_477) } else { arg_481 = linked_475.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O__O(root_474, arg_477) }; if linked_479 == nil { arg_486 = ifn_480.Invoke_O__O(arg_481) } else { arg_486 = linked_479.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_478, arg_481) }; if linked_483 == nil { tmp4 = ifn_484.Invoke_O_O__O(arg_485, arg_486) } else { tmp4 = linked_483.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_482, arg_485, arg_486) }; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp7 any; var root_522 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any; var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp9 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_109); var tmp10 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_110); var tmp11 any; var root_511 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_513 lang.IFn; if


	linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var arg_514 any; var tmp12 any = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(closed_over_name__2); var tmp13 *jrt.Class; var fncls__510 *jrt.Class = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class; if fncls__510 == nil { var fncls__510d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class = fncls__510d; tmp13 = fncls__510d } else { tmp13 = fncls__510 }; arg_514 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_515 any; var or__1927000174__auto____3 any = arglists__0; if




	jrt.J2g_Truth(or__1927000174__auto____3) { arg_515 = or__1927000174__auto____3 } else { arg_515 = A_arbace_spec_test_alpha_A_const_115 }; if /*line :231:1*/ linked_512 == nil { tmp11 = ifn_513.Invoke_O_O__O(arg_514, arg_515) } else { tmp11 = linked_512.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_511, arg_514, arg_515) }; arg_525 = /*line :228:1*/tmp8.Invoke_O_O_O__O(tmp9, tmp10, tmp11); if linked_523 == nil { tmp7 = ifn_524.Invoke_O__O(arg_525) } else { tmp7 = linked_523.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_522, arg_525) }; arg_535 = tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6.Invoke_O__O(tmp7)); if linked_533 == nil { return ifn_534.Invoke_O__O(arg_535) } else { return linked_533.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_532, arg_535) } }


func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(p0 any) *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Ctor_O(c__closed_over_name any) { t.F_closed_over_name = c__closed_over_name }
//line :231:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Invoke_O_O__O(self, arglist__1 any) any { var varargs_decl__2 any; var root_487 any = A_arbace_spec_test_alpha_A_const_90.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_487, A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class); var ifn_489 lang.IFn; if
														linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = arglist__1; if linked_488 == nil { varargs_decl__2 = ifn_489.Invoke_O__O(arg_490) } else { varargs_decl__2 = linked_488.(*A_arbace_spec_test_alpha_find_varargs_decl_A).Invoke_O_O__O(root_487, arg_490) }; var tmp1 any; var root_491 any =
														A_arbace_spec_test_alpha_A_const_88.GetRawRoot__O(); var linked_492 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_491, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_493 lang.IFn; if linked_492 == nil { ifn_493 = lang.IFn_Cast(root_491) } else { ifn_493 = nil }; var arg_494 any = varargs_decl__2; if linked_492 == nil { tmp1 = ifn_493.Invoke_O__O(arg_494) } else { tmp1 = linked_492.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_491, arg_494) }; if jrt.J2g_Truth(tmp1) { var root_495 any = A_arbace_spec_test_alpha_A_const_111.GetRawRoot__O(); var linked_496 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_495, A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class); var ifn_497 lang.IFn; if linked_496 == nil { ifn_497 = lang.IFn_Cast(root_495) } else { ifn_497 = nil }; var arg_498 any = t.F_closed_over_name; var arg_499 any = arglist__1; if linked_496 == nil { return ifn_497.Invoke_O_O__O(arg_498, arg_499) } else { return linked_496.(*A_arbace_spec_test_alpha_build_kwargs_body_A).Invoke_O_O_O__O(root_495, arg_498, arg_499) } } else { if jrt.J2g_Truth(varargs_decl__2) {
															var root_500 any = A_arbace_spec_test_alpha_A_const_112.GetRawRoot__O(); var linked_501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_500, A_arbace_spec_test_alpha_build_varargs_body_A_fn_class); var ifn_502 lang.IFn; if linked_501 == nil { ifn_502 = lang.IFn_Cast(root_500) } else { ifn_502 = nil }; var arg_503 any = t.F_closed_over_name; var arg_504 any = arglist__1; if linked_501 == nil { return ifn_502.Invoke_O_O__O(arg_503, arg_504) } else { return linked_501.(*A_arbace_spec_test_alpha_build_varargs_body_A).Invoke_O_O_O__O(root_500, arg_503, arg_504) } } else {
//line :233:1
			if A_arbace_spec_test_alpha_A_const_113 != nil {

				var root_505 any = A_arbace_spec_test_alpha_A_const_114.GetRawRoot__O(); var linked_506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_505, A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class); var ifn_507 lang.IFn; if linked_506 == nil { ifn_507 = lang.IFn_Cast(root_505) } else { ifn_507 = nil }; var arg_508 any = t.F_closed_over_name; var arg_509 any = arglist__1; if linked_506 == nil { return ifn_507.Invoke_O_O__O(arg_508, arg_509) } else { return linked_506.(*A_arbace_spec_test_alpha_build_fixed_args_body_A).Invoke_O_O_O__O(root_505, arg_508, arg_509) } } else {
//line :233:1
					return nil } } } }





















func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_New() *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Ctor() {}
//line :255:1
func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Invoke_O_O_O__O(self, f__0, arglists__1 any) any {




	var tmp1 any; var root_536 any = A_arbace_spec_test_alpha_A_const_116.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = arglists__1; if linked_537 == nil { tmp1 = ifn_538.Invoke_O__O(arg_539) } else { tmp1 = linked_537.(*A_arbace_spec_test_alpha_has_kwargs_QMARK__A).Invoke_O_O__O(root_536, arg_539) }; if jrt.J2g_Truth(tmp1) { var flattener_code__3 any; var root_540 any = A_arbace_spec_test_alpha_A_const_117.GetRawRoot__O(); var linked_541 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_540, A_arbace_spec_test_alpha_build_flattener_code_A_fn_class); var ifn_542 lang.IFn
		if linked_541 == nil { ifn_542 = lang.IFn_Cast(root_540) } else { ifn_542 = nil }; var arg_543 any = arglists__1; if linked_541 == nil { flattener_code__3 = ifn_542.Invoke_O__O(arg_543) } else { flattener_code__3 = linked_541.(*A_arbace_spec_test_alpha_build_flattener_code_A).Invoke_O_O__O(root_540, arg_543) }
//line :260:1
		var kvs_emu__4 any; var root_544 any = A_arbace_spec_test_alpha_A_const_118.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_eval_A_fn_class); var ifn_546 lang.IFn

		if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = flattener_code__3; if linked_545 == nil { kvs_emu__4 = ifn_546.Invoke_O__O(arg_547) } else { kvs_emu__4 = linked_545.(*aot_arbace_core.A_arbace_core_eval_A).Invoke_O_O__O(root_544, arg_547) }
		return lang.IFn_Cast(kvs_emu__4).Invoke_O__O(f__0) } else {
//line :260:1
			return f__0
		}
}



func A_arbace_spec_test_alpha_instrument_choose_fn_A_New() *A_arbace_spec_test_alpha_instrument_choose_fn_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_choose_fn_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Ctor() {}
//line :266:1
func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Invoke_O_O_O_O_O__O(self, f__0, spec__1, sym__2, p__107000078__3 any) any { var map__107000079__5 any = p__107000078__3; var map__107000079__6 any; if lang.ISeq_InstanceOf(map__107000079__5) { var tmp1 any; var root_548 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_548, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_550 lang.IFn; if linked_549 == nil { ifn_550 = lang.IFn_Cast(root_548) } else { ifn_550 = nil }; var arg_551 any = map__107000079__5; if linked_549 == nil { tmp1 = ifn_550.Invoke_O__O(arg_551) } else { tmp1 = linked_549.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_548, arg_551) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_552 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_552, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_554 lang.IFn; if linked_553 == nil { ifn_554 = lang.IFn_Cast(root_552) } else { ifn_554 = nil }; var arg_555 any = map__107000079__5; if linked_553 == nil { tmp2 = ifn_554.Invoke_O__O(arg_555) } else { tmp2 = linked_553.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_552, arg_555) }; map__107000079__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_556 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_556, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_558 lang.IFn; if linked_557 == nil { ifn_558 = lang.IFn_Cast(root_556) } else { ifn_558 = nil }; var arg_559 any = map__107000079__5; if linked_557 == nil { tmp3 = ifn_558.Invoke_O__O(arg_559) } else { tmp3 = linked_557.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_556, arg_559) }; if jrt.J2g_Truth(tmp3) { var root_560 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_560, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_562 lang.IFn; if linked_561 == nil { ifn_562 = lang.IFn_Cast(root_560) } else { ifn_562 = nil }; var arg_563 any = map__107000079__5; if linked_561 == nil { map__107000079__6 = ifn_562.Invoke_O__O(arg_563) } else { map__107000079__6 = linked_561.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_560, arg_563) } } else { map__107000079__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000079__6 = map__107000079__5 }; var over__7 any = lang.RT_Get_O_O__O_NoInit(map__107000079__6, A_arbace_spec_test_alpha_A_const_119); var stub__8 any = lang.RT_Get_O_O__O_NoInit(map__107000079__6, A_arbace_spec_test_alpha_A_const_120); var replace__9 any = lang.RT_Get_O_O__O_NoInit(map__107000079__6, A_arbace_spec_test_alpha_A_const_121); var tmp4 any; var root_564 any = A_arbace_spec_test_alpha_A_const_89.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_566 lang.IFn; if


	linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, sym__2)); var arg_568 any = stub__8; if linked_565 == nil { tmp4 = ifn_566.Invoke_O_O__O(arg_567, arg_568) } else { tmp4 = linked_565.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_564, arg_567, arg_568) }; if jrt.J2g_Truth(tmp4) {
		var root_574 any = A_arbace_spec_test_alpha_A_const_122.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any; var root_569 any = A_arbace_spec_test_alpha_A_const_123.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_spec_alpha.A_arbace_spec_alpha_gen_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = spec__1; var arg_573 any = over__7; if linked_570 == nil { arg_577 = ifn_571.Invoke_O_O__O(arg_572, arg_573) } else { arg_577 = linked_570.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_gen_A).Invoke_O_O_O__O(root_569, arg_572, arg_573) }; if linked_575 == nil { return ifn_576.Invoke_O__O(arg_577) } else { return linked_575.(*aot_arbace_spec_gen_alpha.A_arbace_spec_gen_alpha_eval1067000023_generate__1067000034_A).Invoke_O_O__O(root_574, arg_577) } } else {
			return lang.RT_Get_O_O_O__O_NoInit(replace__9, sym__2, f__0) } }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_New() *A_arbace_spec_test_alpha_instrument_choose_spec_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_choose_spec_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Ctor() {}
//line :273:1
func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Invoke_O_O_O_O__O(self, spec__0, sym__1, p__107000082__2 any) any { var map__107000083__4 any = p__107000082__2; var map__107000083__5 any; if lang.ISeq_InstanceOf(map__107000083__4) { var tmp1 any; var root_578 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any = map__107000083__4; if linked_579 == nil { tmp1 = ifn_580.Invoke_O__O(arg_581) } else { tmp1 = linked_579.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_578, arg_581) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_582 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_583 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_582, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_584 lang.IFn; if linked_583 == nil { ifn_584 = lang.IFn_Cast(root_582) } else { ifn_584 = nil }; var arg_585 any = map__107000083__4; if linked_583 == nil { tmp2 = ifn_584.Invoke_O__O(arg_585) } else { tmp2 = linked_583.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_582, arg_585) }; map__107000083__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_586 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_587 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_586, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_588 lang.IFn; if linked_587 == nil { ifn_588 = lang.IFn_Cast(root_586) } else { ifn_588 = nil }; var arg_589 any = map__107000083__4; if linked_587 == nil { tmp3 = ifn_588.Invoke_O__O(arg_589) } else { tmp3 = linked_587.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_586, arg_589) }; if jrt.J2g_Truth(tmp3) { var root_590 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_590, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_592 lang.IFn; if linked_591 == nil { ifn_592 = lang.IFn_Cast(root_590) } else { ifn_592 = nil }; var arg_593 any = map__107000083__4; if linked_591 == nil { map__107000083__5 = ifn_592.Invoke_O__O(arg_593) } else { map__107000083__5 = linked_591.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_590, arg_593) } } else { map__107000083__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000083__5 = map__107000083__4 }; var overrides__6 any = lang.RT_Get_O_O__O_NoInit(map__107000083__5, A_arbace_spec_test_alpha_A_const_82); return /*line :276:1*/ lang.RT_Get_O_O_O__O_NoInit(overrides__6, sym__1, spec__0) }

func A_arbace_spec_test_alpha_instrument_1_A_New() *A_arbace_spec_test_alpha_instrument_1_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_1_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_spec_test_alpha_instrument_1_A) Ctor() {}
//line :278:1
func (t *A_arbace_spec_test_alpha_instrument_1_A) Invoke_O_O_O__O(self, s__0, opts__1 any) any { var temp__1927000414__auto____3 any; var root_594 any = A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O(); var linked_595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_594, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_596 lang.IFn; if

	linked_595 == nil { ifn_596 = lang.IFn_Cast(root_594) } else { ifn_596 = nil }; var arg_597 any = s__0; if linked_595 == nil { temp__1927000414__auto____3 = ifn_596.Invoke_O__O(arg_597) } else { temp__1927000414__auto____3 = linked_595.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_594, arg_597) }; if jrt.J2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; var tmp1 *lang.Keyword = A_arbace_spec_test_alpha_A_const_124
		if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__4))) { return nil } else { var spec__5 any; var root_598 any = A_arbace_spec_test_alpha_A_const_125.GetRawRoot__O(); var linked_599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_598, aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A_fn_class); var ifn_600 lang.IFn
			if linked_599 == nil { ifn_600 = lang.IFn_Cast(root_598) } else { ifn_600 = nil }; var arg_601 any = v__4; if linked_599 == nil { spec__5 = ifn_600.Invoke_O__O(arg_601) } else { spec__5 = linked_599.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A).Invoke_O_O__O(root_598, arg_601) }
//line :281:1
			var map__107000086__6 any; var tmp2 any; var root_602 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_604 lang.IFn

			if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); if linked_603 == nil { tmp2 = ifn_604.Invoke_O__O(arg_605) } else { tmp2 = linked_603.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_602, arg_605) }; map__107000086__6 = lang.RT_Get_O_O__O_NoInit(tmp2, v__4)
//line :281:1
			var map__107000086__7 any
			if lang.ISeq_InstanceOf(map__107000086__6) { var tmp3 any; var root_606 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = map__107000086__6; if linked_607 == nil { tmp3 = ifn_608.Invoke_O__O(arg_609) } else { tmp3 = linked_607.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_606, arg_609) }; if jrt.J2g_Truth(tmp3) { var tmp4 any; var root_610 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_611 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_610, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_612 lang.IFn; if linked_611 == nil { ifn_612 = lang.IFn_Cast(root_610) } else { ifn_612 = nil }; var arg_613 any = map__107000086__6; if linked_611 == nil { tmp4 = ifn_612.Invoke_O__O(arg_613) } else { tmp4 = linked_611.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_610, arg_613) }; map__107000086__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp4, jrt.Object_class.ArrayClass())).Ref() } else { var tmp5 any; var root_614 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = map__107000086__6; if linked_615 == nil { tmp5 = ifn_616.Invoke_O__O(arg_617) } else { tmp5 = linked_615.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_614, arg_617) }; if jrt.J2g_Truth(tmp5) { var root_618 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = map__107000086__6; if linked_619 == nil { map__107000086__7 = ifn_620.Invoke_O__O(arg_621) } else { map__107000086__7 = linked_619.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_618, arg_621) } } else { map__107000086__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000086__7 = map__107000086__6 }
//line :281:1
			var raw__8 any = lang.RT_Get_O_O__O_NoInit(map__107000086__7, A_arbace_spec_test_alpha_A_const_127); var wrapped__9 any = lang.RT_Get_O_O__O_NoInit(map__107000086__7, A_arbace_spec_test_alpha_A_const_128); var current__10 any; var root_622 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_624 lang.IFn
			if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = v__4; if linked_623 == nil { current__10 = ifn_624.Invoke_O__O(arg_625) } else { current__10 = linked_623.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_622, arg_625) }
//line :281:1
			var to_wrap__11 any



			if lang.Util_Equiv_O_O__Z_NoInit(wrapped__9, current__10) { to_wrap__11 = raw__8 } else { to_wrap__11 = current__10 }
//line :281:1
			var ospec__12 any; var or__1927000174__auto____12 any; var root_626 any = A_arbace_spec_test_alpha_A_const_129.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class); var ifn_628 lang.IFn




			if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = spec__5; var arg_630 any = s__0; var arg_631 any = opts__1; if linked_627 == nil { or__1927000174__auto____12 = ifn_628.Invoke_O_O_O__O(arg_629, arg_630, arg_631) } else { or__1927000174__auto____12 = linked_627.(*A_arbace_spec_test_alpha_instrument_choose_spec_A).Invoke_O_O_O_O__O(root_626, arg_629, arg_630, arg_631) }; if jrt.J2g_Truth(or__1927000174__auto____12) { ospec__12 = or__1927000174__auto____12 } else { var tmp6 any; var root_632 any = A_arbace_spec_test_alpha_A_const_130.GetRawRoot__O(); var linked_633 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_632, A_arbace_spec_test_alpha_no_fspec_A_fn_class); var ifn_634 lang.IFn
				if linked_633 == nil { ifn_634 = lang.IFn_Cast(root_632) } else { ifn_634 = nil }; var arg_635 any = v__4; var arg_636 any = spec__5; if linked_633 == nil { tmp6 = ifn_634.Invoke_O_O__O(arg_635, arg_636) } else { tmp6 = linked_633.(*A_arbace_spec_test_alpha_no_fspec_A).Invoke_O_O_O__O(root_632, arg_635, arg_636) }
//line :286:1
				panic(jrt.Thrown(jrt.Throwable_Cast(tmp6))) }
//line :281:1
			var ofn__13 any; var root_637 any = A_arbace_spec_test_alpha_A_const_131.GetRawRoot__O(); var linked_638 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_637, A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class); var ifn_639 lang.IFn






			if linked_638 == nil { ifn_639 = lang.IFn_Cast(root_637) } else { ifn_639 = nil }; var arg_640 any = to_wrap__11; var arg_641 any = ospec__12; var arg_642 any = s__0; var arg_643 any = opts__1; if linked_638 == nil { ofn__13 = ifn_639.Invoke_O_O_O_O__O(arg_640, arg_641, arg_642, arg_643) } else { ofn__13 = linked_638.(*A_arbace_spec_test_alpha_instrument_choose_fn_A).Invoke_O_O_O_O_O__O(root_637, arg_640, arg_641, arg_642, arg_643) }
//line :281:1
			var checked__14 any; var root_648 any = A_arbace_spec_test_alpha_A_const_132.GetRawRoot__O(); var linked_649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_648, A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class); var ifn_650 lang.IFn







			if linked_649 == nil { ifn_650 = lang.IFn_Cast(root_648) } else { ifn_650 = nil }; var arg_651 any; var root_644 any = A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O(); var linked_645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_644, A_arbace_spec_test_alpha___GT_sym_A_fn_class); var ifn_646 lang.IFn; if linked_645 == nil { ifn_646 = lang.IFn_Cast(root_644) } else { ifn_646 = nil }; var arg_647 any = v__4; if linked_645 == nil { arg_651 = ifn_646.Invoke_O__O(arg_647) } else { arg_651 = linked_645.(*A_arbace_spec_test_alpha___GT_sym_A).Invoke_O_O__O(root_644, arg_647) }; var arg_652 any = ofn__13; var arg_653 any = ospec__12; if linked_649 == nil { checked__14 = ifn_650.Invoke_O_O_O__O(arg_651, arg_652, arg_653) } else { checked__14 = linked_649.(*A_arbace_spec_test_alpha_spec_checking_fn_A).Invoke_O_O_O_O__O(root_648, arg_651, arg_652, arg_653) }
//line :281:1
			var arglists__15 any; var root_659 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_661 lang.IFn








			if linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any; var root_654 any = A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = A_arbace_spec_test_alpha_A_const_135.GetRawRoot__O(); var tmp7 *lang.Keyword = A_arbace_spec_test_alpha_A_const_136; var arg_658 any = tmp7.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__4)); if linked_655 == nil { arg_662 = ifn_656.Invoke_O_O__O(arg_657, arg_658) } else { arg_662 = linked_655.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_654, arg_657, arg_658) }; if linked_660 == nil { arglists__15 = ifn_661.Invoke_O__O(arg_662) } else { arglists__15 = linked_660.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_659, arg_662) }
//line :281:1
			var wrapped__16 any; var root_663 any = A_arbace_spec_test_alpha_A_const_137.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class); var ifn_665 lang.IFn









			if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = checked__14; var arg_667 any = arglists__15; if linked_664 == nil { wrapped__16 = ifn_665.Invoke_O_O__O(arg_666, arg_667) } else { wrapped__16 = linked_664.(*A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A).Invoke_O_O_O__O(root_663, arg_666, arg_667) }
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_138.GetRawRoot__O()); var tmp9 any; var root_672 any = A_arbace_spec_test_alpha_A_const_139.GetRawRoot__O(); var linked_673 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_672, aot_arbace_core.A_arbace_core_constantly_A_fn_class); var ifn_674 lang.IFn; if linked_673 == nil { ifn_674 = lang.IFn_Cast(root_672) } else { ifn_674 = nil }; var arg_675 any = wrapped__16; if linked_673 == nil { tmp9 = ifn_674.Invoke_O__O(arg_675) } else { tmp9 = linked_673.(*aot_arbace_core.A_arbace_core_constantly_A).Invoke_O_O__O(root_672, arg_675) }; tmp8.Invoke_O_O__O(v__4, tmp9)
			var root_681 any = A_arbace_spec_test_alpha_A_const_140.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); var arg_685 any = A_arbace_spec_test_alpha_A_const_68.GetRawRoot__O(); var arg_686 any = v__4; var arg_687 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_127, to_wrap__11, A_arbace_spec_test_alpha_A_const_128, wrapped__16)); if linked_682 == nil { ifn_683.Invoke_O_O_O_O__O(arg_684, arg_685, arg_686, arg_687) } else { linked_682.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O_O__O(root_681, arg_684, arg_685, arg_686, arg_687) }
			var root_668 any = A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, A_arbace_spec_test_alpha___GT_sym_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any = v__4; if linked_669 == nil { return ifn_670.Invoke_O__O(arg_671) } else { return linked_669.(*A_arbace_spec_test_alpha___GT_sym_A).Invoke_O_O__O(root_668, arg_671) } } } else {
//line :280:1
				return nil } }















func A_arbace_spec_test_alpha_unstrument_1_A_New() *A_arbace_spec_test_alpha_unstrument_1_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_unstrument_1_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_spec_test_alpha_unstrument_1_A) Ctor() {}
//line :296:1
func (t *A_arbace_spec_test_alpha_unstrument_1_A) Invoke_O_O__O(self, s__0 any) any { var temp__1927000414__auto____2 any; var root_688 any = A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O(); var linked_689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_688, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_690 lang.IFn; if

	linked_689 == nil { ifn_690 = lang.IFn_Cast(root_688) } else { ifn_690 = nil }; var arg_691 any = s__0; if linked_689 == nil { temp__1927000414__auto____2 = ifn_690.Invoke_O__O(arg_691) } else { temp__1927000414__auto____2 = linked_689.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_688, arg_691) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any; var tmp1 any; var root_692 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_692, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_694 lang.IFn
		if linked_693 == nil { ifn_694 = lang.IFn_Cast(root_692) } else { ifn_694 = nil }; var arg_695 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); if linked_693 == nil { tmp1 = ifn_694.Invoke_O__O(arg_695) } else { tmp1 = linked_693.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_692, arg_695) }; temp__1927000414__auto____4 = lang.RT_Get_O_O__O_NoInit(tmp1, v__3); if jrt.J2g_Truth(temp__1927000414__auto____4) { var map__107000089__5 any = temp__1927000414__auto____4; var map__107000089__6 any; if lang.ISeq_InstanceOf(map__107000089__5) { var tmp2 any; var root_696 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_696, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_698 lang.IFn; if linked_697 == nil { ifn_698 = lang.IFn_Cast(root_696) } else { ifn_698 = nil }; var arg_699 any = map__107000089__5; if linked_697 == nil { tmp2 = ifn_698.Invoke_O__O(arg_699) } else { tmp2 = linked_697.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_696, arg_699) }; if jrt.J2g_Truth(tmp2) { var tmp3 any; var root_700 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_700, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_702 lang.IFn; if linked_701 == nil { ifn_702 = lang.IFn_Cast(root_700) } else { ifn_702 = nil }; var arg_703 any = map__107000089__5; if linked_701 == nil { tmp3 = ifn_702.Invoke_O__O(arg_703) } else { tmp3 = linked_701.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_700, arg_703) }; map__107000089__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.Object_class.ArrayClass())).Ref() } else { var tmp4 any; var root_704 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_704, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_706 lang.IFn; if linked_705 == nil { ifn_706 = lang.IFn_Cast(root_704) } else { ifn_706 = nil }; var arg_707 any = map__107000089__5; if linked_705 == nil { tmp4 = ifn_706.Invoke_O__O(arg_707) } else { tmp4 = linked_705.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_704, arg_707) }; if jrt.J2g_Truth(tmp4) { var root_708 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_710 lang.IFn; if linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any = map__107000089__5; if linked_709 == nil { map__107000089__6 = ifn_710.Invoke_O__O(arg_711) } else { map__107000089__6 = linked_709.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_708, arg_711) } } else { map__107000089__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000089__6 = map__107000089__5 }; var raw__7 any = lang.RT_Get_O_O__O_NoInit(map__107000089__6, A_arbace_spec_test_alpha_A_const_127); var wrapped__8 any = lang.RT_Get_O_O__O_NoInit(map__107000089__6, A_arbace_spec_test_alpha_A_const_128); var root_720 any = A_arbace_spec_test_alpha_A_const_140.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_722 lang.IFn
			if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); var arg_724 any = A_arbace_spec_test_alpha_A_const_75.GetRawRoot__O(); var arg_725 any = v__3; if linked_721 == nil { ifn_722.Invoke_O_O_O__O(arg_723, arg_724, arg_725) } else { linked_721.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_720, arg_723, arg_724, arg_725) }
//line :299:1
			var current__9 any; var root_712 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_714 lang.IFn

			if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = v__3; if linked_713 == nil { current__9 = ifn_714.Invoke_O__O(arg_715) } else { current__9 = linked_713.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_712, arg_715) }
			if lang.Util_Equiv_O_O__Z_NoInit(wrapped__8, current__9) {
				var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_138.GetRawRoot__O()); var tmp6 any; var root_726 any = A_arbace_spec_test_alpha_A_const_139.GetRawRoot__O(); var linked_727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_726, aot_arbace_core.A_arbace_core_constantly_A_fn_class); var ifn_728 lang.IFn; if linked_727 == nil { ifn_728 = lang.IFn_Cast(root_726) } else { ifn_728 = nil }; var arg_729 any = raw__7; if linked_727 == nil { tmp6 = ifn_728.Invoke_O__O(arg_729) } else { tmp6 = linked_727.(*aot_arbace_core.A_arbace_core_constantly_A).Invoke_O_O__O(root_726, arg_729) }; tmp5.Invoke_O_O__O(v__3, tmp6)
				var root_716 any = A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, A_arbace_spec_test_alpha___GT_sym_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = v__3; if linked_717 == nil { return ifn_718.Invoke_O__O(arg_719) } else { return linked_717.(*A_arbace_spec_test_alpha___GT_sym_A).Invoke_O_O__O(root_716, arg_719) } } else {
//line :302:1
					return nil } } else {
//line :299:1
						return nil } } else {
//line :298:1
							return nil } }







func A_arbace_spec_test_alpha_opt_syms_A_New() *A_arbace_spec_test_alpha_opt_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_opt_syms_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_spec_test_alpha_opt_syms_A) Ctor() {}
//line :306:1
func (t *A_arbace_spec_test_alpha_opt_syms_A) Invoke_O_O__O(self, opts__0 any) any {


	var root_743 any = A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O(); var linked_744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_743, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_745 lang.IFn; if linked_744 == nil { ifn_745 = lang.IFn_Cast(root_743) } else { ifn_745 = nil }; var arg_746 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var arg_747 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_748 any; var tmp1 any = A_arbace_spec_test_alpha_A_const_120.Invoke_O__O(opts__0); var tmp2 any; var root_735 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_735, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_737 lang.IFn; if linked_736 == nil { ifn_737 = lang.IFn_Cast(root_735) } else { ifn_737 = nil }; var arg_738 any = A_arbace_spec_test_alpha_A_const_121.Invoke_O__O(opts__0); if linked_736 == nil { tmp2 = ifn_737.Invoke_O__O(arg_738) } else { tmp2 = linked_736.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_735, arg_738) }; var tmp3 any = tmp2; var tmp4 any; var root_739 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any = A_arbace_spec_test_alpha_A_const_82.Invoke_O__O(opts__0); if linked_740 == nil { tmp4 = ifn_741.Invoke_O__O(arg_742) } else { tmp4 = linked_740.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_739, arg_742) }; arg_748 = lang.Tuple_Create_O_O_O__IPersistentVector(tmp1, tmp3, tmp4); if linked_744 == nil { return ifn_745.Invoke_O_O_O__O(arg_746, arg_747, arg_748) } else { return linked_744.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_743, arg_746, arg_747, arg_748)
	} }
func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_New() *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_fn_spec_name_QMARK__A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Ctor() {}
//line :311:1
func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any; var root_749 any = A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O(); var linked_750 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_749, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_751 lang.IFn; if

	linked_750 == nil { ifn_751 = lang.IFn_Cast(root_749) } else { ifn_751 = nil }; var arg_752 any = s__0; if linked_750 == nil { and__1927000168__auto____2 = ifn_751.Invoke_O__O(arg_752) } else { and__1927000168__auto____2 = linked_750.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_749, arg_752) }; if jrt.J2g_Truth(and__1927000168__auto____2) {
		var root_757 any = A_arbace_spec_test_alpha_A_const_142.GetRawRoot__O(); var linked_758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_757, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_759 lang.IFn; if linked_758 == nil { ifn_759 = lang.IFn_Cast(root_757) } else { ifn_759 = nil }; var arg_760 any; var G__107000093__3_ any; var root_753 any = A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O(); var linked_754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_753, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_755 lang.IFn; if linked_754 == nil { ifn_755 = lang.IFn_Cast(root_753) } else { ifn_755 = nil }; var arg_756 any = s__0; if linked_754 == nil { G__107000093__3_ = ifn_755.Invoke_O__O(arg_756) } else { G__107000093__3_ = linked_754.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_753, arg_756) }; var G__107000093__4_ any; if lang.Util_Identical_O_O__Z_NoInit(G__107000093__3_, nil) { G__107000093__4_ = nil } else { G__107000093__4_ = lang.RT_Meta_O__IPersistentMap_NoInit(G__107000093__3_) }; if lang.Util_Identical_O_O__Z_NoInit(G__107000093__4_, nil) { arg_760 = nil } else { arg_760 = A_arbace_spec_test_alpha_A_const_124.Invoke_O__O(G__107000093__4_) }; if linked_758 == nil { return ifn_759.Invoke_O__O(arg_760) } else { return linked_758.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_757, arg_760) } } else {
//line :313:1
			return and__1927000168__auto____2 } }


func A_arbace_spec_test_alpha_instrumentable_syms_A_New() *A_arbace_spec_test_alpha_instrumentable_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrumentable_syms_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Ctor() {}
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Invoke_O_O__O(self, opts__0 any) any {




	var tmp1 any; var root_791 any = A_arbace_spec_test_alpha_A_const_145.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = A_arbace_spec_test_alpha_A_const_146.GetRawRoot__O(); var arg_795 any; var root_787 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = A_arbace_spec_test_alpha_A_const_119.Invoke_O__O(opts__0); if linked_788 == nil { arg_795 = ifn_789.Invoke_O__O(arg_790) } else { arg_795 = linked_788.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_787, arg_790) }; if linked_792 == nil { tmp1 = ifn_793.Invoke_O_O__O(arg_794, arg_795) } else { tmp1 = linked_792.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_791, arg_794, arg_795) }; if jrt.J2g_Truth(tmp1) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, Lit_15, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_147))).Ref()))) }
	var root_781 any = A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var arg_785 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_786 any; var tmp2 any; var root_768 any = A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O(); var linked_769 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_768, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_770 lang.IFn; if linked_769 == nil { ifn_770 = lang.IFn_Cast(root_768) } else { ifn_770 = nil }; var arg_771 any = A_arbace_spec_test_alpha_A_const_143.GetRawRoot__O(); var arg_772 any; var root_764 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any; var root_761 any = A_arbace_spec_test_alpha_A_const_144.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, aot_arbace_spec_alpha.A_arbace_spec_alpha_registry_A_fn_class); var ifn_763 lang.IFn; if linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; if linked_762 == nil { arg_767 = ifn_763.Invoke__O() } else { arg_767 = linked_762.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_registry_A).Invoke_O__O(root_761) }; if linked_765 == nil { arg_772 = ifn_766.Invoke_O__O(arg_767) } else { arg_772 = linked_765.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_764, arg_767) }; if linked_769 == nil { tmp2 = ifn_770.Invoke_O_O__O(arg_771, arg_772) } else { tmp2 = linked_769.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_768, arg_771, arg_772) }; var tmp3 any = tmp2; var tmp4 any; var root_773 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_775 lang.IFn
	if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any = A_arbace_spec_test_alpha_A_const_82.Invoke_O__O(opts__0); if linked_774 == nil { tmp4 = ifn_775.Invoke_O__O(arg_776) } else { tmp4 = linked_774.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_773, arg_776) }
//line :322:1
	var tmp5 any = tmp4; var tmp6 any = A_arbace_spec_test_alpha_A_const_120.Invoke_O__O(opts__0); var tmp7 any; var root_777 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_777, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_779 lang.IFn


	if linked_778 == nil { ifn_779 = lang.IFn_Cast(root_777) } else { ifn_779 = nil }; var arg_780 any = A_arbace_spec_test_alpha_A_const_121.Invoke_O__O(opts__0); if linked_778 == nil { tmp7 = ifn_779.Invoke_O__O(arg_780) } else { tmp7 = linked_778.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_777, arg_780) }
//line :322:1
	arg_786 = lang.Tuple_Create_O_O_O_O__IPersistentVector(tmp3, tmp5, tmp6, tmp7); if linked_782 == nil { return ifn_783.Invoke_O_O_O__O(arg_784, arg_785, arg_786) } else { return linked_782.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_781, arg_784, arg_785, arg_786) } }
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Invoke_O__O(self any) any {


	var root_800 any = A_arbace_spec_test_alpha_A_const_148.GetRawRoot__O(); var linked_801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_800, A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class); var ifn_802 lang.IFn; if linked_801 == nil { ifn_802 = lang.IFn_Cast(root_800) } else { ifn_802 = nil }; var arg_803 any; if linked_801 == nil { return ifn_802.Invoke_O__O(arg_803) } else { return linked_801.(*A_arbace_spec_test_alpha_instrumentable_syms_A).Invoke_O_O__O(root_800, arg_803)
	}
}





func A_arbace_spec_test_alpha_instrument_A_New() *A_arbace_spec_test_alpha_instrument_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Ctor() {}
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O_O_O__O(self, sym_or_syms__0, opts__1 any) any { var lockee__1927000360__auto____3 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








































	{ var root_840 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var linked_841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_840, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_842 lang.IFn; if linked_841 == nil { ifn_842 = lang.IFn_Cast(root_840) } else { ifn_842 = nil }; var arg_843 any = lang.PersistentVector_EMPTY.Ref(); var arg_844 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_59.GetRawRoot__O()); var tmp3 any; var root_808 any = A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O(); var linked_809 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_808, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_810 lang.IFn

		if linked_809 == nil { ifn_810 = lang.IFn_Cast(root_808) } else { ifn_810 = nil }; var arg_811 any; var root_804 any = A_arbace_spec_test_alpha_A_const_148.GetRawRoot__O(); var linked_805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_804, A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class); var ifn_806 lang.IFn; if linked_805 == nil { ifn_806 = lang.IFn_Cast(root_804) } else { ifn_806 = nil }; var arg_807 any = opts__1; if linked_805 == nil { arg_811 = ifn_806.Invoke_O__O(arg_807) } else { arg_811 = linked_805.(*A_arbace_spec_test_alpha_instrumentable_syms_A).Invoke_O_O__O(root_804, arg_807) }; if linked_809 == nil { tmp3 = ifn_810.Invoke_O__O(arg_811) } else { tmp3 = linked_809.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_808, arg_811) }; var tmp4 any = tmp3; var tmp5 any; var root_812 any = A_arbace_spec_test_alpha_A_const_149.GetRawRoot__O(); var linked_813 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_812, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_814 lang.IFn
		if linked_813 == nil { ifn_814 = lang.IFn_Cast(root_812) } else { ifn_814 = nil }; if linked_813 == nil { tmp5 = ifn_814.Invoke__O() } else { tmp5 = linked_813.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O__O(root_812) }
//line :370:1
		var tmp6 any = tmp5; var tmp7 any; var root_821 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_822 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_821, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_823 lang.IFn

		if linked_822 == nil { ifn_823 = lang.IFn_Cast(root_821) } else { ifn_823 = nil }; var arg_824 any; var tmp8 any = A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(opts__1); var tmp9 *jrt.Class; var fncls__820 *jrt.Class = A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class; if fncls__820 == nil { var fncls__820d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class = fncls__820d; tmp9 = fncls__820d } else { tmp9 = fncls__820 }; arg_824 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); if linked_822 == nil { tmp7 = ifn_823.Invoke_O__O(arg_824) } else { tmp7 = linked_822.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_821, arg_824) }
//line :370:1
		var tmp10 any = tmp7; var tmp11 any; var root_825 any = A_arbace_spec_test_alpha_A_const_151.GetRawRoot__O(); var linked_826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_825, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_827 lang.IFn


		if linked_826 == nil { ifn_827 = lang.IFn_Cast(root_825) } else { ifn_827 = nil }; var arg_828 any = A_arbace_spec_test_alpha_A_const_152.GetRawRoot__O(); if linked_826 == nil { tmp11 = ifn_827.Invoke_O__O(arg_828) } else { tmp11 = linked_826.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_825, arg_828) }
//line :370:1
		arg_844 = tmp2.Invoke_O_O_O_O__O(tmp4, tmp6, tmp10, tmp11)
//line :368:1
		var arg_845 any; var root_836 any = A_arbace_spec_test_alpha_A_const_27.GetRawRoot__O(); var linked_837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_836, A_arbace_spec_test_alpha_collectionize_A_fn_class); var ifn_838 lang.IFn





		if linked_837 == nil { ifn_838 = lang.IFn_Cast(root_836) } else { ifn_838 = nil }; var arg_839 any = sym_or_syms__0; if linked_837 == nil { arg_845 = ifn_838.Invoke_O__O(arg_839) } else { arg_845 = linked_837.(*A_arbace_spec_test_alpha_collectionize_A).Invoke_O_O__O(root_836, arg_839) }
//line :368:1
		if linked_841 == nil { tmp1 = ifn_842.Invoke_O_O_O__O(arg_843, arg_844, arg_845) } else { tmp1 = linked_841.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_840, arg_843, arg_844, arg_845) } }
//line :327:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp12 != nil { panic(tmp12) }; return tmp1 }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O_O__O(self, sym_or_syms__0 any) any {





































	var root_846 any = A_arbace_spec_test_alpha_A_const_153.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, A_arbace_spec_test_alpha_instrument_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = sym_or_syms__0; var arg_850 any; if linked_847 == nil { return ifn_848.Invoke_O_O__O(arg_849, arg_850) } else { return linked_847.(*A_arbace_spec_test_alpha_instrument_A).Invoke_O_O_O__O(root_846, arg_849, arg_850) } }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O__O(self any) any {




































	var root_854 any = A_arbace_spec_test_alpha_A_const_153.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, A_arbace_spec_test_alpha_instrument_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any; var root_851 any = A_arbace_spec_test_alpha_A_const_148.GetRawRoot__O(); var linked_852 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_851, A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class); var ifn_853 lang.IFn; if linked_852 == nil { ifn_853 = lang.IFn_Cast(root_851) } else { ifn_853 = nil }; if linked_852 == nil { arg_857 = ifn_853.Invoke__O() } else { arg_857 = linked_852.(*A_arbace_spec_test_alpha_instrumentable_syms_A).Invoke_O__O(root_851) }; if linked_855 == nil { return ifn_856.Invoke_O__O(arg_857) } else { return linked_855.(*A_arbace_spec_test_alpha_instrument_A).Invoke_O_O__O(root_854, arg_857)
	}
}





func A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(p0 any) *A_arbace_spec_test_alpha_instrument_fn__107000097_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_fn__107000097_A{}; t.Ctor_O(p0); return t }
//line :372:1
func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :372:1
func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Invoke_O_O__O(self, p1__107000096_SHARP___1 any) any { var root_815 any = A_arbace_spec_test_alpha_A_const_150.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, A_arbace_spec_test_alpha_instrument_1_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = p1__107000096_SHARP___1; var arg_819 any = t.F_opts; if linked_816 == nil { return ifn_817.Invoke_O_O__O(arg_818, arg_819) } else { return linked_816.(*A_arbace_spec_test_alpha_instrument_1_A).Invoke_O_O_O__O(root_815, arg_818, arg_819) } }



func A_arbace_spec_test_alpha_unstrument_A_New() *A_arbace_spec_test_alpha_unstrument_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_unstrument_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Ctor() {}
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Invoke_O_O__O(self, sym_or_syms__0 any) any { var lockee__1927000360__auto____2 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); var locklocal__1927000361__auto____5 any = lockee__1927000360__auto____2; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____5); var tmp1 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var root_880 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var linked_881 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_880, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_882 lang.IFn; if linked_881 == nil { ifn_882 = lang.IFn_Cast(root_880) } else { ifn_882 = nil }; var arg_883 any = lang.PersistentVector_EMPTY.Ref(); var arg_884 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_59.GetRawRoot__O()); var tmp3 any; var root_858 any = A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_860 lang.IFn

		if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any = A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O(); if linked_859 == nil { tmp3 = ifn_860.Invoke_O__O(arg_861) } else { tmp3 = linked_859.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_858, arg_861) }; var tmp4 any = tmp3; var tmp5 any; var root_862 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_863 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_862, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_864 lang.IFn
		if linked_863 == nil { ifn_864 = lang.IFn_Cast(root_862) } else { ifn_864 = nil }; var arg_865 any = A_arbace_spec_test_alpha_A_const_154.GetRawRoot__O(); if linked_863 == nil { tmp5 = ifn_864.Invoke_O__O(arg_865) } else { tmp5 = linked_863.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O__O(root_862, arg_865) }
//line :385:1
		var tmp6 any = tmp5; var tmp7 any; var root_866 any = A_arbace_spec_test_alpha_A_const_151.GetRawRoot__O(); var linked_867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_866, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_868 lang.IFn

		if linked_867 == nil { ifn_868 = lang.IFn_Cast(root_866) } else { ifn_868 = nil }; var arg_869 any = A_arbace_spec_test_alpha_A_const_152.GetRawRoot__O(); if linked_867 == nil { tmp7 = ifn_868.Invoke_O__O(arg_869) } else { tmp7 = linked_867.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O__O(root_866, arg_869) }
//line :385:1
		arg_884 = tmp2.Invoke_O_O_O__O(tmp4, tmp6, tmp7)
//line :383:1
		var arg_885 any; var root_876 any = A_arbace_spec_test_alpha_A_const_27.GetRawRoot__O(); var linked_877 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_876, A_arbace_spec_test_alpha_collectionize_A_fn_class); var ifn_878 lang.IFn




		if linked_877 == nil { ifn_878 = lang.IFn_Cast(root_876) } else { ifn_878 = nil }; var arg_879 any = sym_or_syms__0; if linked_877 == nil { arg_885 = ifn_878.Invoke_O__O(arg_879) } else { arg_885 = linked_877.(*A_arbace_spec_test_alpha_collectionize_A).Invoke_O_O__O(root_876, arg_879) }
//line :383:1
		if linked_881 == nil { tmp1 = ifn_882.Invoke_O_O_O__O(arg_883, arg_884, arg_885) } else { tmp1 = linked_881.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_880, arg_883, arg_884, arg_885) } }
//line :376:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____5); if tmp8 != nil { panic(tmp8) }; return tmp1 }
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Invoke_O__O(self any) any {



	var root_899 any = A_arbace_spec_test_alpha_A_const_155.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, A_arbace_spec_test_alpha_unstrument_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any; var root_894 any = A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O(); var linked_895 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_894, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_896 lang.IFn; if linked_895 == nil { ifn_896 = lang.IFn_Cast(root_894) } else { ifn_896 = nil }; var arg_897 any = A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O(); var arg_898 any; var root_890 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_891 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_890, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_892 lang.IFn; if linked_891 == nil { ifn_892 = lang.IFn_Cast(root_890) } else { ifn_892 = nil }; var arg_893 any; var root_886 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_888 lang.IFn; if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any = A_arbace_spec_test_alpha_A_const_126.GetRawRoot__O(); if linked_887 == nil { arg_893 = ifn_888.Invoke_O__O(arg_889) } else { arg_893 = linked_887.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_886, arg_889) }; if linked_891 == nil { arg_898 = ifn_892.Invoke_O__O(arg_893) } else { arg_898 = linked_891.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_890, arg_893) }; if linked_895 == nil { arg_902 = ifn_896.Invoke_O_O__O(arg_897, arg_898) } else { arg_902 = linked_895.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_894, arg_897, arg_898) }; if linked_900 == nil { return ifn_901.Invoke_O__O(arg_902) } else { return linked_900.(*A_arbace_spec_test_alpha_unstrument_A).Invoke_O_O__O(root_899, arg_902)
	}
}









func A_arbace_spec_test_alpha_explain_check_A_New() *A_arbace_spec_test_alpha_explain_check_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_explain_check_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_spec_test_alpha_explain_check_A) Ctor() {}
//line :392:1
func (t *A_arbace_spec_test_alpha_explain_check_A) Invoke_O_O_O_O_O__O(self, args__0, spec__1, v__2, role__3 any) any {

	var root_927 any = A_arbace_spec_test_alpha_A_const_76.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = Lit_11; var arg_931 any; var tmp1 any; var root_903 any = A_arbace_spec_test_alpha_A_const_156.GetRawRoot__O(); var linked_904 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_903, aot_arbace_spec_alpha.A_arbace_spec_alpha_valid_QMARK__A_fn_class); var ifn_905 lang.IFn

	if linked_904 == nil { ifn_905 = lang.IFn_Cast(root_903) } else { ifn_905 = nil }; var arg_906 any = spec__1; var arg_907 any = v__2; var arg_908 any; if linked_904 == nil { tmp1 = ifn_905.Invoke_O_O_O__O(arg_906, arg_907, arg_908) } else { tmp1 = linked_904.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_valid_QMARK__A).Invoke_O_O_O_O__O(root_903, arg_906, arg_907, arg_908) }; if jrt.J2g_Truth(tmp1) { arg_931 = nil } else {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_68.GetRawRoot__O()); var tmp3 any; var root_909 any = A_arbace_spec_test_alpha_A_const_69.GetRawRoot__O(); var linked_910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_909, aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_data_STAR__A_fn_class); var ifn_911 lang.IFn; if linked_910 == nil { ifn_911 = lang.IFn_Cast(root_909) } else { ifn_911 = nil }; var arg_912 any = spec__1; var arg_913 any = lang.Tuple_Create_O__IPersistentVector(role__3); var arg_914 any = lang.PersistentVector_EMPTY.Ref(); var arg_915 any = lang.PersistentVector_EMPTY.Ref(); var arg_916 any = v__2; if linked_910 == nil { tmp3 = ifn_911.Invoke_O_O_O_O_O__O(arg_912, arg_913, arg_914, arg_915, arg_916) } else { tmp3 = linked_910.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_explain_data_STAR__A).Invoke_O_O_O_O_O_O__O(root_909, arg_912, arg_913, arg_914, arg_915, arg_916) }; arg_931 = tmp2.Invoke_O_O_O_O_O_O_O__O(tmp3, A_arbace_spec_test_alpha_A_const_157, args__0, A_arbace_spec_test_alpha_A_const_158, v__2, A_arbace_spec_test_alpha_A_const_72, A_arbace_spec_test_alpha_A_const_159) }
//line :394:1
	if linked_928 == nil { return ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { return linked_928.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_927, arg_930, arg_931)
	}
}





func A_arbace_spec_test_alpha_check_call_A_New() *A_arbace_spec_test_alpha_check_call_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_call_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_spec_test_alpha_check_call_A) Ctor() {}
//line :402:1
func (t *A_arbace_spec_test_alpha_check_call_A) Invoke_O_O_O_O__O(self, f__0, specs__1, args__2 any) any { var cargs__4 any; if



	jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1)) { var root_932 any = A_arbace_spec_test_alpha_A_const_65.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1); var arg_936 any = args__2; if linked_933 == nil { cargs__4 = ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { cargs__4 = linked_933.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) } } else { cargs__4 = nil }; if
	lang.Util_Equiv_O_O__Z_NoInit(cargs__4, A_arbace_spec_test_alpha_A_const_66) {
		var root_937 any = A_arbace_spec_test_alpha_A_const_160.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, A_arbace_spec_test_alpha_explain_check_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = args__2; var arg_941 any = A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1); var arg_942 any = args__2; var arg_943 any = A_arbace_spec_test_alpha_A_const_28; if linked_938 == nil { return ifn_939.Invoke_O_O_O_O__O(arg_940, arg_941, arg_942, arg_943) } else { return linked_938.(*A_arbace_spec_test_alpha_explain_check_A).Invoke_O_O_O_O_O__O(root_937, arg_940, arg_941, arg_942, arg_943) } } else {
//line :407:1
			var ret__5 any; var root_944 any = A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_946 lang.IFn

			if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = f__0; var arg_948 any = args__2; if linked_945 == nil { ret__5 = ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { ret__5 = linked_945.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_944, arg_947, arg_948) }
//line :407:1
			var cret__6 any


			if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1)) { var root_949 any = A_arbace_spec_test_alpha_A_const_65.GetRawRoot__O(); var linked_950 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_949, aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A_fn_class); var ifn_951 lang.IFn; if linked_950 == nil { ifn_951 = lang.IFn_Cast(root_949) } else { ifn_951 = nil }; var arg_952 any = A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1); var arg_953 any = ret__5; if linked_950 == nil { cret__6 = ifn_951.Invoke_O_O__O(arg_952, arg_953) } else { cret__6 = linked_950.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_conform_A).Invoke_O_O_O__O(root_949, arg_952, arg_953) } } else { cret__6 = nil }
			if lang.Util_Equiv_O_O__Z_NoInit(cret__6, A_arbace_spec_test_alpha_A_const_66) {
				var root_954 any = A_arbace_spec_test_alpha_A_const_160.GetRawRoot__O(); var linked_955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_954, A_arbace_spec_test_alpha_explain_check_A_fn_class); var ifn_956 lang.IFn; if linked_955 == nil { ifn_956 = lang.IFn_Cast(root_954) } else { ifn_956 = nil }; var arg_957 any = args__2; var arg_958 any = A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1); var arg_959 any = ret__5; var arg_960 any = A_arbace_spec_test_alpha_A_const_29; if linked_955 == nil { return ifn_956.Invoke_O_O_O_O__O(arg_957, arg_958, arg_959, arg_960) } else { return linked_955.(*A_arbace_spec_test_alpha_explain_check_A).Invoke_O_O_O_O_O__O(root_954, arg_957, arg_958, arg_959, arg_960) } } else {
					var tmp1 any; var and__1927000168__auto____7 any = A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = A_arbace_spec_test_alpha_A_const_161.Invoke_O__O(specs__1) } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) {
						var tmp2 any; var root_961 any = A_arbace_spec_test_alpha_A_const_156.GetRawRoot__O(); var linked_962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_961, aot_arbace_spec_alpha.A_arbace_spec_alpha_valid_QMARK__A_fn_class); var ifn_963 lang.IFn; if linked_962 == nil { ifn_963 = lang.IFn_Cast(root_961) } else { ifn_963 = nil }; var arg_964 any = A_arbace_spec_test_alpha_A_const_161.Invoke_O__O(specs__1); var arg_965 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_28, cargs__4, A_arbace_spec_test_alpha_A_const_29, cret__6)); if linked_962 == nil { tmp2 = ifn_963.Invoke_O_O__O(arg_964, arg_965) } else { tmp2 = linked_962.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_valid_QMARK__A).Invoke_O_O_O__O(root_961, arg_964, arg_965) }; if jrt.J2g_Truth(tmp2) { return jrt.Boolean_TRUE.Ref() } else {

							var root_966 any = A_arbace_spec_test_alpha_A_const_160.GetRawRoot__O(); var linked_967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_966, A_arbace_spec_test_alpha_explain_check_A_fn_class); var ifn_968 lang.IFn; if linked_967 == nil { ifn_968 = lang.IFn_Cast(root_966) } else { ifn_968 = nil }; var arg_969 any = args__2; var arg_970 any = A_arbace_spec_test_alpha_A_const_161.Invoke_O__O(specs__1); var arg_971 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_28, cargs__4, A_arbace_spec_test_alpha_A_const_29, cret__6)); var arg_972 any = A_arbace_spec_test_alpha_A_const_161; if linked_967 == nil { return ifn_968.Invoke_O_O_O_O__O(arg_969, arg_970, arg_971, arg_972) } else { return linked_967.(*A_arbace_spec_test_alpha_explain_check_A).Invoke_O_O_O_O_O__O(root_966, arg_969, arg_970, arg_971, arg_972) } } } else {
//line :413:1
								return jrt.Boolean_TRUE.Ref() } } } }





func A_arbace_spec_test_alpha_quick_check_A_New() *A_arbace_spec_test_alpha_quick_check_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_spec_test_alpha_quick_check_A) Ctor() {}
//line :419:1
func (t *A_arbace_spec_test_alpha_quick_check_A) Invoke_O_O_O_O__O(self, f__0, specs__1, p__107000104__2 any) any { var map__107000105__4 any = p__107000104__2; var map__107000105__5 any; if lang.ISeq_InstanceOf(map__107000105__4) { var tmp1 any; var root_973 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = map__107000105__4; if linked_974 == nil { tmp1 = ifn_975.Invoke_O__O(arg_976) } else { tmp1 = linked_974.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_973, arg_976) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_977 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_977, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_979 lang.IFn; if linked_978 == nil { ifn_979 = lang.IFn_Cast(root_977) } else { ifn_979 = nil }; var arg_980 any = map__107000105__4; if linked_978 == nil { tmp2 = ifn_979.Invoke_O__O(arg_980) } else { tmp2 = linked_978.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_977, arg_980) }; map__107000105__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_981 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = map__107000105__4; if linked_982 == nil { tmp3 = ifn_983.Invoke_O__O(arg_984) } else { tmp3 = linked_982.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_981, arg_984) }; if jrt.J2g_Truth(tmp3) { var root_985 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = map__107000105__4; if linked_986 == nil { map__107000105__5 = ifn_987.Invoke_O__O(arg_988) } else { map__107000105__5 = linked_986.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_985, arg_988) } } else { map__107000105__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000105__5 = map__107000105__4 }; var gen__6 any = lang.RT_Get_O_O__O_NoInit(map__107000105__5, A_arbace_spec_test_alpha_A_const_119); var opts__7 any = lang.RT_Get_O_O__O_NoInit(map__107000105__5, A_arbace_spec_test_alpha_A_const_162); var default__107000109__8 int64 = 1000; var map__107000107__9 any = opts__7; var map__107000107__10 any; if

	lang.ISeq_InstanceOf(map__107000107__9) { var tmp4 any; var root_989 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_990 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_989, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_991 lang.IFn; if linked_990 == nil { ifn_991 = lang.IFn_Cast(root_989) } else { ifn_991 = nil }; var arg_992 any = map__107000107__9; if linked_990 == nil { tmp4 = ifn_991.Invoke_O__O(arg_992) } else { tmp4 = linked_990.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_989, arg_992) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_993 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_994 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_993, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_995 lang.IFn; if linked_994 == nil { ifn_995 = lang.IFn_Cast(root_993) } else { ifn_995 = nil }; var arg_996 any = map__107000107__9; if linked_994 == nil { tmp5 = ifn_995.Invoke_O__O(arg_996) } else { tmp5 = linked_994.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_993, arg_996) }; map__107000107__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_997 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_998 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_997, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_999 lang.IFn; if linked_998 == nil { ifn_999 = lang.IFn_Cast(root_997) } else { ifn_999 = nil }; var arg_1000 any = map__107000107__9; if linked_998 == nil { tmp6 = ifn_999.Invoke_O__O(arg_1000) } else { tmp6 = linked_998.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_997, arg_1000) }; if jrt.J2g_Truth(tmp6) { var root_1001 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_1002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1001, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1003 lang.IFn; if linked_1002 == nil { ifn_1003 = lang.IFn_Cast(root_1001) } else { ifn_1003 = nil }; var arg_1004 any = map__107000107__9; if linked_1002 == nil { map__107000107__10 = ifn_1003.Invoke_O__O(arg_1004) } else { map__107000107__10 = linked_1002.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1001, arg_1004) } } else { map__107000107__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000107__10 = map__107000107__9 }; var tmp7 any = A_arbace_spec_test_alpha_A_const_163; var num_tests__11 any = /*line :419:1*/lang.RT_Get_O_O_O__O_NoInit(map__107000107__10, tmp7, jrt.Long_ValueOf_J__Long_NoInit(default__107000109__8).Ref()); var g__12 any; var tmp8 any = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(gen__6, specs__1); var tmp9 *jrt.Class; var fncls__1010 *jrt.Class = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class; if


	fncls__1010 == nil { var fncls__1010d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class = fncls__1010d; tmp9 = fncls__1010d } else { tmp9 = fncls__1010 }; g__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil).Invoke__O(); var tmp10 any; var root_1011 any =
	A_arbace_spec_test_alpha_A_const_164.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = g__12; if linked_1012 == nil { tmp10 = ifn_1013.Invoke_O__O(arg_1014) } else { tmp10 = linked_1012.(*A_arbace_spec_test_alpha_throwable_QMARK__A).Invoke_O_O__O(root_1011, arg_1014) }; if jrt.J2g_Truth(tmp10) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_165, g__12)) } else { var prop__13 any; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_166.GetRawRoot__O()); var tmp12 any = lang.Tuple_Create_O__IPersistentVector(g__12); var tmp13 any = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(f__0, specs__1); var tmp14 *jrt.Class
		var fncls__1021 /*line :423:1*/*jrt.Class = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class

		if fncls__1021 == nil { var fncls__1021d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class = fncls__1021d; tmp14 = fncls__1021d } else { tmp14 = fncls__1021 }; prop__13 = tmp11.Invoke_O_O__O(tmp12, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil))
		var root_1032 any = A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any = A_arbace_spec_test_alpha_A_const_168.GetRawRoot__O(); var arg_1036 any = num_tests__11; var arg_1037 any = prop__13; var arg_1038 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_169.GetRawRoot__O(), opts__7); if linked_1033 == nil { return ifn_1034.Invoke_O_O_O_O__O(arg_1035, arg_1036, arg_1037, arg_1038) } else { return linked_1033.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O_O__O(root_1032, arg_1035, arg_1036, arg_1037, arg_1038) } } }
//line :422:1
func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(p0, p1 any) *A_arbace_spec_test_alpha_quick_check_fn__107000111_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_fn__107000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :422:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Ctor_O_O(c__gen, c__specs any) { t.F_gen = c__gen; t.F_specs = c__specs }
//line :422:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var root_1005 any = A_arbace_spec_test_alpha_A_const_123.GetRawRoot__O(); var linked_1006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1005, aot_arbace_spec_alpha.A_arbace_spec_alpha_gen_A_fn_class); var ifn_1007 lang.IFn; if linked_1006 == nil { ifn_1007 = lang.IFn_Cast(root_1005) } else { ifn_1007 = nil }; var arg_1008 any; var tmp2 *lang.Keyword = A_arbace_spec_test_alpha_A_const_28; var tmp3 any; var t_ any = t.F_specs; t.F_specs = nil; tmp3 = t_; arg_1008 = tmp2.Invoke_O__O(tmp3); var arg_1009 any; var t__2 any = t.F_gen; t.F_gen = nil; arg_1009 = t__2; if linked_1006 == nil { tmp1 = ifn_1007.Invoke_O_O__O(arg_1008, arg_1009) } else { tmp1 = linked_1006.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_gen_A).Invoke_O_O_O__O(root_1005, arg_1008, arg_1009) } }; return nil }(); if tmp4 != nil { if true { var t__3 jrt.Throwable_I = tmp4; tmp1 = t__3 } }; return tmp1 }


func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(p0, p1 any) *A_arbace_spec_test_alpha_quick_check_fn__107000113_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_fn__107000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :425:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Ctor_O_O(c__f, c__specs any) { t.F_f = c__f; t.F_specs = c__specs }
//line :425:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Invoke_O_O__O(self, p1__107000103_SHARP___1 any) any { var root_1015 any = A_arbace_spec_test_alpha_A_const_167.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, A_arbace_spec_test_alpha_check_call_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = t.F_f; var arg_1019 any = t.F_specs; var arg_1020 any = p1__107000103_SHARP___1; if linked_1016 == nil { return ifn_1017.Invoke_O_O_O__O(arg_1018, arg_1019, arg_1020) } else { return linked_1016.(*A_arbace_spec_test_alpha_check_call_A).Invoke_O_O_O_O__O(root_1015, arg_1018, arg_1019, arg_1020) } }


func A_arbace_spec_test_alpha_make_check_result_A_New() *A_arbace_spec_test_alpha_make_check_result_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_make_check_result_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_spec_test_alpha_make_check_result_A) Ctor() {}
//line :428:1
func (t *A_arbace_spec_test_alpha_make_check_result_A) Invoke_O_O_O_O__O(self, check_sym__0, spec__1, test_check_ret__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_45.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_82, spec__1, A_arbace_spec_test_alpha_A_const_170, test_check_ret__2)); var tmp3 lang.IPersistentMap

	if jrt.J2g_Truth(check_sym__0) { tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_171, check_sym__0)) } else { tmp3 = nil }
//line :431:1
	var tmp4 any = tmp3; var tmp5 lang.IPersistentMap; var temp__1927000414__auto____4 any = A_arbace_spec_test_alpha_A_const_165.Invoke_O__O(test_check_ret__2)



	if jrt.J2g_Truth(temp__1927000414__auto____4) { var result__5 any = temp__1927000414__auto____4; var tmp6 any; var root_1039 any = A_arbace_spec_test_alpha_A_const_172.GetRawRoot__O(); var linked_1040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1039, aot_arbace_core.A_arbace_core_true_QMARK__A_fn_class); var ifn_1041 lang.IFn
		if linked_1040 == nil { ifn_1041 = lang.IFn_Cast(root_1039) } else { ifn_1041 = nil }; var arg_1042 any = result__5; if linked_1040 == nil { tmp6 = ifn_1041.Invoke_O__O(arg_1042) } else { tmp6 = linked_1040.(*aot_arbace_core.A_arbace_core_true_QMARK__A).Invoke_O_O__O(root_1039, arg_1042) }; if jrt.J2g_Truth(tmp6) { tmp5 = nil } else { tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_173, result__5)) } } else {
//line :435:1
			tmp5 = nil }
//line :431:1
	var tmp7 any = tmp5; var tmp8 lang.IPersistentMap; var temp__1927000414__auto____4_2 any = A_arbace_spec_test_alpha_A_const_174.Invoke_O__O(test_check_ret__2)





	if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var shrunk__5 any = temp__1927000414__auto____4_2; var tmp9 any = A_arbace_spec_test_alpha_A_const_173; tmp8 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, A_arbace_spec_test_alpha_A_const_165.Invoke_O__O(shrunk__5))) } else { tmp8 = nil }
//line :431:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, tmp7, tmp8)
}







func A_arbace_spec_test_alpha_check_1_A_New() *A_arbace_spec_test_alpha_check_1_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_1_A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_spec_test_alpha_check_1_A) Ctor() {}
//line :440:1
func (t *A_arbace_spec_test_alpha_check_1_A) Invoke_O_O_O__O(self, p__107000117__0, opts__1 any) any { var map__107000118__3 any = p__107000117__0; var map__107000118__4 any; if lang.ISeq_InstanceOf(map__107000118__3) { var tmp1 any; var root_1050 any = A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = map__107000118__3; if linked_1051 == nil { tmp1 = ifn_1052.Invoke_O__O(arg_1053) } else { tmp1 = linked_1051.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1050, arg_1053) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1054 any = A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = map__107000118__3; if linked_1055 == nil { tmp2 = ifn_1056.Invoke_O__O(arg_1057) } else { tmp2 = linked_1055.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1054, arg_1057) }; map__107000118__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1058 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = map__107000118__3; if linked_1059 == nil { tmp3 = ifn_1060.Invoke_O__O(arg_1061) } else { tmp3 = linked_1059.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1058, arg_1061) }; if jrt.J2g_Truth(tmp3) { var root_1062 any = A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = map__107000118__3; if linked_1063 == nil { map__107000118__4 = ifn_1064.Invoke_O__O(arg_1065) } else { map__107000118__4 = linked_1063.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1062, arg_1065) } } else { map__107000118__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000118__4 = map__107000118__3 }; var s__5 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_175); var f__6 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_176); var v__7 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_177); var spec__8 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_82); var re_inst_QMARK___9 any; var and__1927000168__auto____9 any = v__7; if

	jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_1070 any = A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1072 lang.IFn; if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any; var root_1066 any = A_arbace_spec_test_alpha_A_const_155.GetRawRoot__O(); var linked_1067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1066, A_arbace_spec_test_alpha_unstrument_A_fn_class); var ifn_1068 lang.IFn; if linked_1067 == nil { ifn_1068 = lang.IFn_Cast(root_1066) } else { ifn_1068 = nil }; var arg_1069 any = s__5; if linked_1067 == nil { arg_1073 = ifn_1068.Invoke_O__O(arg_1069) } else { arg_1073 = linked_1067.(*A_arbace_spec_test_alpha_unstrument_A).Invoke_O_O__O(root_1066, arg_1069) }; if linked_1071 == nil { and__1927000168__auto____10 = ifn_1072.Invoke_O__O(arg_1073) } else { and__1927000168__auto____10 = linked_1071.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1070, arg_1073) }; if jrt.J2g_Truth(and__1927000168__auto____10) { re_inst_QMARK___9 = jrt.Boolean_TRUE.Ref() } else { re_inst_QMARK___9 = and__1927000168__auto____10 } } else { re_inst_QMARK___9 = and__1927000168__auto____9 }; var f__10 any; var or__1927000174__auto____10 any = f__6; if
	jrt.J2g_Truth(or__1927000174__auto____10) { f__10 = or__1927000174__auto____10 } else { if jrt.J2g_Truth(v__7) { var root_1074 any = A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = v__7; if linked_1075 == nil { f__10 = ifn_1076.Invoke_O__O(arg_1077) } else { f__10 = linked_1075.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1074, arg_1077) } } else { f__10 = nil } }; var specd__11 any; var root_1078 any = /*line :440:1*/A_arbace_spec_test_alpha_A_const_178.GetRawRoot__O(); var linked_1079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1078, aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_impl_A_fn_class); var ifn_1080 lang.IFn; if



	linked_1079 == nil { ifn_1080 = lang.IFn_Cast(root_1078) } else { ifn_1080 = nil }; var arg_1081 any = A_arbace_spec_test_alpha_A_const_179; var arg_1082 any = spec__8; var arg_1083 any; var arg_1084 any; if linked_1079 == nil { specd__11 = ifn_1080.Invoke_O_O_O_O__O(arg_1081, arg_1082, arg_1083, arg_1084) } else { specd__11 = linked_1079.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_spec_impl_A).Invoke_O_O_O_O_O__O(root_1078, arg_1081, arg_1082, arg_1083, arg_1084) }; var tmp4 any; tmp10 := /*line :440:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		{ var tmp5 any; var or__1927000174__auto____14 bool = lang.Util_Identical_O_O__Z_NoInit(f__10, nil)
			if or__1927000174__auto____14 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____14).Ref() } else { var G__107000120__15_ any = v__7; var G__107000120__16_ any; if lang.Util_Identical_O_O__Z_NoInit(G__107000120__15_, nil) { G__107000120__16_ = nil } else { G__107000120__16_ = lang.RT_Meta_O__IPersistentMap_NoInit(G__107000120__15_) }; if lang.Util_Identical_O_O__Z_NoInit(G__107000120__16_, nil) { tmp5 = nil } else { tmp5 = A_arbace_spec_test_alpha_A_const_124.Invoke_O__O(G__107000120__16_) } }
//line :446:1
			if jrt.J2g_Truth(tmp5) { var tmp6 any = A_arbace_spec_test_alpha_A_const_173; var tmp7 any; var root_1085 any = A_arbace_spec_test_alpha_A_const_76.GetRawRoot__O(); var linked_1086 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1085, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1087 lang.IFn

				if linked_1086 == nil { ifn_1087 = lang.IFn_Cast(root_1085) } else { ifn_1087 = nil }; var arg_1088 any = Lit_7; var arg_1089 any = A_arbace_spec_test_alpha_A_const_180; if linked_1086 == nil { tmp7 = ifn_1087.Invoke_O_O__O(arg_1088, arg_1089) } else { tmp7 = linked_1086.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1085, arg_1088, arg_1089) }
//line :446:1
				tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp7, A_arbace_spec_test_alpha_A_const_171, s__5, A_arbace_spec_test_alpha_A_const_82, spec__8)) } else { if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specd__11)) { var tcret__14 any; var root_1090 any = A_arbace_spec_test_alpha_A_const_181.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, A_arbace_spec_test_alpha_quick_check_A_fn_class); var ifn_1092 lang.IFn





					if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any = f__10; var arg_1094 any = specd__11; var arg_1095 any = opts__1; if linked_1091 == nil { tcret__14 = ifn_1092.Invoke_O_O_O__O(arg_1093, arg_1094, arg_1095) } else { tcret__14 = linked_1091.(*A_arbace_spec_test_alpha_quick_check_A).Invoke_O_O_O_O__O(root_1090, arg_1093, arg_1094, arg_1095) }
					var root_1096 any = A_arbace_spec_test_alpha_A_const_182.GetRawRoot__O(); var linked_1097 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1096, A_arbace_spec_test_alpha_make_check_result_A_fn_class); var ifn_1098 lang.IFn; if linked_1097 == nil { ifn_1098 = lang.IFn_Cast(root_1096) } else { ifn_1098 = nil }; var arg_1099 any = s__5; var arg_1100 any = spec__8; var arg_1101 any = tcret__14; if linked_1097 == nil { tmp4 = ifn_1098.Invoke_O_O_O__O(arg_1099, arg_1100, arg_1101) } else { tmp4 = linked_1097.(*A_arbace_spec_test_alpha_make_check_result_A).Invoke_O_O_O_O__O(root_1096, arg_1099, arg_1100, arg_1101) } } else {
//line :446:1
						if A_arbace_spec_test_alpha_A_const_113 != nil { var tmp8 any = A_arbace_spec_test_alpha_A_const_173; var tmp9 any; var root_1102 any = A_arbace_spec_test_alpha_A_const_76.GetRawRoot__O(); var linked_1103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1102, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_1104 lang.IFn









							if linked_1103 == nil { ifn_1104 = lang.IFn_Cast(root_1102) } else { ifn_1104 = nil }; var arg_1105 any = Lit_8; var arg_1106 any = A_arbace_spec_test_alpha_A_const_183; if linked_1103 == nil { tmp9 = ifn_1104.Invoke_O_O__O(arg_1105, arg_1106) } else { tmp9 = linked_1103.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_1102, arg_1105, arg_1106) }
//line :446:1
							tmp4 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, tmp9, A_arbace_spec_test_alpha_A_const_171, s__5, A_arbace_spec_test_alpha_A_const_82, spec__8)) } else { tmp4 = nil } } } }
//line :440:1
		return nil }(); if


















	jrt.J2g_Truth(re_inst_QMARK___9) { var root_1107 any = A_arbace_spec_test_alpha_A_const_153.GetRawRoot__O(); var linked_1108 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1107, A_arbace_spec_test_alpha_instrument_A_fn_class); var ifn_1109 lang.IFn; if linked_1108 == nil { ifn_1109 = lang.IFn_Cast(root_1107) } else { ifn_1109 = nil }; var arg_1110 any = s__5; if linked_1108 == nil { ifn_1109.Invoke_O__O(arg_1110) } else { linked_1108.(*A_arbace_spec_test_alpha_instrument_A).Invoke_O_O__O(root_1107, arg_1110) } }; if /*line :440:1*/ tmp10 != nil { panic(tmp10) }; return tmp4 }




















func A_arbace_spec_test_alpha_sym__GT_check_map_A_New() *A_arbace_spec_test_alpha_sym__GT_check_map_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_sym__GT_check_map_A{}; t.Ctor(); return t }
//line :461:1
func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Ctor() {}
//line :461:1
func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Invoke_O_O__O(self, s__0 any) any { var v__2 any; var root_1111 any = A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, aot_arbace_core.A_arbace_core_resolve_A_fn_class); var ifn_1113 lang.IFn; if

	linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = s__0; if linked_1112 == nil { v__2 = ifn_1113.Invoke_O__O(arg_1114) } else { v__2 = linked_1112.(*aot_arbace_core.A_arbace_core_resolve_A).Invoke_O_O__O(root_1111, arg_1114) }; var tmp1 any = A_arbace_spec_test_alpha_A_const_175; var tmp2 any = A_arbace_spec_test_alpha_A_const_177; var tmp3 any = A_arbace_spec_test_alpha_A_const_82; var tmp4 any; if


	jrt.J2g_Truth(v__2) { var root_1115 any = A_arbace_spec_test_alpha_A_const_125.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A_fn_class); var ifn_1117 lang.IFn; if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = v__2; if linked_1116 == nil { tmp4 = ifn_1117.Invoke_O__O(arg_1118) } else { tmp4 = linked_1116.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_get_spec_A).Invoke_O_O__O(root_1115, arg_1118) } } else { tmp4 = nil }; return /*line :461:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, s__0, tmp2, v__2, tmp3, tmp4)) }






func A_arbace_spec_test_alpha_validate_check_opts_A_New() *A_arbace_spec_test_alpha_validate_check_opts_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_validate_check_opts_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Ctor() {}
//line :468:1
func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Invoke_O_O__O(self, opts__0 any) any {

	var tmp1 any; var root_1123 any = A_arbace_spec_test_alpha_A_const_145.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = A_arbace_spec_test_alpha_A_const_146.GetRawRoot__O(); var arg_1127 any; var root_1119 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_1120 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1119, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1121 lang.IFn; if linked_1120 == nil { ifn_1121 = lang.IFn_Cast(root_1119) } else { ifn_1121 = nil }; var arg_1122 any = A_arbace_spec_test_alpha_A_const_119.Invoke_O__O(opts__0); if linked_1120 == nil { arg_1127 = ifn_1121.Invoke_O__O(arg_1122) } else { arg_1127 = linked_1120.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1119, arg_1122) }; if linked_1124 == nil { tmp1 = ifn_1125.Invoke_O_O__O(arg_1126, arg_1127) } else { tmp1 = linked_1124.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_1123, arg_1126, arg_1127) }; if jrt.J2g_Truth(tmp1) { return nil } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, Lit_32, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_184))).Ref())))
	} }
func A_arbace_spec_test_alpha_check_fn_A_New() *A_arbace_spec_test_alpha_check_fn_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_fn_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Ctor() {}
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Invoke_O_O_O_O__O(self, f__0, spec__1, opts__2 any) any {




	var root_1137 any = A_arbace_spec_test_alpha_A_const_186.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, A_arbace_spec_test_alpha_validate_check_opts_A_fn_class); var ifn_1139 lang.IFn; if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = opts__2; if linked_1138 == nil { ifn_1139.Invoke_O__O(arg_1140) } else { linked_1138.(*A_arbace_spec_test_alpha_validate_check_opts_A).Invoke_O_O__O(root_1137, arg_1140) }
	var root_1132 any = A_arbace_spec_test_alpha_A_const_185.GetRawRoot__O(); var linked_1133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1132, A_arbace_spec_test_alpha_check_1_A_fn_class); var ifn_1134 lang.IFn; if linked_1133 == nil { ifn_1134 = lang.IFn_Cast(root_1132) } else { ifn_1134 = nil }; var arg_1135 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_176, f__0, A_arbace_spec_test_alpha_A_const_82, spec__1)); var arg_1136 any = opts__2; if linked_1133 == nil { return ifn_1134.Invoke_O_O__O(arg_1135, arg_1136) } else { return linked_1133.(*A_arbace_spec_test_alpha_check_1_A).Invoke_O_O_O__O(root_1132, arg_1135, arg_1136) } }
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Invoke_O_O_O__O(self, f__0, spec__1 any) any {


	var root_1141 any = A_arbace_spec_test_alpha_A_const_187.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, A_arbace_spec_test_alpha_check_fn_A_fn_class); var ifn_1143 lang.IFn; if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = f__0; var arg_1145 any = spec__1; var arg_1146 any; if linked_1142 == nil { return ifn_1143.Invoke_O_O_O__O(arg_1144, arg_1145, arg_1146) } else { return linked_1142.(*A_arbace_spec_test_alpha_check_fn_A).Invoke_O_O_O_O__O(root_1141, arg_1144, arg_1145, arg_1146)
	}
}


func A_arbace_spec_test_alpha_checkable_syms_A_New() *A_arbace_spec_test_alpha_checkable_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_checkable_syms_A{}; t.Ctor(); return t }
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Ctor() {}
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Invoke_O_O__O(self, opts__0 any) any {




	var root_1169 any = A_arbace_spec_test_alpha_A_const_186.GetRawRoot__O(); var linked_1170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1169, A_arbace_spec_test_alpha_validate_check_opts_A_fn_class); var ifn_1171 lang.IFn; if linked_1170 == nil { ifn_1171 = lang.IFn_Cast(root_1169) } else { ifn_1171 = nil }; var arg_1172 any = opts__0; if linked_1170 == nil { ifn_1171.Invoke_O__O(arg_1172) } else { linked_1170.(*A_arbace_spec_test_alpha_validate_check_opts_A).Invoke_O_O__O(root_1169, arg_1172) }
	var root_1163 any = A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var arg_1167 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_1168 any; var tmp1 any; var root_1154 any = A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = A_arbace_spec_test_alpha_A_const_143.GetRawRoot__O(); var arg_1158 any; var root_1150 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_1151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1150, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1152 lang.IFn; if linked_1151 == nil { ifn_1152 = lang.IFn_Cast(root_1150) } else { ifn_1152 = nil }; var arg_1153 any; var root_1147 any = A_arbace_spec_test_alpha_A_const_144.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_spec_alpha.A_arbace_spec_alpha_registry_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; if linked_1148 == nil { arg_1153 = ifn_1149.Invoke__O() } else { arg_1153 = linked_1148.(*aot_arbace_spec_alpha.A_arbace_spec_alpha_registry_A).Invoke_O__O(root_1147) }; if linked_1151 == nil { arg_1158 = ifn_1152.Invoke_O__O(arg_1153) } else { arg_1158 = linked_1151.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1150, arg_1153) }; if linked_1155 == nil { tmp1 = ifn_1156.Invoke_O_O__O(arg_1157, arg_1158) } else { tmp1 = linked_1155.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1154, arg_1157, arg_1158) }; var tmp2 any = tmp1; var tmp3 any; var root_1159 any = A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1161 lang.IFn
	if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = A_arbace_spec_test_alpha_A_const_82.Invoke_O__O(opts__0); if linked_1160 == nil { tmp3 = ifn_1161.Invoke_O__O(arg_1162) } else { tmp3 = linked_1160.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1159, arg_1162) }
//line :486:1
	arg_1168 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, tmp3); if linked_1164 == nil { return ifn_1165.Invoke_O_O_O__O(arg_1166, arg_1167, arg_1168) } else { return linked_1164.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1163, arg_1166, arg_1167, arg_1168) } }
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Invoke_O__O(self any) any {


	var root_1173 any = A_arbace_spec_test_alpha_A_const_188.GetRawRoot__O(); var linked_1174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1173, A_arbace_spec_test_alpha_checkable_syms_A_fn_class); var ifn_1175 lang.IFn; if linked_1174 == nil { ifn_1175 = lang.IFn_Cast(root_1173) } else { ifn_1175 = nil }; var arg_1176 any; if linked_1174 == nil { return ifn_1175.Invoke_O__O(arg_1176) } else { return linked_1174.(*A_arbace_spec_test_alpha_checkable_syms_A).Invoke_O_O__O(root_1173, arg_1176)
	}
}



func A_arbace_spec_test_alpha_check_A_New() *A_arbace_spec_test_alpha_check_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Ctor() {}
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O_O_O__O(self, sym_or_syms__0, opts__1 any) any {





































	var root_1200 any = A_arbace_spec_test_alpha_A_const_189.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any; var tmp1 any = A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(opts__1); var tmp2 *jrt.Class; var fncls__1186 *jrt.Class = A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class; if fncls__1186 == nil { var fncls__1186d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class = fncls__1186d; tmp2 = fncls__1186d } else { tmp2 = fncls__1186 }; arg_1203 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1204 any; var root_1195 any = A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O(); var linked_1196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1195, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1197 lang.IFn
//line :526:1
	if linked_1196 == nil { ifn_1197 = lang.IFn_Cast(root_1195) } else { ifn_1197 = nil }; var arg_1198 any; var root_1187 any = A_arbace_spec_test_alpha_A_const_188.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, A_arbace_spec_test_alpha_checkable_syms_A_fn_class); var ifn_1189 lang.IFn; if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = opts__1; if linked_1188 == nil { arg_1198 = ifn_1189.Invoke_O__O(arg_1190) } else { arg_1198 = linked_1188.(*A_arbace_spec_test_alpha_checkable_syms_A).Invoke_O_O__O(root_1187, arg_1190) }; var arg_1199 any; var root_1191 any = A_arbace_spec_test_alpha_A_const_27.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, A_arbace_spec_test_alpha_collectionize_A_fn_class); var ifn_1193 lang.IFn
//line :525:1
	if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = sym_or_syms__0; if linked_1192 == nil { arg_1199 = ifn_1193.Invoke_O__O(arg_1194) } else { arg_1199 = linked_1192.(*A_arbace_spec_test_alpha_collectionize_A).Invoke_O_O__O(root_1191, arg_1194) }
	if linked_1196 == nil { arg_1204 = ifn_1197.Invoke_O_O__O(arg_1198, arg_1199) } else { arg_1204 = linked_1196.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1195, arg_1198, arg_1199) }
	if linked_1201 == nil { return ifn_1202.Invoke_O_O__O(arg_1203, arg_1204) } else { return linked_1201.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1200, arg_1203, arg_1204) } }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O_O__O(self, sym_or_syms__0 any) any {

































	var root_1205 any = A_arbace_spec_test_alpha_A_const_191.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, A_arbace_spec_test_alpha_check_A_fn_class); var ifn_1207 lang.IFn; if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = sym_or_syms__0; var arg_1209 any; if linked_1206 == nil { return ifn_1207.Invoke_O_O__O(arg_1208, arg_1209) } else { return linked_1206.(*A_arbace_spec_test_alpha_check_A).Invoke_O_O_O__O(root_1205, arg_1208, arg_1209) } }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O__O(self any) any {
































	var root_1213 any = A_arbace_spec_test_alpha_A_const_191.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, A_arbace_spec_test_alpha_check_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any; var root_1210 any = A_arbace_spec_test_alpha_A_const_188.GetRawRoot__O(); var linked_1211 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1210, A_arbace_spec_test_alpha_checkable_syms_A_fn_class); var ifn_1212 lang.IFn; if linked_1211 == nil { ifn_1212 = lang.IFn_Cast(root_1210) } else { ifn_1212 = nil }; if linked_1211 == nil { arg_1216 = ifn_1212.Invoke__O() } else { arg_1216 = linked_1211.(*A_arbace_spec_test_alpha_checkable_syms_A).Invoke_O__O(root_1210) }; if linked_1214 == nil { return ifn_1215.Invoke_O__O(arg_1216) } else { return linked_1214.(*A_arbace_spec_test_alpha_check_A).Invoke_O_O__O(root_1213, arg_1216)
	}
}


func A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(p0 any) *A_arbace_spec_test_alpha_check_fn__107000127_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_fn__107000127_A{}; t.Ctor_O(p0); return t }
//line :527:1
func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :527:1
func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Invoke_O_O__O(self, p1__107000126_SHARP___1 any) any {
	var root_1181 any = A_arbace_spec_test_alpha_A_const_185.GetRawRoot__O(); var linked_1182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1181, A_arbace_spec_test_alpha_check_1_A_fn_class); var ifn_1183 lang.IFn; if linked_1182 == nil { ifn_1183 = lang.IFn_Cast(root_1181) } else { ifn_1183 = nil }; var arg_1184 any; var root_1177 any = A_arbace_spec_test_alpha_A_const_190.GetRawRoot__O(); var linked_1178 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1177, A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class); var ifn_1179 lang.IFn; if linked_1178 == nil { ifn_1179 = lang.IFn_Cast(root_1177) } else { ifn_1179 = nil }; var arg_1180 any = p1__107000126_SHARP___1; if linked_1178 == nil { arg_1184 = ifn_1179.Invoke_O__O(arg_1180) } else { arg_1184 = linked_1178.(*A_arbace_spec_test_alpha_sym__GT_check_map_A).Invoke_O_O__O(root_1177, arg_1180) }; var arg_1185 any = t.F_opts; if linked_1182 == nil { return ifn_1183.Invoke_O_O__O(arg_1184, arg_1185) } else { return linked_1182.(*A_arbace_spec_test_alpha_check_1_A).Invoke_O_O_O__O(root_1181, arg_1184, arg_1185)
	}
}

func A_arbace_spec_test_alpha_failure_type_A_New() *A_arbace_spec_test_alpha_failure_type_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_failure_type_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_spec_test_alpha_failure_type_A) Ctor() {}
//line :532:1
func (t *A_arbace_spec_test_alpha_failure_type_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 *lang.Keyword = A_arbace_spec_test_alpha_A_const_72; var tmp2 any; var root_1217 any = A_arbace_spec_test_alpha_A_const_192.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = x__0; if linked_1218 == nil { tmp2 = ifn_1219.Invoke_O__O(arg_1220) } else { tmp2 = linked_1218.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1217, arg_1220) }; return tmp1.Invoke_O__O(tmp2)
}
func A_arbace_spec_test_alpha_unwrap_failure_A_New() *A_arbace_spec_test_alpha_unwrap_failure_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_unwrap_failure_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Ctor() {}
//line :536:1
func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 any; var root_1221 any = A_arbace_spec_test_alpha_A_const_193.GetRawRoot__O(); var linked_1222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1221, A_arbace_spec_test_alpha_failure_type_A_fn_class); var ifn_1223 lang.IFn; if linked_1222 == nil { ifn_1223 = lang.IFn_Cast(root_1221) } else { ifn_1223 = nil }; var arg_1224 any = x__0; if linked_1222 == nil { tmp1 = ifn_1223.Invoke_O__O(arg_1224) } else { tmp1 = linked_1222.(*A_arbace_spec_test_alpha_failure_type_A).Invoke_O_O__O(root_1221, arg_1224) }; if jrt.J2g_Truth(tmp1) {
		var root_1225 any = A_arbace_spec_test_alpha_A_const_192.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_1227 lang.IFn; if linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = x__0; if linked_1226 == nil { return ifn_1227.Invoke_O__O(arg_1228) } else { return linked_1226.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_1225, arg_1228) } } else {
//line :538:1
			return x__0
		}
}

func A_arbace_spec_test_alpha_result_type_A_New() *A_arbace_spec_test_alpha_result_type_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_result_type_A{}; t.Ctor(); return t }
//line :542:1
func (t *A_arbace_spec_test_alpha_result_type_A) Ctor() {}
//line :542:1
func (t *A_arbace_spec_test_alpha_result_type_A) Invoke_O_O__O(self, ret__0 any) any { var failure__2 any = A_arbace_spec_test_alpha_A_const_173.Invoke_O__O(ret__0); if







	lang.Util_Identical_O_O__Z_NoInit(failure__2, nil) { return A_arbace_spec_test_alpha_A_const_194 } else { var tmp1 any; var root_1229 any = A_arbace_spec_test_alpha_A_const_193.GetRawRoot__O(); var linked_1230 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1229, A_arbace_spec_test_alpha_failure_type_A_fn_class); var ifn_1231 lang.IFn

		if linked_1230 == nil { ifn_1231 = lang.IFn_Cast(root_1229) } else { ifn_1231 = nil }; var arg_1232 any = failure__2; if linked_1230 == nil { tmp1 = ifn_1231.Invoke_O__O(arg_1232) } else { tmp1 = linked_1230.(*A_arbace_spec_test_alpha_failure_type_A).Invoke_O_O__O(root_1229, arg_1232) }
//line :550:1
		if jrt.J2g_Truth(tmp1) {

			var root_1233 any = A_arbace_spec_test_alpha_A_const_193.GetRawRoot__O(); var linked_1234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1233, A_arbace_spec_test_alpha_failure_type_A_fn_class); var ifn_1235 lang.IFn; if linked_1234 == nil { ifn_1235 = lang.IFn_Cast(root_1233) } else { ifn_1235 = nil }; var arg_1236 any = failure__2; if linked_1234 == nil { return ifn_1235.Invoke_O__O(arg_1236) } else { return linked_1234.(*A_arbace_spec_test_alpha_failure_type_A).Invoke_O_O__O(root_1233, arg_1236) } } else {
//line :550:1
				if A_arbace_spec_test_alpha_A_const_113 != nil { return A_arbace_spec_test_alpha_A_const_195 } else { return nil } } } }




func A_arbace_spec_test_alpha_abbrev_result_A_New() *A_arbace_spec_test_alpha_abbrev_result_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_abbrev_result_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_spec_test_alpha_abbrev_result_A) Ctor() {}
//line :555:1
func (t *A_arbace_spec_test_alpha_abbrev_result_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_173.Invoke_O__O(x__0)) {


		var root_1248 any = A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O(); var linked_1249 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1248, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1250 lang.IFn; if linked_1249 == nil { ifn_1250 = lang.IFn_Cast(root_1248) } else { ifn_1250 = nil }; var arg_1251 any; var root_1242 any = A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1244 lang.IFn
//line :561:1
		if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any; var root_1237 any = A_arbace_spec_test_alpha_A_const_75.GetRawRoot__O(); var linked_1238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1237, aot_arbace_core.A_arbace_core_dissoc_A_fn_class); var ifn_1239 lang.IFn
//line :560:1
		if linked_1238 == nil { ifn_1239 = lang.IFn_Cast(root_1237) } else { ifn_1239 = nil }; var arg_1240 any = x__0; var arg_1241 any = A_arbace_spec_test_alpha_A_const_170; if linked_1238 == nil { arg_1245 = ifn_1239.Invoke_O_O__O(arg_1240, arg_1241) } else { arg_1245 = linked_1238.(*aot_arbace_core.A_arbace_core_dissoc_A).Invoke_O_O_O__O(root_1237, arg_1240, arg_1241) }
		var arg_1246 any = A_arbace_spec_test_alpha_A_const_82; var arg_1247 any = A_arbace_spec_test_alpha_A_const_197.GetRawRoot__O(); if linked_1243 == nil { arg_1251 = ifn_1244.Invoke_O_O_O__O(arg_1245, arg_1246, arg_1247) } else { arg_1251 = linked_1243.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1242, arg_1245, arg_1246, arg_1247) }
		var arg_1252 any = A_arbace_spec_test_alpha_A_const_173; var arg_1253 any = A_arbace_spec_test_alpha_A_const_198.GetRawRoot__O(); if linked_1249 == nil { return ifn_1250.Invoke_O_O_O__O(arg_1251, arg_1252, arg_1253) } else { return linked_1249.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1248, arg_1251, arg_1252, arg_1253) } } else {
			return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_75.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_spec_test_alpha_A_const_82, A_arbace_spec_test_alpha_A_const_170)
		} }
func A_arbace_spec_test_alpha_summarize_results_A_New() *A_arbace_spec_test_alpha_summarize_results_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_summarize_results_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Ctor() {}
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Invoke_O_O_O__O(self, check_results__0, summary_result__1 any) any {







	var root_1286 any = A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1286, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any; var tmp1 any = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(summary_result__1); var tmp2 *jrt.Class; var fncls__1285 *jrt.Class = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class
	if fncls__1285 == nil { var fncls__1285d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class = fncls__1285d; tmp2 = fncls__1285d } else { tmp2 = fncls__1285 }; arg_1289 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :573:1
	var arg_1290 any = A_arbace_spec_test_alpha_A_const_205; var arg_1291 any = check_results__0; if linked_1287 == nil { return ifn_1288.Invoke_O_O_O__O(arg_1289, arg_1290, arg_1291) } else { return linked_1287.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_1286, arg_1289, arg_1290, arg_1291) } }
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Invoke_O_O__O(self, check_results__0 any) any {





	var root_1292 any = A_arbace_spec_test_alpha_A_const_206.GetRawRoot__O(); var linked_1293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1292, A_arbace_spec_test_alpha_summarize_results_A_fn_class); var ifn_1294 lang.IFn; if linked_1293 == nil { ifn_1294 = lang.IFn_Cast(root_1292) } else { ifn_1294 = nil }; var arg_1295 any = check_results__0; var arg_1296 any = A_arbace_spec_test_alpha_A_const_207.GetRawRoot__O(); if linked_1293 == nil { return ifn_1294.Invoke_O_O__O(arg_1295, arg_1296) } else { return linked_1293.(*A_arbace_spec_test_alpha_summarize_results_A).Invoke_O_O_O__O(root_1292, arg_1295, arg_1296)
	}
}
func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(p0 any) *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_summarize_results_fn__107000134_A{}; t.Ctor_O(p0); return t }
//line :574:1
func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Ctor_O(c__summary_result any) { t.F_summary_result = c__summary_result }
//line :574:1
func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Invoke_O_O_O__O(self, summary__1, result__2 any) any {
	var root_1281 any = A_arbace_spec_test_alpha_A_const_204.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_pprint.A_arbace_pprint_pprint_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = lang.IFn_Cast(t.F_summary_result).Invoke_O__O(result__2); if linked_1282 == nil { ifn_1283.Invoke_O__O(arg_1284) } else { linked_1282.(*aot_arbace_pprint.A_arbace_pprint_pprint_A).Invoke_O_O__O(root_1281, arg_1284)
	}

	var root_1275 any = A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1275, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1277 lang.IFn; if linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any; var root_1260 any = A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O(); var linked_1261 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1260, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1262 lang.IFn
//line :577:1
	if linked_1261 == nil { ifn_1262 = lang.IFn_Cast(root_1260) } else { ifn_1262 = nil }; var arg_1263 any = summary__1; var arg_1264 any = A_arbace_spec_test_alpha_A_const_199; var arg_1265 any = A_arbace_spec_test_alpha_A_const_200.GetRawRoot__O(); if linked_1261 == nil { arg_1278 = ifn_1262.Invoke_O_O_O__O(arg_1263, arg_1264, arg_1265) } else { arg_1278 = linked_1261.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1260, arg_1263, arg_1264, arg_1265) }
	var arg_1279 any; var root_1266 any = A_arbace_spec_test_alpha_A_const_201.GetRawRoot__O(); var linked_1267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1266, A_arbace_spec_test_alpha_result_type_A_fn_class); var ifn_1268 lang.IFn; if linked_1267 == nil { ifn_1268 = lang.IFn_Cast(root_1266) } else { ifn_1268 = nil }; var arg_1269 any = result__2; if linked_1267 == nil { arg_1279 = ifn_1268.Invoke_O__O(arg_1269) } else { arg_1279 = linked_1267.(*A_arbace_spec_test_alpha_result_type_A).Invoke_O_O__O(root_1266, arg_1269) }; var arg_1280 any; var root_1270 any = A_arbace_spec_test_alpha_A_const_202.GetRawRoot__O(); var linked_1271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1270, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_1272 lang.IFn; if linked_1271 == nil { ifn_1272 = lang.IFn_Cast(root_1270) } else { ifn_1272 = nil }; var arg_1273 any = A_arbace_spec_test_alpha_A_const_200.GetRawRoot__O(); var arg_1274 any = A_arbace_spec_test_alpha_A_const_203; if linked_1271 == nil { arg_1280 = ifn_1272.Invoke_O_O__O(arg_1273, arg_1274) } else { arg_1280 = linked_1271.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_1270, arg_1273, arg_1274) }; if linked_1276 == nil { return ifn_1277.Invoke_O_O_O__O(arg_1278, arg_1279, arg_1280) } else { return linked_1276.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1275, arg_1278, arg_1279, arg_1280)
	}
}

type A_arbace_spec_test_alpha_A struct{ jrt.Object }

var A_arbace_spec_test_alpha_A_const_pool *jrt.RefArray

var A_arbace_spec_test_alpha_A_const_0 *lang.Var

var A_arbace_spec_test_alpha_A_const_1 any

var A_arbace_spec_test_alpha_A_const_2 any

var A_arbace_spec_test_alpha_A_const_3 any

var A_arbace_spec_test_alpha_A_const_4 any

var A_arbace_spec_test_alpha_A_const_5 *lang.Var

var A_arbace_spec_test_alpha_A_const_6 any

var A_arbace_spec_test_alpha_A_const_7 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_8 any

var A_arbace_spec_test_alpha_A_const_9 *lang.Var

var A_arbace_spec_test_alpha_A_const_10 *lang.Var

var A_arbace_spec_test_alpha_A_const_11 *lang.Var

var A_arbace_spec_test_alpha_A_const_12 *lang.Var

var A_arbace_spec_test_alpha_A_const_13 any

var A_arbace_spec_test_alpha_A_const_14 *lang.Var

var A_arbace_spec_test_alpha_A_const_15 *lang.Var

var A_arbace_spec_test_alpha_A_const_16 *lang.Var

var A_arbace_spec_test_alpha_A_const_17 *lang.Var

var A_arbace_spec_test_alpha_A_const_18 *lang.Var

var A_arbace_spec_test_alpha_A_const_19 *lang.Var

var A_arbace_spec_test_alpha_A_const_20 *lang.Var

var A_arbace_spec_test_alpha_A_const_21 *lang.Var

var A_arbace_spec_test_alpha_A_const_22 *lang.Var

var A_arbace_spec_test_alpha_A_const_23 *lang.Var

var A_arbace_spec_test_alpha_A_const_24 *lang.Var

var A_arbace_spec_test_alpha_A_const_25 *lang.Var

var A_arbace_spec_test_alpha_A_const_26 *lang.Var

var A_arbace_spec_test_alpha_A_const_27 *lang.Var

var A_arbace_spec_test_alpha_A_const_28 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_29 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_30 *lang.Var

var A_arbace_spec_test_alpha_A_const_31 *lang.Var

var A_arbace_spec_test_alpha_A_const_32 any

var A_arbace_spec_test_alpha_A_const_33 *lang.Var

var A_arbace_spec_test_alpha_A_const_34 *lang.Var

var A_arbace_spec_test_alpha_A_const_35 any

var A_arbace_spec_test_alpha_A_const_36 *lang.Var

var A_arbace_spec_test_alpha_A_const_37 *lang.Var

var A_arbace_spec_test_alpha_A_const_38 any

var A_arbace_spec_test_alpha_A_const_39 *lang.Var

var A_arbace_spec_test_alpha_A_const_40 any

var A_arbace_spec_test_alpha_A_const_41 *lang.Var

var A_arbace_spec_test_alpha_A_const_42 *lang.Var

var A_arbace_spec_test_alpha_A_const_43 any

var A_arbace_spec_test_alpha_A_const_44 any

var A_arbace_spec_test_alpha_A_const_45 *lang.Var

var A_arbace_spec_test_alpha_A_const_46 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_47 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_48 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_49 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_50 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_51 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_52 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_53 *lang.Var

var A_arbace_spec_test_alpha_A_const_54 *lang.Var

var A_arbace_spec_test_alpha_A_const_55 *lang.Var

var A_arbace_spec_test_alpha_A_const_56 *lang.Var

var A_arbace_spec_test_alpha_A_const_57 any

var A_arbace_spec_test_alpha_A_const_58 *lang.Var

var A_arbace_spec_test_alpha_A_const_59 *lang.Var

var A_arbace_spec_test_alpha_A_const_60 *lang.Var

var A_arbace_spec_test_alpha_A_const_61 *lang.Var

var A_arbace_spec_test_alpha_A_const_62 *lang.Var

var A_arbace_spec_test_alpha_A_const_63 *lang.Var

var A_arbace_spec_test_alpha_A_const_64 *lang.Var

var A_arbace_spec_test_alpha_A_const_65 *lang.Var

var A_arbace_spec_test_alpha_A_const_66 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_67 *lang.Var

var A_arbace_spec_test_alpha_A_const_68 *lang.Var

var A_arbace_spec_test_alpha_A_const_69 *lang.Var

var A_arbace_spec_test_alpha_A_const_70 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_71 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_72 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_73 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_74 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_75 *lang.Var

var A_arbace_spec_test_alpha_A_const_76 *lang.Var

var A_arbace_spec_test_alpha_A_const_77 *lang.Var

var A_arbace_spec_test_alpha_A_const_78 *lang.Var

var A_arbace_spec_test_alpha_A_const_79 *lang.Var

var A_arbace_spec_test_alpha_A_const_80 *lang.Var

var A_arbace_spec_test_alpha_A_const_81 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_82 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_83 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_84 *lang.Var

var A_arbace_spec_test_alpha_A_const_85 *lang.Var

var A_arbace_spec_test_alpha_A_const_86 *lang.Var

var A_arbace_spec_test_alpha_A_const_87 any

var A_arbace_spec_test_alpha_A_const_88 *lang.Var

var A_arbace_spec_test_alpha_A_const_89 *lang.Var

var A_arbace_spec_test_alpha_A_const_90 *lang.Var

var A_arbace_spec_test_alpha_A_const_91 *lang.Var

var A_arbace_spec_test_alpha_A_const_92 *lang.Var

var A_arbace_spec_test_alpha_A_const_93 *lang.Var

var A_arbace_spec_test_alpha_A_const_94 *lang.Var

var A_arbace_spec_test_alpha_A_const_95 *lang.Var

var A_arbace_spec_test_alpha_A_const_96 *lang.Var

var A_arbace_spec_test_alpha_A_const_97 *lang.Var

var A_arbace_spec_test_alpha_A_const_98 *lang.Var

var A_arbace_spec_test_alpha_A_const_99 any

var A_arbace_spec_test_alpha_A_const_100 *lang.Var

var A_arbace_spec_test_alpha_A_const_101 any

var A_arbace_spec_test_alpha_A_const_102 any

var A_arbace_spec_test_alpha_A_const_103 any

var A_arbace_spec_test_alpha_A_const_104 any

var A_arbace_spec_test_alpha_A_const_105 any

var A_arbace_spec_test_alpha_A_const_106 any

var A_arbace_spec_test_alpha_A_const_107 any

var A_arbace_spec_test_alpha_A_const_108 any

var A_arbace_spec_test_alpha_A_const_109 any

var A_arbace_spec_test_alpha_A_const_110 any

var A_arbace_spec_test_alpha_A_const_111 *lang.Var

var A_arbace_spec_test_alpha_A_const_112 *lang.Var

var A_arbace_spec_test_alpha_A_const_113 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_114 *lang.Var

var A_arbace_spec_test_alpha_A_const_115 any

var A_arbace_spec_test_alpha_A_const_116 *lang.Var

var A_arbace_spec_test_alpha_A_const_117 *lang.Var

var A_arbace_spec_test_alpha_A_const_118 *lang.Var

var A_arbace_spec_test_alpha_A_const_119 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_120 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_121 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_122 *lang.Var

var A_arbace_spec_test_alpha_A_const_123 *lang.Var

var A_arbace_spec_test_alpha_A_const_124 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_125 *lang.Var

var A_arbace_spec_test_alpha_A_const_126 *lang.Var

var A_arbace_spec_test_alpha_A_const_127 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_128 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_129 *lang.Var

var A_arbace_spec_test_alpha_A_const_130 *lang.Var

var A_arbace_spec_test_alpha_A_const_131 *lang.Var

var A_arbace_spec_test_alpha_A_const_132 *lang.Var

var A_arbace_spec_test_alpha_A_const_133 *lang.Var

var A_arbace_spec_test_alpha_A_const_134 *lang.Var

var A_arbace_spec_test_alpha_A_const_135 *lang.Var

var A_arbace_spec_test_alpha_A_const_136 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_137 *lang.Var

var A_arbace_spec_test_alpha_A_const_138 *lang.Var

var A_arbace_spec_test_alpha_A_const_139 *lang.Var

var A_arbace_spec_test_alpha_A_const_140 *lang.Var

var A_arbace_spec_test_alpha_A_const_141 *lang.Var

var A_arbace_spec_test_alpha_A_const_142 *lang.Var

var A_arbace_spec_test_alpha_A_const_143 *lang.Var

var A_arbace_spec_test_alpha_A_const_144 *lang.Var

var A_arbace_spec_test_alpha_A_const_145 *lang.Var

var A_arbace_spec_test_alpha_A_const_146 *lang.Var

var A_arbace_spec_test_alpha_A_const_147 any

var A_arbace_spec_test_alpha_A_const_148 *lang.Var

var A_arbace_spec_test_alpha_A_const_149 *lang.Var

var A_arbace_spec_test_alpha_A_const_150 *lang.Var

var A_arbace_spec_test_alpha_A_const_151 *lang.Var

var A_arbace_spec_test_alpha_A_const_152 *lang.Var

var A_arbace_spec_test_alpha_A_const_153 *lang.Var

var A_arbace_spec_test_alpha_A_const_154 *lang.Var

var A_arbace_spec_test_alpha_A_const_155 *lang.Var

var A_arbace_spec_test_alpha_A_const_156 *lang.Var

var A_arbace_spec_test_alpha_A_const_157 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_158 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_159 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_160 *lang.Var

var A_arbace_spec_test_alpha_A_const_161 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_162 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_163 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_164 *lang.Var

var A_arbace_spec_test_alpha_A_const_165 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_166 *lang.Var

var A_arbace_spec_test_alpha_A_const_167 *lang.Var

var A_arbace_spec_test_alpha_A_const_168 *lang.Var

var A_arbace_spec_test_alpha_A_const_169 *lang.Var

var A_arbace_spec_test_alpha_A_const_170 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_171 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_172 *lang.Var

var A_arbace_spec_test_alpha_A_const_173 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_174 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_175 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_176 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_177 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_178 *lang.Var

var A_arbace_spec_test_alpha_A_const_179 any

var A_arbace_spec_test_alpha_A_const_180 any

var A_arbace_spec_test_alpha_A_const_181 *lang.Var

var A_arbace_spec_test_alpha_A_const_182 *lang.Var

var A_arbace_spec_test_alpha_A_const_183 any

var A_arbace_spec_test_alpha_A_const_184 any

var A_arbace_spec_test_alpha_A_const_185 *lang.Var

var A_arbace_spec_test_alpha_A_const_186 *lang.Var

var A_arbace_spec_test_alpha_A_const_187 *lang.Var

var A_arbace_spec_test_alpha_A_const_188 *lang.Var

var A_arbace_spec_test_alpha_A_const_189 *lang.Var

var A_arbace_spec_test_alpha_A_const_190 *lang.Var

var A_arbace_spec_test_alpha_A_const_191 *lang.Var

var A_arbace_spec_test_alpha_A_const_192 *lang.Var

var A_arbace_spec_test_alpha_A_const_193 *lang.Var

var A_arbace_spec_test_alpha_A_const_194 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_195 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_196 *lang.Var

var A_arbace_spec_test_alpha_A_const_197 *lang.Var

var A_arbace_spec_test_alpha_A_const_198 *lang.Var

var A_arbace_spec_test_alpha_A_const_199 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_200 *lang.Var

var A_arbace_spec_test_alpha_A_const_201 *lang.Var

var A_arbace_spec_test_alpha_A_const_202 *lang.Var

var A_arbace_spec_test_alpha_A_const_203 any

var A_arbace_spec_test_alpha_A_const_204 *lang.Var

var A_arbace_spec_test_alpha_A_const_205 any

var A_arbace_spec_test_alpha_A_const_206 *lang.Var

var A_arbace_spec_test_alpha_A_const_207 *lang.Var

var A_arbace_spec_test_alpha_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_A_Init() { if !A_arbace_spec_test_alpha_A_init.Done() { A_arbace_spec_test_alpha_A_init.Run(A_arbace_spec_test_alpha_A_clinit) } }

func A_arbace_spec_test_alpha_A_clinit() { A_arbace_spec_test_alpha_A_clinit_p0(); A_arbace_spec_test_alpha_A_clinit_p1(); A_arbace_spec_test_alpha_A_clinit_p2(); A_arbace_spec_test_alpha_A_clinit_p3(); A_arbace_spec_test_alpha_A_clinit_p4(); A_arbace_spec_test_alpha_A_clinit_p5(); A_arbace_spec_test_alpha_A_clinit_p6(); A_arbace_spec_test_alpha_A_clinit_p7(); A_arbace_spec_test_alpha_A_clinit_p8(); A_arbace_spec_test_alpha_A_clinit_p9(); A_arbace_spec_test_alpha_A_clinit_p10(); A_arbace_spec_test_alpha_A_clinit_p11(); A_arbace_spec_test_alpha_A_clinit_p12(); A_arbace_spec_test_alpha_A_clinit_p13(); A_arbace_spec_test_alpha_A_clinit_p14(); A_arbace_spec_test_alpha_A_clinit_p15(); A_arbace_spec_test_alpha_A_clinit_p16(); A_arbace_spec_test_alpha_A_clinit_p17() }

func A_arbace_spec_test_alpha_A_clinit_p0() { jrt.StartCheck(); A_arbace_spec_test_alpha_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 285); A_arbace_spec_test_alpha_A_const_0 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[77]); A_arbace_spec_test_alpha_A_const_1 = A_arbace_spec_test_alpha_A_const_pool.A[78]; A_arbace_spec_test_alpha_A_const_2 = A_arbace_spec_test_alpha_A_const_pool.A[79]; A_arbace_spec_test_alpha_A_const_3 = A_arbace_spec_test_alpha_A_const_pool.A[80]; A_arbace_spec_test_alpha_A_const_4 = A_arbace_spec_test_alpha_A_const_pool.A[81]; A_arbace_spec_test_alpha_A_const_5 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[82]); A_arbace_spec_test_alpha_A_const_6 = A_arbace_spec_test_alpha_A_const_pool.A[83]; A_arbace_spec_test_alpha_A_const_7 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[84]); A_arbace_spec_test_alpha_A_const_8 = A_arbace_spec_test_alpha_A_const_pool.A[85]; A_arbace_spec_test_alpha_A_const_9 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[86]); A_arbace_spec_test_alpha_A_const_10 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[87]); A_arbace_spec_test_alpha_A_const_11 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[88]) }

func A_arbace_spec_test_alpha_A_clinit_p1() { A_arbace_spec_test_alpha_A_const_12 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[89]); A_arbace_spec_test_alpha_A_const_13 = A_arbace_spec_test_alpha_A_const_pool.A[90]; A_arbace_spec_test_alpha_A_const_14 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[91]); A_arbace_spec_test_alpha_A_const_15 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[92]); A_arbace_spec_test_alpha_A_const_16 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[93]); A_arbace_spec_test_alpha_A_const_17 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[94]); A_arbace_spec_test_alpha_A_const_18 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[95]); A_arbace_spec_test_alpha_A_const_19 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[96]); A_arbace_spec_test_alpha_A_const_20 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[97]); A_arbace_spec_test_alpha_A_const_21 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[98]); A_arbace_spec_test_alpha_A_const_22 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[99]); A_arbace_spec_test_alpha_A_const_23 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[100]) }

func A_arbace_spec_test_alpha_A_clinit_p2() { A_arbace_spec_test_alpha_A_const_24 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[101]); A_arbace_spec_test_alpha_A_const_25 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[102]); A_arbace_spec_test_alpha_A_const_26 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[103]); A_arbace_spec_test_alpha_A_const_27 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[104]); A_arbace_spec_test_alpha_A_const_28 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[105]); A_arbace_spec_test_alpha_A_const_29 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[106]); A_arbace_spec_test_alpha_A_const_30 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[107]); A_arbace_spec_test_alpha_A_const_31 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[108]); A_arbace_spec_test_alpha_A_const_32 = A_arbace_spec_test_alpha_A_const_pool.A[109]; A_arbace_spec_test_alpha_A_const_33 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[110]); A_arbace_spec_test_alpha_A_const_34 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[111]); A_arbace_spec_test_alpha_A_const_35 = A_arbace_spec_test_alpha_A_const_pool.A[112] }

func A_arbace_spec_test_alpha_A_clinit_p3() { A_arbace_spec_test_alpha_A_const_36 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[113]); A_arbace_spec_test_alpha_A_const_37 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[114]); A_arbace_spec_test_alpha_A_const_38 = A_arbace_spec_test_alpha_A_const_pool.A[115]; A_arbace_spec_test_alpha_A_const_39 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[116]); A_arbace_spec_test_alpha_A_const_40 = A_arbace_spec_test_alpha_A_const_pool.A[117]; A_arbace_spec_test_alpha_A_const_41 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[118]); A_arbace_spec_test_alpha_A_const_42 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[119]); A_arbace_spec_test_alpha_A_const_43 = A_arbace_spec_test_alpha_A_const_pool.A[120]; A_arbace_spec_test_alpha_A_const_44 = A_arbace_spec_test_alpha_A_const_pool.A[121]; A_arbace_spec_test_alpha_A_const_45 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[122]); A_arbace_spec_test_alpha_A_const_46 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[123]); A_arbace_spec_test_alpha_A_const_47 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[124]); A_arbace_spec_test_alpha_A_const_48 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[125]) }

func A_arbace_spec_test_alpha_A_clinit_p4() { A_arbace_spec_test_alpha_A_const_49 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[126]); A_arbace_spec_test_alpha_A_const_50 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[127]); A_arbace_spec_test_alpha_A_const_51 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[128]); A_arbace_spec_test_alpha_A_const_52 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[129]); A_arbace_spec_test_alpha_A_const_53 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[130]); A_arbace_spec_test_alpha_A_const_54 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[131]); A_arbace_spec_test_alpha_A_const_55 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[132]); A_arbace_spec_test_alpha_A_const_56 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[133]); A_arbace_spec_test_alpha_A_const_57 = A_arbace_spec_test_alpha_A_const_pool.A[134]; A_arbace_spec_test_alpha_A_const_58 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[135]); A_arbace_spec_test_alpha_A_const_59 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[136]); A_arbace_spec_test_alpha_A_const_60 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[137]) }

func A_arbace_spec_test_alpha_A_clinit_p5() { A_arbace_spec_test_alpha_A_const_61 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[138]); A_arbace_spec_test_alpha_A_const_62 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[139]); A_arbace_spec_test_alpha_A_const_63 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[140]); A_arbace_spec_test_alpha_A_const_64 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[141]); A_arbace_spec_test_alpha_A_const_65 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[142]); A_arbace_spec_test_alpha_A_const_66 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[143]); A_arbace_spec_test_alpha_A_const_67 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[144]); A_arbace_spec_test_alpha_A_const_68 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[145]); A_arbace_spec_test_alpha_A_const_69 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[146]); A_arbace_spec_test_alpha_A_const_70 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[147]); A_arbace_spec_test_alpha_A_const_71 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[148]); A_arbace_spec_test_alpha_A_const_72 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[149]) }

func A_arbace_spec_test_alpha_A_clinit_p6() { A_arbace_spec_test_alpha_A_const_73 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[150]); A_arbace_spec_test_alpha_A_const_74 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[151]); A_arbace_spec_test_alpha_A_const_75 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[152]); A_arbace_spec_test_alpha_A_const_76 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[153]); A_arbace_spec_test_alpha_A_const_77 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[154]); A_arbace_spec_test_alpha_A_const_78 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[155]); A_arbace_spec_test_alpha_A_const_79 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[156]); A_arbace_spec_test_alpha_A_const_80 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[157]); A_arbace_spec_test_alpha_A_const_81 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[158]); A_arbace_spec_test_alpha_A_const_82 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[159]); A_arbace_spec_test_alpha_A_const_83 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[160]); A_arbace_spec_test_alpha_A_const_84 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[161]) }

func A_arbace_spec_test_alpha_A_clinit_p7() { A_arbace_spec_test_alpha_A_const_85 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[162]); A_arbace_spec_test_alpha_A_const_86 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[163]); A_arbace_spec_test_alpha_A_const_87 = A_arbace_spec_test_alpha_A_const_pool.A[164]; A_arbace_spec_test_alpha_A_const_88 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[165]); A_arbace_spec_test_alpha_A_const_89 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[166]); A_arbace_spec_test_alpha_A_const_90 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[167]); A_arbace_spec_test_alpha_A_const_91 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[168]); A_arbace_spec_test_alpha_A_const_92 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[169]); A_arbace_spec_test_alpha_A_const_93 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[170]); A_arbace_spec_test_alpha_A_const_94 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[171]); A_arbace_spec_test_alpha_A_const_95 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[172]); A_arbace_spec_test_alpha_A_const_96 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[173]) }

func A_arbace_spec_test_alpha_A_clinit_p8() { A_arbace_spec_test_alpha_A_const_97 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[174]); A_arbace_spec_test_alpha_A_const_98 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[175]); A_arbace_spec_test_alpha_A_const_99 = A_arbace_spec_test_alpha_A_const_pool.A[176]; A_arbace_spec_test_alpha_A_const_100 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[177]); A_arbace_spec_test_alpha_A_const_101 = A_arbace_spec_test_alpha_A_const_pool.A[178]; A_arbace_spec_test_alpha_A_const_102 = A_arbace_spec_test_alpha_A_const_pool.A[179]; A_arbace_spec_test_alpha_A_const_103 = A_arbace_spec_test_alpha_A_const_pool.A[180]; A_arbace_spec_test_alpha_A_const_104 = A_arbace_spec_test_alpha_A_const_pool.A[181]; A_arbace_spec_test_alpha_A_const_105 = A_arbace_spec_test_alpha_A_const_pool.A[182]; A_arbace_spec_test_alpha_A_const_106 = A_arbace_spec_test_alpha_A_const_pool.A[183]; A_arbace_spec_test_alpha_A_const_107 = A_arbace_spec_test_alpha_A_const_pool.A[184]; A_arbace_spec_test_alpha_A_const_108 = A_arbace_spec_test_alpha_A_const_pool.A[185]; A_arbace_spec_test_alpha_A_const_109 = A_arbace_spec_test_alpha_A_const_pool.A[186]; A_arbace_spec_test_alpha_A_const_110 = A_arbace_spec_test_alpha_A_const_pool.A[187] }

func A_arbace_spec_test_alpha_A_clinit_p9() { A_arbace_spec_test_alpha_A_const_111 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[188]); A_arbace_spec_test_alpha_A_const_112 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[189]); A_arbace_spec_test_alpha_A_const_113 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[190]); A_arbace_spec_test_alpha_A_const_114 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[191]); A_arbace_spec_test_alpha_A_const_115 = A_arbace_spec_test_alpha_A_const_pool.A[192]; A_arbace_spec_test_alpha_A_const_116 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[193]); A_arbace_spec_test_alpha_A_const_117 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[194]); A_arbace_spec_test_alpha_A_const_118 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[195]); A_arbace_spec_test_alpha_A_const_119 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[196]); A_arbace_spec_test_alpha_A_const_120 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[197]); A_arbace_spec_test_alpha_A_const_121 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[198]); A_arbace_spec_test_alpha_A_const_122 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[199]) }

func A_arbace_spec_test_alpha_A_clinit_p10() { A_arbace_spec_test_alpha_A_const_123 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[200]); A_arbace_spec_test_alpha_A_const_124 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[201]); A_arbace_spec_test_alpha_A_const_125 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[202]); A_arbace_spec_test_alpha_A_const_126 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[203]); A_arbace_spec_test_alpha_A_const_127 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[204]); A_arbace_spec_test_alpha_A_const_128 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[205]); A_arbace_spec_test_alpha_A_const_129 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[206]); A_arbace_spec_test_alpha_A_const_130 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[207]); A_arbace_spec_test_alpha_A_const_131 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[208]); A_arbace_spec_test_alpha_A_const_132 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[209]); A_arbace_spec_test_alpha_A_const_133 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[210]); A_arbace_spec_test_alpha_A_const_134 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[211]) }

func A_arbace_spec_test_alpha_A_clinit_p11() { A_arbace_spec_test_alpha_A_const_135 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[212]); A_arbace_spec_test_alpha_A_const_136 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[213]); A_arbace_spec_test_alpha_A_const_137 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[214]); A_arbace_spec_test_alpha_A_const_138 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[215]); A_arbace_spec_test_alpha_A_const_139 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[216]); A_arbace_spec_test_alpha_A_const_140 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[217]); A_arbace_spec_test_alpha_A_const_141 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[218]); A_arbace_spec_test_alpha_A_const_142 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[219]); A_arbace_spec_test_alpha_A_const_143 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[220]); A_arbace_spec_test_alpha_A_const_144 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[221]); A_arbace_spec_test_alpha_A_const_145 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[222]); A_arbace_spec_test_alpha_A_const_146 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[223]) }

func A_arbace_spec_test_alpha_A_clinit_p12() { A_arbace_spec_test_alpha_A_const_147 = A_arbace_spec_test_alpha_A_const_pool.A[224]; A_arbace_spec_test_alpha_A_const_148 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[225]); A_arbace_spec_test_alpha_A_const_149 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[226]); A_arbace_spec_test_alpha_A_const_150 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[227]); A_arbace_spec_test_alpha_A_const_151 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[228]); A_arbace_spec_test_alpha_A_const_152 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[229]); A_arbace_spec_test_alpha_A_const_153 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[230]); A_arbace_spec_test_alpha_A_const_154 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[231]); A_arbace_spec_test_alpha_A_const_155 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[232]); A_arbace_spec_test_alpha_A_const_156 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[233]); A_arbace_spec_test_alpha_A_const_157 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[234]); A_arbace_spec_test_alpha_A_const_158 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[235]) }

func A_arbace_spec_test_alpha_A_clinit_p13() { A_arbace_spec_test_alpha_A_const_159 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[236]); A_arbace_spec_test_alpha_A_const_160 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[237]); A_arbace_spec_test_alpha_A_const_161 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[238]); A_arbace_spec_test_alpha_A_const_162 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[239]); A_arbace_spec_test_alpha_A_const_163 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[240]); A_arbace_spec_test_alpha_A_const_164 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[241]); A_arbace_spec_test_alpha_A_const_165 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[242]); A_arbace_spec_test_alpha_A_const_166 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[243]); A_arbace_spec_test_alpha_A_const_167 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[244]); A_arbace_spec_test_alpha_A_const_168 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[245]); A_arbace_spec_test_alpha_A_const_169 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[246]); A_arbace_spec_test_alpha_A_const_170 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[247]) }

func A_arbace_spec_test_alpha_A_clinit_p14() { A_arbace_spec_test_alpha_A_const_171 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[248]); A_arbace_spec_test_alpha_A_const_172 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[249]); A_arbace_spec_test_alpha_A_const_173 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[250]); A_arbace_spec_test_alpha_A_const_174 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[251]); A_arbace_spec_test_alpha_A_const_175 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[252]); A_arbace_spec_test_alpha_A_const_176 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[253]); A_arbace_spec_test_alpha_A_const_177 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[254]); A_arbace_spec_test_alpha_A_const_178 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[255]); A_arbace_spec_test_alpha_A_const_179 = A_arbace_spec_test_alpha_A_const_pool.A[256]; A_arbace_spec_test_alpha_A_const_180 = A_arbace_spec_test_alpha_A_const_pool.A[257]; A_arbace_spec_test_alpha_A_const_181 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[258]); A_arbace_spec_test_alpha_A_const_182 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[259]) }

func A_arbace_spec_test_alpha_A_clinit_p15() { A_arbace_spec_test_alpha_A_const_183 = A_arbace_spec_test_alpha_A_const_pool.A[260]; A_arbace_spec_test_alpha_A_const_184 = A_arbace_spec_test_alpha_A_const_pool.A[261]; A_arbace_spec_test_alpha_A_const_185 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[262]); A_arbace_spec_test_alpha_A_const_186 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[263]); A_arbace_spec_test_alpha_A_const_187 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[264]); A_arbace_spec_test_alpha_A_const_188 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[265]); A_arbace_spec_test_alpha_A_const_189 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[266]); A_arbace_spec_test_alpha_A_const_190 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[267]); A_arbace_spec_test_alpha_A_const_191 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[268]); A_arbace_spec_test_alpha_A_const_192 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[269]); A_arbace_spec_test_alpha_A_const_193 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[270]); A_arbace_spec_test_alpha_A_const_194 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[271]) }

func A_arbace_spec_test_alpha_A_clinit_p16() { A_arbace_spec_test_alpha_A_const_195 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[272]); A_arbace_spec_test_alpha_A_const_196 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[273]); A_arbace_spec_test_alpha_A_const_197 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[274]); A_arbace_spec_test_alpha_A_const_198 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[275]); A_arbace_spec_test_alpha_A_const_199 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[276]); A_arbace_spec_test_alpha_A_const_200 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[277]); A_arbace_spec_test_alpha_A_const_201 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[278]); A_arbace_spec_test_alpha_A_const_202 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[279]); A_arbace_spec_test_alpha_A_const_203 = A_arbace_spec_test_alpha_A_const_pool.A[280]; A_arbace_spec_test_alpha_A_const_204 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[281]); A_arbace_spec_test_alpha_A_const_205 = A_arbace_spec_test_alpha_A_const_pool.A[282]; A_arbace_spec_test_alpha_A_const_206 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[283]) }

func A_arbace_spec_test_alpha_A_clinit_p17() { A_arbace_spec_test_alpha_A_const_207 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[284]) }

func A_arbace_spec_test_alpha_A_New() *A_arbace_spec_test_alpha_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_A_class }

func (t *A_arbace_spec_test_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_A); return ok }

func A_arbace_spec_test_alpha_A_Cast(x any) *A_arbace_spec_test_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_A_class)) }; return v }



type A_arbace_spec_test_alpha___GT_sym_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha___GT_sym_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha___GT_var_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha___GT_var_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_abbrev_result_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_abbrev_result_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_fixed_args_body_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_flattener_code_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_flattener_code_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A struct{ j2g_header uint64; F_closed_over_name any }

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_kwargs_body_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_varargs_body_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_varargs_body_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_fn__107000127_A struct{ j2g_header uint64; F_opts any }

var A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_1_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_1_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_call_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_call_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_fn_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_checkable_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_checkable_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_collectionize_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_collectionize_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_enumerate_namespace_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A struct{ j2g_header uint64; F_ns_sym any }

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_eval107000002_A struct{ jrt.Object }

func A_arbace_spec_test_alpha_eval107000002_A_New() *A_arbace_spec_test_alpha_eval107000002_A { t := &A_arbace_spec_test_alpha_eval107000002_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_eval107000002_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_eval107000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000002_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000002_A_class }

func (t *A_arbace_spec_test_alpha_eval107000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000002_A); return ok }

func A_arbace_spec_test_alpha_eval107000002_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000002_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_eval107000006_A struct{ jrt.Object }

func A_arbace_spec_test_alpha_eval107000006_A_New() *A_arbace_spec_test_alpha_eval107000006_A { t := &A_arbace_spec_test_alpha_eval107000006_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_eval107000006_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_eval107000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000006_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000006_A_class }

func (t *A_arbace_spec_test_alpha_eval107000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000006_A); return ok }

func A_arbace_spec_test_alpha_eval107000006_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000006_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000006_fn__107000007_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_explain_check_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_explain_check_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_failure_type_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_failure_type_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_find_varargs_decl_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_fn_spec_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_fn_spec_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_gen_fixed_args_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_has_kwargs_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_fn__107000097_A struct{ j2g_header uint64; F_opts any }

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_1_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_1_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_choose_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_choose_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrumentable_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_interpret_stack_trace_element_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_kwargs__GT_kvs_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_make_check_result_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_make_check_result_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_no_fspec_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_no_fspec_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_opt_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_opt_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_quick_check_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_quick_check_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_quick_check_fn__107000111_A struct{ j2g_header uint64; F_gen, F_specs any }

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_quick_check_fn__107000113_A struct{ j2g_header uint64; F_f, F_specs any }

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_result_type_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_result_type_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_spec_checking_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A struct{ j2g_header uint64; F_fn_name, F_f, F_conform_BANG_, F_fn_spec any }

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_summarize_results_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_summarize_results_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_summarize_results_fn__107000134_A struct{ j2g_header uint64; F_summary_result any }

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_sym__GT_check_map_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_throwable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_thunk_frame_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_unstrument_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_unstrument_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_unstrument_1_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_unstrument_1_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_unwrap_failure_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_unwrap_failure_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_validate_check_opts_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_validate_check_opts_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_with_instrument_disabled_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class *jrt.Class
