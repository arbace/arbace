//line aot_arbace_spec_test_alpha.ae:1
package aot_arbace_spec_test_alpha

import (
	"arbace/jrt"
	"arbace/lang"
)






func A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_New() *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_1.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_test_alpha_A_const_2, A_arbace_spec_test_alpha_A_const_3, A_arbace_spec_test_alpha_A_const_4); tmp2 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_test_alpha_A_const_5, A_arbace_spec_test_alpha_A_const_6, A_arbace_spec_test_alpha_A_const_7, A_arbace_spec_test_alpha_A_const_8); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :13:1
func A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_New() *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_eval107000006_fn__107000007_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Ctor() {}
//line :13:1
func (t *A_arbace_spec_test_alpha_eval107000006_fn__107000007_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_9.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_13), A_arbace_spec_test_alpha_A_const_11.GetRawRoot__O(), A_arbace_spec_test_alpha_A_const_12) }











func A_arbace_spec_test_alpha_throwable_QMARK__A_New() *A_arbace_spec_test_alpha_throwable_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_throwable_QMARK__A{}; t.Ctor(); return t }
//line :25:1
func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Ctor() {}
//line :25:1
func (t *A_arbace_spec_test_alpha_throwable_QMARK__A) Invoke_O_O__O(self, x__0 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.Throwable_InstanceOf(x__0)).Ref() }



func A_arbace_spec_test_alpha___GT_sym_A_New() *A_arbace_spec_test_alpha___GT_sym_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha___GT_sym_A{}; t.Ctor(); return t }
//line :29:1
func (t *A_arbace_spec_test_alpha___GT_sym_A) Ctor() {}
//line :29:1
func (t *A_arbace_spec_test_alpha___GT_sym_A) Invoke_O_O__O(self, x__0 any) any {

	return lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_14)).Invoke_O__O(x__0)
}
func A_arbace_spec_test_alpha___GT_var_A_New() *A_arbace_spec_test_alpha___GT_var_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha___GT_var_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_spec_test_alpha___GT_var_A) Ctor() {}
//line :33:1
func (t *A_arbace_spec_test_alpha___GT_var_A) Invoke_O_O__O(self, s_or_v__0 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(s_or_v__0)) { return s_or_v__0 } else { var v__2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(s_or_v__0)

		if jrt.J2g_Truth(and__1927000168__auto____2) { v__2 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O()).Invoke_O__O(s_or_v__0) } else { v__2 = and__1927000168__auto____2 }
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_15.GetRawRoot__O()).Invoke_O__O(v__2)) { return v__2 } else { panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_1), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_18.GetRawRoot__O()).Invoke_O__O(s_or_v__0), nil)))))
		}
	}
}
func A_arbace_spec_test_alpha_collectionize_A_New() *A_arbace_spec_test_alpha_collectionize_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_collectionize_A{}; t.Ctor(); return t }
//line :42:1
func (t *A_arbace_spec_test_alpha_collectionize_A) Ctor() {}
//line :42:1
func (t *A_arbace_spec_test_alpha_collectionize_A) Invoke_O_O__O(self, x__0 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(x__0)) {
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :44:1
			return x__0
		}
}

func A_arbace_spec_test_alpha_enumerate_namespace_A_New() *A_arbace_spec_test_alpha_enumerate_namespace_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_A{}; t.Ctor(); return t }
//line :48:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Ctor() {}
//line :48:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_A) Invoke_O_O__O(self, ns_sym_or_syms__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O()); var tmp2 any = lang.PersistentHashSet_EMPTY.Ref(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_21.GetRawRoot__O()); var tmp4 any = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New(); var tmp5 *jrt.Class
	var fncls__2 /*line :52:1*/*jrt.Class = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class

	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class = fncls__2d; tmp5 = fncls__2d } else { tmp5 = fncls__2 }
//line :52:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp3.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil)), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O()).Invoke_O__O(ns_sym_or_syms__0))
}
func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_New() *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A{}; t.Ctor(); return t }
//line :54:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Ctor() {}
//line :54:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A) Invoke_O_O__O(self, ns_sym__1 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(ns_sym__1); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class
	if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }
//line :55:1
	return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_27.GetRawRoot__O()).Invoke_O__O(ns_sym__1))) }
func A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_New_O(p0 any) *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A{}; t.Ctor_O(p0); return t }
//line :56:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Ctor_O(c__ns_sym any) { t.F_ns_sym = c__ns_sym }
//line :56:1
func (t *A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A) Invoke_O_O__O(self, name_sym__1 any) any {
	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_24.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(t.F_ns_sym), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_25.GetRawRoot__O()).Invoke_O__O(name_sym__1))
}








func A_arbace_spec_test_alpha_fn_spec_QMARK__A_New() *A_arbace_spec_test_alpha_fn_spec_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_fn_spec_QMARK__A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Ctor() {}
//line :67:1
func (t *A_arbace_spec_test_alpha_fn_spec_QMARK__A) Invoke_O_O__O(self, m__0 any) any { var or__1927000174__auto____2 any = A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(m__0); if


	jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { return A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(m__0) } }

func A_arbace_spec_test_alpha_with_instrument_disabled_A_New() *A_arbace_spec_test_alpha_with_instrument_disabled_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_with_instrument_disabled_A{}; t.Ctor(); return t }
//line :72:1
func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) Ctor() {}
//line :72:1
func (t *A_arbace_spec_test_alpha_with_instrument_disabled_A) DoInvoke_O_O_O_O__O(self, _AMPERSAND_form__0, _AMPERSAND_env__1, body__2 any) any { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_32), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_34.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_35), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(nil))))), body__2)) }





func A_arbace_spec_test_alpha_thunk_frame_QMARK__A_New() *A_arbace_spec_test_alpha_thunk_frame_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_thunk_frame_QMARK__A{}; t.Ctor(); return t }
//line :78:1
func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Ctor() {}
//line :78:1
func (t *A_arbace_spec_test_alpha_thunk_frame_QMARK__A) Invoke_O_O__O(self, s__0 any) any {
	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_36.GetRawRoot__O()).Invoke_O_O__O(s__0, Lit_31)
}
func A_arbace_spec_test_alpha_interpret_stack_trace_element_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_A{}; t.Ctor(); return t }
//line :81:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Ctor() {}
//line :81:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_A) Invoke_O_O__O(self, p__107000034__0 any) any { var vec__107000035__2 any = p__107000034__0; var cls__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(0), nil); var method__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(1), nil); var file__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(2), nil); var line__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000035__2, lang.RT_IntCast_J__I_NoInit(3), nil); var clojure_QMARK___7 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_41, method__4); var demunge__8 any; var tmp1 any = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class; if













	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_17, false); A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; demunge__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var degensym__9 any; var tmp3 any = /*line :81:1*/A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New(); var tmp4 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class; if













	fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_18, false); A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class = fncls__4d; tmp4 = fncls__4d } else { tmp4 = fncls__4 }; degensym__9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var vec__107000038__10 any; if


	jrt.J2g_Truth(clojure_QMARK___7) {

		vec__107000038__10 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()).Invoke_O_O__O(demunge__8, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_42.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_43.GetRawRoot__O()).Invoke_O__O(cls__3), A_arbace_spec_test_alpha_A_const_44, A_arbace_spec_test_alpha_A_const_45)) } else {
//line :98:1
			vec__107000038__10 = nil }; var ns_sym__11 any = /*line :81:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__107000038__10, lang.RT_IntCast_J__I_NoInit(0), nil); var name_sym__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000038__10, lang.RT_IntCast_J__I_NoInit(1), nil); var local__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000038__10, lang.RT_IntCast_J__I_NoInit(2), nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_40.GetRawRoot__O()); var tmp6 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_46, file__5, A_arbace_spec_test_alpha_A_const_47, line__6, A_arbace_spec_test_alpha_A_const_48, method__4, A_arbace_spec_test_alpha_A_const_49, cls__3)); var tmp7 lang.IPersistentMap; var tmp8 any; var and__1927000168__auto____14 any = ns_sym__11; if























	jrt.J2g_Truth(and__1927000168__auto____14) { tmp8 = name_sym__12 } else { tmp8 = and__1927000168__auto____14 }; if jrt.J2g_Truth(tmp8) { var tmp9 any = A_arbace_spec_test_alpha_A_const_50; tmp7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp9, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_24.GetRawRoot__O()).Invoke_O_O__O(ns_sym__11, name_sym__12))) } else { tmp7 = nil }; var tmp10 any = tmp7; var tmp11 lang.IPersistentMap; if

	jrt.J2g_Truth(local__13) { var tmp12 any = A_arbace_spec_test_alpha_A_const_51; var tmp13 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(degensym__9).Invoke_O__O(local__13)); var tmp14 any = A_arbace_spec_test_alpha_A_const_52; tmp11 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp13, tmp14, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_53.GetRawRoot__O()).Invoke_O__O(local__13))) } else { tmp11 = nil }; return /*line :101:1*/ tmp5.Invoke_O_O_O__O(tmp6, tmp10, tmp11) }
//line :95:1
func A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Ctor() {}
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A) Invoke_O_O__O(self, p1__107000033_SHARP___1 any) any {

	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_38.GetRawRoot__O()).Invoke_O_O_O__O(p1__107000033_SHARP___1, A_arbace_spec_test_alpha_A_const_39, Lit_19) }
//line :95:1
func A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_New() *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A{}; t.Ctor(); return t }
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Ctor() {}
//line :95:1
func (t *A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A) Invoke_O_O__O(self, p1__107000032_SHARP___1 any) any {
	return lang.Compiler_Demunge_String__String_NoInit(jrt.String_Cast(p1__107000032_SHARP___1)).Ref()
}













func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_New() *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A{}; t.Ctor(); return t }
//line :111:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Ctor() {}
//line :111:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A) Invoke_O_O__O(self, elems__0 any) any { var plumbing_QMARK___2 any; var tmp1 any = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New(); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class; if





	fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_29, false); A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; plumbing_QMARK___2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return /*line :122:1*/ lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_58.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_59.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_62.GetRawRoot__O()), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_63.GetRawRoot__O()), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_50), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_61.GetRawRoot__O()).Invoke_O__O(plumbing_QMARK___2)), elems__0) }
//line :117:1
func A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_New() *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Ctor() {}
//line :117:1
func (t *A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A) Invoke_O_O__O(self, p__107000046__1 any) any { var map__107000048__2 any = p__107000046__1; var map__107000048__3 any; if lang.ISeq_InstanceOf(map__107000048__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000048__2)) { map__107000048__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000048__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000048__2)) { map__107000048__3 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000048__2) } else { map__107000048__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000048__3 = map__107000048__2 }; var var_scope__4 any = lang.RT_Get_O_O__O_NoInit(map__107000048__3, A_arbace_spec_test_alpha_A_const_50); var thunk_QMARK___5 any = lang.RT_Get_O_O__O_NoInit(map__107000048__3, A_arbace_spec_test_alpha_A_const_52); var or__1927000174__auto____6 any = thunk_QMARK___5; if
																		jrt.J2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
																			return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_37.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_57, var_scope__4) } }








func A_arbace_spec_test_alpha_spec_checking_fn_A_New() *A_arbace_spec_test_alpha_spec_checking_fn_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_A{}; t.Ctor(); return t }
//line :128:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Ctor() {}
//line :128:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_A) Invoke_O_O_O_O__O(self, fn_name__0, f__1, fn_spec__2 any) any { var fn_spec__4 any = lang.IFn_Cast(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_80)).Invoke_O__O(fn_spec__2); var conform_BANG___5 any; var tmp1 any = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New(); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class; if






	fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; conform_BANG___5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 any =















	A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(fn_name__0, f__1, conform_BANG___5, fn_spec__4); var tmp4 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, true); A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class = fncls__7d; tmp4 = fncls__7d } else { tmp4 = fncls__7 }; return lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp3, tmp4, nil, 0) }
//line :135:1
func A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_New() *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Ctor() {}
//line :135:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A) Invoke_O_O_O_O_O_O__O(self, fn_name__1, role__2, spec__3, data__4, args__5 any) any { var conformed__6 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_64.GetRawRoot__O()).Invoke_O_O__O(spec__3, data__4); if

	lang.Util_Equiv_O_O__Z_NoInit(A_arbace_spec_test_alpha_A_const_65, conformed__6) { var caller__7 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_67.GetRawRoot__O()).Invoke_O__O(jrt.Thread_CurrentThread__Thread().GetStackTrace__StackTraceElement1().Ref())); var ed__8 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_40.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_68.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_71.GetRawRoot__O()).Invoke_O_O_O_O_O__O(spec__3, lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref(), data__4), A_arbace_spec_test_alpha_A_const_72, fn_name__1, A_arbace_spec_test_alpha_A_const_73, args__5, A_arbace_spec_test_alpha_A_const_74, A_arbace_spec_test_alpha_A_const_75); var tmp3 lang.IPersistentMap







		if jrt.J2g_Truth(caller__7) { var tmp4 any = A_arbace_spec_test_alpha_A_const_69; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_70.GetRawRoot__O()).Invoke_O_O_O__O(caller__7, A_arbace_spec_test_alpha_A_const_49, A_arbace_spec_test_alpha_A_const_48))) } else { tmp3 = nil }
//line :141:1
		ed__8 = tmp1.Invoke_O_O__O(tmp2, tmp3)
//line :137:1
		panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_27, nil, Lit_28), jrt.RefArrayOf(jrt.Object_class, nil, fn_name__1, nil)).Ref(), ed__8)))) } else { return conformed__6 } }













func A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :151:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) Ctor_O_O_O_O(c__fn_name, c__f, c__conform_BANG_, c__fn_spec any) { t.F_fn_name = c__fn_name; t.F_f = c__f; t.F_conform_BANG_ = c__conform_BANG_; t.F_fn_spec = c__fn_spec }
//line :151:1
func (t *A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A) DoInvoke_O_O__O(self, args__1 any) any {

	if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_76.Get__O()) {
		lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_76, nil))
//line :153:1
		var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)

			if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(t.F_fn_spec)) { var tmp2 lang.IFn = lang.IFn_Cast(t.F_conform_BANG_); var tmp3 any = t.F_fn_name; var tmp4 any = A_arbace_spec_test_alpha_A_const_28; tmp2.Invoke_O_O_O_O_O__O(tmp3, tmp4, A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(t.F_fn_spec), args__1, args__1) }
			lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_78.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_79.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_76, jrt.Boolean_TRUE.Ref()))
//line :153:1
			{ tmp6 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)



				{ var tmp5 lang.IFn = lang.IFn_Cast(t.F_f); tmp1 = tmp5.ApplyTo_ISeq__O(lang.ISeq_Cast(args__1)) }
//line :153:1
				return nil
			}()

				lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_77.GetRawRoot__O()).Invoke__O()
//line :153:1
				if tmp6 != nil { panic(tmp6) } }; return nil }()
		lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_77.GetRawRoot__O()).Invoke__O()
//line :153:1
		if tmp7 != nil { panic(tmp7) }; return tmp1 } else {




			var tmp8 lang.IFn = lang.IFn_Cast(t.F_f); return tmp8.ApplyTo_ISeq__O(lang.ISeq_Cast(args__1))
		} }
func A_arbace_spec_test_alpha_no_fspec_A_New() *A_arbace_spec_test_alpha_no_fspec_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_no_fspec_A{}; t.Ctor(); return t }
//line :160:1
func (t *A_arbace_spec_test_alpha_no_fspec_A) Ctor() {}
//line :160:1
func (t *A_arbace_spec_test_alpha_no_fspec_A) Invoke_O_O_O__O(self, v__0, spec__1 any) any {

	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_66.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_21, nil, Lit_22), jrt.RefArrayOf(jrt.Object_class, nil, v__0, nil)).Ref(), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_81, v__0, A_arbace_spec_test_alpha_A_const_82, spec__1, A_arbace_spec_test_alpha_A_const_74, A_arbace_spec_test_alpha_A_const_83)))
}



func A_arbace_spec_test_alpha_find_varargs_decl_A_New() *A_arbace_spec_test_alpha_find_varargs_decl_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_find_varargs_decl_A{}; t.Ctor(); return t }
//line :167:1
func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Ctor() {}
//line :167:1
func (t *A_arbace_spec_test_alpha_find_varargs_decl_A) Invoke_O_O__O(self, arglist__0 any) any { var vec__107000060__2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_84.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_85.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_86.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_87), arglist__0)); var ___3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000060__2, lang.RT_IntCast_J__I_NoInit(0), nil); var decl__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__107000060__2, lang.RT_IntCast_J__I_NoInit(1), nil); var restargs__5 any = vec__107000060__2; var and__1927000168__auto____6 bool = lang.Util_Equiv_J_J__Z_NoInit(2, int64(lang.RT_Count_O__I_NoInit(restargs__5))); _ = ___3; if and__1927000168__auto____6 {





	return decl__4 } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() } }


func A_arbace_spec_test_alpha_has_kwargs_QMARK__A_New() *A_arbace_spec_test_alpha_has_kwargs_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_has_kwargs_QMARK__A{}; t.Ctor(); return t }
//line :176:1
func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Ctor() {}
//line :176:1
func (t *A_arbace_spec_test_alpha_has_kwargs_QMARK__A) Invoke_O_O__O(self, arglists__0 any) any {
	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_88.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_89.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_90.GetRawRoot__O(), arglists__0))
}
func A_arbace_spec_test_alpha_kwargs__GT_kvs_A_New() *A_arbace_spec_test_alpha_kwargs__GT_kvs_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_kwargs__GT_kvs_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Ctor() {}
//line :179:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_A) Invoke_O_O__O(self, args__0 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_91.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(args__0)).Ref())) { return args__0 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_92.GetRawRoot__O()).Invoke_O__O(args__0); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_93.GetRawRoot__O()); var tmp4 any = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New(); var tmp5 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class
		if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_20, false); A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class = fncls__8d; tmp5 = fncls__8d } else { tmp5 = fncls__8 }
//line :186:1
		var tmp6 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var tmp7 any = lang.PersistentList_EMPTY.Ref(); return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O_O__O(tmp6, tmp7, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_95.GetRawRoot__O()).Invoke_O__O(args__0))) } }
func A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_New() *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A{}; t.Ctor(); return t }
//line :187:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Ctor() {}
//line :187:1
func (t *A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A) Invoke_O_O_O_O__O(self, acc__1, k__2, v__3 any) any { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_94.GetRawRoot__O()).Invoke_O_O__O(k__2, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_94.GetRawRoot__O()).Invoke_O_O__O(v__3, acc__1)) }



func A_arbace_spec_test_alpha_gen_fixed_args_syms_A_New() *A_arbace_spec_test_alpha_gen_fixed_args_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_gen_fixed_args_syms_A{}; t.Ctor(); return t }
//line :191:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Ctor() {}
//line :191:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_A) Invoke_O_O__O(self, arglist__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_96.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()); var tmp3 any = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New(); var tmp4 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class = fncls__9d; tmp4 = fncls__9d } else { tmp4 = fncls__9 }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_98.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_86.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_99), arglist__0))) }
//line :195:1
func A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_New() *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Ctor() {}
//line :195:1
func (t *A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A) Invoke_O_O__O(self, ___1 any) any { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O()).Invoke__O() }

func A_arbace_spec_test_alpha_build_kwargs_body_A_New() *A_arbace_spec_test_alpha_build_kwargs_body_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_kwargs_body_A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Ctor() {}
//line :197:1
func (t *A_arbace_spec_test_alpha_build_kwargs_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var alias__3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O()).Invoke_O__O(Lit_4); var head_args__4 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_100.GetRawRoot__O()).Invoke_O__O(arglist__1); return /*line :204:1*/ lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(head_args__4, A_arbace_spec_test_alpha_A_const_101, alias__3), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_102), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(fn_name__0), head_args__4, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_103), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_104), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_105))))))), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(alias__3))))))) }


func A_arbace_spec_test_alpha_build_varargs_body_A_New() *A_arbace_spec_test_alpha_build_varargs_body_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_varargs_body_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Ctor() {}
//line :207:1
func (t *A_arbace_spec_test_alpha_build_varargs_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var head_args__3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_100.GetRawRoot__O()).Invoke_O__O(arglist__1); var alias__4 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O()).Invoke_O__O(Lit_5); return /*line :213:1*/ lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_11.GetRawRoot__O()).Invoke_O_O_O__O(head_args__3, A_arbace_spec_test_alpha_A_const_106, alias__4), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_107), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(fn_name__0), head_args__3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(alias__4)))) }


func A_arbace_spec_test_alpha_build_fixed_args_body_A_New() *A_arbace_spec_test_alpha_build_fixed_args_body_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_fixed_args_body_A{}; t.Ctor(); return t }
//line :216:1
func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Ctor() {}
//line :216:1
func (t *A_arbace_spec_test_alpha_build_fixed_args_body_A) Invoke_O_O_O__O(self, fn_name__0, arglist__1 any) any { var arglist__3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_100.GetRawRoot__O()).Invoke_O__O(arglist__1); return /*line :221:1*/ lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O_O__O(arglist__3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(fn_name__0), arglist__3))) }


func A_arbace_spec_test_alpha_build_flattener_code_A_New() *A_arbace_spec_test_alpha_build_flattener_code_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_flattener_code_A{}; t.Ctor(); return t }
//line :224:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Ctor() {}
//line :224:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_A) Invoke_O_O__O(self, arglists__0 any) any { var closed_over_name__2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_97.GetRawRoot__O()).Invoke_O__O(Lit_2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_108); var tmp4 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_34.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(closed_over_name__2))))); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_31.GetRawRoot__O()); var tmp8 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_109); var tmp9 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_19.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_110); var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()); var tmp11 any = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(closed_over_name__2); var tmp12 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class; if






	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class = fncls__10d; tmp12 = fncls__10d } else { tmp12 = fncls__10 }; var tmp13 any = /*line :228:1*/lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); var tmp14 any; var or__1927000174__auto____3 any = arglists__0; if







	jrt.J2g_Truth(or__1927000174__auto____3) { tmp14 = or__1927000174__auto____3 } else { tmp14 = A_arbace_spec_test_alpha_A_const_115 }; return /*line :228:1*/ tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(tmp3, tmp4, tmp5.Invoke_O__O(tmp6.Invoke_O__O(tmp7.Invoke_O_O_O__O(tmp8, tmp9, tmp10.Invoke_O_O__O(tmp13, tmp14)))))) }


func A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_New_O(p0 any) *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A{}; t.Ctor_O(p0); return t }
//line :231:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Ctor_O(c__closed_over_name any) { t.F_closed_over_name = c__closed_over_name }
//line :231:1
func (t *A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A) Invoke_O_O__O(self, arglist__1 any) any { var varargs_decl__2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_90.GetRawRoot__O()).Invoke_O__O(arglist__1); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_88.GetRawRoot__O()).Invoke_O__O(varargs_decl__2)) { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_111.GetRawRoot__O()).Invoke_O_O__O(t.F_closed_over_name, arglist__1) } else { if jrt.J2g_Truth(varargs_decl__2) {
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_112.GetRawRoot__O()).Invoke_O_O__O(t.F_closed_over_name, arglist__1) } else {
//line :233:1
			if A_arbace_spec_test_alpha_A_const_113 != nil {

				return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_114.GetRawRoot__O()).Invoke_O_O__O(t.F_closed_over_name, arglist__1) } else {
//line :233:1
					return nil } } } }





















func A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_New() *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A{}; t.Ctor(); return t }
//line :255:1
func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Ctor() {}
//line :255:1
func (t *A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A) Invoke_O_O_O__O(self, f__0, arglists__1 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_116.GetRawRoot__O()).Invoke_O__O(arglists__1)) { var flattener_code__3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_117.GetRawRoot__O()).Invoke_O__O(arglists__1); var kvs_emu__4 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_118.GetRawRoot__O()).Invoke_O__O(flattener_code__3)


		return lang.IFn_Cast(kvs_emu__4).Invoke_O__O(f__0) } else {
//line :260:1
			return f__0
		}
}



func A_arbace_spec_test_alpha_instrument_choose_fn_A_New() *A_arbace_spec_test_alpha_instrument_choose_fn_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_choose_fn_A{}; t.Ctor(); return t }
//line :266:1
func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Ctor() {}
//line :266:1
func (t *A_arbace_spec_test_alpha_instrument_choose_fn_A) Invoke_O_O_O_O_O__O(self, f__0, spec__1, sym__2, p__107000078__3 any) any { var map__107000079__5 any = p__107000078__3; var map__107000079__6 any; if lang.ISeq_InstanceOf(map__107000079__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000079__5)) { map__107000079__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000079__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000079__5)) { map__107000079__6 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000079__5) } else { map__107000079__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000079__6 = map__107000079__5 }; var over__7 any = lang.RT_Get_O_O__O_NoInit(map__107000079__6, A_arbace_spec_test_alpha_A_const_119); var stub__8 any = lang.RT_Get_O_O__O_NoInit(map__107000079__6, A_arbace_spec_test_alpha_A_const_120); var replace__9 any = lang.RT_Get_O_O__O_NoInit(map__107000079__6, A_arbace_spec_test_alpha_A_const_121); if


	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_89.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Set_O1__IPersistentSet_NoInit(jrt.RefArrayOf(jrt.Object_class, sym__2)), stub__8)) {
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_122.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_123.GetRawRoot__O()).Invoke_O_O__O(spec__1, over__7)) } else {
			return lang.RT_Get_O_O_O__O_NoInit(replace__9, sym__2, f__0) } }

func A_arbace_spec_test_alpha_instrument_choose_spec_A_New() *A_arbace_spec_test_alpha_instrument_choose_spec_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_choose_spec_A{}; t.Ctor(); return t }
//line :273:1
func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Ctor() {}
//line :273:1
func (t *A_arbace_spec_test_alpha_instrument_choose_spec_A) Invoke_O_O_O_O__O(self, spec__0, sym__1, p__107000082__2 any) any { var map__107000083__4 any = p__107000082__2; var map__107000083__5 any; if lang.ISeq_InstanceOf(map__107000083__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000083__4)) { map__107000083__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000083__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000083__4)) { map__107000083__5 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000083__4) } else { map__107000083__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000083__5 = map__107000083__4 }; var overrides__6 any = lang.RT_Get_O_O__O_NoInit(map__107000083__5, A_arbace_spec_test_alpha_A_const_82); return /*line :276:1*/ lang.RT_Get_O_O_O__O_NoInit(overrides__6, sym__1, spec__0) }

func A_arbace_spec_test_alpha_instrument_1_A_New() *A_arbace_spec_test_alpha_instrument_1_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_1_A{}; t.Ctor(); return t }
//line :278:1
func (t *A_arbace_spec_test_alpha_instrument_1_A) Ctor() {}
//line :278:1
func (t *A_arbace_spec_test_alpha_instrument_1_A) Invoke_O_O_O__O(self, s__0, opts__1 any) any { var temp__1927000414__auto____3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O()).Invoke_O__O(s__0); if

	jrt.J2g_Truth(temp__1927000414__auto____3) { var v__4 any = temp__1927000414__auto____3; var tmp1 *lang.Keyword = A_arbace_spec_test_alpha_A_const_124
		if jrt.J2g_Truth(tmp1.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__4))) { return nil } else { var spec__5 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_125.GetRawRoot__O()).Invoke_O__O(v__4); var map__107000086__6 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O()), v__4); var map__107000086__7 any
			if lang.ISeq_InstanceOf(map__107000086__6) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000086__6)) { map__107000086__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000086__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000086__6)) { map__107000086__7 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000086__6) } else { map__107000086__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000086__7 = map__107000086__6 }
//line :281:1
			var raw__8 any = lang.RT_Get_O_O__O_NoInit(map__107000086__7, A_arbace_spec_test_alpha_A_const_126); var wrapped__9 any = lang.RT_Get_O_O__O_NoInit(map__107000086__7, A_arbace_spec_test_alpha_A_const_127); var current__10 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(v__4); var to_wrap__11 any



			if lang.Util_Equiv_O_O__Z_NoInit(wrapped__9, current__10) { to_wrap__11 = raw__8 } else { to_wrap__11 = current__10 }
//line :281:1
			var ospec__12 any; var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_128.GetRawRoot__O()).Invoke_O_O_O__O(spec__5, s__0, opts__1)




			if jrt.J2g_Truth(or__1927000174__auto____12) { ospec__12 = or__1927000174__auto____12 } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_129.GetRawRoot__O()).Invoke_O_O__O(v__4, spec__5)))) }
//line :281:1
			var ofn__13 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_130.GetRawRoot__O()).Invoke_O_O_O_O__O(to_wrap__11, ospec__12, s__0, opts__1); var checked__14 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O()).Invoke_O__O(v__4), ofn__13, ospec__12); var tmp2 *lang.Keyword = A_arbace_spec_test_alpha_A_const_137; var arglists__15 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_135.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_136.GetRawRoot__O(), tmp2.Invoke_O__O(lang.RT_Meta_O__IPersistentMap_NoInit(v__4)))); var wrapped__16 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_132.GetRawRoot__O()).Invoke_O_O__O(checked__14, arglists__15)










			lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_138.GetRawRoot__O()).Invoke_O_O__O(v__4, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_140.GetRawRoot__O()).Invoke_O__O(wrapped__16))
			lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_139.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O(), A_arbace_spec_test_alpha_A_const_68.GetRawRoot__O(), v__4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_126, to_wrap__11, A_arbace_spec_test_alpha_A_const_127, wrapped__16)))
			return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O()).Invoke_O__O(v__4) } } else {
//line :280:1
				return nil } }















func A_arbace_spec_test_alpha_unstrument_1_A_New() *A_arbace_spec_test_alpha_unstrument_1_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_unstrument_1_A{}; t.Ctor(); return t }
//line :296:1
func (t *A_arbace_spec_test_alpha_unstrument_1_A) Ctor() {}
//line :296:1
func (t *A_arbace_spec_test_alpha_unstrument_1_A) Invoke_O_O__O(self, s__0 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O()).Invoke_O__O(s__0); if

	jrt.J2g_Truth(temp__1927000414__auto____2) { var v__3 any = temp__1927000414__auto____2; var temp__1927000414__auto____4 any = lang.RT_Get_O_O__O_NoInit(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O()), v__3)
		if jrt.J2g_Truth(temp__1927000414__auto____4) { var map__107000089__5 any = temp__1927000414__auto____4; var map__107000089__6 any; if lang.ISeq_InstanceOf(map__107000089__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000089__5)) { map__107000089__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000089__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000089__5)) { map__107000089__6 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000089__5) } else { map__107000089__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000089__6 = map__107000089__5 }; var raw__7 any = lang.RT_Get_O_O__O_NoInit(map__107000089__6, A_arbace_spec_test_alpha_A_const_126); var wrapped__8 any = lang.RT_Get_O_O__O_NoInit(map__107000089__6, A_arbace_spec_test_alpha_A_const_127)
			lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_139.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O(), A_arbace_spec_test_alpha_A_const_70.GetRawRoot__O(), v__3)
//line :299:1
			var current__9 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(v__3)


			if lang.Util_Equiv_O_O__Z_NoInit(wrapped__8, current__9) {
				lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_138.GetRawRoot__O()).Invoke_O_O__O(v__3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_140.GetRawRoot__O()).Invoke_O__O(raw__7))
				return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O()).Invoke_O__O(v__3) } else {
//line :302:1
					return nil } } else {
//line :299:1
						return nil } } else {
//line :298:1
							return nil } }







func A_arbace_spec_test_alpha_opt_syms_A_New() *A_arbace_spec_test_alpha_opt_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_opt_syms_A{}; t.Ctor(); return t }
//line :306:1
func (t *A_arbace_spec_test_alpha_opt_syms_A) Ctor() {}
//line :306:1
func (t *A_arbace_spec_test_alpha_opt_syms_A) Invoke_O_O__O(self, opts__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var tmp3 any = lang.PersistentHashSet_EMPTY.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_spec_test_alpha_A_const_120.Invoke_O__O(opts__0), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_121.Invoke_O__O(opts__0)), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_82.Invoke_O__O(opts__0))))
}
func A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_New() *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_fn_spec_name_QMARK__A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Ctor() {}
//line :311:1
func (t *A_arbace_spec_test_alpha_fn_spec_name_QMARK__A) Invoke_O_O__O(self, s__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O()).Invoke_O__O(s__0); if

	jrt.J2g_Truth(and__1927000168__auto____2) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_142.GetRawRoot__O()); var tmp2 any; var G__107000093__3_ any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O()).Invoke_O__O(s__0); var G__107000093__4_ any; if lang.Util_Identical_O_O__Z_NoInit(G__107000093__3_, nil) { G__107000093__4_ = nil } else { G__107000093__4_ = lang.RT_Meta_O__IPersistentMap_NoInit(G__107000093__3_) }; if lang.Util_Identical_O_O__Z_NoInit(G__107000093__4_, nil) { tmp2 = nil } else { tmp2 = A_arbace_spec_test_alpha_A_const_124.Invoke_O__O(G__107000093__4_) }; return tmp1.Invoke_O__O(tmp2) } else {
//line :313:1
			return and__1927000168__auto____2 } }


func A_arbace_spec_test_alpha_instrumentable_syms_A_New() *A_arbace_spec_test_alpha_instrumentable_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrumentable_syms_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Ctor() {}
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Invoke_O_O__O(self, opts__0 any) any {




	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_144.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_119.Invoke_O__O(opts__0)))) { } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, Lit_15, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_145))).Ref()))) }
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var tmp3 any = lang.PersistentHashSet_EMPTY.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_147.GetRawRoot__O()).Invoke__O())), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_82.Invoke_O__O(opts__0)), A_arbace_spec_test_alpha_A_const_120.Invoke_O__O(opts__0), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_121.Invoke_O__O(opts__0)))) }
//line :316:1
func (t *A_arbace_spec_test_alpha_instrumentable_syms_A) Invoke_O__O(self any) any {


	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_148.GetRawRoot__O()).Invoke_O__O(nil)
}






func A_arbace_spec_test_alpha_instrument_A_New() *A_arbace_spec_test_alpha_instrument_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_A{}; t.Ctor(); return t }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Ctor() {}
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O_O_O__O(self, sym_or_syms__0, opts__1 any) any { var lockee__1927000360__auto____3 any = A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O(); var locklocal__1927000361__auto____6 any = lockee__1927000360__auto____3; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____6); var tmp1 any; tmp10 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)








































	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O()); var tmp3 any = lang.PersistentVector_EMPTY.Ref(); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_59.GetRawRoot__O()); var tmp5 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_148.GetRawRoot__O()).Invoke_O__O(opts__1)); var tmp6 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_149.GetRawRoot__O()).Invoke__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()); var tmp8 any = A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(opts__1); var tmp9 *jrt.Class
		var fncls__11 /*line :368:1*/*jrt.Class = A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class



		if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class = fncls__11d; tmp9 = fncls__11d } else { tmp9 = fncls__11 }
//line :368:1
		tmp1 = tmp2.Invoke_O_O_O__O(tmp3, tmp4.Invoke_O_O_O_O__O(tmp5, tmp6, tmp7.Invoke_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil)), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_152.GetRawRoot__O())), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O()).Invoke_O__O(sym_or_syms__0)) }
//line :327:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____6); if tmp10 != nil { panic(tmp10) }; return tmp1 }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O_O__O(self, sym_or_syms__0 any) any {





































	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_153.GetRawRoot__O()).Invoke_O_O__O(sym_or_syms__0, nil) }
//line :327:1
func (t *A_arbace_spec_test_alpha_instrument_A) Invoke_O__O(self any) any {




































	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_153.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_148.GetRawRoot__O()).Invoke__O())
}






func A_arbace_spec_test_alpha_instrument_fn__107000097_A_New_O(p0 any) *A_arbace_spec_test_alpha_instrument_fn__107000097_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_instrument_fn__107000097_A{}; t.Ctor_O(p0); return t }
//line :372:1
func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :372:1
func (t *A_arbace_spec_test_alpha_instrument_fn__107000097_A) Invoke_O_O__O(self, p1__107000096_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_151.GetRawRoot__O()).Invoke_O_O__O(p1__107000096_SHARP___1, t.F_opts) }



func A_arbace_spec_test_alpha_unstrument_A_New() *A_arbace_spec_test_alpha_unstrument_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_unstrument_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Ctor() {}
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Invoke_O_O__O(self, sym_or_syms__0 any) any { var lockee__1927000360__auto____2 any = A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O(); var locklocal__1927000361__auto____5 any = lockee__1927000360__auto____2; lang.Compiler_Evaluator_MonitorEnter_O__V_NoInit(locklocal__1927000361__auto____5); var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)






	{ var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O()); var tmp3 any = lang.PersistentVector_EMPTY.Ref(); tmp1 = tmp2.Invoke_O_O_O__O(tmp3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_59.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_16.GetRawRoot__O()), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_154.GetRawRoot__O()), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_150.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_152.GetRawRoot__O())), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O()).Invoke_O__O(sym_or_syms__0)) }
//line :376:1
	return nil }(); lang.Compiler_Evaluator_MonitorExit_O__V_NoInit(locklocal__1927000361__auto____5); if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :376:1
func (t *A_arbace_spec_test_alpha_unstrument_A) Invoke_O__O(self any) any {



	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_155.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_133.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_134.GetRawRoot__O()))))
}










func A_arbace_spec_test_alpha_explain_check_A_New() *A_arbace_spec_test_alpha_explain_check_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_explain_check_A{}; t.Ctor(); return t }
//line :392:1
func (t *A_arbace_spec_test_alpha_explain_check_A) Ctor() {}
//line :392:1
func (t *A_arbace_spec_test_alpha_explain_check_A) Invoke_O_O_O_O_O__O(self, args__0, spec__1, v__2, role__3 any) any {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_66.GetRawRoot__O()); var tmp2 any

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_156.GetRawRoot__O()).Invoke_O_O_O__O(spec__1, v__2, nil)) { tmp2 = nil } else {
		tmp2 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_68.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_71.GetRawRoot__O()).Invoke_O_O_O_O_O__O(spec__1, lang.Tuple_Create_O__IPersistentVector(role__3), lang.PersistentVector_EMPTY.Ref(), lang.PersistentVector_EMPTY.Ref(), v__2), A_arbace_spec_test_alpha_A_const_157, args__0, A_arbace_spec_test_alpha_A_const_158, v__2, A_arbace_spec_test_alpha_A_const_74, A_arbace_spec_test_alpha_A_const_159) }
//line :394:1
	return tmp1.Invoke_O_O__O(Lit_11, tmp2)
}






func A_arbace_spec_test_alpha_check_call_A_New() *A_arbace_spec_test_alpha_check_call_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_call_A{}; t.Ctor(); return t }
//line :402:1
func (t *A_arbace_spec_test_alpha_check_call_A) Ctor() {}
//line :402:1
func (t *A_arbace_spec_test_alpha_check_call_A) Invoke_O_O_O_O__O(self, f__0, specs__1, args__2 any) any { var cargs__4 any; if



	jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1)) { cargs__4 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1), args__2) } else { cargs__4 = nil }; if
	lang.Util_Equiv_O_O__Z_NoInit(cargs__4, A_arbace_spec_test_alpha_A_const_65) {
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_160.GetRawRoot__O()).Invoke_O_O_O_O__O(args__2, A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1), args__2, A_arbace_spec_test_alpha_A_const_28) } else {
//line :407:1
			var ret__5 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O__O(f__0, args__2); var cret__6 any


			if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1)) { cret__6 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_64.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1), ret__5) } else { cret__6 = nil }
			if lang.Util_Equiv_O_O__Z_NoInit(cret__6, A_arbace_spec_test_alpha_A_const_65) {
				return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_160.GetRawRoot__O()).Invoke_O_O_O_O__O(args__2, A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1), ret__5, A_arbace_spec_test_alpha_A_const_29) } else {
					var tmp1 any; var and__1927000168__auto____7 any = A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specs__1); if jrt.J2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = A_arbace_spec_test_alpha_A_const_29.Invoke_O__O(specs__1); if jrt.J2g_Truth(and__1927000168__auto____8) { tmp1 = A_arbace_spec_test_alpha_A_const_161.Invoke_O__O(specs__1) } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp1) {
						if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_156.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_161.Invoke_O__O(specs__1), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_28, cargs__4, A_arbace_spec_test_alpha_A_const_29, cret__6)))) { return jrt.Boolean_TRUE.Ref() } else {

							return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_160.GetRawRoot__O()).Invoke_O_O_O_O__O(args__2, A_arbace_spec_test_alpha_A_const_161.Invoke_O__O(specs__1), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_28, cargs__4, A_arbace_spec_test_alpha_A_const_29, cret__6)), A_arbace_spec_test_alpha_A_const_161) } } else {
//line :413:1
								return jrt.Boolean_TRUE.Ref() } } } }





func A_arbace_spec_test_alpha_quick_check_A_New() *A_arbace_spec_test_alpha_quick_check_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_spec_test_alpha_quick_check_A) Ctor() {}
//line :419:1
func (t *A_arbace_spec_test_alpha_quick_check_A) Invoke_O_O_O_O__O(self, f__0, specs__1, p__107000104__2 any) any { var map__107000105__4 any = p__107000104__2; var map__107000105__5 any; if lang.ISeq_InstanceOf(map__107000105__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000105__4)) { map__107000105__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000105__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000105__4)) { map__107000105__5 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000105__4) } else { map__107000105__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000105__5 = map__107000105__4 }; var gen__6 any = lang.RT_Get_O_O__O_NoInit(map__107000105__5, A_arbace_spec_test_alpha_A_const_119); var opts__7 any = lang.RT_Get_O_O__O_NoInit(map__107000105__5, A_arbace_spec_test_alpha_A_const_162); var default__107000109__8 int64 = 1000; var map__107000107__9 any = opts__7; var map__107000107__10 any; if

	lang.ISeq_InstanceOf(map__107000107__9) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000107__9)) { map__107000107__10 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000107__9), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000107__9)) { map__107000107__10 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000107__9) } else { map__107000107__10 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000107__10 = map__107000107__9 }; var tmp1 any = A_arbace_spec_test_alpha_A_const_163; var num_tests__11 any = /*line :419:1*/lang.RT_Get_O_O_O__O_NoInit(map__107000107__10, tmp1, jrt.Long_ValueOf_J__Long_NoInit(default__107000109__8).Ref()); var g__12 any; var tmp2 any = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(gen__6, specs__1); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class; if


	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; g__12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O(); if
	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_164.GetRawRoot__O()).Invoke_O__O(g__12)) { return lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_165, g__12)) } else { var prop__13 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_166.GetRawRoot__O()); var tmp5 any = lang.Tuple_Create_O__IPersistentVector(g__12); var tmp6 any = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(f__0, specs__1); var tmp7 *jrt.Class
		var fncls__13 /*line :423:1*/*jrt.Class = A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class

		if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class = fncls__13d; tmp7 = fncls__13d } else { tmp7 = fncls__13 }; prop__13 = tmp4.Invoke_O_O__O(tmp5, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil))
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_33.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_test_alpha_A_const_168.GetRawRoot__O(), num_tests__11, prop__13, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_21.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_169.GetRawRoot__O(), opts__7)) } }
//line :422:1
func A_arbace_spec_test_alpha_quick_check_fn__107000111_A_New_O_O(p0, p1 any) *A_arbace_spec_test_alpha_quick_check_fn__107000111_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_fn__107000111_A{}; t.Ctor_O_O(p0, p1); return t }
//line :422:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Ctor_O_O(c__gen, c__specs any) { t.F_gen = c__gen; t.F_specs = c__specs }
//line :422:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000111_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_123.GetRawRoot__O()); var tmp3 *lang.Keyword = A_arbace_spec_test_alpha_A_const_28; var tmp4 any; var t_ any = t.F_specs; t.F_specs = nil; tmp4 = t_; var tmp5 any = tmp3.Invoke_O__O(tmp4); var tmp6 any; var t__2 any = t.F_gen; t.F_gen = nil; tmp6 = t__2; tmp1 = tmp2.Invoke_O_O__O(tmp5, tmp6) }; return nil }(); if tmp7 != nil { if true { var t__3 jrt.Throwable_I = tmp7; tmp1 = t__3 } }; return tmp1 }


func A_arbace_spec_test_alpha_quick_check_fn__107000113_A_New_O_O(p0, p1 any) *A_arbace_spec_test_alpha_quick_check_fn__107000113_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_quick_check_fn__107000113_A{}; t.Ctor_O_O(p0, p1); return t }
//line :425:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Ctor_O_O(c__f, c__specs any) { t.F_f = c__f; t.F_specs = c__specs }
//line :425:1
func (t *A_arbace_spec_test_alpha_quick_check_fn__107000113_A) Invoke_O_O__O(self, p1__107000103_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_167.GetRawRoot__O()).Invoke_O_O_O__O(t.F_f, t.F_specs, p1__107000103_SHARP___1) }


func A_arbace_spec_test_alpha_make_check_result_A_New() *A_arbace_spec_test_alpha_make_check_result_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_make_check_result_A{}; t.Ctor(); return t }
//line :428:1
func (t *A_arbace_spec_test_alpha_make_check_result_A) Ctor() {}
//line :428:1
func (t *A_arbace_spec_test_alpha_make_check_result_A) Invoke_O_O_O_O__O(self, check_sym__0, spec__1, test_check_ret__2 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_40.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_82, spec__1, A_arbace_spec_test_alpha_A_const_170, test_check_ret__2)); var tmp3 lang.IPersistentMap

	if jrt.J2g_Truth(check_sym__0) { tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_171, check_sym__0)) } else { tmp3 = nil }
//line :431:1
	var tmp4 any = tmp3; var tmp5 lang.IPersistentMap; var temp__1927000414__auto____4 any = A_arbace_spec_test_alpha_A_const_165.Invoke_O__O(test_check_ret__2)



	if jrt.J2g_Truth(temp__1927000414__auto____4) { var result__5 any = temp__1927000414__auto____4
		if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_172.GetRawRoot__O()).Invoke_O__O(result__5)) { tmp5 = nil } else { tmp5 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_173, result__5)) } } else {
//line :435:1
			tmp5 = nil }
//line :431:1
	var tmp6 any = tmp5; var tmp7 lang.IPersistentMap; var temp__1927000414__auto____4_2 any = A_arbace_spec_test_alpha_A_const_174.Invoke_O__O(test_check_ret__2)





	if jrt.J2g_Truth(temp__1927000414__auto____4_2) { var shrunk__5 any = temp__1927000414__auto____4_2; var tmp8 any = A_arbace_spec_test_alpha_A_const_173; tmp7 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp8, A_arbace_spec_test_alpha_A_const_165.Invoke_O__O(shrunk__5))) } else { tmp7 = nil }
//line :431:1
	return tmp1.Invoke_O_O_O_O__O(tmp2, tmp4, tmp6, tmp7)
}







func A_arbace_spec_test_alpha_check_1_A_New() *A_arbace_spec_test_alpha_check_1_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_1_A{}; t.Ctor(); return t }
//line :440:1
func (t *A_arbace_spec_test_alpha_check_1_A) Ctor() {}
//line :440:1
func (t *A_arbace_spec_test_alpha_check_1_A) Invoke_O_O_O__O(self, p__107000117__0, opts__1 any) any { var map__107000118__3 any = p__107000117__0; var map__107000118__4 any; if lang.ISeq_InstanceOf(map__107000118__3) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_54.GetRawRoot__O()).Invoke_O__O(map__107000118__3)) { map__107000118__4 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_55.GetRawRoot__O()).Invoke_O__O(map__107000118__3), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(map__107000118__3)) { map__107000118__4 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_56.GetRawRoot__O()).Invoke_O__O(map__107000118__3) } else { map__107000118__4 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__107000118__4 = map__107000118__3 }; var s__5 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_175); var f__6 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_176); var v__7 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_177); var spec__8 any = lang.RT_Get_O_O__O_NoInit(map__107000118__4, A_arbace_spec_test_alpha_A_const_82); var re_inst_QMARK___9 any; var and__1927000168__auto____9 any = v__7; if

	jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_30.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_155.GetRawRoot__O()).Invoke_O__O(s__5)); if jrt.J2g_Truth(and__1927000168__auto____10) { re_inst_QMARK___9 = jrt.Boolean_TRUE.Ref() } else { re_inst_QMARK___9 = and__1927000168__auto____10 } } else { re_inst_QMARK___9 = and__1927000168__auto____9 }; var f__10 any; var or__1927000174__auto____10 any = f__6; if
	jrt.J2g_Truth(or__1927000174__auto____10) { f__10 = or__1927000174__auto____10 } else { if jrt.J2g_Truth(v__7) { f__10 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_10.GetRawRoot__O()).Invoke_O__O(v__7) } else { f__10 = nil } }; var specd__11 any = /*line :440:1*/lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_178.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_spec_test_alpha_A_const_181, spec__8, nil, nil); var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)





		{ var tmp2 any; var or__1927000174__auto____14 bool = lang.Util_Identical_O_O__Z_NoInit(f__10, nil)
			if or__1927000174__auto____14 { tmp2 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____14).Ref() } else { var G__107000120__15_ any = v__7; var G__107000120__16_ any; if lang.Util_Identical_O_O__Z_NoInit(G__107000120__15_, nil) { G__107000120__16_ = nil } else { G__107000120__16_ = lang.RT_Meta_O__IPersistentMap_NoInit(G__107000120__15_) }; if lang.Util_Identical_O_O__Z_NoInit(G__107000120__16_, nil) { tmp2 = nil } else { tmp2 = A_arbace_spec_test_alpha_A_const_124.Invoke_O__O(G__107000120__16_) } }
//line :446:1
			if jrt.J2g_Truth(tmp2) { var tmp3 any = A_arbace_spec_test_alpha_A_const_173; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_66.GetRawRoot__O()).Invoke_O_O__O(Lit_7, A_arbace_spec_test_alpha_A_const_182), A_arbace_spec_test_alpha_A_const_171, s__5, A_arbace_spec_test_alpha_A_const_82, spec__8)) } else { if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_28.Invoke_O__O(specd__11)) { var tcret__14 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_179.GetRawRoot__O()).Invoke_O_O_O__O(f__10, specd__11, opts__1)






				tmp1 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_180.GetRawRoot__O()).Invoke_O_O_O__O(s__5, spec__8, tcret__14) } else {
//line :446:1
					if A_arbace_spec_test_alpha_A_const_113 != nil { var tmp4 any = A_arbace_spec_test_alpha_A_const_173; tmp1 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp4, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_66.GetRawRoot__O()).Invoke_O_O__O(Lit_8, A_arbace_spec_test_alpha_A_const_183), A_arbace_spec_test_alpha_A_const_171, s__5, A_arbace_spec_test_alpha_A_const_82, spec__8)) } else { tmp1 = nil } } } }
//line :440:1
		return nil }(); if


















	jrt.J2g_Truth(re_inst_QMARK___9) { lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_153.GetRawRoot__O()).Invoke_O__O(s__5) }; if /*line :440:1*/ tmp5 != nil { panic(tmp5) }; return tmp1 }




















func A_arbace_spec_test_alpha_sym__GT_check_map_A_New() *A_arbace_spec_test_alpha_sym__GT_check_map_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_sym__GT_check_map_A{}; t.Ctor(); return t }
//line :461:1
func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Ctor() {}
//line :461:1
func (t *A_arbace_spec_test_alpha_sym__GT_check_map_A) Invoke_O_O__O(self, s__0 any) any { var v__2 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_17.GetRawRoot__O()).Invoke_O__O(s__0); var tmp1 any = A_arbace_spec_test_alpha_A_const_175; var tmp2 any = A_arbace_spec_test_alpha_A_const_177; var tmp3 any = A_arbace_spec_test_alpha_A_const_82; var tmp4 any; if




	jrt.J2g_Truth(v__2) { tmp4 = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_125.GetRawRoot__O()).Invoke_O__O(v__2) } else { tmp4 = nil }; return /*line :461:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, s__0, tmp2, v__2, tmp3, tmp4)) }






func A_arbace_spec_test_alpha_validate_check_opts_A_New() *A_arbace_spec_test_alpha_validate_check_opts_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_validate_check_opts_A{}; t.Ctor(); return t }
//line :468:1
func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Ctor() {}
//line :468:1
func (t *A_arbace_spec_test_alpha_validate_check_opts_A) Invoke_O_O__O(self, opts__0 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_143.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_144.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_119.Invoke_O__O(opts__0)))) { return nil } else { panic(jrt.Thrown(jrt.AssertionError_New_O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_14, Lit_32, Lit_16, nil), jrt.RefArrayOf(jrt.Object_class, nil, nil, nil, lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_18.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_184))).Ref())))
	} }
func A_arbace_spec_test_alpha_check_fn_A_New() *A_arbace_spec_test_alpha_check_fn_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_fn_A{}; t.Ctor(); return t }
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Ctor() {}
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Invoke_O_O_O_O__O(self, f__0, spec__1, opts__2 any) any {




	lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_186.GetRawRoot__O()).Invoke_O__O(opts__2)
	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_185.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_spec_test_alpha_A_const_176, f__0, A_arbace_spec_test_alpha_A_const_82, spec__1)), opts__2) }
//line :472:1
func (t *A_arbace_spec_test_alpha_check_fn_A) Invoke_O_O_O__O(self, f__0, spec__1 any) any {


	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_187.GetRawRoot__O()).Invoke_O_O_O__O(f__0, spec__1, nil)
}



func A_arbace_spec_test_alpha_checkable_syms_A_New() *A_arbace_spec_test_alpha_checkable_syms_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_checkable_syms_A{}; t.Ctor(); return t }
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Ctor() {}
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Invoke_O_O__O(self, opts__0 any) any {




	lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_186.GetRawRoot__O()).Invoke_O__O(opts__0)
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_A_const_20.GetRawRoot__O(); var tmp3 any = lang.PersistentHashSet_EMPTY.Ref(); return tmp1.Invoke_O_O_O__O(tmp2, tmp3, lang.Tuple_Create_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_146.GetRawRoot__O(), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_147.GetRawRoot__O()).Invoke__O())), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_26.GetRawRoot__O()).Invoke_O__O(A_arbace_spec_test_alpha_A_const_82.Invoke_O__O(opts__0)))) }
//line :480:1
func (t *A_arbace_spec_test_alpha_checkable_syms_A) Invoke_O__O(self any) any {


	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_188.GetRawRoot__O()).Invoke_O__O(nil)
}




func A_arbace_spec_test_alpha_check_A_New() *A_arbace_spec_test_alpha_check_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_A{}; t.Ctor(); return t }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Ctor() {}
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O_O_O__O(self, sym_or_syms__0, opts__1 any) any {





































	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_189.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(opts__1); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_60.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_188.GetRawRoot__O()).Invoke_O__O(opts__1), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_22.GetRawRoot__O()).Invoke_O__O(sym_or_syms__0))) }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O_O__O(self, sym_or_syms__0 any) any {

































	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_191.GetRawRoot__O()).Invoke_O_O__O(sym_or_syms__0, nil) }
//line :489:1
func (t *A_arbace_spec_test_alpha_check_A) Invoke_O__O(self any) any {
































	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_191.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_188.GetRawRoot__O()).Invoke__O())
}



func A_arbace_spec_test_alpha_check_fn__107000127_A_New_O(p0 any) *A_arbace_spec_test_alpha_check_fn__107000127_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_check_fn__107000127_A{}; t.Ctor_O(p0); return t }
//line :527:1
func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :527:1
func (t *A_arbace_spec_test_alpha_check_fn__107000127_A) Invoke_O_O__O(self, p1__107000126_SHARP___1 any) any {
	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_185.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_190.GetRawRoot__O()).Invoke_O__O(p1__107000126_SHARP___1), t.F_opts)
}


func A_arbace_spec_test_alpha_failure_type_A_New() *A_arbace_spec_test_alpha_failure_type_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_failure_type_A{}; t.Ctor(); return t }
//line :532:1
func (t *A_arbace_spec_test_alpha_failure_type_A) Ctor() {}
//line :532:1
func (t *A_arbace_spec_test_alpha_failure_type_A) Invoke_O_O__O(self, x__0 any) any {

	var tmp1 *lang.Keyword = A_arbace_spec_test_alpha_A_const_74; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_192.GetRawRoot__O()).Invoke_O__O(x__0))
}
func A_arbace_spec_test_alpha_unwrap_failure_A_New() *A_arbace_spec_test_alpha_unwrap_failure_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_unwrap_failure_A{}; t.Ctor(); return t }
//line :536:1
func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Ctor() {}
//line :536:1
func (t *A_arbace_spec_test_alpha_unwrap_failure_A) Invoke_O_O__O(self, x__0 any) any {

	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_193.GetRawRoot__O()).Invoke_O__O(x__0)) {
		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_192.GetRawRoot__O()).Invoke_O__O(x__0) } else {
//line :538:1
			return x__0
		}
}

func A_arbace_spec_test_alpha_result_type_A_New() *A_arbace_spec_test_alpha_result_type_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_result_type_A{}; t.Ctor(); return t }
//line :542:1
func (t *A_arbace_spec_test_alpha_result_type_A) Ctor() {}
//line :542:1
func (t *A_arbace_spec_test_alpha_result_type_A) Invoke_O_O__O(self, ret__0 any) any { var failure__2 any = A_arbace_spec_test_alpha_A_const_173.Invoke_O__O(ret__0); if







	lang.Util_Identical_O_O__Z_NoInit(failure__2, nil) { return A_arbace_spec_test_alpha_A_const_194 } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_193.GetRawRoot__O()).Invoke_O__O(failure__2)) {

		return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_193.GetRawRoot__O()).Invoke_O__O(failure__2) } else {
//line :550:1
			if A_arbace_spec_test_alpha_A_const_113 != nil { return A_arbace_spec_test_alpha_A_const_195 } else { return nil } } } }




func A_arbace_spec_test_alpha_abbrev_result_A_New() *A_arbace_spec_test_alpha_abbrev_result_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_abbrev_result_A{}; t.Ctor(); return t }
//line :555:1
func (t *A_arbace_spec_test_alpha_abbrev_result_A) Ctor() {}
//line :555:1
func (t *A_arbace_spec_test_alpha_abbrev_result_A) Invoke_O_O__O(self, x__0 any) any {



	if jrt.J2g_Truth(A_arbace_spec_test_alpha_A_const_173.Invoke_O__O(x__0)) {


		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O()); var tmp3 any = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_70.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_spec_test_alpha_A_const_170); var tmp4 any = A_arbace_spec_test_alpha_A_const_82; var tmp5 any = tmp2.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_spec_test_alpha_A_const_198.GetRawRoot__O()); var tmp6 any = A_arbace_spec_test_alpha_A_const_173; return tmp1.Invoke_O_O_O__O(tmp5, tmp6, A_arbace_spec_test_alpha_A_const_197.GetRawRoot__O()) } else {
			return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_70.GetRawRoot__O()).Invoke_O_O_O__O(x__0, A_arbace_spec_test_alpha_A_const_82, A_arbace_spec_test_alpha_A_const_170)
		} }
func A_arbace_spec_test_alpha_summarize_results_A_New() *A_arbace_spec_test_alpha_summarize_results_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_summarize_results_A{}; t.Ctor(); return t }
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Ctor() {}
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Invoke_O_O_O__O(self, check_results__0, summary_result__1 any) any {







	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_141.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(summary_result__1); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class
	if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_30, false); A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }
//line :573:1
	return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), A_arbace_spec_test_alpha_A_const_205, check_results__0) }
//line :565:1
func (t *A_arbace_spec_test_alpha_summarize_results_A) Invoke_O_O__O(self, check_results__0 any) any {





	return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_206.GetRawRoot__O()).Invoke_O_O__O(check_results__0, A_arbace_spec_test_alpha_A_const_207.GetRawRoot__O())
}

func A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_New_O(p0 any) *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_summarize_results_fn__107000134_A{}; t.Ctor_O(p0); return t }
//line :574:1
func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Ctor_O(c__summary_result any) { t.F_summary_result = c__summary_result }
//line :574:1
func (t *A_arbace_spec_test_alpha_summarize_results_fn__107000134_A) Invoke_O_O_O__O(self, summary__1, result__2 any) any {
	lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_199.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_summary_result).Invoke_O__O(result__2))


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O()); var tmp2 any = A_arbace_spec_test_alpha_A_const_202; return lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_196.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O_O_O__O(summary__1, tmp2, A_arbace_spec_test_alpha_A_const_203.GetRawRoot__O()), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_200.GetRawRoot__O()).Invoke_O__O(result__2), lang.IFn_Cast(A_arbace_spec_test_alpha_A_const_201.GetRawRoot__O()).Invoke_O_O__O(A_arbace_spec_test_alpha_A_const_203.GetRawRoot__O(), A_arbace_spec_test_alpha_A_const_204))
}


type A_arbace_spec_test_alpha_A struct{ jrt.Object }

var A_arbace_spec_test_alpha_A_const_pool *jrt.RefArray

var A_arbace_spec_test_alpha_A_const_0 *lang.Var

var A_arbace_spec_test_alpha_A_const_1 *lang.Var

var A_arbace_spec_test_alpha_A_const_2 any

var A_arbace_spec_test_alpha_A_const_3 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_4 any

var A_arbace_spec_test_alpha_A_const_5 any

var A_arbace_spec_test_alpha_A_const_6 any

var A_arbace_spec_test_alpha_A_const_7 any

var A_arbace_spec_test_alpha_A_const_8 any

var A_arbace_spec_test_alpha_A_const_9 *lang.Var

var A_arbace_spec_test_alpha_A_const_10 *lang.Var

var A_arbace_spec_test_alpha_A_const_11 *lang.Var

var A_arbace_spec_test_alpha_A_const_12 any

var A_arbace_spec_test_alpha_A_const_13 *lang.Var

var A_arbace_spec_test_alpha_A_const_14 *lang.Var

var A_arbace_spec_test_alpha_A_const_15 *lang.Var

var A_arbace_spec_test_alpha_A_const_16 *lang.Var

var A_arbace_spec_test_alpha_A_const_17 *lang.Var

var A_arbace_spec_test_alpha_A_const_18 *lang.Var

var A_arbace_spec_test_alpha_A_const_19 *lang.Var

var A_arbace_spec_test_alpha_A_const_20 *lang.Var

var A_arbace_spec_test_alpha_A_const_21 *lang.Var

var A_arbace_spec_test_alpha_A_const_22 *lang.Var

var A_arbace_spec_test_alpha_A_const_23 *lang.Var

var A_arbace_spec_test_alpha_A_const_24 *lang.Var

var A_arbace_spec_test_alpha_A_const_25 *lang.Var

var A_arbace_spec_test_alpha_A_const_26 *lang.Var

var A_arbace_spec_test_alpha_A_const_27 *lang.Var

var A_arbace_spec_test_alpha_A_const_28 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_29 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_30 *lang.Var

var A_arbace_spec_test_alpha_A_const_31 *lang.Var

var A_arbace_spec_test_alpha_A_const_32 any

var A_arbace_spec_test_alpha_A_const_33 *lang.Var

var A_arbace_spec_test_alpha_A_const_34 *lang.Var

var A_arbace_spec_test_alpha_A_const_35 any

var A_arbace_spec_test_alpha_A_const_36 *lang.Var

var A_arbace_spec_test_alpha_A_const_37 *lang.Var

var A_arbace_spec_test_alpha_A_const_38 *lang.Var

var A_arbace_spec_test_alpha_A_const_39 any

var A_arbace_spec_test_alpha_A_const_40 *lang.Var

var A_arbace_spec_test_alpha_A_const_41 any

var A_arbace_spec_test_alpha_A_const_42 *lang.Var

var A_arbace_spec_test_alpha_A_const_43 *lang.Var

var A_arbace_spec_test_alpha_A_const_44 any

var A_arbace_spec_test_alpha_A_const_45 any

var A_arbace_spec_test_alpha_A_const_46 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_47 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_48 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_49 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_50 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_51 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_52 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_53 *lang.Var

var A_arbace_spec_test_alpha_A_const_54 *lang.Var

var A_arbace_spec_test_alpha_A_const_55 *lang.Var

var A_arbace_spec_test_alpha_A_const_56 *lang.Var

var A_arbace_spec_test_alpha_A_const_57 any

var A_arbace_spec_test_alpha_A_const_58 *lang.Var

var A_arbace_spec_test_alpha_A_const_59 *lang.Var

var A_arbace_spec_test_alpha_A_const_60 *lang.Var

var A_arbace_spec_test_alpha_A_const_61 *lang.Var

var A_arbace_spec_test_alpha_A_const_62 *lang.Var

var A_arbace_spec_test_alpha_A_const_63 *lang.Var

var A_arbace_spec_test_alpha_A_const_64 *lang.Var

var A_arbace_spec_test_alpha_A_const_65 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_66 *lang.Var

var A_arbace_spec_test_alpha_A_const_67 *lang.Var

var A_arbace_spec_test_alpha_A_const_68 *lang.Var

var A_arbace_spec_test_alpha_A_const_69 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_70 *lang.Var

var A_arbace_spec_test_alpha_A_const_71 *lang.Var

var A_arbace_spec_test_alpha_A_const_72 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_73 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_74 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_75 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_76 *lang.Var

var A_arbace_spec_test_alpha_A_const_77 *lang.Var

var A_arbace_spec_test_alpha_A_const_78 *lang.Var

var A_arbace_spec_test_alpha_A_const_79 *lang.Var

var A_arbace_spec_test_alpha_A_const_80 *lang.Var

var A_arbace_spec_test_alpha_A_const_81 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_82 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_83 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_84 *lang.Var

var A_arbace_spec_test_alpha_A_const_85 *lang.Var

var A_arbace_spec_test_alpha_A_const_86 *lang.Var

var A_arbace_spec_test_alpha_A_const_87 any

var A_arbace_spec_test_alpha_A_const_88 *lang.Var

var A_arbace_spec_test_alpha_A_const_89 *lang.Var

var A_arbace_spec_test_alpha_A_const_90 *lang.Var

var A_arbace_spec_test_alpha_A_const_91 *lang.Var

var A_arbace_spec_test_alpha_A_const_92 *lang.Var

var A_arbace_spec_test_alpha_A_const_93 *lang.Var

var A_arbace_spec_test_alpha_A_const_94 *lang.Var

var A_arbace_spec_test_alpha_A_const_95 *lang.Var

var A_arbace_spec_test_alpha_A_const_96 *lang.Var

var A_arbace_spec_test_alpha_A_const_97 *lang.Var

var A_arbace_spec_test_alpha_A_const_98 *lang.Var

var A_arbace_spec_test_alpha_A_const_99 any

var A_arbace_spec_test_alpha_A_const_100 *lang.Var

var A_arbace_spec_test_alpha_A_const_101 any

var A_arbace_spec_test_alpha_A_const_102 any

var A_arbace_spec_test_alpha_A_const_103 any

var A_arbace_spec_test_alpha_A_const_104 any

var A_arbace_spec_test_alpha_A_const_105 any

var A_arbace_spec_test_alpha_A_const_106 any

var A_arbace_spec_test_alpha_A_const_107 any

var A_arbace_spec_test_alpha_A_const_108 any

var A_arbace_spec_test_alpha_A_const_109 any

var A_arbace_spec_test_alpha_A_const_110 any

var A_arbace_spec_test_alpha_A_const_111 *lang.Var

var A_arbace_spec_test_alpha_A_const_112 *lang.Var

var A_arbace_spec_test_alpha_A_const_113 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_114 *lang.Var

var A_arbace_spec_test_alpha_A_const_115 any

var A_arbace_spec_test_alpha_A_const_116 *lang.Var

var A_arbace_spec_test_alpha_A_const_117 *lang.Var

var A_arbace_spec_test_alpha_A_const_118 *lang.Var

var A_arbace_spec_test_alpha_A_const_119 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_120 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_121 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_122 *lang.Var

var A_arbace_spec_test_alpha_A_const_123 *lang.Var

var A_arbace_spec_test_alpha_A_const_124 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_125 *lang.Var

var A_arbace_spec_test_alpha_A_const_126 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_127 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_128 *lang.Var

var A_arbace_spec_test_alpha_A_const_129 *lang.Var

var A_arbace_spec_test_alpha_A_const_130 *lang.Var

var A_arbace_spec_test_alpha_A_const_131 *lang.Var

var A_arbace_spec_test_alpha_A_const_132 *lang.Var

var A_arbace_spec_test_alpha_A_const_133 *lang.Var

var A_arbace_spec_test_alpha_A_const_134 *lang.Var

var A_arbace_spec_test_alpha_A_const_135 *lang.Var

var A_arbace_spec_test_alpha_A_const_136 *lang.Var

var A_arbace_spec_test_alpha_A_const_137 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_138 *lang.Var

var A_arbace_spec_test_alpha_A_const_139 *lang.Var

var A_arbace_spec_test_alpha_A_const_140 *lang.Var

var A_arbace_spec_test_alpha_A_const_141 *lang.Var

var A_arbace_spec_test_alpha_A_const_142 *lang.Var

var A_arbace_spec_test_alpha_A_const_143 *lang.Var

var A_arbace_spec_test_alpha_A_const_144 *lang.Var

var A_arbace_spec_test_alpha_A_const_145 any

var A_arbace_spec_test_alpha_A_const_146 *lang.Var

var A_arbace_spec_test_alpha_A_const_147 *lang.Var

var A_arbace_spec_test_alpha_A_const_148 *lang.Var

var A_arbace_spec_test_alpha_A_const_149 *lang.Var

var A_arbace_spec_test_alpha_A_const_150 *lang.Var

var A_arbace_spec_test_alpha_A_const_151 *lang.Var

var A_arbace_spec_test_alpha_A_const_152 *lang.Var

var A_arbace_spec_test_alpha_A_const_153 *lang.Var

var A_arbace_spec_test_alpha_A_const_154 *lang.Var

var A_arbace_spec_test_alpha_A_const_155 *lang.Var

var A_arbace_spec_test_alpha_A_const_156 *lang.Var

var A_arbace_spec_test_alpha_A_const_157 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_158 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_159 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_160 *lang.Var

var A_arbace_spec_test_alpha_A_const_161 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_162 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_163 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_164 *lang.Var

var A_arbace_spec_test_alpha_A_const_165 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_166 *lang.Var

var A_arbace_spec_test_alpha_A_const_167 *lang.Var

var A_arbace_spec_test_alpha_A_const_168 *lang.Var

var A_arbace_spec_test_alpha_A_const_169 *lang.Var

var A_arbace_spec_test_alpha_A_const_170 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_171 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_172 *lang.Var

var A_arbace_spec_test_alpha_A_const_173 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_174 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_175 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_176 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_177 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_178 *lang.Var

var A_arbace_spec_test_alpha_A_const_179 *lang.Var

var A_arbace_spec_test_alpha_A_const_180 *lang.Var

var A_arbace_spec_test_alpha_A_const_181 any

var A_arbace_spec_test_alpha_A_const_182 any

var A_arbace_spec_test_alpha_A_const_183 any

var A_arbace_spec_test_alpha_A_const_184 any

var A_arbace_spec_test_alpha_A_const_185 *lang.Var

var A_arbace_spec_test_alpha_A_const_186 *lang.Var

var A_arbace_spec_test_alpha_A_const_187 *lang.Var

var A_arbace_spec_test_alpha_A_const_188 *lang.Var

var A_arbace_spec_test_alpha_A_const_189 *lang.Var

var A_arbace_spec_test_alpha_A_const_190 *lang.Var

var A_arbace_spec_test_alpha_A_const_191 *lang.Var

var A_arbace_spec_test_alpha_A_const_192 *lang.Var

var A_arbace_spec_test_alpha_A_const_193 *lang.Var

var A_arbace_spec_test_alpha_A_const_194 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_195 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_196 *lang.Var

var A_arbace_spec_test_alpha_A_const_197 *lang.Var

var A_arbace_spec_test_alpha_A_const_198 *lang.Var

var A_arbace_spec_test_alpha_A_const_199 *lang.Var

var A_arbace_spec_test_alpha_A_const_200 *lang.Var

var A_arbace_spec_test_alpha_A_const_201 *lang.Var

var A_arbace_spec_test_alpha_A_const_202 *lang.Keyword

var A_arbace_spec_test_alpha_A_const_203 *lang.Var

var A_arbace_spec_test_alpha_A_const_204 any

var A_arbace_spec_test_alpha_A_const_205 any

var A_arbace_spec_test_alpha_A_const_206 *lang.Var

var A_arbace_spec_test_alpha_A_const_207 *lang.Var

var A_arbace_spec_test_alpha_A_init jrt.ClassInit

func A_arbace_spec_test_alpha_A_Init() { if !A_arbace_spec_test_alpha_A_init.Done() { A_arbace_spec_test_alpha_A_init.Run(A_arbace_spec_test_alpha_A_clinit) } }

func A_arbace_spec_test_alpha_A_clinit() { A_arbace_spec_test_alpha_A_clinit_p0(); A_arbace_spec_test_alpha_A_clinit_p1(); A_arbace_spec_test_alpha_A_clinit_p2(); A_arbace_spec_test_alpha_A_clinit_p3(); A_arbace_spec_test_alpha_A_clinit_p4(); A_arbace_spec_test_alpha_A_clinit_p5(); A_arbace_spec_test_alpha_A_clinit_p6(); A_arbace_spec_test_alpha_A_clinit_p7(); A_arbace_spec_test_alpha_A_clinit_p8(); A_arbace_spec_test_alpha_A_clinit_p9(); A_arbace_spec_test_alpha_A_clinit_p10(); A_arbace_spec_test_alpha_A_clinit_p11(); A_arbace_spec_test_alpha_A_clinit_p12(); A_arbace_spec_test_alpha_A_clinit_p13(); A_arbace_spec_test_alpha_A_clinit_p14(); A_arbace_spec_test_alpha_A_clinit_p15(); A_arbace_spec_test_alpha_A_clinit_p16() }

func A_arbace_spec_test_alpha_A_clinit_p0() { jrt.StartCheck(); A_arbace_spec_test_alpha_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 285); A_arbace_spec_test_alpha_A_const_0 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[77]); A_arbace_spec_test_alpha_A_const_1 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[78]); A_arbace_spec_test_alpha_A_const_2 = A_arbace_spec_test_alpha_A_const_pool.A[79]; A_arbace_spec_test_alpha_A_const_3 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[80]); A_arbace_spec_test_alpha_A_const_4 = A_arbace_spec_test_alpha_A_const_pool.A[81]; A_arbace_spec_test_alpha_A_const_5 = A_arbace_spec_test_alpha_A_const_pool.A[82]; A_arbace_spec_test_alpha_A_const_6 = A_arbace_spec_test_alpha_A_const_pool.A[83]; A_arbace_spec_test_alpha_A_const_7 = A_arbace_spec_test_alpha_A_const_pool.A[84]; A_arbace_spec_test_alpha_A_const_8 = A_arbace_spec_test_alpha_A_const_pool.A[85]; A_arbace_spec_test_alpha_A_const_9 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[86]); A_arbace_spec_test_alpha_A_const_10 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[87]); A_arbace_spec_test_alpha_A_const_11 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[88]); A_arbace_spec_test_alpha_A_const_12 = A_arbace_spec_test_alpha_A_const_pool.A[89] }

func A_arbace_spec_test_alpha_A_clinit_p1() { A_arbace_spec_test_alpha_A_const_13 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[90]); A_arbace_spec_test_alpha_A_const_14 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[91]); A_arbace_spec_test_alpha_A_const_15 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[92]); A_arbace_spec_test_alpha_A_const_16 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[93]); A_arbace_spec_test_alpha_A_const_17 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[94]); A_arbace_spec_test_alpha_A_const_18 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[95]); A_arbace_spec_test_alpha_A_const_19 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[96]); A_arbace_spec_test_alpha_A_const_20 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[97]); A_arbace_spec_test_alpha_A_const_21 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[98]); A_arbace_spec_test_alpha_A_const_22 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[99]); A_arbace_spec_test_alpha_A_const_23 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[100]); A_arbace_spec_test_alpha_A_const_24 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[101]) }

func A_arbace_spec_test_alpha_A_clinit_p2() { A_arbace_spec_test_alpha_A_const_25 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[102]); A_arbace_spec_test_alpha_A_const_26 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[103]); A_arbace_spec_test_alpha_A_const_27 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[104]); A_arbace_spec_test_alpha_A_const_28 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[105]); A_arbace_spec_test_alpha_A_const_29 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[106]); A_arbace_spec_test_alpha_A_const_30 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[107]); A_arbace_spec_test_alpha_A_const_31 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[108]); A_arbace_spec_test_alpha_A_const_32 = A_arbace_spec_test_alpha_A_const_pool.A[109]; A_arbace_spec_test_alpha_A_const_33 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[110]); A_arbace_spec_test_alpha_A_const_34 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[111]); A_arbace_spec_test_alpha_A_const_35 = A_arbace_spec_test_alpha_A_const_pool.A[112]; A_arbace_spec_test_alpha_A_const_36 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[113]) }

func A_arbace_spec_test_alpha_A_clinit_p3() { A_arbace_spec_test_alpha_A_const_37 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[114]); A_arbace_spec_test_alpha_A_const_38 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[115]); A_arbace_spec_test_alpha_A_const_39 = A_arbace_spec_test_alpha_A_const_pool.A[116]; A_arbace_spec_test_alpha_A_const_40 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[117]); A_arbace_spec_test_alpha_A_const_41 = A_arbace_spec_test_alpha_A_const_pool.A[118]; A_arbace_spec_test_alpha_A_const_42 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[119]); A_arbace_spec_test_alpha_A_const_43 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[120]); A_arbace_spec_test_alpha_A_const_44 = A_arbace_spec_test_alpha_A_const_pool.A[121]; A_arbace_spec_test_alpha_A_const_45 = A_arbace_spec_test_alpha_A_const_pool.A[122]; A_arbace_spec_test_alpha_A_const_46 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[123]); A_arbace_spec_test_alpha_A_const_47 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[124]); A_arbace_spec_test_alpha_A_const_48 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[125]); A_arbace_spec_test_alpha_A_const_49 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[126]) }

func A_arbace_spec_test_alpha_A_clinit_p4() { A_arbace_spec_test_alpha_A_const_50 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[127]); A_arbace_spec_test_alpha_A_const_51 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[128]); A_arbace_spec_test_alpha_A_const_52 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[129]); A_arbace_spec_test_alpha_A_const_53 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[130]); A_arbace_spec_test_alpha_A_const_54 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[131]); A_arbace_spec_test_alpha_A_const_55 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[132]); A_arbace_spec_test_alpha_A_const_56 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[133]); A_arbace_spec_test_alpha_A_const_57 = A_arbace_spec_test_alpha_A_const_pool.A[134]; A_arbace_spec_test_alpha_A_const_58 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[135]); A_arbace_spec_test_alpha_A_const_59 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[136]); A_arbace_spec_test_alpha_A_const_60 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[137]); A_arbace_spec_test_alpha_A_const_61 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[138]) }

func A_arbace_spec_test_alpha_A_clinit_p5() { A_arbace_spec_test_alpha_A_const_62 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[139]); A_arbace_spec_test_alpha_A_const_63 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[140]); A_arbace_spec_test_alpha_A_const_64 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[141]); A_arbace_spec_test_alpha_A_const_65 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[142]); A_arbace_spec_test_alpha_A_const_66 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[143]); A_arbace_spec_test_alpha_A_const_67 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[144]); A_arbace_spec_test_alpha_A_const_68 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[145]); A_arbace_spec_test_alpha_A_const_69 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[146]); A_arbace_spec_test_alpha_A_const_70 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[147]); A_arbace_spec_test_alpha_A_const_71 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[148]); A_arbace_spec_test_alpha_A_const_72 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[149]); A_arbace_spec_test_alpha_A_const_73 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[150]) }

func A_arbace_spec_test_alpha_A_clinit_p6() { A_arbace_spec_test_alpha_A_const_74 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[151]); A_arbace_spec_test_alpha_A_const_75 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[152]); A_arbace_spec_test_alpha_A_const_76 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[153]); A_arbace_spec_test_alpha_A_const_77 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[154]); A_arbace_spec_test_alpha_A_const_78 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[155]); A_arbace_spec_test_alpha_A_const_79 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[156]); A_arbace_spec_test_alpha_A_const_80 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[157]); A_arbace_spec_test_alpha_A_const_81 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[158]); A_arbace_spec_test_alpha_A_const_82 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[159]); A_arbace_spec_test_alpha_A_const_83 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[160]); A_arbace_spec_test_alpha_A_const_84 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[161]); A_arbace_spec_test_alpha_A_const_85 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[162]) }

func A_arbace_spec_test_alpha_A_clinit_p7() { A_arbace_spec_test_alpha_A_const_86 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[163]); A_arbace_spec_test_alpha_A_const_87 = A_arbace_spec_test_alpha_A_const_pool.A[164]; A_arbace_spec_test_alpha_A_const_88 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[165]); A_arbace_spec_test_alpha_A_const_89 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[166]); A_arbace_spec_test_alpha_A_const_90 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[167]); A_arbace_spec_test_alpha_A_const_91 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[168]); A_arbace_spec_test_alpha_A_const_92 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[169]); A_arbace_spec_test_alpha_A_const_93 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[170]); A_arbace_spec_test_alpha_A_const_94 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[171]); A_arbace_spec_test_alpha_A_const_95 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[172]); A_arbace_spec_test_alpha_A_const_96 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[173]); A_arbace_spec_test_alpha_A_const_97 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[174]) }

func A_arbace_spec_test_alpha_A_clinit_p8() { A_arbace_spec_test_alpha_A_const_98 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[175]); A_arbace_spec_test_alpha_A_const_99 = A_arbace_spec_test_alpha_A_const_pool.A[176]; A_arbace_spec_test_alpha_A_const_100 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[177]); A_arbace_spec_test_alpha_A_const_101 = A_arbace_spec_test_alpha_A_const_pool.A[178]; A_arbace_spec_test_alpha_A_const_102 = A_arbace_spec_test_alpha_A_const_pool.A[179]; A_arbace_spec_test_alpha_A_const_103 = A_arbace_spec_test_alpha_A_const_pool.A[180]; A_arbace_spec_test_alpha_A_const_104 = A_arbace_spec_test_alpha_A_const_pool.A[181]; A_arbace_spec_test_alpha_A_const_105 = A_arbace_spec_test_alpha_A_const_pool.A[182]; A_arbace_spec_test_alpha_A_const_106 = A_arbace_spec_test_alpha_A_const_pool.A[183]; A_arbace_spec_test_alpha_A_const_107 = A_arbace_spec_test_alpha_A_const_pool.A[184]; A_arbace_spec_test_alpha_A_const_108 = A_arbace_spec_test_alpha_A_const_pool.A[185]; A_arbace_spec_test_alpha_A_const_109 = A_arbace_spec_test_alpha_A_const_pool.A[186]; A_arbace_spec_test_alpha_A_const_110 = A_arbace_spec_test_alpha_A_const_pool.A[187]; A_arbace_spec_test_alpha_A_const_111 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[188]) }

func A_arbace_spec_test_alpha_A_clinit_p9() { A_arbace_spec_test_alpha_A_const_112 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[189]); A_arbace_spec_test_alpha_A_const_113 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[190]); A_arbace_spec_test_alpha_A_const_114 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[191]); A_arbace_spec_test_alpha_A_const_115 = A_arbace_spec_test_alpha_A_const_pool.A[192]; A_arbace_spec_test_alpha_A_const_116 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[193]); A_arbace_spec_test_alpha_A_const_117 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[194]); A_arbace_spec_test_alpha_A_const_118 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[195]); A_arbace_spec_test_alpha_A_const_119 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[196]); A_arbace_spec_test_alpha_A_const_120 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[197]); A_arbace_spec_test_alpha_A_const_121 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[198]); A_arbace_spec_test_alpha_A_const_122 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[199]); A_arbace_spec_test_alpha_A_const_123 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[200]) }

func A_arbace_spec_test_alpha_A_clinit_p10() { A_arbace_spec_test_alpha_A_const_124 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[201]); A_arbace_spec_test_alpha_A_const_125 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[202]); A_arbace_spec_test_alpha_A_const_126 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[203]); A_arbace_spec_test_alpha_A_const_127 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[204]); A_arbace_spec_test_alpha_A_const_128 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[205]); A_arbace_spec_test_alpha_A_const_129 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[206]); A_arbace_spec_test_alpha_A_const_130 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[207]); A_arbace_spec_test_alpha_A_const_131 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[208]); A_arbace_spec_test_alpha_A_const_132 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[209]); A_arbace_spec_test_alpha_A_const_133 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[210]); A_arbace_spec_test_alpha_A_const_134 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[211]); A_arbace_spec_test_alpha_A_const_135 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[212]) }

func A_arbace_spec_test_alpha_A_clinit_p11() { A_arbace_spec_test_alpha_A_const_136 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[213]); A_arbace_spec_test_alpha_A_const_137 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[214]); A_arbace_spec_test_alpha_A_const_138 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[215]); A_arbace_spec_test_alpha_A_const_139 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[216]); A_arbace_spec_test_alpha_A_const_140 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[217]); A_arbace_spec_test_alpha_A_const_141 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[218]); A_arbace_spec_test_alpha_A_const_142 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[219]); A_arbace_spec_test_alpha_A_const_143 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[220]); A_arbace_spec_test_alpha_A_const_144 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[221]); A_arbace_spec_test_alpha_A_const_145 = A_arbace_spec_test_alpha_A_const_pool.A[222]; A_arbace_spec_test_alpha_A_const_146 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[223]); A_arbace_spec_test_alpha_A_const_147 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[224]) }

func A_arbace_spec_test_alpha_A_clinit_p12() { A_arbace_spec_test_alpha_A_const_148 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[225]); A_arbace_spec_test_alpha_A_const_149 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[226]); A_arbace_spec_test_alpha_A_const_150 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[227]); A_arbace_spec_test_alpha_A_const_151 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[228]); A_arbace_spec_test_alpha_A_const_152 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[229]); A_arbace_spec_test_alpha_A_const_153 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[230]); A_arbace_spec_test_alpha_A_const_154 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[231]); A_arbace_spec_test_alpha_A_const_155 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[232]); A_arbace_spec_test_alpha_A_const_156 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[233]); A_arbace_spec_test_alpha_A_const_157 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[234]); A_arbace_spec_test_alpha_A_const_158 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[235]); A_arbace_spec_test_alpha_A_const_159 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[236]) }

func A_arbace_spec_test_alpha_A_clinit_p13() { A_arbace_spec_test_alpha_A_const_160 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[237]); A_arbace_spec_test_alpha_A_const_161 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[238]); A_arbace_spec_test_alpha_A_const_162 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[239]); A_arbace_spec_test_alpha_A_const_163 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[240]); A_arbace_spec_test_alpha_A_const_164 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[241]); A_arbace_spec_test_alpha_A_const_165 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[242]); A_arbace_spec_test_alpha_A_const_166 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[243]); A_arbace_spec_test_alpha_A_const_167 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[244]); A_arbace_spec_test_alpha_A_const_168 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[245]); A_arbace_spec_test_alpha_A_const_169 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[246]); A_arbace_spec_test_alpha_A_const_170 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[247]); A_arbace_spec_test_alpha_A_const_171 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[248]) }

func A_arbace_spec_test_alpha_A_clinit_p14() { A_arbace_spec_test_alpha_A_const_172 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[249]); A_arbace_spec_test_alpha_A_const_173 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[250]); A_arbace_spec_test_alpha_A_const_174 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[251]); A_arbace_spec_test_alpha_A_const_175 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[252]); A_arbace_spec_test_alpha_A_const_176 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[253]); A_arbace_spec_test_alpha_A_const_177 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[254]); A_arbace_spec_test_alpha_A_const_178 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[255]); A_arbace_spec_test_alpha_A_const_179 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[256]); A_arbace_spec_test_alpha_A_const_180 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[257]); A_arbace_spec_test_alpha_A_const_181 = A_arbace_spec_test_alpha_A_const_pool.A[258]; A_arbace_spec_test_alpha_A_const_182 = A_arbace_spec_test_alpha_A_const_pool.A[259]; A_arbace_spec_test_alpha_A_const_183 = A_arbace_spec_test_alpha_A_const_pool.A[260]; A_arbace_spec_test_alpha_A_const_184 = A_arbace_spec_test_alpha_A_const_pool.A[261] }

func A_arbace_spec_test_alpha_A_clinit_p15() { A_arbace_spec_test_alpha_A_const_185 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[262]); A_arbace_spec_test_alpha_A_const_186 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[263]); A_arbace_spec_test_alpha_A_const_187 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[264]); A_arbace_spec_test_alpha_A_const_188 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[265]); A_arbace_spec_test_alpha_A_const_189 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[266]); A_arbace_spec_test_alpha_A_const_190 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[267]); A_arbace_spec_test_alpha_A_const_191 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[268]); A_arbace_spec_test_alpha_A_const_192 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[269]); A_arbace_spec_test_alpha_A_const_193 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[270]); A_arbace_spec_test_alpha_A_const_194 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[271]); A_arbace_spec_test_alpha_A_const_195 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[272]); A_arbace_spec_test_alpha_A_const_196 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[273]) }

func A_arbace_spec_test_alpha_A_clinit_p16() { A_arbace_spec_test_alpha_A_const_197 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[274]); A_arbace_spec_test_alpha_A_const_198 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[275]); A_arbace_spec_test_alpha_A_const_199 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[276]); A_arbace_spec_test_alpha_A_const_200 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[277]); A_arbace_spec_test_alpha_A_const_201 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[278]); A_arbace_spec_test_alpha_A_const_202 = lang.Keyword_Cast(A_arbace_spec_test_alpha_A_const_pool.A[279]); A_arbace_spec_test_alpha_A_const_203 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[280]); A_arbace_spec_test_alpha_A_const_204 = A_arbace_spec_test_alpha_A_const_pool.A[281]; A_arbace_spec_test_alpha_A_const_205 = A_arbace_spec_test_alpha_A_const_pool.A[282]; A_arbace_spec_test_alpha_A_const_206 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[283]); A_arbace_spec_test_alpha_A_const_207 = lang.Var_Cast(A_arbace_spec_test_alpha_A_const_pool.A[284]) }

func A_arbace_spec_test_alpha_A_New() *A_arbace_spec_test_alpha_A { A_arbace_spec_test_alpha_A_Init(); t := &A_arbace_spec_test_alpha_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_A_class }

func (t *A_arbace_spec_test_alpha_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_A); return ok }

func A_arbace_spec_test_alpha_A_Cast(x any) *A_arbace_spec_test_alpha_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_A_class)) }; return v }



type A_arbace_spec_test_alpha___GT_sym_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha___GT_sym_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha___GT_var_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha___GT_var_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_abbrev_result_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_abbrev_result_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_fixed_args_body_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_fixed_args_body_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_flattener_code_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_flattener_code_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A struct{ j2g_header uint64; F_closed_over_name any }

var A_arbace_spec_test_alpha_build_flattener_code_fn__107000074_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_kwargs_body_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_kwargs_body_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_build_varargs_body_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_build_varargs_body_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_fn__107000127_A struct{ j2g_header uint64; F_opts any }

var A_arbace_spec_test_alpha_check_fn__107000127_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_1_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_1_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_call_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_call_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_check_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_check_fn_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_checkable_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_checkable_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_collectionize_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_collectionize_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_enumerate_namespace_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_enumerate_namespace_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A struct{ j2g_header uint64; F_ns_sym any }

var A_arbace_spec_test_alpha_enumerate_namespace_fn__107000020_fn__107000021_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_eval107000002_A struct{ jrt.Object }

func A_arbace_spec_test_alpha_eval107000002_A_New() *A_arbace_spec_test_alpha_eval107000002_A { t := &A_arbace_spec_test_alpha_eval107000002_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_eval107000002_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_eval107000002_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000002_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000002_A_class }

func (t *A_arbace_spec_test_alpha_eval107000002_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000002_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000002_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000002_A); return ok }

func A_arbace_spec_test_alpha_eval107000002_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000002_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000002_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000002_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_eval107000002_loading__1927001464__auto____107000003_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_eval107000006_A struct{ jrt.Object }

func A_arbace_spec_test_alpha_eval107000006_A_New() *A_arbace_spec_test_alpha_eval107000006_A { t := &A_arbace_spec_test_alpha_eval107000006_A{}; t.Ctor(); return t }

func (t *A_arbace_spec_test_alpha_eval107000006_A) Ctor() {}

func (t *A_arbace_spec_test_alpha_eval107000006_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_spec_test_alpha_eval107000006_A) GetClass__Class() *jrt.Class { return A_arbace_spec_test_alpha_eval107000006_A_class }

func (t *A_arbace_spec_test_alpha_eval107000006_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_spec_test_alpha_eval107000006_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_spec_test_alpha_eval107000006_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_spec_test_alpha_eval107000006_A); return ok }

func A_arbace_spec_test_alpha_eval107000006_A_Cast(x any) *A_arbace_spec_test_alpha_eval107000006_A { if x == nil { return nil }; v, ok := x.(*A_arbace_spec_test_alpha_eval107000006_A); if !ok { panic(jrt.ClassCast(x, A_arbace_spec_test_alpha_eval107000006_A_class)) }; return v }



type A_arbace_spec_test_alpha_eval107000006_fn__107000007_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_eval107000006_fn__107000007_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_explain_check_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_explain_check_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_failure_type_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_failure_type_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_find_varargs_decl_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_find_varargs_decl_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_fn_spec_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_fn_spec_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_fn_spec_name_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_fn_spec_name_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_gen_fixed_args_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_gen_fixed_args_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_gen_fixed_args_syms_fn__107000068_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_has_kwargs_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_has_kwargs_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_fn__107000097_A struct{ j2g_header uint64; F_opts any }

var A_arbace_spec_test_alpha_instrument_fn__107000097_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_1_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_1_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_choose_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_choose_fn_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrument_choose_spec_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrument_choose_spec_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_instrumentable_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_instrumentable_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_interpret_stack_trace_element_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_degensym__107000043_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_interpret_stack_trace_element_demunge__107000041_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_kwargs__GT_kvs_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_kwargs__GT_kvs_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_kwargs__GT_kvs_fn__107000065_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_make_check_result_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_make_check_result_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_maybe_wrap_kvs_emulation_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_no_fspec_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_no_fspec_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_opt_syms_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_opt_syms_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_quick_check_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_quick_check_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_quick_check_fn__107000111_A struct{ j2g_header uint64; F_gen, F_specs any }

var A_arbace_spec_test_alpha_quick_check_fn__107000111_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_quick_check_fn__107000113_A struct{ j2g_header uint64; F_f, F_specs any }

var A_arbace_spec_test_alpha_quick_check_fn__107000113_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_result_type_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_result_type_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_spec_checking_fn_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_spec_checking_fn_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_spec_checking_fn_conform_BANG___107000052_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A struct{ j2g_header uint64; F_fn_name, F_f, F_conform_BANG_, F_fn_spec any }

var A_arbace_spec_test_alpha_spec_checking_fn_fn__107000054_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_stacktrace_relevant_to_instrument_plumbing_QMARK___107000047_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_summarize_results_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_summarize_results_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_summarize_results_fn__107000134_A struct{ j2g_header uint64; F_summary_result any }

var A_arbace_spec_test_alpha_summarize_results_fn__107000134_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_sym__GT_check_map_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_sym__GT_check_map_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_throwable_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_throwable_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_thunk_frame_QMARK__A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_thunk_frame_QMARK__A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_unstrument_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_unstrument_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_unstrument_1_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_unstrument_1_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_unwrap_failure_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_unwrap_failure_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_validate_check_opts_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_validate_check_opts_A_fn_class *jrt.Class



type A_arbace_spec_test_alpha_with_instrument_disabled_A struct{ j2g_header uint64 }

var A_arbace_spec_test_alpha_with_instrument_disabled_A_fn_class *jrt.Class
