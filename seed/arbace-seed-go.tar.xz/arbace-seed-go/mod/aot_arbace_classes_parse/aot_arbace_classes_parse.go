//line aot_arbace_classes_parse.ae:1
package aot_arbace_classes_parse

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_New() *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A { A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_Init(); t := &A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_classes_parse_A_Init(); tmp9 = A_arbace_classes_parse_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_classes_parse_A_Init(); tmp11 = A_arbace_classes_parse_A_const_4; tmp3 = tmp8.Invoke_O_O__O(tmp10, tmp11) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp12 != nil { panic(tmp12) }; return tmp3 }
//line :1:1
func A_arbace_classes_parse_eval662000008_fn__662000009_A_New() *A_arbace_classes_parse_eval662000008_fn__662000009_A { A_arbace_classes_parse_eval662000008_fn__662000009_A_Init(); t := &A_arbace_classes_parse_eval662000008_fn__662000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_5; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_6; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_9; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_7; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_classes_parse_A_Init(); tmp9 = A_arbace_classes_parse_A_const_8; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }







func A_arbace_classes_parse_kw_meta_A_New() *A_arbace_classes_parse_kw_meta_A { A_arbace_classes_parse_kw_meta_A_Init(); t := &A_arbace_classes_parse_kw_meta_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_classes_parse_kw_meta_A) Ctor() {}
//line :9:1
func (t *A_arbace_classes_parse_kw_meta_A) Invoke_O_O_O__O(self, m__0, k__1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.RT_Get_O_O__O(m__0, k__1))).Ref() }








func A_arbace_classes_parse_flags_of_A_New() *A_arbace_classes_parse_flags_of_A { A_arbace_classes_parse_flags_of_A_Init(); t := &A_arbace_classes_parse_flags_of_A{}; t.Ctor(); return t }
//line :18:1
func (t *A_arbace_classes_parse_flags_of_A) Ctor() {}
//line :18:1
func (t *A_arbace_classes_parse_flags_of_A) Invoke_O_O_O__O(self, m__0, allowed__1 any) any {


	var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_10; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_parse_flags_of_fn__662000013_A_New_O_O(allowed__1, m__0); var tmp4 *jrt.Class; A_arbace_classes_parse_flags_of_fn__662000013_A_Init(); tmp4 = A_arbace_classes_parse_flags_of_fn__662000013_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 any; A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_12; var tmp7 any = tmp6; var tmp8 *lang.Var; A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_classes_parse_A_Init(); tmp10 = A_arbace_classes_parse_A_const_11; return tmp2.Invoke_O_O_O__O(tmp5, tmp7, tmp9.Invoke_O__O(jrt.NN(tmp10).GetRawRoot__O())) }
//line :21:1
func A_arbace_classes_parse_flags_of_fn__662000013_A_New_O_O(p0, p1 any) *A_arbace_classes_parse_flags_of_fn__662000013_A { A_arbace_classes_parse_flags_of_fn__662000013_A_Init(); t := &A_arbace_classes_parse_flags_of_fn__662000013_A{}; t.Ctor_O_O(p0, p1); return t }
//line :21:1
func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) Ctor_O_O(c__allowed, c__m any) { t.F_allowed = c__allowed; t.F_m = c__m }
//line :21:1
func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) Invoke_O_O_O__O(self, acc__1, k__2 any) any { var tmp1 any; var and__1927000168__auto____3 any = lang.RT_Get_O_O__O(t.F_m, k__2); if jrt.A2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(t.F_allowed).Invoke_O__O(k__2) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { var tmp2 *lang.Var; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_11; return jrt.Long_ValueOf_J__Long(lang.Numbers_Or_O_O__J(acc__1, lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(k__2))).Ref() } else { return acc__1 } }


func A_arbace_classes_parse_has_QMARK__A_New() *A_arbace_classes_parse_has_QMARK__A { A_arbace_classes_parse_has_QMARK__A_Init(); t := &A_arbace_classes_parse_has_QMARK__A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_classes_parse_has_QMARK__A) Ctor() {}
//line :24:1
func (t *A_arbace_classes_parse_has_QMARK__A) Invoke_O_O_O__O(self, flags__0, f__1 any) any { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_14; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(jrt.Boolean_ValueOf_Z__Boolean(lang.Numbers_IsZero_J__Z(lang.Numbers_And_O_O__J(flags__0, f__1))).Ref()) }

func A_arbace_classes_parse_kind_of_A_New() *A_arbace_classes_parse_kind_of_A { A_arbace_classes_parse_kind_of_A_Init(); t := &A_arbace_classes_parse_kind_of_A{}; t.Ctor(); return t }
//line :26:1
func (t *A_arbace_classes_parse_kind_of_A) Ctor() {}
//line :26:1
func (t *A_arbace_classes_parse_kind_of_A) Invoke_O_O__O(self, m__0 any) any {
	var tmp1 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_15; if jrt.A2g_Truth(jrt.NN(tmp1).Invoke_O__O(m__0)) { A_arbace_classes_parse_A_Init(); return A_arbace_classes_parse_A_const_15.Ref() } else { var tmp2 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_16; if jrt.A2g_Truth(jrt.NN(tmp2).Invoke_O__O(m__0)) { A_arbace_classes_parse_A_Init(); return A_arbace_classes_parse_A_const_16.Ref() } else { var tmp3 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_17; if jrt.A2g_Truth(jrt.NN(tmp3).Invoke_O__O(m__0)) { A_arbace_classes_parse_A_Init(); return A_arbace_classes_parse_A_const_17.Ref() } else { var tmp4 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_18; if jrt.A2g_Truth(jrt.NN(tmp4).Invoke_O__O(m__0)) { A_arbace_classes_parse_A_Init(); return A_arbace_classes_parse_A_const_18.Ref() } else { var tmp5 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_19; if tmp5 != nil { A_arbace_classes_parse_A_Init(); return A_arbace_classes_parse_A_const_20.Ref() } else { return nil
	}
	} } } } }
func A_arbace_classes_parse_split_options_A_New() *A_arbace_classes_parse_split_options_A { A_arbace_classes_parse_split_options_A_Init(); t := &A_arbace_classes_parse_split_options_A{}; t.Ctor(); return t }
//line :30:1
func (t *A_arbace_classes_parse_split_options_A) Ctor() {}
//line :30:1
func (t *A_arbace_classes_parse_split_options_A) Invoke_O_O__O(self, xs__0 any) any { { var xs__2 any = xs__0; var opts__3 any; lang.PersistentArrayMap_Init(); opts__3 = lang.PersistentArrayMap_EMPTY.Ref(); L1: for {



	var tmp1 any; var and__1927000168__auto____4 any; var tmp2 *lang.Var; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_21; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_23; and__1927000168__auto____4 = tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(xs__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp5 *lang.Var; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_22; tmp1 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(xs__2) } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) {
		var tmp6 *lang.Var; A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_24; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(xs__2); var tmp8 *lang.Var; A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_25; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_classes_parse_A_Init(); tmp10 = A_arbace_classes_parse_A_const_23; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(xs__2); var tmp12 *lang.Var; A_arbace_classes_parse_A_Init(); tmp12 = A_arbace_classes_parse_A_const_26; xs__2, opts__3 = tmp7, tmp9.Invoke_O_O_O__O(opts__3, tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(xs__2)); continue L1 } else {
//line :34:1
			return lang.Tuple_Create_O_O__IPersistentVector(opts__3, xs__2) } } }; /*line :30:1*/panic("a2g: unreachable") }







func A_arbace_classes_parse_expand_members_A_New() *A_arbace_classes_parse_expand_members_A { A_arbace_classes_parse_expand_members_A_Init(); t := &A_arbace_classes_parse_expand_members_A{}; t.Ctor(); return t }
//line :38:1
func (t *A_arbace_classes_parse_expand_members_A) Ctor() {}
//line :38:1
func (t *A_arbace_classes_parse_expand_members_A) Invoke_O_O_O__O(self, ns__0, forms__1 any) any {


	var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_27; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_classes_parse_expand_members_expand__662000019_A_New_O(ns__0); var tmp4 *jrt.Class; A_arbace_classes_parse_expand_members_expand__662000019_A_Init(); tmp4 = A_arbace_classes_parse_expand_members_expand__662000019_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__1) }
//line :41:1
func A_arbace_classes_parse_expand_members_expand__662000019_A_New_O(p0 any) *A_arbace_classes_parse_expand_members_expand__662000019_A { A_arbace_classes_parse_expand_members_expand__662000019_A_Init(); t := &A_arbace_classes_parse_expand_members_expand__662000019_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) Ctor_O(c__ns any) { t.F_ns = c__ns }
//line :41:1
func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) Invoke_O_O__O(self, f__1 any) any {
	var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_14; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_36; if jrt.A2g_Truth(tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(f__1))) { var tmp4 *lang.Var; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_28; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_131, nil); var tmp7 *lang.Var; A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_37; var tmp8 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp6, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var tmp9 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp9 = A_arbace_classes_parse_A_const_38; panic(jrt.Thrown(jrt.Throwable_Cast(tmp5.Invoke_O_O__O(tmp8, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp9.Ref(), f__1)))))) } else { var tmp10 any; A_arbace_classes_parse_A_Init(); tmp10 = A_arbace_classes_parse_A_const_29; var tmp11 any = tmp10; var tmp12 *lang.Var; A_arbace_classes_parse_A_Init(); tmp12 = A_arbace_classes_parse_A_const_23; if lang.Util_Equiv_O_O__Z(tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(f__1)) {

		var tmp13 *lang.Var; A_arbace_classes_parse_A_Init(); tmp13 = A_arbace_classes_parse_A_const_27; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_classes_parse_A_Init(); tmp15 = A_arbace_classes_parse_A_const_39; return tmp14.Invoke_O_O__O(self, lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(f__1)) } else {
//line :42:1
			var tmp16 *lang.Var; A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_30; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_classes_parse_A_Init(); tmp18 = A_arbace_classes_parse_A_const_23; if jrt.A2g_Truth(tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(f__1))) { return lang.Tuple_Create_O__IPersistentVector(f__1) } else { var tmp19 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp19 = A_arbace_classes_parse_A_const_19; if tmp19 != nil { var v__2 any; var and__1927000168__auto____2 any; var tmp20 *lang.Var




				A_arbace_classes_parse_A_Init(); tmp20 = A_arbace_classes_parse_A_const_31; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_classes_parse_A_Init(); tmp22 = A_arbace_classes_parse_A_const_23; and__1927000168__auto____2 = tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(f__1)); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp23 *lang.Var; A_arbace_classes_parse_A_Init(); tmp23 = A_arbace_classes_parse_A_const_40; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_classes_parse_A_Init(); tmp25 = A_arbace_classes_parse_A_const_41; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Var; A_arbace_classes_parse_A_Init(); tmp27 = A_arbace_classes_parse_A_const_42; tmp24.Invoke_O__O(tmp26.Invoke_O_O__O(tmp27.Ref(), t.F_ns)); var tmp28 any = A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_New_O(f__1); var tmp29 *jrt.Class; A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_Init(); tmp29 = A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_fn_class; v__2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil).Invoke__O() } else { v__2 = and__1927000168__auto____2 }
				var tmp30 any; var and__1927000168__auto____3 any; var tmp31 *lang.Var; A_arbace_classes_parse_A_Init(); tmp31 = A_arbace_classes_parse_A_const_34; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(v__2); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp32 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp32 = A_arbace_classes_parse_A_const_35; var tmp33 *lang.Keyword = tmp32; tmp30 = jrt.NN(tmp33).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(v__2)) } else { tmp30 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp30) {
					var tmp34 lang.IFn = lang.IFn_Cast(self); var tmp35 *lang.Var; A_arbace_classes_parse_A_Init(); tmp35 = A_arbace_classes_parse_A_const_43; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_classes_parse_A_Init(); tmp37 = A_arbace_classes_parse_A_const_6; var tmp38 any = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(v__2); var tmp39 *lang.Var; A_arbace_classes_parse_A_Init(); tmp39 = A_arbace_classes_parse_A_const_39; return tmp34.Invoke_O__O(tmp36.Invoke_O_O_O_O__O(tmp38, f__1, nil, lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(f__1))) } else {
//line :48:1
						var tmp40 *lang.Var; A_arbace_classes_parse_A_Init(); tmp40 = A_arbace_classes_parse_A_const_28; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_131, nil); var tmp43 *lang.Var; A_arbace_classes_parse_A_Init(); tmp43 = A_arbace_classes_parse_A_const_37; var tmp44 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp42, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(f__1))).Ref(); var tmp45 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp45 = A_arbace_classes_parse_A_const_38; panic(jrt.Thrown(jrt.Throwable_Cast(tmp41.Invoke_O_O__O(tmp44, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp45.Ref(), f__1)))))) } } else {
//line :42:1
							return nil
						}
			}
		}
	} }
func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_New_O(p0 any) *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A { A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_Init(); t := &A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A{}; t.Ctor_O(p0); return t }
//line :47:1
func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) Ctor_O(c__f any) { t.F_f = c__f }
//line :47:1
func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) Invoke_O__O(self any) any { var tmp1 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_32; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_23; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; var t_ any = t.F_f; t.F_f = nil; tmp6 = t_; tmp1 = tmp3.Invoke_O__O(tmp5.Invoke_O__O(tmp6)) }; return nil }(); var tmp8 *lang.Var; A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_33; lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke__O(); if tmp7 != nil { panic(tmp7) }; return tmp1 }







func A_arbace_classes_parse_parse_params_A_New() *A_arbace_classes_parse_parse_params_A { A_arbace_classes_parse_parse_params_A_Init(); t := &A_arbace_classes_parse_parse_params_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_classes_parse_parse_params_A) Ctor() {}
//line :55:1
func (t *A_arbace_classes_parse_parse_params_A) Invoke_O_O__O(self, v__0 any) any {
	var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_49; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__0)) { } else { var tmp2 *lang.Var; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_28; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_150, nil); var tmp5 *lang.Var; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_37; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(v__0))).Ref(); var tmp7 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_38; panic(jrt.Thrown(jrt.Throwable_Cast(tmp3.Invoke_O_O__O(tmp6, lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7.Ref(), v__0)))))) }
//line :55:1
	var vec__662000025__2 any; var tmp8 *lang.Var

	A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_44; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 any = A_arbace_classes_parse_parse_params_fn__662000031_A_New(); var tmp11 *jrt.Class; A_arbace_classes_parse_parse_params_fn__662000031_A_Init(); tmp11 = A_arbace_classes_parse_parse_params_fn__662000031_A_fn_class; vec__662000025__2 = tmp9.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil), v__0)
//line :55:1
	var fixed__3 any = lang.RT_Nth_O_I_O__O(vec__662000025__2, lang.RT_IntCast_J__I(0), nil); var vec__662000028__4 any = lang.RT_Nth_O_I_O__O(vec__662000025__2, lang.RT_IntCast_J__I(1), nil); var ___5 any = lang.RT_Nth_O_I_O__O(vec__662000028__4, lang.RT_IntCast_J__I(0), nil); var rest_param__6 any = lang.RT_Nth_O_I_O__O(vec__662000028__4, lang.RT_IntCast_J__I(1), nil); var tmp12 *lang.Keyword; _ = ___5; A_arbace_classes_parse_A_Init(); tmp12 = A_arbace_classes_parse_A_const_45; var tmp13 any = tmp12.Ref(); var tmp14 *lang.Var; A_arbace_classes_parse_A_Init(); tmp14 = A_arbace_classes_parse_A_const_46; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_52; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 lang.IPersistentVector


	if jrt.A2g_Truth(rest_param__6) { tmp18 = lang.Tuple_Create_O__IPersistentVector(rest_param__6) } else { tmp18 = nil }
//line :55:1
	var tmp19 any = tmp15.Invoke_O__O(tmp17.Invoke_O_O__O(fixed__3, tmp18)); var tmp20 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp20 = A_arbace_classes_parse_A_const_47; var tmp21 any = tmp20.Ref(); var tmp22 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(rest_param__6)).Ref(); var tmp23 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp23 = A_arbace_classes_parse_A_const_48; var tmp24 any = tmp23.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp19, tmp21, tmp22, tmp24, lang.RT_Meta_O__IPersistentMap(v__0)))
}
func A_arbace_classes_parse_parse_params_fn__662000031_A_New() *A_arbace_classes_parse_parse_params_fn__662000031_A { A_arbace_classes_parse_parse_params_fn__662000031_A_Init(); t := &A_arbace_classes_parse_parse_params_fn__662000031_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) Ctor() {}
//line :57:1
func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) Invoke_O_O__O(self, p1__662000024_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_50; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_51; return tmp2.Invoke_O_O__O(tmp3, p1__662000024_SHARP___1) }






func A_arbace_classes_parse_parse_member_A_New() *A_arbace_classes_parse_parse_member_A { A_arbace_classes_parse_parse_member_A_Init(); t := &A_arbace_classes_parse_parse_member_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_classes_parse_parse_member_A) Ctor() {}
//line :64:1
func (t *A_arbace_classes_parse_parse_member_A) Invoke_O_O_O__O(self, ns__0, f__1 any) any { var G__662000034__3_ any; var tmp1 *lang.Var;


	A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_25; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_54; var tmp4 any = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(ns__0, f__1); var tmp5 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_55; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Var; A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_56; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_classes_parse_A_Init(); tmp9 = A_arbace_classes_parse_A_const_57; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_classes_parse_A_Init(); tmp11 = A_arbace_classes_parse_A_const_58; G__662000034__3_ = tmp2.Invoke_O_O_O__O(tmp4, tmp6, tmp8.Invoke_O_O__O(tmp10, jrt.NN(tmp11).GetRawRoot__O())); var tmp12 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp12 = A_arbace_classes_parse_A_const_53; var tmp13 *lang.Keyword = tmp12; if jrt.A2g_Truth(jrt.NN(tmp13).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__1))) {
		var tmp14 *lang.Var; A_arbace_classes_parse_A_Init(); tmp14 = A_arbace_classes_parse_A_const_25; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_53; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp18 = A_arbace_classes_parse_A_const_53; var tmp19 *lang.Keyword = tmp18; return tmp15.Invoke_O_O_O__O(G__662000034__3_, tmp17, jrt.NN(tmp19).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(f__1))) } else {
//line :67:1
			return G__662000034__3_ } }


func A_arbace_classes_parse_parse_member_STAR__A_New() *A_arbace_classes_parse_parse_member_STAR__A { A_arbace_classes_parse_parse_member_STAR__A_Init(); t := &A_arbace_classes_parse_parse_member_STAR__A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_classes_parse_parse_member_STAR__A) Ctor() {}
//line :70:1
func (t *A_arbace_classes_parse_parse_member_STAR__A) Invoke_O_O_O__O(self, ns__0, f__1 any) any { var G__662000036__3_ any; var tmp1 *lang.Var;
													A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_23; G__662000036__3_ = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(f__1); switch lang.Util_Hash_O__I(G__662000036__3_) >> 24 & 7 { case 0: var tmp2 any; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_59; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp2) { var vec__662000037__4 any = f__1; var seq__662000038__5 any; var tmp3 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_60; seq__662000038__5 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(vec__662000037__4)
//line :71:1
		var first__662000039__6 any; var tmp4 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_23; first__662000039__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(seq__662000038__5)
//line :71:1
		var seq__662000038__7 any; var tmp5 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_22; seq__662000038__7 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq__662000038__5)
//line :71:1
		var ___8 any = first__662000039__6; var first__662000039__9 any; var tmp6 *lang.Var; _ = ___8



		A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_23; first__662000039__9 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq__662000038__7)
//line :71:1
		var seq__662000038__10 any; var tmp7 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_22; seq__662000038__10 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq__662000038__7)
//line :71:1
		var nm__11 any = first__662000039__9; var more__12 any = seq__662000038__10; var vec__662000040__13 any; var tmp8 *lang.Var




		A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_61; vec__662000040__13 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(more__12)
//line :71:1
		var opts__14 any = lang.RT_Nth_O_I_O__O(vec__662000040__13, lang.RT_IntCast_J__I(0), nil); var more__15 any = lang.RT_Nth_O_I_O__O(vec__662000040__13, lang.RT_IntCast_J__I(1), nil); var vec__662000043__16 any = more__15; var seq__662000044__17 any; var tmp9 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp9 = A_arbace_classes_parse_A_const_60; seq__662000044__17 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(vec__662000043__16)
//line :71:1
		var first__662000045__18 any; var tmp10 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp10 = A_arbace_classes_parse_A_const_23; first__662000045__18 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq__662000044__17)
//line :71:1
		var seq__662000044__19 any; var tmp11 *lang.Var



		A_arbace_classes_parse_A_Init(); tmp11 = A_arbace_classes_parse_A_const_22; seq__662000044__19 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq__662000044__17)
//line :71:1
		var pv__20 any = first__662000045__18; var body__21 any = seq__662000044__19; var tmp12 *lang.Var






		A_arbace_classes_parse_A_Init(); tmp12 = A_arbace_classes_parse_A_const_62; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp14 = A_arbace_classes_parse_A_const_64; var tmp15 any = tmp14.Ref(); var tmp16 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_70; var tmp17 any = tmp16.Ref(); var tmp18 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp18 = A_arbace_classes_parse_A_const_71; var tmp19 any = tmp18.Ref(); var tmp20 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp20 = A_arbace_classes_parse_A_const_72; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Var; A_arbace_classes_parse_A_Init(); tmp22 = A_arbace_classes_parse_A_const_73; var tmp23 any = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(nm__11); var tmp24 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp24 = A_arbace_classes_parse_A_const_74; var tmp25 any = tmp24.Ref(); var tmp26 any = lang.RT_Meta_O__IPersistentMap(nm__11); var tmp27 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp27 = A_arbace_classes_parse_A_const_75; var tmp28 any = tmp27.Ref(); var tmp29 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp29 = A_arbace_classes_parse_A_const_76; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp31 = A_arbace_classes_parse_A_const_77; var tmp32 any = tmp31.Ref(); var tmp33 *lang.Var; A_arbace_classes_parse_A_Init(); tmp33 = A_arbace_classes_parse_A_const_60; var tmp34 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp15, tmp17, tmp19, nm__11, tmp21, tmp23, tmp25, tmp26, tmp28, opts__14, tmp30, body__21, tmp32, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(body__21))).Ref())); var tmp35 *lang.Var; A_arbace_classes_parse_A_Init(); tmp35 = A_arbace_classes_parse_A_const_66; return tmp13.Invoke_O_O__O(tmp34, lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(pv__20)) }
//line :71:1
	case 1: var tmp36 any; A_arbace_classes_parse_A_Init(); tmp36 = A_arbace_classes_parse_A_const_63; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp36) { var tmp37 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp37 = A_arbace_classes_parse_A_const_64; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp39 = A_arbace_classes_parse_A_const_20; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp41 = A_arbace_classes_parse_A_const_38; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp38, tmp40, tmp41.Ref(), f__1)) }; case 2: var tmp42 any; A_arbace_classes_parse_A_Init(); tmp42 = A_arbace_classes_parse_A_const_65; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp42) { var vec__662000046__4 any = f__1; var seq__662000047__5 any; var tmp43 *lang.Var









		A_arbace_classes_parse_A_Init(); tmp43 = A_arbace_classes_parse_A_const_60; seq__662000047__5 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(vec__662000046__4)
//line :71:1
		var first__662000048__6 any; var tmp44 *lang.Var









		A_arbace_classes_parse_A_Init(); tmp44 = A_arbace_classes_parse_A_const_23; first__662000048__6 = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()).Invoke_O__O(seq__662000047__5)
//line :71:1
		var seq__662000047__7 any; var tmp45 *lang.Var









		A_arbace_classes_parse_A_Init(); tmp45 = A_arbace_classes_parse_A_const_22; seq__662000047__7 = lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(seq__662000047__5)
//line :71:1
		var ___8_2 any = first__662000048__6; var more__9 any = seq__662000047__7; var vec__662000049__10 any; var tmp46 *lang.Var; _ = ___8_2










		A_arbace_classes_parse_A_Init(); tmp46 = A_arbace_classes_parse_A_const_61; vec__662000049__10 = lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(more__9)
//line :71:1
		var opts__11 any = lang.RT_Nth_O_I_O__O(vec__662000049__10, lang.RT_IntCast_J__I(0), nil); var more__12_2 any = lang.RT_Nth_O_I_O__O(vec__662000049__10, lang.RT_IntCast_J__I(1), nil); var vec__662000052__13 any = more__12_2; var seq__662000053__14 any; var tmp47 *lang.Var









		A_arbace_classes_parse_A_Init(); tmp47 = A_arbace_classes_parse_A_const_60; seq__662000053__14 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(vec__662000052__13)
//line :71:1
		var first__662000054__15 any; var tmp48 *lang.Var









		A_arbace_classes_parse_A_Init(); tmp48 = A_arbace_classes_parse_A_const_23; first__662000054__15 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(seq__662000053__14)
//line :71:1
		var seq__662000053__16 any; var tmp49 *lang.Var









		A_arbace_classes_parse_A_Init(); tmp49 = A_arbace_classes_parse_A_const_22; seq__662000053__16 = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(seq__662000053__14)
//line :71:1
		var pv__17 any = first__662000054__15; var body__18 any = seq__662000053__16; var pp__19 any; var tmp50 *lang.Var












		A_arbace_classes_parse_A_Init(); tmp50 = A_arbace_classes_parse_A_const_66; pp__19 = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(pv__17)
		var tmp51 *lang.Var; A_arbace_classes_parse_A_Init(); tmp51 = A_arbace_classes_parse_A_const_62; var tmp52 lang.IFn = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()); var tmp53 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp53 = A_arbace_classes_parse_A_const_64; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp55 = A_arbace_classes_parse_A_const_78; var tmp56 any = tmp55.Ref(); var tmp57 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp57 = A_arbace_classes_parse_A_const_72; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp59 = A_arbace_classes_parse_A_const_75; var tmp60 any = tmp59.Ref(); var tmp61 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp61 = A_arbace_classes_parse_A_const_76; return tmp52.Invoke_O_O__O(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp54, tmp56, tmp58, Lit_146, tmp60, opts__11, tmp61.Ref(), body__18)), pp__19) }
//line :71:1
	case 3: var tmp62 any; A_arbace_classes_parse_A_Init(); tmp62 = A_arbace_classes_parse_A_const_67; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp62) { var tmp63 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp63 = A_arbace_classes_parse_A_const_64; var tmp64 any = tmp63.Ref(); var tmp65 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp65 = A_arbace_classes_parse_A_const_68; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp67 = A_arbace_classes_parse_A_const_68; var tmp68 any = tmp67.Ref(); var tmp69 *lang.Var; A_arbace_classes_parse_A_Init(); tmp69 = A_arbace_classes_parse_A_const_69; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 any = A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_New(); var tmp72 *jrt.Class; A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_Init(); tmp72 = A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_fn_class; var tmp73 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp71, tmp72, nil); var tmp74 *lang.Var; A_arbace_classes_parse_A_Init(); tmp74 = A_arbace_classes_parse_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp64, tmp66, tmp68, tmp70.Invoke_O_O__O(tmp73, lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()).Invoke_O__O(f__1)))) }; case 5: var tmp75 any; A_arbace_classes_parse_A_Init(); tmp75 = A_arbace_classes_parse_A_const_79; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp75) { var tmp76 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp76 = A_arbace_classes_parse_A_const_64; var tmp77 any = tmp76.Ref(); var tmp78 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp78 = A_arbace_classes_parse_A_const_80; var tmp79 any = tmp78.Ref(); var tmp80 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp80 = A_arbace_classes_parse_A_const_76; var tmp81 any = tmp80.Ref(); var tmp82 *lang.Var; A_arbace_classes_parse_A_Init(); tmp82 = A_arbace_classes_parse_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp77, tmp79, tmp81, lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(f__1))) }; case 6: var tmp83 any; A_arbace_classes_parse_A_Init(); tmp83 = A_arbace_classes_parse_A_const_84; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp83) { var vec__662000060__4 any = f__1; var seq__662000061__5 any; var tmp84 *lang.Var
		A_arbace_classes_parse_A_Init(); tmp84 = A_arbace_classes_parse_A_const_60; seq__662000061__5 = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke_O__O(vec__662000060__4)
//line :71:1
		var first__662000062__6 any; var tmp85 *lang.Var
		A_arbace_classes_parse_A_Init(); tmp85 = A_arbace_classes_parse_A_const_23; first__662000062__6 = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()).Invoke_O__O(seq__662000061__5)
//line :71:1
		var seq__662000061__7 any; var tmp86 *lang.Var
		A_arbace_classes_parse_A_Init(); tmp86 = A_arbace_classes_parse_A_const_22; seq__662000061__7 = lang.IFn_Cast(jrt.NN(tmp86).GetRawRoot__O()).Invoke_O__O(seq__662000061__5)
//line :71:1
		var ___8_3 any = first__662000062__6; var first__662000062__9 any; var tmp87 *lang.Var; _ = ___8_3
		A_arbace_classes_parse_A_Init(); tmp87 = A_arbace_classes_parse_A_const_23; first__662000062__9 = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()).Invoke_O__O(seq__662000061__7)
//line :71:1
		var seq__662000061__10 any; var tmp88 *lang.Var
		A_arbace_classes_parse_A_Init(); tmp88 = A_arbace_classes_parse_A_const_22; seq__662000061__10 = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()).Invoke_O__O(seq__662000061__7)
//line :71:1
		var nm__11_2 any = first__662000062__9; var init__12 any = seq__662000061__10; var tmp89 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp89 = A_arbace_classes_parse_A_const_64; var tmp90 any = tmp89.Ref(); var tmp91 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp91 = A_arbace_classes_parse_A_const_85; var tmp92 any = tmp91.Ref(); var tmp93 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp93 = A_arbace_classes_parse_A_const_71; var tmp94 any = tmp93.Ref(); var tmp95 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp95 = A_arbace_classes_parse_A_const_72; var tmp96 any = tmp95.Ref(); var tmp97 *lang.Var; A_arbace_classes_parse_A_Init(); tmp97 = A_arbace_classes_parse_A_const_73; var tmp98 any = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()).Invoke_O__O(nm__11_2); var tmp99 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp99 = A_arbace_classes_parse_A_const_74; var tmp100 any = tmp99.Ref(); var tmp101 any = lang.RT_Meta_O__IPersistentMap(nm__11_2); var tmp102 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp102 = A_arbace_classes_parse_A_const_86; var tmp103 any = tmp102.Ref(); var tmp104 *lang.Var; A_arbace_classes_parse_A_Init(); tmp104 = A_arbace_classes_parse_A_const_60; var tmp105 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()).Invoke_O__O(init__12))).Ref(); var tmp106 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp106 = A_arbace_classes_parse_A_const_80; var tmp107 any = tmp106.Ref(); var tmp108 *lang.Var; A_arbace_classes_parse_A_Init(); tmp108 = A_arbace_classes_parse_A_const_23; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp90, tmp92, tmp94, nm__11_2, tmp96, tmp98, tmp100, tmp101, tmp103, tmp105, tmp107, lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()).Invoke_O__O(init__12))) }; case 7: var tmp109 any; A_arbace_classes_parse_A_Init(); tmp109 = A_arbace_classes_parse_A_const_87; if lang.Util_Equiv_O_O__Z(G__662000036__3_, tmp109) { var tmp110 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp110 = A_arbace_classes_parse_A_const_64; var tmp111 any = tmp110.Ref(); var tmp112 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp112 = A_arbace_classes_parse_A_const_88; var tmp113 any = tmp112.Ref(); var tmp114 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp114 = A_arbace_classes_parse_A_const_76; var tmp115 any = tmp114.Ref(); var tmp116 *lang.Var; A_arbace_classes_parse_A_Init(); tmp116 = A_arbace_classes_parse_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp111, tmp113, tmp115, lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()).Invoke_O__O(f__1))) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_147, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__662000036__3_))))) }

















func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_New() *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A { A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_Init(); t := &A_arbace_classes_parse_parse_member_STAR__fn__662000055_A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) Ctor() {}
//line :89:1
func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) Invoke_O_O__O(self, c__1 any) any {
	var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__1)) { var tmp2 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_71; var tmp3 any = tmp2.Ref(); var tmp4 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_72; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Var; A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_73; var tmp7 any = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(c__1); var tmp8 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_74; var tmp9 any = tmp8.Ref(); var tmp10 any = lang.RT_Meta_O__IPersistentMap(c__1); var tmp11 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp11 = A_arbace_classes_parse_A_const_81; var tmp12 any = tmp11.Ref(); var tmp13 *lang.PersistentVector; lang.PersistentVector_Init(); tmp13 = lang.PersistentVector_EMPTY; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, c__1, tmp5, tmp7, tmp9, tmp10, tmp12, tmp13.Ref())) } else { var vec__662000056__2 any = c__1; var seq__662000057__3 any; var tmp14 *lang.Var

		A_arbace_classes_parse_A_Init(); tmp14 = A_arbace_classes_parse_A_const_60; seq__662000057__3 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(vec__662000056__2)
//line :90:1
		var first__662000058__4 any; var tmp15 *lang.Var

		A_arbace_classes_parse_A_Init(); tmp15 = A_arbace_classes_parse_A_const_23; first__662000058__4 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq__662000057__3)
//line :90:1
		var seq__662000057__5 any; var tmp16 *lang.Var

		A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_22; seq__662000057__5 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(seq__662000057__3)
//line :90:1
		var nm__6 any = first__662000058__4; var first__662000058__7 any; var tmp17 *lang.Var

		A_arbace_classes_parse_A_Init(); tmp17 = A_arbace_classes_parse_A_const_23; first__662000058__7 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(seq__662000057__5)
//line :90:1
		var seq__662000057__8 any; var tmp18 *lang.Var

		A_arbace_classes_parse_A_Init(); tmp18 = A_arbace_classes_parse_A_const_22; seq__662000057__8 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq__662000057__5)
//line :90:1
		var args__9 any = first__662000058__7; var body__10 any = seq__662000057__8; var tmp19 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp19 = A_arbace_classes_parse_A_const_71; var tmp20 any = tmp19.Ref(); var tmp21 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp21 = A_arbace_classes_parse_A_const_72; var tmp22 any = tmp21.Ref(); var tmp23 *lang.Var; A_arbace_classes_parse_A_Init(); tmp23 = A_arbace_classes_parse_A_const_73; var tmp24 any = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(nm__6); var tmp25 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp25 = A_arbace_classes_parse_A_const_74; var tmp26 any = tmp25.Ref(); var tmp27 any = lang.RT_Meta_O__IPersistentMap(nm__6); var tmp28 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp28 = A_arbace_classes_parse_A_const_81; var tmp29 any = tmp28.Ref(); var tmp30 *lang.Var; A_arbace_classes_parse_A_Init(); tmp30 = A_arbace_classes_parse_A_const_46; var tmp31 any = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(args__9); var tmp32 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp32 = A_arbace_classes_parse_A_const_82; var tmp33 any = tmp32.Ref(); var tmp34 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp34 = A_arbace_classes_parse_A_const_82; var tmp35 *lang.Keyword = tmp34; var tmp36 any = jrt.NN(tmp35).Invoke_O__O(lang.RT_Meta_O__IPersistentMap(args__9)); var tmp37 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp37 = A_arbace_classes_parse_A_const_76; var tmp38 any = tmp37.Ref(); var tmp39 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp39 = A_arbace_classes_parse_A_const_77; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Var; A_arbace_classes_parse_A_Init(); tmp41 = A_arbace_classes_parse_A_const_83; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp20, nm__6, tmp22, tmp24, tmp26, tmp27, tmp29, tmp31, tmp33, tmp36, tmp38, body__10, tmp40, lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(body__10)))
	}
}






func A_arbace_classes_parse_interface_like_QMARK__A_New() *A_arbace_classes_parse_interface_like_QMARK__A { A_arbace_classes_parse_interface_like_QMARK__A_Init(); t := &A_arbace_classes_parse_interface_like_QMARK__A{}; t.Ctor(); return t }
//line :99:1
func (t *A_arbace_classes_parse_interface_like_QMARK__A) Ctor() {}
//line :99:1
func (t *A_arbace_classes_parse_interface_like_QMARK__A) Invoke_O_O__O(self, kind__0 any) any { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_89; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_90; return tmp2.Invoke_O_O__O(tmp3, kind__0) }

func A_arbace_classes_parse_class_flags_A_New() *A_arbace_classes_parse_class_flags_A { A_arbace_classes_parse_class_flags_A_Init(); t := &A_arbace_classes_parse_class_flags_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_classes_parse_class_flags_A) Ctor() {}
//line :101:1
func (t *A_arbace_classes_parse_class_flags_A) Invoke_O_O__O(self, p__662000066__0 any) any { var map__662000067__2 any = p__662000066__0; var map__662000067__3 any; if lang.ISeq_InstanceOf(map__662000067__2) { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__662000067__2)) { var tmp2 *lang.Var; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_91; map__662000067__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__662000067__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_60; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__662000067__2)) { var tmp4 *lang.Var; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_23; map__662000067__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__662000067__2) } else { lang.PersistentArrayMap_Init(); map__662000067__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__662000067__3 = map__662000067__2 }; var decl__4 any = map__662000067__3; var kind__5 any; var tmp5 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_64; kind__5 = lang.RT_Get_O_O__O(map__662000067__3, tmp5.Ref()); var meta__6 any; var tmp6 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_74; meta__6 = lang.RT_Get_O_O__O(map__662000067__3, tmp6.Ref()); var nesting__7 any; var tmp7 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp7 = A_arbace_classes_parse_A_const_92; nesting__7 = lang.RT_Get_O_O__O(map__662000067__3, tmp7.Ref()); var outer_kind__8 any; var tmp8 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_93; outer_kind__8 = lang.RT_Get_O_O__O(map__662000067__3, tmp8.Ref()); var constants__9 any; var tmp9 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp9 = A_arbace_classes_parse_A_const_68; constants__9 = lang.RT_Get_O_O__O(map__662000067__3, tmp9.Ref()); var members__10 any; var tmp10 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp10 = A_arbace_classes_parse_A_const_94; members__10 = lang.RT_Get_O_O__O(map__662000067__3, tmp10.Ref()); var m__11 any = meta__6; var member_QMARK___12 bool; var tmp11 *lang.Keyword;



	A_arbace_classes_parse_A_Init(); tmp11 = A_arbace_classes_parse_A_const_95; member_QMARK___12 = lang.Util_Equiv_O_O__Z(nesting__7, tmp11.Ref()); var in_interface_QMARK___13 any; var tmp12 /*line :101:1*/*lang.Var;




	A_arbace_classes_parse_A_Init(); tmp12 = A_arbace_classes_parse_A_const_96; in_interface_QMARK___13 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(outer_kind__8); var acc__14 any; var tmp13 any; var and__1927000168__auto____14 bool = member_QMARK___12; if and__1927000168__auto____14 {

		tmp13 = in_interface_QMARK___13 } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() }; if /*line :107:1*/ jrt.A2g_Truth(tmp13) { A_arbace_classes_parse_A_Init(); acc__14 = A_arbace_classes_parse_A_const_97 } else { var tmp14 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp14 = A_arbace_classes_parse_A_const_98; if jrt.A2g_Truth(jrt.NN(tmp14).Invoke_O__O(m__11)) { A_arbace_classes_parse_A_Init(); acc__14 = A_arbace_classes_parse_A_const_97 } else { var tmp15 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp15 = A_arbace_classes_parse_A_const_99; if jrt.A2g_Truth(jrt.NN(tmp15).Invoke_O__O(m__11)) { A_arbace_classes_parse_A_Init(); acc__14 = A_arbace_classes_parse_A_const_100 } else { var tmp16 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_101; if jrt.A2g_Truth(jrt.NN(tmp16).Invoke_O__O(m__11)) { A_arbace_classes_parse_A_Init(); acc__14 = A_arbace_classes_parse_A_const_102 } else { var tmp17 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp17 = A_arbace_classes_parse_A_const_19; if tmp17 != nil { A_arbace_classes_parse_A_Init(); acc__14 = A_arbace_classes_parse_A_const_12 } else { acc__14 = nil } } } } }; var static_QMARK___15 any; var or__1927000174__auto____15 any; var tmp18 /*line :101:1*/*lang.Keyword;











	A_arbace_classes_parse_A_Init(); tmp18 = A_arbace_classes_parse_A_const_103; or__1927000174__auto____15 = jrt.NN(tmp18).Invoke_O__O(m__11); if jrt.A2g_Truth(or__1927000174__auto____15) { static_QMARK___15 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any; var and__1927000168__auto____16 bool = member_QMARK___12
		if and__1927000168__auto____16 { var or__1927000174__auto____17 any = in_interface_QMARK___13; if jrt.A2g_Truth(or__1927000174__auto____17) { or__1927000174__auto____16 = or__1927000174__auto____17 } else { var tmp19 *lang.Var; A_arbace_classes_parse_A_Init(); tmp19 = A_arbace_classes_parse_A_const_50; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp21 = A_arbace_classes_parse_A_const_20; or__1927000174__auto____16 = tmp20.Invoke_O_O__O(kind__5, tmp21.Ref()) } } else { or__1927000174__auto____16 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____16).Ref() }
//line :113:1
		if jrt.A2g_Truth(or__1927000174__auto____16) { static_QMARK___15 = or__1927000174__auto____16 } else { var and__1927000168__auto____17 bool; var tmp22 *lang.Keyword

			A_arbace_classes_parse_A_Init(); tmp22 = A_arbace_classes_parse_A_const_104; and__1927000168__auto____17 = lang.Util_Equiv_O_O__Z(nesting__7, tmp22.Ref()); if and__1927000168__auto____17 { var tmp23 *lang.Var; A_arbace_classes_parse_A_Init(); tmp23 = A_arbace_classes_parse_A_const_50; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp25 = A_arbace_classes_parse_A_const_20; static_QMARK___15 = tmp24.Invoke_O_O__O(kind__5, tmp25.Ref()) } else { static_QMARK___15 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____17).Ref() } } }; var enum_bodies_QMARK___16 any; var tmp26 /*line :101:1*/*lang.Var;














	A_arbace_classes_parse_A_Init(); tmp26 = A_arbace_classes_parse_A_const_105; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp28 = A_arbace_classes_parse_A_const_77; enum_bodies_QMARK___16 = tmp27.Invoke_O_O__O(tmp28.Ref(), constants__9); var enum_abstract_QMARK___17 any; var and__1927000168__auto____17_2 bool; var tmp29 /*line :101:1*/*lang.Keyword;















	A_arbace_classes_parse_A_Init(); tmp29 = A_arbace_classes_parse_A_const_16; and__1927000168__auto____17_2 = lang.Util_Equiv_O_O__Z(kind__5, tmp29.Ref()); if and__1927000168__auto____17_2 {
		var tmp30 *lang.Var; A_arbace_classes_parse_A_Init(); tmp30 = A_arbace_classes_parse_A_const_105; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 any = A_arbace_classes_parse_class_flags_fn__662000069_A_New(); var tmp33 *jrt.Class; A_arbace_classes_parse_class_flags_fn__662000069_A_Init(); tmp33 = A_arbace_classes_parse_class_flags_fn__662000069_A_fn_class; enum_abstract_QMARK___17 = tmp31.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp32, tmp33, nil), members__10) } else {
//line :117:1
			enum_abstract_QMARK___17 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____17_2).Ref() }; var enum_body_QMARK___18 any; var tmp34 /*line :101:1*/*lang.Keyword;

















	A_arbace_classes_parse_A_Init(); tmp34 = A_arbace_classes_parse_A_const_106; enum_body_QMARK___18 = jrt.NN(tmp34).Invoke_O__O(decl__4); var final_QMARK___19 any; var or__1927000174__auto____19 any; var tmp35 /*line :101:1*/*lang.Keyword;


















	A_arbace_classes_parse_A_Init(); tmp35 = A_arbace_classes_parse_A_const_107; or__1927000174__auto____19 = jrt.NN(tmp35).Invoke_O__O(m__11); if jrt.A2g_Truth(or__1927000174__auto____19) { final_QMARK___19 = or__1927000174__auto____19 } else { var or__1927000174__auto____20 bool; var tmp36 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp36 = A_arbace_classes_parse_A_const_17; or__1927000174__auto____20 = lang.Util_Equiv_O_O__Z(kind__5, tmp36.Ref()); if or__1927000174__auto____20 { final_QMARK___19 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____20).Ref() } else { var or__1927000174__auto____21 any = enum_body_QMARK___18; if jrt.A2g_Truth(or__1927000174__auto____21) { final_QMARK___19 = or__1927000174__auto____21 } else { var and__1927000168__auto____22 bool; var tmp37 *lang.Keyword
		A_arbace_classes_parse_A_Init(); tmp37 = A_arbace_classes_parse_A_const_16; and__1927000168__auto____22 = lang.Util_Equiv_O_O__Z(kind__5, tmp37.Ref()); if and__1927000168__auto____22 { var tmp38 *lang.Var; A_arbace_classes_parse_A_Init(); tmp38 = A_arbace_classes_parse_A_const_14; final_QMARK___19 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(enum_bodies_QMARK___16) } else { final_QMARK___19 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____22).Ref() } } } }; var abstract_QMARK___20 any; var or__1927000174__auto____20_2 any; var tmp39 /*line :101:1*/*lang.Keyword;




















	A_arbace_classes_parse_A_Init(); tmp39 = A_arbace_classes_parse_A_const_108; or__1927000174__auto____20_2 = jrt.NN(tmp39).Invoke_O__O(m__11); if jrt.A2g_Truth(or__1927000174__auto____20_2) { abstract_QMARK___20 = or__1927000174__auto____20_2 } else { var or__1927000174__auto____21_2 any; var tmp40 *lang.Var; A_arbace_classes_parse_A_Init(); tmp40 = A_arbace_classes_parse_A_const_96; or__1927000174__auto____21_2 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(kind__5); if jrt.A2g_Truth(or__1927000174__auto____21_2) { abstract_QMARK___20 = or__1927000174__auto____21_2 } else { var and__1927000168__auto____22_2 any = enum_abstract_QMARK___17; if jrt.A2g_Truth(and__1927000168__auto____22_2) { abstract_QMARK___20 = enum_bodies_QMARK___16 } else { abstract_QMARK___20 = and__1927000168__auto____22_2 } } }; var base__21 int64; var tmp41 int64; if
	jrt.A2g_Truth(final_QMARK___19) { tmp41 = 16 } else { tmp41 = 0 }; var tmp42 int64 = tmp41; var tmp43 int64; if
	jrt.A2g_Truth(abstract_QMARK___20) { tmp43 = 1024 } else { tmp43 = 0 }; var tmp44 int64 = /*line :123:1*/lang.Numbers_Or_J_J__J(tmp42, tmp43); var tmp45 int64; var tmp46 *lang.Var;

	A_arbace_classes_parse_A_Init(); tmp46 = A_arbace_classes_parse_A_const_96; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(kind__5)) { tmp45 = 512 } else { tmp45 = 0 }; var tmp47 int64 = /*line :123:1*/lang.Numbers_Or_J_J__J(tmp44, tmp45); var tmp48 int64; var tmp49 *lang.Keyword;


	A_arbace_classes_parse_A_Init(); tmp49 = A_arbace_classes_parse_A_const_18; if lang.Util_Equiv_O_O__Z(kind__5, tmp49.Ref()) { tmp48 = 8192 } else { tmp48 = 0 }; var tmp50 int64 = /*line :123:1*/lang.Numbers_Or_J_J__J(tmp47, tmp48); var tmp51 int64; var tmp52 any; var or__1927000174__auto____21_3 bool; var tmp53 *lang.Keyword;



	A_arbace_classes_parse_A_Init(); tmp53 = A_arbace_classes_parse_A_const_16; or__1927000174__auto____21_3 = lang.Util_Equiv_O_O__Z(kind__5, tmp53.Ref()); if or__1927000174__auto____21_3 { tmp52 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____21_3).Ref() } else { tmp52 = enum_body_QMARK___18 }; if jrt.A2g_Truth(tmp52) { tmp51 = 16384 } else { tmp51 = 0 }; var tmp54 int64 = /*line :123:1*/lang.Numbers_Or_J_J__J(tmp50, tmp51); var tmp55 int64; var tmp56 *lang.Keyword;




	A_arbace_classes_parse_A_Init(); tmp56 = A_arbace_classes_parse_A_const_109; if jrt.A2g_Truth(jrt.NN(tmp56).Invoke_O__O(m__11)) { tmp55 = 4096 } else { tmp55 = 0 }; base__21 = /*line :123:1*/lang.Numbers_Or_J_J__J(tmp54, tmp55); var inner__22 int64; var tmp57 int64 = /*line :101:1*/lang.Numbers_Or_J_O__J(base__21, acc__14); var tmp58 int64; if



























	jrt.A2g_Truth(static_QMARK___15) { tmp58 = 8 } else { tmp58 = 0 }; inner__22 = lang.Numbers_Or_J_J__J(tmp57, tmp58); var cls__23 int64; var tmp59 int64; var tmp60 /*line :101:1*/*lang.Var;





























	A_arbace_classes_parse_A_Init(); tmp60 = A_arbace_classes_parse_A_const_110; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O_O__O(acc__14, jrt.Long_ValueOf_J__Long(lang.Numbers_Or_J_J__J(1, 4)).Ref())) { tmp59 = 1 } else { tmp59 = 0 }; var tmp61 int64 = /*line :130:1*/lang.Numbers_Or_J_J__J(base__21, tmp59); var tmp62 int64; var tmp63 *lang.Var;

	A_arbace_classes_parse_A_Init(); tmp63 = A_arbace_classes_parse_A_const_96; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(kind__5)) { tmp62 = 0 } else { tmp62 = 32 }; cls__23 = /*line :130:1*/lang.Numbers_Or_J_J__J(tmp61, tmp62); var tmp64 /*line :101:1*/*lang.Keyword; A_arbace_classes_parse_A_Init(); tmp64 = A_arbace_classes_parse_A_const_111; var tmp65 any = tmp64.Ref(); var tmp66 any = jrt.Long_ValueOf_J__Long(cls__23).Ref(); var tmp67 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp67 = A_arbace_classes_parse_A_const_112; var tmp68 any = tmp67.Ref(); var tmp69 any = jrt.Long_ValueOf_J__Long(inner__22).Ref(); var tmp70 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp70 = A_arbace_classes_parse_A_const_113; var tmp71 any = tmp70.Ref(); return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp65, tmp66, tmp68, tmp69, tmp71, jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(static_QMARK___15)).Ref())) }
















func A_arbace_classes_parse_class_flags_fn__662000069_A_New() *A_arbace_classes_parse_class_flags_fn__662000069_A { A_arbace_classes_parse_class_flags_fn__662000069_A_Init(); t := &A_arbace_classes_parse_class_flags_fn__662000069_A{}; t.Ctor(); return t }
//line :118:1
func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) Ctor() {}
//line :118:1
func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) Invoke_O_O__O(self, p1__662000065_SHARP___1 any) any { var and__1927000168__auto____2 bool; var tmp1 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_70; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_64; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__662000065_SHARP___1)); if and__1927000168__auto____2 { var tmp4 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_108; var tmp5 *lang.Keyword = tmp4; var tmp6 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp6 = A_arbace_classes_parse_A_const_74; return jrt.NN(tmp5).Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p1__662000065_SHARP___1)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() } }
















func A_arbace_classes_parse_parse_class_A_New() *A_arbace_classes_parse_parse_class_A { A_arbace_classes_parse_parse_class_A_Init(); t := &A_arbace_classes_parse_parse_class_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_classes_parse_parse_class_A) Ctor() {}
//line :135:1
func (t *A_arbace_classes_parse_parse_class_A) Invoke_O_O_O__O(self, ctx__0, p__662000075__1 any) any { var vec__662000076__3 any = p__662000075__1; var seq__662000077__4 any; var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_60; seq__662000077__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(vec__662000076__3); var first__662000078__5 any; var tmp2 *lang.Var; A_arbace_classes_parse_A_Init(); tmp2 = A_arbace_classes_parse_A_const_23; first__662000078__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(seq__662000077__4); var seq__662000077__6 any; var tmp3 *lang.Var; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_22; seq__662000077__6 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(seq__662000077__4); var nm__7 any = first__662000078__5; var more__8 any = seq__662000077__6; var tmp4 *lang.Var;




	A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_31; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(nm__7)) { } else { var tmp5 *lang.Var; A_arbace_classes_parse_A_Init(); tmp5 = A_arbace_classes_parse_A_const_28; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_140, nil); var tmp8 *lang.Var; A_arbace_classes_parse_A_Init(); tmp8 = A_arbace_classes_parse_A_const_37; var tmp9 any = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp7, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(nm__7))).Ref(); var tmp10 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp6.Invoke_O_O__O(tmp9, tmp10.Ref())))) }; var m__9 any = /*line :135:1*/lang.RT_Meta_O__IPersistentMap(nm__7); var kind__10 any; var tmp11 *lang.Var;






	A_arbace_classes_parse_A_Init(); tmp11 = A_arbace_classes_parse_A_const_114; kind__10 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(m__9); var vec__662000079__11 any; var tmp12 any; var and__1927000168__auto____11 bool; var tmp13 /*line :135:1*/*lang.Keyword;







	A_arbace_classes_parse_A_Init(); tmp13 = A_arbace_classes_parse_A_const_17; and__1927000168__auto____11 = lang.Util_Equiv_O_O__Z(kind__10, tmp13.Ref()); if and__1927000168__auto____11 { var tmp14 *lang.Var; A_arbace_classes_parse_A_Init(); tmp14 = A_arbace_classes_parse_A_const_49; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_classes_parse_A_Init(); tmp16 = A_arbace_classes_parse_A_const_23; tmp12 = tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(more__8)) } else { tmp12 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____11).Ref() }; if jrt.A2g_Truth(tmp12) { var tmp17 *lang.Var; A_arbace_classes_parse_A_Init(); tmp17 = A_arbace_classes_parse_A_const_23; var tmp18 any = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(more__8); var tmp19 *lang.Var; A_arbace_classes_parse_A_Init(); tmp19 = A_arbace_classes_parse_A_const_39; vec__662000079__11 = lang.Tuple_Create_O_O__IPersistentVector(tmp18, lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(more__8)) } else { vec__662000079__11 = lang.Tuple_Create_O_O__IPersistentVector(nil, more__8) }; var components__12 any = /*line :135:1*/lang.RT_Nth_O_I_O__O(vec__662000079__11, lang.RT_IntCast_J__I(0), nil); var more__13 any = lang.RT_Nth_O_I_O__O(vec__662000079__11, lang.RT_IntCast_J__I(1), nil); var vec__662000082__14 any; var tmp20 *lang.Var;










	A_arbace_classes_parse_A_Init(); tmp20 = A_arbace_classes_parse_A_const_61; vec__662000082__14 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(more__13); var opts__15 any = /*line :135:1*/lang.RT_Nth_O_I_O__O(vec__662000082__14, lang.RT_IntCast_J__I(0), nil); var members__16 any = lang.RT_Nth_O_I_O__O(vec__662000082__14, lang.RT_IntCast_J__I(1), nil); var members__17 any; var tmp21 *lang.Var;











	A_arbace_classes_parse_A_Init(); tmp21 = A_arbace_classes_parse_A_const_115; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 any = A_arbace_classes_parse_parse_class_fn__662000085_A_New_O(ctx__0); var tmp24 *jrt.Class; A_arbace_classes_parse_parse_class_fn__662000085_A_Init(); tmp24 = A_arbace_classes_parse_parse_class_fn__662000085_A_fn_class; var tmp25 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var tmp26 *lang.Var; A_arbace_classes_parse_A_Init(); tmp26 = A_arbace_classes_parse_A_const_121; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp28 = A_arbace_classes_parse_A_const_119; members__17 = tmp22.Invoke_O_O__O(tmp25, tmp27.Invoke_O_O__O(jrt.NN(tmp28).Invoke_O__O(ctx__0), members__16)); var constants__18 any; var tmp29 /*line :135:1*/*lang.Var;












	A_arbace_classes_parse_A_Init(); tmp29 = A_arbace_classes_parse_A_const_105; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 any = A_arbace_classes_parse_parse_class_fn__662000087_A_New(); var tmp32 *jrt.Class; A_arbace_classes_parse_parse_class_fn__662000087_A_Init(); tmp32 = A_arbace_classes_parse_parse_class_fn__662000087_A_fn_class; constants__18 = tmp30.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil), members__17); var decl__19 any; var tmp33 /*line :135:1*/*lang.Keyword; A_arbace_classes_parse_A_Init(); tmp33 = A_arbace_classes_parse_A_const_71; var tmp34 any = tmp33.Ref(); var tmp35 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp35 = A_arbace_classes_parse_A_const_116; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_classes_parse_A_Init(); tmp37 = A_arbace_classes_parse_A_const_73; var tmp38 any = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(nm__7); var tmp39 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp39 = A_arbace_classes_parse_A_const_64; var tmp40 any = tmp39.Ref(); var tmp41 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp41 = A_arbace_classes_parse_A_const_74; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp43 = A_arbace_classes_parse_A_const_92; var tmp44 any = tmp43.Ref(); var tmp45 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp45 = A_arbace_classes_parse_A_const_92; var tmp46 any = jrt.NN(tmp45).Invoke_O__O(ctx__0); var tmp47 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp47 = A_arbace_classes_parse_A_const_93; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp49 = A_arbace_classes_parse_A_const_64; var tmp50 *lang.Keyword = tmp49; var tmp51 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp51 = A_arbace_classes_parse_A_const_117; var tmp52 any = jrt.NN(tmp50).Invoke_O__O(jrt.NN(tmp51).Invoke_O__O(ctx__0)); var tmp53 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp53 = A_arbace_classes_parse_A_const_75; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp55 = A_arbace_classes_parse_A_const_118; var tmp56 any = tmp55.Ref(); var tmp57 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp57 = A_arbace_classes_parse_A_const_68; var tmp58 any = tmp57.Ref(); var tmp59 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp59 = A_arbace_classes_parse_A_const_94; var tmp60 any = tmp59.Ref(); var tmp61 *lang.Var; A_arbace_classes_parse_A_Init(); tmp61 = A_arbace_classes_parse_A_const_46; var tmp62 any = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(members__17); var tmp63 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp63 = A_arbace_classes_parse_A_const_119; var tmp64 any = tmp63.Ref(); var tmp65 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp65 = A_arbace_classes_parse_A_const_119; decl__19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, nm__7, tmp36, tmp38, tmp40, kind__10, tmp42, m__9, tmp44, tmp46, tmp48, tmp52, tmp54, opts__15, tmp56, components__12, tmp58, constants__18, tmp60, tmp62, tmp64, jrt.NN(tmp65).Invoke_O__O(ctx__0))); var tmp66 /*line :153:1*/*lang.Var; A_arbace_classes_parse_A_Init(); tmp66 = A_arbace_classes_parse_A_const_105; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 any = A_arbace_classes_parse_parse_class_fn__662000089_A_New_O(nm__7); var tmp69 *jrt.Class; A_arbace_classes_parse_parse_class_fn__662000089_A_Init(); tmp69 = A_arbace_classes_parse_parse_class_fn__662000089_A_fn_class; var tmp70 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp68, tmp69, nil); var tmp71 any; A_arbace_classes_parse_A_Init(); tmp71 = A_arbace_classes_parse_A_const_123; if jrt.A2g_Truth(tmp67.Invoke_O_O__O(tmp70, tmp71)) { var tmp72 *lang.Var; A_arbace_classes_parse_A_Init(); tmp72 = A_arbace_classes_parse_A_const_28; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_140, nil), jrt.RefArrayOf(jrt.Object_class, nil, nm__7)).Ref(); var tmp75 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp75 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp73.Invoke_O_O__O(tmp74, tmp75.Ref())))) }; var tmp76 /*line :155:1*/*lang.Var; A_arbace_classes_parse_A_Init(); tmp76 = A_arbace_classes_parse_A_const_62; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 *lang.Var; A_arbace_classes_parse_A_Init(); tmp78 = A_arbace_classes_parse_A_const_124; return tmp77.Invoke_O_O__O(decl__19, lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O__O(decl__19)) }
//line :147:1
func A_arbace_classes_parse_parse_class_fn__662000085_A_New_O(p0 any) *A_arbace_classes_parse_parse_class_fn__662000085_A { A_arbace_classes_parse_parse_class_fn__662000085_A_Init(); t := &A_arbace_classes_parse_parse_class_fn__662000085_A{}; t.Ctor_O(p0); return t }
//line :147:1
func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) Ctor_O(c__ctx any) { t.F_ctx = c__ctx }
//line :147:1
func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) Invoke_O_O__O(self, p1__662000072_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_120; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_119; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).Invoke_O__O(t.F_ctx), p1__662000072_SHARP___1) }
func A_arbace_classes_parse_parse_class_fn__662000087_A_New() *A_arbace_classes_parse_parse_class_fn__662000087_A { A_arbace_classes_parse_parse_class_fn__662000087_A_Init(); t := &A_arbace_classes_parse_parse_class_fn__662000087_A{}; t.Ctor(); return t }
//line :148:1
func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) Ctor() {}
//line :148:1
func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) Invoke_O_O__O(self, p1__662000073_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_68; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_64; if lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__662000073_SHARP___1)) { var tmp4 *lang.Keyword; A_arbace_classes_parse_A_Init(); tmp4 = A_arbace_classes_parse_A_const_68; return jrt.NN(tmp4).Invoke_O__O(p1__662000073_SHARP___1) } else { return nil } }




func A_arbace_classes_parse_parse_class_fn__662000089_A_New_O(p0 any) *A_arbace_classes_parse_parse_class_fn__662000089_A { A_arbace_classes_parse_parse_class_fn__662000089_A_Init(); t := &A_arbace_classes_parse_parse_class_fn__662000089_A{}; t.Ctor_O(p0); return t }
//line :153:1
func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) Ctor_O(c__nm any) { t.F_nm = c__nm }
//line :153:1
func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) Invoke_O_O__O(self, p1__662000074_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_classes_parse_A_Init(); tmp1 = A_arbace_classes_parse_A_const_122; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_classes_parse_A_Init(); tmp3 = A_arbace_classes_parse_A_const_73; return tmp2.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(t.F_nm), p1__662000074_SHARP___1) }













type A_arbace_classes_parse_A struct{ jrt.Object }

var A_arbace_classes_parse_A_const_0 *lang.Var

var A_arbace_classes_parse_A_const_1 *lang.Var

var A_arbace_classes_parse_A_const_2 any

var A_arbace_classes_parse_A_const_3 any

var A_arbace_classes_parse_A_const_4 any

var A_arbace_classes_parse_A_const_5 *lang.Var

var A_arbace_classes_parse_A_const_6 *lang.Var

var A_arbace_classes_parse_A_const_7 *lang.Var

var A_arbace_classes_parse_A_const_8 any

var A_arbace_classes_parse_A_const_9 *lang.Var

var A_arbace_classes_parse_A_const_10 *lang.Var

var A_arbace_classes_parse_A_const_11 *lang.Var

var A_arbace_classes_parse_A_const_12 any

var A_arbace_classes_parse_A_const_13 *lang.Var

var A_arbace_classes_parse_A_const_14 *lang.Var

var A_arbace_classes_parse_A_const_15 *lang.Keyword

var A_arbace_classes_parse_A_const_16 *lang.Keyword

var A_arbace_classes_parse_A_const_17 *lang.Keyword

var A_arbace_classes_parse_A_const_18 *lang.Keyword

var A_arbace_classes_parse_A_const_19 *lang.Keyword

var A_arbace_classes_parse_A_const_20 *lang.Keyword

var A_arbace_classes_parse_A_const_21 *lang.Var

var A_arbace_classes_parse_A_const_22 *lang.Var

var A_arbace_classes_parse_A_const_23 *lang.Var

var A_arbace_classes_parse_A_const_24 *lang.Var

var A_arbace_classes_parse_A_const_25 *lang.Var

var A_arbace_classes_parse_A_const_26 *lang.Var

var A_arbace_classes_parse_A_const_27 *lang.Var

var A_arbace_classes_parse_A_const_28 *lang.Var

var A_arbace_classes_parse_A_const_29 any

var A_arbace_classes_parse_A_const_30 *lang.Var

var A_arbace_classes_parse_A_const_31 *lang.Var

var A_arbace_classes_parse_A_const_32 *lang.Var

var A_arbace_classes_parse_A_const_33 *lang.Var

var A_arbace_classes_parse_A_const_34 *lang.Var

var A_arbace_classes_parse_A_const_35 *lang.Keyword

var A_arbace_classes_parse_A_const_36 *lang.Var

var A_arbace_classes_parse_A_const_37 *lang.Var

var A_arbace_classes_parse_A_const_38 *lang.Keyword

var A_arbace_classes_parse_A_const_39 *lang.Var

var A_arbace_classes_parse_A_const_40 *lang.Var

var A_arbace_classes_parse_A_const_41 *lang.Var

var A_arbace_classes_parse_A_const_42 *lang.Var

var A_arbace_classes_parse_A_const_43 *lang.Var

var A_arbace_classes_parse_A_const_44 *lang.Var

var A_arbace_classes_parse_A_const_45 *lang.Keyword

var A_arbace_classes_parse_A_const_46 *lang.Var

var A_arbace_classes_parse_A_const_47 *lang.Keyword

var A_arbace_classes_parse_A_const_48 *lang.Keyword

var A_arbace_classes_parse_A_const_49 *lang.Var

var A_arbace_classes_parse_A_const_50 *lang.Var

var A_arbace_classes_parse_A_const_51 any

var A_arbace_classes_parse_A_const_52 *lang.Var

var A_arbace_classes_parse_A_const_53 *lang.Keyword

var A_arbace_classes_parse_A_const_54 *lang.Var

var A_arbace_classes_parse_A_const_55 *lang.Keyword

var A_arbace_classes_parse_A_const_56 *lang.Var

var A_arbace_classes_parse_A_const_57 *lang.Var

var A_arbace_classes_parse_A_const_58 *lang.Var

var A_arbace_classes_parse_A_const_59 any

var A_arbace_classes_parse_A_const_60 *lang.Var

var A_arbace_classes_parse_A_const_61 *lang.Var

var A_arbace_classes_parse_A_const_62 *lang.Var

var A_arbace_classes_parse_A_const_63 any

var A_arbace_classes_parse_A_const_64 *lang.Keyword

var A_arbace_classes_parse_A_const_65 any

var A_arbace_classes_parse_A_const_66 *lang.Var

var A_arbace_classes_parse_A_const_67 any

var A_arbace_classes_parse_A_const_68 *lang.Keyword

var A_arbace_classes_parse_A_const_69 *lang.Var

var A_arbace_classes_parse_A_const_70 *lang.Keyword

var A_arbace_classes_parse_A_const_71 *lang.Keyword

var A_arbace_classes_parse_A_const_72 *lang.Keyword

var A_arbace_classes_parse_A_const_73 *lang.Var

var A_arbace_classes_parse_A_const_74 *lang.Keyword

var A_arbace_classes_parse_A_const_75 *lang.Keyword

var A_arbace_classes_parse_A_const_76 *lang.Keyword

var A_arbace_classes_parse_A_const_77 *lang.Keyword

var A_arbace_classes_parse_A_const_78 *lang.Keyword

var A_arbace_classes_parse_A_const_79 any

var A_arbace_classes_parse_A_const_80 *lang.Keyword

var A_arbace_classes_parse_A_const_81 *lang.Keyword

var A_arbace_classes_parse_A_const_82 *lang.Keyword

var A_arbace_classes_parse_A_const_83 *lang.Var

var A_arbace_classes_parse_A_const_84 any

var A_arbace_classes_parse_A_const_85 *lang.Keyword

var A_arbace_classes_parse_A_const_86 *lang.Keyword

var A_arbace_classes_parse_A_const_87 any

var A_arbace_classes_parse_A_const_88 *lang.Keyword

var A_arbace_classes_parse_A_const_89 *lang.Var

var A_arbace_classes_parse_A_const_90 any

var A_arbace_classes_parse_A_const_91 *lang.Var

var A_arbace_classes_parse_A_const_92 *lang.Keyword

var A_arbace_classes_parse_A_const_93 *lang.Keyword

var A_arbace_classes_parse_A_const_94 *lang.Keyword

var A_arbace_classes_parse_A_const_95 *lang.Keyword

var A_arbace_classes_parse_A_const_96 *lang.Var

var A_arbace_classes_parse_A_const_97 any

var A_arbace_classes_parse_A_const_98 *lang.Keyword

var A_arbace_classes_parse_A_const_99 *lang.Keyword

var A_arbace_classes_parse_A_const_100 any

var A_arbace_classes_parse_A_const_101 *lang.Keyword

var A_arbace_classes_parse_A_const_102 any

var A_arbace_classes_parse_A_const_103 *lang.Keyword

var A_arbace_classes_parse_A_const_104 *lang.Keyword

var A_arbace_classes_parse_A_const_105 *lang.Var

var A_arbace_classes_parse_A_const_106 *lang.Keyword

var A_arbace_classes_parse_A_const_107 *lang.Keyword

var A_arbace_classes_parse_A_const_108 *lang.Keyword

var A_arbace_classes_parse_A_const_109 *lang.Keyword

var A_arbace_classes_parse_A_const_110 *lang.Var

var A_arbace_classes_parse_A_const_111 *lang.Keyword

var A_arbace_classes_parse_A_const_112 *lang.Keyword

var A_arbace_classes_parse_A_const_113 *lang.Keyword

var A_arbace_classes_parse_A_const_114 *lang.Var

var A_arbace_classes_parse_A_const_115 *lang.Var

var A_arbace_classes_parse_A_const_116 *lang.Keyword

var A_arbace_classes_parse_A_const_117 *lang.Keyword

var A_arbace_classes_parse_A_const_118 *lang.Keyword

var A_arbace_classes_parse_A_const_119 *lang.Keyword

var A_arbace_classes_parse_A_const_120 *lang.Var

var A_arbace_classes_parse_A_const_121 *lang.Var

var A_arbace_classes_parse_A_const_122 *lang.Var

var A_arbace_classes_parse_A_const_123 any

var A_arbace_classes_parse_A_const_124 *lang.Var

var A_arbace_classes_parse_A_init jrt.ClassInit

func A_arbace_classes_parse_A_Init() { if !A_arbace_classes_parse_A_init.Done() { A_arbace_classes_parse_A_init.Run(A_arbace_classes_parse_A_clinit) } }

func A_arbace_classes_parse_A_clinit() { A_arbace_classes_parse_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_classes_parse_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_classes_parse_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_parse_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_classes_parse_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_classes_parse_A_const_5 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_classes_parse_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_classes_parse_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_classes_parse_A_const_8 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_classes_parse_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_classes_parse_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_15); A_arbace_classes_parse_A_const_11 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); A_arbace_classes_parse_A_const_12 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_parse_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_classes_parse_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_classes_parse_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_classes_parse_A_const_16 = lang.RT_Keyword_String_String__Keyword(nil, Lit_20); A_arbace_classes_parse_A_const_17 = lang.RT_Keyword_String_String__Keyword(nil, Lit_21); A_arbace_classes_parse_A_const_18 = lang.RT_Keyword_String_String__Keyword(nil, Lit_22); A_arbace_classes_parse_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_23); A_arbace_classes_parse_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_24); A_arbace_classes_parse_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_classes_parse_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_classes_parse_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_classes_parse_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_classes_parse_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_classes_parse_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_classes_parse_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_classes_parse_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_classes_parse_A_const_29 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(); A_arbace_classes_parse_A_const_30 = lang.RT_Var_String_String__Var(Lit_11, Lit_34); A_arbace_classes_parse_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_classes_parse_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_classes_parse_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_37); A_arbace_classes_parse_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_38); A_arbace_classes_parse_A_const_35 = lang.RT_Keyword_String_String__Keyword(nil, Lit_39); A_arbace_classes_parse_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_classes_parse_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_classes_parse_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_classes_parse_A_const_39 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_classes_parse_A_const_40 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_classes_parse_A_const_41 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_classes_parse_A_const_42 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_classes_parse_A_const_43 = lang.RT_Var_String_String__Var(Lit_0, Lit_47); A_arbace_classes_parse_A_const_44 = lang.RT_Var_String_String__Var(Lit_0, Lit_48); A_arbace_classes_parse_A_const_45 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_classes_parse_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_classes_parse_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_51); A_arbace_classes_parse_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_52); A_arbace_classes_parse_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_classes_parse_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_54); A_arbace_classes_parse_A_const_51 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(); A_arbace_classes_parse_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_56); A_arbace_classes_parse_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_classes_parse_A_const_54 = lang.RT_Var_String_String__Var(Lit_11, Lit_58); A_arbace_classes_parse_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_59); A_arbace_classes_parse_A_const_56 = lang.RT_Var_String_String__Var(Lit_0, Lit_60); A_arbace_classes_parse_A_const_57 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); A_arbace_classes_parse_A_const_58 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_classes_parse_A_const_59 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_63).Ref(); A_arbace_classes_parse_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_64); A_arbace_classes_parse_A_const_61 = lang.RT_Var_String_String__Var(Lit_11, Lit_65); A_arbace_classes_parse_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_66); A_arbace_classes_parse_A_const_63 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(); A_arbace_classes_parse_A_const_64 = lang.RT_Keyword_String_String__Keyword(nil, Lit_68); A_arbace_classes_parse_A_const_65 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref(); A_arbace_classes_parse_A_const_66 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); A_arbace_classes_parse_A_const_67 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(); A_arbace_classes_parse_A_const_68 = lang.RT_Keyword_String_String__Keyword(nil, Lit_71); A_arbace_classes_parse_A_const_69 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_classes_parse_A_const_70 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_classes_parse_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_73); A_arbace_classes_parse_A_const_72 = lang.RT_Keyword_String_String__Keyword(nil, Lit_74); A_arbace_classes_parse_A_const_73 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_classes_parse_A_const_74 = lang.RT_Keyword_String_String__Keyword(nil, Lit_75); A_arbace_classes_parse_A_const_75 = lang.RT_Keyword_String_String__Keyword(nil, Lit_76); A_arbace_classes_parse_A_const_76 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_classes_parse_A_const_77 = lang.RT_Keyword_String_String__Keyword(nil, Lit_78); A_arbace_classes_parse_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_79); A_arbace_classes_parse_A_const_79 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(); A_arbace_classes_parse_A_const_80 = lang.RT_Keyword_String_String__Keyword(nil, Lit_81); A_arbace_classes_parse_A_const_81 = lang.RT_Keyword_String_String__Keyword(nil, Lit_82); A_arbace_classes_parse_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_83); A_arbace_classes_parse_A_const_83 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_classes_parse_A_const_84 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(); A_arbace_classes_parse_A_const_85 = lang.RT_Keyword_String_String__Keyword(nil, Lit_85); A_arbace_classes_parse_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_86); A_arbace_classes_parse_A_const_87 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(); A_arbace_classes_parse_A_const_88 = lang.RT_Keyword_String_String__Keyword(nil, Lit_88); A_arbace_classes_parse_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_89); A_arbace_classes_parse_A_const_90 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_19).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_22).Ref())).Ref(); A_arbace_classes_parse_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_90); A_arbace_classes_parse_A_const_92 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_classes_parse_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_92); A_arbace_classes_parse_A_const_94 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_classes_parse_A_const_95 = lang.RT_Keyword_String_String__Keyword(nil, Lit_94); A_arbace_classes_parse_A_const_96 = lang.RT_Var_String_String__Var(Lit_11, Lit_95); A_arbace_classes_parse_A_const_97 = jrt.Integer_ValueOf_I__Integer(1).Ref(); A_arbace_classes_parse_A_const_98 = lang.RT_Keyword_String_String__Keyword(nil, Lit_96); A_arbace_classes_parse_A_const_99 = lang.RT_Keyword_String_String__Keyword(nil, Lit_97); A_arbace_classes_parse_A_const_100 = jrt.Integer_ValueOf_I__Integer(4).Ref(); A_arbace_classes_parse_A_const_101 = lang.RT_Keyword_String_String__Keyword(nil, Lit_98); A_arbace_classes_parse_A_const_102 = jrt.Integer_ValueOf_I__Integer(2).Ref(); A_arbace_classes_parse_A_const_103 = lang.RT_Keyword_String_String__Keyword(nil, Lit_99); A_arbace_classes_parse_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_100); A_arbace_classes_parse_A_const_105 = lang.RT_Var_String_String__Var(Lit_0, Lit_101); A_arbace_classes_parse_A_const_106 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102); A_arbace_classes_parse_A_const_107 = lang.RT_Keyword_String_String__Keyword(nil, Lit_103); A_arbace_classes_parse_A_const_108 = lang.RT_Keyword_String_String__Keyword(nil, Lit_104); A_arbace_classes_parse_A_const_109 = lang.RT_Keyword_String_String__Keyword(nil, Lit_105); A_arbace_classes_parse_A_const_110 = lang.RT_Var_String_String__Var(Lit_11, Lit_106); A_arbace_classes_parse_A_const_111 = lang.RT_Keyword_String_String__Keyword(nil, Lit_107); A_arbace_classes_parse_A_const_112 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_classes_parse_A_const_113 = lang.RT_Keyword_String_String__Keyword(nil, Lit_109); A_arbace_classes_parse_A_const_114 = lang.RT_Var_String_String__Var(Lit_11, Lit_110); A_arbace_classes_parse_A_const_115 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_classes_parse_A_const_116 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_classes_parse_A_const_117 = lang.RT_Keyword_String_String__Keyword(nil, Lit_113); A_arbace_classes_parse_A_const_118 = lang.RT_Keyword_String_String__Keyword(nil, Lit_114); A_arbace_classes_parse_A_const_119 = lang.RT_Keyword_String_String__Keyword(nil, Lit_115); A_arbace_classes_parse_A_const_120 = lang.RT_Var_String_String__Var(Lit_11, Lit_116); A_arbace_classes_parse_A_const_121 = lang.RT_Var_String_String__Var(Lit_11, Lit_117); A_arbace_classes_parse_A_const_122 = lang.RT_Var_String_String__Var(Lit_3, Lit_118); A_arbace_classes_parse_A_const_123 = lang.Tuple_Create_O_O_O_O_O__IPersistentVector(Lit_119, Lit_120, Lit_121, Lit_122, Lit_123); A_arbace_classes_parse_A_const_124 = lang.RT_Var_String_String__Var(Lit_11, Lit_124) }

func A_arbace_classes_parse_A_New() *A_arbace_classes_parse_A { A_arbace_classes_parse_A_Init(); t := &A_arbace_classes_parse_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_parse_A) Ctor() {}

func (t *A_arbace_classes_parse_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_A_class }

func (t *A_arbace_classes_parse_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_A); return ok }

func A_arbace_classes_parse_A_Cast(x any) *A_arbace_classes_parse_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_A_class)) }; return v }



type A_arbace_classes_parse_class_flags_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_class_flags_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_class_flags_A_fn_class *jrt.Class

var A_arbace_classes_parse_class_flags_A_init jrt.ClassInit

func A_arbace_classes_parse_class_flags_A_Init() { if !A_arbace_classes_parse_class_flags_A_init.Done() { A_arbace_classes_parse_class_flags_A_init.Run(A_arbace_classes_parse_class_flags_A_clinit) } }

func A_arbace_classes_parse_class_flags_A_clinit() { A_arbace_classes_parse_class_flags_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_125, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_class_flags_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_class_flags_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_class_flags_A_class }

func (t *A_arbace_classes_parse_class_flags_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_class_flags_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_class_flags_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_class_flags_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_class_flags_A); return ok }

func A_arbace_classes_parse_class_flags_A_Cast(x any) *A_arbace_classes_parse_class_flags_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_class_flags_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_class_flags_A_class)) }; return v }



type A_arbace_classes_parse_class_flags_fn__662000069_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_class_flags_fn__662000069_A_fn_class *jrt.Class

var A_arbace_classes_parse_class_flags_fn__662000069_A_init jrt.ClassInit

func A_arbace_classes_parse_class_flags_fn__662000069_A_Init() { if !A_arbace_classes_parse_class_flags_fn__662000069_A_init.Done() { A_arbace_classes_parse_class_flags_fn__662000069_A_init.Run(A_arbace_classes_parse_class_flags_fn__662000069_A_clinit) } }

func A_arbace_classes_parse_class_flags_fn__662000069_A_clinit() { A_arbace_classes_parse_class_flags_fn__662000069_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_126, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_class_flags_fn__662000069_A_class }

func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_class_flags_fn__662000069_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_class_flags_fn__662000069_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_class_flags_fn__662000069_A); return ok }

func A_arbace_classes_parse_class_flags_fn__662000069_A_Cast(x any) *A_arbace_classes_parse_class_flags_fn__662000069_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_class_flags_fn__662000069_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_class_flags_fn__662000069_A_class)) }; return v }



type A_arbace_classes_parse_eval662000004_A struct{ jrt.Object }

func A_arbace_classes_parse_eval662000004_A_New() *A_arbace_classes_parse_eval662000004_A { t := &A_arbace_classes_parse_eval662000004_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_parse_eval662000004_A) Ctor() {}

func (t *A_arbace_classes_parse_eval662000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_eval662000004_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_eval662000004_A_class }

func (t *A_arbace_classes_parse_eval662000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_eval662000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_eval662000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_eval662000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_eval662000004_A); return ok }

func A_arbace_classes_parse_eval662000004_A_Cast(x any) *A_arbace_classes_parse_eval662000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_eval662000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_eval662000004_A_class)) }; return v }



type A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_fn_class *jrt.Class

var A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_init jrt.ClassInit

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_Init() { if !A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_init.Done() { A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_init.Run(A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_clinit) } }

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_clinit() { A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_127, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class }

func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A); return ok }

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_Cast(x any) *A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class)) }; return v }



type A_arbace_classes_parse_eval662000008_A struct{ jrt.Object }

func A_arbace_classes_parse_eval662000008_A_New() *A_arbace_classes_parse_eval662000008_A { t := &A_arbace_classes_parse_eval662000008_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_parse_eval662000008_A) Ctor() {}

func (t *A_arbace_classes_parse_eval662000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_eval662000008_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_eval662000008_A_class }

func (t *A_arbace_classes_parse_eval662000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_eval662000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_eval662000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_eval662000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_eval662000008_A); return ok }

func A_arbace_classes_parse_eval662000008_A_Cast(x any) *A_arbace_classes_parse_eval662000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_eval662000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_eval662000008_A_class)) }; return v }



type A_arbace_classes_parse_eval662000008_fn__662000009_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_parse_eval662000008_fn__662000009_A_fn_class *jrt.Class

var A_arbace_classes_parse_eval662000008_fn__662000009_A_init jrt.ClassInit

func A_arbace_classes_parse_eval662000008_fn__662000009_A_Init() { if !A_arbace_classes_parse_eval662000008_fn__662000009_A_init.Done() { A_arbace_classes_parse_eval662000008_fn__662000009_A_init.Run(A_arbace_classes_parse_eval662000008_fn__662000009_A_clinit) } }

func A_arbace_classes_parse_eval662000008_fn__662000009_A_clinit() { A_arbace_classes_parse_eval662000008_fn__662000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_128, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_eval662000008_fn__662000009_A_class }

func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_eval662000008_fn__662000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_eval662000008_fn__662000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_eval662000008_fn__662000009_A); return ok }

func A_arbace_classes_parse_eval662000008_fn__662000009_A_Cast(x any) *A_arbace_classes_parse_eval662000008_fn__662000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_eval662000008_fn__662000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_eval662000008_fn__662000009_A_class)) }; return v }



type A_arbace_classes_parse_expand_members_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_expand_members_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_expand_members_A_fn_class *jrt.Class

var A_arbace_classes_parse_expand_members_A_init jrt.ClassInit

func A_arbace_classes_parse_expand_members_A_Init() { if !A_arbace_classes_parse_expand_members_A_init.Done() { A_arbace_classes_parse_expand_members_A_init.Run(A_arbace_classes_parse_expand_members_A_clinit) } }

func A_arbace_classes_parse_expand_members_A_clinit() { A_arbace_classes_parse_expand_members_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_129, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_expand_members_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_expand_members_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_expand_members_A_class }

func (t *A_arbace_classes_parse_expand_members_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_expand_members_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_expand_members_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_expand_members_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_expand_members_A); return ok }

func A_arbace_classes_parse_expand_members_A_Cast(x any) *A_arbace_classes_parse_expand_members_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_expand_members_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_expand_members_A_class)) }; return v }



type A_arbace_classes_parse_expand_members_expand__662000019_A struct{ jrt.Object; F_ns any }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_expand_members_expand__662000019_A_fn_class *jrt.Class

var A_arbace_classes_parse_expand_members_expand__662000019_A_init jrt.ClassInit

func A_arbace_classes_parse_expand_members_expand__662000019_A_Init() { if !A_arbace_classes_parse_expand_members_expand__662000019_A_init.Done() { A_arbace_classes_parse_expand_members_expand__662000019_A_init.Run(A_arbace_classes_parse_expand_members_expand__662000019_A_clinit) } }

func A_arbace_classes_parse_expand_members_expand__662000019_A_clinit() { A_arbace_classes_parse_expand_members_expand__662000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_130, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_expand_members_expand__662000019_A_class }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_expand_members_expand__662000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_expand_members_expand__662000019_A); return ok }

func A_arbace_classes_parse_expand_members_expand__662000019_A_Cast(x any) *A_arbace_classes_parse_expand_members_expand__662000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_expand_members_expand__662000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_expand_members_expand__662000019_A_class)) }; return v }



type A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A struct{ jrt.Object; F_f any }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) Is_Compiler_AOTF0() {}

var A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_fn_class *jrt.Class

var A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_init jrt.ClassInit

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_Init() { if !A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_init.Done() { A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_init.Run(A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_clinit) } }

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_clinit() { A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_132, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A); return ok }

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_Cast(x any) *A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class)) }; return v }



type A_arbace_classes_parse_flags_of_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_flags_of_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_flags_of_A_fn_class *jrt.Class

var A_arbace_classes_parse_flags_of_A_init jrt.ClassInit

func A_arbace_classes_parse_flags_of_A_Init() { if !A_arbace_classes_parse_flags_of_A_init.Done() { A_arbace_classes_parse_flags_of_A_init.Run(A_arbace_classes_parse_flags_of_A_clinit) } }

func A_arbace_classes_parse_flags_of_A_clinit() { A_arbace_classes_parse_flags_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_133, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_flags_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_flags_of_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_flags_of_A_class }

func (t *A_arbace_classes_parse_flags_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_flags_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_flags_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_flags_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_flags_of_A); return ok }

func A_arbace_classes_parse_flags_of_A_Cast(x any) *A_arbace_classes_parse_flags_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_flags_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_flags_of_A_class)) }; return v }



type A_arbace_classes_parse_flags_of_fn__662000013_A struct{ jrt.Object; F_allowed, F_m any }

func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_flags_of_fn__662000013_A_fn_class *jrt.Class

var A_arbace_classes_parse_flags_of_fn__662000013_A_init jrt.ClassInit

func A_arbace_classes_parse_flags_of_fn__662000013_A_Init() { if !A_arbace_classes_parse_flags_of_fn__662000013_A_init.Done() { A_arbace_classes_parse_flags_of_fn__662000013_A_init.Run(A_arbace_classes_parse_flags_of_fn__662000013_A_clinit) } }

func A_arbace_classes_parse_flags_of_fn__662000013_A_clinit() { A_arbace_classes_parse_flags_of_fn__662000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_134, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_flags_of_fn__662000013_A_class }

func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_flags_of_fn__662000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_flags_of_fn__662000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_flags_of_fn__662000013_A); return ok }

func A_arbace_classes_parse_flags_of_fn__662000013_A_Cast(x any) *A_arbace_classes_parse_flags_of_fn__662000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_flags_of_fn__662000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_flags_of_fn__662000013_A_class)) }; return v }



type A_arbace_classes_parse_has_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_parse_has_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_has_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_parse_has_QMARK__A_init jrt.ClassInit

func A_arbace_classes_parse_has_QMARK__A_Init() { if !A_arbace_classes_parse_has_QMARK__A_init.Done() { A_arbace_classes_parse_has_QMARK__A_init.Run(A_arbace_classes_parse_has_QMARK__A_clinit) } }

func A_arbace_classes_parse_has_QMARK__A_clinit() { A_arbace_classes_parse_has_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_135, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_has_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_has_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_has_QMARK__A_class }

func (t *A_arbace_classes_parse_has_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_has_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_has_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_has_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_has_QMARK__A); return ok }

func A_arbace_classes_parse_has_QMARK__A_Cast(x any) *A_arbace_classes_parse_has_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_has_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_has_QMARK__A_class)) }; return v }



type A_arbace_classes_parse_interface_like_QMARK__A struct{ jrt.Object }

func (t *A_arbace_classes_parse_interface_like_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_interface_like_QMARK__A_fn_class *jrt.Class

var A_arbace_classes_parse_interface_like_QMARK__A_init jrt.ClassInit

func A_arbace_classes_parse_interface_like_QMARK__A_Init() { if !A_arbace_classes_parse_interface_like_QMARK__A_init.Done() { A_arbace_classes_parse_interface_like_QMARK__A_init.Run(A_arbace_classes_parse_interface_like_QMARK__A_clinit) } }

func A_arbace_classes_parse_interface_like_QMARK__A_clinit() { A_arbace_classes_parse_interface_like_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_136, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_interface_like_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_interface_like_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_interface_like_QMARK__A_class }

func (t *A_arbace_classes_parse_interface_like_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_interface_like_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_interface_like_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_interface_like_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_interface_like_QMARK__A); return ok }

func A_arbace_classes_parse_interface_like_QMARK__A_Cast(x any) *A_arbace_classes_parse_interface_like_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_interface_like_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_interface_like_QMARK__A_class)) }; return v }



type A_arbace_classes_parse_kind_of_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_kind_of_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_kind_of_A_fn_class *jrt.Class

var A_arbace_classes_parse_kind_of_A_init jrt.ClassInit

func A_arbace_classes_parse_kind_of_A_Init() { if !A_arbace_classes_parse_kind_of_A_init.Done() { A_arbace_classes_parse_kind_of_A_init.Run(A_arbace_classes_parse_kind_of_A_clinit) } }

func A_arbace_classes_parse_kind_of_A_clinit() { A_arbace_classes_parse_kind_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_137, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_kind_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_kind_of_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_kind_of_A_class }

func (t *A_arbace_classes_parse_kind_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_kind_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_kind_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_kind_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_kind_of_A); return ok }

func A_arbace_classes_parse_kind_of_A_Cast(x any) *A_arbace_classes_parse_kind_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_kind_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_kind_of_A_class)) }; return v }



type A_arbace_classes_parse_kw_meta_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_kw_meta_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_kw_meta_A_fn_class *jrt.Class

var A_arbace_classes_parse_kw_meta_A_init jrt.ClassInit

func A_arbace_classes_parse_kw_meta_A_Init() { if !A_arbace_classes_parse_kw_meta_A_init.Done() { A_arbace_classes_parse_kw_meta_A_init.Run(A_arbace_classes_parse_kw_meta_A_clinit) } }

func A_arbace_classes_parse_kw_meta_A_clinit() { A_arbace_classes_parse_kw_meta_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_138, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_kw_meta_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_kw_meta_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_kw_meta_A_class }

func (t *A_arbace_classes_parse_kw_meta_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_kw_meta_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_kw_meta_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_kw_meta_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_kw_meta_A); return ok }

func A_arbace_classes_parse_kw_meta_A_Cast(x any) *A_arbace_classes_parse_kw_meta_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_kw_meta_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_kw_meta_A_class)) }; return v }



type A_arbace_classes_parse_parse_class_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_class_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_parse_class_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_class_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_class_A_Init() { if !A_arbace_classes_parse_parse_class_A_init.Done() { A_arbace_classes_parse_parse_class_A_init.Run(A_arbace_classes_parse_parse_class_A_clinit) } }

func A_arbace_classes_parse_parse_class_A_clinit() { A_arbace_classes_parse_parse_class_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_139, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_class_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_class_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_class_A_class }

func (t *A_arbace_classes_parse_parse_class_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_class_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_class_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_class_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_class_A); return ok }

func A_arbace_classes_parse_parse_class_A_Cast(x any) *A_arbace_classes_parse_parse_class_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_class_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_class_A_class)) }; return v }



type A_arbace_classes_parse_parse_class_fn__662000085_A struct{ jrt.Object; F_ctx any }

func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_parse_class_fn__662000085_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_class_fn__662000085_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_class_fn__662000085_A_Init() { if !A_arbace_classes_parse_parse_class_fn__662000085_A_init.Done() { A_arbace_classes_parse_parse_class_fn__662000085_A_init.Run(A_arbace_classes_parse_parse_class_fn__662000085_A_clinit) } }

func A_arbace_classes_parse_parse_class_fn__662000085_A_clinit() { A_arbace_classes_parse_parse_class_fn__662000085_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_141, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_class_fn__662000085_A_class }

func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_class_fn__662000085_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_class_fn__662000085_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_class_fn__662000085_A); return ok }

func A_arbace_classes_parse_parse_class_fn__662000085_A_Cast(x any) *A_arbace_classes_parse_parse_class_fn__662000085_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_class_fn__662000085_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_class_fn__662000085_A_class)) }; return v }



type A_arbace_classes_parse_parse_class_fn__662000087_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_parse_class_fn__662000087_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_class_fn__662000087_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_class_fn__662000087_A_Init() { if !A_arbace_classes_parse_parse_class_fn__662000087_A_init.Done() { A_arbace_classes_parse_parse_class_fn__662000087_A_init.Run(A_arbace_classes_parse_parse_class_fn__662000087_A_clinit) } }

func A_arbace_classes_parse_parse_class_fn__662000087_A_clinit() { A_arbace_classes_parse_parse_class_fn__662000087_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_142, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_class_fn__662000087_A_class }

func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_class_fn__662000087_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_class_fn__662000087_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_class_fn__662000087_A); return ok }

func A_arbace_classes_parse_parse_class_fn__662000087_A_Cast(x any) *A_arbace_classes_parse_parse_class_fn__662000087_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_class_fn__662000087_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_class_fn__662000087_A_class)) }; return v }



type A_arbace_classes_parse_parse_class_fn__662000089_A struct{ jrt.Object; F_nm any }

func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_parse_class_fn__662000089_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_class_fn__662000089_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_class_fn__662000089_A_Init() { if !A_arbace_classes_parse_parse_class_fn__662000089_A_init.Done() { A_arbace_classes_parse_parse_class_fn__662000089_A_init.Run(A_arbace_classes_parse_parse_class_fn__662000089_A_clinit) } }

func A_arbace_classes_parse_parse_class_fn__662000089_A_clinit() { A_arbace_classes_parse_parse_class_fn__662000089_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_143, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_class_fn__662000089_A_class }

func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_class_fn__662000089_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_class_fn__662000089_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_class_fn__662000089_A); return ok }

func A_arbace_classes_parse_parse_class_fn__662000089_A_Cast(x any) *A_arbace_classes_parse_parse_class_fn__662000089_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_class_fn__662000089_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_class_fn__662000089_A_class)) }; return v }



type A_arbace_classes_parse_parse_member_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_member_A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_parse_member_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_member_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_member_A_Init() { if !A_arbace_classes_parse_parse_member_A_init.Done() { A_arbace_classes_parse_parse_member_A_init.Run(A_arbace_classes_parse_parse_member_A_clinit) } }

func A_arbace_classes_parse_parse_member_A_clinit() { A_arbace_classes_parse_parse_member_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_144, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_member_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_member_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_member_A_class }

func (t *A_arbace_classes_parse_parse_member_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_member_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_member_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_member_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_member_A); return ok }

func A_arbace_classes_parse_parse_member_A_Cast(x any) *A_arbace_classes_parse_parse_member_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_member_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_member_A_class)) }; return v }



type A_arbace_classes_parse_parse_member_STAR__A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_member_STAR__A) Is_Compiler_AOTF2() {}

var A_arbace_classes_parse_parse_member_STAR__A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_member_STAR__A_init jrt.ClassInit

func A_arbace_classes_parse_parse_member_STAR__A_Init() { if !A_arbace_classes_parse_parse_member_STAR__A_init.Done() { A_arbace_classes_parse_parse_member_STAR__A_init.Run(A_arbace_classes_parse_parse_member_STAR__A_clinit) } }

func A_arbace_classes_parse_parse_member_STAR__A_clinit() { A_arbace_classes_parse_parse_member_STAR__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_145, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_member_STAR__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_member_STAR__A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_member_STAR__A_class }

func (t *A_arbace_classes_parse_parse_member_STAR__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_member_STAR__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_member_STAR__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_member_STAR__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_member_STAR__A); return ok }

func A_arbace_classes_parse_parse_member_STAR__A_Cast(x any) *A_arbace_classes_parse_parse_member_STAR__A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_member_STAR__A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_member_STAR__A_class)) }; return v }



type A_arbace_classes_parse_parse_member_STAR__fn__662000055_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_Init() { if !A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_init.Done() { A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_init.Run(A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_clinit) } }

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_clinit() { A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_148, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class }

func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_member_STAR__fn__662000055_A); return ok }

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_Cast(x any) *A_arbace_classes_parse_parse_member_STAR__fn__662000055_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_member_STAR__fn__662000055_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class)) }; return v }



type A_arbace_classes_parse_parse_params_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_params_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_parse_params_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_params_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_params_A_Init() { if !A_arbace_classes_parse_parse_params_A_init.Done() { A_arbace_classes_parse_parse_params_A_init.Run(A_arbace_classes_parse_parse_params_A_clinit) } }

func A_arbace_classes_parse_parse_params_A_clinit() { A_arbace_classes_parse_parse_params_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_149, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_params_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_params_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_params_A_class }

func (t *A_arbace_classes_parse_parse_params_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_params_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_params_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_params_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_params_A); return ok }

func A_arbace_classes_parse_parse_params_A_Cast(x any) *A_arbace_classes_parse_parse_params_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_params_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_params_A_class)) }; return v }



type A_arbace_classes_parse_parse_params_fn__662000031_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_parse_params_fn__662000031_A_fn_class *jrt.Class

var A_arbace_classes_parse_parse_params_fn__662000031_A_init jrt.ClassInit

func A_arbace_classes_parse_parse_params_fn__662000031_A_Init() { if !A_arbace_classes_parse_parse_params_fn__662000031_A_init.Done() { A_arbace_classes_parse_parse_params_fn__662000031_A_init.Run(A_arbace_classes_parse_parse_params_fn__662000031_A_clinit) } }

func A_arbace_classes_parse_parse_params_fn__662000031_A_clinit() { A_arbace_classes_parse_parse_params_fn__662000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_151, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_parse_params_fn__662000031_A_class }

func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_parse_params_fn__662000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_parse_params_fn__662000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_parse_params_fn__662000031_A); return ok }

func A_arbace_classes_parse_parse_params_fn__662000031_A_Cast(x any) *A_arbace_classes_parse_parse_params_fn__662000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_parse_params_fn__662000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_parse_params_fn__662000031_A_class)) }; return v }



type A_arbace_classes_parse_split_options_A struct{ jrt.Object }

func (t *A_arbace_classes_parse_split_options_A) Is_Compiler_AOTF1() {}

var A_arbace_classes_parse_split_options_A_fn_class *jrt.Class

var A_arbace_classes_parse_split_options_A_init jrt.ClassInit

func A_arbace_classes_parse_split_options_A_Init() { if !A_arbace_classes_parse_split_options_A_init.Done() { A_arbace_classes_parse_split_options_A_init.Run(A_arbace_classes_parse_split_options_A_clinit) } }

func A_arbace_classes_parse_split_options_A_clinit() { A_arbace_classes_parse_split_options_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_152, lang.Compiler_AOTFn_class) }

func (t *A_arbace_classes_parse_split_options_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse_split_options_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse_split_options_A_class }

func (t *A_arbace_classes_parse_split_options_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse_split_options_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse_split_options_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse_split_options_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse_split_options_A); return ok }

func A_arbace_classes_parse_split_options_A_Cast(x any) *A_arbace_classes_parse_split_options_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse_split_options_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse_split_options_A_class)) }; return v }
