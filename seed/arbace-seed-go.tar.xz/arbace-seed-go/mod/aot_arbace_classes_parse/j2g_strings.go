//line j2g_strings.ae:1
package aot_arbace_classes_parse

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn9,interfacekn4,enumkn6,recordkn10,annotationkn4,elsekn5,classyn2,dokn5,macrokn4,formkn6,paramskn7,varargskn5,vmetayn1,&kn4,linekn3,midyn6,methodyn8,defclasskn4,kindyn11,constructoryn9,constantskn9,constantskn6,methodkn3,symkn4,namekn4,metakn4,optskn4,bodykn8,has-bodykn4,ctoryn11,initializerkn4,initkn4,argskn10,param-tagsyn5,fieldkn5,fieldkn8,has-inityn18,static-initializerkn6,clinitkn7,nestingkn10,outer-kindkn7,memberskn6,memberkn6,publickn9,protectedkn7,privatekn6,statickn5,localkn9,enum-bodykn5,finalkn8,abstractkn9,synthetickn5,flagskn11,inner-flagskn7,static?kn6,simplekn5,outerkn10,componentskn2,nsv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn20,arbace.classes.parsem2,R6,s180,Syntax of the Java forms (SPEC §4): a Java form becomes a class declaration map, before\n  any name is resolved. Access flags follow from the metadata and Java's implicit modifiers.v11,arbace.core13,*loaded-libs*v11,arbace.core6,reducev20,arbace.classes.parse14,modifier-flagsl0,v11,arbace.core4,keysv11,arbace.core3,notR7,R8,R9,R10,R11,R12,v11,arbace.core8,keyword?v11,arbace.core4,nextv11,arbace.core5,firstv11,arbace.core5,nnextv11,arbace.core5,assocv11,arbace.core6,secondv11,arbace.core6,mapcatv11,arbace.core7,ex-infoR13,v20,arbace.classes.parse12,member-headsv11,arbace.core7,symbol?v11,arbace.core7,resolvev11,arbace.core19,pop-thread-bindingsv11,arbace.core4,var?R14,v11,arbace.core4,seq?v11,arbace.core6,pr-strR15,v11,arbace.core4,restv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,*ns*v11,arbace.core5,applyv11,arbace.core10,split-withR16,v11,arbace.core3,vecR17,R18,v11,arbace.core7,vector?v11,arbace.core4,not=R19,v11,arbace.core6,concatR20,v20,arbace.classes.parse13,parse-member*R21,v11,arbace.core5,swap!v20,arbace.classes.parse10,member-idsv11,arbace.core3,incR22,v11,arbace.core3,seqv20,arbace.classes.parse13,split-optionsv11,arbace.core5,mergeR23,R24,R25,v20,arbace.classes.parse12,parse-paramsR26,R27,v11,arbace.core4,mapvR28,R29,R30,v11,arbace.core4,nameR31,R32,R33,R34,R35,R36,R37,R38,R39,v11,arbace.core5,some?R40,R41,R42,R43,R44,v11,arbace.core9,contains?S2,R7,R10,v11,arbace.core8,to-arrayR45,R46,R47,R48,v20,arbace.classes.parse15,interface-like?i1,R49,R50,i4,R51,i2,R52,R53,v11,arbace.core4,someR54,R55,R56,R57,v20,arbace.classes.parse4,has?R58,R59,R60,v20,arbace.classes.parse7,kind-ofv11,arbace.core3,mapR61,R62,R63,R64,v20,arbace.classes.parse12,parse-memberv20,arbace.classes.parse14,expand-membersv13,arbace.string9,includes?V5,s1,;s1,[s1,/s1,<s1,>v20,arbace.classes.parse11,class-flags")

var Lit_1 *jrt.String = jrt.Intern("arbace.classes.parse$class_flags$fn__662000069")

var Lit_2 *jrt.String = jrt.Intern("arbace.classes.parse$expand_members$expand__662000019")

var Lit_3 *jrt.String = jrt.Intern("Bad class member: ")

var Lit_4 *jrt.String = jrt.Intern("arbace.classes.parse$expand_members$expand__662000019$fn__662000020")

var Lit_5 *jrt.String = jrt.Intern("arbace.classes.parse$flags_of$fn__662000013")

var Lit_6 *jrt.String = jrt.Intern("Bad class name: ")

var Lit_7 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class$fn__662000085")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class$fn__662000087")

var Lit_9 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class$fn__662000089")

var Lit_10 *jrt.String = jrt.Intern("<init>")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.parse$parse_member_STAR_$fn__662000055")

var Lit_12 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_13 *jrt.String = jrt.Intern("Expected a parameter vector: ")

var Lit_14 *jrt.String = jrt.Intern("arbace.classes.parse$parse_params$fn__662000031")

var Lit_15 *jrt.String = jrt.Intern("kn3,docyn11,arbace.coreyn18,static-initializeryn11,initializeryn9,constantsyn2,doyn6,methodyn5,fieldyn8,defclassyn11,constructorkn4,linekn6,columnkn4,filekn7,privatekn8,arglistsyn1,myn1,kkn6,publickn9,protectedkn6,statickn5,finalkn8,abstractkn12,synchronizedkn6,nativekn9,transientkn8,volatilekn9,synthetickn6,bridgeyn7,allowedyn5,flagsyn1,fyn2,xsyn2,nsyn5,formskn8,declaredyn1,vyn4,kindkn4,keysyn4,metayn7,nestingyn10,outer-kindyn7,memberskn2,asyn4,declyn3,ctxyn2,nmyn1,&yn4,morev11,arbace.core5,in-nsMyn20,arbace.classes.parsem2,R0,s180,Syntax of the Java forms (SPEC §4): a Java form becomes a class declaration map, before\n  any name is resolved. Access flags follow from the metadata and Java's implicit modifiers.m2,R0,s180,Syntax of the Java forms (SPEC §4): a Java form becomes a class declaration map, before\n  any name is resolved. Access flags follow from the metadata and Java's implicit modifiers.R1,v20,arbace.classes.parse12,member-headsS8,R2,R3,R4,R5,R6,R7,R8,R9,m6,R10,i7,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse7,kw-metam10,R13,TR14,L1,V2,R15,R16,R10,i9,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse14,modifier-flagsm24,R17,i1,R13,i2,R18,i4,R19,i8,R20,i16,R21,i1024,R22,i32,R23,i256,R24,i128,R25,i64,R26,i4096,R27,i64,m6,R10,i11,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse8,flags-ofm10,R14,L1,V2,R15,R28,R0,s74,Flags from modifier keywords in metadata m, limited to those in `allowed`.R10,i18,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse4,has?m8,R14,L1,V2,R29,R30,R10,i24,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse7,kind-ofm8,R14,L1,V1,R15,R10,i26,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse13,split-optionsm10,R14,L1,V1,R31,R0,s80,Splits leading keyword/value options off a sequence. Returns [options-map rest].R10,i30,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse14,expand-membersm10,R14,L1,V2,R32,R33,R0,s65,Splices `do` and expands member macros, resolved in namespace ns.R10,i38,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse11,parse-classm8,R34,TR10,i53,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse13,parse-member*m8,R34,TR10,i53,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse12,parse-paramsm10,R13,TR14,L1,V1,R35,R10,i55,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse10,member-idsv11,arbace.core4,atomm8,R13,TR10,i62,R11,i1,R12,s23,arbace/classes/parse.ael0,v20,arbace.classes.parse12,parse-memberm10,R14,L1,V2,R32,R30,R0,s85,A parsed member; :mid identifies it (members equal as values may differ in metadata).R10,i64,R11,i1,R12,s23,arbace/classes/parse.aem10,R13,TR14,L1,V2,R32,R30,R10,i70,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse15,interface-like?m10,R13,TR14,L1,V1,R36,R10,i99,R11,i1,R12,s23,arbace/classes/parse.aev20,arbace.classes.parse11,class-flagsm10,R14,L1,V1,m4,R37,V6,R36,R38,R39,R40,R4,R41,R42,R43,R0,s64,Class file access flags and InnerClasses flags of a declaration.R10,i101,R11,i1,R12,s23,arbace/classes/parse.aem10,R14,L1,V2,R44,V3,R45,R46,R47,R0,s263,Parses a Java form (name record-components? option* member*), the defclass head stripped.\n  `ctx`: {:ns ns :nesting :top|:member|:local :outer outer-decl}. Returns a declaration:\n  {:simple :kind :meta :nesting :opts :components :members [parsed member ...] ...}.R10,i135,R11,i1,R12,s23,arbace/classes/parse.ae")

var Lit_16 *jrt.String = jrt.Intern("arbace.classes.parse$eval662000004$loading__1927001464__auto____662000005")

var Lit_17 *jrt.String = jrt.Intern("arbace.classes.parse$eval662000008$fn__662000009")

var Lit_18 *jrt.String = jrt.Intern("arbace.classes.parse$kw_meta")

var Lit_19 *jrt.String = jrt.Intern("arbace.classes.parse$flags_of")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.parse$has_QMARK_")

var Lit_21 *jrt.String = jrt.Intern("arbace.classes.parse$kind_of")

var Lit_22 *jrt.String = jrt.Intern("arbace.classes.parse$split_options")

var Lit_23 *jrt.String = jrt.Intern("arbace.classes.parse$expand_members")

var Lit_24 *jrt.String = jrt.Intern("arbace.classes.parse$parse_params")

var Lit_25 *jrt.String = jrt.Intern("arbace.classes.parse$parse_member")

var Lit_26 *jrt.String = jrt.Intern("arbace.classes.parse$parse_member_STAR_")

var Lit_27 *jrt.String = jrt.Intern("arbace.classes.parse$interface_like_QMARK_")

var Lit_28 *jrt.String = jrt.Intern("arbace.classes.parse$class_flags")

var Lit_29 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class")
