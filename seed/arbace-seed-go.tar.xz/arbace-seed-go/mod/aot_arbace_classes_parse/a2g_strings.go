//line a2g_strings.ae:1
package aot_arbace_classes_parse

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_7 *jrt.String = jrt.Intern("Opcodes")

var Lit_8 *jrt.String = jrt.Intern("commute")

var Lit_9 *jrt.String = jrt.Intern("deref")

var Lit_10 *jrt.String = jrt.Intern("conj")

var Lit_11 *jrt.String = jrt.Intern("arbace.classes.parse")

var Lit_12 *jrt.String = jrt.Intern("doc")

var Lit_13 *jrt.String = jrt.Intern("Syntax of the class forms (SPEC §4): a class form becomes a class declaration map, before\n  any name is resolved. Access flags follow from the metadata and Java's implicit modifiers.")

var Lit_14 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_15 *jrt.String = jrt.Intern("reduce")

var Lit_16 *jrt.String = jrt.Intern("modifier-flags")

var Lit_17 *jrt.String = jrt.Intern("keys")

var Lit_18 *jrt.String = jrt.Intern("not")

var Lit_19 *jrt.String = jrt.Intern("interface")

var Lit_20 *jrt.String = jrt.Intern("enum")

var Lit_21 *jrt.String = jrt.Intern("record")

var Lit_22 *jrt.String = jrt.Intern("annotation")

var Lit_23 *jrt.String = jrt.Intern("else")

var Lit_24 *jrt.String = jrt.Intern("class")

var Lit_25 *jrt.String = jrt.Intern("keyword?")

var Lit_26 *jrt.String = jrt.Intern("next")

var Lit_27 *jrt.String = jrt.Intern("first")

var Lit_28 *jrt.String = jrt.Intern("nnext")

var Lit_29 *jrt.String = jrt.Intern("assoc")

var Lit_30 *jrt.String = jrt.Intern("second")

var Lit_31 *jrt.String = jrt.Intern("mapcat")

var Lit_32 *jrt.String = jrt.Intern("ex-info")

var Lit_33 *jrt.String = jrt.Intern("do")

var Lit_34 *jrt.String = jrt.Intern("member-heads")

var Lit_35 *jrt.String = jrt.Intern("symbol?")

var Lit_36 *jrt.String = jrt.Intern("resolve")

var Lit_37 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_38 *jrt.String = jrt.Intern("var?")

var Lit_39 *jrt.String = jrt.Intern("macro")

var Lit_40 *jrt.String = jrt.Intern("seq?")

var Lit_41 *jrt.String = jrt.Intern("pr-str")

var Lit_42 *jrt.String = jrt.Intern("form")

var Lit_43 *jrt.String = jrt.Intern("rest")

var Lit_44 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_45 *jrt.String = jrt.Intern("hash-map")

var Lit_46 *jrt.String = jrt.Intern("*ns*")

var Lit_47 *jrt.String = jrt.Intern("apply")

var Lit_48 *jrt.String = jrt.Intern("split-with")

var Lit_49 *jrt.String = jrt.Intern("params")

var Lit_50 *jrt.String = jrt.Intern("vec")

var Lit_51 *jrt.String = jrt.Intern("varargs")

var Lit_52 *jrt.String = jrt.Intern("vmeta")

var Lit_53 *jrt.String = jrt.Intern("vector?")

var Lit_54 *jrt.String = jrt.Intern("not=")

var Lit_55 *jrt.String = jrt.Intern("&")

var Lit_56 *jrt.String = jrt.Intern("concat")

var Lit_57 *jrt.String = jrt.Intern("line")

var Lit_58 *jrt.String = jrt.Intern("parse-member*")

var Lit_59 *jrt.String = jrt.Intern("mid")

var Lit_60 *jrt.String = jrt.Intern("swap!")

var Lit_61 *jrt.String = jrt.Intern("member-ids")

var Lit_62 *jrt.String = jrt.Intern("inc")

var Lit_63 *jrt.String = jrt.Intern("method")

var Lit_64 *jrt.String = jrt.Intern("seq")

var Lit_65 *jrt.String = jrt.Intern("split-options")

var Lit_66 *jrt.String = jrt.Intern("merge")

var Lit_67 *jrt.String = jrt.Intern("defclass")

var Lit_68 *jrt.String = jrt.Intern("kind")

var Lit_69 *jrt.String = jrt.Intern("constructor")

var Lit_70 *jrt.String = jrt.Intern("parse-params")

var Lit_71 *jrt.String = jrt.Intern("constants")

var Lit_72 *jrt.String = jrt.Intern("mapv")

var Lit_73 *jrt.String = jrt.Intern("sym")

var Lit_74 *jrt.String = jrt.Intern("name")

var Lit_75 *jrt.String = jrt.Intern("meta")

var Lit_76 *jrt.String = jrt.Intern("opts")

var Lit_77 *jrt.String = jrt.Intern("body")

var Lit_78 *jrt.String = jrt.Intern("has-body")

var Lit_79 *jrt.String = jrt.Intern("ctor")

var Lit_80 *jrt.String = jrt.Intern("initializer")

var Lit_81 *jrt.String = jrt.Intern("init")

var Lit_82 *jrt.String = jrt.Intern("args")

var Lit_83 *jrt.String = jrt.Intern("param-tags")

var Lit_84 *jrt.String = jrt.Intern("some?")

var Lit_85 *jrt.String = jrt.Intern("field")

var Lit_86 *jrt.String = jrt.Intern("has-init")

var Lit_87 *jrt.String = jrt.Intern("static-initializer")

var Lit_88 *jrt.String = jrt.Intern("clinit")

var Lit_89 *jrt.String = jrt.Intern("contains?")

var Lit_90 *jrt.String = jrt.Intern("to-array")

var Lit_91 *jrt.String = jrt.Intern("nesting")

var Lit_92 *jrt.String = jrt.Intern("outer-kind")

var Lit_93 *jrt.String = jrt.Intern("members")

var Lit_94 *jrt.String = jrt.Intern("member")

var Lit_95 *jrt.String = jrt.Intern("interface-like?")

var Lit_96 *jrt.String = jrt.Intern("public")

var Lit_97 *jrt.String = jrt.Intern("protected")

var Lit_98 *jrt.String = jrt.Intern("private")

var Lit_99 *jrt.String = jrt.Intern("static")

var Lit_100 *jrt.String = jrt.Intern("local")

var Lit_101 *jrt.String = jrt.Intern("some")

var Lit_102 *jrt.String = jrt.Intern("enum-body")

var Lit_103 *jrt.String = jrt.Intern("final")

var Lit_104 *jrt.String = jrt.Intern("abstract")

var Lit_105 *jrt.String = jrt.Intern("synthetic")

var Lit_106 *jrt.String = jrt.Intern("has?")

var Lit_107 *jrt.String = jrt.Intern("flags")

var Lit_108 *jrt.String = jrt.Intern("inner-flags")

var Lit_109 *jrt.String = jrt.Intern("static?")

var Lit_110 *jrt.String = jrt.Intern("kind-of")

var Lit_111 *jrt.String = jrt.Intern("map")

var Lit_112 *jrt.String = jrt.Intern("simple")

var Lit_113 *jrt.String = jrt.Intern("outer")

var Lit_114 *jrt.String = jrt.Intern("components")

var Lit_115 *jrt.String = jrt.Intern("ns")

var Lit_116 *jrt.String = jrt.Intern("parse-member")

var Lit_117 *jrt.String = jrt.Intern("expand-members")

var Lit_118 *jrt.String = jrt.Intern("includes?")

var Lit_119 *jrt.String = jrt.Intern(";")

var Lit_120 *jrt.String = jrt.Intern("[")

var Lit_121 *jrt.String = jrt.Intern("/")

var Lit_122 *jrt.String = jrt.Intern("<")

var Lit_123 *jrt.String = jrt.Intern(">")

var Lit_124 *jrt.String = jrt.Intern("class-flags")

var Lit_125 *jrt.String = jrt.Intern("arbace.classes.parse$class_flags")

var Lit_126 *jrt.String = jrt.Intern("arbace.classes.parse$class_flags$fn__662000069")

var Lit_127 *jrt.String = jrt.Intern("arbace.classes.parse$eval662000004$loading__1927001464__auto____662000005")

var Lit_128 *jrt.String = jrt.Intern("arbace.classes.parse$eval662000008$fn__662000009")

var Lit_129 *jrt.String = jrt.Intern("arbace.classes.parse$expand_members")

var Lit_130 *jrt.String = jrt.Intern("arbace.classes.parse$expand_members$expand__662000019")

var Lit_131 *jrt.String = jrt.Intern("Bad class member: ")

var Lit_132 *jrt.String = jrt.Intern("arbace.classes.parse$expand_members$expand__662000019$fn__662000020")

var Lit_133 *jrt.String = jrt.Intern("arbace.classes.parse$flags_of")

var Lit_134 *jrt.String = jrt.Intern("arbace.classes.parse$flags_of$fn__662000013")

var Lit_135 *jrt.String = jrt.Intern("arbace.classes.parse$has_QMARK_")

var Lit_136 *jrt.String = jrt.Intern("arbace.classes.parse$interface_like_QMARK_")

var Lit_137 *jrt.String = jrt.Intern("arbace.classes.parse$kind_of")

var Lit_138 *jrt.String = jrt.Intern("arbace.classes.parse$kw_meta")

var Lit_139 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class")

var Lit_140 *jrt.String = jrt.Intern("Bad class name: ")

var Lit_141 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class$fn__662000085")

var Lit_142 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class$fn__662000087")

var Lit_143 *jrt.String = jrt.Intern("arbace.classes.parse$parse_class$fn__662000089")

var Lit_144 *jrt.String = jrt.Intern("arbace.classes.parse$parse_member")

var Lit_145 *jrt.String = jrt.Intern("arbace.classes.parse$parse_member_STAR_")

var Lit_146 *jrt.String = jrt.Intern("<init>")

var Lit_147 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_148 *jrt.String = jrt.Intern("arbace.classes.parse$parse_member_STAR_$fn__662000055")

var Lit_149 *jrt.String = jrt.Intern("arbace.classes.parse$parse_params")

var Lit_150 *jrt.String = jrt.Intern("Expected a parameter vector: ")

var Lit_151 *jrt.String = jrt.Intern("arbace.classes.parse$parse_params$fn__662000031")

var Lit_152 *jrt.String = jrt.Intern("arbace.classes.parse$split_options")

var Lit_153 *jrt.String = jrt.Intern("in-ns")

var Lit_154 *jrt.String = jrt.Intern("column")

var Lit_155 *jrt.String = jrt.Intern("file")

var Lit_156 *jrt.String = jrt.Intern("arbace/classes/parse.ae")

var Lit_157 *jrt.String = jrt.Intern("kw-meta")

var Lit_158 *jrt.String = jrt.Intern("arglists")

var Lit_159 *jrt.String = jrt.Intern("m")

var Lit_160 *jrt.String = jrt.Intern("k")

var Lit_161 *jrt.String = jrt.Intern("synchronized")

var Lit_162 *jrt.String = jrt.Intern("native")

var Lit_163 *jrt.String = jrt.Intern("transient")

var Lit_164 *jrt.String = jrt.Intern("volatile")

var Lit_165 *jrt.String = jrt.Intern("bridge")

var Lit_166 *jrt.String = jrt.Intern("flags-of")

var Lit_167 *jrt.String = jrt.Intern("allowed")

var Lit_168 *jrt.String = jrt.Intern("Flags from modifier keywords in metadata m, limited to those in `allowed`.")

var Lit_169 *jrt.String = jrt.Intern("f")

var Lit_170 *jrt.String = jrt.Intern("xs")

var Lit_171 *jrt.String = jrt.Intern("Splits leading keyword/value options off a sequence. Returns [options-map rest].")

var Lit_172 *jrt.String = jrt.Intern("forms")

var Lit_173 *jrt.String = jrt.Intern("Splices `do` and expands member macros, resolved in namespace ns.")

var Lit_174 *jrt.String = jrt.Intern("parse-class")

var Lit_175 *jrt.String = jrt.Intern("declared")

var Lit_176 *jrt.String = jrt.Intern("v")

var Lit_177 *jrt.String = jrt.Intern("atom")

var Lit_178 *jrt.String = jrt.Intern("A parsed member; :mid identifies it (members equal as values may differ in metadata).")

var Lit_179 *jrt.String = jrt.Intern("decl")

var Lit_180 *jrt.String = jrt.Intern("Class file access flags and InnerClasses flags of a declaration.")

var Lit_181 *jrt.String = jrt.Intern("ctx")

var Lit_182 *jrt.String = jrt.Intern("nm")

var Lit_183 *jrt.String = jrt.Intern("more")

var Lit_184 *jrt.String = jrt.Intern("Parses a class form (name record-components? option* member*), the defclass head stripped.\n  `ctx`: {:ns ns :nesting :top|:member|:local :outer outer-decl}. Returns a declaration:\n  {:simple :kind :meta :nesting :opts :components :members [parsed member ...] ...}.")
