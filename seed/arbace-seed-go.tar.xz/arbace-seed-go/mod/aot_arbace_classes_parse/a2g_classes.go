//line a2g_classes.ae:1
package aot_arbace_classes_parse

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_classes_parse_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_A_New()}; return nil }

var A_arbace_classes_parse_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_parse_A_new}

var A_arbace_classes_parse_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_A"})

func init() { i := A_arbace_classes_parse_A_class.Info(); i.IsInstance = A_arbace_classes_parse_A_InstanceOf; i.Init = A_arbace_classes_parse_A_Init; i.Table = A_arbace_classes_parse_A_members; jrt.RegisterGoType(A_arbace_classes_parse_A_class, reflect.TypeFor[A_arbace_classes_parse_A]()) }

func A_arbace_classes_parse_class_flags_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_class_flags_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_class_flags_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_class_flags_A_New()}; return nil }

func A_arbace_classes_parse_class_flags_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_class_flags_A_fn_class)}; return nil }

var A_arbace_classes_parse_class_flags_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_class_flags_A_invoke, New: A_arbace_classes_parse_class_flags_A_new, Get: A_arbace_classes_parse_class_flags_A_get}

var A_arbace_classes_parse_class_flags_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$class_flags", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "class_flags", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_class_flags_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_class_flags_A_class.Info(); i.IsInstance = A_arbace_classes_parse_class_flags_A_InstanceOf; i.Init = A_arbace_classes_parse_class_flags_A_Init; i.Table = A_arbace_classes_parse_class_flags_A_members; jrt.RegisterGoType(A_arbace_classes_parse_class_flags_A_class, reflect.TypeFor[A_arbace_classes_parse_class_flags_A]()) }

func A_arbace_classes_parse_class_flags_fn__662000069_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_class_flags_fn__662000069_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_class_flags_fn__662000069_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_class_flags_fn__662000069_A_New()}; return nil }

func A_arbace_classes_parse_class_flags_fn__662000069_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_class_flags_fn__662000069_A_fn_class)}; return nil }

var A_arbace_classes_parse_class_flags_fn__662000069_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_class_flags_fn__662000069_A_invoke, New: A_arbace_classes_parse_class_flags_fn__662000069_A_new, Get: A_arbace_classes_parse_class_flags_fn__662000069_A_get}

var A_arbace_classes_parse_class_flags_fn__662000069_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$class_flags$fn__662000069", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_class_flags_A_class, Simple: "fn__662000069", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_class_flags_fn__662000069_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_class_flags_fn__662000069_A_class.Info(); i.IsInstance = A_arbace_classes_parse_class_flags_fn__662000069_A_InstanceOf; i.Init = A_arbace_classes_parse_class_flags_fn__662000069_A_Init; i.Table = A_arbace_classes_parse_class_flags_fn__662000069_A_members; jrt.RegisterGoType(A_arbace_classes_parse_class_flags_fn__662000069_A_class, reflect.TypeFor[A_arbace_classes_parse_class_flags_fn__662000069_A]()) }

func A_arbace_classes_parse_eval662000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_eval662000004_A_New()}; return nil }

var A_arbace_classes_parse_eval662000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_parse_eval662000004_A_new}

var A_arbace_classes_parse_eval662000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$eval662000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_parse_A_class, Simple: "eval662000004", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000004_A"})

func init() { i := A_arbace_classes_parse_eval662000004_A_class.Info(); i.IsInstance = A_arbace_classes_parse_eval662000004_A_InstanceOf; i.Table = A_arbace_classes_parse_eval662000004_A_members; jrt.RegisterGoType(A_arbace_classes_parse_eval662000004_A_class, reflect.TypeFor[A_arbace_classes_parse_eval662000004_A]()) }

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_New()}; return nil }

func A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_fn_class)}; return nil }

var A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_invoke, New: A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_new, Get: A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_get}

var A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$eval662000004$loading__1927001464__auto____662000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_parse_eval662000004_A_class, Simple: "loading__1927001464__auto____662000005", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class.Info(); i.IsInstance = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_InstanceOf; i.Init = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_Init; i.Table = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_members; jrt.RegisterGoType(A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class, reflect.TypeFor[A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A]()) }

func A_arbace_classes_parse_eval662000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_eval662000008_A_New()}; return nil }

var A_arbace_classes_parse_eval662000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_parse_eval662000008_A_new}

var A_arbace_classes_parse_eval662000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$eval662000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_parse_A_class, Simple: "eval662000008", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000008_A"})

func init() { i := A_arbace_classes_parse_eval662000008_A_class.Info(); i.IsInstance = A_arbace_classes_parse_eval662000008_A_InstanceOf; i.Table = A_arbace_classes_parse_eval662000008_A_members; jrt.RegisterGoType(A_arbace_classes_parse_eval662000008_A_class, reflect.TypeFor[A_arbace_classes_parse_eval662000008_A]()) }

func A_arbace_classes_parse_eval662000008_fn__662000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_eval662000008_fn__662000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_parse_eval662000008_fn__662000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_eval662000008_fn__662000009_A_New()}; return nil }

func A_arbace_classes_parse_eval662000008_fn__662000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_eval662000008_fn__662000009_A_fn_class)}; return nil }

var A_arbace_classes_parse_eval662000008_fn__662000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_eval662000008_fn__662000009_A_invoke, New: A_arbace_classes_parse_eval662000008_fn__662000009_A_new, Get: A_arbace_classes_parse_eval662000008_fn__662000009_A_get}

var A_arbace_classes_parse_eval662000008_fn__662000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$eval662000008$fn__662000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_parse_eval662000008_A_class, Simple: "fn__662000009", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000008_fn__662000009_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_eval662000008_fn__662000009_A_class.Info(); i.IsInstance = A_arbace_classes_parse_eval662000008_fn__662000009_A_InstanceOf; i.Init = A_arbace_classes_parse_eval662000008_fn__662000009_A_Init; i.Table = A_arbace_classes_parse_eval662000008_fn__662000009_A_members; jrt.RegisterGoType(A_arbace_classes_parse_eval662000008_fn__662000009_A_class, reflect.TypeFor[A_arbace_classes_parse_eval662000008_fn__662000009_A]()) }

func A_arbace_classes_parse_expand_members_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_expand_members_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_expand_members_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_expand_members_A_New()}; return nil }

func A_arbace_classes_parse_expand_members_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_expand_members_A_fn_class)}; return nil }

var A_arbace_classes_parse_expand_members_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_expand_members_A_invoke, New: A_arbace_classes_parse_expand_members_A_new, Get: A_arbace_classes_parse_expand_members_A_get}

var A_arbace_classes_parse_expand_members_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$expand_members", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "expand_members", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_expand_members_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_expand_members_A_class.Info(); i.IsInstance = A_arbace_classes_parse_expand_members_A_InstanceOf; i.Init = A_arbace_classes_parse_expand_members_A_Init; i.Table = A_arbace_classes_parse_expand_members_A_members; jrt.RegisterGoType(A_arbace_classes_parse_expand_members_A_class, reflect.TypeFor[A_arbace_classes_parse_expand_members_A]()) }

func A_arbace_classes_parse_expand_members_expand__662000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_expand_members_expand__662000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_expand_members_expand__662000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_expand_members_expand__662000019_A_New_O(args[0])}; return nil }

func A_arbace_classes_parse_expand_members_expand__662000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_expand_members_expand__662000019_A_fn_class)}; return nil }

var A_arbace_classes_parse_expand_members_expand__662000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_expand_members_expand__662000019_A_invoke, New: A_arbace_classes_parse_expand_members_expand__662000019_A_new, Get: A_arbace_classes_parse_expand_members_expand__662000019_A_get}

var A_arbace_classes_parse_expand_members_expand__662000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$expand_members$expand__662000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_expand_members_A_class, Simple: "expand__662000019", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_expand_members_expand__662000019_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_expand_members_expand__662000019_A_class.Info(); i.IsInstance = A_arbace_classes_parse_expand_members_expand__662000019_A_InstanceOf; i.Init = A_arbace_classes_parse_expand_members_expand__662000019_A_Init; i.Table = A_arbace_classes_parse_expand_members_expand__662000019_A_members; jrt.RegisterGoType(A_arbace_classes_parse_expand_members_expand__662000019_A_class, reflect.TypeFor[A_arbace_classes_parse_expand_members_expand__662000019_A]()) }

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_New_O(args[0])}; return nil }

func A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_fn_class)}; return nil }

var A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_invoke, New: A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_new, Get: A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_get}

var A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$expand_members$expand__662000019$fn__662000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_classes_parse_expand_members_expand__662000019_A_class, Simple: "fn__662000020", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class.Info(); i.IsInstance = A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_InstanceOf; i.Init = A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_Init; i.Table = A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_members; jrt.RegisterGoType(A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class, reflect.TypeFor[A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A]()) }

func A_arbace_classes_parse_flags_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_flags_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_flags_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_flags_of_A_New()}; return nil }

func A_arbace_classes_parse_flags_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_flags_of_A_fn_class)}; return nil }

var A_arbace_classes_parse_flags_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_flags_of_A_invoke, New: A_arbace_classes_parse_flags_of_A_new, Get: A_arbace_classes_parse_flags_of_A_get}

var A_arbace_classes_parse_flags_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$flags_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "flags_of", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_flags_of_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_flags_of_A_class.Info(); i.IsInstance = A_arbace_classes_parse_flags_of_A_InstanceOf; i.Init = A_arbace_classes_parse_flags_of_A_Init; i.Table = A_arbace_classes_parse_flags_of_A_members; jrt.RegisterGoType(A_arbace_classes_parse_flags_of_A_class, reflect.TypeFor[A_arbace_classes_parse_flags_of_A]()) }

func A_arbace_classes_parse_flags_of_fn__662000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_flags_of_fn__662000013_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_flags_of_fn__662000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_flags_of_fn__662000013_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_flags_of_fn__662000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_flags_of_fn__662000013_A_fn_class)}; return nil }

var A_arbace_classes_parse_flags_of_fn__662000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_flags_of_fn__662000013_A_invoke, New: A_arbace_classes_parse_flags_of_fn__662000013_A_new, Get: A_arbace_classes_parse_flags_of_fn__662000013_A_get}

var A_arbace_classes_parse_flags_of_fn__662000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$flags_of$fn__662000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_flags_of_A_class, Simple: "fn__662000013", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_flags_of_fn__662000013_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_flags_of_fn__662000013_A_class.Info(); i.IsInstance = A_arbace_classes_parse_flags_of_fn__662000013_A_InstanceOf; i.Init = A_arbace_classes_parse_flags_of_fn__662000013_A_Init; i.Table = A_arbace_classes_parse_flags_of_fn__662000013_A_members; jrt.RegisterGoType(A_arbace_classes_parse_flags_of_fn__662000013_A_class, reflect.TypeFor[A_arbace_classes_parse_flags_of_fn__662000013_A]()) }

func A_arbace_classes_parse_has_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_has_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_has_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_has_QMARK__A_New()}; return nil }

func A_arbace_classes_parse_has_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_has_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_parse_has_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_has_QMARK__A_invoke, New: A_arbace_classes_parse_has_QMARK__A_new, Get: A_arbace_classes_parse_has_QMARK__A_get}

var A_arbace_classes_parse_has_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$has_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "has_QMARK_", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_has_QMARK__A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_has_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_parse_has_QMARK__A_InstanceOf; i.Init = A_arbace_classes_parse_has_QMARK__A_Init; i.Table = A_arbace_classes_parse_has_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_parse_has_QMARK__A_class, reflect.TypeFor[A_arbace_classes_parse_has_QMARK__A]()) }

func A_arbace_classes_parse_interface_like_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_interface_like_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_interface_like_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_interface_like_QMARK__A_New()}; return nil }

func A_arbace_classes_parse_interface_like_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_interface_like_QMARK__A_fn_class)}; return nil }

var A_arbace_classes_parse_interface_like_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_interface_like_QMARK__A_invoke, New: A_arbace_classes_parse_interface_like_QMARK__A_new, Get: A_arbace_classes_parse_interface_like_QMARK__A_get}

var A_arbace_classes_parse_interface_like_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$interface_like_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "interface_like_QMARK_", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_interface_like_QMARK__A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_interface_like_QMARK__A_class.Info(); i.IsInstance = A_arbace_classes_parse_interface_like_QMARK__A_InstanceOf; i.Init = A_arbace_classes_parse_interface_like_QMARK__A_Init; i.Table = A_arbace_classes_parse_interface_like_QMARK__A_members; jrt.RegisterGoType(A_arbace_classes_parse_interface_like_QMARK__A_class, reflect.TypeFor[A_arbace_classes_parse_interface_like_QMARK__A]()) }

func A_arbace_classes_parse_kind_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_kind_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_kind_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_kind_of_A_New()}; return nil }

func A_arbace_classes_parse_kind_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_kind_of_A_fn_class)}; return nil }

var A_arbace_classes_parse_kind_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_kind_of_A_invoke, New: A_arbace_classes_parse_kind_of_A_new, Get: A_arbace_classes_parse_kind_of_A_get}

var A_arbace_classes_parse_kind_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$kind_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "kind_of", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_kind_of_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_kind_of_A_class.Info(); i.IsInstance = A_arbace_classes_parse_kind_of_A_InstanceOf; i.Init = A_arbace_classes_parse_kind_of_A_Init; i.Table = A_arbace_classes_parse_kind_of_A_members; jrt.RegisterGoType(A_arbace_classes_parse_kind_of_A_class, reflect.TypeFor[A_arbace_classes_parse_kind_of_A]()) }

func A_arbace_classes_parse_kw_meta_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_kw_meta_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_kw_meta_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_kw_meta_A_New()}; return nil }

func A_arbace_classes_parse_kw_meta_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_kw_meta_A_fn_class)}; return nil }

var A_arbace_classes_parse_kw_meta_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_kw_meta_A_invoke, New: A_arbace_classes_parse_kw_meta_A_new, Get: A_arbace_classes_parse_kw_meta_A_get}

var A_arbace_classes_parse_kw_meta_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$kw_meta", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "kw_meta", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_kw_meta_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_kw_meta_A_class.Info(); i.IsInstance = A_arbace_classes_parse_kw_meta_A_InstanceOf; i.Init = A_arbace_classes_parse_kw_meta_A_Init; i.Table = A_arbace_classes_parse_kw_meta_A_members; jrt.RegisterGoType(A_arbace_classes_parse_kw_meta_A_class, reflect.TypeFor[A_arbace_classes_parse_kw_meta_A]()) }

func A_arbace_classes_parse_parse_class_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_class_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_parse_class_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_class_A_New()}; return nil }

func A_arbace_classes_parse_parse_class_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_class_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_class_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_class_A_invoke, New: A_arbace_classes_parse_parse_class_A_new, Get: A_arbace_classes_parse_parse_class_A_get}

var A_arbace_classes_parse_parse_class_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_class", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "parse_class", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_class_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_class_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_class_A_Init; i.Table = A_arbace_classes_parse_parse_class_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_class_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_class_A]()) }

func A_arbace_classes_parse_parse_class_fn__662000085_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_class_fn__662000085_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_parse_class_fn__662000085_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_class_fn__662000085_A_New_O(args[0])}; return nil }

func A_arbace_classes_parse_parse_class_fn__662000085_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_class_fn__662000085_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_class_fn__662000085_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_class_fn__662000085_A_invoke, New: A_arbace_classes_parse_parse_class_fn__662000085_A_new, Get: A_arbace_classes_parse_parse_class_fn__662000085_A_get}

var A_arbace_classes_parse_parse_class_fn__662000085_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_class$fn__662000085", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_parse_class_A_class, Simple: "fn__662000085", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_fn__662000085_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_class_fn__662000085_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_class_fn__662000085_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_class_fn__662000085_A_Init; i.Table = A_arbace_classes_parse_parse_class_fn__662000085_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_class_fn__662000085_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_class_fn__662000085_A]()) }

func A_arbace_classes_parse_parse_class_fn__662000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_class_fn__662000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_parse_class_fn__662000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_class_fn__662000087_A_New()}; return nil }

func A_arbace_classes_parse_parse_class_fn__662000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_class_fn__662000087_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_class_fn__662000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_class_fn__662000087_A_invoke, New: A_arbace_classes_parse_parse_class_fn__662000087_A_new, Get: A_arbace_classes_parse_parse_class_fn__662000087_A_get}

var A_arbace_classes_parse_parse_class_fn__662000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_class$fn__662000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_parse_class_A_class, Simple: "fn__662000087", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_fn__662000087_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_class_fn__662000087_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_class_fn__662000087_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_class_fn__662000087_A_Init; i.Table = A_arbace_classes_parse_parse_class_fn__662000087_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_class_fn__662000087_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_class_fn__662000087_A]()) }

func A_arbace_classes_parse_parse_class_fn__662000089_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_class_fn__662000089_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_parse_class_fn__662000089_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_class_fn__662000089_A_New_O(args[0])}; return nil }

func A_arbace_classes_parse_parse_class_fn__662000089_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_class_fn__662000089_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_class_fn__662000089_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_class_fn__662000089_A_invoke, New: A_arbace_classes_parse_parse_class_fn__662000089_A_new, Get: A_arbace_classes_parse_parse_class_fn__662000089_A_get}

var A_arbace_classes_parse_parse_class_fn__662000089_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_class$fn__662000089", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_parse_class_A_class, Simple: "fn__662000089", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_fn__662000089_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_class_fn__662000089_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_class_fn__662000089_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_class_fn__662000089_A_Init; i.Table = A_arbace_classes_parse_parse_class_fn__662000089_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_class_fn__662000089_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_class_fn__662000089_A]()) }

func A_arbace_classes_parse_parse_member_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_member_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_parse_member_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_member_A_New()}; return nil }

func A_arbace_classes_parse_parse_member_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_member_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_member_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_member_A_invoke, New: A_arbace_classes_parse_parse_member_A_new, Get: A_arbace_classes_parse_parse_member_A_get}

var A_arbace_classes_parse_parse_member_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_member", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "parse_member", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_member_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_member_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_member_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_member_A_Init; i.Table = A_arbace_classes_parse_parse_member_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_member_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_member_A]()) }

func A_arbace_classes_parse_parse_member_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_member_STAR__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_classes_parse_parse_member_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_member_STAR__A_New()}; return nil }

func A_arbace_classes_parse_parse_member_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_member_STAR__A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_member_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_member_STAR__A_invoke, New: A_arbace_classes_parse_parse_member_STAR__A_new, Get: A_arbace_classes_parse_parse_member_STAR__A_get}

var A_arbace_classes_parse_parse_member_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_member_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "parse_member_STAR_", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_member_STAR__A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_member_STAR__A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_member_STAR__A_InstanceOf; i.Init = A_arbace_classes_parse_parse_member_STAR__A_Init; i.Table = A_arbace_classes_parse_parse_member_STAR__A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_member_STAR__A_class, reflect.TypeFor[A_arbace_classes_parse_parse_member_STAR__A]()) }

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_member_STAR__fn__662000055_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_New()}; return nil }

func A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_invoke, New: A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_new, Get: A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_get}

var A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_member_STAR_$fn__662000055", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_parse_member_STAR__A_class, Simple: "fn__662000055", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_member_STAR__fn__662000055_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_Init; i.Table = A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_member_STAR__fn__662000055_A]()) }

func A_arbace_classes_parse_parse_params_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_params_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_parse_params_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_params_A_New()}; return nil }

func A_arbace_classes_parse_parse_params_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_params_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_params_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_params_A_invoke, New: A_arbace_classes_parse_parse_params_A_new, Get: A_arbace_classes_parse_parse_params_A_get}

var A_arbace_classes_parse_parse_params_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_params", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "parse_params", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_params_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_params_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_params_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_params_A_Init; i.Table = A_arbace_classes_parse_parse_params_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_params_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_params_A]()) }

func A_arbace_classes_parse_parse_params_fn__662000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_parse_params_fn__662000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_parse_params_fn__662000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_parse_params_fn__662000031_A_New()}; return nil }

func A_arbace_classes_parse_parse_params_fn__662000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_parse_params_fn__662000031_A_fn_class)}; return nil }

var A_arbace_classes_parse_parse_params_fn__662000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_parse_params_fn__662000031_A_invoke, New: A_arbace_classes_parse_parse_params_fn__662000031_A_new, Get: A_arbace_classes_parse_parse_params_fn__662000031_A_get}

var A_arbace_classes_parse_parse_params_fn__662000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$parse_params$fn__662000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_parse_params_A_class, Simple: "fn__662000031", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_params_fn__662000031_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_parse_params_fn__662000031_A_class.Info(); i.IsInstance = A_arbace_classes_parse_parse_params_fn__662000031_A_InstanceOf; i.Init = A_arbace_classes_parse_parse_params_fn__662000031_A_Init; i.Table = A_arbace_classes_parse_parse_params_fn__662000031_A_members; jrt.RegisterGoType(A_arbace_classes_parse_parse_params_fn__662000031_A_class, reflect.TypeFor[A_arbace_classes_parse_parse_params_fn__662000031_A]()) }

func A_arbace_classes_parse_split_options_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_classes_parse_split_options_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_classes_parse_split_options_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_split_options_A_New()}; return nil }

func A_arbace_classes_parse_split_options_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_classes_parse_split_options_A_fn_class)}; return nil }

var A_arbace_classes_parse_split_options_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_classes_parse_split_options_A_invoke, New: A_arbace_classes_parse_split_options_A_new, Get: A_arbace_classes_parse_split_options_A_get}

var A_arbace_classes_parse_split_options_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$split_options", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_classes_parse_A_class, Simple: "split_options", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse_split_options_A_class.Info(); i.IsInstance = A_arbace_classes_parse_split_options_A_InstanceOf; i.Init = A_arbace_classes_parse_split_options_A_Init; i.Table = A_arbace_classes_parse_split_options_A_members; jrt.RegisterGoType(A_arbace_classes_parse_split_options_A_class, reflect.TypeFor[A_arbace_classes_parse_split_options_A]()) }

func A_arbace_classes_parse__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_parse__init_A_Load__O(); case 1: return A_arbace_classes_parse__init_A_Unit0__O(); case 2: return A_arbace_classes_parse__init_A_Unit1__O(); case 3: return A_arbace_classes_parse__init_A_Unit10__O(); case 4: return A_arbace_classes_parse__init_A_Unit11__O(); case 5: return A_arbace_classes_parse__init_A_Unit12__O(); case 6: return A_arbace_classes_parse__init_A_Unit13__O(); case 7: return A_arbace_classes_parse__init_A_Unit14__O(); case 8: return A_arbace_classes_parse__init_A_Unit15__O(); case 9: return A_arbace_classes_parse__init_A_Unit16__O(); case 10: return A_arbace_classes_parse__init_A_Unit17__O(); case 11: return A_arbace_classes_parse__init_A_Unit18__O(); case 12: return A_arbace_classes_parse__init_A_Unit19__O(); case 13: return A_arbace_classes_parse__init_A_Unit2__O(); case 14: return A_arbace_classes_parse__init_A_Unit20__O(); case 15: return A_arbace_classes_parse__init_A_Unit3__O(); case 16: return A_arbace_classes_parse__init_A_Unit4__O(); case 17: return A_arbace_classes_parse__init_A_Unit5__O(); case 18: return A_arbace_classes_parse__init_A_Unit6__O(); case 19: return A_arbace_classes_parse__init_A_Unit7__O(); case 20: return A_arbace_classes_parse__init_A_Unit8__O(); case 21: return A_arbace_classes_parse__init_A_Unit9__O()}; return nil }

func A_arbace_classes_parse__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse__init_A_New()}; return nil }

var A_arbace_classes_parse__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_parse__init_A_invoke, New: A_arbace_classes_parse__init_A_new}

var A_arbace_classes_parse__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse__init_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse__init_A_class.Info(); i.IsInstance = A_arbace_classes_parse__init_A_InstanceOf; i.Init = A_arbace_classes_parse__init_A_Init; i.Table = A_arbace_classes_parse__init_A_members; jrt.RegisterGoType(A_arbace_classes_parse__init_A_class, reflect.TypeFor[A_arbace_classes_parse__init_A]()) }
