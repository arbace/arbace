//line j2g_classes.ae:1
package aot_arbace_classes_parse

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_classes_parse_class_flags_A_class, Name: "arbace.classes.parse$class_flags", Modifiers: 25, Simple: "class_flags", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_class_flags_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_class_flags_fn__662000069_A_class, Name: "arbace.classes.parse$class_flags$fn__662000069", Modifiers: 25, Simple: "fn__662000069", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_class_flags_fn__662000069_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_class_flags_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class, Name: "arbace.classes.parse$eval662000004$loading__1927001464__auto____662000005", Modifiers: 25, Simple: "loading__1927001464__auto____662000005", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_eval662000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_eval662000008_fn__662000009_A_class, Name: "arbace.classes.parse$eval662000008$fn__662000009", Modifiers: 25, Simple: "fn__662000009", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000008_fn__662000009_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_eval662000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_expand_members_A_class, Name: "arbace.classes.parse$expand_members", Modifiers: 25, Simple: "expand_members", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_expand_members_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_expand_members_expand__662000019_A_class, Name: "arbace.classes.parse$expand_members$expand__662000019", Modifiers: 25, Simple: "expand__662000019", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_expand_members_expand__662000019_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_expand_members_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class, Name: "arbace.classes.parse$expand_members$expand__662000019$fn__662000020", Modifiers: 25, Simple: "fn__662000020", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_expand_members_expand__662000019_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_flags_of_A_class, Name: "arbace.classes.parse$flags_of", Modifiers: 25, Simple: "flags_of", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_flags_of_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_flags_of_fn__662000013_A_class, Name: "arbace.classes.parse$flags_of$fn__662000013", Modifiers: 25, Simple: "fn__662000013", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_flags_of_fn__662000013_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_flags_of_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_has_QMARK__A_class, Name: "arbace.classes.parse$has_QMARK_", Modifiers: 25, Simple: "has_QMARK_", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_has_QMARK__A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_interface_like_QMARK__A_class, Name: "arbace.classes.parse$interface_like_QMARK_", Modifiers: 25, Simple: "interface_like_QMARK_", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_interface_like_QMARK__A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_kind_of_A_class, Name: "arbace.classes.parse$kind_of", Modifiers: 25, Simple: "kind_of", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_kind_of_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_kw_meta_A_class, Name: "arbace.classes.parse$kw_meta", Modifiers: 25, Simple: "kw_meta", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_kw_meta_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_class_A_class, Name: "arbace.classes.parse$parse_class", Modifiers: 25, Simple: "parse_class", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_class_fn__662000085_A_class, Name: "arbace.classes.parse$parse_class$fn__662000085", Modifiers: 25, Simple: "fn__662000085", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_fn__662000085_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_parse_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_class_fn__662000087_A_class, Name: "arbace.classes.parse$parse_class$fn__662000087", Modifiers: 25, Simple: "fn__662000087", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_fn__662000087_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_parse_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_class_fn__662000089_A_class, Name: "arbace.classes.parse$parse_class$fn__662000089", Modifiers: 25, Simple: "fn__662000089", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_class_fn__662000089_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_parse_class_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_member_A_class, Name: "arbace.classes.parse$parse_member", Modifiers: 25, Simple: "parse_member", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_member_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_member_STAR__A_class, Name: "arbace.classes.parse$parse_member_STAR_", Modifiers: 25, Simple: "parse_member_STAR_", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_member_STAR__A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class, Name: "arbace.classes.parse$parse_member_STAR_$fn__662000055", Modifiers: 25, Simple: "fn__662000055", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_member_STAR__fn__662000055_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_parse_member_STAR__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_params_A_class, Name: "arbace.classes.parse$parse_params", Modifiers: 25, Simple: "parse_params", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_params_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_parse_params_fn__662000031_A_class, Name: "arbace.classes.parse$parse_params$fn__662000031", Modifiers: 25, Simple: "fn__662000031", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_parse_params_fn__662000031_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_parse_params_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_classes_parse_split_options_A_class, Name: "arbace.classes.parse$split_options", Modifiers: 25, Simple: "split_options", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_split_options_A", Source: "parse.ae", Declaring: &A_arbace_classes_parse_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_classes_parse_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_A_New()}; return nil }

var A_arbace_classes_parse_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_parse_A_new}

var A_arbace_classes_parse_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_A"})

func init() { i := A_arbace_classes_parse_A_class.Info(); i.IsInstance = A_arbace_classes_parse_A_InstanceOf; i.Init = A_arbace_classes_parse_A_Init; i.Table = A_arbace_classes_parse_A_members }

var A_arbace_classes_parse_class_flags_A_class *jrt.Class

var A_arbace_classes_parse_class_flags_fn__662000069_A_class *jrt.Class

func A_arbace_classes_parse_eval662000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_eval662000004_A_New()}; return nil }

var A_arbace_classes_parse_eval662000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_parse_eval662000004_A_new}

var A_arbace_classes_parse_eval662000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$eval662000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_parse_A_class, Simple: "eval662000004", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000004_A"})

func init() { i := A_arbace_classes_parse_eval662000004_A_class.Info(); i.IsInstance = A_arbace_classes_parse_eval662000004_A_InstanceOf; i.Table = A_arbace_classes_parse_eval662000004_A_members }

var A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_class *jrt.Class

func A_arbace_classes_parse_eval662000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse_eval662000008_A_New()}; return nil }

var A_arbace_classes_parse_eval662000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_classes_parse_eval662000008_A_new}

var A_arbace_classes_parse_eval662000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse$eval662000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_classes_parse_A_class, Simple: "eval662000008", Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse_eval662000008_A"})

func init() { i := A_arbace_classes_parse_eval662000008_A_class.Info(); i.IsInstance = A_arbace_classes_parse_eval662000008_A_InstanceOf; i.Table = A_arbace_classes_parse_eval662000008_A_members }

var A_arbace_classes_parse_eval662000008_fn__662000009_A_class *jrt.Class

var A_arbace_classes_parse_expand_members_A_class *jrt.Class

var A_arbace_classes_parse_expand_members_expand__662000019_A_class *jrt.Class

var A_arbace_classes_parse_expand_members_expand__662000019_fn__662000020_A_class *jrt.Class

var A_arbace_classes_parse_flags_of_A_class *jrt.Class

var A_arbace_classes_parse_flags_of_fn__662000013_A_class *jrt.Class

var A_arbace_classes_parse_has_QMARK__A_class *jrt.Class

var A_arbace_classes_parse_interface_like_QMARK__A_class *jrt.Class

var A_arbace_classes_parse_kind_of_A_class *jrt.Class

var A_arbace_classes_parse_kw_meta_A_class *jrt.Class

var A_arbace_classes_parse_parse_class_A_class *jrt.Class

var A_arbace_classes_parse_parse_class_fn__662000085_A_class *jrt.Class

var A_arbace_classes_parse_parse_class_fn__662000087_A_class *jrt.Class

var A_arbace_classes_parse_parse_class_fn__662000089_A_class *jrt.Class

var A_arbace_classes_parse_parse_member_A_class *jrt.Class

var A_arbace_classes_parse_parse_member_STAR__A_class *jrt.Class

var A_arbace_classes_parse_parse_member_STAR__fn__662000055_A_class *jrt.Class

var A_arbace_classes_parse_parse_params_A_class *jrt.Class

var A_arbace_classes_parse_parse_params_fn__662000031_A_class *jrt.Class

var A_arbace_classes_parse_split_options_A_class *jrt.Class

func A_arbace_classes_parse__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_classes_parse__init_A_Load__O()}; return nil }

func A_arbace_classes_parse__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_classes_parse__init_A_New()}; return nil }

var A_arbace_classes_parse__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_classes_parse__init_A_invoke, New: A_arbace_classes_parse__init_A_new}

var A_arbace_classes_parse__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.classes.parse__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_classes_parse.A_arbace_classes_parse__init_A", Source: "parse.ae"})

func init() { i := A_arbace_classes_parse__init_A_class.Info(); i.IsInstance = A_arbace_classes_parse__init_A_InstanceOf; i.Init = A_arbace_classes_parse__init_A_Init; i.Table = A_arbace_classes_parse__init_A_members }
