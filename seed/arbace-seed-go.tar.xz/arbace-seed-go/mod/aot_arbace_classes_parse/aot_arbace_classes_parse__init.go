//line aot_arbace_classes_parse__init.ae:1
package aot_arbace_classes_parse

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_parse__init_A_Unit0__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return lang.IFn_Cast(A_arbace_classes_parse__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_classes_parse__init_A_const_1) }
//line :1:1
func A_arbace_classes_parse__init_A_Unit1__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace_NoInit(lang.Symbol_Cast(A_arbace_classes_parse__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_2)) }
//line :1:1
func A_arbace_classes_parse__init_A_Unit2__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); var tmp1 *lang.Compiler_AOTFn; var fnbody__2 any = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_16, false, nil); A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2, tmp2, nil); return Up_Compiler_AOTFn_IFn(tmp1).Invoke__O() }
//line :1:1
func A_arbace_classes_parse__init_A_Unit3__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_parse__init_A_const_1)).Equals_O__Z(A_arbace_classes_parse__init_A_const_3) { return nil } else { var tmp1 *lang.Compiler_AOTFn; var fnbody__4 any = A_arbace_classes_parse_eval662000008_fn__662000009_A_New(); var tmp2 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_classes_parse_eval662000008_fn__662000009_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_17, false, nil); A_arbace_classes_parse_eval662000008_fn__662000009_A_fn_class = fncls__3d; tmp2 = fncls__3d } else { tmp2 = fncls__3 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__4, tmp2, nil); lang.LockingTransaction_RunInTransaction_Callable__O_NoInit(Up_Compiler_AOTFn_Callable(tmp1)); return nil } }



func A_arbace_classes_parse__init_A_Load__O() any { A_arbace_classes_parse__init_A_Init(); jrt.StartCheck(); A_arbace_classes_parse__init_A_Unit0__O(); A_arbace_classes_parse__init_A_Unit1__O(); A_arbace_classes_parse__init_A_Unit2__O(); A_arbace_classes_parse__init_A_Unit3__O(); A_arbace_classes_parse__init_A_Unit4__O(); A_arbace_classes_parse__init_A_Unit5__O(); A_arbace_classes_parse__init_A_Unit6__O(); A_arbace_classes_parse__init_A_Unit7__O(); A_arbace_classes_parse__init_A_Unit8__O(); A_arbace_classes_parse__init_A_Unit9__O(); A_arbace_classes_parse__init_A_Unit10__O(); A_arbace_classes_parse__init_A_Unit11__O(); A_arbace_classes_parse__init_A_Unit12__O(); A_arbace_classes_parse__init_A_Unit13__O(); A_arbace_classes_parse__init_A_Unit14__O(); A_arbace_classes_parse__init_A_Unit15__O(); A_arbace_classes_parse__init_A_Unit16__O(); A_arbace_classes_parse__init_A_Unit17__O(); A_arbace_classes_parse__init_A_Unit18__O(); A_arbace_classes_parse__init_A_Unit19__O(); A_arbace_classes_parse__init_A_Unit20__O(); return nil }

func A_arbace_classes_parse__init_A_Unit4__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(7, 1); A_arbace_classes_parse__init_A_const_4.BindRoot_O__V(A_arbace_classes_parse__init_A_const_5); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_4; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_6)); return A_arbace_classes_parse__init_A_const_4 }

func A_arbace_classes_parse__init_A_Unit5__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(9, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_7; var tmp2 *lang.Compiler_AOTFn; var fnbody__6 any = A_arbace_classes_parse_kw_meta_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_classes_parse_kw_meta_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_18, false, nil); A_arbace_classes_parse_kw_meta_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__6, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_7; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_8)); return A_arbace_classes_parse__init_A_const_7 }

func A_arbace_classes_parse__init_A_Unit6__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(11, 1); A_arbace_classes_parse__init_A_const_9.BindRoot_O__V(A_arbace_classes_parse__init_A_const_10); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_9; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_11)); return A_arbace_classes_parse__init_A_const_9 }






func A_arbace_classes_parse__init_A_Unit7__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(18, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_12; var tmp2 *lang.Compiler_AOTFn; var fnbody__8 any = A_arbace_classes_parse_flags_of_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_classes_parse_flags_of_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_19, false, nil); A_arbace_classes_parse_flags_of_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__8, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_13)); return A_arbace_classes_parse__init_A_const_12 }





func A_arbace_classes_parse__init_A_Unit8__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(24, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_14; var tmp2 *lang.Compiler_AOTFn; var fnbody__10 any = A_arbace_classes_parse_has_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_classes_parse_has_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_20, false, nil); A_arbace_classes_parse_has_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__10, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_15)); return A_arbace_classes_parse__init_A_const_14 }

func A_arbace_classes_parse__init_A_Unit9__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(26, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_16; var tmp2 *lang.Compiler_AOTFn; var fnbody__12 any = A_arbace_classes_parse_kind_of_A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_classes_parse_kind_of_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_21, false, nil); A_arbace_classes_parse_kind_of_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__12, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_17)); return A_arbace_classes_parse__init_A_const_16 }



func A_arbace_classes_parse__init_A_Unit10__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(30, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_18; var tmp2 *lang.Compiler_AOTFn; var fnbody__14 any = A_arbace_classes_parse_split_options_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_classes_parse_split_options_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_22, false, nil); A_arbace_classes_parse_split_options_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__14, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_19)); return A_arbace_classes_parse__init_A_const_18 }







func A_arbace_classes_parse__init_A_Unit11__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(38, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_20; var tmp2 *lang.Compiler_AOTFn; var fnbody__16 any = A_arbace_classes_parse_expand_members_A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_classes_parse_expand_members_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, nil); A_arbace_classes_parse_expand_members_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__16, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_21)); return A_arbace_classes_parse__init_A_const_20 }














func A_arbace_classes_parse__init_A_Unit12__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_23)); return A_arbace_classes_parse__init_A_const_22 }
//line :53:1
func A_arbace_classes_parse__init_A_Unit13__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(53, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_24; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_25)); return A_arbace_classes_parse__init_A_const_24 }

func A_arbace_classes_parse__init_A_Unit14__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(55, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_26; var tmp2 *lang.Compiler_AOTFn; var fnbody__18 any = A_arbace_classes_parse_parse_params_A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_classes_parse_parse_params_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, nil); A_arbace_classes_parse_parse_params_A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__18, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_27)); return A_arbace_classes_parse__init_A_const_26 }






func A_arbace_classes_parse__init_A_Unit15__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(62, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_28; var tmp2 any; var root_19 any = A_arbace_classes_parse__init_A_const_29.GetRawRoot__O(); var linked_20 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_19, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_21 lang.IFn; if linked_20 == nil { ifn_21 = lang.IFn_Cast(root_19) } else { ifn_21 = nil }; var arg_22 any = A_arbace_classes_parse__init_A_const_30; if linked_20 == nil { tmp2 = ifn_21.Invoke_O__O(arg_22) } else { tmp2 = linked_20.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_19, arg_22) }; tmp1.BindRoot_O__V(tmp2); var tmp3 *lang.Var = A_arbace_classes_parse__init_A_const_28; tmp3.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_31)); return A_arbace_classes_parse__init_A_const_28 }

func A_arbace_classes_parse__init_A_Unit16__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(64, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_32; var tmp2 *lang.Compiler_AOTFn; var fnbody__24 any = A_arbace_classes_parse_parse_member_A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_classes_parse_parse_member_A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_25, false, nil); A_arbace_classes_parse_parse_member_A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__24, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_32; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_33)); return A_arbace_classes_parse__init_A_const_32 }





func A_arbace_classes_parse__init_A_Unit17__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(70, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_24; var tmp2 *lang.Compiler_AOTFn; var fnbody__26 any = A_arbace_classes_parse_parse_member_STAR__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_classes_parse_parse_member_STAR__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, nil); A_arbace_classes_parse_parse_member_STAR__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__26, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_34)); return A_arbace_classes_parse__init_A_const_24 }


































func A_arbace_classes_parse__init_A_Unit18__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(105, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_35; var tmp2 *lang.Compiler_AOTFn; var fnbody__28 any = A_arbace_classes_parse_interface_like_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_classes_parse_interface_like_QMARK__A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_27, false, nil); A_arbace_classes_parse_interface_like_QMARK__A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__28, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_35; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_36)); return A_arbace_classes_parse__init_A_const_35 }

func A_arbace_classes_parse__init_A_Unit19__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(107, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_37; var tmp2 *lang.Compiler_AOTFn; var fnbody__30 any = A_arbace_classes_parse_class_flags_A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_classes_parse_class_flags_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_28, false, nil); A_arbace_classes_parse_class_flags_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__30, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_37; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_38)); return A_arbace_classes_parse__init_A_const_37 }

































func A_arbace_classes_parse__init_A_Unit20__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V_NoInit(141, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_22; var tmp2 *lang.Compiler_AOTFn; var fnbody__32 any = A_arbace_classes_parse_parse_class_A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_classes_parse_parse_class_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_29, false, nil); A_arbace_classes_parse_parse_class_A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__32, tmp3, nil); tmp1.BindRoot_O__V(tmp2.Ref()); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_22; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_39)); return A_arbace_classes_parse__init_A_const_22 }



type A_arbace_classes_parse__init_A struct{ jrt.Object }

var A_arbace_classes_parse__init_A_const_pool *jrt.RefArray

var A_arbace_classes_parse__init_A_const_0 *lang.Var

var A_arbace_classes_parse__init_A_const_1 any

var A_arbace_classes_parse__init_A_const_2 any

var A_arbace_classes_parse__init_A_const_3 any

var A_arbace_classes_parse__init_A_const_4 *lang.Var

var A_arbace_classes_parse__init_A_const_5 any

var A_arbace_classes_parse__init_A_const_6 any

var A_arbace_classes_parse__init_A_const_7 *lang.Var

var A_arbace_classes_parse__init_A_const_8 any

var A_arbace_classes_parse__init_A_const_9 *lang.Var

var A_arbace_classes_parse__init_A_const_10 any

var A_arbace_classes_parse__init_A_const_11 any

var A_arbace_classes_parse__init_A_const_12 *lang.Var

var A_arbace_classes_parse__init_A_const_13 any

var A_arbace_classes_parse__init_A_const_14 *lang.Var

var A_arbace_classes_parse__init_A_const_15 any

var A_arbace_classes_parse__init_A_const_16 *lang.Var

var A_arbace_classes_parse__init_A_const_17 any

var A_arbace_classes_parse__init_A_const_18 *lang.Var

var A_arbace_classes_parse__init_A_const_19 any

var A_arbace_classes_parse__init_A_const_20 *lang.Var

var A_arbace_classes_parse__init_A_const_21 any

var A_arbace_classes_parse__init_A_const_22 *lang.Var

var A_arbace_classes_parse__init_A_const_23 any

var A_arbace_classes_parse__init_A_const_24 *lang.Var

var A_arbace_classes_parse__init_A_const_25 any

var A_arbace_classes_parse__init_A_const_26 *lang.Var

var A_arbace_classes_parse__init_A_const_27 any

var A_arbace_classes_parse__init_A_const_28 *lang.Var

var A_arbace_classes_parse__init_A_const_29 *lang.Var

var A_arbace_classes_parse__init_A_const_30 any

var A_arbace_classes_parse__init_A_const_31 any

var A_arbace_classes_parse__init_A_const_32 *lang.Var

var A_arbace_classes_parse__init_A_const_33 any

var A_arbace_classes_parse__init_A_const_34 any

var A_arbace_classes_parse__init_A_const_35 *lang.Var

var A_arbace_classes_parse__init_A_const_36 any

var A_arbace_classes_parse__init_A_const_37 *lang.Var

var A_arbace_classes_parse__init_A_const_38 any

var A_arbace_classes_parse__init_A_const_39 any

var A_arbace_classes_parse__init_A_init jrt.ClassInit

func A_arbace_classes_parse__init_A_Init() { if !A_arbace_classes_parse__init_A_init.Done() { A_arbace_classes_parse__init_A_init.Run(A_arbace_classes_parse__init_A_clinit) } }

func A_arbace_classes_parse__init_A_clinit() { A_arbace_classes_parse__init_A_clinit_p0(); A_arbace_classes_parse__init_A_clinit_p1(); A_arbace_classes_parse__init_A_clinit_p2() }

func A_arbace_classes_parse__init_A_clinit_p0() { jrt.StartCheck(); A_arbace_classes_parse__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_15, 88); A_arbace_classes_parse__init_A_const_0 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[48]); A_arbace_classes_parse__init_A_const_1 = A_arbace_classes_parse__init_A_const_pool.A[49]; A_arbace_classes_parse__init_A_const_2 = A_arbace_classes_parse__init_A_const_pool.A[50]; A_arbace_classes_parse__init_A_const_3 = A_arbace_classes_parse__init_A_const_pool.A[51]; A_arbace_classes_parse__init_A_const_4 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[52]); A_arbace_classes_parse__init_A_const_5 = A_arbace_classes_parse__init_A_const_pool.A[53]; A_arbace_classes_parse__init_A_const_6 = A_arbace_classes_parse__init_A_const_pool.A[54]; A_arbace_classes_parse__init_A_const_7 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[55]); A_arbace_classes_parse__init_A_const_8 = A_arbace_classes_parse__init_A_const_pool.A[56]; A_arbace_classes_parse__init_A_const_9 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[57]); A_arbace_classes_parse__init_A_const_10 = A_arbace_classes_parse__init_A_const_pool.A[58]; A_arbace_classes_parse__init_A_const_11 = A_arbace_classes_parse__init_A_const_pool.A[59]; A_arbace_classes_parse__init_A_const_12 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[60]) }

func A_arbace_classes_parse__init_A_clinit_p1() { A_arbace_classes_parse__init_A_const_13 = A_arbace_classes_parse__init_A_const_pool.A[61]; A_arbace_classes_parse__init_A_const_14 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[62]); A_arbace_classes_parse__init_A_const_15 = A_arbace_classes_parse__init_A_const_pool.A[63]; A_arbace_classes_parse__init_A_const_16 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[64]); A_arbace_classes_parse__init_A_const_17 = A_arbace_classes_parse__init_A_const_pool.A[65]; A_arbace_classes_parse__init_A_const_18 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[66]); A_arbace_classes_parse__init_A_const_19 = A_arbace_classes_parse__init_A_const_pool.A[67]; A_arbace_classes_parse__init_A_const_20 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[68]); A_arbace_classes_parse__init_A_const_21 = A_arbace_classes_parse__init_A_const_pool.A[69]; A_arbace_classes_parse__init_A_const_22 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[70]); A_arbace_classes_parse__init_A_const_23 = A_arbace_classes_parse__init_A_const_pool.A[71]; A_arbace_classes_parse__init_A_const_24 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[72]); A_arbace_classes_parse__init_A_const_25 = A_arbace_classes_parse__init_A_const_pool.A[73] }

func A_arbace_classes_parse__init_A_clinit_p2() { A_arbace_classes_parse__init_A_const_26 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[74]); A_arbace_classes_parse__init_A_const_27 = A_arbace_classes_parse__init_A_const_pool.A[75]; A_arbace_classes_parse__init_A_const_28 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[76]); A_arbace_classes_parse__init_A_const_29 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[77]); A_arbace_classes_parse__init_A_const_30 = A_arbace_classes_parse__init_A_const_pool.A[78]; A_arbace_classes_parse__init_A_const_31 = A_arbace_classes_parse__init_A_const_pool.A[79]; A_arbace_classes_parse__init_A_const_32 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[80]); A_arbace_classes_parse__init_A_const_33 = A_arbace_classes_parse__init_A_const_pool.A[81]; A_arbace_classes_parse__init_A_const_34 = A_arbace_classes_parse__init_A_const_pool.A[82]; A_arbace_classes_parse__init_A_const_35 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[83]); A_arbace_classes_parse__init_A_const_36 = A_arbace_classes_parse__init_A_const_pool.A[84]; A_arbace_classes_parse__init_A_const_37 = lang.Var_Cast(A_arbace_classes_parse__init_A_const_pool.A[85]); A_arbace_classes_parse__init_A_const_38 = A_arbace_classes_parse__init_A_const_pool.A[86]; A_arbace_classes_parse__init_A_const_39 = A_arbace_classes_parse__init_A_const_pool.A[87] }

func A_arbace_classes_parse__init_A_New() *A_arbace_classes_parse__init_A { A_arbace_classes_parse__init_A_Init(); t := &A_arbace_classes_parse__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_parse__init_A) Ctor() {}

func (t *A_arbace_classes_parse__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse__init_A_class }

func (t *A_arbace_classes_parse__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse__init_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_classes_parse__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse__init_A); return ok }

func A_arbace_classes_parse__init_A_Cast(x any) *A_arbace_classes_parse__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse__init_A_class)) }; return v }
