//line aot_arbace_classes_parse__init.ae:1
package aot_arbace_classes_parse

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_classes_parse__init_A_Unit0__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_classes_parse__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_parse__init_A_const_1) }
//line :1:1
func A_arbace_classes_parse__init_A_Unit1__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_classes_parse__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_2)) }
//line :1:1
func A_arbace_classes_parse__init_A_Unit2__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_New(); var tmp2 *jrt.Class; A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_Init(); tmp2 = A_arbace_classes_parse_eval662000004_loading__1927001464__auto____662000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_classes_parse__init_A_Unit3__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_classes_parse__init_A_const_1)).Equals_O__Z(A_arbace_classes_parse__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_classes_parse_eval662000008_fn__662000009_A_New(); var tmp2 *jrt.Class; A_arbace_classes_parse_eval662000008_fn__662000009_A_Init(); tmp2 = A_arbace_classes_parse_eval662000008_fn__662000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_classes_parse__init_A_Load__O() any { A_arbace_classes_parse__init_A_Init(); A_arbace_classes_parse__init_A_Unit0__O(); A_arbace_classes_parse__init_A_Unit1__O(); A_arbace_classes_parse__init_A_Unit2__O(); A_arbace_classes_parse__init_A_Unit3__O(); A_arbace_classes_parse__init_A_Unit4__O(); A_arbace_classes_parse__init_A_Unit5__O(); A_arbace_classes_parse__init_A_Unit6__O(); A_arbace_classes_parse__init_A_Unit7__O(); A_arbace_classes_parse__init_A_Unit8__O(); A_arbace_classes_parse__init_A_Unit9__O(); A_arbace_classes_parse__init_A_Unit10__O(); A_arbace_classes_parse__init_A_Unit11__O(); A_arbace_classes_parse__init_A_Unit12__O(); A_arbace_classes_parse__init_A_Unit13__O(); A_arbace_classes_parse__init_A_Unit14__O(); A_arbace_classes_parse__init_A_Unit15__O(); A_arbace_classes_parse__init_A_Unit16__O(); A_arbace_classes_parse__init_A_Unit17__O(); A_arbace_classes_parse__init_A_Unit18__O(); A_arbace_classes_parse__init_A_Unit19__O(); A_arbace_classes_parse__init_A_Unit20__O(); return nil }

func A_arbace_classes_parse__init_A_Unit4__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(7, 1); jrt.NN(A_arbace_classes_parse__init_A_const_4).BindRoot_O__V(A_arbace_classes_parse__init_A_const_5); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_4; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_6)); return A_arbace_classes_parse__init_A_const_4.Ref() }

func A_arbace_classes_parse__init_A_Unit5__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_7; var tmp2 any = A_arbace_classes_parse_kw_meta_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_kw_meta_A_Init(); tmp3 = A_arbace_classes_parse_kw_meta_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_7; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_8)); return A_arbace_classes_parse__init_A_const_7.Ref() }

func A_arbace_classes_parse__init_A_Unit6__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(11, 1); jrt.NN(A_arbace_classes_parse__init_A_const_9).BindRoot_O__V(A_arbace_classes_parse__init_A_const_10); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_9; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_11)); return A_arbace_classes_parse__init_A_const_9.Ref() }






func A_arbace_classes_parse__init_A_Unit7__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(18, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_12; var tmp2 any = A_arbace_classes_parse_flags_of_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_flags_of_A_Init(); tmp3 = A_arbace_classes_parse_flags_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_13)); return A_arbace_classes_parse__init_A_const_12.Ref() }





func A_arbace_classes_parse__init_A_Unit8__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(24, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_14; var tmp2 any = A_arbace_classes_parse_has_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_has_QMARK__A_Init(); tmp3 = A_arbace_classes_parse_has_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_15)); return A_arbace_classes_parse__init_A_const_14.Ref() }

func A_arbace_classes_parse__init_A_Unit9__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(26, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_16; var tmp2 any = A_arbace_classes_parse_kind_of_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_kind_of_A_Init(); tmp3 = A_arbace_classes_parse_kind_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_17)); return A_arbace_classes_parse__init_A_const_16.Ref() }



func A_arbace_classes_parse__init_A_Unit10__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(30, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_18; var tmp2 any = A_arbace_classes_parse_split_options_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_split_options_A_Init(); tmp3 = A_arbace_classes_parse_split_options_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_19)); return A_arbace_classes_parse__init_A_const_18.Ref() }







func A_arbace_classes_parse__init_A_Unit11__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(38, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_20; var tmp2 any = A_arbace_classes_parse_expand_members_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_expand_members_A_Init(); tmp3 = A_arbace_classes_parse_expand_members_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_21)); return A_arbace_classes_parse__init_A_const_20.Ref() }














func A_arbace_classes_parse__init_A_Unit12__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_22; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_23)); return A_arbace_classes_parse__init_A_const_22.Ref() }
//line :53:1
func A_arbace_classes_parse__init_A_Unit13__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(53, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_24; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_25)); return A_arbace_classes_parse__init_A_const_24.Ref() }

func A_arbace_classes_parse__init_A_Unit14__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(55, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_26; var tmp2 any = A_arbace_classes_parse_parse_params_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_parse_params_A_Init(); tmp3 = A_arbace_classes_parse_parse_params_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_27)); return A_arbace_classes_parse__init_A_const_26.Ref() }






func A_arbace_classes_parse__init_A_Unit15__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(62, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_28; jrt.NN(tmp1).BindRoot_O__V(lang.IFn_Cast(jrt.NN(A_arbace_classes_parse__init_A_const_29).GetRawRoot__O()).Invoke_O__O(A_arbace_classes_parse__init_A_const_31)); var tmp2 *lang.Var = A_arbace_classes_parse__init_A_const_28; jrt.NN(tmp2).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_30)); return A_arbace_classes_parse__init_A_const_28.Ref() }

func A_arbace_classes_parse__init_A_Unit16__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_32; var tmp2 any = A_arbace_classes_parse_parse_member_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_parse_member_A_Init(); tmp3 = A_arbace_classes_parse_parse_member_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_32; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_33)); return A_arbace_classes_parse__init_A_const_32.Ref() }





func A_arbace_classes_parse__init_A_Unit17__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_24; var tmp2 any = A_arbace_classes_parse_parse_member_STAR__A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_parse_member_STAR__A_Init(); tmp3 = A_arbace_classes_parse_parse_member_STAR__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_34)); return A_arbace_classes_parse__init_A_const_24.Ref() }




























func A_arbace_classes_parse__init_A_Unit18__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_35; var tmp2 any = A_arbace_classes_parse_interface_like_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_interface_like_QMARK__A_Init(); tmp3 = A_arbace_classes_parse_interface_like_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_35; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_36)); return A_arbace_classes_parse__init_A_const_35.Ref() }

func A_arbace_classes_parse__init_A_Unit19__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(101, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_37; var tmp2 any = A_arbace_classes_parse_class_flags_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_class_flags_A_Init(); tmp3 = A_arbace_classes_parse_class_flags_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_37; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_38)); return A_arbace_classes_parse__init_A_const_37.Ref() }

































func A_arbace_classes_parse__init_A_Unit20__O() any { A_arbace_classes_parse__init_A_Init(); lang.Compiler_AOT_At_I_I__V(135, 1); var tmp1 *lang.Var = A_arbace_classes_parse__init_A_const_22; var tmp2 any = A_arbace_classes_parse_parse_class_A_New(); var tmp3 *jrt.Class; A_arbace_classes_parse_parse_class_A_Init(); tmp3 = A_arbace_classes_parse_parse_class_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_classes_parse__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_classes_parse__init_A_const_39)); return A_arbace_classes_parse__init_A_const_22.Ref() }



type A_arbace_classes_parse__init_A struct{ jrt.Object }

var A_arbace_classes_parse__init_A_const_0 *lang.Var

var A_arbace_classes_parse__init_A_const_1 any

var A_arbace_classes_parse__init_A_const_2 any

var A_arbace_classes_parse__init_A_const_3 any

var A_arbace_classes_parse__init_A_const_4 *lang.Var

var A_arbace_classes_parse__init_A_const_5 any

var A_arbace_classes_parse__init_A_const_6 any

var A_arbace_classes_parse__init_A_const_7 *lang.Var

var A_arbace_classes_parse__init_A_const_8 any

var A_arbace_classes_parse__init_A_const_9 *lang.Var

var A_arbace_classes_parse__init_A_const_10 any

var A_arbace_classes_parse__init_A_const_11 any

var A_arbace_classes_parse__init_A_const_12 *lang.Var

var A_arbace_classes_parse__init_A_const_13 any

var A_arbace_classes_parse__init_A_const_14 *lang.Var

var A_arbace_classes_parse__init_A_const_15 any

var A_arbace_classes_parse__init_A_const_16 *lang.Var

var A_arbace_classes_parse__init_A_const_17 any

var A_arbace_classes_parse__init_A_const_18 *lang.Var

var A_arbace_classes_parse__init_A_const_19 any

var A_arbace_classes_parse__init_A_const_20 *lang.Var

var A_arbace_classes_parse__init_A_const_21 any

var A_arbace_classes_parse__init_A_const_22 *lang.Var

var A_arbace_classes_parse__init_A_const_23 any

var A_arbace_classes_parse__init_A_const_24 *lang.Var

var A_arbace_classes_parse__init_A_const_25 any

var A_arbace_classes_parse__init_A_const_26 *lang.Var

var A_arbace_classes_parse__init_A_const_27 any

var A_arbace_classes_parse__init_A_const_28 *lang.Var

var A_arbace_classes_parse__init_A_const_29 *lang.Var

var A_arbace_classes_parse__init_A_const_30 any

var A_arbace_classes_parse__init_A_const_31 any

var A_arbace_classes_parse__init_A_const_32 *lang.Var

var A_arbace_classes_parse__init_A_const_33 any

var A_arbace_classes_parse__init_A_const_34 any

var A_arbace_classes_parse__init_A_const_35 *lang.Var

var A_arbace_classes_parse__init_A_const_36 any

var A_arbace_classes_parse__init_A_const_37 *lang.Var

var A_arbace_classes_parse__init_A_const_38 any

var A_arbace_classes_parse__init_A_const_39 any

var A_arbace_classes_parse__init_A_init jrt.ClassInit

func A_arbace_classes_parse__init_A_Init() { if !A_arbace_classes_parse__init_A_init.Done() { A_arbace_classes_parse__init_A_init.Run(A_arbace_classes_parse__init_A_clinit) } }

func A_arbace_classes_parse__init_A_clinit() { A_arbace_classes_parse__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_153); A_arbace_classes_parse__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_11)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13))); A_arbace_classes_parse__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_13)); A_arbace_classes_parse__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_classes_parse__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_11, Lit_34); A_arbace_classes_parse__init_A_const_5 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_80).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_33).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_63).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_67).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_69).Ref())).Ref(); A_arbace_classes_parse__init_A_const_6 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(7).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_7 = lang.RT_Var_String_String__Var(Lit_11, Lit_157); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_classes_parse__init_A_const_8 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_160).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(9).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_9 = lang.RT_Var_String_String__Var(Lit_11, Lit_16); A_arbace_classes_parse__init_A_const_10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_96).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(), jrt.Integer_ValueOf_I__Integer(2).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_97).Ref(), jrt.Integer_ValueOf_I__Integer(4).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_99).Ref(), jrt.Integer_ValueOf_I__Integer(8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_103).Ref(), jrt.Integer_ValueOf_I__Integer(16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_104).Ref(), jrt.Integer_ValueOf_I__Integer(1024).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_161).Ref(), jrt.Integer_ValueOf_I__Integer(32).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_162).Ref(), jrt.Integer_ValueOf_I__Integer(256).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_163).Ref(), jrt.Integer_ValueOf_I__Integer(128).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_164).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_105).Ref(), jrt.Integer_ValueOf_I__Integer(4096).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_165).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref())); A_arbace_classes_parse__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(11).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_11, Lit_166); A_arbace_classes_parse__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_167).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_168, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_11, Lit_106); A_arbace_classes_parse__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_169).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(24).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_11, Lit_110); A_arbace_classes_parse__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_159).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(26).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_11, Lit_65); A_arbace_classes_parse__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_170).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_171, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(30).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_11, Lit_117); A_arbace_classes_parse__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_172).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_173, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_11, Lit_174); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_classes_parse__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_11, Lit_58); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_175).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_classes_parse__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(53).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_11, Lit_70); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_classes_parse__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_176).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_11, Lit_61); A_arbace_classes_parse__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_177); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_classes_parse__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_31 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_classes_parse__init_A_const_32 = lang.RT_Var_String_String__Var(Lit_11, Lit_116); A_arbace_classes_parse__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_169).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_178, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_classes_parse__init_A_const_34 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_169).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_35 = lang.RT_Var_String_String__Var(Lit_11, Lit_95); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_98).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_classes_parse__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(99).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_37 = lang.RT_Var_String_String__Var(Lit_11, Lit_124); A_arbace_classes_parse__init_A_const_38 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(), lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_68).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_75).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_91).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_92).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_71).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_93).Ref()), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_179).Ref())))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_180, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(101).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)); A_arbace_classes_parse__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_158).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_181).Ref(), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_182).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_55).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_183).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_12).Ref(), Lit_184, lang.RT_Keyword_String_String__Keyword(nil, Lit_57).Ref(), jrt.Integer_ValueOf_I__Integer(135).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_154).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_155).Ref(), Lit_156)) }

func A_arbace_classes_parse__init_A_New() *A_arbace_classes_parse__init_A { A_arbace_classes_parse__init_A_Init(); t := &A_arbace_classes_parse__init_A{}; t.Ctor(); return t }

func (t *A_arbace_classes_parse__init_A) Ctor() {}

func (t *A_arbace_classes_parse__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_classes_parse__init_A) GetClass__Class() *jrt.Class { return A_arbace_classes_parse__init_A_class }

func (t *A_arbace_classes_parse__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_classes_parse__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_classes_parse__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_classes_parse__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_classes_parse__init_A); return ok }

func A_arbace_classes_parse__init_A_Cast(x any) *A_arbace_classes_parse__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_classes_parse__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_classes_parse__init_A_class)) }; return v }
