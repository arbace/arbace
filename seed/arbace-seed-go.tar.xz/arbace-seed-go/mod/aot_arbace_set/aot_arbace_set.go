//line aot_arbace_set.ae:1
package aot_arbace_set

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_New() *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A { A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_Init(); t := &A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp7 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_1; tmp3 = tmp5.Invoke_O__O(tmp6) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp7 != nil { panic(tmp7) }; return tmp3 }
//line :9:1
func A_arbace_set_eval1726000008_fn__1726000009_A_New() *A_arbace_set_eval1726000008_fn__1726000009_A { A_arbace_set_eval1726000008_fn__1726000009_A_Init(); t := &A_arbace_set_eval1726000008_fn__1726000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_set_A_Init(); tmp7 = A_arbace_set_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_set_A_Init(); tmp9 = A_arbace_set_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }



func A_arbace_set_bubble_max_key_A_New() *A_arbace_set_bubble_max_key_A { A_arbace_set_bubble_max_key_A_Init(); t := &A_arbace_set_bubble_max_key_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Ctor() {}
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Invoke_O_O_O__O(self, k__0, coll__1 any) any { var max__3 any; var tmp1 *lang.Var;



	A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_9; max__3 = tmp2.Invoke_O_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), k__0, coll__1); var tmp4 /*line :18:1*/*lang.Var; A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_8; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_10; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 any = A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(max__3); var tmp9 *jrt.Class; A_arbace_set_bubble_max_key_fn__1726000013_A_Init(); tmp9 = A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class; return tmp5.Invoke_O_O__O(max__3, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), coll__1)) }
//line :18:1
func A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(p0 any) *A_arbace_set_bubble_max_key_fn__1726000013_A { A_arbace_set_bubble_max_key_fn__1726000013_A_Init(); t := &A_arbace_set_bubble_max_key_fn__1726000013_A{}; t.Ctor_O(p0); return t }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Ctor_O(c__max any) { t.F_max = c__max }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Invoke_O_O__O(self, p1__1726000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Identical_O_O__Z(t.F_max, p1__1726000012_SHARP___1)).Ref() }

func A_arbace_set_union_A_New() *A_arbace_set_union_A { A_arbace_set_union_A_Init(); t := &A_arbace_set_union_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_set_union_A) Ctor() {}
//line :20:1
func (t *A_arbace_set_union_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var tmp1 *lang.Var;









	A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_13; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_4; bubbled_sets__4 = tmp2.Invoke_O_O__O(tmp4, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0)); var tmp6 /*line :31:1*/*lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_12; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_set_A_Init(); tmp8 = A_arbace_set_A_const_14; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 *lang.Var; A_arbace_set_A_Init(); tmp10 = A_arbace_set_A_const_15; var tmp11 any = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(bubbled_sets__4); var tmp12 *lang.Var; A_arbace_set_A_Init(); tmp12 = A_arbace_set_A_const_16; return tmp7.Invoke_O_O_O__O(tmp9, tmp11, lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(bubbled_sets__4)) }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {





	if lang.Numbers_Lt_J_J__Z(int64(lang.RT_Count_O__I(s1__0)), int64(lang.RT_Count_O__I(s2__1))) {
		var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_4; return tmp2.Invoke_O_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), s2__1, s1__0) } else {
			var tmp4 *lang.Var; A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_12; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_4; return tmp5.Invoke_O_O_O__O(jrt.NN(tmp6).GetRawRoot__O(), s1__0, s2__1) } }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O__O(self any) any { lang.PersistentHashSet_Init(); return lang.PersistentHashSet_EMPTY.Ref() }












func A_arbace_set_intersection_A_New() *A_arbace_set_intersection_A { A_arbace_set_intersection_A_Init(); t := &A_arbace_set_intersection_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_set_intersection_A) Ctor() {}
//line :33:1
func (t *A_arbace_set_intersection_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var tmp1 *lang.Var;












	A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_11; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_intersection_fn__1726000020_A_New(); var tmp4 *jrt.Class; A_arbace_set_intersection_fn__1726000020_A_Init(); tmp4 = A_arbace_set_intersection_fn__1726000020_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_4; bubbled_sets__4 = tmp2.Invoke_O_O__O(tmp5, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0)); var tmp7 /*line :47:1*/*lang.Var; A_arbace_set_A_Init(); tmp7 = A_arbace_set_A_const_12; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_set_A_Init(); tmp9 = A_arbace_set_A_const_17; var tmp10 any = jrt.NN(tmp9).GetRawRoot__O(); var tmp11 *lang.Var; A_arbace_set_A_Init(); tmp11 = A_arbace_set_A_const_15; var tmp12 any = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(bubbled_sets__4); var tmp13 *lang.Var; A_arbace_set_A_Init(); tmp13 = A_arbace_set_A_const_16; return tmp8.Invoke_O_O_O__O(tmp10, tmp12, lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(bubbled_sets__4)) }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any { { var s1__0_2 any = s1__0; var s2__1_2 any = s2__1; L1: for {




	if lang.Numbers_Lt_J_J__Z(int64(lang.RT_Count_O__I(s2__1_2)), int64(lang.RT_Count_O__I(s1__0_2))) {
		s1__0_2, s2__1_2 = s2__1_2, s1__0_2; continue L1 } else {
			var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_intersection_fn__1726000018_A_New_O(s2__1_2); var tmp4 *jrt.Class; A_arbace_set_intersection_fn__1726000018_A_Init(); tmp4 = A_arbace_set_intersection_fn__1726000018_A_fn_class; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), s1__0_2, s1__0_2) } } }; /*line :33:1*/panic("a2g: unreachable") }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }






func A_arbace_set_intersection_fn__1726000018_A_New_O(p0 any) *A_arbace_set_intersection_fn__1726000018_A { A_arbace_set_intersection_fn__1726000018_A_Init(); t := &A_arbace_set_intersection_fn__1726000018_A{}; t.Ctor_O(p0); return t }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_s2, item__2)) { return result__1 } else {

		var tmp2 *lang.Var; A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_19; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(result__1, item__2)
	}
}
func A_arbace_set_intersection_fn__1726000020_A_New() *A_arbace_set_intersection_fn__1726000020_A { A_arbace_set_intersection_fn__1726000020_A_Init(); t := &A_arbace_set_intersection_fn__1726000020_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Ctor() {}
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Invoke_O_O__O(self, p1__1726000017_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long(lang.Numbers_Minus_J__J(int64(lang.RT_Count_O__I(p1__1726000017_SHARP___1)))).Ref() }


func A_arbace_set_difference_A_New() *A_arbace_set_difference_A { A_arbace_set_difference_A_Init(); t := &A_arbace_set_difference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_set_difference_A) Ctor() {}
//line :49:1
func (t *A_arbace_set_difference_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any {












	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_20; var tmp4 any = jrt.NN(tmp3).GetRawRoot__O(); var tmp5 *lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_4; return tmp2.Invoke_O_O_O__O(tmp4, s1__0, lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O_O__O(sets__2, s2__1)) }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {




	if lang.Numbers_Lt_J_J__Z(int64(lang.RT_Count_O__I(s1__0)), int64(lang.RT_Count_O__I(s2__1))) {
		var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_difference_fn__1726000023_A_New_O(s2__1); var tmp4 *jrt.Class; A_arbace_set_difference_fn__1726000023_A_Init(); tmp4 = A_arbace_set_difference_fn__1726000023_A_fn_class; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), s1__0, s1__0) } else {




			var tmp5 *lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_12; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_set_A_Init(); tmp7 = A_arbace_set_A_const_19; return tmp6.Invoke_O_O_O__O(jrt.NN(tmp7).GetRawRoot__O(), s1__0, s2__1) } }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }





func A_arbace_set_difference_fn__1726000023_A_New_O(p0 any) *A_arbace_set_difference_fn__1726000023_A { A_arbace_set_difference_fn__1726000023_A_Init(); t := &A_arbace_set_difference_fn__1726000023_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_s2, item__2)) {
		var tmp2 *lang.Var; A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_19; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(result__1, item__2) } else {
//line :56:1
			return result__1
		}
}





func A_arbace_set_select_A_New() *A_arbace_set_select_A { A_arbace_set_select_A_Init(); t := &A_arbace_set_select_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_set_select_A) Ctor() {}
//line :64:1
func (t *A_arbace_set_select_A) Invoke_O_O_O__O(self, pred__0, xset__1 any) any {



	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_select_fn__1726000026_A_New_O(pred__0); var tmp4 *jrt.Class; A_arbace_set_select_fn__1726000026_A_Init(); tmp4 = A_arbace_set_select_fn__1726000026_A_fn_class; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), xset__1, xset__1) }
//line :68:1
func A_arbace_set_select_fn__1726000026_A_New_O(p0 any) *A_arbace_set_select_fn__1726000026_A { A_arbace_set_select_fn__1726000026_A_Init(); t := &A_arbace_set_select_fn__1726000026_A{}; t.Ctor_O(p0); return t }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Invoke_O_O_O__O(self, s__1, k__2 any) any { if jrt.A2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(k__2)) { return s__1 } else { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_19; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(s__1, k__2) } }


func A_arbace_set_project_A_New() *A_arbace_set_project_A { A_arbace_set_project_A_Init(); t := &A_arbace_set_project_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_set_project_A) Ctor() {}
//line :71:1
func (t *A_arbace_set_project_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {



	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_22; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_23; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_set_project_fn__1726000030_A_New_O(ks__1); var tmp8 *jrt.Class; A_arbace_set_project_fn__1726000030_A_Init(); tmp8 = A_arbace_set_project_fn__1726000030_A_fn_class; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), xrel__0)), lang.RT_Meta_O__IPersistentMap(xrel__0)) }
//line :75:1
func A_arbace_set_project_fn__1726000030_A_New_O(p0 any) *A_arbace_set_project_fn__1726000030_A { A_arbace_set_project_fn__1726000030_A_Init(); t := &A_arbace_set_project_fn__1726000030_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Invoke_O_O__O(self, p1__1726000029_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_24; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__1726000029_SHARP___1, t.F_ks) }

func A_arbace_set_rename_keys_A_New() *A_arbace_set_rename_keys_A { A_arbace_set_rename_keys_A_Init(); t := &A_arbace_set_rename_keys_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_set_rename_keys_A) Ctor() {}
//line :77:1
func (t *A_arbace_set_rename_keys_A) Invoke_O_O_O__O(self, map__0, kmap__1 any) any {



	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_rename_keys_fn__1726000034_A_New_O(map__0); var tmp4 *jrt.Class; A_arbace_set_rename_keys_fn__1726000034_A_Init(); tmp4 = A_arbace_set_rename_keys_fn__1726000034_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_7; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_set_A_Init(); tmp8 = A_arbace_set_A_const_26; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 *lang.Var; A_arbace_set_A_Init(); tmp10 = A_arbace_set_A_const_27; return tmp2.Invoke_O_O_O__O(tmp5, tmp7.Invoke_O_O_O__O(tmp9, map__0, lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(kmap__1)), kmap__1) }
func A_arbace_set_rename_keys_fn__1726000034_A_New_O(p0 any) *A_arbace_set_rename_keys_fn__1726000034_A { A_arbace_set_rename_keys_fn__1726000034_A_Init(); t := &A_arbace_set_rename_keys_fn__1726000034_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Ctor_O(c__map any) { t.F_map = c__map }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Invoke_O_O_O__O(self, m__1, p__1726000033__2 any) any { var vec__1726000035__3 any = p__1726000033__2; var old__4 any = lang.RT_Nth_O_I_O__O(vec__1726000035__3, lang.RT_IntCast_J__I(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O(vec__1726000035__3, lang.RT_IntCast_J__I(1), nil); var tmp1 *lang.Var;
														A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_18; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_map, old__4)) {
															var tmp2 *lang.Var; A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_25; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O_O__O(m__1, new__5, lang.RT_Get_O_O__O(t.F_map, old__4)) } else {
//line :83:1
			return m__1 } }




func A_arbace_set_rename_A_New() *A_arbace_set_rename_A { A_arbace_set_rename_A_Init(); t := &A_arbace_set_rename_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_set_rename_A) Ctor() {}
//line :88:1
func (t *A_arbace_set_rename_A) Invoke_O_O_O__O(self, xrel__0, kmap__1 any) any {



	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_21; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_22; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_23; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_set_rename_fn__1726000041_A_New_O(kmap__1); var tmp8 *jrt.Class; A_arbace_set_rename_fn__1726000041_A_Init(); tmp8 = A_arbace_set_rename_fn__1726000041_A_fn_class; return tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), xrel__0)), lang.RT_Meta_O__IPersistentMap(xrel__0)) }
//line :92:1
func A_arbace_set_rename_fn__1726000041_A_New_O(p0 any) *A_arbace_set_rename_fn__1726000041_A { A_arbace_set_rename_fn__1726000041_A_Init(); t := &A_arbace_set_rename_fn__1726000041_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Ctor_O(c__kmap any) { t.F_kmap = c__kmap }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Invoke_O_O__O(self, p1__1726000040_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_28; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__1726000040_SHARP___1, t.F_kmap) }

func A_arbace_set_index_A_New() *A_arbace_set_index_A { A_arbace_set_index_A_Init(); t := &A_arbace_set_index_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_set_index_A) Ctor() {}
//line :94:1
func (t *A_arbace_set_index_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {




	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_index_fn__1726000044_A_New_O(ks__1); var tmp4 *jrt.Class; A_arbace_set_index_fn__1726000044_A_Init(); tmp4 = A_arbace_set_index_fn__1726000044_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp6 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O_O_O__O(tmp5, tmp6.Ref(), xrel__0) }
func A_arbace_set_index_fn__1726000044_A_New_O(p0 any) *A_arbace_set_index_fn__1726000044_A { A_arbace_set_index_fn__1726000044_A_Init(); t := &A_arbace_set_index_fn__1726000044_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Invoke_O_O_O__O(self, m__1, x__2 any) any { var ik__3 any; var tmp1 *lang.Var;
											A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_24; ik__3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(x__2, t.F_ks); var tmp2 /*line :102:1*/*lang.Var; A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_25; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_4; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp6 = lang.PersistentHashSet_EMPTY; return tmp3.Invoke_O_O_O__O(m__1, ik__3, tmp5.Invoke_O_O__O(lang.RT_Get_O_O_O__O(m__1, ik__3, tmp6.Ref()), x__2)) }


func A_arbace_set_map_invert_A_New() *A_arbace_set_map_invert_A { A_arbace_set_map_invert_A_Init(); t := &A_arbace_set_map_invert_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_set_map_invert_A) Ctor() {}
//line :105:1
func (t *A_arbace_set_map_invert_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_29; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_30; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_set_map_invert_fn__1726000047_A_New(); var tmp6 *jrt.Class; A_arbace_set_map_invert_fn__1726000047_A_Init(); tmp6 = A_arbace_set_map_invert_fn__1726000047_A_fn_class; var tmp7 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var tmp8 *lang.Var; A_arbace_set_A_Init(); tmp8 = A_arbace_set_A_const_32; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp10 = lang.PersistentArrayMap_EMPTY; return tmp2.Invoke_O__O(tmp4.Invoke_O_O_O__O(tmp7, tmp9.Invoke_O__O(tmp10.Ref()), m__0)) }
func A_arbace_set_map_invert_fn__1726000047_A_New() *A_arbace_set_map_invert_fn__1726000047_A { A_arbace_set_map_invert_fn__1726000047_A_Init(); t := &A_arbace_set_map_invert_fn__1726000047_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Ctor() {}
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Invoke_O_O_O_O__O(self, m__1, k__2, v__3 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_31; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O_O__O(m__1, v__3, k__2) }



func A_arbace_set_join_A_New() *A_arbace_set_join_A { A_arbace_set_join_A_Init(); t := &A_arbace_set_join_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_set_join_A) Ctor() {}
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O_O__O(self, xrel__0, yrel__1, km__2 any) any { var vec__1726000061__4 any; if



















	lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(xrel__0)), int64(lang.RT_Count_O__I(yrel__1))) { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_34; vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(xrel__0, yrel__1, lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(km__2)) } else { vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(yrel__1, xrel__0, km__2) }; var r__5 any = /*line :114:1*/lang.RT_Nth_O_I_O__O(vec__1726000061__4, lang.RT_IntCast_J__I(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O(vec__1726000061__4, lang.RT_IntCast_J__I(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O(vec__1726000061__4, lang.RT_IntCast_J__I(2), nil); var idx__8 any; var tmp2 *lang.Var;






















	A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_33; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_35; idx__8 = tmp3.Invoke_O_O__O(r__5, lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(k__7)); var tmp5 /*line :138:1*/*lang.Var; A_arbace_set_A_Init(); tmp5 = A_arbace_set_A_const_12; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_set_join_fn__1726000064_A_New_O_O(k__7, idx__8); var tmp8 *jrt.Class; A_arbace_set_join_fn__1726000064_A_Init(); tmp8 = A_arbace_set_join_fn__1726000064_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp10 = lang.PersistentHashSet_EMPTY; return tmp6.Invoke_O_O_O__O(tmp9, tmp10.Ref(), s__6) }
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O__O(self, xrel__0, yrel__1 any) any {





	var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_37; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xrel__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_37; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(yrel__1) } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) { var ks__3 any; var tmp4 *lang.Var
		A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_17; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_22; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_set_A_Init(); tmp8 = A_arbace_set_A_const_27; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Var; A_arbace_set_A_Init(); tmp10 = A_arbace_set_A_const_15; var tmp11 any = tmp7.Invoke_O__O(tmp9.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(xrel__0))); var tmp12 *lang.Var; A_arbace_set_A_Init(); tmp12 = A_arbace_set_A_const_22; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_set_A_Init(); tmp14 = A_arbace_set_A_const_27; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_set_A_Init(); tmp16 = A_arbace_set_A_const_15; ks__3 = tmp5.Invoke_O_O__O(tmp11, tmp13.Invoke_O__O(tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(yrel__1))))
//line :120:1
		var vec__1726000054__4 any

		if lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(xrel__0)), int64(lang.RT_Count_O__I(yrel__1))) { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(xrel__0, yrel__1) } else { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(yrel__1, xrel__0) }
//line :120:1
		var r__5 any = lang.RT_Nth_O_I_O__O(vec__1726000054__4, lang.RT_IntCast_J__I(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O(vec__1726000054__4, lang.RT_IntCast_J__I(1), nil); var idx__7 any; var tmp17 *lang.Var




		A_arbace_set_A_Init(); tmp17 = A_arbace_set_A_const_33; idx__7 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O_O__O(r__5, ks__3)
		var tmp18 *lang.Var; A_arbace_set_A_Init(); tmp18 = A_arbace_set_A_const_12; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = A_arbace_set_join_fn__1726000057_A_New_O_O(ks__3, idx__7); var tmp21 *jrt.Class; A_arbace_set_join_fn__1726000057_A_Init(); tmp21 = A_arbace_set_join_fn__1726000057_A_fn_class; var tmp22 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil); var tmp23 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp23 = lang.PersistentHashSet_EMPTY; return tmp19.Invoke_O_O_O__O(tmp22, tmp23.Ref(), s__6) } else {
//line :120:1
			lang.PersistentHashSet_Init(); return lang.PersistentHashSet_EMPTY.Ref()
		}
}



func A_arbace_set_join_fn__1726000057_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000057_A { A_arbace_set_join_fn__1726000057_A_Init(); t := &A_arbace_set_join_fn__1726000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Ctor_O_O(c__ks, c__idx any) { t.F_ks = c__ks; t.F_idx = c__idx }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var found__3 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var tmp2 *lang.Var;
												A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_24; found__3 = tmp1.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(x__2, t.F_ks)); if
												jrt.A2g_Truth(found__3) {
													var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_12; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 any = A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(x__2); var tmp6 *jrt.Class; A_arbace_set_join_fn__1726000057_fn__1726000058_A_Init(); tmp6 = A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class; return tmp4.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), ret__1, found__3) } else {
//line :128:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(p0 any) *A_arbace_set_join_fn__1726000057_fn__1726000058_A { A_arbace_set_join_fn__1726000057_fn__1726000058_A_Init(); t := &A_arbace_set_join_fn__1726000057_fn__1726000058_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Invoke_O_O_O__O(self, p1__1726000050_SHARP___1, p2__1726000051_SHARP___2 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_36; return tmp2.Invoke_O_O__O(p1__1726000050_SHARP___1, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(p2__1726000051_SHARP___2, t.F_x)) }








func A_arbace_set_join_fn__1726000064_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000064_A { A_arbace_set_join_fn__1726000064_A_Init(); t := &A_arbace_set_join_fn__1726000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Ctor_O_O(c__k, c__idx any) { t.F_k = c__k; t.F_idx = c__idx }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var found__3 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var tmp2 *lang.Var;
												A_arbace_set_A_Init(); tmp2 = A_arbace_set_A_const_28; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_set_A_Init(); tmp4 = A_arbace_set_A_const_24; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_set_A_Init(); tmp6 = A_arbace_set_A_const_27; found__3 = tmp1.Invoke_O__O(tmp3.Invoke_O_O__O(tmp5.Invoke_O_O__O(x__2, lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(t.F_k)), t.F_k)); if
												jrt.A2g_Truth(found__3) {
													var tmp7 *lang.Var; A_arbace_set_A_Init(); tmp7 = A_arbace_set_A_const_12; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any = A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(x__2); var tmp10 *jrt.Class; A_arbace_set_join_fn__1726000064_fn__1726000065_A_Init(); tmp10 = A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class; return tmp8.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), ret__1, found__3) } else {
//line :140:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(p0 any) *A_arbace_set_join_fn__1726000064_fn__1726000065_A { A_arbace_set_join_fn__1726000064_fn__1726000065_A_Init(); t := &A_arbace_set_join_fn__1726000064_fn__1726000065_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Invoke_O_O_O__O(self, p1__1726000052_SHARP___1, p2__1726000053_SHARP___2 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_4; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_set_A_Init(); tmp3 = A_arbace_set_A_const_36; return tmp2.Invoke_O_O__O(p1__1726000052_SHARP___1, lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(p2__1726000053_SHARP___2, t.F_x)) }



func A_arbace_set_subset_QMARK__A_New() *A_arbace_set_subset_QMARK__A { A_arbace_set_subset_QMARK__A_Init(); t := &A_arbace_set_subset_QMARK__A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Ctor() {}
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Lte_J_J__Z(int64(lang.RT_Count_O__I(set1__0)), int64(lang.RT_Count_O__I(set2__1))); if and__1927000168__auto____3 {





	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(set2__1); var tmp4 *jrt.Class; A_arbace_set_subset_QMARK__fn__1726000070_A_Init(); tmp4 = A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), set1__0) } else {
//line :150:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }
func A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(p0 any) *A_arbace_set_subset_QMARK__fn__1726000070_A { A_arbace_set_subset_QMARK__fn__1726000070_A_Init(); t := &A_arbace_set_subset_QMARK__fn__1726000070_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Ctor_O(c__set2 any) { t.F_set2 = c__set2 }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Invoke_O_O__O(self, p1__1726000069_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_18; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_set2, p1__1726000069_SHARP___1) }

func A_arbace_set_superset_QMARK__A_New() *A_arbace_set_superset_QMARK__A { A_arbace_set_superset_QMARK__A_Init(); t := &A_arbace_set_superset_QMARK__A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Ctor() {}
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z(int64(lang.RT_Count_O__I(set1__0)), int64(lang.RT_Count_O__I(set2__1))); if and__1927000168__auto____3 {





	var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_38; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(set1__0); var tmp4 *jrt.Class; A_arbace_set_superset_QMARK__fn__1726000074_A_Init(); tmp4 = A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), set2__1) } else {
//line :158:1
		return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } }
func A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(p0 any) *A_arbace_set_superset_QMARK__fn__1726000074_A { A_arbace_set_superset_QMARK__fn__1726000074_A_Init(); t := &A_arbace_set_superset_QMARK__fn__1726000074_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Ctor_O(c__set1 any) { t.F_set1 = c__set1 }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Invoke_O_O__O(self, p1__1726000073_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_set_A_Init(); tmp1 = A_arbace_set_A_const_18; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(t.F_set1, p1__1726000073_SHARP___1) }





















































type A_arbace_set_A struct{ jrt.Object }

var A_arbace_set_A_const_0 *lang.Var

var A_arbace_set_A_const_1 any

var A_arbace_set_A_const_2 *lang.Var

var A_arbace_set_A_const_3 *lang.Var

var A_arbace_set_A_const_4 *lang.Var

var A_arbace_set_A_const_5 any

var A_arbace_set_A_const_6 *lang.Var

var A_arbace_set_A_const_7 *lang.Var

var A_arbace_set_A_const_8 *lang.Var

var A_arbace_set_A_const_9 *lang.Var

var A_arbace_set_A_const_10 *lang.Var

var A_arbace_set_A_const_11 *lang.Var

var A_arbace_set_A_const_12 *lang.Var

var A_arbace_set_A_const_13 *lang.Var

var A_arbace_set_A_const_14 *lang.Var

var A_arbace_set_A_const_15 *lang.Var

var A_arbace_set_A_const_16 *lang.Var

var A_arbace_set_A_const_17 *lang.Var

var A_arbace_set_A_const_18 *lang.Var

var A_arbace_set_A_const_19 *lang.Var

var A_arbace_set_A_const_20 *lang.Var

var A_arbace_set_A_const_21 *lang.Var

var A_arbace_set_A_const_22 *lang.Var

var A_arbace_set_A_const_23 *lang.Var

var A_arbace_set_A_const_24 *lang.Var

var A_arbace_set_A_const_25 *lang.Var

var A_arbace_set_A_const_26 *lang.Var

var A_arbace_set_A_const_27 *lang.Var

var A_arbace_set_A_const_28 *lang.Var

var A_arbace_set_A_const_29 *lang.Var

var A_arbace_set_A_const_30 *lang.Var

var A_arbace_set_A_const_31 *lang.Var

var A_arbace_set_A_const_32 *lang.Var

var A_arbace_set_A_const_33 *lang.Var

var A_arbace_set_A_const_34 *lang.Var

var A_arbace_set_A_const_35 *lang.Var

var A_arbace_set_A_const_36 *lang.Var

var A_arbace_set_A_const_37 *lang.Var

var A_arbace_set_A_const_38 *lang.Var

var A_arbace_set_A_init jrt.ClassInit

func A_arbace_set_A_Init() { if !A_arbace_set_A_init.Done() { A_arbace_set_A_init.Run(A_arbace_set_A_clinit) } }

func A_arbace_set_A_clinit() { A_arbace_set_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_set_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_set_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_set_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_set_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_set_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_set_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_set_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_11); A_arbace_set_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_set_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_set_A_const_10 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_set_A_const_11 = lang.RT_Var_String_String__Var(Lit_5, Lit_15); A_arbace_set_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_16); A_arbace_set_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_17); A_arbace_set_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_set_A_const_15 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_set_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_20); A_arbace_set_A_const_17 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_set_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_set_A_const_19 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_set_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); A_arbace_set_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_set_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_26); A_arbace_set_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_27); A_arbace_set_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_set_A_const_25 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_set_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_set_A_const_27 = lang.RT_Var_String_String__Var(Lit_0, Lit_31); A_arbace_set_A_const_28 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_set_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_set_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_set_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_set_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_set_A_const_33 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); A_arbace_set_A_const_34 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); A_arbace_set_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_39); A_arbace_set_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_set_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_set_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_42) }

func A_arbace_set_A_New() *A_arbace_set_A { A_arbace_set_A_Init(); t := &A_arbace_set_A{}; t.Ctor(); return t }

func (t *A_arbace_set_A) Ctor() {}

func (t *A_arbace_set_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_A) GetClass__Class() *jrt.Class { return A_arbace_set_A_class }

func (t *A_arbace_set_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_A); return ok }

func A_arbace_set_A_Cast(x any) *A_arbace_set_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_A_class)) }; return v }



type A_arbace_set_bubble_max_key_A struct{ jrt.Object }

func (t *A_arbace_set_bubble_max_key_A) Is_Compiler_AOTF2() {}

var A_arbace_set_bubble_max_key_A_fn_class *jrt.Class

var A_arbace_set_bubble_max_key_A_init jrt.ClassInit

func A_arbace_set_bubble_max_key_A_Init() { if !A_arbace_set_bubble_max_key_A_init.Done() { A_arbace_set_bubble_max_key_A_init.Run(A_arbace_set_bubble_max_key_A_clinit) } }

func A_arbace_set_bubble_max_key_A_clinit() { A_arbace_set_bubble_max_key_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_43, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_bubble_max_key_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_bubble_max_key_A) GetClass__Class() *jrt.Class { return A_arbace_set_bubble_max_key_A_class }

func (t *A_arbace_set_bubble_max_key_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_bubble_max_key_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_bubble_max_key_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_bubble_max_key_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_bubble_max_key_A); return ok }

func A_arbace_set_bubble_max_key_A_Cast(x any) *A_arbace_set_bubble_max_key_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_bubble_max_key_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_bubble_max_key_A_class)) }; return v }



type A_arbace_set_bubble_max_key_fn__1726000013_A struct{ jrt.Object; F_max any }

func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Is_Compiler_AOTF1() {}

var A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class *jrt.Class

var A_arbace_set_bubble_max_key_fn__1726000013_A_init jrt.ClassInit

func A_arbace_set_bubble_max_key_fn__1726000013_A_Init() { if !A_arbace_set_bubble_max_key_fn__1726000013_A_init.Done() { A_arbace_set_bubble_max_key_fn__1726000013_A_init.Run(A_arbace_set_bubble_max_key_fn__1726000013_A_clinit) } }

func A_arbace_set_bubble_max_key_fn__1726000013_A_clinit() { A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_44, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) GetClass__Class() *jrt.Class { return A_arbace_set_bubble_max_key_fn__1726000013_A_class }

func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_bubble_max_key_fn__1726000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_bubble_max_key_fn__1726000013_A); return ok }

func A_arbace_set_bubble_max_key_fn__1726000013_A_Cast(x any) *A_arbace_set_bubble_max_key_fn__1726000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_bubble_max_key_fn__1726000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_bubble_max_key_fn__1726000013_A_class)) }; return v }



type A_arbace_set_difference_A struct{ jrt.Object }

func (t *A_arbace_set_difference_A) Is_Compiler_AOTR2() {}

func (t *A_arbace_set_difference_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_set_difference_A) Is_Compiler_AOTF1() {}

var A_arbace_set_difference_A_fn_class *jrt.Class

var A_arbace_set_difference_A_init jrt.ClassInit

func A_arbace_set_difference_A_Init() { if !A_arbace_set_difference_A_init.Done() { A_arbace_set_difference_A_init.Run(A_arbace_set_difference_A_clinit) } }

func A_arbace_set_difference_A_clinit() { A_arbace_set_difference_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_45, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_set_difference_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_difference_A) GetClass__Class() *jrt.Class { return A_arbace_set_difference_A_class }

func (t *A_arbace_set_difference_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_difference_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_difference_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_difference_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_difference_A); return ok }

func A_arbace_set_difference_A_Cast(x any) *A_arbace_set_difference_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_difference_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_difference_A_class)) }; return v }



type A_arbace_set_difference_fn__1726000023_A struct{ jrt.Object; F_s2 any }

func (t *A_arbace_set_difference_fn__1726000023_A) Is_Compiler_AOTF2() {}

var A_arbace_set_difference_fn__1726000023_A_fn_class *jrt.Class

var A_arbace_set_difference_fn__1726000023_A_init jrt.ClassInit

func A_arbace_set_difference_fn__1726000023_A_Init() { if !A_arbace_set_difference_fn__1726000023_A_init.Done() { A_arbace_set_difference_fn__1726000023_A_init.Run(A_arbace_set_difference_fn__1726000023_A_clinit) } }

func A_arbace_set_difference_fn__1726000023_A_clinit() { A_arbace_set_difference_fn__1726000023_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_46, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_difference_fn__1726000023_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_difference_fn__1726000023_A) GetClass__Class() *jrt.Class { return A_arbace_set_difference_fn__1726000023_A_class }

func (t *A_arbace_set_difference_fn__1726000023_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_difference_fn__1726000023_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_difference_fn__1726000023_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_difference_fn__1726000023_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_difference_fn__1726000023_A); return ok }

func A_arbace_set_difference_fn__1726000023_A_Cast(x any) *A_arbace_set_difference_fn__1726000023_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_difference_fn__1726000023_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_difference_fn__1726000023_A_class)) }; return v }



type A_arbace_set_eval1726000004_A struct{ jrt.Object }

func A_arbace_set_eval1726000004_A_New() *A_arbace_set_eval1726000004_A { t := &A_arbace_set_eval1726000004_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000004_A) Ctor() {}

func (t *A_arbace_set_eval1726000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000004_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000004_A_class }

func (t *A_arbace_set_eval1726000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000004_A); return ok }

func A_arbace_set_eval1726000004_A_Cast(x any) *A_arbace_set_eval1726000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000004_A_class)) }; return v }



type A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A struct{ jrt.Object }

func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Is_Compiler_AOTF0() {}

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class *jrt.Class

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_init jrt.ClassInit

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_Init() { if !A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_init.Done() { A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_init.Run(A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_clinit) } }

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_clinit() { A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_47, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class }

func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A); return ok }

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_Cast(x any) *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class)) }; return v }



type A_arbace_set_eval1726000008_A struct{ jrt.Object }

func A_arbace_set_eval1726000008_A_New() *A_arbace_set_eval1726000008_A { t := &A_arbace_set_eval1726000008_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000008_A) Ctor() {}

func (t *A_arbace_set_eval1726000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000008_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000008_A_class }

func (t *A_arbace_set_eval1726000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000008_A); return ok }

func A_arbace_set_eval1726000008_A_Cast(x any) *A_arbace_set_eval1726000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000008_A_class)) }; return v }



type A_arbace_set_eval1726000008_fn__1726000009_A struct{ jrt.Object }

func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Is_Compiler_AOTF0() {}

var A_arbace_set_eval1726000008_fn__1726000009_A_fn_class *jrt.Class

var A_arbace_set_eval1726000008_fn__1726000009_A_init jrt.ClassInit

func A_arbace_set_eval1726000008_fn__1726000009_A_Init() { if !A_arbace_set_eval1726000008_fn__1726000009_A_init.Done() { A_arbace_set_eval1726000008_fn__1726000009_A_init.Run(A_arbace_set_eval1726000008_fn__1726000009_A_clinit) } }

func A_arbace_set_eval1726000008_fn__1726000009_A_clinit() { A_arbace_set_eval1726000008_fn__1726000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000008_fn__1726000009_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000008_fn__1726000009_A_class }

func (t *A_arbace_set_eval1726000008_fn__1726000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000008_fn__1726000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000008_fn__1726000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000008_fn__1726000009_A); return ok }

func A_arbace_set_eval1726000008_fn__1726000009_A_Cast(x any) *A_arbace_set_eval1726000008_fn__1726000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000008_fn__1726000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000008_fn__1726000009_A_class)) }; return v }



type A_arbace_set_index_A struct{ jrt.Object }

func (t *A_arbace_set_index_A) Is_Compiler_AOTF2() {}

var A_arbace_set_index_A_fn_class *jrt.Class

var A_arbace_set_index_A_init jrt.ClassInit

func A_arbace_set_index_A_Init() { if !A_arbace_set_index_A_init.Done() { A_arbace_set_index_A_init.Run(A_arbace_set_index_A_clinit) } }

func A_arbace_set_index_A_clinit() { A_arbace_set_index_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_index_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_index_A) GetClass__Class() *jrt.Class { return A_arbace_set_index_A_class }

func (t *A_arbace_set_index_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_index_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_index_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_index_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_index_A); return ok }

func A_arbace_set_index_A_Cast(x any) *A_arbace_set_index_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_index_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_index_A_class)) }; return v }



type A_arbace_set_index_fn__1726000044_A struct{ jrt.Object; F_ks any }

func (t *A_arbace_set_index_fn__1726000044_A) Is_Compiler_AOTF2() {}

var A_arbace_set_index_fn__1726000044_A_fn_class *jrt.Class

var A_arbace_set_index_fn__1726000044_A_init jrt.ClassInit

func A_arbace_set_index_fn__1726000044_A_Init() { if !A_arbace_set_index_fn__1726000044_A_init.Done() { A_arbace_set_index_fn__1726000044_A_init.Run(A_arbace_set_index_fn__1726000044_A_clinit) } }

func A_arbace_set_index_fn__1726000044_A_clinit() { A_arbace_set_index_fn__1726000044_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_50, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_index_fn__1726000044_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_index_fn__1726000044_A) GetClass__Class() *jrt.Class { return A_arbace_set_index_fn__1726000044_A_class }

func (t *A_arbace_set_index_fn__1726000044_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_index_fn__1726000044_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_index_fn__1726000044_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_index_fn__1726000044_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_index_fn__1726000044_A); return ok }

func A_arbace_set_index_fn__1726000044_A_Cast(x any) *A_arbace_set_index_fn__1726000044_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_index_fn__1726000044_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_index_fn__1726000044_A_class)) }; return v }



type A_arbace_set_intersection_A struct{ jrt.Object }

func (t *A_arbace_set_intersection_A) Is_Compiler_AOTR2() {}

func (t *A_arbace_set_intersection_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_set_intersection_A) Is_Compiler_AOTF1() {}

var A_arbace_set_intersection_A_fn_class *jrt.Class

var A_arbace_set_intersection_A_init jrt.ClassInit

func A_arbace_set_intersection_A_Init() { if !A_arbace_set_intersection_A_init.Done() { A_arbace_set_intersection_A_init.Run(A_arbace_set_intersection_A_clinit) } }

func A_arbace_set_intersection_A_clinit() { A_arbace_set_intersection_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_set_intersection_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_intersection_A) GetClass__Class() *jrt.Class { return A_arbace_set_intersection_A_class }

func (t *A_arbace_set_intersection_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_intersection_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_intersection_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_intersection_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_intersection_A); return ok }

func A_arbace_set_intersection_A_Cast(x any) *A_arbace_set_intersection_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_intersection_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_intersection_A_class)) }; return v }



type A_arbace_set_intersection_fn__1726000018_A struct{ jrt.Object; F_s2 any }

func (t *A_arbace_set_intersection_fn__1726000018_A) Is_Compiler_AOTF2() {}

var A_arbace_set_intersection_fn__1726000018_A_fn_class *jrt.Class

var A_arbace_set_intersection_fn__1726000018_A_init jrt.ClassInit

func A_arbace_set_intersection_fn__1726000018_A_Init() { if !A_arbace_set_intersection_fn__1726000018_A_init.Done() { A_arbace_set_intersection_fn__1726000018_A_init.Run(A_arbace_set_intersection_fn__1726000018_A_clinit) } }

func A_arbace_set_intersection_fn__1726000018_A_clinit() { A_arbace_set_intersection_fn__1726000018_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_52, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_intersection_fn__1726000018_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_intersection_fn__1726000018_A) GetClass__Class() *jrt.Class { return A_arbace_set_intersection_fn__1726000018_A_class }

func (t *A_arbace_set_intersection_fn__1726000018_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_intersection_fn__1726000018_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_intersection_fn__1726000018_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_intersection_fn__1726000018_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_intersection_fn__1726000018_A); return ok }

func A_arbace_set_intersection_fn__1726000018_A_Cast(x any) *A_arbace_set_intersection_fn__1726000018_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_intersection_fn__1726000018_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_intersection_fn__1726000018_A_class)) }; return v }



type A_arbace_set_intersection_fn__1726000020_A struct{ jrt.Object }

func (t *A_arbace_set_intersection_fn__1726000020_A) Is_Compiler_AOTF1() {}

var A_arbace_set_intersection_fn__1726000020_A_fn_class *jrt.Class

var A_arbace_set_intersection_fn__1726000020_A_init jrt.ClassInit

func A_arbace_set_intersection_fn__1726000020_A_Init() { if !A_arbace_set_intersection_fn__1726000020_A_init.Done() { A_arbace_set_intersection_fn__1726000020_A_init.Run(A_arbace_set_intersection_fn__1726000020_A_clinit) } }

func A_arbace_set_intersection_fn__1726000020_A_clinit() { A_arbace_set_intersection_fn__1726000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_53, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_intersection_fn__1726000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_intersection_fn__1726000020_A) GetClass__Class() *jrt.Class { return A_arbace_set_intersection_fn__1726000020_A_class }

func (t *A_arbace_set_intersection_fn__1726000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_intersection_fn__1726000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_intersection_fn__1726000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_intersection_fn__1726000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_intersection_fn__1726000020_A); return ok }

func A_arbace_set_intersection_fn__1726000020_A_Cast(x any) *A_arbace_set_intersection_fn__1726000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_intersection_fn__1726000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_intersection_fn__1726000020_A_class)) }; return v }



type A_arbace_set_join_A struct{ jrt.Object }

func (t *A_arbace_set_join_A) Is_Compiler_AOTF3() {}

func (t *A_arbace_set_join_A) Is_Compiler_AOTF2() {}

var A_arbace_set_join_A_fn_class *jrt.Class

var A_arbace_set_join_A_init jrt.ClassInit

func A_arbace_set_join_A_Init() { if !A_arbace_set_join_A_init.Done() { A_arbace_set_join_A_init.Run(A_arbace_set_join_A_clinit) } }

func A_arbace_set_join_A_clinit() { A_arbace_set_join_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_join_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_join_A) GetClass__Class() *jrt.Class { return A_arbace_set_join_A_class }

func (t *A_arbace_set_join_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_join_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_join_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_join_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_join_A); return ok }

func A_arbace_set_join_A_Cast(x any) *A_arbace_set_join_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_join_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_join_A_class)) }; return v }



type A_arbace_set_join_fn__1726000057_A struct{ jrt.Object; F_ks, F_idx any }

func (t *A_arbace_set_join_fn__1726000057_A) Is_Compiler_AOTF2() {}

var A_arbace_set_join_fn__1726000057_A_fn_class *jrt.Class

var A_arbace_set_join_fn__1726000057_A_init jrt.ClassInit

func A_arbace_set_join_fn__1726000057_A_Init() { if !A_arbace_set_join_fn__1726000057_A_init.Done() { A_arbace_set_join_fn__1726000057_A_init.Run(A_arbace_set_join_fn__1726000057_A_clinit) } }

func A_arbace_set_join_fn__1726000057_A_clinit() { A_arbace_set_join_fn__1726000057_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_55, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_join_fn__1726000057_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_join_fn__1726000057_A) GetClass__Class() *jrt.Class { return A_arbace_set_join_fn__1726000057_A_class }

func (t *A_arbace_set_join_fn__1726000057_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_join_fn__1726000057_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_join_fn__1726000057_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_join_fn__1726000057_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_join_fn__1726000057_A); return ok }

func A_arbace_set_join_fn__1726000057_A_Cast(x any) *A_arbace_set_join_fn__1726000057_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_join_fn__1726000057_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_join_fn__1726000057_A_class)) }; return v }



type A_arbace_set_join_fn__1726000057_fn__1726000058_A struct{ jrt.Object; F_x any }

func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Is_Compiler_AOTF2() {}

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class *jrt.Class

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_init jrt.ClassInit

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_Init() { if !A_arbace_set_join_fn__1726000057_fn__1726000058_A_init.Done() { A_arbace_set_join_fn__1726000057_fn__1726000058_A_init.Run(A_arbace_set_join_fn__1726000057_fn__1726000058_A_clinit) } }

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_clinit() { A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) GetClass__Class() *jrt.Class { return A_arbace_set_join_fn__1726000057_fn__1726000058_A_class }

func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_join_fn__1726000057_fn__1726000058_A); return ok }

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_Cast(x any) *A_arbace_set_join_fn__1726000057_fn__1726000058_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_join_fn__1726000057_fn__1726000058_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_join_fn__1726000057_fn__1726000058_A_class)) }; return v }



type A_arbace_set_join_fn__1726000064_A struct{ jrt.Object; F_k, F_idx any }

func (t *A_arbace_set_join_fn__1726000064_A) Is_Compiler_AOTF2() {}

var A_arbace_set_join_fn__1726000064_A_fn_class *jrt.Class

var A_arbace_set_join_fn__1726000064_A_init jrt.ClassInit

func A_arbace_set_join_fn__1726000064_A_Init() { if !A_arbace_set_join_fn__1726000064_A_init.Done() { A_arbace_set_join_fn__1726000064_A_init.Run(A_arbace_set_join_fn__1726000064_A_clinit) } }

func A_arbace_set_join_fn__1726000064_A_clinit() { A_arbace_set_join_fn__1726000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_57, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_join_fn__1726000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_join_fn__1726000064_A) GetClass__Class() *jrt.Class { return A_arbace_set_join_fn__1726000064_A_class }

func (t *A_arbace_set_join_fn__1726000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_join_fn__1726000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_join_fn__1726000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_join_fn__1726000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_join_fn__1726000064_A); return ok }

func A_arbace_set_join_fn__1726000064_A_Cast(x any) *A_arbace_set_join_fn__1726000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_join_fn__1726000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_join_fn__1726000064_A_class)) }; return v }



type A_arbace_set_join_fn__1726000064_fn__1726000065_A struct{ jrt.Object; F_x any }

func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Is_Compiler_AOTF2() {}

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class *jrt.Class

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_init jrt.ClassInit

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_Init() { if !A_arbace_set_join_fn__1726000064_fn__1726000065_A_init.Done() { A_arbace_set_join_fn__1726000064_fn__1726000065_A_init.Run(A_arbace_set_join_fn__1726000064_fn__1726000065_A_clinit) } }

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_clinit() { A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_58, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) GetClass__Class() *jrt.Class { return A_arbace_set_join_fn__1726000064_fn__1726000065_A_class }

func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_join_fn__1726000064_fn__1726000065_A); return ok }

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_Cast(x any) *A_arbace_set_join_fn__1726000064_fn__1726000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_join_fn__1726000064_fn__1726000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_join_fn__1726000064_fn__1726000065_A_class)) }; return v }



type A_arbace_set_map_invert_A struct{ jrt.Object }

func (t *A_arbace_set_map_invert_A) Is_Compiler_AOTF1() {}

var A_arbace_set_map_invert_A_fn_class *jrt.Class

var A_arbace_set_map_invert_A_init jrt.ClassInit

func A_arbace_set_map_invert_A_Init() { if !A_arbace_set_map_invert_A_init.Done() { A_arbace_set_map_invert_A_init.Run(A_arbace_set_map_invert_A_clinit) } }

func A_arbace_set_map_invert_A_clinit() { A_arbace_set_map_invert_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_59, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_map_invert_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_map_invert_A) GetClass__Class() *jrt.Class { return A_arbace_set_map_invert_A_class }

func (t *A_arbace_set_map_invert_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_map_invert_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_map_invert_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_map_invert_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_map_invert_A); return ok }

func A_arbace_set_map_invert_A_Cast(x any) *A_arbace_set_map_invert_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_map_invert_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_map_invert_A_class)) }; return v }



type A_arbace_set_map_invert_fn__1726000047_A struct{ jrt.Object }

func (t *A_arbace_set_map_invert_fn__1726000047_A) Is_Compiler_AOTF3() {}

var A_arbace_set_map_invert_fn__1726000047_A_fn_class *jrt.Class

var A_arbace_set_map_invert_fn__1726000047_A_init jrt.ClassInit

func A_arbace_set_map_invert_fn__1726000047_A_Init() { if !A_arbace_set_map_invert_fn__1726000047_A_init.Done() { A_arbace_set_map_invert_fn__1726000047_A_init.Run(A_arbace_set_map_invert_fn__1726000047_A_clinit) } }

func A_arbace_set_map_invert_fn__1726000047_A_clinit() { A_arbace_set_map_invert_fn__1726000047_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_60, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_map_invert_fn__1726000047_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_map_invert_fn__1726000047_A) GetClass__Class() *jrt.Class { return A_arbace_set_map_invert_fn__1726000047_A_class }

func (t *A_arbace_set_map_invert_fn__1726000047_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_map_invert_fn__1726000047_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_map_invert_fn__1726000047_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_map_invert_fn__1726000047_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_map_invert_fn__1726000047_A); return ok }

func A_arbace_set_map_invert_fn__1726000047_A_Cast(x any) *A_arbace_set_map_invert_fn__1726000047_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_map_invert_fn__1726000047_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_map_invert_fn__1726000047_A_class)) }; return v }



type A_arbace_set_project_A struct{ jrt.Object }

func (t *A_arbace_set_project_A) Is_Compiler_AOTF2() {}

var A_arbace_set_project_A_fn_class *jrt.Class

var A_arbace_set_project_A_init jrt.ClassInit

func A_arbace_set_project_A_Init() { if !A_arbace_set_project_A_init.Done() { A_arbace_set_project_A_init.Run(A_arbace_set_project_A_clinit) } }

func A_arbace_set_project_A_clinit() { A_arbace_set_project_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_61, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_project_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_project_A) GetClass__Class() *jrt.Class { return A_arbace_set_project_A_class }

func (t *A_arbace_set_project_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_project_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_project_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_project_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_project_A); return ok }

func A_arbace_set_project_A_Cast(x any) *A_arbace_set_project_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_project_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_project_A_class)) }; return v }



type A_arbace_set_project_fn__1726000030_A struct{ jrt.Object; F_ks any }

func (t *A_arbace_set_project_fn__1726000030_A) Is_Compiler_AOTF1() {}

var A_arbace_set_project_fn__1726000030_A_fn_class *jrt.Class

var A_arbace_set_project_fn__1726000030_A_init jrt.ClassInit

func A_arbace_set_project_fn__1726000030_A_Init() { if !A_arbace_set_project_fn__1726000030_A_init.Done() { A_arbace_set_project_fn__1726000030_A_init.Run(A_arbace_set_project_fn__1726000030_A_clinit) } }

func A_arbace_set_project_fn__1726000030_A_clinit() { A_arbace_set_project_fn__1726000030_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_62, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_project_fn__1726000030_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_project_fn__1726000030_A) GetClass__Class() *jrt.Class { return A_arbace_set_project_fn__1726000030_A_class }

func (t *A_arbace_set_project_fn__1726000030_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_project_fn__1726000030_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_project_fn__1726000030_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_project_fn__1726000030_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_project_fn__1726000030_A); return ok }

func A_arbace_set_project_fn__1726000030_A_Cast(x any) *A_arbace_set_project_fn__1726000030_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_project_fn__1726000030_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_project_fn__1726000030_A_class)) }; return v }



type A_arbace_set_rename_A struct{ jrt.Object }

func (t *A_arbace_set_rename_A) Is_Compiler_AOTF2() {}

var A_arbace_set_rename_A_fn_class *jrt.Class

var A_arbace_set_rename_A_init jrt.ClassInit

func A_arbace_set_rename_A_Init() { if !A_arbace_set_rename_A_init.Done() { A_arbace_set_rename_A_init.Run(A_arbace_set_rename_A_clinit) } }

func A_arbace_set_rename_A_clinit() { A_arbace_set_rename_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_63, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_rename_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_rename_A) GetClass__Class() *jrt.Class { return A_arbace_set_rename_A_class }

func (t *A_arbace_set_rename_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_rename_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_rename_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_rename_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_rename_A); return ok }

func A_arbace_set_rename_A_Cast(x any) *A_arbace_set_rename_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_rename_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_rename_A_class)) }; return v }



type A_arbace_set_rename_fn__1726000041_A struct{ jrt.Object; F_kmap any }

func (t *A_arbace_set_rename_fn__1726000041_A) Is_Compiler_AOTF1() {}

var A_arbace_set_rename_fn__1726000041_A_fn_class *jrt.Class

var A_arbace_set_rename_fn__1726000041_A_init jrt.ClassInit

func A_arbace_set_rename_fn__1726000041_A_Init() { if !A_arbace_set_rename_fn__1726000041_A_init.Done() { A_arbace_set_rename_fn__1726000041_A_init.Run(A_arbace_set_rename_fn__1726000041_A_clinit) } }

func A_arbace_set_rename_fn__1726000041_A_clinit() { A_arbace_set_rename_fn__1726000041_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_64, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_rename_fn__1726000041_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_rename_fn__1726000041_A) GetClass__Class() *jrt.Class { return A_arbace_set_rename_fn__1726000041_A_class }

func (t *A_arbace_set_rename_fn__1726000041_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_rename_fn__1726000041_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_rename_fn__1726000041_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_rename_fn__1726000041_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_rename_fn__1726000041_A); return ok }

func A_arbace_set_rename_fn__1726000041_A_Cast(x any) *A_arbace_set_rename_fn__1726000041_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_rename_fn__1726000041_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_rename_fn__1726000041_A_class)) }; return v }



type A_arbace_set_rename_keys_A struct{ jrt.Object }

func (t *A_arbace_set_rename_keys_A) Is_Compiler_AOTF2() {}

var A_arbace_set_rename_keys_A_fn_class *jrt.Class

var A_arbace_set_rename_keys_A_init jrt.ClassInit

func A_arbace_set_rename_keys_A_Init() { if !A_arbace_set_rename_keys_A_init.Done() { A_arbace_set_rename_keys_A_init.Run(A_arbace_set_rename_keys_A_clinit) } }

func A_arbace_set_rename_keys_A_clinit() { A_arbace_set_rename_keys_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_65, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_rename_keys_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_rename_keys_A) GetClass__Class() *jrt.Class { return A_arbace_set_rename_keys_A_class }

func (t *A_arbace_set_rename_keys_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_rename_keys_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_rename_keys_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_rename_keys_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_rename_keys_A); return ok }

func A_arbace_set_rename_keys_A_Cast(x any) *A_arbace_set_rename_keys_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_rename_keys_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_rename_keys_A_class)) }; return v }



type A_arbace_set_rename_keys_fn__1726000034_A struct{ jrt.Object; F_map any }

func (t *A_arbace_set_rename_keys_fn__1726000034_A) Is_Compiler_AOTF2() {}

var A_arbace_set_rename_keys_fn__1726000034_A_fn_class *jrt.Class

var A_arbace_set_rename_keys_fn__1726000034_A_init jrt.ClassInit

func A_arbace_set_rename_keys_fn__1726000034_A_Init() { if !A_arbace_set_rename_keys_fn__1726000034_A_init.Done() { A_arbace_set_rename_keys_fn__1726000034_A_init.Run(A_arbace_set_rename_keys_fn__1726000034_A_clinit) } }

func A_arbace_set_rename_keys_fn__1726000034_A_clinit() { A_arbace_set_rename_keys_fn__1726000034_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_rename_keys_fn__1726000034_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_rename_keys_fn__1726000034_A) GetClass__Class() *jrt.Class { return A_arbace_set_rename_keys_fn__1726000034_A_class }

func (t *A_arbace_set_rename_keys_fn__1726000034_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_rename_keys_fn__1726000034_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_rename_keys_fn__1726000034_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_rename_keys_fn__1726000034_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_rename_keys_fn__1726000034_A); return ok }

func A_arbace_set_rename_keys_fn__1726000034_A_Cast(x any) *A_arbace_set_rename_keys_fn__1726000034_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_rename_keys_fn__1726000034_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_rename_keys_fn__1726000034_A_class)) }; return v }



type A_arbace_set_select_A struct{ jrt.Object }

func (t *A_arbace_set_select_A) Is_Compiler_AOTF2() {}

var A_arbace_set_select_A_fn_class *jrt.Class

var A_arbace_set_select_A_init jrt.ClassInit

func A_arbace_set_select_A_Init() { if !A_arbace_set_select_A_init.Done() { A_arbace_set_select_A_init.Run(A_arbace_set_select_A_clinit) } }

func A_arbace_set_select_A_clinit() { A_arbace_set_select_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_67, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_select_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_select_A) GetClass__Class() *jrt.Class { return A_arbace_set_select_A_class }

func (t *A_arbace_set_select_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_select_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_select_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_select_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_select_A); return ok }

func A_arbace_set_select_A_Cast(x any) *A_arbace_set_select_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_select_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_select_A_class)) }; return v }



type A_arbace_set_select_fn__1726000026_A struct{ jrt.Object; F_pred any }

func (t *A_arbace_set_select_fn__1726000026_A) Is_Compiler_AOTF2() {}

var A_arbace_set_select_fn__1726000026_A_fn_class *jrt.Class

var A_arbace_set_select_fn__1726000026_A_init jrt.ClassInit

func A_arbace_set_select_fn__1726000026_A_Init() { if !A_arbace_set_select_fn__1726000026_A_init.Done() { A_arbace_set_select_fn__1726000026_A_init.Run(A_arbace_set_select_fn__1726000026_A_clinit) } }

func A_arbace_set_select_fn__1726000026_A_clinit() { A_arbace_set_select_fn__1726000026_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_select_fn__1726000026_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_select_fn__1726000026_A) GetClass__Class() *jrt.Class { return A_arbace_set_select_fn__1726000026_A_class }

func (t *A_arbace_set_select_fn__1726000026_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_select_fn__1726000026_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_select_fn__1726000026_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_select_fn__1726000026_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_select_fn__1726000026_A); return ok }

func A_arbace_set_select_fn__1726000026_A_Cast(x any) *A_arbace_set_select_fn__1726000026_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_select_fn__1726000026_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_select_fn__1726000026_A_class)) }; return v }



type A_arbace_set_subset_QMARK__A struct{ jrt.Object }

func (t *A_arbace_set_subset_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_set_subset_QMARK__A_fn_class *jrt.Class

var A_arbace_set_subset_QMARK__A_init jrt.ClassInit

func A_arbace_set_subset_QMARK__A_Init() { if !A_arbace_set_subset_QMARK__A_init.Done() { A_arbace_set_subset_QMARK__A_init.Run(A_arbace_set_subset_QMARK__A_clinit) } }

func A_arbace_set_subset_QMARK__A_clinit() { A_arbace_set_subset_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_69, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_subset_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_subset_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_set_subset_QMARK__A_class }

func (t *A_arbace_set_subset_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_subset_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_subset_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_subset_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_subset_QMARK__A); return ok }

func A_arbace_set_subset_QMARK__A_Cast(x any) *A_arbace_set_subset_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_subset_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_subset_QMARK__A_class)) }; return v }



type A_arbace_set_subset_QMARK__fn__1726000070_A struct{ jrt.Object; F_set2 any }

func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Is_Compiler_AOTF1() {}

var A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class *jrt.Class

var A_arbace_set_subset_QMARK__fn__1726000070_A_init jrt.ClassInit

func A_arbace_set_subset_QMARK__fn__1726000070_A_Init() { if !A_arbace_set_subset_QMARK__fn__1726000070_A_init.Done() { A_arbace_set_subset_QMARK__fn__1726000070_A_init.Run(A_arbace_set_subset_QMARK__fn__1726000070_A_clinit) } }

func A_arbace_set_subset_QMARK__fn__1726000070_A_clinit() { A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) GetClass__Class() *jrt.Class { return A_arbace_set_subset_QMARK__fn__1726000070_A_class }

func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_subset_QMARK__fn__1726000070_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_subset_QMARK__fn__1726000070_A); return ok }

func A_arbace_set_subset_QMARK__fn__1726000070_A_Cast(x any) *A_arbace_set_subset_QMARK__fn__1726000070_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_subset_QMARK__fn__1726000070_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_subset_QMARK__fn__1726000070_A_class)) }; return v }



type A_arbace_set_superset_QMARK__A struct{ jrt.Object }

func (t *A_arbace_set_superset_QMARK__A) Is_Compiler_AOTF2() {}

var A_arbace_set_superset_QMARK__A_fn_class *jrt.Class

var A_arbace_set_superset_QMARK__A_init jrt.ClassInit

func A_arbace_set_superset_QMARK__A_Init() { if !A_arbace_set_superset_QMARK__A_init.Done() { A_arbace_set_superset_QMARK__A_init.Run(A_arbace_set_superset_QMARK__A_clinit) } }

func A_arbace_set_superset_QMARK__A_clinit() { A_arbace_set_superset_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_superset_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_superset_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_set_superset_QMARK__A_class }

func (t *A_arbace_set_superset_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_superset_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_superset_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_superset_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_superset_QMARK__A); return ok }

func A_arbace_set_superset_QMARK__A_Cast(x any) *A_arbace_set_superset_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_superset_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_superset_QMARK__A_class)) }; return v }



type A_arbace_set_superset_QMARK__fn__1726000074_A struct{ jrt.Object; F_set1 any }

func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Is_Compiler_AOTF1() {}

var A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class *jrt.Class

var A_arbace_set_superset_QMARK__fn__1726000074_A_init jrt.ClassInit

func A_arbace_set_superset_QMARK__fn__1726000074_A_Init() { if !A_arbace_set_superset_QMARK__fn__1726000074_A_init.Done() { A_arbace_set_superset_QMARK__fn__1726000074_A_init.Run(A_arbace_set_superset_QMARK__fn__1726000074_A_clinit) } }

func A_arbace_set_superset_QMARK__fn__1726000074_A_clinit() { A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) GetClass__Class() *jrt.Class { return A_arbace_set_superset_QMARK__fn__1726000074_A_class }

func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_superset_QMARK__fn__1726000074_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_superset_QMARK__fn__1726000074_A); return ok }

func A_arbace_set_superset_QMARK__fn__1726000074_A_Cast(x any) *A_arbace_set_superset_QMARK__fn__1726000074_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_superset_QMARK__fn__1726000074_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_superset_QMARK__fn__1726000074_A_class)) }; return v }



type A_arbace_set_union_A struct{ jrt.Object }

func (t *A_arbace_set_union_A) Is_Compiler_AOTR2() {}

func (t *A_arbace_set_union_A) Is_Compiler_AOTF2() {}

func (t *A_arbace_set_union_A) Is_Compiler_AOTF1() {}

func (t *A_arbace_set_union_A) Is_Compiler_AOTF0() {}

var A_arbace_set_union_A_fn_class *jrt.Class

var A_arbace_set_union_A_init jrt.ClassInit

func A_arbace_set_union_A_Init() { if !A_arbace_set_union_A_init.Done() { A_arbace_set_union_A_init.Run(A_arbace_set_union_A_clinit) } }

func A_arbace_set_union_A_clinit() { A_arbace_set_union_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_73, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_set_union_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_union_A) GetClass__Class() *jrt.Class { return A_arbace_set_union_A_class }

func (t *A_arbace_set_union_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_union_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set_union_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_union_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_union_A); return ok }

func A_arbace_set_union_A_Cast(x any) *A_arbace_set_union_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_union_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_union_A_class)) }; return v }
