//line aot_arbace_set.ae:1
package aot_arbace_set

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_New() *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A { A_arbace_set_A_Init(); t := &A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_set_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_set_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_set_eval1726000008_fn__1726000009_A_New() *A_arbace_set_eval1726000008_fn__1726000009_A { A_arbace_set_A_Init(); t := &A_arbace_set_eval1726000008_fn__1726000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_2.GetRawRoot__O()); var tmp2 any; var root_11 any = A_arbace_set_A_const_3.GetRawRoot__O(); var linked_12 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_11, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_13 lang.IFn; if linked_12 == nil { ifn_13 = lang.IFn_Cast(root_11) } else { ifn_13 = nil }; var arg_14 any = A_arbace_set_A_const_4; if linked_12 == nil { tmp2 = ifn_13.Invoke_O__O(arg_14) } else { tmp2 = linked_12.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_11, arg_14) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_set_A_const_5.GetRawRoot__O(), A_arbace_set_A_const_6) }



func A_arbace_set_bubble_max_key_A_New() *A_arbace_set_bubble_max_key_A { A_arbace_set_A_Init(); t := &A_arbace_set_bubble_max_key_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Ctor() {}
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Invoke_O_O_O__O(self, k__0, coll__1 any) any { var max__3 any; var root_15 any = A_arbace_set_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_17 lang.IFn; if



	linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_set_A_const_8.GetRawRoot__O(); var arg_19 any = k__0; var arg_20 any = coll__1; if linked_16 == nil { max__3 = ifn_17.Invoke_O_O_O__O(arg_18, arg_19, arg_20) } else { max__3 = linked_16.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_15, arg_18, arg_19, arg_20) }; var root_21 any =
	A_arbace_set_A_const_9.GetRawRoot__O(); var linked_22 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_21, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_23 lang.IFn; if linked_22 == nil { ifn_23 = lang.IFn_Cast(root_21) } else { ifn_23 = nil }; var arg_24 any = max__3; var arg_25 any; var root_26 any = A_arbace_set_A_const_10.GetRawRoot__O(); var linked_27 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_26, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_28 lang.IFn; if linked_27 == nil { ifn_28 = lang.IFn_Cast(root_26) } else { ifn_28 = nil }; var arg_29 any; var tmp1 any = A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(max__3); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; arg_29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_30 any = coll__1; if linked_27 == nil { arg_25 = ifn_28.Invoke_O_O__O(arg_29, arg_30) } else { arg_25 = linked_27.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_26, arg_29, arg_30) }; if linked_22 == nil { return ifn_23.Invoke_O_O__O(arg_24, arg_25) } else { return linked_22.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_21, arg_24, arg_25) } }
//line :18:1
func A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(p0 any) *A_arbace_set_bubble_max_key_fn__1726000013_A { A_arbace_set_A_Init(); t := &A_arbace_set_bubble_max_key_fn__1726000013_A{}; t.Ctor_O(p0); return t }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Ctor_O(c__max any) { t.F_max = c__max }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Invoke_O_O__O(self, p1__1726000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t.F_max, p1__1726000012_SHARP___1)).Ref() }

func A_arbace_set_union_A_New() *A_arbace_set_union_A { A_arbace_set_A_Init(); t := &A_arbace_set_union_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_set_union_A) Ctor() {}
//line :20:1
func (t *A_arbace_set_union_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var root_32 any = A_arbace_set_A_const_11.GetRawRoot__O(); var linked_33 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_32, A_arbace_set_bubble_max_key_A_fn_class); var ifn_34 lang.IFn; if









	linked_33 == nil { ifn_34 = lang.IFn_Cast(root_32) } else { ifn_34 = nil }; var arg_35 any = A_arbace_set_A_const_12.GetRawRoot__O(); var arg_36 any = lang.IFn_Cast(A_arbace_set_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0); if linked_33 == nil { bubbled_sets__4 = ifn_34.Invoke_O_O__O(arg_35, arg_36) } else { bubbled_sets__4 = linked_33.(*A_arbace_set_bubble_max_key_A).Invoke_O_O_O__O(root_32, arg_35, arg_36) }; var root_43 any =
	A_arbace_set_A_const_13.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = A_arbace_set_A_const_14.GetRawRoot__O(); var arg_47 any; var root_49 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_50 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_49, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_51 lang.IFn; if linked_50 == nil { ifn_51 = lang.IFn_Cast(root_49) } else { ifn_51 = nil }; var arg_52 any = bubbled_sets__4; if linked_50 == nil { arg_47 = ifn_51.Invoke_O__O(arg_52) } else { arg_47 = linked_50.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_49, arg_52) }; var arg_48 any; var root_53 any = A_arbace_set_A_const_16.GetRawRoot__O(); var linked_54 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_53, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_55 lang.IFn; if linked_54 == nil { ifn_55 = lang.IFn_Cast(root_53) } else { ifn_55 = nil }; var arg_56 any = bubbled_sets__4; if linked_54 == nil { arg_48 = ifn_55.Invoke_O__O(arg_56) } else { arg_48 = linked_54.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_53, arg_56) }; if linked_44 == nil { return ifn_45.Invoke_O_O_O__O(arg_46, arg_47, arg_48) } else { return linked_44.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_43, arg_46, arg_47, arg_48) } }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {





	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s1__0)), int64(lang.RT_Count_O__I_NoInit(s2__1))) {
		var root_57 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = A_arbace_set_A_const_5.GetRawRoot__O(); var arg_61 any = s2__1; var arg_62 any = s1__0; if linked_58 == nil { return ifn_59.Invoke_O_O_O__O(arg_60, arg_61, arg_62) } else { return linked_58.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_57, arg_60, arg_61, arg_62) } } else {
			var root_63 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = A_arbace_set_A_const_5.GetRawRoot__O(); var arg_67 any = s1__0; var arg_68 any = s2__1; if linked_64 == nil { return ifn_65.Invoke_O_O_O__O(arg_66, arg_67, arg_68) } else { return linked_64.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_63, arg_66, arg_67, arg_68) } } }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O__O(self any) any { return lang.PersistentHashSet_EMPTY.Ref() }












func A_arbace_set_intersection_A_New() *A_arbace_set_intersection_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_set_intersection_A) Ctor() {}
//line :33:1
func (t *A_arbace_set_intersection_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var root_69 any = A_arbace_set_A_const_11.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, A_arbace_set_bubble_max_key_A_fn_class); var ifn_71 lang.IFn; if












	linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var tmp1 any = A_arbace_set_intersection_fn__1726000020_A_New(); var tmp2 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_set_intersection_fn__1726000020_A_fn_class; if fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_set_intersection_fn__1726000020_A_fn_class = fncls__74d; tmp2 = fncls__74d } else { tmp2 = fncls__74 }; arg_72 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_73 any = lang.IFn_Cast(A_arbace_set_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0); if linked_70 == nil { bubbled_sets__4 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { bubbled_sets__4 = linked_70.(*A_arbace_set_bubble_max_key_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }; var root_81 any =
	A_arbace_set_A_const_13.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = A_arbace_set_A_const_17.GetRawRoot__O(); var arg_85 any; var root_87 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any = bubbled_sets__4; if linked_88 == nil { arg_85 = ifn_89.Invoke_O__O(arg_90) } else { arg_85 = linked_88.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_87, arg_90) }; var arg_86 any; var root_91 any = A_arbace_set_A_const_16.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = bubbled_sets__4; if linked_92 == nil { arg_86 = ifn_93.Invoke_O__O(arg_94) } else { arg_86 = linked_92.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_91, arg_94) }; if linked_82 == nil { return ifn_83.Invoke_O_O_O__O(arg_84, arg_85, arg_86) } else { return linked_82.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_81, arg_84, arg_85, arg_86) } }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any { { var s1__0_2 any = s1__0; var s2__1_2 any = s2__1; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s2__1_2)), int64(lang.RT_Count_O__I_NoInit(s1__0_2))) {
		s1__0_2, s2__1_2 = s2__1_2, s1__0_2; continue L1 } else {
			var root_95 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var tmp1 any = A_arbace_set_intersection_fn__1726000018_A_New_O(s2__1_2); var tmp2 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_set_intersection_fn__1726000018_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_set_intersection_fn__1726000018_A_fn_class = fncls__111d; tmp2 = fncls__111d } else { tmp2 = fncls__111 }; arg_98 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_99 any = s1__0_2; var arg_100 any = s1__0_2; if linked_96 == nil { return ifn_97.Invoke_O_O_O__O(arg_98, arg_99, arg_100) } else { return linked_96.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_95, arg_98, arg_99, arg_100) } } } }; /*line :33:1*/panic("j2g: unreachable") }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }






func A_arbace_set_intersection_fn__1726000018_A_New_O(p0 any) *A_arbace_set_intersection_fn__1726000018_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_fn__1726000018_A{}; t.Ctor_O(p0); return t }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	var tmp1 any; var root_101 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_101, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_103 lang.IFn; if linked_102 == nil { ifn_103 = lang.IFn_Cast(root_101) } else { ifn_103 = nil }; var arg_104 any = t.F_s2; var arg_105 any = item__2; if linked_102 == nil { tmp1 = ifn_103.Invoke_O_O__O(arg_104, arg_105) } else { tmp1 = linked_102.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_101, arg_104, arg_105) }; if jrt.J2g_Truth(tmp1) { return result__1 } else {

		var root_106 any = A_arbace_set_A_const_19.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = result__1; var arg_110 any = item__2; if linked_107 == nil { return ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { return linked_107.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_106, arg_109, arg_110)
		}
	} }
func A_arbace_set_intersection_fn__1726000020_A_New() *A_arbace_set_intersection_fn__1726000020_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_fn__1726000020_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Ctor() {}
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Invoke_O_O__O(self, p1__1726000017_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(p1__1726000017_SHARP___1)))).Ref() }


func A_arbace_set_difference_A_New() *A_arbace_set_difference_A { A_arbace_set_A_Init(); t := &A_arbace_set_difference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_set_difference_A) Ctor() {}
//line :49:1
func (t *A_arbace_set_difference_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any {












	var root_112 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = A_arbace_set_A_const_20.GetRawRoot__O(); var arg_116 any = s1__0; var arg_117 any; var root_118 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_118, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_120 lang.IFn; if linked_119 == nil { ifn_120 = lang.IFn_Cast(root_118) } else { ifn_120 = nil }; var arg_121 any = sets__2; var arg_122 any = s2__1; if linked_119 == nil { arg_117 = ifn_120.Invoke_O_O__O(arg_121, arg_122) } else { arg_117 = linked_119.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_118, arg_121, arg_122) }; if linked_113 == nil { return ifn_114.Invoke_O_O_O__O(arg_115, arg_116, arg_117) } else { return linked_113.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_112, arg_115, arg_116, arg_117) } }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {




	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s1__0)), int64(lang.RT_Count_O__I_NoInit(s2__1))) {
		var root_123 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any; var tmp1 any = A_arbace_set_difference_fn__1726000023_A_New_O(s2__1); var tmp2 *jrt.Class; var fncls__139 *jrt.Class = A_arbace_set_difference_fn__1726000023_A_fn_class; if fncls__139 == nil { var fncls__139d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_set_difference_fn__1726000023_A_fn_class = fncls__139d; tmp2 = fncls__139d } else { tmp2 = fncls__139 }; arg_126 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_127 any = s1__0; var arg_128 any = s1__0; if linked_124 == nil { return ifn_125.Invoke_O_O_O__O(arg_126, arg_127, arg_128) } else { return linked_124.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_123, arg_126, arg_127, arg_128) } } else {




			var root_140 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = A_arbace_set_A_const_19.GetRawRoot__O(); var arg_144 any = s1__0; var arg_145 any = s2__1; if linked_141 == nil { return ifn_142.Invoke_O_O_O__O(arg_143, arg_144, arg_145) } else { return linked_141.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_140, arg_143, arg_144, arg_145) } } }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }





func A_arbace_set_difference_fn__1726000023_A_New_O(p0 any) *A_arbace_set_difference_fn__1726000023_A { A_arbace_set_A_Init(); t := &A_arbace_set_difference_fn__1726000023_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	var tmp1 any; var root_129 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_129, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_131 lang.IFn; if linked_130 == nil { ifn_131 = lang.IFn_Cast(root_129) } else { ifn_131 = nil }; var arg_132 any = t.F_s2; var arg_133 any = item__2; if linked_130 == nil { tmp1 = ifn_131.Invoke_O_O__O(arg_132, arg_133) } else { tmp1 = linked_130.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_129, arg_132, arg_133) }; if jrt.J2g_Truth(tmp1) {
		var root_134 any = A_arbace_set_A_const_19.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = result__1; var arg_138 any = item__2; if linked_135 == nil { return ifn_136.Invoke_O_O__O(arg_137, arg_138) } else { return linked_135.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_134, arg_137, arg_138) } } else {
//line :56:1
			return result__1
		}
}





func A_arbace_set_select_A_New() *A_arbace_set_select_A { A_arbace_set_A_Init(); t := &A_arbace_set_select_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_set_select_A) Ctor() {}
//line :64:1
func (t *A_arbace_set_select_A) Invoke_O_O_O__O(self, pred__0, xset__1 any) any {



	var root_146 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any; var tmp1 any = A_arbace_set_select_fn__1726000026_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__157 *jrt.Class = A_arbace_set_select_fn__1726000026_A_fn_class; if fncls__157 == nil { var fncls__157d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_set_select_fn__1726000026_A_fn_class = fncls__157d; tmp2 = fncls__157d } else { tmp2 = fncls__157 }; arg_149 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_150 any = xset__1; var arg_151 any = xset__1; if linked_147 == nil { return ifn_148.Invoke_O_O_O__O(arg_149, arg_150, arg_151) } else { return linked_147.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_146, arg_149, arg_150, arg_151) } }
//line :68:1
func A_arbace_set_select_fn__1726000026_A_New_O(p0 any) *A_arbace_set_select_fn__1726000026_A { A_arbace_set_A_Init(); t := &A_arbace_set_select_fn__1726000026_A{}; t.Ctor_O(p0); return t }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Invoke_O_O_O__O(self, s__1, k__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(k__2)) { return s__1 } else { var root_152 any = A_arbace_set_A_const_19.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any = s__1; var arg_156 any = k__2; if linked_153 == nil { return ifn_154.Invoke_O_O__O(arg_155, arg_156) } else { return linked_153.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_152, arg_155, arg_156) } } }


func A_arbace_set_project_A_New() *A_arbace_set_project_A { A_arbace_set_A_Init(); t := &A_arbace_set_project_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_set_project_A) Ctor() {}
//line :71:1
func (t *A_arbace_set_project_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {



	var root_158 any = A_arbace_set_A_const_21.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any; var root_163 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any; var root_167 any = A_arbace_set_A_const_23.GetRawRoot__O(); var linked_168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_167, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_169 lang.IFn; if linked_168 == nil { ifn_169 = lang.IFn_Cast(root_167) } else { ifn_169 = nil }; var arg_170 any; var tmp1 any = A_arbace_set_project_fn__1726000030_A_New_O(ks__1); var tmp2 *jrt.Class; var fncls__177 *jrt.Class = A_arbace_set_project_fn__1726000030_A_fn_class; if fncls__177 == nil { var fncls__177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_set_project_fn__1726000030_A_fn_class = fncls__177d; tmp2 = fncls__177d } else { tmp2 = fncls__177 }; arg_170 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_171 any = xrel__0; if linked_168 == nil { arg_166 = ifn_169.Invoke_O_O__O(arg_170, arg_171) } else { arg_166 = linked_168.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_167, arg_170, arg_171) }; if linked_164 == nil { arg_161 = ifn_165.Invoke_O__O(arg_166) } else { arg_161 = linked_164.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_163, arg_166) }; var arg_162 any = lang.RT_Meta_O__IPersistentMap_NoInit(xrel__0); if linked_159 == nil { return ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { return linked_159.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) } }
//line :75:1
func A_arbace_set_project_fn__1726000030_A_New_O(p0 any) *A_arbace_set_project_fn__1726000030_A { A_arbace_set_A_Init(); t := &A_arbace_set_project_fn__1726000030_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Invoke_O_O__O(self, p1__1726000029_SHARP___1 any) any { var root_172 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_172, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_174 lang.IFn; if linked_173 == nil { ifn_174 = lang.IFn_Cast(root_172) } else { ifn_174 = nil }; var arg_175 any = p1__1726000029_SHARP___1; var arg_176 any = t.F_ks; if linked_173 == nil { return ifn_174.Invoke_O_O__O(arg_175, arg_176) } else { return linked_173.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_172, arg_175, arg_176) } }

func A_arbace_set_rename_keys_A_New() *A_arbace_set_rename_keys_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_keys_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_set_rename_keys_A) Ctor() {}
//line :77:1
func (t *A_arbace_set_rename_keys_A) Invoke_O_O_O__O(self, map__0, kmap__1 any) any {



	var root_178 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any; var tmp1 any = A_arbace_set_rename_keys_fn__1726000034_A_New_O(map__0); var tmp2 *jrt.Class; var fncls__195 *jrt.Class = A_arbace_set_rename_keys_fn__1726000034_A_fn_class
	if fncls__195 == nil { var fncls__195d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_set_rename_keys_fn__1726000034_A_fn_class = fncls__195d; tmp2 = fncls__195d } else { tmp2 = fncls__195 }; arg_181 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :81:1
	var arg_182 any; var root_196 any = A_arbace_set_A_const_7.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_198 lang.IFn




	if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_set_A_const_26.GetRawRoot__O(); var arg_200 any = map__0; var arg_201 any; var root_202 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = kmap__1; if linked_203 == nil { arg_201 = ifn_204.Invoke_O__O(arg_205) } else { arg_201 = linked_203.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_202, arg_205) }; if linked_197 == nil { arg_182 = ifn_198.Invoke_O_O_O__O(arg_199, arg_200, arg_201) } else { arg_182 = linked_197.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_196, arg_199, arg_200, arg_201) }
//line :81:1
	var arg_183 any = kmap__1; if linked_179 == nil { return ifn_180.Invoke_O_O_O__O(arg_181, arg_182, arg_183) } else { return linked_179.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_178, arg_181, arg_182, arg_183) } }
func A_arbace_set_rename_keys_fn__1726000034_A_New_O(p0 any) *A_arbace_set_rename_keys_fn__1726000034_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_keys_fn__1726000034_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Ctor_O(c__map any) { t.F_map = c__map }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Invoke_O_O_O__O(self, m__1, p__1726000033__2 any) any { var vec__1726000035__3 any = p__1726000033__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000035__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000035__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_184 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_186 lang.IFn; if
														linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any = t.F_map; var arg_188 any = old__4; if linked_185 == nil { tmp1 = ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { tmp1 = linked_185.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_184, arg_187, arg_188) }; if jrt.J2g_Truth(tmp1) {
															var root_189 any = A_arbace_set_A_const_25.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = m__1; var arg_193 any = new__5; var arg_194 any = lang.RT_Get_O_O__O_NoInit(t.F_map, old__4); if linked_190 == nil { return ifn_191.Invoke_O_O_O__O(arg_192, arg_193, arg_194) } else { return linked_190.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_189, arg_192, arg_193, arg_194) } } else {
//line :83:1
			return m__1 } }




func A_arbace_set_rename_A_New() *A_arbace_set_rename_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_set_rename_A) Ctor() {}
//line :88:1
func (t *A_arbace_set_rename_A) Invoke_O_O_O__O(self, xrel__0, kmap__1 any) any {



	var root_206 any = A_arbace_set_A_const_21.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var root_211 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var root_215 any = A_arbace_set_A_const_23.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var tmp1 any = A_arbace_set_rename_fn__1726000041_A_New_O(kmap__1); var tmp2 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_set_rename_fn__1726000041_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_set_rename_fn__1726000041_A_fn_class = fncls__225d; tmp2 = fncls__225d } else { tmp2 = fncls__225 }; arg_218 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_219 any = xrel__0; if linked_216 == nil { arg_214 = ifn_217.Invoke_O_O__O(arg_218, arg_219) } else { arg_214 = linked_216.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_215, arg_218, arg_219) }; if linked_212 == nil { arg_209 = ifn_213.Invoke_O__O(arg_214) } else { arg_209 = linked_212.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_211, arg_214) }; var arg_210 any = lang.RT_Meta_O__IPersistentMap_NoInit(xrel__0); if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } }
//line :92:1
func A_arbace_set_rename_fn__1726000041_A_New_O(p0 any) *A_arbace_set_rename_fn__1726000041_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_fn__1726000041_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Ctor_O(c__kmap any) { t.F_kmap = c__kmap }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Invoke_O_O__O(self, p1__1726000040_SHARP___1 any) any { var root_220 any = A_arbace_set_A_const_28.GetRawRoot__O(); var linked_221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_220, A_arbace_set_rename_keys_A_fn_class); var ifn_222 lang.IFn; if linked_221 == nil { ifn_222 = lang.IFn_Cast(root_220) } else { ifn_222 = nil }; var arg_223 any = p1__1726000040_SHARP___1; var arg_224 any = t.F_kmap; if linked_221 == nil { return ifn_222.Invoke_O_O__O(arg_223, arg_224) } else { return linked_221.(*A_arbace_set_rename_keys_A).Invoke_O_O_O__O(root_220, arg_223, arg_224) } }

func A_arbace_set_index_A_New() *A_arbace_set_index_A { A_arbace_set_A_Init(); t := &A_arbace_set_index_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_set_index_A) Ctor() {}
//line :94:1
func (t *A_arbace_set_index_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {




	var root_226 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any; var tmp1 any = A_arbace_set_index_fn__1726000044_A_New_O(ks__1); var tmp2 *jrt.Class; var fncls__248 *jrt.Class = A_arbace_set_index_fn__1726000044_A_fn_class
	if fncls__248 == nil { var fncls__248d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_set_index_fn__1726000044_A_fn_class = fncls__248d; tmp2 = fncls__248d } else { tmp2 = fncls__248 }; arg_229 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :99:1
	var arg_230 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_231 any = xrel__0; if linked_227 == nil { return ifn_228.Invoke_O_O_O__O(arg_229, arg_230, arg_231) } else { return linked_227.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_226, arg_229, arg_230, arg_231) } }
func A_arbace_set_index_fn__1726000044_A_New_O(p0 any) *A_arbace_set_index_fn__1726000044_A { A_arbace_set_A_Init(); t := &A_arbace_set_index_fn__1726000044_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Invoke_O_O_O__O(self, m__1, x__2 any) any { var ik__3 any; var root_232 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_234 lang.IFn; if
											linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = x__2; var arg_236 any = t.F_ks; if linked_233 == nil { ik__3 = ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { ik__3 = linked_233.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) }; var root_237 any =
											A_arbace_set_A_const_25.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = m__1; var arg_241 any = ik__3; var arg_242 any; var root_243 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = lang.RT_Get_O_O_O__O_NoInit(m__1, ik__3, lang.PersistentHashSet_EMPTY.Ref()); var arg_247 any = x__2; if linked_244 == nil { arg_242 = ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { arg_242 = linked_244.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) }; if linked_238 == nil { return ifn_239.Invoke_O_O_O__O(arg_240, arg_241, arg_242) } else { return linked_238.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_237, arg_240, arg_241, arg_242) } }


func A_arbace_set_map_invert_A_New() *A_arbace_set_map_invert_A { A_arbace_set_A_Init(); t := &A_arbace_set_map_invert_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_set_map_invert_A) Ctor() {}
//line :105:1
func (t *A_arbace_set_map_invert_A) Invoke_O_O__O(self, m__0 any) any {



	var root_249 any = A_arbace_set_A_const_29.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any; var root_253 any = A_arbace_set_A_const_30.GetRawRoot__O(); var linked_254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_253, aot_arbace_core.A_arbace_core_reduce_kv_A_fn_class); var ifn_255 lang.IFn
	if linked_254 == nil { ifn_255 = lang.IFn_Cast(root_253) } else { ifn_255 = nil }; var arg_256 any; var tmp1 any = A_arbace_set_map_invert_fn__1726000047_A_New(); var tmp2 *jrt.Class; var fncls__265 *jrt.Class = A_arbace_set_map_invert_fn__1726000047_A_fn_class; if fncls__265 == nil { var fncls__265d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_set_map_invert_fn__1726000047_A_fn_class = fncls__265d; tmp2 = fncls__265d } else { tmp2 = fncls__265 }; arg_256 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_257 any; var root_266 any = A_arbace_set_A_const_32.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_268 lang.IFn
	if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_267 == nil { arg_257 = ifn_268.Invoke_O__O(arg_269) } else { arg_257 = linked_267.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_266, arg_269) }
//line :110:1
	var arg_258 any = m__0; if linked_254 == nil { arg_252 = ifn_255.Invoke_O_O_O__O(arg_256, arg_257, arg_258) } else { arg_252 = linked_254.(*aot_arbace_core.A_arbace_core_reduce_kv_A).Invoke_O_O_O_O__O(root_253, arg_256, arg_257, arg_258) }
//line :109:1
	if linked_250 == nil { return ifn_251.Invoke_O__O(arg_252) } else { return linked_250.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_249, arg_252) } }
func A_arbace_set_map_invert_fn__1726000047_A_New() *A_arbace_set_map_invert_fn__1726000047_A { A_arbace_set_A_Init(); t := &A_arbace_set_map_invert_fn__1726000047_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Ctor() {}
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Invoke_O_O_O_O__O(self, m__1, k__2, v__3 any) any { var root_259 any = A_arbace_set_A_const_31.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_assoc_BANG__A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = m__1; var arg_263 any = v__3; var arg_264 any = k__2; if linked_260 == nil { return ifn_261.Invoke_O_O_O__O(arg_262, arg_263, arg_264) } else { return linked_260.(*aot_arbace_core.A_arbace_core_assoc_BANG__A).Invoke_O_O_O_O__O(root_259, arg_262, arg_263, arg_264) } }



func A_arbace_set_join_A_New() *A_arbace_set_join_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_set_join_A) Ctor() {}
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O_O__O(self, xrel__0, yrel__1, km__2 any) any { var vec__1726000061__4 any; if



















	lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xrel__0)), int64(lang.RT_Count_O__I_NoInit(yrel__1))) { var tmp1 any; var root_317 any = A_arbace_set_A_const_36.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, A_arbace_set_map_invert_A_fn_class); var ifn_319 lang.IFn
		if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = km__2; if linked_318 == nil { tmp1 = ifn_319.Invoke_O__O(arg_320) } else { tmp1 = linked_318.(*A_arbace_set_map_invert_A).Invoke_O_O__O(root_317, arg_320) }
//line :134:1
		vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(xrel__0, yrel__1, tmp1) } else { vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(yrel__1, xrel__0, km__2) }; var r__5 any = /*line :114:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(2), nil); var idx__8 any; var root_270 any = A_arbace_set_A_const_33.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, A_arbace_set_index_A_fn_class); var ifn_272 lang.IFn; if






















	linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = r__5; var arg_274 any; var root_275 any = A_arbace_set_A_const_34.GetRawRoot__O(); var linked_276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_275, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_277 lang.IFn; if linked_276 == nil { ifn_277 = lang.IFn_Cast(root_275) } else { ifn_277 = nil }; var arg_278 any = k__7; if linked_276 == nil { arg_274 = ifn_277.Invoke_O__O(arg_278) } else { arg_274 = linked_276.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_275, arg_278) }; if linked_271 == nil { idx__8 = ifn_272.Invoke_O_O__O(arg_273, arg_274) } else { idx__8 = linked_271.(*A_arbace_set_index_A).Invoke_O_O_O__O(root_270, arg_273, arg_274) }; var root_279 any =
	A_arbace_set_A_const_13.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any; var tmp2 any = A_arbace_set_join_fn__1726000064_A_New_O_O(k__7, idx__8); var tmp3 *jrt.Class; var fncls__316 *jrt.Class = A_arbace_set_join_fn__1726000064_A_fn_class; if fncls__316 == nil { var fncls__316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_set_join_fn__1726000064_A_fn_class = fncls__316d; tmp3 = fncls__316d } else { tmp3 = fncls__316 }; arg_282 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_283 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_284 any = s__6; if linked_280 == nil { return ifn_281.Invoke_O_O_O__O(arg_282, arg_283, arg_284) } else { return linked_280.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_279, arg_282, arg_283, arg_284) } }
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O__O(self, xrel__0, yrel__1 any) any {





	var tmp1 any; var and__1927000168__auto____3 any; var root_321 any = A_arbace_set_A_const_37.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = xrel__0; if linked_322 == nil { and__1927000168__auto____3 = ifn_323.Invoke_O__O(arg_324) } else { and__1927000168__auto____3 = linked_322.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_325 any = A_arbace_set_A_const_37.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = yrel__1; if linked_326 == nil { tmp1 = ifn_327.Invoke_O__O(arg_328) } else { tmp1 = linked_326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_325, arg_328) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var ks__3 any; var root_329 any = A_arbace_set_A_const_17.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_329, A_arbace_set_intersection_A_fn_class); var ifn_331 lang.IFn
		if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any; var root_334 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any; var root_338 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any; var root_342 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = xrel__0; if linked_343 == nil { arg_341 = ifn_344.Invoke_O__O(arg_345) } else { arg_341 = linked_343.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_342, arg_345) }; if linked_339 == nil { arg_337 = ifn_340.Invoke_O__O(arg_341) } else { arg_337 = linked_339.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_338, arg_341) }; if linked_335 == nil { arg_332 = ifn_336.Invoke_O__O(arg_337) } else { arg_332 = linked_335.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_334, arg_337) }; var arg_333 any; var root_346 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_346, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_348 lang.IFn; if linked_347 == nil { ifn_348 = lang.IFn_Cast(root_346) } else { ifn_348 = nil }; var arg_349 any; var root_350 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_351 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_350, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_352 lang.IFn; if linked_351 == nil { ifn_352 = lang.IFn_Cast(root_350) } else { ifn_352 = nil }; var arg_353 any; var root_354 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_356 lang.IFn; if linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = yrel__1; if linked_355 == nil { arg_353 = ifn_356.Invoke_O__O(arg_357) } else { arg_353 = linked_355.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_354, arg_357) }; if linked_351 == nil { arg_349 = ifn_352.Invoke_O__O(arg_353) } else { arg_349 = linked_351.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_350, arg_353) }; if linked_347 == nil { arg_333 = ifn_348.Invoke_O__O(arg_349) } else { arg_333 = linked_347.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_346, arg_349) }; if linked_330 == nil { ks__3 = ifn_331.Invoke_O_O__O(arg_332, arg_333) } else { ks__3 = linked_330.(*A_arbace_set_intersection_A).Invoke_O_O_O__O(root_329, arg_332, arg_333) }
//line :120:1
		var vec__1726000054__4 any

		if lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xrel__0)), int64(lang.RT_Count_O__I_NoInit(yrel__1))) { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(xrel__0, yrel__1) } else { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(yrel__1, xrel__0) }
//line :120:1
		var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000054__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000054__4, lang.RT_IntCast_J__I_NoInit(1), nil); var idx__7 any; var root_358 any = A_arbace_set_A_const_33.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_set_index_A_fn_class); var ifn_360 lang.IFn




		if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = r__5; var arg_362 any = ks__3; if linked_359 == nil { idx__7 = ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { idx__7 = linked_359.(*A_arbace_set_index_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) }
		var root_363 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any; var tmp2 any = A_arbace_set_join_fn__1726000057_A_New_O_O(ks__3, idx__7); var tmp3 *jrt.Class; var fncls__391 *jrt.Class = A_arbace_set_join_fn__1726000057_A_fn_class; if fncls__391 == nil { var fncls__391d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_set_join_fn__1726000057_A_fn_class = fncls__391d; tmp3 = fncls__391d } else { tmp3 = fncls__391 }; arg_366 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_367 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_368 any = s__6; if linked_364 == nil { return ifn_365.Invoke_O_O_O__O(arg_366, arg_367, arg_368) } else { return linked_364.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_363, arg_366, arg_367, arg_368) } } else {
//line :120:1
			return lang.PersistentHashSet_EMPTY.Ref()
		}
}



func A_arbace_set_join_fn__1726000057_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000057_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Ctor_O_O(c__ks, c__idx any) { t.F_ks = c__ks; t.F_idx = c__idx }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var found__3 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var tmp2 any; var root_386 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_388 lang.IFn; if
												linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = x__2; var arg_390 any = t.F_ks; if linked_387 == nil { tmp2 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { tmp2 = linked_387.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }; found__3 = tmp1.Invoke_O__O(tmp2); if
												jrt.J2g_Truth(found__3) {
													var root_369 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any; var tmp3 any = A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(x__2); var tmp4 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class = fncls__385d; tmp4 = fncls__385d } else { tmp4 = fncls__385 }; arg_372 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_373 any = ret__1; var arg_374 any = found__3; if linked_370 == nil { return ifn_371.Invoke_O_O_O__O(arg_372, arg_373, arg_374) } else { return linked_370.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_369, arg_372, arg_373, arg_374) } } else {
//line :128:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(p0 any) *A_arbace_set_join_fn__1726000057_fn__1726000058_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000057_fn__1726000058_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Invoke_O_O_O__O(self, p1__1726000050_SHARP___1, p2__1726000051_SHARP___2 any) any { var root_375 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_376 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_375, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_377 lang.IFn; if linked_376 == nil { ifn_377 = lang.IFn_Cast(root_375) } else { ifn_377 = nil }; var arg_378 any = p1__1726000050_SHARP___1; var arg_379 any; var root_380 any = A_arbace_set_A_const_35.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_382 lang.IFn; if linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = p2__1726000051_SHARP___2; var arg_384 any = t.F_x; if linked_381 == nil { arg_379 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { arg_379 = linked_381.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; if linked_376 == nil { return ifn_377.Invoke_O_O__O(arg_378, arg_379) } else { return linked_376.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_375, arg_378, arg_379) } }








func A_arbace_set_join_fn__1726000064_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000064_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Ctor_O_O(c__k, c__idx any) { t.F_k = c__k; t.F_idx = c__idx }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var found__3 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var tmp2 any; var root_302 any = A_arbace_set_A_const_28.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, A_arbace_set_rename_keys_A_fn_class); var ifn_304 lang.IFn; if
												linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any; var root_307 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any = x__2; var arg_311 any; var root_312 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_314 lang.IFn; if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = t.F_k; if linked_313 == nil { arg_311 = ifn_314.Invoke_O__O(arg_315) } else { arg_311 = linked_313.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_312, arg_315) }; if linked_308 == nil { arg_305 = ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { arg_305 = linked_308.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) }; var arg_306 any = t.F_k; if linked_303 == nil { tmp2 = ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { tmp2 = linked_303.(*A_arbace_set_rename_keys_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) }; found__3 = tmp1.Invoke_O__O(tmp2); if
												jrt.J2g_Truth(found__3) {
													var root_285 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any; var tmp3 any = A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(x__2); var tmp4 *jrt.Class; var fncls__301 *jrt.Class = A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class; if fncls__301 == nil { var fncls__301d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class = fncls__301d; tmp4 = fncls__301d } else { tmp4 = fncls__301 }; arg_288 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_289 any = ret__1; var arg_290 any = found__3; if linked_286 == nil { return ifn_287.Invoke_O_O_O__O(arg_288, arg_289, arg_290) } else { return linked_286.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_285, arg_288, arg_289, arg_290) } } else {
//line :140:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(p0 any) *A_arbace_set_join_fn__1726000064_fn__1726000065_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000064_fn__1726000065_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Invoke_O_O_O__O(self, p1__1726000052_SHARP___1, p2__1726000053_SHARP___2 any) any { var root_291 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_292 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_291, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_293 lang.IFn; if linked_292 == nil { ifn_293 = lang.IFn_Cast(root_291) } else { ifn_293 = nil }; var arg_294 any = p1__1726000052_SHARP___1; var arg_295 any; var root_296 any = A_arbace_set_A_const_35.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = p2__1726000053_SHARP___2; var arg_300 any = t.F_x; if linked_297 == nil { arg_295 = ifn_298.Invoke_O_O__O(arg_299, arg_300) } else { arg_295 = linked_297.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_296, arg_299, arg_300) }; if linked_292 == nil { return ifn_293.Invoke_O_O__O(arg_294, arg_295) } else { return linked_292.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_291, arg_294, arg_295) } }



func A_arbace_set_subset_QMARK__A_New() *A_arbace_set_subset_QMARK__A { A_arbace_set_A_Init(); t := &A_arbace_set_subset_QMARK__A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Ctor() {}
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(set1__0)), int64(lang.RT_Count_O__I_NoInit(set2__1))); if and__1927000168__auto____3 {





	var root_392 any = A_arbace_set_A_const_38.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any; var tmp1 any = A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(set2__1); var tmp2 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class; if fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class = fncls__402d; tmp2 = fncls__402d } else { tmp2 = fncls__402 }; arg_395 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_396 any = set1__0; if linked_393 == nil { return ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { return linked_393.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_392, arg_395, arg_396) } } else {
//line :150:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(p0 any) *A_arbace_set_subset_QMARK__fn__1726000070_A { A_arbace_set_A_Init(); t := &A_arbace_set_subset_QMARK__fn__1726000070_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Ctor_O(c__set2 any) { t.F_set2 = c__set2 }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Invoke_O_O__O(self, p1__1726000069_SHARP___1 any) any { var root_397 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_397, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_399 lang.IFn; if linked_398 == nil { ifn_399 = lang.IFn_Cast(root_397) } else { ifn_399 = nil }; var arg_400 any = t.F_set2; var arg_401 any = p1__1726000069_SHARP___1; if linked_398 == nil { return ifn_399.Invoke_O_O__O(arg_400, arg_401) } else { return linked_398.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_397, arg_400, arg_401) } }

func A_arbace_set_superset_QMARK__A_New() *A_arbace_set_superset_QMARK__A { A_arbace_set_A_Init(); t := &A_arbace_set_superset_QMARK__A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Ctor() {}
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(set1__0)), int64(lang.RT_Count_O__I_NoInit(set2__1))); if and__1927000168__auto____3 {





	var root_403 any = A_arbace_set_A_const_38.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any; var tmp1 any = A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(set1__0); var tmp2 *jrt.Class; var fncls__413 *jrt.Class = A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class; if fncls__413 == nil { var fncls__413d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class = fncls__413d; tmp2 = fncls__413d } else { tmp2 = fncls__413 }; arg_406 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_407 any = set2__1; if linked_404 == nil { return ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { return linked_404.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_403, arg_406, arg_407) } } else {
//line :158:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(p0 any) *A_arbace_set_superset_QMARK__fn__1726000074_A { A_arbace_set_A_Init(); t := &A_arbace_set_superset_QMARK__fn__1726000074_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Ctor_O(c__set1 any) { t.F_set1 = c__set1 }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Invoke_O_O__O(self, p1__1726000073_SHARP___1 any) any { var root_408 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = t.F_set1; var arg_412 any = p1__1726000073_SHARP___1; if linked_409 == nil { return ifn_410.Invoke_O_O__O(arg_411, arg_412) } else { return linked_409.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_408, arg_411, arg_412) } }





















































type A_arbace_set_A struct{ jrt.Object }

var A_arbace_set_A_const_pool *jrt.RefArray

var A_arbace_set_A_const_0 *lang.Var

var A_arbace_set_A_const_1 any

var A_arbace_set_A_const_2 *lang.Var

var A_arbace_set_A_const_3 *lang.Var

var A_arbace_set_A_const_4 *lang.Var

var A_arbace_set_A_const_5 *lang.Var

var A_arbace_set_A_const_6 any

var A_arbace_set_A_const_7 *lang.Var

var A_arbace_set_A_const_8 *lang.Var

var A_arbace_set_A_const_9 *lang.Var

var A_arbace_set_A_const_10 *lang.Var

var A_arbace_set_A_const_11 *lang.Var

var A_arbace_set_A_const_12 *lang.Var

var A_arbace_set_A_const_13 *lang.Var

var A_arbace_set_A_const_14 *lang.Var

var A_arbace_set_A_const_15 *lang.Var

var A_arbace_set_A_const_16 *lang.Var

var A_arbace_set_A_const_17 *lang.Var

var A_arbace_set_A_const_18 *lang.Var

var A_arbace_set_A_const_19 *lang.Var

var A_arbace_set_A_const_20 *lang.Var

var A_arbace_set_A_const_21 *lang.Var

var A_arbace_set_A_const_22 *lang.Var

var A_arbace_set_A_const_23 *lang.Var

var A_arbace_set_A_const_24 *lang.Var

var A_arbace_set_A_const_25 *lang.Var

var A_arbace_set_A_const_26 *lang.Var

var A_arbace_set_A_const_27 *lang.Var

var A_arbace_set_A_const_28 *lang.Var

var A_arbace_set_A_const_29 *lang.Var

var A_arbace_set_A_const_30 *lang.Var

var A_arbace_set_A_const_31 *lang.Var

var A_arbace_set_A_const_32 *lang.Var

var A_arbace_set_A_const_33 *lang.Var

var A_arbace_set_A_const_34 *lang.Var

var A_arbace_set_A_const_35 *lang.Var

var A_arbace_set_A_const_36 *lang.Var

var A_arbace_set_A_const_37 *lang.Var

var A_arbace_set_A_const_38 *lang.Var

var A_arbace_set_A_init jrt.ClassInit

func A_arbace_set_A_Init() { if !A_arbace_set_A_init.Done() { A_arbace_set_A_init.Run(A_arbace_set_A_clinit) } }

func A_arbace_set_A_clinit() { A_arbace_set_A_clinit_p0(); A_arbace_set_A_clinit_p1(); A_arbace_set_A_clinit_p2(); A_arbace_set_A_clinit_p3() }

func A_arbace_set_A_clinit_p0() { jrt.StartCheck(); A_arbace_set_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 42); A_arbace_set_A_const_0 = lang.Var_Cast(A_arbace_set_A_const_pool.A[3]); A_arbace_set_A_const_1 = A_arbace_set_A_const_pool.A[4]; A_arbace_set_A_const_2 = lang.Var_Cast(A_arbace_set_A_const_pool.A[5]); A_arbace_set_A_const_3 = lang.Var_Cast(A_arbace_set_A_const_pool.A[6]); A_arbace_set_A_const_4 = lang.Var_Cast(A_arbace_set_A_const_pool.A[7]); A_arbace_set_A_const_5 = lang.Var_Cast(A_arbace_set_A_const_pool.A[8]); A_arbace_set_A_const_6 = A_arbace_set_A_const_pool.A[9]; A_arbace_set_A_const_7 = lang.Var_Cast(A_arbace_set_A_const_pool.A[10]); A_arbace_set_A_const_8 = lang.Var_Cast(A_arbace_set_A_const_pool.A[11]); A_arbace_set_A_const_9 = lang.Var_Cast(A_arbace_set_A_const_pool.A[12]); A_arbace_set_A_const_10 = lang.Var_Cast(A_arbace_set_A_const_pool.A[13]) }

func A_arbace_set_A_clinit_p1() { A_arbace_set_A_const_11 = lang.Var_Cast(A_arbace_set_A_const_pool.A[14]); A_arbace_set_A_const_12 = lang.Var_Cast(A_arbace_set_A_const_pool.A[15]); A_arbace_set_A_const_13 = lang.Var_Cast(A_arbace_set_A_const_pool.A[16]); A_arbace_set_A_const_14 = lang.Var_Cast(A_arbace_set_A_const_pool.A[17]); A_arbace_set_A_const_15 = lang.Var_Cast(A_arbace_set_A_const_pool.A[18]); A_arbace_set_A_const_16 = lang.Var_Cast(A_arbace_set_A_const_pool.A[19]); A_arbace_set_A_const_17 = lang.Var_Cast(A_arbace_set_A_const_pool.A[20]); A_arbace_set_A_const_18 = lang.Var_Cast(A_arbace_set_A_const_pool.A[21]); A_arbace_set_A_const_19 = lang.Var_Cast(A_arbace_set_A_const_pool.A[22]); A_arbace_set_A_const_20 = lang.Var_Cast(A_arbace_set_A_const_pool.A[23]); A_arbace_set_A_const_21 = lang.Var_Cast(A_arbace_set_A_const_pool.A[24]); A_arbace_set_A_const_22 = lang.Var_Cast(A_arbace_set_A_const_pool.A[25]) }

func A_arbace_set_A_clinit_p2() { A_arbace_set_A_const_23 = lang.Var_Cast(A_arbace_set_A_const_pool.A[26]); A_arbace_set_A_const_24 = lang.Var_Cast(A_arbace_set_A_const_pool.A[27]); A_arbace_set_A_const_25 = lang.Var_Cast(A_arbace_set_A_const_pool.A[28]); A_arbace_set_A_const_26 = lang.Var_Cast(A_arbace_set_A_const_pool.A[29]); A_arbace_set_A_const_27 = lang.Var_Cast(A_arbace_set_A_const_pool.A[30]); A_arbace_set_A_const_28 = lang.Var_Cast(A_arbace_set_A_const_pool.A[31]); A_arbace_set_A_const_29 = lang.Var_Cast(A_arbace_set_A_const_pool.A[32]); A_arbace_set_A_const_30 = lang.Var_Cast(A_arbace_set_A_const_pool.A[33]); A_arbace_set_A_const_31 = lang.Var_Cast(A_arbace_set_A_const_pool.A[34]); A_arbace_set_A_const_32 = lang.Var_Cast(A_arbace_set_A_const_pool.A[35]); A_arbace_set_A_const_33 = lang.Var_Cast(A_arbace_set_A_const_pool.A[36]); A_arbace_set_A_const_34 = lang.Var_Cast(A_arbace_set_A_const_pool.A[37]) }

func A_arbace_set_A_clinit_p3() { A_arbace_set_A_const_35 = lang.Var_Cast(A_arbace_set_A_const_pool.A[38]); A_arbace_set_A_const_36 = lang.Var_Cast(A_arbace_set_A_const_pool.A[39]); A_arbace_set_A_const_37 = lang.Var_Cast(A_arbace_set_A_const_pool.A[40]); A_arbace_set_A_const_38 = lang.Var_Cast(A_arbace_set_A_const_pool.A[41]) }

func A_arbace_set_A_New() *A_arbace_set_A { A_arbace_set_A_Init(); t := &A_arbace_set_A{}; t.Ctor(); return t }

func (t *A_arbace_set_A) Ctor() {}

func (t *A_arbace_set_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_A) GetClass__Class() *jrt.Class { return A_arbace_set_A_class }

func (t *A_arbace_set_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_A); return ok }

func A_arbace_set_A_Cast(x any) *A_arbace_set_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_A_class)) }; return v }



type A_arbace_set_bubble_max_key_A struct{ j2g_header uint64 }

var A_arbace_set_bubble_max_key_A_fn_class *jrt.Class



type A_arbace_set_bubble_max_key_fn__1726000013_A struct{ j2g_header uint64; F_max any }

var A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class *jrt.Class



type A_arbace_set_difference_A struct{ j2g_header uint64 }

var A_arbace_set_difference_A_fn_class *jrt.Class



type A_arbace_set_difference_fn__1726000023_A struct{ j2g_header uint64; F_s2 any }

var A_arbace_set_difference_fn__1726000023_A_fn_class *jrt.Class



type A_arbace_set_eval1726000004_A struct{ jrt.Object }

func A_arbace_set_eval1726000004_A_New() *A_arbace_set_eval1726000004_A { t := &A_arbace_set_eval1726000004_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000004_A) Ctor() {}

func (t *A_arbace_set_eval1726000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000004_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000004_A_class }

func (t *A_arbace_set_eval1726000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000004_A); return ok }

func A_arbace_set_eval1726000004_A_Cast(x any) *A_arbace_set_eval1726000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000004_A_class)) }; return v }



type A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A struct{ j2g_header uint64 }

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class *jrt.Class



type A_arbace_set_eval1726000008_A struct{ jrt.Object }

func A_arbace_set_eval1726000008_A_New() *A_arbace_set_eval1726000008_A { t := &A_arbace_set_eval1726000008_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000008_A) Ctor() {}

func (t *A_arbace_set_eval1726000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000008_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000008_A_class }

func (t *A_arbace_set_eval1726000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000008_A); return ok }

func A_arbace_set_eval1726000008_A_Cast(x any) *A_arbace_set_eval1726000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000008_A_class)) }; return v }



type A_arbace_set_eval1726000008_fn__1726000009_A struct{ j2g_header uint64 }

var A_arbace_set_eval1726000008_fn__1726000009_A_fn_class *jrt.Class



type A_arbace_set_index_A struct{ j2g_header uint64 }

var A_arbace_set_index_A_fn_class *jrt.Class



type A_arbace_set_index_fn__1726000044_A struct{ j2g_header uint64; F_ks any }

var A_arbace_set_index_fn__1726000044_A_fn_class *jrt.Class



type A_arbace_set_intersection_A struct{ j2g_header uint64 }

var A_arbace_set_intersection_A_fn_class *jrt.Class



type A_arbace_set_intersection_fn__1726000018_A struct{ j2g_header uint64; F_s2 any }

var A_arbace_set_intersection_fn__1726000018_A_fn_class *jrt.Class



type A_arbace_set_intersection_fn__1726000020_A struct{ j2g_header uint64 }

var A_arbace_set_intersection_fn__1726000020_A_fn_class *jrt.Class



type A_arbace_set_join_A struct{ j2g_header uint64 }

var A_arbace_set_join_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000057_A struct{ j2g_header uint64; F_ks, F_idx any }

var A_arbace_set_join_fn__1726000057_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000057_fn__1726000058_A struct{ j2g_header uint64; F_x any }

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000064_A struct{ j2g_header uint64; F_k, F_idx any }

var A_arbace_set_join_fn__1726000064_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000064_fn__1726000065_A struct{ j2g_header uint64; F_x any }

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class *jrt.Class



type A_arbace_set_map_invert_A struct{ j2g_header uint64 }

var A_arbace_set_map_invert_A_fn_class *jrt.Class



type A_arbace_set_map_invert_fn__1726000047_A struct{ j2g_header uint64 }

var A_arbace_set_map_invert_fn__1726000047_A_fn_class *jrt.Class



type A_arbace_set_project_A struct{ j2g_header uint64 }

var A_arbace_set_project_A_fn_class *jrt.Class



type A_arbace_set_project_fn__1726000030_A struct{ j2g_header uint64; F_ks any }

var A_arbace_set_project_fn__1726000030_A_fn_class *jrt.Class



type A_arbace_set_rename_A struct{ j2g_header uint64 }

var A_arbace_set_rename_A_fn_class *jrt.Class



type A_arbace_set_rename_fn__1726000041_A struct{ j2g_header uint64; F_kmap any }

var A_arbace_set_rename_fn__1726000041_A_fn_class *jrt.Class



type A_arbace_set_rename_keys_A struct{ j2g_header uint64 }

var A_arbace_set_rename_keys_A_fn_class *jrt.Class



type A_arbace_set_rename_keys_fn__1726000034_A struct{ j2g_header uint64; F_map any }

var A_arbace_set_rename_keys_fn__1726000034_A_fn_class *jrt.Class



type A_arbace_set_select_A struct{ j2g_header uint64 }

var A_arbace_set_select_A_fn_class *jrt.Class



type A_arbace_set_select_fn__1726000026_A struct{ j2g_header uint64; F_pred any }

var A_arbace_set_select_fn__1726000026_A_fn_class *jrt.Class



type A_arbace_set_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_set_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_set_subset_QMARK__fn__1726000070_A struct{ j2g_header uint64; F_set2 any }

var A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class *jrt.Class



type A_arbace_set_superset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_set_superset_QMARK__A_fn_class *jrt.Class



type A_arbace_set_superset_QMARK__fn__1726000074_A struct{ j2g_header uint64; F_set1 any }

var A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class *jrt.Class



type A_arbace_set_union_A struct{ j2g_header uint64 }

var A_arbace_set_union_A_fn_class *jrt.Class
