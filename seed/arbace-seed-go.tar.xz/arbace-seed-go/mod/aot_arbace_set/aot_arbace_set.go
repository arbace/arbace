//line aot_arbace_set.ae:1
package aot_arbace_set

import (
	"arbace/jrt"
	"arbace/lang"
)


func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_New() *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A { A_arbace_set_A_Init(); t := &A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_set_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_set_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_set_eval1726000008_fn__1726000009_A_New() *A_arbace_set_eval1726000008_fn__1726000009_A { A_arbace_set_A_Init(); t := &A_arbace_set_eval1726000008_fn__1726000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_set_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_set_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_set_A_const_6), A_arbace_set_A_const_4.GetRawRoot__O(), A_arbace_set_A_const_5) }



func A_arbace_set_bubble_max_key_A_New() *A_arbace_set_bubble_max_key_A { A_arbace_set_A_Init(); t := &A_arbace_set_bubble_max_key_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Ctor() {}
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Invoke_O_O_O__O(self, k__0, coll__1 any) any { var max__3 any = lang.IFn_Cast(A_arbace_set_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_9.GetRawRoot__O(), k__0, coll__1); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_8.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_10.GetRawRoot__O()); var tmp3 any = A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(max__3); var tmp4 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class; if




	fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class = fncls__1d; tmp4 = fncls__1d } else { tmp4 = fncls__1 }; return tmp1.Invoke_O_O__O(max__3, tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), coll__1)) }
//line :18:1
func A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(p0 any) *A_arbace_set_bubble_max_key_fn__1726000013_A { A_arbace_set_A_Init(); t := &A_arbace_set_bubble_max_key_fn__1726000013_A{}; t.Ctor_O(p0); return t }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Ctor_O(c__max any) { t.F_max = c__max }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Invoke_O_O__O(self, p1__1726000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t.F_max, p1__1726000012_SHARP___1)).Ref() }

func A_arbace_set_union_A_New() *A_arbace_set_union_A { A_arbace_set_A_Init(); t := &A_arbace_set_union_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_set_union_A) Ctor() {}
//line :20:1
func (t *A_arbace_set_union_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any = lang.IFn_Cast(A_arbace_set_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_set_A_const_13.GetRawRoot__O(), lang.IFn_Cast(A_arbace_set_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0)); return /*line :31:1*/ lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_14.GetRawRoot__O(), lang.IFn_Cast(A_arbace_set_A_const_15.GetRawRoot__O()).Invoke_O__O(bubbled_sets__4), lang.IFn_Cast(A_arbace_set_A_const_16.GetRawRoot__O()).Invoke_O__O(bubbled_sets__4)) }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {





	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s1__0)), int64(lang.RT_Count_O__I_NoInit(s2__1))) {
		return lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_4.GetRawRoot__O(), s2__1, s1__0) } else {
			return lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_4.GetRawRoot__O(), s1__0, s2__1) } }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O__O(self any) any { return lang.PersistentHashSet_EMPTY.Ref() }












func A_arbace_set_intersection_A_New() *A_arbace_set_intersection_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_set_intersection_A) Ctor() {}
//line :33:1
func (t *A_arbace_set_intersection_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_11.GetRawRoot__O()); var tmp2 any = A_arbace_set_intersection_fn__1726000020_A_New(); var tmp3 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_set_intersection_fn__1726000020_A_fn_class; if












	fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_set_intersection_fn__1726000020_A_fn_class = fncls__2d; tmp3 = fncls__2d } else { tmp3 = fncls__2 }; bubbled_sets__4 = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_set_A_const_4.GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0)); return /*line :47:1*/ lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_17.GetRawRoot__O(), lang.IFn_Cast(A_arbace_set_A_const_15.GetRawRoot__O()).Invoke_O__O(bubbled_sets__4), lang.IFn_Cast(A_arbace_set_A_const_16.GetRawRoot__O()).Invoke_O__O(bubbled_sets__4)) }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any { { var s1__0_2 any = s1__0; var s2__1_2 any = s2__1; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s2__1_2)), int64(lang.RT_Count_O__I_NoInit(s1__0_2))) {
		s1__0_2, s2__1_2 = s2__1_2, s1__0_2; continue L1 } else {
			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_set_intersection_fn__1726000018_A_New_O(s2__1_2); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_set_intersection_fn__1726000018_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_set_intersection_fn__1726000018_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s1__0_2, s1__0_2) } } }; /*line :33:1*/panic("j2g: unreachable") }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }






func A_arbace_set_intersection_fn__1726000018_A_New_O(p0 any) *A_arbace_set_intersection_fn__1726000018_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_fn__1726000018_A{}; t.Ctor_O(p0); return t }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_set_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_s2, item__2)) { return result__1 } else {

		return lang.IFn_Cast(A_arbace_set_A_const_19.GetRawRoot__O()).Invoke_O_O__O(result__1, item__2)
	}
}
func A_arbace_set_intersection_fn__1726000020_A_New() *A_arbace_set_intersection_fn__1726000020_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_fn__1726000020_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Ctor() {}
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Invoke_O_O__O(self, p1__1726000017_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(p1__1726000017_SHARP___1)))).Ref() }


func A_arbace_set_difference_A_New() *A_arbace_set_difference_A { A_arbace_set_A_Init(); t := &A_arbace_set_difference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_set_difference_A) Ctor() {}
//line :49:1
func (t *A_arbace_set_difference_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any {












	return lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_20.GetRawRoot__O(), s1__0, lang.IFn_Cast(A_arbace_set_A_const_4.GetRawRoot__O()).Invoke_O_O__O(sets__2, s2__1)) }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {




	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s1__0)), int64(lang.RT_Count_O__I_NoInit(s2__1))) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_set_difference_fn__1726000023_A_New_O(s2__1); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_set_difference_fn__1726000023_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_set_difference_fn__1726000023_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s1__0, s1__0) } else {




			return lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_19.GetRawRoot__O(), s1__0, s2__1) } }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }





func A_arbace_set_difference_fn__1726000023_A_New_O(p0 any) *A_arbace_set_difference_fn__1726000023_A { A_arbace_set_A_Init(); t := &A_arbace_set_difference_fn__1726000023_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_set_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_s2, item__2)) {
		return lang.IFn_Cast(A_arbace_set_A_const_19.GetRawRoot__O()).Invoke_O_O__O(result__1, item__2) } else {
//line :56:1
			return result__1
		}
}





func A_arbace_set_select_A_New() *A_arbace_set_select_A { A_arbace_set_A_Init(); t := &A_arbace_set_select_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_set_select_A) Ctor() {}
//line :64:1
func (t *A_arbace_set_select_A) Invoke_O_O_O__O(self, pred__0, xset__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_set_select_fn__1726000026_A_New_O(pred__0); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_set_select_fn__1726000026_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_set_select_fn__1726000026_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), xset__1, xset__1) }
//line :68:1
func A_arbace_set_select_fn__1726000026_A_New_O(p0 any) *A_arbace_set_select_fn__1726000026_A { A_arbace_set_A_Init(); t := &A_arbace_set_select_fn__1726000026_A{}; t.Ctor_O(p0); return t }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Invoke_O_O_O__O(self, s__1, k__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(k__2)) { return s__1 } else { return lang.IFn_Cast(A_arbace_set_A_const_19.GetRawRoot__O()).Invoke_O_O__O(s__1, k__2) } }


func A_arbace_set_project_A_New() *A_arbace_set_project_A { A_arbace_set_A_Init(); t := &A_arbace_set_project_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_set_project_A) Ctor() {}
//line :71:1
func (t *A_arbace_set_project_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_21.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_22.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_23.GetRawRoot__O()); var tmp4 any = A_arbace_set_project_fn__1726000030_A_New_O(ks__1); var tmp5 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_set_project_fn__1726000030_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_set_project_fn__1726000030_A_fn_class = fncls__6d; tmp5 = fncls__6d } else { tmp5 = fncls__6 }; return tmp1.Invoke_O_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), xrel__0)), lang.RT_Meta_O__IPersistentMap_NoInit(xrel__0)) }
//line :75:1
func A_arbace_set_project_fn__1726000030_A_New_O(p0 any) *A_arbace_set_project_fn__1726000030_A { A_arbace_set_A_Init(); t := &A_arbace_set_project_fn__1726000030_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Invoke_O_O__O(self, p1__1726000029_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_set_A_const_24.GetRawRoot__O()).Invoke_O_O__O(p1__1726000029_SHARP___1, t.F_ks) }

func A_arbace_set_rename_keys_A_New() *A_arbace_set_rename_keys_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_keys_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_set_rename_keys_A) Ctor() {}
//line :77:1
func (t *A_arbace_set_rename_keys_A) Invoke_O_O_O__O(self, map__0, kmap__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_set_rename_keys_fn__1726000034_A_New_O(map__0); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_set_rename_keys_fn__1726000034_A_fn_class
	if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_set_rename_keys_fn__1726000034_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }
//line :81:1
	return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.IFn_Cast(A_arbace_set_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_set_A_const_26.GetRawRoot__O(), map__0, lang.IFn_Cast(A_arbace_set_A_const_27.GetRawRoot__O()).Invoke_O__O(kmap__1)), kmap__1) }
func A_arbace_set_rename_keys_fn__1726000034_A_New_O(p0 any) *A_arbace_set_rename_keys_fn__1726000034_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_keys_fn__1726000034_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Ctor_O(c__map any) { t.F_map = c__map }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Invoke_O_O_O__O(self, m__1, p__1726000033__2 any) any { var vec__1726000035__3 any = p__1726000033__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000035__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000035__3, lang.RT_IntCast_J__I_NoInit(1), nil); if
														jrt.J2g_Truth(lang.IFn_Cast(A_arbace_set_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_map, old__4)) {
															return lang.IFn_Cast(A_arbace_set_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(m__1, new__5, lang.RT_Get_O_O__O_NoInit(t.F_map, old__4)) } else {
//line :83:1
			return m__1 } }




func A_arbace_set_rename_A_New() *A_arbace_set_rename_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_set_rename_A) Ctor() {}
//line :88:1
func (t *A_arbace_set_rename_A) Invoke_O_O_O__O(self, xrel__0, kmap__1 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_21.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_22.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_23.GetRawRoot__O()); var tmp4 any = A_arbace_set_rename_fn__1726000041_A_New_O(kmap__1); var tmp5 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_set_rename_fn__1726000041_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_set_rename_fn__1726000041_A_fn_class = fncls__8d; tmp5 = fncls__8d } else { tmp5 = fncls__8 }; return tmp1.Invoke_O_O__O(tmp2.Invoke_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), xrel__0)), lang.RT_Meta_O__IPersistentMap_NoInit(xrel__0)) }
//line :92:1
func A_arbace_set_rename_fn__1726000041_A_New_O(p0 any) *A_arbace_set_rename_fn__1726000041_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_fn__1726000041_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Ctor_O(c__kmap any) { t.F_kmap = c__kmap }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Invoke_O_O__O(self, p1__1726000040_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_set_A_const_28.GetRawRoot__O()).Invoke_O_O__O(p1__1726000040_SHARP___1, t.F_kmap) }

func A_arbace_set_index_A_New() *A_arbace_set_index_A { A_arbace_set_A_Init(); t := &A_arbace_set_index_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_set_index_A) Ctor() {}
//line :94:1
func (t *A_arbace_set_index_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {




	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_set_index_fn__1726000044_A_New_O(ks__1); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_set_index_fn__1726000044_A_fn_class
	if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_set_index_fn__1726000044_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }
//line :99:1
	return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.PersistentArrayMap_EMPTY.Ref(), xrel__0) }
func A_arbace_set_index_fn__1726000044_A_New_O(p0 any) *A_arbace_set_index_fn__1726000044_A { A_arbace_set_A_Init(); t := &A_arbace_set_index_fn__1726000044_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Invoke_O_O_O__O(self, m__1, x__2 any) any { var ik__3 any = lang.IFn_Cast(A_arbace_set_A_const_24.GetRawRoot__O()).Invoke_O_O__O(x__2, t.F_ks); return /*line :102:1*/ lang.IFn_Cast(A_arbace_set_A_const_25.GetRawRoot__O()).Invoke_O_O_O__O(m__1, ik__3, lang.IFn_Cast(A_arbace_set_A_const_4.GetRawRoot__O()).Invoke_O_O__O(lang.RT_Get_O_O_O__O_NoInit(m__1, ik__3, lang.PersistentHashSet_EMPTY.Ref()), x__2)) }


func A_arbace_set_map_invert_A_New() *A_arbace_set_map_invert_A { A_arbace_set_A_Init(); t := &A_arbace_set_map_invert_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_set_map_invert_A) Ctor() {}
//line :105:1
func (t *A_arbace_set_map_invert_A) Invoke_O_O__O(self, m__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_29.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_30.GetRawRoot__O()); var tmp3 any = A_arbace_set_map_invert_fn__1726000047_A_New(); var tmp4 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_set_map_invert_fn__1726000047_A_fn_class
	if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_set_map_invert_fn__1726000047_A_fn_class = fncls__10d; tmp4 = fncls__10d } else { tmp4 = fncls__10 }
//line :109:1
	return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.IFn_Cast(A_arbace_set_A_const_32.GetRawRoot__O()).Invoke_O__O(lang.PersistentArrayMap_EMPTY.Ref()), m__0)) }
func A_arbace_set_map_invert_fn__1726000047_A_New() *A_arbace_set_map_invert_fn__1726000047_A { A_arbace_set_A_Init(); t := &A_arbace_set_map_invert_fn__1726000047_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Ctor() {}
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Invoke_O_O_O_O__O(self, m__1, k__2, v__3 any) any { return lang.IFn_Cast(A_arbace_set_A_const_31.GetRawRoot__O()).Invoke_O_O_O__O(m__1, v__3, k__2) }



func A_arbace_set_join_A_New() *A_arbace_set_join_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_set_join_A) Ctor() {}
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O_O__O(self, xrel__0, yrel__1, km__2 any) any { var vec__1726000061__4 any; if



















	lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xrel__0)), int64(lang.RT_Count_O__I_NoInit(yrel__1))) { vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(xrel__0, yrel__1, lang.IFn_Cast(A_arbace_set_A_const_34.GetRawRoot__O()).Invoke_O__O(km__2)) } else { vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(yrel__1, xrel__0, km__2) }; var r__5 any = /*line :114:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(2), nil); var idx__8 any = lang.IFn_Cast(A_arbace_set_A_const_33.GetRawRoot__O()).Invoke_O_O__O(r__5, lang.IFn_Cast(A_arbace_set_A_const_35.GetRawRoot__O()).Invoke_O__O(k__7)); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp2 any = A_arbace_set_join_fn__1726000064_A_New_O_O(k__7, idx__8); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_set_join_fn__1726000064_A_fn_class; if























	fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_set_join_fn__1726000064_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; return tmp1.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), lang.PersistentHashSet_EMPTY.Ref(), s__6) }
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O__O(self, xrel__0, yrel__1 any) any {





	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_set_A_const_37.GetRawRoot__O()).Invoke_O__O(xrel__0); if jrt.J2g_Truth(and__1927000168__auto____3) { tmp1 = lang.IFn_Cast(A_arbace_set_A_const_37.GetRawRoot__O()).Invoke_O__O(yrel__1) } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var ks__3 any = lang.IFn_Cast(A_arbace_set_A_const_17.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_set_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_set_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_set_A_const_15.GetRawRoot__O()).Invoke_O__O(xrel__0))), lang.IFn_Cast(A_arbace_set_A_const_22.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_set_A_const_27.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_set_A_const_15.GetRawRoot__O()).Invoke_O__O(yrel__1)))); var vec__1726000054__4 any

		if lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xrel__0)), int64(lang.RT_Count_O__I_NoInit(yrel__1))) { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(xrel__0, yrel__1) } else { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(yrel__1, xrel__0) }
//line :120:1
		var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000054__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000054__4, lang.RT_IntCast_J__I_NoInit(1), nil); var idx__7 any = lang.IFn_Cast(A_arbace_set_A_const_33.GetRawRoot__O()).Invoke_O_O__O(r__5, ks__3); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_set_join_fn__1726000057_A_New_O_O(ks__3, idx__7); var tmp4 *jrt.Class
		var fncls__14 /*line :120:1*/*jrt.Class = A_arbace_set_join_fn__1726000057_A_fn_class





		if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_set_join_fn__1726000057_A_fn_class = fncls__14d; tmp4 = fncls__14d } else { tmp4 = fncls__14 }; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), lang.PersistentHashSet_EMPTY.Ref(), s__6) } else {
//line :120:1
			return lang.PersistentHashSet_EMPTY.Ref()
		}
}



func A_arbace_set_join_fn__1726000057_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000057_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Ctor_O_O(c__ks, c__idx any) { t.F_ks = c__ks; t.F_idx = c__idx }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var found__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_set_A_const_24.GetRawRoot__O()).Invoke_O_O__O(x__2, t.F_ks)); if

	jrt.J2g_Truth(found__3) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(x__2); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ret__1, found__3) } else {
//line :128:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(p0 any) *A_arbace_set_join_fn__1726000057_fn__1726000058_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000057_fn__1726000058_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Invoke_O_O_O__O(self, p1__1726000050_SHARP___1, p2__1726000051_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_set_A_const_4.GetRawRoot__O()).Invoke_O_O__O(p1__1726000050_SHARP___1, lang.IFn_Cast(A_arbace_set_A_const_36.GetRawRoot__O()).Invoke_O_O__O(p2__1726000051_SHARP___2, t.F_x)) }








func A_arbace_set_join_fn__1726000064_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000064_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Ctor_O_O(c__k, c__idx any) { t.F_k = c__k; t.F_idx = c__idx }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var found__3 any = tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_set_A_const_28.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_set_A_const_24.GetRawRoot__O()).Invoke_O_O__O(x__2, lang.IFn_Cast(A_arbace_set_A_const_27.GetRawRoot__O()).Invoke_O__O(t.F_k)), t.F_k)); if

	jrt.J2g_Truth(found__3) {
		var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_12.GetRawRoot__O()); var tmp3 any = A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(x__2); var tmp4 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class = fncls__11d; tmp4 = fncls__11d } else { tmp4 = fncls__11 }; return tmp2.Invoke_O_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), ret__1, found__3) } else {
//line :140:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(p0 any) *A_arbace_set_join_fn__1726000064_fn__1726000065_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000064_fn__1726000065_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Invoke_O_O_O__O(self, p1__1726000052_SHARP___1, p2__1726000053_SHARP___2 any) any { return lang.IFn_Cast(A_arbace_set_A_const_4.GetRawRoot__O()).Invoke_O_O__O(p1__1726000052_SHARP___1, lang.IFn_Cast(A_arbace_set_A_const_36.GetRawRoot__O()).Invoke_O_O__O(p2__1726000053_SHARP___2, t.F_x)) }



func A_arbace_set_subset_QMARK__A_New() *A_arbace_set_subset_QMARK__A { A_arbace_set_A_Init(); t := &A_arbace_set_subset_QMARK__A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Ctor() {}
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(set1__0)), int64(lang.RT_Count_O__I_NoInit(set2__1))); if and__1927000168__auto____3 {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(set2__1); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), set1__0) } else {
//line :150:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(p0 any) *A_arbace_set_subset_QMARK__fn__1726000070_A { A_arbace_set_A_Init(); t := &A_arbace_set_subset_QMARK__fn__1726000070_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Ctor_O(c__set2 any) { t.F_set2 = c__set2 }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Invoke_O_O__O(self, p1__1726000069_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_set_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_set2, p1__1726000069_SHARP___1) }

func A_arbace_set_superset_QMARK__A_New() *A_arbace_set_superset_QMARK__A { A_arbace_set_A_Init(); t := &A_arbace_set_superset_QMARK__A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Ctor() {}
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(set1__0)), int64(lang.RT_Count_O__I_NoInit(set2__1))); if and__1927000168__auto____3 {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(set1__0); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), set2__1) } else {
//line :158:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(p0 any) *A_arbace_set_superset_QMARK__fn__1726000074_A { A_arbace_set_A_Init(); t := &A_arbace_set_superset_QMARK__fn__1726000074_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Ctor_O(c__set1 any) { t.F_set1 = c__set1 }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Invoke_O_O__O(self, p1__1726000073_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_set_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_set1, p1__1726000073_SHARP___1) }





















































type A_arbace_set_A struct{ jrt.Object }

var A_arbace_set_A_const_pool *jrt.RefArray

var A_arbace_set_A_const_0 *lang.Var

var A_arbace_set_A_const_1 any

var A_arbace_set_A_const_2 *lang.Var

var A_arbace_set_A_const_3 *lang.Var

var A_arbace_set_A_const_4 *lang.Var

var A_arbace_set_A_const_5 any

var A_arbace_set_A_const_6 *lang.Var

var A_arbace_set_A_const_7 *lang.Var

var A_arbace_set_A_const_8 *lang.Var

var A_arbace_set_A_const_9 *lang.Var

var A_arbace_set_A_const_10 *lang.Var

var A_arbace_set_A_const_11 *lang.Var

var A_arbace_set_A_const_12 *lang.Var

var A_arbace_set_A_const_13 *lang.Var

var A_arbace_set_A_const_14 *lang.Var

var A_arbace_set_A_const_15 *lang.Var

var A_arbace_set_A_const_16 *lang.Var

var A_arbace_set_A_const_17 *lang.Var

var A_arbace_set_A_const_18 *lang.Var

var A_arbace_set_A_const_19 *lang.Var

var A_arbace_set_A_const_20 *lang.Var

var A_arbace_set_A_const_21 *lang.Var

var A_arbace_set_A_const_22 *lang.Var

var A_arbace_set_A_const_23 *lang.Var

var A_arbace_set_A_const_24 *lang.Var

var A_arbace_set_A_const_25 *lang.Var

var A_arbace_set_A_const_26 *lang.Var

var A_arbace_set_A_const_27 *lang.Var

var A_arbace_set_A_const_28 *lang.Var

var A_arbace_set_A_const_29 *lang.Var

var A_arbace_set_A_const_30 *lang.Var

var A_arbace_set_A_const_31 *lang.Var

var A_arbace_set_A_const_32 *lang.Var

var A_arbace_set_A_const_33 *lang.Var

var A_arbace_set_A_const_34 *lang.Var

var A_arbace_set_A_const_35 *lang.Var

var A_arbace_set_A_const_36 *lang.Var

var A_arbace_set_A_const_37 *lang.Var

var A_arbace_set_A_const_38 *lang.Var

var A_arbace_set_A_init jrt.ClassInit

func A_arbace_set_A_Init() { if !A_arbace_set_A_init.Done() { A_arbace_set_A_init.Run(A_arbace_set_A_clinit) } }

func A_arbace_set_A_clinit() { A_arbace_set_A_clinit_p0(); A_arbace_set_A_clinit_p1(); A_arbace_set_A_clinit_p2(); A_arbace_set_A_clinit_p3() }

func A_arbace_set_A_clinit_p0() { jrt.StartCheck(); A_arbace_set_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 42); A_arbace_set_A_const_0 = lang.Var_Cast(A_arbace_set_A_const_pool.A[3]); A_arbace_set_A_const_1 = A_arbace_set_A_const_pool.A[4]; A_arbace_set_A_const_2 = lang.Var_Cast(A_arbace_set_A_const_pool.A[5]); A_arbace_set_A_const_3 = lang.Var_Cast(A_arbace_set_A_const_pool.A[6]); A_arbace_set_A_const_4 = lang.Var_Cast(A_arbace_set_A_const_pool.A[7]); A_arbace_set_A_const_5 = A_arbace_set_A_const_pool.A[8]; A_arbace_set_A_const_6 = lang.Var_Cast(A_arbace_set_A_const_pool.A[9]); A_arbace_set_A_const_7 = lang.Var_Cast(A_arbace_set_A_const_pool.A[10]); A_arbace_set_A_const_8 = lang.Var_Cast(A_arbace_set_A_const_pool.A[11]); A_arbace_set_A_const_9 = lang.Var_Cast(A_arbace_set_A_const_pool.A[12]); A_arbace_set_A_const_10 = lang.Var_Cast(A_arbace_set_A_const_pool.A[13]) }

func A_arbace_set_A_clinit_p1() { A_arbace_set_A_const_11 = lang.Var_Cast(A_arbace_set_A_const_pool.A[14]); A_arbace_set_A_const_12 = lang.Var_Cast(A_arbace_set_A_const_pool.A[15]); A_arbace_set_A_const_13 = lang.Var_Cast(A_arbace_set_A_const_pool.A[16]); A_arbace_set_A_const_14 = lang.Var_Cast(A_arbace_set_A_const_pool.A[17]); A_arbace_set_A_const_15 = lang.Var_Cast(A_arbace_set_A_const_pool.A[18]); A_arbace_set_A_const_16 = lang.Var_Cast(A_arbace_set_A_const_pool.A[19]); A_arbace_set_A_const_17 = lang.Var_Cast(A_arbace_set_A_const_pool.A[20]); A_arbace_set_A_const_18 = lang.Var_Cast(A_arbace_set_A_const_pool.A[21]); A_arbace_set_A_const_19 = lang.Var_Cast(A_arbace_set_A_const_pool.A[22]); A_arbace_set_A_const_20 = lang.Var_Cast(A_arbace_set_A_const_pool.A[23]); A_arbace_set_A_const_21 = lang.Var_Cast(A_arbace_set_A_const_pool.A[24]); A_arbace_set_A_const_22 = lang.Var_Cast(A_arbace_set_A_const_pool.A[25]) }

func A_arbace_set_A_clinit_p2() { A_arbace_set_A_const_23 = lang.Var_Cast(A_arbace_set_A_const_pool.A[26]); A_arbace_set_A_const_24 = lang.Var_Cast(A_arbace_set_A_const_pool.A[27]); A_arbace_set_A_const_25 = lang.Var_Cast(A_arbace_set_A_const_pool.A[28]); A_arbace_set_A_const_26 = lang.Var_Cast(A_arbace_set_A_const_pool.A[29]); A_arbace_set_A_const_27 = lang.Var_Cast(A_arbace_set_A_const_pool.A[30]); A_arbace_set_A_const_28 = lang.Var_Cast(A_arbace_set_A_const_pool.A[31]); A_arbace_set_A_const_29 = lang.Var_Cast(A_arbace_set_A_const_pool.A[32]); A_arbace_set_A_const_30 = lang.Var_Cast(A_arbace_set_A_const_pool.A[33]); A_arbace_set_A_const_31 = lang.Var_Cast(A_arbace_set_A_const_pool.A[34]); A_arbace_set_A_const_32 = lang.Var_Cast(A_arbace_set_A_const_pool.A[35]); A_arbace_set_A_const_33 = lang.Var_Cast(A_arbace_set_A_const_pool.A[36]); A_arbace_set_A_const_34 = lang.Var_Cast(A_arbace_set_A_const_pool.A[37]) }

func A_arbace_set_A_clinit_p3() { A_arbace_set_A_const_35 = lang.Var_Cast(A_arbace_set_A_const_pool.A[38]); A_arbace_set_A_const_36 = lang.Var_Cast(A_arbace_set_A_const_pool.A[39]); A_arbace_set_A_const_37 = lang.Var_Cast(A_arbace_set_A_const_pool.A[40]); A_arbace_set_A_const_38 = lang.Var_Cast(A_arbace_set_A_const_pool.A[41]) }

func A_arbace_set_A_New() *A_arbace_set_A { A_arbace_set_A_Init(); t := &A_arbace_set_A{}; t.Ctor(); return t }

func (t *A_arbace_set_A) Ctor() {}

func (t *A_arbace_set_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_A) GetClass__Class() *jrt.Class { return A_arbace_set_A_class }

func (t *A_arbace_set_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_A); return ok }

func A_arbace_set_A_Cast(x any) *A_arbace_set_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_A_class)) }; return v }



type A_arbace_set_bubble_max_key_A struct{ j2g_header uint64 }

var A_arbace_set_bubble_max_key_A_fn_class *jrt.Class



type A_arbace_set_bubble_max_key_fn__1726000013_A struct{ j2g_header uint64; F_max any }

var A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class *jrt.Class



type A_arbace_set_difference_A struct{ j2g_header uint64 }

var A_arbace_set_difference_A_fn_class *jrt.Class



type A_arbace_set_difference_fn__1726000023_A struct{ j2g_header uint64; F_s2 any }

var A_arbace_set_difference_fn__1726000023_A_fn_class *jrt.Class



type A_arbace_set_eval1726000004_A struct{ jrt.Object }

func A_arbace_set_eval1726000004_A_New() *A_arbace_set_eval1726000004_A { t := &A_arbace_set_eval1726000004_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000004_A) Ctor() {}

func (t *A_arbace_set_eval1726000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000004_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000004_A_class }

func (t *A_arbace_set_eval1726000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000004_A); return ok }

func A_arbace_set_eval1726000004_A_Cast(x any) *A_arbace_set_eval1726000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000004_A_class)) }; return v }



type A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A struct{ j2g_header uint64 }

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class *jrt.Class



type A_arbace_set_eval1726000008_A struct{ jrt.Object }

func A_arbace_set_eval1726000008_A_New() *A_arbace_set_eval1726000008_A { t := &A_arbace_set_eval1726000008_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000008_A) Ctor() {}

func (t *A_arbace_set_eval1726000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000008_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000008_A_class }

func (t *A_arbace_set_eval1726000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000008_A); return ok }

func A_arbace_set_eval1726000008_A_Cast(x any) *A_arbace_set_eval1726000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000008_A_class)) }; return v }



type A_arbace_set_eval1726000008_fn__1726000009_A struct{ j2g_header uint64 }

var A_arbace_set_eval1726000008_fn__1726000009_A_fn_class *jrt.Class



type A_arbace_set_index_A struct{ j2g_header uint64 }

var A_arbace_set_index_A_fn_class *jrt.Class



type A_arbace_set_index_fn__1726000044_A struct{ j2g_header uint64; F_ks any }

var A_arbace_set_index_fn__1726000044_A_fn_class *jrt.Class



type A_arbace_set_intersection_A struct{ j2g_header uint64 }

var A_arbace_set_intersection_A_fn_class *jrt.Class



type A_arbace_set_intersection_fn__1726000018_A struct{ j2g_header uint64; F_s2 any }

var A_arbace_set_intersection_fn__1726000018_A_fn_class *jrt.Class



type A_arbace_set_intersection_fn__1726000020_A struct{ j2g_header uint64 }

var A_arbace_set_intersection_fn__1726000020_A_fn_class *jrt.Class



type A_arbace_set_join_A struct{ j2g_header uint64 }

var A_arbace_set_join_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000057_A struct{ j2g_header uint64; F_ks, F_idx any }

var A_arbace_set_join_fn__1726000057_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000057_fn__1726000058_A struct{ j2g_header uint64; F_x any }

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000064_A struct{ j2g_header uint64; F_k, F_idx any }

var A_arbace_set_join_fn__1726000064_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000064_fn__1726000065_A struct{ j2g_header uint64; F_x any }

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class *jrt.Class



type A_arbace_set_map_invert_A struct{ j2g_header uint64 }

var A_arbace_set_map_invert_A_fn_class *jrt.Class



type A_arbace_set_map_invert_fn__1726000047_A struct{ j2g_header uint64 }

var A_arbace_set_map_invert_fn__1726000047_A_fn_class *jrt.Class



type A_arbace_set_project_A struct{ j2g_header uint64 }

var A_arbace_set_project_A_fn_class *jrt.Class



type A_arbace_set_project_fn__1726000030_A struct{ j2g_header uint64; F_ks any }

var A_arbace_set_project_fn__1726000030_A_fn_class *jrt.Class



type A_arbace_set_rename_A struct{ j2g_header uint64 }

var A_arbace_set_rename_A_fn_class *jrt.Class



type A_arbace_set_rename_fn__1726000041_A struct{ j2g_header uint64; F_kmap any }

var A_arbace_set_rename_fn__1726000041_A_fn_class *jrt.Class



type A_arbace_set_rename_keys_A struct{ j2g_header uint64 }

var A_arbace_set_rename_keys_A_fn_class *jrt.Class



type A_arbace_set_rename_keys_fn__1726000034_A struct{ j2g_header uint64; F_map any }

var A_arbace_set_rename_keys_fn__1726000034_A_fn_class *jrt.Class



type A_arbace_set_select_A struct{ j2g_header uint64 }

var A_arbace_set_select_A_fn_class *jrt.Class



type A_arbace_set_select_fn__1726000026_A struct{ j2g_header uint64; F_pred any }

var A_arbace_set_select_fn__1726000026_A_fn_class *jrt.Class



type A_arbace_set_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_set_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_set_subset_QMARK__fn__1726000070_A struct{ j2g_header uint64; F_set2 any }

var A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class *jrt.Class



type A_arbace_set_superset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_set_superset_QMARK__A_fn_class *jrt.Class



type A_arbace_set_superset_QMARK__fn__1726000074_A struct{ j2g_header uint64; F_set1 any }

var A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class *jrt.Class



type A_arbace_set_union_A struct{ j2g_header uint64 }

var A_arbace_set_union_A_fn_class *jrt.Class
