//line aot_arbace_set.ae:1
package aot_arbace_set

import (
	"arbace/aot_arbace_core"
	"arbace/jrt"
	"arbace/lang"
)

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_New() *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A { A_arbace_set_A_Init(); t := &A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp2 = lang.IFn_Cast(A_arbace_set_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_set_A_const_1); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :9:1
func A_arbace_set_eval1726000008_fn__1726000009_A_New() *A_arbace_set_eval1726000008_fn__1726000009_A { A_arbace_set_A_Init(); t := &A_arbace_set_eval1726000008_fn__1726000009_A{}; t.Ctor(); return t }
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Ctor() {}
//line :9:1
func (t *A_arbace_set_eval1726000008_fn__1726000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_set_A_const_2.GetRawRoot__O()); var tmp2 any; var root_5 any = A_arbace_set_A_const_3.GetRawRoot__O(); var linked_6 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_5, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_7 lang.IFn; if linked_6 == nil { ifn_7 = lang.IFn_Cast(root_5) } else { ifn_7 = nil }; var arg_8 any = A_arbace_set_A_const_4; if linked_6 == nil { tmp2 = ifn_7.Invoke_O__O(arg_8) } else { tmp2 = linked_6.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_5, arg_8) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_set_A_const_5.GetRawRoot__O(), A_arbace_set_A_const_6) }



func A_arbace_set_bubble_max_key_A_New() *A_arbace_set_bubble_max_key_A { A_arbace_set_A_Init(); t := &A_arbace_set_bubble_max_key_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Ctor() {}
//line :13:1
func (t *A_arbace_set_bubble_max_key_A) Invoke_O_O_O__O(self, k__0, coll__1 any) any { var max__3 any; var root_15 any = A_arbace_set_A_const_7.GetRawRoot__O(); var linked_16 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_15, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_17 lang.IFn; if



	linked_16 == nil { ifn_17 = lang.IFn_Cast(root_15) } else { ifn_17 = nil }; var arg_18 any = A_arbace_set_A_const_8.GetRawRoot__O(); var arg_19 any = k__0; var arg_20 any = coll__1; if linked_16 == nil { max__3 = ifn_17.Invoke_O_O_O__O(arg_18, arg_19, arg_20) } else { max__3 = linked_16.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_15, arg_18, arg_19, arg_20) }; var root_27 any =
	A_arbace_set_A_const_9.GetRawRoot__O(); var linked_28 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_27, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_29 lang.IFn; if linked_28 == nil { ifn_29 = lang.IFn_Cast(root_27) } else { ifn_29 = nil }; var arg_30 any = max__3; var arg_31 any; var root_22 any = A_arbace_set_A_const_10.GetRawRoot__O(); var linked_23 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_22, aot_arbace_core.A_arbace_core_remove_A_fn_class); var ifn_24 lang.IFn; if linked_23 == nil { ifn_24 = lang.IFn_Cast(root_22) } else { ifn_24 = nil }; var arg_25 any; var tmp1 any = A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(max__3); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_1, false); A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; arg_25 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_26 any = coll__1; if linked_23 == nil { arg_31 = ifn_24.Invoke_O_O__O(arg_25, arg_26) } else { arg_31 = linked_23.(*aot_arbace_core.A_arbace_core_remove_A).Invoke_O_O_O__O(root_22, arg_25, arg_26) }; if linked_28 == nil { return ifn_29.Invoke_O_O__O(arg_30, arg_31) } else { return linked_28.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_27, arg_30, arg_31) } }
//line :18:1
func A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(p0 any) *A_arbace_set_bubble_max_key_fn__1726000013_A { A_arbace_set_A_Init(); t := &A_arbace_set_bubble_max_key_fn__1726000013_A{}; t.Ctor_O(p0); return t }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Ctor_O(c__max any) { t.F_max = c__max }
//line :18:1
func (t *A_arbace_set_bubble_max_key_fn__1726000013_A) Invoke_O_O__O(self, p1__1726000012_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Identical_O_O__Z_NoInit(t.F_max, p1__1726000012_SHARP___1)).Ref() }

func A_arbace_set_union_A_New() *A_arbace_set_union_A { A_arbace_set_A_Init(); t := &A_arbace_set_union_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_set_union_A) Ctor() {}
//line :20:1
func (t *A_arbace_set_union_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var root_38 any = A_arbace_set_A_const_11.GetRawRoot__O(); var linked_39 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_38, A_arbace_set_bubble_max_key_A_fn_class); var ifn_40 lang.IFn; if









	linked_39 == nil { ifn_40 = lang.IFn_Cast(root_38) } else { ifn_40 = nil }; var arg_41 any = A_arbace_set_A_const_12.GetRawRoot__O(); var arg_42 any = lang.IFn_Cast(A_arbace_set_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0); if linked_39 == nil { bubbled_sets__4 = ifn_40.Invoke_O_O__O(arg_41, arg_42) } else { bubbled_sets__4 = linked_39.(*A_arbace_set_bubble_max_key_A).Invoke_O_O_O__O(root_38, arg_41, arg_42) }; var root_51 any =
	A_arbace_set_A_const_13.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = A_arbace_set_A_const_14.GetRawRoot__O(); var arg_55 any; var root_43 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_44 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_43, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_45 lang.IFn; if linked_44 == nil { ifn_45 = lang.IFn_Cast(root_43) } else { ifn_45 = nil }; var arg_46 any = bubbled_sets__4; if linked_44 == nil { arg_55 = ifn_45.Invoke_O__O(arg_46) } else { arg_55 = linked_44.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_43, arg_46) }; var arg_56 any; var root_47 any = A_arbace_set_A_const_16.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any = bubbled_sets__4; if linked_48 == nil { arg_56 = ifn_49.Invoke_O__O(arg_50) } else { arg_56 = linked_48.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_47, arg_50) }; if linked_52 == nil { return ifn_53.Invoke_O_O_O__O(arg_54, arg_55, arg_56) } else { return linked_52.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_51, arg_54, arg_55, arg_56) } }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {





	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s1__0)), int64(lang.RT_Count_O__I_NoInit(s2__1))) {
		var root_57 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_58 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_57, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_59 lang.IFn; if linked_58 == nil { ifn_59 = lang.IFn_Cast(root_57) } else { ifn_59 = nil }; var arg_60 any = A_arbace_set_A_const_5.GetRawRoot__O(); var arg_61 any = s2__1; var arg_62 any = s1__0; if linked_58 == nil { return ifn_59.Invoke_O_O_O__O(arg_60, arg_61, arg_62) } else { return linked_58.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_57, arg_60, arg_61, arg_62) } } else {
			var root_63 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_64 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_63, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_65 lang.IFn; if linked_64 == nil { ifn_65 = lang.IFn_Cast(root_63) } else { ifn_65 = nil }; var arg_66 any = A_arbace_set_A_const_5.GetRawRoot__O(); var arg_67 any = s1__0; var arg_68 any = s2__1; if linked_64 == nil { return ifn_65.Invoke_O_O_O__O(arg_66, arg_67, arg_68) } else { return linked_64.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_63, arg_66, arg_67, arg_68) } } }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }
//line :20:1
func (t *A_arbace_set_union_A) Invoke_O__O(self any) any { return lang.PersistentHashSet_EMPTY.Ref() }












func A_arbace_set_intersection_A_New() *A_arbace_set_intersection_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_set_intersection_A) Ctor() {}
//line :33:1
func (t *A_arbace_set_intersection_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any { var bubbled_sets__4 any; var root_76 any = A_arbace_set_A_const_11.GetRawRoot__O(); var linked_77 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_76, A_arbace_set_bubble_max_key_A_fn_class); var ifn_78 lang.IFn; if












	linked_77 == nil { ifn_78 = lang.IFn_Cast(root_76) } else { ifn_78 = nil }; var arg_79 any; var tmp1 any = A_arbace_set_intersection_fn__1726000020_A_New(); var tmp2 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_set_intersection_fn__1726000020_A_fn_class; if fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_4, false); A_arbace_set_intersection_fn__1726000020_A_fn_class = fncls__69d; tmp2 = fncls__69d } else { tmp2 = fncls__69 }; arg_79 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_80 any = lang.IFn_Cast(A_arbace_set_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(sets__2, s2__1, s1__0); if linked_77 == nil { bubbled_sets__4 = ifn_78.Invoke_O_O__O(arg_79, arg_80) } else { bubbled_sets__4 = linked_77.(*A_arbace_set_bubble_max_key_A).Invoke_O_O_O__O(root_76, arg_79, arg_80) }; var root_89 any =
	A_arbace_set_A_const_13.GetRawRoot__O(); var linked_90 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_89, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_91 lang.IFn; if linked_90 == nil { ifn_91 = lang.IFn_Cast(root_89) } else { ifn_91 = nil }; var arg_92 any = A_arbace_set_A_const_17.GetRawRoot__O(); var arg_93 any; var root_81 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any = bubbled_sets__4; if linked_82 == nil { arg_93 = ifn_83.Invoke_O__O(arg_84) } else { arg_93 = linked_82.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_81, arg_84) }; var arg_94 any; var root_85 any = A_arbace_set_A_const_16.GetRawRoot__O(); var linked_86 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_85, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_87 lang.IFn; if linked_86 == nil { ifn_87 = lang.IFn_Cast(root_85) } else { ifn_87 = nil }; var arg_88 any = bubbled_sets__4; if linked_86 == nil { arg_94 = ifn_87.Invoke_O__O(arg_88) } else { arg_94 = linked_86.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_85, arg_88) }; if linked_90 == nil { return ifn_91.Invoke_O_O_O__O(arg_92, arg_93, arg_94) } else { return linked_90.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_89, arg_92, arg_93, arg_94) } }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any { { var s1__0_2 any = s1__0; var s2__1_2 any = s2__1; L1: for {




	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s2__1_2)), int64(lang.RT_Count_O__I_NoInit(s1__0_2))) {
		s1__0_2, s2__1_2 = s2__1_2, s1__0_2; continue L1 } else {
			var root_106 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any; var tmp1 any = A_arbace_set_intersection_fn__1726000018_A_New_O(s2__1_2); var tmp2 *jrt.Class; var fncls__105 *jrt.Class = A_arbace_set_intersection_fn__1726000018_A_fn_class; if fncls__105 == nil { var fncls__105d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_5, false); A_arbace_set_intersection_fn__1726000018_A_fn_class = fncls__105d; tmp2 = fncls__105d } else { tmp2 = fncls__105 }; arg_109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_110 any = s1__0_2; var arg_111 any = s1__0_2; if linked_107 == nil { return ifn_108.Invoke_O_O_O__O(arg_109, arg_110, arg_111) } else { return linked_107.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_106, arg_109, arg_110, arg_111) } } } }; /*line :33:1*/panic("j2g: unreachable") }
//line :33:1
func (t *A_arbace_set_intersection_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }






func A_arbace_set_intersection_fn__1726000018_A_New_O(p0 any) *A_arbace_set_intersection_fn__1726000018_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_fn__1726000018_A{}; t.Ctor_O(p0); return t }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :40:1
func (t *A_arbace_set_intersection_fn__1726000018_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	var tmp1 any; var root_95 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_97 lang.IFn; if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any = t.F_s2; var arg_99 any = item__2; if linked_96 == nil { tmp1 = ifn_97.Invoke_O_O__O(arg_98, arg_99) } else { tmp1 = linked_96.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_95, arg_98, arg_99) }; if jrt.J2g_Truth(tmp1) { return result__1 } else {

		var root_100 any = A_arbace_set_A_const_19.GetRawRoot__O(); var linked_101 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_100, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_102 lang.IFn; if linked_101 == nil { ifn_102 = lang.IFn_Cast(root_100) } else { ifn_102 = nil }; var arg_103 any = result__1; var arg_104 any = item__2; if linked_101 == nil { return ifn_102.Invoke_O_O__O(arg_103, arg_104) } else { return linked_101.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_100, arg_103, arg_104)
		}
	} }
func A_arbace_set_intersection_fn__1726000020_A_New() *A_arbace_set_intersection_fn__1726000020_A { A_arbace_set_A_Init(); t := &A_arbace_set_intersection_fn__1726000020_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Ctor() {}
//line :46:1
func (t *A_arbace_set_intersection_fn__1726000020_A) Invoke_O_O__O(self, p1__1726000017_SHARP___1 any) any { return jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(p1__1726000017_SHARP___1)))).Ref() }


func A_arbace_set_difference_A_New() *A_arbace_set_difference_A { A_arbace_set_A_Init(); t := &A_arbace_set_difference_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_set_difference_A) Ctor() {}
//line :49:1
func (t *A_arbace_set_difference_A) DoInvoke_O_O_O_O__O(self, s1__0, s2__1, sets__2 any) any {












	var root_117 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = A_arbace_set_A_const_20.GetRawRoot__O(); var arg_121 any = s1__0; var arg_122 any; var root_112 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = sets__2; var arg_116 any = s2__1; if linked_113 == nil { arg_122 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { arg_122 = linked_113.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) }; if linked_118 == nil { return ifn_119.Invoke_O_O_O__O(arg_120, arg_121, arg_122) } else { return linked_118.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_117, arg_120, arg_121, arg_122) } }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O_O__O(self, s1__0, s2__1 any) any {




	if lang.Numbers_Lt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(s1__0)), int64(lang.RT_Count_O__I_NoInit(s2__1))) {
		var root_134 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any; var tmp1 any = A_arbace_set_difference_fn__1726000023_A_New_O(s2__1); var tmp2 *jrt.Class; var fncls__133 *jrt.Class = A_arbace_set_difference_fn__1726000023_A_fn_class; if fncls__133 == nil { var fncls__133d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_2, false); A_arbace_set_difference_fn__1726000023_A_fn_class = fncls__133d; tmp2 = fncls__133d } else { tmp2 = fncls__133 }; arg_137 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_138 any = s1__0; var arg_139 any = s1__0; if linked_135 == nil { return ifn_136.Invoke_O_O_O__O(arg_137, arg_138, arg_139) } else { return linked_135.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_134, arg_137, arg_138, arg_139) } } else {




			var root_140 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_140, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_142 lang.IFn; if linked_141 == nil { ifn_142 = lang.IFn_Cast(root_140) } else { ifn_142 = nil }; var arg_143 any = A_arbace_set_A_const_19.GetRawRoot__O(); var arg_144 any = s1__0; var arg_145 any = s2__1; if linked_141 == nil { return ifn_142.Invoke_O_O_O__O(arg_143, arg_144, arg_145) } else { return linked_141.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_140, arg_143, arg_144, arg_145) } } }
//line :49:1
func (t *A_arbace_set_difference_A) Invoke_O_O__O(self, s1__0 any) any { return s1__0 }





func A_arbace_set_difference_fn__1726000023_A_New_O(p0 any) *A_arbace_set_difference_fn__1726000023_A { A_arbace_set_A_Init(); t := &A_arbace_set_difference_fn__1726000023_A{}; t.Ctor_O(p0); return t }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Ctor_O(c__s2 any) { t.F_s2 = c__s2 }
//line :55:1
func (t *A_arbace_set_difference_fn__1726000023_A) Invoke_O_O_O__O(self, result__1, item__2 any) any {
	var tmp1 any; var root_123 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_123, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_125 lang.IFn; if linked_124 == nil { ifn_125 = lang.IFn_Cast(root_123) } else { ifn_125 = nil }; var arg_126 any = t.F_s2; var arg_127 any = item__2; if linked_124 == nil { tmp1 = ifn_125.Invoke_O_O__O(arg_126, arg_127) } else { tmp1 = linked_124.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_123, arg_126, arg_127) }; if jrt.J2g_Truth(tmp1) {
		var root_128 any = A_arbace_set_A_const_19.GetRawRoot__O(); var linked_129 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_128, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_130 lang.IFn; if linked_129 == nil { ifn_130 = lang.IFn_Cast(root_128) } else { ifn_130 = nil }; var arg_131 any = result__1; var arg_132 any = item__2; if linked_129 == nil { return ifn_130.Invoke_O_O__O(arg_131, arg_132) } else { return linked_129.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_128, arg_131, arg_132) } } else {
//line :56:1
			return result__1
		}
}





func A_arbace_set_select_A_New() *A_arbace_set_select_A { A_arbace_set_A_Init(); t := &A_arbace_set_select_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_set_select_A) Ctor() {}
//line :64:1
func (t *A_arbace_set_select_A) Invoke_O_O_O__O(self, pred__0, xset__1 any) any {



	var root_152 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_153 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_152, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_154 lang.IFn; if linked_153 == nil { ifn_154 = lang.IFn_Cast(root_152) } else { ifn_154 = nil }; var arg_155 any; var tmp1 any = A_arbace_set_select_fn__1726000026_A_New_O(pred__0); var tmp2 *jrt.Class; var fncls__151 *jrt.Class = A_arbace_set_select_fn__1726000026_A_fn_class; if fncls__151 == nil { var fncls__151d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_14, false); A_arbace_set_select_fn__1726000026_A_fn_class = fncls__151d; tmp2 = fncls__151d } else { tmp2 = fncls__151 }; arg_155 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_156 any = xset__1; var arg_157 any = xset__1; if linked_153 == nil { return ifn_154.Invoke_O_O_O__O(arg_155, arg_156, arg_157) } else { return linked_153.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_152, arg_155, arg_156, arg_157) } }
//line :68:1
func A_arbace_set_select_fn__1726000026_A_New_O(p0 any) *A_arbace_set_select_fn__1726000026_A { A_arbace_set_A_Init(); t := &A_arbace_set_select_fn__1726000026_A{}; t.Ctor_O(p0); return t }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Ctor_O(c__pred any) { t.F_pred = c__pred }
//line :68:1
func (t *A_arbace_set_select_fn__1726000026_A) Invoke_O_O_O__O(self, s__1, k__2 any) any { if jrt.J2g_Truth(lang.IFn_Cast(t.F_pred).Invoke_O__O(k__2)) { return s__1 } else { var root_146 any = A_arbace_set_A_const_19.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_disj_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__1; var arg_150 any = k__2; if linked_147 == nil { return ifn_148.Invoke_O_O__O(arg_149, arg_150) } else { return linked_147.(*aot_arbace_core.A_arbace_core_disj_A).Invoke_O_O_O__O(root_146, arg_149, arg_150) } } }


func A_arbace_set_project_A_New() *A_arbace_set_project_A { A_arbace_set_A_Init(); t := &A_arbace_set_project_A{}; t.Ctor(); return t }
//line :71:1
func (t *A_arbace_set_project_A) Ctor() {}
//line :71:1
func (t *A_arbace_set_project_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {



	var root_173 any = A_arbace_set_A_const_21.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_169 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any; var root_164 any = A_arbace_set_A_const_23.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_166 lang.IFn; if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any; var tmp1 any = A_arbace_set_project_fn__1726000030_A_New_O(ks__1); var tmp2 *jrt.Class; var fncls__163 *jrt.Class = A_arbace_set_project_fn__1726000030_A_fn_class; if fncls__163 == nil { var fncls__163d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_11, false); A_arbace_set_project_fn__1726000030_A_fn_class = fncls__163d; tmp2 = fncls__163d } else { tmp2 = fncls__163 }; arg_167 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_168 any = xrel__0; if linked_165 == nil { arg_172 = ifn_166.Invoke_O_O__O(arg_167, arg_168) } else { arg_172 = linked_165.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_164, arg_167, arg_168) }; if linked_170 == nil { arg_176 = ifn_171.Invoke_O__O(arg_172) } else { arg_176 = linked_170.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_169, arg_172) }; var arg_177 any = lang.RT_Meta_O__IPersistentMap_NoInit(xrel__0); if linked_174 == nil { return ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { return linked_174.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) } }
//line :75:1
func A_arbace_set_project_fn__1726000030_A_New_O(p0 any) *A_arbace_set_project_fn__1726000030_A { A_arbace_set_A_Init(); t := &A_arbace_set_project_fn__1726000030_A{}; t.Ctor_O(p0); return t }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :75:1
func (t *A_arbace_set_project_fn__1726000030_A) Invoke_O_O__O(self, p1__1726000029_SHARP___1 any) any { var root_158 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_159 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_158, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_160 lang.IFn; if linked_159 == nil { ifn_160 = lang.IFn_Cast(root_158) } else { ifn_160 = nil }; var arg_161 any = p1__1726000029_SHARP___1; var arg_162 any = t.F_ks; if linked_159 == nil { return ifn_160.Invoke_O_O__O(arg_161, arg_162) } else { return linked_159.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_158, arg_161, arg_162) } }

func A_arbace_set_rename_keys_A_New() *A_arbace_set_rename_keys_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_keys_A{}; t.Ctor(); return t }
//line :77:1
func (t *A_arbace_set_rename_keys_A) Ctor() {}
//line :77:1
func (t *A_arbace_set_rename_keys_A) Invoke_O_O_O__O(self, map__0, kmap__1 any) any {



	var root_200 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any; var tmp1 any = A_arbace_set_rename_keys_fn__1726000034_A_New_O(map__0); var tmp2 *jrt.Class; var fncls__189 *jrt.Class = A_arbace_set_rename_keys_fn__1726000034_A_fn_class
	if fncls__189 == nil { var fncls__189d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_13, false); A_arbace_set_rename_keys_fn__1726000034_A_fn_class = fncls__189d; tmp2 = fncls__189d } else { tmp2 = fncls__189 }; arg_203 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :81:1
	var arg_204 any; var root_194 any = A_arbace_set_A_const_7.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_196 lang.IFn




	if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = A_arbace_set_A_const_26.GetRawRoot__O(); var arg_198 any = map__0; var arg_199 any; var root_190 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_191 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_190, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_192 lang.IFn; if linked_191 == nil { ifn_192 = lang.IFn_Cast(root_190) } else { ifn_192 = nil }; var arg_193 any = kmap__1; if linked_191 == nil { arg_199 = ifn_192.Invoke_O__O(arg_193) } else { arg_199 = linked_191.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_190, arg_193) }; if linked_195 == nil { arg_204 = ifn_196.Invoke_O_O_O__O(arg_197, arg_198, arg_199) } else { arg_204 = linked_195.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O_O__O(root_194, arg_197, arg_198, arg_199) }
//line :81:1
	var arg_205 any = kmap__1; if linked_201 == nil { return ifn_202.Invoke_O_O_O__O(arg_203, arg_204, arg_205) } else { return linked_201.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_200, arg_203, arg_204, arg_205) } }
func A_arbace_set_rename_keys_fn__1726000034_A_New_O(p0 any) *A_arbace_set_rename_keys_fn__1726000034_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_keys_fn__1726000034_A{}; t.Ctor_O(p0); return t }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Ctor_O(c__map any) { t.F_map = c__map }
//line :82:1
func (t *A_arbace_set_rename_keys_fn__1726000034_A) Invoke_O_O_O__O(self, m__1, p__1726000033__2 any) any { var vec__1726000035__3 any = p__1726000033__2; var old__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000035__3, lang.RT_IntCast_J__I_NoInit(0), nil); var new__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000035__3, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 any; var root_178 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_180 lang.IFn; if
														linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = t.F_map; var arg_182 any = old__4; if linked_179 == nil { tmp1 = ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { tmp1 = linked_179.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_178, arg_181, arg_182) }; if jrt.J2g_Truth(tmp1) {
															var root_183 any = A_arbace_set_A_const_25.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = m__1; var arg_187 any = new__5; var arg_188 any = lang.RT_Get_O_O__O_NoInit(t.F_map, old__4); if linked_184 == nil { return ifn_185.Invoke_O_O_O__O(arg_186, arg_187, arg_188) } else { return linked_184.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_183, arg_186, arg_187, arg_188) } } else {
//line :83:1
			return m__1 } }




func A_arbace_set_rename_A_New() *A_arbace_set_rename_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_set_rename_A) Ctor() {}
//line :88:1
func (t *A_arbace_set_rename_A) Invoke_O_O_O__O(self, xrel__0, kmap__1 any) any {



	var root_221 any = A_arbace_set_A_const_21.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_with_meta__1927000046_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any; var root_217 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any; var root_212 any = A_arbace_set_A_const_23.GetRawRoot__O(); var linked_213 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_212, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_214 lang.IFn; if linked_213 == nil { ifn_214 = lang.IFn_Cast(root_212) } else { ifn_214 = nil }; var arg_215 any; var tmp1 any = A_arbace_set_rename_fn__1726000041_A_New_O(kmap__1); var tmp2 *jrt.Class; var fncls__211 *jrt.Class = A_arbace_set_rename_fn__1726000041_A_fn_class; if fncls__211 == nil { var fncls__211d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_12, false); A_arbace_set_rename_fn__1726000041_A_fn_class = fncls__211d; tmp2 = fncls__211d } else { tmp2 = fncls__211 }; arg_215 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_216 any = xrel__0; if linked_213 == nil { arg_220 = ifn_214.Invoke_O_O__O(arg_215, arg_216) } else { arg_220 = linked_213.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_212, arg_215, arg_216) }; if linked_218 == nil { arg_224 = ifn_219.Invoke_O__O(arg_220) } else { arg_224 = linked_218.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_217, arg_220) }; var arg_225 any = lang.RT_Meta_O__IPersistentMap_NoInit(xrel__0); if linked_222 == nil { return ifn_223.Invoke_O_O__O(arg_224, arg_225) } else { return linked_222.(*aot_arbace_core.A_arbace_core_with_meta__1927000046_A).Invoke_O_O_O__O(root_221, arg_224, arg_225) } }
//line :92:1
func A_arbace_set_rename_fn__1726000041_A_New_O(p0 any) *A_arbace_set_rename_fn__1726000041_A { A_arbace_set_A_Init(); t := &A_arbace_set_rename_fn__1726000041_A{}; t.Ctor_O(p0); return t }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Ctor_O(c__kmap any) { t.F_kmap = c__kmap }
//line :92:1
func (t *A_arbace_set_rename_fn__1726000041_A) Invoke_O_O__O(self, p1__1726000040_SHARP___1 any) any { var root_206 any = A_arbace_set_A_const_28.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, A_arbace_set_rename_keys_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any = p1__1726000040_SHARP___1; var arg_210 any = t.F_kmap; if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*A_arbace_set_rename_keys_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } }

func A_arbace_set_index_A_New() *A_arbace_set_index_A { A_arbace_set_A_Init(); t := &A_arbace_set_index_A{}; t.Ctor(); return t }
//line :94:1
func (t *A_arbace_set_index_A) Ctor() {}
//line :94:1
func (t *A_arbace_set_index_A) Invoke_O_O_O__O(self, xrel__0, ks__1 any) any {




	var root_243 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var tmp1 any = A_arbace_set_index_fn__1726000044_A_New_O(ks__1); var tmp2 *jrt.Class; var fncls__242 *jrt.Class = A_arbace_set_index_fn__1726000044_A_fn_class
	if fncls__242 == nil { var fncls__242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_set_index_fn__1726000044_A_fn_class = fncls__242d; tmp2 = fncls__242d } else { tmp2 = fncls__242 }; arg_246 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)
//line :99:1
	var arg_247 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_248 any = xrel__0; if linked_244 == nil { return ifn_245.Invoke_O_O_O__O(arg_246, arg_247, arg_248) } else { return linked_244.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_243, arg_246, arg_247, arg_248) } }
func A_arbace_set_index_fn__1726000044_A_New_O(p0 any) *A_arbace_set_index_fn__1726000044_A { A_arbace_set_A_Init(); t := &A_arbace_set_index_fn__1726000044_A{}; t.Ctor_O(p0); return t }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Ctor_O(c__ks any) { t.F_ks = c__ks }
//line :100:1
func (t *A_arbace_set_index_fn__1726000044_A) Invoke_O_O_O__O(self, m__1, x__2 any) any { var ik__3 any; var root_226 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_228 lang.IFn; if
											linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = x__2; var arg_230 any = t.F_ks; if linked_227 == nil { ik__3 = ifn_228.Invoke_O_O__O(arg_229, arg_230) } else { ik__3 = linked_227.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_226, arg_229, arg_230) }; var root_236 any =
											A_arbace_set_A_const_25.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = m__1; var arg_240 any = ik__3; var arg_241 any; var root_231 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_231, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_233 lang.IFn; if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any = lang.RT_Get_O_O_O__O_NoInit(m__1, ik__3, lang.PersistentHashSet_EMPTY.Ref()); var arg_235 any = x__2; if linked_232 == nil { arg_241 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { arg_241 = linked_232.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }; if linked_237 == nil { return ifn_238.Invoke_O_O_O__O(arg_239, arg_240, arg_241) } else { return linked_237.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_236, arg_239, arg_240, arg_241) } }


func A_arbace_set_map_invert_A_New() *A_arbace_set_map_invert_A { A_arbace_set_A_Init(); t := &A_arbace_set_map_invert_A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_set_map_invert_A) Ctor() {}
//line :105:1
func (t *A_arbace_set_map_invert_A) Invoke_O_O__O(self, m__0 any) any {



	var root_266 any = A_arbace_set_A_const_29.GetRawRoot__O(); var linked_267 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_266, aot_arbace_core.A_arbace_core_persistent_BANG__A_fn_class); var ifn_268 lang.IFn; if linked_267 == nil { ifn_268 = lang.IFn_Cast(root_266) } else { ifn_268 = nil }; var arg_269 any; var root_260 any = A_arbace_set_A_const_30.GetRawRoot__O(); var linked_261 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_260, aot_arbace_core.A_arbace_core_reduce_kv_A_fn_class); var ifn_262 lang.IFn
	if linked_261 == nil { ifn_262 = lang.IFn_Cast(root_260) } else { ifn_262 = nil }; var arg_263 any; var tmp1 any = A_arbace_set_map_invert_fn__1726000047_A_New(); var tmp2 *jrt.Class; var fncls__255 *jrt.Class = A_arbace_set_map_invert_fn__1726000047_A_fn_class; if fncls__255 == nil { var fncls__255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_10, false); A_arbace_set_map_invert_fn__1726000047_A_fn_class = fncls__255d; tmp2 = fncls__255d } else { tmp2 = fncls__255 }; arg_263 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_264 any; var root_256 any = A_arbace_set_A_const_32.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_transient_A_fn_class); var ifn_258 lang.IFn
	if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_257 == nil { arg_264 = ifn_258.Invoke_O__O(arg_259) } else { arg_264 = linked_257.(*aot_arbace_core.A_arbace_core_transient_A).Invoke_O_O__O(root_256, arg_259) }
//line :110:1
	var arg_265 any = m__0; if linked_261 == nil { arg_269 = ifn_262.Invoke_O_O_O__O(arg_263, arg_264, arg_265) } else { arg_269 = linked_261.(*aot_arbace_core.A_arbace_core_reduce_kv_A).Invoke_O_O_O_O__O(root_260, arg_263, arg_264, arg_265) }
//line :109:1
	if linked_267 == nil { return ifn_268.Invoke_O__O(arg_269) } else { return linked_267.(*aot_arbace_core.A_arbace_core_persistent_BANG__A).Invoke_O_O__O(root_266, arg_269) } }
func A_arbace_set_map_invert_fn__1726000047_A_New() *A_arbace_set_map_invert_fn__1726000047_A { A_arbace_set_A_Init(); t := &A_arbace_set_map_invert_fn__1726000047_A{}; t.Ctor(); return t }
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Ctor() {}
//line :110:1
func (t *A_arbace_set_map_invert_fn__1726000047_A) Invoke_O_O_O_O__O(self, m__1, k__2, v__3 any) any { var root_249 any = A_arbace_set_A_const_31.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_assoc_BANG__A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = m__1; var arg_253 any = v__3; var arg_254 any = k__2; if linked_250 == nil { return ifn_251.Invoke_O_O_O__O(arg_252, arg_253, arg_254) } else { return linked_250.(*aot_arbace_core.A_arbace_core_assoc_BANG__A).Invoke_O_O_O_O__O(root_249, arg_252, arg_253, arg_254) } }



func A_arbace_set_join_A_New() *A_arbace_set_join_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_set_join_A) Ctor() {}
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O_O__O(self, xrel__0, yrel__1, km__2 any) any { var vec__1726000061__4 any; if



















	lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xrel__0)), int64(lang.RT_Count_O__I_NoInit(yrel__1))) { var tmp1 any; var root_317 any = A_arbace_set_A_const_36.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_317, A_arbace_set_map_invert_A_fn_class); var ifn_319 lang.IFn
		if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any = km__2; if linked_318 == nil { tmp1 = ifn_319.Invoke_O__O(arg_320) } else { tmp1 = linked_318.(*A_arbace_set_map_invert_A).Invoke_O_O__O(root_317, arg_320) }
//line :134:1
		vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(xrel__0, yrel__1, tmp1) } else { vec__1726000061__4 = lang.Tuple_Create_O_O_O__IPersistentVector(yrel__1, xrel__0, km__2) }; var r__5 any = /*line :114:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(1), nil); var k__7 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000061__4, lang.RT_IntCast_J__I_NoInit(2), nil); var idx__8 any; var root_274 any = A_arbace_set_A_const_33.GetRawRoot__O(); var linked_275 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_274, A_arbace_set_index_A_fn_class); var ifn_276 lang.IFn; if






















	linked_275 == nil { ifn_276 = lang.IFn_Cast(root_274) } else { ifn_276 = nil }; var arg_277 any = r__5; var arg_278 any; var root_270 any = A_arbace_set_A_const_34.GetRawRoot__O(); var linked_271 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_270, aot_arbace_core.A_arbace_core_vals_A_fn_class); var ifn_272 lang.IFn; if linked_271 == nil { ifn_272 = lang.IFn_Cast(root_270) } else { ifn_272 = nil }; var arg_273 any = k__7; if linked_271 == nil { arg_278 = ifn_272.Invoke_O__O(arg_273) } else { arg_278 = linked_271.(*aot_arbace_core.A_arbace_core_vals_A).Invoke_O_O__O(root_270, arg_273) }; if linked_275 == nil { idx__8 = ifn_276.Invoke_O_O__O(arg_277, arg_278) } else { idx__8 = linked_275.(*A_arbace_set_index_A).Invoke_O_O_O__O(root_274, arg_277, arg_278) }; var root_311 any =
	A_arbace_set_A_const_13.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any; var tmp2 any = A_arbace_set_join_fn__1726000064_A_New_O_O(k__7, idx__8); var tmp3 *jrt.Class; var fncls__310 *jrt.Class = A_arbace_set_join_fn__1726000064_A_fn_class; if fncls__310 == nil { var fncls__310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_6, false); A_arbace_set_join_fn__1726000064_A_fn_class = fncls__310d; tmp3 = fncls__310d } else { tmp3 = fncls__310 }; arg_314 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_315 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_316 any = s__6; if linked_312 == nil { return ifn_313.Invoke_O_O_O__O(arg_314, arg_315, arg_316) } else { return linked_312.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_311, arg_314, arg_315, arg_316) } }
//line :114:1
func (t *A_arbace_set_join_A) Invoke_O_O_O__O(self, xrel__0, yrel__1 any) any {





	var tmp1 any; var and__1927000168__auto____3 any; var root_321 any = A_arbace_set_A_const_37.GetRawRoot__O(); var linked_322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_321, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_323 lang.IFn; if linked_322 == nil { ifn_323 = lang.IFn_Cast(root_321) } else { ifn_323 = nil }; var arg_324 any = xrel__0; if linked_322 == nil { and__1927000168__auto____3 = ifn_323.Invoke_O__O(arg_324) } else { and__1927000168__auto____3 = linked_322.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_321, arg_324) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var root_325 any = A_arbace_set_A_const_37.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = yrel__1; if linked_326 == nil { tmp1 = ifn_327.Invoke_O__O(arg_328) } else { tmp1 = linked_326.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_325, arg_328) } } else { tmp1 = and__1927000168__auto____3 }; if jrt.J2g_Truth(tmp1) { var ks__3 any; var root_353 any = A_arbace_set_A_const_17.GetRawRoot__O(); var linked_354 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_353, A_arbace_set_intersection_A_fn_class); var ifn_355 lang.IFn
		if linked_354 == nil { ifn_355 = lang.IFn_Cast(root_353) } else { ifn_355 = nil }; var arg_356 any; var root_337 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any; var root_333 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_333, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_335 lang.IFn; if linked_334 == nil { ifn_335 = lang.IFn_Cast(root_333) } else { ifn_335 = nil }; var arg_336 any; var root_329 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_329, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_331 lang.IFn; if linked_330 == nil { ifn_331 = lang.IFn_Cast(root_329) } else { ifn_331 = nil }; var arg_332 any = xrel__0; if linked_330 == nil { arg_336 = ifn_331.Invoke_O__O(arg_332) } else { arg_336 = linked_330.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_329, arg_332) }; if linked_334 == nil { arg_340 = ifn_335.Invoke_O__O(arg_336) } else { arg_340 = linked_334.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_333, arg_336) }; if linked_338 == nil { arg_356 = ifn_339.Invoke_O__O(arg_340) } else { arg_356 = linked_338.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_337, arg_340) }; var arg_357 any; var root_349 any = A_arbace_set_A_const_22.GetRawRoot__O(); var linked_350 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_349, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_351 lang.IFn; if linked_350 == nil { ifn_351 = lang.IFn_Cast(root_349) } else { ifn_351 = nil }; var arg_352 any; var root_345 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_346 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_345, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_347 lang.IFn; if linked_346 == nil { ifn_347 = lang.IFn_Cast(root_345) } else { ifn_347 = nil }; var arg_348 any; var root_341 any = A_arbace_set_A_const_15.GetRawRoot__O(); var linked_342 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_341, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_343 lang.IFn; if linked_342 == nil { ifn_343 = lang.IFn_Cast(root_341) } else { ifn_343 = nil }; var arg_344 any = yrel__1; if linked_342 == nil { arg_348 = ifn_343.Invoke_O__O(arg_344) } else { arg_348 = linked_342.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_341, arg_344) }; if linked_346 == nil { arg_352 = ifn_347.Invoke_O__O(arg_348) } else { arg_352 = linked_346.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_345, arg_348) }; if linked_350 == nil { arg_357 = ifn_351.Invoke_O__O(arg_352) } else { arg_357 = linked_350.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_349, arg_352) }; if linked_354 == nil { ks__3 = ifn_355.Invoke_O_O__O(arg_356, arg_357) } else { ks__3 = linked_354.(*A_arbace_set_intersection_A).Invoke_O_O_O__O(root_353, arg_356, arg_357) }
//line :120:1
		var vec__1726000054__4 any

		if lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(xrel__0)), int64(lang.RT_Count_O__I_NoInit(yrel__1))) { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(xrel__0, yrel__1) } else { vec__1726000054__4 = lang.Tuple_Create_O_O__IPersistentVector(yrel__1, xrel__0) }
//line :120:1
		var r__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000054__4, lang.RT_IntCast_J__I_NoInit(0), nil); var s__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1726000054__4, lang.RT_IntCast_J__I_NoInit(1), nil); var idx__7 any; var root_358 any = A_arbace_set_A_const_33.GetRawRoot__O(); var linked_359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_358, A_arbace_set_index_A_fn_class); var ifn_360 lang.IFn




		if linked_359 == nil { ifn_360 = lang.IFn_Cast(root_358) } else { ifn_360 = nil }; var arg_361 any = r__5; var arg_362 any = ks__3; if linked_359 == nil { idx__7 = ifn_360.Invoke_O_O__O(arg_361, arg_362) } else { idx__7 = linked_359.(*A_arbace_set_index_A).Invoke_O_O_O__O(root_358, arg_361, arg_362) }
		var root_386 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any; var tmp2 any = A_arbace_set_join_fn__1726000057_A_New_O_O(ks__3, idx__7); var tmp3 *jrt.Class; var fncls__385 *jrt.Class = A_arbace_set_join_fn__1726000057_A_fn_class; if fncls__385 == nil { var fncls__385d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_7, false); A_arbace_set_join_fn__1726000057_A_fn_class = fncls__385d; tmp3 = fncls__385d } else { tmp3 = fncls__385 }; arg_389 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_390 any = lang.PersistentHashSet_EMPTY.Ref(); var arg_391 any = s__6; if linked_387 == nil { return ifn_388.Invoke_O_O_O__O(arg_389, arg_390, arg_391) } else { return linked_387.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_386, arg_389, arg_390, arg_391) } } else {
//line :120:1
			return lang.PersistentHashSet_EMPTY.Ref()
		}
}



func A_arbace_set_join_fn__1726000057_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000057_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000057_A{}; t.Ctor_O_O(p0, p1); return t }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Ctor_O_O(c__ks, c__idx any) { t.F_ks = c__ks; t.F_idx = c__idx }
//line :126:1
func (t *A_arbace_set_join_fn__1726000057_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var found__3 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var tmp2 any; var root_380 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_380, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_382 lang.IFn; if
												linked_381 == nil { ifn_382 = lang.IFn_Cast(root_380) } else { ifn_382 = nil }; var arg_383 any = x__2; var arg_384 any = t.F_ks; if linked_381 == nil { tmp2 = ifn_382.Invoke_O_O__O(arg_383, arg_384) } else { tmp2 = linked_381.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_380, arg_383, arg_384) }; found__3 = tmp1.Invoke_O__O(tmp2); if
												jrt.J2g_Truth(found__3) {
													var root_374 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var tmp3 any = A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(x__2); var tmp4 *jrt.Class; var fncls__373 *jrt.Class = A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class; if fncls__373 == nil { var fncls__373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_8, false); A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class = fncls__373d; tmp4 = fncls__373d } else { tmp4 = fncls__373 }; arg_377 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_378 any = ret__1; var arg_379 any = found__3; if linked_375 == nil { return ifn_376.Invoke_O_O_O__O(arg_377, arg_378, arg_379) } else { return linked_375.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_374, arg_377, arg_378, arg_379) } } else {
//line :128:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(p0 any) *A_arbace_set_join_fn__1726000057_fn__1726000058_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000057_fn__1726000058_A{}; t.Ctor_O(p0); return t }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :129:1
func (t *A_arbace_set_join_fn__1726000057_fn__1726000058_A) Invoke_O_O_O__O(self, p1__1726000050_SHARP___1, p2__1726000051_SHARP___2 any) any { var root_368 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any = p1__1726000050_SHARP___1; var arg_372 any; var root_363 any = A_arbace_set_A_const_35.GetRawRoot__O(); var linked_364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_363, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_365 lang.IFn; if linked_364 == nil { ifn_365 = lang.IFn_Cast(root_363) } else { ifn_365 = nil }; var arg_366 any = p2__1726000051_SHARP___2; var arg_367 any = t.F_x; if linked_364 == nil { arg_372 = ifn_365.Invoke_O_O__O(arg_366, arg_367) } else { arg_372 = linked_364.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_363, arg_366, arg_367) }; if linked_369 == nil { return ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { return linked_369.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) } }








func A_arbace_set_join_fn__1726000064_A_New_O_O(p0, p1 any) *A_arbace_set_join_fn__1726000064_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000064_A{}; t.Ctor_O_O(p0, p1); return t }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Ctor_O_O(c__k, c__idx any) { t.F_k = c__k; t.F_idx = c__idx }
//line :138:1
func (t *A_arbace_set_join_fn__1726000064_A) Invoke_O_O_O__O(self, ret__1, x__2 any) any { var found__3 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_idx); var tmp2 any; var root_305 any = A_arbace_set_A_const_28.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_305, A_arbace_set_rename_keys_A_fn_class); var ifn_307 lang.IFn; if
												linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any; var root_300 any = A_arbace_set_A_const_24.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_302 lang.IFn; if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = x__2; var arg_304 any; var root_296 any = A_arbace_set_A_const_27.GetRawRoot__O(); var linked_297 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_296, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_298 lang.IFn; if linked_297 == nil { ifn_298 = lang.IFn_Cast(root_296) } else { ifn_298 = nil }; var arg_299 any = t.F_k; if linked_297 == nil { arg_304 = ifn_298.Invoke_O__O(arg_299) } else { arg_304 = linked_297.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_296, arg_299) }; if linked_301 == nil { arg_308 = ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { arg_308 = linked_301.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) }; var arg_309 any = t.F_k; if linked_306 == nil { tmp2 = ifn_307.Invoke_O_O__O(arg_308, arg_309) } else { tmp2 = linked_306.(*A_arbace_set_rename_keys_A).Invoke_O_O_O__O(root_305, arg_308, arg_309) }; found__3 = tmp1.Invoke_O__O(tmp2); if
												jrt.J2g_Truth(found__3) {
													var root_290 any = A_arbace_set_A_const_13.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_reduce_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any; var tmp3 any = A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(x__2); var tmp4 *jrt.Class; var fncls__289 *jrt.Class = A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class; if fncls__289 == nil { var fncls__289d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_9, false); A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class = fncls__289d; tmp4 = fncls__289d } else { tmp4 = fncls__289 }; arg_293 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_294 any = ret__1; var arg_295 any = found__3; if linked_291 == nil { return ifn_292.Invoke_O_O_O__O(arg_293, arg_294, arg_295) } else { return linked_291.(*aot_arbace_core.A_arbace_core_reduce_A).Invoke_O_O_O_O__O(root_290, arg_293, arg_294, arg_295) } } else {
//line :140:1
			return ret__1 } }
func A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(p0 any) *A_arbace_set_join_fn__1726000064_fn__1726000065_A { A_arbace_set_A_Init(); t := &A_arbace_set_join_fn__1726000064_fn__1726000065_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :141:1
func (t *A_arbace_set_join_fn__1726000064_fn__1726000065_A) Invoke_O_O_O__O(self, p1__1726000052_SHARP___1, p2__1726000053_SHARP___2 any) any { var root_284 any = A_arbace_set_A_const_5.GetRawRoot__O(); var linked_285 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_284, aot_arbace_core.A_arbace_core_conj__1927000014_A_fn_class); var ifn_286 lang.IFn; if linked_285 == nil { ifn_286 = lang.IFn_Cast(root_284) } else { ifn_286 = nil }; var arg_287 any = p1__1726000052_SHARP___1; var arg_288 any; var root_279 any = A_arbace_set_A_const_35.GetRawRoot__O(); var linked_280 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_279, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_281 lang.IFn; if linked_280 == nil { ifn_281 = lang.IFn_Cast(root_279) } else { ifn_281 = nil }; var arg_282 any = p2__1726000053_SHARP___2; var arg_283 any = t.F_x; if linked_280 == nil { arg_288 = ifn_281.Invoke_O_O__O(arg_282, arg_283) } else { arg_288 = linked_280.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_279, arg_282, arg_283) }; if linked_285 == nil { return ifn_286.Invoke_O_O__O(arg_287, arg_288) } else { return linked_285.(*aot_arbace_core.A_arbace_core_conj__1927000014_A).Invoke_O_O_O__O(root_284, arg_287, arg_288) } }



func A_arbace_set_subset_QMARK__A_New() *A_arbace_set_subset_QMARK__A { A_arbace_set_A_Init(); t := &A_arbace_set_subset_QMARK__A{}; t.Ctor(); return t }
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Ctor() {}
//line :145:1
func (t *A_arbace_set_subset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Lte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(set1__0)), int64(lang.RT_Count_O__I_NoInit(set2__1))); if and__1927000168__auto____3 {





	var root_398 any = A_arbace_set_A_const_38.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any; var tmp1 any = A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(set2__1); var tmp2 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_15, false); A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class = fncls__397d; tmp2 = fncls__397d } else { tmp2 = fncls__397 }; arg_401 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_402 any = set1__0; if linked_399 == nil { return ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { return linked_399.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_398, arg_401, arg_402) } } else {
//line :150:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(p0 any) *A_arbace_set_subset_QMARK__fn__1726000070_A { A_arbace_set_A_Init(); t := &A_arbace_set_subset_QMARK__fn__1726000070_A{}; t.Ctor_O(p0); return t }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Ctor_O(c__set2 any) { t.F_set2 = c__set2 }
//line :151:1
func (t *A_arbace_set_subset_QMARK__fn__1726000070_A) Invoke_O_O__O(self, p1__1726000069_SHARP___1 any) any { var root_392 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_393 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_392, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_394 lang.IFn; if linked_393 == nil { ifn_394 = lang.IFn_Cast(root_392) } else { ifn_394 = nil }; var arg_395 any = t.F_set2; var arg_396 any = p1__1726000069_SHARP___1; if linked_393 == nil { return ifn_394.Invoke_O_O__O(arg_395, arg_396) } else { return linked_393.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_392, arg_395, arg_396) } }

func A_arbace_set_superset_QMARK__A_New() *A_arbace_set_superset_QMARK__A { A_arbace_set_A_Init(); t := &A_arbace_set_superset_QMARK__A{}; t.Ctor(); return t }
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Ctor() {}
//line :153:1
func (t *A_arbace_set_superset_QMARK__A) Invoke_O_O_O__O(self, set1__0, set2__1 any) any { var and__1927000168__auto____3 bool = lang.Numbers_Gte_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(set1__0)), int64(lang.RT_Count_O__I_NoInit(set2__1))); if and__1927000168__auto____3 {





	var root_409 any = A_arbace_set_A_const_38.GetRawRoot__O(); var linked_410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_409, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_411 lang.IFn; if linked_410 == nil { ifn_411 = lang.IFn_Cast(root_409) } else { ifn_411 = nil }; var arg_412 any; var tmp1 any = A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(set1__0); var tmp2 *jrt.Class; var fncls__408 *jrt.Class = A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class; if fncls__408 == nil { var fncls__408d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_16, false); A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class = fncls__408d; tmp2 = fncls__408d } else { tmp2 = fncls__408 }; arg_412 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_413 any = set2__1; if linked_410 == nil { return ifn_411.Invoke_O_O__O(arg_412, arg_413) } else { return linked_410.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_409, arg_412, arg_413) } } else {
//line :158:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____3).Ref() } }
func A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(p0 any) *A_arbace_set_superset_QMARK__fn__1726000074_A { A_arbace_set_A_Init(); t := &A_arbace_set_superset_QMARK__fn__1726000074_A{}; t.Ctor_O(p0); return t }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Ctor_O(c__set1 any) { t.F_set1 = c__set1 }
//line :159:1
func (t *A_arbace_set_superset_QMARK__fn__1726000074_A) Invoke_O_O__O(self, p1__1726000073_SHARP___1 any) any { var root_403 any = A_arbace_set_A_const_18.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = t.F_set1; var arg_407 any = p1__1726000073_SHARP___1; if linked_404 == nil { return ifn_405.Invoke_O_O__O(arg_406, arg_407) } else { return linked_404.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_403, arg_406, arg_407) } }





















































type A_arbace_set_A struct{ jrt.Object }

var A_arbace_set_A_const_pool *jrt.RefArray

var A_arbace_set_A_const_0 *lang.Var

var A_arbace_set_A_const_1 any

var A_arbace_set_A_const_2 *lang.Var

var A_arbace_set_A_const_3 *lang.Var

var A_arbace_set_A_const_4 *lang.Var

var A_arbace_set_A_const_5 *lang.Var

var A_arbace_set_A_const_6 any

var A_arbace_set_A_const_7 *lang.Var

var A_arbace_set_A_const_8 *lang.Var

var A_arbace_set_A_const_9 *lang.Var

var A_arbace_set_A_const_10 *lang.Var

var A_arbace_set_A_const_11 *lang.Var

var A_arbace_set_A_const_12 *lang.Var

var A_arbace_set_A_const_13 *lang.Var

var A_arbace_set_A_const_14 *lang.Var

var A_arbace_set_A_const_15 *lang.Var

var A_arbace_set_A_const_16 *lang.Var

var A_arbace_set_A_const_17 *lang.Var

var A_arbace_set_A_const_18 *lang.Var

var A_arbace_set_A_const_19 *lang.Var

var A_arbace_set_A_const_20 *lang.Var

var A_arbace_set_A_const_21 *lang.Var

var A_arbace_set_A_const_22 *lang.Var

var A_arbace_set_A_const_23 *lang.Var

var A_arbace_set_A_const_24 *lang.Var

var A_arbace_set_A_const_25 *lang.Var

var A_arbace_set_A_const_26 *lang.Var

var A_arbace_set_A_const_27 *lang.Var

var A_arbace_set_A_const_28 *lang.Var

var A_arbace_set_A_const_29 *lang.Var

var A_arbace_set_A_const_30 *lang.Var

var A_arbace_set_A_const_31 *lang.Var

var A_arbace_set_A_const_32 *lang.Var

var A_arbace_set_A_const_33 *lang.Var

var A_arbace_set_A_const_34 *lang.Var

var A_arbace_set_A_const_35 *lang.Var

var A_arbace_set_A_const_36 *lang.Var

var A_arbace_set_A_const_37 *lang.Var

var A_arbace_set_A_const_38 *lang.Var

var A_arbace_set_A_init jrt.ClassInit

func A_arbace_set_A_Init() { if !A_arbace_set_A_init.Done() { A_arbace_set_A_init.Run(A_arbace_set_A_clinit) } }

func A_arbace_set_A_clinit() { A_arbace_set_A_clinit_p0(); A_arbace_set_A_clinit_p1(); A_arbace_set_A_clinit_p2(); A_arbace_set_A_clinit_p3() }

func A_arbace_set_A_clinit_p0() { jrt.StartCheck(); A_arbace_set_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 42); A_arbace_set_A_const_0 = lang.Var_Cast(A_arbace_set_A_const_pool.A[3]); A_arbace_set_A_const_1 = A_arbace_set_A_const_pool.A[4]; A_arbace_set_A_const_2 = lang.Var_Cast(A_arbace_set_A_const_pool.A[5]); A_arbace_set_A_const_3 = lang.Var_Cast(A_arbace_set_A_const_pool.A[6]); A_arbace_set_A_const_4 = lang.Var_Cast(A_arbace_set_A_const_pool.A[7]); A_arbace_set_A_const_5 = lang.Var_Cast(A_arbace_set_A_const_pool.A[8]); A_arbace_set_A_const_6 = A_arbace_set_A_const_pool.A[9]; A_arbace_set_A_const_7 = lang.Var_Cast(A_arbace_set_A_const_pool.A[10]); A_arbace_set_A_const_8 = lang.Var_Cast(A_arbace_set_A_const_pool.A[11]); A_arbace_set_A_const_9 = lang.Var_Cast(A_arbace_set_A_const_pool.A[12]); A_arbace_set_A_const_10 = lang.Var_Cast(A_arbace_set_A_const_pool.A[13]) }

func A_arbace_set_A_clinit_p1() { A_arbace_set_A_const_11 = lang.Var_Cast(A_arbace_set_A_const_pool.A[14]); A_arbace_set_A_const_12 = lang.Var_Cast(A_arbace_set_A_const_pool.A[15]); A_arbace_set_A_const_13 = lang.Var_Cast(A_arbace_set_A_const_pool.A[16]); A_arbace_set_A_const_14 = lang.Var_Cast(A_arbace_set_A_const_pool.A[17]); A_arbace_set_A_const_15 = lang.Var_Cast(A_arbace_set_A_const_pool.A[18]); A_arbace_set_A_const_16 = lang.Var_Cast(A_arbace_set_A_const_pool.A[19]); A_arbace_set_A_const_17 = lang.Var_Cast(A_arbace_set_A_const_pool.A[20]); A_arbace_set_A_const_18 = lang.Var_Cast(A_arbace_set_A_const_pool.A[21]); A_arbace_set_A_const_19 = lang.Var_Cast(A_arbace_set_A_const_pool.A[22]); A_arbace_set_A_const_20 = lang.Var_Cast(A_arbace_set_A_const_pool.A[23]); A_arbace_set_A_const_21 = lang.Var_Cast(A_arbace_set_A_const_pool.A[24]); A_arbace_set_A_const_22 = lang.Var_Cast(A_arbace_set_A_const_pool.A[25]) }

func A_arbace_set_A_clinit_p2() { A_arbace_set_A_const_23 = lang.Var_Cast(A_arbace_set_A_const_pool.A[26]); A_arbace_set_A_const_24 = lang.Var_Cast(A_arbace_set_A_const_pool.A[27]); A_arbace_set_A_const_25 = lang.Var_Cast(A_arbace_set_A_const_pool.A[28]); A_arbace_set_A_const_26 = lang.Var_Cast(A_arbace_set_A_const_pool.A[29]); A_arbace_set_A_const_27 = lang.Var_Cast(A_arbace_set_A_const_pool.A[30]); A_arbace_set_A_const_28 = lang.Var_Cast(A_arbace_set_A_const_pool.A[31]); A_arbace_set_A_const_29 = lang.Var_Cast(A_arbace_set_A_const_pool.A[32]); A_arbace_set_A_const_30 = lang.Var_Cast(A_arbace_set_A_const_pool.A[33]); A_arbace_set_A_const_31 = lang.Var_Cast(A_arbace_set_A_const_pool.A[34]); A_arbace_set_A_const_32 = lang.Var_Cast(A_arbace_set_A_const_pool.A[35]); A_arbace_set_A_const_33 = lang.Var_Cast(A_arbace_set_A_const_pool.A[36]); A_arbace_set_A_const_34 = lang.Var_Cast(A_arbace_set_A_const_pool.A[37]) }

func A_arbace_set_A_clinit_p3() { A_arbace_set_A_const_35 = lang.Var_Cast(A_arbace_set_A_const_pool.A[38]); A_arbace_set_A_const_36 = lang.Var_Cast(A_arbace_set_A_const_pool.A[39]); A_arbace_set_A_const_37 = lang.Var_Cast(A_arbace_set_A_const_pool.A[40]); A_arbace_set_A_const_38 = lang.Var_Cast(A_arbace_set_A_const_pool.A[41]) }

func A_arbace_set_A_New() *A_arbace_set_A { A_arbace_set_A_Init(); t := &A_arbace_set_A{}; t.Ctor(); return t }

func (t *A_arbace_set_A) Ctor() {}

func (t *A_arbace_set_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_A) GetClass__Class() *jrt.Class { return A_arbace_set_A_class }

func (t *A_arbace_set_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_A); return ok }

func A_arbace_set_A_Cast(x any) *A_arbace_set_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_A_class)) }; return v }



type A_arbace_set_bubble_max_key_A struct{ j2g_header uint64 }

var A_arbace_set_bubble_max_key_A_fn_class *jrt.Class



type A_arbace_set_bubble_max_key_fn__1726000013_A struct{ j2g_header uint64; F_max any }

var A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class *jrt.Class



type A_arbace_set_difference_A struct{ j2g_header uint64 }

var A_arbace_set_difference_A_fn_class *jrt.Class



type A_arbace_set_difference_fn__1726000023_A struct{ j2g_header uint64; F_s2 any }

var A_arbace_set_difference_fn__1726000023_A_fn_class *jrt.Class



type A_arbace_set_eval1726000004_A struct{ jrt.Object }

func A_arbace_set_eval1726000004_A_New() *A_arbace_set_eval1726000004_A { t := &A_arbace_set_eval1726000004_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000004_A) Ctor() {}

func (t *A_arbace_set_eval1726000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000004_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000004_A_class }

func (t *A_arbace_set_eval1726000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000004_A); return ok }

func A_arbace_set_eval1726000004_A_Cast(x any) *A_arbace_set_eval1726000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000004_A_class)) }; return v }



type A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A struct{ j2g_header uint64 }

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class *jrt.Class



type A_arbace_set_eval1726000008_A struct{ jrt.Object }

func A_arbace_set_eval1726000008_A_New() *A_arbace_set_eval1726000008_A { t := &A_arbace_set_eval1726000008_A{}; t.Ctor(); return t }

func (t *A_arbace_set_eval1726000008_A) Ctor() {}

func (t *A_arbace_set_eval1726000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set_eval1726000008_A) GetClass__Class() *jrt.Class { return A_arbace_set_eval1726000008_A_class }

func (t *A_arbace_set_eval1726000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set_eval1726000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_set_eval1726000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set_eval1726000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set_eval1726000008_A); return ok }

func A_arbace_set_eval1726000008_A_Cast(x any) *A_arbace_set_eval1726000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set_eval1726000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set_eval1726000008_A_class)) }; return v }



type A_arbace_set_eval1726000008_fn__1726000009_A struct{ j2g_header uint64 }

var A_arbace_set_eval1726000008_fn__1726000009_A_fn_class *jrt.Class



type A_arbace_set_index_A struct{ j2g_header uint64 }

var A_arbace_set_index_A_fn_class *jrt.Class



type A_arbace_set_index_fn__1726000044_A struct{ j2g_header uint64; F_ks any }

var A_arbace_set_index_fn__1726000044_A_fn_class *jrt.Class



type A_arbace_set_intersection_A struct{ j2g_header uint64 }

var A_arbace_set_intersection_A_fn_class *jrt.Class



type A_arbace_set_intersection_fn__1726000018_A struct{ j2g_header uint64; F_s2 any }

var A_arbace_set_intersection_fn__1726000018_A_fn_class *jrt.Class



type A_arbace_set_intersection_fn__1726000020_A struct{ j2g_header uint64 }

var A_arbace_set_intersection_fn__1726000020_A_fn_class *jrt.Class



type A_arbace_set_join_A struct{ j2g_header uint64 }

var A_arbace_set_join_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000057_A struct{ j2g_header uint64; F_ks, F_idx any }

var A_arbace_set_join_fn__1726000057_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000057_fn__1726000058_A struct{ j2g_header uint64; F_x any }

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000064_A struct{ j2g_header uint64; F_k, F_idx any }

var A_arbace_set_join_fn__1726000064_A_fn_class *jrt.Class



type A_arbace_set_join_fn__1726000064_fn__1726000065_A struct{ j2g_header uint64; F_x any }

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class *jrt.Class



type A_arbace_set_map_invert_A struct{ j2g_header uint64 }

var A_arbace_set_map_invert_A_fn_class *jrt.Class



type A_arbace_set_map_invert_fn__1726000047_A struct{ j2g_header uint64 }

var A_arbace_set_map_invert_fn__1726000047_A_fn_class *jrt.Class



type A_arbace_set_project_A struct{ j2g_header uint64 }

var A_arbace_set_project_A_fn_class *jrt.Class



type A_arbace_set_project_fn__1726000030_A struct{ j2g_header uint64; F_ks any }

var A_arbace_set_project_fn__1726000030_A_fn_class *jrt.Class



type A_arbace_set_rename_A struct{ j2g_header uint64 }

var A_arbace_set_rename_A_fn_class *jrt.Class



type A_arbace_set_rename_fn__1726000041_A struct{ j2g_header uint64; F_kmap any }

var A_arbace_set_rename_fn__1726000041_A_fn_class *jrt.Class



type A_arbace_set_rename_keys_A struct{ j2g_header uint64 }

var A_arbace_set_rename_keys_A_fn_class *jrt.Class



type A_arbace_set_rename_keys_fn__1726000034_A struct{ j2g_header uint64; F_map any }

var A_arbace_set_rename_keys_fn__1726000034_A_fn_class *jrt.Class



type A_arbace_set_select_A struct{ j2g_header uint64 }

var A_arbace_set_select_A_fn_class *jrt.Class



type A_arbace_set_select_fn__1726000026_A struct{ j2g_header uint64; F_pred any }

var A_arbace_set_select_fn__1726000026_A_fn_class *jrt.Class



type A_arbace_set_subset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_set_subset_QMARK__A_fn_class *jrt.Class



type A_arbace_set_subset_QMARK__fn__1726000070_A struct{ j2g_header uint64; F_set2 any }

var A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class *jrt.Class



type A_arbace_set_superset_QMARK__A struct{ j2g_header uint64 }

var A_arbace_set_superset_QMARK__A_fn_class *jrt.Class



type A_arbace_set_superset_QMARK__fn__1726000074_A struct{ j2g_header uint64; F_set1 any }

var A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class *jrt.Class



type A_arbace_set_union_A struct{ j2g_header uint64 }

var A_arbace_set_union_A_fn_class *jrt.Class
