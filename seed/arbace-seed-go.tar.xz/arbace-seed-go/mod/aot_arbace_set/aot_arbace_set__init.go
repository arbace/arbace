//line aot_arbace_set__init.ae:1
package aot_arbace_set

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_set__init_A_Load__O() any { A_arbace_set__init_A_Init(); A_arbace_set__init_A_Unit0__O(); A_arbace_set__init_A_Unit1__O(); A_arbace_set__init_A_Unit2__O(); A_arbace_set__init_A_Unit3__O(); A_arbace_set__init_A_Unit4__O(); A_arbace_set__init_A_Unit5__O(); A_arbace_set__init_A_Unit6__O(); A_arbace_set__init_A_Unit7__O(); A_arbace_set__init_A_Unit8__O(); A_arbace_set__init_A_Unit9__O(); A_arbace_set__init_A_Unit10__O(); A_arbace_set__init_A_Unit11__O(); A_arbace_set__init_A_Unit12__O(); A_arbace_set__init_A_Unit13__O(); A_arbace_set__init_A_Unit14__O(); A_arbace_set__init_A_Unit15__O(); A_arbace_set__init_A_Unit16__O(); A_arbace_set__init_A_Unit17__O(); return nil }



func A_arbace_set__init_A_Unit0__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return lang.IFn_Cast(jrt.NN(A_arbace_set__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_set__init_A_const_1) }
//line :9:1
func A_arbace_set__init_A_Unit1__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_set__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_2)) }
//line :9:1
func A_arbace_set__init_A_Unit2__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); var tmp1 any = A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_New(); var tmp2 *jrt.Class; A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_Init(); tmp2 = A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :9:1
func A_arbace_set__init_A_Unit3__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(9, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_set__init_A_const_1)).Equals_O__Z(A_arbace_set__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_set_eval1726000008_fn__1726000009_A_New(); var tmp2 *jrt.Class; A_arbace_set_eval1726000008_fn__1726000009_A_Init(); tmp2 = A_arbace_set_eval1726000008_fn__1726000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_set__init_A_Unit4__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(13, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_4; var tmp2 any = A_arbace_set_bubble_max_key_A_New(); var tmp3 *jrt.Class; A_arbace_set_bubble_max_key_A_Init(); tmp3 = A_arbace_set_bubble_max_key_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_5)); return A_arbace_set__init_A_const_4.Ref() }






func A_arbace_set__init_A_Unit5__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(20, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_6; var tmp2 any = A_arbace_set_union_A_New(); var tmp3 *jrt.Class; A_arbace_set_union_A_Init(); tmp3 = A_arbace_set_union_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_set__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_7)); return A_arbace_set__init_A_const_6.Ref() }












func A_arbace_set__init_A_Unit6__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_8; var tmp2 any = A_arbace_set_intersection_A_New(); var tmp3 *jrt.Class; A_arbace_set_intersection_A_Init(); tmp3 = A_arbace_set_intersection_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_set__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_9)); return A_arbace_set__init_A_const_8.Ref() }















func A_arbace_set__init_A_Unit7__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_10; var tmp2 any = A_arbace_set_difference_A_New(); var tmp3 *jrt.Class; A_arbace_set_difference_A_Init(); tmp3 = A_arbace_set_difference_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 2)); var tmp4 *lang.Var = A_arbace_set__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_11)); return A_arbace_set__init_A_const_10.Ref() }














func A_arbace_set__init_A_Unit8__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(64, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_12; var tmp2 any = A_arbace_set_select_A_New(); var tmp3 *jrt.Class; A_arbace_set_select_A_Init(); tmp3 = A_arbace_set_select_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_13)); return A_arbace_set__init_A_const_12.Ref() }






func A_arbace_set__init_A_Unit9__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_14; var tmp2 any = A_arbace_set_project_A_New(); var tmp3 *jrt.Class; A_arbace_set_project_A_Init(); tmp3 = A_arbace_set_project_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_14; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_15)); return A_arbace_set__init_A_const_14.Ref() }





func A_arbace_set__init_A_Unit10__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(77, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_16; var tmp2 any = A_arbace_set_rename_keys_A_New(); var tmp3 *jrt.Class; A_arbace_set_rename_keys_A_Init(); tmp3 = A_arbace_set_rename_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_16; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_17)); return A_arbace_set__init_A_const_16.Ref() }










func A_arbace_set__init_A_Unit11__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(88, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_18; var tmp2 any = A_arbace_set_rename_A_New(); var tmp3 *jrt.Class; A_arbace_set_rename_A_Init(); tmp3 = A_arbace_set_rename_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_18; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_19)); return A_arbace_set__init_A_const_18.Ref() }





func A_arbace_set__init_A_Unit12__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(94, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_20; var tmp2 any = A_arbace_set_index_A_New(); var tmp3 *jrt.Class; A_arbace_set_index_A_Init(); tmp3 = A_arbace_set_index_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_20; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_21)); return A_arbace_set__init_A_const_20.Ref() }










func A_arbace_set__init_A_Unit13__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(105, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_22; var tmp2 any = A_arbace_set_map_invert_A_New(); var tmp3 *jrt.Class; A_arbace_set_map_invert_A_Init(); tmp3 = A_arbace_set_map_invert_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_22; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_23)); return A_arbace_set__init_A_const_22.Ref() }








func A_arbace_set__init_A_Unit14__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(114, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_24; var tmp2 any = A_arbace_set_join_A_New(); var tmp3 *jrt.Class; A_arbace_set_join_A_Init(); tmp3 = A_arbace_set_join_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_24; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_25)); return A_arbace_set__init_A_const_24.Ref() }






























func A_arbace_set__init_A_Unit15__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(145, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_26; var tmp2 any = A_arbace_set_subset_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_set_subset_QMARK__A_Init(); tmp3 = A_arbace_set_subset_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_26; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_27)); return A_arbace_set__init_A_const_26.Ref() }







func A_arbace_set__init_A_Unit16__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(153, 1); var tmp1 *lang.Var = A_arbace_set__init_A_const_28; var tmp2 any = A_arbace_set_superset_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_set_superset_QMARK__A_Init(); tmp3 = A_arbace_set_superset_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_set__init_A_const_28; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_set__init_A_const_29)); return A_arbace_set__init_A_const_28.Ref() }







func A_arbace_set__init_A_Unit17__O() any { A_arbace_set__init_A_Init(); lang.Compiler_AOT_At_I_I__V(161, 1); return nil }



type A_arbace_set__init_A struct{ jrt.Object }

var A_arbace_set__init_A_const_0 *lang.Var

var A_arbace_set__init_A_const_1 any

var A_arbace_set__init_A_const_2 any

var A_arbace_set__init_A_const_3 any

var A_arbace_set__init_A_const_4 *lang.Var

var A_arbace_set__init_A_const_5 any

var A_arbace_set__init_A_const_6 *lang.Var

var A_arbace_set__init_A_const_7 any

var A_arbace_set__init_A_const_8 *lang.Var

var A_arbace_set__init_A_const_9 any

var A_arbace_set__init_A_const_10 *lang.Var

var A_arbace_set__init_A_const_11 any

var A_arbace_set__init_A_const_12 *lang.Var

var A_arbace_set__init_A_const_13 any

var A_arbace_set__init_A_const_14 *lang.Var

var A_arbace_set__init_A_const_15 any

var A_arbace_set__init_A_const_16 *lang.Var

var A_arbace_set__init_A_const_17 any

var A_arbace_set__init_A_const_18 *lang.Var

var A_arbace_set__init_A_const_19 any

var A_arbace_set__init_A_const_20 *lang.Var

var A_arbace_set__init_A_const_21 any

var A_arbace_set__init_A_const_22 *lang.Var

var A_arbace_set__init_A_const_23 any

var A_arbace_set__init_A_const_24 *lang.Var

var A_arbace_set__init_A_const_25 any

var A_arbace_set__init_A_const_26 *lang.Var

var A_arbace_set__init_A_const_27 any

var A_arbace_set__init_A_const_28 *lang.Var

var A_arbace_set__init_A_const_29 any

var A_arbace_set__init_A_init jrt.ClassInit

func A_arbace_set__init_A_Init() { if !A_arbace_set__init_A_init.Done() { A_arbace_set__init_A_init.Run(A_arbace_set__init_A_clinit) } }

func A_arbace_set__init_A_clinit() { A_arbace_set__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_set__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9))); A_arbace_set__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7, lang.RT_Keyword_String_String__Keyword(nil, Lit_8).Ref(), Lit_9)); A_arbace_set__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_set__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_15); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_set__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_77).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_78).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_79, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(13).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_84); A_arbace_set__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_89, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_5, Lit_21); A_arbace_set__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_92, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_5, Lit_24); A_arbace_set__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref()), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref()), lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_85).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_86).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_87).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_88).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_93, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_5, Lit_94); A_arbace_set__init_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_95).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_96).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_97, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(64).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_14 = lang.RT_Var_String_String__Var(Lit_5, Lit_98); A_arbace_set__init_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_101, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(71).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_16 = lang.RT_Var_String_String__Var(Lit_5, Lit_32); A_arbace_set__init_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_27).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_103, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(77).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_18 = lang.RT_Var_String_String__Var(Lit_5, Lit_104); A_arbace_set__init_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_102).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_105, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(88).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_20 = lang.RT_Var_String_String__Var(Lit_5, Lit_37); A_arbace_set__init_A_const_21 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_100).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_106, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(94).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_22 = lang.RT_Var_String_String__Var(Lit_5, Lit_38); A_arbace_set__init_A_const_23 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_107).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_108, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(105).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_24 = lang.RT_Var_String_String__Var(Lit_5, Lit_109); A_arbace_set__init_A_const_25 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref()), lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_99).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_110).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_111).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_112, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_91, lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(114).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_26 = lang.RT_Var_String_String__Var(Lit_5, Lit_113); A_arbace_set__init_A_const_27 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_116, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_117, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_119).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(145).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)); A_arbace_set__init_A_const_28 = lang.RT_Var_String_String__Var(Lit_5, Lit_120); A_arbace_set__init_A_const_29 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_114).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_115).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_121, lang.RT_Keyword_String_String__Keyword(nil, Lit_90).Ref(), Lit_117, lang.RT_Keyword_String_String__Keyword(nil, Lit_118).Ref(), lang.RT_ClassForNameNonLoading_String__Class(Lit_119).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_80).Ref(), jrt.Integer_ValueOf_I__Integer(153).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_81).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_82).Ref(), Lit_83)) }

func A_arbace_set__init_A_New() *A_arbace_set__init_A { A_arbace_set__init_A_Init(); t := &A_arbace_set__init_A{}; t.Ctor(); return t }

func (t *A_arbace_set__init_A) Ctor() {}

func (t *A_arbace_set__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_set__init_A) GetClass__Class() *jrt.Class { return A_arbace_set__init_A_class }

func (t *A_arbace_set__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_set__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_set__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_set__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_set__init_A); return ok }

func A_arbace_set__init_A_Cast(x any) *A_arbace_set__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_set__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_set__init_A_class)) }; return v }
