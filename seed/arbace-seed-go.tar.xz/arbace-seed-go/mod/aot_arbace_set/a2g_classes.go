//line a2g_classes.ae:1
package aot_arbace_set

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_set_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_A_New()}; return nil }

var A_arbace_set_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_set_A_new}

var A_arbace_set_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_set.A_arbace_set_A"})

func init() { i := A_arbace_set_A_class.Info(); i.IsInstance = A_arbace_set_A_InstanceOf; i.Init = A_arbace_set_A_Init; i.Table = A_arbace_set_A_members; jrt.RegisterGoType(A_arbace_set_A_class, reflect.TypeFor[A_arbace_set_A]()) }

func A_arbace_set_bubble_max_key_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_bubble_max_key_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_bubble_max_key_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_bubble_max_key_A_New()}; return nil }

func A_arbace_set_bubble_max_key_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_bubble_max_key_A_fn_class)}; return nil }

var A_arbace_set_bubble_max_key_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_bubble_max_key_A_invoke, New: A_arbace_set_bubble_max_key_A_new, Get: A_arbace_set_bubble_max_key_A_get}

var A_arbace_set_bubble_max_key_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$bubble_max_key", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "bubble_max_key", Go: "arbace/aot_arbace_set.A_arbace_set_bubble_max_key_A", Source: "set.ae"})

func init() { i := A_arbace_set_bubble_max_key_A_class.Info(); i.IsInstance = A_arbace_set_bubble_max_key_A_InstanceOf; i.Init = A_arbace_set_bubble_max_key_A_Init; i.Table = A_arbace_set_bubble_max_key_A_members; jrt.RegisterGoType(A_arbace_set_bubble_max_key_A_class, reflect.TypeFor[A_arbace_set_bubble_max_key_A]()) }

func A_arbace_set_bubble_max_key_fn__1726000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_bubble_max_key_fn__1726000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_bubble_max_key_fn__1726000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_bubble_max_key_fn__1726000013_A_New_O(args[0])}; return nil }

func A_arbace_set_bubble_max_key_fn__1726000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_bubble_max_key_fn__1726000013_A_fn_class)}; return nil }

var A_arbace_set_bubble_max_key_fn__1726000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_bubble_max_key_fn__1726000013_A_invoke, New: A_arbace_set_bubble_max_key_fn__1726000013_A_new, Get: A_arbace_set_bubble_max_key_fn__1726000013_A_get}

var A_arbace_set_bubble_max_key_fn__1726000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$bubble_max_key$fn__1726000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_bubble_max_key_A_class, Simple: "fn__1726000013", Go: "arbace/aot_arbace_set.A_arbace_set_bubble_max_key_fn__1726000013_A", Source: "set.ae"})

func init() { i := A_arbace_set_bubble_max_key_fn__1726000013_A_class.Info(); i.IsInstance = A_arbace_set_bubble_max_key_fn__1726000013_A_InstanceOf; i.Init = A_arbace_set_bubble_max_key_fn__1726000013_A_Init; i.Table = A_arbace_set_bubble_max_key_fn__1726000013_A_members; jrt.RegisterGoType(A_arbace_set_bubble_max_key_fn__1726000013_A_class, reflect.TypeFor[A_arbace_set_bubble_max_key_fn__1726000013_A]()) }

func A_arbace_set_difference_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_difference_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_set_difference_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_set_difference_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_difference_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_difference_A_New()}; return nil }

func A_arbace_set_difference_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_difference_A_fn_class)}; return nil }

var A_arbace_set_difference_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_difference_A_invoke, New: A_arbace_set_difference_A_new, Get: A_arbace_set_difference_A_get}

var A_arbace_set_difference_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$difference", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_A_class, Simple: "difference", Go: "arbace/aot_arbace_set.A_arbace_set_difference_A", Source: "set.ae"})

func init() { i := A_arbace_set_difference_A_class.Info(); i.IsInstance = A_arbace_set_difference_A_InstanceOf; i.Init = A_arbace_set_difference_A_Init; i.Table = A_arbace_set_difference_A_members; jrt.RegisterGoType(A_arbace_set_difference_A_class, reflect.TypeFor[A_arbace_set_difference_A]()) }

func A_arbace_set_difference_fn__1726000023_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_difference_fn__1726000023_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_difference_fn__1726000023_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_difference_fn__1726000023_A_New_O(args[0])}; return nil }

func A_arbace_set_difference_fn__1726000023_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_difference_fn__1726000023_A_fn_class)}; return nil }

var A_arbace_set_difference_fn__1726000023_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_difference_fn__1726000023_A_invoke, New: A_arbace_set_difference_fn__1726000023_A_new, Get: A_arbace_set_difference_fn__1726000023_A_get}

var A_arbace_set_difference_fn__1726000023_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$difference$fn__1726000023", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_difference_A_class, Simple: "fn__1726000023", Go: "arbace/aot_arbace_set.A_arbace_set_difference_fn__1726000023_A", Source: "set.ae"})

func init() { i := A_arbace_set_difference_fn__1726000023_A_class.Info(); i.IsInstance = A_arbace_set_difference_fn__1726000023_A_InstanceOf; i.Init = A_arbace_set_difference_fn__1726000023_A_Init; i.Table = A_arbace_set_difference_fn__1726000023_A_members; jrt.RegisterGoType(A_arbace_set_difference_fn__1726000023_A_class, reflect.TypeFor[A_arbace_set_difference_fn__1726000023_A]()) }

func A_arbace_set_eval1726000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_eval1726000004_A_New()}; return nil }

var A_arbace_set_eval1726000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_set_eval1726000004_A_new}

var A_arbace_set_eval1726000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$eval1726000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_set_A_class, Simple: "eval1726000004", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000004_A"})

func init() { i := A_arbace_set_eval1726000004_A_class.Info(); i.IsInstance = A_arbace_set_eval1726000004_A_InstanceOf; i.Table = A_arbace_set_eval1726000004_A_members; jrt.RegisterGoType(A_arbace_set_eval1726000004_A_class, reflect.TypeFor[A_arbace_set_eval1726000004_A]()) }

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_New()}; return nil }

func A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_fn_class)}; return nil }

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_invoke, New: A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_new, Get: A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_get}

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$eval1726000004$loading__1927001464__auto____1726000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_set_eval1726000004_A_class, Simple: "loading__1927001464__auto____1726000005", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A", Source: "set.ae"})

func init() { i := A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class.Info(); i.IsInstance = A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_InstanceOf; i.Init = A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_Init; i.Table = A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_members; jrt.RegisterGoType(A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class, reflect.TypeFor[A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A]()) }

func A_arbace_set_eval1726000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_eval1726000008_A_New()}; return nil }

var A_arbace_set_eval1726000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_set_eval1726000008_A_new}

var A_arbace_set_eval1726000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$eval1726000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_set_A_class, Simple: "eval1726000008", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000008_A"})

func init() { i := A_arbace_set_eval1726000008_A_class.Info(); i.IsInstance = A_arbace_set_eval1726000008_A_InstanceOf; i.Table = A_arbace_set_eval1726000008_A_members; jrt.RegisterGoType(A_arbace_set_eval1726000008_A_class, reflect.TypeFor[A_arbace_set_eval1726000008_A]()) }

func A_arbace_set_eval1726000008_fn__1726000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_eval1726000008_fn__1726000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_set_eval1726000008_fn__1726000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_eval1726000008_fn__1726000009_A_New()}; return nil }

func A_arbace_set_eval1726000008_fn__1726000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_eval1726000008_fn__1726000009_A_fn_class)}; return nil }

var A_arbace_set_eval1726000008_fn__1726000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_eval1726000008_fn__1726000009_A_invoke, New: A_arbace_set_eval1726000008_fn__1726000009_A_new, Get: A_arbace_set_eval1726000008_fn__1726000009_A_get}

var A_arbace_set_eval1726000008_fn__1726000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$eval1726000008$fn__1726000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_set_eval1726000008_A_class, Simple: "fn__1726000009", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000008_fn__1726000009_A", Source: "set.ae"})

func init() { i := A_arbace_set_eval1726000008_fn__1726000009_A_class.Info(); i.IsInstance = A_arbace_set_eval1726000008_fn__1726000009_A_InstanceOf; i.Init = A_arbace_set_eval1726000008_fn__1726000009_A_Init; i.Table = A_arbace_set_eval1726000008_fn__1726000009_A_members; jrt.RegisterGoType(A_arbace_set_eval1726000008_fn__1726000009_A_class, reflect.TypeFor[A_arbace_set_eval1726000008_fn__1726000009_A]()) }

func A_arbace_set_index_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_index_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_index_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_index_A_New()}; return nil }

func A_arbace_set_index_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_index_A_fn_class)}; return nil }

var A_arbace_set_index_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_index_A_invoke, New: A_arbace_set_index_A_new, Get: A_arbace_set_index_A_get}

var A_arbace_set_index_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$index", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "index", Go: "arbace/aot_arbace_set.A_arbace_set_index_A", Source: "set.ae"})

func init() { i := A_arbace_set_index_A_class.Info(); i.IsInstance = A_arbace_set_index_A_InstanceOf; i.Init = A_arbace_set_index_A_Init; i.Table = A_arbace_set_index_A_members; jrt.RegisterGoType(A_arbace_set_index_A_class, reflect.TypeFor[A_arbace_set_index_A]()) }

func A_arbace_set_index_fn__1726000044_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_index_fn__1726000044_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_index_fn__1726000044_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_index_fn__1726000044_A_New_O(args[0])}; return nil }

func A_arbace_set_index_fn__1726000044_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_index_fn__1726000044_A_fn_class)}; return nil }

var A_arbace_set_index_fn__1726000044_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_index_fn__1726000044_A_invoke, New: A_arbace_set_index_fn__1726000044_A_new, Get: A_arbace_set_index_fn__1726000044_A_get}

var A_arbace_set_index_fn__1726000044_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$index$fn__1726000044", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_index_A_class, Simple: "fn__1726000044", Go: "arbace/aot_arbace_set.A_arbace_set_index_fn__1726000044_A", Source: "set.ae"})

func init() { i := A_arbace_set_index_fn__1726000044_A_class.Info(); i.IsInstance = A_arbace_set_index_fn__1726000044_A_InstanceOf; i.Init = A_arbace_set_index_fn__1726000044_A_Init; i.Table = A_arbace_set_index_fn__1726000044_A_members; jrt.RegisterGoType(A_arbace_set_index_fn__1726000044_A_class, reflect.TypeFor[A_arbace_set_index_fn__1726000044_A]()) }

func A_arbace_set_intersection_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_intersection_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_set_intersection_A).Invoke_O_O__O(args[0], args[1]); case 2: return this.(*A_arbace_set_intersection_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_intersection_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_intersection_A_New()}; return nil }

func A_arbace_set_intersection_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_intersection_A_fn_class)}; return nil }

var A_arbace_set_intersection_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_intersection_A_invoke, New: A_arbace_set_intersection_A_new, Get: A_arbace_set_intersection_A_get}

var A_arbace_set_intersection_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$intersection", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_A_class, Simple: "intersection", Go: "arbace/aot_arbace_set.A_arbace_set_intersection_A", Source: "set.ae"})

func init() { i := A_arbace_set_intersection_A_class.Info(); i.IsInstance = A_arbace_set_intersection_A_InstanceOf; i.Init = A_arbace_set_intersection_A_Init; i.Table = A_arbace_set_intersection_A_members; jrt.RegisterGoType(A_arbace_set_intersection_A_class, reflect.TypeFor[A_arbace_set_intersection_A]()) }

func A_arbace_set_intersection_fn__1726000018_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_intersection_fn__1726000018_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_intersection_fn__1726000018_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_intersection_fn__1726000018_A_New_O(args[0])}; return nil }

func A_arbace_set_intersection_fn__1726000018_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_intersection_fn__1726000018_A_fn_class)}; return nil }

var A_arbace_set_intersection_fn__1726000018_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_intersection_fn__1726000018_A_invoke, New: A_arbace_set_intersection_fn__1726000018_A_new, Get: A_arbace_set_intersection_fn__1726000018_A_get}

var A_arbace_set_intersection_fn__1726000018_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$intersection$fn__1726000018", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_intersection_A_class, Simple: "fn__1726000018", Go: "arbace/aot_arbace_set.A_arbace_set_intersection_fn__1726000018_A", Source: "set.ae"})

func init() { i := A_arbace_set_intersection_fn__1726000018_A_class.Info(); i.IsInstance = A_arbace_set_intersection_fn__1726000018_A_InstanceOf; i.Init = A_arbace_set_intersection_fn__1726000018_A_Init; i.Table = A_arbace_set_intersection_fn__1726000018_A_members; jrt.RegisterGoType(A_arbace_set_intersection_fn__1726000018_A_class, reflect.TypeFor[A_arbace_set_intersection_fn__1726000018_A]()) }

func A_arbace_set_intersection_fn__1726000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_intersection_fn__1726000020_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_intersection_fn__1726000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_intersection_fn__1726000020_A_New()}; return nil }

func A_arbace_set_intersection_fn__1726000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_intersection_fn__1726000020_A_fn_class)}; return nil }

var A_arbace_set_intersection_fn__1726000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_intersection_fn__1726000020_A_invoke, New: A_arbace_set_intersection_fn__1726000020_A_new, Get: A_arbace_set_intersection_fn__1726000020_A_get}

var A_arbace_set_intersection_fn__1726000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$intersection$fn__1726000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_intersection_A_class, Simple: "fn__1726000020", Go: "arbace/aot_arbace_set.A_arbace_set_intersection_fn__1726000020_A", Source: "set.ae"})

func init() { i := A_arbace_set_intersection_fn__1726000020_A_class.Info(); i.IsInstance = A_arbace_set_intersection_fn__1726000020_A_InstanceOf; i.Init = A_arbace_set_intersection_fn__1726000020_A_Init; i.Table = A_arbace_set_intersection_fn__1726000020_A_members; jrt.RegisterGoType(A_arbace_set_intersection_fn__1726000020_A_class, reflect.TypeFor[A_arbace_set_intersection_fn__1726000020_A]()) }

func A_arbace_set_join_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_join_A).Invoke_O_O_O__O(args[0], args[1], args[2]); case 1: return this.(*A_arbace_set_join_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_set_join_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_join_A_New()}; return nil }

func A_arbace_set_join_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_join_A_fn_class)}; return nil }

var A_arbace_set_join_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_join_A_invoke, New: A_arbace_set_join_A_new, Get: A_arbace_set_join_A_get}

var A_arbace_set_join_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$join", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class, lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "join", Go: "arbace/aot_arbace_set.A_arbace_set_join_A", Source: "set.ae"})

func init() { i := A_arbace_set_join_A_class.Info(); i.IsInstance = A_arbace_set_join_A_InstanceOf; i.Init = A_arbace_set_join_A_Init; i.Table = A_arbace_set_join_A_members; jrt.RegisterGoType(A_arbace_set_join_A_class, reflect.TypeFor[A_arbace_set_join_A]()) }

func A_arbace_set_join_fn__1726000057_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_join_fn__1726000057_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_join_fn__1726000057_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_join_fn__1726000057_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_set_join_fn__1726000057_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_join_fn__1726000057_A_fn_class)}; return nil }

var A_arbace_set_join_fn__1726000057_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_join_fn__1726000057_A_invoke, New: A_arbace_set_join_fn__1726000057_A_new, Get: A_arbace_set_join_fn__1726000057_A_get}

var A_arbace_set_join_fn__1726000057_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$join$fn__1726000057", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_join_A_class, Simple: "fn__1726000057", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000057_A", Source: "set.ae"})

func init() { i := A_arbace_set_join_fn__1726000057_A_class.Info(); i.IsInstance = A_arbace_set_join_fn__1726000057_A_InstanceOf; i.Init = A_arbace_set_join_fn__1726000057_A_Init; i.Table = A_arbace_set_join_fn__1726000057_A_members; jrt.RegisterGoType(A_arbace_set_join_fn__1726000057_A_class, reflect.TypeFor[A_arbace_set_join_fn__1726000057_A]()) }

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_join_fn__1726000057_fn__1726000058_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_join_fn__1726000057_fn__1726000058_A_New_O(args[0])}; return nil }

func A_arbace_set_join_fn__1726000057_fn__1726000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_join_fn__1726000057_fn__1726000058_A_fn_class)}; return nil }

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_join_fn__1726000057_fn__1726000058_A_invoke, New: A_arbace_set_join_fn__1726000057_fn__1726000058_A_new, Get: A_arbace_set_join_fn__1726000057_fn__1726000058_A_get}

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$join$fn__1726000057$fn__1726000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_join_fn__1726000057_A_class, Simple: "fn__1726000058", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000057_fn__1726000058_A", Source: "set.ae"})

func init() { i := A_arbace_set_join_fn__1726000057_fn__1726000058_A_class.Info(); i.IsInstance = A_arbace_set_join_fn__1726000057_fn__1726000058_A_InstanceOf; i.Init = A_arbace_set_join_fn__1726000057_fn__1726000058_A_Init; i.Table = A_arbace_set_join_fn__1726000057_fn__1726000058_A_members; jrt.RegisterGoType(A_arbace_set_join_fn__1726000057_fn__1726000058_A_class, reflect.TypeFor[A_arbace_set_join_fn__1726000057_fn__1726000058_A]()) }

func A_arbace_set_join_fn__1726000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_join_fn__1726000064_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_join_fn__1726000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_join_fn__1726000064_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_set_join_fn__1726000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_join_fn__1726000064_A_fn_class)}; return nil }

var A_arbace_set_join_fn__1726000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_join_fn__1726000064_A_invoke, New: A_arbace_set_join_fn__1726000064_A_new, Get: A_arbace_set_join_fn__1726000064_A_get}

var A_arbace_set_join_fn__1726000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$join$fn__1726000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_join_A_class, Simple: "fn__1726000064", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000064_A", Source: "set.ae"})

func init() { i := A_arbace_set_join_fn__1726000064_A_class.Info(); i.IsInstance = A_arbace_set_join_fn__1726000064_A_InstanceOf; i.Init = A_arbace_set_join_fn__1726000064_A_Init; i.Table = A_arbace_set_join_fn__1726000064_A_members; jrt.RegisterGoType(A_arbace_set_join_fn__1726000064_A_class, reflect.TypeFor[A_arbace_set_join_fn__1726000064_A]()) }

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_join_fn__1726000064_fn__1726000065_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_join_fn__1726000064_fn__1726000065_A_New_O(args[0])}; return nil }

func A_arbace_set_join_fn__1726000064_fn__1726000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_join_fn__1726000064_fn__1726000065_A_fn_class)}; return nil }

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_join_fn__1726000064_fn__1726000065_A_invoke, New: A_arbace_set_join_fn__1726000064_fn__1726000065_A_new, Get: A_arbace_set_join_fn__1726000064_fn__1726000065_A_get}

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$join$fn__1726000064$fn__1726000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_join_fn__1726000064_A_class, Simple: "fn__1726000065", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000064_fn__1726000065_A", Source: "set.ae"})

func init() { i := A_arbace_set_join_fn__1726000064_fn__1726000065_A_class.Info(); i.IsInstance = A_arbace_set_join_fn__1726000064_fn__1726000065_A_InstanceOf; i.Init = A_arbace_set_join_fn__1726000064_fn__1726000065_A_Init; i.Table = A_arbace_set_join_fn__1726000064_fn__1726000065_A_members; jrt.RegisterGoType(A_arbace_set_join_fn__1726000064_fn__1726000065_A_class, reflect.TypeFor[A_arbace_set_join_fn__1726000064_fn__1726000065_A]()) }

func A_arbace_set_map_invert_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_map_invert_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_map_invert_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_map_invert_A_New()}; return nil }

func A_arbace_set_map_invert_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_map_invert_A_fn_class)}; return nil }

var A_arbace_set_map_invert_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_map_invert_A_invoke, New: A_arbace_set_map_invert_A_new, Get: A_arbace_set_map_invert_A_get}

var A_arbace_set_map_invert_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$map_invert", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_A_class, Simple: "map_invert", Go: "arbace/aot_arbace_set.A_arbace_set_map_invert_A", Source: "set.ae"})

func init() { i := A_arbace_set_map_invert_A_class.Info(); i.IsInstance = A_arbace_set_map_invert_A_InstanceOf; i.Init = A_arbace_set_map_invert_A_Init; i.Table = A_arbace_set_map_invert_A_members; jrt.RegisterGoType(A_arbace_set_map_invert_A_class, reflect.TypeFor[A_arbace_set_map_invert_A]()) }

func A_arbace_set_map_invert_fn__1726000047_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_map_invert_fn__1726000047_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_set_map_invert_fn__1726000047_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_map_invert_fn__1726000047_A_New()}; return nil }

func A_arbace_set_map_invert_fn__1726000047_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_map_invert_fn__1726000047_A_fn_class)}; return nil }

var A_arbace_set_map_invert_fn__1726000047_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_map_invert_fn__1726000047_A_invoke, New: A_arbace_set_map_invert_fn__1726000047_A_new, Get: A_arbace_set_map_invert_fn__1726000047_A_get}

var A_arbace_set_map_invert_fn__1726000047_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$map_invert$fn__1726000047", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_set_map_invert_A_class, Simple: "fn__1726000047", Go: "arbace/aot_arbace_set.A_arbace_set_map_invert_fn__1726000047_A", Source: "set.ae"})

func init() { i := A_arbace_set_map_invert_fn__1726000047_A_class.Info(); i.IsInstance = A_arbace_set_map_invert_fn__1726000047_A_InstanceOf; i.Init = A_arbace_set_map_invert_fn__1726000047_A_Init; i.Table = A_arbace_set_map_invert_fn__1726000047_A_members; jrt.RegisterGoType(A_arbace_set_map_invert_fn__1726000047_A_class, reflect.TypeFor[A_arbace_set_map_invert_fn__1726000047_A]()) }

func A_arbace_set_project_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_project_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_project_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_project_A_New()}; return nil }

func A_arbace_set_project_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_project_A_fn_class)}; return nil }

var A_arbace_set_project_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_project_A_invoke, New: A_arbace_set_project_A_new, Get: A_arbace_set_project_A_get}

var A_arbace_set_project_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$project", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "project", Go: "arbace/aot_arbace_set.A_arbace_set_project_A", Source: "set.ae"})

func init() { i := A_arbace_set_project_A_class.Info(); i.IsInstance = A_arbace_set_project_A_InstanceOf; i.Init = A_arbace_set_project_A_Init; i.Table = A_arbace_set_project_A_members; jrt.RegisterGoType(A_arbace_set_project_A_class, reflect.TypeFor[A_arbace_set_project_A]()) }

func A_arbace_set_project_fn__1726000030_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_project_fn__1726000030_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_project_fn__1726000030_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_project_fn__1726000030_A_New_O(args[0])}; return nil }

func A_arbace_set_project_fn__1726000030_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_project_fn__1726000030_A_fn_class)}; return nil }

var A_arbace_set_project_fn__1726000030_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_project_fn__1726000030_A_invoke, New: A_arbace_set_project_fn__1726000030_A_new, Get: A_arbace_set_project_fn__1726000030_A_get}

var A_arbace_set_project_fn__1726000030_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$project$fn__1726000030", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_project_A_class, Simple: "fn__1726000030", Go: "arbace/aot_arbace_set.A_arbace_set_project_fn__1726000030_A", Source: "set.ae"})

func init() { i := A_arbace_set_project_fn__1726000030_A_class.Info(); i.IsInstance = A_arbace_set_project_fn__1726000030_A_InstanceOf; i.Init = A_arbace_set_project_fn__1726000030_A_Init; i.Table = A_arbace_set_project_fn__1726000030_A_members; jrt.RegisterGoType(A_arbace_set_project_fn__1726000030_A_class, reflect.TypeFor[A_arbace_set_project_fn__1726000030_A]()) }

func A_arbace_set_rename_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_rename_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_rename_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_rename_A_New()}; return nil }

func A_arbace_set_rename_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_rename_A_fn_class)}; return nil }

var A_arbace_set_rename_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_rename_A_invoke, New: A_arbace_set_rename_A_new, Get: A_arbace_set_rename_A_get}

var A_arbace_set_rename_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$rename", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "rename", Go: "arbace/aot_arbace_set.A_arbace_set_rename_A", Source: "set.ae"})

func init() { i := A_arbace_set_rename_A_class.Info(); i.IsInstance = A_arbace_set_rename_A_InstanceOf; i.Init = A_arbace_set_rename_A_Init; i.Table = A_arbace_set_rename_A_members; jrt.RegisterGoType(A_arbace_set_rename_A_class, reflect.TypeFor[A_arbace_set_rename_A]()) }

func A_arbace_set_rename_fn__1726000041_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_rename_fn__1726000041_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_rename_fn__1726000041_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_rename_fn__1726000041_A_New_O(args[0])}; return nil }

func A_arbace_set_rename_fn__1726000041_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_rename_fn__1726000041_A_fn_class)}; return nil }

var A_arbace_set_rename_fn__1726000041_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_rename_fn__1726000041_A_invoke, New: A_arbace_set_rename_fn__1726000041_A_new, Get: A_arbace_set_rename_fn__1726000041_A_get}

var A_arbace_set_rename_fn__1726000041_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$rename$fn__1726000041", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_rename_A_class, Simple: "fn__1726000041", Go: "arbace/aot_arbace_set.A_arbace_set_rename_fn__1726000041_A", Source: "set.ae"})

func init() { i := A_arbace_set_rename_fn__1726000041_A_class.Info(); i.IsInstance = A_arbace_set_rename_fn__1726000041_A_InstanceOf; i.Init = A_arbace_set_rename_fn__1726000041_A_Init; i.Table = A_arbace_set_rename_fn__1726000041_A_members; jrt.RegisterGoType(A_arbace_set_rename_fn__1726000041_A_class, reflect.TypeFor[A_arbace_set_rename_fn__1726000041_A]()) }

func A_arbace_set_rename_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_rename_keys_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_rename_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_rename_keys_A_New()}; return nil }

func A_arbace_set_rename_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_rename_keys_A_fn_class)}; return nil }

var A_arbace_set_rename_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_rename_keys_A_invoke, New: A_arbace_set_rename_keys_A_new, Get: A_arbace_set_rename_keys_A_get}

var A_arbace_set_rename_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$rename_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "rename_keys", Go: "arbace/aot_arbace_set.A_arbace_set_rename_keys_A", Source: "set.ae"})

func init() { i := A_arbace_set_rename_keys_A_class.Info(); i.IsInstance = A_arbace_set_rename_keys_A_InstanceOf; i.Init = A_arbace_set_rename_keys_A_Init; i.Table = A_arbace_set_rename_keys_A_members; jrt.RegisterGoType(A_arbace_set_rename_keys_A_class, reflect.TypeFor[A_arbace_set_rename_keys_A]()) }

func A_arbace_set_rename_keys_fn__1726000034_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_rename_keys_fn__1726000034_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_rename_keys_fn__1726000034_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_rename_keys_fn__1726000034_A_New_O(args[0])}; return nil }

func A_arbace_set_rename_keys_fn__1726000034_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_rename_keys_fn__1726000034_A_fn_class)}; return nil }

var A_arbace_set_rename_keys_fn__1726000034_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_rename_keys_fn__1726000034_A_invoke, New: A_arbace_set_rename_keys_fn__1726000034_A_new, Get: A_arbace_set_rename_keys_fn__1726000034_A_get}

var A_arbace_set_rename_keys_fn__1726000034_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$rename_keys$fn__1726000034", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_rename_keys_A_class, Simple: "fn__1726000034", Go: "arbace/aot_arbace_set.A_arbace_set_rename_keys_fn__1726000034_A", Source: "set.ae"})

func init() { i := A_arbace_set_rename_keys_fn__1726000034_A_class.Info(); i.IsInstance = A_arbace_set_rename_keys_fn__1726000034_A_InstanceOf; i.Init = A_arbace_set_rename_keys_fn__1726000034_A_Init; i.Table = A_arbace_set_rename_keys_fn__1726000034_A_members; jrt.RegisterGoType(A_arbace_set_rename_keys_fn__1726000034_A_class, reflect.TypeFor[A_arbace_set_rename_keys_fn__1726000034_A]()) }

func A_arbace_set_select_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_select_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_select_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_select_A_New()}; return nil }

func A_arbace_set_select_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_select_A_fn_class)}; return nil }

var A_arbace_set_select_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_select_A_invoke, New: A_arbace_set_select_A_new, Get: A_arbace_set_select_A_get}

var A_arbace_set_select_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$select", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "select", Go: "arbace/aot_arbace_set.A_arbace_set_select_A", Source: "set.ae"})

func init() { i := A_arbace_set_select_A_class.Info(); i.IsInstance = A_arbace_set_select_A_InstanceOf; i.Init = A_arbace_set_select_A_Init; i.Table = A_arbace_set_select_A_members; jrt.RegisterGoType(A_arbace_set_select_A_class, reflect.TypeFor[A_arbace_set_select_A]()) }

func A_arbace_set_select_fn__1726000026_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_select_fn__1726000026_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_select_fn__1726000026_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_select_fn__1726000026_A_New_O(args[0])}; return nil }

func A_arbace_set_select_fn__1726000026_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_select_fn__1726000026_A_fn_class)}; return nil }

var A_arbace_set_select_fn__1726000026_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_select_fn__1726000026_A_invoke, New: A_arbace_set_select_fn__1726000026_A_new, Get: A_arbace_set_select_fn__1726000026_A_get}

var A_arbace_set_select_fn__1726000026_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$select$fn__1726000026", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_select_A_class, Simple: "fn__1726000026", Go: "arbace/aot_arbace_set.A_arbace_set_select_fn__1726000026_A", Source: "set.ae"})

func init() { i := A_arbace_set_select_fn__1726000026_A_class.Info(); i.IsInstance = A_arbace_set_select_fn__1726000026_A_InstanceOf; i.Init = A_arbace_set_select_fn__1726000026_A_Init; i.Table = A_arbace_set_select_fn__1726000026_A_members; jrt.RegisterGoType(A_arbace_set_select_fn__1726000026_A_class, reflect.TypeFor[A_arbace_set_select_fn__1726000026_A]()) }

func A_arbace_set_subset_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_subset_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_subset_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_subset_QMARK__A_New()}; return nil }

func A_arbace_set_subset_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_subset_QMARK__A_fn_class)}; return nil }

var A_arbace_set_subset_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_subset_QMARK__A_invoke, New: A_arbace_set_subset_QMARK__A_new, Get: A_arbace_set_subset_QMARK__A_get}

var A_arbace_set_subset_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$subset_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "subset_QMARK_", Go: "arbace/aot_arbace_set.A_arbace_set_subset_QMARK__A", Source: "set.ae"})

func init() { i := A_arbace_set_subset_QMARK__A_class.Info(); i.IsInstance = A_arbace_set_subset_QMARK__A_InstanceOf; i.Init = A_arbace_set_subset_QMARK__A_Init; i.Table = A_arbace_set_subset_QMARK__A_members; jrt.RegisterGoType(A_arbace_set_subset_QMARK__A_class, reflect.TypeFor[A_arbace_set_subset_QMARK__A]()) }

func A_arbace_set_subset_QMARK__fn__1726000070_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_subset_QMARK__fn__1726000070_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_subset_QMARK__fn__1726000070_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_subset_QMARK__fn__1726000070_A_New_O(args[0])}; return nil }

func A_arbace_set_subset_QMARK__fn__1726000070_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_subset_QMARK__fn__1726000070_A_fn_class)}; return nil }

var A_arbace_set_subset_QMARK__fn__1726000070_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_subset_QMARK__fn__1726000070_A_invoke, New: A_arbace_set_subset_QMARK__fn__1726000070_A_new, Get: A_arbace_set_subset_QMARK__fn__1726000070_A_get}

var A_arbace_set_subset_QMARK__fn__1726000070_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$subset_QMARK_$fn__1726000070", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_subset_QMARK__A_class, Simple: "fn__1726000070", Go: "arbace/aot_arbace_set.A_arbace_set_subset_QMARK__fn__1726000070_A", Source: "set.ae"})

func init() { i := A_arbace_set_subset_QMARK__fn__1726000070_A_class.Info(); i.IsInstance = A_arbace_set_subset_QMARK__fn__1726000070_A_InstanceOf; i.Init = A_arbace_set_subset_QMARK__fn__1726000070_A_Init; i.Table = A_arbace_set_subset_QMARK__fn__1726000070_A_members; jrt.RegisterGoType(A_arbace_set_subset_QMARK__fn__1726000070_A_class, reflect.TypeFor[A_arbace_set_subset_QMARK__fn__1726000070_A]()) }

func A_arbace_set_superset_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_superset_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_superset_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_superset_QMARK__A_New()}; return nil }

func A_arbace_set_superset_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_superset_QMARK__A_fn_class)}; return nil }

var A_arbace_set_superset_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_superset_QMARK__A_invoke, New: A_arbace_set_superset_QMARK__A_new, Get: A_arbace_set_superset_QMARK__A_get}

var A_arbace_set_superset_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$superset_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_set_A_class, Simple: "superset_QMARK_", Go: "arbace/aot_arbace_set.A_arbace_set_superset_QMARK__A", Source: "set.ae"})

func init() { i := A_arbace_set_superset_QMARK__A_class.Info(); i.IsInstance = A_arbace_set_superset_QMARK__A_InstanceOf; i.Init = A_arbace_set_superset_QMARK__A_Init; i.Table = A_arbace_set_superset_QMARK__A_members; jrt.RegisterGoType(A_arbace_set_superset_QMARK__A_class, reflect.TypeFor[A_arbace_set_superset_QMARK__A]()) }

func A_arbace_set_superset_QMARK__fn__1726000074_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_superset_QMARK__fn__1726000074_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_set_superset_QMARK__fn__1726000074_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_superset_QMARK__fn__1726000074_A_New_O(args[0])}; return nil }

func A_arbace_set_superset_QMARK__fn__1726000074_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_superset_QMARK__fn__1726000074_A_fn_class)}; return nil }

var A_arbace_set_superset_QMARK__fn__1726000074_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_superset_QMARK__fn__1726000074_A_invoke, New: A_arbace_set_superset_QMARK__fn__1726000074_A_new, Get: A_arbace_set_superset_QMARK__fn__1726000074_A_get}

var A_arbace_set_superset_QMARK__fn__1726000074_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$superset_QMARK_$fn__1726000074", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_set_superset_QMARK__A_class, Simple: "fn__1726000074", Go: "arbace/aot_arbace_set.A_arbace_set_superset_QMARK__fn__1726000074_A", Source: "set.ae"})

func init() { i := A_arbace_set_superset_QMARK__fn__1726000074_A_class.Info(); i.IsInstance = A_arbace_set_superset_QMARK__fn__1726000074_A_InstanceOf; i.Init = A_arbace_set_superset_QMARK__fn__1726000074_A_Init; i.Table = A_arbace_set_superset_QMARK__fn__1726000074_A_members; jrt.RegisterGoType(A_arbace_set_superset_QMARK__fn__1726000074_A_class, reflect.TypeFor[A_arbace_set_superset_QMARK__fn__1726000074_A]()) }

func A_arbace_set_union_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_set_union_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3]); case 1: return this.(*A_arbace_set_union_A).Invoke_O__O(args[0]); case 2: return this.(*A_arbace_set_union_A).Invoke_O_O__O(args[0], args[1]); case 3: return this.(*A_arbace_set_union_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_set_union_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_union_A_New()}; return nil }

func A_arbace_set_union_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_set_union_A_fn_class)}; return nil }

var A_arbace_set_union_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_set_union_A_invoke, New: A_arbace_set_union_A_new, Get: A_arbace_set_union_A_get}

var A_arbace_set_union_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$union", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class, lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class, lang.Compiler_AOTF0_class}, Declaring: A_arbace_set_A_class, Simple: "union", Go: "arbace/aot_arbace_set.A_arbace_set_union_A", Source: "set.ae"})

func init() { i := A_arbace_set_union_A_class.Info(); i.IsInstance = A_arbace_set_union_A_InstanceOf; i.Init = A_arbace_set_union_A_Init; i.Table = A_arbace_set_union_A_members; jrt.RegisterGoType(A_arbace_set_union_A_class, reflect.TypeFor[A_arbace_set_union_A]()) }

func A_arbace_set__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_set__init_A_Load__O(); case 1: return A_arbace_set__init_A_Unit0__O(); case 2: return A_arbace_set__init_A_Unit1__O(); case 3: return A_arbace_set__init_A_Unit10__O(); case 4: return A_arbace_set__init_A_Unit11__O(); case 5: return A_arbace_set__init_A_Unit12__O(); case 6: return A_arbace_set__init_A_Unit13__O(); case 7: return A_arbace_set__init_A_Unit14__O(); case 8: return A_arbace_set__init_A_Unit15__O(); case 9: return A_arbace_set__init_A_Unit16__O(); case 10: return A_arbace_set__init_A_Unit17__O(); case 11: return A_arbace_set__init_A_Unit2__O(); case 12: return A_arbace_set__init_A_Unit3__O(); case 13: return A_arbace_set__init_A_Unit4__O(); case 14: return A_arbace_set__init_A_Unit5__O(); case 15: return A_arbace_set__init_A_Unit6__O(); case 16: return A_arbace_set__init_A_Unit7__O(); case 17: return A_arbace_set__init_A_Unit8__O(); case 18: return A_arbace_set__init_A_Unit9__O()}; return nil }

func A_arbace_set__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set__init_A_New()}; return nil }

var A_arbace_set__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_set__init_A_invoke, New: A_arbace_set__init_A_new}

var A_arbace_set__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_set.A_arbace_set__init_A", Source: "set.ae"})

func init() { i := A_arbace_set__init_A_class.Info(); i.IsInstance = A_arbace_set__init_A_InstanceOf; i.Init = A_arbace_set__init_A_Init; i.Table = A_arbace_set__init_A_members; jrt.RegisterGoType(A_arbace_set__init_A_class, reflect.TypeFor[A_arbace_set__init_A]()) }
