//line j2g_strings.ae:1
package aot_arbace_set

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,dockn6,authorv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn10,arbace.setm4,R1,s42,Set operations such as union/intersection.R2,s11,Rich Hickeyv11,arbace.core13,*loaded-libs*v11,arbace.core5,applyv11,arbace.core4,consv11,arbace.core7,max-keyv11,arbace.core6,removev10,arbace.set14,bubble-max-keyv11,arbace.core6,reducev11,arbace.core5,countv11,arbace.core4,intov11,arbace.core5,firstv11,arbace.core4,restv10,arbace.set12,intersectionv11,arbace.core9,contains?v11,arbace.core4,disjv10,arbace.set10,differencev11,arbace.core9,with-metav11,arbace.core3,setv11,arbace.core3,mapv11,arbace.core11,select-keysv11,arbace.core5,assocv11,arbace.core6,dissocv11,arbace.core4,keysv10,arbace.set11,rename-keysv11,arbace.core11,persistent!v11,arbace.core9,reduce-kvv11,arbace.core6,assoc!v11,arbace.core9,transientv10,arbace.set5,indexv10,arbace.set10,map-invertv11,arbace.core4,valsv11,arbace.core5,mergev11,arbace.core3,seqv11,arbace.core6,every?")

var Lit_1 *jrt.String = jrt.Intern("arbace.set$bubble_max_key$fn__1726000013")

var Lit_2 *jrt.String = jrt.Intern("arbace.set$difference$fn__1726000023")

var Lit_3 *jrt.String = jrt.Intern("arbace.set$index$fn__1726000044")

var Lit_4 *jrt.String = jrt.Intern("arbace.set$intersection$fn__1726000020")

var Lit_5 *jrt.String = jrt.Intern("arbace.set$intersection$fn__1726000018")

var Lit_6 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000064")

var Lit_7 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000057")

var Lit_8 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000057$fn__1726000058")

var Lit_9 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000064$fn__1726000065")

var Lit_10 *jrt.String = jrt.Intern("arbace.set$map_invert$fn__1726000047")

var Lit_11 *jrt.String = jrt.Intern("arbace.set$project$fn__1726000030")

var Lit_12 *jrt.String = jrt.Intern("arbace.set$rename$fn__1726000041")

var Lit_13 *jrt.String = jrt.Intern("arbace.set$rename_keys$fn__1726000034")

var Lit_14 *jrt.String = jrt.Intern("arbace.set$select$fn__1726000026")

var Lit_15 *jrt.String = jrt.Intern("arbace.set$subset_QMARK_$fn__1726000070")

var Lit_16 *jrt.String = jrt.Intern("arbace.set$superset_QMARK_$fn__1726000074")

var Lit_17 *jrt.String = jrt.Intern("kn3,dockn6,authoryn11,arbace.corekn7,privatekn8,arglistsyn1,kyn4,collkn4,linekn6,columnkn4,fileyn2,s1yn2,s2yn1,&yn4,setskn5,addedyn4,predyn4,xsetyn4,xrelyn2,ksyn3,mapyn4,kmapyn1,myn4,yrelyn2,kmyn4,set1yn4,set2kn3,tagv11,arbace.core5,in-nsMyn10,arbace.setm4,R0,s42,Set operations such as union/intersection.R1,s11,Rich Hickeym4,R0,s42,Set operations such as union/intersection.R1,s11,Rich HickeyR2,v10,arbace.set14,bubble-max-keym12,R3,TR4,L1,V2,R5,R6,R0,s97,Move a maximal element of coll according to fn k (which returns a\n  number) to the front of coll.R7,i13,R8,i1,R9,s13,arbace/set.aev10,arbace.set5,unionm12,R4,L4,V0,V1,R10,V2,R10,R11,V4,R10,R11,R12,R13,R0,s48,Return a set that is the union of the input setsR14,s3,1.0R7,i20,R8,i1,R9,s13,arbace/set.aev10,arbace.set12,intersectionm12,R4,L3,V1,R10,V2,R10,R11,V4,R10,R11,R12,R13,R0,s55,Return a set that is the intersection of the input setsR14,s3,1.0R7,i33,R8,i1,R9,s13,arbace/set.aev10,arbace.set10,differencem12,R4,L3,V1,R10,V2,R10,R11,V4,R10,R11,R12,R13,R0,s73,Return a set that is the first set without elements of the remaining setsR14,s3,1.0R7,i49,R8,i1,R9,s13,arbace/set.aev10,arbace.set6,selectm12,R4,L1,V2,R15,R16,R0,s52,Returns a set of the elements for which pred is trueR14,s3,1.0R7,i64,R8,i1,R9,s13,arbace/set.aev10,arbace.set7,projectm12,R4,L1,V2,R17,R18,R0,s62,Returns a rel of the elements of xrel with only the keys in ksR14,s3,1.0R7,i71,R8,i1,R9,s13,arbace/set.aev10,arbace.set11,rename-keysm12,R4,L1,V2,R19,R20,R0,s65,Returns the map with the keys in kmap renamed to the vals in kmapR14,s3,1.0R7,i77,R8,i1,R9,s13,arbace/set.aev10,arbace.set6,renamem12,R4,L1,V2,R17,R20,R0,s83,Returns a rel of the maps in xrel with the keys in kmap renamed to the vals in kmapR14,s3,1.0R7,i88,R8,i1,R9,s13,arbace/set.aev10,arbace.set5,indexm12,R4,L1,V2,R17,R18,R0,s129,Returns a map of the distinct values of ks in the xrel mapped to a\n  set of the maps in xrel with the corresponding values of ks.R14,s3,1.0R7,i94,R8,i1,R9,s13,arbace/set.aev10,arbace.set10,map-invertm12,R4,L1,V1,R21,R0,s49,Returns the map with the vals mapped to the keys.R14,s3,1.0R7,i105,R8,i1,R9,s13,arbace/set.aev10,arbace.set4,joinm12,R4,L2,V2,R17,R22,V3,R17,R22,R23,R0,s141,When passed 2 rels, returns the rel corresponding to the natural\n  join. When passed an additional keymap, joins on the corresponding\n  keys.R14,s3,1.0R7,i114,R8,i1,R9,s13,arbace/set.aev10,arbace.set7,subset?m14,R4,L1,V2,R24,R25,R0,s25,Is set1 a subset of set2?R14,s3,1.2R26,C17,java.lang.BooleanR7,i145,R8,i1,R9,s13,arbace/set.aev10,arbace.set9,superset?m14,R4,L1,V2,R24,R25,R0,s27,Is set1 a superset of set2?R14,s3,1.2R26,C17,java.lang.BooleanR7,i153,R8,i1,R9,s13,arbace/set.ae")

var Lit_18 *jrt.String = jrt.Intern("arbace.set$eval1726000004$loading__1927001464__auto____1726000005")

var Lit_19 *jrt.String = jrt.Intern("arbace.set$eval1726000008$fn__1726000009")

var Lit_20 *jrt.String = jrt.Intern("arbace.set$bubble_max_key")

var Lit_21 *jrt.String = jrt.Intern("arbace.set$union")

var Lit_22 *jrt.String = jrt.Intern("arbace.set$intersection")

var Lit_23 *jrt.String = jrt.Intern("arbace.set$difference")

var Lit_24 *jrt.String = jrt.Intern("arbace.set$select")

var Lit_25 *jrt.String = jrt.Intern("arbace.set$project")

var Lit_26 *jrt.String = jrt.Intern("arbace.set$rename_keys")

var Lit_27 *jrt.String = jrt.Intern("arbace.set$rename")

var Lit_28 *jrt.String = jrt.Intern("arbace.set$index")

var Lit_29 *jrt.String = jrt.Intern("arbace.set$map_invert")

var Lit_30 *jrt.String = jrt.Intern("arbace.set$join")

var Lit_31 *jrt.String = jrt.Intern("arbace.set$subset_QMARK_")

var Lit_32 *jrt.String = jrt.Intern("arbace.set$superset_QMARK_")
