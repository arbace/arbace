//line a2g_strings.ae:1
package aot_arbace_set

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.set")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("Set operations such as union/intersection.")

var Lit_8 *jrt.String = jrt.Intern("author")

var Lit_9 *jrt.String = jrt.Intern("Rich Hickey")

var Lit_10 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_11 *jrt.String = jrt.Intern("apply")

var Lit_12 *jrt.String = jrt.Intern("cons")

var Lit_13 *jrt.String = jrt.Intern("max-key")

var Lit_14 *jrt.String = jrt.Intern("remove")

var Lit_15 *jrt.String = jrt.Intern("bubble-max-key")

var Lit_16 *jrt.String = jrt.Intern("reduce")

var Lit_17 *jrt.String = jrt.Intern("count")

var Lit_18 *jrt.String = jrt.Intern("into")

var Lit_19 *jrt.String = jrt.Intern("first")

var Lit_20 *jrt.String = jrt.Intern("rest")

var Lit_21 *jrt.String = jrt.Intern("intersection")

var Lit_22 *jrt.String = jrt.Intern("contains?")

var Lit_23 *jrt.String = jrt.Intern("disj")

var Lit_24 *jrt.String = jrt.Intern("difference")

var Lit_25 *jrt.String = jrt.Intern("with-meta")

var Lit_26 *jrt.String = jrt.Intern("set")

var Lit_27 *jrt.String = jrt.Intern("map")

var Lit_28 *jrt.String = jrt.Intern("select-keys")

var Lit_29 *jrt.String = jrt.Intern("assoc")

var Lit_30 *jrt.String = jrt.Intern("dissoc")

var Lit_31 *jrt.String = jrt.Intern("keys")

var Lit_32 *jrt.String = jrt.Intern("rename-keys")

var Lit_33 *jrt.String = jrt.Intern("persistent!")

var Lit_34 *jrt.String = jrt.Intern("reduce-kv")

var Lit_35 *jrt.String = jrt.Intern("assoc!")

var Lit_36 *jrt.String = jrt.Intern("transient")

var Lit_37 *jrt.String = jrt.Intern("index")

var Lit_38 *jrt.String = jrt.Intern("map-invert")

var Lit_39 *jrt.String = jrt.Intern("vals")

var Lit_40 *jrt.String = jrt.Intern("merge")

var Lit_41 *jrt.String = jrt.Intern("seq")

var Lit_42 *jrt.String = jrt.Intern("every?")

var Lit_43 *jrt.String = jrt.Intern("arbace.set$bubble_max_key")

var Lit_44 *jrt.String = jrt.Intern("arbace.set$bubble_max_key$fn__1726000013")

var Lit_45 *jrt.String = jrt.Intern("arbace.set$difference")

var Lit_46 *jrt.String = jrt.Intern("arbace.set$difference$fn__1726000023")

var Lit_47 *jrt.String = jrt.Intern("arbace.set$eval1726000004$loading__1927001464__auto____1726000005")

var Lit_48 *jrt.String = jrt.Intern("arbace.set$eval1726000008$fn__1726000009")

var Lit_49 *jrt.String = jrt.Intern("arbace.set$index")

var Lit_50 *jrt.String = jrt.Intern("arbace.set$index$fn__1726000044")

var Lit_51 *jrt.String = jrt.Intern("arbace.set$intersection")

var Lit_52 *jrt.String = jrt.Intern("arbace.set$intersection$fn__1726000018")

var Lit_53 *jrt.String = jrt.Intern("arbace.set$intersection$fn__1726000020")

var Lit_54 *jrt.String = jrt.Intern("arbace.set$join")

var Lit_55 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000057")

var Lit_56 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000057$fn__1726000058")

var Lit_57 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000064")

var Lit_58 *jrt.String = jrt.Intern("arbace.set$join$fn__1726000064$fn__1726000065")

var Lit_59 *jrt.String = jrt.Intern("arbace.set$map_invert")

var Lit_60 *jrt.String = jrt.Intern("arbace.set$map_invert$fn__1726000047")

var Lit_61 *jrt.String = jrt.Intern("arbace.set$project")

var Lit_62 *jrt.String = jrt.Intern("arbace.set$project$fn__1726000030")

var Lit_63 *jrt.String = jrt.Intern("arbace.set$rename")

var Lit_64 *jrt.String = jrt.Intern("arbace.set$rename$fn__1726000041")

var Lit_65 *jrt.String = jrt.Intern("arbace.set$rename_keys")

var Lit_66 *jrt.String = jrt.Intern("arbace.set$rename_keys$fn__1726000034")

var Lit_67 *jrt.String = jrt.Intern("arbace.set$select")

var Lit_68 *jrt.String = jrt.Intern("arbace.set$select$fn__1726000026")

var Lit_69 *jrt.String = jrt.Intern("arbace.set$subset_QMARK_")

var Lit_70 *jrt.String = jrt.Intern("arbace.set$subset_QMARK_$fn__1726000070")

var Lit_71 *jrt.String = jrt.Intern("arbace.set$superset_QMARK_")

var Lit_72 *jrt.String = jrt.Intern("arbace.set$superset_QMARK_$fn__1726000074")

var Lit_73 *jrt.String = jrt.Intern("arbace.set$union")

var Lit_74 *jrt.String = jrt.Intern("in-ns")

var Lit_75 *jrt.String = jrt.Intern("private")

var Lit_76 *jrt.String = jrt.Intern("arglists")

var Lit_77 *jrt.String = jrt.Intern("k")

var Lit_78 *jrt.String = jrt.Intern("coll")

var Lit_79 *jrt.String = jrt.Intern("Move a maximal element of coll according to fn k (which returns a\n  number) to the front of coll.")

var Lit_80 *jrt.String = jrt.Intern("line")

var Lit_81 *jrt.String = jrt.Intern("column")

var Lit_82 *jrt.String = jrt.Intern("file")

var Lit_83 *jrt.String = jrt.Intern("arbace/set.ae")

var Lit_84 *jrt.String = jrt.Intern("union")

var Lit_85 *jrt.String = jrt.Intern("s1")

var Lit_86 *jrt.String = jrt.Intern("s2")

var Lit_87 *jrt.String = jrt.Intern("&")

var Lit_88 *jrt.String = jrt.Intern("sets")

var Lit_89 *jrt.String = jrt.Intern("Return a set that is the union of the input sets")

var Lit_90 *jrt.String = jrt.Intern("added")

var Lit_91 *jrt.String = jrt.Intern("1.0")

var Lit_92 *jrt.String = jrt.Intern("Return a set that is the intersection of the input sets")

var Lit_93 *jrt.String = jrt.Intern("Return a set that is the first set without elements of the remaining sets")

var Lit_94 *jrt.String = jrt.Intern("select")

var Lit_95 *jrt.String = jrt.Intern("pred")

var Lit_96 *jrt.String = jrt.Intern("xset")

var Lit_97 *jrt.String = jrt.Intern("Returns a set of the elements for which pred is true")

var Lit_98 *jrt.String = jrt.Intern("project")

var Lit_99 *jrt.String = jrt.Intern("xrel")

var Lit_100 *jrt.String = jrt.Intern("ks")

var Lit_101 *jrt.String = jrt.Intern("Returns a rel of the elements of xrel with only the keys in ks")

var Lit_102 *jrt.String = jrt.Intern("kmap")

var Lit_103 *jrt.String = jrt.Intern("Returns the map with the keys in kmap renamed to the vals in kmap")

var Lit_104 *jrt.String = jrt.Intern("rename")

var Lit_105 *jrt.String = jrt.Intern("Returns a rel of the maps in xrel with the keys in kmap renamed to the vals in kmap")

var Lit_106 *jrt.String = jrt.Intern("Returns a map of the distinct values of ks in the xrel mapped to a\n  set of the maps in xrel with the corresponding values of ks.")

var Lit_107 *jrt.String = jrt.Intern("m")

var Lit_108 *jrt.String = jrt.Intern("Returns the map with the vals mapped to the keys.")

var Lit_109 *jrt.String = jrt.Intern("join")

var Lit_110 *jrt.String = jrt.Intern("yrel")

var Lit_111 *jrt.String = jrt.Intern("km")

var Lit_112 *jrt.String = jrt.Intern("When passed 2 rels, returns the rel corresponding to the natural\n  join. When passed an additional keymap, joins on the corresponding\n  keys.")

var Lit_113 *jrt.String = jrt.Intern("subset?")

var Lit_114 *jrt.String = jrt.Intern("set1")

var Lit_115 *jrt.String = jrt.Intern("set2")

var Lit_116 *jrt.String = jrt.Intern("Is set1 a subset of set2?")

var Lit_117 *jrt.String = jrt.Intern("1.2")

var Lit_118 *jrt.String = jrt.Intern("tag")

var Lit_119 *jrt.String = jrt.Intern("java.lang.Boolean")

var Lit_120 *jrt.String = jrt.Intern("superset?")

var Lit_121 *jrt.String = jrt.Intern("Is set1 a superset of set2?")
