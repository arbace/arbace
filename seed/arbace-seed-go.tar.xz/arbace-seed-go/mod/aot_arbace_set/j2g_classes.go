//line j2g_classes.ae:1
package aot_arbace_set

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var j2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_set_bubble_max_key_A_class, Name: "arbace.set$bubble_max_key", Modifiers: 25, Simple: "bubble_max_key", Go: "arbace/aot_arbace_set.A_arbace_set_bubble_max_key_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_bubble_max_key_fn__1726000013_A_class, Name: "arbace.set$bubble_max_key$fn__1726000013", Modifiers: 25, Simple: "fn__1726000013", Go: "arbace/aot_arbace_set.A_arbace_set_bubble_max_key_fn__1726000013_A", Source: "set.ae", Declaring: &A_arbace_set_bubble_max_key_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_difference_A_class, Name: "arbace.set$difference", Modifiers: 25, Simple: "difference", Go: "arbace/aot_arbace_set.A_arbace_set_difference_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_difference_fn__1726000023_A_class, Name: "arbace.set$difference$fn__1726000023", Modifiers: 25, Simple: "fn__1726000023", Go: "arbace/aot_arbace_set.A_arbace_set_difference_fn__1726000023_A", Source: "set.ae", Declaring: &A_arbace_set_difference_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class, Name: "arbace.set$eval1726000004$loading__1927001464__auto____1726000005", Modifiers: 25, Simple: "loading__1927001464__auto____1726000005", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A", Source: "set.ae", Declaring: &A_arbace_set_eval1726000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_set_eval1726000008_fn__1726000009_A_class, Name: "arbace.set$eval1726000008$fn__1726000009", Modifiers: 25, Simple: "fn__1726000009", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000008_fn__1726000009_A", Source: "set.ae", Declaring: &A_arbace_set_eval1726000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_set_index_A_class, Name: "arbace.set$index", Modifiers: 25, Simple: "index", Go: "arbace/aot_arbace_set.A_arbace_set_index_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_index_fn__1726000044_A_class, Name: "arbace.set$index$fn__1726000044", Modifiers: 25, Simple: "fn__1726000044", Go: "arbace/aot_arbace_set.A_arbace_set_index_fn__1726000044_A", Source: "set.ae", Declaring: &A_arbace_set_index_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_intersection_A_class, Name: "arbace.set$intersection", Modifiers: 25, Simple: "intersection", Go: "arbace/aot_arbace_set.A_arbace_set_intersection_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_intersection_fn__1726000018_A_class, Name: "arbace.set$intersection$fn__1726000018", Modifiers: 25, Simple: "fn__1726000018", Go: "arbace/aot_arbace_set.A_arbace_set_intersection_fn__1726000018_A", Source: "set.ae", Declaring: &A_arbace_set_intersection_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_intersection_fn__1726000020_A_class, Name: "arbace.set$intersection$fn__1726000020", Modifiers: 25, Simple: "fn__1726000020", Go: "arbace/aot_arbace_set.A_arbace_set_intersection_fn__1726000020_A", Source: "set.ae", Declaring: &A_arbace_set_intersection_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_join_A_class, Name: "arbace.set$join", Modifiers: 25, Simple: "join", Go: "arbace/aot_arbace_set.A_arbace_set_join_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class, &lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_join_fn__1726000057_A_class, Name: "arbace.set$join$fn__1726000057", Modifiers: 25, Simple: "fn__1726000057", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000057_A", Source: "set.ae", Declaring: &A_arbace_set_join_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_join_fn__1726000057_fn__1726000058_A_class, Name: "arbace.set$join$fn__1726000057$fn__1726000058", Modifiers: 25, Simple: "fn__1726000058", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000057_fn__1726000058_A", Source: "set.ae", Declaring: &A_arbace_set_join_fn__1726000057_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_join_fn__1726000064_A_class, Name: "arbace.set$join$fn__1726000064", Modifiers: 25, Simple: "fn__1726000064", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000064_A", Source: "set.ae", Declaring: &A_arbace_set_join_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_join_fn__1726000064_fn__1726000065_A_class, Name: "arbace.set$join$fn__1726000064$fn__1726000065", Modifiers: 25, Simple: "fn__1726000065", Go: "arbace/aot_arbace_set.A_arbace_set_join_fn__1726000064_fn__1726000065_A", Source: "set.ae", Declaring: &A_arbace_set_join_fn__1726000064_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_map_invert_A_class, Name: "arbace.set$map_invert", Modifiers: 25, Simple: "map_invert", Go: "arbace/aot_arbace_set.A_arbace_set_map_invert_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_map_invert_fn__1726000047_A_class, Name: "arbace.set$map_invert$fn__1726000047", Modifiers: 25, Simple: "fn__1726000047", Go: "arbace/aot_arbace_set.A_arbace_set_map_invert_fn__1726000047_A", Source: "set.ae", Declaring: &A_arbace_set_map_invert_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF3_class}}, jrt.CodeDecl{Out: &A_arbace_set_project_A_class, Name: "arbace.set$project", Modifiers: 25, Simple: "project", Go: "arbace/aot_arbace_set.A_arbace_set_project_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_project_fn__1726000030_A_class, Name: "arbace.set$project$fn__1726000030", Modifiers: 25, Simple: "fn__1726000030", Go: "arbace/aot_arbace_set.A_arbace_set_project_fn__1726000030_A", Source: "set.ae", Declaring: &A_arbace_set_project_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_rename_A_class, Name: "arbace.set$rename", Modifiers: 25, Simple: "rename", Go: "arbace/aot_arbace_set.A_arbace_set_rename_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_rename_fn__1726000041_A_class, Name: "arbace.set$rename$fn__1726000041", Modifiers: 25, Simple: "fn__1726000041", Go: "arbace/aot_arbace_set.A_arbace_set_rename_fn__1726000041_A", Source: "set.ae", Declaring: &A_arbace_set_rename_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_rename_keys_A_class, Name: "arbace.set$rename_keys", Modifiers: 25, Simple: "rename_keys", Go: "arbace/aot_arbace_set.A_arbace_set_rename_keys_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_rename_keys_fn__1726000034_A_class, Name: "arbace.set$rename_keys$fn__1726000034", Modifiers: 25, Simple: "fn__1726000034", Go: "arbace/aot_arbace_set.A_arbace_set_rename_keys_fn__1726000034_A", Source: "set.ae", Declaring: &A_arbace_set_rename_keys_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_select_A_class, Name: "arbace.set$select", Modifiers: 25, Simple: "select", Go: "arbace/aot_arbace_set.A_arbace_set_select_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_select_fn__1726000026_A_class, Name: "arbace.set$select$fn__1726000026", Modifiers: 25, Simple: "fn__1726000026", Go: "arbace/aot_arbace_set.A_arbace_set_select_fn__1726000026_A", Source: "set.ae", Declaring: &A_arbace_set_select_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_subset_QMARK__A_class, Name: "arbace.set$subset_QMARK_", Modifiers: 25, Simple: "subset_QMARK_", Go: "arbace/aot_arbace_set.A_arbace_set_subset_QMARK__A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_subset_QMARK__fn__1726000070_A_class, Name: "arbace.set$subset_QMARK_$fn__1726000070", Modifiers: 25, Simple: "fn__1726000070", Go: "arbace/aot_arbace_set.A_arbace_set_subset_QMARK__fn__1726000070_A", Source: "set.ae", Declaring: &A_arbace_set_subset_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_superset_QMARK__A_class, Name: "arbace.set$superset_QMARK_", Modifiers: 25, Simple: "superset_QMARK_", Go: "arbace/aot_arbace_set.A_arbace_set_superset_QMARK__A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF2_class}}, jrt.CodeDecl{Out: &A_arbace_set_superset_QMARK__fn__1726000074_A_class, Name: "arbace.set$superset_QMARK_$fn__1726000074", Modifiers: 25, Simple: "fn__1726000074", Go: "arbace/aot_arbace_set.A_arbace_set_superset_QMARK__fn__1726000074_A", Source: "set.ae", Declaring: &A_arbace_set_superset_QMARK__A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_set_union_A_class, Name: "arbace.set$union", Modifiers: 25, Simple: "union", Go: "arbace/aot_arbace_set.A_arbace_set_union_A", Source: "set.ae", Declaring: &A_arbace_set_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR2_class, &lang.Compiler_AOTF2_class, &lang.Compiler_AOTF1_class, &lang.Compiler_AOTF0_class}}}

var j2gCodeDefined bool = jrt.DefineCode(j2gCode)

func init() { jrt.LinkCode(j2gCode) }

func A_arbace_set_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_A_New()}; return nil }

var A_arbace_set_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_set_A_new}

var A_arbace_set_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_set.A_arbace_set_A"})

func init() { i := A_arbace_set_A_class.Info(); i.IsInstance = A_arbace_set_A_InstanceOf; i.Init = A_arbace_set_A_Init; i.Table = A_arbace_set_A_members }

var A_arbace_set_bubble_max_key_A_class *jrt.Class

var A_arbace_set_bubble_max_key_fn__1726000013_A_class *jrt.Class

var A_arbace_set_difference_A_class *jrt.Class

var A_arbace_set_difference_fn__1726000023_A_class *jrt.Class

func A_arbace_set_eval1726000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_eval1726000004_A_New()}; return nil }

var A_arbace_set_eval1726000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_set_eval1726000004_A_new}

var A_arbace_set_eval1726000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$eval1726000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_set_A_class, Simple: "eval1726000004", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000004_A"})

func init() { i := A_arbace_set_eval1726000004_A_class.Info(); i.IsInstance = A_arbace_set_eval1726000004_A_InstanceOf; i.Table = A_arbace_set_eval1726000004_A_members }

var A_arbace_set_eval1726000004_loading__1927001464__auto____1726000005_A_class *jrt.Class

func A_arbace_set_eval1726000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set_eval1726000008_A_New()}; return nil }

var A_arbace_set_eval1726000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_set_eval1726000008_A_new}

var A_arbace_set_eval1726000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set$eval1726000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_set_A_class, Simple: "eval1726000008", Go: "arbace/aot_arbace_set.A_arbace_set_eval1726000008_A"})

func init() { i := A_arbace_set_eval1726000008_A_class.Info(); i.IsInstance = A_arbace_set_eval1726000008_A_InstanceOf; i.Table = A_arbace_set_eval1726000008_A_members }

var A_arbace_set_eval1726000008_fn__1726000009_A_class *jrt.Class

var A_arbace_set_index_A_class *jrt.Class

var A_arbace_set_index_fn__1726000044_A_class *jrt.Class

var A_arbace_set_intersection_A_class *jrt.Class

var A_arbace_set_intersection_fn__1726000018_A_class *jrt.Class

var A_arbace_set_intersection_fn__1726000020_A_class *jrt.Class

var A_arbace_set_join_A_class *jrt.Class

var A_arbace_set_join_fn__1726000057_A_class *jrt.Class

var A_arbace_set_join_fn__1726000057_fn__1726000058_A_class *jrt.Class

var A_arbace_set_join_fn__1726000064_A_class *jrt.Class

var A_arbace_set_join_fn__1726000064_fn__1726000065_A_class *jrt.Class

var A_arbace_set_map_invert_A_class *jrt.Class

var A_arbace_set_map_invert_fn__1726000047_A_class *jrt.Class

var A_arbace_set_project_A_class *jrt.Class

var A_arbace_set_project_fn__1726000030_A_class *jrt.Class

var A_arbace_set_rename_A_class *jrt.Class

var A_arbace_set_rename_fn__1726000041_A_class *jrt.Class

var A_arbace_set_rename_keys_A_class *jrt.Class

var A_arbace_set_rename_keys_fn__1726000034_A_class *jrt.Class

var A_arbace_set_select_A_class *jrt.Class

var A_arbace_set_select_fn__1726000026_A_class *jrt.Class

var A_arbace_set_subset_QMARK__A_class *jrt.Class

var A_arbace_set_subset_QMARK__fn__1726000070_A_class *jrt.Class

var A_arbace_set_superset_QMARK__A_class *jrt.Class

var A_arbace_set_superset_QMARK__fn__1726000074_A_class *jrt.Class

var A_arbace_set_union_A_class *jrt.Class

func A_arbace_set__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_set__init_A_Load__O()}; return nil }

func A_arbace_set__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_set__init_A_New()}; return nil }

var A_arbace_set__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_set__init_A_invoke, New: A_arbace_set__init_A_new}

var A_arbace_set__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.set__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_set.A_arbace_set__init_A", Source: "set.ae"})

func init() { i := A_arbace_set__init_A_class.Info(); i.IsInstance = A_arbace_set__init_A_InstanceOf; i.Init = A_arbace_set__init_A_Init; i.Table = A_arbace_set__init_A_members }
