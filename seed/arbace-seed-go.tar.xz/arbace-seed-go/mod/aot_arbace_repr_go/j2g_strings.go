//line j2g_strings.ae:1
package aot_arbace_repr_go

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn22,arbace.repr.go.convertkn2,asyn2,cvyn21,arbace.repr.go.layoutyn6,layoutyn18,arbace.repr.go.lityn3,lityn19,arbace.repr.go.readyn2,rdyn20,arbace.repr.go.typesyn2,tyyn13,arbace.stringyn3,strkn3,dockn5,valueks22,arbace.repr.go.convert3,rawks22,arbace.repr.go.convert5,derefkn4,elseyn5,in-nsyn5,quoteys11,arbace.core5,derefkn4,linekn6,columnkn5,linesks22,arbace.repr.go.convert1,lkn4,datakn4,metakn3,dirys20,arbace.repr.go.print13,print-packagekn4,namekn7,missingkn5,fileskn4,keyskn6,differkn8,dir-testkn7,packagekn2,nskn10,namespaceskn4,testkn8,packageskn7,src-dirkn8,text-dirkn4,stemkn5,formskn8,commentskn4,pathkn4,failkn5,tracekn3,outkn9,positionskn6,gorootkn5,checkkn5,printkn4,textkn3,rawkn3,badkn3,astkn5,byteskn2,mskn7,read-mskn5,statskn6,layoutkn10,dump-nodeskn8,unplacedkn4,openkn5,nodeskn5,noteskn10,text-knownkn4,jobskn5,quietkn6,reportkn12,report-extrakn5,dumpskn6,failedkn7,secondskn4,fullyn20,arbace.repr.go.printkn3,tagv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn14,arbace.repr.gom2,R14,s916,Command line of repr/go's reader, Go into Go forms (doc/go/CONVERTER-NOTES.md).\n\n  bin/repr-go read ... runs\n    -m arbace.repr.go read [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/repr-go/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given, and so does a package of a directory test (a dump with\n  :dir-test, key DIR.dir/STEM: go.test.<DIR>_dir.<STEM>). Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.v18,arbace.repr.go.lit4,lit?R15,v11,arbace.core4,seq?R16,v11,arbace.core4,listR17,v11,arbace.core5,applyv11,arbace.core3,mapv14,arbace.repr.go7,data-ofv11,arbace.core7,vector?v11,arbace.core4,mapvv11,arbace.core4,map?v11,arbace.core4,intoR18,R19,R20,v11,arbace.core6,secondR21,v21,arbace.repr.go.layout11,public-metav11,arbace.core6,dissocR22,R23,v11,arbace.core4,not=v14,arbace.repr.go13,expected-metav14,arbace.repr.go9,read-metav11,arbace.core3,seqv21,arbace.repr.go.layout6,*mode*R24,v11,arbace.core3,notR25,v14,arbace.repr.go4,diffl1,v11,arbace.core5,firstv11,arbace.core4,keepv11,arbace.core8,identityv11,arbace.core11,map-indexedv11,arbace.core6,vectorR26,R27,v11,arbace.core4,readv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core11,*read-eval*v14,arbace.repr.go8,read-allv11,arbace.core4,somev11,arbace.core6,pr-strv11,arbace.core5,rangeC16,java.lang.Stringv13,arbace.string7,replacep6,\\.edn$p5,\\.go$v11,arbace.core6,symbolv13,arbace.string4,joinv14,arbace.repr.go9,munge-segv13,arbace.string5,splitp1,/v11,arbace.core3,strp2,\\.v11,arbace.core4,spitR28,v13,arbace.string12,starts-with?v11,arbace.core4,subsv11,arbace.core17,requiring-resolveR29,v11,arbace.core5,classp3,/+$v11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferR30,v11,arbace.core12,chunk-appendv14,arbace.repr.go8,text-keyR31,v14,arbace.repr.go16,first-differencev11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restR32,R33,R34,v11,arbace.core3,vecv11,arbace.core6,filterR35,R36,v11,arbace.core5,some?R37,v14,arbace.repr.go10,program-nsv20,arbace.repr.go.types10,ns-name-ofR38,R39,p5,\\.go$p1,/R40,R41,R42,v11,arbace.core4,lastv14,arbace.repr.go6,ns-dirp1,/v21,arbace.repr.go.layout13,write-packageR43,v21,arbace.repr.go.layout10,write-fileR44,R45,v19,arbace.repr.go.read9,read-dumpv14,arbace.repr.go12,convert-dataR46,R47,R48,v11,arbace.core4,takel12,v11,arbace.core4,nextv11,arbace.core8,to-arrayR49,R50,R51,R52,R53,R54,R55,v14,arbace.repr.go12,dump-contextv22,arbace.repr.go.convert15,convert-packagep1,/v11,arbace.core4,atomv14,arbace.repr.go10,check-textv21,arbace.repr.go.layout7,preparev11,arbace.core5,assocR56,v14,arbace.repr.go15,print-candidatev14,arbace.repr.go13,candidate-dirv14,arbace.repr.go10,text-levelv11,arbace.core11,frequenciesv11,arbace.core6,mapcatv11,arbace.core4,compv19,arbace.repr.go.read5,nodesR57,R58,R59,R60,R61,R62,R63,R64,v11,arbace.core6,concatR65,v22,arbace.repr.go.convert11,open-countsv21,arbace.repr.go.layout7,*stats*v14,arbace.repr.go9,spit-filev11,arbace.core5,swap!v11,arbace.core1,+v11,arbace.core7,sort-byv13,arbace.string10,ends-with?v11,arbace.core8,file-seqv11,arbace.core10,merge-withv11,arbace.core6,removev14,arbace.repr.go12,merge-countsv11,arbace.core6,get-inV2,R61,R66,V2,R61,R67,R68,v11,arbace.core11,read-stringv11,arbace.core5,slurpv11,arbace.core9,contains?v11,arbace.core3,setv11,arbace.core4,sortv11,arbace.core4,keysl0,v11,arbace.core7,printlnv11,arbace.core10,sorted-mapv11,arbace.core6,formatv11,arbace.core6,reduceR69,R70,v11,arbace.core4,nameR71,v11,arbace.core5,mergeR72,R73,R74,R75,R66,R67,m8,R49,s18,.tmp/repr-go/formsR50,R24,R69,l1,R52,TR76,v11,arbace.core10,parse-longv14,arbace.repr.go10,dump-filesR77,v14,arbace.repr.go12,convert-dumpm2,R78,C29,java.util.concurrent.Callablev14,arbace.repr.go6,reportv11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("read")

var Lit_2 *jrt.String = jrt.Intern("usage: read [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check] [--report FILE] DUMP|DIR...")

var Lit_3 *jrt.String = jrt.Intern("arbace.repr.go$_main$fn__590000277")

var Lit_4 *jrt.String = jrt.Intern("arbace.repr.go$_main$fn__590000284")

var Lit_5 *jrt.String = jrt.Intern("arbace.repr.go$_main$fn__590000291")

var Lit_6 *jrt.String = jrt.Intern("--print")

var Lit_7 *jrt.String = jrt.Intern("--full")

var Lit_8 *jrt.String = jrt.Intern("--text-known")

var Lit_9 *jrt.String = jrt.Intern("--goroot")

var Lit_10 *jrt.String = jrt.Intern("--quiet")

var Lit_11 *jrt.String = jrt.Intern("--no-check")

var Lit_12 *jrt.String = jrt.Intern("--out")

var Lit_13 *jrt.String = jrt.Intern("--text")

var Lit_14 *jrt.String = jrt.Intern("--report")

var Lit_15 *jrt.String = jrt.Intern("--jobs")

var Lit_16 *jrt.String = jrt.Intern("arbace.repr.go$_main$fn__590000284$fn__590000288")

var Lit_17 *jrt.String = jrt.Intern("$GOROOT/")

var Lit_18 *jrt.String = jrt.Intern("/")

var Lit_19 *jrt.String = jrt.Intern("/test/")

var Lit_20 *jrt.String = jrt.Intern("read ")

var Lit_21 *jrt.String = jrt.Intern(" forms, wrote ")

var Lit_22 *jrt.String = jrt.Intern("arbace.repr.go$check_text$fn__590000036")

var Lit_23 *jrt.String = jrt.Intern("read error: ")

var Lit_24 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000119")

var Lit_25 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000131")

var Lit_26 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000133")

var Lit_27 *jrt.String = jrt.Intern("getBytes")

var Lit_28 *jrt.String = jrt.Intern("UTF-8")

var Lit_29 *jrt.String = jrt.Intern(".ae")

var Lit_30 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$iter__590000140__590000146")

var Lit_31 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000156")

var Lit_32 *jrt.String = jrt.Intern("package")

var Lit_33 *jrt.String = jrt.Intern("print")

var Lit_34 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000119$iter__590000120__590000124")

var Lit_35 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000119$iter__590000120__590000124$fn__590000125")

var Lit_36 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$fn__590000119$iter__590000120__590000124$fn__590000125$fn__590000126")

var Lit_37 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$iter__590000140__590000146$fn__590000147")

var Lit_38 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$iter__590000140__590000146$fn__590000147$iter__590000142__590000148")

var Lit_39 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$iter__590000140__590000146$fn__590000147$iter__590000142__590000148$fn__590000149")

var Lit_40 *jrt.String = jrt.Intern("arbace.repr.go$convert_data$iter__590000140__590000146$fn__590000147$iter__590000142__590000148$fn__590000149$fn__590000150")

var Lit_41 *jrt.String = jrt.Intern(": ")

var Lit_42 *jrt.String = jrt.Intern("arbace.repr.go$data_of$fn__590000013")

var Lit_43 *jrt.String = jrt.Intern("arbace.repr.go$diff$fn__590000028")

var Lit_44 *jrt.String = jrt.Intern("command-line-arguments")

var Lit_45 *jrt.String = jrt.Intern(".dir")

var Lit_46 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065")

var Lit_47 *jrt.String = jrt.Intern("$GOROOT")

var Lit_48 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066")

var Lit_49 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$fn__590000067")

var Lit_50 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$iter__590000085__590000089")

var Lit_51 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$fn__590000067$iter__590000071__590000075")

var Lit_52 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$fn__590000067$iter__590000071__590000075$fn__590000076")

var Lit_53 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$fn__590000067$iter__590000071__590000075$fn__590000076$fn__590000077")

var Lit_54 *jrt.String = jrt.Intern(".")

var Lit_55 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$iter__590000085__590000089$fn__590000090")

var Lit_56 *jrt.String = jrt.Intern("arbace.repr.go$dump_context$iter__590000061__590000065$fn__590000066$iter__590000085__590000089$fn__590000090$fn__590000091")

var Lit_57 *jrt.String = jrt.Intern("arbace.repr.go$dump_files$iter__590000159__590000165")

var Lit_58 *jrt.String = jrt.Intern("arbace.repr.go$dump_files$iter__590000159__590000165$fn__590000166")

var Lit_59 *jrt.String = jrt.Intern("arbace.repr.go$dump_files$iter__590000159__590000165$fn__590000166$iter__590000161__590000167")

var Lit_60 *jrt.String = jrt.Intern("arbace.repr.go$dump_files$iter__590000159__590000165$fn__590000166$iter__590000161__590000167$fn__590000168")

var Lit_61 *jrt.String = jrt.Intern("arbace.repr.go$dump_files$iter__590000159__590000165$fn__590000166$iter__590000161__590000167$fn__590000168$fn__590000169")

var Lit_62 *jrt.String = jrt.Intern(".edn")

var Lit_63 *jrt.String = jrt.Intern("java.io.File")

var Lit_64 *jrt.String = jrt.Intern("java.io.StringReader")

var Lit_65 *jrt.String = jrt.Intern("java.util.concurrent.Executors")

var Lit_66 *jrt.String = jrt.Intern("java.util.concurrent.TimeUnit")

var Lit_67 *jrt.String = jrt.Intern("arbace.repr.go$expected_meta$fn__590000020")

var Lit_68 *jrt.String = jrt.Intern("replaceAll")

var Lit_69 *jrt.String = jrt.Intern("[.-]")

var Lit_70 *jrt.String = jrt.Intern("_")

var Lit_71 *jrt.String = jrt.Intern("arbace.repr.go$package_texts$fn__590000099")

var Lit_72 *jrt.String = jrt.Intern("arbace.repr.go$package_texts$iter__590000101__590000105")

var Lit_73 *jrt.String = jrt.Intern("arbace.repr.go$package_texts$iter__590000101__590000105$fn__590000106")

var Lit_74 *jrt.String = jrt.Intern("arbace.repr.go$package_texts$iter__590000101__590000105$fn__590000106$fn__590000107")

var Lit_75 *jrt.String = jrt.Intern("")

var Lit_76 *jrt.String = jrt.Intern("go.test.")

var Lit_77 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000182")

var Lit_78 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000184")

var Lit_79 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000186")

var Lit_80 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000188")

var Lit_81 *jrt.String = jrt.Intern("FAIL")

var Lit_82 *jrt.String = jrt.Intern("    ")

var Lit_83 *jrt.String = jrt.Intern("BAD")

var Lit_84 *jrt.String = jrt.Intern("%s: %s, %d files, %.1f KB, %.0f ms (read %.0f ms)")

var Lit_85 *jrt.String = jrt.Intern("UNPLACED directive")

var Lit_86 *jrt.String = jrt.Intern("node kinds (converted / in the dumps):")

var Lit_87 *jrt.String = jrt.Intern("  %-20s %9d / %9d%s")

var Lit_88 *jrt.String = jrt.Intern("  *")

var Lit_89 *jrt.String = jrt.Intern("notes:")

var Lit_90 *jrt.String = jrt.Intern("layout:")

var Lit_91 *jrt.String = jrt.Intern("converted %d of %d dumps (%d files, %.1f MB of forms) in %.1f s with %d threads; %d failed, %d did not read back")

var Lit_92 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000238")

var Lit_93 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000241")

var Lit_94 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000246")

var Lit_95 *jrt.String = jrt.Intern("TEXT known")

var Lit_96 *jrt.String = jrt.Intern("TEXT")

var Lit_97 *jrt.String = jrt.Intern("line")

var Lit_98 *jrt.String = jrt.Intern("(")

var Lit_99 *jrt.String = jrt.Intern(")")

var Lit_100 *jrt.String = jrt.Intern("TEXT fixed")

var Lit_101 *jrt.String = jrt.Intern("(known as differing: remove it from the known differences)")

var Lit_102 *jrt.String = jrt.Intern("text: %d files, %d byte-identical, %d differ (%d known, %d not known)")

var Lit_103 *jrt.String = jrt.Intern("arbace.repr.go$report$fn__590000188$fn__590000189")

var Lit_104 *jrt.String = jrt.Intern("test/")

var Lit_105 *jrt.String = jrt.Intern("arbace.repr.go$text_level$iter__590000050__590000054")

var Lit_106 *jrt.String = jrt.Intern("arbace.repr.go$text_level$iter__590000050__590000054$fn__590000055")

var Lit_107 *jrt.String = jrt.Intern("arbace.repr.go$text_level$iter__590000050__590000054$fn__590000055$fn__590000056")

var Lit_108 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,filekn7,privateyn1,ryn4,pathkn3,tagyn6,Stringyn4,textyn8,preparedyn6,ns-symyn4,Fileyn4,candyn4,dumpyn8,pkg-fileyn3,diryn5,bytesyn4,nameyn5,filesyn8,text-diryn8,cand-diryn1,dyn3,relyn6,gorootyn9,positionskn8,declaredyn4,optsyn2,t0yn2,t1kn4,keysyn3,outyn5,checkyn5,printyn3,rawyn5,pathsyn2,msyn2,rsyn4,wallyn1,&yn4,argsv11,arbace.core5,in-nsMyn14,arbace.repr.gom2,R0,s916,Command line of repr/go's reader, Go into Go forms (doc/go/CONVERTER-NOTES.md).\n\n  bin/repr-go read ... runs\n    -m arbace.repr.go read [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/repr-go/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given, and so does a package of a directory test (a dump with\n  :dir-test, key DIR.dir/STEM: go.test.<DIR>_dir.<STEM>). Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.m2,R0,s916,Command line of repr/go's reader, Go into Go forms (doc/go/CONVERTER-NOTES.md).\n\n  bin/repr-go read ... runs\n    -m arbace.repr.go read [--out DIR] [--full] [--jobs N] [--goroot DIR] [--no-check]\n       [--report FILE] DUMP|DIR...\n  Converts each helper dump (DIRs: every .edn below them) to Go forms under OUT (default\n  .tmp/repr-go/forms): go/<path>.ae and go/<path>/<file>.ae per package (doc/go/SPEC.md §4.1).\n  A single-file program (path command-line-arguments) gets the namespace go.test. plus its\n  dump's path relative to the DIR given, and so does a package of a directory test (a dump with\n  :dir-test, key DIR.dir/STEM: go.test.<DIR>_dir.<STEM>). Unless --no-check, every file written is read back\n  with Arbace's reader and compared with the forms in memory, metadata and the lines of lists\n  included. Prints per dump a line, then totals and the coverage per node kind; --report\n  writes them as data.R1,v14,arbace.repr.go7,data-ofm10,R2,L1,V1,R3,R0,s60,The data an in-memory form reads back as (without metadata).R4,i26,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go13,expected-metam12,R7,TR2,L1,V1,R3,R0,s79,The metadata x reads back with, as data, without :line/:column (checked apart).R4,i38,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go9,read-metam10,R7,TR2,L1,V1,R3,R4,i44,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go4,diffm10,R2,L1,V3,R3,R8,R9,R0,s125,The first difference between the in-memory form x (prepared) and the form r read back, or\n  nil: [path what expected actual].R4,i48,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go8,read-allm8,R2,L1,V1,Myn4,textm2,R10,R11,R4,i71,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go10,check-textm10,R2,L1,V2,R12,R13,R0,s63,nil when text reads back as the prepared forms, else a message.R4,i79,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go9,munge-segm10,R7,TR2,L1,V1,Myn1,sm2,R10,R11,R4,i92,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go10,program-nsm10,R2,L1,V1,Myn3,relm2,R10,R11,R0,s82,The namespace of a single-file program from its dump's relative path (x/y.go.edn).R4,i94,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go6,ns-dirm8,R2,L1,V1,R14,R4,i101,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go9,spit-filem10,R7,TR2,L1,V2,Myn1,fm2,R10,R15,Myn4,textm2,R10,R11,R4,i104,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go13,candidate-dirm10,R2,L1,V2,R16,R17,R0,s76,Where the printed Go files of a dump go in a candidate laid out like GOROOT.R4,i108,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go15,print-candidatem10,R2,L1,V2,R18,R19,R0,s136,Prints the forms of the package file pkg-file (arbace.repr.go.print, loaded on first use) into\n  the candidate; nil or an error message.R4,i116,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go16,first-differencem12,R7,TR2,L1,V2,Myn1,am2,R10,R20,Myn1,bm2,R10,R20,R0,s83,The first line (from 1) where the bytes a and b differ, or nil when they are equal.R4,i125,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go8,text-keym10,R2,L1,V2,R17,R21,R0,s97,The name of a Go file in the text level's results: its path under GOROOT (src/... or\n  test/...).R4,i136,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go10,text-levelm10,R2,L1,V4,R17,R22,R23,R24,R0,s157,The text level of the round trip (mode :full): each printed file of the dump compared\n  byte for byte with its original. {:files n :differ [[key line] ...]}.R4,i146,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go12,dump-contextm10,R2,L1,V3,R25,R26,R27,R0,s182,How dump d, at rel (its path relative to the directory given), converts: {:ns :namespaces\n  :src-dir :text-dir}; goroot the Go tree of its sources (nil: no source directory or text).R4,i163,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go13,package-textsm10,R2,L1,V3,R8,R14,R28,R0,s156,The .ae texts of conversion r (convert-package's, of namespace ns-sym) in mode positions, as\n  convert-data writes them: [[\"package\" text] [stem text] ...].R4,i186,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go12,convert-datam8,R29,TR4,i195,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go12,convert-dumpm10,R2,L1,V3,R9,R26,R30,R0,s57,Converts the dump at path into out; returns a result map.R4,i197,R5,i1,R6,s17,arbace/repr/go.aem10,R2,L1,V6,R25,R9,R26,R31,R32,m2,R33,V7,R34,R28,R27,R35,R36,R12,R37,R0,s219,Converts dump d (read from path at t0, by t1; or made in memory) into out; returns a result\n  map. opts :raw: raw forms (arbace.repr.go.convert's raw mode, with :positions :full), their\n  open decisions counted (:open).R4,i208,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go10,dump-filesm10,R2,L1,V1,R38,R0,s82,[path rel] of the .edn files of the paths, sorted; rel relative to the path given.R4,i252,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go12,merge-countsm10,R7,TR2,L1,V1,R39,R4,i265,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go6,reportm10,R2,L1,V3,R40,R41,R30,R0,s459,Prints the results rs of a conversion (convert-dump's or convert-data's, one per dump; wall\n  its seconds) as bin/repr-go read prints them: a line per dump (unless :quiet), FAIL and BAD\n  lines, the coverage per node kind, the totals, the text level (:text, against :text-known);\n  writes them as data to :report. Returns the exit status: 1 when a conversion failed, a file did\n  not read back or (:text) a file differs that the known differences do not list.R4,i267,R5,i1,R6,s17,arbace/repr/go.aev14,arbace.repr.go5,-mainm8,R2,L1,V2,R42,R43,R4,i331,R5,i1,R6,s17,arbace/repr/go.ae")

var Lit_109 *jrt.String = jrt.Intern("arbace.repr.go$eval590000004$loading__1927001464__auto____590000005")

var Lit_110 *jrt.String = jrt.Intern("arbace.repr.go$eval590000008$fn__590000009")

var Lit_111 *jrt.String = jrt.Intern("arbace.repr.go$data_of")

var Lit_112 *jrt.String = jrt.Intern("arbace.repr.go$expected_meta")

var Lit_113 *jrt.String = jrt.Intern("arbace.repr.go$read_meta")

var Lit_114 *jrt.String = jrt.Intern("arbace.repr.go$diff")

var Lit_115 *jrt.String = jrt.Intern("arbace.repr.go$read_all")

var Lit_116 *jrt.String = jrt.Intern("arbace.repr.go$check_text")

var Lit_117 *jrt.String = jrt.Intern("arbace.repr.go$munge_seg")

var Lit_118 *jrt.String = jrt.Intern("arbace.repr.go$program_ns")

var Lit_119 *jrt.String = jrt.Intern("arbace.repr.go$ns_dir")

var Lit_120 *jrt.String = jrt.Intern("arbace.repr.go$spit_file")

var Lit_121 *jrt.String = jrt.Intern("arbace.repr.go$candidate_dir")

var Lit_122 *jrt.String = jrt.Intern("arbace.repr.go$print_candidate")

var Lit_123 *jrt.String = jrt.Intern("arbace.repr.go$first_difference")

var Lit_124 *jrt.String = jrt.Intern("arbace.repr.go$text_key")

var Lit_125 *jrt.String = jrt.Intern("arbace.repr.go$text_level")

var Lit_126 *jrt.String = jrt.Intern("arbace.repr.go$dump_context")

var Lit_127 *jrt.String = jrt.Intern("arbace.repr.go$package_texts")

var Lit_128 *jrt.String = jrt.Intern("arbace.repr.go$convert_dump")

var Lit_129 *jrt.String = jrt.Intern("arbace.repr.go$convert_data")

var Lit_130 *jrt.String = jrt.Intern("arbace.repr.go$dump_files")

var Lit_131 *jrt.String = jrt.Intern("arbace.repr.go$merge_counts")

var Lit_132 *jrt.String = jrt.Intern("arbace.repr.go$report")

var Lit_133 *jrt.String = jrt.Intern("arbace.repr.go$_main")
