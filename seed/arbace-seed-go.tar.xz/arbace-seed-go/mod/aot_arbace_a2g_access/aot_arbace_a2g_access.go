//line aot_arbace_a2g_access.ae:1
package aot_arbace_a2g_access

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_New() *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_access_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_a2g_access_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_access_A_const_3, A_arbace_a2g_access_A_const_4, A_arbace_a2g_access_A_const_5, A_arbace_a2g_access_A_const_6); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_a2g_access_eval41000008_fn__41000009_A_New() *A_arbace_a2g_access_eval41000008_fn__41000009_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_eval41000008_fn__41000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_access_A_const_7.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_8.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_11), A_arbace_a2g_access_A_const_9.GetRawRoot__O(), A_arbace_a2g_access_A_const_10) }











func A_arbace_a2g_access_accessor_A_New() *A_arbace_a2g_access_accessor_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_accessor_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_a2g_access_accessor_A) Ctor() {}
//line :13:1
func (t *A_arbace_a2g_access_accessor_A) Invoke_O_O_O__O(self, o__0, mname__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_12.GetRawRoot__O()).Invoke_O__O(mname__1); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_13.GetRawRoot__O()).Invoke_O_O__O(mname__1, Lit_1); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp1 = lang.IFn_Cast(A_arbace_a2g_access_A_const_14.GetRawRoot__O()).Invoke_O__O(o__0) } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp2 *lang.Keyword = A_arbace_a2g_access_A_const_15; return lang.RT_Get_O_O__O(tmp2.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_8.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_16.GetRawRoot__O()).Invoke_O__O(o__0))), mname__1) } else {
//line :17:1
			return nil
		}
}
func A_arbace_a2g_access_find_field_A_New() *A_arbace_a2g_access_find_field_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_find_field_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_a2g_access_find_field_A) Ctor() {}
//line :20:1
func (t *A_arbace_a2g_access_find_field_A) Invoke_O_O_O__O(self, owner__0, fname__1 any) any { var or__1927000174__auto____3 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_17.GetRawRoot__O()).Invoke_O_O__O(owner__0, fname__1); if
												jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_18.GetRawRoot__O()); var tmp2 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_2, nil, Lit_3, nil), jrt.RefArrayOf(jrt.Object_class, nil, owner__0, nil, fname__1)).Ref(); var tmp3 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp3 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp1.Invoke_O_O__O(tmp2, tmp3.Ref())))) } }


func A_arbace_a2g_access_unaccess_A_New() *A_arbace_a2g_access_unaccess_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_unaccess_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_a2g_access_unaccess_A) Ctor() {}
//line :24:1
func (t *A_arbace_a2g_access_unaccess_A) Invoke_O_O__O(self, node__0 any) any { var temp__1927000408__auto____2 any; var tmp1 any = A_arbace_a2g_access_A_const_19; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_a2g_access_A_const_20.Invoke_O__O(node__0)); if and__1927000168__auto____2 {


	var tmp2 any = A_arbace_a2g_access_A_const_21; var and__1927000168__auto____3 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_access_A_const_22.Invoke_O__O(node__0)); if and__1927000168__auto____3 { temp__1927000408__auto____2 = lang.IFn_Cast(A_arbace_a2g_access_A_const_23.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(node__0), A_arbace_a2g_access_A_const_43.Invoke_O__O(node__0)) } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.A2g_Truth(temp__1927000408__auto____2) { var acc__3 any = temp__1927000408__auto____2; var args__4 any = A_arbace_a2g_access_A_const_24.Invoke_O__O(node__0); var G__41000015__5_ any = A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3)

		switch lang.Util_Hash_O__I(G__41000015__5_) >> 4 & 15 { case 0: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_26) { var f__6 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3)); var tmp3 any = A_arbace_a2g_access_A_const_20; var tmp4 any = A_arbace_a2g_access_A_const_28; var tmp5 any = A_arbace_a2g_access_A_const_29; var tmp6 any = A_arbace_a2g_access_A_const_30; var tmp7 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(f__6); var tmp8 any = A_arbace_a2g_access_A_const_31; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4, tmp5, f__6, tmp6, tmp7, tmp8, A_arbace_a2g_access_A_const_32.Invoke_O__O(f__6))) }; case 4: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_33) { var tmp9 any = A_arbace_a2g_access_A_const_33; var static_QMARK___6 bool = lang.Util_Equiv_O_O__Z(tmp9, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3)); var m__7 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_34.GetRawRoot__O()); var tmp11 any = A_arbace_a2g_access_unaccess_fn__41000019_A_New_O(acc__3); var tmp12 *jrt.Class
			var fncls__4 /*line :29:1*/*jrt.Class = A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class











			if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_4, false); A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class = fncls__4d; tmp12 = fncls__4d } else { tmp12 = fncls__4 }; var tmp13 *lang.Keyword = A_arbace_a2g_access_A_const_53; m__7 = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), tmp13.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))))
//line :29:1
			var m__8 any; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_35.GetRawRoot__O()); var tmp15 any
			var or__1927000174__auto____8 any = m__7












			if jrt.A2g_Truth(or__1927000174__auto____8) { tmp15 = or__1927000174__auto____8 } else { var tmp16 any = A_arbace_a2g_access_A_const_43; var tmp17 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp18 any = A_arbace_a2g_access_A_const_32; tmp15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp17, tmp18, A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_55, A_arbace_a2g_access_A_const_56)) }; var tmp19 any = tmp15; var tmp20 any = A_arbace_a2g_access_A_const_30; m__8 = tmp14.Invoke_O_O_O__O(tmp19, tmp20, A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))
//line :29:1
			var vec__41000016__9 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3)); var ___10 any = lang.RT_Nth_O_I_O__O(vec__41000016__9, lang.RT_IntCast_J__I(0), nil); var r__11 any = lang.RT_Nth_O_I_O__O(vec__41000016__9, lang.RT_IntCast_J__I(1), nil); var tmp21 any = A_arbace_a2g_access_A_const_20; var tmp22 any = A_arbace_a2g_access_A_const_19; var tmp23 any = A_arbace_a2g_access_A_const_22; var tmp24 *lang.Keyword; var G__41000021__12_ any = A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3); _ = ___10
















		L2: switch { default: switch lang.Util_Hash_O__I(G__41000021__12_) >> 10 & 3 { case 0: if any(G__41000021__12_) == any(A_arbace_a2g_access_A_const_37) { tmp24 = A_arbace_a2g_access_A_const_38; break L2 }; case 1: if any(G__41000021__12_) == any(A_arbace_a2g_access_A_const_39) { tmp24 = A_arbace_a2g_access_A_const_40; break L2 }; case 2: if any(G__41000021__12_) == any(A_arbace_a2g_access_A_const_33) { tmp24 = A_arbace_a2g_access_A_const_21; break L2 }; default:}; tmp24 = A_arbace_a2g_access_A_const_41}
//line :29:1
			var tmp25 any = tmp24.Ref(); var tmp26 any = A_arbace_a2g_access_A_const_30; var tmp27 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3); var tmp28 any = A_arbace_a2g_access_A_const_42; var tmp29 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_a2g_access_A_const_42.Invoke_O__O(acc__3))).Ref(); var tmp30 any = A_arbace_a2g_access_A_const_43; var tmp31 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp32 any = A_arbace_a2g_access_A_const_32; var tmp33 any = A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3); var tmp34 any = A_arbace_a2g_access_A_const_44; var tmp35 any



















			if static_QMARK___6 { tmp35 = nil } else { tmp35 = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
			var tmp36 any = tmp35; var tmp37 any = A_arbace_a2g_access_A_const_24; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_46.GetRawRoot__O()); var tmp39 any



















			if static_QMARK___6 { tmp39 = args__4 } else { tmp39 = lang.IFn_Cast(A_arbace_a2g_access_A_const_57.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
			var tmp40 any = tmp38.Invoke_O__O(tmp39); var tmp41 any = A_arbace_a2g_access_A_const_31; var tmp42 any = A_arbace_a2g_access_A_const_47; var tmp43 any = A_arbace_a2g_access_A_const_48; var tmp44 any = A_arbace_a2g_access_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp22, tmp23, tmp25, tmp26, tmp27, tmp28, tmp29, tmp30, tmp31, tmp32, tmp33, tmp34, tmp36, tmp37, tmp40, tmp41, r__11, tmp42, m__8, tmp43, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp44, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3))).Ref())) }; case 6: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_49) { var f__6_2 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3)); var tmp45 any = A_arbace_a2g_access_A_const_20; var tmp46 any = A_arbace_a2g_access_A_const_50; var tmp47 any = A_arbace_a2g_access_A_const_29; var tmp48 any = A_arbace_a2g_access_A_const_30; var tmp49 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(f__6_2); var tmp50 any = A_arbace_a2g_access_A_const_51; var tmp51 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4); var tmp52 any = A_arbace_a2g_access_A_const_31; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp45, tmp46, tmp47, f__6_2, tmp48, tmp49, tmp50, tmp51, tmp52, A_arbace_a2g_access_A_const_32.Invoke_O__O(f__6_2))) }; case 8: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_52) { var tmp53 any = A_arbace_a2g_access_A_const_33; var static_QMARK___6_2 bool = lang.Util_Equiv_O_O__Z(tmp53, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3)); var m__7_2 any; var tmp54 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_34.GetRawRoot__O()); var tmp55 any = A_arbace_a2g_access_unaccess_fn__41000025_A_New_O(acc__3); var tmp56 *jrt.Class
				var fncls__5 /*line :29:1*/*jrt.Class = A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class











				if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_5, false); A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class = fncls__5d; tmp56 = fncls__5d } else { tmp56 = fncls__5 }; var tmp57 *lang.Keyword = A_arbace_a2g_access_A_const_53; m__7_2 = tmp54.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp55, tmp56, nil), tmp57.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))))
//line :29:1
				var m__8_2 any; var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_35.GetRawRoot__O()); var tmp59 any
				var or__1927000174__auto____8_2 any = m__7_2












				if jrt.A2g_Truth(or__1927000174__auto____8_2) { tmp59 = or__1927000174__auto____8_2 } else { var tmp60 any = A_arbace_a2g_access_A_const_43; var tmp61 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp62 any = A_arbace_a2g_access_A_const_32; tmp59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp60, tmp61, tmp62, A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_55, A_arbace_a2g_access_A_const_56)) }; var tmp63 any = tmp59; var tmp64 any = A_arbace_a2g_access_A_const_30; m__8_2 = tmp58.Invoke_O_O_O__O(tmp63, tmp64, A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))
//line :29:1
				var vec__41000022__9 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3)); var ___10_2 any = lang.RT_Nth_O_I_O__O(vec__41000022__9, lang.RT_IntCast_J__I(0), nil); var r__11_2 any = lang.RT_Nth_O_I_O__O(vec__41000022__9, lang.RT_IntCast_J__I(1), nil); var tmp65 any = A_arbace_a2g_access_A_const_20; var tmp66 any = A_arbace_a2g_access_A_const_19; var tmp67 any = A_arbace_a2g_access_A_const_22; var tmp68 *lang.Keyword; var G__41000027__12_ any = A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3); _ = ___10_2
















			L3: switch { default: switch lang.Util_Hash_O__I(G__41000027__12_) >> 10 & 3 { case 0: if any(G__41000027__12_) == any(A_arbace_a2g_access_A_const_37) { tmp68 = A_arbace_a2g_access_A_const_38; break L3 }; case 1: if any(G__41000027__12_) == any(A_arbace_a2g_access_A_const_39) { tmp68 = A_arbace_a2g_access_A_const_40; break L3 }; case 2: if any(G__41000027__12_) == any(A_arbace_a2g_access_A_const_33) { tmp68 = A_arbace_a2g_access_A_const_21; break L3 }; default:}; tmp68 = A_arbace_a2g_access_A_const_41}
//line :29:1
				var tmp69 any = tmp68.Ref(); var tmp70 any = A_arbace_a2g_access_A_const_30; var tmp71 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3); var tmp72 any = A_arbace_a2g_access_A_const_42; var tmp73 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_a2g_access_A_const_42.Invoke_O__O(acc__3))).Ref(); var tmp74 any = A_arbace_a2g_access_A_const_43; var tmp75 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp76 any = A_arbace_a2g_access_A_const_32; var tmp77 any = A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3); var tmp78 any = A_arbace_a2g_access_A_const_44; var tmp79 any



















				if static_QMARK___6_2 { tmp79 = nil } else { tmp79 = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
				var tmp80 any = tmp79; var tmp81 any = A_arbace_a2g_access_A_const_24; var tmp82 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_46.GetRawRoot__O()); var tmp83 any



















				if static_QMARK___6_2 { tmp83 = args__4 } else { tmp83 = lang.IFn_Cast(A_arbace_a2g_access_A_const_57.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
				var tmp84 any = tmp82.Invoke_O__O(tmp83); var tmp85 any = A_arbace_a2g_access_A_const_31; var tmp86 any = A_arbace_a2g_access_A_const_47; var tmp87 any = A_arbace_a2g_access_A_const_48; var tmp88 any = A_arbace_a2g_access_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp65, tmp66, tmp67, tmp69, tmp70, tmp71, tmp72, tmp73, tmp74, tmp75, tmp76, tmp77, tmp78, tmp80, tmp81, tmp84, tmp85, r__11_2, tmp86, m__8_2, tmp87, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp88, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3))).Ref())) }; case 10: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_58) { var f__6_3 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3)); var tmp89 any = A_arbace_a2g_access_A_const_20; var tmp90 any = A_arbace_a2g_access_A_const_59; var tmp91 any = A_arbace_a2g_access_A_const_29; var tmp92 any = A_arbace_a2g_access_A_const_30; var tmp93 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(f__6_3); var tmp94 any = A_arbace_a2g_access_A_const_44; var tmp95 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4); var tmp96 any = A_arbace_a2g_access_A_const_31; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp89, tmp90, tmp91, f__6_3, tmp92, tmp93, tmp94, tmp95, tmp96, A_arbace_a2g_access_A_const_32.Invoke_O__O(f__6_3))) }; case 11: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_60) { var f__6_4 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_27.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3)); var tmp97 any = A_arbace_a2g_access_A_const_20; var tmp98 any = A_arbace_a2g_access_A_const_61; var tmp99 any = A_arbace_a2g_access_A_const_29; var tmp100 any = A_arbace_a2g_access_A_const_30; var tmp101 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(f__6_4); var tmp102 any = A_arbace_a2g_access_A_const_44; var tmp103 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4); var tmp104 any = A_arbace_a2g_access_A_const_51; var tmp105 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_62.GetRawRoot__O()).Invoke_O__O(args__4); var tmp106 any = A_arbace_a2g_access_A_const_31; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp97, tmp98, tmp99, f__6_4, tmp100, tmp101, tmp102, tmp103, tmp104, tmp105, tmp106, A_arbace_a2g_access_A_const_32.Invoke_O__O(f__6_4))) }; case 12: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_39) { var tmp107 any = A_arbace_a2g_access_A_const_33; var static_QMARK___6_3 bool = lang.Util_Equiv_O_O__Z(tmp107, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3)); var m__7_3 any; var tmp108 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_34.GetRawRoot__O()); var tmp109 any = A_arbace_a2g_access_unaccess_fn__41000031_A_New_O(acc__3); var tmp110 *jrt.Class
					var fncls__8 /*line :29:1*/*jrt.Class = A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class











					if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class = fncls__8d; tmp110 = fncls__8d } else { tmp110 = fncls__8 }; var tmp111 *lang.Keyword = A_arbace_a2g_access_A_const_53; m__7_3 = tmp108.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp109, tmp110, nil), tmp111.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))))
//line :29:1
					var m__8_3 any; var tmp112 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_35.GetRawRoot__O()); var tmp113 any
					var or__1927000174__auto____8_3 any = m__7_3












					if jrt.A2g_Truth(or__1927000174__auto____8_3) { tmp113 = or__1927000174__auto____8_3 } else { var tmp114 any = A_arbace_a2g_access_A_const_43; var tmp115 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp116 any = A_arbace_a2g_access_A_const_32; tmp113 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp114, tmp115, tmp116, A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_55, A_arbace_a2g_access_A_const_56)) }; var tmp117 any = tmp113; var tmp118 any = A_arbace_a2g_access_A_const_30; m__8_3 = tmp112.Invoke_O_O_O__O(tmp117, tmp118, A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))
//line :29:1
					var vec__41000028__9 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3)); var ___10_3 any = lang.RT_Nth_O_I_O__O(vec__41000028__9, lang.RT_IntCast_J__I(0), nil); var r__11_3 any = lang.RT_Nth_O_I_O__O(vec__41000028__9, lang.RT_IntCast_J__I(1), nil); var tmp119 any = A_arbace_a2g_access_A_const_20; var tmp120 any = A_arbace_a2g_access_A_const_19; var tmp121 any = A_arbace_a2g_access_A_const_22; var tmp122 *lang.Keyword; var G__41000033__12_ any = A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3); _ = ___10_3
















				L4: switch { default: switch lang.Util_Hash_O__I(G__41000033__12_) >> 10 & 3 { case 0: if any(G__41000033__12_) == any(A_arbace_a2g_access_A_const_37) { tmp122 = A_arbace_a2g_access_A_const_38; break L4 }; case 1: if any(G__41000033__12_) == any(A_arbace_a2g_access_A_const_39) { tmp122 = A_arbace_a2g_access_A_const_40; break L4 }; case 2: if any(G__41000033__12_) == any(A_arbace_a2g_access_A_const_33) { tmp122 = A_arbace_a2g_access_A_const_21; break L4 }; default:}; tmp122 = A_arbace_a2g_access_A_const_41}
//line :29:1
					var tmp123 any = tmp122.Ref(); var tmp124 any = A_arbace_a2g_access_A_const_30; var tmp125 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3); var tmp126 any = A_arbace_a2g_access_A_const_42; var tmp127 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_a2g_access_A_const_42.Invoke_O__O(acc__3))).Ref(); var tmp128 any = A_arbace_a2g_access_A_const_43; var tmp129 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp130 any = A_arbace_a2g_access_A_const_32; var tmp131 any = A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3); var tmp132 any = A_arbace_a2g_access_A_const_44; var tmp133 any



















					if static_QMARK___6_3 { tmp133 = nil } else { tmp133 = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
					var tmp134 any = tmp133; var tmp135 any = A_arbace_a2g_access_A_const_24; var tmp136 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_46.GetRawRoot__O()); var tmp137 any



















					if static_QMARK___6_3 { tmp137 = args__4 } else { tmp137 = lang.IFn_Cast(A_arbace_a2g_access_A_const_57.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
					var tmp138 any = tmp136.Invoke_O__O(tmp137); var tmp139 any = A_arbace_a2g_access_A_const_31; var tmp140 any = A_arbace_a2g_access_A_const_47; var tmp141 any = A_arbace_a2g_access_A_const_48; var tmp142 any = A_arbace_a2g_access_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp119, tmp120, tmp121, tmp123, tmp124, tmp125, tmp126, tmp127, tmp128, tmp129, tmp130, tmp131, tmp132, tmp134, tmp135, tmp138, tmp139, r__11_3, tmp140, m__8_3, tmp141, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp142, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3))).Ref())) }; case 14: if any(G__41000015__5_) == any(A_arbace_a2g_access_A_const_37) { var tmp143 any = A_arbace_a2g_access_A_const_33; var static_QMARK___6_4 bool = lang.Util_Equiv_O_O__Z(tmp143, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3)); var m__7_4 any; var tmp144 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_34.GetRawRoot__O()); var tmp145 any = A_arbace_a2g_access_unaccess_fn__41000037_A_New_O(acc__3); var tmp146 *jrt.Class
						var fncls__9 /*line :29:1*/*jrt.Class = A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class











						if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class = fncls__9d; tmp146 = fncls__9d } else { tmp146 = fncls__9 }; var tmp147 *lang.Keyword = A_arbace_a2g_access_A_const_53; m__7_4 = tmp144.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp145, tmp146, nil), tmp147.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_access_A_const_54.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))))
//line :29:1
						var m__8_4 any; var tmp148 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_35.GetRawRoot__O()); var tmp149 any
						var or__1927000174__auto____8_4 any = m__7_4












						if jrt.A2g_Truth(or__1927000174__auto____8_4) { tmp149 = or__1927000174__auto____8_4 } else { var tmp150 any = A_arbace_a2g_access_A_const_43; var tmp151 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp152 any = A_arbace_a2g_access_A_const_32; tmp149 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp150, tmp151, tmp152, A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3), A_arbace_a2g_access_A_const_55, A_arbace_a2g_access_A_const_56)) }; var tmp153 any = tmp149; var tmp154 any = A_arbace_a2g_access_A_const_30; m__8_4 = tmp148.Invoke_O_O_O__O(tmp153, tmp154, A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3))
//line :29:1
						var vec__41000034__9 any = lang.IFn_Cast(A_arbace_a2g_access_A_const_36.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3)); var ___10_4 any = lang.RT_Nth_O_I_O__O(vec__41000034__9, lang.RT_IntCast_J__I(0), nil); var r__11_4 any = lang.RT_Nth_O_I_O__O(vec__41000034__9, lang.RT_IntCast_J__I(1), nil); var tmp155 any = A_arbace_a2g_access_A_const_20; var tmp156 any = A_arbace_a2g_access_A_const_19; var tmp157 any = A_arbace_a2g_access_A_const_22; var tmp158 *lang.Keyword; var G__41000039__12_ any = A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3); _ = ___10_4
















					L5: switch { default: switch lang.Util_Hash_O__I(G__41000039__12_) >> 10 & 3 { case 0: if any(G__41000039__12_) == any(A_arbace_a2g_access_A_const_37) { tmp158 = A_arbace_a2g_access_A_const_38; break L5 }; case 1: if any(G__41000039__12_) == any(A_arbace_a2g_access_A_const_39) { tmp158 = A_arbace_a2g_access_A_const_40; break L5 }; case 2: if any(G__41000039__12_) == any(A_arbace_a2g_access_A_const_33) { tmp158 = A_arbace_a2g_access_A_const_21; break L5 }; default:}; tmp158 = A_arbace_a2g_access_A_const_41}
//line :29:1
						var tmp159 any = tmp158.Ref(); var tmp160 any = A_arbace_a2g_access_A_const_30; var tmp161 any = A_arbace_a2g_access_A_const_30.Invoke_O__O(acc__3); var tmp162 any = A_arbace_a2g_access_A_const_42; var tmp163 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(A_arbace_a2g_access_A_const_42.Invoke_O__O(acc__3))).Ref(); var tmp164 any = A_arbace_a2g_access_A_const_43; var tmp165 any = A_arbace_a2g_access_A_const_43.Invoke_O__O(acc__3); var tmp166 any = A_arbace_a2g_access_A_const_32; var tmp167 any = A_arbace_a2g_access_A_const_32.Invoke_O__O(acc__3); var tmp168 any = A_arbace_a2g_access_A_const_44; var tmp169 any



















						if static_QMARK___6_4 { tmp169 = nil } else { tmp169 = lang.IFn_Cast(A_arbace_a2g_access_A_const_45.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
						var tmp170 any = tmp169; var tmp171 any = A_arbace_a2g_access_A_const_24; var tmp172 lang.IFn = lang.IFn_Cast(A_arbace_a2g_access_A_const_46.GetRawRoot__O()); var tmp173 any



















						if static_QMARK___6_4 { tmp173 = args__4 } else { tmp173 = lang.IFn_Cast(A_arbace_a2g_access_A_const_57.GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
						var tmp174 any = tmp172.Invoke_O__O(tmp173); var tmp175 any = A_arbace_a2g_access_A_const_31; var tmp176 any = A_arbace_a2g_access_A_const_47; var tmp177 any = A_arbace_a2g_access_A_const_48; var tmp178 any = A_arbace_a2g_access_A_const_39; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp155, tmp156, tmp157, tmp159, tmp160, tmp161, tmp162, tmp163, tmp164, tmp165, tmp166, tmp167, tmp168, tmp170, tmp171, tmp174, tmp175, r__11_4, tmp176, m__8_4, tmp177, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp178, A_arbace_a2g_access_A_const_25.Invoke_O__O(acc__3))).Ref())) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_8, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__41000015__5_))))) } else {
//line :27:1
							return node__0 } }













func A_arbace_a2g_access_unaccess_fn__41000019_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000019_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000019_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_43.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_43.Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_32.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_32.Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_a2g_access_unaccess_fn__41000025_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000025_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000025_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_43.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_43.Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_32.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_32.Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_a2g_access_unaccess_fn__41000031_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000031_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000031_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_43.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_43.Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_32.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_32.Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_a2g_access_unaccess_fn__41000037_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000037_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000037_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_43.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_43.Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { tmp1 = lang.Util_Equiv_O_O__Z(A_arbace_a2g_access_A_const_32.Invoke_O__O(t.F_acc), A_arbace_a2g_access_A_const_32.Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }

























type A_arbace_a2g_access_A struct{ jrt.Object }

var A_arbace_a2g_access_A_const_pool *jrt.RefArray

var A_arbace_a2g_access_A_const_0 *lang.Var

var A_arbace_a2g_access_A_const_1 *lang.Var

var A_arbace_a2g_access_A_const_2 any

var A_arbace_a2g_access_A_const_3 any

var A_arbace_a2g_access_A_const_4 any

var A_arbace_a2g_access_A_const_5 any

var A_arbace_a2g_access_A_const_6 any

var A_arbace_a2g_access_A_const_7 *lang.Var

var A_arbace_a2g_access_A_const_8 *lang.Var

var A_arbace_a2g_access_A_const_9 *lang.Var

var A_arbace_a2g_access_A_const_10 any

var A_arbace_a2g_access_A_const_11 *lang.Var

var A_arbace_a2g_access_A_const_12 *lang.Var

var A_arbace_a2g_access_A_const_13 *lang.Var

var A_arbace_a2g_access_A_const_14 *lang.Var

var A_arbace_a2g_access_A_const_15 *lang.Keyword

var A_arbace_a2g_access_A_const_16 *lang.Var

var A_arbace_a2g_access_A_const_17 *lang.Var

var A_arbace_a2g_access_A_const_18 *lang.Var

var A_arbace_a2g_access_A_const_19 *lang.Keyword

var A_arbace_a2g_access_A_const_20 *lang.Keyword

var A_arbace_a2g_access_A_const_21 *lang.Keyword

var A_arbace_a2g_access_A_const_22 *lang.Keyword

var A_arbace_a2g_access_A_const_23 *lang.Var

var A_arbace_a2g_access_A_const_24 *lang.Keyword

var A_arbace_a2g_access_A_const_25 *lang.Keyword

var A_arbace_a2g_access_A_const_26 *lang.Keyword

var A_arbace_a2g_access_A_const_27 *lang.Var

var A_arbace_a2g_access_A_const_28 *lang.Keyword

var A_arbace_a2g_access_A_const_29 *lang.Keyword

var A_arbace_a2g_access_A_const_30 *lang.Keyword

var A_arbace_a2g_access_A_const_31 *lang.Keyword

var A_arbace_a2g_access_A_const_32 *lang.Keyword

var A_arbace_a2g_access_A_const_33 *lang.Keyword

var A_arbace_a2g_access_A_const_34 *lang.Var

var A_arbace_a2g_access_A_const_35 *lang.Var

var A_arbace_a2g_access_A_const_36 *lang.Var

var A_arbace_a2g_access_A_const_37 *lang.Keyword

var A_arbace_a2g_access_A_const_38 *lang.Keyword

var A_arbace_a2g_access_A_const_39 *lang.Keyword

var A_arbace_a2g_access_A_const_40 *lang.Keyword

var A_arbace_a2g_access_A_const_41 *lang.Keyword

var A_arbace_a2g_access_A_const_42 *lang.Keyword

var A_arbace_a2g_access_A_const_43 *lang.Keyword

var A_arbace_a2g_access_A_const_44 *lang.Keyword

var A_arbace_a2g_access_A_const_45 *lang.Var

var A_arbace_a2g_access_A_const_46 *lang.Var

var A_arbace_a2g_access_A_const_47 *lang.Keyword

var A_arbace_a2g_access_A_const_48 *lang.Keyword

var A_arbace_a2g_access_A_const_49 *lang.Keyword

var A_arbace_a2g_access_A_const_50 *lang.Keyword

var A_arbace_a2g_access_A_const_51 *lang.Keyword

var A_arbace_a2g_access_A_const_52 *lang.Keyword

var A_arbace_a2g_access_A_const_53 *lang.Keyword

var A_arbace_a2g_access_A_const_54 *lang.Var

var A_arbace_a2g_access_A_const_55 *lang.Keyword

var A_arbace_a2g_access_A_const_56 any

var A_arbace_a2g_access_A_const_57 *lang.Var

var A_arbace_a2g_access_A_const_58 *lang.Keyword

var A_arbace_a2g_access_A_const_59 *lang.Keyword

var A_arbace_a2g_access_A_const_60 *lang.Keyword

var A_arbace_a2g_access_A_const_61 *lang.Keyword

var A_arbace_a2g_access_A_const_62 *lang.Var

var A_arbace_a2g_access_A_init jrt.ClassInit

func A_arbace_a2g_access_A_Init() { if !A_arbace_a2g_access_A_init.Done() { A_arbace_a2g_access_A_init.Run(A_arbace_a2g_access_A_clinit) } }

func A_arbace_a2g_access_A_clinit() { A_arbace_a2g_access_A_clinit_p0(); A_arbace_a2g_access_A_clinit_p1(); A_arbace_a2g_access_A_clinit_p2(); A_arbace_a2g_access_A_clinit_p3(); A_arbace_a2g_access_A_clinit_p4(); A_arbace_a2g_access_A_clinit_p5() }

func A_arbace_a2g_access_A_clinit_p0() { A_arbace_a2g_access_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 108); A_arbace_a2g_access_A_const_0 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[45]); A_arbace_a2g_access_A_const_1 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[46]); A_arbace_a2g_access_A_const_2 = A_arbace_a2g_access_A_const_pool.A[47]; A_arbace_a2g_access_A_const_3 = A_arbace_a2g_access_A_const_pool.A[48]; A_arbace_a2g_access_A_const_4 = A_arbace_a2g_access_A_const_pool.A[49]; A_arbace_a2g_access_A_const_5 = A_arbace_a2g_access_A_const_pool.A[50]; A_arbace_a2g_access_A_const_6 = A_arbace_a2g_access_A_const_pool.A[51]; A_arbace_a2g_access_A_const_7 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[52]); A_arbace_a2g_access_A_const_8 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[53]); A_arbace_a2g_access_A_const_9 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[54]); A_arbace_a2g_access_A_const_10 = A_arbace_a2g_access_A_const_pool.A[55]; A_arbace_a2g_access_A_const_11 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[56]); A_arbace_a2g_access_A_const_12 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[57]) }

func A_arbace_a2g_access_A_clinit_p1() { A_arbace_a2g_access_A_const_13 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[58]); A_arbace_a2g_access_A_const_14 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[59]); A_arbace_a2g_access_A_const_15 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[60]); A_arbace_a2g_access_A_const_16 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[61]); A_arbace_a2g_access_A_const_17 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[62]); A_arbace_a2g_access_A_const_18 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[63]); A_arbace_a2g_access_A_const_19 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[64]); A_arbace_a2g_access_A_const_20 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[65]); A_arbace_a2g_access_A_const_21 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[66]); A_arbace_a2g_access_A_const_22 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[67]); A_arbace_a2g_access_A_const_23 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[68]); A_arbace_a2g_access_A_const_24 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[69]) }

func A_arbace_a2g_access_A_clinit_p2() { A_arbace_a2g_access_A_const_25 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[70]); A_arbace_a2g_access_A_const_26 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[71]); A_arbace_a2g_access_A_const_27 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[72]); A_arbace_a2g_access_A_const_28 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[73]); A_arbace_a2g_access_A_const_29 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[74]); A_arbace_a2g_access_A_const_30 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[75]); A_arbace_a2g_access_A_const_31 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[76]); A_arbace_a2g_access_A_const_32 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[77]); A_arbace_a2g_access_A_const_33 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[78]); A_arbace_a2g_access_A_const_34 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[79]); A_arbace_a2g_access_A_const_35 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[80]); A_arbace_a2g_access_A_const_36 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[81]) }

func A_arbace_a2g_access_A_clinit_p3() { A_arbace_a2g_access_A_const_37 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[82]); A_arbace_a2g_access_A_const_38 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[83]); A_arbace_a2g_access_A_const_39 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[84]); A_arbace_a2g_access_A_const_40 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[85]); A_arbace_a2g_access_A_const_41 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[86]); A_arbace_a2g_access_A_const_42 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[87]); A_arbace_a2g_access_A_const_43 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[88]); A_arbace_a2g_access_A_const_44 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[89]); A_arbace_a2g_access_A_const_45 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[90]); A_arbace_a2g_access_A_const_46 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[91]); A_arbace_a2g_access_A_const_47 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[92]); A_arbace_a2g_access_A_const_48 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[93]) }

func A_arbace_a2g_access_A_clinit_p4() { A_arbace_a2g_access_A_const_49 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[94]); A_arbace_a2g_access_A_const_50 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[95]); A_arbace_a2g_access_A_const_51 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[96]); A_arbace_a2g_access_A_const_52 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[97]); A_arbace_a2g_access_A_const_53 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[98]); A_arbace_a2g_access_A_const_54 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[99]); A_arbace_a2g_access_A_const_55 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[100]); A_arbace_a2g_access_A_const_56 = A_arbace_a2g_access_A_const_pool.A[101]; A_arbace_a2g_access_A_const_57 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[102]); A_arbace_a2g_access_A_const_58 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[103]); A_arbace_a2g_access_A_const_59 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[104]); A_arbace_a2g_access_A_const_60 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[105]) }

func A_arbace_a2g_access_A_clinit_p5() { A_arbace_a2g_access_A_const_61 = lang.Keyword_Cast(A_arbace_a2g_access_A_const_pool.A[106]); A_arbace_a2g_access_A_const_62 = lang.Var_Cast(A_arbace_a2g_access_A_const_pool.A[107]) }

func A_arbace_a2g_access_A_New() *A_arbace_a2g_access_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_access_A) Ctor() {}

func (t *A_arbace_a2g_access_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_A_class }

func (t *A_arbace_a2g_access_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_A); return ok }

func A_arbace_a2g_access_A_Cast(x any) *A_arbace_a2g_access_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_A_class)) }; return v }



type A_arbace_a2g_access_accessor_A struct{ a2g_header uint64 }

var A_arbace_a2g_access_accessor_A_fn_class *jrt.Class



type A_arbace_a2g_access_eval41000004_A struct{ jrt.Object }

func A_arbace_a2g_access_eval41000004_A_New() *A_arbace_a2g_access_eval41000004_A { t := &A_arbace_a2g_access_eval41000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_access_eval41000004_A) Ctor() {}

func (t *A_arbace_a2g_access_eval41000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_eval41000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_eval41000004_A_class }

func (t *A_arbace_a2g_access_eval41000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_eval41000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_eval41000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_eval41000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_eval41000004_A); return ok }

func A_arbace_a2g_access_eval41000004_A_Cast(x any) *A_arbace_a2g_access_eval41000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_eval41000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_eval41000004_A_class)) }; return v }



type A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_fn_class *jrt.Class



type A_arbace_a2g_access_eval41000008_A struct{ jrt.Object }

func A_arbace_a2g_access_eval41000008_A_New() *A_arbace_a2g_access_eval41000008_A { t := &A_arbace_a2g_access_eval41000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_access_eval41000008_A) Ctor() {}

func (t *A_arbace_a2g_access_eval41000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_eval41000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_eval41000008_A_class }

func (t *A_arbace_a2g_access_eval41000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_eval41000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_eval41000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_eval41000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_eval41000008_A); return ok }

func A_arbace_a2g_access_eval41000008_A_Cast(x any) *A_arbace_a2g_access_eval41000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_eval41000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_eval41000008_A_class)) }; return v }



type A_arbace_a2g_access_eval41000008_fn__41000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_access_eval41000008_fn__41000009_A_fn_class *jrt.Class



type A_arbace_a2g_access_find_field_A struct{ a2g_header uint64 }

var A_arbace_a2g_access_find_field_A_fn_class *jrt.Class



type A_arbace_a2g_access_unaccess_A struct{ a2g_header uint64 }

var A_arbace_a2g_access_unaccess_A_fn_class *jrt.Class



type A_arbace_a2g_access_unaccess_fn__41000019_A struct{ a2g_header uint64; F_acc any }

var A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class *jrt.Class



type A_arbace_a2g_access_unaccess_fn__41000025_A struct{ a2g_header uint64; F_acc any }

var A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class *jrt.Class



type A_arbace_a2g_access_unaccess_fn__41000031_A struct{ a2g_header uint64; F_acc any }

var A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class *jrt.Class



type A_arbace_a2g_access_unaccess_fn__41000037_A struct{ a2g_header uint64; F_acc any }

var A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class *jrt.Class
