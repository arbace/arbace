//line aot_arbace_a2g_access.ae:1
package aot_arbace_a2g_access

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_New() *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A { A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_Init(); t := &A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp16 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_access_A_Init(); tmp6 = A_arbace_a2g_access_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_access_A_Init(); tmp9 = A_arbace_a2g_access_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_access_A_Init(); tmp11 = A_arbace_a2g_access_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_access_A_Init(); tmp13 = A_arbace_a2g_access_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_access_A_Init(); tmp15 = A_arbace_a2g_access_A_const_6; tmp3 = tmp8.Invoke_O_O_O_O__O(tmp10, tmp12, tmp14, tmp15) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp16 != nil { panic(tmp16) }; return tmp3 }
//line :1:1
func A_arbace_a2g_access_eval41000008_fn__41000009_A_New() *A_arbace_a2g_access_eval41000008_fn__41000009_A { A_arbace_a2g_access_eval41000008_fn__41000009_A_Init(); t := &A_arbace_a2g_access_eval41000008_fn__41000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_access_A_Init(); tmp1 = A_arbace_a2g_access_A_const_7; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_access_A_Init(); tmp3 = A_arbace_a2g_access_A_const_8; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_access_A_Init(); tmp5 = A_arbace_a2g_access_A_const_11; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_9; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_access_A_Init(); tmp9 = A_arbace_a2g_access_A_const_10; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }











func A_arbace_a2g_access_accessor_A_New() *A_arbace_a2g_access_accessor_A { A_arbace_a2g_access_accessor_A_Init(); t := &A_arbace_a2g_access_accessor_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_a2g_access_accessor_A) Ctor() {}
//line :13:1
func (t *A_arbace_a2g_access_accessor_A) Invoke_O_O_O__O(self, o__0, mname__1 any) any {



	var tmp1 any; var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_access_A_Init(); tmp2 = A_arbace_a2g_access_A_const_12; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(mname__1); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_access_A_Init(); tmp3 = A_arbace_a2g_access_A_const_13; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(mname__1, Lit_69); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp4 *lang.Var; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_14; tmp1 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(o__0) } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 }; if jrt.A2g_Truth(tmp1) {
		var tmp5 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp5 = A_arbace_a2g_access_A_const_15; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_8; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_access_A_Init(); tmp9 = A_arbace_a2g_access_A_const_16; return lang.RT_Get_O_O__O(jrt.NN(tmp6).Invoke_O__O(tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(o__0))), mname__1) } else {
//line :17:1
			return nil
		}
}
func A_arbace_a2g_access_find_field_A_New() *A_arbace_a2g_access_find_field_A { A_arbace_a2g_access_find_field_A_Init(); t := &A_arbace_a2g_access_find_field_A{}; t.Ctor(); return t }
//line :20:1
func (t *A_arbace_a2g_access_find_field_A) Ctor() {}
//line :20:1
func (t *A_arbace_a2g_access_find_field_A) Invoke_O_O_O__O(self, owner__0, fname__1 any) any { var or__1927000174__auto____3 any; var tmp1 *lang.Var;
												A_arbace_a2g_access_A_Init(); tmp1 = A_arbace_a2g_access_A_const_17; or__1927000174__auto____3 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(owner__0, fname__1); if jrt.A2g_Truth(or__1927000174__auto____3) { return or__1927000174__auto____3 } else { var tmp2 *lang.Var; A_arbace_a2g_access_A_Init(); tmp2 = A_arbace_a2g_access_A_const_18; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_73, nil, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, owner__0, nil, fname__1)).Ref(); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())))) } }


func A_arbace_a2g_access_unaccess_A_New() *A_arbace_a2g_access_unaccess_A { A_arbace_a2g_access_unaccess_A_Init(); t := &A_arbace_a2g_access_unaccess_A{}; t.Ctor(); return t }
//line :24:1
func (t *A_arbace_a2g_access_unaccess_A) Ctor() {}
//line :24:1
func (t *A_arbace_a2g_access_unaccess_A) Invoke_O_O__O(self, node__0 any) any { var temp__1927000408__auto____2 any; var and__1927000168__auto____2 bool; var tmp1 *lang.Keyword;


	A_arbace_a2g_access_A_Init(); tmp1 = A_arbace_a2g_access_A_const_19; var tmp2 any = tmp1.Ref(); var tmp3 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp3 = A_arbace_a2g_access_A_const_20; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(node__0)); if and__1927000168__auto____2 { var and__1927000168__auto____3 bool; var tmp4 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_21; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp6 = A_arbace_a2g_access_A_const_22; and__1927000168__auto____3 = lang.Util_Equiv_O_O__Z(tmp5, jrt.NN(tmp6).Invoke_O__O(node__0)); if and__1927000168__auto____3 { var tmp7 *lang.Var; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_23; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp9 = A_arbace_a2g_access_A_const_30; var tmp10 any = jrt.NN(tmp9).Invoke_O__O(node__0); var tmp11 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp11 = A_arbace_a2g_access_A_const_43; temp__1927000408__auto____2 = tmp8.Invoke_O_O__O(tmp10, jrt.NN(tmp11).Invoke_O__O(node__0)) } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____3).Ref() } } else { temp__1927000408__auto____2 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____2).Ref() }; if jrt.A2g_Truth(temp__1927000408__auto____2) { var acc__3 any = temp__1927000408__auto____2; var args__4 any; var tmp12 *lang.Keyword
		A_arbace_a2g_access_A_Init(); tmp12 = A_arbace_a2g_access_A_const_24; args__4 = jrt.NN(tmp12).Invoke_O__O(node__0)
//line :27:1
		var G__41000015__5_ any; var tmp13 *lang.Keyword

		A_arbace_a2g_access_A_Init(); tmp13 = A_arbace_a2g_access_A_const_25; G__41000015__5_ = jrt.NN(tmp13).Invoke_O__O(acc__3); switch lang.Util_Hash_O__I(G__41000015__5_) >> 4 & 15 { case 0: var tmp14 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp14 = A_arbace_a2g_access_A_const_26; if any(G__41000015__5_) == any(tmp14.Ref()) { var f__6 any; var tmp15 *lang.Var





			A_arbace_a2g_access_A_Init(); tmp15 = A_arbace_a2g_access_A_const_27; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp17 = A_arbace_a2g_access_A_const_30; var tmp18 any = jrt.NN(tmp17).Invoke_O__O(acc__3); var tmp19 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp19 = A_arbace_a2g_access_A_const_43; f__6 = tmp16.Invoke_O_O__O(tmp18, jrt.NN(tmp19).Invoke_O__O(acc__3))
//line :29:1
			var tmp20 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp20 = A_arbace_a2g_access_A_const_20; var tmp21 any = tmp20.Ref(); var tmp22 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp22 = A_arbace_a2g_access_A_const_28; var tmp23 any = tmp22.Ref(); var tmp24 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp24 = A_arbace_a2g_access_A_const_29; var tmp25 any = tmp24.Ref(); var tmp26 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp26 = A_arbace_a2g_access_A_const_30; var tmp27 any = tmp26.Ref(); var tmp28 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp28 = A_arbace_a2g_access_A_const_30; var tmp29 any = jrt.NN(tmp28).Invoke_O__O(f__6); var tmp30 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp30 = A_arbace_a2g_access_A_const_31; var tmp31 any = tmp30.Ref(); var tmp32 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp32 = A_arbace_a2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp21, tmp23, tmp25, f__6, tmp27, tmp29, tmp31, jrt.NN(tmp32).Invoke_O__O(f__6))) }; case 4: var tmp33 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp33 = A_arbace_a2g_access_A_const_33; if any(G__41000015__5_) == any(tmp33.Ref()) { var static_QMARK___6 bool; var tmp34 *lang.Keyword










				A_arbace_a2g_access_A_Init(); tmp34 = A_arbace_a2g_access_A_const_33; var tmp35 any = tmp34.Ref(); var tmp36 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp36 = A_arbace_a2g_access_A_const_25; static_QMARK___6 = lang.Util_Equiv_O_O__Z(tmp35, jrt.NN(tmp36).Invoke_O__O(acc__3))
//line :29:1
				var m__7 any; var tmp37 *lang.Var











				A_arbace_a2g_access_A_Init(); tmp37 = A_arbace_a2g_access_A_const_34; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 any = A_arbace_a2g_access_unaccess_fn__41000019_A_New_O(acc__3); var tmp40 *jrt.Class; A_arbace_a2g_access_unaccess_fn__41000019_A_Init(); tmp40 = A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class; var tmp41 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil); var tmp42 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp42 = A_arbace_a2g_access_A_const_53; var tmp43 *lang.Keyword = tmp42; var tmp44 *lang.Var; A_arbace_a2g_access_A_Init(); tmp44 = A_arbace_a2g_access_A_const_54; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp46 = A_arbace_a2g_access_A_const_30; m__7 = tmp38.Invoke_O_O__O(tmp41, jrt.NN(tmp43).Invoke_O__O(tmp45.Invoke_O__O(jrt.NN(tmp46).Invoke_O__O(acc__3))))
//line :29:1
				var m__8 any; var tmp47 *lang.Var













				A_arbace_a2g_access_A_Init(); tmp47 = A_arbace_a2g_access_A_const_35; var tmp48 lang.IFn = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()); var tmp49 any; var or__1927000174__auto____8 any = m__7; if jrt.A2g_Truth(or__1927000174__auto____8) { tmp49 = or__1927000174__auto____8 } else { var tmp50 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp50 = A_arbace_a2g_access_A_const_43; var tmp51 any = tmp50.Ref(); var tmp52 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp52 = A_arbace_a2g_access_A_const_43; var tmp53 any = jrt.NN(tmp52).Invoke_O__O(acc__3); var tmp54 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp54 = A_arbace_a2g_access_A_const_32; var tmp55 any = tmp54.Ref(); var tmp56 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp56 = A_arbace_a2g_access_A_const_32; var tmp57 any = jrt.NN(tmp56).Invoke_O__O(acc__3); var tmp58 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp58 = A_arbace_a2g_access_A_const_55; var tmp59 any = tmp58.Ref(); var tmp60 any; A_arbace_a2g_access_A_Init(); tmp60 = A_arbace_a2g_access_A_const_56; tmp49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp51, tmp53, tmp55, tmp57, tmp59, tmp60)) }; var tmp61 any = tmp49; var tmp62 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp62 = A_arbace_a2g_access_A_const_30; var tmp63 any = tmp62.Ref(); var tmp64 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp64 = A_arbace_a2g_access_A_const_30; m__8 = tmp48.Invoke_O_O_O__O(tmp61, tmp63, jrt.NN(tmp64).Invoke_O__O(acc__3))
//line :29:1
				var vec__41000016__9 any; var tmp65 *lang.Var














				A_arbace_a2g_access_A_Init(); tmp65 = A_arbace_a2g_access_A_const_36; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp67 = A_arbace_a2g_access_A_const_32; vec__41000016__9 = tmp66.Invoke_O__O(jrt.NN(tmp67).Invoke_O__O(acc__3))
//line :29:1
				var ___10 any = lang.RT_Nth_O_I_O__O(vec__41000016__9, lang.RT_IntCast_J__I(0), nil); var r__11 any = lang.RT_Nth_O_I_O__O(vec__41000016__9, lang.RT_IntCast_J__I(1), nil); var tmp68 *lang.Keyword; _ = ___10; A_arbace_a2g_access_A_Init(); tmp68 = A_arbace_a2g_access_A_const_20; var tmp69 any = tmp68.Ref(); var tmp70 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp70 = A_arbace_a2g_access_A_const_19; var tmp71 any = tmp70.Ref(); var tmp72 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp72 = A_arbace_a2g_access_A_const_22; var tmp73 any = tmp72.Ref(); var tmp74 *lang.Keyword; var G__41000021__12_ any; var tmp75 *lang.Keyword
















				A_arbace_a2g_access_A_Init(); tmp75 = A_arbace_a2g_access_A_const_25; G__41000021__12_ = jrt.NN(tmp75).Invoke_O__O(acc__3); L2: switch { default: switch lang.Util_Hash_O__I(G__41000021__12_) >> 10 & 3 { case 0: var tmp76 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp76 = A_arbace_a2g_access_A_const_37; if any(G__41000021__12_) == any(tmp76.Ref()) { A_arbace_a2g_access_A_Init(); tmp74 = A_arbace_a2g_access_A_const_38; break L2 }; case 1: var tmp77 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp77 = A_arbace_a2g_access_A_const_39; if any(G__41000021__12_) == any(tmp77.Ref()) { A_arbace_a2g_access_A_Init(); tmp74 = A_arbace_a2g_access_A_const_40; break L2 }; case 2: var tmp78 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp78 = A_arbace_a2g_access_A_const_33; if any(G__41000021__12_) == any(tmp78.Ref()) { A_arbace_a2g_access_A_Init(); tmp74 = A_arbace_a2g_access_A_const_21; break L2 }; default:}; A_arbace_a2g_access_A_Init(); tmp74 = A_arbace_a2g_access_A_const_41}
//line :29:1
				var tmp79 any = tmp74.Ref(); var tmp80 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp80 = A_arbace_a2g_access_A_const_30; var tmp81 any = tmp80.Ref(); var tmp82 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp82 = A_arbace_a2g_access_A_const_30; var tmp83 any = jrt.NN(tmp82).Invoke_O__O(acc__3); var tmp84 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp84 = A_arbace_a2g_access_A_const_42; var tmp85 any = tmp84.Ref(); var tmp86 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp86 = A_arbace_a2g_access_A_const_42; var tmp87 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp86).Invoke_O__O(acc__3))).Ref(); var tmp88 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp88 = A_arbace_a2g_access_A_const_43; var tmp89 any = tmp88.Ref(); var tmp90 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp90 = A_arbace_a2g_access_A_const_43; var tmp91 any = jrt.NN(tmp90).Invoke_O__O(acc__3); var tmp92 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp92 = A_arbace_a2g_access_A_const_32; var tmp93 any = tmp92.Ref(); var tmp94 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp94 = A_arbace_a2g_access_A_const_32; var tmp95 any = jrt.NN(tmp94).Invoke_O__O(acc__3); var tmp96 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp96 = A_arbace_a2g_access_A_const_44; var tmp97 any = tmp96.Ref(); var tmp98 any



















				if static_QMARK___6 { tmp98 = nil } else { var tmp99 *lang.Var; A_arbace_a2g_access_A_Init(); tmp99 = A_arbace_a2g_access_A_const_45; tmp98 = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
				var tmp100 any = tmp98; var tmp101 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp101 = A_arbace_a2g_access_A_const_24; var tmp102 any = tmp101.Ref(); var tmp103 *lang.Var; A_arbace_a2g_access_A_Init(); tmp103 = A_arbace_a2g_access_A_const_46; var tmp104 lang.IFn = lang.IFn_Cast(jrt.NN(tmp103).GetRawRoot__O()); var tmp105 any



















				if static_QMARK___6 { tmp105 = args__4 } else { var tmp106 *lang.Var; A_arbace_a2g_access_A_Init(); tmp106 = A_arbace_a2g_access_A_const_57; tmp105 = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
				var tmp107 any = tmp104.Invoke_O__O(tmp105); var tmp108 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp108 = A_arbace_a2g_access_A_const_31; var tmp109 any = tmp108.Ref(); var tmp110 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp110 = A_arbace_a2g_access_A_const_47; var tmp111 any = tmp110.Ref(); var tmp112 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp112 = A_arbace_a2g_access_A_const_48; var tmp113 any = tmp112.Ref(); var tmp114 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp114 = A_arbace_a2g_access_A_const_39; var tmp115 any = tmp114.Ref(); var tmp116 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp116 = A_arbace_a2g_access_A_const_25; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp69, tmp71, tmp73, tmp79, tmp81, tmp83, tmp85, tmp87, tmp89, tmp91, tmp93, tmp95, tmp97, tmp100, tmp102, tmp107, tmp109, r__11, tmp111, m__8, tmp113, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp115, jrt.NN(tmp116).Invoke_O__O(acc__3))).Ref())) }; case 6: var tmp117 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp117 = A_arbace_a2g_access_A_const_49; if any(G__41000015__5_) == any(tmp117.Ref()) { var f__6_2 any; var tmp118 *lang.Var







					A_arbace_a2g_access_A_Init(); tmp118 = A_arbace_a2g_access_A_const_27; var tmp119 lang.IFn = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()); var tmp120 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp120 = A_arbace_a2g_access_A_const_30; var tmp121 any = jrt.NN(tmp120).Invoke_O__O(acc__3); var tmp122 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp122 = A_arbace_a2g_access_A_const_43; f__6_2 = tmp119.Invoke_O_O__O(tmp121, jrt.NN(tmp122).Invoke_O__O(acc__3))
//line :29:1
					var tmp123 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp123 = A_arbace_a2g_access_A_const_20; var tmp124 any = tmp123.Ref(); var tmp125 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp125 = A_arbace_a2g_access_A_const_50; var tmp126 any = tmp125.Ref(); var tmp127 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp127 = A_arbace_a2g_access_A_const_29; var tmp128 any = tmp127.Ref(); var tmp129 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp129 = A_arbace_a2g_access_A_const_30; var tmp130 any = tmp129.Ref(); var tmp131 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp131 = A_arbace_a2g_access_A_const_30; var tmp132 any = jrt.NN(tmp131).Invoke_O__O(f__6_2); var tmp133 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp133 = A_arbace_a2g_access_A_const_51; var tmp134 any = tmp133.Ref(); var tmp135 *lang.Var; A_arbace_a2g_access_A_Init(); tmp135 = A_arbace_a2g_access_A_const_45; var tmp136 any = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()).Invoke_O__O(args__4); var tmp137 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp137 = A_arbace_a2g_access_A_const_31; var tmp138 any = tmp137.Ref(); var tmp139 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp139 = A_arbace_a2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp124, tmp126, tmp128, f__6_2, tmp130, tmp132, tmp134, tmp136, tmp138, jrt.NN(tmp139).Invoke_O__O(f__6_2))) }; case 8: var tmp140 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp140 = A_arbace_a2g_access_A_const_52; if any(G__41000015__5_) == any(tmp140.Ref()) { var static_QMARK___6_2 bool; var tmp141 *lang.Keyword










						A_arbace_a2g_access_A_Init(); tmp141 = A_arbace_a2g_access_A_const_33; var tmp142 any = tmp141.Ref(); var tmp143 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp143 = A_arbace_a2g_access_A_const_25; static_QMARK___6_2 = lang.Util_Equiv_O_O__Z(tmp142, jrt.NN(tmp143).Invoke_O__O(acc__3))
//line :29:1
						var m__7_2 any; var tmp144 *lang.Var











						A_arbace_a2g_access_A_Init(); tmp144 = A_arbace_a2g_access_A_const_34; var tmp145 lang.IFn = lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()); var tmp146 any = A_arbace_a2g_access_unaccess_fn__41000025_A_New_O(acc__3); var tmp147 *jrt.Class; A_arbace_a2g_access_unaccess_fn__41000025_A_Init(); tmp147 = A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class; var tmp148 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp146, tmp147, nil); var tmp149 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp149 = A_arbace_a2g_access_A_const_53; var tmp150 *lang.Keyword = tmp149; var tmp151 *lang.Var; A_arbace_a2g_access_A_Init(); tmp151 = A_arbace_a2g_access_A_const_54; var tmp152 lang.IFn = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()); var tmp153 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp153 = A_arbace_a2g_access_A_const_30; m__7_2 = tmp145.Invoke_O_O__O(tmp148, jrt.NN(tmp150).Invoke_O__O(tmp152.Invoke_O__O(jrt.NN(tmp153).Invoke_O__O(acc__3))))
//line :29:1
						var m__8_2 any; var tmp154 *lang.Var













						A_arbace_a2g_access_A_Init(); tmp154 = A_arbace_a2g_access_A_const_35; var tmp155 lang.IFn = lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()); var tmp156 any; var or__1927000174__auto____8_2 any = m__7_2; if jrt.A2g_Truth(or__1927000174__auto____8_2) { tmp156 = or__1927000174__auto____8_2 } else { var tmp157 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp157 = A_arbace_a2g_access_A_const_43; var tmp158 any = tmp157.Ref(); var tmp159 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp159 = A_arbace_a2g_access_A_const_43; var tmp160 any = jrt.NN(tmp159).Invoke_O__O(acc__3); var tmp161 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp161 = A_arbace_a2g_access_A_const_32; var tmp162 any = tmp161.Ref(); var tmp163 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp163 = A_arbace_a2g_access_A_const_32; var tmp164 any = jrt.NN(tmp163).Invoke_O__O(acc__3); var tmp165 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp165 = A_arbace_a2g_access_A_const_55; var tmp166 any = tmp165.Ref(); var tmp167 any; A_arbace_a2g_access_A_Init(); tmp167 = A_arbace_a2g_access_A_const_56; tmp156 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp158, tmp160, tmp162, tmp164, tmp166, tmp167)) }; var tmp168 any = tmp156; var tmp169 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp169 = A_arbace_a2g_access_A_const_30; var tmp170 any = tmp169.Ref(); var tmp171 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp171 = A_arbace_a2g_access_A_const_30; m__8_2 = tmp155.Invoke_O_O_O__O(tmp168, tmp170, jrt.NN(tmp171).Invoke_O__O(acc__3))
//line :29:1
						var vec__41000022__9 any; var tmp172 *lang.Var














						A_arbace_a2g_access_A_Init(); tmp172 = A_arbace_a2g_access_A_const_36; var tmp173 lang.IFn = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()); var tmp174 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp174 = A_arbace_a2g_access_A_const_32; vec__41000022__9 = tmp173.Invoke_O__O(jrt.NN(tmp174).Invoke_O__O(acc__3))
//line :29:1
						var ___10_2 any = lang.RT_Nth_O_I_O__O(vec__41000022__9, lang.RT_IntCast_J__I(0), nil); var r__11_2 any = lang.RT_Nth_O_I_O__O(vec__41000022__9, lang.RT_IntCast_J__I(1), nil); var tmp175 *lang.Keyword; _ = ___10_2; A_arbace_a2g_access_A_Init(); tmp175 = A_arbace_a2g_access_A_const_20; var tmp176 any = tmp175.Ref(); var tmp177 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp177 = A_arbace_a2g_access_A_const_19; var tmp178 any = tmp177.Ref(); var tmp179 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp179 = A_arbace_a2g_access_A_const_22; var tmp180 any = tmp179.Ref(); var tmp181 *lang.Keyword; var G__41000027__12_ any; var tmp182 *lang.Keyword
















						A_arbace_a2g_access_A_Init(); tmp182 = A_arbace_a2g_access_A_const_25; G__41000027__12_ = jrt.NN(tmp182).Invoke_O__O(acc__3); L3: switch { default: switch lang.Util_Hash_O__I(G__41000027__12_) >> 10 & 3 { case 0: var tmp183 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp183 = A_arbace_a2g_access_A_const_37; if any(G__41000027__12_) == any(tmp183.Ref()) { A_arbace_a2g_access_A_Init(); tmp181 = A_arbace_a2g_access_A_const_38; break L3 }; case 1: var tmp184 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp184 = A_arbace_a2g_access_A_const_39; if any(G__41000027__12_) == any(tmp184.Ref()) { A_arbace_a2g_access_A_Init(); tmp181 = A_arbace_a2g_access_A_const_40; break L3 }; case 2: var tmp185 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp185 = A_arbace_a2g_access_A_const_33; if any(G__41000027__12_) == any(tmp185.Ref()) { A_arbace_a2g_access_A_Init(); tmp181 = A_arbace_a2g_access_A_const_21; break L3 }; default:}; A_arbace_a2g_access_A_Init(); tmp181 = A_arbace_a2g_access_A_const_41}
//line :29:1
						var tmp186 any = tmp181.Ref(); var tmp187 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp187 = A_arbace_a2g_access_A_const_30; var tmp188 any = tmp187.Ref(); var tmp189 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp189 = A_arbace_a2g_access_A_const_30; var tmp190 any = jrt.NN(tmp189).Invoke_O__O(acc__3); var tmp191 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp191 = A_arbace_a2g_access_A_const_42; var tmp192 any = tmp191.Ref(); var tmp193 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp193 = A_arbace_a2g_access_A_const_42; var tmp194 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp193).Invoke_O__O(acc__3))).Ref(); var tmp195 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp195 = A_arbace_a2g_access_A_const_43; var tmp196 any = tmp195.Ref(); var tmp197 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp197 = A_arbace_a2g_access_A_const_43; var tmp198 any = jrt.NN(tmp197).Invoke_O__O(acc__3); var tmp199 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp199 = A_arbace_a2g_access_A_const_32; var tmp200 any = tmp199.Ref(); var tmp201 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp201 = A_arbace_a2g_access_A_const_32; var tmp202 any = jrt.NN(tmp201).Invoke_O__O(acc__3); var tmp203 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp203 = A_arbace_a2g_access_A_const_44; var tmp204 any = tmp203.Ref(); var tmp205 any



















						if static_QMARK___6_2 { tmp205 = nil } else { var tmp206 *lang.Var; A_arbace_a2g_access_A_Init(); tmp206 = A_arbace_a2g_access_A_const_45; tmp205 = lang.IFn_Cast(jrt.NN(tmp206).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
						var tmp207 any = tmp205; var tmp208 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp208 = A_arbace_a2g_access_A_const_24; var tmp209 any = tmp208.Ref(); var tmp210 *lang.Var; A_arbace_a2g_access_A_Init(); tmp210 = A_arbace_a2g_access_A_const_46; var tmp211 lang.IFn = lang.IFn_Cast(jrt.NN(tmp210).GetRawRoot__O()); var tmp212 any



















						if static_QMARK___6_2 { tmp212 = args__4 } else { var tmp213 *lang.Var; A_arbace_a2g_access_A_Init(); tmp213 = A_arbace_a2g_access_A_const_57; tmp212 = lang.IFn_Cast(jrt.NN(tmp213).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
						var tmp214 any = tmp211.Invoke_O__O(tmp212); var tmp215 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp215 = A_arbace_a2g_access_A_const_31; var tmp216 any = tmp215.Ref(); var tmp217 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp217 = A_arbace_a2g_access_A_const_47; var tmp218 any = tmp217.Ref(); var tmp219 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp219 = A_arbace_a2g_access_A_const_48; var tmp220 any = tmp219.Ref(); var tmp221 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp221 = A_arbace_a2g_access_A_const_39; var tmp222 any = tmp221.Ref(); var tmp223 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp223 = A_arbace_a2g_access_A_const_25; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp176, tmp178, tmp180, tmp186, tmp188, tmp190, tmp192, tmp194, tmp196, tmp198, tmp200, tmp202, tmp204, tmp207, tmp209, tmp214, tmp216, r__11_2, tmp218, m__8_2, tmp220, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp222, jrt.NN(tmp223).Invoke_O__O(acc__3))).Ref())) }; case 10: var tmp224 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp224 = A_arbace_a2g_access_A_const_58; if any(G__41000015__5_) == any(tmp224.Ref()) { var f__6_3 any; var tmp225 *lang.Var
							A_arbace_a2g_access_A_Init(); tmp225 = A_arbace_a2g_access_A_const_27; var tmp226 lang.IFn = lang.IFn_Cast(jrt.NN(tmp225).GetRawRoot__O()); var tmp227 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp227 = A_arbace_a2g_access_A_const_30; var tmp228 any = jrt.NN(tmp227).Invoke_O__O(acc__3); var tmp229 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp229 = A_arbace_a2g_access_A_const_43; f__6_3 = tmp226.Invoke_O_O__O(tmp228, jrt.NN(tmp229).Invoke_O__O(acc__3))
//line :29:1
							var tmp230 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp230 = A_arbace_a2g_access_A_const_20; var tmp231 any = tmp230.Ref(); var tmp232 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp232 = A_arbace_a2g_access_A_const_59; var tmp233 any = tmp232.Ref(); var tmp234 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp234 = A_arbace_a2g_access_A_const_29; var tmp235 any = tmp234.Ref(); var tmp236 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp236 = A_arbace_a2g_access_A_const_30; var tmp237 any = tmp236.Ref(); var tmp238 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp238 = A_arbace_a2g_access_A_const_30; var tmp239 any = jrt.NN(tmp238).Invoke_O__O(f__6_3); var tmp240 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp240 = A_arbace_a2g_access_A_const_44; var tmp241 any = tmp240.Ref(); var tmp242 *lang.Var; A_arbace_a2g_access_A_Init(); tmp242 = A_arbace_a2g_access_A_const_45; var tmp243 any = lang.IFn_Cast(jrt.NN(tmp242).GetRawRoot__O()).Invoke_O__O(args__4); var tmp244 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp244 = A_arbace_a2g_access_A_const_31; var tmp245 any = tmp244.Ref(); var tmp246 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp246 = A_arbace_a2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp231, tmp233, tmp235, f__6_3, tmp237, tmp239, tmp241, tmp243, tmp245, jrt.NN(tmp246).Invoke_O__O(f__6_3))) }; case 11: var tmp247 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp247 = A_arbace_a2g_access_A_const_60; if any(G__41000015__5_) == any(tmp247.Ref()) { var f__6_4 any; var tmp248 *lang.Var


								A_arbace_a2g_access_A_Init(); tmp248 = A_arbace_a2g_access_A_const_27; var tmp249 lang.IFn = lang.IFn_Cast(jrt.NN(tmp248).GetRawRoot__O()); var tmp250 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp250 = A_arbace_a2g_access_A_const_30; var tmp251 any = jrt.NN(tmp250).Invoke_O__O(acc__3); var tmp252 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp252 = A_arbace_a2g_access_A_const_43; f__6_4 = tmp249.Invoke_O_O__O(tmp251, jrt.NN(tmp252).Invoke_O__O(acc__3))
//line :29:1
								var tmp253 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp253 = A_arbace_a2g_access_A_const_20; var tmp254 any = tmp253.Ref(); var tmp255 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp255 = A_arbace_a2g_access_A_const_61; var tmp256 any = tmp255.Ref(); var tmp257 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp257 = A_arbace_a2g_access_A_const_29; var tmp258 any = tmp257.Ref(); var tmp259 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp259 = A_arbace_a2g_access_A_const_30; var tmp260 any = tmp259.Ref(); var tmp261 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp261 = A_arbace_a2g_access_A_const_30; var tmp262 any = jrt.NN(tmp261).Invoke_O__O(f__6_4); var tmp263 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp263 = A_arbace_a2g_access_A_const_44; var tmp264 any = tmp263.Ref(); var tmp265 *lang.Var; A_arbace_a2g_access_A_Init(); tmp265 = A_arbace_a2g_access_A_const_45; var tmp266 any = lang.IFn_Cast(jrt.NN(tmp265).GetRawRoot__O()).Invoke_O__O(args__4); var tmp267 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp267 = A_arbace_a2g_access_A_const_51; var tmp268 any = tmp267.Ref(); var tmp269 *lang.Var; A_arbace_a2g_access_A_Init(); tmp269 = A_arbace_a2g_access_A_const_62; var tmp270 any = lang.IFn_Cast(jrt.NN(tmp269).GetRawRoot__O()).Invoke_O__O(args__4); var tmp271 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp271 = A_arbace_a2g_access_A_const_31; var tmp272 any = tmp271.Ref(); var tmp273 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp273 = A_arbace_a2g_access_A_const_32; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp254, tmp256, tmp258, f__6_4, tmp260, tmp262, tmp264, tmp266, tmp268, tmp270, tmp272, jrt.NN(tmp273).Invoke_O__O(f__6_4))) }; case 12: var tmp274 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp274 = A_arbace_a2g_access_A_const_39; if any(G__41000015__5_) == any(tmp274.Ref()) { var static_QMARK___6_3 bool; var tmp275 *lang.Keyword










									A_arbace_a2g_access_A_Init(); tmp275 = A_arbace_a2g_access_A_const_33; var tmp276 any = tmp275.Ref(); var tmp277 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp277 = A_arbace_a2g_access_A_const_25; static_QMARK___6_3 = lang.Util_Equiv_O_O__Z(tmp276, jrt.NN(tmp277).Invoke_O__O(acc__3))
//line :29:1
									var m__7_3 any; var tmp278 *lang.Var











									A_arbace_a2g_access_A_Init(); tmp278 = A_arbace_a2g_access_A_const_34; var tmp279 lang.IFn = lang.IFn_Cast(jrt.NN(tmp278).GetRawRoot__O()); var tmp280 any = A_arbace_a2g_access_unaccess_fn__41000031_A_New_O(acc__3); var tmp281 *jrt.Class; A_arbace_a2g_access_unaccess_fn__41000031_A_Init(); tmp281 = A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class; var tmp282 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp280, tmp281, nil); var tmp283 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp283 = A_arbace_a2g_access_A_const_53; var tmp284 *lang.Keyword = tmp283; var tmp285 *lang.Var; A_arbace_a2g_access_A_Init(); tmp285 = A_arbace_a2g_access_A_const_54; var tmp286 lang.IFn = lang.IFn_Cast(jrt.NN(tmp285).GetRawRoot__O()); var tmp287 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp287 = A_arbace_a2g_access_A_const_30; m__7_3 = tmp279.Invoke_O_O__O(tmp282, jrt.NN(tmp284).Invoke_O__O(tmp286.Invoke_O__O(jrt.NN(tmp287).Invoke_O__O(acc__3))))
//line :29:1
									var m__8_3 any; var tmp288 *lang.Var













									A_arbace_a2g_access_A_Init(); tmp288 = A_arbace_a2g_access_A_const_35; var tmp289 lang.IFn = lang.IFn_Cast(jrt.NN(tmp288).GetRawRoot__O()); var tmp290 any; var or__1927000174__auto____8_3 any = m__7_3; if jrt.A2g_Truth(or__1927000174__auto____8_3) { tmp290 = or__1927000174__auto____8_3 } else { var tmp291 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp291 = A_arbace_a2g_access_A_const_43; var tmp292 any = tmp291.Ref(); var tmp293 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp293 = A_arbace_a2g_access_A_const_43; var tmp294 any = jrt.NN(tmp293).Invoke_O__O(acc__3); var tmp295 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp295 = A_arbace_a2g_access_A_const_32; var tmp296 any = tmp295.Ref(); var tmp297 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp297 = A_arbace_a2g_access_A_const_32; var tmp298 any = jrt.NN(tmp297).Invoke_O__O(acc__3); var tmp299 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp299 = A_arbace_a2g_access_A_const_55; var tmp300 any = tmp299.Ref(); var tmp301 any; A_arbace_a2g_access_A_Init(); tmp301 = A_arbace_a2g_access_A_const_56; tmp290 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp292, tmp294, tmp296, tmp298, tmp300, tmp301)) }; var tmp302 any = tmp290; var tmp303 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp303 = A_arbace_a2g_access_A_const_30; var tmp304 any = tmp303.Ref(); var tmp305 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp305 = A_arbace_a2g_access_A_const_30; m__8_3 = tmp289.Invoke_O_O_O__O(tmp302, tmp304, jrt.NN(tmp305).Invoke_O__O(acc__3))
//line :29:1
									var vec__41000028__9 any; var tmp306 *lang.Var














									A_arbace_a2g_access_A_Init(); tmp306 = A_arbace_a2g_access_A_const_36; var tmp307 lang.IFn = lang.IFn_Cast(jrt.NN(tmp306).GetRawRoot__O()); var tmp308 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp308 = A_arbace_a2g_access_A_const_32; vec__41000028__9 = tmp307.Invoke_O__O(jrt.NN(tmp308).Invoke_O__O(acc__3))
//line :29:1
									var ___10_3 any = lang.RT_Nth_O_I_O__O(vec__41000028__9, lang.RT_IntCast_J__I(0), nil); var r__11_3 any = lang.RT_Nth_O_I_O__O(vec__41000028__9, lang.RT_IntCast_J__I(1), nil); var tmp309 *lang.Keyword; _ = ___10_3; A_arbace_a2g_access_A_Init(); tmp309 = A_arbace_a2g_access_A_const_20; var tmp310 any = tmp309.Ref(); var tmp311 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp311 = A_arbace_a2g_access_A_const_19; var tmp312 any = tmp311.Ref(); var tmp313 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp313 = A_arbace_a2g_access_A_const_22; var tmp314 any = tmp313.Ref(); var tmp315 *lang.Keyword; var G__41000033__12_ any; var tmp316 *lang.Keyword
















									A_arbace_a2g_access_A_Init(); tmp316 = A_arbace_a2g_access_A_const_25; G__41000033__12_ = jrt.NN(tmp316).Invoke_O__O(acc__3); L4: switch { default: switch lang.Util_Hash_O__I(G__41000033__12_) >> 10 & 3 { case 0: var tmp317 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp317 = A_arbace_a2g_access_A_const_37; if any(G__41000033__12_) == any(tmp317.Ref()) { A_arbace_a2g_access_A_Init(); tmp315 = A_arbace_a2g_access_A_const_38; break L4 }; case 1: var tmp318 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp318 = A_arbace_a2g_access_A_const_39; if any(G__41000033__12_) == any(tmp318.Ref()) { A_arbace_a2g_access_A_Init(); tmp315 = A_arbace_a2g_access_A_const_40; break L4 }; case 2: var tmp319 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp319 = A_arbace_a2g_access_A_const_33; if any(G__41000033__12_) == any(tmp319.Ref()) { A_arbace_a2g_access_A_Init(); tmp315 = A_arbace_a2g_access_A_const_21; break L4 }; default:}; A_arbace_a2g_access_A_Init(); tmp315 = A_arbace_a2g_access_A_const_41}
//line :29:1
									var tmp320 any = tmp315.Ref(); var tmp321 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp321 = A_arbace_a2g_access_A_const_30; var tmp322 any = tmp321.Ref(); var tmp323 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp323 = A_arbace_a2g_access_A_const_30; var tmp324 any = jrt.NN(tmp323).Invoke_O__O(acc__3); var tmp325 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp325 = A_arbace_a2g_access_A_const_42; var tmp326 any = tmp325.Ref(); var tmp327 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp327 = A_arbace_a2g_access_A_const_42; var tmp328 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp327).Invoke_O__O(acc__3))).Ref(); var tmp329 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp329 = A_arbace_a2g_access_A_const_43; var tmp330 any = tmp329.Ref(); var tmp331 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp331 = A_arbace_a2g_access_A_const_43; var tmp332 any = jrt.NN(tmp331).Invoke_O__O(acc__3); var tmp333 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp333 = A_arbace_a2g_access_A_const_32; var tmp334 any = tmp333.Ref(); var tmp335 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp335 = A_arbace_a2g_access_A_const_32; var tmp336 any = jrt.NN(tmp335).Invoke_O__O(acc__3); var tmp337 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp337 = A_arbace_a2g_access_A_const_44; var tmp338 any = tmp337.Ref(); var tmp339 any



















									if static_QMARK___6_3 { tmp339 = nil } else { var tmp340 *lang.Var; A_arbace_a2g_access_A_Init(); tmp340 = A_arbace_a2g_access_A_const_45; tmp339 = lang.IFn_Cast(jrt.NN(tmp340).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
									var tmp341 any = tmp339; var tmp342 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp342 = A_arbace_a2g_access_A_const_24; var tmp343 any = tmp342.Ref(); var tmp344 *lang.Var; A_arbace_a2g_access_A_Init(); tmp344 = A_arbace_a2g_access_A_const_46; var tmp345 lang.IFn = lang.IFn_Cast(jrt.NN(tmp344).GetRawRoot__O()); var tmp346 any



















									if static_QMARK___6_3 { tmp346 = args__4 } else { var tmp347 *lang.Var; A_arbace_a2g_access_A_Init(); tmp347 = A_arbace_a2g_access_A_const_57; tmp346 = lang.IFn_Cast(jrt.NN(tmp347).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
									var tmp348 any = tmp345.Invoke_O__O(tmp346); var tmp349 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp349 = A_arbace_a2g_access_A_const_31; var tmp350 any = tmp349.Ref(); var tmp351 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp351 = A_arbace_a2g_access_A_const_47; var tmp352 any = tmp351.Ref(); var tmp353 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp353 = A_arbace_a2g_access_A_const_48; var tmp354 any = tmp353.Ref(); var tmp355 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp355 = A_arbace_a2g_access_A_const_39; var tmp356 any = tmp355.Ref(); var tmp357 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp357 = A_arbace_a2g_access_A_const_25; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp310, tmp312, tmp314, tmp320, tmp322, tmp324, tmp326, tmp328, tmp330, tmp332, tmp334, tmp336, tmp338, tmp341, tmp343, tmp348, tmp350, r__11_3, tmp352, m__8_3, tmp354, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp356, jrt.NN(tmp357).Invoke_O__O(acc__3))).Ref())) }; case 14: var tmp358 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp358 = A_arbace_a2g_access_A_const_37; if any(G__41000015__5_) == any(tmp358.Ref()) { var static_QMARK___6_4 bool; var tmp359 *lang.Keyword










										A_arbace_a2g_access_A_Init(); tmp359 = A_arbace_a2g_access_A_const_33; var tmp360 any = tmp359.Ref(); var tmp361 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp361 = A_arbace_a2g_access_A_const_25; static_QMARK___6_4 = lang.Util_Equiv_O_O__Z(tmp360, jrt.NN(tmp361).Invoke_O__O(acc__3))
//line :29:1
										var m__7_4 any; var tmp362 *lang.Var











										A_arbace_a2g_access_A_Init(); tmp362 = A_arbace_a2g_access_A_const_34; var tmp363 lang.IFn = lang.IFn_Cast(jrt.NN(tmp362).GetRawRoot__O()); var tmp364 any = A_arbace_a2g_access_unaccess_fn__41000037_A_New_O(acc__3); var tmp365 *jrt.Class; A_arbace_a2g_access_unaccess_fn__41000037_A_Init(); tmp365 = A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class; var tmp366 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp364, tmp365, nil); var tmp367 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp367 = A_arbace_a2g_access_A_const_53; var tmp368 *lang.Keyword = tmp367; var tmp369 *lang.Var; A_arbace_a2g_access_A_Init(); tmp369 = A_arbace_a2g_access_A_const_54; var tmp370 lang.IFn = lang.IFn_Cast(jrt.NN(tmp369).GetRawRoot__O()); var tmp371 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp371 = A_arbace_a2g_access_A_const_30; m__7_4 = tmp363.Invoke_O_O__O(tmp366, jrt.NN(tmp368).Invoke_O__O(tmp370.Invoke_O__O(jrt.NN(tmp371).Invoke_O__O(acc__3))))
//line :29:1
										var m__8_4 any; var tmp372 *lang.Var













										A_arbace_a2g_access_A_Init(); tmp372 = A_arbace_a2g_access_A_const_35; var tmp373 lang.IFn = lang.IFn_Cast(jrt.NN(tmp372).GetRawRoot__O()); var tmp374 any; var or__1927000174__auto____8_4 any = m__7_4; if jrt.A2g_Truth(or__1927000174__auto____8_4) { tmp374 = or__1927000174__auto____8_4 } else { var tmp375 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp375 = A_arbace_a2g_access_A_const_43; var tmp376 any = tmp375.Ref(); var tmp377 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp377 = A_arbace_a2g_access_A_const_43; var tmp378 any = jrt.NN(tmp377).Invoke_O__O(acc__3); var tmp379 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp379 = A_arbace_a2g_access_A_const_32; var tmp380 any = tmp379.Ref(); var tmp381 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp381 = A_arbace_a2g_access_A_const_32; var tmp382 any = jrt.NN(tmp381).Invoke_O__O(acc__3); var tmp383 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp383 = A_arbace_a2g_access_A_const_55; var tmp384 any = tmp383.Ref(); var tmp385 any; A_arbace_a2g_access_A_Init(); tmp385 = A_arbace_a2g_access_A_const_56; tmp374 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp376, tmp378, tmp380, tmp382, tmp384, tmp385)) }; var tmp386 any = tmp374; var tmp387 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp387 = A_arbace_a2g_access_A_const_30; var tmp388 any = tmp387.Ref(); var tmp389 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp389 = A_arbace_a2g_access_A_const_30; m__8_4 = tmp373.Invoke_O_O_O__O(tmp386, tmp388, jrt.NN(tmp389).Invoke_O__O(acc__3))
//line :29:1
										var vec__41000034__9 any; var tmp390 *lang.Var














										A_arbace_a2g_access_A_Init(); tmp390 = A_arbace_a2g_access_A_const_36; var tmp391 lang.IFn = lang.IFn_Cast(jrt.NN(tmp390).GetRawRoot__O()); var tmp392 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp392 = A_arbace_a2g_access_A_const_32; vec__41000034__9 = tmp391.Invoke_O__O(jrt.NN(tmp392).Invoke_O__O(acc__3))
//line :29:1
										var ___10_4 any = lang.RT_Nth_O_I_O__O(vec__41000034__9, lang.RT_IntCast_J__I(0), nil); var r__11_4 any = lang.RT_Nth_O_I_O__O(vec__41000034__9, lang.RT_IntCast_J__I(1), nil); var tmp393 *lang.Keyword; _ = ___10_4; A_arbace_a2g_access_A_Init(); tmp393 = A_arbace_a2g_access_A_const_20; var tmp394 any = tmp393.Ref(); var tmp395 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp395 = A_arbace_a2g_access_A_const_19; var tmp396 any = tmp395.Ref(); var tmp397 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp397 = A_arbace_a2g_access_A_const_22; var tmp398 any = tmp397.Ref(); var tmp399 *lang.Keyword; var G__41000039__12_ any; var tmp400 *lang.Keyword
















										A_arbace_a2g_access_A_Init(); tmp400 = A_arbace_a2g_access_A_const_25; G__41000039__12_ = jrt.NN(tmp400).Invoke_O__O(acc__3); L5: switch { default: switch lang.Util_Hash_O__I(G__41000039__12_) >> 10 & 3 { case 0: var tmp401 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp401 = A_arbace_a2g_access_A_const_37; if any(G__41000039__12_) == any(tmp401.Ref()) { A_arbace_a2g_access_A_Init(); tmp399 = A_arbace_a2g_access_A_const_38; break L5 }; case 1: var tmp402 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp402 = A_arbace_a2g_access_A_const_39; if any(G__41000039__12_) == any(tmp402.Ref()) { A_arbace_a2g_access_A_Init(); tmp399 = A_arbace_a2g_access_A_const_40; break L5 }; case 2: var tmp403 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp403 = A_arbace_a2g_access_A_const_33; if any(G__41000039__12_) == any(tmp403.Ref()) { A_arbace_a2g_access_A_Init(); tmp399 = A_arbace_a2g_access_A_const_21; break L5 }; default:}; A_arbace_a2g_access_A_Init(); tmp399 = A_arbace_a2g_access_A_const_41}
//line :29:1
										var tmp404 any = tmp399.Ref(); var tmp405 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp405 = A_arbace_a2g_access_A_const_30; var tmp406 any = tmp405.Ref(); var tmp407 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp407 = A_arbace_a2g_access_A_const_30; var tmp408 any = jrt.NN(tmp407).Invoke_O__O(acc__3); var tmp409 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp409 = A_arbace_a2g_access_A_const_42; var tmp410 any = tmp409.Ref(); var tmp411 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp411 = A_arbace_a2g_access_A_const_42; var tmp412 any = jrt.Boolean_ValueOf_Z__Boolean(lang.RT_BooleanCast_O__Z(jrt.NN(tmp411).Invoke_O__O(acc__3))).Ref(); var tmp413 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp413 = A_arbace_a2g_access_A_const_43; var tmp414 any = tmp413.Ref(); var tmp415 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp415 = A_arbace_a2g_access_A_const_43; var tmp416 any = jrt.NN(tmp415).Invoke_O__O(acc__3); var tmp417 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp417 = A_arbace_a2g_access_A_const_32; var tmp418 any = tmp417.Ref(); var tmp419 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp419 = A_arbace_a2g_access_A_const_32; var tmp420 any = jrt.NN(tmp419).Invoke_O__O(acc__3); var tmp421 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp421 = A_arbace_a2g_access_A_const_44; var tmp422 any = tmp421.Ref(); var tmp423 any



















										if static_QMARK___6_4 { tmp423 = nil } else { var tmp424 *lang.Var; A_arbace_a2g_access_A_Init(); tmp424 = A_arbace_a2g_access_A_const_45; tmp423 = lang.IFn_Cast(jrt.NN(tmp424).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
										var tmp425 any = tmp423; var tmp426 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp426 = A_arbace_a2g_access_A_const_24; var tmp427 any = tmp426.Ref(); var tmp428 *lang.Var; A_arbace_a2g_access_A_Init(); tmp428 = A_arbace_a2g_access_A_const_46; var tmp429 lang.IFn = lang.IFn_Cast(jrt.NN(tmp428).GetRawRoot__O()); var tmp430 any



















										if static_QMARK___6_4 { tmp430 = args__4 } else { var tmp431 *lang.Var; A_arbace_a2g_access_A_Init(); tmp431 = A_arbace_a2g_access_A_const_57; tmp430 = lang.IFn_Cast(jrt.NN(tmp431).GetRawRoot__O()).Invoke_O__O(args__4) }
//line :29:1
										var tmp432 any = tmp429.Invoke_O__O(tmp430); var tmp433 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp433 = A_arbace_a2g_access_A_const_31; var tmp434 any = tmp433.Ref(); var tmp435 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp435 = A_arbace_a2g_access_A_const_47; var tmp436 any = tmp435.Ref(); var tmp437 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp437 = A_arbace_a2g_access_A_const_48; var tmp438 any = tmp437.Ref(); var tmp439 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp439 = A_arbace_a2g_access_A_const_39; var tmp440 any = tmp439.Ref(); var tmp441 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp441 = A_arbace_a2g_access_A_const_25; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp394, tmp396, tmp398, tmp404, tmp406, tmp408, tmp410, tmp412, tmp414, tmp416, tmp418, tmp420, tmp422, tmp425, tmp427, tmp432, tmp434, r__11_4, tmp436, m__8_4, tmp438, jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(tmp440, jrt.NN(tmp441).Invoke_O__O(acc__3))).Ref())) }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_76, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__41000015__5_))))) } else {
//line :27:1
											return node__0 } }













func A_arbace_a2g_access_unaccess_fn__41000019_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000019_A { A_arbace_a2g_access_unaccess_fn__41000019_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000019_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp2 = A_arbace_a2g_access_A_const_43; var tmp3 any = jrt.NN(tmp2).Invoke_O__O(t.F_acc); var tmp4 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_43; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { var tmp5 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp5 = A_arbace_a2g_access_A_const_32; var tmp6 any = jrt.NN(tmp5).Invoke_O__O(t.F_acc); var tmp7 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_32; tmp1 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_a2g_access_unaccess_fn__41000025_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000025_A { A_arbace_a2g_access_unaccess_fn__41000025_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000025_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp2 = A_arbace_a2g_access_A_const_43; var tmp3 any = jrt.NN(tmp2).Invoke_O__O(t.F_acc); var tmp4 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_43; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { var tmp5 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp5 = A_arbace_a2g_access_A_const_32; var tmp6 any = jrt.NN(tmp5).Invoke_O__O(t.F_acc); var tmp7 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_32; tmp1 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_a2g_access_unaccess_fn__41000031_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000031_A { A_arbace_a2g_access_unaccess_fn__41000031_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000031_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp2 = A_arbace_a2g_access_A_const_43; var tmp3 any = jrt.NN(tmp2).Invoke_O__O(t.F_acc); var tmp4 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_43; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { var tmp5 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp5 = A_arbace_a2g_access_A_const_32; var tmp6 any = jrt.NN(tmp5).Invoke_O__O(t.F_acc); var tmp7 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_32; tmp1 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }
//line :41:1
func A_arbace_a2g_access_unaccess_fn__41000037_A_New_O(p0 any) *A_arbace_a2g_access_unaccess_fn__41000037_A { A_arbace_a2g_access_unaccess_fn__41000037_A_Init(); t := &A_arbace_a2g_access_unaccess_fn__41000037_A{}; t.Ctor_O(p0); return t }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :41:1
func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Invoke_O_O__O(self, p1__41000014_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp2 = A_arbace_a2g_access_A_const_43; var tmp3 any = jrt.NN(tmp2).Invoke_O__O(t.F_acc); var tmp4 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp4 = A_arbace_a2g_access_A_const_43; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp3, jrt.NN(tmp4).Invoke_O__O(p1__41000014_SHARP___1)); if and__1927000168__auto____2 { var tmp5 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp5 = A_arbace_a2g_access_A_const_32; var tmp6 any = jrt.NN(tmp5).Invoke_O__O(t.F_acc); var tmp7 *lang.Keyword; A_arbace_a2g_access_A_Init(); tmp7 = A_arbace_a2g_access_A_const_32; tmp1 = lang.Util_Equiv_O_O__Z(tmp6, jrt.NN(tmp7).Invoke_O__O(p1__41000014_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__41000014_SHARP___1 } else { return nil } }

























type A_arbace_a2g_access_A struct{ jrt.Object }

var A_arbace_a2g_access_A_const_0 *lang.Var

var A_arbace_a2g_access_A_const_1 *lang.Var

var A_arbace_a2g_access_A_const_2 any

var A_arbace_a2g_access_A_const_3 any

var A_arbace_a2g_access_A_const_4 any

var A_arbace_a2g_access_A_const_5 any

var A_arbace_a2g_access_A_const_6 any

var A_arbace_a2g_access_A_const_7 *lang.Var

var A_arbace_a2g_access_A_const_8 *lang.Var

var A_arbace_a2g_access_A_const_9 *lang.Var

var A_arbace_a2g_access_A_const_10 any

var A_arbace_a2g_access_A_const_11 *lang.Var

var A_arbace_a2g_access_A_const_12 *lang.Var

var A_arbace_a2g_access_A_const_13 *lang.Var

var A_arbace_a2g_access_A_const_14 *lang.Var

var A_arbace_a2g_access_A_const_15 *lang.Keyword

var A_arbace_a2g_access_A_const_16 *lang.Var

var A_arbace_a2g_access_A_const_17 *lang.Var

var A_arbace_a2g_access_A_const_18 *lang.Var

var A_arbace_a2g_access_A_const_19 *lang.Keyword

var A_arbace_a2g_access_A_const_20 *lang.Keyword

var A_arbace_a2g_access_A_const_21 *lang.Keyword

var A_arbace_a2g_access_A_const_22 *lang.Keyword

var A_arbace_a2g_access_A_const_23 *lang.Var

var A_arbace_a2g_access_A_const_24 *lang.Keyword

var A_arbace_a2g_access_A_const_25 *lang.Keyword

var A_arbace_a2g_access_A_const_26 *lang.Keyword

var A_arbace_a2g_access_A_const_27 *lang.Var

var A_arbace_a2g_access_A_const_28 *lang.Keyword

var A_arbace_a2g_access_A_const_29 *lang.Keyword

var A_arbace_a2g_access_A_const_30 *lang.Keyword

var A_arbace_a2g_access_A_const_31 *lang.Keyword

var A_arbace_a2g_access_A_const_32 *lang.Keyword

var A_arbace_a2g_access_A_const_33 *lang.Keyword

var A_arbace_a2g_access_A_const_34 *lang.Var

var A_arbace_a2g_access_A_const_35 *lang.Var

var A_arbace_a2g_access_A_const_36 *lang.Var

var A_arbace_a2g_access_A_const_37 *lang.Keyword

var A_arbace_a2g_access_A_const_38 *lang.Keyword

var A_arbace_a2g_access_A_const_39 *lang.Keyword

var A_arbace_a2g_access_A_const_40 *lang.Keyword

var A_arbace_a2g_access_A_const_41 *lang.Keyword

var A_arbace_a2g_access_A_const_42 *lang.Keyword

var A_arbace_a2g_access_A_const_43 *lang.Keyword

var A_arbace_a2g_access_A_const_44 *lang.Keyword

var A_arbace_a2g_access_A_const_45 *lang.Var

var A_arbace_a2g_access_A_const_46 *lang.Var

var A_arbace_a2g_access_A_const_47 *lang.Keyword

var A_arbace_a2g_access_A_const_48 *lang.Keyword

var A_arbace_a2g_access_A_const_49 *lang.Keyword

var A_arbace_a2g_access_A_const_50 *lang.Keyword

var A_arbace_a2g_access_A_const_51 *lang.Keyword

var A_arbace_a2g_access_A_const_52 *lang.Keyword

var A_arbace_a2g_access_A_const_53 *lang.Keyword

var A_arbace_a2g_access_A_const_54 *lang.Var

var A_arbace_a2g_access_A_const_55 *lang.Keyword

var A_arbace_a2g_access_A_const_56 any

var A_arbace_a2g_access_A_const_57 *lang.Var

var A_arbace_a2g_access_A_const_58 *lang.Keyword

var A_arbace_a2g_access_A_const_59 *lang.Keyword

var A_arbace_a2g_access_A_const_60 *lang.Keyword

var A_arbace_a2g_access_A_const_61 *lang.Keyword

var A_arbace_a2g_access_A_const_62 *lang.Var

var A_arbace_a2g_access_A_init jrt.ClassInit

func A_arbace_a2g_access_A_Init() { if !A_arbace_a2g_access_A_init.Done() { A_arbace_a2g_access_A_init.Run(A_arbace_a2g_access_A_clinit) } }

func A_arbace_a2g_access_A_clinit() { A_arbace_a2g_access_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_access_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_access_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_access_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_access_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_access_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_access_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_access_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_12); A_arbace_a2g_access_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_13); A_arbace_a2g_access_A_const_9 = lang.RT_Var_String_String__Var(Lit_0, Lit_14); A_arbace_a2g_access_A_const_10 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_15)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_16).Ref(), Lit_17))); A_arbace_a2g_access_A_const_11 = lang.RT_Var_String_String__Var(Lit_0, Lit_18); A_arbace_a2g_access_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_19); A_arbace_a2g_access_A_const_13 = lang.RT_Var_String_String__Var(Lit_3, Lit_20); A_arbace_a2g_access_A_const_14 = lang.RT_Var_String_String__Var(Lit_10, Lit_21); A_arbace_a2g_access_A_const_15 = lang.RT_Keyword_String_String__Keyword(nil, Lit_22); A_arbace_a2g_access_A_const_16 = lang.RT_Var_String_String__Var(Lit_10, Lit_23); A_arbace_a2g_access_A_const_17 = lang.RT_Var_String_String__Var(Lit_8, Lit_24); A_arbace_a2g_access_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_25); A_arbace_a2g_access_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_26); A_arbace_a2g_access_A_const_20 = lang.RT_Keyword_String_String__Keyword(nil, Lit_27); A_arbace_a2g_access_A_const_21 = lang.RT_Keyword_String_String__Keyword(nil, Lit_28); A_arbace_a2g_access_A_const_22 = lang.RT_Keyword_String_String__Keyword(nil, Lit_29); A_arbace_a2g_access_A_const_23 = lang.RT_Var_String_String__Var(Lit_15, Lit_30); A_arbace_a2g_access_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_a2g_access_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_32); A_arbace_a2g_access_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_33); A_arbace_a2g_access_A_const_27 = lang.RT_Var_String_String__Var(Lit_15, Lit_24); A_arbace_a2g_access_A_const_28 = lang.RT_Keyword_String_String__Keyword(nil, Lit_34); A_arbace_a2g_access_A_const_29 = lang.RT_Keyword_String_String__Keyword(nil, Lit_35); A_arbace_a2g_access_A_const_30 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_a2g_access_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_a2g_access_A_const_32 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_a2g_access_A_const_33 = lang.RT_Keyword_String_String__Keyword(nil, Lit_39); A_arbace_a2g_access_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_40); A_arbace_a2g_access_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_a2g_access_A_const_36 = lang.RT_Var_String_String__Var(Lit_6, Lit_42); A_arbace_a2g_access_A_const_37 = lang.RT_Keyword_String_String__Keyword(nil, Lit_43); A_arbace_a2g_access_A_const_38 = lang.RT_Keyword_String_String__Keyword(nil, Lit_44); A_arbace_a2g_access_A_const_39 = lang.RT_Keyword_String_String__Keyword(nil, Lit_45); A_arbace_a2g_access_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_a2g_access_A_const_41 = lang.RT_Keyword_String_String__Keyword(nil, Lit_47); A_arbace_a2g_access_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_48); A_arbace_a2g_access_A_const_43 = lang.RT_Keyword_String_String__Keyword(nil, Lit_49); A_arbace_a2g_access_A_const_44 = lang.RT_Keyword_String_String__Keyword(nil, Lit_50); A_arbace_a2g_access_A_const_45 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_a2g_access_A_const_46 = lang.RT_Var_String_String__Var(Lit_0, Lit_52); A_arbace_a2g_access_A_const_47 = lang.RT_Keyword_String_String__Keyword(nil, Lit_53); A_arbace_a2g_access_A_const_48 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_a2g_access_A_const_49 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_a2g_access_A_const_50 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_a2g_access_A_const_51 = lang.RT_Keyword_String_String__Keyword(nil, Lit_57); A_arbace_a2g_access_A_const_52 = lang.RT_Keyword_String_String__Keyword(nil, Lit_58); A_arbace_a2g_access_A_const_53 = lang.RT_Keyword_String_String__Keyword(nil, Lit_59); A_arbace_a2g_access_A_const_54 = lang.RT_Var_String_String__Var(Lit_8, Lit_60); A_arbace_a2g_access_A_const_55 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_a2g_access_A_const_56 = jrt.Long_ValueOf_J__Long(0).Ref(); A_arbace_a2g_access_A_const_57 = lang.RT_Var_String_String__Var(Lit_0, Lit_62); A_arbace_a2g_access_A_const_58 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_a2g_access_A_const_59 = lang.RT_Keyword_String_String__Keyword(nil, Lit_64); A_arbace_a2g_access_A_const_60 = lang.RT_Keyword_String_String__Keyword(nil, Lit_65); A_arbace_a2g_access_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_66); A_arbace_a2g_access_A_const_62 = lang.RT_Var_String_String__Var(Lit_0, Lit_67) }

func A_arbace_a2g_access_A_New() *A_arbace_a2g_access_A { A_arbace_a2g_access_A_Init(); t := &A_arbace_a2g_access_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_access_A) Ctor() {}

func (t *A_arbace_a2g_access_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_A_class }

func (t *A_arbace_a2g_access_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_A); return ok }

func A_arbace_a2g_access_A_Cast(x any) *A_arbace_a2g_access_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_A_class)) }; return v }



type A_arbace_a2g_access_accessor_A struct{ jrt.Object }

func (t *A_arbace_a2g_access_accessor_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_access_accessor_A_fn_class *jrt.Class

var A_arbace_a2g_access_accessor_A_init jrt.ClassInit

func A_arbace_a2g_access_accessor_A_Init() { if !A_arbace_a2g_access_accessor_A_init.Done() { A_arbace_a2g_access_accessor_A_init.Run(A_arbace_a2g_access_accessor_A_clinit) } }

func A_arbace_a2g_access_accessor_A_clinit() { A_arbace_a2g_access_accessor_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_68, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_accessor_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_accessor_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_accessor_A_class }

func (t *A_arbace_a2g_access_accessor_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_accessor_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_accessor_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_accessor_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_accessor_A); return ok }

func A_arbace_a2g_access_accessor_A_Cast(x any) *A_arbace_a2g_access_accessor_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_accessor_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_accessor_A_class)) }; return v }



type A_arbace_a2g_access_eval41000004_A struct{ jrt.Object }

func A_arbace_a2g_access_eval41000004_A_New() *A_arbace_a2g_access_eval41000004_A { t := &A_arbace_a2g_access_eval41000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_access_eval41000004_A) Ctor() {}

func (t *A_arbace_a2g_access_eval41000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_eval41000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_eval41000004_A_class }

func (t *A_arbace_a2g_access_eval41000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_eval41000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_eval41000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_eval41000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_eval41000004_A); return ok }

func A_arbace_a2g_access_eval41000004_A_Cast(x any) *A_arbace_a2g_access_eval41000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_eval41000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_eval41000004_A_class)) }; return v }



type A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_fn_class *jrt.Class

var A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_init jrt.ClassInit

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_Init() { if !A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_init.Done() { A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_init.Run(A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_clinit) } }

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_clinit() { A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_70, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_class }

func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A); return ok }

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_Cast(x any) *A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_class)) }; return v }



type A_arbace_a2g_access_eval41000008_A struct{ jrt.Object }

func A_arbace_a2g_access_eval41000008_A_New() *A_arbace_a2g_access_eval41000008_A { t := &A_arbace_a2g_access_eval41000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_access_eval41000008_A) Ctor() {}

func (t *A_arbace_a2g_access_eval41000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_eval41000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_eval41000008_A_class }

func (t *A_arbace_a2g_access_eval41000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_eval41000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_eval41000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_eval41000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_eval41000008_A); return ok }

func A_arbace_a2g_access_eval41000008_A_Cast(x any) *A_arbace_a2g_access_eval41000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_eval41000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_eval41000008_A_class)) }; return v }



type A_arbace_a2g_access_eval41000008_fn__41000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_access_eval41000008_fn__41000009_A_fn_class *jrt.Class

var A_arbace_a2g_access_eval41000008_fn__41000009_A_init jrt.ClassInit

func A_arbace_a2g_access_eval41000008_fn__41000009_A_Init() { if !A_arbace_a2g_access_eval41000008_fn__41000009_A_init.Done() { A_arbace_a2g_access_eval41000008_fn__41000009_A_init.Run(A_arbace_a2g_access_eval41000008_fn__41000009_A_clinit) } }

func A_arbace_a2g_access_eval41000008_fn__41000009_A_clinit() { A_arbace_a2g_access_eval41000008_fn__41000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_71, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_eval41000008_fn__41000009_A_class }

func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_eval41000008_fn__41000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_eval41000008_fn__41000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_eval41000008_fn__41000009_A); return ok }

func A_arbace_a2g_access_eval41000008_fn__41000009_A_Cast(x any) *A_arbace_a2g_access_eval41000008_fn__41000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_eval41000008_fn__41000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_eval41000008_fn__41000009_A_class)) }; return v }



type A_arbace_a2g_access_find_field_A struct{ jrt.Object }

func (t *A_arbace_a2g_access_find_field_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_access_find_field_A_fn_class *jrt.Class

var A_arbace_a2g_access_find_field_A_init jrt.ClassInit

func A_arbace_a2g_access_find_field_A_Init() { if !A_arbace_a2g_access_find_field_A_init.Done() { A_arbace_a2g_access_find_field_A_init.Run(A_arbace_a2g_access_find_field_A_clinit) } }

func A_arbace_a2g_access_find_field_A_clinit() { A_arbace_a2g_access_find_field_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_72, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_find_field_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_find_field_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_find_field_A_class }

func (t *A_arbace_a2g_access_find_field_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_find_field_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_find_field_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_find_field_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_find_field_A); return ok }

func A_arbace_a2g_access_find_field_A_Cast(x any) *A_arbace_a2g_access_find_field_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_find_field_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_find_field_A_class)) }; return v }



type A_arbace_a2g_access_unaccess_A struct{ jrt.Object }

func (t *A_arbace_a2g_access_unaccess_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_access_unaccess_A_fn_class *jrt.Class

var A_arbace_a2g_access_unaccess_A_init jrt.ClassInit

func A_arbace_a2g_access_unaccess_A_Init() { if !A_arbace_a2g_access_unaccess_A_init.Done() { A_arbace_a2g_access_unaccess_A_init.Run(A_arbace_a2g_access_unaccess_A_clinit) } }

func A_arbace_a2g_access_unaccess_A_clinit() { A_arbace_a2g_access_unaccess_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_75, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_unaccess_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_unaccess_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_unaccess_A_class }

func (t *A_arbace_a2g_access_unaccess_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_unaccess_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_unaccess_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_unaccess_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_unaccess_A); return ok }

func A_arbace_a2g_access_unaccess_A_Cast(x any) *A_arbace_a2g_access_unaccess_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_unaccess_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_unaccess_A_class)) }; return v }



type A_arbace_a2g_access_unaccess_fn__41000019_A struct{ jrt.Object; F_acc any }

func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class *jrt.Class

var A_arbace_a2g_access_unaccess_fn__41000019_A_init jrt.ClassInit

func A_arbace_a2g_access_unaccess_fn__41000019_A_Init() { if !A_arbace_a2g_access_unaccess_fn__41000019_A_init.Done() { A_arbace_a2g_access_unaccess_fn__41000019_A_init.Run(A_arbace_a2g_access_unaccess_fn__41000019_A_clinit) } }

func A_arbace_a2g_access_unaccess_fn__41000019_A_clinit() { A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_77, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_unaccess_fn__41000019_A_class }

func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000019_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_unaccess_fn__41000019_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000019_A); return ok }

func A_arbace_a2g_access_unaccess_fn__41000019_A_Cast(x any) *A_arbace_a2g_access_unaccess_fn__41000019_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000019_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_unaccess_fn__41000019_A_class)) }; return v }



type A_arbace_a2g_access_unaccess_fn__41000025_A struct{ jrt.Object; F_acc any }

func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class *jrt.Class

var A_arbace_a2g_access_unaccess_fn__41000025_A_init jrt.ClassInit

func A_arbace_a2g_access_unaccess_fn__41000025_A_Init() { if !A_arbace_a2g_access_unaccess_fn__41000025_A_init.Done() { A_arbace_a2g_access_unaccess_fn__41000025_A_init.Run(A_arbace_a2g_access_unaccess_fn__41000025_A_clinit) } }

func A_arbace_a2g_access_unaccess_fn__41000025_A_clinit() { A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_78, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_unaccess_fn__41000025_A_class }

func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_unaccess_fn__41000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000025_A); return ok }

func A_arbace_a2g_access_unaccess_fn__41000025_A_Cast(x any) *A_arbace_a2g_access_unaccess_fn__41000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_unaccess_fn__41000025_A_class)) }; return v }



type A_arbace_a2g_access_unaccess_fn__41000031_A struct{ jrt.Object; F_acc any }

func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class *jrt.Class

var A_arbace_a2g_access_unaccess_fn__41000031_A_init jrt.ClassInit

func A_arbace_a2g_access_unaccess_fn__41000031_A_Init() { if !A_arbace_a2g_access_unaccess_fn__41000031_A_init.Done() { A_arbace_a2g_access_unaccess_fn__41000031_A_init.Run(A_arbace_a2g_access_unaccess_fn__41000031_A_clinit) } }

func A_arbace_a2g_access_unaccess_fn__41000031_A_clinit() { A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_79, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_unaccess_fn__41000031_A_class }

func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_unaccess_fn__41000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000031_A); return ok }

func A_arbace_a2g_access_unaccess_fn__41000031_A_Cast(x any) *A_arbace_a2g_access_unaccess_fn__41000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_unaccess_fn__41000031_A_class)) }; return v }



type A_arbace_a2g_access_unaccess_fn__41000037_A struct{ jrt.Object; F_acc any }

func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class *jrt.Class

var A_arbace_a2g_access_unaccess_fn__41000037_A_init jrt.ClassInit

func A_arbace_a2g_access_unaccess_fn__41000037_A_Init() { if !A_arbace_a2g_access_unaccess_fn__41000037_A_init.Done() { A_arbace_a2g_access_unaccess_fn__41000037_A_init.Run(A_arbace_a2g_access_unaccess_fn__41000037_A_clinit) } }

func A_arbace_a2g_access_unaccess_fn__41000037_A_clinit() { A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_80, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_access_unaccess_fn__41000037_A_class }

func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_access_unaccess_fn__41000037_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_access_unaccess_fn__41000037_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000037_A); return ok }

func A_arbace_a2g_access_unaccess_fn__41000037_A_Cast(x any) *A_arbace_a2g_access_unaccess_fn__41000037_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_access_unaccess_fn__41000037_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_access_unaccess_fn__41000037_A_class)) }; return v }
