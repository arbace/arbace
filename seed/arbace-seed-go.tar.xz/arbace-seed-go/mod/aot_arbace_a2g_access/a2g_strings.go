//line a2g_strings.ae:1
package aot_arbace_a2g_access

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("commute")

var Lit_13 *jrt.String = jrt.Intern("deref")

var Lit_14 *jrt.String = jrt.Intern("conj")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.access")

var Lit_16 *jrt.String = jrt.Intern("doc")

var Lit_17 *jrt.String = jrt.Intern("javac's accessor methods (access$NNN, arbace.classes.analyze's accessorize and\n  outer-super-call): the analyzer turns a private member access across a nest into a call of a\n  synthetic static method, whose code it keeps as a bytecode-writing function and, as data, the\n  one member instruction it holds (the class state's :accessors). Go has no private members\n  across the classes of one package, so a2g undoes the indirection: it gives the access node\n  the accessor stands for (no class file is written: doc/STANDALONE-NOTES.md, S2).")

var Lit_18 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_19 *jrt.String = jrt.Intern("string?")

var Lit_20 *jrt.String = jrt.Intern("starts-with?")

var Lit_21 *jrt.String = jrt.Intern("decl")

var Lit_22 *jrt.String = jrt.Intern("accessors")

var Lit_23 *jrt.String = jrt.Intern("state")

var Lit_24 *jrt.String = jrt.Intern("find-field")

var Lit_25 *jrt.String = jrt.Intern("ex-info")

var Lit_26 *jrt.String = jrt.Intern("invoke")

var Lit_27 *jrt.String = jrt.Intern("op")

var Lit_28 *jrt.String = jrt.Intern("static")

var Lit_29 *jrt.String = jrt.Intern("kind")

var Lit_30 *jrt.String = jrt.Intern("accessor")

var Lit_31 *jrt.String = jrt.Intern("args")

var Lit_32 *jrt.String = jrt.Intern("insn")

var Lit_33 *jrt.String = jrt.Intern("getstatic")

var Lit_34 *jrt.String = jrt.Intern("get-static")

var Lit_35 *jrt.String = jrt.Intern("field")

var Lit_36 *jrt.String = jrt.Intern("owner")

var Lit_37 *jrt.String = jrt.Intern("type")

var Lit_38 *jrt.String = jrt.Intern("desc")

var Lit_39 *jrt.String = jrt.Intern("invokestatic")

var Lit_40 *jrt.String = jrt.Intern("some")

var Lit_41 *jrt.String = jrt.Intern("assoc")

var Lit_42 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_43 *jrt.String = jrt.Intern("invokeinterface")

var Lit_44 *jrt.String = jrt.Intern("interface")

var Lit_45 *jrt.String = jrt.Intern("invokespecial")

var Lit_46 *jrt.String = jrt.Intern("special")

var Lit_47 *jrt.String = jrt.Intern("virtual")

var Lit_48 *jrt.String = jrt.Intern("itf")

var Lit_49 *jrt.String = jrt.Intern("name")

var Lit_50 *jrt.String = jrt.Intern("target")

var Lit_51 *jrt.String = jrt.Intern("first")

var Lit_52 *jrt.String = jrt.Intern("vec")

var Lit_53 *jrt.String = jrt.Intern("method")

var Lit_54 *jrt.String = jrt.Intern("outer-super")

var Lit_55 *jrt.String = jrt.Intern("putstatic")

var Lit_56 *jrt.String = jrt.Intern("set-static")

var Lit_57 *jrt.String = jrt.Intern("val")

var Lit_58 *jrt.String = jrt.Intern("invokevirtual")

var Lit_59 *jrt.String = jrt.Intern("methods")

var Lit_60 *jrt.String = jrt.Intern("info")

var Lit_61 *jrt.String = jrt.Intern("flags")

var Lit_62 *jrt.String = jrt.Intern("rest")

var Lit_63 *jrt.String = jrt.Intern("getfield")

var Lit_64 *jrt.String = jrt.Intern("get-field")

var Lit_65 *jrt.String = jrt.Intern("putfield")

var Lit_66 *jrt.String = jrt.Intern("set-field")

var Lit_67 *jrt.String = jrt.Intern("second")

var Lit_68 *jrt.String = jrt.Intern("arbace.a2g.access$accessor")

var Lit_69 *jrt.String = jrt.Intern("access$")

var Lit_70 *jrt.String = jrt.Intern("arbace.a2g.access$eval41000004$loading__1927001464__auto____41000005")

var Lit_71 *jrt.String = jrt.Intern("arbace.a2g.access$eval41000008$fn__41000009")

var Lit_72 *jrt.String = jrt.Intern("arbace.a2g.access$find_field")

var Lit_73 *jrt.String = jrt.Intern("a2g: accessor field not found ")

var Lit_74 *jrt.String = jrt.Intern(".")

var Lit_75 *jrt.String = jrt.Intern("arbace.a2g.access$unaccess")

var Lit_76 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_77 *jrt.String = jrt.Intern("arbace.a2g.access$unaccess$fn__41000019")

var Lit_78 *jrt.String = jrt.Intern("arbace.a2g.access$unaccess$fn__41000025")

var Lit_79 *jrt.String = jrt.Intern("arbace.a2g.access$unaccess$fn__41000031")

var Lit_80 *jrt.String = jrt.Intern("arbace.a2g.access$unaccess$fn__41000037")

var Lit_81 *jrt.String = jrt.Intern("in-ns")

var Lit_82 *jrt.String = jrt.Intern("arglists")

var Lit_83 *jrt.String = jrt.Intern("o")

var Lit_84 *jrt.String = jrt.Intern("mname")

var Lit_85 *jrt.String = jrt.Intern("The member instruction of accessor method mname of class o, {:insn kw :owner :name :desc\n  :itf}, or nil.")

var Lit_86 *jrt.String = jrt.Intern("line")

var Lit_87 *jrt.String = jrt.Intern("column")

var Lit_88 *jrt.String = jrt.Intern("file")

var Lit_89 *jrt.String = jrt.Intern("arbace/a2g/access.ae")

var Lit_90 *jrt.String = jrt.Intern("private")

var Lit_91 *jrt.String = jrt.Intern("fname")

var Lit_92 *jrt.String = jrt.Intern("unaccess")

var Lit_93 *jrt.String = jrt.Intern("node")

var Lit_94 *jrt.String = jrt.Intern("The access node an accessor call node stands for, or the node itself.")
