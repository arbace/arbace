//line a2g_classes.ae:1
package aot_arbace_a2g_access

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_access_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_A_New()}; return nil }

var A_arbace_a2g_access_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_access_A_new}

var A_arbace_a2g_access_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_A"})

func init() { i := A_arbace_a2g_access_A_class.Info(); i.IsInstance = A_arbace_a2g_access_A_InstanceOf; i.Init = A_arbace_a2g_access_A_Init; i.Table = A_arbace_a2g_access_A_members; jrt.RegisterGoType(A_arbace_a2g_access_A_class, reflect.TypeFor[A_arbace_a2g_access_A]()) }

func A_arbace_a2g_access_accessor_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_accessor_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_access_accessor_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_accessor_A_New()}; return nil }

func A_arbace_a2g_access_accessor_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_accessor_A_fn_class)}; return nil }

var A_arbace_a2g_access_accessor_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_accessor_A_invoke, New: A_arbace_a2g_access_accessor_A_new, Get: A_arbace_a2g_access_accessor_A_get}

var A_arbace_a2g_access_accessor_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$accessor", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_access_A_class, Simple: "accessor", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_accessor_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_accessor_A_class.Info(); i.IsInstance = A_arbace_a2g_access_accessor_A_InstanceOf; i.Init = A_arbace_a2g_access_accessor_A_Init; i.Table = A_arbace_a2g_access_accessor_A_members; jrt.RegisterGoType(A_arbace_a2g_access_accessor_A_class, reflect.TypeFor[A_arbace_a2g_access_accessor_A]()) }

func A_arbace_a2g_access_eval41000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_eval41000004_A_New()}; return nil }

var A_arbace_a2g_access_eval41000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_access_eval41000004_A_new}

var A_arbace_a2g_access_eval41000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$eval41000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_access_A_class, Simple: "eval41000004", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_eval41000004_A"})

func init() { i := A_arbace_a2g_access_eval41000004_A_class.Info(); i.IsInstance = A_arbace_a2g_access_eval41000004_A_InstanceOf; i.Table = A_arbace_a2g_access_eval41000004_A_members; jrt.RegisterGoType(A_arbace_a2g_access_eval41000004_A_class, reflect.TypeFor[A_arbace_a2g_access_eval41000004_A]()) }

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_New()}; return nil }

func A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_fn_class)}; return nil }

var A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_invoke, New: A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_new, Get: A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_get}

var A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$eval41000004$loading__1927001464__auto____41000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_access_eval41000004_A_class, Simple: "loading__1927001464__auto____41000005", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_class.Info(); i.IsInstance = A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_InstanceOf; i.Init = A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_Init; i.Table = A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_members; jrt.RegisterGoType(A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A_class, reflect.TypeFor[A_arbace_a2g_access_eval41000004_loading__1927001464__auto____41000005_A]()) }

func A_arbace_a2g_access_eval41000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_eval41000008_A_New()}; return nil }

var A_arbace_a2g_access_eval41000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_access_eval41000008_A_new}

var A_arbace_a2g_access_eval41000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$eval41000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_access_A_class, Simple: "eval41000008", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_eval41000008_A"})

func init() { i := A_arbace_a2g_access_eval41000008_A_class.Info(); i.IsInstance = A_arbace_a2g_access_eval41000008_A_InstanceOf; i.Table = A_arbace_a2g_access_eval41000008_A_members; jrt.RegisterGoType(A_arbace_a2g_access_eval41000008_A_class, reflect.TypeFor[A_arbace_a2g_access_eval41000008_A]()) }

func A_arbace_a2g_access_eval41000008_fn__41000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_eval41000008_fn__41000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_access_eval41000008_fn__41000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_eval41000008_fn__41000009_A_New()}; return nil }

func A_arbace_a2g_access_eval41000008_fn__41000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_eval41000008_fn__41000009_A_fn_class)}; return nil }

var A_arbace_a2g_access_eval41000008_fn__41000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_eval41000008_fn__41000009_A_invoke, New: A_arbace_a2g_access_eval41000008_fn__41000009_A_new, Get: A_arbace_a2g_access_eval41000008_fn__41000009_A_get}

var A_arbace_a2g_access_eval41000008_fn__41000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$eval41000008$fn__41000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_access_eval41000008_A_class, Simple: "fn__41000009", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_eval41000008_fn__41000009_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_eval41000008_fn__41000009_A_class.Info(); i.IsInstance = A_arbace_a2g_access_eval41000008_fn__41000009_A_InstanceOf; i.Init = A_arbace_a2g_access_eval41000008_fn__41000009_A_Init; i.Table = A_arbace_a2g_access_eval41000008_fn__41000009_A_members; jrt.RegisterGoType(A_arbace_a2g_access_eval41000008_fn__41000009_A_class, reflect.TypeFor[A_arbace_a2g_access_eval41000008_fn__41000009_A]()) }

func A_arbace_a2g_access_find_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_find_field_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_access_find_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_find_field_A_New()}; return nil }

func A_arbace_a2g_access_find_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_find_field_A_fn_class)}; return nil }

var A_arbace_a2g_access_find_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_find_field_A_invoke, New: A_arbace_a2g_access_find_field_A_new, Get: A_arbace_a2g_access_find_field_A_get}

var A_arbace_a2g_access_find_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$find_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_access_A_class, Simple: "find_field", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_find_field_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_find_field_A_class.Info(); i.IsInstance = A_arbace_a2g_access_find_field_A_InstanceOf; i.Init = A_arbace_a2g_access_find_field_A_Init; i.Table = A_arbace_a2g_access_find_field_A_members; jrt.RegisterGoType(A_arbace_a2g_access_find_field_A_class, reflect.TypeFor[A_arbace_a2g_access_find_field_A]()) }

func A_arbace_a2g_access_unaccess_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_unaccess_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_access_unaccess_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_unaccess_A_New()}; return nil }

func A_arbace_a2g_access_unaccess_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_unaccess_A_fn_class)}; return nil }

var A_arbace_a2g_access_unaccess_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_unaccess_A_invoke, New: A_arbace_a2g_access_unaccess_A_new, Get: A_arbace_a2g_access_unaccess_A_get}

var A_arbace_a2g_access_unaccess_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$unaccess", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_access_A_class, Simple: "unaccess", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_unaccess_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_unaccess_A_class.Info(); i.IsInstance = A_arbace_a2g_access_unaccess_A_InstanceOf; i.Init = A_arbace_a2g_access_unaccess_A_Init; i.Table = A_arbace_a2g_access_unaccess_A_members; jrt.RegisterGoType(A_arbace_a2g_access_unaccess_A_class, reflect.TypeFor[A_arbace_a2g_access_unaccess_A]()) }

func A_arbace_a2g_access_unaccess_fn__41000019_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_unaccess_fn__41000019_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000019_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_unaccess_fn__41000019_A_New_O(args[0])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000019_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_unaccess_fn__41000019_A_fn_class)}; return nil }

var A_arbace_a2g_access_unaccess_fn__41000019_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_unaccess_fn__41000019_A_invoke, New: A_arbace_a2g_access_unaccess_fn__41000019_A_new, Get: A_arbace_a2g_access_unaccess_fn__41000019_A_get}

var A_arbace_a2g_access_unaccess_fn__41000019_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$unaccess$fn__41000019", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_access_unaccess_A_class, Simple: "fn__41000019", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_unaccess_fn__41000019_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_unaccess_fn__41000019_A_class.Info(); i.IsInstance = A_arbace_a2g_access_unaccess_fn__41000019_A_InstanceOf; i.Init = A_arbace_a2g_access_unaccess_fn__41000019_A_Init; i.Table = A_arbace_a2g_access_unaccess_fn__41000019_A_members; jrt.RegisterGoType(A_arbace_a2g_access_unaccess_fn__41000019_A_class, reflect.TypeFor[A_arbace_a2g_access_unaccess_fn__41000019_A]()) }

func A_arbace_a2g_access_unaccess_fn__41000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_unaccess_fn__41000025_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_unaccess_fn__41000025_A_New_O(args[0])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_unaccess_fn__41000025_A_fn_class)}; return nil }

var A_arbace_a2g_access_unaccess_fn__41000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_unaccess_fn__41000025_A_invoke, New: A_arbace_a2g_access_unaccess_fn__41000025_A_new, Get: A_arbace_a2g_access_unaccess_fn__41000025_A_get}

var A_arbace_a2g_access_unaccess_fn__41000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$unaccess$fn__41000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_access_unaccess_A_class, Simple: "fn__41000025", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_unaccess_fn__41000025_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_unaccess_fn__41000025_A_class.Info(); i.IsInstance = A_arbace_a2g_access_unaccess_fn__41000025_A_InstanceOf; i.Init = A_arbace_a2g_access_unaccess_fn__41000025_A_Init; i.Table = A_arbace_a2g_access_unaccess_fn__41000025_A_members; jrt.RegisterGoType(A_arbace_a2g_access_unaccess_fn__41000025_A_class, reflect.TypeFor[A_arbace_a2g_access_unaccess_fn__41000025_A]()) }

func A_arbace_a2g_access_unaccess_fn__41000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_unaccess_fn__41000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_unaccess_fn__41000031_A_New_O(args[0])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_unaccess_fn__41000031_A_fn_class)}; return nil }

var A_arbace_a2g_access_unaccess_fn__41000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_unaccess_fn__41000031_A_invoke, New: A_arbace_a2g_access_unaccess_fn__41000031_A_new, Get: A_arbace_a2g_access_unaccess_fn__41000031_A_get}

var A_arbace_a2g_access_unaccess_fn__41000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$unaccess$fn__41000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_access_unaccess_A_class, Simple: "fn__41000031", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_unaccess_fn__41000031_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_unaccess_fn__41000031_A_class.Info(); i.IsInstance = A_arbace_a2g_access_unaccess_fn__41000031_A_InstanceOf; i.Init = A_arbace_a2g_access_unaccess_fn__41000031_A_Init; i.Table = A_arbace_a2g_access_unaccess_fn__41000031_A_members; jrt.RegisterGoType(A_arbace_a2g_access_unaccess_fn__41000031_A_class, reflect.TypeFor[A_arbace_a2g_access_unaccess_fn__41000031_A]()) }

func A_arbace_a2g_access_unaccess_fn__41000037_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_access_unaccess_fn__41000037_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000037_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access_unaccess_fn__41000037_A_New_O(args[0])}; return nil }

func A_arbace_a2g_access_unaccess_fn__41000037_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_access_unaccess_fn__41000037_A_fn_class)}; return nil }

var A_arbace_a2g_access_unaccess_fn__41000037_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_access_unaccess_fn__41000037_A_invoke, New: A_arbace_a2g_access_unaccess_fn__41000037_A_new, Get: A_arbace_a2g_access_unaccess_fn__41000037_A_get}

var A_arbace_a2g_access_unaccess_fn__41000037_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access$unaccess$fn__41000037", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_access_unaccess_A_class, Simple: "fn__41000037", Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access_unaccess_fn__41000037_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access_unaccess_fn__41000037_A_class.Info(); i.IsInstance = A_arbace_a2g_access_unaccess_fn__41000037_A_InstanceOf; i.Init = A_arbace_a2g_access_unaccess_fn__41000037_A_Init; i.Table = A_arbace_a2g_access_unaccess_fn__41000037_A_members; jrt.RegisterGoType(A_arbace_a2g_access_unaccess_fn__41000037_A_class, reflect.TypeFor[A_arbace_a2g_access_unaccess_fn__41000037_A]()) }

func A_arbace_a2g_access__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_access__init_A_Load__O(); case 1: return A_arbace_a2g_access__init_A_Unit0__O(); case 2: return A_arbace_a2g_access__init_A_Unit1__O(); case 3: return A_arbace_a2g_access__init_A_Unit2__O(); case 4: return A_arbace_a2g_access__init_A_Unit3__O(); case 5: return A_arbace_a2g_access__init_A_Unit4__O(); case 6: return A_arbace_a2g_access__init_A_Unit5__O(); case 7: return A_arbace_a2g_access__init_A_Unit6__O()}; return nil }

func A_arbace_a2g_access__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_access__init_A_New()}; return nil }

var A_arbace_a2g_access__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_access__init_A_invoke, New: A_arbace_a2g_access__init_A_new}

var A_arbace_a2g_access__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.access__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_access.A_arbace_a2g_access__init_A", Source: "access.ae"})

func init() { i := A_arbace_a2g_access__init_A_class.Info(); i.IsInstance = A_arbace_a2g_access__init_A_InstanceOf; i.Init = A_arbace_a2g_access__init_A_Init; i.Table = A_arbace_a2g_access__init_A_members; jrt.RegisterGoType(A_arbace_a2g_access__init_A_class, reflect.TypeFor[A_arbace_a2g_access__init_A]()) }
