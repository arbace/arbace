//line a2g_strings.ae:1
package aot_arbace_a2g_code

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_13 *jrt.String = jrt.Intern("m")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_15 *jrt.String = jrt.Intern("nm")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.access")

var Lit_17 *jrt.String = jrt.Intern("acc")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.vh")

var Lit_19 *jrt.String = jrt.Intern("vh")

var Lit_20 *jrt.String = jrt.Intern("commute")

var Lit_21 *jrt.String = jrt.Intern("deref")

var Lit_22 *jrt.String = jrt.Intern("conj")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.code")

var Lit_24 *jrt.String = jrt.Intern("doc")

var Lit_25 *jrt.String = jrt.Intern("a2g's translation of code (A2G-SPEC §7): the analyzer's typed nodes to Go statements and\n  expressions, in four contexts (statement, return, assign, expression, §7.2), with\n  temporaries for Java's order of evaluation, Java's arithmetic (§7.4), null checks and the\n  typed-nil rule (§5.6), try/catch/finally and control codes (§7.9), monitors (§8.1), loops,\n  labels and switches (§7.7, §7.8), lambdas (§7.11).")

var Lit_26 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_27 *jrt.String = jrt.Intern("*races*")

var Lit_28 *jrt.String = jrt.Intern("static?")

var Lit_29 *jrt.String = jrt.Intern("iface-desc?")

var Lit_30 *jrt.String = jrt.Intern("not")

var Lit_31 *jrt.String = jrt.Intern("swap!")

var Lit_32 *jrt.String = jrt.Intern("desc")

var Lit_33 *jrt.String = jrt.Intern("has?")

var Lit_34 *jrt.String = jrt.Intern("flags")

var Lit_35 *jrt.String = jrt.Intern("class")

var Lit_36 *jrt.String = jrt.Intern("*f*")

var Lit_37 *jrt.String = jrt.Intern("clinit")

var Lit_38 *jrt.String = jrt.Intern("ctor")

var Lit_39 *jrt.String = jrt.Intern("sync")

var Lit_40 *jrt.String = jrt.Intern("locked-this")

var Lit_41 *jrt.String = jrt.Intern("name")

var Lit_42 *jrt.String = jrt.Intern("method-name")

var Lit_43 *jrt.String = jrt.Intern("ex-info")

var Lit_44 *jrt.String = jrt.Intern("merge")

var Lit_45 *jrt.String = jrt.Intern("fail")

var Lit_46 *jrt.String = jrt.Intern("pkg")

var Lit_47 *jrt.String = jrt.Intern("jrt-sym")

var Lit_48 *jrt.String = jrt.Intern("class-sym")

var Lit_49 *jrt.String = jrt.Intern("go-type")

var Lit_50 *jrt.String = jrt.Intern("with-meta")

var Lit_51 *jrt.String = jrt.Intern("tag")

var Lit_52 *jrt.String = jrt.Intern("counter")

var Lit_53 *jrt.String = jrt.Intern("update")

var Lit_54 *jrt.String = jrt.Intern("fnil")

var Lit_55 *jrt.String = jrt.Intern("inc")

var Lit_56 *jrt.String = jrt.Intern("taken")

var Lit_57 *jrt.String = jrt.Intern("local-name")

var Lit_58 *jrt.String = jrt.Intern("contains?")

var Lit_59 *jrt.String = jrt.Intern("symbol")

var Lit_60 *jrt.String = jrt.Intern("fresh-raw")

var Lit_61 *jrt.String = jrt.Intern("new-counter!")

var Lit_62 *jrt.String = jrt.Intern("tmp")

var Lit_63 *jrt.String = jrt.Intern("used")

var Lit_64 *jrt.String = jrt.Intern("id")

var Lit_65 *jrt.String = jrt.Intern("fresh")

var Lit_66 *jrt.String = jrt.Intern("names")

var Lit_67 *jrt.String = jrt.Intern("sym")

var Lit_68 *jrt.String = jrt.Intern("assoc")

var Lit_69 *jrt.String = jrt.Intern("*line*")

var Lit_70 *jrt.String = jrt.Intern("seq?")

var Lit_71 *jrt.String = jrt.Intern("vary-meta")

var Lit_72 *jrt.String = jrt.Intern("a2g")

var Lit_73 *jrt.String = jrt.Intern("line")

var Lit_74 *jrt.String = jrt.Intern("*block*")

var Lit_75 *jrt.String = jrt.Intern("with-line")

var Lit_76 *jrt.String = jrt.Intern("let")

var Lit_77 *jrt.String = jrt.Intern("some?")

var Lit_78 *jrt.String = jrt.Intern("list")

var Lit_79 *jrt.String = jrt.Intern("zero")

var Lit_80 *jrt.String = jrt.Intern("reverse")

var Lit_81 *jrt.String = jrt.Intern("seq")

var Lit_82 *jrt.String = jrt.Intern("first")

var Lit_83 *jrt.String = jrt.Intern("next")

var Lit_84 *jrt.String = jrt.Intern("vector?")

var Lit_85 *jrt.String = jrt.Intern("rest")

var Lit_86 *jrt.String = jrt.Intern("vec")

var Lit_87 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_88 *jrt.String = jrt.Intern("chunk-first")

var Lit_89 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_90 *jrt.String = jrt.Intern("symbol?")

var Lit_91 *jrt.String = jrt.Intern("not=")

var Lit_92 *jrt.String = jrt.Intern("_")

var Lit_93 *jrt.String = jrt.Intern("chunk-append")

var Lit_94 *jrt.String = jrt.Intern("set!")

var Lit_95 *jrt.String = jrt.Intern("chunk-cons")

var Lit_96 *jrt.String = jrt.Intern("cons")

var Lit_97 *jrt.String = jrt.Intern("chunk")

var Lit_98 *jrt.String = jrt.Intern("chunk-rest")

var Lit_99 *jrt.String = jrt.Intern("concat")

var Lit_100 *jrt.String = jrt.Intern("mapcat")

var Lit_101 *jrt.String = jrt.Intern("apply")

var Lit_102 *jrt.String = jrt.Intern("some")

var Lit_103 *jrt.String = jrt.Intern("fold-items")

var Lit_104 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_105 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_106 *jrt.String = jrt.Intern("hash-map")

var Lit_107 *jrt.String = jrt.Intern("atom")

var Lit_108 *jrt.String = jrt.Intern("value-type")

var Lit_109 *jrt.String = jrt.Intern("type")

var Lit_110 *jrt.String = jrt.Intern("null")

var Lit_111 *jrt.String = jrt.Intern("F")

var Lit_112 *jrt.String = jrt.Intern("D")

var Lit_113 *jrt.String = jrt.Intern("else")

var Lit_114 *jrt.String = jrt.Intern("number?")

var Lit_115 *jrt.String = jrt.Intern("boolean?")

var Lit_116 *jrt.String = jrt.Intern("string?")

var Lit_117 *jrt.String = jrt.Intern("object-like?")

var Lit_118 *jrt.String = jrt.Intern(".Ref")

var Lit_119 *jrt.String = jrt.Intern("ups")

var Lit_120 *jrt.String = jrt.Intern("*pkgstate*")

var Lit_121 *jrt.String = jrt.Intern("desc-code")

var Lit_122 *jrt.String = jrt.Intern("prim?")

var Lit_123 *jrt.String = jrt.Intern("zero-of")

var Lit_124 *jrt.String = jrt.Intern("none")

var Lit_125 *jrt.String = jrt.Intern("prim-convert")

var Lit_126 *jrt.String = jrt.Intern("coerce")

var Lit_127 *jrt.String = jrt.Intern("unbox-of")

var Lit_128 *jrt.String = jrt.Intern("pointer-desc?")

var Lit_129 *jrt.String = jrt.Intern("up-sym")

var Lit_130 *jrt.String = jrt.Intern("gotype")

var Lit_131 *jrt.String = jrt.Intern("box-val")

var Lit_132 *jrt.String = jrt.Intern("box-of")

var Lit_133 *jrt.String = jrt.Intern("method-base")

var Lit_134 *jrt.String = jrt.Intern("prim-desc->name")

var Lit_135 *jrt.String = jrt.Intern("jsym")

var Lit_136 *jrt.String = jrt.Intern("inst")

var Lit_137 *jrt.String = jrt.Intern("to-array")

var Lit_138 *jrt.String = jrt.Intern("x")

var Lit_139 *jrt.String = jrt.Intern("simple-ops")

var Lit_140 *jrt.String = jrt.Intern("op")

var Lit_141 *jrt.String = jrt.Intern("or")

var Lit_142 *jrt.String = jrt.Intern("and")

var Lit_143 *jrt.String = jrt.Intern("method-ref")

var Lit_144 *jrt.String = jrt.Intern("bound")

var Lit_145 *jrt.String = jrt.Intern("kind")

var Lit_146 *jrt.String = jrt.Intern("guarded-static?")

var Lit_147 *jrt.String = jrt.Intern("set-static")

var Lit_148 *jrt.String = jrt.Intern("get-static")

var Lit_149 *jrt.String = jrt.Intern("field")

var Lit_150 *jrt.String = jrt.Intern("declarer")

var Lit_151 *jrt.String = jrt.Intern("owner")

var Lit_152 *jrt.String = jrt.Intern("translated?")

var Lit_153 *jrt.String = jrt.Intern("trivial-init?")

var Lit_154 *jrt.String = jrt.Intern("subclass?")

var Lit_155 *jrt.String = jrt.Intern("unaccess")

var Lit_156 *jrt.String = jrt.Intern("expressible?")

var Lit_157 *jrt.String = jrt.Intern("every?")

var Lit_158 *jrt.String = jrt.Intern("missing-reason")

var Lit_159 *jrt.String = jrt.Intern("simple?")

var Lit_160 *jrt.String = jrt.Intern("lambda")

var Lit_161 *jrt.String = jrt.Intern("remove")

var Lit_162 *jrt.String = jrt.Intern("nil?")

var Lit_163 *jrt.String = jrt.Intern("recv")

var Lit_164 *jrt.String = jrt.Intern("map?")

var Lit_165 *jrt.String = jrt.Intern("target")

var Lit_166 *jrt.String = jrt.Intern("filter")

var Lit_167 *jrt.String = jrt.Intern("args")

var Lit_168 *jrt.String = jrt.Intern("elems")

var Lit_169 *jrt.String = jrt.Intern("dims")

var Lit_170 *jrt.String = jrt.Intern("keep")

var Lit_171 *jrt.String = jrt.Intern("expr")

var Lit_172 *jrt.String = jrt.Intern("val")

var Lit_173 *jrt.String = jrt.Intern("array")

var Lit_174 *jrt.String = jrt.Intern("index")

var Lit_175 *jrt.String = jrt.Intern("base")

var Lit_176 *jrt.String = jrt.Intern("node")

var Lit_177 *jrt.String = jrt.Intern("parts")

var Lit_178 *jrt.String = jrt.Intern("volatile!")

var Lit_179 *jrt.String = jrt.Intern("effect-ops")

var Lit_180 *jrt.String = jrt.Intern("alength")

var Lit_181 *jrt.String = jrt.Intern("convert")

var Lit_182 *jrt.String = jrt.Intern("get-field")

var Lit_183 *jrt.String = jrt.Intern("arith")

var Lit_184 *jrt.String = jrt.Intern("aget")

var Lit_185 *jrt.String = jrt.Intern("ref?")

var Lit_186 *jrt.String = jrt.Intern("rem")

var Lit_187 *jrt.String = jrt.Intern("div")

var Lit_188 *jrt.String = jrt.Intern("J")

var Lit_189 *jrt.String = jrt.Intern("I")

var Lit_190 *jrt.String = jrt.Intern("vreset!")

var Lit_191 *jrt.String = jrt.Intern("this-path")

var Lit_192 *jrt.String = jrt.Intern("from")

var Lit_193 *jrt.String = jrt.Intern("o")

var Lit_194 *jrt.String = jrt.Intern("new")

var Lit_195 *jrt.String = jrt.Intern("var-invoke")

var Lit_196 *jrt.String = jrt.Intern("invoke")

var Lit_197 *jrt.String = jrt.Intern("java-str")

var Lit_198 *jrt.String = jrt.Intern("var-deref")

var Lit_199 *jrt.String = jrt.Intern("class-lit")

var Lit_200 *jrt.String = jrt.Intern("const")

var Lit_201 *jrt.String = jrt.Intern("local")

var Lit_202 *jrt.String = jrt.Intern("mutable")

var Lit_203 *jrt.String = jrt.Intern("b")

var Lit_204 *jrt.String = jrt.Intern("decl!")

var Lit_205 *jrt.String = jrt.Intern("use-sym!")

var Lit_206 *jrt.String = jrt.Intern("pure")

var Lit_207 *jrt.String = jrt.Intern("any-after")

var Lit_208 *jrt.String = jrt.Intern("mapv")

var Lit_209 *jrt.String = jrt.Intern("effects?")

var Lit_210 *jrt.String = jrt.Intern("reads-state?")

var Lit_211 *jrt.String = jrt.Intern("stable?")

var Lit_212 *jrt.String = jrt.Intern("range")

var Lit_213 *jrt.String = jrt.Intern("missing")

var Lit_214 *jrt.String = jrt.Intern("hoist-value")

var Lit_215 *jrt.String = jrt.Intern("missing-expr")

var Lit_216 *jrt.String = jrt.Intern("nn")

var Lit_217 *jrt.String = jrt.Intern("lits")

var Lit_218 *jrt.String = jrt.Intern("lit-prefix")

var Lit_219 *jrt.String = jrt.Intern("v")

var Lit_220 *jrt.String = jrt.Intern("char?")

var Lit_221 *jrt.String = jrt.Intern("float-lit")

var Lit_222 *jrt.String = jrt.Intern("string-lit")

var Lit_223 *jrt.String = jrt.Intern("keyword?")

var Lit_224 *jrt.String = jrt.Intern("erased-desc?")

var Lit_225 *jrt.String = jrt.Intern("conv")

var Lit_226 *jrt.String = jrt.Intern("bool")

var Lit_227 *jrt.String = jrt.Intern("in-world?")

var Lit_228 *jrt.String = jrt.Intern("replace")

var Lit_229 *jrt.String = jrt.Intern("class-missing")

var Lit_230 *jrt.String = jrt.Intern("desc-classes")

var Lit_231 *jrt.String = jrt.Intern("method-desc-classes")

var Lit_232 *jrt.String = jrt.Intern("a2g-static?")

var Lit_233 *jrt.String = jrt.Intern("funcs")

var Lit_234 *jrt.String = jrt.Intern("jrt")

var Lit_235 *jrt.String = jrt.Intern("*w*")

var Lit_236 *jrt.String = jrt.Intern("go-name")

var Lit_237 *jrt.String = jrt.Intern("static")

var Lit_238 *jrt.String = jrt.Intern("empty?")

var Lit_239 *jrt.String = jrt.Intern("op-handle")

var Lit_240 *jrt.String = jrt.Intern("handles")

var Lit_241 *jrt.String = jrt.Intern("get")

var Lit_242 *jrt.String = jrt.Intern("Z")

var Lit_243 *jrt.String = jrt.Intern("cas")

var Lit_244 *jrt.String = jrt.Intern("swap")

var Lit_245 *jrt.String = jrt.Intern("add")

var Lit_246 *jrt.String = jrt.Intern("set")

var Lit_247 *jrt.String = jrt.Intern("xor")

var Lit_248 *jrt.String = jrt.Intern("cmpxchg")

var Lit_249 *jrt.String = jrt.Intern("fence?")

var Lit_250 *jrt.String = jrt.Intern("vh-ok")

var Lit_251 *jrt.String = jrt.Intern("lookup-call?")

var Lit_252 *jrt.String = jrt.Intern("varhandle")

var Lit_253 *jrt.String = jrt.Intern("vh-op")

var Lit_254 *jrt.String = jrt.Intern("view")

var Lit_255 *jrt.String = jrt.Intern("elem-type")

var Lit_256 *jrt.String = jrt.Intern("vh-supported?")

var Lit_257 *jrt.String = jrt.Intern("mode")

var Lit_258 *jrt.String = jrt.Intern("desc-missing")

var Lit_259 *jrt.String = jrt.Intern("hand-written?")

var Lit_260 *jrt.String = jrt.Intern("static-field-name")

var Lit_261 *jrt.String = jrt.Intern("cast")

var Lit_262 *jrt.String = jrt.Intern("instance?")

var Lit_263 *jrt.String = jrt.Intern("vars")

var Lit_264 *jrt.String = jrt.Intern("consts")

var Lit_265 *jrt.String = jrt.Intern("bigint")

var Lit_266 *jrt.String = jrt.Intern("method")

var Lit_267 *jrt.String = jrt.Intern("vh-missing")

var Lit_268 *jrt.String = jrt.Intern("array-clone")

var Lit_269 *jrt.String = jrt.Intern("mdesc-missing")

var Lit_270 *jrt.String = jrt.Intern("special")

var Lit_271 *jrt.String = jrt.Intern("outer-super")

var Lit_272 *jrt.String = jrt.Intern("hw-static-exists?")

var Lit_273 *jrt.String = jrt.Intern("hw-method-exists?")

var Lit_274 *jrt.String = jrt.Intern("new-array")

var Lit_275 *jrt.String = jrt.Intern("all-supertypes")

var Lit_276 *jrt.String = jrt.Intern("member-in-world?")

var Lit_277 *jrt.String = jrt.Intern("set-field")

var Lit_278 *jrt.String = jrt.Intern("array-init")

var Lit_279 *jrt.String = jrt.Intern("new-name")

var Lit_280 *jrt.String = jrt.Intern("fi")

var Lit_281 *jrt.String = jrt.Intern("fi-adapter")

var Lit_282 *jrt.String = jrt.Intern("desc->internal")

var Lit_283 *jrt.String = jrt.Intern("this")

var Lit_284 *jrt.String = jrt.Intern("internal->desc")

var Lit_285 *jrt.String = jrt.Intern("leaf?")

var Lit_286 *jrt.String = jrt.Intern("field-name")

var Lit_287 *jrt.String = jrt.Intern("this0-name")

var Lit_288 *jrt.String = jrt.Intern("path")

var Lit_289 *jrt.String = jrt.Intern("this-val")

var Lit_290 *jrt.String = jrt.Intern("outer-param")

var Lit_291 *jrt.String = jrt.Intern("outer-field")

var Lit_292 *jrt.String = jrt.Intern("outer")

var Lit_293 *jrt.String = jrt.Intern("decl")

var Lit_294 *jrt.String = jrt.Intern("captured")

var Lit_295 *jrt.String = jrt.Intern("binding-sym")

var Lit_296 *jrt.String = jrt.Intern("fields-of")

var Lit_297 *jrt.String = jrt.Intern("take-while")

var Lit_298 *jrt.String = jrt.Intern("superclass-chain")

var Lit_299 *jrt.String = jrt.Intern("fields")

var Lit_300 *jrt.String = jrt.Intern("vh-field?")

var Lit_301 *jrt.String = jrt.Intern("volatile-flag")

var Lit_302 *jrt.String = jrt.Intern(".Load")

var Lit_303 *jrt.String = jrt.Intern("int8")

var Lit_304 *jrt.String = jrt.Intern("uint16")

var Lit_305 *jrt.String = jrt.Intern("math")

var Lit_306 *jrt.String = jrt.Intern("Float64frombits")

var Lit_307 *jrt.String = jrt.Intern("Float32frombits")

var Lit_308 *jrt.String = jrt.Intern("int16")

var Lit_309 *jrt.String = jrt.Intern(".Store")

var Lit_310 *jrt.String = jrt.Intern("int32")

var Lit_311 *jrt.String = jrt.Intern("Float64bits")

var Lit_312 *jrt.String = jrt.Intern("Float32bits")

var Lit_313 *jrt.String = jrt.Intern("struct-of")

var Lit_314 *jrt.String = jrt.Intern("ptr")

var Lit_315 *jrt.String = jrt.Intern("into")

var Lit_316 *jrt.String = jrt.Intern("operands")

var Lit_317 *jrt.String = jrt.Intern("munge-name")

var Lit_318 *jrt.String = jrt.Intern("csym")

var Lit_319 *jrt.String = jrt.Intern("array?")

var Lit_320 *jrt.String = jrt.Intern(".ArrayClass")

var Lit_321 *jrt.String = jrt.Intern("class-val")

var Lit_322 *jrt.String = jrt.Intern("cuts")

var Lit_323 *jrt.String = jrt.Intern("vt")

var Lit_324 *jrt.String = jrt.Intern("stmt!")

var Lit_325 *jrt.String = jrt.Intern("assign!")

var Lit_326 *jrt.String = jrt.Intern("var")

var Lit_327 *jrt.String = jrt.Intern("go")

var Lit_328 *jrt.String = jrt.Intern("hoist")

var Lit_329 *jrt.String = jrt.Intern("expr-op")

var Lit_330 *jrt.String = jrt.Intern("emit!")

var Lit_331 *jrt.String = jrt.Intern("cast-val")

var Lit_332 *jrt.String = jrt.Intern("target-operands")

var Lit_333 *jrt.String = jrt.Intern("field-place")

var Lit_334 *jrt.String = jrt.Intern("null-checked")

var Lit_335 *jrt.String = jrt.Intern("lambda-val")

var Lit_336 *jrt.String = jrt.Intern("volatile-field?")

var Lit_337 *jrt.String = jrt.Intern("volatile-read")

var Lit_338 *jrt.String = jrt.Intern("convert-val")

var Lit_339 *jrt.String = jrt.Intern("lang-class")

var Lit_340 *jrt.String = jrt.Intern(".Deref__O")

var Lit_341 *jrt.String = jrt.Intern("static-place")

var Lit_342 *jrt.String = jrt.Intern("repeat")

var Lit_343 *jrt.String = jrt.Intern("method-desc")

var Lit_344 *jrt.String = jrt.Intern("map")

var Lit_345 *jrt.String = jrt.Intern("invoke-val")

var Lit_346 *jrt.String = jrt.Intern("cond-expr")

var Lit_347 *jrt.String = jrt.Intern("compare")

var Lit_348 *jrt.String = jrt.Intern("cmp")

var Lit_349 *jrt.String = jrt.Intern("local-val")

var Lit_350 *jrt.String = jrt.Intern("==")

var Lit_351 *jrt.String = jrt.Intern("instance-val")

var Lit_352 *jrt.String = jrt.Intern("identical?")

var Lit_353 *jrt.String = jrt.Intern("arith-val")

var Lit_354 *jrt.String = jrt.Intern("any")

var Lit_355 *jrt.String = jrt.Intern("new-val")

var Lit_356 *jrt.String = jrt.Intern("array-val")

var Lit_357 *jrt.String = jrt.Intern("outer-param-path")

var Lit_358 *jrt.String = jrt.Intern("bool=")

var Lit_359 *jrt.String = jrt.Intern("len")

var Lit_360 *jrt.String = jrt.Intern(".-A")

var Lit_361 *jrt.String = jrt.Intern("method-ref-val")

var Lit_362 *jrt.String = jrt.Intern("this-path-val")

var Lit_363 *jrt.String = jrt.Intern("fi-adapter-val")

var Lit_364 *jrt.String = jrt.Intern("java-str-val")

var Lit_365 *jrt.String = jrt.Intern("const-value")

var Lit_366 *jrt.String = jrt.Intern("!=")

var Lit_367 *jrt.String = jrt.Intern("float?")

var Lit_368 *jrt.String = jrt.Intern("18446744073709551616N")

var Lit_369 *jrt.String = jrt.Intern("family")

var Lit_370 *jrt.String = jrt.Intern("ushr")

var Lit_371 *jrt.String = jrt.Intern("shr")

var Lit_372 *jrt.String = jrt.Intern("shl")

var Lit_373 *jrt.String = jrt.Intern("go-lit?")

var Lit_374 *jrt.String = jrt.Intern("bit-and")

var Lit_375 *jrt.String = jrt.Intern("*")

var Lit_376 *jrt.String = jrt.Intern("exact")

var Lit_377 *jrt.String = jrt.Intern("mul")

var Lit_378 *jrt.String = jrt.Intern("sub")

var Lit_379 *jrt.String = jrt.Intern("dec")

var Lit_380 *jrt.String = jrt.Intern("/")

var Lit_381 *jrt.String = jrt.Intern("%")

var Lit_382 *jrt.String = jrt.Intern("float32")

var Lit_383 *jrt.String = jrt.Intern("Mod")

var Lit_384 *jrt.String = jrt.Intern("float64")

var Lit_385 *jrt.String = jrt.Intern("int64")

var Lit_386 *jrt.String = jrt.Intern(">>")

var Lit_387 *jrt.String = jrt.Intern("uint64")

var Lit_388 *jrt.String = jrt.Intern("unsigned-lit")

var Lit_389 *jrt.String = jrt.Intern("uint32")

var Lit_390 *jrt.String = jrt.Intern("-")

var Lit_391 *jrt.String = jrt.Intern("bit-not")

var Lit_392 *jrt.String = jrt.Intern("bit-or")

var Lit_393 *jrt.String = jrt.Intern("+")

var Lit_394 *jrt.String = jrt.Intern("bit-xor")

var Lit_395 *jrt.String = jrt.Intern("neg")

var Lit_396 *jrt.String = jrt.Intern("andnot")

var Lit_397 *jrt.String = jrt.Intern("bit-and-not")

var Lit_398 *jrt.String = jrt.Intern("<<")

var Lit_399 *jrt.String = jrt.Intern("fold-int-conv")

var Lit_400 *jrt.String = jrt.Intern("B")

var Lit_401 *jrt.String = jrt.Intern("C")

var Lit_402 *jrt.String = jrt.Intern("S")

var Lit_403 *jrt.String = jrt.Intern("prim-go")

var Lit_404 *jrt.String = jrt.Intern("to")

var Lit_405 *jrt.String = jrt.Intern("assignable?")

var Lit_406 *jrt.String = jrt.Intern(".IsInstance_O__Z")

var Lit_407 *jrt.String = jrt.Intern("parse-method-desc")

var Lit_408 *jrt.String = jrt.Intern("super")

var Lit_409 *jrt.String = jrt.Intern("i32")

var Lit_410 *jrt.String = jrt.Intern("narrow")

var Lit_411 *jrt.String = jrt.Intern("i64")

var Lit_412 *jrt.String = jrt.Intern("f32")

var Lit_413 *jrt.String = jrt.Intern("f64")

var Lit_414 *jrt.String = jrt.Intern("vol")

var Lit_415 *jrt.String = jrt.Intern("addr")

var Lit_416 *jrt.String = jrt.Intern(".CompareAndSet")

var Lit_417 *jrt.String = jrt.Intern(".CompareAndSwap")

var Lit_418 *jrt.String = jrt.Intern(".Swap")

var Lit_419 *jrt.String = jrt.Intern("volatile-write")

var Lit_420 *jrt.String = jrt.Intern("vh-result")

var Lit_421 *jrt.String = jrt.Intern("vh-arg")

var Lit_422 *jrt.String = jrt.Intern("second")

var Lit_423 *jrt.String = jrt.Intern("drop")

var Lit_424 *jrt.String = jrt.Intern("[B")

var Lit_425 *jrt.String = jrt.Intern("order")

var Lit_426 *jrt.String = jrt.Intern("vh-field-form")

var Lit_427 *jrt.String = jrt.Intern("vh-val")

var Lit_428 *jrt.String = jrt.Intern("args-for")

var Lit_429 *jrt.String = jrt.Intern("interface?")

var Lit_430 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_431 *jrt.String = jrt.Intern("struct-methods")

var Lit_432 *jrt.String = jrt.Intern("private?")

var Lit_433 *jrt.String = jrt.Intern("object-helpers")

var Lit_434 *jrt.String = jrt.Intern("notifyAll")

var Lit_435 *jrt.String = jrt.Intern("()V")

var Lit_436 *jrt.String = jrt.Intern("wait")

var Lit_437 *jrt.String = jrt.Intern("(J)V")

var Lit_438 *jrt.String = jrt.Intern("notify")

var Lit_439 *jrt.String = jrt.Intern("cast-to")

var Lit_440 *jrt.String = jrt.Intern(".Copy")

var Lit_441 *jrt.String = jrt.Intern("impl-name")

var Lit_442 *jrt.String = jrt.Intern("super-struct")

var Lit_443 *jrt.String = jrt.Intern("info")

var Lit_444 *jrt.String = jrt.Intern("split-at")

var Lit_445 *jrt.String = jrt.Intern("enum-const")

var Lit_446 *jrt.String = jrt.Intern("anon")

var Lit_447 *jrt.String = jrt.Intern("outer-instance?")

var Lit_448 *jrt.String = jrt.Intern("super-outer")

var Lit_449 *jrt.String = jrt.Intern("ordinal")

var Lit_450 *jrt.String = jrt.Intern("nesting")

var Lit_451 *jrt.String = jrt.Intern("captures")

var Lit_452 *jrt.String = jrt.Intern("state")

var Lit_453 *jrt.String = jrt.Intern("ctor-real-desc")

var Lit_454 *jrt.String = jrt.Intern("ctor-args")

var Lit_455 *jrt.String = jrt.Intern("pkg-name")

var Lit_456 *jrt.String = jrt.Intern("utf8-safe?")

var Lit_457 *jrt.String = jrt.Intern("hole")

var Lit_458 *jrt.String = jrt.Intern("const-tree")

var Lit_459 *jrt.String = jrt.Intern("arr")

var Lit_460 *jrt.String = jrt.Intern("reduce")

var Lit_461 *jrt.String = jrt.Intern("const-strings")

var Lit_462 *jrt.String = jrt.Intern("keep-indexed")

var Lit_463 *jrt.String = jrt.Intern("const-encode")

var Lit_464 *jrt.String = jrt.Intern("const-array-min")

var Lit_465 *jrt.String = jrt.Intern("lit")

var Lit_466 *jrt.String = jrt.Intern("slice")

var Lit_467 *jrt.String = jrt.Intern("const-array")

var Lit_468 *jrt.String = jrt.Intern("prim-array-go")

var Lit_469 *jrt.String = jrt.Intern("subs")

var Lit_470 *jrt.String = jrt.Intern("zipmap")

var Lit_471 *jrt.String = jrt.Intern("literal")

var Lit_472 *jrt.String = jrt.Intern("tag-const")

var Lit_473 *jrt.String = jrt.Intern("map-indexed")

var Lit_474 *jrt.String = jrt.Intern("targets")

var Lit_475 *jrt.String = jrt.Intern("try-frame")

var Lit_476 *jrt.String = jrt.Intern("codes")

var Lit_477 *jrt.String = jrt.Intern("code")

var Lit_478 *jrt.String = jrt.Intern("return")

var Lit_479 *jrt.String = jrt.Intern("rv")

var Lit_480 *jrt.String = jrt.Intern("rv-zero")

var Lit_481 *jrt.String = jrt.Intern("fn-id")

var Lit_482 *jrt.String = jrt.Intern("outside?")

var Lit_483 *jrt.String = jrt.Intern("code-jump!")

var Lit_484 *jrt.String = jrt.Intern("method-fn")

var Lit_485 *jrt.String = jrt.Intern("void")

var Lit_486 *jrt.String = jrt.Intern("expr-as")

var Lit_487 *jrt.String = jrt.Intern("class-init-call")

var Lit_488 *jrt.String = jrt.Intern("note-store!")

var Lit_489 *jrt.String = jrt.Intern("desc-in-world?")

var Lit_490 *jrt.String = jrt.Intern("stmt!*")

var Lit_491 *jrt.String = jrt.Intern("break")

var Lit_492 *jrt.String = jrt.Intern("translate-ctx")

var Lit_493 *jrt.String = jrt.Intern("assert")

var Lit_494 *jrt.String = jrt.Intern("try")

var Lit_495 *jrt.String = jrt.Intern("if")

var Lit_496 *jrt.String = jrt.Intern("dropped-store?")

var Lit_497 *jrt.String = jrt.Intern("k")

var Lit_498 *jrt.String = jrt.Intern("stmt")

var Lit_499 *jrt.String = jrt.Intern("ctor-call")

var Lit_500 *jrt.String = jrt.Intern("ctor-call-fn")

var Lit_501 *jrt.String = jrt.Intern("aset")

var Lit_502 *jrt.String = jrt.Intern("label")

var Lit_503 *jrt.String = jrt.Intern("if-instance")

var Lit_504 *jrt.String = jrt.Intern("for-each")

var Lit_505 *jrt.String = jrt.Intern("set-field!")

var Lit_506 *jrt.String = jrt.Intern("switch")

var Lit_507 *jrt.String = jrt.Intern("set-static!")

var Lit_508 *jrt.String = jrt.Intern("loop")

var Lit_509 *jrt.String = jrt.Intern("monitor")

var Lit_510 *jrt.String = jrt.Intern("recur")

var Lit_511 *jrt.String = jrt.Intern("bindings")

var Lit_512 *jrt.String = jrt.Intern("cval")

var Lit_513 *jrt.String = jrt.Intern("body")

var Lit_514 *jrt.String = jrt.Intern("set-local")

var Lit_515 *jrt.String = jrt.Intern("do")

var Lit_516 *jrt.String = jrt.Intern("run!")

var Lit_517 *jrt.String = jrt.Intern("statements")

var Lit_518 *jrt.String = jrt.Intern("ret")

var Lit_519 *jrt.String = jrt.Intern("throw")

var Lit_520 *jrt.String = jrt.Intern("when")

var Lit_521 *jrt.String = jrt.Intern("panic")

var Lit_522 *jrt.String = jrt.Intern("method-ret")

var Lit_523 *jrt.String = jrt.Intern("method-return!")

var Lit_524 *jrt.String = jrt.Intern("go-call?")

var Lit_525 *jrt.String = jrt.Intern("go-heads")

var Lit_526 *jrt.String = jrt.Intern("starts-with?")

var Lit_527 *jrt.String = jrt.Intern("assign")

var Lit_528 *jrt.String = jrt.Intern("translate-ctx*")

var Lit_529 *jrt.String = jrt.Intern("ctx-desc")

var Lit_530 *jrt.String = jrt.Intern("assign-value!")

var Lit_531 *jrt.String = jrt.Intern("msg")

var Lit_532 *jrt.String = jrt.Intern("translate-if-instance")

var Lit_533 *jrt.String = jrt.Intern("translate-and-or")

var Lit_534 *jrt.String = jrt.Intern("jump")

var Lit_535 *jrt.String = jrt.Intern("target-info")

var Lit_536 *jrt.String = jrt.Intern("ctx")

var Lit_537 *jrt.String = jrt.Intern("test")

var Lit_538 *jrt.String = jrt.Intern("msg-desc")

var Lit_539 *jrt.String = jrt.Intern("translate-monitor")

var Lit_540 *jrt.String = jrt.Intern("translate-try")

var Lit_541 *jrt.String = jrt.Intern("with-block")

var Lit_542 *jrt.String = jrt.Intern("translate-for-each")

var Lit_543 *jrt.String = jrt.Intern("then")

var Lit_544 *jrt.String = jrt.Intern("translate-switch")

var Lit_545 *jrt.String = jrt.Intern("translate-label")

var Lit_546 *jrt.String = jrt.Intern("translate-loop")

var Lit_547 *jrt.String = jrt.Intern("label-used")

var Lit_548 *jrt.String = jrt.Intern("types")

var Lit_549 *jrt.String = jrt.Intern("values")

var Lit_550 *jrt.String = jrt.Intern("continue")

var Lit_551 *jrt.String = jrt.Intern("keyword")

var Lit_552 *jrt.String = jrt.Intern("new-label")

var Lit_553 *jrt.String = jrt.Intern("comp")

var Lit_554 *jrt.String = jrt.Intern("assoc-in")

var Lit_555 *jrt.String = jrt.Intern("while")

var Lit_556 *jrt.String = jrt.Intern("default")

var Lit_557 *jrt.String = jrt.Intern("hidden")

var Lit_558 *jrt.String = jrt.Intern("elem")

var Lit_559 *jrt.String = jrt.Intern("i")

var Lit_560 *jrt.String = jrt.Intern("coll")

var Lit_561 *jrt.String = jrt.Intern("for")

var Lit_562 *jrt.String = jrt.Intern("<")

var Lit_563 *jrt.String = jrt.Intern("inc!")

var Lit_564 *jrt.String = jrt.Intern("it")

var Lit_565 *jrt.String = jrt.Intern("iterator")

var Lit_566 *jrt.String = jrt.Intern(".HasNext__Z")

var Lit_567 *jrt.String = jrt.Intern("pop")

var Lit_568 *jrt.String = jrt.Intern("peek")

var Lit_569 *jrt.String = jrt.Intern("pattern-bindings")

var Lit_570 *jrt.String = jrt.Intern("pattern")

var Lit_571 *jrt.String = jrt.Intern("comps")

var Lit_572 *jrt.String = jrt.Intern("record")

var Lit_573 *jrt.String = jrt.Intern("record-accessor")

var Lit_574 *jrt.String = jrt.Intern("derived")

var Lit_575 *jrt.String = jrt.Intern("methods")

var Lit_576 *jrt.String = jrt.Intern("derived-accessor")

var Lit_577 *jrt.String = jrt.Intern("virtual")

var Lit_578 *jrt.String = jrt.Intern("fn")

var Lit_579 *jrt.String = jrt.Intern("results")

var Lit_580 *jrt.String = jrt.Intern("exc")

var Lit_581 *jrt.String = jrt.Intern("defer")

var Lit_582 *jrt.String = jrt.Intern("accessor")

var Lit_583 *jrt.String = jrt.Intern("match-pattern!")

var Lit_584 *jrt.String = jrt.Intern("accessor-call!")

var Lit_585 *jrt.String = jrt.Intern("record-pattern?")

var Lit_586 *jrt.String = jrt.Intern("declare-pattern!")

var Lit_587 *jrt.String = jrt.Intern("constants")

var Lit_588 *jrt.String = jrt.Intern("reflected")

var Lit_589 *jrt.String = jrt.Intern("enum-constants")

var Lit_590 *jrt.String = jrt.Intern("cases")

var Lit_591 *jrt.String = jrt.Intern("last")

var Lit_592 *jrt.String = jrt.Intern("reset!")

var Lit_593 *jrt.String = jrt.Intern("guard")

var Lit_594 *jrt.String = jrt.Intern("enum")

var Lit_595 *jrt.String = jrt.Intern(".Equals_O__Z")

var Lit_596 *jrt.String = jrt.Intern("int")

var Lit_597 *jrt.String = jrt.Intern("string")

var Lit_598 *jrt.String = jrt.Intern("group-by")

var Lit_599 *jrt.String = jrt.Intern("labels")

var Lit_600 *jrt.String = jrt.Intern("vector")

var Lit_601 *jrt.String = jrt.Intern("sel")

var Lit_602 *jrt.String = jrt.Intern("case")

var Lit_603 *jrt.String = jrt.Intern("java-hash")

var Lit_604 *jrt.String = jrt.Intern("cond")

var Lit_605 *jrt.String = jrt.Intern(".HashCode__I")

var Lit_606 *jrt.String = jrt.Intern("sort-by")

var Lit_607 *jrt.String = jrt.Intern("key")

var Lit_608 *jrt.String = jrt.Intern("sel-type")

var Lit_609 *jrt.String = jrt.Intern(".-F_ordinal")

var Lit_610 *jrt.String = jrt.Intern(".Self_Enum")

var Lit_611 *jrt.String = jrt.Intern("enum-ordinal")

var Lit_612 *jrt.String = jrt.Intern("classes")

var Lit_613 *jrt.String = jrt.Intern("catches")

var Lit_614 *jrt.String = jrt.Intern("catch?")

var Lit_615 *jrt.String = jrt.Intern("gensym")

var Lit_616 *jrt.String = jrt.Intern("forms")

var Lit_617 *jrt.String = jrt.Intern("rv?")

var Lit_618 *jrt.String = jrt.Intern("ctl?")

var Lit_619 *jrt.String = jrt.Intern("ctl")

var Lit_620 *jrt.String = jrt.Intern("finally")

var Lit_621 *jrt.String = jrt.Intern("normal-finally")

var Lit_622 *jrt.String = jrt.Intern("try-literal")

var Lit_623 *jrt.String = jrt.Intern("literal-form")

var Lit_624 *jrt.String = jrt.Intern("dispatch-codes!")

var Lit_625 *jrt.String = jrt.Intern("live-catches")

var Lit_626 *jrt.String = jrt.Intern("take-nth")

var Lit_627 *jrt.String = jrt.Intern("lock")

var Lit_628 *jrt.String = jrt.Intern("find-sam")

var Lit_629 *jrt.String = jrt.Intern("sam")

var Lit_630 *jrt.String = jrt.Intern("ps")

var Lit_631 *jrt.String = jrt.Intern("r")

var Lit_632 *jrt.String = jrt.Intern("sort")

var Lit_633 *jrt.String = jrt.Intern("distinct")

var Lit_634 *jrt.String = jrt.Intern("serializable")

var Lit_635 *jrt.String = jrt.Intern("java/io/Serializable")

var Lit_636 *jrt.String = jrt.Intern("markers")

var Lit_637 *jrt.String = jrt.Intern("lambdas")

var Lit_638 *jrt.String = jrt.Intern("adapter-sym")

var Lit_639 *jrt.String = jrt.Intern("sam-sig")

var Lit_640 *jrt.String = jrt.Intern("params")

var Lit_641 *jrt.String = jrt.Intern("convert-ref-or-prim")

var Lit_642 *jrt.String = jrt.Intern("inst-desc")

var Lit_643 *jrt.String = jrt.Intern("Fn")

var Lit_644 *jrt.String = jrt.Intern("lambda-markers")

var Lit_645 *jrt.String = jrt.Intern("list*")

var Lit_646 *jrt.String = jrt.Intern("invoker-desc")

var Lit_647 *jrt.String = jrt.Intern("f")

var Lit_648 *jrt.String = jrt.Intern("invoker")

var Lit_649 *jrt.String = jrt.Intern("isfn")

var Lit_650 *jrt.String = jrt.Intern("unbound")

var Lit_651 *jrt.String = jrt.Intern("find-method")

var Lit_652 *jrt.String = jrt.Intern("null-check")

var Lit_653 *jrt.String = jrt.Intern("arbace.a2g.code$accessor_call_BANG_")

var Lit_654 *jrt.String = jrt.Intern(".-")

var Lit_655 *jrt.String = jrt.Intern("MatchException_New_String_Throwable")

var Lit_656 *jrt.String = jrt.Intern("Throwable_I")

var Lit_657 *jrt.String = jrt.Intern("Catch")

var Lit_658 *jrt.String = jrt.Intern("Thrown")

var Lit_659 *jrt.String = jrt.Intern("StrOfObj")

var Lit_660 *jrt.String = jrt.Intern("arbace.a2g.code$adapter_sym")

var Lit_661 *jrt.String = jrt.Intern("_Fn")

var Lit_662 *jrt.String = jrt.Intern("arbace.a2g.code$adapter_sym$fn__16000794")

var Lit_663 *jrt.String = jrt.Intern("arbace.a2g.code$any_after")

var Lit_664 *jrt.String = jrt.Intern("arbace.a2g.code$args_for")

var Lit_665 *jrt.String = jrt.Intern("arbace.a2g.code$arith_val")

var Lit_666 *jrt.String = jrt.Intern("Math_MultiplyExact_J_J__J")

var Lit_667 *jrt.String = jrt.Intern("Math_AddExact_J_J__J")

var Lit_668 *jrt.String = jrt.Intern("Math_IncrementExact_J__J")

var Lit_669 *jrt.String = jrt.Intern("Math_SubtractExact_J_J__J")

var Lit_670 *jrt.String = jrt.Intern("Math_DecrementExact_J__J")

var Lit_671 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_672 *jrt.String = jrt.Intern("arbace.a2g.code$arith_val$cnt__16000240")

var Lit_673 *jrt.String = jrt.Intern("arbace.a2g.code$arith_val$fmul__16000242")

var Lit_674 *jrt.String = jrt.Intern("arbace.a2g.code$array_val")

var Lit_675 *jrt.String = jrt.Intern("NewMultiArray")

var Lit_676 *jrt.String = jrt.Intern("New")

var Lit_677 *jrt.String = jrt.Intern("NewRefArray")

var Lit_678 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_679 *jrt.String = jrt.Intern("ArrayOf")

var Lit_680 *jrt.String = jrt.Intern("RefArrayOf")

var Lit_681 *jrt.String = jrt.Intern("arbace.a2g.code$assign_BANG_")

var Lit_682 *jrt.String = jrt.Intern("arbace.a2g.code$assign_value_BANG_")

var Lit_683 *jrt.String = jrt.Intern("arbace.a2g.code$binding_sym")

var Lit_684 *jrt.String = jrt.Intern("p")

var Lit_685 *jrt.String = jrt.Intern("arbace.a2g.code$block_forms")

var Lit_686 *jrt.String = jrt.Intern("arbace.a2g.code$box_val")

var Lit_687 *jrt.String = jrt.Intern("valueOf")

var Lit_688 *jrt.String = jrt.Intern("(")

var Lit_689 *jrt.String = jrt.Intern(")L")

var Lit_690 *jrt.String = jrt.Intern(";")

var Lit_691 *jrt.String = jrt.Intern("arbace.a2g.code$cast_val")

var Lit_692 *jrt.String = jrt.Intern("A2g_CastArray")

var Lit_693 *jrt.String = jrt.Intern("_Cast")

var Lit_694 *jrt.String = jrt.Intern("As")

var Lit_695 *jrt.String = jrt.Intern("arbace.a2g.code$class_init_call")

var Lit_696 *jrt.String = jrt.Intern("_Init")

var Lit_697 *jrt.String = jrt.Intern("arbace.a2g.code$class_missing")

var Lit_698 *jrt.String = jrt.Intern("class ")

var Lit_699 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_700 *jrt.String = jrt.Intern(".")

var Lit_701 *jrt.String = jrt.Intern("arbace.a2g.code$class_val")

var Lit_702 *jrt.String = jrt.Intern("Prim_")

var Lit_703 *jrt.String = jrt.Intern("V")

var Lit_704 *jrt.String = jrt.Intern("Prim_void")

var Lit_705 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_706 *jrt.String = jrt.Intern("Object_class")

var Lit_707 *jrt.String = jrt.Intern("_class")

var Lit_708 *jrt.String = jrt.Intern("arbace.a2g.code$code_jump_BANG_")

var Lit_709 *jrt.String = jrt.Intern("arbace.a2g.code$coerce")

var Lit_710 *jrt.String = jrt.Intern("L")

var Lit_711 *jrt.String = jrt.Intern("Value")

var Lit_712 *jrt.String = jrt.Intern("()")

var Lit_713 *jrt.String = jrt.Intern("NN")

var Lit_714 *jrt.String = jrt.Intern("unexpected primitive coercion ")

var Lit_715 *jrt.String = jrt.Intern(" -> ")

var Lit_716 *jrt.String = jrt.Intern(" in method ")

var Lit_717 *jrt.String = jrt.Intern("pointer coercion ")

var Lit_718 *jrt.String = jrt.Intern("arbace.a2g.code$cond_expr")

var Lit_719 *jrt.String = jrt.Intern("Ljava/lang/Boolean;")

var Lit_720 *jrt.String = jrt.Intern("A2g_Truth")

var Lit_721 *jrt.String = jrt.Intern("arbace.a2g.code$const_array")

var Lit_722 *jrt.String = jrt.Intern("ConstRefArray")

var Lit_723 *jrt.String = jrt.Intern("Class")

var Lit_724 *jrt.String = jrt.Intern("arbace.a2g.code$const_encode")

var Lit_725 *jrt.String = jrt.Intern("[")

var Lit_726 *jrt.String = jrt.Intern(",")

var Lit_727 *jrt.String = jrt.Intern("h")

var Lit_728 *jrt.String = jrt.Intern("s")

var Lit_729 *jrt.String = jrt.Intern(":")

var Lit_730 *jrt.String = jrt.Intern("UTF-8")

var Lit_731 *jrt.String = jrt.Intern("n")

var Lit_732 *jrt.String = jrt.Intern("arbace.a2g.code$const_encode$fn__16000375")

var Lit_733 *jrt.String = jrt.Intern("arbace.a2g.code$const_strings")

var Lit_734 *jrt.String = jrt.Intern("arbace.a2g.code$const_tree")

var Lit_735 *jrt.String = jrt.Intern("arbace.a2g.code$const_tree$fn__16000364")

var Lit_736 *jrt.String = jrt.Intern("arbace.a2g.code$const_value")

var Lit_737 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_738 *jrt.String = jrt.Intern("Clojure constant")

var Lit_739 *jrt.String = jrt.Intern("arbace.a2g.code$convert_ref_or_prim")

var Lit_740 *jrt.String = jrt.Intern("arbace.a2g.code$convert_val")

var Lit_741 *jrt.String = jrt.Intern("unboxing ")

var Lit_742 *jrt.String = jrt.Intern("arbace.a2g.code$csym")

var Lit_743 *jrt.String = jrt.Intern("arbace.a2g.code$ctor_args")

var Lit_744 *jrt.String = jrt.Intern("arbace.a2g.code$ctor_args$iter__16000349__16000353")

var Lit_745 *jrt.String = jrt.Intern("arbace.a2g.code$ctor_args$iter__16000349__16000353$fn__16000354")

var Lit_746 *jrt.String = jrt.Intern("arbace.a2g.code$ctor_args$iter__16000349__16000353$fn__16000354$fn__16000355")

var Lit_747 *jrt.String = jrt.Intern("arbace.a2g.code$ctx_desc")

var Lit_748 *jrt.String = jrt.Intern("arbace.a2g.code$decl_BANG_")

var Lit_749 *jrt.String = jrt.Intern("arbace.a2g.code$declare_pattern_BANG_")

var Lit_750 *jrt.String = jrt.Intern("arbace.a2g.code$declare_pattern_BANG_$fn__16000526")

var Lit_751 *jrt.String = jrt.Intern("arbace.a2g.code$derived_accessor")

var Lit_752 *jrt.String = jrt.Intern("arbace.a2g.code$derived_accessor$fn__16000508")

var Lit_753 *jrt.String = jrt.Intern("arbace.a2g.code$desc_missing")

var Lit_754 *jrt.String = jrt.Intern("arbace.a2g.code$dispatch_codes_BANG_")

var Lit_755 *jrt.String = jrt.Intern("arbace.a2g.code$dispatch_codes_BANG_$clause__16000729")

var Lit_756 *jrt.String = jrt.Intern("arbace.a2g.code$dispatch_codes_BANG_$clause__16000729$fn__16000730")

var Lit_757 *jrt.String = jrt.Intern("arbace.a2g.code$dropped_store_QMARK_")

var Lit_758 *jrt.String = jrt.Intern("arbace.a2g.code$effects_QMARK_")

var Lit_759 *jrt.String = jrt.Intern("arbace.a2g.code$effects_QMARK_$w__16000090")

var Lit_760 *jrt.String = jrt.Intern("arbace.a2g.code$emit_BANG_")

var Lit_761 *jrt.String = jrt.Intern("arbace.a2g.code$enum_ordinal")

var Lit_762 *jrt.String = jrt.Intern("a2g: no constant ")

var Lit_763 *jrt.String = jrt.Intern(" in enum ")

var Lit_764 *jrt.String = jrt.Intern("arbace.a2g.code$enum_ordinal$fn__16000539")

var Lit_765 *jrt.String = jrt.Intern("arbace.a2g.code$enum_ordinal$fn__16000541")

var Lit_766 *jrt.String = jrt.Intern("arbace.a2g.code$enum_ordinal$fn__16000543")

var Lit_767 *jrt.String = jrt.Intern("arbace.a2g.code$enum_ordinal$fn__16000543$fn__16000544")

var Lit_768 *jrt.String = jrt.Intern("arbace.a2g.code$eval16000004$loading__1927001464__auto____16000005")

var Lit_769 *jrt.String = jrt.Intern("arbace.a2g.code$eval16000008$fn__16000009")

var Lit_770 *jrt.String = jrt.Intern("arbace.a2g.code$expr")

var Lit_771 *jrt.String = jrt.Intern("arbace.a2g.code$expr_as")

var Lit_772 *jrt.String = jrt.Intern("arbace.a2g.code$expr_op")

var Lit_773 *jrt.String = jrt.Intern("A2g_NotNull")

var Lit_774 *jrt.String = jrt.Intern("IFn")

var Lit_775 *jrt.String = jrt.Intern("unreachable")

var Lit_776 *jrt.String = jrt.Intern("Ljava/lang/Class;")

var Lit_777 *jrt.String = jrt.Intern("no expression translation for ")

var Lit_778 *jrt.String = jrt.Intern("arbace.a2g.code$expressible_QMARK_")

var Lit_779 *jrt.String = jrt.Intern("arbace.a2g.code$fail")

var Lit_780 *jrt.String = jrt.Intern("a2g: ")

var Lit_781 *jrt.String = jrt.Intern("arbace.a2g.code$fi_adapter_val")

var Lit_782 *jrt.String = jrt.Intern("FnInvokers")

var Lit_783 *jrt.String = jrt.Intern("_InstanceOf")

var Lit_784 *jrt.String = jrt.Intern("arbace.a2g.code$fi_adapter_val$fn__16000846")

var Lit_785 *jrt.String = jrt.Intern("arbace.a2g.code$fi_adapter_val$fn__16000849")

var Lit_786 *jrt.String = jrt.Intern("arbace.a2g.code$fi_adapter_val$iter__16000836__16000840")

var Lit_787 *jrt.String = jrt.Intern("arbace.a2g.code$fi_adapter_val$iter__16000836__16000840$fn__16000841")

var Lit_788 *jrt.String = jrt.Intern("arbace.a2g.code$fi_adapter_val$iter__16000836__16000840$fn__16000841$fn__16000842")

var Lit_789 *jrt.String = jrt.Intern("arbace.a2g.code$field_place")

var Lit_790 *jrt.String = jrt.Intern("arbace.a2g.code$float_lit")

var Lit_791 *jrt.String = jrt.Intern("NaN32")

var Lit_792 *jrt.String = jrt.Intern("NaN64")

var Lit_793 *jrt.String = jrt.Intern("PosInf")

var Lit_794 *jrt.String = jrt.Intern("NegInf")

var Lit_795 *jrt.String = jrt.Intern("32")

var Lit_796 *jrt.String = jrt.Intern("64")

var Lit_797 *jrt.String = jrt.Intern("NegZero32")

var Lit_798 *jrt.String = jrt.Intern("NegZero64")

var Lit_799 *jrt.String = jrt.Intern("arbace.a2g.code$fold_int_conv")

var Lit_800 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items")

var Lit_801 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$fn__16000039")

var Lit_802 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$fn__16000042")

var Lit_803 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$fn__16000066")

var Lit_804 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$iter__16000047__16000053")

var Lit_805 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054")

var Lit_806 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054$iter__16000049__16000058")

var Lit_807 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054$iter__16000049__16000058$fn__16000059")

var Lit_808 *jrt.String = jrt.Intern("arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054$iter__16000049__16000058$fn__16000059$fn__16000060")

var Lit_809 *jrt.String = jrt.Intern("arbace.a2g.code$fresh")

var Lit_810 *jrt.String = jrt.Intern("arbace.a2g.code$fresh_raw")

var Lit_811 *jrt.String = jrt.Intern("arbace.a2g.code$go_call_QMARK_")

var Lit_812 *jrt.String = jrt.Intern("arbace.a2g.code$go_lit_QMARK_")

var Lit_813 *jrt.String = jrt.Intern("arbace.a2g.code$gotype")

var Lit_814 *jrt.String = jrt.Intern("arbace.a2g.code$guarded_static_QMARK_")

var Lit_815 *jrt.String = jrt.Intern("arbace.a2g.code$hoist")

var Lit_816 *jrt.String = jrt.Intern("arbace.a2g.code$hoist_value")

var Lit_817 *jrt.String = jrt.Intern("arbace.a2g.code$hw_static_exists_QMARK_")

var Lit_818 *jrt.String = jrt.Intern("arbace.a2g.code$instance_val")

var Lit_819 *jrt.String = jrt.Intern("A2g_Discard")

var Lit_820 *jrt.String = jrt.Intern("arbace.a2g.code$instance_val$fn__16000255")

var Lit_821 *jrt.String = jrt.Intern("arbace.a2g.code$invoke_val")

var Lit_822 *jrt.String = jrt.Intern("VhFence")

var Lit_823 *jrt.String = jrt.Intern("static Object method")

var Lit_824 *jrt.String = jrt.Intern("getClass")

var Lit_825 *jrt.String = jrt.Intern("GetClass")

var Lit_826 *jrt.String = jrt.Intern("hashCode")

var Lit_827 *jrt.String = jrt.Intern("IdentityHash")

var Lit_828 *jrt.String = jrt.Intern("toString")

var Lit_829 *jrt.String = jrt.Intern("Object_toString")

var Lit_830 *jrt.String = jrt.Intern("clone")

var Lit_831 *jrt.String = jrt.Intern("A2g_ObjectClone")

var Lit_832 *jrt.String = jrt.Intern("equals")

var Lit_833 *jrt.String = jrt.Intern("super call of Object.")

var Lit_834 *jrt.String = jrt.Intern(".Impl_")

var Lit_835 *jrt.String = jrt.Intern(".Self_")

var Lit_836 *jrt.String = jrt.Intern("Object method ")

var Lit_837 *jrt.String = jrt.Intern(" on an Object")

var Lit_838 *jrt.String = jrt.Intern("arbace.a2g.code$invoke_val$rv__16000324")

var Lit_839 *jrt.String = jrt.Intern("arbace.a2g.code$java_hash")

var Lit_840 *jrt.String = jrt.Intern("arbace.a2g.code$java_str_val")

var Lit_841 *jrt.String = jrt.Intern("Concat")

var Lit_842 *jrt.String = jrt.Intern("arbace.a2g.code$java_str_val$fn__16000385")

var Lit_843 *jrt.String = jrt.Intern("arbace.a2g.code$java_str_val$iter__16000387__16000391")

var Lit_844 *jrt.String = jrt.Intern("arbace.a2g.code$java_str_val$iter__16000387__16000391$fn__16000392")

var Lit_845 *jrt.String = jrt.Intern("StrOfInt")

var Lit_846 *jrt.String = jrt.Intern("StrOfChar")

var Lit_847 *jrt.String = jrt.Intern("StrOfDouble")

var Lit_848 *jrt.String = jrt.Intern("StrOfFloat")

var Lit_849 *jrt.String = jrt.Intern("StrOfLong")

var Lit_850 *jrt.String = jrt.Intern("StrOfBool")

var Lit_851 *jrt.String = jrt.Intern("arbace.a2g.code$java_str_val$iter__16000387__16000391$fn__16000392$fn__16000393")

var Lit_852 *jrt.String = jrt.Intern("arbace.a2g.code$jsym")

var Lit_853 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_markers")

var Lit_854 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_markers$fn__16000790")

var Lit_855 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val")

var Lit_856 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val$fn__16000813")

var Lit_857 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val$fn__16000813$fn__16000814")

var Lit_858 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val$fn__16000813$fn__16000827")

var Lit_859 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val$iter__16000803__16000807")

var Lit_860 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val$iter__16000803__16000807$fn__16000808")

var Lit_861 *jrt.String = jrt.Intern("arbace.a2g.code$lambda_val$iter__16000803__16000807$fn__16000808$fn__16000809")

var Lit_862 *jrt.String = jrt.Intern("arbace.a2g.code$literal_QMARK_")

var Lit_863 *jrt.String = jrt.Intern("arbace.a2g.code$literal_form")

var Lit_864 *jrt.String = jrt.Intern("arbace.a2g.code$literal_form$fix__16000739")

var Lit_865 *jrt.String = jrt.Intern("arbace.a2g.code$live_catches")

var Lit_866 *jrt.String = jrt.Intern("arbace.a2g.code$live_catches$fn__16000715")

var Lit_867 *jrt.String = jrt.Intern("arbace.a2g.code$live_catches$fn__16000715$fn__16000716")

var Lit_868 *jrt.String = jrt.Intern("java/lang/Throwable")

var Lit_869 *jrt.String = jrt.Intern("arbace.a2g.code$local_val")

var Lit_870 *jrt.String = jrt.Intern("arbace.a2g.code$lookup_call_QMARK_")

var Lit_871 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_872 *jrt.String = jrt.Intern("lookup")

var Lit_873 *jrt.String = jrt.Intern("arbace.a2g.code$match_pattern_BANG_")

var Lit_874 *jrt.String = jrt.Intern("arbace.a2g.code$match_pattern_BANG_$inner__16000512")

var Lit_875 *jrt.String = jrt.Intern("arbace.a2g.code$match_pattern_BANG_$inner__16000512$comps__16000514")

var Lit_876 *jrt.String = jrt.Intern("arbace.a2g.code$match_pattern_BANG_$inner__16000512$comps__16000514$fn__16000517")

var Lit_877 *jrt.String = jrt.Intern("arbace.a2g.code$mdesc_missing")

var Lit_878 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val")

var Lit_879 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$callf__16000867")

var Lit_880 *jrt.String = jrt.Intern("")

var Lit_881 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$callf__16000867$fn__16000869")

var Lit_882 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$callf__16000867$fn__16000871")

var Lit_883 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$fn__16000876")

var Lit_884 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$iter__16000857__16000861")

var Lit_885 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$iter__16000857__16000861$fn__16000862")

var Lit_886 *jrt.String = jrt.Intern("arbace.a2g.code$method_ref_val$iter__16000857__16000861$fn__16000862$fn__16000863")

var Lit_887 *jrt.String = jrt.Intern("arbace.a2g.code$method_return_BANG_")

var Lit_888 *jrt.String = jrt.Intern("arbace.a2g.code$missing_expr")

var Lit_889 *jrt.String = jrt.Intern("A2g_Missing")

var Lit_890 *jrt.String = jrt.Intern("arbace.a2g.code$missing_reason")

var Lit_891 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_892 *jrt.String = jrt.Intern("a BigInt constant")

var Lit_893 *jrt.String = jrt.Intern("an outer class's super call")

var Lit_894 *jrt.String = jrt.Intern("method ")

var Lit_895 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_896 *jrt.String = jrt.Intern("arbace.a2g.code$missing_reason$fn__16000161")

var Lit_897 *jrt.String = jrt.Intern("arbace.a2g.code$new_counter_BANG_")

var Lit_898 *jrt.String = jrt.Intern("arbace.a2g.code$new_label")

var Lit_899 *jrt.String = jrt.Intern("arbace.a2g.code$new_val")

var Lit_900 *jrt.String = jrt.Intern("Object_New")

var Lit_901 *jrt.String = jrt.Intern("arbace.a2g.code$note_store_BANG_")

var Lit_902 *jrt.String = jrt.Intern("?")

var Lit_903 *jrt.String = jrt.Intern("arbace.a2g.code$object_like_QMARK_")

var Lit_904 *jrt.String = jrt.Intern("arbace.a2g.code$operands")

var Lit_905 *jrt.String = jrt.Intern("arbace.a2g.code$operands$fn__16000110")

var Lit_906 *jrt.String = jrt.Intern("arbace.a2g.code$operands$fn__16000112")

var Lit_907 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000114__16000118")

var Lit_908 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000114__16000118$fn__16000119")

var Lit_909 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000114__16000118$fn__16000119$fn__16000120")

var Lit_910 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000124__16000128")

var Lit_911 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000124__16000128$fn__16000129")

var Lit_912 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000124__16000128$fn__16000129$fn__16000130")

var Lit_913 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000134__16000138")

var Lit_914 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000134__16000138$fn__16000139")

var Lit_915 *jrt.String = jrt.Intern("arbace.a2g.code$operands$iter__16000134__16000138$fn__16000139$fn__16000140")

var Lit_916 *jrt.String = jrt.Intern("arbace.a2g.code$outer_field")

var Lit_917 *jrt.String = jrt.Intern("arbace.a2g.code$outside_QMARK_")

var Lit_918 *jrt.String = jrt.Intern("arbace.a2g.code$pattern_bindings")

var Lit_919 *jrt.String = jrt.Intern("arbace.a2g.code$pattern_bindings$fn__16000500")

var Lit_920 *jrt.String = jrt.Intern("arbace.a2g.code$pkg")

var Lit_921 *jrt.String = jrt.Intern("arbace.a2g.code$prim_convert")

var Lit_922 *jrt.String = jrt.Intern("D2I")

var Lit_923 *jrt.String = jrt.Intern("D2L")

var Lit_924 *jrt.String = jrt.Intern("F2I")

var Lit_925 *jrt.String = jrt.Intern("F2L")

var Lit_926 *jrt.String = jrt.Intern("arbace.a2g.code$reads_state_QMARK_")

var Lit_927 *jrt.String = jrt.Intern("arbace.a2g.code$reads_state_QMARK_$w__16000097")

var Lit_928 *jrt.String = jrt.Intern("arbace.a2g.code$record_pattern_QMARK_")

var Lit_929 *jrt.String = jrt.Intern("arbace.a2g.code$ret_BANG_")

var Lit_930 *jrt.String = jrt.Intern("arbace.a2g.code$sam_sig")

var Lit_931 *jrt.String = jrt.Intern("arbace.a2g.code$set_field_BANG_")

var Lit_932 *jrt.String = jrt.Intern("arbace.a2g.code$set_static_BANG_")

var Lit_933 *jrt.String = jrt.Intern("arbace.a2g.code$simple_QMARK_")

var Lit_934 *jrt.String = jrt.Intern("arbace.a2g.code$simple_QMARK_$fn__16000087")

var Lit_935 *jrt.String = jrt.Intern("arbace.a2g.code$stable_QMARK_")

var Lit_936 *jrt.String = jrt.Intern("arbace.a2g.code$static_place")

var Lit_937 *jrt.String = jrt.Intern("arbace.a2g.code$stmt_BANG_")

var Lit_938 *jrt.String = jrt.Intern("arbace.a2g.code$stmt_BANG__STAR_")

var Lit_939 *jrt.String = jrt.Intern("Ljava/lang/Throwable;")

var Lit_940 *jrt.String = jrt.Intern("arbace.a2g.code$string_lit")

var Lit_941 *jrt.String = jrt.Intern("Lit_")

var Lit_942 *jrt.String = jrt.Intern("arbace.a2g.code$struct_of")

var Lit_943 *jrt.String = jrt.Intern("arbace.a2g.code$struct_of$fn__16000184")

var Lit_944 *jrt.String = jrt.Intern("arbace.a2g.code$struct_of$fn__16000184$fn__16000185")

var Lit_945 *jrt.String = jrt.Intern("arbace.a2g.code$struct_of$fn__16000188")

var Lit_946 *jrt.String = jrt.Intern("arbace.a2g.code$super_struct")

var Lit_947 *jrt.String = jrt.Intern("arbace.a2g.code$tag")

var Lit_948 *jrt.String = jrt.Intern("arbace.a2g.code$target_info")

var Lit_949 *jrt.String = jrt.Intern("arbace.a2g.code$target_operands")

var Lit_950 *jrt.String = jrt.Intern("arbace.a2g.code$this_path_val")

var Lit_951 *jrt.String = jrt.Intern("arbace.a2g.code$this_val")

var Lit_952 *jrt.String = jrt.Intern("no this here")

var Lit_953 *jrt.String = jrt.Intern("arbace.a2g.code$tmp")

var Lit_954 *jrt.String = jrt.Intern("arbace.a2g.code$translate_and_or")

var Lit_955 *jrt.String = jrt.Intern("arbace.a2g.code$translate_and_or$go__16000452")

var Lit_956 *jrt.String = jrt.Intern("arbace.a2g.code$translate_and_or$go__16000452$fn__16000456")

var Lit_957 *jrt.String = jrt.Intern("arbace.a2g.code$translate_ctx")

var Lit_958 *jrt.String = jrt.Intern("arbace.a2g.code$translate_ctx_STAR_")

var Lit_959 *jrt.String = jrt.Intern("AssertionError_New_")

var Lit_960 *jrt.String = jrt.Intern("AssertionError_New")

var Lit_961 *jrt.String = jrt.Intern("A2g_AssertionsDisabled")

var Lit_962 *jrt.String = jrt.Intern("break target not in scope")

var Lit_963 *jrt.String = jrt.Intern("recur target not in scope")

var Lit_964 *jrt.String = jrt.Intern("arbace.a2g.code$translate_ctx_STAR_$fn__16000434")

var Lit_965 *jrt.String = jrt.Intern("arbace.a2g.code$translate_ctx_STAR_$fn__16000436")

var Lit_966 *jrt.String = jrt.Intern("arbace.a2g.code$translate_ctx_STAR_$fn__16000440")

var Lit_967 *jrt.String = jrt.Intern("arbace.a2g.code$translate_ctx_STAR_$fn__16000442")

var Lit_968 *jrt.String = jrt.Intern("arbace.a2g.code$translate_for_each")

var Lit_969 *jrt.String = jrt.Intern("Ljava/util/Iterator;")

var Lit_970 *jrt.String = jrt.Intern("arbace.a2g.code$translate_for_each$fn__16000487")

var Lit_971 *jrt.String = jrt.Intern("arbace.a2g.code$translate_for_each$fn__16000487$fn__16000488")

var Lit_972 *jrt.String = jrt.Intern("arbace.a2g.code$translate_for_each$fn__16000491")

var Lit_973 *jrt.String = jrt.Intern("arbace.a2g.code$translate_for_each$fn__16000491$fn__16000492")

var Lit_974 *jrt.String = jrt.Intern("arbace.a2g.code$translate_for_each$fn__16000495")

var Lit_975 *jrt.String = jrt.Intern("arbace.a2g.code$translate_if_instance")

var Lit_976 *jrt.String = jrt.Intern("arbace.a2g.code$translate_if_instance$fn__16000529")

var Lit_977 *jrt.String = jrt.Intern("arbace.a2g.code$translate_if_instance$fn__16000531")

var Lit_978 *jrt.String = jrt.Intern("arbace.a2g.code$translate_if_instance$fn__16000533")

var Lit_979 *jrt.String = jrt.Intern("arbace.a2g.code$translate_if_instance$fn__16000535")

var Lit_980 *jrt.String = jrt.Intern("arbace.a2g.code$translate_label")

var Lit_981 *jrt.String = jrt.Intern("arbace.a2g.code$translate_label$fn__16000482")

var Lit_982 *jrt.String = jrt.Intern("arbace.a2g.code$translate_label$fn__16000482$fn__16000483")

var Lit_983 *jrt.String = jrt.Intern("arbace.a2g.code$translate_loop")

var Lit_984 *jrt.String = jrt.Intern("arbace.a2g.code$translate_loop$fn__16000477")

var Lit_985 *jrt.String = jrt.Intern("arbace.a2g.code$translate_loop$fn__16000477$fn__16000478")

var Lit_986 *jrt.String = jrt.Intern("arbace.a2g.code$translate_loop$iter__16000461__16000465")

var Lit_987 *jrt.String = jrt.Intern("arbace.a2g.code$translate_loop$iter__16000461__16000465$fn__16000466")

var Lit_988 *jrt.String = jrt.Intern("arbace.a2g.code$translate_loop$iter__16000461__16000465$fn__16000466$fn__16000467")

var Lit_989 *jrt.String = jrt.Intern("arbace.a2g.code$translate_monitor")

var Lit_990 *jrt.String = jrt.Intern("MonitorEnter")

var Lit_991 *jrt.String = jrt.Intern("arbace.a2g.code$translate_monitor$fn__16000780")

var Lit_992 *jrt.String = jrt.Intern("arbace.a2g.code$translate_monitor$fn__16000780$fn__16000781")

var Lit_993 *jrt.String = jrt.Intern("MonitorExit")

var Lit_994 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch")

var Lit_995 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$arm__16000558")

var Lit_996 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$arm__16000558$fn__16000559")

var Lit_997 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$arm_done__16000574")

var Lit_998 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$done__16000572")

var Lit_999 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000553")

var Lit_1000 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000562")

var Lit_1001 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000567")

var Lit_1002 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580")

var Lit_1003 *jrt.String = jrt.Intern("NPE")

var Lit_1004 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000585")

var Lit_1005 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000587")

var Lit_1006 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000589")

var Lit_1007 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000591")

var Lit_1008 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000593")

var Lit_1009 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000595")

var Lit_1010 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000597")

var Lit_1011 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000580$fn__16000599")

var Lit_1012 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000635")

var Lit_1013 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$fn__16000638")

var Lit_1014 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$guarded__16000576")

var Lit_1015 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000602__16000606")

var Lit_1016 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607")

var Lit_1017 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607$fn__16000608")

var Lit_1018 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607$fn__16000608$fn__16000609")

var Lit_1019 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607$fn__16000612")

var Lit_1020 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000616__16000622")

var Lit_1021 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623")

var Lit_1022 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623$iter__16000618__16000627")

var Lit_1023 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623$iter__16000618__16000627$fn__16000628")

var Lit_1024 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623$iter__16000618__16000627$fn__16000628$fn__16000629")

var Lit_1025 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000643__16000647")

var Lit_1026 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648")

var Lit_1027 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648$fn__16000649")

var Lit_1028 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648$fn__16000649$fn__16000654")

var Lit_1029 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648$fn__16000664")

var Lit_1030 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000671__16000675")

var Lit_1031 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676")

var Lit_1032 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676$fn__16000677")

var Lit_1033 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676$fn__16000677$fn__16000682")

var Lit_1034 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676$fn__16000692")

var Lit_1035 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000699__16000703")

var Lit_1036 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704")

var Lit_1037 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704$fn__16000705")

var Lit_1038 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704$fn__16000705$fn__16000706")

var Lit_1039 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704$fn__16000709")

var Lit_1040 *jrt.String = jrt.Intern("arbace.a2g.code$translate_switch$label_test__16000578")

var Lit_1041 *jrt.String = jrt.Intern("a constant pattern label")

var Lit_1042 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try")

var Lit_1043 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$fn__16000773")

var Lit_1044 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749")

var Lit_1045 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000750")

var Lit_1046 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000752")

var Lit_1047 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000754")

var Lit_1048 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000754$fn__16000755")

var Lit_1049 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000754$fn__16000767")

var Lit_1050 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000754$iter__16000757__16000761")

var Lit_1051 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000754$iter__16000757__16000761$fn__16000762")

var Lit_1052 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000754$iter__16000757__16000761$fn__16000762$fn__16000763")

var Lit_1053 *jrt.String = jrt.Intern("arbace.a2g.code$translate_try$inner__16000749$fn__16000770")

var Lit_1054 *jrt.String = jrt.Intern("arbace.a2g.code$try_literal")

var Lit_1055 *jrt.String = jrt.Intern("arbace.a2g.code$try_literal$fn__16000724")

var Lit_1056 *jrt.String = jrt.Intern("arbace.a2g.code$try_literal$fn__16000726")

var Lit_1057 *jrt.String = jrt.Intern("arbace.a2g.code$unsigned_lit")

var Lit_1058 *jrt.String = jrt.Intern("arbace.a2g.code$up_sym")

var Lit_1059 *jrt.String = jrt.Intern("Up_")

var Lit_1060 *jrt.String = jrt.Intern("arbace.a2g.code$use_sym_BANG_")

var Lit_1061 *jrt.String = jrt.Intern("arbace.a2g.code$utf8_safe_QMARK_")

var Lit_1062 *jrt.String = jrt.Intern("arbace.a2g.code$v")

var Lit_1063 *jrt.String = jrt.Intern("arbace.a2g.code$vh_arg")

var Lit_1064 *jrt.String = jrt.Intern("arbace.a2g.code$vh_field_QMARK_")

var Lit_1065 *jrt.String = jrt.Intern("arbace.a2g.code$vh_field_form")

var Lit_1066 *jrt.String = jrt.Intern("Xor")

var Lit_1067 *jrt.String = jrt.Intern("And")

var Lit_1068 *jrt.String = jrt.Intern("Or")

var Lit_1069 *jrt.String = jrt.Intern("VhGetAnd")

var Lit_1070 *jrt.String = jrt.Intern("Bool")

var Lit_1071 *jrt.String = jrt.Intern("VhGetAndXorInt32")

var Lit_1072 *jrt.String = jrt.Intern("VhGetAndXorInt64")

var Lit_1073 *jrt.String = jrt.Intern("VhGetAndAddFloat32")

var Lit_1074 *jrt.String = jrt.Intern("VhGetAndAddInt32")

var Lit_1075 *jrt.String = jrt.Intern("VhGetAndAddInt64")

var Lit_1076 *jrt.String = jrt.Intern("VhGetAndAddFloat64")

var Lit_1077 *jrt.String = jrt.Intern("VhCmpXchgBool")

var Lit_1078 *jrt.String = jrt.Intern("VhCmpXchgPtr")

var Lit_1079 *jrt.String = jrt.Intern("VhCmpXchgVol")

var Lit_1080 *jrt.String = jrt.Intern("VhCmpXchgUint32")

var Lit_1081 *jrt.String = jrt.Intern("VhCmpXchgInt32")

var Lit_1082 *jrt.String = jrt.Intern("VhCmpXchgInt64")

var Lit_1083 *jrt.String = jrt.Intern("VhCmpXchgUint64")

var Lit_1084 *jrt.String = jrt.Intern("arbace.a2g.code$vh_field_form$bits__16000273")

var Lit_1085 *jrt.String = jrt.Intern("arbace.a2g.code$vh_field_form$narrow__16000268")

var Lit_1086 *jrt.String = jrt.Intern("arbace.a2g.code$vh_field_form$unbits__16000276")

var Lit_1087 *jrt.String = jrt.Intern("arbace.a2g.code$vh_field_form$widen__16000270")

var Lit_1088 *jrt.String = jrt.Intern("arbace.a2g.code$vh_missing")

var Lit_1089 *jrt.String = jrt.Intern("VarHandle.")

var Lit_1090 *jrt.String = jrt.Intern(" on ")

var Lit_1091 *jrt.String = jrt.Intern(" (A2G-SPEC §8.5)")

var Lit_1092 *jrt.String = jrt.Intern(" on a handle that is not a constant of its class (A2G-SPEC §8.5)")

var Lit_1093 *jrt.String = jrt.Intern("arbace.a2g.code$vh_op")

var Lit_1094 *jrt.String = jrt.Intern("arbace.a2g.code$vh_result")

var Lit_1095 *jrt.String = jrt.Intern("arbace.a2g.code$vh_supported_QMARK_")

var Lit_1096 *jrt.String = jrt.Intern("arbace.a2g.code$vh_val")

var Lit_1097 *jrt.String = jrt.Intern("VhView")

var Lit_1098 *jrt.String = jrt.Intern("Set")

var Lit_1099 *jrt.String = jrt.Intern("Get")

var Lit_1100 *jrt.String = jrt.Intern("Int")

var Lit_1101 *jrt.String = jrt.Intern("Long")

var Lit_1102 *jrt.String = jrt.Intern("IntArray")

var Lit_1103 *jrt.String = jrt.Intern("LongArray")

var Lit_1104 *jrt.String = jrt.Intern("RefArray")

var Lit_1105 *jrt.String = jrt.Intern("GetAndAnd")

var Lit_1106 *jrt.String = jrt.Intern("Cas")

var Lit_1107 *jrt.String = jrt.Intern("Swap")

var Lit_1108 *jrt.String = jrt.Intern("GetAndAdd")

var Lit_1109 *jrt.String = jrt.Intern("GetAndOr")

var Lit_1110 *jrt.String = jrt.Intern("GetAndXor")

var Lit_1111 *jrt.String = jrt.Intern("CmpXchg")

var Lit_1112 *jrt.String = jrt.Intern("Vh")

var Lit_1113 *jrt.String = jrt.Intern("arbace.a2g.code$vh_val$fn__16000301")

var Lit_1114 *jrt.String = jrt.Intern("arbace.a2g.code$vh_val$fn__16000308")

var Lit_1115 *jrt.String = jrt.Intern("arbace.a2g.code$vh_val$fn__16000314")

var Lit_1116 *jrt.String = jrt.Intern("arbace.a2g.code$volatile_field_QMARK_")

var Lit_1117 *jrt.String = jrt.Intern("arbace.a2g.code$volatile_read")

var Lit_1118 *jrt.String = jrt.Intern("arbace.a2g.code$volatile_write")

var Lit_1119 *jrt.String = jrt.Intern("arbace.a2g.code$vt")

var Lit_1120 *jrt.String = jrt.Intern("arbace.a2g.code$with_block")

var Lit_1121 *jrt.String = jrt.Intern("arbace.a2g.code$with_line")

var Lit_1122 *jrt.String = jrt.Intern("arbace.a2g.code$zero_of")

var Lit_1123 *jrt.String = jrt.Intern("in-ns")

var Lit_1124 *jrt.String = jrt.Intern("dynamic")

var Lit_1125 *jrt.String = jrt.Intern("column")

var Lit_1126 *jrt.String = jrt.Intern("file")

var Lit_1127 *jrt.String = jrt.Intern("arbace/a2g/code.ae")

var Lit_1128 *jrt.String = jrt.Intern("The Go function being written: {:pkg :class :static :t :this :method-ret :fn-id :targets\n  :try-frame :captured :ctor-params, and atoms :names :taken :used :counter :pkgstate}.")

var Lit_1129 *jrt.String = jrt.Intern("The statement list being written: an atom of items.")

var Lit_1130 *jrt.String = jrt.Intern("Per package: {:lits (atom {string sym}) :ups (atom #{[from to]}) :lambdas (atom #{fi})\n  :cuts (atom #{class})}; for one class translated on its own (arbace.a2g.main's parallel\n  translation): :lits local with a :lit-prefix, :ups :lambdas :cuts atoms of vectors (what\n  was conj'ed, in order, for the merge to replay).")

var Lit_1131 *jrt.String = jrt.Intern("An atom collecting the candidate two-word races (A2G-SPEC §8.3, Q10), or nil:\n  #{[class field-name desc static? writer]}.")

var Lit_1132 *jrt.String = jrt.Intern("arglists")

var Lit_1133 *jrt.String = jrt.Intern("Records a store into field f (declared in o) when it is a two-word race candidate: a\n  non-final, non-volatile field of interface Go type written outside its class's constructors\n  (static initializer for a static field), not in a synchronized method nor in locking on this.")

var Lit_1134 *jrt.String = jrt.Intern("&")

var Lit_1135 *jrt.String = jrt.Intern("data")

var Lit_1136 *jrt.String = jrt.Intern("ident")

var Lit_1137 *jrt.String = jrt.Intern("suffix")

var Lit_1138 *jrt.String = jrt.Intern("d")

var Lit_1139 *jrt.String = jrt.Intern("private")

var Lit_1140 *jrt.String = jrt.Intern("A fresh Go local name based on s.")

var Lit_1141 *jrt.String = jrt.Intern("A fresh Go local name for a2g's own variables (not munged: no Java local has it).")

var Lit_1142 *jrt.String = jrt.Intern("The Go name of an analyzer binding in the current function.")

var Lit_1143 *jrt.String = jrt.Intern("The class forms line of the node being translated (the analyzer's :line), or nil: the\n  statements written meanwhile carry it as :a2g/line metadata, which arbace.a2g.out turns into\n  the forms' positions (A2G-SPEC §4.3, §7.9.6).")

var Lit_1144 *jrt.String = jrt.Intern("form")

var Lit_1145 *jrt.String = jrt.Intern("form with the current line as :a2g/line, unless it has one (lists only).")

var Lit_1146 *jrt.String = jrt.Intern("gt")

var Lit_1147 *jrt.String = jrt.Intern("init")

var Lit_1148 *jrt.String = jrt.Intern("Declares Go local sym of Go type gt with initial value init (nil: the zero value).")

var Lit_1149 *jrt.String = jrt.Intern("items")

var Lit_1150 *jrt.String = jrt.Intern("Runs f with a fresh statement list; returns the list of Go statements.")

var Lit_1151 *jrt.String = jrt.Intern("block-forms")

var Lit_1152 *jrt.String = jrt.Intern("The Go zero value of descriptor d, as an expression.")

var Lit_1153 *jrt.String = jrt.Intern("literal?")

var Lit_1154 *jrt.String = jrt.Intern("A Go integer literal converted to Java type to (wrapping as Java's conversions do).")

var Lit_1155 *jrt.String = jrt.Intern("declared")

var Lit_1156 *jrt.String = jrt.Intern("ret!")

var Lit_1157 *jrt.String = jrt.Intern("The nil-preserving conversion of pointer type `from` (desc) to interface `to` (desc):\n  .Ref for any, else a generated Up_ function.")

var Lit_1158 *jrt.String = jrt.Intern("Converts Go expression x of Java static type from (a descriptor, :null) to Java type `to`\n  as an assignment conversion that the analyzer left implicit (reference widening): pointer\n  to interface conversions are nil-preserving unless nn (x known not null).")

var Lit_1159 *jrt.String = jrt.Intern("more")

var Lit_1160 *jrt.String = jrt.Intern("Is node's own operation one Go expression (its operands may still need statements)?")

var Lit_1161 *jrt.String = jrt.Intern("A static access that runs C_Init() first (from code outside the class and its subclasses).")

var Lit_1162 *jrt.String = jrt.Intern("Can node be one Go expression (§7.2)?")

var Lit_1163 *jrt.String = jrt.Intern("Can evaluating node change state or throw (§7.2)?")

var Lit_1164 *jrt.String = jrt.Intern("Is node's value at risk from a later operand's call (§7.2): it reads a field, a static or\n  an array element, or can throw (an integer division), outside the arguments of a call of\n  its own (Go orders calls among themselves, and a call's arguments come before it)?")

var Lit_1165 *jrt.String = jrt.Intern("Is node's value unaffected by any later evaluation (a constant, an immutable local, this)?")

var Lit_1166 *jrt.String = jrt.Intern("Puts a translated value into a fresh temporary.")

var Lit_1167 *jrt.String = jrt.Intern("For a vector of flags: whether one after position i is true, for each i (one pass from the\n  right, so that an array initializer of n elements costs n tests, not n squared).")

var Lit_1168 *jrt.String = jrt.Intern("nodes")

var Lit_1169 *jrt.String = jrt.Intern("wants")

var Lit_1170 *jrt.String = jrt.Intern("Translates nodes left to right as operands of one Go expression (or call), each converted\n  to its type in `wants` (a desc or nil). An operand is moved to a temporary when a later\n  operand writes statements or has side effects that could change what it reads.")

var Lit_1171 *jrt.String = jrt.Intern("String")

var Lit_1172 *jrt.String = jrt.Intern("The pooled literal (§7.5) of Java string s: a package variable Lit_n. In a class translated\n  on its own (arbace.a2g.main's parallel translation), :lit-prefix names the class's literals\n  apart, in its own first-use order; the merge renames them Lit_n in the package's order.")

var Lit_1173 *jrt.String = jrt.Intern("why")

var Lit_1174 *jrt.String = jrt.Intern("cls")

var Lit_1175 *jrt.String = jrt.Intern("MethodHandles.lookup(): the lookup VarHandle constants are found with (A2G-SPEC §8.5); in Go\n  a nil of no use, the handles being compiled statically.")

var Lit_1176 *jrt.String = jrt.Intern("The constant VarHandle and access mode of a VarHandle call (A2G-SPEC §8.5), or nil.")

var Lit_1177 *jrt.String = jrt.Intern("Can a2g translate access mode m of a handle of kind k on values of descriptor d?")

var Lit_1178 *jrt.String = jrt.Intern("For a VarHandle call or MethodHandles.lookup(): ::vh-ok when a2g translates it, else why\n  not; nil for any other node.")

var Lit_1179 *jrt.String = jrt.Intern("Why node cannot be translated in this world (a class or member it needs does not exist in\n  Go), or nil.")

var Lit_1180 *jrt.String = jrt.Intern("The whole object of the current instance code: t in a leaf class, this otherwise.")

var Lit_1181 *jrt.String = jrt.Intern("sd")

var Lit_1182 *jrt.String = jrt.Intern("fname")

var Lit_1183 *jrt.String = jrt.Intern("An expression of the struct of declaring class `decl` reached from value x of static type\n  desc sd (§5.2): x itself for a pointer, Self_D for a class interface; through the embedded\n  struct when a nearer class hides a field of the same name. ptr: x is the struct pointer of\n  sd's class itself (t, the receiver).")

var Lit_1184 *jrt.String = jrt.Intern("Does a constant VarHandle of the world name field f (A2G-SPEC §8.5)? It then has the\n  volatile representation.")

var Lit_1185 *jrt.String = jrt.Intern("place")

var Lit_1186 *jrt.String = jrt.Intern("tv")

var Lit_1187 *jrt.String = jrt.Intern("The Go place of instance field f (declared in class o) on value tv.")

var Lit_1188 *jrt.String = jrt.Intern("operands, with this (the current object, no outer hops) as the receiver struct t.")

var Lit_1189 *jrt.String = jrt.Intern("The Class object of descriptor d.")

var Lit_1190 *jrt.String = jrt.Intern("const-or-missing")

var Lit_1191 *jrt.String = jrt.Intern("Translates a node that is not one Go expression into a fresh temporary (assign context).")

var Lit_1192 *jrt.String = jrt.Intern("Translates node in expression context: {:x go-form :t java-desc :nn bool}.")

var Lit_1193 *jrt.String = jrt.Intern("The Go expression of an expressible node's own operation (operands translated as needed).")

var Lit_1194 *jrt.String = jrt.Intern("node's Go expression converted to Java type `to`.")

var Lit_1195 *jrt.String = jrt.Intern("A Go boolean expression of node as a condition (Clojure's truth on non-booleans).")

var Lit_1196 *jrt.String = jrt.Intern("bits")

var Lit_1197 *jrt.String = jrt.Intern("A Go literal of the unsigned value of Java integer v of the given width (Go rejects the\n  conversion of a negative constant to an unsigned type).")

var Lit_1198 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_1199 *jrt.String = jrt.Intern("Equals")

var Lit_1200 *jrt.String = jrt.Intern("()I")

var Lit_1201 *jrt.String = jrt.Intern("HashCode")

var Lit_1202 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_1203 *jrt.String = jrt.Intern("ToString")

var Lit_1204 *jrt.String = jrt.Intern("()Ljava/lang/Class;")

var Lit_1205 *jrt.String = jrt.Intern("Notify")

var Lit_1206 *jrt.String = jrt.Intern("NotifyAll")

var Lit_1207 *jrt.String = jrt.Intern("Wait")

var Lit_1208 *jrt.String = jrt.Intern("WaitTimeout")

var Lit_1209 *jrt.String = jrt.Intern("m-desc")

var Lit_1210 *jrt.String = jrt.Intern("arg-nodes")

var Lit_1211 *jrt.String = jrt.Intern("The embedded struct of the current class's superclass: (.-B t).")

var Lit_1212 *jrt.String = jrt.Intern("An argument node of a VarHandle call converted to descriptor d as the handle does: a\n  checked cast unless its static type is assignable.")

var Lit_1213 *jrt.String = jrt.Intern("A VarHandle call's result form x of descriptor d as the call's return type r (the JVM's\n  checkcast of a polymorphic call's result).")

var Lit_1214 *jrt.String = jrt.Intern("xs")

var Lit_1215 *jrt.String = jrt.Intern("The Go form of access mode m on the atomic field place (the volatile representation of a\n  field of descriptor d, §8.2) with argument forms xs.")

var Lit_1216 *jrt.String = jrt.Intern("A VarHandle access-mode call on a constant handle (A2G-SPEC §8.5): the atomic operation on\n  the field it names, or on the array element (jrt's Vh functions).")

var Lit_1217 *jrt.String = jrt.Intern("cn")

var Lit_1218 *jrt.String = jrt.Intern("The Go arguments of constructor ctor of class cn for a :new or :ctor-call node: the outer\n  instance, the superclass's outer instance, the enum constant's name and ordinal, the\n  declared arguments, the captured locals.")

var Lit_1219 *jrt.String = jrt.Intern("The least number of string leaves for which an initializer is written as data.")

var Lit_1220 *jrt.String = jrt.Intern("Can the Java string travel as Go UTF-8 text (no unpaired surrogates)?")

var Lit_1221 *jrt.String = jrt.Intern("holes")

var Lit_1222 *jrt.String = jrt.Intern("node as a constant array tree ([:arr elem-desc trees], [:str s], [:null], [:hole i]), holes\n  collecting the immutable locals, or nil when it is none.")

var Lit_1223 *jrt.String = jrt.Intern("tree")

var Lit_1224 *jrt.String = jrt.Intern("sb")

var Lit_1225 *jrt.String = jrt.Intern("StringBuilder")

var Lit_1226 *jrt.String = jrt.Intern("The encoding of a tree (jrt's constarray.ae), classes an atom of the element descriptors.")

var Lit_1227 *jrt.String = jrt.Intern("The ConstRefArray call of a reference array initializer that is a constant tree with enough\n  strings, or nil.")

var Lit_1228 *jrt.String = jrt.Intern("A jump (return, break, recur) leaving the Go function literal of a try or locking body: it\n  is recorded in the innermost frame with a control code and performed after the literal\n  returns (§7.9.3). jump is {:kind :return|:break|:recur ...}.")

var Lit_1229 *jrt.String = jrt.Intern("target-fn")

var Lit_1230 *jrt.String = jrt.Intern("val-form")

var Lit_1231 *jrt.String = jrt.Intern("A return from the method (::void for a void method's), a control code inside a try body.")

var Lit_1232 *jrt.String = jrt.Intern("A store into a field that the closed world drops (its type is outside it) that can go:\n  a static initializer's store into a field of its class (serialization's\n  serialPersistentFields: nothing can read the field), or the store of the constant null\n  into a field of this object or a static field (PrintWriter's psOut, a PrintStream: the\n  field can hold nothing else, no instance of its type exists).")

var Lit_1233 *jrt.String = jrt.Intern("Translates node in statement context.")

var Lit_1234 *jrt.String = jrt.Intern("<=")

var Lit_1235 *jrt.String = jrt.Intern("make")

var Lit_1236 *jrt.String = jrt.Intern(">")

var Lit_1237 *jrt.String = jrt.Intern("cap")

var Lit_1238 *jrt.String = jrt.Intern("subslice")

var Lit_1239 *jrt.String = jrt.Intern(">=")

var Lit_1240 *jrt.String = jrt.Intern("Is Go form x a call (which may stand as a statement)?")

var Lit_1241 *jrt.String = jrt.Intern("Translates node storing its value into ctx's variable.")

var Lit_1242 *jrt.String = jrt.Intern("Translates node as the value of the current method (return context).")

var Lit_1243 *jrt.String = jrt.Intern("Translates node in context ctx: {:k :stmt}, {:k :assign :var sym :desc d}, {:k :return}.")

var Lit_1244 *jrt.String = jrt.Intern("keys")

var Lit_1245 *jrt.String = jrt.Intern("The record component field an accessor reads when the record does not declare the accessor\n  itself (the analyzer derived it: it cannot throw), else nil.")

var Lit_1246 *jrt.String = jrt.Intern("rd")

var Lit_1247 *jrt.String = jrt.Intern("c")

var Lit_1248 *jrt.String = jrt.Intern("Assigns record r's component (accessor `accessor`) to Go variable c. A derived accessor is\n  the field read (records are final, r is not null); a declared one is called, and an\n  exception it throws is wrapped in MatchException(t.toString(), t), as javac wraps it\n  (JLS 14.30.2).")

var Lit_1249 *jrt.String = jrt.Intern("Emits the statements matching Go value x (a stable expression of Java type vt) against\n  pattern p: the type tests, the record components read through their accessors, the\n  bindings assigned (declared before by declare-pattern!); calls k to emit what follows a\n  match, inside the tests.")

var Lit_1250 *jrt.String = jrt.Intern("Declares the bindings of pattern p and a flag; returns the flag, set when the value\n  matches (after match-pattern!).")

var Lit_1251 *jrt.String = jrt.Intern("e")

var Lit_1252 *jrt.String = jrt.Intern("The catch clauses of a try node that can catch something: those naming a class of the world.")

var Lit_1253 *jrt.String = jrt.Intern("body-fn")

var Lit_1254 *jrt.String = jrt.Intern("Runs body-fn as the body of a Go function literal called in place, with control codes for\n  the jumps out of it. Returns {:call form :codes [...] :has-exc bool :rv? bool} and the\n  literal's statement forms.")

var Lit_1255 *jrt.String = jrt.Intern("After a try literal: performs the pending jump of each control code in the enclosing\n  function.")

var Lit_1256 *jrt.String = jrt.Intern("lit-rv-desc")

var Lit_1257 *jrt.String = jrt.Intern("The Go function literal and its call: results ctl, rv (when used), exc (when catching).")

var Lit_1258 *jrt.String = jrt.Intern("The marker interfaces of a lambda or method reference whose target is an intersection\n  (\"(& Comparator Serializable)\": LambdaMetafactory's altMetafactory makes its class implement\n  them; amendment JB5): Serializable when serializable, and the other markers, those in the\n  world that the interface does not already extend, sorted.")

var Lit_1259 *jrt.String = jrt.Intern("The adapter type F_Fn of functional interface fi, recorded for generation in fi's package;\n  with marker interfaces, the adapter F_Fn_M1_..._Mn that also implements them (JB5).")

var Lit_1260 *jrt.String = jrt.Intern("Converts Go value x of Java type from to Java type to, as LambdaMetafactory adapts:\n  casts, unboxing, boxing, primitive widening.")

var Lit_1261 *jrt.String = jrt.Intern("Clojure's adapter of an argument to a functional interface parameter (Compiler's\n  FISupport.maybeEmitFIAdapter; :fi-adapter): an IFn that is not already an instance of the\n  interface becomes its adapter F_Fn (§7.11) calling FnInvokers' invoker, as the JVM's\n  LambdaMetafactory site does; anything else is cast.")
