//line a2g_classes.ae:1
package aot_arbace_a2g_code

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_code_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_A_New()}; return nil }

var A_arbace_a2g_code_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_code_A_new}

var A_arbace_a2g_code_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_A"})

func init() { i := A_arbace_a2g_code_A_class.Info(); i.IsInstance = A_arbace_a2g_code_A_InstanceOf; i.Init = A_arbace_a2g_code_A_Init; i.Table = A_arbace_a2g_code_A_members; jrt.RegisterGoType(A_arbace_a2g_code_A_class, reflect.TypeFor[A_arbace_a2g_code_A]()) }

func A_arbace_a2g_code_accessor_call_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_accessor_call_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_accessor_call_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_accessor_call_BANG__A_New()}; return nil }

func A_arbace_a2g_code_accessor_call_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_accessor_call_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_accessor_call_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_accessor_call_BANG__A_invoke, New: A_arbace_a2g_code_accessor_call_BANG__A_new, Get: A_arbace_a2g_code_accessor_call_BANG__A_get}

var A_arbace_a2g_code_accessor_call_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$accessor_call_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "accessor_call_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_accessor_call_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_accessor_call_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_accessor_call_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_accessor_call_BANG__A_Init; i.Table = A_arbace_a2g_code_accessor_call_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_accessor_call_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_accessor_call_BANG__A]()) }

func A_arbace_a2g_code_adapter_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_adapter_sym_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_a2g_code_adapter_sym_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_adapter_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_adapter_sym_A_New()}; return nil }

func A_arbace_a2g_code_adapter_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_adapter_sym_A_fn_class)}; return nil }

var A_arbace_a2g_code_adapter_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_adapter_sym_A_invoke, New: A_arbace_a2g_code_adapter_sym_A_new, Get: A_arbace_a2g_code_adapter_sym_A_get}

var A_arbace_a2g_code_adapter_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$adapter_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "adapter_sym", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_adapter_sym_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_adapter_sym_A_class.Info(); i.IsInstance = A_arbace_a2g_code_adapter_sym_A_InstanceOf; i.Init = A_arbace_a2g_code_adapter_sym_A_Init; i.Table = A_arbace_a2g_code_adapter_sym_A_members; jrt.RegisterGoType(A_arbace_a2g_code_adapter_sym_A_class, reflect.TypeFor[A_arbace_a2g_code_adapter_sym_A]()) }

func A_arbace_a2g_code_adapter_sym_fn__16000794_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_adapter_sym_fn__16000794_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_adapter_sym_fn__16000794_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_adapter_sym_fn__16000794_A_New()}; return nil }

func A_arbace_a2g_code_adapter_sym_fn__16000794_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_adapter_sym_fn__16000794_A_fn_class)}; return nil }

var A_arbace_a2g_code_adapter_sym_fn__16000794_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_adapter_sym_fn__16000794_A_invoke, New: A_arbace_a2g_code_adapter_sym_fn__16000794_A_new, Get: A_arbace_a2g_code_adapter_sym_fn__16000794_A_get}

var A_arbace_a2g_code_adapter_sym_fn__16000794_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$adapter_sym$fn__16000794", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_adapter_sym_A_class, Simple: "fn__16000794", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_adapter_sym_fn__16000794_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_adapter_sym_fn__16000794_A_class.Info(); i.IsInstance = A_arbace_a2g_code_adapter_sym_fn__16000794_A_InstanceOf; i.Init = A_arbace_a2g_code_adapter_sym_fn__16000794_A_Init; i.Table = A_arbace_a2g_code_adapter_sym_fn__16000794_A_members; jrt.RegisterGoType(A_arbace_a2g_code_adapter_sym_fn__16000794_A_class, reflect.TypeFor[A_arbace_a2g_code_adapter_sym_fn__16000794_A]()) }

func A_arbace_a2g_code_any_after_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_any_after_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_any_after_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_any_after_A_New()}; return nil }

func A_arbace_a2g_code_any_after_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_any_after_A_fn_class)}; return nil }

var A_arbace_a2g_code_any_after_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_any_after_A_invoke, New: A_arbace_a2g_code_any_after_A_new, Get: A_arbace_a2g_code_any_after_A_get}

var A_arbace_a2g_code_any_after_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$any_after", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "any_after", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_any_after_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_any_after_A_class.Info(); i.IsInstance = A_arbace_a2g_code_any_after_A_InstanceOf; i.Init = A_arbace_a2g_code_any_after_A_Init; i.Table = A_arbace_a2g_code_any_after_A_members; jrt.RegisterGoType(A_arbace_a2g_code_any_after_A_class, reflect.TypeFor[A_arbace_a2g_code_any_after_A]()) }

func A_arbace_a2g_code_args_for_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_args_for_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_args_for_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_args_for_A_New()}; return nil }

func A_arbace_a2g_code_args_for_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_args_for_A_fn_class)}; return nil }

var A_arbace_a2g_code_args_for_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_args_for_A_invoke, New: A_arbace_a2g_code_args_for_A_new, Get: A_arbace_a2g_code_args_for_A_get}

var A_arbace_a2g_code_args_for_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$args_for", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "args_for", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_args_for_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_args_for_A_class.Info(); i.IsInstance = A_arbace_a2g_code_args_for_A_InstanceOf; i.Init = A_arbace_a2g_code_args_for_A_Init; i.Table = A_arbace_a2g_code_args_for_A_members; jrt.RegisterGoType(A_arbace_a2g_code_args_for_A_class, reflect.TypeFor[A_arbace_a2g_code_args_for_A]()) }

func A_arbace_a2g_code_arith_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_arith_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_arith_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_arith_val_A_New()}; return nil }

func A_arbace_a2g_code_arith_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_arith_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_arith_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_arith_val_A_invoke, New: A_arbace_a2g_code_arith_val_A_new, Get: A_arbace_a2g_code_arith_val_A_get}

var A_arbace_a2g_code_arith_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$arith_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "arith_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_arith_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_arith_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_arith_val_A_InstanceOf; i.Init = A_arbace_a2g_code_arith_val_A_Init; i.Table = A_arbace_a2g_code_arith_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_arith_val_A_class, reflect.TypeFor[A_arbace_a2g_code_arith_val_A]()) }

func A_arbace_a2g_code_arith_val_cnt__16000240_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_arith_val_cnt__16000240_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_arith_val_cnt__16000240_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_arith_val_cnt__16000240_A_New_O_J(args[0], args[1].(int64))}; return nil }

func A_arbace_a2g_code_arith_val_cnt__16000240_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_arith_val_cnt__16000240_A_fn_class)}; return nil }

var A_arbace_a2g_code_arith_val_cnt__16000240_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;J)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_arith_val_cnt__16000240_A_invoke, New: A_arbace_a2g_code_arith_val_cnt__16000240_A_new, Get: A_arbace_a2g_code_arith_val_cnt__16000240_A_get}

var A_arbace_a2g_code_arith_val_cnt__16000240_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$arith_val$cnt__16000240", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_arith_val_A_class, Simple: "cnt__16000240", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_arith_val_cnt__16000240_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_arith_val_cnt__16000240_A_class.Info(); i.IsInstance = A_arbace_a2g_code_arith_val_cnt__16000240_A_InstanceOf; i.Init = A_arbace_a2g_code_arith_val_cnt__16000240_A_Init; i.Table = A_arbace_a2g_code_arith_val_cnt__16000240_A_members; jrt.RegisterGoType(A_arbace_a2g_code_arith_val_cnt__16000240_A_class, reflect.TypeFor[A_arbace_a2g_code_arith_val_cnt__16000240_A]()) }

func A_arbace_a2g_code_arith_val_fmul__16000242_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_arith_val_fmul__16000242_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_arith_val_fmul__16000242_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_arith_val_fmul__16000242_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_arith_val_fmul__16000242_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_arith_val_fmul__16000242_A_fn_class)}; return nil }

var A_arbace_a2g_code_arith_val_fmul__16000242_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_arith_val_fmul__16000242_A_invoke, New: A_arbace_a2g_code_arith_val_fmul__16000242_A_new, Get: A_arbace_a2g_code_arith_val_fmul__16000242_A_get}

var A_arbace_a2g_code_arith_val_fmul__16000242_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$arith_val$fmul__16000242", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_arith_val_A_class, Simple: "fmul__16000242", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_arith_val_fmul__16000242_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_arith_val_fmul__16000242_A_class.Info(); i.IsInstance = A_arbace_a2g_code_arith_val_fmul__16000242_A_InstanceOf; i.Init = A_arbace_a2g_code_arith_val_fmul__16000242_A_Init; i.Table = A_arbace_a2g_code_arith_val_fmul__16000242_A_members; jrt.RegisterGoType(A_arbace_a2g_code_arith_val_fmul__16000242_A_class, reflect.TypeFor[A_arbace_a2g_code_arith_val_fmul__16000242_A]()) }

func A_arbace_a2g_code_array_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_array_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_array_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_array_val_A_New()}; return nil }

func A_arbace_a2g_code_array_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_array_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_array_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_array_val_A_invoke, New: A_arbace_a2g_code_array_val_A_new, Get: A_arbace_a2g_code_array_val_A_get}

var A_arbace_a2g_code_array_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$array_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "array_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_array_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_array_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_array_val_A_InstanceOf; i.Init = A_arbace_a2g_code_array_val_A_Init; i.Table = A_arbace_a2g_code_array_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_array_val_A_class, reflect.TypeFor[A_arbace_a2g_code_array_val_A]()) }

func A_arbace_a2g_code_assign_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_assign_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_assign_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_assign_BANG__A_New()}; return nil }

func A_arbace_a2g_code_assign_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_assign_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_assign_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_assign_BANG__A_invoke, New: A_arbace_a2g_code_assign_BANG__A_new, Get: A_arbace_a2g_code_assign_BANG__A_get}

var A_arbace_a2g_code_assign_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$assign_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "assign_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_assign_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_assign_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_assign_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_assign_BANG__A_Init; i.Table = A_arbace_a2g_code_assign_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_assign_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_assign_BANG__A]()) }

func A_arbace_a2g_code_assign_value_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_assign_value_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_assign_value_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_assign_value_BANG__A_New()}; return nil }

func A_arbace_a2g_code_assign_value_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_assign_value_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_assign_value_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_assign_value_BANG__A_invoke, New: A_arbace_a2g_code_assign_value_BANG__A_new, Get: A_arbace_a2g_code_assign_value_BANG__A_get}

var A_arbace_a2g_code_assign_value_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$assign_value_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "assign_value_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_assign_value_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_assign_value_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_assign_value_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_assign_value_BANG__A_Init; i.Table = A_arbace_a2g_code_assign_value_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_assign_value_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_assign_value_BANG__A]()) }

func A_arbace_a2g_code_binding_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_binding_sym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_binding_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_binding_sym_A_New()}; return nil }

func A_arbace_a2g_code_binding_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_binding_sym_A_fn_class)}; return nil }

var A_arbace_a2g_code_binding_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_binding_sym_A_invoke, New: A_arbace_a2g_code_binding_sym_A_new, Get: A_arbace_a2g_code_binding_sym_A_get}

var A_arbace_a2g_code_binding_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$binding_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "binding_sym", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_binding_sym_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_binding_sym_A_class.Info(); i.IsInstance = A_arbace_a2g_code_binding_sym_A_InstanceOf; i.Init = A_arbace_a2g_code_binding_sym_A_Init; i.Table = A_arbace_a2g_code_binding_sym_A_members; jrt.RegisterGoType(A_arbace_a2g_code_binding_sym_A_class, reflect.TypeFor[A_arbace_a2g_code_binding_sym_A]()) }

func A_arbace_a2g_code_block_forms_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_block_forms_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_block_forms_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_block_forms_A_New()}; return nil }

func A_arbace_a2g_code_block_forms_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_block_forms_A_fn_class)}; return nil }

var A_arbace_a2g_code_block_forms_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_block_forms_A_invoke, New: A_arbace_a2g_code_block_forms_A_new, Get: A_arbace_a2g_code_block_forms_A_get}

var A_arbace_a2g_code_block_forms_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$block_forms", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "block_forms", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_block_forms_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_block_forms_A_class.Info(); i.IsInstance = A_arbace_a2g_code_block_forms_A_InstanceOf; i.Init = A_arbace_a2g_code_block_forms_A_Init; i.Table = A_arbace_a2g_code_block_forms_A_members; jrt.RegisterGoType(A_arbace_a2g_code_block_forms_A_class, reflect.TypeFor[A_arbace_a2g_code_block_forms_A]()) }

func A_arbace_a2g_code_box_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_box_val_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_box_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_box_val_A_New()}; return nil }

func A_arbace_a2g_code_box_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_box_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_box_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_box_val_A_invoke, New: A_arbace_a2g_code_box_val_A_new, Get: A_arbace_a2g_code_box_val_A_get}

var A_arbace_a2g_code_box_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$box_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "box_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_box_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_box_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_box_val_A_InstanceOf; i.Init = A_arbace_a2g_code_box_val_A_Init; i.Table = A_arbace_a2g_code_box_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_box_val_A_class, reflect.TypeFor[A_arbace_a2g_code_box_val_A]()) }

func A_arbace_a2g_code_cast_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_cast_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_cast_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_cast_val_A_New()}; return nil }

func A_arbace_a2g_code_cast_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_cast_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_cast_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_cast_val_A_invoke, New: A_arbace_a2g_code_cast_val_A_new, Get: A_arbace_a2g_code_cast_val_A_get}

var A_arbace_a2g_code_cast_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$cast_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "cast_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_cast_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_cast_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_cast_val_A_InstanceOf; i.Init = A_arbace_a2g_code_cast_val_A_Init; i.Table = A_arbace_a2g_code_cast_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_cast_val_A_class, reflect.TypeFor[A_arbace_a2g_code_cast_val_A]()) }

func A_arbace_a2g_code_class_init_call_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_class_init_call_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_class_init_call_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_class_init_call_A_New()}; return nil }

func A_arbace_a2g_code_class_init_call_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_class_init_call_A_fn_class)}; return nil }

var A_arbace_a2g_code_class_init_call_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_class_init_call_A_invoke, New: A_arbace_a2g_code_class_init_call_A_new, Get: A_arbace_a2g_code_class_init_call_A_get}

var A_arbace_a2g_code_class_init_call_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$class_init_call", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "class_init_call", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_class_init_call_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_class_init_call_A_class.Info(); i.IsInstance = A_arbace_a2g_code_class_init_call_A_InstanceOf; i.Init = A_arbace_a2g_code_class_init_call_A_Init; i.Table = A_arbace_a2g_code_class_init_call_A_members; jrt.RegisterGoType(A_arbace_a2g_code_class_init_call_A_class, reflect.TypeFor[A_arbace_a2g_code_class_init_call_A]()) }

func A_arbace_a2g_code_class_missing_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_class_missing_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_class_missing_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_class_missing_A_New()}; return nil }

func A_arbace_a2g_code_class_missing_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_class_missing_A_fn_class)}; return nil }

var A_arbace_a2g_code_class_missing_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_class_missing_A_invoke, New: A_arbace_a2g_code_class_missing_A_new, Get: A_arbace_a2g_code_class_missing_A_get}

var A_arbace_a2g_code_class_missing_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$class_missing", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "class_missing", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_class_missing_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_class_missing_A_class.Info(); i.IsInstance = A_arbace_a2g_code_class_missing_A_InstanceOf; i.Init = A_arbace_a2g_code_class_missing_A_Init; i.Table = A_arbace_a2g_code_class_missing_A_members; jrt.RegisterGoType(A_arbace_a2g_code_class_missing_A_class, reflect.TypeFor[A_arbace_a2g_code_class_missing_A]()) }

func A_arbace_a2g_code_class_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_class_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_class_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_class_val_A_New()}; return nil }

func A_arbace_a2g_code_class_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_class_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_class_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_class_val_A_invoke, New: A_arbace_a2g_code_class_val_A_new, Get: A_arbace_a2g_code_class_val_A_get}

var A_arbace_a2g_code_class_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$class_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "class_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_class_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_class_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_class_val_A_InstanceOf; i.Init = A_arbace_a2g_code_class_val_A_Init; i.Table = A_arbace_a2g_code_class_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_class_val_A_class, reflect.TypeFor[A_arbace_a2g_code_class_val_A]()) }

func A_arbace_a2g_code_code_jump_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_code_jump_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_code_jump_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_code_jump_BANG__A_New()}; return nil }

func A_arbace_a2g_code_code_jump_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_code_jump_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_code_jump_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_code_jump_BANG__A_invoke, New: A_arbace_a2g_code_code_jump_BANG__A_new, Get: A_arbace_a2g_code_code_jump_BANG__A_get}

var A_arbace_a2g_code_code_jump_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$code_jump_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "code_jump_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_code_jump_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_code_jump_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_code_jump_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_code_jump_BANG__A_Init; i.Table = A_arbace_a2g_code_code_jump_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_code_jump_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_code_jump_BANG__A]()) }

func A_arbace_a2g_code_coerce_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_coerce_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_coerce_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_coerce_A_New()}; return nil }

func A_arbace_a2g_code_coerce_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_coerce_A_fn_class)}; return nil }

var A_arbace_a2g_code_coerce_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_coerce_A_invoke, New: A_arbace_a2g_code_coerce_A_new, Get: A_arbace_a2g_code_coerce_A_get}

var A_arbace_a2g_code_coerce_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$coerce", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "coerce", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_coerce_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_coerce_A_class.Info(); i.IsInstance = A_arbace_a2g_code_coerce_A_InstanceOf; i.Init = A_arbace_a2g_code_coerce_A_Init; i.Table = A_arbace_a2g_code_coerce_A_members; jrt.RegisterGoType(A_arbace_a2g_code_coerce_A_class, reflect.TypeFor[A_arbace_a2g_code_coerce_A]()) }

func A_arbace_a2g_code_cond_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_cond_expr_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_cond_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_cond_expr_A_New()}; return nil }

func A_arbace_a2g_code_cond_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_cond_expr_A_fn_class)}; return nil }

var A_arbace_a2g_code_cond_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_cond_expr_A_invoke, New: A_arbace_a2g_code_cond_expr_A_new, Get: A_arbace_a2g_code_cond_expr_A_get}

var A_arbace_a2g_code_cond_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$cond_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "cond_expr", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_cond_expr_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_cond_expr_A_class.Info(); i.IsInstance = A_arbace_a2g_code_cond_expr_A_InstanceOf; i.Init = A_arbace_a2g_code_cond_expr_A_Init; i.Table = A_arbace_a2g_code_cond_expr_A_members; jrt.RegisterGoType(A_arbace_a2g_code_cond_expr_A_class, reflect.TypeFor[A_arbace_a2g_code_cond_expr_A]()) }

func A_arbace_a2g_code_const_array_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_array_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_const_array_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_array_A_New()}; return nil }

func A_arbace_a2g_code_const_array_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_array_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_array_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_array_A_invoke, New: A_arbace_a2g_code_const_array_A_new, Get: A_arbace_a2g_code_const_array_A_get}

var A_arbace_a2g_code_const_array_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_array", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "const_array", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_array_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_array_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_array_A_InstanceOf; i.Init = A_arbace_a2g_code_const_array_A_Init; i.Table = A_arbace_a2g_code_const_array_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_array_A_class, reflect.TypeFor[A_arbace_a2g_code_const_array_A]()) }

func A_arbace_a2g_code_const_encode_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_encode_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_const_encode_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_encode_A_New()}; return nil }

func A_arbace_a2g_code_const_encode_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_encode_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_encode_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_encode_A_invoke, New: A_arbace_a2g_code_const_encode_A_new, Get: A_arbace_a2g_code_const_encode_A_get}

var A_arbace_a2g_code_const_encode_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_encode", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "const_encode", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_encode_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_encode_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_encode_A_InstanceOf; i.Init = A_arbace_a2g_code_const_encode_A_Init; i.Table = A_arbace_a2g_code_const_encode_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_encode_A_class, reflect.TypeFor[A_arbace_a2g_code_const_encode_A]()) }

func A_arbace_a2g_code_const_encode_fn__16000375_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_encode_fn__16000375_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_const_encode_fn__16000375_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_encode_fn__16000375_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_const_encode_fn__16000375_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_encode_fn__16000375_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_encode_fn__16000375_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_encode_fn__16000375_A_invoke, New: A_arbace_a2g_code_const_encode_fn__16000375_A_new, Get: A_arbace_a2g_code_const_encode_fn__16000375_A_get}

var A_arbace_a2g_code_const_encode_fn__16000375_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_encode$fn__16000375", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_const_encode_A_class, Simple: "fn__16000375", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_encode_fn__16000375_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_encode_fn__16000375_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_encode_fn__16000375_A_InstanceOf; i.Init = A_arbace_a2g_code_const_encode_fn__16000375_A_Init; i.Table = A_arbace_a2g_code_const_encode_fn__16000375_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_encode_fn__16000375_A_class, reflect.TypeFor[A_arbace_a2g_code_const_encode_fn__16000375_A]()) }

func A_arbace_a2g_code_const_strings_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_strings_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_const_strings_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_strings_A_New()}; return nil }

func A_arbace_a2g_code_const_strings_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_strings_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_strings_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_strings_A_invoke, New: A_arbace_a2g_code_const_strings_A_new, Get: A_arbace_a2g_code_const_strings_A_get}

var A_arbace_a2g_code_const_strings_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_strings", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "const_strings", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_strings_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_strings_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_strings_A_InstanceOf; i.Init = A_arbace_a2g_code_const_strings_A_Init; i.Table = A_arbace_a2g_code_const_strings_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_strings_A_class, reflect.TypeFor[A_arbace_a2g_code_const_strings_A]()) }

func A_arbace_a2g_code_const_tree_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_tree_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_const_tree_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_tree_A_New()}; return nil }

func A_arbace_a2g_code_const_tree_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_tree_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_tree_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_tree_A_invoke, New: A_arbace_a2g_code_const_tree_A_new, Get: A_arbace_a2g_code_const_tree_A_get}

var A_arbace_a2g_code_const_tree_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_tree", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "const_tree", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_tree_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_tree_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_tree_A_InstanceOf; i.Init = A_arbace_a2g_code_const_tree_A_Init; i.Table = A_arbace_a2g_code_const_tree_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_tree_A_class, reflect.TypeFor[A_arbace_a2g_code_const_tree_A]()) }

func A_arbace_a2g_code_const_tree_fn__16000364_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_tree_fn__16000364_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_const_tree_fn__16000364_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_tree_fn__16000364_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_const_tree_fn__16000364_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_tree_fn__16000364_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_tree_fn__16000364_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_tree_fn__16000364_A_invoke, New: A_arbace_a2g_code_const_tree_fn__16000364_A_new, Get: A_arbace_a2g_code_const_tree_fn__16000364_A_get}

var A_arbace_a2g_code_const_tree_fn__16000364_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_tree$fn__16000364", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_const_tree_A_class, Simple: "fn__16000364", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_tree_fn__16000364_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_tree_fn__16000364_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_tree_fn__16000364_A_InstanceOf; i.Init = A_arbace_a2g_code_const_tree_fn__16000364_A_Init; i.Table = A_arbace_a2g_code_const_tree_fn__16000364_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_tree_fn__16000364_A_class, reflect.TypeFor[A_arbace_a2g_code_const_tree_fn__16000364_A]()) }

func A_arbace_a2g_code_const_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_const_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_const_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_const_value_A_New()}; return nil }

func A_arbace_a2g_code_const_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_const_value_A_fn_class)}; return nil }

var A_arbace_a2g_code_const_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_const_value_A_invoke, New: A_arbace_a2g_code_const_value_A_new, Get: A_arbace_a2g_code_const_value_A_get}

var A_arbace_a2g_code_const_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$const_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "const_value", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_const_value_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_const_value_A_class.Info(); i.IsInstance = A_arbace_a2g_code_const_value_A_InstanceOf; i.Init = A_arbace_a2g_code_const_value_A_Init; i.Table = A_arbace_a2g_code_const_value_A_members; jrt.RegisterGoType(A_arbace_a2g_code_const_value_A_class, reflect.TypeFor[A_arbace_a2g_code_const_value_A]()) }

func A_arbace_a2g_code_convert_ref_or_prim_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_convert_ref_or_prim_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_convert_ref_or_prim_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_convert_ref_or_prim_A_New()}; return nil }

func A_arbace_a2g_code_convert_ref_or_prim_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_convert_ref_or_prim_A_fn_class)}; return nil }

var A_arbace_a2g_code_convert_ref_or_prim_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_convert_ref_or_prim_A_invoke, New: A_arbace_a2g_code_convert_ref_or_prim_A_new, Get: A_arbace_a2g_code_convert_ref_or_prim_A_get}

var A_arbace_a2g_code_convert_ref_or_prim_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$convert_ref_or_prim", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "convert_ref_or_prim", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_convert_ref_or_prim_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_convert_ref_or_prim_A_class.Info(); i.IsInstance = A_arbace_a2g_code_convert_ref_or_prim_A_InstanceOf; i.Init = A_arbace_a2g_code_convert_ref_or_prim_A_Init; i.Table = A_arbace_a2g_code_convert_ref_or_prim_A_members; jrt.RegisterGoType(A_arbace_a2g_code_convert_ref_or_prim_A_class, reflect.TypeFor[A_arbace_a2g_code_convert_ref_or_prim_A]()) }

func A_arbace_a2g_code_convert_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_convert_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_convert_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_convert_val_A_New()}; return nil }

func A_arbace_a2g_code_convert_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_convert_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_convert_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_convert_val_A_invoke, New: A_arbace_a2g_code_convert_val_A_new, Get: A_arbace_a2g_code_convert_val_A_get}

var A_arbace_a2g_code_convert_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$convert_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "convert_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_convert_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_convert_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_convert_val_A_InstanceOf; i.Init = A_arbace_a2g_code_convert_val_A_Init; i.Table = A_arbace_a2g_code_convert_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_convert_val_A_class, reflect.TypeFor[A_arbace_a2g_code_convert_val_A]()) }

func A_arbace_a2g_code_csym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_csym_A).Invoke_O_O__O(args[0], args[1]); case 1: return this.(*A_arbace_a2g_code_csym_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_csym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_csym_A_New()}; return nil }

func A_arbace_a2g_code_csym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_csym_A_fn_class)}; return nil }

var A_arbace_a2g_code_csym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nM1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_csym_A_invoke, New: A_arbace_a2g_code_csym_A_new, Get: A_arbace_a2g_code_csym_A_get}

var A_arbace_a2g_code_csym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$csym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class, lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "csym", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_csym_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_csym_A_class.Info(); i.IsInstance = A_arbace_a2g_code_csym_A_InstanceOf; i.Init = A_arbace_a2g_code_csym_A_Init; i.Table = A_arbace_a2g_code_csym_A_members; jrt.RegisterGoType(A_arbace_a2g_code_csym_A_class, reflect.TypeFor[A_arbace_a2g_code_csym_A]()) }

func A_arbace_a2g_code_ctor_args_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_ctor_args_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_ctor_args_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_ctor_args_A_New()}; return nil }

func A_arbace_a2g_code_ctor_args_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_ctor_args_A_fn_class)}; return nil }

var A_arbace_a2g_code_ctor_args_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_ctor_args_A_invoke, New: A_arbace_a2g_code_ctor_args_A_new, Get: A_arbace_a2g_code_ctor_args_A_get}

var A_arbace_a2g_code_ctor_args_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$ctor_args", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "ctor_args", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_ctor_args_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_ctor_args_A_class.Info(); i.IsInstance = A_arbace_a2g_code_ctor_args_A_InstanceOf; i.Init = A_arbace_a2g_code_ctor_args_A_Init; i.Table = A_arbace_a2g_code_ctor_args_A_members; jrt.RegisterGoType(A_arbace_a2g_code_ctor_args_A_class, reflect.TypeFor[A_arbace_a2g_code_ctor_args_A]()) }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_New()}; return nil }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_fn_class)}; return nil }

var A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_invoke, New: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_new, Get: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_get}

var A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$ctor_args$iter__16000349__16000353", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_ctor_args_A_class, Simple: "iter__16000349__16000353", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_class.Info(); i.IsInstance = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_InstanceOf; i.Init = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_Init; i.Table = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_members; jrt.RegisterGoType(A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_class, reflect.TypeFor[A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A]()) }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_fn_class)}; return nil }

var A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_invoke, New: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_new, Get: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_get}

var A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$ctor_args$iter__16000349__16000353$fn__16000354", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_A_class, Simple: "fn__16000354", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_class.Info(); i.IsInstance = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_InstanceOf; i.Init = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_Init; i.Table = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_members; jrt.RegisterGoType(A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_class, reflect.TypeFor[A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A]()) }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_fn_class)}; return nil }

var A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_invoke, New: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_new, Get: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_get}

var A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$ctor_args$iter__16000349__16000353$fn__16000354$fn__16000355", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_A_class, Simple: "fn__16000355", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_class.Info(); i.IsInstance = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_InstanceOf; i.Init = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_Init; i.Table = A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_members; jrt.RegisterGoType(A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A_class, reflect.TypeFor[A_arbace_a2g_code_ctor_args_iter__16000349__16000353_fn__16000354_fn__16000355_A]()) }

func A_arbace_a2g_code_ctx_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_ctx_desc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_ctx_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_ctx_desc_A_New()}; return nil }

func A_arbace_a2g_code_ctx_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_ctx_desc_A_fn_class)}; return nil }

var A_arbace_a2g_code_ctx_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_ctx_desc_A_invoke, New: A_arbace_a2g_code_ctx_desc_A_new, Get: A_arbace_a2g_code_ctx_desc_A_get}

var A_arbace_a2g_code_ctx_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$ctx_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "ctx_desc", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_ctx_desc_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_ctx_desc_A_class.Info(); i.IsInstance = A_arbace_a2g_code_ctx_desc_A_InstanceOf; i.Init = A_arbace_a2g_code_ctx_desc_A_Init; i.Table = A_arbace_a2g_code_ctx_desc_A_members; jrt.RegisterGoType(A_arbace_a2g_code_ctx_desc_A_class, reflect.TypeFor[A_arbace_a2g_code_ctx_desc_A]()) }

func A_arbace_a2g_code_decl_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_decl_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_decl_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_decl_BANG__A_New()}; return nil }

func A_arbace_a2g_code_decl_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_decl_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_decl_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_decl_BANG__A_invoke, New: A_arbace_a2g_code_decl_BANG__A_new, Get: A_arbace_a2g_code_decl_BANG__A_get}

var A_arbace_a2g_code_decl_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$decl_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "decl_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_decl_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_decl_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_decl_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_decl_BANG__A_Init; i.Table = A_arbace_a2g_code_decl_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_decl_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_decl_BANG__A]()) }

func A_arbace_a2g_code_declare_pattern_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_declare_pattern_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_declare_pattern_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_declare_pattern_BANG__A_New()}; return nil }

func A_arbace_a2g_code_declare_pattern_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_declare_pattern_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_declare_pattern_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_declare_pattern_BANG__A_invoke, New: A_arbace_a2g_code_declare_pattern_BANG__A_new, Get: A_arbace_a2g_code_declare_pattern_BANG__A_get}

var A_arbace_a2g_code_declare_pattern_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$declare_pattern_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "declare_pattern_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_declare_pattern_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_declare_pattern_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_declare_pattern_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_declare_pattern_BANG__A_Init; i.Table = A_arbace_a2g_code_declare_pattern_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_declare_pattern_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_declare_pattern_BANG__A]()) }

func A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_fn_class)}; return nil }

var A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_invoke, New: A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_new, Get: A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_get}

var A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$declare_pattern_BANG_$fn__16000526", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_declare_pattern_BANG__A_class, Simple: "fn__16000526", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_class.Info(); i.IsInstance = A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_InstanceOf; i.Init = A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_Init; i.Table = A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_members; jrt.RegisterGoType(A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A_class, reflect.TypeFor[A_arbace_a2g_code_declare_pattern_BANG__fn__16000526_A]()) }

func A_arbace_a2g_code_derived_accessor_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_derived_accessor_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_derived_accessor_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_derived_accessor_A_New()}; return nil }

func A_arbace_a2g_code_derived_accessor_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_derived_accessor_A_fn_class)}; return nil }

var A_arbace_a2g_code_derived_accessor_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_derived_accessor_A_invoke, New: A_arbace_a2g_code_derived_accessor_A_new, Get: A_arbace_a2g_code_derived_accessor_A_get}

var A_arbace_a2g_code_derived_accessor_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$derived_accessor", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "derived_accessor", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_derived_accessor_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_derived_accessor_A_class.Info(); i.IsInstance = A_arbace_a2g_code_derived_accessor_A_InstanceOf; i.Init = A_arbace_a2g_code_derived_accessor_A_Init; i.Table = A_arbace_a2g_code_derived_accessor_A_members; jrt.RegisterGoType(A_arbace_a2g_code_derived_accessor_A_class, reflect.TypeFor[A_arbace_a2g_code_derived_accessor_A]()) }

func A_arbace_a2g_code_derived_accessor_fn__16000508_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_derived_accessor_fn__16000508_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_derived_accessor_fn__16000508_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_derived_accessor_fn__16000508_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_derived_accessor_fn__16000508_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_derived_accessor_fn__16000508_A_fn_class)}; return nil }

var A_arbace_a2g_code_derived_accessor_fn__16000508_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_derived_accessor_fn__16000508_A_invoke, New: A_arbace_a2g_code_derived_accessor_fn__16000508_A_new, Get: A_arbace_a2g_code_derived_accessor_fn__16000508_A_get}

var A_arbace_a2g_code_derived_accessor_fn__16000508_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$derived_accessor$fn__16000508", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_derived_accessor_A_class, Simple: "fn__16000508", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_derived_accessor_fn__16000508_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_derived_accessor_fn__16000508_A_class.Info(); i.IsInstance = A_arbace_a2g_code_derived_accessor_fn__16000508_A_InstanceOf; i.Init = A_arbace_a2g_code_derived_accessor_fn__16000508_A_Init; i.Table = A_arbace_a2g_code_derived_accessor_fn__16000508_A_members; jrt.RegisterGoType(A_arbace_a2g_code_derived_accessor_fn__16000508_A_class, reflect.TypeFor[A_arbace_a2g_code_derived_accessor_fn__16000508_A]()) }

func A_arbace_a2g_code_desc_missing_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_desc_missing_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_desc_missing_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_desc_missing_A_New()}; return nil }

func A_arbace_a2g_code_desc_missing_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_desc_missing_A_fn_class)}; return nil }

var A_arbace_a2g_code_desc_missing_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_desc_missing_A_invoke, New: A_arbace_a2g_code_desc_missing_A_new, Get: A_arbace_a2g_code_desc_missing_A_get}

var A_arbace_a2g_code_desc_missing_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$desc_missing", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "desc_missing", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_desc_missing_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_desc_missing_A_class.Info(); i.IsInstance = A_arbace_a2g_code_desc_missing_A_InstanceOf; i.Init = A_arbace_a2g_code_desc_missing_A_Init; i.Table = A_arbace_a2g_code_desc_missing_A_members; jrt.RegisterGoType(A_arbace_a2g_code_desc_missing_A_class, reflect.TypeFor[A_arbace_a2g_code_desc_missing_A]()) }

func A_arbace_a2g_code_dispatch_codes_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_dispatch_codes_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_dispatch_codes_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_dispatch_codes_BANG__A_New()}; return nil }

func A_arbace_a2g_code_dispatch_codes_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_dispatch_codes_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_dispatch_codes_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_dispatch_codes_BANG__A_invoke, New: A_arbace_a2g_code_dispatch_codes_BANG__A_new, Get: A_arbace_a2g_code_dispatch_codes_BANG__A_get}

var A_arbace_a2g_code_dispatch_codes_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$dispatch_codes_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "dispatch_codes_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_dispatch_codes_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_dispatch_codes_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_dispatch_codes_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_dispatch_codes_BANG__A_Init; i.Table = A_arbace_a2g_code_dispatch_codes_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_dispatch_codes_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_dispatch_codes_BANG__A]()) }

func A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_fn_class)}; return nil }

var A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_invoke, New: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_new, Get: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_get}

var A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$dispatch_codes_BANG_$clause__16000729", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_dispatch_codes_BANG__A_class, Simple: "clause__16000729", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_class.Info(); i.IsInstance = A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_InstanceOf; i.Init = A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_Init; i.Table = A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_members; jrt.RegisterGoType(A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_class, reflect.TypeFor[A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A]()) }

func A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_fn_class)}; return nil }

var A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_invoke, New: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_new, Get: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_get}

var A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$dispatch_codes_BANG_$clause__16000729$fn__16000730", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_A_class, Simple: "fn__16000730", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_class.Info(); i.IsInstance = A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_InstanceOf; i.Init = A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_Init; i.Table = A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_members; jrt.RegisterGoType(A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A_class, reflect.TypeFor[A_arbace_a2g_code_dispatch_codes_BANG__clause__16000729_fn__16000730_A]()) }

func A_arbace_a2g_code_dropped_store_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_dropped_store_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_dropped_store_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_dropped_store_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_dropped_store_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_dropped_store_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_dropped_store_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_dropped_store_QMARK__A_invoke, New: A_arbace_a2g_code_dropped_store_QMARK__A_new, Get: A_arbace_a2g_code_dropped_store_QMARK__A_get}

var A_arbace_a2g_code_dropped_store_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$dropped_store_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "dropped_store_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_dropped_store_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_dropped_store_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_dropped_store_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_dropped_store_QMARK__A_Init; i.Table = A_arbace_a2g_code_dropped_store_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_dropped_store_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_dropped_store_QMARK__A]()) }

func A_arbace_a2g_code_effects_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_effects_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_effects_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_effects_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_effects_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_effects_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_effects_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_effects_QMARK__A_invoke, New: A_arbace_a2g_code_effects_QMARK__A_new, Get: A_arbace_a2g_code_effects_QMARK__A_get}

var A_arbace_a2g_code_effects_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$effects_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "effects_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_effects_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_effects_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_effects_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_effects_QMARK__A_Init; i.Table = A_arbace_a2g_code_effects_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_effects_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_effects_QMARK__A]()) }

func A_arbace_a2g_code_effects_QMARK__w__16000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_effects_QMARK__w__16000090_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_effects_QMARK__w__16000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_effects_QMARK__w__16000090_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_effects_QMARK__w__16000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_effects_QMARK__w__16000090_A_fn_class)}; return nil }

var A_arbace_a2g_code_effects_QMARK__w__16000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_effects_QMARK__w__16000090_A_invoke, New: A_arbace_a2g_code_effects_QMARK__w__16000090_A_new, Get: A_arbace_a2g_code_effects_QMARK__w__16000090_A_get}

var A_arbace_a2g_code_effects_QMARK__w__16000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$effects_QMARK_$w__16000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_effects_QMARK__A_class, Simple: "w__16000090", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_effects_QMARK__w__16000090_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_effects_QMARK__w__16000090_A_class.Info(); i.IsInstance = A_arbace_a2g_code_effects_QMARK__w__16000090_A_InstanceOf; i.Init = A_arbace_a2g_code_effects_QMARK__w__16000090_A_Init; i.Table = A_arbace_a2g_code_effects_QMARK__w__16000090_A_members; jrt.RegisterGoType(A_arbace_a2g_code_effects_QMARK__w__16000090_A_class, reflect.TypeFor[A_arbace_a2g_code_effects_QMARK__w__16000090_A]()) }

func A_arbace_a2g_code_emit_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_emit_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_emit_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_emit_BANG__A_New()}; return nil }

func A_arbace_a2g_code_emit_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_emit_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_emit_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_emit_BANG__A_invoke, New: A_arbace_a2g_code_emit_BANG__A_new, Get: A_arbace_a2g_code_emit_BANG__A_get}

var A_arbace_a2g_code_emit_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$emit_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "emit_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_emit_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_emit_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_emit_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_emit_BANG__A_Init; i.Table = A_arbace_a2g_code_emit_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_emit_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_emit_BANG__A]()) }

func A_arbace_a2g_code_enum_ordinal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_enum_ordinal_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_enum_ordinal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_enum_ordinal_A_New()}; return nil }

func A_arbace_a2g_code_enum_ordinal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_enum_ordinal_A_fn_class)}; return nil }

var A_arbace_a2g_code_enum_ordinal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_enum_ordinal_A_invoke, New: A_arbace_a2g_code_enum_ordinal_A_new, Get: A_arbace_a2g_code_enum_ordinal_A_get}

var A_arbace_a2g_code_enum_ordinal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$enum_ordinal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "enum_ordinal", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_enum_ordinal_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_enum_ordinal_A_class.Info(); i.IsInstance = A_arbace_a2g_code_enum_ordinal_A_InstanceOf; i.Init = A_arbace_a2g_code_enum_ordinal_A_Init; i.Table = A_arbace_a2g_code_enum_ordinal_A_members; jrt.RegisterGoType(A_arbace_a2g_code_enum_ordinal_A_class, reflect.TypeFor[A_arbace_a2g_code_enum_ordinal_A]()) }

func A_arbace_a2g_code_enum_ordinal_fn__16000539_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_enum_ordinal_fn__16000539_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000539_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_enum_ordinal_fn__16000539_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000539_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_enum_ordinal_fn__16000539_A_fn_class)}; return nil }

var A_arbace_a2g_code_enum_ordinal_fn__16000539_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_enum_ordinal_fn__16000539_A_invoke, New: A_arbace_a2g_code_enum_ordinal_fn__16000539_A_new, Get: A_arbace_a2g_code_enum_ordinal_fn__16000539_A_get}

var A_arbace_a2g_code_enum_ordinal_fn__16000539_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$enum_ordinal$fn__16000539", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_enum_ordinal_A_class, Simple: "fn__16000539", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_enum_ordinal_fn__16000539_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_enum_ordinal_fn__16000539_A_class.Info(); i.IsInstance = A_arbace_a2g_code_enum_ordinal_fn__16000539_A_InstanceOf; i.Init = A_arbace_a2g_code_enum_ordinal_fn__16000539_A_Init; i.Table = A_arbace_a2g_code_enum_ordinal_fn__16000539_A_members; jrt.RegisterGoType(A_arbace_a2g_code_enum_ordinal_fn__16000539_A_class, reflect.TypeFor[A_arbace_a2g_code_enum_ordinal_fn__16000539_A]()) }

func A_arbace_a2g_code_enum_ordinal_fn__16000541_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_enum_ordinal_fn__16000541_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000541_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_enum_ordinal_fn__16000541_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000541_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_enum_ordinal_fn__16000541_A_fn_class)}; return nil }

var A_arbace_a2g_code_enum_ordinal_fn__16000541_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_enum_ordinal_fn__16000541_A_invoke, New: A_arbace_a2g_code_enum_ordinal_fn__16000541_A_new, Get: A_arbace_a2g_code_enum_ordinal_fn__16000541_A_get}

var A_arbace_a2g_code_enum_ordinal_fn__16000541_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$enum_ordinal$fn__16000541", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_enum_ordinal_A_class, Simple: "fn__16000541", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_enum_ordinal_fn__16000541_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_enum_ordinal_fn__16000541_A_class.Info(); i.IsInstance = A_arbace_a2g_code_enum_ordinal_fn__16000541_A_InstanceOf; i.Init = A_arbace_a2g_code_enum_ordinal_fn__16000541_A_Init; i.Table = A_arbace_a2g_code_enum_ordinal_fn__16000541_A_members; jrt.RegisterGoType(A_arbace_a2g_code_enum_ordinal_fn__16000541_A_class, reflect.TypeFor[A_arbace_a2g_code_enum_ordinal_fn__16000541_A]()) }

func A_arbace_a2g_code_enum_ordinal_fn__16000543_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_enum_ordinal_fn__16000543_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000543_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_enum_ordinal_fn__16000543_A_New()}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000543_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_enum_ordinal_fn__16000543_A_fn_class)}; return nil }

var A_arbace_a2g_code_enum_ordinal_fn__16000543_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_enum_ordinal_fn__16000543_A_invoke, New: A_arbace_a2g_code_enum_ordinal_fn__16000543_A_new, Get: A_arbace_a2g_code_enum_ordinal_fn__16000543_A_get}

var A_arbace_a2g_code_enum_ordinal_fn__16000543_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$enum_ordinal$fn__16000543", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_enum_ordinal_A_class, Simple: "fn__16000543", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_enum_ordinal_fn__16000543_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_enum_ordinal_fn__16000543_A_class.Info(); i.IsInstance = A_arbace_a2g_code_enum_ordinal_fn__16000543_A_InstanceOf; i.Init = A_arbace_a2g_code_enum_ordinal_fn__16000543_A_Init; i.Table = A_arbace_a2g_code_enum_ordinal_fn__16000543_A_members; jrt.RegisterGoType(A_arbace_a2g_code_enum_ordinal_fn__16000543_A_class, reflect.TypeFor[A_arbace_a2g_code_enum_ordinal_fn__16000543_A]()) }

func A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_New()}; return nil }

func A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_fn_class)}; return nil }

var A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_invoke, New: A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_new, Get: A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_get}

var A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$enum_ordinal$fn__16000543$fn__16000544", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_enum_ordinal_fn__16000543_A_class, Simple: "fn__16000544", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_class.Info(); i.IsInstance = A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_InstanceOf; i.Init = A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_Init; i.Table = A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_members; jrt.RegisterGoType(A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A_class, reflect.TypeFor[A_arbace_a2g_code_enum_ordinal_fn__16000543_fn__16000544_A]()) }

func A_arbace_a2g_code_eval16000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_eval16000004_A_New()}; return nil }

var A_arbace_a2g_code_eval16000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_code_eval16000004_A_new}

var A_arbace_a2g_code_eval16000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$eval16000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_code_A_class, Simple: "eval16000004", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_eval16000004_A"})

func init() { i := A_arbace_a2g_code_eval16000004_A_class.Info(); i.IsInstance = A_arbace_a2g_code_eval16000004_A_InstanceOf; i.Table = A_arbace_a2g_code_eval16000004_A_members; jrt.RegisterGoType(A_arbace_a2g_code_eval16000004_A_class, reflect.TypeFor[A_arbace_a2g_code_eval16000004_A]()) }

func A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_New()}; return nil }

func A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_fn_class)}; return nil }

var A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_invoke, New: A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_new, Get: A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_get}

var A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$eval16000004$loading__1927001464__auto____16000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_eval16000004_A_class, Simple: "loading__1927001464__auto____16000005", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_class.Info(); i.IsInstance = A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_InstanceOf; i.Init = A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_Init; i.Table = A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_members; jrt.RegisterGoType(A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A_class, reflect.TypeFor[A_arbace_a2g_code_eval16000004_loading__1927001464__auto____16000005_A]()) }

func A_arbace_a2g_code_eval16000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_eval16000008_A_New()}; return nil }

var A_arbace_a2g_code_eval16000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_code_eval16000008_A_new}

var A_arbace_a2g_code_eval16000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$eval16000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_code_A_class, Simple: "eval16000008", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_eval16000008_A"})

func init() { i := A_arbace_a2g_code_eval16000008_A_class.Info(); i.IsInstance = A_arbace_a2g_code_eval16000008_A_InstanceOf; i.Table = A_arbace_a2g_code_eval16000008_A_members; jrt.RegisterGoType(A_arbace_a2g_code_eval16000008_A_class, reflect.TypeFor[A_arbace_a2g_code_eval16000008_A]()) }

func A_arbace_a2g_code_eval16000008_fn__16000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_eval16000008_fn__16000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_eval16000008_fn__16000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_eval16000008_fn__16000009_A_New()}; return nil }

func A_arbace_a2g_code_eval16000008_fn__16000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_eval16000008_fn__16000009_A_fn_class)}; return nil }

var A_arbace_a2g_code_eval16000008_fn__16000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_eval16000008_fn__16000009_A_invoke, New: A_arbace_a2g_code_eval16000008_fn__16000009_A_new, Get: A_arbace_a2g_code_eval16000008_fn__16000009_A_get}

var A_arbace_a2g_code_eval16000008_fn__16000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$eval16000008$fn__16000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_eval16000008_A_class, Simple: "fn__16000009", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_eval16000008_fn__16000009_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_eval16000008_fn__16000009_A_class.Info(); i.IsInstance = A_arbace_a2g_code_eval16000008_fn__16000009_A_InstanceOf; i.Init = A_arbace_a2g_code_eval16000008_fn__16000009_A_Init; i.Table = A_arbace_a2g_code_eval16000008_fn__16000009_A_members; jrt.RegisterGoType(A_arbace_a2g_code_eval16000008_fn__16000009_A_class, reflect.TypeFor[A_arbace_a2g_code_eval16000008_fn__16000009_A]()) }

func A_arbace_a2g_code_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_expr_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_expr_A_New()}; return nil }

func A_arbace_a2g_code_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_expr_A_fn_class)}; return nil }

var A_arbace_a2g_code_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_expr_A_invoke, New: A_arbace_a2g_code_expr_A_new, Get: A_arbace_a2g_code_expr_A_get}

var A_arbace_a2g_code_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "expr", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_expr_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_expr_A_class.Info(); i.IsInstance = A_arbace_a2g_code_expr_A_InstanceOf; i.Init = A_arbace_a2g_code_expr_A_Init; i.Table = A_arbace_a2g_code_expr_A_members; jrt.RegisterGoType(A_arbace_a2g_code_expr_A_class, reflect.TypeFor[A_arbace_a2g_code_expr_A]()) }

func A_arbace_a2g_code_expr_as_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_expr_as_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_expr_as_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_expr_as_A_New()}; return nil }

func A_arbace_a2g_code_expr_as_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_expr_as_A_fn_class)}; return nil }

var A_arbace_a2g_code_expr_as_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_expr_as_A_invoke, New: A_arbace_a2g_code_expr_as_A_new, Get: A_arbace_a2g_code_expr_as_A_get}

var A_arbace_a2g_code_expr_as_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$expr_as", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "expr_as", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_expr_as_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_expr_as_A_class.Info(); i.IsInstance = A_arbace_a2g_code_expr_as_A_InstanceOf; i.Init = A_arbace_a2g_code_expr_as_A_Init; i.Table = A_arbace_a2g_code_expr_as_A_members; jrt.RegisterGoType(A_arbace_a2g_code_expr_as_A_class, reflect.TypeFor[A_arbace_a2g_code_expr_as_A]()) }

func A_arbace_a2g_code_expr_op_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_expr_op_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_expr_op_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_expr_op_A_New()}; return nil }

func A_arbace_a2g_code_expr_op_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_expr_op_A_fn_class)}; return nil }

var A_arbace_a2g_code_expr_op_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_expr_op_A_invoke, New: A_arbace_a2g_code_expr_op_A_new, Get: A_arbace_a2g_code_expr_op_A_get}

var A_arbace_a2g_code_expr_op_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$expr_op", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "expr_op", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_expr_op_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_expr_op_A_class.Info(); i.IsInstance = A_arbace_a2g_code_expr_op_A_InstanceOf; i.Init = A_arbace_a2g_code_expr_op_A_Init; i.Table = A_arbace_a2g_code_expr_op_A_members; jrt.RegisterGoType(A_arbace_a2g_code_expr_op_A_class, reflect.TypeFor[A_arbace_a2g_code_expr_op_A]()) }

func A_arbace_a2g_code_expressible_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_expressible_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_expressible_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_expressible_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_expressible_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_expressible_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_expressible_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_expressible_QMARK__A_invoke, New: A_arbace_a2g_code_expressible_QMARK__A_new, Get: A_arbace_a2g_code_expressible_QMARK__A_get}

var A_arbace_a2g_code_expressible_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$expressible_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "expressible_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_expressible_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_expressible_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_expressible_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_expressible_QMARK__A_Init; i.Table = A_arbace_a2g_code_expressible_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_expressible_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_expressible_QMARK__A]()) }

func A_arbace_a2g_code_fail_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fail_A).DoInvoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_fail_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fail_A_New()}; return nil }

func A_arbace_a2g_code_fail_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fail_A_fn_class)}; return nil }

var A_arbace_a2g_code_fail_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fail_A_invoke, New: A_arbace_a2g_code_fail_A_new, Get: A_arbace_a2g_code_fail_A_get}

var A_arbace_a2g_code_fail_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fail", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "fail", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fail_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fail_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fail_A_InstanceOf; i.Init = A_arbace_a2g_code_fail_A_Init; i.Table = A_arbace_a2g_code_fail_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fail_A_class, reflect.TypeFor[A_arbace_a2g_code_fail_A]()) }

func A_arbace_a2g_code_fi_adapter_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fi_adapter_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fi_adapter_val_A_New()}; return nil }

func A_arbace_a2g_code_fi_adapter_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fi_adapter_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_fi_adapter_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fi_adapter_val_A_invoke, New: A_arbace_a2g_code_fi_adapter_val_A_new, Get: A_arbace_a2g_code_fi_adapter_val_A_get}

var A_arbace_a2g_code_fi_adapter_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fi_adapter_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "fi_adapter_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fi_adapter_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fi_adapter_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fi_adapter_val_A_InstanceOf; i.Init = A_arbace_a2g_code_fi_adapter_val_A_Init; i.Table = A_arbace_a2g_code_fi_adapter_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fi_adapter_val_A_class, reflect.TypeFor[A_arbace_a2g_code_fi_adapter_val_A]()) }

func A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fi_adapter_val_fn__16000846_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_New()}; return nil }

func A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_fn_class)}; return nil }

var A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_invoke, New: A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_new, Get: A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_get}

var A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fi_adapter_val$fn__16000846", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_fi_adapter_val_A_class, Simple: "fn__16000846", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fi_adapter_val_fn__16000846_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_InstanceOf; i.Init = A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_Init; i.Table = A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fi_adapter_val_fn__16000846_A_class, reflect.TypeFor[A_arbace_a2g_code_fi_adapter_val_fn__16000846_A]()) }

func A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fi_adapter_val_fn__16000849_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_New()}; return nil }

func A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_fn_class)}; return nil }

var A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_invoke, New: A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_new, Get: A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_get}

var A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fi_adapter_val$fn__16000849", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_fi_adapter_val_A_class, Simple: "fn__16000849", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fi_adapter_val_fn__16000849_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_InstanceOf; i.Init = A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_Init; i.Table = A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fi_adapter_val_fn__16000849_A_class, reflect.TypeFor[A_arbace_a2g_code_fi_adapter_val_fn__16000849_A]()) }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_New()}; return nil }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_fn_class)}; return nil }

var A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_invoke, New: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_new, Get: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_get}

var A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fi_adapter_val$iter__16000836__16000840", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_fi_adapter_val_A_class, Simple: "iter__16000836__16000840", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_InstanceOf; i.Init = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_Init; i.Table = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_class, reflect.TypeFor[A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A]()) }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_fn_class)}; return nil }

var A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_invoke, New: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_new, Get: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_get}

var A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fi_adapter_val$iter__16000836__16000840$fn__16000841", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_A_class, Simple: "fn__16000841", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_InstanceOf; i.Init = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_Init; i.Table = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_class, reflect.TypeFor[A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A]()) }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_fn_class)}; return nil }

var A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_invoke, New: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_new, Get: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_get}

var A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fi_adapter_val$iter__16000836__16000840$fn__16000841$fn__16000842", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_A_class, Simple: "fn__16000842", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_InstanceOf; i.Init = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_Init; i.Table = A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A_class, reflect.TypeFor[A_arbace_a2g_code_fi_adapter_val_iter__16000836__16000840_fn__16000841_fn__16000842_A]()) }

func A_arbace_a2g_code_field_place_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_field_place_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_field_place_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_field_place_A_New()}; return nil }

func A_arbace_a2g_code_field_place_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_field_place_A_fn_class)}; return nil }

var A_arbace_a2g_code_field_place_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_field_place_A_invoke, New: A_arbace_a2g_code_field_place_A_new, Get: A_arbace_a2g_code_field_place_A_get}

var A_arbace_a2g_code_field_place_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$field_place", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "field_place", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_field_place_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_field_place_A_class.Info(); i.IsInstance = A_arbace_a2g_code_field_place_A_InstanceOf; i.Init = A_arbace_a2g_code_field_place_A_Init; i.Table = A_arbace_a2g_code_field_place_A_members; jrt.RegisterGoType(A_arbace_a2g_code_field_place_A_class, reflect.TypeFor[A_arbace_a2g_code_field_place_A]()) }

func A_arbace_a2g_code_float_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_float_lit_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_float_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_float_lit_A_New()}; return nil }

func A_arbace_a2g_code_float_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_float_lit_A_fn_class)}; return nil }

var A_arbace_a2g_code_float_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_float_lit_A_invoke, New: A_arbace_a2g_code_float_lit_A_new, Get: A_arbace_a2g_code_float_lit_A_get}

var A_arbace_a2g_code_float_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$float_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "float_lit", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_float_lit_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_float_lit_A_class.Info(); i.IsInstance = A_arbace_a2g_code_float_lit_A_InstanceOf; i.Init = A_arbace_a2g_code_float_lit_A_Init; i.Table = A_arbace_a2g_code_float_lit_A_members; jrt.RegisterGoType(A_arbace_a2g_code_float_lit_A_class, reflect.TypeFor[A_arbace_a2g_code_float_lit_A]()) }

func A_arbace_a2g_code_fold_int_conv_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_int_conv_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_fold_int_conv_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_int_conv_A_New()}; return nil }

func A_arbace_a2g_code_fold_int_conv_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_int_conv_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_int_conv_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_int_conv_A_invoke, New: A_arbace_a2g_code_fold_int_conv_A_new, Get: A_arbace_a2g_code_fold_int_conv_A_get}

var A_arbace_a2g_code_fold_int_conv_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_int_conv", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "fold_int_conv", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_int_conv_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_int_conv_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_int_conv_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_int_conv_A_Init; i.Table = A_arbace_a2g_code_fold_int_conv_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_int_conv_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_int_conv_A]()) }

func A_arbace_a2g_code_fold_items_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_fold_items_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_A_New()}; return nil }

func A_arbace_a2g_code_fold_items_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_A_invoke, New: A_arbace_a2g_code_fold_items_A_new, Get: A_arbace_a2g_code_fold_items_A_get}

var A_arbace_a2g_code_fold_items_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "fold_items", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_A_Init; i.Table = A_arbace_a2g_code_fold_items_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_A]()) }

func A_arbace_a2g_code_fold_items_fn__16000039_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_fn__16000039_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_fold_items_fn__16000039_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_fn__16000039_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fold_items_fn__16000039_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_fn__16000039_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_fn__16000039_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_fn__16000039_A_invoke, New: A_arbace_a2g_code_fold_items_fn__16000039_A_new, Get: A_arbace_a2g_code_fold_items_fn__16000039_A_get}

var A_arbace_a2g_code_fold_items_fn__16000039_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$fn__16000039", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_fold_items_A_class, Simple: "fn__16000039", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_fn__16000039_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_fn__16000039_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_fn__16000039_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_fn__16000039_A_Init; i.Table = A_arbace_a2g_code_fold_items_fn__16000039_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_fn__16000039_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_fn__16000039_A]()) }

func A_arbace_a2g_code_fold_items_fn__16000042_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_fn__16000042_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fold_items_fn__16000042_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_fn__16000042_A_New()}; return nil }

func A_arbace_a2g_code_fold_items_fn__16000042_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_fn__16000042_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_fn__16000042_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_fn__16000042_A_invoke, New: A_arbace_a2g_code_fold_items_fn__16000042_A_new, Get: A_arbace_a2g_code_fold_items_fn__16000042_A_get}

var A_arbace_a2g_code_fold_items_fn__16000042_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$fn__16000042", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_fold_items_A_class, Simple: "fn__16000042", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_fn__16000042_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_fn__16000042_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_fn__16000042_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_fn__16000042_A_Init; i.Table = A_arbace_a2g_code_fold_items_fn__16000042_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_fn__16000042_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_fn__16000042_A]()) }

func A_arbace_a2g_code_fold_items_fn__16000066_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_fn__16000066_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fold_items_fn__16000066_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_fn__16000066_A_New()}; return nil }

func A_arbace_a2g_code_fold_items_fn__16000066_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_fn__16000066_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_fn__16000066_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_fn__16000066_A_invoke, New: A_arbace_a2g_code_fold_items_fn__16000066_A_new, Get: A_arbace_a2g_code_fold_items_fn__16000066_A_get}

var A_arbace_a2g_code_fold_items_fn__16000066_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$fn__16000066", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_fold_items_A_class, Simple: "fn__16000066", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_fn__16000066_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_fn__16000066_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_fn__16000066_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_fn__16000066_A_Init; i.Table = A_arbace_a2g_code_fold_items_fn__16000066_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_fn__16000066_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_fn__16000066_A]()) }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_iter__16000047__16000053_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_invoke, New: A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_new, Get: A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_get}

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$iter__16000047__16000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_fold_items_A_class, Simple: "iter__16000047__16000053", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_iter__16000047__16000053_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_Init; i.Table = A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_iter__16000047__16000053_A]()) }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_invoke, New: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_new, Get: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_get}

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_fold_items_iter__16000047__16000053_A_class, Simple: "fn__16000054", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_Init; i.Table = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A]()) }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_invoke, New: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_new, Get: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_get}

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054$iter__16000049__16000058", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_A_class, Simple: "iter__16000049__16000058", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_Init; i.Table = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A]()) }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_invoke, New: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_new, Get: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_get}

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054$iter__16000049__16000058$fn__16000059", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_A_class, Simple: "fn__16000059", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_Init; i.Table = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A]()) }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_New_O_I_O_O(args[0], args[1].(int32), args[2], args[3])}; return nil }

func A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_fn_class)}; return nil }

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_invoke, New: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_new, Get: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_get}

var A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fold_items$iter__16000047__16000053$fn__16000054$iter__16000049__16000058$fn__16000059$fn__16000060", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_A_class, Simple: "fn__16000060", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_InstanceOf; i.Init = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_Init; i.Table = A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A_class, reflect.TypeFor[A_arbace_a2g_code_fold_items_iter__16000047__16000053_fn__16000054_iter__16000049__16000058_fn__16000059_fn__16000060_A]()) }

func A_arbace_a2g_code_fresh_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fresh_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fresh_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fresh_A_New()}; return nil }

func A_arbace_a2g_code_fresh_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fresh_A_fn_class)}; return nil }

var A_arbace_a2g_code_fresh_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fresh_A_invoke, New: A_arbace_a2g_code_fresh_A_new, Get: A_arbace_a2g_code_fresh_A_get}

var A_arbace_a2g_code_fresh_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fresh", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "fresh", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fresh_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fresh_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fresh_A_InstanceOf; i.Init = A_arbace_a2g_code_fresh_A_Init; i.Table = A_arbace_a2g_code_fresh_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fresh_A_class, reflect.TypeFor[A_arbace_a2g_code_fresh_A]()) }

func A_arbace_a2g_code_fresh_raw_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_fresh_raw_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_fresh_raw_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_fresh_raw_A_New()}; return nil }

func A_arbace_a2g_code_fresh_raw_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_fresh_raw_A_fn_class)}; return nil }

var A_arbace_a2g_code_fresh_raw_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_fresh_raw_A_invoke, New: A_arbace_a2g_code_fresh_raw_A_new, Get: A_arbace_a2g_code_fresh_raw_A_get}

var A_arbace_a2g_code_fresh_raw_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$fresh_raw", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "fresh_raw", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_fresh_raw_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_fresh_raw_A_class.Info(); i.IsInstance = A_arbace_a2g_code_fresh_raw_A_InstanceOf; i.Init = A_arbace_a2g_code_fresh_raw_A_Init; i.Table = A_arbace_a2g_code_fresh_raw_A_members; jrt.RegisterGoType(A_arbace_a2g_code_fresh_raw_A_class, reflect.TypeFor[A_arbace_a2g_code_fresh_raw_A]()) }

func A_arbace_a2g_code_go_call_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_go_call_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_go_call_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_go_call_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_go_call_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_go_call_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_go_call_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_go_call_QMARK__A_invoke, New: A_arbace_a2g_code_go_call_QMARK__A_new, Get: A_arbace_a2g_code_go_call_QMARK__A_get}

var A_arbace_a2g_code_go_call_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$go_call_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "go_call_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_go_call_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_go_call_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_go_call_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_go_call_QMARK__A_Init; i.Table = A_arbace_a2g_code_go_call_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_go_call_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_go_call_QMARK__A]()) }

func A_arbace_a2g_code_go_lit_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_go_lit_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_go_lit_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_go_lit_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_go_lit_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_go_lit_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_go_lit_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_go_lit_QMARK__A_invoke, New: A_arbace_a2g_code_go_lit_QMARK__A_new, Get: A_arbace_a2g_code_go_lit_QMARK__A_get}

var A_arbace_a2g_code_go_lit_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$go_lit_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "go_lit_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_go_lit_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_go_lit_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_go_lit_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_go_lit_QMARK__A_Init; i.Table = A_arbace_a2g_code_go_lit_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_go_lit_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_go_lit_QMARK__A]()) }

func A_arbace_a2g_code_gotype_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_gotype_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_gotype_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_gotype_A_New()}; return nil }

func A_arbace_a2g_code_gotype_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_gotype_A_fn_class)}; return nil }

var A_arbace_a2g_code_gotype_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_gotype_A_invoke, New: A_arbace_a2g_code_gotype_A_new, Get: A_arbace_a2g_code_gotype_A_get}

var A_arbace_a2g_code_gotype_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$gotype", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "gotype", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_gotype_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_gotype_A_class.Info(); i.IsInstance = A_arbace_a2g_code_gotype_A_InstanceOf; i.Init = A_arbace_a2g_code_gotype_A_Init; i.Table = A_arbace_a2g_code_gotype_A_members; jrt.RegisterGoType(A_arbace_a2g_code_gotype_A_class, reflect.TypeFor[A_arbace_a2g_code_gotype_A]()) }

func A_arbace_a2g_code_guarded_static_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_guarded_static_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_guarded_static_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_guarded_static_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_guarded_static_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_guarded_static_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_guarded_static_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_guarded_static_QMARK__A_invoke, New: A_arbace_a2g_code_guarded_static_QMARK__A_new, Get: A_arbace_a2g_code_guarded_static_QMARK__A_get}

var A_arbace_a2g_code_guarded_static_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$guarded_static_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "guarded_static_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_guarded_static_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_guarded_static_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_guarded_static_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_guarded_static_QMARK__A_Init; i.Table = A_arbace_a2g_code_guarded_static_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_guarded_static_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_guarded_static_QMARK__A]()) }

func A_arbace_a2g_code_hoist_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_hoist_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_hoist_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_hoist_A_New()}; return nil }

func A_arbace_a2g_code_hoist_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_hoist_A_fn_class)}; return nil }

var A_arbace_a2g_code_hoist_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_hoist_A_invoke, New: A_arbace_a2g_code_hoist_A_new, Get: A_arbace_a2g_code_hoist_A_get}

var A_arbace_a2g_code_hoist_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$hoist", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "hoist", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_hoist_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_hoist_A_class.Info(); i.IsInstance = A_arbace_a2g_code_hoist_A_InstanceOf; i.Init = A_arbace_a2g_code_hoist_A_Init; i.Table = A_arbace_a2g_code_hoist_A_members; jrt.RegisterGoType(A_arbace_a2g_code_hoist_A_class, reflect.TypeFor[A_arbace_a2g_code_hoist_A]()) }

func A_arbace_a2g_code_hoist_value_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_hoist_value_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_hoist_value_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_hoist_value_A_New()}; return nil }

func A_arbace_a2g_code_hoist_value_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_hoist_value_A_fn_class)}; return nil }

var A_arbace_a2g_code_hoist_value_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_hoist_value_A_invoke, New: A_arbace_a2g_code_hoist_value_A_new, Get: A_arbace_a2g_code_hoist_value_A_get}

var A_arbace_a2g_code_hoist_value_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$hoist_value", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "hoist_value", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_hoist_value_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_hoist_value_A_class.Info(); i.IsInstance = A_arbace_a2g_code_hoist_value_A_InstanceOf; i.Init = A_arbace_a2g_code_hoist_value_A_Init; i.Table = A_arbace_a2g_code_hoist_value_A_members; jrt.RegisterGoType(A_arbace_a2g_code_hoist_value_A_class, reflect.TypeFor[A_arbace_a2g_code_hoist_value_A]()) }

func A_arbace_a2g_code_hw_static_exists_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_hw_static_exists_QMARK__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_hw_static_exists_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_hw_static_exists_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_hw_static_exists_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_hw_static_exists_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_hw_static_exists_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_hw_static_exists_QMARK__A_invoke, New: A_arbace_a2g_code_hw_static_exists_QMARK__A_new, Get: A_arbace_a2g_code_hw_static_exists_QMARK__A_get}

var A_arbace_a2g_code_hw_static_exists_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$hw_static_exists_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "hw_static_exists_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_hw_static_exists_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_hw_static_exists_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_hw_static_exists_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_hw_static_exists_QMARK__A_Init; i.Table = A_arbace_a2g_code_hw_static_exists_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_hw_static_exists_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_hw_static_exists_QMARK__A]()) }

func A_arbace_a2g_code_instance_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_instance_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_instance_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_instance_val_A_New()}; return nil }

func A_arbace_a2g_code_instance_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_instance_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_instance_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_instance_val_A_invoke, New: A_arbace_a2g_code_instance_val_A_new, Get: A_arbace_a2g_code_instance_val_A_get}

var A_arbace_a2g_code_instance_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$instance_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "instance_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_instance_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_instance_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_instance_val_A_InstanceOf; i.Init = A_arbace_a2g_code_instance_val_A_Init; i.Table = A_arbace_a2g_code_instance_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_instance_val_A_class, reflect.TypeFor[A_arbace_a2g_code_instance_val_A]()) }

func A_arbace_a2g_code_instance_val_fn__16000255_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_instance_val_fn__16000255_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_instance_val_fn__16000255_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_instance_val_fn__16000255_A_New()}; return nil }

func A_arbace_a2g_code_instance_val_fn__16000255_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_instance_val_fn__16000255_A_fn_class)}; return nil }

var A_arbace_a2g_code_instance_val_fn__16000255_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_instance_val_fn__16000255_A_invoke, New: A_arbace_a2g_code_instance_val_fn__16000255_A_new, Get: A_arbace_a2g_code_instance_val_fn__16000255_A_get}

var A_arbace_a2g_code_instance_val_fn__16000255_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$instance_val$fn__16000255", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_instance_val_A_class, Simple: "fn__16000255", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_instance_val_fn__16000255_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_instance_val_fn__16000255_A_class.Info(); i.IsInstance = A_arbace_a2g_code_instance_val_fn__16000255_A_InstanceOf; i.Init = A_arbace_a2g_code_instance_val_fn__16000255_A_Init; i.Table = A_arbace_a2g_code_instance_val_fn__16000255_A_members; jrt.RegisterGoType(A_arbace_a2g_code_instance_val_fn__16000255_A_class, reflect.TypeFor[A_arbace_a2g_code_instance_val_fn__16000255_A]()) }

func A_arbace_a2g_code_invoke_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_invoke_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_invoke_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_invoke_val_A_New()}; return nil }

func A_arbace_a2g_code_invoke_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_invoke_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_invoke_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_invoke_val_A_invoke, New: A_arbace_a2g_code_invoke_val_A_new, Get: A_arbace_a2g_code_invoke_val_A_get}

var A_arbace_a2g_code_invoke_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$invoke_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "invoke_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_invoke_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_invoke_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_invoke_val_A_InstanceOf; i.Init = A_arbace_a2g_code_invoke_val_A_Init; i.Table = A_arbace_a2g_code_invoke_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_invoke_val_A_class, reflect.TypeFor[A_arbace_a2g_code_invoke_val_A]()) }

func A_arbace_a2g_code_invoke_val_rv__16000324_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_invoke_val_rv__16000324_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_invoke_val_rv__16000324_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_invoke_val_rv__16000324_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_invoke_val_rv__16000324_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_invoke_val_rv__16000324_A_fn_class)}; return nil }

var A_arbace_a2g_code_invoke_val_rv__16000324_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_invoke_val_rv__16000324_A_invoke, New: A_arbace_a2g_code_invoke_val_rv__16000324_A_new, Get: A_arbace_a2g_code_invoke_val_rv__16000324_A_get}

var A_arbace_a2g_code_invoke_val_rv__16000324_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$invoke_val$rv__16000324", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_invoke_val_A_class, Simple: "rv__16000324", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_invoke_val_rv__16000324_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_invoke_val_rv__16000324_A_class.Info(); i.IsInstance = A_arbace_a2g_code_invoke_val_rv__16000324_A_InstanceOf; i.Init = A_arbace_a2g_code_invoke_val_rv__16000324_A_Init; i.Table = A_arbace_a2g_code_invoke_val_rv__16000324_A_members; jrt.RegisterGoType(A_arbace_a2g_code_invoke_val_rv__16000324_A_class, reflect.TypeFor[A_arbace_a2g_code_invoke_val_rv__16000324_A]()) }

func A_arbace_a2g_code_java_hash_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_java_hash_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_java_hash_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_java_hash_A_New()}; return nil }

func A_arbace_a2g_code_java_hash_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_java_hash_A_fn_class)}; return nil }

var A_arbace_a2g_code_java_hash_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_java_hash_A_invoke, New: A_arbace_a2g_code_java_hash_A_new, Get: A_arbace_a2g_code_java_hash_A_get}

var A_arbace_a2g_code_java_hash_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$java_hash", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "java_hash", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_java_hash_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_java_hash_A_class.Info(); i.IsInstance = A_arbace_a2g_code_java_hash_A_InstanceOf; i.Init = A_arbace_a2g_code_java_hash_A_Init; i.Table = A_arbace_a2g_code_java_hash_A_members; jrt.RegisterGoType(A_arbace_a2g_code_java_hash_A_class, reflect.TypeFor[A_arbace_a2g_code_java_hash_A]()) }

func A_arbace_a2g_code_java_str_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_java_str_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_java_str_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_java_str_val_A_New()}; return nil }

func A_arbace_a2g_code_java_str_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_java_str_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_java_str_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_java_str_val_A_invoke, New: A_arbace_a2g_code_java_str_val_A_new, Get: A_arbace_a2g_code_java_str_val_A_get}

var A_arbace_a2g_code_java_str_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$java_str_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "java_str_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_java_str_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_java_str_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_java_str_val_A_InstanceOf; i.Init = A_arbace_a2g_code_java_str_val_A_Init; i.Table = A_arbace_a2g_code_java_str_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_java_str_val_A_class, reflect.TypeFor[A_arbace_a2g_code_java_str_val_A]()) }

func A_arbace_a2g_code_java_str_val_fn__16000385_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_java_str_val_fn__16000385_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_java_str_val_fn__16000385_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_java_str_val_fn__16000385_A_New()}; return nil }

func A_arbace_a2g_code_java_str_val_fn__16000385_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_java_str_val_fn__16000385_A_fn_class)}; return nil }

var A_arbace_a2g_code_java_str_val_fn__16000385_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_java_str_val_fn__16000385_A_invoke, New: A_arbace_a2g_code_java_str_val_fn__16000385_A_new, Get: A_arbace_a2g_code_java_str_val_fn__16000385_A_get}

var A_arbace_a2g_code_java_str_val_fn__16000385_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$java_str_val$fn__16000385", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_java_str_val_A_class, Simple: "fn__16000385", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_java_str_val_fn__16000385_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_java_str_val_fn__16000385_A_class.Info(); i.IsInstance = A_arbace_a2g_code_java_str_val_fn__16000385_A_InstanceOf; i.Init = A_arbace_a2g_code_java_str_val_fn__16000385_A_Init; i.Table = A_arbace_a2g_code_java_str_val_fn__16000385_A_members; jrt.RegisterGoType(A_arbace_a2g_code_java_str_val_fn__16000385_A_class, reflect.TypeFor[A_arbace_a2g_code_java_str_val_fn__16000385_A]()) }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_fn_class)}; return nil }

var A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_invoke, New: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_new, Get: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_get}

var A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$java_str_val$iter__16000387__16000391", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_java_str_val_A_class, Simple: "iter__16000387__16000391", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_class.Info(); i.IsInstance = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_InstanceOf; i.Init = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_Init; i.Table = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_members; jrt.RegisterGoType(A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_class, reflect.TypeFor[A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A]()) }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_fn_class)}; return nil }

var A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_invoke, New: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_new, Get: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_get}

var A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$java_str_val$iter__16000387__16000391$fn__16000392", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_A_class, Simple: "fn__16000392", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_class.Info(); i.IsInstance = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_InstanceOf; i.Init = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_Init; i.Table = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_members; jrt.RegisterGoType(A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_class, reflect.TypeFor[A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A]()) }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_fn_class)}; return nil }

var A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_invoke, New: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_new, Get: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_get}

var A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$java_str_val$iter__16000387__16000391$fn__16000392$fn__16000393", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_A_class, Simple: "fn__16000393", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_class.Info(); i.IsInstance = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_InstanceOf; i.Init = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_Init; i.Table = A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_members; jrt.RegisterGoType(A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A_class, reflect.TypeFor[A_arbace_a2g_code_java_str_val_iter__16000387__16000391_fn__16000392_fn__16000393_A]()) }

func A_arbace_a2g_code_jsym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_jsym_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_jsym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_jsym_A_New()}; return nil }

func A_arbace_a2g_code_jsym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_jsym_A_fn_class)}; return nil }

var A_arbace_a2g_code_jsym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_jsym_A_invoke, New: A_arbace_a2g_code_jsym_A_new, Get: A_arbace_a2g_code_jsym_A_get}

var A_arbace_a2g_code_jsym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$jsym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "jsym", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_jsym_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_jsym_A_class.Info(); i.IsInstance = A_arbace_a2g_code_jsym_A_InstanceOf; i.Init = A_arbace_a2g_code_jsym_A_Init; i.Table = A_arbace_a2g_code_jsym_A_members; jrt.RegisterGoType(A_arbace_a2g_code_jsym_A_class, reflect.TypeFor[A_arbace_a2g_code_jsym_A]()) }

func A_arbace_a2g_code_lambda_markers_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_markers_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_lambda_markers_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_markers_A_New()}; return nil }

func A_arbace_a2g_code_lambda_markers_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_markers_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_markers_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_markers_A_invoke, New: A_arbace_a2g_code_lambda_markers_A_new, Get: A_arbace_a2g_code_lambda_markers_A_get}

var A_arbace_a2g_code_lambda_markers_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_markers", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "lambda_markers", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_markers_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_markers_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_markers_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_markers_A_Init; i.Table = A_arbace_a2g_code_lambda_markers_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_markers_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_markers_A]()) }

func A_arbace_a2g_code_lambda_markers_fn__16000790_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_markers_fn__16000790_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_lambda_markers_fn__16000790_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_markers_fn__16000790_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_lambda_markers_fn__16000790_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_markers_fn__16000790_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_markers_fn__16000790_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_markers_fn__16000790_A_invoke, New: A_arbace_a2g_code_lambda_markers_fn__16000790_A_new, Get: A_arbace_a2g_code_lambda_markers_fn__16000790_A_get}

var A_arbace_a2g_code_lambda_markers_fn__16000790_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_markers$fn__16000790", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_lambda_markers_A_class, Simple: "fn__16000790", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_markers_fn__16000790_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_markers_fn__16000790_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_markers_fn__16000790_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_markers_fn__16000790_A_Init; i.Table = A_arbace_a2g_code_lambda_markers_fn__16000790_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_markers_fn__16000790_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_markers_fn__16000790_A]()) }

func A_arbace_a2g_code_lambda_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_lambda_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_A_New()}; return nil }

func A_arbace_a2g_code_lambda_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_A_invoke, New: A_arbace_a2g_code_lambda_val_A_new, Get: A_arbace_a2g_code_lambda_val_A_get}

var A_arbace_a2g_code_lambda_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "lambda_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_A_Init; i.Table = A_arbace_a2g_code_lambda_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_A]()) }

func A_arbace_a2g_code_lambda_val_fn__16000813_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_fn__16000813_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_lambda_val_fn__16000813_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_fn__16000813_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_code_lambda_val_fn__16000813_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_fn__16000813_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_fn__16000813_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_fn__16000813_A_invoke, New: A_arbace_a2g_code_lambda_val_fn__16000813_A_new, Get: A_arbace_a2g_code_lambda_val_fn__16000813_A_get}

var A_arbace_a2g_code_lambda_val_fn__16000813_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val$fn__16000813", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_lambda_val_A_class, Simple: "fn__16000813", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_fn__16000813_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_fn__16000813_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_fn__16000813_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_fn__16000813_A_Init; i.Table = A_arbace_a2g_code_lambda_val_fn__16000813_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_fn__16000813_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_fn__16000813_A]()) }

func A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_New_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_invoke, New: A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_new, Get: A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_get}

var A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val$fn__16000813$fn__16000814", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_lambda_val_fn__16000813_A_class, Simple: "fn__16000814", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_Init; i.Table = A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000814_A]()) }

func A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_New()}; return nil }

func A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_invoke, New: A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_new, Get: A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_get}

var A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val$fn__16000813$fn__16000827", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_lambda_val_fn__16000813_A_class, Simple: "fn__16000827", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_Init; i.Table = A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_fn__16000813_fn__16000827_A]()) }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_New()}; return nil }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_invoke, New: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_new, Get: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_get}

var A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val$iter__16000803__16000807", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_lambda_val_A_class, Simple: "iter__16000803__16000807", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_Init; i.Table = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A]()) }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_invoke, New: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_new, Get: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_get}

var A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val$iter__16000803__16000807$fn__16000808", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_A_class, Simple: "fn__16000808", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_Init; i.Table = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A]()) }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_fn_class)}; return nil }

var A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_invoke, New: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_new, Get: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_get}

var A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lambda_val$iter__16000803__16000807$fn__16000808$fn__16000809", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_A_class, Simple: "fn__16000809", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_class.Info(); i.IsInstance = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_InstanceOf; i.Init = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_Init; i.Table = A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_members; jrt.RegisterGoType(A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A_class, reflect.TypeFor[A_arbace_a2g_code_lambda_val_iter__16000803__16000807_fn__16000808_fn__16000809_A]()) }

func A_arbace_a2g_code_literal_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_literal_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_literal_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_literal_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_literal_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_literal_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_literal_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_literal_QMARK__A_invoke, New: A_arbace_a2g_code_literal_QMARK__A_new, Get: A_arbace_a2g_code_literal_QMARK__A_get}

var A_arbace_a2g_code_literal_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$literal_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "literal_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_literal_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_literal_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_literal_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_literal_QMARK__A_Init; i.Table = A_arbace_a2g_code_literal_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_literal_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_literal_QMARK__A]()) }

func A_arbace_a2g_code_literal_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_literal_form_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_literal_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_literal_form_A_New()}; return nil }

func A_arbace_a2g_code_literal_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_literal_form_A_fn_class)}; return nil }

var A_arbace_a2g_code_literal_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_literal_form_A_invoke, New: A_arbace_a2g_code_literal_form_A_new, Get: A_arbace_a2g_code_literal_form_A_get}

var A_arbace_a2g_code_literal_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$literal_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "literal_form", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_literal_form_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_literal_form_A_class.Info(); i.IsInstance = A_arbace_a2g_code_literal_form_A_InstanceOf; i.Init = A_arbace_a2g_code_literal_form_A_Init; i.Table = A_arbace_a2g_code_literal_form_A_members; jrt.RegisterGoType(A_arbace_a2g_code_literal_form_A_class, reflect.TypeFor[A_arbace_a2g_code_literal_form_A]()) }

func A_arbace_a2g_code_literal_form_fix__16000739_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_literal_form_fix__16000739_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_literal_form_fix__16000739_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_literal_form_fix__16000739_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_literal_form_fix__16000739_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_literal_form_fix__16000739_A_fn_class)}; return nil }

var A_arbace_a2g_code_literal_form_fix__16000739_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_literal_form_fix__16000739_A_invoke, New: A_arbace_a2g_code_literal_form_fix__16000739_A_new, Get: A_arbace_a2g_code_literal_form_fix__16000739_A_get}

var A_arbace_a2g_code_literal_form_fix__16000739_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$literal_form$fix__16000739", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_literal_form_A_class, Simple: "fix__16000739", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_literal_form_fix__16000739_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_literal_form_fix__16000739_A_class.Info(); i.IsInstance = A_arbace_a2g_code_literal_form_fix__16000739_A_InstanceOf; i.Init = A_arbace_a2g_code_literal_form_fix__16000739_A_Init; i.Table = A_arbace_a2g_code_literal_form_fix__16000739_A_members; jrt.RegisterGoType(A_arbace_a2g_code_literal_form_fix__16000739_A_class, reflect.TypeFor[A_arbace_a2g_code_literal_form_fix__16000739_A]()) }

func A_arbace_a2g_code_live_catches_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_live_catches_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_live_catches_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_live_catches_A_New()}; return nil }

func A_arbace_a2g_code_live_catches_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_live_catches_A_fn_class)}; return nil }

var A_arbace_a2g_code_live_catches_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_live_catches_A_invoke, New: A_arbace_a2g_code_live_catches_A_new, Get: A_arbace_a2g_code_live_catches_A_get}

var A_arbace_a2g_code_live_catches_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$live_catches", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "live_catches", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_live_catches_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_live_catches_A_class.Info(); i.IsInstance = A_arbace_a2g_code_live_catches_A_InstanceOf; i.Init = A_arbace_a2g_code_live_catches_A_Init; i.Table = A_arbace_a2g_code_live_catches_A_members; jrt.RegisterGoType(A_arbace_a2g_code_live_catches_A_class, reflect.TypeFor[A_arbace_a2g_code_live_catches_A]()) }

func A_arbace_a2g_code_live_catches_fn__16000715_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_live_catches_fn__16000715_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_live_catches_fn__16000715_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_live_catches_fn__16000715_A_New()}; return nil }

func A_arbace_a2g_code_live_catches_fn__16000715_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_live_catches_fn__16000715_A_fn_class)}; return nil }

var A_arbace_a2g_code_live_catches_fn__16000715_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_live_catches_fn__16000715_A_invoke, New: A_arbace_a2g_code_live_catches_fn__16000715_A_new, Get: A_arbace_a2g_code_live_catches_fn__16000715_A_get}

var A_arbace_a2g_code_live_catches_fn__16000715_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$live_catches$fn__16000715", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_live_catches_A_class, Simple: "fn__16000715", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_live_catches_fn__16000715_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_live_catches_fn__16000715_A_class.Info(); i.IsInstance = A_arbace_a2g_code_live_catches_fn__16000715_A_InstanceOf; i.Init = A_arbace_a2g_code_live_catches_fn__16000715_A_Init; i.Table = A_arbace_a2g_code_live_catches_fn__16000715_A_members; jrt.RegisterGoType(A_arbace_a2g_code_live_catches_fn__16000715_A_class, reflect.TypeFor[A_arbace_a2g_code_live_catches_fn__16000715_A]()) }

func A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_New()}; return nil }

func A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_fn_class)}; return nil }

var A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_invoke, New: A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_new, Get: A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_get}

var A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$live_catches$fn__16000715$fn__16000716", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_live_catches_fn__16000715_A_class, Simple: "fn__16000716", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_class.Info(); i.IsInstance = A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_InstanceOf; i.Init = A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_Init; i.Table = A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_members; jrt.RegisterGoType(A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A_class, reflect.TypeFor[A_arbace_a2g_code_live_catches_fn__16000715_fn__16000716_A]()) }

func A_arbace_a2g_code_local_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_local_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_local_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_local_val_A_New()}; return nil }

func A_arbace_a2g_code_local_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_local_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_local_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_local_val_A_invoke, New: A_arbace_a2g_code_local_val_A_new, Get: A_arbace_a2g_code_local_val_A_get}

var A_arbace_a2g_code_local_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$local_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "local_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_local_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_local_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_local_val_A_InstanceOf; i.Init = A_arbace_a2g_code_local_val_A_Init; i.Table = A_arbace_a2g_code_local_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_local_val_A_class, reflect.TypeFor[A_arbace_a2g_code_local_val_A]()) }

func A_arbace_a2g_code_lookup_call_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_lookup_call_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_lookup_call_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_lookup_call_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_lookup_call_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_lookup_call_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_lookup_call_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_lookup_call_QMARK__A_invoke, New: A_arbace_a2g_code_lookup_call_QMARK__A_new, Get: A_arbace_a2g_code_lookup_call_QMARK__A_get}

var A_arbace_a2g_code_lookup_call_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$lookup_call_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "lookup_call_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_lookup_call_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_lookup_call_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_lookup_call_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_lookup_call_QMARK__A_Init; i.Table = A_arbace_a2g_code_lookup_call_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_lookup_call_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_lookup_call_QMARK__A]()) }

func A_arbace_a2g_code_match_pattern_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_match_pattern_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_match_pattern_BANG__A_New()}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_match_pattern_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_match_pattern_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_match_pattern_BANG__A_invoke, New: A_arbace_a2g_code_match_pattern_BANG__A_new, Get: A_arbace_a2g_code_match_pattern_BANG__A_get}

var A_arbace_a2g_code_match_pattern_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$match_pattern_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "match_pattern_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_match_pattern_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_match_pattern_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_match_pattern_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_match_pattern_BANG__A_Init; i.Table = A_arbace_a2g_code_match_pattern_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_match_pattern_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_match_pattern_BANG__A]()) }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_fn_class)}; return nil }

var A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_invoke, New: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_new, Get: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_get}

var A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$match_pattern_BANG_$inner__16000512", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_match_pattern_BANG__A_class, Simple: "inner__16000512", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_class.Info(); i.IsInstance = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_InstanceOf; i.Init = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_Init; i.Table = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_members; jrt.RegisterGoType(A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_class, reflect.TypeFor[A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A]()) }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_fn_class)}; return nil }

var A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_invoke, New: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_new, Get: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_get}

var A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$match_pattern_BANG_$inner__16000512$comps__16000514", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_A_class, Simple: "comps__16000514", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_class.Info(); i.IsInstance = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_InstanceOf; i.Init = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_Init; i.Table = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_members; jrt.RegisterGoType(A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_class, reflect.TypeFor[A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A]()) }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_fn_class)}; return nil }

var A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_invoke, New: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_new, Get: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_get}

var A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$match_pattern_BANG_$inner__16000512$comps__16000514$fn__16000517", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_A_class, Simple: "fn__16000517", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_class.Info(); i.IsInstance = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_InstanceOf; i.Init = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_Init; i.Table = A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_members; jrt.RegisterGoType(A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A_class, reflect.TypeFor[A_arbace_a2g_code_match_pattern_BANG__inner__16000512_comps__16000514_fn__16000517_A]()) }

func A_arbace_a2g_code_mdesc_missing_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_mdesc_missing_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_mdesc_missing_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_mdesc_missing_A_New()}; return nil }

func A_arbace_a2g_code_mdesc_missing_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_mdesc_missing_A_fn_class)}; return nil }

var A_arbace_a2g_code_mdesc_missing_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_mdesc_missing_A_invoke, New: A_arbace_a2g_code_mdesc_missing_A_new, Get: A_arbace_a2g_code_mdesc_missing_A_get}

var A_arbace_a2g_code_mdesc_missing_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$mdesc_missing", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "mdesc_missing", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_mdesc_missing_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_mdesc_missing_A_class.Info(); i.IsInstance = A_arbace_a2g_code_mdesc_missing_A_InstanceOf; i.Init = A_arbace_a2g_code_mdesc_missing_A_Init; i.Table = A_arbace_a2g_code_mdesc_missing_A_members; jrt.RegisterGoType(A_arbace_a2g_code_mdesc_missing_A_class, reflect.TypeFor[A_arbace_a2g_code_mdesc_missing_A]()) }

func A_arbace_a2g_code_method_ref_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_method_ref_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_A_New()}; return nil }

func A_arbace_a2g_code_method_ref_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_A_invoke, New: A_arbace_a2g_code_method_ref_val_A_new, Get: A_arbace_a2g_code_method_ref_val_A_get}

var A_arbace_a2g_code_method_ref_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "method_ref_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_A]()) }

func A_arbace_a2g_code_method_ref_val_callf__16000867_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_callf__16000867_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_method_ref_val_callf__16000867_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_callf__16000867_A_New_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7])}; return nil }

func A_arbace_a2g_code_method_ref_val_callf__16000867_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_callf__16000867_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_callf__16000867_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_callf__16000867_A_invoke, New: A_arbace_a2g_code_method_ref_val_callf__16000867_A_new, Get: A_arbace_a2g_code_method_ref_val_callf__16000867_A_get}

var A_arbace_a2g_code_method_ref_val_callf__16000867_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$callf__16000867", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_method_ref_val_A_class, Simple: "callf__16000867", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_callf__16000867_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_callf__16000867_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_callf__16000867_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_callf__16000867_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_callf__16000867_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_callf__16000867_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_callf__16000867_A]()) }

func A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_New()}; return nil }

func A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_invoke, New: A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_new, Get: A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_get}

var A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$callf__16000867$fn__16000869", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_method_ref_val_callf__16000867_A_class, Simple: "fn__16000869", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000869_A]()) }

func A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_New()}; return nil }

func A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_invoke, New: A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_new, Get: A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_get}

var A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$callf__16000867$fn__16000871", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_method_ref_val_callf__16000867_A_class, Simple: "fn__16000871", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_callf__16000867_fn__16000871_A]()) }

func A_arbace_a2g_code_method_ref_val_fn__16000876_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_fn__16000876_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_method_ref_val_fn__16000876_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_fn__16000876_A_New()}; return nil }

func A_arbace_a2g_code_method_ref_val_fn__16000876_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_fn__16000876_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_fn__16000876_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_fn__16000876_A_invoke, New: A_arbace_a2g_code_method_ref_val_fn__16000876_A_new, Get: A_arbace_a2g_code_method_ref_val_fn__16000876_A_get}

var A_arbace_a2g_code_method_ref_val_fn__16000876_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$fn__16000876", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_method_ref_val_A_class, Simple: "fn__16000876", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_fn__16000876_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_fn__16000876_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_fn__16000876_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_fn__16000876_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_fn__16000876_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_fn__16000876_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_fn__16000876_A]()) }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_New()}; return nil }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_invoke, New: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_new, Get: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_get}

var A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$iter__16000857__16000861", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_method_ref_val_A_class, Simple: "iter__16000857__16000861", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A]()) }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_invoke, New: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_new, Get: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_get}

var A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$iter__16000857__16000861$fn__16000862", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_A_class, Simple: "fn__16000862", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A]()) }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_fn_class)}; return nil }

var A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_invoke, New: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_new, Get: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_get}

var A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_ref_val$iter__16000857__16000861$fn__16000862$fn__16000863", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_A_class, Simple: "fn__16000863", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_InstanceOf; i.Init = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_Init; i.Table = A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A_class, reflect.TypeFor[A_arbace_a2g_code_method_ref_val_iter__16000857__16000861_fn__16000862_fn__16000863_A]()) }

func A_arbace_a2g_code_method_return_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_method_return_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_method_return_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_method_return_BANG__A_New()}; return nil }

func A_arbace_a2g_code_method_return_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_method_return_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_method_return_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_method_return_BANG__A_invoke, New: A_arbace_a2g_code_method_return_BANG__A_new, Get: A_arbace_a2g_code_method_return_BANG__A_get}

var A_arbace_a2g_code_method_return_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$method_return_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "method_return_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_method_return_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_method_return_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_method_return_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_method_return_BANG__A_Init; i.Table = A_arbace_a2g_code_method_return_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_method_return_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_method_return_BANG__A]()) }

func A_arbace_a2g_code_missing_expr_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_missing_expr_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_missing_expr_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_missing_expr_A_New()}; return nil }

func A_arbace_a2g_code_missing_expr_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_missing_expr_A_fn_class)}; return nil }

var A_arbace_a2g_code_missing_expr_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_missing_expr_A_invoke, New: A_arbace_a2g_code_missing_expr_A_new, Get: A_arbace_a2g_code_missing_expr_A_get}

var A_arbace_a2g_code_missing_expr_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$missing_expr", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "missing_expr", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_missing_expr_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_missing_expr_A_class.Info(); i.IsInstance = A_arbace_a2g_code_missing_expr_A_InstanceOf; i.Init = A_arbace_a2g_code_missing_expr_A_Init; i.Table = A_arbace_a2g_code_missing_expr_A_members; jrt.RegisterGoType(A_arbace_a2g_code_missing_expr_A_class, reflect.TypeFor[A_arbace_a2g_code_missing_expr_A]()) }

func A_arbace_a2g_code_missing_reason_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_missing_reason_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_missing_reason_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_missing_reason_A_New()}; return nil }

func A_arbace_a2g_code_missing_reason_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_missing_reason_A_fn_class)}; return nil }

var A_arbace_a2g_code_missing_reason_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_missing_reason_A_invoke, New: A_arbace_a2g_code_missing_reason_A_new, Get: A_arbace_a2g_code_missing_reason_A_get}

var A_arbace_a2g_code_missing_reason_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$missing_reason", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "missing_reason", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_missing_reason_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_missing_reason_A_class.Info(); i.IsInstance = A_arbace_a2g_code_missing_reason_A_InstanceOf; i.Init = A_arbace_a2g_code_missing_reason_A_Init; i.Table = A_arbace_a2g_code_missing_reason_A_members; jrt.RegisterGoType(A_arbace_a2g_code_missing_reason_A_class, reflect.TypeFor[A_arbace_a2g_code_missing_reason_A]()) }

func A_arbace_a2g_code_missing_reason_fn__16000161_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_missing_reason_fn__16000161_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_missing_reason_fn__16000161_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_missing_reason_fn__16000161_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_missing_reason_fn__16000161_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_missing_reason_fn__16000161_A_fn_class)}; return nil }

var A_arbace_a2g_code_missing_reason_fn__16000161_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_missing_reason_fn__16000161_A_invoke, New: A_arbace_a2g_code_missing_reason_fn__16000161_A_new, Get: A_arbace_a2g_code_missing_reason_fn__16000161_A_get}

var A_arbace_a2g_code_missing_reason_fn__16000161_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$missing_reason$fn__16000161", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_missing_reason_A_class, Simple: "fn__16000161", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_missing_reason_fn__16000161_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_missing_reason_fn__16000161_A_class.Info(); i.IsInstance = A_arbace_a2g_code_missing_reason_fn__16000161_A_InstanceOf; i.Init = A_arbace_a2g_code_missing_reason_fn__16000161_A_Init; i.Table = A_arbace_a2g_code_missing_reason_fn__16000161_A_members; jrt.RegisterGoType(A_arbace_a2g_code_missing_reason_fn__16000161_A_class, reflect.TypeFor[A_arbace_a2g_code_missing_reason_fn__16000161_A]()) }

func A_arbace_a2g_code_new_counter_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_new_counter_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_new_counter_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_new_counter_BANG__A_New()}; return nil }

func A_arbace_a2g_code_new_counter_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_new_counter_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_new_counter_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_new_counter_BANG__A_invoke, New: A_arbace_a2g_code_new_counter_BANG__A_new, Get: A_arbace_a2g_code_new_counter_BANG__A_get}

var A_arbace_a2g_code_new_counter_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$new_counter_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "new_counter_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_new_counter_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_new_counter_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_new_counter_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_new_counter_BANG__A_Init; i.Table = A_arbace_a2g_code_new_counter_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_new_counter_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_new_counter_BANG__A]()) }

func A_arbace_a2g_code_new_label_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_new_label_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_new_label_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_new_label_A_New()}; return nil }

func A_arbace_a2g_code_new_label_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_new_label_A_fn_class)}; return nil }

var A_arbace_a2g_code_new_label_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_new_label_A_invoke, New: A_arbace_a2g_code_new_label_A_new, Get: A_arbace_a2g_code_new_label_A_get}

var A_arbace_a2g_code_new_label_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$new_label", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "new_label", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_new_label_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_new_label_A_class.Info(); i.IsInstance = A_arbace_a2g_code_new_label_A_InstanceOf; i.Init = A_arbace_a2g_code_new_label_A_Init; i.Table = A_arbace_a2g_code_new_label_A_members; jrt.RegisterGoType(A_arbace_a2g_code_new_label_A_class, reflect.TypeFor[A_arbace_a2g_code_new_label_A]()) }

func A_arbace_a2g_code_new_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_new_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_new_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_new_val_A_New()}; return nil }

func A_arbace_a2g_code_new_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_new_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_new_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_new_val_A_invoke, New: A_arbace_a2g_code_new_val_A_new, Get: A_arbace_a2g_code_new_val_A_get}

var A_arbace_a2g_code_new_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$new_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "new_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_new_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_new_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_new_val_A_InstanceOf; i.Init = A_arbace_a2g_code_new_val_A_Init; i.Table = A_arbace_a2g_code_new_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_new_val_A_class, reflect.TypeFor[A_arbace_a2g_code_new_val_A]()) }

func A_arbace_a2g_code_note_store_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_note_store_BANG__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_note_store_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_note_store_BANG__A_New()}; return nil }

func A_arbace_a2g_code_note_store_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_note_store_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_note_store_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_note_store_BANG__A_invoke, New: A_arbace_a2g_code_note_store_BANG__A_new, Get: A_arbace_a2g_code_note_store_BANG__A_get}

var A_arbace_a2g_code_note_store_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$note_store_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "note_store_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_note_store_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_note_store_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_note_store_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_note_store_BANG__A_Init; i.Table = A_arbace_a2g_code_note_store_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_note_store_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_note_store_BANG__A]()) }

func A_arbace_a2g_code_object_like_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_object_like_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_object_like_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_object_like_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_object_like_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_object_like_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_object_like_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_object_like_QMARK__A_invoke, New: A_arbace_a2g_code_object_like_QMARK__A_new, Get: A_arbace_a2g_code_object_like_QMARK__A_get}

var A_arbace_a2g_code_object_like_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$object_like_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "object_like_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_object_like_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_object_like_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_object_like_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_object_like_QMARK__A_Init; i.Table = A_arbace_a2g_code_object_like_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_object_like_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_object_like_QMARK__A]()) }

func A_arbace_a2g_code_operands_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_operands_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_A_New()}; return nil }

func A_arbace_a2g_code_operands_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_A_invoke, New: A_arbace_a2g_code_operands_A_new, Get: A_arbace_a2g_code_operands_A_get}

var A_arbace_a2g_code_operands_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "operands", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_A_Init; i.Table = A_arbace_a2g_code_operands_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_A]()) }

func A_arbace_a2g_code_operands_fn__16000110_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_fn__16000110_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_operands_fn__16000110_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_fn__16000110_A_New()}; return nil }

func A_arbace_a2g_code_operands_fn__16000110_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_fn__16000110_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_fn__16000110_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_fn__16000110_A_invoke, New: A_arbace_a2g_code_operands_fn__16000110_A_new, Get: A_arbace_a2g_code_operands_fn__16000110_A_get}

var A_arbace_a2g_code_operands_fn__16000110_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$fn__16000110", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_operands_A_class, Simple: "fn__16000110", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_fn__16000110_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_fn__16000110_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_fn__16000110_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_fn__16000110_A_Init; i.Table = A_arbace_a2g_code_operands_fn__16000110_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_fn__16000110_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_fn__16000110_A]()) }

func A_arbace_a2g_code_operands_fn__16000112_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_fn__16000112_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_operands_fn__16000112_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_fn__16000112_A_New()}; return nil }

func A_arbace_a2g_code_operands_fn__16000112_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_fn__16000112_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_fn__16000112_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_fn__16000112_A_invoke, New: A_arbace_a2g_code_operands_fn__16000112_A_new, Get: A_arbace_a2g_code_operands_fn__16000112_A_get}

var A_arbace_a2g_code_operands_fn__16000112_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$fn__16000112", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_operands_A_class, Simple: "fn__16000112", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_fn__16000112_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_fn__16000112_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_fn__16000112_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_fn__16000112_A_Init; i.Table = A_arbace_a2g_code_operands_fn__16000112_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_fn__16000112_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_fn__16000112_A]()) }

func A_arbace_a2g_code_operands_iter__16000114__16000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000114__16000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_operands_iter__16000114__16000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000114__16000118_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_operands_iter__16000114__16000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000114__16000118_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000114__16000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000114__16000118_A_invoke, New: A_arbace_a2g_code_operands_iter__16000114__16000118_A_new, Get: A_arbace_a2g_code_operands_iter__16000114__16000118_A_get}

var A_arbace_a2g_code_operands_iter__16000114__16000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000114__16000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_operands_A_class, Simple: "iter__16000114__16000118", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000114__16000118_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000114__16000118_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000114__16000118_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000114__16000118_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000114__16000118_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000114__16000118_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000114__16000118_A]()) }

func A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_invoke, New: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_new, Get: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_get}

var A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000114__16000118$fn__16000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_operands_iter__16000114__16000118_A_class, Simple: "fn__16000119", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A]()) }

func A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_invoke, New: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_new, Get: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_get}

var A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000114__16000118$fn__16000119$fn__16000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_A_class, Simple: "fn__16000120", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000114__16000118_fn__16000119_fn__16000120_A]()) }

func A_arbace_a2g_code_operands_iter__16000124__16000128_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000124__16000128_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_operands_iter__16000124__16000128_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000124__16000128_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_operands_iter__16000124__16000128_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000124__16000128_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000124__16000128_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000124__16000128_A_invoke, New: A_arbace_a2g_code_operands_iter__16000124__16000128_A_new, Get: A_arbace_a2g_code_operands_iter__16000124__16000128_A_get}

var A_arbace_a2g_code_operands_iter__16000124__16000128_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000124__16000128", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_operands_A_class, Simple: "iter__16000124__16000128", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000124__16000128_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000124__16000128_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000124__16000128_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000124__16000128_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000124__16000128_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000124__16000128_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000124__16000128_A]()) }

func A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_invoke, New: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_new, Get: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_get}

var A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000124__16000128$fn__16000129", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_operands_iter__16000124__16000128_A_class, Simple: "fn__16000129", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A]()) }

func A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_invoke, New: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_new, Get: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_get}

var A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000124__16000128$fn__16000129$fn__16000130", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_A_class, Simple: "fn__16000130", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000124__16000128_fn__16000129_fn__16000130_A]()) }

func A_arbace_a2g_code_operands_iter__16000134__16000138_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000134__16000138_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_operands_iter__16000134__16000138_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000134__16000138_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_operands_iter__16000134__16000138_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000134__16000138_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000134__16000138_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000134__16000138_A_invoke, New: A_arbace_a2g_code_operands_iter__16000134__16000138_A_new, Get: A_arbace_a2g_code_operands_iter__16000134__16000138_A_get}

var A_arbace_a2g_code_operands_iter__16000134__16000138_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000134__16000138", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_operands_A_class, Simple: "iter__16000134__16000138", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000134__16000138_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000134__16000138_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000134__16000138_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000134__16000138_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000134__16000138_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000134__16000138_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000134__16000138_A]()) }

func A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_invoke, New: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_new, Get: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_get}

var A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000134__16000138$fn__16000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_operands_iter__16000134__16000138_A_class, Simple: "fn__16000139", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A]()) }

func A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_fn_class)}; return nil }

var A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_invoke, New: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_new, Get: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_get}

var A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$operands$iter__16000134__16000138$fn__16000139$fn__16000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_A_class, Simple: "fn__16000140", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_class.Info(); i.IsInstance = A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_InstanceOf; i.Init = A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_Init; i.Table = A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_members; jrt.RegisterGoType(A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A_class, reflect.TypeFor[A_arbace_a2g_code_operands_iter__16000134__16000138_fn__16000139_fn__16000140_A]()) }

func A_arbace_a2g_code_outer_field_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_outer_field_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_outer_field_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_outer_field_A_New()}; return nil }

func A_arbace_a2g_code_outer_field_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_outer_field_A_fn_class)}; return nil }

var A_arbace_a2g_code_outer_field_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_outer_field_A_invoke, New: A_arbace_a2g_code_outer_field_A_new, Get: A_arbace_a2g_code_outer_field_A_get}

var A_arbace_a2g_code_outer_field_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$outer_field", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "outer_field", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_outer_field_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_outer_field_A_class.Info(); i.IsInstance = A_arbace_a2g_code_outer_field_A_InstanceOf; i.Init = A_arbace_a2g_code_outer_field_A_Init; i.Table = A_arbace_a2g_code_outer_field_A_members; jrt.RegisterGoType(A_arbace_a2g_code_outer_field_A_class, reflect.TypeFor[A_arbace_a2g_code_outer_field_A]()) }

func A_arbace_a2g_code_outside_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_outside_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_outside_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_outside_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_outside_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_outside_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_outside_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_outside_QMARK__A_invoke, New: A_arbace_a2g_code_outside_QMARK__A_new, Get: A_arbace_a2g_code_outside_QMARK__A_get}

var A_arbace_a2g_code_outside_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$outside_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "outside_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_outside_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_outside_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_outside_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_outside_QMARK__A_Init; i.Table = A_arbace_a2g_code_outside_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_outside_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_outside_QMARK__A]()) }

func A_arbace_a2g_code_pattern_bindings_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_pattern_bindings_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_pattern_bindings_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_pattern_bindings_A_New()}; return nil }

func A_arbace_a2g_code_pattern_bindings_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_pattern_bindings_A_fn_class)}; return nil }

var A_arbace_a2g_code_pattern_bindings_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_pattern_bindings_A_invoke, New: A_arbace_a2g_code_pattern_bindings_A_new, Get: A_arbace_a2g_code_pattern_bindings_A_get}

var A_arbace_a2g_code_pattern_bindings_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$pattern_bindings", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "pattern_bindings", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_pattern_bindings_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_pattern_bindings_A_class.Info(); i.IsInstance = A_arbace_a2g_code_pattern_bindings_A_InstanceOf; i.Init = A_arbace_a2g_code_pattern_bindings_A_Init; i.Table = A_arbace_a2g_code_pattern_bindings_A_members; jrt.RegisterGoType(A_arbace_a2g_code_pattern_bindings_A_class, reflect.TypeFor[A_arbace_a2g_code_pattern_bindings_A]()) }

func A_arbace_a2g_code_pattern_bindings_fn__16000500_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_pattern_bindings_fn__16000500_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_pattern_bindings_fn__16000500_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_pattern_bindings_fn__16000500_A_New()}; return nil }

func A_arbace_a2g_code_pattern_bindings_fn__16000500_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_pattern_bindings_fn__16000500_A_fn_class)}; return nil }

var A_arbace_a2g_code_pattern_bindings_fn__16000500_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_pattern_bindings_fn__16000500_A_invoke, New: A_arbace_a2g_code_pattern_bindings_fn__16000500_A_new, Get: A_arbace_a2g_code_pattern_bindings_fn__16000500_A_get}

var A_arbace_a2g_code_pattern_bindings_fn__16000500_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$pattern_bindings$fn__16000500", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_pattern_bindings_A_class, Simple: "fn__16000500", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_pattern_bindings_fn__16000500_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_pattern_bindings_fn__16000500_A_class.Info(); i.IsInstance = A_arbace_a2g_code_pattern_bindings_fn__16000500_A_InstanceOf; i.Init = A_arbace_a2g_code_pattern_bindings_fn__16000500_A_Init; i.Table = A_arbace_a2g_code_pattern_bindings_fn__16000500_A_members; jrt.RegisterGoType(A_arbace_a2g_code_pattern_bindings_fn__16000500_A_class, reflect.TypeFor[A_arbace_a2g_code_pattern_bindings_fn__16000500_A]()) }

func A_arbace_a2g_code_pkg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_pkg_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_pkg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_pkg_A_New()}; return nil }

func A_arbace_a2g_code_pkg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_pkg_A_fn_class)}; return nil }

var A_arbace_a2g_code_pkg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_pkg_A_invoke, New: A_arbace_a2g_code_pkg_A_new, Get: A_arbace_a2g_code_pkg_A_get}

var A_arbace_a2g_code_pkg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$pkg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "pkg", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_pkg_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_pkg_A_class.Info(); i.IsInstance = A_arbace_a2g_code_pkg_A_InstanceOf; i.Init = A_arbace_a2g_code_pkg_A_Init; i.Table = A_arbace_a2g_code_pkg_A_members; jrt.RegisterGoType(A_arbace_a2g_code_pkg_A_class, reflect.TypeFor[A_arbace_a2g_code_pkg_A]()) }

func A_arbace_a2g_code_prim_convert_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_prim_convert_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_prim_convert_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_prim_convert_A_New()}; return nil }

func A_arbace_a2g_code_prim_convert_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_prim_convert_A_fn_class)}; return nil }

var A_arbace_a2g_code_prim_convert_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_prim_convert_A_invoke, New: A_arbace_a2g_code_prim_convert_A_new, Get: A_arbace_a2g_code_prim_convert_A_get}

var A_arbace_a2g_code_prim_convert_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$prim_convert", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "prim_convert", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_prim_convert_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_prim_convert_A_class.Info(); i.IsInstance = A_arbace_a2g_code_prim_convert_A_InstanceOf; i.Init = A_arbace_a2g_code_prim_convert_A_Init; i.Table = A_arbace_a2g_code_prim_convert_A_members; jrt.RegisterGoType(A_arbace_a2g_code_prim_convert_A_class, reflect.TypeFor[A_arbace_a2g_code_prim_convert_A]()) }

func A_arbace_a2g_code_reads_state_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_reads_state_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_reads_state_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_reads_state_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_reads_state_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_reads_state_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_reads_state_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_reads_state_QMARK__A_invoke, New: A_arbace_a2g_code_reads_state_QMARK__A_new, Get: A_arbace_a2g_code_reads_state_QMARK__A_get}

var A_arbace_a2g_code_reads_state_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$reads_state_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "reads_state_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_reads_state_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_reads_state_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_reads_state_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_reads_state_QMARK__A_Init; i.Table = A_arbace_a2g_code_reads_state_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_reads_state_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_reads_state_QMARK__A]()) }

func A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_reads_state_QMARK__w__16000097_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_fn_class)}; return nil }

var A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_invoke, New: A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_new, Get: A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_get}

var A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$reads_state_QMARK_$w__16000097", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_reads_state_QMARK__A_class, Simple: "w__16000097", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_reads_state_QMARK__w__16000097_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_class.Info(); i.IsInstance = A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_InstanceOf; i.Init = A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_Init; i.Table = A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_members; jrt.RegisterGoType(A_arbace_a2g_code_reads_state_QMARK__w__16000097_A_class, reflect.TypeFor[A_arbace_a2g_code_reads_state_QMARK__w__16000097_A]()) }

func A_arbace_a2g_code_record_pattern_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_record_pattern_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_record_pattern_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_record_pattern_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_record_pattern_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_record_pattern_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_record_pattern_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_record_pattern_QMARK__A_invoke, New: A_arbace_a2g_code_record_pattern_QMARK__A_new, Get: A_arbace_a2g_code_record_pattern_QMARK__A_get}

var A_arbace_a2g_code_record_pattern_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$record_pattern_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "record_pattern_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_record_pattern_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_record_pattern_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_record_pattern_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_record_pattern_QMARK__A_Init; i.Table = A_arbace_a2g_code_record_pattern_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_record_pattern_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_record_pattern_QMARK__A]()) }

func A_arbace_a2g_code_ret_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_ret_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_ret_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_ret_BANG__A_New()}; return nil }

func A_arbace_a2g_code_ret_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_ret_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_ret_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_ret_BANG__A_invoke, New: A_arbace_a2g_code_ret_BANG__A_new, Get: A_arbace_a2g_code_ret_BANG__A_get}

var A_arbace_a2g_code_ret_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$ret_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "ret_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_ret_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_ret_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_ret_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_ret_BANG__A_Init; i.Table = A_arbace_a2g_code_ret_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_ret_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_ret_BANG__A]()) }

func A_arbace_a2g_code_sam_sig_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_sam_sig_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_sam_sig_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_sam_sig_A_New()}; return nil }

func A_arbace_a2g_code_sam_sig_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_sam_sig_A_fn_class)}; return nil }

var A_arbace_a2g_code_sam_sig_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_sam_sig_A_invoke, New: A_arbace_a2g_code_sam_sig_A_new, Get: A_arbace_a2g_code_sam_sig_A_get}

var A_arbace_a2g_code_sam_sig_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$sam_sig", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "sam_sig", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_sam_sig_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_sam_sig_A_class.Info(); i.IsInstance = A_arbace_a2g_code_sam_sig_A_InstanceOf; i.Init = A_arbace_a2g_code_sam_sig_A_Init; i.Table = A_arbace_a2g_code_sam_sig_A_members; jrt.RegisterGoType(A_arbace_a2g_code_sam_sig_A_class, reflect.TypeFor[A_arbace_a2g_code_sam_sig_A]()) }

func A_arbace_a2g_code_set_field_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_set_field_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_set_field_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_set_field_BANG__A_New()}; return nil }

func A_arbace_a2g_code_set_field_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_set_field_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_set_field_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_set_field_BANG__A_invoke, New: A_arbace_a2g_code_set_field_BANG__A_new, Get: A_arbace_a2g_code_set_field_BANG__A_get}

var A_arbace_a2g_code_set_field_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$set_field_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "set_field_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_set_field_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_set_field_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_set_field_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_set_field_BANG__A_Init; i.Table = A_arbace_a2g_code_set_field_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_set_field_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_set_field_BANG__A]()) }

func A_arbace_a2g_code_set_static_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_set_static_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_set_static_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_set_static_BANG__A_New()}; return nil }

func A_arbace_a2g_code_set_static_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_set_static_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_set_static_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_set_static_BANG__A_invoke, New: A_arbace_a2g_code_set_static_BANG__A_new, Get: A_arbace_a2g_code_set_static_BANG__A_get}

var A_arbace_a2g_code_set_static_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$set_static_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "set_static_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_set_static_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_set_static_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_set_static_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_set_static_BANG__A_Init; i.Table = A_arbace_a2g_code_set_static_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_set_static_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_set_static_BANG__A]()) }

func A_arbace_a2g_code_simple_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_simple_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_simple_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_simple_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_simple_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_simple_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_simple_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_simple_QMARK__A_invoke, New: A_arbace_a2g_code_simple_QMARK__A_new, Get: A_arbace_a2g_code_simple_QMARK__A_get}

var A_arbace_a2g_code_simple_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$simple_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "simple_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_simple_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_simple_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_simple_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_simple_QMARK__A_Init; i.Table = A_arbace_a2g_code_simple_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_simple_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_simple_QMARK__A]()) }

func A_arbace_a2g_code_simple_QMARK__fn__16000087_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_simple_QMARK__fn__16000087_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_simple_QMARK__fn__16000087_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_simple_QMARK__fn__16000087_A_New()}; return nil }

func A_arbace_a2g_code_simple_QMARK__fn__16000087_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_simple_QMARK__fn__16000087_A_fn_class)}; return nil }

var A_arbace_a2g_code_simple_QMARK__fn__16000087_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_simple_QMARK__fn__16000087_A_invoke, New: A_arbace_a2g_code_simple_QMARK__fn__16000087_A_new, Get: A_arbace_a2g_code_simple_QMARK__fn__16000087_A_get}

var A_arbace_a2g_code_simple_QMARK__fn__16000087_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$simple_QMARK_$fn__16000087", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_simple_QMARK__A_class, Simple: "fn__16000087", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_simple_QMARK__fn__16000087_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_simple_QMARK__fn__16000087_A_class.Info(); i.IsInstance = A_arbace_a2g_code_simple_QMARK__fn__16000087_A_InstanceOf; i.Init = A_arbace_a2g_code_simple_QMARK__fn__16000087_A_Init; i.Table = A_arbace_a2g_code_simple_QMARK__fn__16000087_A_members; jrt.RegisterGoType(A_arbace_a2g_code_simple_QMARK__fn__16000087_A_class, reflect.TypeFor[A_arbace_a2g_code_simple_QMARK__fn__16000087_A]()) }

func A_arbace_a2g_code_stable_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_stable_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_stable_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_stable_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_stable_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_stable_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_stable_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_stable_QMARK__A_invoke, New: A_arbace_a2g_code_stable_QMARK__A_new, Get: A_arbace_a2g_code_stable_QMARK__A_get}

var A_arbace_a2g_code_stable_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$stable_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "stable_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_stable_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_stable_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_stable_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_stable_QMARK__A_Init; i.Table = A_arbace_a2g_code_stable_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_stable_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_stable_QMARK__A]()) }

func A_arbace_a2g_code_static_place_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_static_place_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_static_place_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_static_place_A_New()}; return nil }

func A_arbace_a2g_code_static_place_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_static_place_A_fn_class)}; return nil }

var A_arbace_a2g_code_static_place_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_static_place_A_invoke, New: A_arbace_a2g_code_static_place_A_new, Get: A_arbace_a2g_code_static_place_A_get}

var A_arbace_a2g_code_static_place_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$static_place", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "static_place", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_static_place_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_static_place_A_class.Info(); i.IsInstance = A_arbace_a2g_code_static_place_A_InstanceOf; i.Init = A_arbace_a2g_code_static_place_A_Init; i.Table = A_arbace_a2g_code_static_place_A_members; jrt.RegisterGoType(A_arbace_a2g_code_static_place_A_class, reflect.TypeFor[A_arbace_a2g_code_static_place_A]()) }

func A_arbace_a2g_code_stmt_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_stmt_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_stmt_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_stmt_BANG__A_New()}; return nil }

func A_arbace_a2g_code_stmt_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_stmt_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_stmt_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_stmt_BANG__A_invoke, New: A_arbace_a2g_code_stmt_BANG__A_new, Get: A_arbace_a2g_code_stmt_BANG__A_get}

var A_arbace_a2g_code_stmt_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$stmt_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "stmt_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_stmt_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_stmt_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_stmt_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_stmt_BANG__A_Init; i.Table = A_arbace_a2g_code_stmt_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_stmt_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_stmt_BANG__A]()) }

func A_arbace_a2g_code_stmt_BANG__STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_stmt_BANG__STAR__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_stmt_BANG__STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_stmt_BANG__STAR__A_New()}; return nil }

func A_arbace_a2g_code_stmt_BANG__STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_stmt_BANG__STAR__A_fn_class)}; return nil }

var A_arbace_a2g_code_stmt_BANG__STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_stmt_BANG__STAR__A_invoke, New: A_arbace_a2g_code_stmt_BANG__STAR__A_new, Get: A_arbace_a2g_code_stmt_BANG__STAR__A_get}

var A_arbace_a2g_code_stmt_BANG__STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$stmt_BANG__STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "stmt_BANG__STAR_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_stmt_BANG__STAR__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_stmt_BANG__STAR__A_class.Info(); i.IsInstance = A_arbace_a2g_code_stmt_BANG__STAR__A_InstanceOf; i.Init = A_arbace_a2g_code_stmt_BANG__STAR__A_Init; i.Table = A_arbace_a2g_code_stmt_BANG__STAR__A_members; jrt.RegisterGoType(A_arbace_a2g_code_stmt_BANG__STAR__A_class, reflect.TypeFor[A_arbace_a2g_code_stmt_BANG__STAR__A]()) }

func A_arbace_a2g_code_string_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_string_lit_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_string_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_string_lit_A_New()}; return nil }

func A_arbace_a2g_code_string_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_string_lit_A_fn_class)}; return nil }

var A_arbace_a2g_code_string_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_string_lit_A_invoke, New: A_arbace_a2g_code_string_lit_A_new, Get: A_arbace_a2g_code_string_lit_A_get}

var A_arbace_a2g_code_string_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$string_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "string_lit", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_string_lit_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_string_lit_A_class.Info(); i.IsInstance = A_arbace_a2g_code_string_lit_A_InstanceOf; i.Init = A_arbace_a2g_code_string_lit_A_Init; i.Table = A_arbace_a2g_code_string_lit_A_members; jrt.RegisterGoType(A_arbace_a2g_code_string_lit_A_class, reflect.TypeFor[A_arbace_a2g_code_string_lit_A]()) }

func A_arbace_a2g_code_struct_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_struct_of_A).DoInvoke_O_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4], args[5])}; return nil }

func A_arbace_a2g_code_struct_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_struct_of_A_New()}; return nil }

func A_arbace_a2g_code_struct_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_struct_of_A_fn_class)}; return nil }

var A_arbace_a2g_code_struct_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_struct_of_A_invoke, New: A_arbace_a2g_code_struct_of_A_new, Get: A_arbace_a2g_code_struct_of_A_get}

var A_arbace_a2g_code_struct_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$struct_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR4_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "struct_of", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_struct_of_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_struct_of_A_class.Info(); i.IsInstance = A_arbace_a2g_code_struct_of_A_InstanceOf; i.Init = A_arbace_a2g_code_struct_of_A_Init; i.Table = A_arbace_a2g_code_struct_of_A_members; jrt.RegisterGoType(A_arbace_a2g_code_struct_of_A_class, reflect.TypeFor[A_arbace_a2g_code_struct_of_A]()) }

func A_arbace_a2g_code_struct_of_fn__16000184_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_struct_of_fn__16000184_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_struct_of_fn__16000184_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_struct_of_fn__16000184_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_struct_of_fn__16000184_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_struct_of_fn__16000184_A_fn_class)}; return nil }

var A_arbace_a2g_code_struct_of_fn__16000184_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_struct_of_fn__16000184_A_invoke, New: A_arbace_a2g_code_struct_of_fn__16000184_A_new, Get: A_arbace_a2g_code_struct_of_fn__16000184_A_get}

var A_arbace_a2g_code_struct_of_fn__16000184_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$struct_of$fn__16000184", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_struct_of_A_class, Simple: "fn__16000184", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_struct_of_fn__16000184_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_struct_of_fn__16000184_A_class.Info(); i.IsInstance = A_arbace_a2g_code_struct_of_fn__16000184_A_InstanceOf; i.Init = A_arbace_a2g_code_struct_of_fn__16000184_A_Init; i.Table = A_arbace_a2g_code_struct_of_fn__16000184_A_members; jrt.RegisterGoType(A_arbace_a2g_code_struct_of_fn__16000184_A_class, reflect.TypeFor[A_arbace_a2g_code_struct_of_fn__16000184_A]()) }

func A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_fn_class)}; return nil }

var A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_invoke, New: A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_new, Get: A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_get}

var A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$struct_of$fn__16000184$fn__16000185", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_struct_of_fn__16000184_A_class, Simple: "fn__16000185", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_class.Info(); i.IsInstance = A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_InstanceOf; i.Init = A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_Init; i.Table = A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_members; jrt.RegisterGoType(A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A_class, reflect.TypeFor[A_arbace_a2g_code_struct_of_fn__16000184_fn__16000185_A]()) }

func A_arbace_a2g_code_struct_of_fn__16000188_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_struct_of_fn__16000188_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_struct_of_fn__16000188_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_struct_of_fn__16000188_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_struct_of_fn__16000188_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_struct_of_fn__16000188_A_fn_class)}; return nil }

var A_arbace_a2g_code_struct_of_fn__16000188_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_struct_of_fn__16000188_A_invoke, New: A_arbace_a2g_code_struct_of_fn__16000188_A_new, Get: A_arbace_a2g_code_struct_of_fn__16000188_A_get}

var A_arbace_a2g_code_struct_of_fn__16000188_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$struct_of$fn__16000188", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_struct_of_A_class, Simple: "fn__16000188", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_struct_of_fn__16000188_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_struct_of_fn__16000188_A_class.Info(); i.IsInstance = A_arbace_a2g_code_struct_of_fn__16000188_A_InstanceOf; i.Init = A_arbace_a2g_code_struct_of_fn__16000188_A_Init; i.Table = A_arbace_a2g_code_struct_of_fn__16000188_A_members; jrt.RegisterGoType(A_arbace_a2g_code_struct_of_fn__16000188_A_class, reflect.TypeFor[A_arbace_a2g_code_struct_of_fn__16000188_A]()) }

func A_arbace_a2g_code_super_struct_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_super_struct_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_super_struct_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_super_struct_A_New()}; return nil }

func A_arbace_a2g_code_super_struct_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_super_struct_A_fn_class)}; return nil }

var A_arbace_a2g_code_super_struct_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_super_struct_A_invoke, New: A_arbace_a2g_code_super_struct_A_new, Get: A_arbace_a2g_code_super_struct_A_get}

var A_arbace_a2g_code_super_struct_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$super_struct", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "super_struct", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_super_struct_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_super_struct_A_class.Info(); i.IsInstance = A_arbace_a2g_code_super_struct_A_InstanceOf; i.Init = A_arbace_a2g_code_super_struct_A_Init; i.Table = A_arbace_a2g_code_super_struct_A_members; jrt.RegisterGoType(A_arbace_a2g_code_super_struct_A_class, reflect.TypeFor[A_arbace_a2g_code_super_struct_A]()) }

func A_arbace_a2g_code_tag_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_tag_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_tag_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_tag_A_New()}; return nil }

func A_arbace_a2g_code_tag_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_tag_A_fn_class)}; return nil }

var A_arbace_a2g_code_tag_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_tag_A_invoke, New: A_arbace_a2g_code_tag_A_new, Get: A_arbace_a2g_code_tag_A_get}

var A_arbace_a2g_code_tag_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$tag", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "tag", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_tag_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_tag_A_class.Info(); i.IsInstance = A_arbace_a2g_code_tag_A_InstanceOf; i.Init = A_arbace_a2g_code_tag_A_Init; i.Table = A_arbace_a2g_code_tag_A_members; jrt.RegisterGoType(A_arbace_a2g_code_tag_A_class, reflect.TypeFor[A_arbace_a2g_code_tag_A]()) }

func A_arbace_a2g_code_target_info_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_target_info_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_target_info_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_target_info_A_New()}; return nil }

func A_arbace_a2g_code_target_info_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_target_info_A_fn_class)}; return nil }

var A_arbace_a2g_code_target_info_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_target_info_A_invoke, New: A_arbace_a2g_code_target_info_A_new, Get: A_arbace_a2g_code_target_info_A_get}

var A_arbace_a2g_code_target_info_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$target_info", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "target_info", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_target_info_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_target_info_A_class.Info(); i.IsInstance = A_arbace_a2g_code_target_info_A_InstanceOf; i.Init = A_arbace_a2g_code_target_info_A_Init; i.Table = A_arbace_a2g_code_target_info_A_members; jrt.RegisterGoType(A_arbace_a2g_code_target_info_A_class, reflect.TypeFor[A_arbace_a2g_code_target_info_A]()) }

func A_arbace_a2g_code_target_operands_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_target_operands_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_target_operands_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_target_operands_A_New()}; return nil }

func A_arbace_a2g_code_target_operands_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_target_operands_A_fn_class)}; return nil }

var A_arbace_a2g_code_target_operands_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_target_operands_A_invoke, New: A_arbace_a2g_code_target_operands_A_new, Get: A_arbace_a2g_code_target_operands_A_get}

var A_arbace_a2g_code_target_operands_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$target_operands", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "target_operands", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_target_operands_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_target_operands_A_class.Info(); i.IsInstance = A_arbace_a2g_code_target_operands_A_InstanceOf; i.Init = A_arbace_a2g_code_target_operands_A_Init; i.Table = A_arbace_a2g_code_target_operands_A_members; jrt.RegisterGoType(A_arbace_a2g_code_target_operands_A_class, reflect.TypeFor[A_arbace_a2g_code_target_operands_A]()) }

func A_arbace_a2g_code_this_path_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_this_path_val_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_this_path_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_this_path_val_A_New()}; return nil }

func A_arbace_a2g_code_this_path_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_this_path_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_this_path_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_this_path_val_A_invoke, New: A_arbace_a2g_code_this_path_val_A_new, Get: A_arbace_a2g_code_this_path_val_A_get}

var A_arbace_a2g_code_this_path_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$this_path_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "this_path_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_this_path_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_this_path_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_this_path_val_A_InstanceOf; i.Init = A_arbace_a2g_code_this_path_val_A_Init; i.Table = A_arbace_a2g_code_this_path_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_this_path_val_A_class, reflect.TypeFor[A_arbace_a2g_code_this_path_val_A]()) }

func A_arbace_a2g_code_this_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_this_val_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_this_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_this_val_A_New()}; return nil }

func A_arbace_a2g_code_this_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_this_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_this_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_this_val_A_invoke, New: A_arbace_a2g_code_this_val_A_new, Get: A_arbace_a2g_code_this_val_A_get}

var A_arbace_a2g_code_this_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$this_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "this_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_this_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_this_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_this_val_A_InstanceOf; i.Init = A_arbace_a2g_code_this_val_A_Init; i.Table = A_arbace_a2g_code_this_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_this_val_A_class, reflect.TypeFor[A_arbace_a2g_code_this_val_A]()) }

func A_arbace_a2g_code_tmp_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_tmp_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_tmp_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_tmp_A_New()}; return nil }

func A_arbace_a2g_code_tmp_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_tmp_A_fn_class)}; return nil }

var A_arbace_a2g_code_tmp_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_tmp_A_invoke, New: A_arbace_a2g_code_tmp_A_new, Get: A_arbace_a2g_code_tmp_A_get}

var A_arbace_a2g_code_tmp_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$tmp", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "tmp", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_tmp_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_tmp_A_class.Info(); i.IsInstance = A_arbace_a2g_code_tmp_A_InstanceOf; i.Init = A_arbace_a2g_code_tmp_A_Init; i.Table = A_arbace_a2g_code_tmp_A_members; jrt.RegisterGoType(A_arbace_a2g_code_tmp_A_class, reflect.TypeFor[A_arbace_a2g_code_tmp_A]()) }

func A_arbace_a2g_code_translate_and_or_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_and_or_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_and_or_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_and_or_A_New()}; return nil }

func A_arbace_a2g_code_translate_and_or_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_and_or_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_and_or_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_and_or_A_invoke, New: A_arbace_a2g_code_translate_and_or_A_new, Get: A_arbace_a2g_code_translate_and_or_A_get}

var A_arbace_a2g_code_translate_and_or_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_and_or", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_and_or", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_and_or_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_and_or_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_and_or_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_and_or_A_Init; i.Table = A_arbace_a2g_code_translate_and_or_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_and_or_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_and_or_A]()) }

func A_arbace_a2g_code_translate_and_or_go__16000452_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_and_or_go__16000452_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_and_or_go__16000452_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_and_or_go__16000452_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_and_or_go__16000452_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_and_or_go__16000452_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_and_or_go__16000452_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_and_or_go__16000452_A_invoke, New: A_arbace_a2g_code_translate_and_or_go__16000452_A_new, Get: A_arbace_a2g_code_translate_and_or_go__16000452_A_get}

var A_arbace_a2g_code_translate_and_or_go__16000452_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_and_or$go__16000452", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_and_or_A_class, Simple: "go__16000452", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_and_or_go__16000452_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_and_or_go__16000452_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_and_or_go__16000452_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_and_or_go__16000452_A_Init; i.Table = A_arbace_a2g_code_translate_and_or_go__16000452_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_and_or_go__16000452_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_and_or_go__16000452_A]()) }

func A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_invoke, New: A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_new, Get: A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_get}

var A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_and_or$go__16000452$fn__16000456", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_and_or_go__16000452_A_class, Simple: "fn__16000456", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_Init; i.Table = A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_and_or_go__16000452_fn__16000456_A]()) }

func A_arbace_a2g_code_translate_ctx_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_ctx_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_ctx_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_ctx_A_New()}; return nil }

func A_arbace_a2g_code_translate_ctx_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_ctx_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_ctx_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_ctx_A_invoke, New: A_arbace_a2g_code_translate_ctx_A_new, Get: A_arbace_a2g_code_translate_ctx_A_get}

var A_arbace_a2g_code_translate_ctx_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_ctx", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_ctx", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_ctx_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_ctx_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_ctx_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_ctx_A_Init; i.Table = A_arbace_a2g_code_translate_ctx_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_ctx_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_ctx_A]()) }

func A_arbace_a2g_code_translate_ctx_STAR__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_ctx_STAR__A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_ctx_STAR__A_New()}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_ctx_STAR__A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_ctx_STAR__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_ctx_STAR__A_invoke, New: A_arbace_a2g_code_translate_ctx_STAR__A_new, Get: A_arbace_a2g_code_translate_ctx_STAR__A_get}

var A_arbace_a2g_code_translate_ctx_STAR__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_ctx_STAR_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_ctx_STAR_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_ctx_STAR__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_ctx_STAR__A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_ctx_STAR__A_InstanceOf; i.Init = A_arbace_a2g_code_translate_ctx_STAR__A_Init; i.Table = A_arbace_a2g_code_translate_ctx_STAR__A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_ctx_STAR__A_class, reflect.TypeFor[A_arbace_a2g_code_translate_ctx_STAR__A]()) }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_invoke, New: A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_new, Get: A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_get}

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_ctx_STAR_$fn__16000434", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_ctx_STAR__A_class, Simple: "fn__16000434", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_Init; i.Table = A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_ctx_STAR__fn__16000434_A]()) }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_invoke, New: A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_new, Get: A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_get}

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_ctx_STAR_$fn__16000436", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_ctx_STAR__A_class, Simple: "fn__16000436", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_Init; i.Table = A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_ctx_STAR__fn__16000436_A]()) }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_invoke, New: A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_new, Get: A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_get}

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_ctx_STAR_$fn__16000440", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_ctx_STAR__A_class, Simple: "fn__16000440", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_Init; i.Table = A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_ctx_STAR__fn__16000440_A]()) }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_invoke, New: A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_new, Get: A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_get}

var A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_ctx_STAR_$fn__16000442", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_ctx_STAR__A_class, Simple: "fn__16000442", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_Init; i.Table = A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_ctx_STAR__fn__16000442_A]()) }

func A_arbace_a2g_code_translate_for_each_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_for_each_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_for_each_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_for_each_A_New()}; return nil }

func A_arbace_a2g_code_translate_for_each_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_for_each_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_for_each_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_for_each_A_invoke, New: A_arbace_a2g_code_translate_for_each_A_new, Get: A_arbace_a2g_code_translate_for_each_A_get}

var A_arbace_a2g_code_translate_for_each_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_for_each", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_for_each", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_for_each_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_for_each_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_for_each_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_for_each_A_Init; i.Table = A_arbace_a2g_code_translate_for_each_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_for_each_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_for_each_A]()) }

func A_arbace_a2g_code_translate_for_each_fn__16000487_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_for_each_fn__16000487_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000487_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_for_each_fn__16000487_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000487_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_for_each_fn__16000487_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_for_each_fn__16000487_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_for_each_fn__16000487_A_invoke, New: A_arbace_a2g_code_translate_for_each_fn__16000487_A_new, Get: A_arbace_a2g_code_translate_for_each_fn__16000487_A_get}

var A_arbace_a2g_code_translate_for_each_fn__16000487_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_for_each$fn__16000487", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_for_each_A_class, Simple: "fn__16000487", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_for_each_fn__16000487_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_for_each_fn__16000487_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_for_each_fn__16000487_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_for_each_fn__16000487_A_Init; i.Table = A_arbace_a2g_code_translate_for_each_fn__16000487_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_for_each_fn__16000487_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_for_each_fn__16000487_A]()) }

func A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_invoke, New: A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_new, Get: A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_get}

var A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_for_each$fn__16000487$fn__16000488", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_for_each_fn__16000487_A_class, Simple: "fn__16000488", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_Init; i.Table = A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_for_each_fn__16000487_fn__16000488_A]()) }

func A_arbace_a2g_code_translate_for_each_fn__16000491_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_for_each_fn__16000491_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000491_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_for_each_fn__16000491_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000491_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_for_each_fn__16000491_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_for_each_fn__16000491_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_for_each_fn__16000491_A_invoke, New: A_arbace_a2g_code_translate_for_each_fn__16000491_A_new, Get: A_arbace_a2g_code_translate_for_each_fn__16000491_A_get}

var A_arbace_a2g_code_translate_for_each_fn__16000491_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_for_each$fn__16000491", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_for_each_A_class, Simple: "fn__16000491", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_for_each_fn__16000491_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_for_each_fn__16000491_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_for_each_fn__16000491_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_for_each_fn__16000491_A_Init; i.Table = A_arbace_a2g_code_translate_for_each_fn__16000491_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_for_each_fn__16000491_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_for_each_fn__16000491_A]()) }

func A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_invoke, New: A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_new, Get: A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_get}

var A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_for_each$fn__16000491$fn__16000492", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_for_each_fn__16000491_A_class, Simple: "fn__16000492", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_Init; i.Table = A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_for_each_fn__16000491_fn__16000492_A]()) }

func A_arbace_a2g_code_translate_for_each_fn__16000495_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_for_each_fn__16000495_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000495_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_for_each_fn__16000495_A_New()}; return nil }

func A_arbace_a2g_code_translate_for_each_fn__16000495_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_for_each_fn__16000495_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_for_each_fn__16000495_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_for_each_fn__16000495_A_invoke, New: A_arbace_a2g_code_translate_for_each_fn__16000495_A_new, Get: A_arbace_a2g_code_translate_for_each_fn__16000495_A_get}

var A_arbace_a2g_code_translate_for_each_fn__16000495_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_for_each$fn__16000495", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_for_each_A_class, Simple: "fn__16000495", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_for_each_fn__16000495_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_for_each_fn__16000495_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_for_each_fn__16000495_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_for_each_fn__16000495_A_Init; i.Table = A_arbace_a2g_code_translate_for_each_fn__16000495_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_for_each_fn__16000495_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_for_each_fn__16000495_A]()) }

func A_arbace_a2g_code_translate_if_instance_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_if_instance_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_if_instance_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_if_instance_A_New()}; return nil }

func A_arbace_a2g_code_translate_if_instance_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_if_instance_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_if_instance_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_if_instance_A_invoke, New: A_arbace_a2g_code_translate_if_instance_A_new, Get: A_arbace_a2g_code_translate_if_instance_A_get}

var A_arbace_a2g_code_translate_if_instance_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_if_instance", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_if_instance", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_if_instance_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_if_instance_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_if_instance_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_if_instance_A_Init; i.Table = A_arbace_a2g_code_translate_if_instance_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_if_instance_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_if_instance_A]()) }

func A_arbace_a2g_code_translate_if_instance_fn__16000529_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_if_instance_fn__16000529_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000529_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_if_instance_fn__16000529_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000529_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_if_instance_fn__16000529_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_if_instance_fn__16000529_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_if_instance_fn__16000529_A_invoke, New: A_arbace_a2g_code_translate_if_instance_fn__16000529_A_new, Get: A_arbace_a2g_code_translate_if_instance_fn__16000529_A_get}

var A_arbace_a2g_code_translate_if_instance_fn__16000529_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_if_instance$fn__16000529", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_if_instance_A_class, Simple: "fn__16000529", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_if_instance_fn__16000529_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_if_instance_fn__16000529_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_if_instance_fn__16000529_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_if_instance_fn__16000529_A_Init; i.Table = A_arbace_a2g_code_translate_if_instance_fn__16000529_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_if_instance_fn__16000529_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_if_instance_fn__16000529_A]()) }

func A_arbace_a2g_code_translate_if_instance_fn__16000531_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_if_instance_fn__16000531_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000531_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_if_instance_fn__16000531_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000531_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_if_instance_fn__16000531_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_if_instance_fn__16000531_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_if_instance_fn__16000531_A_invoke, New: A_arbace_a2g_code_translate_if_instance_fn__16000531_A_new, Get: A_arbace_a2g_code_translate_if_instance_fn__16000531_A_get}

var A_arbace_a2g_code_translate_if_instance_fn__16000531_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_if_instance$fn__16000531", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_if_instance_A_class, Simple: "fn__16000531", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_if_instance_fn__16000531_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_if_instance_fn__16000531_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_if_instance_fn__16000531_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_if_instance_fn__16000531_A_Init; i.Table = A_arbace_a2g_code_translate_if_instance_fn__16000531_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_if_instance_fn__16000531_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_if_instance_fn__16000531_A]()) }

func A_arbace_a2g_code_translate_if_instance_fn__16000533_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_if_instance_fn__16000533_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000533_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_if_instance_fn__16000533_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000533_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_if_instance_fn__16000533_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_if_instance_fn__16000533_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_if_instance_fn__16000533_A_invoke, New: A_arbace_a2g_code_translate_if_instance_fn__16000533_A_new, Get: A_arbace_a2g_code_translate_if_instance_fn__16000533_A_get}

var A_arbace_a2g_code_translate_if_instance_fn__16000533_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_if_instance$fn__16000533", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_if_instance_A_class, Simple: "fn__16000533", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_if_instance_fn__16000533_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_if_instance_fn__16000533_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_if_instance_fn__16000533_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_if_instance_fn__16000533_A_Init; i.Table = A_arbace_a2g_code_translate_if_instance_fn__16000533_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_if_instance_fn__16000533_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_if_instance_fn__16000533_A]()) }

func A_arbace_a2g_code_translate_if_instance_fn__16000535_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_if_instance_fn__16000535_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000535_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_if_instance_fn__16000535_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_if_instance_fn__16000535_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_if_instance_fn__16000535_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_if_instance_fn__16000535_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_if_instance_fn__16000535_A_invoke, New: A_arbace_a2g_code_translate_if_instance_fn__16000535_A_new, Get: A_arbace_a2g_code_translate_if_instance_fn__16000535_A_get}

var A_arbace_a2g_code_translate_if_instance_fn__16000535_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_if_instance$fn__16000535", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_if_instance_A_class, Simple: "fn__16000535", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_if_instance_fn__16000535_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_if_instance_fn__16000535_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_if_instance_fn__16000535_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_if_instance_fn__16000535_A_Init; i.Table = A_arbace_a2g_code_translate_if_instance_fn__16000535_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_if_instance_fn__16000535_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_if_instance_fn__16000535_A]()) }

func A_arbace_a2g_code_translate_label_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_label_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_label_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_label_A_New()}; return nil }

func A_arbace_a2g_code_translate_label_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_label_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_label_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_label_A_invoke, New: A_arbace_a2g_code_translate_label_A_new, Get: A_arbace_a2g_code_translate_label_A_get}

var A_arbace_a2g_code_translate_label_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_label", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_label", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_label_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_label_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_label_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_label_A_Init; i.Table = A_arbace_a2g_code_translate_label_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_label_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_label_A]()) }

func A_arbace_a2g_code_translate_label_fn__16000482_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_label_fn__16000482_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_label_fn__16000482_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_label_fn__16000482_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_label_fn__16000482_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_label_fn__16000482_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_label_fn__16000482_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_label_fn__16000482_A_invoke, New: A_arbace_a2g_code_translate_label_fn__16000482_A_new, Get: A_arbace_a2g_code_translate_label_fn__16000482_A_get}

var A_arbace_a2g_code_translate_label_fn__16000482_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_label$fn__16000482", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_label_A_class, Simple: "fn__16000482", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_label_fn__16000482_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_label_fn__16000482_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_label_fn__16000482_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_label_fn__16000482_A_Init; i.Table = A_arbace_a2g_code_translate_label_fn__16000482_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_label_fn__16000482_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_label_fn__16000482_A]()) }

func A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_invoke, New: A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_new, Get: A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_get}

var A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_label$fn__16000482$fn__16000483", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_label_fn__16000482_A_class, Simple: "fn__16000483", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_Init; i.Table = A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_label_fn__16000482_fn__16000483_A]()) }

func A_arbace_a2g_code_translate_loop_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_loop_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_loop_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_loop_A_New()}; return nil }

func A_arbace_a2g_code_translate_loop_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_loop_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_loop_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_loop_A_invoke, New: A_arbace_a2g_code_translate_loop_A_new, Get: A_arbace_a2g_code_translate_loop_A_get}

var A_arbace_a2g_code_translate_loop_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_loop", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_loop", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_loop_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_loop_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_loop_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_loop_A_Init; i.Table = A_arbace_a2g_code_translate_loop_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_loop_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_loop_A]()) }

func A_arbace_a2g_code_translate_loop_fn__16000477_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_loop_fn__16000477_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_loop_fn__16000477_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_loop_fn__16000477_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_loop_fn__16000477_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_loop_fn__16000477_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_loop_fn__16000477_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_loop_fn__16000477_A_invoke, New: A_arbace_a2g_code_translate_loop_fn__16000477_A_new, Get: A_arbace_a2g_code_translate_loop_fn__16000477_A_get}

var A_arbace_a2g_code_translate_loop_fn__16000477_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_loop$fn__16000477", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_loop_A_class, Simple: "fn__16000477", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_loop_fn__16000477_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_loop_fn__16000477_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_loop_fn__16000477_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_loop_fn__16000477_A_Init; i.Table = A_arbace_a2g_code_translate_loop_fn__16000477_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_loop_fn__16000477_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_loop_fn__16000477_A]()) }

func A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_invoke, New: A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_new, Get: A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_get}

var A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_loop$fn__16000477$fn__16000478", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_loop_fn__16000477_A_class, Simple: "fn__16000478", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_Init; i.Table = A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_loop_fn__16000477_fn__16000478_A]()) }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_New()}; return nil }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_invoke, New: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_new, Get: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_get}

var A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_loop$iter__16000461__16000465", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_loop_A_class, Simple: "iter__16000461__16000465", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_Init; i.Table = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A]()) }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_invoke, New: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_new, Get: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_get}

var A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_loop$iter__16000461__16000465$fn__16000466", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_A_class, Simple: "fn__16000466", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_Init; i.Table = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A]()) }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_invoke, New: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_new, Get: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_get}

var A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_loop$iter__16000461__16000465$fn__16000466$fn__16000467", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_A_class, Simple: "fn__16000467", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_Init; i.Table = A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_loop_iter__16000461__16000465_fn__16000466_fn__16000467_A]()) }

func A_arbace_a2g_code_translate_monitor_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_monitor_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_monitor_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_monitor_A_New()}; return nil }

func A_arbace_a2g_code_translate_monitor_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_monitor_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_monitor_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_monitor_A_invoke, New: A_arbace_a2g_code_translate_monitor_A_new, Get: A_arbace_a2g_code_translate_monitor_A_get}

var A_arbace_a2g_code_translate_monitor_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_monitor", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_monitor", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_monitor_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_monitor_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_monitor_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_monitor_A_Init; i.Table = A_arbace_a2g_code_translate_monitor_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_monitor_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_monitor_A]()) }

func A_arbace_a2g_code_translate_monitor_fn__16000780_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_monitor_fn__16000780_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_monitor_fn__16000780_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_monitor_fn__16000780_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_monitor_fn__16000780_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_monitor_fn__16000780_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_monitor_fn__16000780_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_monitor_fn__16000780_A_invoke, New: A_arbace_a2g_code_translate_monitor_fn__16000780_A_new, Get: A_arbace_a2g_code_translate_monitor_fn__16000780_A_get}

var A_arbace_a2g_code_translate_monitor_fn__16000780_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_monitor$fn__16000780", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_monitor_A_class, Simple: "fn__16000780", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_monitor_fn__16000780_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_monitor_fn__16000780_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_monitor_fn__16000780_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_monitor_fn__16000780_A_Init; i.Table = A_arbace_a2g_code_translate_monitor_fn__16000780_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_monitor_fn__16000780_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_monitor_fn__16000780_A]()) }

func A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_invoke, New: A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_new, Get: A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_get}

var A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_monitor$fn__16000780$fn__16000781", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_monitor_fn__16000780_A_class, Simple: "fn__16000781", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_Init; i.Table = A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_monitor_fn__16000780_fn__16000781_A]()) }

func A_arbace_a2g_code_translate_switch_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_switch_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_A_invoke, New: A_arbace_a2g_code_translate_switch_A_new, Get: A_arbace_a2g_code_translate_switch_A_get}

var A_arbace_a2g_code_translate_switch_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_switch", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_A_Init; i.Table = A_arbace_a2g_code_translate_switch_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_A]()) }

func A_arbace_a2g_code_translate_switch_arm__16000558_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_arm__16000558_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_arm__16000558_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_arm__16000558_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_arm__16000558_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_arm__16000558_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_arm__16000558_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_arm__16000558_A_invoke, New: A_arbace_a2g_code_translate_switch_arm__16000558_A_new, Get: A_arbace_a2g_code_translate_switch_arm__16000558_A_get}

var A_arbace_a2g_code_translate_switch_arm__16000558_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$arm__16000558", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "arm__16000558", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_arm__16000558_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_arm__16000558_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_arm__16000558_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_arm__16000558_A_Init; i.Table = A_arbace_a2g_code_translate_switch_arm__16000558_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_arm__16000558_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_arm__16000558_A]()) }

func A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_invoke, New: A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_new, Get: A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_get}

var A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$arm__16000558$fn__16000559", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_arm__16000558_A_class, Simple: "fn__16000559", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_Init; i.Table = A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_arm__16000558_fn__16000559_A]()) }

func A_arbace_a2g_code_translate_switch_arm_done__16000574_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_arm_done__16000574_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_arm_done__16000574_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_arm_done__16000574_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_arm_done__16000574_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_arm_done__16000574_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_arm_done__16000574_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_arm_done__16000574_A_invoke, New: A_arbace_a2g_code_translate_switch_arm_done__16000574_A_new, Get: A_arbace_a2g_code_translate_switch_arm_done__16000574_A_get}

var A_arbace_a2g_code_translate_switch_arm_done__16000574_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$arm_done__16000574", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "arm_done__16000574", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_arm_done__16000574_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_arm_done__16000574_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_arm_done__16000574_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_arm_done__16000574_A_Init; i.Table = A_arbace_a2g_code_translate_switch_arm_done__16000574_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_arm_done__16000574_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_arm_done__16000574_A]()) }

func A_arbace_a2g_code_translate_switch_done__16000572_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_done__16000572_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_done__16000572_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_done__16000572_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_done__16000572_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_done__16000572_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_done__16000572_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_done__16000572_A_invoke, New: A_arbace_a2g_code_translate_switch_done__16000572_A_new, Get: A_arbace_a2g_code_translate_switch_done__16000572_A_get}

var A_arbace_a2g_code_translate_switch_done__16000572_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$done__16000572", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "done__16000572", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_done__16000572_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_done__16000572_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_done__16000572_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_done__16000572_A_Init; i.Table = A_arbace_a2g_code_translate_switch_done__16000572_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_done__16000572_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_done__16000572_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000553_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000553_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000553_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000553_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000553_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000553_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000553_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000553_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000553_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000553_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000553_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000553", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "fn__16000553", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000553_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000553_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000553_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000553_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000553_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000553_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000553_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000562_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000562_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000562_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000562_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000562_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000562_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000562_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000562_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000562_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000562_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000562_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000562", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "fn__16000562", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000562_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000562_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000562_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000562_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000562_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000562_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000562_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000567_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000567_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000567_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000567_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000567_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000567_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000567_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000567_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000567_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000567_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000567_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000567", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "fn__16000567", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000567_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000567_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000567_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000567_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000567_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000567_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000567_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_A_New_O_O_O_O_O_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4], args[5], args[6], args[7], args[8], args[9])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "fn__16000580", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000585", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000585", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000585_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000587", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000587", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000587_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000589", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000589", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000589_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000591", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000591", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000591_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000593", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000593", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000593_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000595", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000595", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000595_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000597", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000597", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000597_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000580$fn__16000599", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_fn__16000580_A_class, Simple: "fn__16000599", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000580_fn__16000599_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000635_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000635_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000635_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000635_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000635_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000635_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000635_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000635_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000635_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000635_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000635_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000635", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "fn__16000635", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000635_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000635_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000635_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000635_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000635_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000635_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000635_A]()) }

func A_arbace_a2g_code_translate_switch_fn__16000638_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_fn__16000638_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000638_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_fn__16000638_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_fn__16000638_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_fn__16000638_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_fn__16000638_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_fn__16000638_A_invoke, New: A_arbace_a2g_code_translate_switch_fn__16000638_A_new, Get: A_arbace_a2g_code_translate_switch_fn__16000638_A_get}

var A_arbace_a2g_code_translate_switch_fn__16000638_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$fn__16000638", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "fn__16000638", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_fn__16000638_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_fn__16000638_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_fn__16000638_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_fn__16000638_A_Init; i.Table = A_arbace_a2g_code_translate_switch_fn__16000638_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_fn__16000638_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_fn__16000638_A]()) }

func A_arbace_a2g_code_translate_switch_guarded__16000576_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_guarded__16000576_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_guarded__16000576_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_guarded__16000576_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_guarded__16000576_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_guarded__16000576_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_guarded__16000576_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_guarded__16000576_A_invoke, New: A_arbace_a2g_code_translate_switch_guarded__16000576_A_new, Get: A_arbace_a2g_code_translate_switch_guarded__16000576_A_get}

var A_arbace_a2g_code_translate_switch_guarded__16000576_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$guarded__16000576", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "guarded__16000576", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_guarded__16000576_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_guarded__16000576_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_guarded__16000576_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_guarded__16000576_A_Init; i.Table = A_arbace_a2g_code_translate_switch_guarded__16000576_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_guarded__16000576_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_guarded__16000576_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000602__16000606", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "iter__16000602__16000606", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_A_class, Simple: "fn__16000607", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607$fn__16000608", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_class, Simple: "fn__16000608", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607$fn__16000608$fn__16000609", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_A_class, Simple: "fn__16000609", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000608_fn__16000609_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000602__16000606$fn__16000607$fn__16000612", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_A_class, Simple: "fn__16000612", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000602__16000606_fn__16000607_fn__16000612_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_New()}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000616__16000622", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "iter__16000616__16000622", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_A_class, Simple: "fn__16000623", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623$iter__16000618__16000627", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_A_class, Simple: "iter__16000618__16000627", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623$iter__16000618__16000627$fn__16000628", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_A_class, Simple: "fn__16000628", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000616__16000622$fn__16000623$iter__16000618__16000627$fn__16000628$fn__16000629", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_A_class, Simple: "fn__16000629", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000616__16000622_fn__16000623_iter__16000618__16000627_fn__16000628_fn__16000629_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000643__16000647", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "iter__16000643__16000647", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_A_class, Simple: "fn__16000648", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648$fn__16000649", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_class, Simple: "fn__16000649", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648$fn__16000649$fn__16000654", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_A_class, Simple: "fn__16000654", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000649_fn__16000654_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000643__16000647$fn__16000648$fn__16000664", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_A_class, Simple: "fn__16000664", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000643__16000647_fn__16000648_fn__16000664_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000671__16000675", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "iter__16000671__16000675", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_A_class, Simple: "fn__16000676", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676$fn__16000677", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_class, Simple: "fn__16000677", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676$fn__16000677$fn__16000682", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_A_class, Simple: "fn__16000682", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000677_fn__16000682_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000671__16000675$fn__16000676$fn__16000692", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_A_class, Simple: "fn__16000692", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000671__16000675_fn__16000676_fn__16000692_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000699__16000703", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "iter__16000699__16000703", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_A_class, Simple: "fn__16000704", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_New_O_O_O_I_O(args[0], args[1], args[2], args[3].(int32), args[4])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704$fn__16000705", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_class, Simple: "fn__16000705", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704$fn__16000705$fn__16000706", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_A_class, Simple: "fn__16000706", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000705_fn__16000706_A]()) }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_invoke, New: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_new, Get: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_get}

var A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$iter__16000699__16000703$fn__16000704$fn__16000709", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_A_class, Simple: "fn__16000709", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_Init; i.Table = A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_iter__16000699__16000703_fn__16000704_fn__16000709_A]()) }

func A_arbace_a2g_code_translate_switch_label_test__16000578_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_switch_label_test__16000578_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_label_test__16000578_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_switch_label_test__16000578_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_switch_label_test__16000578_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_switch_label_test__16000578_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_switch_label_test__16000578_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_switch_label_test__16000578_A_invoke, New: A_arbace_a2g_code_translate_switch_label_test__16000578_A_new, Get: A_arbace_a2g_code_translate_switch_label_test__16000578_A_get}

var A_arbace_a2g_code_translate_switch_label_test__16000578_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_switch$label_test__16000578", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_switch_A_class, Simple: "label_test__16000578", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_switch_label_test__16000578_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_switch_label_test__16000578_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_switch_label_test__16000578_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_switch_label_test__16000578_A_Init; i.Table = A_arbace_a2g_code_translate_switch_label_test__16000578_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_switch_label_test__16000578_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_switch_label_test__16000578_A]()) }

func A_arbace_a2g_code_translate_try_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_try_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_A_New()}; return nil }

func A_arbace_a2g_code_translate_try_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_A_invoke, New: A_arbace_a2g_code_translate_try_A_new, Get: A_arbace_a2g_code_translate_try_A_get}

var A_arbace_a2g_code_translate_try_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "translate_try", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_A_Init; i.Table = A_arbace_a2g_code_translate_try_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_A]()) }

func A_arbace_a2g_code_translate_try_fn__16000773_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_fn__16000773_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_fn__16000773_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_fn__16000773_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_fn__16000773_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_fn__16000773_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_fn__16000773_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_fn__16000773_A_invoke, New: A_arbace_a2g_code_translate_try_fn__16000773_A_new, Get: A_arbace_a2g_code_translate_try_fn__16000773_A_get}

var A_arbace_a2g_code_translate_try_fn__16000773_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$fn__16000773", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_A_class, Simple: "fn__16000773", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_fn__16000773_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_fn__16000773_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_fn__16000773_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_fn__16000773_A_Init; i.Table = A_arbace_a2g_code_translate_try_fn__16000773_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_fn__16000773_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_fn__16000773_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_A_class, Simple: "inner__16000749", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000750", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_A_class, Simple: "fn__16000750", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000750_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000752", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_A_class, Simple: "fn__16000752", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000752_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000754", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_A_class, Simple: "fn__16000754", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_New()}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000754$fn__16000755", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_class, Simple: "fn__16000755", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000755_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_New_O_O_O_O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000754$fn__16000767", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_class, Simple: "fn__16000767", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_fn__16000767_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000754$iter__16000757__16000761", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_A_class, Simple: "iter__16000757__16000761", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000754$iter__16000757__16000761$fn__16000762", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_A_class, Simple: "fn__16000762", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_New_O_O_I_O(args[0], args[1], args[2].(int32), args[3])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000754$iter__16000757__16000761$fn__16000762$fn__16000763", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_A_class, Simple: "fn__16000763", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000754_iter__16000757__16000761_fn__16000762_fn__16000763_A]()) }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_New()}; return nil }

func A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_fn_class)}; return nil }

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_invoke, New: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_new, Get: A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_get}

var A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$translate_try$inner__16000749$fn__16000770", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_translate_try_inner__16000749_A_class, Simple: "fn__16000770", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_class.Info(); i.IsInstance = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_InstanceOf; i.Init = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_Init; i.Table = A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_members; jrt.RegisterGoType(A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A_class, reflect.TypeFor[A_arbace_a2g_code_translate_try_inner__16000749_fn__16000770_A]()) }

func A_arbace_a2g_code_try_literal_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_try_literal_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_try_literal_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_try_literal_A_New()}; return nil }

func A_arbace_a2g_code_try_literal_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_try_literal_A_fn_class)}; return nil }

var A_arbace_a2g_code_try_literal_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_try_literal_A_invoke, New: A_arbace_a2g_code_try_literal_A_new, Get: A_arbace_a2g_code_try_literal_A_get}

var A_arbace_a2g_code_try_literal_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$try_literal", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "try_literal", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_try_literal_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_try_literal_A_class.Info(); i.IsInstance = A_arbace_a2g_code_try_literal_A_InstanceOf; i.Init = A_arbace_a2g_code_try_literal_A_Init; i.Table = A_arbace_a2g_code_try_literal_A_members; jrt.RegisterGoType(A_arbace_a2g_code_try_literal_A_class, reflect.TypeFor[A_arbace_a2g_code_try_literal_A]()) }

func A_arbace_a2g_code_try_literal_fn__16000724_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_try_literal_fn__16000724_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_code_try_literal_fn__16000724_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_try_literal_fn__16000724_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_try_literal_fn__16000724_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_try_literal_fn__16000724_A_fn_class)}; return nil }

var A_arbace_a2g_code_try_literal_fn__16000724_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_try_literal_fn__16000724_A_invoke, New: A_arbace_a2g_code_try_literal_fn__16000724_A_new, Get: A_arbace_a2g_code_try_literal_fn__16000724_A_get}

var A_arbace_a2g_code_try_literal_fn__16000724_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$try_literal$fn__16000724", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_code_try_literal_A_class, Simple: "fn__16000724", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_try_literal_fn__16000724_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_try_literal_fn__16000724_A_class.Info(); i.IsInstance = A_arbace_a2g_code_try_literal_fn__16000724_A_InstanceOf; i.Init = A_arbace_a2g_code_try_literal_fn__16000724_A_Init; i.Table = A_arbace_a2g_code_try_literal_fn__16000724_A_members; jrt.RegisterGoType(A_arbace_a2g_code_try_literal_fn__16000724_A_class, reflect.TypeFor[A_arbace_a2g_code_try_literal_fn__16000724_A]()) }

func A_arbace_a2g_code_try_literal_fn__16000726_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_try_literal_fn__16000726_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_try_literal_fn__16000726_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_try_literal_fn__16000726_A_New()}; return nil }

func A_arbace_a2g_code_try_literal_fn__16000726_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_try_literal_fn__16000726_A_fn_class)}; return nil }

var A_arbace_a2g_code_try_literal_fn__16000726_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_try_literal_fn__16000726_A_invoke, New: A_arbace_a2g_code_try_literal_fn__16000726_A_new, Get: A_arbace_a2g_code_try_literal_fn__16000726_A_get}

var A_arbace_a2g_code_try_literal_fn__16000726_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$try_literal$fn__16000726", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_try_literal_A_class, Simple: "fn__16000726", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_try_literal_fn__16000726_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_try_literal_fn__16000726_A_class.Info(); i.IsInstance = A_arbace_a2g_code_try_literal_fn__16000726_A_InstanceOf; i.Init = A_arbace_a2g_code_try_literal_fn__16000726_A_Init; i.Table = A_arbace_a2g_code_try_literal_fn__16000726_A_members; jrt.RegisterGoType(A_arbace_a2g_code_try_literal_fn__16000726_A_class, reflect.TypeFor[A_arbace_a2g_code_try_literal_fn__16000726_A]()) }

func A_arbace_a2g_code_unsigned_lit_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_unsigned_lit_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_unsigned_lit_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_unsigned_lit_A_New()}; return nil }

func A_arbace_a2g_code_unsigned_lit_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_unsigned_lit_A_fn_class)}; return nil }

var A_arbace_a2g_code_unsigned_lit_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_unsigned_lit_A_invoke, New: A_arbace_a2g_code_unsigned_lit_A_new, Get: A_arbace_a2g_code_unsigned_lit_A_get}

var A_arbace_a2g_code_unsigned_lit_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$unsigned_lit", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "unsigned_lit", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_unsigned_lit_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_unsigned_lit_A_class.Info(); i.IsInstance = A_arbace_a2g_code_unsigned_lit_A_InstanceOf; i.Init = A_arbace_a2g_code_unsigned_lit_A_Init; i.Table = A_arbace_a2g_code_unsigned_lit_A_members; jrt.RegisterGoType(A_arbace_a2g_code_unsigned_lit_A_class, reflect.TypeFor[A_arbace_a2g_code_unsigned_lit_A]()) }

func A_arbace_a2g_code_up_sym_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_up_sym_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_up_sym_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_up_sym_A_New()}; return nil }

func A_arbace_a2g_code_up_sym_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_up_sym_A_fn_class)}; return nil }

var A_arbace_a2g_code_up_sym_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_up_sym_A_invoke, New: A_arbace_a2g_code_up_sym_A_new, Get: A_arbace_a2g_code_up_sym_A_get}

var A_arbace_a2g_code_up_sym_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$up_sym", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "up_sym", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_up_sym_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_up_sym_A_class.Info(); i.IsInstance = A_arbace_a2g_code_up_sym_A_InstanceOf; i.Init = A_arbace_a2g_code_up_sym_A_Init; i.Table = A_arbace_a2g_code_up_sym_A_members; jrt.RegisterGoType(A_arbace_a2g_code_up_sym_A_class, reflect.TypeFor[A_arbace_a2g_code_up_sym_A]()) }

func A_arbace_a2g_code_use_sym_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_use_sym_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_use_sym_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_use_sym_BANG__A_New()}; return nil }

func A_arbace_a2g_code_use_sym_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_use_sym_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_code_use_sym_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_use_sym_BANG__A_invoke, New: A_arbace_a2g_code_use_sym_BANG__A_new, Get: A_arbace_a2g_code_use_sym_BANG__A_get}

var A_arbace_a2g_code_use_sym_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$use_sym_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "use_sym_BANG_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_use_sym_BANG__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_use_sym_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_code_use_sym_BANG__A_InstanceOf; i.Init = A_arbace_a2g_code_use_sym_BANG__A_Init; i.Table = A_arbace_a2g_code_use_sym_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_code_use_sym_BANG__A_class, reflect.TypeFor[A_arbace_a2g_code_use_sym_BANG__A]()) }

func A_arbace_a2g_code_utf8_safe_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_utf8_safe_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_utf8_safe_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_utf8_safe_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_utf8_safe_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_utf8_safe_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_utf8_safe_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_utf8_safe_QMARK__A_invoke, New: A_arbace_a2g_code_utf8_safe_QMARK__A_new, Get: A_arbace_a2g_code_utf8_safe_QMARK__A_get}

var A_arbace_a2g_code_utf8_safe_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$utf8_safe_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "utf8_safe_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_utf8_safe_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_utf8_safe_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_utf8_safe_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_utf8_safe_QMARK__A_Init; i.Table = A_arbace_a2g_code_utf8_safe_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_utf8_safe_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_utf8_safe_QMARK__A]()) }

func A_arbace_a2g_code_v_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_v_A).DoInvoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_v_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_v_A_New()}; return nil }

func A_arbace_a2g_code_v_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_v_A_fn_class)}; return nil }

var A_arbace_a2g_code_v_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_v_A_invoke, New: A_arbace_a2g_code_v_A_new, Get: A_arbace_a2g_code_v_A_get}

var A_arbace_a2g_code_v_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$v", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "v", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_v_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_v_A_class.Info(); i.IsInstance = A_arbace_a2g_code_v_A_InstanceOf; i.Init = A_arbace_a2g_code_v_A_Init; i.Table = A_arbace_a2g_code_v_A_members; jrt.RegisterGoType(A_arbace_a2g_code_v_A_class, reflect.TypeFor[A_arbace_a2g_code_v_A]()) }

func A_arbace_a2g_code_vh_arg_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_arg_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_vh_arg_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_arg_A_New()}; return nil }

func A_arbace_a2g_code_vh_arg_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_arg_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_arg_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_arg_A_invoke, New: A_arbace_a2g_code_vh_arg_A_new, Get: A_arbace_a2g_code_vh_arg_A_get}

var A_arbace_a2g_code_vh_arg_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_arg", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_arg", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_arg_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_arg_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_arg_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_arg_A_Init; i.Table = A_arbace_a2g_code_vh_arg_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_arg_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_arg_A]()) }

func A_arbace_a2g_code_vh_field_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_field_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_field_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_field_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_vh_field_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_field_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_field_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_field_QMARK__A_invoke, New: A_arbace_a2g_code_vh_field_QMARK__A_new, Get: A_arbace_a2g_code_vh_field_QMARK__A_get}

var A_arbace_a2g_code_vh_field_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_field_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_field_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_field_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_field_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_field_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_vh_field_QMARK__A_Init; i.Table = A_arbace_a2g_code_vh_field_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_field_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_vh_field_QMARK__A]()) }

func A_arbace_a2g_code_vh_field_form_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_field_form_A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_code_vh_field_form_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_field_form_A_New()}; return nil }

func A_arbace_a2g_code_vh_field_form_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_field_form_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_field_form_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_field_form_A_invoke, New: A_arbace_a2g_code_vh_field_form_A_new, Get: A_arbace_a2g_code_vh_field_form_A_get}

var A_arbace_a2g_code_vh_field_form_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_field_form", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_field_form", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_field_form_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_field_form_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_field_form_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_field_form_A_Init; i.Table = A_arbace_a2g_code_vh_field_form_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_field_form_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_field_form_A]()) }

func A_arbace_a2g_code_vh_field_form_bits__16000273_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_field_form_bits__16000273_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_field_form_bits__16000273_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_field_form_bits__16000273_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_vh_field_form_bits__16000273_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_field_form_bits__16000273_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_field_form_bits__16000273_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_field_form_bits__16000273_A_invoke, New: A_arbace_a2g_code_vh_field_form_bits__16000273_A_new, Get: A_arbace_a2g_code_vh_field_form_bits__16000273_A_get}

var A_arbace_a2g_code_vh_field_form_bits__16000273_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_field_form$bits__16000273", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_field_form_A_class, Simple: "bits__16000273", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_field_form_bits__16000273_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_field_form_bits__16000273_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_field_form_bits__16000273_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_field_form_bits__16000273_A_Init; i.Table = A_arbace_a2g_code_vh_field_form_bits__16000273_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_field_form_bits__16000273_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_field_form_bits__16000273_A]()) }

func A_arbace_a2g_code_vh_field_form_narrow__16000268_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_field_form_narrow__16000268_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_field_form_narrow__16000268_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_field_form_narrow__16000268_A_New()}; return nil }

func A_arbace_a2g_code_vh_field_form_narrow__16000268_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_field_form_narrow__16000268_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_field_form_narrow__16000268_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_field_form_narrow__16000268_A_invoke, New: A_arbace_a2g_code_vh_field_form_narrow__16000268_A_new, Get: A_arbace_a2g_code_vh_field_form_narrow__16000268_A_get}

var A_arbace_a2g_code_vh_field_form_narrow__16000268_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_field_form$narrow__16000268", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_field_form_A_class, Simple: "narrow__16000268", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_field_form_narrow__16000268_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_field_form_narrow__16000268_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_field_form_narrow__16000268_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_field_form_narrow__16000268_A_Init; i.Table = A_arbace_a2g_code_vh_field_form_narrow__16000268_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_field_form_narrow__16000268_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_field_form_narrow__16000268_A]()) }

func A_arbace_a2g_code_vh_field_form_unbits__16000276_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_field_form_unbits__16000276_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_field_form_unbits__16000276_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_field_form_unbits__16000276_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_vh_field_form_unbits__16000276_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_field_form_unbits__16000276_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_field_form_unbits__16000276_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_field_form_unbits__16000276_A_invoke, New: A_arbace_a2g_code_vh_field_form_unbits__16000276_A_new, Get: A_arbace_a2g_code_vh_field_form_unbits__16000276_A_get}

var A_arbace_a2g_code_vh_field_form_unbits__16000276_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_field_form$unbits__16000276", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_field_form_A_class, Simple: "unbits__16000276", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_field_form_unbits__16000276_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_field_form_unbits__16000276_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_field_form_unbits__16000276_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_field_form_unbits__16000276_A_Init; i.Table = A_arbace_a2g_code_vh_field_form_unbits__16000276_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_field_form_unbits__16000276_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_field_form_unbits__16000276_A]()) }

func A_arbace_a2g_code_vh_field_form_widen__16000270_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_field_form_widen__16000270_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_field_form_widen__16000270_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_field_form_widen__16000270_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_vh_field_form_widen__16000270_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_field_form_widen__16000270_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_field_form_widen__16000270_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_field_form_widen__16000270_A_invoke, New: A_arbace_a2g_code_vh_field_form_widen__16000270_A_new, Get: A_arbace_a2g_code_vh_field_form_widen__16000270_A_get}

var A_arbace_a2g_code_vh_field_form_widen__16000270_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_field_form$widen__16000270", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_field_form_A_class, Simple: "widen__16000270", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_field_form_widen__16000270_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_field_form_widen__16000270_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_field_form_widen__16000270_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_field_form_widen__16000270_A_Init; i.Table = A_arbace_a2g_code_vh_field_form_widen__16000270_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_field_form_widen__16000270_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_field_form_widen__16000270_A]()) }

func A_arbace_a2g_code_vh_missing_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_missing_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_missing_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_missing_A_New()}; return nil }

func A_arbace_a2g_code_vh_missing_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_missing_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_missing_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_missing_A_invoke, New: A_arbace_a2g_code_vh_missing_A_new, Get: A_arbace_a2g_code_vh_missing_A_get}

var A_arbace_a2g_code_vh_missing_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_missing", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_missing", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_missing_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_missing_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_missing_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_missing_A_Init; i.Table = A_arbace_a2g_code_vh_missing_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_missing_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_missing_A]()) }

func A_arbace_a2g_code_vh_op_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_op_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_op_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_op_A_New()}; return nil }

func A_arbace_a2g_code_vh_op_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_op_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_op_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_op_A_invoke, New: A_arbace_a2g_code_vh_op_A_new, Get: A_arbace_a2g_code_vh_op_A_get}

var A_arbace_a2g_code_vh_op_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_op", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_op", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_op_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_op_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_op_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_op_A_Init; i.Table = A_arbace_a2g_code_vh_op_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_op_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_op_A]()) }

func A_arbace_a2g_code_vh_result_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_result_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_vh_result_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_result_A_New()}; return nil }

func A_arbace_a2g_code_vh_result_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_result_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_result_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_result_A_invoke, New: A_arbace_a2g_code_vh_result_A_new, Get: A_arbace_a2g_code_vh_result_A_get}

var A_arbace_a2g_code_vh_result_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_result", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_result", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_result_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_result_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_result_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_result_A_Init; i.Table = A_arbace_a2g_code_vh_result_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_result_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_result_A]()) }

func A_arbace_a2g_code_vh_supported_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_supported_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_vh_supported_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_supported_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_vh_supported_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_supported_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_supported_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_supported_QMARK__A_invoke, New: A_arbace_a2g_code_vh_supported_QMARK__A_new, Get: A_arbace_a2g_code_vh_supported_QMARK__A_get}

var A_arbace_a2g_code_vh_supported_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_supported_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_supported_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_supported_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_supported_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_supported_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_vh_supported_QMARK__A_Init; i.Table = A_arbace_a2g_code_vh_supported_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_supported_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_vh_supported_QMARK__A]()) }

func A_arbace_a2g_code_vh_val_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_val_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_vh_val_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_val_A_New()}; return nil }

func A_arbace_a2g_code_vh_val_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_val_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_val_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_val_A_invoke, New: A_arbace_a2g_code_vh_val_A_new, Get: A_arbace_a2g_code_vh_val_A_get}

var A_arbace_a2g_code_vh_val_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_val", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vh_val", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_val_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_val_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_val_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_val_A_Init; i.Table = A_arbace_a2g_code_vh_val_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_val_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_val_A]()) }

func A_arbace_a2g_code_vh_val_fn__16000301_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_val_fn__16000301_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_val_fn__16000301_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_val_fn__16000301_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_vh_val_fn__16000301_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_val_fn__16000301_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_val_fn__16000301_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_val_fn__16000301_A_invoke, New: A_arbace_a2g_code_vh_val_fn__16000301_A_new, Get: A_arbace_a2g_code_vh_val_fn__16000301_A_get}

var A_arbace_a2g_code_vh_val_fn__16000301_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_val$fn__16000301", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_val_A_class, Simple: "fn__16000301", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_val_fn__16000301_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_val_fn__16000301_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_val_fn__16000301_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_val_fn__16000301_A_Init; i.Table = A_arbace_a2g_code_vh_val_fn__16000301_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_val_fn__16000301_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_val_fn__16000301_A]()) }

func A_arbace_a2g_code_vh_val_fn__16000308_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_val_fn__16000308_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_val_fn__16000308_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_val_fn__16000308_A_New_O(args[0])}; return nil }

func A_arbace_a2g_code_vh_val_fn__16000308_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_val_fn__16000308_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_val_fn__16000308_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_val_fn__16000308_A_invoke, New: A_arbace_a2g_code_vh_val_fn__16000308_A_new, Get: A_arbace_a2g_code_vh_val_fn__16000308_A_get}

var A_arbace_a2g_code_vh_val_fn__16000308_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_val$fn__16000308", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_val_A_class, Simple: "fn__16000308", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_val_fn__16000308_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_val_fn__16000308_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_val_fn__16000308_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_val_fn__16000308_A_Init; i.Table = A_arbace_a2g_code_vh_val_fn__16000308_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_val_fn__16000308_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_val_fn__16000308_A]()) }

func A_arbace_a2g_code_vh_val_fn__16000314_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vh_val_fn__16000314_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vh_val_fn__16000314_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vh_val_fn__16000314_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_vh_val_fn__16000314_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vh_val_fn__16000314_A_fn_class)}; return nil }

var A_arbace_a2g_code_vh_val_fn__16000314_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vh_val_fn__16000314_A_invoke, New: A_arbace_a2g_code_vh_val_fn__16000314_A_new, Get: A_arbace_a2g_code_vh_val_fn__16000314_A_get}

var A_arbace_a2g_code_vh_val_fn__16000314_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vh_val$fn__16000314", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_vh_val_A_class, Simple: "fn__16000314", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vh_val_fn__16000314_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vh_val_fn__16000314_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vh_val_fn__16000314_A_InstanceOf; i.Init = A_arbace_a2g_code_vh_val_fn__16000314_A_Init; i.Table = A_arbace_a2g_code_vh_val_fn__16000314_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vh_val_fn__16000314_A_class, reflect.TypeFor[A_arbace_a2g_code_vh_val_fn__16000314_A]()) }

func A_arbace_a2g_code_volatile_field_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_volatile_field_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_volatile_field_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_volatile_field_QMARK__A_New()}; return nil }

func A_arbace_a2g_code_volatile_field_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_volatile_field_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_code_volatile_field_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_volatile_field_QMARK__A_invoke, New: A_arbace_a2g_code_volatile_field_QMARK__A_new, Get: A_arbace_a2g_code_volatile_field_QMARK__A_get}

var A_arbace_a2g_code_volatile_field_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$volatile_field_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "volatile_field_QMARK_", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_volatile_field_QMARK__A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_volatile_field_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_code_volatile_field_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_code_volatile_field_QMARK__A_Init; i.Table = A_arbace_a2g_code_volatile_field_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_code_volatile_field_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_code_volatile_field_QMARK__A]()) }

func A_arbace_a2g_code_volatile_read_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_volatile_read_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_code_volatile_read_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_volatile_read_A_New()}; return nil }

func A_arbace_a2g_code_volatile_read_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_volatile_read_A_fn_class)}; return nil }

var A_arbace_a2g_code_volatile_read_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_volatile_read_A_invoke, New: A_arbace_a2g_code_volatile_read_A_new, Get: A_arbace_a2g_code_volatile_read_A_get}

var A_arbace_a2g_code_volatile_read_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$volatile_read", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "volatile_read", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_volatile_read_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_volatile_read_A_class.Info(); i.IsInstance = A_arbace_a2g_code_volatile_read_A_InstanceOf; i.Init = A_arbace_a2g_code_volatile_read_A_Init; i.Table = A_arbace_a2g_code_volatile_read_A_members; jrt.RegisterGoType(A_arbace_a2g_code_volatile_read_A_class, reflect.TypeFor[A_arbace_a2g_code_volatile_read_A]()) }

func A_arbace_a2g_code_volatile_write_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_volatile_write_A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_code_volatile_write_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_volatile_write_A_New()}; return nil }

func A_arbace_a2g_code_volatile_write_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_volatile_write_A_fn_class)}; return nil }

var A_arbace_a2g_code_volatile_write_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_volatile_write_A_invoke, New: A_arbace_a2g_code_volatile_write_A_new, Get: A_arbace_a2g_code_volatile_write_A_get}

var A_arbace_a2g_code_volatile_write_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$volatile_write", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "volatile_write", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_volatile_write_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_volatile_write_A_class.Info(); i.IsInstance = A_arbace_a2g_code_volatile_write_A_InstanceOf; i.Init = A_arbace_a2g_code_volatile_write_A_Init; i.Table = A_arbace_a2g_code_volatile_write_A_members; jrt.RegisterGoType(A_arbace_a2g_code_volatile_write_A_class, reflect.TypeFor[A_arbace_a2g_code_volatile_write_A]()) }

func A_arbace_a2g_code_vt_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_vt_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_vt_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_vt_A_New()}; return nil }

func A_arbace_a2g_code_vt_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_vt_A_fn_class)}; return nil }

var A_arbace_a2g_code_vt_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_vt_A_invoke, New: A_arbace_a2g_code_vt_A_new, Get: A_arbace_a2g_code_vt_A_get}

var A_arbace_a2g_code_vt_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$vt", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "vt", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_vt_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_vt_A_class.Info(); i.IsInstance = A_arbace_a2g_code_vt_A_InstanceOf; i.Init = A_arbace_a2g_code_vt_A_Init; i.Table = A_arbace_a2g_code_vt_A_members; jrt.RegisterGoType(A_arbace_a2g_code_vt_A_class, reflect.TypeFor[A_arbace_a2g_code_vt_A]()) }

func A_arbace_a2g_code_with_block_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_with_block_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_with_block_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_with_block_A_New()}; return nil }

func A_arbace_a2g_code_with_block_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_with_block_A_fn_class)}; return nil }

var A_arbace_a2g_code_with_block_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_with_block_A_invoke, New: A_arbace_a2g_code_with_block_A_new, Get: A_arbace_a2g_code_with_block_A_get}

var A_arbace_a2g_code_with_block_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$with_block", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "with_block", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_with_block_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_with_block_A_class.Info(); i.IsInstance = A_arbace_a2g_code_with_block_A_InstanceOf; i.Init = A_arbace_a2g_code_with_block_A_Init; i.Table = A_arbace_a2g_code_with_block_A_members; jrt.RegisterGoType(A_arbace_a2g_code_with_block_A_class, reflect.TypeFor[A_arbace_a2g_code_with_block_A]()) }

func A_arbace_a2g_code_with_line_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_with_line_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_with_line_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_with_line_A_New()}; return nil }

func A_arbace_a2g_code_with_line_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_with_line_A_fn_class)}; return nil }

var A_arbace_a2g_code_with_line_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_with_line_A_invoke, New: A_arbace_a2g_code_with_line_A_new, Get: A_arbace_a2g_code_with_line_A_get}

var A_arbace_a2g_code_with_line_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$with_line", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "with_line", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_with_line_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_with_line_A_class.Info(); i.IsInstance = A_arbace_a2g_code_with_line_A_InstanceOf; i.Init = A_arbace_a2g_code_with_line_A_Init; i.Table = A_arbace_a2g_code_with_line_A_members; jrt.RegisterGoType(A_arbace_a2g_code_with_line_A_class, reflect.TypeFor[A_arbace_a2g_code_with_line_A]()) }

func A_arbace_a2g_code_zero_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_code_zero_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_code_zero_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code_zero_of_A_New()}; return nil }

func A_arbace_a2g_code_zero_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_code_zero_of_A_fn_class)}; return nil }

var A_arbace_a2g_code_zero_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_code_zero_of_A_invoke, New: A_arbace_a2g_code_zero_of_A_new, Get: A_arbace_a2g_code_zero_of_A_get}

var A_arbace_a2g_code_zero_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code$zero_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_code_A_class, Simple: "zero_of", Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code_zero_of_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code_zero_of_A_class.Info(); i.IsInstance = A_arbace_a2g_code_zero_of_A_InstanceOf; i.Init = A_arbace_a2g_code_zero_of_A_Init; i.Table = A_arbace_a2g_code_zero_of_A_members; jrt.RegisterGoType(A_arbace_a2g_code_zero_of_A_class, reflect.TypeFor[A_arbace_a2g_code_zero_of_A]()) }

func A_arbace_a2g_code__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_code__init_A_Load__O(); case 1: return A_arbace_a2g_code__init_A_Unit0__O(); case 2: return A_arbace_a2g_code__init_A_Unit1__O(); case 3: return A_arbace_a2g_code__init_A_Unit10__O(); case 4: return A_arbace_a2g_code__init_A_Unit100__O(); case 5: return A_arbace_a2g_code__init_A_Unit101__O(); case 6: return A_arbace_a2g_code__init_A_Unit102__O(); case 7: return A_arbace_a2g_code__init_A_Unit103__O(); case 8: return A_arbace_a2g_code__init_A_Unit104__O(); case 9: return A_arbace_a2g_code__init_A_Unit105__O(); case 10: return A_arbace_a2g_code__init_A_Unit106__O(); case 11: return A_arbace_a2g_code__init_A_Unit107__O(); case 12: return A_arbace_a2g_code__init_A_Unit108__O(); case 13: return A_arbace_a2g_code__init_A_Unit109__O(); case 14: return A_arbace_a2g_code__init_A_Unit11__O(); case 15: return A_arbace_a2g_code__init_A_Unit110__O(); case 16: return A_arbace_a2g_code__init_A_Unit111__O(); case 17: return A_arbace_a2g_code__init_A_Unit112__O(); case 18: return A_arbace_a2g_code__init_A_Unit113__O(); case 19: return A_arbace_a2g_code__init_A_Unit114__O(); case 20: return A_arbace_a2g_code__init_A_Unit115__O(); case 21: return A_arbace_a2g_code__init_A_Unit116__O(); case 22: return A_arbace_a2g_code__init_A_Unit117__O(); case 23: return A_arbace_a2g_code__init_A_Unit118__O(); case 24: return A_arbace_a2g_code__init_A_Unit119__O(); case 25: return A_arbace_a2g_code__init_A_Unit12__O(); case 26: return A_arbace_a2g_code__init_A_Unit120__O(); case 27: return A_arbace_a2g_code__init_A_Unit121__O(); case 28: return A_arbace_a2g_code__init_A_Unit122__O(); case 29: return A_arbace_a2g_code__init_A_Unit123__O(); case 30: return A_arbace_a2g_code__init_A_Unit124__O(); case 31: return A_arbace_a2g_code__init_A_Unit125__O(); case 32: return A_arbace_a2g_code__init_A_Unit126__O(); case 33: return A_arbace_a2g_code__init_A_Unit127__O(); case 34: return A_arbace_a2g_code__init_A_Unit128__O(); case 35: return A_arbace_a2g_code__init_A_Unit129__O(); case 36: return A_arbace_a2g_code__init_A_Unit13__O(); case 37: return A_arbace_a2g_code__init_A_Unit130__O(); case 38: return A_arbace_a2g_code__init_A_Unit131__O(); case 39: return A_arbace_a2g_code__init_A_Unit132__O(); case 40: return A_arbace_a2g_code__init_A_Unit133__O(); case 41: return A_arbace_a2g_code__init_A_Unit134__O(); case 42: return A_arbace_a2g_code__init_A_Unit135__O(); case 43: return A_arbace_a2g_code__init_A_Unit136__O(); case 44: return A_arbace_a2g_code__init_A_Unit137__O(); case 45: return A_arbace_a2g_code__init_A_Unit138__O(); case 46: return A_arbace_a2g_code__init_A_Unit139__O(); case 47: return A_arbace_a2g_code__init_A_Unit14__O(); case 48: return A_arbace_a2g_code__init_A_Unit140__O(); case 49: return A_arbace_a2g_code__init_A_Unit141__O(); case 50: return A_arbace_a2g_code__init_A_Unit142__O(); case 51: return A_arbace_a2g_code__init_A_Unit143__O(); case 52: return A_arbace_a2g_code__init_A_Unit144__O(); case 53: return A_arbace_a2g_code__init_A_Unit145__O(); case 54: return A_arbace_a2g_code__init_A_Unit146__O(); case 55: return A_arbace_a2g_code__init_A_Unit147__O(); case 56: return A_arbace_a2g_code__init_A_Unit148__O(); case 57: return A_arbace_a2g_code__init_A_Unit149__O(); case 58: return A_arbace_a2g_code__init_A_Unit15__O(); case 59: return A_arbace_a2g_code__init_A_Unit150__O(); case 60: return A_arbace_a2g_code__init_A_Unit151__O(); case 61: return A_arbace_a2g_code__init_A_Unit152__O(); case 62: return A_arbace_a2g_code__init_A_Unit153__O(); case 63: return A_arbace_a2g_code__init_A_Unit154__O(); case 64: return A_arbace_a2g_code__init_A_Unit155__O(); case 65: return A_arbace_a2g_code__init_A_Unit156__O(); case 66: return A_arbace_a2g_code__init_A_Unit157__O(); case 67: return A_arbace_a2g_code__init_A_Unit158__O(); case 68: return A_arbace_a2g_code__init_A_Unit159__O(); case 69: return A_arbace_a2g_code__init_A_Unit16__O(); case 70: return A_arbace_a2g_code__init_A_Unit160__O(); case 71: return A_arbace_a2g_code__init_A_Unit161__O(); case 72: return A_arbace_a2g_code__init_A_Unit162__O(); case 73: return A_arbace_a2g_code__init_A_Unit163__O(); case 74: return A_arbace_a2g_code__init_A_Unit164__O(); case 75: return A_arbace_a2g_code__init_A_Unit165__O(); case 76: return A_arbace_a2g_code__init_A_Unit166__O(); case 77: return A_arbace_a2g_code__init_A_Unit167__O(); case 78: return A_arbace_a2g_code__init_A_Unit168__O(); case 79: return A_arbace_a2g_code__init_A_Unit169__O(); case 80: return A_arbace_a2g_code__init_A_Unit17__O(); case 81: return A_arbace_a2g_code__init_A_Unit170__O(); case 82: return A_arbace_a2g_code__init_A_Unit171__O(); case 83: return A_arbace_a2g_code__init_A_Unit172__O(); case 84: return A_arbace_a2g_code__init_A_Unit173__O(); case 85: return A_arbace_a2g_code__init_A_Unit174__O(); case 86: return A_arbace_a2g_code__init_A_Unit175__O(); case 87: return A_arbace_a2g_code__init_A_Unit176__O(); case 88: return A_arbace_a2g_code__init_A_Unit177__O(); case 89: return A_arbace_a2g_code__init_A_Unit178__O(); case 90: return A_arbace_a2g_code__init_A_Unit179__O(); case 91: return A_arbace_a2g_code__init_A_Unit18__O(); case 92: return A_arbace_a2g_code__init_A_Unit180__O(); case 93: return A_arbace_a2g_code__init_A_Unit181__O(); case 94: return A_arbace_a2g_code__init_A_Unit182__O(); case 95: return A_arbace_a2g_code__init_A_Unit183__O(); case 96: return A_arbace_a2g_code__init_A_Unit184__O(); case 97: return A_arbace_a2g_code__init_A_Unit185__O(); case 98: return A_arbace_a2g_code__init_A_Unit186__O(); case 99: return A_arbace_a2g_code__init_A_Unit19__O(); case 100: return A_arbace_a2g_code__init_A_Unit2__O(); case 101: return A_arbace_a2g_code__init_A_Unit20__O(); case 102: return A_arbace_a2g_code__init_A_Unit21__O(); case 103: return A_arbace_a2g_code__init_A_Unit22__O(); case 104: return A_arbace_a2g_code__init_A_Unit23__O(); case 105: return A_arbace_a2g_code__init_A_Unit24__O(); case 106: return A_arbace_a2g_code__init_A_Unit25__O(); case 107: return A_arbace_a2g_code__init_A_Unit26__O(); case 108: return A_arbace_a2g_code__init_A_Unit27__O(); case 109: return A_arbace_a2g_code__init_A_Unit28__O(); case 110: return A_arbace_a2g_code__init_A_Unit29__O(); case 111: return A_arbace_a2g_code__init_A_Unit3__O(); case 112: return A_arbace_a2g_code__init_A_Unit30__O(); case 113: return A_arbace_a2g_code__init_A_Unit31__O(); case 114: return A_arbace_a2g_code__init_A_Unit32__O(); case 115: return A_arbace_a2g_code__init_A_Unit33__O(); case 116: return A_arbace_a2g_code__init_A_Unit34__O(); case 117: return A_arbace_a2g_code__init_A_Unit35__O(); case 118: return A_arbace_a2g_code__init_A_Unit36__O(); case 119: return A_arbace_a2g_code__init_A_Unit37__O(); case 120: return A_arbace_a2g_code__init_A_Unit38__O(); case 121: return A_arbace_a2g_code__init_A_Unit39__O(); case 122: return A_arbace_a2g_code__init_A_Unit4__O(); case 123: return A_arbace_a2g_code__init_A_Unit40__O(); case 124: return A_arbace_a2g_code__init_A_Unit41__O(); case 125: return A_arbace_a2g_code__init_A_Unit42__O(); case 126: return A_arbace_a2g_code__init_A_Unit43__O(); case 127: return A_arbace_a2g_code__init_A_Unit44__O(); case 128: return A_arbace_a2g_code__init_A_Unit45__O(); case 129: return A_arbace_a2g_code__init_A_Unit46__O(); case 130: return A_arbace_a2g_code__init_A_Unit47__O(); case 131: return A_arbace_a2g_code__init_A_Unit48__O(); case 132: return A_arbace_a2g_code__init_A_Unit49__O(); case 133: return A_arbace_a2g_code__init_A_Unit5__O(); case 134: return A_arbace_a2g_code__init_A_Unit50__O(); case 135: return A_arbace_a2g_code__init_A_Unit51__O(); case 136: return A_arbace_a2g_code__init_A_Unit52__O(); case 137: return A_arbace_a2g_code__init_A_Unit53__O(); case 138: return A_arbace_a2g_code__init_A_Unit54__O(); case 139: return A_arbace_a2g_code__init_A_Unit55__O(); case 140: return A_arbace_a2g_code__init_A_Unit56__O(); case 141: return A_arbace_a2g_code__init_A_Unit57__O(); case 142: return A_arbace_a2g_code__init_A_Unit58__O(); case 143: return A_arbace_a2g_code__init_A_Unit59__O(); case 144: return A_arbace_a2g_code__init_A_Unit6__O(); case 145: return A_arbace_a2g_code__init_A_Unit60__O(); case 146: return A_arbace_a2g_code__init_A_Unit61__O(); case 147: return A_arbace_a2g_code__init_A_Unit62__O(); case 148: return A_arbace_a2g_code__init_A_Unit63__O(); case 149: return A_arbace_a2g_code__init_A_Unit64__O(); case 150: return A_arbace_a2g_code__init_A_Unit65__O(); case 151: return A_arbace_a2g_code__init_A_Unit66__O(); case 152: return A_arbace_a2g_code__init_A_Unit67__O(); case 153: return A_arbace_a2g_code__init_A_Unit68__O(); case 154: return A_arbace_a2g_code__init_A_Unit69__O(); case 155: return A_arbace_a2g_code__init_A_Unit7__O(); case 156: return A_arbace_a2g_code__init_A_Unit70__O(); case 157: return A_arbace_a2g_code__init_A_Unit71__O(); case 158: return A_arbace_a2g_code__init_A_Unit72__O(); case 159: return A_arbace_a2g_code__init_A_Unit73__O(); case 160: return A_arbace_a2g_code__init_A_Unit74__O(); case 161: return A_arbace_a2g_code__init_A_Unit75__O(); case 162: return A_arbace_a2g_code__init_A_Unit76__O(); case 163: return A_arbace_a2g_code__init_A_Unit77__O(); case 164: return A_arbace_a2g_code__init_A_Unit78__O(); case 165: return A_arbace_a2g_code__init_A_Unit79__O(); case 166: return A_arbace_a2g_code__init_A_Unit8__O(); case 167: return A_arbace_a2g_code__init_A_Unit80__O(); case 168: return A_arbace_a2g_code__init_A_Unit81__O(); case 169: return A_arbace_a2g_code__init_A_Unit82__O(); case 170: return A_arbace_a2g_code__init_A_Unit83__O(); case 171: return A_arbace_a2g_code__init_A_Unit84__O(); case 172: return A_arbace_a2g_code__init_A_Unit85__O(); case 173: return A_arbace_a2g_code__init_A_Unit86__O(); case 174: return A_arbace_a2g_code__init_A_Unit87__O(); case 175: return A_arbace_a2g_code__init_A_Unit88__O(); case 176: return A_arbace_a2g_code__init_A_Unit89__O(); case 177: return A_arbace_a2g_code__init_A_Unit9__O(); case 178: return A_arbace_a2g_code__init_A_Unit90__O(); case 179: return A_arbace_a2g_code__init_A_Unit91__O(); case 180: return A_arbace_a2g_code__init_A_Unit92__O(); case 181: return A_arbace_a2g_code__init_A_Unit93__O(); case 182: return A_arbace_a2g_code__init_A_Unit94__O(); case 183: return A_arbace_a2g_code__init_A_Unit95__O(); case 184: return A_arbace_a2g_code__init_A_Unit96__O(); case 185: return A_arbace_a2g_code__init_A_Unit97__O(); case 186: return A_arbace_a2g_code__init_A_Unit98__O(); case 187: return A_arbace_a2g_code__init_A_Unit99__O()}; return nil }

func A_arbace_a2g_code__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_code__init_A_New()}; return nil }

var A_arbace_a2g_code__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit100 ()Ljava.lang.Object;\nM9 unit101 ()Ljava.lang.Object;\nM9 unit102 ()Ljava.lang.Object;\nM9 unit103 ()Ljava.lang.Object;\nM9 unit104 ()Ljava.lang.Object;\nM9 unit105 ()Ljava.lang.Object;\nM9 unit106 ()Ljava.lang.Object;\nM9 unit107 ()Ljava.lang.Object;\nM9 unit108 ()Ljava.lang.Object;\nM9 unit109 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit110 ()Ljava.lang.Object;\nM9 unit111 ()Ljava.lang.Object;\nM9 unit112 ()Ljava.lang.Object;\nM9 unit113 ()Ljava.lang.Object;\nM9 unit114 ()Ljava.lang.Object;\nM9 unit115 ()Ljava.lang.Object;\nM9 unit116 ()Ljava.lang.Object;\nM9 unit117 ()Ljava.lang.Object;\nM9 unit118 ()Ljava.lang.Object;\nM9 unit119 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit120 ()Ljava.lang.Object;\nM9 unit121 ()Ljava.lang.Object;\nM9 unit122 ()Ljava.lang.Object;\nM9 unit123 ()Ljava.lang.Object;\nM9 unit124 ()Ljava.lang.Object;\nM9 unit125 ()Ljava.lang.Object;\nM9 unit126 ()Ljava.lang.Object;\nM9 unit127 ()Ljava.lang.Object;\nM9 unit128 ()Ljava.lang.Object;\nM9 unit129 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit130 ()Ljava.lang.Object;\nM9 unit131 ()Ljava.lang.Object;\nM9 unit132 ()Ljava.lang.Object;\nM9 unit133 ()Ljava.lang.Object;\nM9 unit134 ()Ljava.lang.Object;\nM9 unit135 ()Ljava.lang.Object;\nM9 unit136 ()Ljava.lang.Object;\nM9 unit137 ()Ljava.lang.Object;\nM9 unit138 ()Ljava.lang.Object;\nM9 unit139 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit140 ()Ljava.lang.Object;\nM9 unit141 ()Ljava.lang.Object;\nM9 unit142 ()Ljava.lang.Object;\nM9 unit143 ()Ljava.lang.Object;\nM9 unit144 ()Ljava.lang.Object;\nM9 unit145 ()Ljava.lang.Object;\nM9 unit146 ()Ljava.lang.Object;\nM9 unit147 ()Ljava.lang.Object;\nM9 unit148 ()Ljava.lang.Object;\nM9 unit149 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit150 ()Ljava.lang.Object;\nM9 unit151 ()Ljava.lang.Object;\nM9 unit152 ()Ljava.lang.Object;\nM9 unit153 ()Ljava.lang.Object;\nM9 unit154 ()Ljava.lang.Object;\nM9 unit155 ()Ljava.lang.Object;\nM9 unit156 ()Ljava.lang.Object;\nM9 unit157 ()Ljava.lang.Object;\nM9 unit158 ()Ljava.lang.Object;\nM9 unit159 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit160 ()Ljava.lang.Object;\nM9 unit161 ()Ljava.lang.Object;\nM9 unit162 ()Ljava.lang.Object;\nM9 unit163 ()Ljava.lang.Object;\nM9 unit164 ()Ljava.lang.Object;\nM9 unit165 ()Ljava.lang.Object;\nM9 unit166 ()Ljava.lang.Object;\nM9 unit167 ()Ljava.lang.Object;\nM9 unit168 ()Ljava.lang.Object;\nM9 unit169 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit170 ()Ljava.lang.Object;\nM9 unit171 ()Ljava.lang.Object;\nM9 unit172 ()Ljava.lang.Object;\nM9 unit173 ()Ljava.lang.Object;\nM9 unit174 ()Ljava.lang.Object;\nM9 unit175 ()Ljava.lang.Object;\nM9 unit176 ()Ljava.lang.Object;\nM9 unit177 ()Ljava.lang.Object;\nM9 unit178 ()Ljava.lang.Object;\nM9 unit179 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit180 ()Ljava.lang.Object;\nM9 unit181 ()Ljava.lang.Object;\nM9 unit182 ()Ljava.lang.Object;\nM9 unit183 ()Ljava.lang.Object;\nM9 unit184 ()Ljava.lang.Object;\nM9 unit185 ()Ljava.lang.Object;\nM9 unit186 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit37 ()Ljava.lang.Object;\nM9 unit38 ()Ljava.lang.Object;\nM9 unit39 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit40 ()Ljava.lang.Object;\nM9 unit41 ()Ljava.lang.Object;\nM9 unit42 ()Ljava.lang.Object;\nM9 unit43 ()Ljava.lang.Object;\nM9 unit44 ()Ljava.lang.Object;\nM9 unit45 ()Ljava.lang.Object;\nM9 unit46 ()Ljava.lang.Object;\nM9 unit47 ()Ljava.lang.Object;\nM9 unit48 ()Ljava.lang.Object;\nM9 unit49 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit50 ()Ljava.lang.Object;\nM9 unit51 ()Ljava.lang.Object;\nM9 unit52 ()Ljava.lang.Object;\nM9 unit53 ()Ljava.lang.Object;\nM9 unit54 ()Ljava.lang.Object;\nM9 unit55 ()Ljava.lang.Object;\nM9 unit56 ()Ljava.lang.Object;\nM9 unit57 ()Ljava.lang.Object;\nM9 unit58 ()Ljava.lang.Object;\nM9 unit59 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit60 ()Ljava.lang.Object;\nM9 unit61 ()Ljava.lang.Object;\nM9 unit62 ()Ljava.lang.Object;\nM9 unit63 ()Ljava.lang.Object;\nM9 unit64 ()Ljava.lang.Object;\nM9 unit65 ()Ljava.lang.Object;\nM9 unit66 ()Ljava.lang.Object;\nM9 unit67 ()Ljava.lang.Object;\nM9 unit68 ()Ljava.lang.Object;\nM9 unit69 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit70 ()Ljava.lang.Object;\nM9 unit71 ()Ljava.lang.Object;\nM9 unit72 ()Ljava.lang.Object;\nM9 unit73 ()Ljava.lang.Object;\nM9 unit74 ()Ljava.lang.Object;\nM9 unit75 ()Ljava.lang.Object;\nM9 unit76 ()Ljava.lang.Object;\nM9 unit77 ()Ljava.lang.Object;\nM9 unit78 ()Ljava.lang.Object;\nM9 unit79 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit80 ()Ljava.lang.Object;\nM9 unit81 ()Ljava.lang.Object;\nM9 unit82 ()Ljava.lang.Object;\nM9 unit83 ()Ljava.lang.Object;\nM9 unit84 ()Ljava.lang.Object;\nM9 unit85 ()Ljava.lang.Object;\nM9 unit86 ()Ljava.lang.Object;\nM9 unit87 ()Ljava.lang.Object;\nM9 unit88 ()Ljava.lang.Object;\nM9 unit89 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nM9 unit90 ()Ljava.lang.Object;\nM9 unit91 ()Ljava.lang.Object;\nM9 unit92 ()Ljava.lang.Object;\nM9 unit93 ()Ljava.lang.Object;\nM9 unit94 ()Ljava.lang.Object;\nM9 unit95 ()Ljava.lang.Object;\nM9 unit96 ()Ljava.lang.Object;\nM9 unit97 ()Ljava.lang.Object;\nM9 unit98 ()Ljava.lang.Object;\nM9 unit99 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_code__init_A_invoke, New: A_arbace_a2g_code__init_A_new}

var A_arbace_a2g_code__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.code__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_code.A_arbace_a2g_code__init_A", Source: "code.ae"})

func init() { i := A_arbace_a2g_code__init_A_class.Info(); i.IsInstance = A_arbace_a2g_code__init_A_InstanceOf; i.Init = A_arbace_a2g_code__init_A_Init; i.Table = A_arbace_a2g_code__init_A_members; jrt.RegisterGoType(A_arbace_a2g_code__init_A_class, reflect.TypeFor[A_arbace_a2g_code__init_A]()) }
