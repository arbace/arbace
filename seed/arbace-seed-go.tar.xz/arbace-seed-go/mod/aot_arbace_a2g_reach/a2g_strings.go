//line a2g_strings.ae:1
package aot_arbace_a2g_reach

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmyn17,arbace.a2g.accessyn3,accyn14,arbace.a2g.jrtyn3,jrtyn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn2,opkn4,ctorkn4,tempkn7,restartkn5,framekn6,methodkn5,fieldkn3,samkn5,scopekn8,boundarykn3,varkn6,hiddenkn1,bkn11,sel-bindingkn4,elsekn8,accessorkn7,patternys11,arbace.core6,if-letyn20,h__214000044__auto__kn3,tagyn13,java.util.Mapys11,arbace.core3,getys16,arbace.a2g.reach4,*cx*ys11,arbace.core3,letyn20,k__214000045__auto__yn20,v__214000046__auto__yn4,.getys11,arbace.core4,condys11,arbace.core10,identical?ys16,arbace.a2g.reach4,noneys11,arbace.core5,some?yn4,.putyn2,ifys11,arbace.core4,nil?kn6,superskn9,supers-ofkn10,interface?kn9,subclass?kn10,super-implkn8,ext-keyskn12,desc-classeskn6,hw-yeskn7,methodskn4,namekn4,desckn5,superkn11,unavailablekn3,jrtkn5,funcskn4,varskn6,constskn15,analysis-failedkn1,Tkn14,failed-classeskn7,standinkn5,statekn5,outerkn10,interfaceskn7,missingkn2,jckn7,reachedkn5,queuekn6,initedkn9,vcalls-bykn4,instkn7,inst-bykn6,vcallskn10,lambda-fiskn6,statickn7,handleskn2,vhkn8,declarerkn5,ownerkn4,kindkn10,get-statickn6,targetkn6,switchkn4,castkn9,new-arraykn9,get-fieldkn9,ctor-callkn11,if-instancekn5,classkn5,compskn4,typekn8,java-strkn4,nodekn8,for-eachkn5,arraykn5,partskn4,nullkn9,class-litkn9,instance?kn10,array-initkn10,method-refkn5,boundkn3,newkn7,unboundkn2,fikn3,trykn6,lambdakn7,catcheskn7,classeskn9,set-fieldkn7,markerskn10,var-invokekn10,fi-adapterkn9,var-derefkn4,argskn7,invokerkn12,invoker-desckn10,set-statickn6,invokekn11,array-clonekn9,interfacekn7,specialkn7,virtualkn6,assertkn8,msg-desckn5,caseskn6,labelskn2,gokn6,bodieskn6,clinitkn8,prologuekn11,calls-superkn4,initkn4,callkn4,bodykn11,uses-assertkn16,interface-assertkn7,derivedkn16,record-canonicalkn12,default-ctorkn6,bridgekn9,bridge-ofkn9,anon-ctorkn10,clj-constskn4,readkn20,record-object-methodkn10,componentskn5,rootskn11,instantiatekn6,slice?kn3,fiskn2,cxkn11,jrt-classesv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.a2g.reachm2,R20,s544,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).v11,arbace.core13,*loaded-libs*v11,arbace.core4,map?v11,arbace.core9,contains?R21,v11,arbace.core3,seqv11,arbace.core3,notv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstS13,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core10,chunk-restS13,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core4,nextv16,arbace.a2g.reach5,node?v11,arbace.core11,sequential?R35,S5,R22,R25,R29,R36,R33,S1,R37,S5,R22,R25,R29,R36,R33,S1,R37,v11,arbace.core6,concatv11,arbace.core4,listR38,v11,arbace.core5,applyv11,arbace.core6,vectorv11,arbace.core9,with-metaR39,v11,arbace.core8,hash-mapR40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R44,R52,R53,R54,R50,v11,arbace.core4,intov11,arbace.core12,chunk-bufferv11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restV8,R55,R56,R57,R58,R59,R60,R61,R62,v16,arbace.a2g.reach4,*cx*R55,v16,arbace.a2g.reach4,nonev11,arbace.core5,some?v18,arbace.classes.env14,all-supertypesR57,v18,arbace.classes.env10,interface?R58,v18,arbace.classes.env9,subclass?v16,arbace.a2g.reach16,*methods-by-key*v11,arbace.core4,someR63,v18,arbace.classes.env4,infoR64,R65,v16,arbace.a2g.reach14,find-method-ofv16,arbace.a2g.model7,static?v16,arbace.a2g.model11,abstract-m?v16,arbace.a2g.reach5,body?v16,arbace.a2g.reach10,super-implv16,arbace.a2g.model8,private?R66,R59,v11,arbace.core6,filterv16,arbace.a2g.reach10,all-supersv11,arbace.core4,not=v16,arbace.a2g.reach10,interface?v16,arbace.a2g.reach9,subclass?v16,arbace.a2g.reach9,*current*v11,arbace.core5,swap!R67,v16,arbace.a2g.reach4,*st*v11,arbace.core6,updatev11,arbace.core4,fnilv16,arbace.a2g.model7,go-namev16,arbace.a2g.names11,method-baseR68,v16,arbace.a2g.model3,*w*v16,arbace.a2g.model11,a2g-static?R69,R70,v16,arbace.a2g.names17,static-field-nameR71,v16,arbace.a2g.model9,jrt-classv16,arbace.a2g.model13,translatable?v22,arbace.classes.analyze4,declR72,v16,arbace.a2g.reach4,use!v11,arbace.core19,pop-thread-bindingsv16,arbace.a2g.model22,reflectable-interface?R73,R74,v16,arbace.a2g.reach17,note-unavailable!R75,v16,arbace.a2g.reach8,*slice?*R76,v11,arbace.core5,assocv11,arbace.core20,push-thread-bindingsv11,arbace.core4,disjR77,R78,R79,v13,arbace.string7,replaceR80,v11,arbace.core6,reducev16,arbace.a2g.reach4,use*v11,arbace.core7,string?R61,v16,arbace.a2g.model12,desc-classesv16,arbace.a2g.reach12,desc-classesR81,R82,v16,arbace.a2g.reach6,reach*R83,v16,arbace.a2g.reach5,init*R60,v11,arbace.core3,vecv16,arbace.a2g.reach17,own-external-keysR56,R84,v16,arbace.a2g.reach13,supertypes-ofv16,arbace.a2g.reach12,java-impl-ofv16,arbace.a2g.reach13,external-keysv16,arbace.a2g.reach12,reach-impls!R85,R86,v16,arbace.a2g.reach12,instantiate*R87,R88,v16,arbace.a2g.reach6,vcall*R62,v16,arbace.a2g.model17,hw-method-exists?v16,arbace.a2g.model13,hand-written?R89,v16,arbace.a2g.reach14,hw-has-static?v16,arbace.a2g.reach17,hw-method-exists?v16,arbace.a2g.model9,in-world?R90,R91,R92,R93,v11,arbace.core8,to-arrayR94,S5,s9,fullFences13,loadLoadFences12,releaseFences15,storeStoreFences12,acquireFencev17,arbace.a2g.access8,unaccessR95,v16,arbace.a2g.reach9,vh-const?R96,R27,R97,R98,v16,arbace.a2g.reach9,use-desc!R99,R100,R101,v16,arbace.a2g.reach6,reach!R102,R103,R104,v16,arbace.a2g.reach6,vcall!R36,R37,R105,R106,R107,v22,arbace.classes.analyze10,value-typev20,arbace.classes.types4,ref?R22,R108,R109,R110,R111,v20,arbace.classes.types6,array?v20,arbace.classes.types14,desc->internalR112,R113,R114,R115,R116,R117,v16,arbace.a2g.reach12,instantiate!R118,v16,arbace.a2g.reach7,lambda!R119,v16,arbace.a2g.reach5,init!R120,v16,arbace.a2g.names8,new-nameR121,R122,R123,R124,R125,R126,R127,v20,arbace.classes.types10,lang-classR128,v20,arbace.classes.types11,method-descv11,arbace.core6,repeatR129,v16,arbace.a2g.reach10,walk-nodesR130,R131,R132,R133,R26,R134,v16,arbace.a2g.reach8,vh-call?R135,v16,arbace.a2g.reach14,check-hw-call!R136,R137,v16,arbace.a2g.reach13,hw-has-field?v16,arbace.a2g.model19,method-desc-classesR138,R139,R140,R141,v16,arbace.a2g.reach5,uses!R142,v16,arbace.a2g.names13,go-class-namev16,arbace.a2g.reach10,scan-node!v16,arbace.a2g.reach9,hw-owner?v11,arbace.core9,reduce-kvv16,arbace.a2g.reach11,scanned-opsv16,arbace.a2g.reach12,skipped-keysv16,arbace.a2g.reach18,skipped-plain-keysv11,arbace.core4,mapvv16,arbace.a2g.reach9,plan-nodev16,arbace.a2g.reach13,scanned-nodesv16,arbace.a2g.reach6,*flat*v11,arbace.core4,run!R143,R144,R145,R146,R147,R148,R149,R150,R151,R152,R153,R154,R155,R156,R157,v16,arbace.a2g.reach10,scan-code!R158,R31,R159,v20,arbace.classes.types9,lang-descR160,R161,v16,arbace.a2g.reach11,method-codeR162,R163,R164,R165,v11,arbace.core4,atomR166,v16,arbace.a2g.reach10,new-cachesR167,S2,s6,<init>s8,<clinit>v16,arbace.a2g.model11,find-methodS2,s6,<init>s8,<clinit>v11,arbace.core6,reset!v16,arbace.a2g.model8,par-mapvv11,arbace.core6,secondv16,arbace.a2g.model4,jobsv16,arbace.a2g.reach9,plan-codev16,arbace.a2g.reach12,scan-method!v11,arbace.core10,constantly")

var Lit_1 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_2 *jrt.String = jrt.Intern("arbace.a2g.reach$check_hw_call_BANG_$fn__214000204")

var Lit_3 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_4 *jrt.String = jrt.Intern(".")

var Lit_5 *jrt.String = jrt.Intern("/")

var Lit_6 *jrt.String = jrt.Intern("arbace.a2g.reach$find_method_of$fn__214000071")

var Lit_7 *jrt.String = jrt.Intern("_")

var Lit_8 *jrt.String = jrt.Intern("<clinit>")

var Lit_9 *jrt.String = jrt.Intern("()V")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000083")

var Lit_11 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000085")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000085$fn__214000086")

var Lit_13 *jrt.String = jrt.Intern("<init>")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.reach$new_caches$iter__214000052__214000056")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.reach$new_caches$iter__214000052__214000056$fn__214000057")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.reach$new_caches$iter__214000052__214000056$fn__214000057$fn__214000058")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys$iter__214000128__214000132")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys$iter__214000138__214000142")

var Lit_19 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys$iter__214000128__214000132$fn__214000133")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys$iter__214000128__214000132$fn__214000133$fn__214000134")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys$iter__214000138__214000142$fn__214000143")

var Lit_22 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys$iter__214000138__214000142$fn__214000143$fn__214000144")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000291")

var Lit_24 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000293")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000295")

var Lit_26 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000297")

var Lit_27 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000299")

var Lit_28 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000301")

var Lit_29 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000303")

var Lit_30 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000305")

var Lit_31 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000307")

var Lit_32 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000309")

var Lit_33 *jrt.String = jrt.Intern("L")

var Lit_34 *jrt.String = jrt.Intern(";")

var Lit_35 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$pre__214000311")

var Lit_36 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000314")

var Lit_37 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000316")

var Lit_38 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000318")

var Lit_39 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000320")

var Lit_40 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000322")

var Lit_41 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000324")

var Lit_42 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_43 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000326")

var Lit_44 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000328")

var Lit_45 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000330")

var Lit_46 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000332")

var Lit_47 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000334")

var Lit_48 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node$fn__214000336")

var Lit_49 *jrt.String = jrt.Intern("jrt lacks static field ")

var Lit_50 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_51 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000415")

var Lit_52 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000415$iter__214000438__214000444")

var Lit_53 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000415$iter__214000438__214000444$fn__214000445")

var Lit_54 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000415$iter__214000438__214000444$fn__214000445$iter__214000440__214000446")

var Lit_55 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000415$iter__214000438__214000444$fn__214000445$iter__214000440__214000446$fn__214000447")

var Lit_56 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000415$iter__214000438__214000444$fn__214000445$iter__214000440__214000446$fn__214000447$fn__214000448")

var Lit_57 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_code_BANG_$fn__214000353")

var Lit_58 *jrt.String = jrt.Intern("analysis failed: ")

var Lit_59 *jrt.String = jrt.Intern("RT")

var Lit_60 *jrt.String = jrt.Intern("var")

var Lit_61 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/String;)")

var Lit_62 *jrt.String = jrt.Intern("Var")

var Lit_63 *jrt.String = jrt.Intern("readString")

var Lit_64 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/lang/Object;")

var Lit_65 *jrt.String = jrt.Intern("hashCode")

var Lit_66 *jrt.String = jrt.Intern("()I")

var Lit_67 *jrt.String = jrt.Intern("equals")

var Lit_68 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_69 *jrt.String = jrt.Intern("toString")

var Lit_70 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_71 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_72 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_73 *jrt.String = jrt.Intern("hasNext")

var Lit_74 *jrt.String = jrt.Intern("()Z")

var Lit_75 *jrt.String = jrt.Intern("next")

var Lit_76 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_77 *jrt.String = jrt.Intern("deref")

var Lit_78 *jrt.String = jrt.Intern("getRawRoot")

var Lit_79 *jrt.String = jrt.Intern("IFn")

var Lit_80 *jrt.String = jrt.Intern("invoke")

var Lit_81 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_82 *jrt.String = jrt.Intern("FnInvokers")

var Lit_83 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$fn__214000233")

var Lit_84 *jrt.String = jrt.Intern("java/lang/AssertionError")

var Lit_85 *jrt.String = jrt.Intern("(")

var Lit_86 *jrt.String = jrt.Intern(")V")

var Lit_87 *jrt.String = jrt.Intern("")

var Lit_88 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000246")

var Lit_89 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000264")

var Lit_90 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000270")

var Lit_91 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000276")

var Lit_92 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000282")

var Lit_93 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes$walk__214000339")

var Lit_94 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes$walk_entry__214000341")

var Lit_95 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes$walk_val__214000343")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes$walk_elem__214000345")

var Lit_97 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes$walk_plain__214000347")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes$walk_plain_entry__214000349")

var Lit_99 *jrt.String = jrt.Intern("arbace.a2g.reach$super_impl$f__214000075")

var Lit_100 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of$fn__214000163")

var Lit_101 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of$fn__214000165")

var Lit_102 *jrt.String = jrt.Intern("class ")

var Lit_103 *jrt.String = jrt.Intern(": ")

var Lit_104 *jrt.String = jrt.Intern(" failed analysis")

var Lit_105 *jrt.String = jrt.Intern("<class>")

var Lit_106 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000093")

var Lit_107 *jrt.String = jrt.Intern("superclass ")

var Lit_108 *jrt.String = jrt.Intern(" unavailable")

var Lit_109 *jrt.String = jrt.Intern(": superclass ")

var Lit_110 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000099")

var Lit_111 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000101")

var Lit_112 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000103")

var Lit_113 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000109")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000111")

var Lit_115 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_116 *jrt.String = jrt.Intern("arbace.a2g.reach$uses_BANG_$fn__214000115")

var Lit_117 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_118 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_119 *jrt.String = jrt.Intern("lookup")

var Lit_120 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk__214000013")

var Lit_121 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk_val__214000025")

var Lit_122 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk_plain__214000031")

var Lit_123 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn1,fyn4,nodekn7,dynamickn7,privateyn1,cyn1,kyn4,expryn1,nyn1,ayn1,bkn3,tagyn4,nameyn4,descyn2,mmkn2,asyn3,whykn8,declaredyn3,clsyn5,fnameyn7,static?yn2,styn2,csyn1,dyn1,syn2,ndyn1,oyn2,fiyn5,owneryn4,kindkn9,var-derefkn10,array-initkn10,set-statickn10,method-refkn6,lambdakn3,newkn9,get-fieldkn4,castkn9,instance?kn9,class-litkn6,assertkn10,fi-adapterkn9,set-fieldkn9,ctor-callkn11,if-instancekn9,new-arraykn10,get-statickn10,var-invokekn6,invokekn3,trykn8,java-strkn8,for-eachkn6,switchkn4,ctorkn4,tempkn7,restartkn5,framekn6,methodkn5,fieldkn3,samkn5,scopekn8,boundarykn3,varkn6,hiddenkn1,bkn11,sel-bindingkn8,accessorkn4,keysyn5,rootsyn11,instantiateyn7,classesyn6,slice?yn3,fisyn5,statev11,arbace.core5,in-nsMyn16,arbace.a2g.reachm2,R0,s544,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).m2,R0,s544,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).R1,v16,arbace.a2g.reach5,node?m8,R2,L1,V1,R3,R4,i21,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,walk-nodesm10,R2,L1,V2,R7,R8,R0,s144,Calls (f node) on node and every node in it (operands, branches, bindings, cases, catches,\n  lambda bodies, patterns), each once, parents first.R4,i23,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach4,*cx*m10,R9,TR4,i49,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s284,The run's caches of answers that depend only on the class environment and the world, which\n  do not change once the world is loaded (the supertypes, the superclass bodies of a method, the\n  classes a descriptor names, ...): {name java.util.HashMap}, kept with the state (run), or nil.v16,arbace.a2g.reach4,nonem10,R10,TR4,i55,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s13,A cached nil.v16,arbace.a2g.reach6,cachedm12,R10,TR2,L1,V3,R11,R12,R13,R0,s111,The value of expr for key k in the run's cache named c (*cx*), computed once; expr itself\n  without the caches.R4,i59,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,new-cachesm10,R10,TR2,L1,V0,R4,i71,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,all-supersm12,R10,TR2,L1,V1,R14,R0,s27,env/all-supertypes, cached.R4,i75,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,interface?m10,R10,TR2,L1,V1,R14,R4,i80,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,subclass?m12,R10,TR2,L1,V2,R15,R16,R0,s22,env/subclass?, cached.R4,i82,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach16,*methods-by-key*m12,R17,C17,java.util.HashMapR9,TR4,i93,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s247,Class -> {[name desc] method} of its methods in env/info's order (the first of a key), for\n  java-impl-of's lookups in a run (instead of a scan of the class's methods each; the class\n  environment does not change once the world is loaded), or nil.v16,arbace.a2g.reach14,find-method-ofm12,R10,TR2,L2,V3,R11,R18,R19,V4,R11,R18,R19,R12,R0,s72,The first method [name desc] of class c (k, when given, is [name desc]).R4,i99,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach5,body?m10,R10,TR2,L1,V1,R20,R4,i114,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,super-implm12,R10,TR2,L1,V2,R11,R12,R0,s187,The first class of the superclass chain from c with a body of method k ([name desc]) that is\n  not private (cached per class and key: the chains of many classes share their superclasses).R4,i116,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,java-impl-ofm10,R2,L1,V2,R14,V4,R18,R19,R21,R12,R0,s366,The [class name desc] implementing virtual method [name desc] for class n (a body in n or a\n  superclass, else an interface's default), by Java's rules on the class environment: the first\n  class of n's superclass chain with a body of it (private only in n itself), else the first,\n  in env/all-supertypes' order, of the most specific interfaces of n with a default.R4,i133,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach4,*st*m8,R9,TR4,i152,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach8,*slice?*v11,arbace.core10,constantlym10,R9,TR4,i153,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s122,Whether a class's code may be translated in this run (classes outside the slice exist as\n  declarations with stub bodies).v16,arbace.a2g.reach9,*current*m8,R9,TR4,i157,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach17,note-unavailable!m10,R10,TR2,L1,V1,R22,R4,i159,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach4,use!m8,R23,TR4,i163,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach5,init!m8,R23,TR4,i163,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,reach!m8,R23,TR4,i163,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,vcall!m8,R23,TR4,i163,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,instantiate!m8,R23,TR4,i163,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach14,hw-has-static?m10,R10,TR2,L1,V3,R24,R18,R19,R4,i165,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,hw-has-field?m10,R10,TR2,L1,V3,R24,R25,R26,R4,i172,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V1,R14,R0,s161,Makes class n exist in Go (translating it when it can and jrt does not provide it, or jrt\n  provides only a stand-in). Returns false, noting why, when it cannot.R4,i180,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach4,use*m12,R10,TR2,L1,V2,R27,R14,R0,s137,use! in the run whose state is st: at once for a class already translated or jrt's own (not a\n  stand-in) that has not failed, else use!.R4,i223,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach5,uses!m12,R10,TR2,L1,V2,R27,R28,R0,s35,use* of each class of cs, in order.R4,i236,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,desc-classesm12,R10,TR2,L1,V1,R29,R0,s36,m/desc-classes, cached for a string.R4,i241,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,use-desc!m10,R10,TR2,L1,V1,R29,R4,i246,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,reach*m12,R10,TR2,L1,V2,R27,R12,R0,s36,reach! in the run whose state is st.R4,i249,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V1,R12,R0,s65,Marks method [c name desc] reached (its body will be translated).R4,i257,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach5,init*m12,R10,TR2,L1,V2,R27,R11,R0,s35,init! in the run whose state is st.R4,i262,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V1,R11,R0,s81,Class c is initialized: its static initializer is reached (and its superclass's).R4,i270,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach17,own-external-keysm12,R10,TR2,L1,V1,R30,R0,s174,The virtual methods of type s that jrt's own code may call when s is Object, a hand-written\n  class or interface of jrt or a class jrt has a stand-in for, else none (cached).R4,i275,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,external-keysm12,R10,TR2,L1,V1,R29,R0,s230,The virtual methods of class d's supertypes that jrt's own code may call: those of Object,\n  of jrt's hand-written classes and interfaces and of the classes jrt has stand-ins for; each\n  once, in the order of its first occurrence.R4,i286,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,supertypes-ofm12,R10,TR2,L1,V1,R29,R0,s89,The types class d is a subtype of (env/subclass?): d, its supertypes and Object (cached).R4,i297,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,reach-impls!m12,R10,TR2,L1,V2,R27,R29,R0,s264,Reaches the implementations for class d of the virtual calls whose receiver's static type is\n  a supertype of d (indexed by receiver type: the roots of --program are each a virtual call,\n  about 20,000), then of the methods jrt's own code may call (external-keys).R4,i304,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,instantiate*m12,R10,TR2,L1,V2,R27,R29,R0,s42,instantiate! in the run whose state is st.R4,i315,R5,i1,R6,s19,arbace/a2g/reach.aem8,R2,L1,V1,R29,R4,i324,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,vcall*m12,R10,TR2,L1,V3,R27,R12,R31,R0,s72,vcall! in the run whose state is st, of k [o name desc], nd [name desc].R4,i328,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V3,R32,R18,R19,R0,s61,A virtual call of [name desc] on a receiver of static type o.R4,i341,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach7,lambda!m10,R2,L1,V1,R33,R0,s135,A lambda or method reference of functional interface fi: its adapter is an instance of fi,\n  whose default methods virtual calls reach.R4,i346,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach17,hw-method-exists?m12,R10,TR2,L1,V2,R14,R20,R0,s181,m/hw-method-exists? of class n and method mm; its yes for a class not translated kept (jrt's\n  Go name of the class and its scan do not change, and what a2g adds only grows with T).R4,i355,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach14,check-hw-call!m12,R10,TR2,L1,V4,R34,R18,R19,R35,R0,s65,A call of a method of jrt's hand-written class: jrt must have it.R4,i368,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,vh-const?m12,R10,TR2,L1,V1,R7,R0,s61,Is field f a constant VarHandle of the world (A2G-SPEC §8.5)?R4,i382,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach8,vh-call?m12,R10,TR2,L1,V1,R8,R0,s177,A VarHandle call a2g compiles statically (A2G-SPEC §8.5): a fence, MethodHandles.lookup(),\n  or an access mode on a constant handle; it names no class of java.lang.invoke in Go.R4,i387,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,scan-node!m10,R10,TR2,L1,V1,R8,R4,i399,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,*flat*m12,R17,C25,java.util.IdentityHashMapR9,TR4,i506,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s181,Node -> the plans of the nodes in it scan-node! acts on, in walk-nodes' order (plan-code: the\n  run's batches of methods planned in parallel ahead of their sequential scan), or nil.v16,arbace.a2g.reach11,scanned-opsS23,R36,R37,R38,R39,R40,R41,R42,R43,R44,R45,R46,R47,R48,R49,R50,R51,R52,R53,R54,R55,R56,R57,R58,m10,R10,TR4,i511,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s90,The ops scan-node! acts on (an accessor's call, an :invoke, may stand for a field access).v16,arbace.a2g.reach9,hw-owner?m12,R10,TR2,L1,V1,R11,R0,s74,Can a call of a method of class c need check-hw-call! (does jrt define c)?R4,i517,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,plan-nodem12,R10,TR2,L1,V1,R8,R0,s496,scan-node! of node as a function of the run's state st, its answers that depend only on the\n  class environment and the world (which do not change during the run) computed ahead: the\n  descriptors' classes, the keys, the accessor's node, whether jrt defines a member. Pure: the\n  plans of a batch are made in parallel (no cache of the run: *cx* is one thread's), then run\n  one after another, each doing what scan-node! does, in the same order. The common ops; the\n  others run scan-node! itself.R4,i522,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,skipped-keysS13,R59,R60,R61,R62,R63,R64,R65,R66,R67,R68,R69,R70,R71,m10,R10,TR4,i611,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s49,The keys of a node walk-nodes does not walk into.v16,arbace.a2g.reach18,skipped-plain-keysS5,R59,R62,R66,R72,R70,m10,R10,TR4,i615,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s93,The keys of a plain map in a node (a catch, a case, a pattern) walk-nodes does not walk into.v16,arbace.a2g.reach13,scanned-nodesm12,R10,TR2,L1,V1,R8,R0,s201,The nodes of node scan-node! acts on, in walk-nodes' order (its walk, with reduce-kv and\n  reduce rather than seqs of the maps' entries: a map's kv-reduce visits its entries in the\n  order of its seq).R4,i619,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,plan-codem12,R10,TR2,L1,V1,R8,R0,s72,The plans of the nodes of node scan-node! acts on, in walk-nodes' order.R4,i650,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,scan-code!m8,R2,L1,V1,R8,R4,i655,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach11,method-codem10,R2,L1,V1,V3,R11,R18,R19,R0,s83,The analyzed code of method [c name desc] of a translated class: a vector of nodes.R4,i661,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,scan-method!m10,R10,TR2,L1,V1,V5,R11,R18,R19,R21,R12,R4,i673,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach3,runm10,R2,L1,V1,m2,R73,V6,R74,R75,R76,R77,R78,R79,R0,s478,Reachability from roots (method keys [class name desc]; classes to instantiate\n  :instantiate; functional interfaces with adapters :fis). Returns {:T #{} :reached #{} :inst #{} :unavailable {k #{why}} :missing {}\n  :state st}. With :state, a previous run's st, the run goes on from where that one ended:\n  reachability is monotone, so a run from more roots is the previous one continued from the\n  new ones (standalone S6: main's stand-in loop runs the closure once, not twice).R4,i712,R5,i1,R6,s19,arbace/a2g/reach.ae")

var Lit_124 *jrt.String = jrt.Intern("arbace.a2g.reach$eval214000004$loading__1927001464__auto____214000005")

var Lit_125 *jrt.String = jrt.Intern("arbace.a2g.reach$eval214000008$fn__214000009")

var Lit_126 *jrt.String = jrt.Intern("arbace.a2g.reach$node_QMARK_")

var Lit_127 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes")

var Lit_128 *jrt.String = jrt.Intern("arbace.a2g.reach$cached")

var Lit_129 *jrt.String = jrt.Intern("arbace.a2g.reach$new_caches")

var Lit_130 *jrt.String = jrt.Intern("arbace.a2g.reach$all_supers")

var Lit_131 *jrt.String = jrt.Intern("arbace.a2g.reach$interface_QMARK_")

var Lit_132 *jrt.String = jrt.Intern("arbace.a2g.reach$subclass_QMARK_")

var Lit_133 *jrt.String = jrt.Intern("arbace.a2g.reach$find_method_of")

var Lit_134 *jrt.String = jrt.Intern("arbace.a2g.reach$body_QMARK_")

var Lit_135 *jrt.String = jrt.Intern("arbace.a2g.reach$super_impl")

var Lit_136 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of")

var Lit_137 *jrt.String = jrt.Intern("arbace.a2g.reach$note_unavailable_BANG_")

var Lit_138 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_has_static_QMARK_")

var Lit_139 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_has_field_QMARK_")

var Lit_140 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_")

var Lit_141 *jrt.String = jrt.Intern("arbace.a2g.reach$use_STAR_")

var Lit_142 *jrt.String = jrt.Intern("arbace.a2g.reach$uses_BANG_")

var Lit_143 *jrt.String = jrt.Intern("arbace.a2g.reach$desc_classes")

var Lit_144 *jrt.String = jrt.Intern("arbace.a2g.reach$use_desc_BANG_")

var Lit_145 *jrt.String = jrt.Intern("arbace.a2g.reach$reach_STAR_")

var Lit_146 *jrt.String = jrt.Intern("arbace.a2g.reach$reach_BANG_")

var Lit_147 *jrt.String = jrt.Intern("arbace.a2g.reach$init_STAR_")

var Lit_148 *jrt.String = jrt.Intern("arbace.a2g.reach$init_BANG_")

var Lit_149 *jrt.String = jrt.Intern("arbace.a2g.reach$own_external_keys")

var Lit_150 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys")

var Lit_151 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of")

var Lit_152 *jrt.String = jrt.Intern("arbace.a2g.reach$reach_impls_BANG_")

var Lit_153 *jrt.String = jrt.Intern("arbace.a2g.reach$instantiate_STAR_")

var Lit_154 *jrt.String = jrt.Intern("arbace.a2g.reach$instantiate_BANG_")

var Lit_155 *jrt.String = jrt.Intern("arbace.a2g.reach$vcall_STAR_")

var Lit_156 *jrt.String = jrt.Intern("arbace.a2g.reach$vcall_BANG_")

var Lit_157 *jrt.String = jrt.Intern("arbace.a2g.reach$lambda_BANG_")

var Lit_158 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_method_exists_QMARK_")

var Lit_159 *jrt.String = jrt.Intern("arbace.a2g.reach$check_hw_call_BANG_")

var Lit_160 *jrt.String = jrt.Intern("arbace.a2g.reach$vh_const_QMARK_")

var Lit_161 *jrt.String = jrt.Intern("arbace.a2g.reach$vh_call_QMARK_")

var Lit_162 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_")

var Lit_163 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_owner_QMARK_")

var Lit_164 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_node")

var Lit_165 *jrt.String = jrt.Intern("arbace.a2g.reach$scanned_nodes")

var Lit_166 *jrt.String = jrt.Intern("arbace.a2g.reach$plan_code")

var Lit_167 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_code_BANG_")

var Lit_168 *jrt.String = jrt.Intern("arbace.a2g.reach$method_code")

var Lit_169 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_method_BANG_")

var Lit_170 *jrt.String = jrt.Intern("arbace.a2g.reach$run")
