//line a2g_strings.ae:1
package aot_arbace_a2g_reach

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn13,arbace.stringkn2,asyn3,stryn20,arbace.classes.typesyn1,tyn18,arbace.classes.envyn3,envyn22,arbace.classes.analyzeyn1,ayn16,arbace.a2g.modelyn1,myn16,arbace.a2g.namesyn2,nmyn17,arbace.a2g.accessyn3,accyn14,arbace.a2g.jrtyn3,jrtyn22,arbace.classes.opcodesyn7,Opcodeskn3,dockn2,opkn4,ctorkn4,tempkn7,restartkn5,framekn6,methodkn5,fieldkn3,samkn5,scopekn8,boundarykn3,varkn6,hiddenkn1,bkn11,sel-bindingkn4,elsekn8,accessorkn7,patternkn4,namekn4,desckn7,methodskn5,superkn11,unavailablekn3,jrtkn5,funcskn4,varskn6,constskn15,analysis-failedkn14,failed-classeskn7,standinkn5,statekn1,Tkn5,outerkn10,interfaceskn7,missingkn7,reachedkn5,queuekn6,initedkn9,vcalls-bykn4,instkn7,inst-bykn6,vcallskn10,lambda-fiskn6,statickn7,handleskn2,vhkn8,declarerkn5,ownerkn4,kindkn10,get-statickn6,targetkn6,switchkn4,castkn9,new-arraykn9,get-fieldkn9,ctor-callkn11,if-instancekn5,classkn5,compskn4,typekn8,java-strkn4,nodekn8,for-eachkn5,arraykn5,partskn4,nullkn9,class-litkn9,instance?kn10,array-initkn10,method-refkn5,boundkn3,newkn7,unboundkn2,fikn3,trykn6,lambdakn7,catcheskn7,classeskn9,set-fieldkn7,markerskn10,var-invokekn10,fi-adapterkn9,var-derefkn4,argskn7,invokerkn12,invoker-desckn10,set-statickn6,invokekn11,array-clonekn9,interfacekn7,specialkn7,virtualkn6,assertkn8,msg-desckn5,caseskn6,labelskn6,bodieskn6,clinitkn8,prologuekn11,calls-superkn4,initkn4,callkn4,bodykn11,uses-assertkn16,interface-assertkn7,derivedkn16,record-canonicalkn12,default-ctorkn6,bridgekn9,bridge-ofkn9,anon-ctorkn10,clj-constskn4,readkn20,record-object-methodkn10,componentskn5,rootskn11,instantiatekn6,slice?kn3,fisv11,arbace.core7,requirev11,arbace.core5,referR0,V3,R1,R2,R3,V3,R4,R2,R5,V3,R6,R2,R7,V3,R8,R2,R9,V3,R10,R2,R11,V3,R12,R2,R13,V3,R14,R2,R15,V3,R16,R2,R17,V3,R18,R2,R19,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.a2g.reachm2,R20,s544,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).v11,arbace.core13,*loaded-libs*v11,arbace.core4,map?v11,arbace.core9,contains?R21,v11,arbace.core3,seqv11,arbace.core3,notv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core5,firstS13,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core10,chunk-restS13,R22,R23,R24,R25,R26,R27,R28,R29,R30,R31,R32,R33,R34,v11,arbace.core4,nextv16,arbace.a2g.reach5,node?v11,arbace.core11,sequential?R35,S5,R22,R25,R29,R36,R33,S1,R37,S5,R22,R25,R29,R36,R33,S1,R37,v11,arbace.core4,somev11,arbace.core12,chunk-bufferv11,arbace.core4,not=v18,arbace.classes.env10,interface?R38,R39,R40,v18,arbace.classes.env4,infov16,arbace.a2g.model11,abstract-m?v16,arbace.a2g.model7,static?v16,arbace.a2g.model8,private?v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core4,consv11,arbace.core5,chunkv11,arbace.core4,restv11,arbace.core6,removev11,arbace.core10,take-whilev11,arbace.core5,some?v11,arbace.core7,iterateR41,v18,arbace.classes.env14,all-supertypesv18,arbace.classes.env9,subclass?v16,arbace.a2g.reach9,*current*v11,arbace.core5,swap!R42,v16,arbace.a2g.reach4,*st*v11,arbace.core6,updatev11,arbace.core4,fnilv16,arbace.a2g.model7,go-namev16,arbace.a2g.names11,method-baseR43,v16,arbace.a2g.model3,*w*v16,arbace.a2g.model11,a2g-static?R44,R45,v16,arbace.a2g.names17,static-field-nameR46,v16,arbace.a2g.model11,translated?v16,arbace.a2g.model9,jrt-classv16,arbace.a2g.model13,translatable?v22,arbace.classes.analyze4,declR47,v16,arbace.a2g.reach4,use!v11,arbace.core19,pop-thread-bindingsv16,arbace.a2g.model22,reflectable-interface?R48,v16,arbace.a2g.reach17,note-unavailable!R49,v16,arbace.a2g.reach8,*slice?*R50,v11,arbace.core5,assocR51,v11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core4,disjR52,R53,R54,v13,arbace.string7,replacev16,arbace.a2g.model12,desc-classesR55,R56,v16,arbace.a2g.reach6,reach!R57,v16,arbace.a2g.reach5,init!v11,arbace.core6,concatv11,arbace.core3,vecR58,v16,arbace.a2g.reach13,supertypes-ofR59,R60,v16,arbace.a2g.reach9,vcalls-onv16,arbace.a2g.reach12,java-impl-ofv11,arbace.core8,distinctv16,arbace.a2g.reach13,external-keysR61,v11,arbace.core6,filterR62,v16,arbace.a2g.model13,hand-written?R63,v16,arbace.a2g.reach14,hw-has-static?v16,arbace.a2g.model17,hw-method-exists?v16,arbace.a2g.model9,in-world?R64,R65,R66,R67,v11,arbace.core8,to-arrayR68,S5,s9,fullFences13,loadLoadFences12,releaseFences15,storeStoreFences12,acquireFencev17,arbace.a2g.access8,unaccessR69,v16,arbace.a2g.reach9,vh-const?R70,R27,R71,R72,v16,arbace.a2g.reach9,use-desc!R73,R74,R75,R76,R77,R78,v16,arbace.a2g.reach6,vcall!R36,R37,R79,R80,R81,v22,arbace.classes.analyze10,value-typev20,arbace.classes.types4,ref?R22,R82,R83,R84,R85,v20,arbace.classes.types6,array?v20,arbace.classes.types14,desc->internalR86,R87,R88,R89,R90,R91,v16,arbace.a2g.reach12,instantiate!R92,v16,arbace.a2g.reach7,lambda!R93,R94,v16,arbace.a2g.names8,new-nameR95,R96,R97,R98,R99,R100,R101,v20,arbace.classes.types10,lang-classR102,v20,arbace.classes.types11,method-descv11,arbace.core6,repeatR103,v16,arbace.a2g.reach10,walk-nodesR104,R105,R106,R107,R26,R108,v16,arbace.a2g.reach8,vh-call?R109,v16,arbace.a2g.reach14,check-hw-call!R110,R111,v16,arbace.a2g.reach13,hw-has-field?v16,arbace.a2g.model19,method-desc-classesR112,R113,R114,R115,v16,arbace.a2g.reach10,scan-node!R116,R117,R118,R119,R120,R121,R122,v16,arbace.a2g.model11,find-methodR123,R124,R125,R126,R127,R128,R129,R130,v16,arbace.a2g.reach10,scan-code!R131,R31,R132,v20,arbace.classes.types9,lang-descR133,R134,v16,arbace.a2g.reach11,method-codeR135,R136,R137,R138,v11,arbace.core4,atomS2,s6,<init>s8,<clinit>S2,s6,<init>s8,<clinit>v16,arbace.a2g.reach12,scan-method!v11,arbace.core6,subvecl1,v11,arbace.core10,constantly")

var Lit_1 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_2 *jrt.String = jrt.Intern("arbace.a2g.reach$check_hw_call_BANG_$fn__214000181")

var Lit_3 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_4 *jrt.String = jrt.Intern(".")

var Lit_5 *jrt.String = jrt.Intern("/")

var Lit_6 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118")

var Lit_7 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119")

var Lit_8 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120")

var Lit_9 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120$fn__214000121")

var Lit_10 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120$fn__214000121$fn__214000122")

var Lit_11 *jrt.String = jrt.Intern("<init>")

var Lit_12 *jrt.String = jrt.Intern("_")

var Lit_13 *jrt.String = jrt.Intern("<clinit>")

var Lit_14 *jrt.String = jrt.Intern("()V")

var Lit_15 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000052")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000056")

var Lit_17 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000072")

var Lit_19 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000052$fn__214000053")

var Lit_20 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000072$fn__214000073")

var Lit_21 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063")

var Lit_22 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000064")

var Lit_23 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000068")

var Lit_24 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000064$fn__214000065")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000327")

var Lit_26 *jrt.String = jrt.Intern("analysis failed: ")

var Lit_27 *jrt.String = jrt.Intern("RT")

var Lit_28 *jrt.String = jrt.Intern("var")

var Lit_29 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/String;)")

var Lit_30 *jrt.String = jrt.Intern("Var")

var Lit_31 *jrt.String = jrt.Intern("readString")

var Lit_32 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/lang/Object;")

var Lit_33 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_34 *jrt.String = jrt.Intern("hashCode")

var Lit_35 *jrt.String = jrt.Intern("()I")

var Lit_36 *jrt.String = jrt.Intern("equals")

var Lit_37 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_38 *jrt.String = jrt.Intern("toString")

var Lit_39 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_40 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_41 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_42 *jrt.String = jrt.Intern("hasNext")

var Lit_43 *jrt.String = jrt.Intern("()Z")

var Lit_44 *jrt.String = jrt.Intern("next")

var Lit_45 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_46 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_47 *jrt.String = jrt.Intern("deref")

var Lit_48 *jrt.String = jrt.Intern("getRawRoot")

var Lit_49 *jrt.String = jrt.Intern("IFn")

var Lit_50 *jrt.String = jrt.Intern("invoke")

var Lit_51 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_52 *jrt.String = jrt.Intern("FnInvokers")

var Lit_53 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$fn__214000211")

var Lit_54 *jrt.String = jrt.Intern("jrt lacks static field ")

var Lit_55 *jrt.String = jrt.Intern("L")

var Lit_56 *jrt.String = jrt.Intern(";")

var Lit_57 *jrt.String = jrt.Intern("java/lang/AssertionError")

var Lit_58 *jrt.String = jrt.Intern("(")

var Lit_59 *jrt.String = jrt.Intern(")V")

var Lit_60 *jrt.String = jrt.Intern("")

var Lit_61 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000224")

var Lit_62 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000242")

var Lit_63 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000248")

var Lit_64 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000254")

var Lit_65 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000260")

var Lit_66 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of$fn__214000130")

var Lit_67 *jrt.String = jrt.Intern("class ")

var Lit_68 *jrt.String = jrt.Intern(": ")

var Lit_69 *jrt.String = jrt.Intern(" failed analysis")

var Lit_70 *jrt.String = jrt.Intern("<class>")

var Lit_71 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000080")

var Lit_72 *jrt.String = jrt.Intern("superclass ")

var Lit_73 *jrt.String = jrt.Intern(" unavailable")

var Lit_74 *jrt.String = jrt.Intern(": superclass ")

var Lit_75 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000086")

var Lit_76 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000088")

var Lit_77 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000090")

var Lit_78 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000096")

var Lit_79 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000098")

var Lit_80 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_81 *jrt.String = jrt.Intern("arbace.a2g.reach$vcall_BANG_$fn__214000168")

var Lit_82 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139")

var Lit_83 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140")

var Lit_84 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141")

var Lit_85 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141$fn__214000142")

var Lit_86 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141$fn__214000142$fn__214000143")

var Lit_87 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_88 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_89 *jrt.String = jrt.Intern("lookup")

var Lit_90 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk__214000013")

var Lit_91 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk_val__214000025")

var Lit_92 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk_plain__214000031")

var Lit_93 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn8,arglistsyn1,xkn4,linekn6,columnkn4,fileyn1,fyn4,nodeyn1,nyn4,nameyn4,desckn7,dynamickn7,privateyn3,whykn8,declaredyn3,clsyn5,fnameyn7,static?yn1,dyn1,ckn2,asyn1,kyn1,oyn2,fiyn5,owneryn4,kindkn4,keysyn5,rootsyn11,instantiateyn7,classesyn6,slice?yn3,fisyn5,statev11,arbace.core5,in-nsMyn16,arbace.a2g.reachm2,R0,s544,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).m2,R0,s544,Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).R1,v16,arbace.a2g.reach5,node?m8,R2,L1,V1,R3,R4,i21,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,walk-nodesm10,R2,L1,V2,R7,R8,R0,s144,Calls (f node) on node and every node in it (operands, branches, bindings, cases, catches,\n  lambda bodies, patterns), each once, parents first.R4,i23,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,java-impl-ofm10,R2,L1,V2,R9,V2,R10,R11,R0,s177,The [class name desc] implementing virtual method [name desc] for class n (a body in n or a\n  superclass, else an interface's default), by Java's rules on the class environment.R4,i49,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach4,*st*m8,R12,TR4,i69,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach8,*slice?*v11,arbace.core10,constantlym10,R12,TR4,i70,R5,i1,R6,s19,arbace/a2g/reach.aeR0,s122,Whether a class's code may be translated in this run (classes outside the slice exist as\n  declarations with stub bodies).v16,arbace.a2g.reach9,*current*m8,R12,TR4,i74,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach17,note-unavailable!m10,R13,TR2,L1,V1,R14,R4,i76,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach4,use!m8,R15,TR4,i80,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach5,init!m8,R15,TR4,i80,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,reach!m8,R15,TR4,i80,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach6,vcall!m8,R15,TR4,i80,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,instantiate!m8,R15,TR4,i80,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach14,hw-has-static?m10,R13,TR2,L1,V3,R16,R10,R11,R4,i82,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,hw-has-field?m10,R13,TR2,L1,V3,R16,R17,R18,R4,i89,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V1,R9,R0,s161,Makes class n exist in Go (translating it when it can and jrt does not provide it, or jrt\n  provides only a stand-in). Returns false, noting why, when it cannot.R4,i97,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,use-desc!m10,R13,TR2,L1,V1,R19,R4,i140,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V1,V5,R20,R10,R11,R21,R22,R0,s65,Marks method [c name desc] reached (its body will be translated).R4,i143,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V1,R20,R0,s81,Class c is initialized: its static initializer is reached (and its superclass's).R4,i150,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,external-keysm12,R13,TR2,L1,V1,R19,R0,s179,The virtual methods of class d's supertypes that jrt's own code may call: those of Object,\n  of jrt's hand-written classes and interfaces and of the classes jrt has stand-ins for.R4,i158,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,supertypes-ofm12,R13,TR2,L1,V1,R19,R0,s80,The types class d is a subtype of (env/subclass?): d, its supertypes and Object.R4,i168,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,vcalls-onm12,R13,TR2,L1,V1,R19,R0,s170,The virtual calls [name desc] whose receiver's static type is a supertype of d (indexed by\n  receiver type: the roots of --program are each a virtual call, about 20,000).R4,i174,R5,i1,R6,s19,arbace/a2g/reach.aem8,R2,L1,V1,R19,R4,i181,R5,i1,R6,s19,arbace/a2g/reach.aem10,R2,L1,V3,R23,R10,R11,R0,s61,A virtual call of [name desc] on a receiver of static type o.R4,i192,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach7,lambda!m10,R2,L1,V1,R24,R0,s135,A lambda or method reference of functional interface fi: its adapter is an instance of fi,\n  whose default methods virtual calls reach.R4,i203,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach14,check-hw-call!m12,R13,TR2,L1,V4,R25,R10,R11,R26,R0,s65,A call of a method of jrt's hand-written class: jrt must have it.R4,i214,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach13,class-of-descm10,R13,TR2,L1,V1,R19,R4,i227,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach9,vh-const?m12,R13,TR2,L1,V1,R7,R0,s61,Is field f a constant VarHandle of the world (A2G-SPEC §8.5)?R4,i229,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach8,vh-call?m12,R13,TR2,L1,V1,R8,R0,s177,A VarHandle call a2g compiles statically (A2G-SPEC §8.5): a fence, MethodHandles.lookup(),\n  or an access mode on a constant handle; it names no class of java.lang.invoke in Go.R4,i234,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,scan-node!m10,R13,TR2,L1,V1,R8,R4,i246,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach10,scan-code!m8,R2,L1,V1,R8,R4,i353,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach11,method-codem10,R2,L1,V1,V3,R20,R10,R11,R0,s83,The analyzed code of method [c name desc] of a translated class: a vector of nodes.R4,i355,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach12,scan-method!m10,R13,TR2,L1,V1,V5,R20,R10,R11,R21,R22,R4,i367,R5,i1,R6,s19,arbace/a2g/reach.aev16,arbace.a2g.reach3,runm10,R2,L1,V1,m2,R27,V6,R28,R29,R30,R31,R32,R33,R0,s478,Reachability from roots (method keys [class name desc]; classes to instantiate\n  :instantiate; functional interfaces with adapters :fis). Returns {:T #{} :reached #{} :inst #{} :unavailable {k #{why}} :missing {}\n  :state st}. With :state, a previous run's st, the run goes on from where that one ended:\n  reachability is monotone, so a run from more roots is the previous one continued from the\n  new ones (standalone S6: main's stand-in loop runs the closure once, not twice).R4,i406,R5,i1,R6,s19,arbace/a2g/reach.ae")

var Lit_94 *jrt.String = jrt.Intern("arbace.a2g.reach$eval214000004$loading__1927001464__auto____214000005")

var Lit_95 *jrt.String = jrt.Intern("arbace.a2g.reach$eval214000008$fn__214000009")

var Lit_96 *jrt.String = jrt.Intern("arbace.a2g.reach$node_QMARK_")

var Lit_97 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes")

var Lit_98 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of")

var Lit_99 *jrt.String = jrt.Intern("arbace.a2g.reach$note_unavailable_BANG_")

var Lit_100 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_has_static_QMARK_")

var Lit_101 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_has_field_QMARK_")

var Lit_102 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_")

var Lit_103 *jrt.String = jrt.Intern("arbace.a2g.reach$use_desc_BANG_")

var Lit_104 *jrt.String = jrt.Intern("arbace.a2g.reach$reach_BANG_")

var Lit_105 *jrt.String = jrt.Intern("arbace.a2g.reach$init_BANG_")

var Lit_106 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys")

var Lit_107 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of")

var Lit_108 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on")

var Lit_109 *jrt.String = jrt.Intern("arbace.a2g.reach$instantiate_BANG_")

var Lit_110 *jrt.String = jrt.Intern("arbace.a2g.reach$vcall_BANG_")

var Lit_111 *jrt.String = jrt.Intern("arbace.a2g.reach$lambda_BANG_")

var Lit_112 *jrt.String = jrt.Intern("arbace.a2g.reach$check_hw_call_BANG_")

var Lit_113 *jrt.String = jrt.Intern("arbace.a2g.reach$class_of_desc")

var Lit_114 *jrt.String = jrt.Intern("arbace.a2g.reach$vh_const_QMARK_")

var Lit_115 *jrt.String = jrt.Intern("arbace.a2g.reach$vh_call_QMARK_")

var Lit_116 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_")

var Lit_117 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_code_BANG_")

var Lit_118 *jrt.String = jrt.Intern("arbace.a2g.reach$method_code")

var Lit_119 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_method_BANG_")

var Lit_120 *jrt.String = jrt.Intern("arbace.a2g.reach$run")
