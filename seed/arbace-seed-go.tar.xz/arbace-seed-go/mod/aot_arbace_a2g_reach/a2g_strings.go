//line a2g_strings.ae:1
package aot_arbace_a2g_reach

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("require")

var Lit_2 *jrt.String = jrt.Intern("refer")

var Lit_3 *jrt.String = jrt.Intern("arbace.string")

var Lit_4 *jrt.String = jrt.Intern("as")

var Lit_5 *jrt.String = jrt.Intern("str")

var Lit_6 *jrt.String = jrt.Intern("arbace.classes.types")

var Lit_7 *jrt.String = jrt.Intern("t")

var Lit_8 *jrt.String = jrt.Intern("arbace.classes.env")

var Lit_9 *jrt.String = jrt.Intern("env")

var Lit_10 *jrt.String = jrt.Intern("arbace.classes.analyze")

var Lit_11 *jrt.String = jrt.Intern("a")

var Lit_12 *jrt.String = jrt.Intern("arbace.a2g.model")

var Lit_13 *jrt.String = jrt.Intern("m")

var Lit_14 *jrt.String = jrt.Intern("arbace.a2g.names")

var Lit_15 *jrt.String = jrt.Intern("nm")

var Lit_16 *jrt.String = jrt.Intern("arbace.a2g.access")

var Lit_17 *jrt.String = jrt.Intern("acc")

var Lit_18 *jrt.String = jrt.Intern("arbace.a2g.jrt")

var Lit_19 *jrt.String = jrt.Intern("jrt")

var Lit_20 *jrt.String = jrt.Intern("arbace.classes.opcodes")

var Lit_21 *jrt.String = jrt.Intern("Opcodes")

var Lit_22 *jrt.String = jrt.Intern("commute")

var Lit_23 *jrt.String = jrt.Intern("deref")

var Lit_24 *jrt.String = jrt.Intern("conj")

var Lit_25 *jrt.String = jrt.Intern("arbace.a2g.reach")

var Lit_26 *jrt.String = jrt.Intern("doc")

var Lit_27 *jrt.String = jrt.Intern("Reachability (JRT-SOURCES.md, the user's decision of 2026-10-08: translate the reached\n  methods, stub the rest): rapid type analysis over the analyzed class forms from root methods.\n  It decides the translated classes T (classes reached code uses: a class jrt provides stays\n  jrt's, except stand-ins, which translated classes replace), the reached methods (translated;\n  every other method of T is a stub throwing UnsupportedOperationException), and the methods\n  whose code needs something the closed world lacks (stubbed too, and reported).")

var Lit_28 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_29 *jrt.String = jrt.Intern("map?")

var Lit_30 *jrt.String = jrt.Intern("contains?")

var Lit_31 *jrt.String = jrt.Intern("op")

var Lit_32 *jrt.String = jrt.Intern("seq")

var Lit_33 *jrt.String = jrt.Intern("not")

var Lit_34 *jrt.String = jrt.Intern("chunked-seq?")

var Lit_35 *jrt.String = jrt.Intern("chunk-first")

var Lit_36 *jrt.String = jrt.Intern("first")

var Lit_37 *jrt.String = jrt.Intern("ctor")

var Lit_38 *jrt.String = jrt.Intern("temp")

var Lit_39 *jrt.String = jrt.Intern("restart")

var Lit_40 *jrt.String = jrt.Intern("frame")

var Lit_41 *jrt.String = jrt.Intern("method")

var Lit_42 *jrt.String = jrt.Intern("field")

var Lit_43 *jrt.String = jrt.Intern("sam")

var Lit_44 *jrt.String = jrt.Intern("scope")

var Lit_45 *jrt.String = jrt.Intern("boundary")

var Lit_46 *jrt.String = jrt.Intern("var")

var Lit_47 *jrt.String = jrt.Intern("hidden")

var Lit_48 *jrt.String = jrt.Intern("b")

var Lit_49 *jrt.String = jrt.Intern("sel-binding")

var Lit_50 *jrt.String = jrt.Intern("chunk-rest")

var Lit_51 *jrt.String = jrt.Intern("next")

var Lit_52 *jrt.String = jrt.Intern("node?")

var Lit_53 *jrt.String = jrt.Intern("sequential?")

var Lit_54 *jrt.String = jrt.Intern("else")

var Lit_55 *jrt.String = jrt.Intern("accessor")

var Lit_56 *jrt.String = jrt.Intern("pattern")

var Lit_57 *jrt.String = jrt.Intern("some")

var Lit_58 *jrt.String = jrt.Intern("chunk-buffer")

var Lit_59 *jrt.String = jrt.Intern("not=")

var Lit_60 *jrt.String = jrt.Intern("interface?")

var Lit_61 *jrt.String = jrt.Intern("name")

var Lit_62 *jrt.String = jrt.Intern("desc")

var Lit_63 *jrt.String = jrt.Intern("methods")

var Lit_64 *jrt.String = jrt.Intern("info")

var Lit_65 *jrt.String = jrt.Intern("abstract-m?")

var Lit_66 *jrt.String = jrt.Intern("static?")

var Lit_67 *jrt.String = jrt.Intern("private?")

var Lit_68 *jrt.String = jrt.Intern("chunk-append")

var Lit_69 *jrt.String = jrt.Intern("chunk-cons")

var Lit_70 *jrt.String = jrt.Intern("cons")

var Lit_71 *jrt.String = jrt.Intern("chunk")

var Lit_72 *jrt.String = jrt.Intern("rest")

var Lit_73 *jrt.String = jrt.Intern("remove")

var Lit_74 *jrt.String = jrt.Intern("take-while")

var Lit_75 *jrt.String = jrt.Intern("some?")

var Lit_76 *jrt.String = jrt.Intern("iterate")

var Lit_77 *jrt.String = jrt.Intern("super")

var Lit_78 *jrt.String = jrt.Intern("all-supertypes")

var Lit_79 *jrt.String = jrt.Intern("subclass?")

var Lit_80 *jrt.String = jrt.Intern("*current*")

var Lit_81 *jrt.String = jrt.Intern("swap!")

var Lit_82 *jrt.String = jrt.Intern("unavailable")

var Lit_83 *jrt.String = jrt.Intern("*st*")

var Lit_84 *jrt.String = jrt.Intern("update")

var Lit_85 *jrt.String = jrt.Intern("fnil")

var Lit_86 *jrt.String = jrt.Intern("go-name")

var Lit_87 *jrt.String = jrt.Intern("method-base")

var Lit_88 *jrt.String = jrt.Intern("*w*")

var Lit_89 *jrt.String = jrt.Intern("a2g-static?")

var Lit_90 *jrt.String = jrt.Intern("funcs")

var Lit_91 *jrt.String = jrt.Intern("vars")

var Lit_92 *jrt.String = jrt.Intern("static-field-name")

var Lit_93 *jrt.String = jrt.Intern("consts")

var Lit_94 *jrt.String = jrt.Intern("translated?")

var Lit_95 *jrt.String = jrt.Intern("jrt-class")

var Lit_96 *jrt.String = jrt.Intern("translatable?")

var Lit_97 *jrt.String = jrt.Intern("decl")

var Lit_98 *jrt.String = jrt.Intern("analysis-failed")

var Lit_99 *jrt.String = jrt.Intern("use!")

var Lit_100 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_101 *jrt.String = jrt.Intern("reflectable-interface?")

var Lit_102 *jrt.String = jrt.Intern("failed-classes")

var Lit_103 *jrt.String = jrt.Intern("note-unavailable!")

var Lit_104 *jrt.String = jrt.Intern("standin")

var Lit_105 *jrt.String = jrt.Intern("*slice?*")

var Lit_106 *jrt.String = jrt.Intern("state")

var Lit_107 *jrt.String = jrt.Intern("assoc")

var Lit_108 *jrt.String = jrt.Intern("T")

var Lit_109 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_110 *jrt.String = jrt.Intern("hash-map")

var Lit_111 *jrt.String = jrt.Intern("disj")

var Lit_112 *jrt.String = jrt.Intern("outer")

var Lit_113 *jrt.String = jrt.Intern("interfaces")

var Lit_114 *jrt.String = jrt.Intern("missing")

var Lit_115 *jrt.String = jrt.Intern("replace")

var Lit_116 *jrt.String = jrt.Intern("desc-classes")

var Lit_117 *jrt.String = jrt.Intern("reached")

var Lit_118 *jrt.String = jrt.Intern("queue")

var Lit_119 *jrt.String = jrt.Intern("reach!")

var Lit_120 *jrt.String = jrt.Intern("inited")

var Lit_121 *jrt.String = jrt.Intern("init!")

var Lit_122 *jrt.String = jrt.Intern("concat")

var Lit_123 *jrt.String = jrt.Intern("vec")

var Lit_124 *jrt.String = jrt.Intern("vcalls-by")

var Lit_125 *jrt.String = jrt.Intern("supertypes-of")

var Lit_126 *jrt.String = jrt.Intern("inst")

var Lit_127 *jrt.String = jrt.Intern("inst-by")

var Lit_128 *jrt.String = jrt.Intern("vcalls-on")

var Lit_129 *jrt.String = jrt.Intern("java-impl-of")

var Lit_130 *jrt.String = jrt.Intern("distinct")

var Lit_131 *jrt.String = jrt.Intern("external-keys")

var Lit_132 *jrt.String = jrt.Intern("vcalls")

var Lit_133 *jrt.String = jrt.Intern("filter")

var Lit_134 *jrt.String = jrt.Intern("lambda-fis")

var Lit_135 *jrt.String = jrt.Intern("hand-written?")

var Lit_136 *jrt.String = jrt.Intern("static")

var Lit_137 *jrt.String = jrt.Intern("hw-has-static?")

var Lit_138 *jrt.String = jrt.Intern("hw-method-exists?")

var Lit_139 *jrt.String = jrt.Intern("in-world?")

var Lit_140 *jrt.String = jrt.Intern("handles")

var Lit_141 *jrt.String = jrt.Intern("vh")

var Lit_142 *jrt.String = jrt.Intern("declarer")

var Lit_143 *jrt.String = jrt.Intern("owner")

var Lit_144 *jrt.String = jrt.Intern("to-array")

var Lit_145 *jrt.String = jrt.Intern("kind")

var Lit_146 *jrt.String = jrt.Intern("unaccess")

var Lit_147 *jrt.String = jrt.Intern("get-static")

var Lit_148 *jrt.String = jrt.Intern("vh-const?")

var Lit_149 *jrt.String = jrt.Intern("target")

var Lit_150 *jrt.String = jrt.Intern("switch")

var Lit_151 *jrt.String = jrt.Intern("cast")

var Lit_152 *jrt.String = jrt.Intern("use-desc!")

var Lit_153 *jrt.String = jrt.Intern("new-array")

var Lit_154 *jrt.String = jrt.Intern("get-field")

var Lit_155 *jrt.String = jrt.Intern("ctor-call")

var Lit_156 *jrt.String = jrt.Intern("if-instance")

var Lit_157 *jrt.String = jrt.Intern("class")

var Lit_158 *jrt.String = jrt.Intern("comps")

var Lit_159 *jrt.String = jrt.Intern("vcall!")

var Lit_160 *jrt.String = jrt.Intern("type")

var Lit_161 *jrt.String = jrt.Intern("java-str")

var Lit_162 *jrt.String = jrt.Intern("node")

var Lit_163 *jrt.String = jrt.Intern("value-type")

var Lit_164 *jrt.String = jrt.Intern("ref?")

var Lit_165 *jrt.String = jrt.Intern("for-each")

var Lit_166 *jrt.String = jrt.Intern("array")

var Lit_167 *jrt.String = jrt.Intern("parts")

var Lit_168 *jrt.String = jrt.Intern("null")

var Lit_169 *jrt.String = jrt.Intern("array?")

var Lit_170 *jrt.String = jrt.Intern("desc->internal")

var Lit_171 *jrt.String = jrt.Intern("class-lit")

var Lit_172 *jrt.String = jrt.Intern("instance?")

var Lit_173 *jrt.String = jrt.Intern("array-init")

var Lit_174 *jrt.String = jrt.Intern("method-ref")

var Lit_175 *jrt.String = jrt.Intern("bound")

var Lit_176 *jrt.String = jrt.Intern("new")

var Lit_177 *jrt.String = jrt.Intern("instantiate!")

var Lit_178 *jrt.String = jrt.Intern("unbound")

var Lit_179 *jrt.String = jrt.Intern("lambda!")

var Lit_180 *jrt.String = jrt.Intern("fi")

var Lit_181 *jrt.String = jrt.Intern("try")

var Lit_182 *jrt.String = jrt.Intern("new-name")

var Lit_183 *jrt.String = jrt.Intern("lambda")

var Lit_184 *jrt.String = jrt.Intern("catches")

var Lit_185 *jrt.String = jrt.Intern("classes")

var Lit_186 *jrt.String = jrt.Intern("set-field")

var Lit_187 *jrt.String = jrt.Intern("markers")

var Lit_188 *jrt.String = jrt.Intern("var-invoke")

var Lit_189 *jrt.String = jrt.Intern("fi-adapter")

var Lit_190 *jrt.String = jrt.Intern("lang-class")

var Lit_191 *jrt.String = jrt.Intern("var-deref")

var Lit_192 *jrt.String = jrt.Intern("method-desc")

var Lit_193 *jrt.String = jrt.Intern("repeat")

var Lit_194 *jrt.String = jrt.Intern("args")

var Lit_195 *jrt.String = jrt.Intern("walk-nodes")

var Lit_196 *jrt.String = jrt.Intern("invoker")

var Lit_197 *jrt.String = jrt.Intern("invoker-desc")

var Lit_198 *jrt.String = jrt.Intern("set-static")

var Lit_199 *jrt.String = jrt.Intern("invoke")

var Lit_200 *jrt.String = jrt.Intern("array-clone")

var Lit_201 *jrt.String = jrt.Intern("vh-call?")

var Lit_202 *jrt.String = jrt.Intern("interface")

var Lit_203 *jrt.String = jrt.Intern("check-hw-call!")

var Lit_204 *jrt.String = jrt.Intern("special")

var Lit_205 *jrt.String = jrt.Intern("virtual")

var Lit_206 *jrt.String = jrt.Intern("hw-has-field?")

var Lit_207 *jrt.String = jrt.Intern("method-desc-classes")

var Lit_208 *jrt.String = jrt.Intern("assert")

var Lit_209 *jrt.String = jrt.Intern("msg-desc")

var Lit_210 *jrt.String = jrt.Intern("cases")

var Lit_211 *jrt.String = jrt.Intern("labels")

var Lit_212 *jrt.String = jrt.Intern("scan-node!")

var Lit_213 *jrt.String = jrt.Intern("bodies")

var Lit_214 *jrt.String = jrt.Intern("clinit")

var Lit_215 *jrt.String = jrt.Intern("prologue")

var Lit_216 *jrt.String = jrt.Intern("calls-super")

var Lit_217 *jrt.String = jrt.Intern("init")

var Lit_218 *jrt.String = jrt.Intern("call")

var Lit_219 *jrt.String = jrt.Intern("body")

var Lit_220 *jrt.String = jrt.Intern("find-method")

var Lit_221 *jrt.String = jrt.Intern("uses-assert")

var Lit_222 *jrt.String = jrt.Intern("interface-assert")

var Lit_223 *jrt.String = jrt.Intern("derived")

var Lit_224 *jrt.String = jrt.Intern("record-canonical")

var Lit_225 *jrt.String = jrt.Intern("default-ctor")

var Lit_226 *jrt.String = jrt.Intern("bridge")

var Lit_227 *jrt.String = jrt.Intern("bridge-of")

var Lit_228 *jrt.String = jrt.Intern("anon-ctor")

var Lit_229 *jrt.String = jrt.Intern("scan-code!")

var Lit_230 *jrt.String = jrt.Intern("clj-consts")

var Lit_231 *jrt.String = jrt.Intern("read")

var Lit_232 *jrt.String = jrt.Intern("lang-desc")

var Lit_233 *jrt.String = jrt.Intern("record-object-method")

var Lit_234 *jrt.String = jrt.Intern("components")

var Lit_235 *jrt.String = jrt.Intern("method-code")

var Lit_236 *jrt.String = jrt.Intern("roots")

var Lit_237 *jrt.String = jrt.Intern("instantiate")

var Lit_238 *jrt.String = jrt.Intern("slice?")

var Lit_239 *jrt.String = jrt.Intern("fis")

var Lit_240 *jrt.String = jrt.Intern("atom")

var Lit_241 *jrt.String = jrt.Intern("<init>")

var Lit_242 *jrt.String = jrt.Intern("<clinit>")

var Lit_243 *jrt.String = jrt.Intern("scan-method!")

var Lit_244 *jrt.String = jrt.Intern("subvec")

var Lit_245 *jrt.String = jrt.Intern("constantly")

var Lit_246 *jrt.String = jrt.Intern("arbace.a2g.reach$check_hw_call_BANG_")

var Lit_247 *jrt.String = jrt.Intern("java/lang/Object")

var Lit_248 *jrt.String = jrt.Intern("jrt lacks ")

var Lit_249 *jrt.String = jrt.Intern(".")

var Lit_250 *jrt.String = jrt.Intern("/")

var Lit_251 *jrt.String = jrt.Intern("arbace.a2g.reach$check_hw_call_BANG_$fn__214000181")

var Lit_252 *jrt.String = jrt.Intern("arbace.a2g.reach$class_of_desc")

var Lit_253 *jrt.String = jrt.Intern("arbace.a2g.reach$eval214000004$loading__1927001464__auto____214000005")

var Lit_254 *jrt.String = jrt.Intern("arbace.a2g.reach$eval214000008$fn__214000009")

var Lit_255 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys")

var Lit_256 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118")

var Lit_257 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119")

var Lit_258 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120")

var Lit_259 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120$fn__214000121")

var Lit_260 *jrt.String = jrt.Intern("arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120$fn__214000121$fn__214000122")

var Lit_261 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_has_field_QMARK_")

var Lit_262 *jrt.String = jrt.Intern("arbace.a2g.reach$hw_has_static_QMARK_")

var Lit_263 *jrt.String = jrt.Intern("_")

var Lit_264 *jrt.String = jrt.Intern("arbace.a2g.reach$init_BANG_")

var Lit_265 *jrt.String = jrt.Intern("()V")

var Lit_266 *jrt.String = jrt.Intern("arbace.a2g.reach$instantiate_BANG_")

var Lit_267 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of")

var Lit_268 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000052")

var Lit_269 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000052$fn__214000053")

var Lit_270 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000056")

var Lit_271 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000072")

var Lit_272 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$fn__214000072$fn__214000073")

var Lit_273 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062")

var Lit_274 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063")

var Lit_275 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000064")

var Lit_276 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000064$fn__214000065")

var Lit_277 *jrt.String = jrt.Intern("arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000068")

var Lit_278 *jrt.String = jrt.Intern("arbace.a2g.reach$lambda_BANG_")

var Lit_279 *jrt.String = jrt.Intern("arbace.a2g.reach$method_code")

var Lit_280 *jrt.String = jrt.Intern("arbace.a2g.reach$node_QMARK_")

var Lit_281 *jrt.String = jrt.Intern("arbace.a2g.reach$note_unavailable_BANG_")

var Lit_282 *jrt.String = jrt.Intern("arbace.a2g.reach$reach_BANG_")

var Lit_283 *jrt.String = jrt.Intern("arbace.a2g.reach$run")

var Lit_284 *jrt.String = jrt.Intern("arbace.a2g.reach$run$fn__214000327")

var Lit_285 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_code_BANG_")

var Lit_286 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_method_BANG_")

var Lit_287 *jrt.String = jrt.Intern("analysis failed: ")

var Lit_288 *jrt.String = jrt.Intern("RT")

var Lit_289 *jrt.String = jrt.Intern("(Ljava/lang/String;Ljava/lang/String;)")

var Lit_290 *jrt.String = jrt.Intern("Var")

var Lit_291 *jrt.String = jrt.Intern("readString")

var Lit_292 *jrt.String = jrt.Intern("(Ljava/lang/String;)Ljava/lang/Object;")

var Lit_293 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_294 *jrt.String = jrt.Intern("hashCode")

var Lit_295 *jrt.String = jrt.Intern("()I")

var Lit_296 *jrt.String = jrt.Intern("equals")

var Lit_297 *jrt.String = jrt.Intern("(Ljava/lang/Object;)Z")

var Lit_298 *jrt.String = jrt.Intern("toString")

var Lit_299 *jrt.String = jrt.Intern("()Ljava/lang/String;")

var Lit_300 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_")

var Lit_301 *jrt.String = jrt.Intern("Ljava/lang/String;")

var Lit_302 *jrt.String = jrt.Intern("java/util/Iterator")

var Lit_303 *jrt.String = jrt.Intern("hasNext")

var Lit_304 *jrt.String = jrt.Intern("()Z")

var Lit_305 *jrt.String = jrt.Intern("()Ljava/lang/Object;")

var Lit_306 *jrt.String = jrt.Intern("jrt lacks constructor ")

var Lit_307 *jrt.String = jrt.Intern("getRawRoot")

var Lit_308 *jrt.String = jrt.Intern("IFn")

var Lit_309 *jrt.String = jrt.Intern("Ljava/lang/Object;")

var Lit_310 *jrt.String = jrt.Intern("FnInvokers")

var Lit_311 *jrt.String = jrt.Intern("jrt lacks static field ")

var Lit_312 *jrt.String = jrt.Intern("L")

var Lit_313 *jrt.String = jrt.Intern(";")

var Lit_314 *jrt.String = jrt.Intern("java/lang/AssertionError")

var Lit_315 *jrt.String = jrt.Intern("(")

var Lit_316 *jrt.String = jrt.Intern(")V")

var Lit_317 *jrt.String = jrt.Intern("")

var Lit_318 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$fn__214000211")

var Lit_319 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000224")

var Lit_320 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000242")

var Lit_321 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000248")

var Lit_322 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000254")

var Lit_323 *jrt.String = jrt.Intern("arbace.a2g.reach$scan_node_BANG_$pat__214000260")

var Lit_324 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of")

var Lit_325 *jrt.String = jrt.Intern("arbace.a2g.reach$supertypes_of$fn__214000130")

var Lit_326 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_")

var Lit_327 *jrt.String = jrt.Intern("class ")

var Lit_328 *jrt.String = jrt.Intern(": ")

var Lit_329 *jrt.String = jrt.Intern(" failed analysis")

var Lit_330 *jrt.String = jrt.Intern("<class>")

var Lit_331 *jrt.String = jrt.Intern("superclass ")

var Lit_332 *jrt.String = jrt.Intern(" unavailable")

var Lit_333 *jrt.String = jrt.Intern(": superclass ")

var Lit_334 *jrt.String = jrt.Intern(" is not in the closed world")

var Lit_335 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000080")

var Lit_336 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000086")

var Lit_337 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000088")

var Lit_338 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000090")

var Lit_339 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000096")

var Lit_340 *jrt.String = jrt.Intern("arbace.a2g.reach$use_BANG_$fn__214000098")

var Lit_341 *jrt.String = jrt.Intern("arbace.a2g.reach$use_desc_BANG_")

var Lit_342 *jrt.String = jrt.Intern("arbace.a2g.reach$vcall_BANG_")

var Lit_343 *jrt.String = jrt.Intern("arbace.a2g.reach$vcall_BANG_$fn__214000168")

var Lit_344 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on")

var Lit_345 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139")

var Lit_346 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140")

var Lit_347 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141")

var Lit_348 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141$fn__214000142")

var Lit_349 *jrt.String = jrt.Intern("arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141$fn__214000142$fn__214000143")

var Lit_350 *jrt.String = jrt.Intern("arbace.a2g.reach$vh_call_QMARK_")

var Lit_351 *jrt.String = jrt.Intern("java/lang/invoke/VarHandle")

var Lit_352 *jrt.String = jrt.Intern("java/lang/invoke/MethodHandles")

var Lit_353 *jrt.String = jrt.Intern("lookup")

var Lit_354 *jrt.String = jrt.Intern("arbace.a2g.reach$vh_const_QMARK_")

var Lit_355 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes")

var Lit_356 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk__214000013")

var Lit_357 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk_plain__214000031")

var Lit_358 *jrt.String = jrt.Intern("arbace.a2g.reach$walk_nodes$walk_val__214000025")

var Lit_359 *jrt.String = jrt.Intern("in-ns")

var Lit_360 *jrt.String = jrt.Intern("arglists")

var Lit_361 *jrt.String = jrt.Intern("x")

var Lit_362 *jrt.String = jrt.Intern("line")

var Lit_363 *jrt.String = jrt.Intern("column")

var Lit_364 *jrt.String = jrt.Intern("file")

var Lit_365 *jrt.String = jrt.Intern("arbace/a2g/reach.ae")

var Lit_366 *jrt.String = jrt.Intern("f")

var Lit_367 *jrt.String = jrt.Intern("Calls (f node) on node and every node in it (operands, branches, bindings, cases, catches,\n  lambda bodies, patterns), each once, parents first.")

var Lit_368 *jrt.String = jrt.Intern("n")

var Lit_369 *jrt.String = jrt.Intern("The [class name desc] implementing virtual method [name desc] for class n (a body in n or a\n  superclass, else an interface's default), by Java's rules on the class environment.")

var Lit_370 *jrt.String = jrt.Intern("dynamic")

var Lit_371 *jrt.String = jrt.Intern("Whether a class's code may be translated in this run (classes outside the slice exist as\n  declarations with stub bodies).")

var Lit_372 *jrt.String = jrt.Intern("private")

var Lit_373 *jrt.String = jrt.Intern("why")

var Lit_374 *jrt.String = jrt.Intern("declared")

var Lit_375 *jrt.String = jrt.Intern("cls")

var Lit_376 *jrt.String = jrt.Intern("fname")

var Lit_377 *jrt.String = jrt.Intern("Makes class n exist in Go (translating it when it can and jrt does not provide it, or jrt\n  provides only a stand-in). Returns false, noting why, when it cannot.")

var Lit_378 *jrt.String = jrt.Intern("d")

var Lit_379 *jrt.String = jrt.Intern("c")

var Lit_380 *jrt.String = jrt.Intern("k")

var Lit_381 *jrt.String = jrt.Intern("Marks method [c name desc] reached (its body will be translated).")

var Lit_382 *jrt.String = jrt.Intern("Class c is initialized: its static initializer is reached (and its superclass's).")

var Lit_383 *jrt.String = jrt.Intern("The virtual methods of class d's supertypes that jrt's own code may call: those of Object,\n  of jrt's hand-written classes and interfaces and of the classes jrt has stand-ins for.")

var Lit_384 *jrt.String = jrt.Intern("The types class d is a subtype of (env/subclass?): d, its supertypes and Object.")

var Lit_385 *jrt.String = jrt.Intern("The virtual calls [name desc] whose receiver's static type is a supertype of d (indexed by\n  receiver type: the roots of --program are each a virtual call, about 20,000).")

var Lit_386 *jrt.String = jrt.Intern("o")

var Lit_387 *jrt.String = jrt.Intern("A virtual call of [name desc] on a receiver of static type o.")

var Lit_388 *jrt.String = jrt.Intern("A lambda or method reference of functional interface fi: its adapter is an instance of fi,\n  whose default methods virtual calls reach.")

var Lit_389 *jrt.String = jrt.Intern("A call of a method of jrt's hand-written class: jrt must have it.")

var Lit_390 *jrt.String = jrt.Intern("class-of-desc")

var Lit_391 *jrt.String = jrt.Intern("Is field f a constant VarHandle of the world (A2G-SPEC §8.5)?")

var Lit_392 *jrt.String = jrt.Intern("A VarHandle call a2g compiles statically (A2G-SPEC §8.5): a fence, MethodHandles.lookup(),\n  or an access mode on a constant handle; it names no class of java.lang.invoke in Go.")

var Lit_393 *jrt.String = jrt.Intern("The analyzed code of method [c name desc] of a translated class: a vector of nodes.")

var Lit_394 *jrt.String = jrt.Intern("run")

var Lit_395 *jrt.String = jrt.Intern("keys")

var Lit_396 *jrt.String = jrt.Intern("Reachability from roots (method keys [class name desc]; classes to instantiate\n  :instantiate; functional interfaces with adapters :fis). Returns {:T #{} :reached #{} :inst #{} :unavailable {k #{why}} :missing {}\n  :state st}. With :state, a previous run's st, the run goes on from where that one ended:\n  reachability is monotone, so a run from more roots is the previous one continued from the\n  new ones (standalone S6: main's stand-in loop runs the closure once, not twice).")
