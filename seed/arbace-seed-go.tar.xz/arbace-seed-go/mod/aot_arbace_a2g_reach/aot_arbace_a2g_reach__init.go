//line aot_arbace_a2g_reach__init.ae:1
package aot_arbace_a2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_reach__init_A_Unit0__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(jrt.NN(A_arbace_a2g_reach__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach__init_A_const_1) }
//line :1:1
func A_arbace_a2g_reach__init_A_Unit1__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_reach__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_reach__init_A_Unit2__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_Init(); tmp2 = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_reach__init_A_Unit3__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_reach__init_A_const_1)).Equals_O__Z(A_arbace_a2g_reach__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_reach_eval214000008_fn__214000009_A_New(); var tmp2 *jrt.Class; A_arbace_a2g_reach_eval214000008_fn__214000009_A_Init(); tmp2 = A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_reach__init_A_Load__O() any { A_arbace_a2g_reach__init_A_Init(); A_arbace_a2g_reach__init_A_Unit0__O(); A_arbace_a2g_reach__init_A_Unit1__O(); A_arbace_a2g_reach__init_A_Unit2__O(); A_arbace_a2g_reach__init_A_Unit3__O(); A_arbace_a2g_reach__init_A_Unit4__O(); A_arbace_a2g_reach__init_A_Unit5__O(); A_arbace_a2g_reach__init_A_Unit6__O(); A_arbace_a2g_reach__init_A_Unit7__O(); A_arbace_a2g_reach__init_A_Unit8__O(); A_arbace_a2g_reach__init_A_Unit9__O(); A_arbace_a2g_reach__init_A_Unit10__O(); A_arbace_a2g_reach__init_A_Unit11__O(); A_arbace_a2g_reach__init_A_Unit12__O(); A_arbace_a2g_reach__init_A_Unit13__O(); A_arbace_a2g_reach__init_A_Unit14__O(); A_arbace_a2g_reach__init_A_Unit15__O(); A_arbace_a2g_reach__init_A_Unit16__O(); A_arbace_a2g_reach__init_A_Unit17__O(); A_arbace_a2g_reach__init_A_Unit18__O(); A_arbace_a2g_reach__init_A_Unit19__O(); A_arbace_a2g_reach__init_A_Unit20__O(); A_arbace_a2g_reach__init_A_Unit21__O(); A_arbace_a2g_reach__init_A_Unit22__O(); A_arbace_a2g_reach__init_A_Unit23__O(); A_arbace_a2g_reach__init_A_Unit24__O(); A_arbace_a2g_reach__init_A_Unit25__O(); A_arbace_a2g_reach__init_A_Unit26__O(); A_arbace_a2g_reach__init_A_Unit27__O(); A_arbace_a2g_reach__init_A_Unit28__O(); A_arbace_a2g_reach__init_A_Unit29__O(); A_arbace_a2g_reach__init_A_Unit30__O(); A_arbace_a2g_reach__init_A_Unit31__O(); A_arbace_a2g_reach__init_A_Unit32__O(); A_arbace_a2g_reach__init_A_Unit33__O(); A_arbace_a2g_reach__init_A_Unit34__O(); A_arbace_a2g_reach__init_A_Unit35__O(); A_arbace_a2g_reach__init_A_Unit36__O(); return nil }















func A_arbace_a2g_reach__init_A_Unit4__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_4; var tmp2 any = A_arbace_a2g_reach_node_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_node_QMARK__A_Init(); tmp3 = A_arbace_a2g_reach_node_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_5)); return A_arbace_a2g_reach__init_A_const_4.Ref() }

func A_arbace_a2g_reach__init_A_Unit5__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_6; var tmp2 any = A_arbace_a2g_reach_walk_nodes_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_walk_nodes_A_Init(); tmp3 = A_arbace_a2g_reach_walk_nodes_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_7)); return A_arbace_a2g_reach__init_A_const_6.Ref() }

























func A_arbace_a2g_reach__init_A_Unit6__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_8; var tmp2 any = A_arbace_a2g_reach_java_impl_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_java_impl_of_A_Init(); tmp3 = A_arbace_a2g_reach_java_impl_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_9)); return A_arbace_a2g_reach__init_A_const_8.Ref() }



















func A_arbace_a2g_reach__init_A_Unit7__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(69, 1); jrt.NN(A_arbace_a2g_reach__init_A_const_10).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_10; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_11)); return jrt.NN(A_arbace_a2g_reach__init_A_const_10).SetDynamic_Z__Var(true).Ref() }
func A_arbace_a2g_reach__init_A_Unit8__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(70, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(A_arbace_a2g_reach__init_A_const_13).GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; jrt.NN(tmp1).BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_12; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_14)); return jrt.NN(A_arbace_a2g_reach__init_A_const_12).SetDynamic_Z__Var(true).Ref() }



func A_arbace_a2g_reach__init_A_Unit9__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(74, 1); jrt.NN(A_arbace_a2g_reach__init_A_const_15).BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_15; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_16)); return jrt.NN(A_arbace_a2g_reach__init_A_const_15).SetDynamic_Z__Var(true).Ref() }

func A_arbace_a2g_reach__init_A_Unit10__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(76, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_17; var tmp2 any = A_arbace_a2g_reach_note_unavailable_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_note_unavailable_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_17; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_18)); return A_arbace_a2g_reach__init_A_const_17.Ref() }



func A_arbace_a2g_reach__init_A_Unit11__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_19; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_20)); return A_arbace_a2g_reach__init_A_const_19.Ref() }
//line :80:1
func A_arbace_a2g_reach__init_A_Unit12__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_21; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_22)); return A_arbace_a2g_reach__init_A_const_21.Ref() }
//line :80:1
func A_arbace_a2g_reach__init_A_Unit13__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_23; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_24)); return A_arbace_a2g_reach__init_A_const_23.Ref() }
//line :80:1
func A_arbace_a2g_reach__init_A_Unit14__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_25; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_26)); return A_arbace_a2g_reach__init_A_const_25.Ref() }
//line :80:1
func A_arbace_a2g_reach__init_A_Unit15__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_27; jrt.NN(tmp1).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_28)); return A_arbace_a2g_reach__init_A_const_27.Ref() }

func A_arbace_a2g_reach__init_A_Unit16__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_29; var tmp2 any = A_arbace_a2g_reach_hw_has_static_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_hw_has_static_QMARK__A_Init(); tmp3 = A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_29; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_30)); return A_arbace_a2g_reach__init_A_const_29.Ref() }






func A_arbace_a2g_reach__init_A_Unit17__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(89, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_31; var tmp2 any = A_arbace_a2g_reach_hw_has_field_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_hw_has_field_QMARK__A_Init(); tmp3 = A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_31; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_32)); return A_arbace_a2g_reach__init_A_const_31.Ref() }







func A_arbace_a2g_reach__init_A_Unit18__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(97, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_19; var tmp2 any = A_arbace_a2g_reach_use_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_use_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_use_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_19; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_33)); return A_arbace_a2g_reach__init_A_const_19.Ref() }










































func A_arbace_a2g_reach__init_A_Unit19__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(140, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_34; var tmp2 any = A_arbace_a2g_reach_use_desc_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_use_desc_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_use_desc_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_34; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_35)); return A_arbace_a2g_reach__init_A_const_34.Ref() }


func A_arbace_a2g_reach__init_A_Unit20__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(143, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_23; var tmp2 any = A_arbace_a2g_reach_reach_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_reach_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_reach_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_23; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_36)); return A_arbace_a2g_reach__init_A_const_23.Ref() }






func A_arbace_a2g_reach__init_A_Unit21__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(150, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_21; var tmp2 any = A_arbace_a2g_reach_init_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_init_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_init_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_21; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_37)); return A_arbace_a2g_reach__init_A_const_21.Ref() }







func A_arbace_a2g_reach__init_A_Unit22__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(158, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_38; var tmp2 any = A_arbace_a2g_reach_external_keys_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_external_keys_A_Init(); tmp3 = A_arbace_a2g_reach_external_keys_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_38; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_39)); return A_arbace_a2g_reach__init_A_const_38.Ref() }









func A_arbace_a2g_reach__init_A_Unit23__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(168, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_40; var tmp2 any = A_arbace_a2g_reach_supertypes_of_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_supertypes_of_A_Init(); tmp3 = A_arbace_a2g_reach_supertypes_of_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_40; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_41)); return A_arbace_a2g_reach__init_A_const_40.Ref() }





func A_arbace_a2g_reach__init_A_Unit24__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(174, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_42; var tmp2 any = A_arbace_a2g_reach_vcalls_on_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_vcalls_on_A_Init(); tmp3 = A_arbace_a2g_reach_vcalls_on_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_42; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_43)); return A_arbace_a2g_reach__init_A_const_42.Ref() }






func A_arbace_a2g_reach__init_A_Unit25__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(181, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_27; var tmp2 any = A_arbace_a2g_reach_instantiate_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_instantiate_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_instantiate_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_27; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_44)); return A_arbace_a2g_reach__init_A_const_27.Ref() }










func A_arbace_a2g_reach__init_A_Unit26__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(192, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_25; var tmp2 any = A_arbace_a2g_reach_vcall_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_vcall_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_vcall_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_25; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_45)); return A_arbace_a2g_reach__init_A_const_25.Ref() }










func A_arbace_a2g_reach__init_A_Unit27__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(203, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_46; var tmp2 any = A_arbace_a2g_reach_lambda_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_lambda_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_lambda_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_46; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_47)); return A_arbace_a2g_reach__init_A_const_46.Ref() }










func A_arbace_a2g_reach__init_A_Unit28__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(214, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_48; var tmp2 any = A_arbace_a2g_reach_check_hw_call_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_check_hw_call_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_48; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_49)); return A_arbace_a2g_reach__init_A_const_48.Ref() }












func A_arbace_a2g_reach__init_A_Unit29__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(227, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_50; var tmp2 any = A_arbace_a2g_reach_class_of_desc_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_class_of_desc_A_Init(); tmp3 = A_arbace_a2g_reach_class_of_desc_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_50; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_51)); return A_arbace_a2g_reach__init_A_const_50.Ref() }

func A_arbace_a2g_reach__init_A_Unit30__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(229, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_52; var tmp2 any = A_arbace_a2g_reach_vh_const_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_vh_const_QMARK__A_Init(); tmp3 = A_arbace_a2g_reach_vh_const_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_52; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_53)); return A_arbace_a2g_reach__init_A_const_52.Ref() }




func A_arbace_a2g_reach__init_A_Unit31__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(234, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_54; var tmp2 any = A_arbace_a2g_reach_vh_call_QMARK__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_vh_call_QMARK__A_Init(); tmp3 = A_arbace_a2g_reach_vh_call_QMARK__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_54; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_55)); return A_arbace_a2g_reach__init_A_const_54.Ref() }











func A_arbace_a2g_reach__init_A_Unit32__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(246, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_56; var tmp2 any = A_arbace_a2g_reach_scan_node_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_scan_node_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_56; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_57)); return A_arbace_a2g_reach__init_A_const_56.Ref() }










































































































func A_arbace_a2g_reach__init_A_Unit33__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(353, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_58; var tmp2 any = A_arbace_a2g_reach_scan_code_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_scan_code_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_scan_code_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_58; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_59)); return A_arbace_a2g_reach__init_A_const_58.Ref() }

func A_arbace_a2g_reach__init_A_Unit34__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(355, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_60; var tmp2 any = A_arbace_a2g_reach_method_code_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_method_code_A_Init(); tmp3 = A_arbace_a2g_reach_method_code_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_60; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_61)); return A_arbace_a2g_reach__init_A_const_60.Ref() }











func A_arbace_a2g_reach__init_A_Unit35__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(367, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_62; var tmp2 any = A_arbace_a2g_reach_scan_method_BANG__A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_scan_method_BANG__A_Init(); tmp3 = A_arbace_a2g_reach_scan_method_BANG__A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_62; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_63)); return A_arbace_a2g_reach__init_A_const_62.Ref() }






































func A_arbace_a2g_reach__init_A_Unit36__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(406, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_64; var tmp2 any = A_arbace_a2g_reach_run_A_New(); var tmp3 *jrt.Class; A_arbace_a2g_reach_run_A_Init(); tmp3 = A_arbace_a2g_reach_run_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_64; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_65)); return A_arbace_a2g_reach__init_A_const_64.Ref() }



type A_arbace_a2g_reach__init_A struct{ jrt.Object }

var A_arbace_a2g_reach__init_A_const_0 *lang.Var

var A_arbace_a2g_reach__init_A_const_1 any

var A_arbace_a2g_reach__init_A_const_2 any

var A_arbace_a2g_reach__init_A_const_3 any

var A_arbace_a2g_reach__init_A_const_4 *lang.Var

var A_arbace_a2g_reach__init_A_const_5 any

var A_arbace_a2g_reach__init_A_const_6 *lang.Var

var A_arbace_a2g_reach__init_A_const_7 any

var A_arbace_a2g_reach__init_A_const_8 *lang.Var

var A_arbace_a2g_reach__init_A_const_9 any

var A_arbace_a2g_reach__init_A_const_10 *lang.Var

var A_arbace_a2g_reach__init_A_const_11 any

var A_arbace_a2g_reach__init_A_const_12 *lang.Var

var A_arbace_a2g_reach__init_A_const_13 *lang.Var

var A_arbace_a2g_reach__init_A_const_14 any

var A_arbace_a2g_reach__init_A_const_15 *lang.Var

var A_arbace_a2g_reach__init_A_const_16 any

var A_arbace_a2g_reach__init_A_const_17 *lang.Var

var A_arbace_a2g_reach__init_A_const_18 any

var A_arbace_a2g_reach__init_A_const_19 *lang.Var

var A_arbace_a2g_reach__init_A_const_20 any

var A_arbace_a2g_reach__init_A_const_21 *lang.Var

var A_arbace_a2g_reach__init_A_const_22 any

var A_arbace_a2g_reach__init_A_const_23 *lang.Var

var A_arbace_a2g_reach__init_A_const_24 any

var A_arbace_a2g_reach__init_A_const_25 *lang.Var

var A_arbace_a2g_reach__init_A_const_26 any

var A_arbace_a2g_reach__init_A_const_27 *lang.Var

var A_arbace_a2g_reach__init_A_const_28 any

var A_arbace_a2g_reach__init_A_const_29 *lang.Var

var A_arbace_a2g_reach__init_A_const_30 any

var A_arbace_a2g_reach__init_A_const_31 *lang.Var

var A_arbace_a2g_reach__init_A_const_32 any

var A_arbace_a2g_reach__init_A_const_33 any

var A_arbace_a2g_reach__init_A_const_34 *lang.Var

var A_arbace_a2g_reach__init_A_const_35 any

var A_arbace_a2g_reach__init_A_const_36 any

var A_arbace_a2g_reach__init_A_const_37 any

var A_arbace_a2g_reach__init_A_const_38 *lang.Var

var A_arbace_a2g_reach__init_A_const_39 any

var A_arbace_a2g_reach__init_A_const_40 *lang.Var

var A_arbace_a2g_reach__init_A_const_41 any

var A_arbace_a2g_reach__init_A_const_42 *lang.Var

var A_arbace_a2g_reach__init_A_const_43 any

var A_arbace_a2g_reach__init_A_const_44 any

var A_arbace_a2g_reach__init_A_const_45 any

var A_arbace_a2g_reach__init_A_const_46 *lang.Var

var A_arbace_a2g_reach__init_A_const_47 any

var A_arbace_a2g_reach__init_A_const_48 *lang.Var

var A_arbace_a2g_reach__init_A_const_49 any

var A_arbace_a2g_reach__init_A_const_50 *lang.Var

var A_arbace_a2g_reach__init_A_const_51 any

var A_arbace_a2g_reach__init_A_const_52 *lang.Var

var A_arbace_a2g_reach__init_A_const_53 any

var A_arbace_a2g_reach__init_A_const_54 *lang.Var

var A_arbace_a2g_reach__init_A_const_55 any

var A_arbace_a2g_reach__init_A_const_56 *lang.Var

var A_arbace_a2g_reach__init_A_const_57 any

var A_arbace_a2g_reach__init_A_const_58 *lang.Var

var A_arbace_a2g_reach__init_A_const_59 any

var A_arbace_a2g_reach__init_A_const_60 *lang.Var

var A_arbace_a2g_reach__init_A_const_61 any

var A_arbace_a2g_reach__init_A_const_62 *lang.Var

var A_arbace_a2g_reach__init_A_const_63 any

var A_arbace_a2g_reach__init_A_const_64 *lang.Var

var A_arbace_a2g_reach__init_A_const_65 any

var A_arbace_a2g_reach__init_A_init jrt.ClassInit

func A_arbace_a2g_reach__init_A_Init() { if !A_arbace_a2g_reach__init_A_init.Done() { A_arbace_a2g_reach__init_A_init.Run(A_arbace_a2g_reach__init_A_clinit) } }

func A_arbace_a2g_reach__init_A_clinit() { A_arbace_a2g_reach__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_359); A_arbace_a2g_reach__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27))); A_arbace_a2g_reach__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27)); A_arbace_a2g_reach__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_reach__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_25, Lit_52); A_arbace_a2g_reach__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_361).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(21).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_25, Lit_195); A_arbace_a2g_reach__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_367, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(23).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_25, Lit_129); A_arbace_a2g_reach__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_368).Ref(), lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_369, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(49).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_25, Lit_83); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_370).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_a2g_reach__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(69).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_12 = lang.RT_Var_String_String__Var(Lit_25, Lit_105); A_arbace_a2g_reach__init_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_245); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_370).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_a2g_reach__init_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(70).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_371)); A_arbace_a2g_reach__init_A_const_15 = lang.RT_Var_String_String__Var(Lit_25, Lit_80); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_370).Ref(); var tmp8 *jrt.Boolean; jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; var tmp9 any = tmp8.Ref(); A_arbace_a2g_reach__init_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp9, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(74).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_17 = lang.RT_Var_String_String__Var(Lit_25, Lit_103); var tmp10 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp11 *jrt.Boolean; jrt.Boolean_Init(); tmp11 = jrt.Boolean_TRUE; var tmp12 any = tmp11.Ref(); A_arbace_a2g_reach__init_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp10, tmp12, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_373).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(76).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_19 = lang.RT_Var_String_String__Var(Lit_25, Lit_99); var tmp13 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_374).Ref(); var tmp14 *jrt.Boolean; jrt.Boolean_Init(); tmp14 = jrt.Boolean_TRUE; var tmp15 any = tmp14.Ref(); A_arbace_a2g_reach__init_A_const_20 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp13, tmp15, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_21 = lang.RT_Var_String_String__Var(Lit_25, Lit_121); var tmp16 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_374).Ref(); var tmp17 *jrt.Boolean; jrt.Boolean_Init(); tmp17 = jrt.Boolean_TRUE; var tmp18 any = tmp17.Ref(); A_arbace_a2g_reach__init_A_const_22 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp16, tmp18, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_23 = lang.RT_Var_String_String__Var(Lit_25, Lit_119); var tmp19 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_374).Ref(); var tmp20 *jrt.Boolean; jrt.Boolean_Init(); tmp20 = jrt.Boolean_TRUE; var tmp21 any = tmp20.Ref(); A_arbace_a2g_reach__init_A_const_24 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp19, tmp21, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_25 = lang.RT_Var_String_String__Var(Lit_25, Lit_159); var tmp22 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_374).Ref(); var tmp23 *jrt.Boolean; jrt.Boolean_Init(); tmp23 = jrt.Boolean_TRUE; var tmp24 any = tmp23.Ref(); A_arbace_a2g_reach__init_A_const_26 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp22, tmp24, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_27 = lang.RT_Var_String_String__Var(Lit_25, Lit_177); var tmp25 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_374).Ref(); var tmp26 *jrt.Boolean; jrt.Boolean_Init(); tmp26 = jrt.Boolean_TRUE; var tmp27 any = tmp26.Ref(); A_arbace_a2g_reach__init_A_const_28 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp25, tmp27, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(80).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_29 = lang.RT_Var_String_String__Var(Lit_25, Lit_137); var tmp28 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp29 *jrt.Boolean; jrt.Boolean_Init(); tmp29 = jrt.Boolean_TRUE; var tmp30 any = tmp29.Ref(); A_arbace_a2g_reach__init_A_const_30 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp28, tmp30, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(82).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_31 = lang.RT_Var_String_String__Var(Lit_25, Lit_206); var tmp31 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp32 *jrt.Boolean; jrt.Boolean_Init(); tmp32 = jrt.Boolean_TRUE; var tmp33 any = tmp32.Ref(); A_arbace_a2g_reach__init_A_const_32 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp31, tmp33, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_375).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_376).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_66).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(89).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_33 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_368).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_377, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(97).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_34 = lang.RT_Var_String_String__Var(Lit_25, Lit_152); var tmp34 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp35 *jrt.Boolean; jrt.Boolean_Init(); tmp35 = jrt.Boolean_TRUE; var tmp36 any = tmp35.Ref(); A_arbace_a2g_reach__init_A_const_35 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp34, tmp36, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_378).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(140).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_36 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_379).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_380).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_381, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(143).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_37 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_379).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_382, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(150).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_38 = lang.RT_Var_String_String__Var(Lit_25, Lit_131); var tmp37 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp38 *jrt.Boolean; jrt.Boolean_Init(); tmp38 = jrt.Boolean_TRUE; var tmp39 any = tmp38.Ref(); A_arbace_a2g_reach__init_A_const_39 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp37, tmp39, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_378).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_383, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(158).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_40 = lang.RT_Var_String_String__Var(Lit_25, Lit_125); var tmp40 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp41 *jrt.Boolean; jrt.Boolean_Init(); tmp41 = jrt.Boolean_TRUE; var tmp42 any = tmp41.Ref(); A_arbace_a2g_reach__init_A_const_41 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp40, tmp42, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_378).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_384, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(168).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_42 = lang.RT_Var_String_String__Var(Lit_25, Lit_128); var tmp43 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp44 *jrt.Boolean; jrt.Boolean_Init(); tmp44 = jrt.Boolean_TRUE; var tmp45 any = tmp44.Ref(); A_arbace_a2g_reach__init_A_const_43 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp43, tmp45, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_378).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_385, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(174).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_44 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_378).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(181).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_45 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_386).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_387, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(192).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_46 = lang.RT_Var_String_String__Var(Lit_25, Lit_179); A_arbace_a2g_reach__init_A_const_47 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_180).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_388, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(203).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_48 = lang.RT_Var_String_String__Var(Lit_25, Lit_203); var tmp46 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp47 *jrt.Boolean; jrt.Boolean_Init(); tmp47 = jrt.Boolean_TRUE; var tmp48 any = tmp47.Ref(); A_arbace_a2g_reach__init_A_const_49 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp46, tmp48, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_143).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_145).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_389, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(214).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_50 = lang.RT_Var_String_String__Var(Lit_25, Lit_390); var tmp49 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp50 *jrt.Boolean; jrt.Boolean_Init(); tmp50 = jrt.Boolean_TRUE; var tmp51 any = tmp50.Ref(); A_arbace_a2g_reach__init_A_const_51 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp49, tmp51, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_378).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(227).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_52 = lang.RT_Var_String_String__Var(Lit_25, Lit_148); var tmp52 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp53 *jrt.Boolean; jrt.Boolean_Init(); tmp53 = jrt.Boolean_TRUE; var tmp54 any = tmp53.Ref(); A_arbace_a2g_reach__init_A_const_53 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp52, tmp54, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_366).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_391, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(229).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_54 = lang.RT_Var_String_String__Var(Lit_25, Lit_201); var tmp55 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp56 *jrt.Boolean; jrt.Boolean_Init(); tmp56 = jrt.Boolean_TRUE; var tmp57 any = tmp56.Ref(); A_arbace_a2g_reach__init_A_const_55 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp55, tmp57, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_392, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(234).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_56 = lang.RT_Var_String_String__Var(Lit_25, Lit_212); var tmp58 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp59 *jrt.Boolean; jrt.Boolean_Init(); tmp59 = jrt.Boolean_TRUE; var tmp60 any = tmp59.Ref(); A_arbace_a2g_reach__init_A_const_57 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp58, tmp60, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(246).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_58 = lang.RT_Var_String_String__Var(Lit_25, Lit_229); A_arbace_a2g_reach__init_A_const_59 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_162).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(353).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_60 = lang.RT_Var_String_String__Var(Lit_25, Lit_235); A_arbace_a2g_reach__init_A_const_61 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_379).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_393, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(355).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_62 = lang.RT_Var_String_String__Var(Lit_25, Lit_243); var tmp61 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_372).Ref(); var tmp62 *jrt.Boolean; jrt.Boolean_Init(); tmp62 = jrt.Boolean_TRUE; var tmp63 any = tmp62.Ref(); A_arbace_a2g_reach__init_A_const_63 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp61, tmp63, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_379).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_61).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_62).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_380).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(367).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)); A_arbace_a2g_reach__init_A_const_64 = lang.RT_Var_String_String__Var(Lit_25, Lit_394); A_arbace_a2g_reach__init_A_const_65 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_360).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_395).Ref(), lang.Tuple_Create_O_O_O_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_236).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_237).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_185).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_238).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_239).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_106).Ref()))))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_396, lang.RT_Keyword_String_String__Keyword(nil, Lit_362).Ref(), jrt.Integer_ValueOf_I__Integer(406).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_363).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_364).Ref(), Lit_365)) }

func A_arbace_a2g_reach__init_A_New() *A_arbace_a2g_reach__init_A { A_arbace_a2g_reach__init_A_Init(); t := &A_arbace_a2g_reach__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach__init_A) Ctor() {}

func (t *A_arbace_a2g_reach__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach__init_A_class }

func (t *A_arbace_a2g_reach__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach__init_A); return ok }

func A_arbace_a2g_reach__init_A_Cast(x any) *A_arbace_a2g_reach__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach__init_A_class)) }; return v }
