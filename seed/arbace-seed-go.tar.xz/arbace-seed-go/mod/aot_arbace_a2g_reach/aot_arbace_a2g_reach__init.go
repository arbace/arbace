//line aot_arbace_a2g_reach__init.ae:1
package aot_arbace_a2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_reach__init_A_Unit0__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return lang.IFn_Cast(A_arbace_a2g_reach__init_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach__init_A_const_1) }
//line :1:1
func A_arbace_a2g_reach__init_A_Unit1__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_a2g_reach__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_2)) }
//line :1:1
func A_arbace_a2g_reach__init_A_Unit2__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); var tmp1 any = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_New(); var tmp2 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_124, false); A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class = fncls__1d; tmp2 = fncls__1d } else { tmp2 = fncls__1 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :1:1
func A_arbace_a2g_reach__init_A_Unit3__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(1, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_a2g_reach__init_A_const_1)).Equals_O__Z(A_arbace_a2g_reach__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_a2g_reach_eval214000008_fn__214000009_A_New(); var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_125, false); A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }



func A_arbace_a2g_reach__init_A_Load__O() any { A_arbace_a2g_reach__init_A_Init(); A_arbace_a2g_reach__init_A_Unit0__O(); A_arbace_a2g_reach__init_A_Unit1__O(); A_arbace_a2g_reach__init_A_Unit2__O(); A_arbace_a2g_reach__init_A_Unit3__O(); A_arbace_a2g_reach__init_A_Unit4__O(); A_arbace_a2g_reach__init_A_Unit5__O(); A_arbace_a2g_reach__init_A_Unit6__O(); A_arbace_a2g_reach__init_A_Unit7__O(); A_arbace_a2g_reach__init_A_Unit8__O(); A_arbace_a2g_reach__init_A_Unit9__O(); A_arbace_a2g_reach__init_A_Unit10__O(); A_arbace_a2g_reach__init_A_Unit11__O(); A_arbace_a2g_reach__init_A_Unit12__O(); A_arbace_a2g_reach__init_A_Unit13__O(); A_arbace_a2g_reach__init_A_Unit14__O(); A_arbace_a2g_reach__init_A_Unit15__O(); A_arbace_a2g_reach__init_A_Unit16__O(); A_arbace_a2g_reach__init_A_Unit17__O(); A_arbace_a2g_reach__init_A_Unit18__O(); A_arbace_a2g_reach__init_A_Unit19__O(); A_arbace_a2g_reach__init_A_Unit20__O(); A_arbace_a2g_reach__init_A_Unit21__O(); A_arbace_a2g_reach__init_A_Unit22__O(); A_arbace_a2g_reach__init_A_Unit23__O(); A_arbace_a2g_reach__init_A_Unit24__O(); A_arbace_a2g_reach__init_A_Unit25__O(); A_arbace_a2g_reach__init_A_Unit26__O(); A_arbace_a2g_reach__init_A_Unit27__O(); A_arbace_a2g_reach__init_A_Unit28__O(); A_arbace_a2g_reach__init_A_Unit29__O(); A_arbace_a2g_reach__init_A_Unit30__O(); A_arbace_a2g_reach__init_A_Unit31__O(); A_arbace_a2g_reach__init_A_Unit32__O(); A_arbace_a2g_reach__init_A_Unit33__O(); A_arbace_a2g_reach__init_A_Unit34__O(); A_arbace_a2g_reach__init_A_Unit35__O(); A_arbace_a2g_reach__init_A_Unit36__O(); A_arbace_a2g_reach__init_A_Unit37__O(); A_arbace_a2g_reach__init_A_Unit38__O(); A_arbace_a2g_reach__init_A_Unit39__O(); A_arbace_a2g_reach__init_A_Unit40__O(); A_arbace_a2g_reach__init_A_Unit41__O(); A_arbace_a2g_reach__init_A_Unit42__O(); A_arbace_a2g_reach__init_A_Unit43__O(); A_arbace_a2g_reach__init_A_Unit44__O(); A_arbace_a2g_reach__init_A_Unit45__O(); A_arbace_a2g_reach__init_A_Unit46__O(); A_arbace_a2g_reach__init_A_Unit47__O(); A_arbace_a2g_reach__init_A_Unit48__O(); A_arbace_a2g_reach__init_A_Unit49__O(); A_arbace_a2g_reach__init_A_Unit50__O(); A_arbace_a2g_reach__init_A_Unit51__O(); A_arbace_a2g_reach__init_A_Unit52__O(); A_arbace_a2g_reach__init_A_Unit53__O(); A_arbace_a2g_reach__init_A_Unit54__O(); A_arbace_a2g_reach__init_A_Unit55__O(); A_arbace_a2g_reach__init_A_Unit56__O(); A_arbace_a2g_reach__init_A_Unit57__O(); A_arbace_a2g_reach__init_A_Unit58__O(); A_arbace_a2g_reach__init_A_Unit59__O(); A_arbace_a2g_reach__init_A_Unit60__O(); A_arbace_a2g_reach__init_A_Unit61__O(); A_arbace_a2g_reach__init_A_Unit62__O(); A_arbace_a2g_reach__init_A_Unit63__O(); A_arbace_a2g_reach__init_A_Unit64__O(); A_arbace_a2g_reach__init_A_Unit65__O(); return nil }















func A_arbace_a2g_reach__init_A_Unit4__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(21, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_4; var tmp2 any = A_arbace_a2g_reach_node_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_reach_node_QMARK__A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_126, false); A_arbace_a2g_reach_node_QMARK__A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_4; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_5)); return A_arbace_a2g_reach__init_A_const_4 }

func A_arbace_a2g_reach__init_A_Unit5__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(23, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_6; var tmp2 any = A_arbace_a2g_reach_walk_nodes_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_reach_walk_nodes_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_127, false); A_arbace_a2g_reach_walk_nodes_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_6; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_7)); return A_arbace_a2g_reach__init_A_const_6 }

























func A_arbace_a2g_reach__init_A_Unit6__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(49, 1); A_arbace_a2g_reach__init_A_const_8.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_8; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_9)); return A_arbace_a2g_reach__init_A_const_8.SetDynamic_Z__Var(true).Ref() }





func A_arbace_a2g_reach__init_A_Unit7__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(55, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_10; tmp1.BindRoot_O__V(jrt.Object_New()); var tmp2 *lang.Var = A_arbace_a2g_reach__init_A_const_10; tmp2.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_11)); return A_arbace_a2g_reach__init_A_const_10 }



func A_arbace_a2g_reach__init_A_Unit8__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_12; var tmp2 any = A_arbace_a2g_reach_cached_A_New(); var tmp3 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_reach_cached_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_128, false); A_arbace_a2g_reach_cached_A_fn_class = fncls__5d; tmp3 = fncls__5d } else { tmp3 = fncls__5 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_12; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_13)); return A_arbace_a2g_reach__init_A_const_12 }
//line :59:1
func A_arbace_a2g_reach__init_A_Unit9__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); A_arbace_a2g_reach__init_A_const_12.SetMacro__V(); return nil }
//line :59:1
func A_arbace_a2g_reach__init_A_Unit10__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(59, 1); return A_arbace_a2g_reach__init_A_const_12 }











func A_arbace_a2g_reach__init_A_Unit11__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(71, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_14; var tmp2 any = A_arbace_a2g_reach_new_caches_A_New(); var tmp3 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_reach_new_caches_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_129, false); A_arbace_a2g_reach_new_caches_A_fn_class = fncls__6d; tmp3 = fncls__6d } else { tmp3 = fncls__6 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_14; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_15)); return A_arbace_a2g_reach__init_A_const_14 }



func A_arbace_a2g_reach__init_A_Unit12__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(75, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_16; var tmp2 any = A_arbace_a2g_reach_all_supers_A_New(); var tmp3 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_reach_all_supers_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_130, false); A_arbace_a2g_reach_all_supers_A_fn_class = fncls__7d; tmp3 = fncls__7d } else { tmp3 = fncls__7 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_16; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_17)); return A_arbace_a2g_reach__init_A_const_16 }




func A_arbace_a2g_reach__init_A_Unit13__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(80, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_18; var tmp2 any = A_arbace_a2g_reach_interface_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_a2g_reach_interface_QMARK__A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_131, false); A_arbace_a2g_reach_interface_QMARK__A_fn_class = fncls__8d; tmp3 = fncls__8d } else { tmp3 = fncls__8 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_18; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_19)); return A_arbace_a2g_reach__init_A_const_18 }

func A_arbace_a2g_reach__init_A_Unit14__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(82, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_20; var tmp2 any = A_arbace_a2g_reach_subclass_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_reach_subclass_QMARK__A_fn_class; if fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_132, false); A_arbace_a2g_reach_subclass_QMARK__A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_20; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_21)); return A_arbace_a2g_reach__init_A_const_20 }










func A_arbace_a2g_reach__init_A_Unit15__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(93, 1); A_arbace_a2g_reach__init_A_const_22.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_22; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_23)); return A_arbace_a2g_reach__init_A_const_22.SetDynamic_Z__Var(true).Ref() }





func A_arbace_a2g_reach__init_A_Unit16__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(99, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_24; var tmp2 any = A_arbace_a2g_reach_find_method_of_A_New(); var tmp3 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_reach_find_method_of_A_fn_class; if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_133, false); A_arbace_a2g_reach_find_method_of_A_fn_class = fncls__10d; tmp3 = fncls__10d } else { tmp3 = fncls__10 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_24; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_25)); return A_arbace_a2g_reach__init_A_const_24 }














func A_arbace_a2g_reach__init_A_Unit17__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(114, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_26; var tmp2 any = A_arbace_a2g_reach_body_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_reach_body_QMARK__A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_134, false); A_arbace_a2g_reach_body_QMARK__A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_26; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_27)); return A_arbace_a2g_reach__init_A_const_26 }

func A_arbace_a2g_reach__init_A_Unit18__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(116, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_28; var tmp2 any = A_arbace_a2g_reach_super_impl_A_New(); var tmp3 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_a2g_reach_super_impl_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_135, false); A_arbace_a2g_reach_super_impl_A_fn_class = fncls__12d; tmp3 = fncls__12d } else { tmp3 = fncls__12 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_28; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_29)); return A_arbace_a2g_reach__init_A_const_28 }
















func A_arbace_a2g_reach__init_A_Unit19__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(133, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_30; var tmp2 any = A_arbace_a2g_reach_java_impl_of_A_New(); var tmp3 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_reach_java_impl_of_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_136, false); A_arbace_a2g_reach_java_impl_of_A_fn_class = fncls__13d; tmp3 = fncls__13d } else { tmp3 = fncls__13 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_30; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_31)); return A_arbace_a2g_reach__init_A_const_30 }


















func A_arbace_a2g_reach__init_A_Unit20__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(152, 1); A_arbace_a2g_reach__init_A_const_32.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_32; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_33)); return A_arbace_a2g_reach__init_A_const_32.SetDynamic_Z__Var(true).Ref() }
func A_arbace_a2g_reach__init_A_Unit21__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(153, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_34; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach__init_A_const_35.GetRawRoot__O()); var tmp3 *jrt.Boolean; jrt.Boolean_Init(); tmp3 = jrt.Boolean_TRUE; tmp1.BindRoot_O__V(tmp2.Invoke_O__O(tmp3.Ref())); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_34; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_36)); return A_arbace_a2g_reach__init_A_const_34.SetDynamic_Z__Var(true).Ref() }



func A_arbace_a2g_reach__init_A_Unit22__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(157, 1); A_arbace_a2g_reach__init_A_const_37.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_37; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_38)); return A_arbace_a2g_reach__init_A_const_37.SetDynamic_Z__Var(true).Ref() }

func A_arbace_a2g_reach__init_A_Unit23__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(159, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_39; var tmp2 any = A_arbace_a2g_reach_note_unavailable_BANG__A_New(); var tmp3 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_137, false); A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class = fncls__14d; tmp3 = fncls__14d } else { tmp3 = fncls__14 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_39; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_40)); return A_arbace_a2g_reach__init_A_const_39 }



func A_arbace_a2g_reach__init_A_Unit24__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_41; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_42)); return A_arbace_a2g_reach__init_A_const_41 }
//line :163:1
func A_arbace_a2g_reach__init_A_Unit25__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_43; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_44)); return A_arbace_a2g_reach__init_A_const_43 }
//line :163:1
func A_arbace_a2g_reach__init_A_Unit26__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_45; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_46)); return A_arbace_a2g_reach__init_A_const_45 }
//line :163:1
func A_arbace_a2g_reach__init_A_Unit27__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_47; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_48)); return A_arbace_a2g_reach__init_A_const_47 }
//line :163:1
func A_arbace_a2g_reach__init_A_Unit28__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(163, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_49; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_50)); return A_arbace_a2g_reach__init_A_const_49 }

func A_arbace_a2g_reach__init_A_Unit29__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(165, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_51; var tmp2 any = A_arbace_a2g_reach_hw_has_static_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_138, false); A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class = fncls__15d; tmp3 = fncls__15d } else { tmp3 = fncls__15 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_51; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_52)); return A_arbace_a2g_reach__init_A_const_51 }






func A_arbace_a2g_reach__init_A_Unit30__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(172, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_53; var tmp2 any = A_arbace_a2g_reach_hw_has_field_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_139, false); A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class = fncls__16d; tmp3 = fncls__16d } else { tmp3 = fncls__16 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_53; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_54)); return A_arbace_a2g_reach__init_A_const_53 }







func A_arbace_a2g_reach__init_A_Unit31__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(180, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_41; var tmp2 any = A_arbace_a2g_reach_use_BANG__A_New(); var tmp3 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_reach_use_BANG__A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_140, false); A_arbace_a2g_reach_use_BANG__A_fn_class = fncls__17d; tmp3 = fncls__17d } else { tmp3 = fncls__17 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_41; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_55)); return A_arbace_a2g_reach__init_A_const_41 }










































func A_arbace_a2g_reach__init_A_Unit32__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(223, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_56; var tmp2 any = A_arbace_a2g_reach_use_STAR__A_New(); var tmp3 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_reach_use_STAR__A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_141, false); A_arbace_a2g_reach_use_STAR__A_fn_class = fncls__18d; tmp3 = fncls__18d } else { tmp3 = fncls__18 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_56; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_57)); return A_arbace_a2g_reach__init_A_const_56 }












func A_arbace_a2g_reach__init_A_Unit33__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(236, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_58; var tmp2 any = A_arbace_a2g_reach_uses_BANG__A_New(); var tmp3 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_reach_uses_BANG__A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_142, false); A_arbace_a2g_reach_uses_BANG__A_fn_class = fncls__19d; tmp3 = fncls__19d } else { tmp3 = fncls__19 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_58; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_59)); return A_arbace_a2g_reach__init_A_const_58 }




func A_arbace_a2g_reach__init_A_Unit34__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(241, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_60; var tmp2 any = A_arbace_a2g_reach_desc_classes_A_New(); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_a2g_reach_desc_classes_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_143, false); A_arbace_a2g_reach_desc_classes_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_60; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_61)); return A_arbace_a2g_reach__init_A_const_60 }




func A_arbace_a2g_reach__init_A_Unit35__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(246, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_62; var tmp2 any = A_arbace_a2g_reach_use_desc_BANG__A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_a2g_reach_use_desc_BANG__A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_144, false); A_arbace_a2g_reach_use_desc_BANG__A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_62; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_63)); return A_arbace_a2g_reach__init_A_const_62 }


func A_arbace_a2g_reach__init_A_Unit36__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(249, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_64; var tmp2 any = A_arbace_a2g_reach_reach_STAR__A_New(); var tmp3 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_a2g_reach_reach_STAR__A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_145, false); A_arbace_a2g_reach_reach_STAR__A_fn_class = fncls__22d; tmp3 = fncls__22d } else { tmp3 = fncls__22 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_64; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_65)); return A_arbace_a2g_reach__init_A_const_64 }







func A_arbace_a2g_reach__init_A_Unit37__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(257, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_45; var tmp2 any = A_arbace_a2g_reach_reach_BANG__A_New(); var tmp3 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_reach_reach_BANG__A_fn_class; if fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_146, false); A_arbace_a2g_reach_reach_BANG__A_fn_class = fncls__23d; tmp3 = fncls__23d } else { tmp3 = fncls__23 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_45; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_66)); return A_arbace_a2g_reach__init_A_const_45 }




func A_arbace_a2g_reach__init_A_Unit38__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(262, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_67; var tmp2 any = A_arbace_a2g_reach_init_STAR__A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_reach_init_STAR__A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_147, false); A_arbace_a2g_reach_init_STAR__A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_67; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_68)); return A_arbace_a2g_reach__init_A_const_67 }







func A_arbace_a2g_reach__init_A_Unit39__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(270, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_43; var tmp2 any = A_arbace_a2g_reach_init_BANG__A_New(); var tmp3 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_a2g_reach_init_BANG__A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_148, false); A_arbace_a2g_reach_init_BANG__A_fn_class = fncls__25d; tmp3 = fncls__25d } else { tmp3 = fncls__25 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_43; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_69)); return A_arbace_a2g_reach__init_A_const_43 }




func A_arbace_a2g_reach__init_A_Unit40__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(275, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_70; var tmp2 any = A_arbace_a2g_reach_own_external_keys_A_New(); var tmp3 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_reach_own_external_keys_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_149, false); A_arbace_a2g_reach_own_external_keys_A_fn_class = fncls__26d; tmp3 = fncls__26d } else { tmp3 = fncls__26 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_70; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_71)); return A_arbace_a2g_reach__init_A_const_70 }










func A_arbace_a2g_reach__init_A_Unit41__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(286, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_72; var tmp2 any = A_arbace_a2g_reach_external_keys_A_New(); var tmp3 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_reach_external_keys_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_150, false); A_arbace_a2g_reach_external_keys_A_fn_class = fncls__27d; tmp3 = fncls__27d } else { tmp3 = fncls__27 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_72; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_73)); return A_arbace_a2g_reach__init_A_const_72 }










func A_arbace_a2g_reach__init_A_Unit42__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(297, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_74; var tmp2 any = A_arbace_a2g_reach_supertypes_of_A_New(); var tmp3 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_a2g_reach_supertypes_of_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_151, false); A_arbace_a2g_reach_supertypes_of_A_fn_class = fncls__28d; tmp3 = fncls__28d } else { tmp3 = fncls__28 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_74; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_75)); return A_arbace_a2g_reach__init_A_const_74 }






func A_arbace_a2g_reach__init_A_Unit43__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(304, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_76; var tmp2 any = A_arbace_a2g_reach_reach_impls_BANG__A_New(); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_reach_reach_impls_BANG__A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_152, false); A_arbace_a2g_reach_reach_impls_BANG__A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_76; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_77)); return A_arbace_a2g_reach__init_A_const_76 }










func A_arbace_a2g_reach__init_A_Unit44__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(315, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_78; var tmp2 any = A_arbace_a2g_reach_instantiate_STAR__A_New(); var tmp3 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_a2g_reach_instantiate_STAR__A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_153, false); A_arbace_a2g_reach_instantiate_STAR__A_fn_class = fncls__30d; tmp3 = fncls__30d } else { tmp3 = fncls__30 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_78; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_79)); return A_arbace_a2g_reach__init_A_const_78 }








func A_arbace_a2g_reach__init_A_Unit45__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(324, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_49; var tmp2 any = A_arbace_a2g_reach_instantiate_BANG__A_New(); var tmp3 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_reach_instantiate_BANG__A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_154, false); A_arbace_a2g_reach_instantiate_BANG__A_fn_class = fncls__31d; tmp3 = fncls__31d } else { tmp3 = fncls__31 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_49; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_80)); return A_arbace_a2g_reach__init_A_const_49 }



func A_arbace_a2g_reach__init_A_Unit46__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(328, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_81; var tmp2 any = A_arbace_a2g_reach_vcall_STAR__A_New(); var tmp3 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_a2g_reach_vcall_STAR__A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_155, false); A_arbace_a2g_reach_vcall_STAR__A_fn_class = fncls__32d; tmp3 = fncls__32d } else { tmp3 = fncls__32 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_81; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_82)); return A_arbace_a2g_reach__init_A_const_81 }












func A_arbace_a2g_reach__init_A_Unit47__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(341, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_47; var tmp2 any = A_arbace_a2g_reach_vcall_BANG__A_New(); var tmp3 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_a2g_reach_vcall_BANG__A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_156, false); A_arbace_a2g_reach_vcall_BANG__A_fn_class = fncls__33d; tmp3 = fncls__33d } else { tmp3 = fncls__33 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_47; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_83)); return A_arbace_a2g_reach__init_A_const_47 }




func A_arbace_a2g_reach__init_A_Unit48__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(346, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_84; var tmp2 any = A_arbace_a2g_reach_lambda_BANG__A_New(); var tmp3 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_a2g_reach_lambda_BANG__A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_157, false); A_arbace_a2g_reach_lambda_BANG__A_fn_class = fncls__34d; tmp3 = fncls__34d } else { tmp3 = fncls__34 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_84; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_85)); return A_arbace_a2g_reach__init_A_const_84 }








func A_arbace_a2g_reach__init_A_Unit49__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(355, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_86; var tmp2 any = A_arbace_a2g_reach_hw_method_exists_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_reach_hw_method_exists_QMARK__A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_158, false); A_arbace_a2g_reach_hw_method_exists_QMARK__A_fn_class = fncls__35d; tmp3 = fncls__35d } else { tmp3 = fncls__35 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_86; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_87)); return A_arbace_a2g_reach__init_A_const_86 }












func A_arbace_a2g_reach__init_A_Unit50__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(368, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_88; var tmp2 any = A_arbace_a2g_reach_check_hw_call_BANG__A_New(); var tmp3 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_159, false); A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class = fncls__36d; tmp3 = fncls__36d } else { tmp3 = fncls__36 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_88; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_89)); return A_arbace_a2g_reach__init_A_const_88 }













func A_arbace_a2g_reach__init_A_Unit51__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(382, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_90; var tmp2 any = A_arbace_a2g_reach_vh_const_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_a2g_reach_vh_const_QMARK__A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_160, false); A_arbace_a2g_reach_vh_const_QMARK__A_fn_class = fncls__37d; tmp3 = fncls__37d } else { tmp3 = fncls__37 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_90; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_91)); return A_arbace_a2g_reach__init_A_const_90 }




func A_arbace_a2g_reach__init_A_Unit52__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(387, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_92; var tmp2 any = A_arbace_a2g_reach_vh_call_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_a2g_reach_vh_call_QMARK__A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_161, false); A_arbace_a2g_reach_vh_call_QMARK__A_fn_class = fncls__38d; tmp3 = fncls__38d } else { tmp3 = fncls__38 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_92; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_93)); return A_arbace_a2g_reach__init_A_const_92 }











func A_arbace_a2g_reach__init_A_Unit53__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(399, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_94; var tmp2 any = A_arbace_a2g_reach_scan_node_BANG__A_New(); var tmp3 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_162, false); A_arbace_a2g_reach_scan_node_BANG__A_fn_class = fncls__39d; tmp3 = fncls__39d } else { tmp3 = fncls__39 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_94; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_95)); return A_arbace_a2g_reach__init_A_const_94 }










































































































func A_arbace_a2g_reach__init_A_Unit54__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(506, 1); A_arbace_a2g_reach__init_A_const_96.BindRoot_O__V(nil); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_96; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_97)); return A_arbace_a2g_reach__init_A_const_96.SetDynamic_Z__Var(true).Ref() }




func A_arbace_a2g_reach__init_A_Unit55__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(511, 1); A_arbace_a2g_reach__init_A_const_98.BindRoot_O__V(A_arbace_a2g_reach__init_A_const_99); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_98; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_100)); return A_arbace_a2g_reach__init_A_const_98 }





func A_arbace_a2g_reach__init_A_Unit56__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(517, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_101; var tmp2 any = A_arbace_a2g_reach_hw_owner_QMARK__A_New(); var tmp3 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_a2g_reach_hw_owner_QMARK__A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_163, false); A_arbace_a2g_reach_hw_owner_QMARK__A_fn_class = fncls__40d; tmp3 = fncls__40d } else { tmp3 = fncls__40 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_101; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_102)); return A_arbace_a2g_reach__init_A_const_101 }




func A_arbace_a2g_reach__init_A_Unit57__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(522, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_103; var tmp2 any = A_arbace_a2g_reach_plan_node_A_New(); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_a2g_reach_plan_node_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_164, false); A_arbace_a2g_reach_plan_node_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_103; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_104)); return A_arbace_a2g_reach__init_A_const_103 }
























































































func A_arbace_a2g_reach__init_A_Unit58__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(611, 1); A_arbace_a2g_reach__init_A_const_105.BindRoot_O__V(A_arbace_a2g_reach__init_A_const_106); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_105; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_107)); return A_arbace_a2g_reach__init_A_const_105 }



func A_arbace_a2g_reach__init_A_Unit59__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(615, 1); A_arbace_a2g_reach__init_A_const_108.BindRoot_O__V(A_arbace_a2g_reach__init_A_const_109); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_108; tmp1.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_110)); return A_arbace_a2g_reach__init_A_const_108 }



func A_arbace_a2g_reach__init_A_Unit60__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(619, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_111; var tmp2 any = A_arbace_a2g_reach_scanned_nodes_A_New(); var tmp3 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_a2g_reach_scanned_nodes_A_fn_class; if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_165, false); A_arbace_a2g_reach_scanned_nodes_A_fn_class = fncls__42d; tmp3 = fncls__42d } else { tmp3 = fncls__42 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_111; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_112)); return A_arbace_a2g_reach__init_A_const_111 }






























func A_arbace_a2g_reach__init_A_Unit61__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(650, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_113; var tmp2 any = A_arbace_a2g_reach_plan_code_A_New(); var tmp3 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_a2g_reach_plan_code_A_fn_class; if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_166, false); A_arbace_a2g_reach_plan_code_A_fn_class = fncls__43d; tmp3 = fncls__43d } else { tmp3 = fncls__43 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_113; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_114)); return A_arbace_a2g_reach__init_A_const_113 }




func A_arbace_a2g_reach__init_A_Unit62__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(655, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_115; var tmp2 any = A_arbace_a2g_reach_scan_code_BANG__A_New(); var tmp3 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_a2g_reach_scan_code_BANG__A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_167, false); A_arbace_a2g_reach_scan_code_BANG__A_fn_class = fncls__44d; tmp3 = fncls__44d } else { tmp3 = fncls__44 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_115; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_116)); return A_arbace_a2g_reach__init_A_const_115 }





func A_arbace_a2g_reach__init_A_Unit63__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(661, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_117; var tmp2 any = A_arbace_a2g_reach_method_code_A_New(); var tmp3 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_a2g_reach_method_code_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_168, false); A_arbace_a2g_reach_method_code_A_fn_class = fncls__45d; tmp3 = fncls__45d } else { tmp3 = fncls__45 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_117; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_118)); return A_arbace_a2g_reach__init_A_const_117 }











func A_arbace_a2g_reach__init_A_Unit64__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(673, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_119; var tmp2 any = A_arbace_a2g_reach_scan_method_BANG__A_New(); var tmp3 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_a2g_reach_scan_method_BANG__A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_169, false); A_arbace_a2g_reach_scan_method_BANG__A_fn_class = fncls__46d; tmp3 = fncls__46d } else { tmp3 = fncls__46 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_119; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_120)); return A_arbace_a2g_reach__init_A_const_119 }






































func A_arbace_a2g_reach__init_A_Unit65__O() any { A_arbace_a2g_reach__init_A_Init(); lang.Compiler_AOT_At_I_I__V(712, 1); var tmp1 *lang.Var = A_arbace_a2g_reach__init_A_const_121; var tmp2 any = A_arbace_a2g_reach_run_A_New(); var tmp3 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_a2g_reach_run_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_170, false); A_arbace_a2g_reach_run_A_fn_class = fncls__47d; tmp3 = fncls__47d } else { tmp3 = fncls__47 }; tmp1.BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_a2g_reach__init_A_const_121; tmp4.SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_a2g_reach__init_A_const_122)); return A_arbace_a2g_reach__init_A_const_121 }



type A_arbace_a2g_reach__init_A struct{ jrt.Object }

var A_arbace_a2g_reach__init_A_const_pool *jrt.RefArray

var A_arbace_a2g_reach__init_A_const_0 *lang.Var

var A_arbace_a2g_reach__init_A_const_1 any

var A_arbace_a2g_reach__init_A_const_2 any

var A_arbace_a2g_reach__init_A_const_3 any

var A_arbace_a2g_reach__init_A_const_4 *lang.Var

var A_arbace_a2g_reach__init_A_const_5 any

var A_arbace_a2g_reach__init_A_const_6 *lang.Var

var A_arbace_a2g_reach__init_A_const_7 any

var A_arbace_a2g_reach__init_A_const_8 *lang.Var

var A_arbace_a2g_reach__init_A_const_9 any

var A_arbace_a2g_reach__init_A_const_10 *lang.Var

var A_arbace_a2g_reach__init_A_const_11 any

var A_arbace_a2g_reach__init_A_const_12 *lang.Var

var A_arbace_a2g_reach__init_A_const_13 any

var A_arbace_a2g_reach__init_A_const_14 *lang.Var

var A_arbace_a2g_reach__init_A_const_15 any

var A_arbace_a2g_reach__init_A_const_16 *lang.Var

var A_arbace_a2g_reach__init_A_const_17 any

var A_arbace_a2g_reach__init_A_const_18 *lang.Var

var A_arbace_a2g_reach__init_A_const_19 any

var A_arbace_a2g_reach__init_A_const_20 *lang.Var

var A_arbace_a2g_reach__init_A_const_21 any

var A_arbace_a2g_reach__init_A_const_22 *lang.Var

var A_arbace_a2g_reach__init_A_const_23 any

var A_arbace_a2g_reach__init_A_const_24 *lang.Var

var A_arbace_a2g_reach__init_A_const_25 any

var A_arbace_a2g_reach__init_A_const_26 *lang.Var

var A_arbace_a2g_reach__init_A_const_27 any

var A_arbace_a2g_reach__init_A_const_28 *lang.Var

var A_arbace_a2g_reach__init_A_const_29 any

var A_arbace_a2g_reach__init_A_const_30 *lang.Var

var A_arbace_a2g_reach__init_A_const_31 any

var A_arbace_a2g_reach__init_A_const_32 *lang.Var

var A_arbace_a2g_reach__init_A_const_33 any

var A_arbace_a2g_reach__init_A_const_34 *lang.Var

var A_arbace_a2g_reach__init_A_const_35 *lang.Var

var A_arbace_a2g_reach__init_A_const_36 any

var A_arbace_a2g_reach__init_A_const_37 *lang.Var

var A_arbace_a2g_reach__init_A_const_38 any

var A_arbace_a2g_reach__init_A_const_39 *lang.Var

var A_arbace_a2g_reach__init_A_const_40 any

var A_arbace_a2g_reach__init_A_const_41 *lang.Var

var A_arbace_a2g_reach__init_A_const_42 any

var A_arbace_a2g_reach__init_A_const_43 *lang.Var

var A_arbace_a2g_reach__init_A_const_44 any

var A_arbace_a2g_reach__init_A_const_45 *lang.Var

var A_arbace_a2g_reach__init_A_const_46 any

var A_arbace_a2g_reach__init_A_const_47 *lang.Var

var A_arbace_a2g_reach__init_A_const_48 any

var A_arbace_a2g_reach__init_A_const_49 *lang.Var

var A_arbace_a2g_reach__init_A_const_50 any

var A_arbace_a2g_reach__init_A_const_51 *lang.Var

var A_arbace_a2g_reach__init_A_const_52 any

var A_arbace_a2g_reach__init_A_const_53 *lang.Var

var A_arbace_a2g_reach__init_A_const_54 any

var A_arbace_a2g_reach__init_A_const_55 any

var A_arbace_a2g_reach__init_A_const_56 *lang.Var

var A_arbace_a2g_reach__init_A_const_57 any

var A_arbace_a2g_reach__init_A_const_58 *lang.Var

var A_arbace_a2g_reach__init_A_const_59 any

var A_arbace_a2g_reach__init_A_const_60 *lang.Var

var A_arbace_a2g_reach__init_A_const_61 any

var A_arbace_a2g_reach__init_A_const_62 *lang.Var

var A_arbace_a2g_reach__init_A_const_63 any

var A_arbace_a2g_reach__init_A_const_64 *lang.Var

var A_arbace_a2g_reach__init_A_const_65 any

var A_arbace_a2g_reach__init_A_const_66 any

var A_arbace_a2g_reach__init_A_const_67 *lang.Var

var A_arbace_a2g_reach__init_A_const_68 any

var A_arbace_a2g_reach__init_A_const_69 any

var A_arbace_a2g_reach__init_A_const_70 *lang.Var

var A_arbace_a2g_reach__init_A_const_71 any

var A_arbace_a2g_reach__init_A_const_72 *lang.Var

var A_arbace_a2g_reach__init_A_const_73 any

var A_arbace_a2g_reach__init_A_const_74 *lang.Var

var A_arbace_a2g_reach__init_A_const_75 any

var A_arbace_a2g_reach__init_A_const_76 *lang.Var

var A_arbace_a2g_reach__init_A_const_77 any

var A_arbace_a2g_reach__init_A_const_78 *lang.Var

var A_arbace_a2g_reach__init_A_const_79 any

var A_arbace_a2g_reach__init_A_const_80 any

var A_arbace_a2g_reach__init_A_const_81 *lang.Var

var A_arbace_a2g_reach__init_A_const_82 any

var A_arbace_a2g_reach__init_A_const_83 any

var A_arbace_a2g_reach__init_A_const_84 *lang.Var

var A_arbace_a2g_reach__init_A_const_85 any

var A_arbace_a2g_reach__init_A_const_86 *lang.Var

var A_arbace_a2g_reach__init_A_const_87 any

var A_arbace_a2g_reach__init_A_const_88 *lang.Var

var A_arbace_a2g_reach__init_A_const_89 any

var A_arbace_a2g_reach__init_A_const_90 *lang.Var

var A_arbace_a2g_reach__init_A_const_91 any

var A_arbace_a2g_reach__init_A_const_92 *lang.Var

var A_arbace_a2g_reach__init_A_const_93 any

var A_arbace_a2g_reach__init_A_const_94 *lang.Var

var A_arbace_a2g_reach__init_A_const_95 any

var A_arbace_a2g_reach__init_A_const_96 *lang.Var

var A_arbace_a2g_reach__init_A_const_97 any

var A_arbace_a2g_reach__init_A_const_98 *lang.Var

var A_arbace_a2g_reach__init_A_const_99 any

var A_arbace_a2g_reach__init_A_const_100 any

var A_arbace_a2g_reach__init_A_const_101 *lang.Var

var A_arbace_a2g_reach__init_A_const_102 any

var A_arbace_a2g_reach__init_A_const_103 *lang.Var

var A_arbace_a2g_reach__init_A_const_104 any

var A_arbace_a2g_reach__init_A_const_105 *lang.Var

var A_arbace_a2g_reach__init_A_const_106 any

var A_arbace_a2g_reach__init_A_const_107 any

var A_arbace_a2g_reach__init_A_const_108 *lang.Var

var A_arbace_a2g_reach__init_A_const_109 any

var A_arbace_a2g_reach__init_A_const_110 any

var A_arbace_a2g_reach__init_A_const_111 *lang.Var

var A_arbace_a2g_reach__init_A_const_112 any

var A_arbace_a2g_reach__init_A_const_113 *lang.Var

var A_arbace_a2g_reach__init_A_const_114 any

var A_arbace_a2g_reach__init_A_const_115 *lang.Var

var A_arbace_a2g_reach__init_A_const_116 any

var A_arbace_a2g_reach__init_A_const_117 *lang.Var

var A_arbace_a2g_reach__init_A_const_118 any

var A_arbace_a2g_reach__init_A_const_119 *lang.Var

var A_arbace_a2g_reach__init_A_const_120 any

var A_arbace_a2g_reach__init_A_const_121 *lang.Var

var A_arbace_a2g_reach__init_A_const_122 any

var A_arbace_a2g_reach__init_A_init jrt.ClassInit

func A_arbace_a2g_reach__init_A_Init() { if !A_arbace_a2g_reach__init_A_init.Done() { A_arbace_a2g_reach__init_A_init.Run(A_arbace_a2g_reach__init_A_clinit) } }

func A_arbace_a2g_reach__init_A_clinit() { A_arbace_a2g_reach__init_A_clinit_p0(); A_arbace_a2g_reach__init_A_clinit_p1(); A_arbace_a2g_reach__init_A_clinit_p2(); A_arbace_a2g_reach__init_A_clinit_p3(); A_arbace_a2g_reach__init_A_clinit_p4(); A_arbace_a2g_reach__init_A_clinit_p5(); A_arbace_a2g_reach__init_A_clinit_p6(); A_arbace_a2g_reach__init_A_clinit_p7(); A_arbace_a2g_reach__init_A_clinit_p8(); A_arbace_a2g_reach__init_A_clinit_p9() }

func A_arbace_a2g_reach__init_A_clinit_p0() { A_arbace_a2g_reach__init_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_123, 203); A_arbace_a2g_reach__init_A_const_0 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[80]); A_arbace_a2g_reach__init_A_const_1 = A_arbace_a2g_reach__init_A_const_pool.A[81]; A_arbace_a2g_reach__init_A_const_2 = A_arbace_a2g_reach__init_A_const_pool.A[82]; A_arbace_a2g_reach__init_A_const_3 = A_arbace_a2g_reach__init_A_const_pool.A[83]; A_arbace_a2g_reach__init_A_const_4 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[84]); A_arbace_a2g_reach__init_A_const_5 = A_arbace_a2g_reach__init_A_const_pool.A[85]; A_arbace_a2g_reach__init_A_const_6 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[86]); A_arbace_a2g_reach__init_A_const_7 = A_arbace_a2g_reach__init_A_const_pool.A[87]; A_arbace_a2g_reach__init_A_const_8 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[88]); A_arbace_a2g_reach__init_A_const_9 = A_arbace_a2g_reach__init_A_const_pool.A[89]; A_arbace_a2g_reach__init_A_const_10 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[90]); A_arbace_a2g_reach__init_A_const_11 = A_arbace_a2g_reach__init_A_const_pool.A[91]; A_arbace_a2g_reach__init_A_const_12 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[92]) }

func A_arbace_a2g_reach__init_A_clinit_p1() { A_arbace_a2g_reach__init_A_const_13 = A_arbace_a2g_reach__init_A_const_pool.A[93]; A_arbace_a2g_reach__init_A_const_14 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[94]); A_arbace_a2g_reach__init_A_const_15 = A_arbace_a2g_reach__init_A_const_pool.A[95]; A_arbace_a2g_reach__init_A_const_16 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[96]); A_arbace_a2g_reach__init_A_const_17 = A_arbace_a2g_reach__init_A_const_pool.A[97]; A_arbace_a2g_reach__init_A_const_18 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[98]); A_arbace_a2g_reach__init_A_const_19 = A_arbace_a2g_reach__init_A_const_pool.A[99]; A_arbace_a2g_reach__init_A_const_20 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[100]); A_arbace_a2g_reach__init_A_const_21 = A_arbace_a2g_reach__init_A_const_pool.A[101]; A_arbace_a2g_reach__init_A_const_22 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[102]); A_arbace_a2g_reach__init_A_const_23 = A_arbace_a2g_reach__init_A_const_pool.A[103]; A_arbace_a2g_reach__init_A_const_24 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[104]); A_arbace_a2g_reach__init_A_const_25 = A_arbace_a2g_reach__init_A_const_pool.A[105] }

func A_arbace_a2g_reach__init_A_clinit_p2() { A_arbace_a2g_reach__init_A_const_26 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[106]); A_arbace_a2g_reach__init_A_const_27 = A_arbace_a2g_reach__init_A_const_pool.A[107]; A_arbace_a2g_reach__init_A_const_28 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[108]); A_arbace_a2g_reach__init_A_const_29 = A_arbace_a2g_reach__init_A_const_pool.A[109]; A_arbace_a2g_reach__init_A_const_30 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[110]); A_arbace_a2g_reach__init_A_const_31 = A_arbace_a2g_reach__init_A_const_pool.A[111]; A_arbace_a2g_reach__init_A_const_32 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[112]); A_arbace_a2g_reach__init_A_const_33 = A_arbace_a2g_reach__init_A_const_pool.A[113]; A_arbace_a2g_reach__init_A_const_34 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[114]); A_arbace_a2g_reach__init_A_const_35 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[115]); A_arbace_a2g_reach__init_A_const_36 = A_arbace_a2g_reach__init_A_const_pool.A[116]; A_arbace_a2g_reach__init_A_const_37 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[117]); A_arbace_a2g_reach__init_A_const_38 = A_arbace_a2g_reach__init_A_const_pool.A[118] }

func A_arbace_a2g_reach__init_A_clinit_p3() { A_arbace_a2g_reach__init_A_const_39 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[119]); A_arbace_a2g_reach__init_A_const_40 = A_arbace_a2g_reach__init_A_const_pool.A[120]; A_arbace_a2g_reach__init_A_const_41 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[121]); A_arbace_a2g_reach__init_A_const_42 = A_arbace_a2g_reach__init_A_const_pool.A[122]; A_arbace_a2g_reach__init_A_const_43 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[123]); A_arbace_a2g_reach__init_A_const_44 = A_arbace_a2g_reach__init_A_const_pool.A[124]; A_arbace_a2g_reach__init_A_const_45 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[125]); A_arbace_a2g_reach__init_A_const_46 = A_arbace_a2g_reach__init_A_const_pool.A[126]; A_arbace_a2g_reach__init_A_const_47 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[127]); A_arbace_a2g_reach__init_A_const_48 = A_arbace_a2g_reach__init_A_const_pool.A[128]; A_arbace_a2g_reach__init_A_const_49 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[129]); A_arbace_a2g_reach__init_A_const_50 = A_arbace_a2g_reach__init_A_const_pool.A[130]; A_arbace_a2g_reach__init_A_const_51 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[131]) }

func A_arbace_a2g_reach__init_A_clinit_p4() { A_arbace_a2g_reach__init_A_const_52 = A_arbace_a2g_reach__init_A_const_pool.A[132]; A_arbace_a2g_reach__init_A_const_53 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[133]); A_arbace_a2g_reach__init_A_const_54 = A_arbace_a2g_reach__init_A_const_pool.A[134]; A_arbace_a2g_reach__init_A_const_55 = A_arbace_a2g_reach__init_A_const_pool.A[135]; A_arbace_a2g_reach__init_A_const_56 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[136]); A_arbace_a2g_reach__init_A_const_57 = A_arbace_a2g_reach__init_A_const_pool.A[137]; A_arbace_a2g_reach__init_A_const_58 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[138]); A_arbace_a2g_reach__init_A_const_59 = A_arbace_a2g_reach__init_A_const_pool.A[139]; A_arbace_a2g_reach__init_A_const_60 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[140]); A_arbace_a2g_reach__init_A_const_61 = A_arbace_a2g_reach__init_A_const_pool.A[141]; A_arbace_a2g_reach__init_A_const_62 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[142]); A_arbace_a2g_reach__init_A_const_63 = A_arbace_a2g_reach__init_A_const_pool.A[143]; A_arbace_a2g_reach__init_A_const_64 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[144]); A_arbace_a2g_reach__init_A_const_65 = A_arbace_a2g_reach__init_A_const_pool.A[145] }

func A_arbace_a2g_reach__init_A_clinit_p5() { A_arbace_a2g_reach__init_A_const_66 = A_arbace_a2g_reach__init_A_const_pool.A[146]; A_arbace_a2g_reach__init_A_const_67 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[147]); A_arbace_a2g_reach__init_A_const_68 = A_arbace_a2g_reach__init_A_const_pool.A[148]; A_arbace_a2g_reach__init_A_const_69 = A_arbace_a2g_reach__init_A_const_pool.A[149]; A_arbace_a2g_reach__init_A_const_70 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[150]); A_arbace_a2g_reach__init_A_const_71 = A_arbace_a2g_reach__init_A_const_pool.A[151]; A_arbace_a2g_reach__init_A_const_72 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[152]); A_arbace_a2g_reach__init_A_const_73 = A_arbace_a2g_reach__init_A_const_pool.A[153]; A_arbace_a2g_reach__init_A_const_74 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[154]); A_arbace_a2g_reach__init_A_const_75 = A_arbace_a2g_reach__init_A_const_pool.A[155]; A_arbace_a2g_reach__init_A_const_76 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[156]); A_arbace_a2g_reach__init_A_const_77 = A_arbace_a2g_reach__init_A_const_pool.A[157]; A_arbace_a2g_reach__init_A_const_78 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[158]); A_arbace_a2g_reach__init_A_const_79 = A_arbace_a2g_reach__init_A_const_pool.A[159] }

func A_arbace_a2g_reach__init_A_clinit_p6() { A_arbace_a2g_reach__init_A_const_80 = A_arbace_a2g_reach__init_A_const_pool.A[160]; A_arbace_a2g_reach__init_A_const_81 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[161]); A_arbace_a2g_reach__init_A_const_82 = A_arbace_a2g_reach__init_A_const_pool.A[162]; A_arbace_a2g_reach__init_A_const_83 = A_arbace_a2g_reach__init_A_const_pool.A[163]; A_arbace_a2g_reach__init_A_const_84 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[164]); A_arbace_a2g_reach__init_A_const_85 = A_arbace_a2g_reach__init_A_const_pool.A[165]; A_arbace_a2g_reach__init_A_const_86 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[166]); A_arbace_a2g_reach__init_A_const_87 = A_arbace_a2g_reach__init_A_const_pool.A[167]; A_arbace_a2g_reach__init_A_const_88 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[168]); A_arbace_a2g_reach__init_A_const_89 = A_arbace_a2g_reach__init_A_const_pool.A[169]; A_arbace_a2g_reach__init_A_const_90 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[170]); A_arbace_a2g_reach__init_A_const_91 = A_arbace_a2g_reach__init_A_const_pool.A[171]; A_arbace_a2g_reach__init_A_const_92 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[172]); A_arbace_a2g_reach__init_A_const_93 = A_arbace_a2g_reach__init_A_const_pool.A[173] }

func A_arbace_a2g_reach__init_A_clinit_p7() { A_arbace_a2g_reach__init_A_const_94 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[174]); A_arbace_a2g_reach__init_A_const_95 = A_arbace_a2g_reach__init_A_const_pool.A[175]; A_arbace_a2g_reach__init_A_const_96 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[176]); A_arbace_a2g_reach__init_A_const_97 = A_arbace_a2g_reach__init_A_const_pool.A[177]; A_arbace_a2g_reach__init_A_const_98 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[178]); A_arbace_a2g_reach__init_A_const_99 = A_arbace_a2g_reach__init_A_const_pool.A[179]; A_arbace_a2g_reach__init_A_const_100 = A_arbace_a2g_reach__init_A_const_pool.A[180]; A_arbace_a2g_reach__init_A_const_101 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[181]); A_arbace_a2g_reach__init_A_const_102 = A_arbace_a2g_reach__init_A_const_pool.A[182]; A_arbace_a2g_reach__init_A_const_103 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[183]); A_arbace_a2g_reach__init_A_const_104 = A_arbace_a2g_reach__init_A_const_pool.A[184]; A_arbace_a2g_reach__init_A_const_105 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[185]); A_arbace_a2g_reach__init_A_const_106 = A_arbace_a2g_reach__init_A_const_pool.A[186]; A_arbace_a2g_reach__init_A_const_107 = A_arbace_a2g_reach__init_A_const_pool.A[187] }

func A_arbace_a2g_reach__init_A_clinit_p8() { A_arbace_a2g_reach__init_A_const_108 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[188]); A_arbace_a2g_reach__init_A_const_109 = A_arbace_a2g_reach__init_A_const_pool.A[189]; A_arbace_a2g_reach__init_A_const_110 = A_arbace_a2g_reach__init_A_const_pool.A[190]; A_arbace_a2g_reach__init_A_const_111 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[191]); A_arbace_a2g_reach__init_A_const_112 = A_arbace_a2g_reach__init_A_const_pool.A[192]; A_arbace_a2g_reach__init_A_const_113 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[193]); A_arbace_a2g_reach__init_A_const_114 = A_arbace_a2g_reach__init_A_const_pool.A[194]; A_arbace_a2g_reach__init_A_const_115 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[195]); A_arbace_a2g_reach__init_A_const_116 = A_arbace_a2g_reach__init_A_const_pool.A[196]; A_arbace_a2g_reach__init_A_const_117 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[197]); A_arbace_a2g_reach__init_A_const_118 = A_arbace_a2g_reach__init_A_const_pool.A[198]; A_arbace_a2g_reach__init_A_const_119 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[199]); A_arbace_a2g_reach__init_A_const_120 = A_arbace_a2g_reach__init_A_const_pool.A[200] }

func A_arbace_a2g_reach__init_A_clinit_p9() { A_arbace_a2g_reach__init_A_const_121 = lang.Var_Cast(A_arbace_a2g_reach__init_A_const_pool.A[201]); A_arbace_a2g_reach__init_A_const_122 = A_arbace_a2g_reach__init_A_const_pool.A[202] }

func A_arbace_a2g_reach__init_A_New() *A_arbace_a2g_reach__init_A { A_arbace_a2g_reach__init_A_Init(); t := &A_arbace_a2g_reach__init_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach__init_A) Ctor() {}

func (t *A_arbace_a2g_reach__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach__init_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach__init_A_class }

func (t *A_arbace_a2g_reach__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach__init_A); return ok }

func A_arbace_a2g_reach__init_A_Cast(x any) *A_arbace_a2g_reach__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach__init_A_class)) }; return v }
