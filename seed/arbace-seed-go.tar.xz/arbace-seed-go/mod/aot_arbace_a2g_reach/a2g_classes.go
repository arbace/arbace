//line a2g_classes.ae:1
package aot_arbace_a2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_a2g_reach_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_A_New()}; return nil }

var A_arbace_a2g_reach_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_reach_A_new}

var A_arbace_a2g_reach_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_A"})

func init() { i := A_arbace_a2g_reach_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_A_InstanceOf; i.Init = A_arbace_a2g_reach_A_Init; i.Table = A_arbace_a2g_reach_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_A_class, reflect.TypeFor[A_arbace_a2g_reach_A]()) }

func A_arbace_a2g_reach_check_hw_call_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_check_hw_call_BANG__A).Invoke_O_O_O_O_O__O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_reach_check_hw_call_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_check_hw_call_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_check_hw_call_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_check_hw_call_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_check_hw_call_BANG__A_invoke, New: A_arbace_a2g_reach_check_hw_call_BANG__A_new, Get: A_arbace_a2g_reach_check_hw_call_BANG__A_get}

var A_arbace_a2g_reach_check_hw_call_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$check_hw_call_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF4_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "check_hw_call_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_check_hw_call_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_check_hw_call_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_check_hw_call_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_check_hw_call_BANG__A_Init; i.Table = A_arbace_a2g_reach_check_hw_call_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_check_hw_call_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_check_hw_call_BANG__A]()) }

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_fn_class)}; return nil }

var A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_invoke, New: A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_new, Get: A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_get}

var A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$check_hw_call_BANG_$fn__214000181", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_check_hw_call_BANG__A_class, Simple: "fn__214000181", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_InstanceOf; i.Init = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_Init; i.Table = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_class, reflect.TypeFor[A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A]()) }

func A_arbace_a2g_reach_class_of_desc_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_class_of_desc_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_class_of_desc_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_class_of_desc_A_New()}; return nil }

func A_arbace_a2g_reach_class_of_desc_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_class_of_desc_A_fn_class)}; return nil }

var A_arbace_a2g_reach_class_of_desc_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_class_of_desc_A_invoke, New: A_arbace_a2g_reach_class_of_desc_A_new, Get: A_arbace_a2g_reach_class_of_desc_A_get}

var A_arbace_a2g_reach_class_of_desc_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$class_of_desc", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "class_of_desc", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_class_of_desc_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_class_of_desc_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_class_of_desc_A_InstanceOf; i.Init = A_arbace_a2g_reach_class_of_desc_A_Init; i.Table = A_arbace_a2g_reach_class_of_desc_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_class_of_desc_A_class, reflect.TypeFor[A_arbace_a2g_reach_class_of_desc_A]()) }

func A_arbace_a2g_reach_eval214000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_eval214000004_A_New()}; return nil }

var A_arbace_a2g_reach_eval214000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_reach_eval214000004_A_new}

var A_arbace_a2g_reach_eval214000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$eval214000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_reach_A_class, Simple: "eval214000004", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_eval214000004_A"})

func init() { i := A_arbace_a2g_reach_eval214000004_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_eval214000004_A_InstanceOf; i.Table = A_arbace_a2g_reach_eval214000004_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_eval214000004_A_class, reflect.TypeFor[A_arbace_a2g_reach_eval214000004_A]()) }

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_New()}; return nil }

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class)}; return nil }

var A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_invoke, New: A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_new, Get: A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_get}

var A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$eval214000004$loading__1927001464__auto____214000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_eval214000004_A_class, Simple: "loading__1927001464__auto____214000005", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_InstanceOf; i.Init = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_Init; i.Table = A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_class, reflect.TypeFor[A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A]()) }

func A_arbace_a2g_reach_eval214000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_eval214000008_A_New()}; return nil }

var A_arbace_a2g_reach_eval214000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_a2g_reach_eval214000008_A_new}

var A_arbace_a2g_reach_eval214000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$eval214000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_a2g_reach_A_class, Simple: "eval214000008", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_eval214000008_A"})

func init() { i := A_arbace_a2g_reach_eval214000008_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_eval214000008_A_InstanceOf; i.Table = A_arbace_a2g_reach_eval214000008_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_eval214000008_A_class, reflect.TypeFor[A_arbace_a2g_reach_eval214000008_A]()) }

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_eval214000008_fn__214000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_eval214000008_fn__214000009_A_New()}; return nil }

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class)}; return nil }

var A_arbace_a2g_reach_eval214000008_fn__214000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_eval214000008_fn__214000009_A_invoke, New: A_arbace_a2g_reach_eval214000008_fn__214000009_A_new, Get: A_arbace_a2g_reach_eval214000008_fn__214000009_A_get}

var A_arbace_a2g_reach_eval214000008_fn__214000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$eval214000008$fn__214000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_eval214000008_A_class, Simple: "fn__214000009", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_eval214000008_fn__214000009_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_eval214000008_fn__214000009_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_eval214000008_fn__214000009_A_InstanceOf; i.Init = A_arbace_a2g_reach_eval214000008_fn__214000009_A_Init; i.Table = A_arbace_a2g_reach_eval214000008_fn__214000009_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_eval214000008_fn__214000009_A_class, reflect.TypeFor[A_arbace_a2g_reach_eval214000008_fn__214000009_A]()) }

func A_arbace_a2g_reach_external_keys_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_external_keys_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_external_keys_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_external_keys_A_New()}; return nil }

func A_arbace_a2g_reach_external_keys_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_external_keys_A_fn_class)}; return nil }

var A_arbace_a2g_reach_external_keys_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_external_keys_A_invoke, New: A_arbace_a2g_reach_external_keys_A_new, Get: A_arbace_a2g_reach_external_keys_A_get}

var A_arbace_a2g_reach_external_keys_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$external_keys", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "external_keys", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_external_keys_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_external_keys_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_external_keys_A_InstanceOf; i.Init = A_arbace_a2g_reach_external_keys_A_Init; i.Table = A_arbace_a2g_reach_external_keys_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_external_keys_A_class, reflect.TypeFor[A_arbace_a2g_reach_external_keys_A]()) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_New()}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_fn_class)}; return nil }

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_invoke, New: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_new, Get: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_get}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$external_keys$iter__214000112__214000118", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_external_keys_A_class, Simple: "iter__214000112__214000118", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_InstanceOf; i.Init = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_Init; i.Table = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_class, reflect.TypeFor[A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A]()) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_fn_class)}; return nil }

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_invoke, New: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_new, Get: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_get}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_class, Simple: "fn__214000119", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_InstanceOf; i.Init = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_Init; i.Table = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_class, reflect.TypeFor[A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A]()) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_New()}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_fn_class)}; return nil }

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_invoke, New: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_new, Get: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_get}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_class, Simple: "iter__214000114__214000120", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_InstanceOf; i.Init = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_Init; i.Table = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_class, reflect.TypeFor[A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A]()) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_fn_class)}; return nil }

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_invoke, New: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_new, Get: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_get}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120$fn__214000121", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_class, Simple: "fn__214000121", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_InstanceOf; i.Init = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_Init; i.Table = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_class, reflect.TypeFor[A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A]()) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_fn_class)}; return nil }

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_invoke, New: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_new, Get: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_get}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$external_keys$iter__214000112__214000118$fn__214000119$iter__214000114__214000120$fn__214000121$fn__214000122", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_class, Simple: "fn__214000122", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_InstanceOf; i.Init = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_Init; i.Table = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_class, reflect.TypeFor[A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A]()) }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_hw_has_field_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_hw_has_field_QMARK__A_New()}; return nil }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_reach_hw_has_field_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_hw_has_field_QMARK__A_invoke, New: A_arbace_a2g_reach_hw_has_field_QMARK__A_new, Get: A_arbace_a2g_reach_hw_has_field_QMARK__A_get}

var A_arbace_a2g_reach_hw_has_field_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$hw_has_field_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "hw_has_field_QMARK_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_hw_has_field_QMARK__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_hw_has_field_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_hw_has_field_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_reach_hw_has_field_QMARK__A_Init; i.Table = A_arbace_a2g_reach_hw_has_field_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_hw_has_field_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_reach_hw_has_field_QMARK__A]()) }

func A_arbace_a2g_reach_hw_has_static_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_hw_has_static_QMARK__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_reach_hw_has_static_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_hw_has_static_QMARK__A_New()}; return nil }

func A_arbace_a2g_reach_hw_has_static_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_reach_hw_has_static_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_hw_has_static_QMARK__A_invoke, New: A_arbace_a2g_reach_hw_has_static_QMARK__A_new, Get: A_arbace_a2g_reach_hw_has_static_QMARK__A_get}

var A_arbace_a2g_reach_hw_has_static_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$hw_has_static_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "hw_has_static_QMARK_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_hw_has_static_QMARK__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_hw_has_static_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_hw_has_static_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_reach_hw_has_static_QMARK__A_Init; i.Table = A_arbace_a2g_reach_hw_has_static_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_hw_has_static_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_reach_hw_has_static_QMARK__A]()) }

func A_arbace_a2g_reach_init_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_init_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_init_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_init_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_init_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_init_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_init_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_init_BANG__A_invoke, New: A_arbace_a2g_reach_init_BANG__A_new, Get: A_arbace_a2g_reach_init_BANG__A_get}

var A_arbace_a2g_reach_init_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$init_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "init_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_init_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_init_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_init_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_init_BANG__A_Init; i.Table = A_arbace_a2g_reach_init_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_init_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_init_BANG__A]()) }

func A_arbace_a2g_reach_instantiate_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_instantiate_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_instantiate_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_instantiate_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_instantiate_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_instantiate_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_instantiate_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_instantiate_BANG__A_invoke, New: A_arbace_a2g_reach_instantiate_BANG__A_new, Get: A_arbace_a2g_reach_instantiate_BANG__A_get}

var A_arbace_a2g_reach_instantiate_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$instantiate_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "instantiate_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_instantiate_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_instantiate_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_instantiate_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_instantiate_BANG__A_Init; i.Table = A_arbace_a2g_reach_instantiate_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_instantiate_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_instantiate_BANG__A]()) }

func A_arbace_a2g_reach_java_impl_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_reach_java_impl_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_A_New()}; return nil }

func A_arbace_a2g_reach_java_impl_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_A_invoke, New: A_arbace_a2g_reach_java_impl_of_A_new, Get: A_arbace_a2g_reach_java_impl_of_A_get}

var A_arbace_a2g_reach_java_impl_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "java_impl_of", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_A]()) }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_fn__214000052_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_fn__214000052_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_fn__214000052_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_fn__214000052_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_fn__214000052_A_invoke, New: A_arbace_a2g_reach_java_impl_of_fn__214000052_A_new, Get: A_arbace_a2g_reach_java_impl_of_fn__214000052_A_get}

var A_arbace_a2g_reach_java_impl_of_fn__214000052_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$fn__214000052", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_A_class, Simple: "fn__214000052", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_fn__214000052_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_fn__214000052_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_fn__214000052_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_fn__214000052_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_fn__214000052_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_fn__214000052_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_fn__214000052_A]()) }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_invoke, New: A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_new, Get: A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_get}

var A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$fn__214000052$fn__214000053", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_fn__214000052_A_class, Simple: "fn__214000053", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A]()) }

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_fn__214000056_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_fn__214000056_A_New()}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_fn__214000056_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_fn__214000056_A_invoke, New: A_arbace_a2g_reach_java_impl_of_fn__214000056_A_new, Get: A_arbace_a2g_reach_java_impl_of_fn__214000056_A_get}

var A_arbace_a2g_reach_java_impl_of_fn__214000056_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$fn__214000056", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_A_class, Simple: "fn__214000056", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_fn__214000056_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_fn__214000056_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_fn__214000056_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_fn__214000056_A]()) }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_fn__214000072_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_fn__214000072_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_fn__214000072_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_fn__214000072_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_fn__214000072_A_invoke, New: A_arbace_a2g_reach_java_impl_of_fn__214000072_A_new, Get: A_arbace_a2g_reach_java_impl_of_fn__214000072_A_get}

var A_arbace_a2g_reach_java_impl_of_fn__214000072_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$fn__214000072", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_A_class, Simple: "fn__214000072", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_fn__214000072_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_fn__214000072_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_fn__214000072_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_fn__214000072_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_fn__214000072_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_fn__214000072_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_fn__214000072_A]()) }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_invoke, New: A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_new, Get: A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_get}

var A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$fn__214000072$fn__214000073", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_fn__214000072_A_class, Simple: "fn__214000073", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A]()) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_invoke, New: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_new, Get: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_get}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$iter__214000058__214000062", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_A_class, Simple: "iter__214000058__214000062", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A]()) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_invoke, New: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_new, Get: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_get}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_class, Simple: "fn__214000063", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A]()) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_New_O_O_O_O_I_O(args[0], args[1], args[2], args[3], args[4].(int32), args[5])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_invoke, New: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_new, Get: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_get}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000064", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class, Simple: "fn__214000064", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A]()) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_invoke, New: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_new, Get: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_get}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000064$fn__214000065", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_class, Simple: "fn__214000065", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A]()) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_fn_class)}; return nil }

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_invoke, New: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_new, Get: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_get}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$java_impl_of$iter__214000058__214000062$fn__214000063$fn__214000068", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class, Simple: "fn__214000068", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_InstanceOf; i.Init = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_Init; i.Table = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_class, reflect.TypeFor[A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A]()) }

func A_arbace_a2g_reach_lambda_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_lambda_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_lambda_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_lambda_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_lambda_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_lambda_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_lambda_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_lambda_BANG__A_invoke, New: A_arbace_a2g_reach_lambda_BANG__A_new, Get: A_arbace_a2g_reach_lambda_BANG__A_get}

var A_arbace_a2g_reach_lambda_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$lambda_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "lambda_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_lambda_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_lambda_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_lambda_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_lambda_BANG__A_Init; i.Table = A_arbace_a2g_reach_lambda_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_lambda_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_lambda_BANG__A]()) }

func A_arbace_a2g_reach_method_code_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_method_code_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_method_code_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_method_code_A_New()}; return nil }

func A_arbace_a2g_reach_method_code_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_method_code_A_fn_class)}; return nil }

var A_arbace_a2g_reach_method_code_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_method_code_A_invoke, New: A_arbace_a2g_reach_method_code_A_new, Get: A_arbace_a2g_reach_method_code_A_get}

var A_arbace_a2g_reach_method_code_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$method_code", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "method_code", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_method_code_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_method_code_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_method_code_A_InstanceOf; i.Init = A_arbace_a2g_reach_method_code_A_Init; i.Table = A_arbace_a2g_reach_method_code_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_method_code_A_class, reflect.TypeFor[A_arbace_a2g_reach_method_code_A]()) }

func A_arbace_a2g_reach_node_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_node_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_node_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_node_QMARK__A_New()}; return nil }

func A_arbace_a2g_reach_node_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_node_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_reach_node_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_node_QMARK__A_invoke, New: A_arbace_a2g_reach_node_QMARK__A_new, Get: A_arbace_a2g_reach_node_QMARK__A_get}

var A_arbace_a2g_reach_node_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$node_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "node_QMARK_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_node_QMARK__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_node_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_node_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_reach_node_QMARK__A_Init; i.Table = A_arbace_a2g_reach_node_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_node_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_reach_node_QMARK__A]()) }

func A_arbace_a2g_reach_note_unavailable_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_note_unavailable_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_note_unavailable_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_note_unavailable_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_note_unavailable_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_note_unavailable_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_note_unavailable_BANG__A_invoke, New: A_arbace_a2g_reach_note_unavailable_BANG__A_new, Get: A_arbace_a2g_reach_note_unavailable_BANG__A_get}

var A_arbace_a2g_reach_note_unavailable_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$note_unavailable_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "note_unavailable_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_note_unavailable_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_note_unavailable_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_note_unavailable_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_note_unavailable_BANG__A_Init; i.Table = A_arbace_a2g_reach_note_unavailable_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_note_unavailable_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_note_unavailable_BANG__A]()) }

func A_arbace_a2g_reach_reach_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_reach_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_reach_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_reach_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_reach_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_reach_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_reach_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_reach_BANG__A_invoke, New: A_arbace_a2g_reach_reach_BANG__A_new, Get: A_arbace_a2g_reach_reach_BANG__A_get}

var A_arbace_a2g_reach_reach_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$reach_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "reach_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_reach_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_reach_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_reach_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_reach_BANG__A_Init; i.Table = A_arbace_a2g_reach_reach_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_reach_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_reach_BANG__A]()) }

func A_arbace_a2g_reach_run_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_run_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_run_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_run_A_New()}; return nil }

func A_arbace_a2g_reach_run_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_run_A_fn_class)}; return nil }

var A_arbace_a2g_reach_run_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_run_A_invoke, New: A_arbace_a2g_reach_run_A_new, Get: A_arbace_a2g_reach_run_A_get}

var A_arbace_a2g_reach_run_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$run", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "run", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_run_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_run_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_run_A_InstanceOf; i.Init = A_arbace_a2g_reach_run_A_Init; i.Table = A_arbace_a2g_reach_run_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_run_A_class, reflect.TypeFor[A_arbace_a2g_reach_run_A]()) }

func A_arbace_a2g_reach_run_fn__214000327_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_run_fn__214000327_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_run_fn__214000327_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_run_fn__214000327_A_New_O_O_O_O_O(args[0], args[1], args[2], args[3], args[4])}; return nil }

func A_arbace_a2g_reach_run_fn__214000327_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_run_fn__214000327_A_fn_class)}; return nil }

var A_arbace_a2g_reach_run_fn__214000327_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_run_fn__214000327_A_invoke, New: A_arbace_a2g_reach_run_fn__214000327_A_new, Get: A_arbace_a2g_reach_run_fn__214000327_A_get}

var A_arbace_a2g_reach_run_fn__214000327_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$run$fn__214000327", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_run_A_class, Simple: "fn__214000327", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_run_fn__214000327_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_run_fn__214000327_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_run_fn__214000327_A_InstanceOf; i.Init = A_arbace_a2g_reach_run_fn__214000327_A_Init; i.Table = A_arbace_a2g_reach_run_fn__214000327_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_run_fn__214000327_A_class, reflect.TypeFor[A_arbace_a2g_reach_run_fn__214000327_A]()) }

func A_arbace_a2g_reach_scan_code_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_code_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_code_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_code_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_scan_code_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_code_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_code_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_code_BANG__A_invoke, New: A_arbace_a2g_reach_scan_code_BANG__A_new, Get: A_arbace_a2g_reach_scan_code_BANG__A_get}

var A_arbace_a2g_reach_scan_code_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_code_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "scan_code_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_code_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_code_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_code_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_code_BANG__A_Init; i.Table = A_arbace_a2g_reach_scan_code_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_code_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_code_BANG__A]()) }

func A_arbace_a2g_reach_scan_method_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_method_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_method_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_method_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_scan_method_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_method_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_method_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_method_BANG__A_invoke, New: A_arbace_a2g_reach_scan_method_BANG__A_new, Get: A_arbace_a2g_reach_scan_method_BANG__A_get}

var A_arbace_a2g_reach_scan_method_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_method_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "scan_method_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_method_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_method_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_method_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_method_BANG__A_Init; i.Table = A_arbace_a2g_reach_scan_method_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_method_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_method_BANG__A]()) }

func A_arbace_a2g_reach_scan_node_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__A_new, Get: A_arbace_a2g_reach_scan_node_BANG__A_get}

var A_arbace_a2g_reach_scan_node_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "scan_node_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__A]()) }

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_new, Get: A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_get}

var A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_$fn__214000211", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_scan_node_BANG__A_class, Simple: "fn__214000211", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A]()) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_new, Get: A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_get}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_$pat__214000224", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_scan_node_BANG__A_class, Simple: "pat__214000224", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A]()) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_new, Get: A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_get}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_$pat__214000242", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_scan_node_BANG__A_class, Simple: "pat__214000242", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A]()) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_new, Get: A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_get}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_$pat__214000248", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_scan_node_BANG__A_class, Simple: "pat__214000248", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A]()) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_new, Get: A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_get}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_$pat__214000254", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_scan_node_BANG__A_class, Simple: "pat__214000254", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A]()) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_New()}; return nil }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_fn_class)}; return nil }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_invoke, New: A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_new, Get: A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_get}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$scan_node_BANG_$pat__214000260", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_scan_node_BANG__A_class, Simple: "pat__214000260", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_InstanceOf; i.Init = A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_Init; i.Table = A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_class, reflect.TypeFor[A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A]()) }

func A_arbace_a2g_reach_supertypes_of_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_supertypes_of_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_supertypes_of_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_supertypes_of_A_New()}; return nil }

func A_arbace_a2g_reach_supertypes_of_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_supertypes_of_A_fn_class)}; return nil }

var A_arbace_a2g_reach_supertypes_of_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_supertypes_of_A_invoke, New: A_arbace_a2g_reach_supertypes_of_A_new, Get: A_arbace_a2g_reach_supertypes_of_A_get}

var A_arbace_a2g_reach_supertypes_of_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$supertypes_of", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "supertypes_of", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_supertypes_of_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_supertypes_of_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_supertypes_of_A_InstanceOf; i.Init = A_arbace_a2g_reach_supertypes_of_A_Init; i.Table = A_arbace_a2g_reach_supertypes_of_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_supertypes_of_A_class, reflect.TypeFor[A_arbace_a2g_reach_supertypes_of_A]()) }

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_supertypes_of_fn__214000130_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_supertypes_of_fn__214000130_A_New()}; return nil }

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_supertypes_of_fn__214000130_A_fn_class)}; return nil }

var A_arbace_a2g_reach_supertypes_of_fn__214000130_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_supertypes_of_fn__214000130_A_invoke, New: A_arbace_a2g_reach_supertypes_of_fn__214000130_A_new, Get: A_arbace_a2g_reach_supertypes_of_fn__214000130_A_get}

var A_arbace_a2g_reach_supertypes_of_fn__214000130_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$supertypes_of$fn__214000130", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_supertypes_of_A_class, Simple: "fn__214000130", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_supertypes_of_fn__214000130_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_supertypes_of_fn__214000130_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_supertypes_of_fn__214000130_A_InstanceOf; i.Init = A_arbace_a2g_reach_supertypes_of_fn__214000130_A_Init; i.Table = A_arbace_a2g_reach_supertypes_of_fn__214000130_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_supertypes_of_fn__214000130_A_class, reflect.TypeFor[A_arbace_a2g_reach_supertypes_of_fn__214000130_A]()) }

func A_arbace_a2g_reach_use_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_use_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_use_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__A_invoke, New: A_arbace_a2g_reach_use_BANG__A_new, Get: A_arbace_a2g_reach_use_BANG__A_get}

var A_arbace_a2g_reach_use_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "use_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__A_Init; i.Table = A_arbace_a2g_reach_use_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__A]()) }

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__fn__214000080_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__fn__214000080_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__fn__214000080_A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__fn__214000080_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__fn__214000080_A_invoke, New: A_arbace_a2g_reach_use_BANG__fn__214000080_A_new, Get: A_arbace_a2g_reach_use_BANG__fn__214000080_A_get}

var A_arbace_a2g_reach_use_BANG__fn__214000080_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_$fn__214000080", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_use_BANG__A_class, Simple: "fn__214000080", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__fn__214000080_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__fn__214000080_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__fn__214000080_A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__fn__214000080_A_Init; i.Table = A_arbace_a2g_reach_use_BANG__fn__214000080_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__fn__214000080_A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__fn__214000080_A]()) }

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__fn__214000086_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__fn__214000086_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__fn__214000086_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__fn__214000086_A_invoke, New: A_arbace_a2g_reach_use_BANG__fn__214000086_A_new, Get: A_arbace_a2g_reach_use_BANG__fn__214000086_A_get}

var A_arbace_a2g_reach_use_BANG__fn__214000086_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_$fn__214000086", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_use_BANG__A_class, Simple: "fn__214000086", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__fn__214000086_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__fn__214000086_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__fn__214000086_A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__fn__214000086_A_Init; i.Table = A_arbace_a2g_reach_use_BANG__fn__214000086_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__fn__214000086_A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__fn__214000086_A]()) }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__fn__214000088_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__fn__214000088_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__fn__214000088_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__fn__214000088_A_invoke, New: A_arbace_a2g_reach_use_BANG__fn__214000088_A_new, Get: A_arbace_a2g_reach_use_BANG__fn__214000088_A_get}

var A_arbace_a2g_reach_use_BANG__fn__214000088_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_$fn__214000088", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_use_BANG__A_class, Simple: "fn__214000088", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__fn__214000088_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__fn__214000088_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__fn__214000088_A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__fn__214000088_A_Init; i.Table = A_arbace_a2g_reach_use_BANG__fn__214000088_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__fn__214000088_A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__fn__214000088_A]()) }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__fn__214000090_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__fn__214000090_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__fn__214000090_A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__fn__214000090_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__fn__214000090_A_invoke, New: A_arbace_a2g_reach_use_BANG__fn__214000090_A_new, Get: A_arbace_a2g_reach_use_BANG__fn__214000090_A_get}

var A_arbace_a2g_reach_use_BANG__fn__214000090_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_$fn__214000090", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_use_BANG__A_class, Simple: "fn__214000090", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__fn__214000090_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__fn__214000090_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__fn__214000090_A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__fn__214000090_A_Init; i.Table = A_arbace_a2g_reach_use_BANG__fn__214000090_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__fn__214000090_A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__fn__214000090_A]()) }

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__fn__214000096_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__fn__214000096_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__fn__214000096_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__fn__214000096_A_invoke, New: A_arbace_a2g_reach_use_BANG__fn__214000096_A_new, Get: A_arbace_a2g_reach_use_BANG__fn__214000096_A_get}

var A_arbace_a2g_reach_use_BANG__fn__214000096_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_$fn__214000096", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_use_BANG__A_class, Simple: "fn__214000096", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__fn__214000096_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__fn__214000096_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__fn__214000096_A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__fn__214000096_A_Init; i.Table = A_arbace_a2g_reach_use_BANG__fn__214000096_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__fn__214000096_A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__fn__214000096_A]()) }

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_BANG__fn__214000098_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_BANG__fn__214000098_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_BANG__fn__214000098_A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_BANG__fn__214000098_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_BANG__fn__214000098_A_invoke, New: A_arbace_a2g_reach_use_BANG__fn__214000098_A_new, Get: A_arbace_a2g_reach_use_BANG__fn__214000098_A_get}

var A_arbace_a2g_reach_use_BANG__fn__214000098_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_BANG_$fn__214000098", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_use_BANG__A_class, Simple: "fn__214000098", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_BANG__fn__214000098_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_BANG__fn__214000098_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_BANG__fn__214000098_A_InstanceOf; i.Init = A_arbace_a2g_reach_use_BANG__fn__214000098_A_Init; i.Table = A_arbace_a2g_reach_use_BANG__fn__214000098_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_BANG__fn__214000098_A_class, reflect.TypeFor[A_arbace_a2g_reach_use_BANG__fn__214000098_A]()) }

func A_arbace_a2g_reach_use_desc_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_use_desc_BANG__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_use_desc_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_use_desc_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_use_desc_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_use_desc_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_use_desc_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_use_desc_BANG__A_invoke, New: A_arbace_a2g_reach_use_desc_BANG__A_new, Get: A_arbace_a2g_reach_use_desc_BANG__A_get}

var A_arbace_a2g_reach_use_desc_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$use_desc_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "use_desc_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_use_desc_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_use_desc_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_use_desc_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_use_desc_BANG__A_Init; i.Table = A_arbace_a2g_reach_use_desc_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_use_desc_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_use_desc_BANG__A]()) }

func A_arbace_a2g_reach_vcall_BANG__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcall_BANG__A).Invoke_O_O_O_O__O(args[0], args[1], args[2], args[3])}; return nil }

func A_arbace_a2g_reach_vcall_BANG__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcall_BANG__A_New()}; return nil }

func A_arbace_a2g_reach_vcall_BANG__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcall_BANG__A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcall_BANG__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcall_BANG__A_invoke, New: A_arbace_a2g_reach_vcall_BANG__A_new, Get: A_arbace_a2g_reach_vcall_BANG__A_get}

var A_arbace_a2g_reach_vcall_BANG__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcall_BANG_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF3_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "vcall_BANG_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcall_BANG__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcall_BANG__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcall_BANG__A_InstanceOf; i.Init = A_arbace_a2g_reach_vcall_BANG__A_Init; i.Table = A_arbace_a2g_reach_vcall_BANG__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcall_BANG__A_class, reflect.TypeFor[A_arbace_a2g_reach_vcall_BANG__A]()) }

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcall_BANG__fn__214000168_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_invoke, New: A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_new, Get: A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_get}

var A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcall_BANG_$fn__214000168", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_vcall_BANG__A_class, Simple: "fn__214000168", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcall_BANG__fn__214000168_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_Init; i.Table = A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcall_BANG__fn__214000168_A]()) }

func A_arbace_a2g_reach_vcalls_on_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcalls_on_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vcalls_on_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcalls_on_A_New()}; return nil }

func A_arbace_a2g_reach_vcalls_on_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcalls_on_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcalls_on_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcalls_on_A_invoke, New: A_arbace_a2g_reach_vcalls_on_A_new, Get: A_arbace_a2g_reach_vcalls_on_A_get}

var A_arbace_a2g_reach_vcalls_on_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcalls_on", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "vcalls_on", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcalls_on_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcalls_on_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcalls_on_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcalls_on_A_Init; i.Table = A_arbace_a2g_reach_vcalls_on_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcalls_on_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcalls_on_A]()) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_New_O(args[0])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_invoke, New: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_new, Get: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_get}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcalls_on$iter__214000133__214000139", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_vcalls_on_A_class, Simple: "iter__214000133__214000139", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_Init; i.Table = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A]()) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_New_O_O_O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_invoke, New: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_new, Get: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_get}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_class, Simple: "fn__214000140", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_Init; i.Table = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A]()) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_New()}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_invoke, New: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_new, Get: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_get}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_class, Simple: "iter__214000135__214000141", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_Init; i.Table = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A]()) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_invoke, New: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_new, Get: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_get}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141$fn__214000142", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_class, Simple: "fn__214000142", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_Init; i.Table = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A]()) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_New_O_I_O(args[0], args[1].(int32), args[2])}; return nil }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_fn_class)}; return nil }

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;ILjava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_invoke, New: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_new, Get: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_get}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vcalls_on$iter__214000133__214000139$fn__214000140$iter__214000135__214000141$fn__214000142$fn__214000143", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_class, Simple: "fn__214000143", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_InstanceOf; i.Init = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_Init; i.Table = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_class, reflect.TypeFor[A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A]()) }

func A_arbace_a2g_reach_vh_call_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vh_call_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vh_call_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vh_call_QMARK__A_New()}; return nil }

func A_arbace_a2g_reach_vh_call_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vh_call_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_reach_vh_call_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vh_call_QMARK__A_invoke, New: A_arbace_a2g_reach_vh_call_QMARK__A_new, Get: A_arbace_a2g_reach_vh_call_QMARK__A_get}

var A_arbace_a2g_reach_vh_call_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vh_call_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "vh_call_QMARK_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vh_call_QMARK__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vh_call_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vh_call_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_reach_vh_call_QMARK__A_Init; i.Table = A_arbace_a2g_reach_vh_call_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vh_call_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_reach_vh_call_QMARK__A]()) }

func A_arbace_a2g_reach_vh_const_QMARK__A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_vh_const_QMARK__A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_vh_const_QMARK__A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_vh_const_QMARK__A_New()}; return nil }

func A_arbace_a2g_reach_vh_const_QMARK__A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_vh_const_QMARK__A_fn_class)}; return nil }

var A_arbace_a2g_reach_vh_const_QMARK__A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_vh_const_QMARK__A_invoke, New: A_arbace_a2g_reach_vh_const_QMARK__A_new, Get: A_arbace_a2g_reach_vh_const_QMARK__A_get}

var A_arbace_a2g_reach_vh_const_QMARK__A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$vh_const_QMARK_", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "vh_const_QMARK_", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_vh_const_QMARK__A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_vh_const_QMARK__A_class.Info(); i.IsInstance = A_arbace_a2g_reach_vh_const_QMARK__A_InstanceOf; i.Init = A_arbace_a2g_reach_vh_const_QMARK__A_Init; i.Table = A_arbace_a2g_reach_vh_const_QMARK__A_members; jrt.RegisterGoType(A_arbace_a2g_reach_vh_const_QMARK__A_class, reflect.TypeFor[A_arbace_a2g_reach_vh_const_QMARK__A]()) }

func A_arbace_a2g_reach_walk_nodes_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_walk_nodes_A).Invoke_O_O_O__O(args[0], args[1], args[2])}; return nil }

func A_arbace_a2g_reach_walk_nodes_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_walk_nodes_A_New()}; return nil }

func A_arbace_a2g_reach_walk_nodes_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_walk_nodes_A_fn_class)}; return nil }

var A_arbace_a2g_reach_walk_nodes_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_walk_nodes_A_invoke, New: A_arbace_a2g_reach_walk_nodes_A_new, Get: A_arbace_a2g_reach_walk_nodes_A_get}

var A_arbace_a2g_reach_walk_nodes_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$walk_nodes", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF2_class}, Declaring: A_arbace_a2g_reach_A_class, Simple: "walk_nodes", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_walk_nodes_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_walk_nodes_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_walk_nodes_A_InstanceOf; i.Init = A_arbace_a2g_reach_walk_nodes_A_Init; i.Table = A_arbace_a2g_reach_walk_nodes_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_walk_nodes_A_class, reflect.TypeFor[A_arbace_a2g_reach_walk_nodes_A]()) }

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_walk_nodes_walk__214000013_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_walk_nodes_walk__214000013_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class)}; return nil }

var A_arbace_a2g_reach_walk_nodes_walk__214000013_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_walk_nodes_walk__214000013_A_invoke, New: A_arbace_a2g_reach_walk_nodes_walk__214000013_A_new, Get: A_arbace_a2g_reach_walk_nodes_walk__214000013_A_get}

var A_arbace_a2g_reach_walk_nodes_walk__214000013_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$walk_nodes$walk__214000013", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_walk_nodes_A_class, Simple: "walk__214000013", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_walk_nodes_walk__214000013_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_walk_nodes_walk__214000013_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_InstanceOf; i.Init = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_Init; i.Table = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_walk_nodes_walk__214000013_A_class, reflect.TypeFor[A_arbace_a2g_reach_walk_nodes_walk__214000013_A]()) }

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class)}; return nil }

var A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_invoke, New: A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_new, Get: A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_get}

var A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$walk_nodes$walk_plain__214000031", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_walk_nodes_A_class, Simple: "walk_plain__214000031", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_InstanceOf; i.Init = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_Init; i.Table = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_class, reflect.TypeFor[A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A]()) }

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_New_O_O(args[0], args[1])}; return nil }

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class)}; return nil }

var A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 (Ljava.lang.Object;Ljava.lang.Object;)V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_invoke, New: A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_new, Get: A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_get}

var A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach$walk_nodes$walk_val__214000025", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_a2g_reach_walk_nodes_A_class, Simple: "walk_val__214000025", Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_class.Info(); i.IsInstance = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_InstanceOf; i.Init = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_Init; i.Table = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_members; jrt.RegisterGoType(A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_class, reflect.TypeFor[A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A]()) }

func A_arbace_a2g_reach__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_a2g_reach__init_A_Load__O(); case 1: return A_arbace_a2g_reach__init_A_Unit0__O(); case 2: return A_arbace_a2g_reach__init_A_Unit1__O(); case 3: return A_arbace_a2g_reach__init_A_Unit10__O(); case 4: return A_arbace_a2g_reach__init_A_Unit11__O(); case 5: return A_arbace_a2g_reach__init_A_Unit12__O(); case 6: return A_arbace_a2g_reach__init_A_Unit13__O(); case 7: return A_arbace_a2g_reach__init_A_Unit14__O(); case 8: return A_arbace_a2g_reach__init_A_Unit15__O(); case 9: return A_arbace_a2g_reach__init_A_Unit16__O(); case 10: return A_arbace_a2g_reach__init_A_Unit17__O(); case 11: return A_arbace_a2g_reach__init_A_Unit18__O(); case 12: return A_arbace_a2g_reach__init_A_Unit19__O(); case 13: return A_arbace_a2g_reach__init_A_Unit2__O(); case 14: return A_arbace_a2g_reach__init_A_Unit20__O(); case 15: return A_arbace_a2g_reach__init_A_Unit21__O(); case 16: return A_arbace_a2g_reach__init_A_Unit22__O(); case 17: return A_arbace_a2g_reach__init_A_Unit23__O(); case 18: return A_arbace_a2g_reach__init_A_Unit24__O(); case 19: return A_arbace_a2g_reach__init_A_Unit25__O(); case 20: return A_arbace_a2g_reach__init_A_Unit26__O(); case 21: return A_arbace_a2g_reach__init_A_Unit27__O(); case 22: return A_arbace_a2g_reach__init_A_Unit28__O(); case 23: return A_arbace_a2g_reach__init_A_Unit29__O(); case 24: return A_arbace_a2g_reach__init_A_Unit3__O(); case 25: return A_arbace_a2g_reach__init_A_Unit30__O(); case 26: return A_arbace_a2g_reach__init_A_Unit31__O(); case 27: return A_arbace_a2g_reach__init_A_Unit32__O(); case 28: return A_arbace_a2g_reach__init_A_Unit33__O(); case 29: return A_arbace_a2g_reach__init_A_Unit34__O(); case 30: return A_arbace_a2g_reach__init_A_Unit35__O(); case 31: return A_arbace_a2g_reach__init_A_Unit36__O(); case 32: return A_arbace_a2g_reach__init_A_Unit4__O(); case 33: return A_arbace_a2g_reach__init_A_Unit5__O(); case 34: return A_arbace_a2g_reach__init_A_Unit6__O(); case 35: return A_arbace_a2g_reach__init_A_Unit7__O(); case 36: return A_arbace_a2g_reach__init_A_Unit8__O(); case 37: return A_arbace_a2g_reach__init_A_Unit9__O()}; return nil }

func A_arbace_a2g_reach__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_a2g_reach__init_A_New()}; return nil }

var A_arbace_a2g_reach__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit10 ()Ljava.lang.Object;\nM9 unit11 ()Ljava.lang.Object;\nM9 unit12 ()Ljava.lang.Object;\nM9 unit13 ()Ljava.lang.Object;\nM9 unit14 ()Ljava.lang.Object;\nM9 unit15 ()Ljava.lang.Object;\nM9 unit16 ()Ljava.lang.Object;\nM9 unit17 ()Ljava.lang.Object;\nM9 unit18 ()Ljava.lang.Object;\nM9 unit19 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit20 ()Ljava.lang.Object;\nM9 unit21 ()Ljava.lang.Object;\nM9 unit22 ()Ljava.lang.Object;\nM9 unit23 ()Ljava.lang.Object;\nM9 unit24 ()Ljava.lang.Object;\nM9 unit25 ()Ljava.lang.Object;\nM9 unit26 ()Ljava.lang.Object;\nM9 unit27 ()Ljava.lang.Object;\nM9 unit28 ()Ljava.lang.Object;\nM9 unit29 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit30 ()Ljava.lang.Object;\nM9 unit31 ()Ljava.lang.Object;\nM9 unit32 ()Ljava.lang.Object;\nM9 unit33 ()Ljava.lang.Object;\nM9 unit34 ()Ljava.lang.Object;\nM9 unit35 ()Ljava.lang.Object;\nM9 unit36 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nM9 unit8 ()Ljava.lang.Object;\nM9 unit9 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_a2g_reach__init_A_invoke, New: A_arbace_a2g_reach__init_A_new}

var A_arbace_a2g_reach__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.a2g.reach__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_a2g_reach.A_arbace_a2g_reach__init_A", Source: "reach.ae"})

func init() { i := A_arbace_a2g_reach__init_A_class.Info(); i.IsInstance = A_arbace_a2g_reach__init_A_InstanceOf; i.Init = A_arbace_a2g_reach__init_A_Init; i.Table = A_arbace_a2g_reach__init_A_members; jrt.RegisterGoType(A_arbace_a2g_reach__init_A_class, reflect.TypeFor[A_arbace_a2g_reach__init_A]()) }
