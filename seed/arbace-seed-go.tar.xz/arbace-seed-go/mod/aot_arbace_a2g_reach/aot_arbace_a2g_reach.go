//line aot_arbace_a2g_reach.ae:1
package aot_arbace_a2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_New() *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A { A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_Init(); t := &A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp26 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_1; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_2; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_0; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_3; var tmp10 any = tmp9; var tmp11 any; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_4; var tmp12 any = tmp11; var tmp13 any; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_5; var tmp14 any = tmp13; var tmp15 any; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_6; var tmp16 any = tmp15; var tmp17 any; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_7; var tmp18 any = tmp17; var tmp19 any; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_8; var tmp20 any = tmp19; var tmp21 any; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_9; var tmp22 any = tmp21; var tmp23 any; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_10; var tmp24 any = tmp23; var tmp25 any; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_11; tmp3 = tmp8.Invoke_O_O_O_O_O_O_O_O_O__O(tmp10, tmp12, tmp14, tmp16, tmp18, tmp20, tmp22, tmp24, tmp25) }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp26 != nil { panic(tmp26) }; return tmp3 }
//line :1:1
func A_arbace_a2g_reach_eval214000008_fn__214000009_A_New() *A_arbace_a2g_reach_eval214000008_fn__214000009_A { A_arbace_a2g_reach_eval214000008_fn__214000009_A_Init(); t := &A_arbace_a2g_reach_eval214000008_fn__214000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_12; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_16; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_14; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_15; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }



















func A_arbace_a2g_reach_node_QMARK__A_New() *A_arbace_a2g_reach_node_QMARK__A { A_arbace_a2g_reach_node_QMARK__A_Init(); t := &A_arbace_a2g_reach_node_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_a2g_reach_node_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_a2g_reach_node_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_17; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_18; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_19; return tmp3.Invoke_O_O__O(x__0, tmp4.Ref()) } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_reach_walk_nodes_A_New() *A_arbace_a2g_reach_walk_nodes_A { A_arbace_a2g_reach_walk_nodes_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_a2g_reach_walk_nodes_A) Ctor() {}
//line :23:1
func (t *A_arbace_a2g_reach_walk_nodes_A) Invoke_O_O_O__O(self, f__0, node__1 any) any { var body_walk__3 *A_arbace_a2g_reach_walk_nodes_walk__214000013_A = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_New_O_O(f__0, nil); var body_walk_val__4 *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_New_O_O(nil, nil); var body_walk_plain__5 *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_New_O_O(nil, nil); var walk__3 any; var tmp1 *jrt.Class; A_arbace_a2g_reach_walk_nodes_walk__214000013_A_Init(); tmp1 = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_walk__3.Ref(), tmp1, nil); var walk_val__4 any; var tmp2 *jrt.Class; A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_Init(); tmp2 = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class; walk_val__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_walk_val__4.Ref(), tmp2, nil); var walk_plain__5 any; var tmp3 *jrt.Class; A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_Init(); tmp3 = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class; walk_plain__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_walk_plain__5.Ref(), tmp3, nil); body_walk__3.F_walk_val = walk_val__4; body_walk_val__4.F_walk = walk__3; body_walk_val__4.F_walk_plain = walk_plain__5; body_walk_plain__5.F_walk = walk__3; body_walk_plain__5.F_walk_val = walk_val__4; var tmp4 /*line :44:1*/*lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(node__1)) { return lang.IFn_Cast(walk__3).Invoke_O__O(node__1) } else { return nil } }
//line :27:1
func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_walk_nodes_walk__214000013_A { A_arbace_a2g_reach_walk_nodes_walk__214000013_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_walk__214000013_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Ctor_O_O(c__f, c__walk_val any) { t.F_f = c__f; t.F_walk_val = c__walk_val }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Invoke_O_O__O(self, n__1 any) any {
	lang.IFn_Cast(t.F_f).Invoke_O__O(n__1)
//line :27:1
	{ var seq_214000014__2 any; var tmp1 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; seq_214000014__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__1)
//line :27:1
		var chunk_214000015__3 any; var count_214000016__4 int64 = 0; var i_214000017__5 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z(i_214000017__5, count_214000016__4) { var vec__214000018__6 any = lang.Indexed_Cast(chunk_214000015__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000017__5)); var k__7 any = lang.RT_Nth_O_I_O__O(vec__214000018__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__214000018__6, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_21; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_25; if jrt.A2g_Truth(tmp3.Invoke_O__O(lang.IFn_Cast(tmp4).Invoke_O__O(k__7))) {

				lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__8)
//line :29:1
				seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = seq_214000014__2, chunk_214000015__3, count_214000016__4, lang.Numbers_Unchecked_inc_J__J(i_214000017__5); continue L1 } else { seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = seq_214000014__2, chunk_214000015__3, count_214000016__4, lang.Numbers_Unchecked_inc_J__J(i_214000017__5); continue L1 } } else { var temp__1927000414__auto____6 any; var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq_214000014__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000014__7 any = temp__1927000414__auto____6; var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_214000014__7)) { var c__1927000678__auto____8 any; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_214000014__7); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_26; seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_214000014__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__214000021__8 any; var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_24; vec__214000021__8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_214000014__7); var k__9 any = lang.RT_Nth_O_I_O__O(vec__214000021__8, lang.RT_IntCast_J__I(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__214000021__8, lang.RT_IntCast_J__I(1), nil); var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_21; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_27; if jrt.A2g_Truth(tmp11.Invoke_O__O(lang.IFn_Cast(tmp12).Invoke_O__O(k__9))) {

					lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__10)
//line :29:1
					var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_28; seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_214000014__7), nil, 0, 0; continue L1 } else { var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_28; seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_214000014__7), nil, 0, 0; continue L1 } } } else { return nil } } } }
//line :27:1
	panic("a2g: unreachable") }
//line :27:1
func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A { A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Ctor_O_O(c__walk, c__walk_val any) { t.F_walk = c__walk; t.F_walk_val = c__walk_val }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Invoke_O_O__O(self, mp__1 any) any { { var seq_214000032__2 any; var tmp1 *lang.Var












	A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; seq_214000032__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(mp__1)
//line :27:1
	var chunk_214000033__3 any; var count_214000034__4 int64 = 0; var i_214000035__5 int64 = 0; L1: for {












		if lang.Numbers_Lt_J_J__Z(i_214000035__5, count_214000034__4) { var vec__214000036__6 any = lang.Indexed_Cast(chunk_214000033__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000035__5)); var k__7 any = lang.RT_Nth_O_I_O__O(vec__214000036__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__214000036__6, lang.RT_IntCast_J__I(1), nil); var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_21; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_32; if jrt.A2g_Truth(tmp3.Invoke_O__O(lang.IFn_Cast(tmp4).Invoke_O__O(k__7))) {
			var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(v__8)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(v__8) } else { var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(v__8)) {
				lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__8) } else {
//line :41:1
					var tmp7 any; var and__1927000168__auto____9 any; var tmp8 *lang.Var

					A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_17; and__1927000168__auto____9 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(v__8); if jrt.A2g_Truth(and__1927000168__auto____9) { var tmp9 any; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_33; tmp7 = lang.IFn_Cast(tmp9).Invoke_O__O(k__7) } else { tmp7 = and__1927000168__auto____9 }
//line :41:1
					if jrt.A2g_Truth(tmp7) {

						lang.IFn_Cast(self).Invoke_O__O(v__8) } } }
//line :40:1
			seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = seq_214000032__2, chunk_214000033__3, count_214000034__4, lang.Numbers_Unchecked_inc_J__J(i_214000035__5); continue L1 } else { seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = seq_214000032__2, chunk_214000033__3, count_214000034__4, lang.Numbers_Unchecked_inc_J__J(i_214000035__5); continue L1 } } else { var temp__1927000414__auto____6 any; var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_214000032__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000032__7 any = temp__1927000414__auto____6; var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_214000032__7)) { var c__1927000678__auto____8 any; var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_214000032__7); var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_26; seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(seq_214000032__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__214000039__8 any; var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_24; vec__214000039__8 = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(seq_214000032__7); var k__9 any = lang.RT_Nth_O_I_O__O(vec__214000039__8, lang.RT_IntCast_J__I(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__214000039__8, lang.RT_IntCast_J__I(1), nil); var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_21; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 any; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_34; if jrt.A2g_Truth(tmp16.Invoke_O__O(lang.IFn_Cast(tmp17).Invoke_O__O(k__9))) {
				var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(v__10)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(v__10) } else { var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(v__10)) {
					lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__10) } else {
//line :41:1
						var tmp20 any; var and__1927000168__auto____11 any; var tmp21 *lang.Var

						A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_17; and__1927000168__auto____11 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(v__10); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp22 any; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_35; tmp20 = lang.IFn_Cast(tmp22).Invoke_O__O(k__9) } else { tmp20 = and__1927000168__auto____11 }
//line :41:1
						if jrt.A2g_Truth(tmp20) {

							lang.IFn_Cast(self).Invoke_O__O(v__10) } } }
//line :40:1
				var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_28; seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000032__7), nil, 0, 0; continue L1 } else { var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_28; seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000032__7), nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :27:1*/panic("a2g: unreachable") }
//line :27:1
func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A { A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Ctor_O_O(c__walk, c__walk_plain any) { t.F_walk = c__walk; t.F_walk_plain = c__walk_plain }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Invoke_O_O__O(self, v__1 any) any {





	{ var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(v__1)) { return lang.IFn_Cast(t.F_walk).Invoke_O__O(v__1) } else { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(v__1)) { var seq_214000026__2 any; var tmp3 *lang.Var
		A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_20; seq_214000026__2 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(v__1)
//line :33:1
		var chunk_214000027__3 any; var count_214000028__4 int64 = 0; var i_214000029__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_214000029__5, count_214000028__4) { var x__6 any = lang.Indexed_Cast(chunk_214000027__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000029__5)); var tmp4 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(x__6)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(x__6) } else { var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(x__6)) {
					lang.IFn_Cast(t.F_walk_plain).Invoke_O__O(x__6) } else {
//line :35:1
						var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(x__6)) {

							lang.IFn_Cast(self).Invoke_O__O(x__6) } } }
//line :34:1
				seq_214000026__2, chunk_214000027__3, count_214000028__4, i_214000029__5 = seq_214000026__2, chunk_214000027__3, count_214000028__4, lang.Numbers_Unchecked_inc_J__J(i_214000029__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_214000026__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000026__7 any = temp__1927000414__auto____6; var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_214000026__7)) { var c__1927000678__auto____8 any; var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_214000026__7); var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_26; seq_214000026__2, chunk_214000027__3, count_214000028__4, i_214000029__5 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_214000026__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var x__8 any; var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_24; x__8 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_214000026__7)
					var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_29; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(x__8)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(x__8) } else { var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_17; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(x__8)) {
						lang.IFn_Cast(t.F_walk_plain).Invoke_O__O(x__8) } else {
//line :35:1
							var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_30; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O__O(x__8)) {

								lang.IFn_Cast(self).Invoke_O__O(x__8) } } }
//line :34:1
					var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_28; seq_214000026__2, chunk_214000027__3, count_214000028__4, i_214000029__5 = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(seq_214000026__7), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :33:1
						var tmp16 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_31; if tmp16 != nil { return nil } else { return nil } } } }
//line :27:1
	panic("a2g: unreachable")
}




















func A_arbace_a2g_reach_java_impl_of_A_New() *A_arbace_a2g_reach_java_impl_of_A { A_arbace_a2g_reach_java_impl_of_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_A{}; t.Ctor(); return t }
//line :49:1
func (t *A_arbace_a2g_reach_java_impl_of_A) Ctor() {}
//line :49:1
func (t *A_arbace_a2g_reach_java_impl_of_A) Invoke_O_O_O__O(self, n__0, p__214000048__1 any) any { var vec__214000049__3 any = p__214000048__1; var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000049__3, lang.RT_IntCast_J__I(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000049__3, lang.RT_IntCast_J__I(1), nil); var or__1927000174__auto____6 any; var tmp1 *lang.Var;



	A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_reach_java_impl_of_fn__214000052_A_New_O_O_O(name__4, desc__5, n__0); var tmp4 *jrt.Class; A_arbace_a2g_reach_java_impl_of_fn__214000052_A_Init(); tmp4 = A_arbace_a2g_reach_java_impl_of_fn__214000052_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_53; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_54; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_55; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 any = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_New(); var tmp13 *jrt.Class; A_arbace_a2g_reach_java_impl_of_fn__214000056_A_Init(); tmp13 = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class; or__1927000174__auto____6 = tmp2.Invoke_O_O__O(tmp5, tmp7.Invoke_O_O__O(tmp9, tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), n__0))); if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var cands__7 any; var iter__1927001039__auto____7 any; var tmp14 any = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_New_O_O_O(name__4, desc__5, n__0); var tmp15 *jrt.Class




		A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_Init(); tmp15 = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_fn_class; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var tmp16 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____7); var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_57; cands__7 = tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(n__0))
//line :53:1
		var cands__8 any; var tmp18 *lang.Var









		A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_52; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 any = A_arbace_a2g_reach_java_impl_of_fn__214000072_A_New_O(cands__7); var tmp21 *jrt.Class; A_arbace_a2g_reach_java_impl_of_fn__214000072_A_Init(); tmp21 = A_arbace_a2g_reach_java_impl_of_fn__214000072_A_fn_class; cands__8 = tmp19.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp20, tmp21, nil), cands__7)
//line :53:1
		var temp__1927000414__auto____9 any; var tmp22 *lang.Var










		A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_24; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(cands__8); if jrt.A2g_Truth(temp__1927000414__auto____9) { var c__10 any = temp__1927000414__auto____9; return lang.Tuple_Create_O_O_O__IPersistentVector(c__10, name__4, desc__5) } else { return nil } } }
//line :53:1
func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_java_impl_of_fn__214000052_A { A_arbace_a2g_reach_java_impl_of_fn__214000052_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000052_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :53:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :53:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any; var tmp1 *lang.Var;
												A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_New_O_O(t.F_name, t.F_desc); var tmp4 *jrt.Class; A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_Init(); tmp4 = A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_fn_class; var tmp5 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_42; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_43; temp__1927000414__auto____2 = tmp2.Invoke_O_O__O(tmp5, jrt.NN(tmp7).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(c__1))); if jrt.A2g_Truth(temp__1927000414__auto____2) { var mm__3 any = temp__1927000414__auto____2; var tmp9 any; var and__1927000168__auto____4 any; var tmp10 *lang.Var
													A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_21; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_45; and__1927000168__auto____4 = tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_21; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_44; and__1927000168__auto____5 = tmp14.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any; var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_21; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_46; or__1927000174__auto____6 = tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp9 = or__1927000174__auto____6 } else { tmp9 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(c__1, t.F_n)).Ref() } } else { tmp9 = and__1927000168__auto____5 } } else { tmp9 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp9) { return lang.Tuple_Create_O_O_O__IPersistentVector(c__1, t.F_name, t.F_desc) } else { return nil } } else {
//line :54:1
			return nil } }
//line :54:1
func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A { A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A{}; t.Ctor_O_O(p0, p1); return t }
//line :54:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :54:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) Invoke_O_O__O(self, p1__214000044_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 any = t.F_name; var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_40; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__214000044_SHARP___1)); if and__1927000168__auto____2 { var tmp4 any = t.F_desc; var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_41; tmp1 = lang.Util_Equiv_O_O__Z(tmp4, jrt.NN(tmp5).Invoke_O__O(p1__214000044_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__214000044_SHARP___1 } else { return nil } }


func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_New() *A_arbace_a2g_reach_java_impl_of_fn__214000056_A { A_arbace_a2g_reach_java_impl_of_fn__214000056_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000056_A{}; t.Ctor(); return t }
//line :57:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Ctor() {}
//line :57:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Invoke_O_O__O(self, p1__214000045_SHARP___1 any) any { var tmp1 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_56; var tmp2 *lang.Keyword = tmp1; var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_43; return jrt.NN(tmp2).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(p1__214000045_SHARP___1)) }
func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :58:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :58:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) Invoke_O_O__O(self, s__214000059__1 any) any { var tmp1 any = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_New_O_O_O_O_O(self, s__214000059__1, t.F_name, t.F_desc, t.F_n); var tmp2 *jrt.Class; A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_Init(); tmp2 = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :58:1
func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :58:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) Ctor_O_O_O_O_O(c__iter__214000058, c__s__214000059, c__name, c__desc, c__n any) { t.F_iter__214000058 = c__iter__214000058; t.F_s__214000059 = c__s__214000059; t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :58:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) Invoke_O__O(self any) any { { var s__214000059__1 any; var t_ any = t.F_s__214000059; t.F_s__214000059 = nil; s__214000059__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__214000059__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000059__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__214000059__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__214000059__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000061__6 any; var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_37; b__214000061__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_New_O_O_O_O_I_O(t.F_name, b__214000061__6, t.F_desc, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_Init(); tmp6 = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_48; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_50; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__214000061__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__214000058); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_26; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__214000059__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_48; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_50; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__214000061__6), nil) } } else { var c__4 any; var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_24; c__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__214000059__3); var tmp17 any; var and__1927000168__auto____5 any; var tmp18 *lang.Var
														A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_38; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(c__4, t.F_n); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_39; tmp17 = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(c__4) } else { tmp17 = and__1927000168__auto____5 }
//line :58:1
	if jrt.A2g_Truth(tmp17) { var mm__5 any; var tmp20 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_36; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 any = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_New_O_O(t.F_name, t.F_desc); var tmp23 *jrt.Class; A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_Init(); tmp23 = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_fn_class; var tmp24 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var tmp25 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_42; var tmp26 *lang.Keyword = tmp25; var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_43; mm__5 = tmp21.Invoke_O_O__O(tmp24, jrt.NN(tmp26).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(c__4)))
//line :58:1
		var tmp28 any
		var and__1927000168__auto____6 any = mm__5

		if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any; var tmp29 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_21; var tmp30 lang.IFn = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()); var tmp31 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_44; and__1927000168__auto____7 = tmp30.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(mm__5)); if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp32 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_21; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp34 = A_arbace_a2g_reach_A_const_45; and__1927000168__auto____8 = tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(mm__5)); if jrt.A2g_Truth(and__1927000168__auto____8) { var tmp35 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_21; var tmp36 lang.IFn = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()); var tmp37 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_46; tmp28 = tmp36.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(mm__5)) } else { tmp28 = and__1927000168__auto____8 } } else { tmp28 = and__1927000168__auto____7 } } else { tmp28 = and__1927000168__auto____6 }
//line :58:1
		if jrt.A2g_Truth(tmp28) { var tmp38 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_49; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 lang.IFn = lang.IFn_Cast(t.F_iter__214000058); var tmp41 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_51; return tmp39.Invoke_O_O__O(c__4, tmp40.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(s__214000059__3))) } else { var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_51; s__214000059__1 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(s__214000059__3); continue L1 } } else { var tmp43 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp43 = A_arbace_a2g_reach_A_const_51; s__214000059__1 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(s__214000059__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :58:1
func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :58:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) Ctor_O_O_O_O_I_O(c__name, c__b__214000061, c__desc, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__214000061 = c__b__214000061; t.F_desc = c__desc; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :58:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) Invoke_O__O(self any) any { { var i__214000060__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000060__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000060__1)); var tmp2 any; var and__1927000168__auto____3 any; var tmp3 *lang.Var
																A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_38; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(c__2, t.F_n); if jrt.A2g_Truth(and__1927000168__auto____3) { var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_39; tmp2 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(c__2) } else { tmp2 = and__1927000168__auto____3 }
//line :58:1
	if jrt.A2g_Truth(tmp2) { var mm__3 any; var tmp5 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_36; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 any = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_New_O_O(t.F_name, t.F_desc); var tmp8 *jrt.Class; A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_Init(); tmp8 = A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_fn_class; var tmp9 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_42; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_43; mm__3 = tmp6.Invoke_O_O__O(tmp9, jrt.NN(tmp11).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(c__2)))
//line :58:1
		var tmp13 any
		var and__1927000168__auto____4 any = mm__3

		if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any; var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_21; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_44; and__1927000168__auto____5 = tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_21; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_45; and__1927000168__auto____6 = tmp18.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_21; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_46; tmp13 = tmp21.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(mm__3)) } else { tmp13 = and__1927000168__auto____6 } } else { tmp13 = and__1927000168__auto____5 } } else { tmp13 = and__1927000168__auto____4 }
//line :58:1
		if jrt.A2g_Truth(tmp13) { var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_47; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O_O__O(t.F_b__214000061, c__2); i__214000060__1 = lang.Numbers_Unchecked_inc_J__J(i__214000060__1); continue L1 } else { i__214000060__1 = lang.Numbers_Unchecked_inc_J__J(i__214000060__1); continue L1 } } else { i__214000060__1 = lang.Numbers_Unchecked_inc_J__J(i__214000060__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A{}; t.Ctor_O_O(p0, p1); return t }
//line :60:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :60:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) Invoke_O_O__O(self, p1__214000046_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 any = t.F_name; var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_40; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__214000046_SHARP___1)); if and__1927000168__auto____2 { var tmp4 any = t.F_desc; var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_41; tmp1 = lang.Util_Equiv_O_O__Z(tmp4, jrt.NN(tmp5).Invoke_O__O(p1__214000046_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__214000046_SHARP___1 } else { return nil } }
//line :60:1
func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A{}; t.Ctor_O_O(p0, p1); return t }
//line :60:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :60:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) Invoke_O_O__O(self, p1__214000046_SHARP___1 any) any { var tmp1 bool; var and__1927000168__auto____2 bool; var tmp2 any = t.F_name; var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_40; and__1927000168__auto____2 = lang.Util_Equiv_O_O__Z(tmp2, jrt.NN(tmp3).Invoke_O__O(p1__214000046_SHARP___1)); if and__1927000168__auto____2 { var tmp4 any = t.F_desc; var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_41; tmp1 = lang.Util_Equiv_O_O__Z(tmp4, jrt.NN(tmp5).Invoke_O__O(p1__214000046_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__214000046_SHARP___1 } else { return nil } }


func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_New_O(p0 any) *A_arbace_a2g_reach_java_impl_of_fn__214000072_A { A_arbace_a2g_reach_java_impl_of_fn__214000072_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000072_A{}; t.Ctor_O(p0); return t }
//line :63:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :63:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_36; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any = A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_New_O(x__1); var tmp4 *jrt.Class; A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_Init(); tmp4 = A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_fn_class; return tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), t.F_cands) }
//line :63:1
func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_New_O(p0 any) *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A { A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A{}; t.Ctor_O(p0); return t }
//line :63:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :63:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) Invoke_O_O__O(self, p1__214000047_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_38; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__214000047_SHARP___1, t.F_x); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_58; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(p1__214000047_SHARP___1, t.F_x) } else { return and__1927000168__auto____2 } }












func A_arbace_a2g_reach_note_unavailable_BANG__A_New() *A_arbace_a2g_reach_note_unavailable_BANG__A { A_arbace_a2g_reach_note_unavailable_BANG__A_Init(); t := &A_arbace_a2g_reach_note_unavailable_BANG__A{}; t.Ctor(); return t }
//line :76:1
func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Ctor() {}
//line :76:1
func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Invoke_O_O__O(self, why__0 any) any {
	var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_59; if jrt.A2g_Truth(jrt.NN(tmp1).Get__O()) {
		var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_60; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_61; var tmp5 *lang.Keyword = tmp4; var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_62; var tmp7 any = jrt.NN(tmp5).Invoke_O__O(jrt.NN(tmp6).Get__O()); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_63; var tmp9 any = jrt.NN(tmp8).GetRawRoot__O(); var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_59; var tmp11 any = jrt.NN(tmp10).Get__O(); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_64; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_14; var tmp15 any = jrt.NN(tmp14).GetRawRoot__O(); var tmp16 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp16 = lang.PersistentHashSet_EMPTY; return tmp3.Invoke_O_O_O_O_O__O(tmp7, tmp9, tmp11, tmp13.Invoke_O_O__O(tmp15, tmp16.Ref()), why__0) } else {
//line :77:1
			return nil
		}
}


func A_arbace_a2g_reach_hw_has_static_QMARK__A_New() *A_arbace_a2g_reach_hw_has_static_QMARK__A { A_arbace_a2g_reach_hw_has_static_QMARK__A_Init(); t := &A_arbace_a2g_reach_hw_has_static_QMARK__A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Ctor() {}
//line :82:1
func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Invoke_O_O_O_O__O(self, cls__0, name__1, desc__2 any) any { var g__4 any; var tmp1 *lang.Var;
														A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_65; g__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(cls__0); var base__5 any; var tmp2 /*line :82:1*/*lang.Var;

	A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_66; base__5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(name__1, desc__2); var scan__6 any; var tmp3 /*line :82:1*/*lang.Keyword;


	A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_67; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_68; scan__6 = jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O()); var or__1927000174__auto____7 any; var tmp6 /*line :82:1*/*lang.Var;



	A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_18; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_70; or__1927000174__auto____7 = tmp7.Invoke_O_O__O(jrt.NN(tmp8).Invoke_O__O(scan__6), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_263, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref()); if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {
		var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_69; return lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(cls__0, base__5) } }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_New() *A_arbace_a2g_reach_hw_has_field_QMARK__A { A_arbace_a2g_reach_hw_has_field_QMARK__A_Init(); t := &A_arbace_a2g_reach_hw_has_field_QMARK__A{}; t.Ctor(); return t }
//line :89:1
func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Ctor() {}
//line :89:1
func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Invoke_O_O_O_O__O(self, cls__0, fname__1, static_QMARK___2 any) any { var g__4 any; var tmp1 *lang.Var;
															A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_65; g__4 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(cls__0); var scan__5 any; var tmp2 /*line :89:1*/*lang.Keyword;

	A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_67; var tmp3 *lang.Keyword = tmp2; var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_68; scan__5 = jrt.NN(tmp3).Invoke_O__O(jrt.NN(tmp4).Get__O()); if
	jrt.A2g_Truth(static_QMARK___2) { var or__1927000174__auto____6 any; var tmp5 *lang.Var
		A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_18; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_71; var tmp8 any = jrt.NN(tmp7).Invoke_O__O(scan__5); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_72; or__1927000174__auto____6 = tmp6.Invoke_O_O__O(tmp8, lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O__O(g__4, fname__1)); if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_18; var tmp11 lang.IFn = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()); var tmp12 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_73; var tmp13 any = jrt.NN(tmp12).Invoke_O__O(scan__5); var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_72; return tmp11.Invoke_O_O__O(tmp13, lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()).Invoke_O_O__O(g__4, fname__1)) } } else {
//line :92:1
				jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } }




func A_arbace_a2g_reach_use_BANG__A_New() *A_arbace_a2g_reach_use_BANG__A { A_arbace_a2g_reach_use_BANG__A_Init(); t := &A_arbace_a2g_reach_use_BANG__A{}; t.Ctor(); return t }
//line :97:1
func (t *A_arbace_a2g_reach_use_BANG__A) Ctor() {}
//line :97:1
func (t *A_arbace_a2g_reach_use_BANG__A) Invoke_O_O__O(self, n__0 any) any {



	if lang.Util_Identical_O_O__Z(n__0, nil) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z(n__0, Lit_247) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_74; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_18; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_13; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_82; var tmp7 *lang.Keyword = tmp6; var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_62; if jrt.A2g_Truth(tmp3.Invoke_O_O__O(tmp5.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(jrt.NN(tmp8).Get__O())), n__0)) {



		var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_83; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_327, nil, Lit_328, nil); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_13; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_82; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_62; tmp10.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil, lang.RT_Get_O_O__O(tmp13.Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Get__O())), n__0))).Ref())
//line :101:1
		jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp17 any; var and__1927000168__auto____2 any; var tmp18 *lang.Var




			A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_75; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_21; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_84; var tmp22 *lang.Keyword = tmp21; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_75; tmp17 = tmp20.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(n__0))) } else { tmp17 = and__1927000168__auto____2 }
//line :101:1
			if jrt.A2g_Truth(tmp17) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp24 any; var and__1927000168__auto____2_2 any; var tmp25 *lang.Var






				A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_75; and__1927000168__auto____2_2 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(n__0); if jrt.A2g_Truth(and__1927000168__auto____2_2) { var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_21; var tmp27 lang.IFn = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()); var tmp28 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp28 = A_arbace_a2g_reach_A_const_85; tmp24 = tmp27.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp28).Get__O()).Invoke_O__O(n__0)) } else { tmp24 = and__1927000168__auto____2_2 }
//line :101:1
				if jrt.A2g_Truth(tmp24) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp29 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_76; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(n__0)) { var d__2 any; var tmp30 *lang.Var








					A_arbace_a2g_reach_A_Init(); tmp30 = A_arbace_a2g_reach_A_const_77; d__2 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(n__0)
//line :101:1
					var temp__1927000408__auto____3 any; var tmp31 *lang.Keyword









					A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_78; var tmp32 *lang.Keyword = tmp31; var tmp33 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_13; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_86; temp__1927000408__auto____3 = jrt.NN(tmp32).Invoke_O__O(tmp34.Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(d__2))); if jrt.A2g_Truth(temp__1927000408__auto____3) { var why__4 any = temp__1927000408__auto____3; var tmp36 *lang.Var
						A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_60; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_82; var tmp39 *lang.Keyword = tmp38; var tmp40 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp40 = A_arbace_a2g_reach_A_const_62; var tmp41 any = jrt.NN(tmp39).Invoke_O__O(jrt.NN(tmp40).Get__O()); var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_87; tmp37.Invoke_O_O_O_O__O(tmp41, jrt.NN(tmp42).GetRawRoot__O(), n__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_287, nil), jrt.RefArrayOf(jrt.Object_class, nil, why__4)).Ref())
						var tmp43 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp43 = A_arbace_a2g_reach_A_const_83; lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_327, nil, Lit_329), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref())
//line :111:1
						jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else {




							var tmp44 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp44 = A_arbace_a2g_reach_A_const_60; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp46 = A_arbace_a2g_reach_A_const_88; var tmp47 *lang.Keyword = tmp46; var tmp48 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp48 = A_arbace_a2g_reach_A_const_62; var tmp49 any = jrt.NN(tmp47).Invoke_O__O(jrt.NN(tmp48).Get__O()); var tmp50 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp50 = A_arbace_a2g_reach_A_const_14; tmp45.Invoke_O_O_O__O(tmp49, jrt.NN(tmp50).GetRawRoot__O(), n__0)
//line :111:1
							var sup__4 any; var tmp51 *lang.Keyword





							A_arbace_a2g_reach_A_Init(); tmp51 = A_arbace_a2g_reach_A_const_56; sup__4 = jrt.NN(tmp51).Invoke_O__O(d__2)
//line :111:1
							var ok__5 any; var tmp52 *lang.Var






							A_arbace_a2g_reach_A_Init(); tmp52 = A_arbace_a2g_reach_A_const_89; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp54 = A_arbace_a2g_reach_A_const_90; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp56 = A_arbace_a2g_reach_A_const_59; var tmp57 any = tmp56.Ref(); tmp53.Invoke_O__O(tmp55.Invoke_O_O__O(tmp57, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_330, Lit_317))); var tmp58 any = A_arbace_a2g_reach_use_BANG__fn__214000080_A_New_O(sup__4); var tmp59 *jrt.Class; A_arbace_a2g_reach_use_BANG__fn__214000080_A_Init(); tmp59 = A_arbace_a2g_reach_use_BANG__fn__214000080_A_fn_class; ok__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp58, tmp59, nil).Invoke__O()
							var tmp60 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp60 = A_arbace_a2g_reach_A_const_21; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(ok__5)) {
								var tmp61 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp61 = A_arbace_a2g_reach_A_const_60; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp63 = A_arbace_a2g_reach_A_const_88; var tmp64 *lang.Keyword = tmp63; var tmp65 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp65 = A_arbace_a2g_reach_A_const_62; var tmp66 any = jrt.NN(tmp64).Invoke_O__O(jrt.NN(tmp65).Get__O()); var tmp67 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp67 = A_arbace_a2g_reach_A_const_91; tmp62.Invoke_O_O_O__O(tmp66, jrt.NN(tmp67).GetRawRoot__O(), n__0)
								var tmp68 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp68 = A_arbace_a2g_reach_A_const_60; var tmp69 lang.IFn = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()); var tmp70 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp70 = A_arbace_a2g_reach_A_const_82; var tmp71 *lang.Keyword = tmp70; var tmp72 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp72 = A_arbace_a2g_reach_A_const_62; var tmp73 any = jrt.NN(tmp71).Invoke_O__O(jrt.NN(tmp72).Get__O()); var tmp74 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp74 = A_arbace_a2g_reach_A_const_87; tmp69.Invoke_O_O_O_O__O(tmp73, jrt.NN(tmp74).GetRawRoot__O(), n__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_331, nil, Lit_332), jrt.RefArrayOf(jrt.Object_class, nil, sup__4, nil)).Ref())
								var tmp75 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp75 = A_arbace_a2g_reach_A_const_83; lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_327, nil, Lit_333, nil, Lit_332), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil, sup__4, nil)).Ref())
//line :119:1
								jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var seq_214000082__6 any; var tmp76 *lang.Var





									A_arbace_a2g_reach_A_Init(); tmp76 = A_arbace_a2g_reach_A_const_20; var tmp77 lang.IFn = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()); var tmp78 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp78 = A_arbace_a2g_reach_A_const_93; seq_214000082__6 = tmp77.Invoke_O__O(jrt.NN(tmp78).Invoke_O__O(d__2))
//line :119:1
									var chunk_214000083__7 any; var count_214000084__8 int64 = 0; var i_214000085__9 int64 = 0; L1: for {





										if lang.Numbers_Lt_J_J__Z(i_214000085__9, count_214000084__8) { var i__10 any = lang.Indexed_Cast(chunk_214000083__7).Nth_I__O(lang.RT_IntCast_J__I(i_214000085__9)); var tmp79 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp79 = A_arbace_a2g_reach_A_const_89; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp81 = A_arbace_a2g_reach_A_const_90; var tmp82 lang.IFn = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()); var tmp83 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp83 = A_arbace_a2g_reach_A_const_59; var tmp84 any = tmp83.Ref(); tmp80.Invoke_O__O(tmp82.Invoke_O_O__O(tmp84, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_330, Lit_317))); var tmp85 any = A_arbace_a2g_reach_use_BANG__fn__214000086_A_New_O(i__10); var tmp86 *jrt.Class; A_arbace_a2g_reach_use_BANG__fn__214000086_A_Init(); tmp86 = A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp85, tmp86, nil).Invoke__O(); seq_214000082__6, chunk_214000083__7, count_214000084__8, i_214000085__9 = seq_214000082__6, chunk_214000083__7, count_214000084__8, lang.Numbers_Unchecked_inc_J__J(i_214000085__9); continue L1 } else { var temp__1927000414__auto____10 any; var tmp87 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp87 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp87).GetRawRoot__O()).Invoke_O__O(seq_214000082__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_214000082__11 any = temp__1927000414__auto____10; var tmp88 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp88 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()).Invoke_O__O(seq_214000082__11)) { var c__1927000678__auto____12 any; var tmp89 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp89 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____12 = lang.IFn_Cast(jrt.NN(tmp89).GetRawRoot__O()).Invoke_O__O(seq_214000082__11); var tmp90 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp90 = A_arbace_a2g_reach_A_const_26; seq_214000082__6, chunk_214000083__7, count_214000084__8, i_214000085__9 = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()).Invoke_O__O(seq_214000082__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__12 any; var tmp91 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp91 = A_arbace_a2g_reach_A_const_24; i__12 = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()).Invoke_O__O(seq_214000082__11); var tmp92 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp92 = A_arbace_a2g_reach_A_const_89; var tmp93 lang.IFn = lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()); var tmp94 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp94 = A_arbace_a2g_reach_A_const_90; var tmp95 lang.IFn = lang.IFn_Cast(jrt.NN(tmp94).GetRawRoot__O()); var tmp96 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp96 = A_arbace_a2g_reach_A_const_59; var tmp97 any = tmp96.Ref(); tmp93.Invoke_O__O(tmp95.Invoke_O_O__O(tmp97, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_330, Lit_317))); var tmp98 any = A_arbace_a2g_reach_use_BANG__fn__214000088_A_New_O(i__12); var tmp99 *jrt.Class; A_arbace_a2g_reach_use_BANG__fn__214000088_A_Init(); tmp99 = A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp98, tmp99, nil).Invoke__O(); var tmp100 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp100 = A_arbace_a2g_reach_A_const_28; seq_214000082__6, chunk_214000083__7, count_214000084__8, i_214000085__9 = lang.IFn_Cast(jrt.NN(tmp100).GetRawRoot__O()).Invoke_O__O(seq_214000082__11), nil, 0, 0; continue L1 } } }
//line :119:1
										break L1 }; var temp__1927000414__auto____6 any; var tmp101 *lang.Keyword







									A_arbace_a2g_reach_A_Init(); tmp101 = A_arbace_a2g_reach_A_const_92; temp__1927000414__auto____6 = jrt.NN(tmp101).Invoke_O__O(d__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var o__7 any = temp__1927000414__auto____6; var tmp102 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp102 = A_arbace_a2g_reach_A_const_89; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp104 = A_arbace_a2g_reach_A_const_90; var tmp105 lang.IFn = lang.IFn_Cast(jrt.NN(tmp104).GetRawRoot__O()); var tmp106 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp106 = A_arbace_a2g_reach_A_const_59; var tmp107 any = tmp106.Ref(); tmp103.Invoke_O__O(tmp105.Invoke_O_O__O(tmp107, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_330, Lit_317))); var tmp108 any = A_arbace_a2g_reach_use_BANG__fn__214000090_A_New_O(o__7); var tmp109 *jrt.Class; A_arbace_a2g_reach_use_BANG__fn__214000090_A_Init(); tmp109 = A_arbace_a2g_reach_use_BANG__fn__214000090_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp108, tmp109, nil).Invoke__O() }
//line :119:1
									jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } } else {
//line :101:1
										var tmp110 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp110 = A_arbace_a2g_reach_A_const_75; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp111 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp111 = A_arbace_a2g_reach_A_const_81; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp111).GetRawRoot__O()).Invoke_O__O(n__0)) {































											var tmp112 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp112 = A_arbace_a2g_reach_A_const_60; var tmp113 lang.IFn = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()); var tmp114 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp114 = A_arbace_a2g_reach_A_const_88; var tmp115 *lang.Keyword = tmp114; var tmp116 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp116 = A_arbace_a2g_reach_A_const_62; var tmp117 any = jrt.NN(tmp115).Invoke_O__O(jrt.NN(tmp116).Get__O()); var tmp118 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp118 = A_arbace_a2g_reach_A_const_14; tmp113.Invoke_O_O_O__O(tmp117, jrt.NN(tmp118).GetRawRoot__O(), n__0)
//line :101:1
											var seq_214000092__2 any; var tmp119 *lang.Var
































											A_arbace_a2g_reach_A_Init(); tmp119 = A_arbace_a2g_reach_A_const_20; var tmp120 lang.IFn = lang.IFn_Cast(jrt.NN(tmp119).GetRawRoot__O()); var tmp121 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp121 = A_arbace_a2g_reach_A_const_93; var tmp122 *lang.Keyword = tmp121; var tmp123 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp123 = A_arbace_a2g_reach_A_const_43; seq_214000092__2 = tmp120.Invoke_O__O(jrt.NN(tmp122).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()).Invoke_O__O(n__0)))
//line :101:1
											var chunk_214000093__3 any; var count_214000094__4 int64 = 0; var i_214000095__5 int64 = 0; L2: for {
































												if lang.Numbers_Lt_J_J__Z(i_214000095__5, count_214000094__4) { var i__6 any = lang.Indexed_Cast(chunk_214000093__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000095__5)); var tmp124 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp124 = A_arbace_a2g_reach_A_const_89; var tmp125 lang.IFn = lang.IFn_Cast(jrt.NN(tmp124).GetRawRoot__O()); var tmp126 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp126 = A_arbace_a2g_reach_A_const_90; var tmp127 lang.IFn = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()); var tmp128 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp128 = A_arbace_a2g_reach_A_const_59; var tmp129 any = tmp128.Ref(); tmp125.Invoke_O__O(tmp127.Invoke_O_O__O(tmp129, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_330, Lit_317))); var tmp130 any = A_arbace_a2g_reach_use_BANG__fn__214000096_A_New_O(i__6); var tmp131 *jrt.Class; A_arbace_a2g_reach_use_BANG__fn__214000096_A_Init(); tmp131 = A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp130, tmp131, nil).Invoke__O(); seq_214000092__2, chunk_214000093__3, count_214000094__4, i_214000095__5 = seq_214000092__2, chunk_214000093__3, count_214000094__4, lang.Numbers_Unchecked_inc_J__J(i_214000095__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var tmp132 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp132 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6_2 = lang.IFn_Cast(jrt.NN(tmp132).GetRawRoot__O()).Invoke_O__O(seq_214000092__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_214000092__7 any = temp__1927000414__auto____6_2; var tmp133 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp133 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp133).GetRawRoot__O()).Invoke_O__O(seq_214000092__7)) { var c__1927000678__auto____8 any; var tmp134 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp134 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp134).GetRawRoot__O()).Invoke_O__O(seq_214000092__7); var tmp135 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp135 = A_arbace_a2g_reach_A_const_26; seq_214000092__2, chunk_214000093__3, count_214000094__4, i_214000095__5 = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()).Invoke_O__O(seq_214000092__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var i__8 any; var tmp136 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp136 = A_arbace_a2g_reach_A_const_24; i__8 = lang.IFn_Cast(jrt.NN(tmp136).GetRawRoot__O()).Invoke_O__O(seq_214000092__7); var tmp137 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp137 = A_arbace_a2g_reach_A_const_89; var tmp138 lang.IFn = lang.IFn_Cast(jrt.NN(tmp137).GetRawRoot__O()); var tmp139 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp139 = A_arbace_a2g_reach_A_const_90; var tmp140 lang.IFn = lang.IFn_Cast(jrt.NN(tmp139).GetRawRoot__O()); var tmp141 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp141 = A_arbace_a2g_reach_A_const_59; var tmp142 any = tmp141.Ref(); tmp138.Invoke_O__O(tmp140.Invoke_O_O__O(tmp142, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_330, Lit_317))); var tmp143 any = A_arbace_a2g_reach_use_BANG__fn__214000098_A_New_O(i__8); var tmp144 *jrt.Class; A_arbace_a2g_reach_use_BANG__fn__214000098_A_Init(); tmp144 = A_arbace_a2g_reach_use_BANG__fn__214000098_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp143, tmp144, nil).Invoke__O(); var tmp145 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp145 = A_arbace_a2g_reach_A_const_28; seq_214000092__2, chunk_214000093__3, count_214000094__4, i_214000095__5 = lang.IFn_Cast(jrt.NN(tmp145).GetRawRoot__O()).Invoke_O__O(seq_214000092__7), nil, 0, 0; continue L2 } } }
//line :101:1
												break L2 }; jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp146 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp146 = A_arbace_a2g_reach_A_const_31; if tmp146 != nil {


































													var tmp147 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp147 = A_arbace_a2g_reach_A_const_60; var tmp148 lang.IFn = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()); var tmp149 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp149 = A_arbace_a2g_reach_A_const_94; var tmp150 *lang.Keyword = tmp149; var tmp151 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp151 = A_arbace_a2g_reach_A_const_62; var tmp152 any = jrt.NN(tmp150).Invoke_O__O(jrt.NN(tmp151).Get__O()); var tmp153 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp153 = A_arbace_a2g_reach_A_const_63; var tmp154 any = jrt.NN(tmp153).GetRawRoot__O(); var tmp155 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp155 = A_arbace_a2g_reach_A_const_64; var tmp156 lang.IFn = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()); var tmp157 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp157 = A_arbace_a2g_reach_A_const_14; var tmp158 any = jrt.NN(tmp157).GetRawRoot__O(); var tmp159 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp159 = lang.PersistentHashSet_EMPTY; var tmp160 any = tmp156.Invoke_O_O__O(tmp158, tmp159.Ref()); var tmp161 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp161 = A_arbace_a2g_reach_A_const_59; tmp148.Invoke_O_O_O_O_O__O(tmp152, tmp154, n__0, tmp160, jrt.NN(tmp161).Get__O())
													var tmp162 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp162 = A_arbace_a2g_reach_A_const_83; var tmp163 lang.IFn = lang.IFn_Cast(jrt.NN(tmp162).GetRawRoot__O()); var tmp164 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_327, nil, Lit_334); var tmp165 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp165 = A_arbace_a2g_reach_A_const_95; tmp163.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp164, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_250, Lit_249), nil)).Ref())
//line :101:1
													jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
													}
												}
										}
									}
				}
			}
		}
	}
	}
	}
}





func A_arbace_a2g_reach_use_BANG__fn__214000080_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000080_A { A_arbace_a2g_reach_use_BANG__fn__214000080_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000080_A{}; t.Ctor_O(p0); return t }
//line :118:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) Ctor_O(c__sup any) { t.F_sup = c__sup }
//line :118:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_sup; t.F_sup = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }






func A_arbace_a2g_reach_use_BANG__fn__214000086_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000086_A { A_arbace_a2g_reach_use_BANG__fn__214000086_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000086_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :125:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_i; t.F_i = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }
//line :125:1
func A_arbace_a2g_reach_use_BANG__fn__214000088_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000088_A { A_arbace_a2g_reach_use_BANG__fn__214000088_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000088_A{}; t.Ctor_O(p0); return t }
//line :125:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :125:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_i; t.F_i = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000090_A { A_arbace_a2g_reach_use_BANG__fn__214000090_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000090_A{}; t.Ctor_O(p0); return t }
//line :127:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) Ctor_O(c__o any) { t.F_o = c__o }
//line :127:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_o; t.F_o = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }






func A_arbace_a2g_reach_use_BANG__fn__214000096_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000096_A { A_arbace_a2g_reach_use_BANG__fn__214000096_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000096_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :134:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_i; t.F_i = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }
//line :134:1
func A_arbace_a2g_reach_use_BANG__fn__214000098_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000098_A { A_arbace_a2g_reach_use_BANG__fn__214000098_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000098_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :134:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_79; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_i; t.F_i = nil; tmp4 = t_; tmp1 = tmp3.Invoke_O__O(tmp4) }; return nil }(); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }





func A_arbace_a2g_reach_use_desc_BANG__A_New() *A_arbace_a2g_reach_use_desc_BANG__A { A_arbace_a2g_reach_use_desc_BANG__A_Init(); t := &A_arbace_a2g_reach_use_desc_BANG__A{}; t.Ctor(); return t }
//line :140:1
func (t *A_arbace_a2g_reach_use_desc_BANG__A) Ctor() {}
//line :140:1
func (t *A_arbace_a2g_reach_use_desc_BANG__A) Invoke_O_O__O(self, d__0 any) any { { var seq_214000101__2 any; var tmp1 *lang.Var
										A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_96; seq_214000101__2 = tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(d__0))
//line :140:1
	var chunk_214000102__3 any; var count_214000103__4 int64 = 0; var i_214000104__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000104__5, count_214000103__4) { var c__6 any = lang.Indexed_Cast(chunk_214000102__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000104__5)); var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(c__6); seq_214000101__2, chunk_214000102__3, count_214000103__4, i_214000104__5 = seq_214000101__2, chunk_214000102__3, count_214000103__4, lang.Numbers_Unchecked_inc_J__J(i_214000104__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(seq_214000101__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000101__7 any = temp__1927000414__auto____6; var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_214000101__7)) { var c__1927000678__auto____8 any; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_214000101__7); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_26; seq_214000101__2, chunk_214000102__3, count_214000103__4, i_214000104__5 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_214000101__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any; var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_24; c__8 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_214000101__7); var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(c__8); var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_28; seq_214000101__2, chunk_214000102__3, count_214000103__4, i_214000104__5 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(seq_214000101__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :140:1*/panic("a2g: unreachable") }


func A_arbace_a2g_reach_reach_BANG__A_New() *A_arbace_a2g_reach_reach_BANG__A { A_arbace_a2g_reach_reach_BANG__A_Init(); t := &A_arbace_a2g_reach_reach_BANG__A{}; t.Ctor(); return t }
//line :143:1
func (t *A_arbace_a2g_reach_reach_BANG__A) Ctor() {}
//line :143:1
func (t *A_arbace_a2g_reach_reach_BANG__A) Invoke_O_O__O(self, p__214000106__0 any) any { var vec__214000107__2 any = p__214000106__0; var c__3 any = lang.RT_Nth_O_I_O__O(vec__214000107__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000107__2, lang.RT_IntCast_J__I(1), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000107__2, lang.RT_IntCast_J__I(2), nil); var k__6 any = vec__214000107__2; var tmp1 any; var and__1927000168__auto____7 any = c__3; _ = name__4; _ = desc__5; if


	jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_74; and__1927000168__auto____8 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(c__3); if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any; var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_77; and__1927000168__auto____9 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(c__3); if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_85; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp4).Get__O()).Invoke_O__O(c__3); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_21; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_18; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_13; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_97; var tmp12 *lang.Keyword = tmp11; var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_62; tmp1 = tmp6.Invoke_O__O(tmp8.Invoke_O_O__O(tmp10.Invoke_O__O(jrt.NN(tmp12).Invoke_O__O(jrt.NN(tmp13).Get__O())), k__6)) } else { tmp1 = and__1927000168__auto____10 } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp1) {
		var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_60; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_97; var tmp17 *lang.Keyword = tmp16; var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_62; var tmp19 any = jrt.NN(tmp17).Invoke_O__O(jrt.NN(tmp18).Get__O()); var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_14; tmp15.Invoke_O_O_O__O(tmp19, jrt.NN(tmp20).GetRawRoot__O(), k__6)
		var tmp21 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_60; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_98; var tmp24 *lang.Keyword = tmp23; var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_62; var tmp26 any = jrt.NN(tmp24).Invoke_O__O(jrt.NN(tmp25).Get__O()); var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_14; return tmp22.Invoke_O_O_O__O(tmp26, jrt.NN(tmp27).GetRawRoot__O(), k__6) } else {
//line :146:1
			return nil } }



func A_arbace_a2g_reach_init_BANG__A_New() *A_arbace_a2g_reach_init_BANG__A { A_arbace_a2g_reach_init_BANG__A_Init(); t := &A_arbace_a2g_reach_init_BANG__A{}; t.Ctor(); return t }
//line :150:1
func (t *A_arbace_a2g_reach_init_BANG__A) Ctor() {}
//line :150:1
func (t *A_arbace_a2g_reach_init_BANG__A) Invoke_O_O__O(self, c__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = c__0; if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_74; and__1927000168__auto____3 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(c__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_77; and__1927000168__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(c__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_21; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_18; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_100; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_62; tmp1 = tmp5.Invoke_O__O(tmp7.Invoke_O_O__O(tmp9.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O())), c__0)) } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_60; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_100; var tmp16 *lang.Keyword = tmp15; var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_62; var tmp18 any = jrt.NN(tmp16).Invoke_O__O(jrt.NN(tmp17).Get__O()); var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_14; tmp14.Invoke_O_O_O__O(tmp18, jrt.NN(tmp19).GetRawRoot__O(), c__0)
//line :153:1
		var temp__1927000414__auto____2 any; var tmp20 *lang.Keyword

		A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_56; var tmp21 *lang.Keyword = tmp20; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_77; temp__1927000414__auto____2 = jrt.NN(tmp21).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(c__0)); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_101; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(s__3) }
		var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_99; return lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(c__0, Lit_242, Lit_265)) } else {
//line :153:1
			return nil
		}
}


func A_arbace_a2g_reach_external_keys_A_New() *A_arbace_a2g_reach_external_keys_A { A_arbace_a2g_reach_external_keys_A_Init(); t := &A_arbace_a2g_reach_external_keys_A{}; t.Ctor(); return t }
//line :158:1
func (t *A_arbace_a2g_reach_external_keys_A) Ctor() {}
//line :158:1
func (t *A_arbace_a2g_reach_external_keys_A) Invoke_O_O__O(self, d__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_New(); var tmp2 *jrt.Class;



	A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_Init(); tmp2 = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_fn_class; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____2); var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_57; return tmp3.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(d__0)) }
//line :162:1
func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_New() *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) Ctor() {}
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) Invoke_O_O__O(self, s__214000113__1 any) any { var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_New_O_O(s__214000113__1, self); var tmp2 *jrt.Class; A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_Init(); tmp2 = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :162:1
func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) Ctor_O_O(c__s__214000113, c__iter__214000112 any) { t.F_s__214000113 = c__s__214000113; t.F_iter__214000112 = c__iter__214000112 }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) Invoke_O__O(self any) any { { var s__214000113__1 any; var t_ any = t.F_s__214000113; t.F_s__214000113 = nil; s__214000113__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__214000113__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var s__4 any; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_24; s__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp3 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z(s__4, Lit_247)
														if or__1927000174__auto____5 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_75; tmp3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(s__4) }
//line :162:1
	if jrt.A2g_Truth(tmp3) { var iterys__1927001035__auto____5 any; var tmp5 any = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_New(); var tmp6 *jrt.Class; A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_Init(); tmp6 = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var fs__1927001036__auto____6 any; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_20; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_42; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_43; fs__1927001036__auto____6 = tmp8.Invoke_O__O(tmp9.Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__4)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_102; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(t.F_iter__214000112); var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_51; return tmp14.Invoke_O_O__O(fs__1927001036__auto____6, tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__214000113__1))) } else { var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_51; s__214000113__1 = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(s__214000113__1); continue L1 } } else { var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_51; s__214000113__1 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(s__214000113__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :162:1
func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_New() *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A{}; t.Ctor(); return t }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) Ctor() {}
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) Invoke_O_O__O(self, s__214000115__1 any) any { var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_New_O_O(self, s__214000115__1); var tmp2 *jrt.Class; A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_Init(); tmp2 = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :162:1
func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A{}; t.Ctor_O_O(p0, p1); return t }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) Ctor_O_O(c__iter__214000114, c__s__214000115 any) { t.F_iter__214000114 = c__iter__214000114; t.F_s__214000115 = c__s__214000115 }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) Invoke_O__O(self any) any { { var s__214000115__1 any; var t_ any = t.F_s__214000115; t.F_s__214000115 = nil; s__214000115__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__214000115__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000115__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__214000115__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__214000115__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000117__6 any; var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_37; b__214000117__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_New_O_I_O(b__214000117__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_Init(); tmp6 = A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_48; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_50; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__214000117__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__214000114); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_26; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__214000115__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_48; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_50; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__214000117__6), nil) } } else { var mm__4 any; var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_24; mm__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__214000115__3); var tmp17 any; var and__1927000168__auto____5 any; var tmp18 *lang.Var


	A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_21; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_45; and__1927000168__auto____5 = tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any; var tmp21 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_21; var tmp22 lang.IFn = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()); var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_46; and__1927000168__auto____6 = tmp22.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_38; var tmp25 lang.IFn = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()); var tmp26 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_40; tmp17 = tmp25.Invoke_O_O__O(Lit_241, jrt.NN(tmp26).Invoke_O__O(mm__4)) } else { tmp17 = and__1927000168__auto____6 } } else { tmp17 = and__1927000168__auto____5 }
//line :162:1
	if jrt.A2g_Truth(tmp17) { var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_49; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_40; var tmp30 any = jrt.NN(tmp29).Invoke_O__O(mm__4); var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_41; var tmp32 any = lang.Tuple_Create_O_O__IPersistentVector(tmp30, jrt.NN(tmp31).Invoke_O__O(mm__4)); var tmp33 lang.IFn = lang.IFn_Cast(t.F_iter__214000114); var tmp34 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp34 = A_arbace_a2g_reach_A_const_51; return tmp28.Invoke_O_O__O(tmp32, tmp33.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(s__214000115__3))) } else { var tmp35 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_51; s__214000115__1 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(s__214000115__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :162:1
func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) Ctor_O_I_O(c__b__214000117 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__214000117 = c__b__214000117; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :162:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) Invoke_O__O(self any) any { { var i__214000116__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000116__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000116__1)); var tmp2 any; var and__1927000168__auto____3 any; var tmp3 *lang.Var


	A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_45; and__1927000168__auto____3 = tmp4.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any; var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_21; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_46; and__1927000168__auto____4 = tmp7.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_38; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_40; tmp2 = tmp10.Invoke_O_O__O(Lit_241, jrt.NN(tmp11).Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :162:1
	if jrt.A2g_Truth(tmp2) { var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_47; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 any = t.F_b__214000117; var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_40; var tmp16 any = jrt.NN(tmp15).Invoke_O__O(mm__2); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_41; tmp13.Invoke_O_O__O(tmp14, lang.Tuple_Create_O_O__IPersistentVector(tmp16, jrt.NN(tmp17).Invoke_O__O(mm__2))); i__214000116__1 = lang.Numbers_Unchecked_inc_J__J(i__214000116__1); continue L1 } else { i__214000116__1 = lang.Numbers_Unchecked_inc_J__J(i__214000116__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_reach_supertypes_of_A_New() *A_arbace_a2g_reach_supertypes_of_A { A_arbace_a2g_reach_supertypes_of_A_Init(); t := &A_arbace_a2g_reach_supertypes_of_A{}; t.Ctor(); return t }
//line :168:1
func (t *A_arbace_a2g_reach_supertypes_of_A) Ctor() {}
//line :168:1
func (t *A_arbace_a2g_reach_supertypes_of_A) Invoke_O_O__O(self, d__0 any) any { var s__2 any; var tmp1 *lang.Var;


	A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_57; s__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(d__0); var tmp2 /*line :172:1*/*lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_36; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = A_arbace_a2g_reach_supertypes_of_fn__214000130_A_New(); var tmp5 *jrt.Class; A_arbace_a2g_reach_supertypes_of_fn__214000130_A_Init(); tmp5 = A_arbace_a2g_reach_supertypes_of_fn__214000130_A_fn_class; if jrt.A2g_Truth(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), s__2)) { return s__2 } else { var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_14; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_103; return tmp7.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(s__2), Lit_247) } }
//line :172:1
func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_New() *A_arbace_a2g_reach_supertypes_of_fn__214000130_A { A_arbace_a2g_reach_supertypes_of_fn__214000130_A_Init(); t := &A_arbace_a2g_reach_supertypes_of_fn__214000130_A{}; t.Ctor(); return t }
//line :172:1
func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) Ctor() {}
//line :172:1
func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) Invoke_O_O__O(self, p1__214000129_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_247, p1__214000129_SHARP___1)).Ref() }

func A_arbace_a2g_reach_vcalls_on_A_New() *A_arbace_a2g_reach_vcalls_on_A { A_arbace_a2g_reach_vcalls_on_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_a2g_reach_vcalls_on_A) Ctor() {}
//line :174:1
func (t *A_arbace_a2g_reach_vcalls_on_A) Invoke_O_O__O(self, d__0 any) any { var by__2 any; var tmp1 *lang.Var;



	A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_13; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_104; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_62; by__2 = tmp2.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp5).Get__O())); var iter__1927001039__auto____3 any; var tmp6 any = /*line :174:1*/A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_New_O(by__2); var tmp7 *jrt.Class;




	A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_Init(); tmp7 = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_fn_class; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var tmp8 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_105; return tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(d__0)) }
//line :179:1
func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_New_O(p0 any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A{}; t.Ctor_O(p0); return t }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) Ctor_O(c__by any) { t.F_by = c__by }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) Invoke_O_O__O(self, s__214000134__1 any) any { var tmp1 any = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_New_O_O_O(s__214000134__1, t.F_by, self); var tmp2 *jrt.Class; A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_Init(); tmp2 = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) Ctor_O_O_O(c__s__214000134, c__by, c__iter__214000133 any) { t.F_s__214000134 = c__s__214000134; t.F_by = c__by; t.F_iter__214000133 = c__iter__214000133 }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) Invoke_O__O(self any) any { { var s__214000134__1 any; var t_ any = t.F_s__214000134; t.F_s__214000134 = nil; s__214000134__1 = t_; L1: for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__214000134__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var s__4 any; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_24; s__4 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp3 any = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_New(); var tmp4 *jrt.Class; A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_Init(); tmp4 = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_fn_class; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var fs__1927001036__auto____6 any; var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_20; fs__1927001036__auto____6 = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.RT_Get_O_O__O(t.F_by, s__4))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_102; var tmp7 lang.IFn = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()); var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__214000133); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_51; return tmp7.Invoke_O_O__O(fs__1927001036__auto____6, tmp8.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(s__214000134__1))) } else { var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_51; s__214000134__1 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(s__214000134__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :179:1
func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_New() *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A{}; t.Ctor(); return t }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) Ctor() {}
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) Invoke_O_O__O(self, s__214000136__1 any) any { var tmp1 any = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_New_O_O(self, s__214000136__1); var tmp2 *jrt.Class; A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_Init(); tmp2 = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_fn_class; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :179:1
func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A{}; t.Ctor_O_O(p0, p1); return t }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) Ctor_O_O(c__iter__214000135, c__s__214000136 any) { t.F_iter__214000135 = c__iter__214000135; t.F_s__214000136 = c__s__214000136 }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) Invoke_O__O(self any) any { { var s__214000136__1 any; var t_ any = t.F_s__214000136; t.F_s__214000136 = nil; s__214000136__1 = t_; for { var temp__1927000414__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(s__214000136__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000136__3 any = temp__1927000414__auto____2; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(s__214000136__3)) { var c__1927001037__auto____4 any; var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_23; c__1927001037__auto____4 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(s__214000136__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000138__6 any; var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_37; b__214000138__6 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp5 any = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_New_O_I_O(b__214000138__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp6 *jrt.Class; A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_Init(); tmp6 = A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_fn_class; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil).Invoke__O()) { var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_48; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_50; var tmp10 any = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(b__214000138__6); var tmp11 lang.IFn = lang.IFn_Cast(t.F_iter__214000135); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_26; return tmp8.Invoke_O_O__O(tmp10, tmp11.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(s__214000136__3))) } else { var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_48; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_50; return tmp14.Invoke_O_O__O(lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()).Invoke_O__O(b__214000138__6), nil) } } else { var nd__4 any; var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_24; nd__4 = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(s__214000136__3); var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_49; var tmp18 lang.IFn = lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()); var tmp19 lang.IFn = lang.IFn_Cast(t.F_iter__214000135); var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_51; return tmp18.Invoke_O_O__O(nd__4, tmp19.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(s__214000136__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :179:1
func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) Ctor_O_I_O(c__b__214000138 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__214000138 = c__b__214000138; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :179:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) Invoke_O__O(self any) any { { var i__214000137__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000137__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nd__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000137__1)); var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_47; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(t.F_b__214000138, nd__2); i__214000137__1 = lang.Numbers_Unchecked_inc_J__J(i__214000137__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_reach_instantiate_BANG__A_New() *A_arbace_a2g_reach_instantiate_BANG__A { A_arbace_a2g_reach_instantiate_BANG__A_Init(); t := &A_arbace_a2g_reach_instantiate_BANG__A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_a2g_reach_instantiate_BANG__A) Ctor() {}
//line :181:1
func (t *A_arbace_a2g_reach_instantiate_BANG__A) Invoke_O_O__O(self, d__0 any) any {

	{ var tmp1 any; var and__1927000168__auto____2 any; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_74; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(d__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_21; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_18; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_13; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_106; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_62; tmp1 = tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Get__O())), d__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_60; var tmp13 lang.IFn = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()); var tmp14 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_106; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_62; var tmp17 any = jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Get__O()); var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_14; tmp13.Invoke_O_O_O__O(tmp17, jrt.NN(tmp18).GetRawRoot__O(), d__0)
//line :183:1
		var seq_214000150__2 any; var tmp19 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_20; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_105; seq_214000150__2 = tmp20.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(d__0))
//line :183:1
		var chunk_214000151__3 any; var count_214000152__4 int64 = 0; var i_214000153__5 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z(i_214000153__5, count_214000152__4) { var s__6 any = lang.Indexed_Cast(chunk_214000151__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000153__5)); var tmp22 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_60; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_107; var tmp25 *lang.Keyword = tmp24; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_62; var tmp27 any = jrt.NN(tmp25).Invoke_O__O(jrt.NN(tmp26).Get__O()); var tmp28 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp28 = A_arbace_a2g_reach_A_const_63; var tmp29 any = jrt.NN(tmp28).GetRawRoot__O(); var tmp30 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp30 = A_arbace_a2g_reach_A_const_64; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_14; var tmp33 any = jrt.NN(tmp32).GetRawRoot__O(); var tmp34 *lang.PersistentVector; lang.PersistentVector_Init(); tmp34 = lang.PersistentVector_EMPTY; tmp23.Invoke_O_O_O_O_O__O(tmp27, tmp29, s__6, tmp31.Invoke_O_O__O(tmp33, tmp34.Ref()), d__0)
//line :185:1
				seq_214000150__2, chunk_214000151__3, count_214000152__4, i_214000153__5 = seq_214000150__2, chunk_214000151__3, count_214000152__4, lang.Numbers_Unchecked_inc_J__J(i_214000153__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp35 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(seq_214000150__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000150__7 any = temp__1927000414__auto____6; var tmp36 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(seq_214000150__7)) { var c__1927000678__auto____8 any; var tmp37 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq_214000150__7); var tmp38 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_26; seq_214000150__2, chunk_214000151__3, count_214000152__4, i_214000153__5 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(seq_214000150__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var s__8 any; var tmp39 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_24; s__8 = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(seq_214000150__7)
					var tmp40 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp40 = A_arbace_a2g_reach_A_const_60; var tmp41 lang.IFn = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()); var tmp42 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_107; var tmp43 *lang.Keyword = tmp42; var tmp44 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp44 = A_arbace_a2g_reach_A_const_62; var tmp45 any = jrt.NN(tmp43).Invoke_O__O(jrt.NN(tmp44).Get__O()); var tmp46 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp46 = A_arbace_a2g_reach_A_const_63; var tmp47 any = jrt.NN(tmp46).GetRawRoot__O(); var tmp48 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp48 = A_arbace_a2g_reach_A_const_64; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp50 = A_arbace_a2g_reach_A_const_14; var tmp51 any = jrt.NN(tmp50).GetRawRoot__O(); var tmp52 *lang.PersistentVector; lang.PersistentVector_Init(); tmp52 = lang.PersistentVector_EMPTY; tmp41.Invoke_O_O_O_O_O__O(tmp45, tmp47, s__8, tmp49.Invoke_O_O__O(tmp51, tmp52.Ref()), d__0)
//line :185:1
					var tmp53 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp53 = A_arbace_a2g_reach_A_const_28; seq_214000150__2, chunk_214000151__3, count_214000152__4, i_214000153__5 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_214000150__7), nil, 0, 0; continue L1 } } }
//line :183:1
			break L1 }; var seq_214000154__2 any; var tmp54 *lang.Var



		A_arbace_a2g_reach_A_Init(); tmp54 = A_arbace_a2g_reach_A_const_20; var tmp55 lang.IFn = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()); var tmp56 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp56 = A_arbace_a2g_reach_A_const_108; seq_214000154__2 = tmp55.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(d__0))
//line :183:1
		var chunk_214000155__3 any; var count_214000156__4 int64 = 0; var i_214000157__5 int64 = 0; L2: for {



			if lang.Numbers_Lt_J_J__Z(i_214000157__5, count_214000156__4) { var nd__6 any = lang.Indexed_Cast(chunk_214000155__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000157__5)); var temp__1927000414__auto____7 any; var tmp57 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp57 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O_O__O(d__0, nd__6); if jrt.A2g_Truth(temp__1927000414__auto____7) { var k__8 any = temp__1927000414__auto____7; var tmp58 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp58 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp58).GetRawRoot__O()).Invoke_O__O(k__8) }
//line :187:1
				seq_214000154__2, chunk_214000155__3, count_214000156__4, i_214000157__5 = seq_214000154__2, chunk_214000155__3, count_214000156__4, lang.Numbers_Unchecked_inc_J__J(i_214000157__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var tmp59 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp59 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6_2 = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()).Invoke_O__O(seq_214000154__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_214000154__7 any = temp__1927000414__auto____6_2; var tmp60 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp60 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(seq_214000154__7)) { var c__1927000678__auto____8_2 any; var tmp61 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp61 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8_2 = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(seq_214000154__7); var tmp62 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp62 = A_arbace_a2g_reach_A_const_26; seq_214000154__2, chunk_214000155__3, count_214000156__4, i_214000157__5 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(seq_214000154__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var nd__8 any; var tmp63 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp63 = A_arbace_a2g_reach_A_const_24; nd__8 = lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_214000154__7); var temp__1927000414__auto____9 any; var tmp64 *lang.Var
					A_arbace_a2g_reach_A_Init(); tmp64 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O_O__O(d__0, nd__8); if jrt.A2g_Truth(temp__1927000414__auto____9) { var k__10 any = temp__1927000414__auto____9; var tmp65 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp65 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(k__10) }
//line :187:1
					var tmp66 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp66 = A_arbace_a2g_reach_A_const_28; seq_214000154__2, chunk_214000155__3, count_214000156__4, i_214000157__5 = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(seq_214000154__7), nil, 0, 0; continue L2 } } }
//line :183:1
			break L2 }; var seq_214000158__2 any; var tmp67 *lang.Var





		A_arbace_a2g_reach_A_Init(); tmp67 = A_arbace_a2g_reach_A_const_20; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp69 = A_arbace_a2g_reach_A_const_110; var tmp70 lang.IFn = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()); var tmp71 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp71 = A_arbace_a2g_reach_A_const_111; seq_214000158__2 = tmp68.Invoke_O__O(tmp70.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(d__0)))
//line :183:1
		var chunk_214000159__3 any; var count_214000160__4 int64 = 0; var i_214000161__5 int64 = 0; L3: for {





			if lang.Numbers_Lt_J_J__Z(i_214000161__5, count_214000160__4) { var k__6 any = lang.Indexed_Cast(chunk_214000159__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000161__5)); var temp__1927000414__auto____7_2 any; var tmp72 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp72 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____7_2 = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O_O__O(d__0, k__6); if jrt.A2g_Truth(temp__1927000414__auto____7_2) { var impl__8 any = temp__1927000414__auto____7_2; var tmp73 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp73 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(impl__8) }
//line :189:1
				seq_214000158__2, chunk_214000159__3, count_214000160__4, i_214000161__5 = seq_214000158__2, chunk_214000159__3, count_214000160__4, lang.Numbers_Unchecked_inc_J__J(i_214000161__5); continue L3 } else { var temp__1927000414__auto____6_3 any; var tmp74 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp74 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6_3 = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()).Invoke_O__O(seq_214000158__2); if jrt.A2g_Truth(temp__1927000414__auto____6_3) { var seq_214000158__7 any = temp__1927000414__auto____6_3; var tmp75 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp75 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(seq_214000158__7)) { var c__1927000678__auto____8_3 any; var tmp76 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp76 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8_3 = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(seq_214000158__7); var tmp77 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp77 = A_arbace_a2g_reach_A_const_26; seq_214000158__2, chunk_214000159__3, count_214000160__4, i_214000161__5 = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O__O(seq_214000158__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var k__8_2 any; var tmp78 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp78 = A_arbace_a2g_reach_A_const_24; k__8_2 = lang.IFn_Cast(jrt.NN(tmp78).GetRawRoot__O()).Invoke_O__O(seq_214000158__7); var temp__1927000414__auto____9_2 any; var tmp79 *lang.Var
					A_arbace_a2g_reach_A_Init(); tmp79 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____9_2 = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()).Invoke_O_O__O(d__0, k__8_2); if jrt.A2g_Truth(temp__1927000414__auto____9_2) { var impl__10 any = temp__1927000414__auto____9_2; var tmp80 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp80 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(impl__10) }
//line :189:1
					var tmp81 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp81 = A_arbace_a2g_reach_A_const_28; seq_214000158__2, chunk_214000159__3, count_214000160__4, i_214000161__5 = lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O__O(seq_214000158__7), nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :183:1
						return nil } }
//line :181:1
	panic("a2g: unreachable")
}









func A_arbace_a2g_reach_vcall_BANG__A_New() *A_arbace_a2g_reach_vcall_BANG__A { A_arbace_a2g_reach_vcall_BANG__A_Init(); t := &A_arbace_a2g_reach_vcall_BANG__A{}; t.Ctor(); return t }
//line :192:1
func (t *A_arbace_a2g_reach_vcall_BANG__A) Ctor() {}
//line :192:1
func (t *A_arbace_a2g_reach_vcall_BANG__A) Invoke_O_O_O_O__O(self, o__0, name__1, desc__2 any) any { { var k__4 any = lang.Tuple_Create_O_O_O__IPersistentVector(o__0, name__1, desc__2); var tmp1 *lang.Var



	A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_112; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_62; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(jrt.NN(tmp7).Get__O())), k__4)) { return nil } else {
		var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_60; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_112; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_62; var tmp13 any = jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O()); var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_14; tmp9.Invoke_O_O_O__O(tmp13, jrt.NN(tmp14).GetRawRoot__O(), k__4)
		var tmp15 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_60; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_104; var tmp18 *lang.Keyword = tmp17; var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_62; var tmp20 any = jrt.NN(tmp18).Invoke_O__O(jrt.NN(tmp19).Get__O()); var tmp21 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_63; var tmp22 any = jrt.NN(tmp21).GetRawRoot__O(); var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_64; var tmp24 lang.IFn = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_14; var tmp26 any = jrt.NN(tmp25).GetRawRoot__O(); var tmp27 *lang.PersistentVector; lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; tmp16.Invoke_O_O_O_O_O__O(tmp20, tmp22, o__0, tmp24.Invoke_O_O__O(tmp26, tmp27.Ref()), lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2))
//line :196:1
		var seq_214000164__5 any; var tmp28 *lang.Var


		A_arbace_a2g_reach_A_Init(); tmp28 = A_arbace_a2g_reach_A_const_20; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp30 = A_arbace_a2g_reach_A_const_102; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_13; var tmp33 lang.IFn = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()); var tmp34 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp34 = A_arbace_a2g_reach_A_const_107; var tmp35 *lang.Keyword = tmp34; var tmp36 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_62; var tmp37 any = lang.RT_Get_O_O__O(tmp33.Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(jrt.NN(tmp36).Get__O())), o__0); var tmp38 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_113; var tmp39 lang.IFn = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()); var tmp40 any = A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_New_O(o__0); var tmp41 *jrt.Class; A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_Init(); tmp41 = A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_fn_class; var tmp42 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); var tmp43 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp43 = A_arbace_a2g_reach_A_const_13; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp45 = A_arbace_a2g_reach_A_const_114; var tmp46 *lang.Keyword = tmp45; var tmp47 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp47 = A_arbace_a2g_reach_A_const_62; seq_214000164__5 = tmp29.Invoke_O__O(tmp31.Invoke_O_O__O(tmp37, tmp39.Invoke_O_O__O(tmp42, tmp44.Invoke_O__O(jrt.NN(tmp46).Invoke_O__O(jrt.NN(tmp47).Get__O())))))
//line :196:1
		var chunk_214000165__6 any; var count_214000166__7 int64 = 0; var i_214000167__8 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z(i_214000167__8, count_214000166__7) { var d__9 any = lang.Indexed_Cast(chunk_214000165__6).Nth_I__O(lang.RT_IntCast_J__I(i_214000167__8)); var temp__1927000414__auto____10 any; var tmp48 *lang.Var

				A_arbace_a2g_reach_A_Init(); tmp48 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____10 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O_O__O(d__9, lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2)); if jrt.A2g_Truth(temp__1927000414__auto____10) { var impl__11 any = temp__1927000414__auto____10; var tmp49 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp49 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(impl__11) }
//line :199:1
				seq_214000164__5, chunk_214000165__6, count_214000166__7, i_214000167__8 = seq_214000164__5, chunk_214000165__6, count_214000166__7, lang.Numbers_Unchecked_inc_J__J(i_214000167__8); continue L1 } else { var temp__1927000414__auto____9 any; var tmp50 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp50 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(seq_214000164__5); if jrt.A2g_Truth(temp__1927000414__auto____9) { var seq_214000164__10 any = temp__1927000414__auto____9; var tmp51 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp51 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(seq_214000164__10)) { var c__1927000678__auto____11 any; var tmp52 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp52 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____11 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(seq_214000164__10); var tmp53 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp53 = A_arbace_a2g_reach_A_const_26; seq_214000164__5, chunk_214000165__6, count_214000166__7, i_214000167__8 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_214000164__10), c__1927000678__auto____11, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var d__11 any; var tmp54 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp54 = A_arbace_a2g_reach_A_const_24; d__11 = lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(seq_214000164__10); var temp__1927000414__auto____12 any; var tmp55 *lang.Var

					A_arbace_a2g_reach_A_Init(); tmp55 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O_O__O(d__11, lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2)); if jrt.A2g_Truth(temp__1927000414__auto____12) { var impl__13 any = temp__1927000414__auto____12; var tmp56 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp56 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(impl__13) }
//line :199:1
					var tmp57 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp57 = A_arbace_a2g_reach_A_const_28; seq_214000164__5, chunk_214000165__6, count_214000166__7, i_214000167__8 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(seq_214000164__10), nil, 0, 0; continue L1 } } else { return nil } } } } }; /*line :192:1*/panic("a2g: unreachable") }







func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_New_O(p0 any) *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A { A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_Init(); t := &A_arbace_a2g_reach_vcall_BANG__fn__214000168_A{}; t.Ctor_O(p0); return t }
//line :200:1
func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) Ctor_O(c__o any) { t.F_o = c__o }
//line :200:1
func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) Invoke_O_O__O(self, p1__214000163_SHARP___1 any) any { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_58; return lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O_O__O(p1__214000163_SHARP___1, t.F_o) }


func A_arbace_a2g_reach_lambda_BANG__A_New() *A_arbace_a2g_reach_lambda_BANG__A { A_arbace_a2g_reach_lambda_BANG__A_Init(); t := &A_arbace_a2g_reach_lambda_BANG__A{}; t.Ctor(); return t }
//line :203:1
func (t *A_arbace_a2g_reach_lambda_BANG__A) Ctor() {}
//line :203:1
func (t *A_arbace_a2g_reach_lambda_BANG__A) Invoke_O_O__O(self, fi__0 any) any {



	{ var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_13; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_114; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_62; if jrt.A2g_Truth(tmp2.Invoke_O_O__O(tmp4.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(jrt.NN(tmp7).Get__O())), fi__0)) { return nil } else {
		var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_60; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_114; var tmp11 *lang.Keyword = tmp10; var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_62; var tmp13 any = jrt.NN(tmp11).Invoke_O__O(jrt.NN(tmp12).Get__O()); var tmp14 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_14; tmp9.Invoke_O_O_O__O(tmp13, jrt.NN(tmp14).GetRawRoot__O(), fi__0)
//line :207:1
		var seq_214000171__2 any; var tmp15 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_20; var tmp16 lang.IFn = lang.IFn_Cast(jrt.NN(tmp15).GetRawRoot__O()); var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_108; seq_214000171__2 = tmp16.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(fi__0))
//line :207:1
		var chunk_214000172__3 any; var count_214000173__4 int64 = 0; var i_214000174__5 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z(i_214000174__5, count_214000173__4) { var nd__6 any = lang.Indexed_Cast(chunk_214000172__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000174__5)); var temp__1927000414__auto____7 any; var tmp18 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O_O__O(fi__0, nd__6); if jrt.A2g_Truth(temp__1927000414__auto____7) { var impl__8 any = temp__1927000414__auto____7; var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(impl__8) }
//line :209:1
				seq_214000171__2, chunk_214000172__3, count_214000173__4, i_214000174__5 = seq_214000171__2, chunk_214000172__3, count_214000173__4, lang.Numbers_Unchecked_inc_J__J(i_214000174__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_214000171__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000171__7 any = temp__1927000414__auto____6; var tmp21 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_214000171__7)) { var c__1927000678__auto____8 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000171__7); var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_26; seq_214000171__2, chunk_214000172__3, count_214000173__4, i_214000174__5 = lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000171__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var nd__8 any; var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_24; nd__8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000171__7); var temp__1927000414__auto____9 any; var tmp25 *lang.Var
					A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____9 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O_O__O(fi__0, nd__8); if jrt.A2g_Truth(temp__1927000414__auto____9) { var impl__10 any = temp__1927000414__auto____9; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(impl__10) }
//line :209:1
					var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_28; seq_214000171__2, chunk_214000172__3, count_214000173__4, i_214000174__5 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_214000171__7), nil, 0, 0; continue L1 } } }
//line :207:1
			break L1 }; var seq_214000175__2 any; var tmp28 *lang.Var



		A_arbace_a2g_reach_A_Init(); tmp28 = A_arbace_a2g_reach_A_const_20; var tmp29 lang.IFn = lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()); var tmp30 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp30 = A_arbace_a2g_reach_A_const_110; var tmp31 lang.IFn = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()); var tmp32 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_111; seq_214000175__2 = tmp29.Invoke_O__O(tmp31.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(fi__0)))
//line :207:1
		var chunk_214000176__3 any; var count_214000177__4 int64 = 0; var i_214000178__5 int64 = 0; L2: for {



			if lang.Numbers_Lt_J_J__Z(i_214000178__5, count_214000177__4) { var k__6 any = lang.Indexed_Cast(chunk_214000176__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000178__5)); var temp__1927000414__auto____7_2 any; var tmp33 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____7_2 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O_O__O(fi__0, k__6); if jrt.A2g_Truth(temp__1927000414__auto____7_2) { var impl__8_2 any = temp__1927000414__auto____7_2; var tmp34 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp34 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(impl__8_2) }
//line :211:1
				seq_214000175__2, chunk_214000176__3, count_214000177__4, i_214000178__5 = seq_214000175__2, chunk_214000176__3, count_214000177__4, lang.Numbers_Unchecked_inc_J__J(i_214000178__5); continue L2 } else { var temp__1927000414__auto____6_2 any; var tmp35 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6_2 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(seq_214000175__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_214000175__7 any = temp__1927000414__auto____6_2; var tmp36 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(seq_214000175__7)) { var c__1927000678__auto____8_2 any; var tmp37 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8_2 = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()).Invoke_O__O(seq_214000175__7); var tmp38 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_26; seq_214000175__2, chunk_214000176__3, count_214000177__4, i_214000178__5 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O__O(seq_214000175__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var k__8 any; var tmp39 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_24; k__8 = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()).Invoke_O__O(seq_214000175__7); var temp__1927000414__auto____9_2 any; var tmp40 *lang.Var
					A_arbace_a2g_reach_A_Init(); tmp40 = A_arbace_a2g_reach_A_const_109; temp__1927000414__auto____9_2 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O_O__O(fi__0, k__8); if jrt.A2g_Truth(temp__1927000414__auto____9_2) { var impl__10_2 any = temp__1927000414__auto____9_2; var tmp41 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(impl__10_2) }
//line :211:1
					var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_28; seq_214000175__2, chunk_214000176__3, count_214000177__4, i_214000178__5 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_214000175__7), nil, 0, 0; continue L2 } } else { return nil } } } } }
//line :203:1
	panic("a2g: unreachable")
}









func A_arbace_a2g_reach_check_hw_call_BANG__A_New() *A_arbace_a2g_reach_check_hw_call_BANG__A { A_arbace_a2g_reach_check_hw_call_BANG__A_Init(); t := &A_arbace_a2g_reach_check_hw_call_BANG__A{}; t.Ctor(); return t }
//line :214:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Ctor() {}
//line :214:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Invoke_O_O_O_O_O__O(self, owner__0, name__1, desc__2, kind__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any; var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_115; and__1927000168__auto____5 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(owner__0); if jrt.A2g_Truth(and__1927000168__auto____5) { var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_38; tmp1 = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O_O__O(owner__0, Lit_247) } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) { var mm__5 any; var tmp4 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_40; var tmp5 any = tmp4.Ref(); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_41; mm__5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp5, name__1, tmp6.Ref(), desc__2))

		var tmp7 any; var tmp8 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_116; if lang.Util_Equiv_O_O__Z(kind__3, tmp8.Ref()) {
			var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_117; tmp7 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O_O_O__O(owner__0, name__1, desc__2) } else {
//line :219:1
				var or__1927000174__auto____6 any; var tmp10 *lang.Var

				A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_118; or__1927000174__auto____6 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O_O__O(owner__0, mm__5); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp7 = or__1927000174__auto____6 } else {

					var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_36; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 any = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_New_O(mm__5); var tmp14 *jrt.Class; A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_Init(); tmp14 = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_fn_class; var tmp15 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_51; var tmp17 lang.IFn = lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()); var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_57; tmp7 = tmp12.Invoke_O_O__O(tmp15, tmp17.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(owner__0))) } }
//line :219:1
		if jrt.A2g_Truth(tmp7) { return nil } else {





			var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_83; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_248, nil, Lit_249, nil, nil); var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_95; return tmp20.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O_O__O(owner__0, Lit_250, Lit_249), nil, name__1, desc__2)).Ref()) } } else {
//line :217:1
				return nil
			}
}



func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_New_O(p0 any) *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A { A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_Init(); t := &A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A{}; t.Ctor_O(p0); return t }
//line :223:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) Ctor_O(c__mm any) { t.F_mm = c__mm }
//line :223:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) Invoke_O_O__O(self, p1__214000180_SHARP___1 any) any { var and__1927000168__auto____2 any; var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_119; and__1927000168__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(p1__214000180_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(p1__214000180_SHARP___1, Lit_247); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_118; return lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O_O__O(p1__214000180_SHARP___1, t.F_mm) } } else { return and__1927000168__auto____2 } }



func A_arbace_a2g_reach_class_of_desc_A_New() *A_arbace_a2g_reach_class_of_desc_A { A_arbace_a2g_reach_class_of_desc_A_Init(); t := &A_arbace_a2g_reach_class_of_desc_A{}; t.Ctor(); return t }
//line :227:1
func (t *A_arbace_a2g_reach_class_of_desc_A) Ctor() {}
//line :227:1
func (t *A_arbace_a2g_reach_class_of_desc_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_24; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_96; return tmp2.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(d__0)) }

func A_arbace_a2g_reach_vh_const_QMARK__A_New() *A_arbace_a2g_reach_vh_const_QMARK__A { A_arbace_a2g_reach_vh_const_QMARK__A_Init(); t := &A_arbace_a2g_reach_vh_const_QMARK__A{}; t.Ctor(); return t }
//line :229:1
func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Ctor() {}
//line :229:1
func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_18; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_120; var tmp4 *lang.Keyword = tmp3; var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_121; var tmp6 *lang.Keyword = tmp5; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_68; var tmp8 any = jrt.NN(tmp4).Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(jrt.NN(tmp7).Get__O())); var tmp9 any; var or__1927000174__auto____2 any; var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_122; or__1927000174__auto____2 = jrt.NN(tmp10).Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp9 = or__1927000174__auto____2 } else { var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_123; tmp9 = jrt.NN(tmp11).Invoke_O__O(f__0) }; var tmp12 any = tmp9; var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_40; return tmp2.Invoke_O_O__O(tmp8, lang.Tuple_Create_O_O__IPersistentVector(tmp12, jrt.NN(tmp13).Invoke_O__O(f__0)))
}
func A_arbace_a2g_reach_vh_call_QMARK__A_New() *A_arbace_a2g_reach_vh_call_QMARK__A { A_arbace_a2g_reach_vh_call_QMARK__A_Init(); t := &A_arbace_a2g_reach_vh_call_QMARK__A{}; t.Ctor(); return t }
//line :234:1
func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Ctor() {}
//line :234:1
func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var map__214000186__2 any = node__0; var map__214000186__3 any; if



	lang.ISeq_InstanceOf(map__214000186__2) { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__214000186__2)) { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_124; map__214000186__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__214000186__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__214000186__2)) { var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_24; map__214000186__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__214000186__2) } else { lang.PersistentArrayMap_Init(); map__214000186__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000186__3 = map__214000186__2 }; var owner__4 any; var tmp5 /*line :234:1*/*lang.Keyword;



	A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_123; owner__4 = lang.RT_Get_O_O__O(map__214000186__3, tmp5.Ref()); var kind__5 any; var tmp6 /*line :234:1*/*lang.Keyword;



	A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_125; kind__5 = lang.RT_Get_O_O__O(map__214000186__3, tmp6.Ref()); var name__6 any; var tmp7 /*line :234:1*/*lang.Keyword;



	A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_40; name__6 = lang.RT_Get_O_O__O(map__214000186__3, tmp7.Ref()); var or__1927000174__auto____7 any; var and__1927000168__auto____7 bool; var tmp8 /*line :234:1*/*lang.Keyword;




	A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_116; and__1927000168__auto____7 = lang.Util_Equiv_O_O__Z(tmp8.Ref(), kind__5); if and__1927000168__auto____7 { var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(Lit_351, owner__4); if and__1927000168__auto____8 {
		var tmp9 any; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_126; or__1927000174__auto____7 = lang.IFn_Cast(tmp9).Invoke_O__O(name__6) } else {
//line :239:1
			or__1927000174__auto____7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { or__1927000174__auto____7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 bool; var and__1927000168__auto____8_2 bool; var tmp10 *lang.Keyword

				A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_116; and__1927000168__auto____8_2 = lang.Util_Equiv_O_O__Z(tmp10.Ref(), kind__5); if and__1927000168__auto____8_2 { var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(Lit_352, owner__4); if and__1927000168__auto____9 { or__1927000174__auto____8 = lang.Util_Equiv_O_O__Z(Lit_353, name__6) } else { or__1927000174__auto____8 = and__1927000168__auto____9 } } else { or__1927000174__auto____8 = and__1927000168__auto____8_2 }
//line :239:1
				if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var and__1927000168__auto____9_2 any; var tmp11 *lang.Var


					A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_38; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_116; and__1927000168__auto____9_2 = tmp12.Invoke_O_O__O(tmp13.Ref(), kind__5); if jrt.A2g_Truth(and__1927000168__auto____9_2) { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z(Lit_351, owner__4); if and__1927000168__auto____10 { var tg__11 any; var tmp14 *lang.Var
						A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_127; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_130; tg__11 = tmp15.Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(node__0))
//line :242:1
						var and__1927000168__auto____12 bool; var tmp17 *lang.Keyword

						A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_128; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_19; and__1927000168__auto____12 = lang.Util_Equiv_O_O__Z(tmp18, jrt.NN(tmp19).Invoke_O__O(tg__11)); if and__1927000168__auto____12 { var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_129; var tmp21 lang.IFn = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()); var tmp22 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_131; return tmp21.Invoke_O__O(jrt.NN(tmp22).Invoke_O__O(tg__11)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() } } else {
//line :242:1
							return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9_2 } } } }



func A_arbace_a2g_reach_scan_node_BANG__A_New() *A_arbace_a2g_reach_scan_node_BANG__A { A_arbace_a2g_reach_scan_node_BANG__A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__A{}; t.Ctor(); return t }
//line :246:1
func (t *A_arbace_a2g_reach_scan_node_BANG__A) Ctor() {}
//line :246:1
func (t *A_arbace_a2g_reach_scan_node_BANG__A) Invoke_O_O__O(self, node__0 any) any { { var node__2 any; var tmp1 *lang.Var
											A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_127; node__2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(node__0)
//line :246:1
	var G__214000189__3_ any; var tmp2 *lang.Keyword

	A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_19; G__214000189__3_ = jrt.NN(tmp2).Invoke_O__O(node__2); L1: switch { default: switch lang.Util_Hash_O__I(G__214000189__3_) >> 19 & 255 { case 0: var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_133; if any(G__214000189__3_) == any(tmp3.Ref()) {












































		var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_134; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_139; tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(node__2))
//line :248:1
		break L1 }; case 3: var tmp7 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_135; if any(G__214000189__3_) == any(tmp7.Ref()) {














































			var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_134; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_144; tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(node__2))
//line :248:1
			break L1 }; case 32: var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_136; if any(G__214000189__3_) == any(tmp11.Ref()) { var f__4 any; var tmp12 *lang.Keyword











































				A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_131; f__4 = jrt.NN(tmp12).Invoke_O__O(node__2); var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_79; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; var or__1927000174__auto____5 any; var tmp16 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_122; or__1927000174__auto____5 = jrt.NN(tmp16).Invoke_O__O(f__4); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp15 = or__1927000174__auto____5 } else { var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_123; tmp15 = jrt.NN(tmp17).Invoke_O__O(f__4) }; tmp14.Invoke_O__O(tmp15); var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_134; var tmp19 lang.IFn = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()); var tmp20 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_41; tmp19.Invoke_O__O(jrt.NN(tmp20).Invoke_O__O(f__4))
//line :248:1
				break L1 }; case 42: var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_137; if any(G__214000189__3_) == any(tmp21.Ref()) {
































					var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_79; var tmp23 lang.IFn = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()); var tmp24 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_139; tmp23.Invoke_O__O(jrt.NN(tmp24).Invoke_O__O(node__2))
					var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_99; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_139; var tmp28 any = jrt.NN(tmp27).Invoke_O__O(node__2); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_41; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_149; tmp26.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp28, Lit_241, jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(node__2))))
//line :248:1
					break L1 }; case 47: var tmp32 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_145; if any(G__214000189__3_) == any(tmp32.Ref()) { var seq_214000190__4 any; var tmp33 *lang.Var
























































						A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_20; var tmp34 lang.IFn = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()); var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_152; seq_214000190__4 = tmp34.Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(node__2))
//line :248:1
						var chunk_214000191__5 any; var count_214000192__6 int64 = 0; var i_214000193__7 int64 = 0; L2: for {
























































							if lang.Numbers_Lt_J_J__Z(i_214000193__7, count_214000192__6) { var p__8 any = lang.Indexed_Cast(chunk_214000191__5).Nth_I__O(lang.RT_IntCast_J__I(i_214000193__7)); var tmp36 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_146; if jrt.A2g_Truth(jrt.NN(tmp36).Invoke_O__O(p__8)) { var ty__9 any; var tmp37 *lang.Var
								A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_147; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_144; var tmp40 *lang.Keyword = tmp39; var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_146; ty__9 = tmp38.Invoke_O__O(jrt.NN(tmp40).Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(p__8)))
//line :305:1
								var tmp42 any; var and__1927000168__auto____10 any; var tmp43 *lang.Var

								A_arbace_a2g_reach_A_Init(); tmp43 = A_arbace_a2g_reach_A_const_148; and__1927000168__auto____10 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(ty__9); if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var tmp44 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp44 = A_arbace_a2g_reach_A_const_38; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp46 = A_arbace_a2g_reach_A_const_153; and__1927000168__auto____11 = tmp45.Invoke_O_O__O(ty__9, tmp46.Ref()); if jrt.A2g_Truth(and__1927000168__auto____11) { var tmp47 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp47 = A_arbace_a2g_reach_A_const_38; tmp42 = lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O_O__O(ty__9, Lit_301) } else { tmp42 = and__1927000168__auto____11 } } else { tmp42 = and__1927000168__auto____10 }
//line :305:1
								if jrt.A2g_Truth(tmp42) {


									var tmp48 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp48 = A_arbace_a2g_reach_A_const_141; var tmp49 lang.IFn = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()); var tmp50 any; var tmp51 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp51 = A_arbace_a2g_reach_A_const_154; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(ty__9)) { tmp50 = Lit_247 } else { var tmp52 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp52 = A_arbace_a2g_reach_A_const_155; tmp50 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(ty__9) }; tmp49.Invoke_O_O_O__O(tmp50, Lit_298, Lit_299)
//line :305:1
									seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = seq_214000190__4, chunk_214000191__5, count_214000192__6, lang.Numbers_Unchecked_inc_J__J(i_214000193__7); continue L2 } else { seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = seq_214000190__4, chunk_214000191__5, count_214000192__6, lang.Numbers_Unchecked_inc_J__J(i_214000193__7); continue L2 } } else { seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = seq_214000190__4, chunk_214000191__5, count_214000192__6, lang.Numbers_Unchecked_inc_J__J(i_214000193__7); continue L2 } } else { var temp__1927000414__auto____8 any; var tmp53 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp53 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____8 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_214000190__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_214000190__9 any = temp__1927000414__auto____8; var tmp54 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp54 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(seq_214000190__9)) { var c__1927000678__auto____10 any; var tmp55 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp55 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____10 = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(seq_214000190__9); var tmp56 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp56 = A_arbace_a2g_reach_A_const_26; seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(seq_214000190__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var p__10 any; var tmp57 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp57 = A_arbace_a2g_reach_A_const_24; p__10 = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(seq_214000190__9); var tmp58 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp58 = A_arbace_a2g_reach_A_const_146; if jrt.A2g_Truth(jrt.NN(tmp58).Invoke_O__O(p__10)) { var ty__11 any; var tmp59 *lang.Var
										A_arbace_a2g_reach_A_Init(); tmp59 = A_arbace_a2g_reach_A_const_147; var tmp60 lang.IFn = lang.IFn_Cast(jrt.NN(tmp59).GetRawRoot__O()); var tmp61 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp61 = A_arbace_a2g_reach_A_const_144; var tmp62 *lang.Keyword = tmp61; var tmp63 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp63 = A_arbace_a2g_reach_A_const_146; ty__11 = tmp60.Invoke_O__O(jrt.NN(tmp62).Invoke_O__O(jrt.NN(tmp63).Invoke_O__O(p__10)))
//line :305:1
										var tmp64 any; var and__1927000168__auto____12 any; var tmp65 *lang.Var

										A_arbace_a2g_reach_A_Init(); tmp65 = A_arbace_a2g_reach_A_const_148; and__1927000168__auto____12 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(ty__11); if jrt.A2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any; var tmp66 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp66 = A_arbace_a2g_reach_A_const_38; var tmp67 lang.IFn = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()); var tmp68 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp68 = A_arbace_a2g_reach_A_const_153; and__1927000168__auto____13 = tmp67.Invoke_O_O__O(ty__11, tmp68.Ref()); if jrt.A2g_Truth(and__1927000168__auto____13) { var tmp69 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp69 = A_arbace_a2g_reach_A_const_38; tmp64 = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O_O__O(ty__11, Lit_301) } else { tmp64 = and__1927000168__auto____13 } } else { tmp64 = and__1927000168__auto____12 }
//line :305:1
										if jrt.A2g_Truth(tmp64) {


											var tmp70 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp70 = A_arbace_a2g_reach_A_const_141; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 any; var tmp73 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp73 = A_arbace_a2g_reach_A_const_154; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(ty__11)) { tmp72 = Lit_247 } else { var tmp74 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp74 = A_arbace_a2g_reach_A_const_155; tmp72 = lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()).Invoke_O__O(ty__11) }; tmp71.Invoke_O_O_O__O(tmp72, Lit_298, Lit_299)
//line :305:1
											var tmp75 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp75 = A_arbace_a2g_reach_A_const_28; seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(seq_214000190__9), nil, 0, 0; continue L2 } else { var tmp76 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp76 = A_arbace_a2g_reach_A_const_28; seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(seq_214000190__9), nil, 0, 0; continue L2 } } else { var tmp77 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp77 = A_arbace_a2g_reach_A_const_28; seq_214000190__4, chunk_214000191__5, count_214000192__6, i_214000193__7 = lang.IFn_Cast(jrt.NN(tmp77).GetRawRoot__O()).Invoke_O__O(seq_214000190__9), nil, 0, 0; continue L2 } } } }
//line :248:1
							break L2 }; break L1 }; case 53: var tmp78 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp78 = A_arbace_a2g_reach_A_const_150; if any(G__214000189__3_) == any(tmp78.Ref()) {





























































								var tmp79 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp79 = A_arbace_a2g_reach_A_const_151; if jrt.A2g_Truth(jrt.NN(tmp79).Invoke_O__O(node__2)) { } else {
									var tmp80 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp80 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()).Invoke_O__O(Lit_302)
									var tmp81 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp81 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp81).GetRawRoot__O()).Invoke_O_O_O__O(Lit_302, Lit_303, Lit_304)
									var tmp82 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp82 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O_O_O__O(Lit_302, Lit_51, Lit_305) }
//line :248:1
								break L1 }; case 63: var tmp83 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp83 = A_arbace_a2g_reach_A_const_156; if any(G__214000189__3_) == any(tmp83.Ref()) {













































									var tmp84 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp84 = A_arbace_a2g_reach_A_const_134; var tmp85 lang.IFn = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()); var tmp86 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp86 = A_arbace_a2g_reach_A_const_139; tmp85.Invoke_O__O(jrt.NN(tmp86).Invoke_O__O(node__2))
//line :248:1
									break L1 }; case 74: var tmp87 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp87 = A_arbace_a2g_reach_A_const_157; if any(G__214000189__3_) == any(tmp87.Ref()) {












































										var tmp88 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp88 = A_arbace_a2g_reach_A_const_134; var tmp89 lang.IFn = lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()); var tmp90 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp90 = A_arbace_a2g_reach_A_const_139; tmp89.Invoke_O__O(jrt.NN(tmp90).Invoke_O__O(node__2))
//line :248:1
										break L1 }; case 75: var tmp91 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp91 = A_arbace_a2g_reach_A_const_158; if any(G__214000189__3_) == any(tmp91.Ref()) {














































											var tmp92 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp92 = A_arbace_a2g_reach_A_const_134; var tmp93 lang.IFn = lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()); var tmp94 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp94 = A_arbace_a2g_reach_A_const_144; tmp93.Invoke_O__O(jrt.NN(tmp94).Invoke_O__O(node__2))
//line :248:1
											break L1 }; case 126: var tmp95 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp95 = A_arbace_a2g_reach_A_const_159; if any(G__214000189__3_) == any(tmp95.Ref()) {


















































												var tmp96 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp96 = A_arbace_a2g_reach_A_const_79; var tmp97 lang.IFn = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()); var tmp98 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp98 = A_arbace_a2g_reach_A_const_165; if jrt.A2g_Truth(tmp97.Invoke_O__O(jrt.NN(tmp98).Invoke_O__O(node__2))) { var tmp99 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp99 = A_arbace_a2g_reach_A_const_164; var tmp100 lang.IFn = lang.IFn_Cast(jrt.NN(tmp99).GetRawRoot__O()); var tmp101 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp101 = A_arbace_a2g_reach_A_const_165; tmp100.Invoke_O__O(jrt.NN(tmp101).Invoke_O__O(node__2)) }; var tmp102 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp102 = A_arbace_a2g_reach_A_const_79; var tmp103 lang.IFn = lang.IFn_Cast(jrt.NN(tmp102).GetRawRoot__O()); var tmp104 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp104 = A_arbace_a2g_reach_A_const_123; tmp103.Invoke_O__O(jrt.NN(tmp104).Invoke_O__O(node__2))
//line :248:1
												var G__214000194__4_ any; var tmp105 *lang.Keyword



















































												A_arbace_a2g_reach_A_Init(); tmp105 = A_arbace_a2g_reach_A_const_125; G__214000194__4_ = jrt.NN(tmp105).Invoke_O__O(node__2); L3: switch { default: switch lang.Util_Hash_O__I(G__214000194__4_) >> 5 & 3 { case 0: var tmp106 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp106 = A_arbace_a2g_reach_A_const_160; if any(G__214000194__4_) == any(tmp106.Ref()) {



													var tmp107 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp107 = A_arbace_a2g_reach_A_const_141; var tmp108 lang.IFn = lang.IFn_Cast(jrt.NN(tmp107).GetRawRoot__O()); var tmp109 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp109 = A_arbace_a2g_reach_A_const_123; var tmp110 any = jrt.NN(tmp109).Invoke_O__O(node__2); var tmp111 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp111 = A_arbace_a2g_reach_A_const_40; var tmp112 any = jrt.NN(tmp111).Invoke_O__O(node__2); var tmp113 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp113 = A_arbace_a2g_reach_A_const_41; tmp108.Invoke_O_O_O__O(tmp110, tmp112, jrt.NN(tmp113).Invoke_O__O(node__2))
//line :300:1
													break L3 }; case 1: var tmp114 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp114 = A_arbace_a2g_reach_A_const_161; if any(G__214000194__4_) == any(tmp114.Ref()) {

														var tmp115 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp115 = A_arbace_a2g_reach_A_const_101; var tmp116 lang.IFn = lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()); var tmp117 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp117 = A_arbace_a2g_reach_A_const_123; tmp116.Invoke_O__O(jrt.NN(tmp117).Invoke_O__O(node__2)); var tmp118 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp118 = A_arbace_a2g_reach_A_const_99; var tmp119 lang.IFn = lang.IFn_Cast(jrt.NN(tmp118).GetRawRoot__O()); var tmp120 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp120 = A_arbace_a2g_reach_A_const_123; var tmp121 any = jrt.NN(tmp120).Invoke_O__O(node__2); var tmp122 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp122 = A_arbace_a2g_reach_A_const_41; tmp119.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp121, Lit_241, jrt.NN(tmp122).Invoke_O__O(node__2)))
														var tmp123 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp123 = A_arbace_a2g_reach_A_const_162; var tmp124 lang.IFn = lang.IFn_Cast(jrt.NN(tmp123).GetRawRoot__O()); var tmp125 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp125 = A_arbace_a2g_reach_A_const_123; tmp124.Invoke_O__O(jrt.NN(tmp125).Invoke_O__O(node__2))
//line :300:1
														break L3 }; case 2: var tmp126 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp126 = A_arbace_a2g_reach_A_const_163; if any(G__214000194__4_) == any(tmp126.Ref()) {



															var tmp127 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp127 = A_arbace_a2g_reach_A_const_141; var tmp128 lang.IFn = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()); var tmp129 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp129 = A_arbace_a2g_reach_A_const_123; var tmp130 any = jrt.NN(tmp129).Invoke_O__O(node__2); var tmp131 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp131 = A_arbace_a2g_reach_A_const_40; var tmp132 any = jrt.NN(tmp131).Invoke_O__O(node__2); var tmp133 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp133 = A_arbace_a2g_reach_A_const_41; tmp128.Invoke_O_O_O__O(tmp130, tmp132, jrt.NN(tmp133).Invoke_O__O(node__2))
//line :300:1
															break L3 }; case 3: var tmp134 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp134 = A_arbace_a2g_reach_A_const_116; if any(G__214000194__4_) == any(tmp134.Ref()) {
																var tmp135 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp135 = A_arbace_a2g_reach_A_const_101; var tmp136 lang.IFn = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()); var tmp137 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp137 = A_arbace_a2g_reach_A_const_123; tmp136.Invoke_O__O(jrt.NN(tmp137).Invoke_O__O(node__2)); var tmp138 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp138 = A_arbace_a2g_reach_A_const_99; var tmp139 lang.IFn = lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()); var tmp140 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp140 = A_arbace_a2g_reach_A_const_123; var tmp141 any = jrt.NN(tmp140).Invoke_O__O(node__2); var tmp142 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp142 = A_arbace_a2g_reach_A_const_40; var tmp143 any = jrt.NN(tmp142).Invoke_O__O(node__2); var tmp144 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp144 = A_arbace_a2g_reach_A_const_41; tmp139.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp141, tmp143, jrt.NN(tmp144).Invoke_O__O(node__2)))
//line :300:1
																break L3 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_293, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000194__4_)))))}
//line :248:1
												break L1 }; case 155: var tmp145 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp145 = A_arbace_a2g_reach_A_const_161; if any(G__214000189__3_) == any(tmp145.Ref()) { var c__4 any; var tmp146 *lang.Keyword






















													A_arbace_a2g_reach_A_Init(); tmp146 = A_arbace_a2g_reach_A_const_139; c__4 = jrt.NN(tmp146).Invoke_O__O(node__2)
//line :248:1
													var ok__5 any; var tmp147 *lang.Var























													A_arbace_a2g_reach_A_Init(); tmp147 = A_arbace_a2g_reach_A_const_79; ok__5 = lang.IFn_Cast(jrt.NN(tmp147).GetRawRoot__O()).Invoke_O__O(c__4)
													if jrt.A2g_Truth(ok__5) {
														var tmp148 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp148 = A_arbace_a2g_reach_A_const_101; lang.IFn_Cast(jrt.NN(tmp148).GetRawRoot__O()).Invoke_O__O(c__4)
														var tmp149 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp149 = A_arbace_a2g_reach_A_const_99; var tmp150 lang.IFn = lang.IFn_Cast(jrt.NN(tmp149).GetRawRoot__O()); var tmp151 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp151 = A_arbace_a2g_reach_A_const_41; var tmp152 *lang.Keyword = tmp151; var tmp153 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp153 = A_arbace_a2g_reach_A_const_149; tmp150.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(c__4, Lit_241, jrt.NN(tmp152).Invoke_O__O(jrt.NN(tmp153).Invoke_O__O(node__2))))
														var tmp154 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp154 = A_arbace_a2g_reach_A_const_162; lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()).Invoke_O__O(c__4)
														var tmp155 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp155 = A_arbace_a2g_reach_A_const_115; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()).Invoke_O__O(c__4)) { var g__6 any; var tmp156 *lang.Var
															A_arbace_a2g_reach_A_Init(); tmp156 = A_arbace_a2g_reach_A_const_65; g__6 = lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()).Invoke_O__O(c__4)
															var tmp157 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp157 = A_arbace_a2g_reach_A_const_18; var tmp158 lang.IFn = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()); var tmp159 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp159 = A_arbace_a2g_reach_A_const_70; var tmp160 *lang.Keyword = tmp159; var tmp161 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp161 = A_arbace_a2g_reach_A_const_67; var tmp162 *lang.Keyword = tmp161; var tmp163 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp163 = A_arbace_a2g_reach_A_const_68; var tmp164 any = jrt.NN(tmp160).Invoke_O__O(jrt.NN(tmp162).Invoke_O__O(jrt.NN(tmp163).Get__O())); var tmp165 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp165 = A_arbace_a2g_reach_A_const_167; var tmp166 lang.IFn = lang.IFn_Cast(jrt.NN(tmp165).GetRawRoot__O()); var tmp167 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp167 = A_arbace_a2g_reach_A_const_41; var tmp168 *lang.Keyword = tmp167; var tmp169 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp169 = A_arbace_a2g_reach_A_const_149; if jrt.A2g_Truth(tmp158.Invoke_O_O__O(tmp164, tmp166.Invoke_O_O__O(g__6, jrt.NN(tmp168).Invoke_O__O(jrt.NN(tmp169).Invoke_O__O(node__2))))) { } else {
																var tmp170 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp170 = A_arbace_a2g_reach_A_const_83; var tmp171 lang.IFn = lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()); var tmp172 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_306, nil, nil); var tmp173 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp173 = A_arbace_a2g_reach_A_const_41; var tmp174 *lang.Keyword = tmp173; var tmp175 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp175 = A_arbace_a2g_reach_A_const_149; tmp171.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp172, jrt.RefArrayOf(jrt.Object_class, nil, c__4, jrt.NN(tmp174).Invoke_O__O(jrt.NN(tmp175).Invoke_O__O(node__2)))).Ref()) } } }
//line :248:1
													break L1 }; case 156: var tmp176 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp176 = A_arbace_a2g_reach_A_const_166; if any(G__214000189__3_) == any(tmp176.Ref()) { var seq_214000195__4 any; var tmp177 *lang.Var















































														A_arbace_a2g_reach_A_Init(); tmp177 = A_arbace_a2g_reach_A_const_20; var tmp178 lang.IFn = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()); var tmp179 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp179 = A_arbace_a2g_reach_A_const_169; seq_214000195__4 = tmp178.Invoke_O__O(jrt.NN(tmp179).Invoke_O__O(node__2))
//line :248:1
														var chunk_214000196__5 any; var count_214000197__6 int64 = 0; var i_214000198__7 int64 = 0; L4: for {















































															if lang.Numbers_Lt_J_J__Z(i_214000198__7, count_214000197__6) { var c__8 any = lang.Indexed_Cast(chunk_214000196__5).Nth_I__O(lang.RT_IntCast_J__I(i_214000198__7)); var seq_214000203__9 any; var tmp180 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp180 = A_arbace_a2g_reach_A_const_20; var tmp181 lang.IFn = lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()); var tmp182 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp182 = A_arbace_a2g_reach_A_const_170; seq_214000203__9 = tmp181.Invoke_O__O(jrt.NN(tmp182).Invoke_O__O(c__8)); var chunk_214000204__10 any; var count_214000205__11 int64 = 0; var i_214000206__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z(i_214000206__12, count_214000205__11) { var cls__13 any = lang.Indexed_Cast(chunk_214000204__10).Nth_I__O(lang.RT_IntCast_J__I(i_214000206__12)); var tmp183 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp183 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp183).GetRawRoot__O()).Invoke_O__O(cls__13); seq_214000203__9, chunk_214000204__10, count_214000205__11, i_214000206__12 = seq_214000203__9, chunk_214000204__10, count_214000205__11, lang.Numbers_Unchecked_inc_J__J(i_214000206__12); continue L5 } else { var temp__1927000414__auto____13 any; var tmp184 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp184 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____13 = lang.IFn_Cast(jrt.NN(tmp184).GetRawRoot__O()).Invoke_O__O(seq_214000203__9); if jrt.A2g_Truth(temp__1927000414__auto____13) { var seq_214000203__14 any = temp__1927000414__auto____13; var tmp185 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp185 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp185).GetRawRoot__O()).Invoke_O__O(seq_214000203__14)) { var c__1927000678__auto____15 any; var tmp186 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp186 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____15 = lang.IFn_Cast(jrt.NN(tmp186).GetRawRoot__O()).Invoke_O__O(seq_214000203__14); var tmp187 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp187 = A_arbace_a2g_reach_A_const_26; seq_214000203__9, chunk_214000204__10, count_214000205__11, i_214000206__12 = lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()).Invoke_O__O(seq_214000203__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var cls__15 any; var tmp188 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp188 = A_arbace_a2g_reach_A_const_24; cls__15 = lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()).Invoke_O__O(seq_214000203__14); var tmp189 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp189 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp189).GetRawRoot__O()).Invoke_O__O(cls__15); var tmp190 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp190 = A_arbace_a2g_reach_A_const_28; seq_214000203__9, chunk_214000204__10, count_214000205__11, i_214000206__12 = lang.IFn_Cast(jrt.NN(tmp190).GetRawRoot__O()).Invoke_O__O(seq_214000203__14), nil, 0, 0; continue L5 } } }; break L5 }; seq_214000195__4, chunk_214000196__5, count_214000197__6, i_214000198__7 = seq_214000195__4, chunk_214000196__5, count_214000197__6, lang.Numbers_Unchecked_inc_J__J(i_214000198__7); continue L4 } else { var temp__1927000414__auto____8_2 any; var tmp191 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp191 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____8_2 = lang.IFn_Cast(jrt.NN(tmp191).GetRawRoot__O()).Invoke_O__O(seq_214000195__4); if jrt.A2g_Truth(temp__1927000414__auto____8_2) { var seq_214000195__9 any = temp__1927000414__auto____8_2; var tmp192 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp192 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp192).GetRawRoot__O()).Invoke_O__O(seq_214000195__9)) { var c__1927000678__auto____10_2 any; var tmp193 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp193 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____10_2 = lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()).Invoke_O__O(seq_214000195__9); var tmp194 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp194 = A_arbace_a2g_reach_A_const_26; seq_214000195__4, chunk_214000196__5, count_214000197__6, i_214000198__7 = lang.IFn_Cast(jrt.NN(tmp194).GetRawRoot__O()).Invoke_O__O(seq_214000195__9), c__1927000678__auto____10_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var c__10 any; var tmp195 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp195 = A_arbace_a2g_reach_A_const_24; c__10 = lang.IFn_Cast(jrt.NN(tmp195).GetRawRoot__O()).Invoke_O__O(seq_214000195__9); var seq_214000199__11 any; var tmp196 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp196 = A_arbace_a2g_reach_A_const_20; var tmp197 lang.IFn = lang.IFn_Cast(jrt.NN(tmp196).GetRawRoot__O()); var tmp198 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp198 = A_arbace_a2g_reach_A_const_170; seq_214000199__11 = tmp197.Invoke_O__O(jrt.NN(tmp198).Invoke_O__O(c__10)); var chunk_214000200__12 any; var count_214000201__13 int64 = 0; var i_214000202__14 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z(i_214000202__14, count_214000201__13) { var cls__15_2 any = lang.Indexed_Cast(chunk_214000200__12).Nth_I__O(lang.RT_IntCast_J__I(i_214000202__14)); var tmp199 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp199 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp199).GetRawRoot__O()).Invoke_O__O(cls__15_2); seq_214000199__11, chunk_214000200__12, count_214000201__13, i_214000202__14 = seq_214000199__11, chunk_214000200__12, count_214000201__13, lang.Numbers_Unchecked_inc_J__J(i_214000202__14); continue L6 } else { var temp__1927000414__auto____15 any; var tmp200 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp200 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____15 = lang.IFn_Cast(jrt.NN(tmp200).GetRawRoot__O()).Invoke_O__O(seq_214000199__11); if jrt.A2g_Truth(temp__1927000414__auto____15) { var seq_214000199__16 any = temp__1927000414__auto____15; var tmp201 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp201 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp201).GetRawRoot__O()).Invoke_O__O(seq_214000199__16)) { var c__1927000678__auto____17 any; var tmp202 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp202 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____17 = lang.IFn_Cast(jrt.NN(tmp202).GetRawRoot__O()).Invoke_O__O(seq_214000199__16); var tmp203 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp203 = A_arbace_a2g_reach_A_const_26; seq_214000199__11, chunk_214000200__12, count_214000201__13, i_214000202__14 = lang.IFn_Cast(jrt.NN(tmp203).GetRawRoot__O()).Invoke_O__O(seq_214000199__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var cls__17 any; var tmp204 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp204 = A_arbace_a2g_reach_A_const_24; cls__17 = lang.IFn_Cast(jrt.NN(tmp204).GetRawRoot__O()).Invoke_O__O(seq_214000199__16); var tmp205 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp205 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp205).GetRawRoot__O()).Invoke_O__O(cls__17); var tmp206 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp206 = A_arbace_a2g_reach_A_const_28; seq_214000199__11, chunk_214000200__12, count_214000201__13, i_214000202__14 = lang.IFn_Cast(jrt.NN(tmp206).GetRawRoot__O()).Invoke_O__O(seq_214000199__16), nil, 0, 0; continue L6 } } }; break L6 }; var tmp207 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp207 = A_arbace_a2g_reach_A_const_28; seq_214000195__4, chunk_214000196__5, count_214000197__6, i_214000198__7 = lang.IFn_Cast(jrt.NN(tmp207).GetRawRoot__O()).Invoke_O__O(seq_214000195__9), nil, 0, 0; continue L4 } } }
//line :248:1
															break L4 }; break L1 }; case 161: var tmp208 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp208 = A_arbace_a2g_reach_A_const_168; if any(G__214000189__3_) == any(tmp208.Ref()) {
















































																var tmp209 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp209 = A_arbace_a2g_reach_A_const_79; var tmp210 lang.IFn = lang.IFn_Cast(jrt.NN(tmp209).GetRawRoot__O()); var tmp211 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp211 = A_arbace_a2g_reach_A_const_165; if jrt.A2g_Truth(tmp210.Invoke_O__O(jrt.NN(tmp211).Invoke_O__O(node__2))) { var tmp212 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp212 = A_arbace_a2g_reach_A_const_164; var tmp213 lang.IFn = lang.IFn_Cast(jrt.NN(tmp212).GetRawRoot__O()); var tmp214 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp214 = A_arbace_a2g_reach_A_const_165; tmp213.Invoke_O__O(jrt.NN(tmp214).Invoke_O__O(node__2)) }
//line :248:1
																var seq_214000207__4 any; var tmp215 *lang.Var
















































																A_arbace_a2g_reach_A_Init(); tmp215 = A_arbace_a2g_reach_A_const_20; var tmp216 lang.IFn = lang.IFn_Cast(jrt.NN(tmp215).GetRawRoot__O()); var tmp217 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp217 = A_arbace_a2g_reach_A_const_172; seq_214000207__4 = tmp216.Invoke_O__O(jrt.NN(tmp217).Invoke_O__O(node__2))
//line :248:1
																var chunk_214000208__5 any; var count_214000209__6 int64 = 0; var i_214000210__7 int64 = 0; L7: for {
















































																	if lang.Numbers_Lt_J_J__Z(i_214000210__7, count_214000209__6) { var mk__8 any = lang.Indexed_Cast(chunk_214000208__5).Nth_I__O(lang.RT_IntCast_J__I(i_214000210__7)); var tmp218 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp218 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp218).GetRawRoot__O()).Invoke_O__O(mk__8); seq_214000207__4, chunk_214000208__5, count_214000209__6, i_214000210__7 = seq_214000207__4, chunk_214000208__5, count_214000209__6, lang.Numbers_Unchecked_inc_J__J(i_214000210__7); continue L7 } else { var temp__1927000414__auto____8_3 any; var tmp219 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp219 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____8_3 = lang.IFn_Cast(jrt.NN(tmp219).GetRawRoot__O()).Invoke_O__O(seq_214000207__4); if jrt.A2g_Truth(temp__1927000414__auto____8_3) { var seq_214000207__9 any = temp__1927000414__auto____8_3; var tmp220 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp220 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp220).GetRawRoot__O()).Invoke_O__O(seq_214000207__9)) { var c__1927000678__auto____10_3 any; var tmp221 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp221 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____10_3 = lang.IFn_Cast(jrt.NN(tmp221).GetRawRoot__O()).Invoke_O__O(seq_214000207__9); var tmp222 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp222 = A_arbace_a2g_reach_A_const_26; seq_214000207__4, chunk_214000208__5, count_214000209__6, i_214000210__7 = lang.IFn_Cast(jrt.NN(tmp222).GetRawRoot__O()).Invoke_O__O(seq_214000207__9), c__1927000678__auto____10_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10_3))), int64(lang.RT_IntCast_J__I(0)); continue L7 } else { var mk__10 any; var tmp223 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp223 = A_arbace_a2g_reach_A_const_24; mk__10 = lang.IFn_Cast(jrt.NN(tmp223).GetRawRoot__O()).Invoke_O__O(seq_214000207__9); var tmp224 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp224 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp224).GetRawRoot__O()).Invoke_O__O(mk__10); var tmp225 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp225 = A_arbace_a2g_reach_A_const_28; seq_214000207__4, chunk_214000208__5, count_214000209__6, i_214000210__7 = lang.IFn_Cast(jrt.NN(tmp225).GetRawRoot__O()).Invoke_O__O(seq_214000207__9), nil, 0, 0; continue L7 } } }
//line :248:1
																	break L7 }; break L1 }; case 170: var tmp226 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp226 = A_arbace_a2g_reach_A_const_171; if any(G__214000189__3_) == any(tmp226.Ref()) { var f__4_2 any; var tmp227 *lang.Keyword











































																		A_arbace_a2g_reach_A_Init(); tmp227 = A_arbace_a2g_reach_A_const_131; f__4_2 = jrt.NN(tmp227).Invoke_O__O(node__2); var tmp228 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp228 = A_arbace_a2g_reach_A_const_79; var tmp229 lang.IFn = lang.IFn_Cast(jrt.NN(tmp228).GetRawRoot__O()); var tmp230 any; var or__1927000174__auto____5_2 any; var tmp231 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp231 = A_arbace_a2g_reach_A_const_122; or__1927000174__auto____5_2 = jrt.NN(tmp231).Invoke_O__O(f__4_2); if jrt.A2g_Truth(or__1927000174__auto____5_2) { tmp230 = or__1927000174__auto____5_2 } else { var tmp232 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp232 = A_arbace_a2g_reach_A_const_123; tmp230 = jrt.NN(tmp232).Invoke_O__O(f__4_2) }; tmp229.Invoke_O__O(tmp230); var tmp233 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp233 = A_arbace_a2g_reach_A_const_134; var tmp234 lang.IFn = lang.IFn_Cast(jrt.NN(tmp233).GetRawRoot__O()); var tmp235 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp235 = A_arbace_a2g_reach_A_const_41; tmp234.Invoke_O__O(jrt.NN(tmp235).Invoke_O__O(f__4_2))
//line :248:1
																		break L1 }; case 185: var tmp236 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp236 = A_arbace_a2g_reach_A_const_173; if any(G__214000189__3_) == any(tmp236.Ref()) {







































































																			var tmp237 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp237 = A_arbace_a2g_reach_A_const_79; var tmp238 lang.IFn = lang.IFn_Cast(jrt.NN(tmp237).GetRawRoot__O()); var tmp239 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp239 = A_arbace_a2g_reach_A_const_175; tmp238.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp239).GetRawRoot__O()).Invoke_O__O(Lit_290))
																			var tmp240 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp240 = A_arbace_a2g_reach_A_const_141; var tmp241 lang.IFn = lang.IFn_Cast(jrt.NN(tmp240).GetRawRoot__O()); var tmp242 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp242 = A_arbace_a2g_reach_A_const_175; var tmp243 any = lang.IFn_Cast(jrt.NN(tmp242).GetRawRoot__O()).Invoke_O__O(Lit_290); var tmp244 *jrt.String; var tmp245 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp245 = A_arbace_a2g_reach_A_const_176; var tmp246 any = tmp245.Ref(); var tmp247 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp247 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp246, jrt.NN(tmp247).Invoke_O__O(node__2)) { tmp244 = Lit_23 } else { tmp244 = Lit_307 }; var tmp248 any = tmp244.Ref(); var tmp249 *jrt.String; var tmp250 *lang.Keyword
																			A_arbace_a2g_reach_A_Init(); tmp250 = A_arbace_a2g_reach_A_const_176; var tmp251 any = tmp250.Ref(); var tmp252 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp252 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp251, jrt.NN(tmp252).Invoke_O__O(node__2)) { tmp249 = Lit_305 } else { tmp249 = Lit_305 }
//line :321:1
																			tmp241.Invoke_O_O_O__O(tmp243, tmp248, tmp249.Ref())

																			var tmp253 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp253 = A_arbace_a2g_reach_A_const_173; var tmp254 any = tmp253.Ref(); var tmp255 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp255 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp254, jrt.NN(tmp255).Invoke_O__O(node__2)) {
																				var tmp256 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp256 = A_arbace_a2g_reach_A_const_79; var tmp257 lang.IFn = lang.IFn_Cast(jrt.NN(tmp256).GetRawRoot__O()); var tmp258 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp258 = A_arbace_a2g_reach_A_const_175; tmp257.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp258).GetRawRoot__O()).Invoke_O__O(Lit_308))
																				var tmp259 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp259 = A_arbace_a2g_reach_A_const_141; var tmp260 lang.IFn = lang.IFn_Cast(jrt.NN(tmp259).GetRawRoot__O()); var tmp261 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp261 = A_arbace_a2g_reach_A_const_175; var tmp262 any = lang.IFn_Cast(jrt.NN(tmp261).GetRawRoot__O()).Invoke_O__O(Lit_308); var tmp263 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp263 = A_arbace_a2g_reach_A_const_177; var tmp264 lang.IFn = lang.IFn_Cast(jrt.NN(tmp263).GetRawRoot__O()); var tmp265 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp265 = A_arbace_a2g_reach_A_const_178; var tmp266 lang.IFn = lang.IFn_Cast(jrt.NN(tmp265).GetRawRoot__O()); var tmp267 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp267 = A_arbace_a2g_reach_A_const_179; tmp260.Invoke_O_O_O__O(tmp262, Lit_199, tmp264.Invoke_O_O__O(tmp266.Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(jrt.NN(tmp267).Invoke_O__O(node__2))).Ref(), Lit_309), Lit_309)) }
//line :248:1
																			break L1 }; case 191: var tmp268 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp268 = A_arbace_a2g_reach_A_const_174; if any(G__214000189__3_) == any(tmp268.Ref()) { var fi__4 any; var tmp269 *lang.Var

















































































																				A_arbace_a2g_reach_A_Init(); tmp269 = A_arbace_a2g_reach_A_const_155; var tmp270 lang.IFn = lang.IFn_Cast(jrt.NN(tmp269).GetRawRoot__O()); var tmp271 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp271 = A_arbace_a2g_reach_A_const_144; fi__4 = tmp270.Invoke_O__O(jrt.NN(tmp271).Invoke_O__O(node__2))
//line :248:1
																				var fni__5 any; var tmp272 *lang.Var


















































































																				A_arbace_a2g_reach_A_Init(); tmp272 = A_arbace_a2g_reach_A_const_175; fni__5 = lang.IFn_Cast(jrt.NN(tmp272).GetRawRoot__O()).Invoke_O__O(Lit_310)
																				var tmp273 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp273 = A_arbace_a2g_reach_A_const_79; var tmp274 lang.IFn = lang.IFn_Cast(jrt.NN(tmp273).GetRawRoot__O()); var tmp275 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp275 = A_arbace_a2g_reach_A_const_175; tmp274.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp275).GetRawRoot__O()).Invoke_O__O(Lit_308))
																				var tmp276 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp276 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp276).GetRawRoot__O()).Invoke_O__O(fi__4)) { var tmp277 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp277 = A_arbace_a2g_reach_A_const_164; lang.IFn_Cast(jrt.NN(tmp277).GetRawRoot__O()).Invoke_O__O(fi__4) }
																				var tmp278 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp278 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp278).GetRawRoot__O()).Invoke_O__O(fni__5)) {
																					var tmp279 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp279 = A_arbace_a2g_reach_A_const_101; lang.IFn_Cast(jrt.NN(tmp279).GetRawRoot__O()).Invoke_O__O(fni__5)
																					var tmp280 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp280 = A_arbace_a2g_reach_A_const_99; var tmp281 lang.IFn = lang.IFn_Cast(jrt.NN(tmp280).GetRawRoot__O()); var tmp282 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp282 = A_arbace_a2g_reach_A_const_181; var tmp283 any = jrt.NN(tmp282).Invoke_O__O(node__2); var tmp284 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp284 = A_arbace_a2g_reach_A_const_182; tmp281.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(fni__5, tmp283, jrt.NN(tmp284).Invoke_O__O(node__2))) }
//line :248:1
																				break L1 }; case 192: var tmp285 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp285 = A_arbace_a2g_reach_A_const_138; if any(G__214000189__3_) == any(tmp285.Ref()) {





































































																					var tmp286 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp286 = A_arbace_a2g_reach_A_const_180; var tmp287 lang.IFn = lang.IFn_Cast(jrt.NN(tmp286).GetRawRoot__O()); var tmp288 any = A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_New(); var tmp289 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_Init(); tmp289 = A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_fn_class; tmp287.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp288, tmp289, nil), nil)
//line :248:1
																					break L1 }; case 193: var tmp290 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp290 = A_arbace_a2g_reach_A_const_176; if any(G__214000189__3_) == any(tmp290.Ref()) {







































































																						var tmp291 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp291 = A_arbace_a2g_reach_A_const_79; var tmp292 lang.IFn = lang.IFn_Cast(jrt.NN(tmp291).GetRawRoot__O()); var tmp293 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp293 = A_arbace_a2g_reach_A_const_175; tmp292.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp293).GetRawRoot__O()).Invoke_O__O(Lit_290))
																						var tmp294 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp294 = A_arbace_a2g_reach_A_const_141; var tmp295 lang.IFn = lang.IFn_Cast(jrt.NN(tmp294).GetRawRoot__O()); var tmp296 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp296 = A_arbace_a2g_reach_A_const_175; var tmp297 any = lang.IFn_Cast(jrt.NN(tmp296).GetRawRoot__O()).Invoke_O__O(Lit_290); var tmp298 *jrt.String; var tmp299 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp299 = A_arbace_a2g_reach_A_const_176; var tmp300 any = tmp299.Ref(); var tmp301 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp301 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp300, jrt.NN(tmp301).Invoke_O__O(node__2)) { tmp298 = Lit_23 } else { tmp298 = Lit_307 }; var tmp302 any = tmp298.Ref(); var tmp303 *jrt.String; var tmp304 *lang.Keyword
																						A_arbace_a2g_reach_A_Init(); tmp304 = A_arbace_a2g_reach_A_const_176; var tmp305 any = tmp304.Ref(); var tmp306 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp306 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp305, jrt.NN(tmp306).Invoke_O__O(node__2)) { tmp303 = Lit_305 } else { tmp303 = Lit_305 }
//line :321:1
																						tmp295.Invoke_O_O_O__O(tmp297, tmp302, tmp303.Ref())

																						var tmp307 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp307 = A_arbace_a2g_reach_A_const_173; var tmp308 any = tmp307.Ref(); var tmp309 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp309 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp308, jrt.NN(tmp309).Invoke_O__O(node__2)) {
																							var tmp310 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp310 = A_arbace_a2g_reach_A_const_79; var tmp311 lang.IFn = lang.IFn_Cast(jrt.NN(tmp310).GetRawRoot__O()); var tmp312 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp312 = A_arbace_a2g_reach_A_const_175; tmp311.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp312).GetRawRoot__O()).Invoke_O__O(Lit_308))
																							var tmp313 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp313 = A_arbace_a2g_reach_A_const_141; var tmp314 lang.IFn = lang.IFn_Cast(jrt.NN(tmp313).GetRawRoot__O()); var tmp315 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp315 = A_arbace_a2g_reach_A_const_175; var tmp316 any = lang.IFn_Cast(jrt.NN(tmp315).GetRawRoot__O()).Invoke_O__O(Lit_308); var tmp317 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp317 = A_arbace_a2g_reach_A_const_177; var tmp318 lang.IFn = lang.IFn_Cast(jrt.NN(tmp317).GetRawRoot__O()); var tmp319 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp319 = A_arbace_a2g_reach_A_const_178; var tmp320 lang.IFn = lang.IFn_Cast(jrt.NN(tmp319).GetRawRoot__O()); var tmp321 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp321 = A_arbace_a2g_reach_A_const_179; tmp314.Invoke_O_O_O__O(tmp316, Lit_199, tmp318.Invoke_O_O__O(tmp320.Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(jrt.NN(tmp321).Invoke_O__O(node__2))).Ref(), Lit_309), Lit_309)) }
//line :248:1
																						break L1 }; case 194: var tmp322 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp322 = A_arbace_a2g_reach_A_const_183; if any(G__214000189__3_) == any(tmp322.Ref()) { var f__4_3 any; var tmp323 *lang.Keyword



































																							A_arbace_a2g_reach_A_Init(); tmp323 = A_arbace_a2g_reach_A_const_131; f__4_3 = jrt.NN(tmp323).Invoke_O__O(node__2)
//line :248:1
																							var o__5 any; var or__1927000174__auto____5_3 any; var tmp324 *lang.Keyword




































																							A_arbace_a2g_reach_A_Init(); tmp324 = A_arbace_a2g_reach_A_const_122; or__1927000174__auto____5_3 = jrt.NN(tmp324).Invoke_O__O(f__4_3); if jrt.A2g_Truth(or__1927000174__auto____5_3) { o__5 = or__1927000174__auto____5_3 } else { var tmp325 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp325 = A_arbace_a2g_reach_A_const_123; o__5 = jrt.NN(tmp325).Invoke_O__O(f__4_3) }
																							var tmp326 any; var and__1927000168__auto____6 any; var tmp327 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp327 = A_arbace_a2g_reach_A_const_21; var tmp328 lang.IFn = lang.IFn_Cast(jrt.NN(tmp327).GetRawRoot__O()); var tmp329 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp329 = A_arbace_a2g_reach_A_const_129; and__1927000168__auto____6 = tmp328.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp329).GetRawRoot__O()).Invoke_O__O(f__4_3)); if jrt.A2g_Truth(and__1927000168__auto____6) { var tmp330 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp330 = A_arbace_a2g_reach_A_const_79; tmp326 = lang.IFn_Cast(jrt.NN(tmp330).GetRawRoot__O()).Invoke_O__O(o__5) } else { tmp326 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp326) {
																								var tmp331 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp331 = A_arbace_a2g_reach_A_const_101; lang.IFn_Cast(jrt.NN(tmp331).GetRawRoot__O()).Invoke_O__O(o__5)
																								var tmp332 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp332 = A_arbace_a2g_reach_A_const_134; var tmp333 lang.IFn = lang.IFn_Cast(jrt.NN(tmp332).GetRawRoot__O()); var tmp334 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp334 = A_arbace_a2g_reach_A_const_41; tmp333.Invoke_O__O(jrt.NN(tmp334).Invoke_O__O(f__4_3))
																								var tmp335 any; var and__1927000168__auto____6_2 any; var tmp336 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp336 = A_arbace_a2g_reach_A_const_115; and__1927000168__auto____6_2 = lang.IFn_Cast(jrt.NN(tmp336).GetRawRoot__O()).Invoke_O__O(o__5); if jrt.A2g_Truth(and__1927000168__auto____6_2) { var tmp337 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp337 = A_arbace_a2g_reach_A_const_21; var tmp338 lang.IFn = lang.IFn_Cast(jrt.NN(tmp337).GetRawRoot__O()); var tmp339 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp339 = A_arbace_a2g_reach_A_const_192; var tmp340 lang.IFn = lang.IFn_Cast(jrt.NN(tmp339).GetRawRoot__O()); var tmp341 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp341 = A_arbace_a2g_reach_A_const_40; var tmp342 any = jrt.NN(tmp341).Invoke_O__O(f__4_3); var tmp343 *jrt.Boolean; jrt.Boolean_Init(); tmp343 = jrt.Boolean_TRUE; tmp335 = tmp338.Invoke_O__O(tmp340.Invoke_O_O_O__O(o__5, tmp342, tmp343.Ref())) } else { tmp335 = and__1927000168__auto____6_2 }; if jrt.A2g_Truth(tmp335) {
																									var tmp344 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp344 = A_arbace_a2g_reach_A_const_83; var tmp345 lang.IFn = lang.IFn_Cast(jrt.NN(tmp344).GetRawRoot__O()); var tmp346 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_311, nil, Lit_249, nil); var tmp347 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp347 = A_arbace_a2g_reach_A_const_40; tmp345.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp346, jrt.RefArrayOf(jrt.Object_class, nil, o__5, nil, jrt.NN(tmp347).Invoke_O__O(f__4_3))).Ref()) } }
//line :248:1
																							break L1 }; case 209: var tmp348 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp348 = A_arbace_a2g_reach_A_const_184; if any(G__214000189__3_) == any(tmp348.Ref()) { var mm__4 any; var tmp349 *lang.Keyword

																								A_arbace_a2g_reach_A_Init(); tmp349 = A_arbace_a2g_reach_A_const_185; mm__4 = jrt.NN(tmp349).Invoke_O__O(node__2)
//line :248:1
																								var mowner__5 any; var or__1927000174__auto____5_4 any; var tmp350 *lang.Keyword


																								A_arbace_a2g_reach_A_Init(); tmp350 = A_arbace_a2g_reach_A_const_123; or__1927000174__auto____5_4 = jrt.NN(tmp350).Invoke_O__O(mm__4); if jrt.A2g_Truth(or__1927000174__auto____5_4) { mowner__5 = or__1927000174__auto____5_4 } else { var tmp351 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp351 = A_arbace_a2g_reach_A_const_123; mowner__5 = jrt.NN(tmp351).Invoke_O__O(node__2) }
//line :248:1
																								var map__214000213__6 any = node__2; var map__214000213__7 any

																								if lang.ISeq_InstanceOf(map__214000213__6) { var tmp352 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp352 = A_arbace_a2g_reach_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp352).GetRawRoot__O()).Invoke_O__O(map__214000213__6)) { var tmp353 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp353 = A_arbace_a2g_reach_A_const_124; map__214000213__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp353).GetRawRoot__O()).Invoke_O__O(map__214000213__6), jrt.Object_class.ArrayClass())).Ref() } else { var tmp354 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp354 = A_arbace_a2g_reach_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp354).GetRawRoot__O()).Invoke_O__O(map__214000213__6)) { var tmp355 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp355 = A_arbace_a2g_reach_A_const_24; map__214000213__7 = lang.IFn_Cast(jrt.NN(tmp355).GetRawRoot__O()).Invoke_O__O(map__214000213__6) } else { lang.PersistentArrayMap_Init(); map__214000213__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000213__7 = map__214000213__6 }
//line :248:1
																								var name__8 any; var tmp356 *lang.Keyword

																								A_arbace_a2g_reach_A_Init(); tmp356 = A_arbace_a2g_reach_A_const_40; name__8 = lang.RT_Get_O_O__O(map__214000213__7, tmp356.Ref())
//line :248:1
																								var desc__9 any; var tmp357 *lang.Keyword

																								A_arbace_a2g_reach_A_Init(); tmp357 = A_arbace_a2g_reach_A_const_41; desc__9 = lang.RT_Get_O_O__O(map__214000213__7, tmp357.Ref())


																								var tmp358 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp358 = A_arbace_a2g_reach_A_const_186; if jrt.A2g_Truth(jrt.NN(tmp358).Invoke_O__O(node__2)) {
																									var tmp359 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp359 = A_arbace_a2g_reach_A_const_134; var tmp360 lang.IFn = lang.IFn_Cast(jrt.NN(tmp359).GetRawRoot__O()); var tmp361 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp361 = A_arbace_a2g_reach_A_const_123; tmp360.Invoke_O__O(jrt.NN(tmp361).Invoke_O__O(node__2)) } else {
//line :253:1
																										var tmp362 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp362 = A_arbace_a2g_reach_A_const_187; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp362).GetRawRoot__O()).Invoke_O__O(node__2)) { var seq_214000215__10 any; var tmp363 *lang.Var

																											A_arbace_a2g_reach_A_Init(); tmp363 = A_arbace_a2g_reach_A_const_20; var tmp364 lang.IFn = lang.IFn_Cast(jrt.NN(tmp363).GetRawRoot__O()); var tmp365 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp365 = A_arbace_a2g_reach_A_const_193; seq_214000215__10 = tmp364.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp365).GetRawRoot__O()).Invoke_O__O(desc__9))
//line :253:1
																											var chunk_214000216__11 any; var count_214000217__12 int64 = 0; var i_214000218__13 int64 = 0; L8: for {

																												if lang.Numbers_Lt_J_J__Z(i_214000218__13, count_214000217__12) { var c__14 any = lang.Indexed_Cast(chunk_214000216__11).Nth_I__O(lang.RT_IntCast_J__I(i_214000218__13)); var tmp366 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp366 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp366).GetRawRoot__O()).Invoke_O__O(c__14); seq_214000215__10, chunk_214000216__11, count_214000217__12, i_214000218__13 = seq_214000215__10, chunk_214000216__11, count_214000217__12, lang.Numbers_Unchecked_inc_J__J(i_214000218__13); continue L8 } else { var temp__1927000414__auto____14 any; var tmp367 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp367 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____14 = lang.IFn_Cast(jrt.NN(tmp367).GetRawRoot__O()).Invoke_O__O(seq_214000215__10); if jrt.A2g_Truth(temp__1927000414__auto____14) { var seq_214000215__15 any = temp__1927000414__auto____14; var tmp368 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp368 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp368).GetRawRoot__O()).Invoke_O__O(seq_214000215__15)) { var c__1927000678__auto____16 any; var tmp369 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp369 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____16 = lang.IFn_Cast(jrt.NN(tmp369).GetRawRoot__O()).Invoke_O__O(seq_214000215__15); var tmp370 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp370 = A_arbace_a2g_reach_A_const_26; seq_214000215__10, chunk_214000216__11, count_214000217__12, i_214000218__13 = lang.IFn_Cast(jrt.NN(tmp370).GetRawRoot__O()).Invoke_O__O(seq_214000215__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var c__16 any; var tmp371 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp371 = A_arbace_a2g_reach_A_const_24; c__16 = lang.IFn_Cast(jrt.NN(tmp371).GetRawRoot__O()).Invoke_O__O(seq_214000215__15); var tmp372 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp372 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp372).GetRawRoot__O()).Invoke_O__O(c__16); var tmp373 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp373 = A_arbace_a2g_reach_A_const_28; seq_214000215__10, chunk_214000216__11, count_214000217__12, i_214000218__13 = lang.IFn_Cast(jrt.NN(tmp373).GetRawRoot__O()).Invoke_O__O(seq_214000215__15), nil, 0, 0; continue L8 } } }
//line :253:1
																												break L8 } } else { var tmp374 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp374 = A_arbace_a2g_reach_A_const_31; if tmp374 != nil {




																													var tmp375 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp375 = A_arbace_a2g_reach_A_const_79; var tmp376 lang.IFn = lang.IFn_Cast(jrt.NN(tmp375).GetRawRoot__O()); var tmp377 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp377 = A_arbace_a2g_reach_A_const_123; tmp376.Invoke_O__O(jrt.NN(tmp377).Invoke_O__O(node__2))
																													var tmp378 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp378 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp378).GetRawRoot__O()).Invoke_O__O(mowner__5)
																													var tmp379 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp379 = A_arbace_a2g_reach_A_const_134; var tmp380 lang.IFn = lang.IFn_Cast(jrt.NN(tmp379).GetRawRoot__O()); var tmp381 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_312, nil, Lit_313); var tmp382 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp382 = A_arbace_a2g_reach_A_const_123; tmp380.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp381, jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(tmp382).Invoke_O__O(node__2), nil)).Ref())
//line :253:1
																													var seq_214000219__10 any; var tmp383 *lang.Var







																													A_arbace_a2g_reach_A_Init(); tmp383 = A_arbace_a2g_reach_A_const_20; var tmp384 lang.IFn = lang.IFn_Cast(jrt.NN(tmp383).GetRawRoot__O()); var tmp385 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp385 = A_arbace_a2g_reach_A_const_193; seq_214000219__10 = tmp384.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp385).GetRawRoot__O()).Invoke_O__O(desc__9))
//line :253:1
																													var chunk_214000220__11 any; var count_214000221__12 int64 = 0; var i_214000222__13 int64 = 0; L9: for {







																														if lang.Numbers_Lt_J_J__Z(i_214000222__13, count_214000221__12) { var c__14_2 any = lang.Indexed_Cast(chunk_214000220__11).Nth_I__O(lang.RT_IntCast_J__I(i_214000222__13)); var tmp386 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp386 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp386).GetRawRoot__O()).Invoke_O__O(c__14_2); seq_214000219__10, chunk_214000220__11, count_214000221__12, i_214000222__13 = seq_214000219__10, chunk_214000220__11, count_214000221__12, lang.Numbers_Unchecked_inc_J__J(i_214000222__13); continue L9 } else { var temp__1927000414__auto____14_2 any; var tmp387 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp387 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____14_2 = lang.IFn_Cast(jrt.NN(tmp387).GetRawRoot__O()).Invoke_O__O(seq_214000219__10); if jrt.A2g_Truth(temp__1927000414__auto____14_2) { var seq_214000219__15 any = temp__1927000414__auto____14_2; var tmp388 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp388 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp388).GetRawRoot__O()).Invoke_O__O(seq_214000219__15)) { var c__1927000678__auto____16_2 any; var tmp389 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp389 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____16_2 = lang.IFn_Cast(jrt.NN(tmp389).GetRawRoot__O()).Invoke_O__O(seq_214000219__15); var tmp390 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp390 = A_arbace_a2g_reach_A_const_26; seq_214000219__10, chunk_214000220__11, count_214000221__12, i_214000222__13 = lang.IFn_Cast(jrt.NN(tmp390).GetRawRoot__O()).Invoke_O__O(seq_214000219__15), c__1927000678__auto____16_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16_2))), int64(lang.RT_IntCast_J__I(0)); continue L9 } else { var c__16_2 any; var tmp391 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp391 = A_arbace_a2g_reach_A_const_24; c__16_2 = lang.IFn_Cast(jrt.NN(tmp391).GetRawRoot__O()).Invoke_O__O(seq_214000219__15); var tmp392 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp392 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp392).GetRawRoot__O()).Invoke_O__O(c__16_2); var tmp393 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp393 = A_arbace_a2g_reach_A_const_28; seq_214000219__10, chunk_214000220__11, count_214000221__12, i_214000222__13 = lang.IFn_Cast(jrt.NN(tmp393).GetRawRoot__O()).Invoke_O__O(seq_214000219__15), nil, 0, 0; continue L9 } } }
//line :253:1
																														break L9 }; var G__214000223__10_ any; var tmp394 *lang.Keyword








																													A_arbace_a2g_reach_A_Init(); tmp394 = A_arbace_a2g_reach_A_const_125; G__214000223__10_ = jrt.NN(tmp394).Invoke_O__O(node__2); L10: switch { default: switch lang.Util_Hash_O__I(G__214000223__10_) >> 4 & 7 { case 3: var tmp395 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp395 = A_arbace_a2g_reach_A_const_188; if any(G__214000223__10_) == any(tmp395.Ref()) {




																														var tmp396 any; var and__1927000168__auto____11_2 any = mm__4; if jrt.A2g_Truth(and__1927000168__auto____11_2) { var tmp397 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp397 = A_arbace_a2g_reach_A_const_46; tmp396 = lang.IFn_Cast(jrt.NN(tmp397).GetRawRoot__O()).Invoke_O__O(mm__4) } else { tmp396 = and__1927000168__auto____11_2 }; if jrt.A2g_Truth(tmp396) {
																															var tmp398 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp398 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp398).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9)) } else {
																																var tmp399 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp399 = A_arbace_a2g_reach_A_const_141; var tmp400 lang.IFn = lang.IFn_Cast(jrt.NN(tmp399).GetRawRoot__O()); var tmp401 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp401 = A_arbace_a2g_reach_A_const_123; tmp400.Invoke_O_O_O__O(jrt.NN(tmp401).Invoke_O__O(node__2), name__8, desc__9)
																																var tmp402 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp402 = A_arbace_a2g_reach_A_const_189; var tmp403 lang.IFn = lang.IFn_Cast(jrt.NN(tmp402).GetRawRoot__O()); var tmp404 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp404 = A_arbace_a2g_reach_A_const_123; var tmp405 any = jrt.NN(tmp404).Invoke_O__O(node__2); var tmp406 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp406 = A_arbace_a2g_reach_A_const_191; tmp403.Invoke_O_O_O_O__O(tmp405, name__8, desc__9, tmp406.Ref()) }
//line :262:1
																														break L10 }; case 5: var tmp407 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp407 = A_arbace_a2g_reach_A_const_190; if any(G__214000223__10_) == any(tmp407.Ref()) {


																															var tmp408 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp408 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp408).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9)); var tmp409 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp409 = A_arbace_a2g_reach_A_const_189; var tmp410 lang.IFn = lang.IFn_Cast(jrt.NN(tmp409).GetRawRoot__O()); var tmp411 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp411 = A_arbace_a2g_reach_A_const_190; tmp410.Invoke_O_O_O_O__O(mowner__5, name__8, desc__9, tmp411.Ref())
//line :262:1
																															break L10 }; case 6: var tmp412 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp412 = A_arbace_a2g_reach_A_const_191; if any(G__214000223__10_) == any(tmp412.Ref()) {




																																var tmp413 any; var and__1927000168__auto____11_3 any = mm__4; if jrt.A2g_Truth(and__1927000168__auto____11_3) { var tmp414 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp414 = A_arbace_a2g_reach_A_const_46; tmp413 = lang.IFn_Cast(jrt.NN(tmp414).GetRawRoot__O()).Invoke_O__O(mm__4) } else { tmp413 = and__1927000168__auto____11_3 }; if jrt.A2g_Truth(tmp413) {
																																	var tmp415 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp415 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp415).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9)) } else {
																																		var tmp416 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp416 = A_arbace_a2g_reach_A_const_141; var tmp417 lang.IFn = lang.IFn_Cast(jrt.NN(tmp416).GetRawRoot__O()); var tmp418 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp418 = A_arbace_a2g_reach_A_const_123; tmp417.Invoke_O_O_O__O(jrt.NN(tmp418).Invoke_O__O(node__2), name__8, desc__9)
																																		var tmp419 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp419 = A_arbace_a2g_reach_A_const_189; var tmp420 lang.IFn = lang.IFn_Cast(jrt.NN(tmp419).GetRawRoot__O()); var tmp421 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp421 = A_arbace_a2g_reach_A_const_123; var tmp422 any = jrt.NN(tmp421).Invoke_O__O(node__2); var tmp423 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp423 = A_arbace_a2g_reach_A_const_191; tmp420.Invoke_O_O_O_O__O(tmp422, name__8, desc__9, tmp423.Ref()) }
//line :262:1
																																break L10 }; case 7: var tmp424 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp424 = A_arbace_a2g_reach_A_const_116; if any(G__214000223__10_) == any(tmp424.Ref()) {
																																	var tmp425 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp425 = A_arbace_a2g_reach_A_const_101; lang.IFn_Cast(jrt.NN(tmp425).GetRawRoot__O()).Invoke_O__O(mowner__5); var tmp426 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp426 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp426).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9))
																																	var tmp427 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp427 = A_arbace_a2g_reach_A_const_189; var tmp428 lang.IFn = lang.IFn_Cast(jrt.NN(tmp427).GetRawRoot__O()); var tmp429 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp429 = A_arbace_a2g_reach_A_const_116; tmp428.Invoke_O_O_O_O__O(mowner__5, name__8, desc__9, tmp429.Ref())
//line :262:1
																																	break L10 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_293, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000223__10_)))))} } } }
//line :248:1
																								break L1 }; case 222: var tmp430 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp430 = A_arbace_a2g_reach_A_const_128; if any(G__214000189__3_) == any(tmp430.Ref()) { var f__4_4 any; var tmp431 *lang.Keyword



































																									A_arbace_a2g_reach_A_Init(); tmp431 = A_arbace_a2g_reach_A_const_131; f__4_4 = jrt.NN(tmp431).Invoke_O__O(node__2)
//line :248:1
																									var o__5_2 any; var or__1927000174__auto____5_5 any; var tmp432 *lang.Keyword




































																									A_arbace_a2g_reach_A_Init(); tmp432 = A_arbace_a2g_reach_A_const_122; or__1927000174__auto____5_5 = jrt.NN(tmp432).Invoke_O__O(f__4_4); if jrt.A2g_Truth(or__1927000174__auto____5_5) { o__5_2 = or__1927000174__auto____5_5 } else { var tmp433 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp433 = A_arbace_a2g_reach_A_const_123; o__5_2 = jrt.NN(tmp433).Invoke_O__O(f__4_4) }
																									var tmp434 any; var and__1927000168__auto____6_3 any; var tmp435 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp435 = A_arbace_a2g_reach_A_const_21; var tmp436 lang.IFn = lang.IFn_Cast(jrt.NN(tmp435).GetRawRoot__O()); var tmp437 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp437 = A_arbace_a2g_reach_A_const_129; and__1927000168__auto____6_3 = tmp436.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp437).GetRawRoot__O()).Invoke_O__O(f__4_4)); if jrt.A2g_Truth(and__1927000168__auto____6_3) { var tmp438 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp438 = A_arbace_a2g_reach_A_const_79; tmp434 = lang.IFn_Cast(jrt.NN(tmp438).GetRawRoot__O()).Invoke_O__O(o__5_2) } else { tmp434 = and__1927000168__auto____6_3 }; if jrt.A2g_Truth(tmp434) {
																										var tmp439 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp439 = A_arbace_a2g_reach_A_const_101; lang.IFn_Cast(jrt.NN(tmp439).GetRawRoot__O()).Invoke_O__O(o__5_2)
																										var tmp440 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp440 = A_arbace_a2g_reach_A_const_134; var tmp441 lang.IFn = lang.IFn_Cast(jrt.NN(tmp440).GetRawRoot__O()); var tmp442 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp442 = A_arbace_a2g_reach_A_const_41; tmp441.Invoke_O__O(jrt.NN(tmp442).Invoke_O__O(f__4_4))
																										var tmp443 any; var and__1927000168__auto____6_4 any; var tmp444 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp444 = A_arbace_a2g_reach_A_const_115; and__1927000168__auto____6_4 = lang.IFn_Cast(jrt.NN(tmp444).GetRawRoot__O()).Invoke_O__O(o__5_2); if jrt.A2g_Truth(and__1927000168__auto____6_4) { var tmp445 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp445 = A_arbace_a2g_reach_A_const_21; var tmp446 lang.IFn = lang.IFn_Cast(jrt.NN(tmp445).GetRawRoot__O()); var tmp447 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp447 = A_arbace_a2g_reach_A_const_192; var tmp448 lang.IFn = lang.IFn_Cast(jrt.NN(tmp447).GetRawRoot__O()); var tmp449 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp449 = A_arbace_a2g_reach_A_const_40; var tmp450 any = jrt.NN(tmp449).Invoke_O__O(f__4_4); var tmp451 *jrt.Boolean; jrt.Boolean_Init(); tmp451 = jrt.Boolean_TRUE; tmp443 = tmp446.Invoke_O__O(tmp448.Invoke_O_O_O__O(o__5_2, tmp450, tmp451.Ref())) } else { tmp443 = and__1927000168__auto____6_4 }; if jrt.A2g_Truth(tmp443) {
																											var tmp452 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp452 = A_arbace_a2g_reach_A_const_83; var tmp453 lang.IFn = lang.IFn_Cast(jrt.NN(tmp452).GetRawRoot__O()); var tmp454 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_311, nil, Lit_249, nil); var tmp455 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp455 = A_arbace_a2g_reach_A_const_40; tmp453.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(tmp454, jrt.RefArrayOf(jrt.Object_class, nil, o__5_2, nil, jrt.NN(tmp455).Invoke_O__O(f__4_4))).Ref()) } }
//line :248:1
																									break L1 }; case 239: var tmp456 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp456 = A_arbace_a2g_reach_A_const_194; if any(G__214000189__3_) == any(tmp456.Ref()) {

































































																										var tmp457 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp457 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp457).GetRawRoot__O()).Invoke_O__O(Lit_314)
//line :248:1
																										var d__4 any; var tmp458 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_315, nil, Lit_316); var tmp459 any; var or__1927000174__auto____7 any; var tmp460 *lang.Keyword


































































																										A_arbace_a2g_reach_A_Init(); tmp460 = A_arbace_a2g_reach_A_const_195; or__1927000174__auto____7 = jrt.NN(tmp460).Invoke_O__O(node__2); if jrt.A2g_Truth(or__1927000174__auto____7) { tmp459 = or__1927000174__auto____7 } else { tmp459 = Lit_317 }; d__4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp458, jrt.RefArrayOf(jrt.Object_class, nil, tmp459, nil)).Ref()
																										var tmp461 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp461 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp461).GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_314, Lit_241, d__4))
																										var tmp462 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp462 = A_arbace_a2g_reach_A_const_162; lang.IFn_Cast(jrt.NN(tmp462).GetRawRoot__O()).Invoke_O__O(Lit_314)
//line :248:1
																										break L1 }; default:
	}
	}
























































































	var tmp463 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp463 = A_arbace_a2g_reach_A_const_138; var tmp464 any = tmp463.Ref(); var tmp465 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp465 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp464, jrt.NN(tmp465).Invoke_O__O(node__2)) { var body_pat__3 *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_New(); var pat__3 any; var tmp466 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_Init(); tmp466 = A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_fn_class; pat__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_pat__3.Ref(), tmp466, nil)




		var tmp467 lang.IFn = lang.IFn_Cast(pat__3); var tmp468 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp468 = A_arbace_a2g_reach_A_const_143; tmp467.Invoke_O__O(jrt.NN(tmp468).Invoke_O__O(node__2)) }
	var tmp469 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp469 = A_arbace_a2g_reach_A_const_132; var tmp470 any = tmp469.Ref(); var tmp471 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp471 = A_arbace_a2g_reach_A_const_19; if lang.Util_Equiv_O_O__Z(tmp470, jrt.NN(tmp471).Invoke_O__O(node__2)) { var seq_214000230__3 any; var tmp472 *lang.Var
		A_arbace_a2g_reach_A_Init(); tmp472 = A_arbace_a2g_reach_A_const_20; var tmp473 lang.IFn = lang.IFn_Cast(jrt.NN(tmp472).GetRawRoot__O()); var tmp474 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp474 = A_arbace_a2g_reach_A_const_196; seq_214000230__3 = tmp473.Invoke_O__O(jrt.NN(tmp474).Invoke_O__O(node__2))
//line :345:1
		var chunk_214000231__4 any; var count_214000232__5 int64 = 0; var i_214000233__6 int64 = 0; L11: for {
			if lang.Numbers_Lt_J_J__Z(i_214000233__6, count_214000232__5) { var c__7 any = lang.Indexed_Cast(chunk_214000231__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000233__6)); var seq_214000238__8 any; var tmp475 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp475 = A_arbace_a2g_reach_A_const_20; var tmp476 lang.IFn = lang.IFn_Cast(jrt.NN(tmp475).GetRawRoot__O()); var tmp477 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp477 = A_arbace_a2g_reach_A_const_197; seq_214000238__8 = tmp476.Invoke_O__O(jrt.NN(tmp477).Invoke_O__O(c__7)); var chunk_214000239__9 any; var count_214000240__10 int64 = 0; var i_214000241__11 int64 = 0; L12: for { if lang.Numbers_Lt_J_J__Z(i_214000241__11, count_214000240__10) { var l__12 any = lang.Indexed_Cast(chunk_214000239__9).Nth_I__O(lang.RT_IntCast_J__I(i_214000241__11)); var tmp478 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp478 = A_arbace_a2g_reach_A_const_143; if jrt.A2g_Truth(jrt.NN(tmp478).Invoke_O__O(l__12)) { var body_pat__13 *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_New(); var pat__13 any; var tmp479 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_Init(); tmp479 = A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_fn_class; pat__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_pat__13.Ref(), tmp479, nil)




				var tmp480 lang.IFn = lang.IFn_Cast(pat__13); var tmp481 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp481 = A_arbace_a2g_reach_A_const_143; tmp480.Invoke_O__O(jrt.NN(tmp481).Invoke_O__O(l__12))
//line :346:1
				seq_214000238__8, chunk_214000239__9, count_214000240__10, i_214000241__11 = seq_214000238__8, chunk_214000239__9, count_214000240__10, lang.Numbers_Unchecked_inc_J__J(i_214000241__11); continue L12 } else { seq_214000238__8, chunk_214000239__9, count_214000240__10, i_214000241__11 = seq_214000238__8, chunk_214000239__9, count_214000240__10, lang.Numbers_Unchecked_inc_J__J(i_214000241__11); continue L12 } } else { var temp__1927000414__auto____12 any; var tmp482 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp482 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp482).GetRawRoot__O()).Invoke_O__O(seq_214000238__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_214000238__13 any = temp__1927000414__auto____12; var tmp483 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp483 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp483).GetRawRoot__O()).Invoke_O__O(seq_214000238__13)) { var c__1927000678__auto____14 any; var tmp484 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp484 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____14 = lang.IFn_Cast(jrt.NN(tmp484).GetRawRoot__O()).Invoke_O__O(seq_214000238__13); var tmp485 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp485 = A_arbace_a2g_reach_A_const_26; seq_214000238__8, chunk_214000239__9, count_214000240__10, i_214000241__11 = lang.IFn_Cast(jrt.NN(tmp485).GetRawRoot__O()).Invoke_O__O(seq_214000238__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L12 } else { var l__14 any; var tmp486 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp486 = A_arbace_a2g_reach_A_const_24; l__14 = lang.IFn_Cast(jrt.NN(tmp486).GetRawRoot__O()).Invoke_O__O(seq_214000238__13); var tmp487 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp487 = A_arbace_a2g_reach_A_const_143; if jrt.A2g_Truth(jrt.NN(tmp487).Invoke_O__O(l__14)) { var body_pat__15 *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_New(); var pat__15 any; var tmp488 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_Init(); tmp488 = A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_fn_class; pat__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_pat__15.Ref(), tmp488, nil)




					var tmp489 lang.IFn = lang.IFn_Cast(pat__15); var tmp490 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp490 = A_arbace_a2g_reach_A_const_143; tmp489.Invoke_O__O(jrt.NN(tmp490).Invoke_O__O(l__14))
//line :346:1
					var tmp491 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp491 = A_arbace_a2g_reach_A_const_28; seq_214000238__8, chunk_214000239__9, count_214000240__10, i_214000241__11 = lang.IFn_Cast(jrt.NN(tmp491).GetRawRoot__O()).Invoke_O__O(seq_214000238__13), nil, 0, 0; continue L12 } else { var tmp492 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp492 = A_arbace_a2g_reach_A_const_28; seq_214000238__8, chunk_214000239__9, count_214000240__10, i_214000241__11 = lang.IFn_Cast(jrt.NN(tmp492).GetRawRoot__O()).Invoke_O__O(seq_214000238__13), nil, 0, 0; continue L12 } } } }; break L12 }; seq_214000230__3, chunk_214000231__4, count_214000232__5, i_214000233__6 = seq_214000230__3, chunk_214000231__4, count_214000232__5, lang.Numbers_Unchecked_inc_J__J(i_214000233__6); continue L11 } else { var temp__1927000414__auto____7 any; var tmp493 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp493 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp493).GetRawRoot__O()).Invoke_O__O(seq_214000230__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_214000230__8 any = temp__1927000414__auto____7; var tmp494 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp494 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp494).GetRawRoot__O()).Invoke_O__O(seq_214000230__8)) { var c__1927000678__auto____9 any; var tmp495 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp495 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp495).GetRawRoot__O()).Invoke_O__O(seq_214000230__8); var tmp496 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp496 = A_arbace_a2g_reach_A_const_26; seq_214000230__3, chunk_214000231__4, count_214000232__5, i_214000233__6 = lang.IFn_Cast(jrt.NN(tmp496).GetRawRoot__O()).Invoke_O__O(seq_214000230__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L11 } else { var c__9 any; var tmp497 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp497 = A_arbace_a2g_reach_A_const_24; c__9 = lang.IFn_Cast(jrt.NN(tmp497).GetRawRoot__O()).Invoke_O__O(seq_214000230__8); var seq_214000234__10 any; var tmp498 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp498 = A_arbace_a2g_reach_A_const_20; var tmp499 lang.IFn = lang.IFn_Cast(jrt.NN(tmp498).GetRawRoot__O()); var tmp500 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp500 = A_arbace_a2g_reach_A_const_197; seq_214000234__10 = tmp499.Invoke_O__O(jrt.NN(tmp500).Invoke_O__O(c__9)); var chunk_214000235__11 any; var count_214000236__12 int64 = 0; var i_214000237__13 int64 = 0; L13: for { if lang.Numbers_Lt_J_J__Z(i_214000237__13, count_214000236__12) { var l__14_2 any = lang.Indexed_Cast(chunk_214000235__11).Nth_I__O(lang.RT_IntCast_J__I(i_214000237__13)); var tmp501 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp501 = A_arbace_a2g_reach_A_const_143; if jrt.A2g_Truth(jrt.NN(tmp501).Invoke_O__O(l__14_2)) { var body_pat__15_2 *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_New(); var pat__15_2 any; var tmp502 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_Init(); tmp502 = A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_fn_class; pat__15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_pat__15_2.Ref(), tmp502, nil)




						var tmp503 lang.IFn = lang.IFn_Cast(pat__15_2); var tmp504 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp504 = A_arbace_a2g_reach_A_const_143; tmp503.Invoke_O__O(jrt.NN(tmp504).Invoke_O__O(l__14_2))
//line :346:1
						seq_214000234__10, chunk_214000235__11, count_214000236__12, i_214000237__13 = seq_214000234__10, chunk_214000235__11, count_214000236__12, lang.Numbers_Unchecked_inc_J__J(i_214000237__13); continue L13 } else { seq_214000234__10, chunk_214000235__11, count_214000236__12, i_214000237__13 = seq_214000234__10, chunk_214000235__11, count_214000236__12, lang.Numbers_Unchecked_inc_J__J(i_214000237__13); continue L13 } } else { var temp__1927000414__auto____14_3 any; var tmp505 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp505 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____14_3 = lang.IFn_Cast(jrt.NN(tmp505).GetRawRoot__O()).Invoke_O__O(seq_214000234__10); if jrt.A2g_Truth(temp__1927000414__auto____14_3) { var seq_214000234__15 any = temp__1927000414__auto____14_3; var tmp506 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp506 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp506).GetRawRoot__O()).Invoke_O__O(seq_214000234__15)) { var c__1927000678__auto____16_3 any; var tmp507 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp507 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____16_3 = lang.IFn_Cast(jrt.NN(tmp507).GetRawRoot__O()).Invoke_O__O(seq_214000234__15); var tmp508 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp508 = A_arbace_a2g_reach_A_const_26; seq_214000234__10, chunk_214000235__11, count_214000236__12, i_214000237__13 = lang.IFn_Cast(jrt.NN(tmp508).GetRawRoot__O()).Invoke_O__O(seq_214000234__15), c__1927000678__auto____16_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16_3))), int64(lang.RT_IntCast_J__I(0)); continue L13 } else { var l__16 any; var tmp509 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp509 = A_arbace_a2g_reach_A_const_24; l__16 = lang.IFn_Cast(jrt.NN(tmp509).GetRawRoot__O()).Invoke_O__O(seq_214000234__15); var tmp510 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp510 = A_arbace_a2g_reach_A_const_143; if jrt.A2g_Truth(jrt.NN(tmp510).Invoke_O__O(l__16)) { var body_pat__17 *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_New(); var pat__17 any; var tmp511 *jrt.Class; A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_Init(); tmp511 = A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_fn_class; pat__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(body_pat__17.Ref(), tmp511, nil)




							var tmp512 lang.IFn = lang.IFn_Cast(pat__17); var tmp513 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp513 = A_arbace_a2g_reach_A_const_143; tmp512.Invoke_O__O(jrt.NN(tmp513).Invoke_O__O(l__16))
//line :346:1
							var tmp514 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp514 = A_arbace_a2g_reach_A_const_28; seq_214000234__10, chunk_214000235__11, count_214000236__12, i_214000237__13 = lang.IFn_Cast(jrt.NN(tmp514).GetRawRoot__O()).Invoke_O__O(seq_214000234__15), nil, 0, 0; continue L13 } else { var tmp515 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp515 = A_arbace_a2g_reach_A_const_28; seq_214000234__10, chunk_214000235__11, count_214000236__12, i_214000237__13 = lang.IFn_Cast(jrt.NN(tmp515).GetRawRoot__O()).Invoke_O__O(seq_214000234__15), nil, 0, 0; continue L13 } } } }; break L13 }; var tmp516 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp516 = A_arbace_a2g_reach_A_const_28; seq_214000230__3, chunk_214000231__4, count_214000232__5, i_214000233__6 = lang.IFn_Cast(jrt.NN(tmp516).GetRawRoot__O()).Invoke_O__O(seq_214000230__8), nil, 0, 0; continue L11 } } else { return nil } } } } else {
//line :345:1
								return nil } }; /*line :246:1*/panic("a2g: unreachable") }







































































func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_New() *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A { A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A{}; t.Ctor(); return t }
//line :318:1
func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) Ctor() {}
//line :318:1
func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) Invoke_O_O__O(self, ___1 any) any { return nil }





















func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A { A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A{}; t.Ctor(); return t }
//line :340:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) Ctor() {}
//line :340:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) Invoke_O_O__O(self, p__1 any) any { { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_134; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_139; tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(p__1)); var seq_214000225__2 any; var tmp4 *lang.Var
												A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_140; seq_214000225__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p__1))
//line :340:1
	var chunk_214000226__3 any; var count_214000227__4 int64 = 0; var i_214000228__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000228__5, count_214000227__4) { var c__6 any = lang.Indexed_Cast(chunk_214000226__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000228__5)); var tmp7 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_141; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_123; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_142; var tmp12 any = jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(c__6)); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_40; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_142; var tmp16 any = jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(c__6)); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_41; var tmp18 *lang.Keyword = tmp17; var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_142; tmp8.Invoke_O_O_O__O(tmp12, tmp16, jrt.NN(tmp18).Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(c__6)))
			var tmp20 lang.IFn = lang.IFn_Cast(self); var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_143; tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(c__6))
//line :341:1
			seq_214000225__2, chunk_214000226__3, count_214000227__4, i_214000228__5 = seq_214000225__2, chunk_214000226__3, count_214000227__4, lang.Numbers_Unchecked_inc_J__J(i_214000228__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000225__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000225__7 any = temp__1927000414__auto____6; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000225__7)) { var c__1927000678__auto____8 any; var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000225__7); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_26; seq_214000225__2, chunk_214000226__3, count_214000227__4, i_214000228__5 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_214000225__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_24; c__8 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_214000225__7)
				var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_141; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_123; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_142; var tmp32 any = jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(c__8)); var tmp33 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_40; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_142; var tmp36 any = jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(c__8)); var tmp37 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_41; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_142; tmp28.Invoke_O_O_O__O(tmp32, tmp36, jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Invoke_O__O(c__8)))
				var tmp40 lang.IFn = lang.IFn_Cast(self); var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_143; tmp40.Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(c__8))
//line :341:1
				var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_28; seq_214000225__2, chunk_214000226__3, count_214000227__4, i_214000228__5 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_214000225__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :340:1*/panic("a2g: unreachable") }






func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A { A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) Ctor() {}
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) Invoke_O_O__O(self, p__1 any) any { { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_134; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_139; tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(p__1)); var seq_214000243__2 any; var tmp4 *lang.Var
												A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_140; seq_214000243__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p__1))
//line :347:1
	var chunk_214000244__3 any; var count_214000245__4 int64 = 0; var i_214000246__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000246__5, count_214000245__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000244__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000246__5)); var tmp7 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_141; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_123; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_142; var tmp12 any = jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(cc__6)); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_40; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_142; var tmp16 any = jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(cc__6)); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_41; var tmp18 *lang.Keyword = tmp17; var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_142; tmp8.Invoke_O_O_O__O(tmp12, tmp16, jrt.NN(tmp18).Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(cc__6)))
			var tmp20 lang.IFn = lang.IFn_Cast(self); var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_143; tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(cc__6))
//line :348:1
			seq_214000243__2, chunk_214000244__3, count_214000245__4, i_214000246__5 = seq_214000243__2, chunk_214000244__3, count_214000245__4, lang.Numbers_Unchecked_inc_J__J(i_214000246__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000243__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000243__7 any = temp__1927000414__auto____6; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000243__7)) { var c__1927000678__auto____8 any; var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000243__7); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_26; seq_214000243__2, chunk_214000244__3, count_214000245__4, i_214000246__5 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_214000243__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_24; cc__8 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_214000243__7)
				var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_141; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_123; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_142; var tmp32 any = jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(cc__8)); var tmp33 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_40; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_142; var tmp36 any = jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(cc__8)); var tmp37 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_41; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_142; tmp28.Invoke_O_O_O__O(tmp32, tmp36, jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Invoke_O__O(cc__8)))
				var tmp40 lang.IFn = lang.IFn_Cast(self); var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_143; tmp40.Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(cc__8))
//line :348:1
				var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_28; seq_214000243__2, chunk_214000244__3, count_214000245__4, i_214000246__5 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_214000243__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :347:1*/panic("a2g: unreachable") }
//line :347:1
func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A { A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) Ctor() {}
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) Invoke_O_O__O(self, p__1 any) any { { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_134; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_139; tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(p__1)); var seq_214000249__2 any; var tmp4 *lang.Var
												A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_140; seq_214000249__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p__1))
//line :347:1
	var chunk_214000250__3 any; var count_214000251__4 int64 = 0; var i_214000252__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000252__5, count_214000251__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000250__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000252__5)); var tmp7 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_141; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_123; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_142; var tmp12 any = jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(cc__6)); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_40; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_142; var tmp16 any = jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(cc__6)); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_41; var tmp18 *lang.Keyword = tmp17; var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_142; tmp8.Invoke_O_O_O__O(tmp12, tmp16, jrt.NN(tmp18).Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(cc__6)))
			var tmp20 lang.IFn = lang.IFn_Cast(self); var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_143; tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(cc__6))
//line :348:1
			seq_214000249__2, chunk_214000250__3, count_214000251__4, i_214000252__5 = seq_214000249__2, chunk_214000250__3, count_214000251__4, lang.Numbers_Unchecked_inc_J__J(i_214000252__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000249__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000249__7 any = temp__1927000414__auto____6; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000249__7)) { var c__1927000678__auto____8 any; var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000249__7); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_26; seq_214000249__2, chunk_214000250__3, count_214000251__4, i_214000252__5 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_214000249__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_24; cc__8 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_214000249__7)
				var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_141; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_123; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_142; var tmp32 any = jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(cc__8)); var tmp33 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_40; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_142; var tmp36 any = jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(cc__8)); var tmp37 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_41; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_142; tmp28.Invoke_O_O_O__O(tmp32, tmp36, jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Invoke_O__O(cc__8)))
				var tmp40 lang.IFn = lang.IFn_Cast(self); var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_143; tmp40.Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(cc__8))
//line :348:1
				var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_28; seq_214000249__2, chunk_214000250__3, count_214000251__4, i_214000252__5 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_214000249__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :347:1*/panic("a2g: unreachable") }
//line :347:1
func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A { A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) Ctor() {}
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) Invoke_O_O__O(self, p__1 any) any { { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_134; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_139; tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(p__1)); var seq_214000255__2 any; var tmp4 *lang.Var
												A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_140; seq_214000255__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p__1))
//line :347:1
	var chunk_214000256__3 any; var count_214000257__4 int64 = 0; var i_214000258__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000258__5, count_214000257__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000256__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000258__5)); var tmp7 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_141; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_123; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_142; var tmp12 any = jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(cc__6)); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_40; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_142; var tmp16 any = jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(cc__6)); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_41; var tmp18 *lang.Keyword = tmp17; var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_142; tmp8.Invoke_O_O_O__O(tmp12, tmp16, jrt.NN(tmp18).Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(cc__6)))
			var tmp20 lang.IFn = lang.IFn_Cast(self); var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_143; tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(cc__6))
//line :348:1
			seq_214000255__2, chunk_214000256__3, count_214000257__4, i_214000258__5 = seq_214000255__2, chunk_214000256__3, count_214000257__4, lang.Numbers_Unchecked_inc_J__J(i_214000258__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000255__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000255__7 any = temp__1927000414__auto____6; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000255__7)) { var c__1927000678__auto____8 any; var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000255__7); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_26; seq_214000255__2, chunk_214000256__3, count_214000257__4, i_214000258__5 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_214000255__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_24; cc__8 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_214000255__7)
				var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_141; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_123; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_142; var tmp32 any = jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(cc__8)); var tmp33 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_40; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_142; var tmp36 any = jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(cc__8)); var tmp37 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_41; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_142; tmp28.Invoke_O_O_O__O(tmp32, tmp36, jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Invoke_O__O(cc__8)))
				var tmp40 lang.IFn = lang.IFn_Cast(self); var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_143; tmp40.Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(cc__8))
//line :348:1
				var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_28; seq_214000255__2, chunk_214000256__3, count_214000257__4, i_214000258__5 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_214000255__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :347:1*/panic("a2g: unreachable") }
//line :347:1
func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A { A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A{}; t.Ctor(); return t }
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) Ctor() {}
//line :347:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) Invoke_O_O__O(self, p__1 any) any { { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_134; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_139; tmp2.Invoke_O__O(jrt.NN(tmp3).Invoke_O__O(p__1)); var seq_214000261__2 any; var tmp4 *lang.Var
												A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_20; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_140; seq_214000261__2 = tmp5.Invoke_O__O(jrt.NN(tmp6).Invoke_O__O(p__1))
//line :347:1
	var chunk_214000262__3 any; var count_214000263__4 int64 = 0; var i_214000264__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000264__5, count_214000263__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000262__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000264__5)); var tmp7 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_141; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_123; var tmp10 *lang.Keyword = tmp9; var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_142; var tmp12 any = jrt.NN(tmp10).Invoke_O__O(jrt.NN(tmp11).Invoke_O__O(cc__6)); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_40; var tmp14 *lang.Keyword = tmp13; var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_142; var tmp16 any = jrt.NN(tmp14).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(cc__6)); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_41; var tmp18 *lang.Keyword = tmp17; var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_142; tmp8.Invoke_O_O_O__O(tmp12, tmp16, jrt.NN(tmp18).Invoke_O__O(jrt.NN(tmp19).Invoke_O__O(cc__6)))
			var tmp20 lang.IFn = lang.IFn_Cast(self); var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_143; tmp20.Invoke_O__O(jrt.NN(tmp21).Invoke_O__O(cc__6))
//line :348:1
			seq_214000261__2, chunk_214000262__3, count_214000263__4, i_214000264__5 = seq_214000261__2, chunk_214000262__3, count_214000263__4, lang.Numbers_Unchecked_inc_J__J(i_214000264__5); continue L1 } else { var temp__1927000414__auto____6 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____6 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000261__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000261__7 any = temp__1927000414__auto____6; var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(seq_214000261__7)) { var c__1927000678__auto____8 any; var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____8 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000261__7); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_26; seq_214000261__2, chunk_214000262__3, count_214000263__4, i_214000264__5 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(seq_214000261__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any; var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_24; cc__8 = lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O__O(seq_214000261__7)
				var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_141; var tmp28 lang.IFn = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_123; var tmp30 *lang.Keyword = tmp29; var tmp31 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_142; var tmp32 any = jrt.NN(tmp30).Invoke_O__O(jrt.NN(tmp31).Invoke_O__O(cc__8)); var tmp33 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_40; var tmp34 *lang.Keyword = tmp33; var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_142; var tmp36 any = jrt.NN(tmp34).Invoke_O__O(jrt.NN(tmp35).Invoke_O__O(cc__8)); var tmp37 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_41; var tmp38 *lang.Keyword = tmp37; var tmp39 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_142; tmp28.Invoke_O_O_O__O(tmp32, tmp36, jrt.NN(tmp38).Invoke_O__O(jrt.NN(tmp39).Invoke_O__O(cc__8)))
				var tmp40 lang.IFn = lang.IFn_Cast(self); var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_143; tmp40.Invoke_O__O(jrt.NN(tmp41).Invoke_O__O(cc__8))
//line :348:1
				var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_28; seq_214000261__2, chunk_214000262__3, count_214000263__4, i_214000264__5 = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O__O(seq_214000261__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :347:1*/panic("a2g: unreachable") }





func A_arbace_a2g_reach_scan_code_BANG__A_New() *A_arbace_a2g_reach_scan_code_BANG__A { A_arbace_a2g_reach_scan_code_BANG__A_Init(); t := &A_arbace_a2g_reach_scan_code_BANG__A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_a2g_reach_scan_code_BANG__A) Ctor() {}
//line :353:1
func (t *A_arbace_a2g_reach_scan_code_BANG__A) Invoke_O_O__O(self, node__0 any) any { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_180; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_198; return tmp2.Invoke_O_O__O(jrt.NN(tmp3).GetRawRoot__O(), node__0) }

func A_arbace_a2g_reach_method_code_A_New() *A_arbace_a2g_reach_method_code_A { A_arbace_a2g_reach_method_code_A_Init(); t := &A_arbace_a2g_reach_method_code_A{}; t.Ctor(); return t }
//line :355:1
func (t *A_arbace_a2g_reach_method_code_A) Ctor() {}
//line :355:1
func (t *A_arbace_a2g_reach_method_code_A) Invoke_O_O__O(self, p__214000268__0 any) any { var vec__214000269__2 any = p__214000268__0; var c__3 any = lang.RT_Nth_O_I_O__O(vec__214000269__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000269__2, lang.RT_IntCast_J__I(1), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000269__2, lang.RT_IntCast_J__I(2), nil); var d__6 any; var tmp1 *lang.Var;


	A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_77; d__6 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(c__3); var st__7 any; var tmp2 /*line :355:1*/*lang.Var;


	A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_13; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_86; st__7 = tmp3.Invoke_O__O(jrt.NN(tmp4).Invoke_O__O(d__6)); if

	lang.Util_Equiv_O_O__Z(name__4, Lit_242) {
		var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_103; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_200; return tmp6.Invoke_O__O(jrt.NN(tmp7).Invoke_O__O(st__7)) } else {
//line :360:1
			var ab__8 any; var tmp8 *lang.Keyword

			A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_199; ab__8 = lang.RT_Get_O_O__O(jrt.NN(tmp8).Invoke_O__O(st__7), lang.Tuple_Create_O_O__IPersistentVector(name__4, desc__5))
			if lang.Util_Equiv_O_O__Z(name__4, Lit_241) {
				var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_103; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_102; var tmp12 lang.IFn = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()); var tmp13 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_201; var tmp14 any = jrt.NN(tmp13).Invoke_O__O(ab__8); var tmp15 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp15 = A_arbace_a2g_reach_A_const_204; var tmp16 any = lang.Tuple_Create_O__IPersistentVector(jrt.NN(tmp15).Invoke_O__O(ab__8)); var tmp17 any; var tmp18 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_202; if jrt.A2g_Truth(jrt.NN(tmp18).Invoke_O__O(ab__8)) { var tmp19 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_203; tmp17 = jrt.NN(tmp19).Invoke_O__O(st__7) } else { tmp17 = nil }; var tmp20 any = tmp17; var tmp21 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_205; return tmp10.Invoke_O__O(tmp12.Invoke_O_O_O_O__O(tmp14, tmp16, tmp20, lang.Tuple_Create_O__IPersistentVector(jrt.NN(tmp21).Invoke_O__O(ab__8)))) } else {
					if jrt.A2g_Truth(ab__8) { var tmp22 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_205; return lang.Tuple_Create_O__IPersistentVector(jrt.NN(tmp22).Invoke_O__O(ab__8)) } else { lang.PersistentVector_Init(); return lang.PersistentVector_EMPTY.Ref() } } } }

func A_arbace_a2g_reach_scan_method_BANG__A_New() *A_arbace_a2g_reach_scan_method_BANG__A { A_arbace_a2g_reach_scan_method_BANG__A_Init(); t := &A_arbace_a2g_reach_scan_method_BANG__A{}; t.Ctor(); return t }
//line :367:1
func (t *A_arbace_a2g_reach_scan_method_BANG__A) Ctor() {}
//line :367:1
func (t *A_arbace_a2g_reach_scan_method_BANG__A) Invoke_O_O__O(self, p__214000273__0 any) any { var vec__214000274__2 any = p__214000273__0; var c__3 any = lang.RT_Nth_O_I_O__O(vec__214000274__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000274__2, lang.RT_IntCast_J__I(1), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000274__2, lang.RT_IntCast_J__I(2), nil); var k__6 any = vec__214000274__2; var tmp1 *lang.Var;
												A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_89; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_90; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_59; tmp2.Invoke_O__O(tmp4.Invoke_O_O__O(tmp5.Ref(), k__6)); var tmp6 any; tmp196 := /*line :367:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var d__9 any; var tmp7 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_77; d__9 = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(c__3)
//line :367:1
		var st__10 any; var tmp8 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_13; var tmp9 lang.IFn = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()); var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_86; st__10 = tmp9.Invoke_O__O(jrt.NN(tmp10).Invoke_O__O(d__9))
//line :367:1
		var mm__11 any



		if lang.Util_Equiv_O_O__Z(name__4, Lit_242) { mm__11 = nil } else { var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_206; mm__11 = lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O_O_O__O(c__3, name__4, desc__5) }
//line :367:1
		var temp__1927000414__auto____12 any; var tmp12 *lang.Keyword




		A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_78; temp__1927000414__auto____12 = jrt.NN(tmp12).Invoke_O__O(st__10); if jrt.A2g_Truth(temp__1927000414__auto____12) { var why__13 any = temp__1927000414__auto____12; var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_83; lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_287, nil), jrt.RefArrayOf(jrt.Object_class, nil, why__13)).Ref()) }
		if jrt.A2g_Truth(mm__11) { var seq_214000277__12 any; var tmp14 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp14 = A_arbace_a2g_reach_A_const_20; var tmp15 lang.IFn = lang.IFn_Cast(jrt.NN(tmp14).GetRawRoot__O()); var tmp16 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_193; seq_214000277__12 = tmp15.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(desc__5))
//line :373:1
			var chunk_214000278__13 any; var count_214000279__14 int64 = 0; var i_214000280__15 int64 = 0; L1: for {
				if lang.Numbers_Lt_J_J__Z(i_214000280__15, count_214000279__14) { var cl__16 any = lang.Indexed_Cast(chunk_214000278__13).Nth_I__O(lang.RT_IntCast_J__I(i_214000280__15)); var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(cl__16); seq_214000277__12, chunk_214000278__13, count_214000279__14, i_214000280__15 = seq_214000277__12, chunk_214000278__13, count_214000279__14, lang.Numbers_Unchecked_inc_J__J(i_214000280__15); continue L1 } else { var temp__1927000414__auto____16 any; var tmp18 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp18 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____16 = lang.IFn_Cast(jrt.NN(tmp18).GetRawRoot__O()).Invoke_O__O(seq_214000277__12); if jrt.A2g_Truth(temp__1927000414__auto____16) { var seq_214000277__17 any = temp__1927000414__auto____16; var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()).Invoke_O__O(seq_214000277__17)) { var c__1927000678__auto____18 any; var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____18 = lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(seq_214000277__17); var tmp21 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_26; seq_214000277__12, chunk_214000278__13, count_214000279__14, i_214000280__15 = lang.IFn_Cast(jrt.NN(tmp21).GetRawRoot__O()).Invoke_O__O(seq_214000277__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cl__18 any; var tmp22 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_24; cl__18 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O__O(seq_214000277__17); var tmp23 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp23).GetRawRoot__O()).Invoke_O__O(cl__18); var tmp24 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_28; seq_214000277__12, chunk_214000278__13, count_214000279__14, i_214000280__15 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(seq_214000277__17), nil, 0, 0; continue L1 } } }
//line :373:1
				break L1 } }
//line :367:1
		var G__214000281__12_ any = name__4







	L2: switch { default: switch lang.Util_Hash_O__I(G__214000281__12_) { case -1944711511: if lang.Util_Equiv_O_O__Z(G__214000281__12_, Lit_242) { var seq_214000282__13 any; var tmp25 *lang.Var

		A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_20; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_200; seq_214000282__13 = tmp26.Invoke_O__O(jrt.NN(tmp27).Invoke_O__O(st__10))
//line :375:1
		var chunk_214000283__14 any; var count_214000284__15 int64 = 0; var i_214000285__16 int64 = 0; L3: for {

			if lang.Numbers_Lt_J_J__Z(i_214000285__16, count_214000284__15) { var nd__17 any = lang.Indexed_Cast(chunk_214000283__14).Nth_I__O(lang.RT_IntCast_J__I(i_214000285__16)); var tmp28 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp28 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(nd__17); seq_214000282__13, chunk_214000283__14, count_214000284__15, i_214000285__16 = seq_214000282__13, chunk_214000283__14, count_214000284__15, lang.Numbers_Unchecked_inc_J__J(i_214000285__16); continue L3 } else { var temp__1927000414__auto____17 any; var tmp29 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____17 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_214000282__13); if jrt.A2g_Truth(temp__1927000414__auto____17) { var seq_214000282__18 any = temp__1927000414__auto____17; var tmp30 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp30 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq_214000282__18)) { var c__1927000678__auto____19 any; var tmp31 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____19 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq_214000282__18); var tmp32 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_26; seq_214000282__13, chunk_214000283__14, count_214000284__15, i_214000285__16 = lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(seq_214000282__18), c__1927000678__auto____19, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var nd__19 any; var tmp33 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_24; nd__19 = lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(seq_214000282__18); var tmp34 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp34 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp34).GetRawRoot__O()).Invoke_O__O(nd__19); var tmp35 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_28; seq_214000282__13, chunk_214000283__14, count_214000284__15, i_214000285__16 = lang.IFn_Cast(jrt.NN(tmp35).GetRawRoot__O()).Invoke_O__O(seq_214000282__18), nil, 0, 0; continue L3 } } }
//line :375:1
			break L3
		}

		var tmp36 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_20; var tmp37 lang.IFn = lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()); var tmp38 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_216; if jrt.A2g_Truth(tmp37.Invoke_O__O(jrt.NN(tmp38).Invoke_O__O(st__10))) {
			var tmp39 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp39 = A_arbace_a2g_reach_A_const_79; var tmp40 lang.IFn = lang.IFn_Cast(jrt.NN(tmp39).GetRawRoot__O()); var tmp41 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_175; tmp40.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(Lit_288))
//line :378:1
			var seq_214000286__13 any; var tmp42 *lang.Var

			A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_20; var tmp43 lang.IFn = lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()); var tmp44 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp44 = A_arbace_a2g_reach_A_const_216; seq_214000286__13 = tmp43.Invoke_O__O(jrt.NN(tmp44).Invoke_O__O(st__10))
//line :378:1
			var chunk_214000287__14 any; var count_214000288__15 int64 = 0; var i_214000289__16 int64 = 0; L4: for {

				if lang.Numbers_Lt_J_J__Z(i_214000289__16, count_214000288__15) { var vec__214000290__17 any = lang.Indexed_Cast(chunk_214000287__14).Nth_I__O(lang.RT_IntCast_J__I(i_214000289__16)); var ___18 any = lang.RT_Nth_O_I_O__O(vec__214000290__17, lang.RT_IntCast_J__I(0), nil); var map__214000293__19 any = lang.RT_Nth_O_I_O__O(vec__214000290__17, lang.RT_IntCast_J__I(1), nil); var map__214000293__20 any; _ = ___18; if lang.ISeq_InstanceOf(map__214000293__19) { var tmp45 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp45 = A_arbace_a2g_reach_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp45).GetRawRoot__O()).Invoke_O__O(map__214000293__19)) { var tmp46 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp46 = A_arbace_a2g_reach_A_const_124; map__214000293__20 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp46).GetRawRoot__O()).Invoke_O__O(map__214000293__19), jrt.Object_class.ArrayClass())).Ref() } else { var tmp47 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp47 = A_arbace_a2g_reach_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(map__214000293__19)) { var tmp48 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp48 = A_arbace_a2g_reach_A_const_24; map__214000293__20 = lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(map__214000293__19) } else { lang.PersistentArrayMap_Init(); map__214000293__20 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000293__20 = map__214000293__19 }; var init__21 any; var tmp49 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp49 = A_arbace_a2g_reach_A_const_203; init__21 = lang.RT_Get_O_O__O(map__214000293__20, tmp49.Ref()); var G__214000295__22_ any; var tmp50 *lang.Keyword
					A_arbace_a2g_reach_A_Init(); tmp50 = A_arbace_a2g_reach_A_const_125; G__214000295__22_ = jrt.NN(tmp50).Invoke_O__O(init__21); L5: switch { default: switch lang.Util_Hash_O__I(G__214000295__22_) >> 0 & 1 { case 0: var tmp51 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp51 = A_arbace_a2g_reach_A_const_217; if any(G__214000295__22_) == any(tmp51.Ref()) {
						var tmp52 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp52 = A_arbace_a2g_reach_A_const_101; var tmp53 lang.IFn = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()); var tmp54 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp54 = A_arbace_a2g_reach_A_const_175; tmp53.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(Lit_288))
						var tmp55 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp55 = A_arbace_a2g_reach_A_const_99; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp57 = A_arbace_a2g_reach_A_const_175; var tmp58 any = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()).Invoke_O__O(Lit_288); var tmp59 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_289, nil); var tmp60 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp60 = A_arbace_a2g_reach_A_const_219; tmp56.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp58, Lit_46, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp59, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(Lit_290))).Ref()))
//line :381:1
						break L5 }; case 1: var tmp61 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp61 = A_arbace_a2g_reach_A_const_218; if any(G__214000295__22_) == any(tmp61.Ref()) {


							var tmp62 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp62 = A_arbace_a2g_reach_A_const_101; var tmp63 lang.IFn = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()); var tmp64 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp64 = A_arbace_a2g_reach_A_const_175; tmp63.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(Lit_288))
							var tmp65 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp65 = A_arbace_a2g_reach_A_const_99; var tmp66 lang.IFn = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()); var tmp67 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp67 = A_arbace_a2g_reach_A_const_175; tmp66.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(Lit_288), Lit_291, Lit_292))
//line :381:1
							break L5 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_293, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000295__22_)))))}
//line :380:1
					seq_214000286__13, chunk_214000287__14, count_214000288__15, i_214000289__16 = seq_214000286__13, chunk_214000287__14, count_214000288__15, lang.Numbers_Unchecked_inc_J__J(i_214000289__16); continue L4 } else { var temp__1927000414__auto____17_2 any; var tmp68 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp68 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____17_2 = lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(seq_214000286__13); if jrt.A2g_Truth(temp__1927000414__auto____17_2) { var seq_214000286__18 any = temp__1927000414__auto____17_2; var tmp69 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp69 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_214000286__18)) { var c__1927000678__auto____19_2 any; var tmp70 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp70 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____19_2 = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()).Invoke_O__O(seq_214000286__18); var tmp71 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp71 = A_arbace_a2g_reach_A_const_26; seq_214000286__13, chunk_214000287__14, count_214000288__15, i_214000289__16 = lang.IFn_Cast(jrt.NN(tmp71).GetRawRoot__O()).Invoke_O__O(seq_214000286__18), c__1927000678__auto____19_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var vec__214000296__19 any; var tmp72 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp72 = A_arbace_a2g_reach_A_const_24; vec__214000296__19 = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()).Invoke_O__O(seq_214000286__18); var ___20 any = lang.RT_Nth_O_I_O__O(vec__214000296__19, lang.RT_IntCast_J__I(0), nil); var map__214000299__21 any = lang.RT_Nth_O_I_O__O(vec__214000296__19, lang.RT_IntCast_J__I(1), nil); var map__214000299__22 any; _ = ___20; if lang.ISeq_InstanceOf(map__214000299__21) { var tmp73 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp73 = A_arbace_a2g_reach_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()).Invoke_O__O(map__214000299__21)) { var tmp74 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp74 = A_arbace_a2g_reach_A_const_124; map__214000299__22 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp74).GetRawRoot__O()).Invoke_O__O(map__214000299__21), jrt.Object_class.ArrayClass())).Ref() } else { var tmp75 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp75 = A_arbace_a2g_reach_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()).Invoke_O__O(map__214000299__21)) { var tmp76 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp76 = A_arbace_a2g_reach_A_const_24; map__214000299__22 = lang.IFn_Cast(jrt.NN(tmp76).GetRawRoot__O()).Invoke_O__O(map__214000299__21) } else { lang.PersistentArrayMap_Init(); map__214000299__22 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000299__22 = map__214000299__21 }; var init__23 any; var tmp77 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp77 = A_arbace_a2g_reach_A_const_203; init__23 = lang.RT_Get_O_O__O(map__214000299__22, tmp77.Ref()); var G__214000301__24_ any; var tmp78 *lang.Keyword
						A_arbace_a2g_reach_A_Init(); tmp78 = A_arbace_a2g_reach_A_const_125; G__214000301__24_ = jrt.NN(tmp78).Invoke_O__O(init__23); L6: switch { default: switch lang.Util_Hash_O__I(G__214000301__24_) >> 0 & 1 { case 0: var tmp79 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp79 = A_arbace_a2g_reach_A_const_217; if any(G__214000301__24_) == any(tmp79.Ref()) {
							var tmp80 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp80 = A_arbace_a2g_reach_A_const_101; var tmp81 lang.IFn = lang.IFn_Cast(jrt.NN(tmp80).GetRawRoot__O()); var tmp82 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp82 = A_arbace_a2g_reach_A_const_175; tmp81.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(Lit_288))
							var tmp83 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp83 = A_arbace_a2g_reach_A_const_99; var tmp84 lang.IFn = lang.IFn_Cast(jrt.NN(tmp83).GetRawRoot__O()); var tmp85 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp85 = A_arbace_a2g_reach_A_const_175; var tmp86 any = lang.IFn_Cast(jrt.NN(tmp85).GetRawRoot__O()).Invoke_O__O(Lit_288); var tmp87 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_289, nil); var tmp88 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp88 = A_arbace_a2g_reach_A_const_219; tmp84.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp86, Lit_46, lang.Compiler_AOT_StrConcat_String1_O1__String(tmp87, jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(jrt.NN(tmp88).GetRawRoot__O()).Invoke_O__O(Lit_290))).Ref()))
//line :381:1
							break L6 }; case 1: var tmp89 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp89 = A_arbace_a2g_reach_A_const_218; if any(G__214000301__24_) == any(tmp89.Ref()) {


								var tmp90 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp90 = A_arbace_a2g_reach_A_const_101; var tmp91 lang.IFn = lang.IFn_Cast(jrt.NN(tmp90).GetRawRoot__O()); var tmp92 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp92 = A_arbace_a2g_reach_A_const_175; tmp91.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp92).GetRawRoot__O()).Invoke_O__O(Lit_288))
								var tmp93 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp93 = A_arbace_a2g_reach_A_const_99; var tmp94 lang.IFn = lang.IFn_Cast(jrt.NN(tmp93).GetRawRoot__O()); var tmp95 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp95 = A_arbace_a2g_reach_A_const_175; tmp94.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(jrt.NN(tmp95).GetRawRoot__O()).Invoke_O__O(Lit_288), Lit_291, Lit_292))
//line :381:1
								break L6 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_293, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000301__24_)))))}
//line :380:1
						var tmp96 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp96 = A_arbace_a2g_reach_A_const_28; seq_214000286__13, chunk_214000287__14, count_214000288__15, i_214000289__16 = lang.IFn_Cast(jrt.NN(tmp96).GetRawRoot__O()).Invoke_O__O(seq_214000286__18), nil, 0, 0; continue L4 } } }
//line :378:1
				break L4
			}
		}





		var tmp97 any; var or__1927000174__auto____13 any; var tmp98 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp98 = A_arbace_a2g_reach_A_const_207; or__1927000174__auto____13 = jrt.NN(tmp98).Invoke_O__O(st__10); if jrt.A2g_Truth(or__1927000174__auto____13) { tmp97 = or__1927000174__auto____13 } else { var tmp99 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp99 = A_arbace_a2g_reach_A_const_208; tmp97 = jrt.NN(tmp99).Invoke_O__O(st__10) }; if jrt.A2g_Truth(tmp97) { tmp6 = nil } else { tmp6 = nil }
//line :375:1
		break L2 }; default:
	}










		var tmp100 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp100 = A_arbace_a2g_reach_A_const_209; if jrt.A2g_Truth(jrt.NN(tmp100).Invoke_O__O(mm__11)) { var G__214000302__13_ any; var tmp101 *lang.Keyword

			A_arbace_a2g_reach_A_Init(); tmp101 = A_arbace_a2g_reach_A_const_209; G__214000302__13_ = jrt.NN(tmp101).Invoke_O__O(mm__11); L7: switch { default: switch lang.Util_Hash_O__I(G__214000302__13_) >> 0 & 7 { case 0: var tmp102 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp102 = A_arbace_a2g_reach_A_const_210; if any(G__214000302__13_) == any(tmp102.Ref()) { var ab__14 any; var tmp103 *lang.Keyword










				A_arbace_a2g_reach_A_Init(); tmp103 = A_arbace_a2g_reach_A_const_199; ab__14 = lang.RT_Get_O_O__O(jrt.NN(tmp103).Invoke_O__O(st__10), lang.Tuple_Create_O_O__IPersistentVector(Lit_241, desc__5))
//line :389:1
				var temp__1927000414__auto____15 any; var tmp104 *lang.Keyword











				A_arbace_a2g_reach_A_Init(); tmp104 = A_arbace_a2g_reach_A_const_204; temp__1927000414__auto____15 = jrt.NN(tmp104).Invoke_O__O(ab__14); if jrt.A2g_Truth(temp__1927000414__auto____15) { var call__16 any = temp__1927000414__auto____15; var tmp105 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp105 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp105).GetRawRoot__O()).Invoke_O__O(call__16) }
//line :389:1
				var seq_214000303__15 any; var tmp106 *lang.Var












				A_arbace_a2g_reach_A_Init(); tmp106 = A_arbace_a2g_reach_A_const_20; var tmp107 lang.IFn = lang.IFn_Cast(jrt.NN(tmp106).GetRawRoot__O()); var tmp108 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp108 = A_arbace_a2g_reach_A_const_203; seq_214000303__15 = tmp107.Invoke_O__O(jrt.NN(tmp108).Invoke_O__O(st__10))
//line :389:1
				var chunk_214000304__16 any; var count_214000305__17 int64 = 0; var i_214000306__18 int64 = 0; L8: for {












					if lang.Numbers_Lt_J_J__Z(i_214000306__18, count_214000305__17) { var i__19 any = lang.Indexed_Cast(chunk_214000304__16).Nth_I__O(lang.RT_IntCast_J__I(i_214000306__18)); var tmp109 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp109 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp109).GetRawRoot__O()).Invoke_O__O(i__19); seq_214000303__15, chunk_214000304__16, count_214000305__17, i_214000306__18 = seq_214000303__15, chunk_214000304__16, count_214000305__17, lang.Numbers_Unchecked_inc_J__J(i_214000306__18); continue L8 } else { var temp__1927000414__auto____19 any; var tmp110 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp110 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____19 = lang.IFn_Cast(jrt.NN(tmp110).GetRawRoot__O()).Invoke_O__O(seq_214000303__15); if jrt.A2g_Truth(temp__1927000414__auto____19) { var seq_214000303__20 any = temp__1927000414__auto____19; var tmp111 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp111 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp111).GetRawRoot__O()).Invoke_O__O(seq_214000303__20)) { var c__1927000678__auto____21 any; var tmp112 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp112 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____21 = lang.IFn_Cast(jrt.NN(tmp112).GetRawRoot__O()).Invoke_O__O(seq_214000303__20); var tmp113 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp113 = A_arbace_a2g_reach_A_const_26; seq_214000303__15, chunk_214000304__16, count_214000305__17, i_214000306__18 = lang.IFn_Cast(jrt.NN(tmp113).GetRawRoot__O()).Invoke_O__O(seq_214000303__20), c__1927000678__auto____21, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var i__21 any; var tmp114 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp114 = A_arbace_a2g_reach_A_const_24; i__21 = lang.IFn_Cast(jrt.NN(tmp114).GetRawRoot__O()).Invoke_O__O(seq_214000303__20); var tmp115 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp115 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp115).GetRawRoot__O()).Invoke_O__O(i__21); var tmp116 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp116 = A_arbace_a2g_reach_A_const_28; seq_214000303__15, chunk_214000304__16, count_214000305__17, i_214000306__18 = lang.IFn_Cast(jrt.NN(tmp116).GetRawRoot__O()).Invoke_O__O(seq_214000303__20), nil, 0, 0; continue L8 } } else { tmp6 = nil } }
//line :389:1
					break L8 }; break L7 }; case 2: var tmp117 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp117 = A_arbace_a2g_reach_A_const_211; if any(G__214000302__13_) == any(tmp117.Ref()) { var ab__14_2 any; var tmp118 *lang.Keyword










						A_arbace_a2g_reach_A_Init(); tmp118 = A_arbace_a2g_reach_A_const_199; ab__14_2 = lang.RT_Get_O_O__O(jrt.NN(tmp118).Invoke_O__O(st__10), lang.Tuple_Create_O_O__IPersistentVector(Lit_241, desc__5))
//line :389:1
						var temp__1927000414__auto____15_2 any; var tmp119 *lang.Keyword











						A_arbace_a2g_reach_A_Init(); tmp119 = A_arbace_a2g_reach_A_const_204; temp__1927000414__auto____15_2 = jrt.NN(tmp119).Invoke_O__O(ab__14_2); if jrt.A2g_Truth(temp__1927000414__auto____15_2) { var call__16_2 any = temp__1927000414__auto____15_2; var tmp120 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp120 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()).Invoke_O__O(call__16_2) }
//line :389:1
						var seq_214000307__15 any; var tmp121 *lang.Var












						A_arbace_a2g_reach_A_Init(); tmp121 = A_arbace_a2g_reach_A_const_20; var tmp122 lang.IFn = lang.IFn_Cast(jrt.NN(tmp121).GetRawRoot__O()); var tmp123 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp123 = A_arbace_a2g_reach_A_const_203; seq_214000307__15 = tmp122.Invoke_O__O(jrt.NN(tmp123).Invoke_O__O(st__10))
//line :389:1
						var chunk_214000308__16 any; var count_214000309__17 int64 = 0; var i_214000310__18 int64 = 0; L9: for {












							if lang.Numbers_Lt_J_J__Z(i_214000310__18, count_214000309__17) { var i__19_2 any = lang.Indexed_Cast(chunk_214000308__16).Nth_I__O(lang.RT_IntCast_J__I(i_214000310__18)); var tmp124 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp124 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp124).GetRawRoot__O()).Invoke_O__O(i__19_2); seq_214000307__15, chunk_214000308__16, count_214000309__17, i_214000310__18 = seq_214000307__15, chunk_214000308__16, count_214000309__17, lang.Numbers_Unchecked_inc_J__J(i_214000310__18); continue L9 } else { var temp__1927000414__auto____19_2 any; var tmp125 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp125 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____19_2 = lang.IFn_Cast(jrt.NN(tmp125).GetRawRoot__O()).Invoke_O__O(seq_214000307__15); if jrt.A2g_Truth(temp__1927000414__auto____19_2) { var seq_214000307__20 any = temp__1927000414__auto____19_2; var tmp126 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp126 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()).Invoke_O__O(seq_214000307__20)) { var c__1927000678__auto____21_2 any; var tmp127 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp127 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____21_2 = lang.IFn_Cast(jrt.NN(tmp127).GetRawRoot__O()).Invoke_O__O(seq_214000307__20); var tmp128 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp128 = A_arbace_a2g_reach_A_const_26; seq_214000307__15, chunk_214000308__16, count_214000309__17, i_214000310__18 = lang.IFn_Cast(jrt.NN(tmp128).GetRawRoot__O()).Invoke_O__O(seq_214000307__20), c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I(0)); continue L9 } else { var i__21_2 any; var tmp129 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp129 = A_arbace_a2g_reach_A_const_24; i__21_2 = lang.IFn_Cast(jrt.NN(tmp129).GetRawRoot__O()).Invoke_O__O(seq_214000307__20); var tmp130 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp130 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp130).GetRawRoot__O()).Invoke_O__O(i__21_2); var tmp131 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp131 = A_arbace_a2g_reach_A_const_28; seq_214000307__15, chunk_214000308__16, count_214000309__17, i_214000310__18 = lang.IFn_Cast(jrt.NN(tmp131).GetRawRoot__O()).Invoke_O__O(seq_214000307__20), nil, 0, 0; continue L9 } } else { tmp6 = nil } }
//line :389:1
							break L9 }; break L7 }; case 3: var tmp132 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp132 = A_arbace_a2g_reach_A_const_212; if any(G__214000302__13_) == any(tmp132.Ref()) { var tg__14 any; var tmp133 *lang.Keyword
								A_arbace_a2g_reach_A_Init(); tmp133 = A_arbace_a2g_reach_A_const_213; tg__14 = jrt.NN(tmp133).Invoke_O__O(mm__11)
								var tmp134 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp134 = A_arbace_a2g_reach_A_const_190; if jrt.A2g_Truth(jrt.NN(tmp134).Invoke_O__O(mm__11)) {
									var tmp135 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp135 = A_arbace_a2g_reach_A_const_99; var tmp136 lang.IFn = lang.IFn_Cast(jrt.NN(tmp135).GetRawRoot__O()); var tmp137 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp137 = A_arbace_a2g_reach_A_const_123; var tmp138 any = jrt.NN(tmp137).Invoke_O__O(tg__14); var tmp139 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp139 = A_arbace_a2g_reach_A_const_40; var tmp140 any = jrt.NN(tmp139).Invoke_O__O(tg__14); var tmp141 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp141 = A_arbace_a2g_reach_A_const_41; tmp6 = tmp136.Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(tmp138, tmp140, jrt.NN(tmp141).Invoke_O__O(tg__14))) } else {
										var tmp142 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp142 = A_arbace_a2g_reach_A_const_141; var tmp143 lang.IFn = lang.IFn_Cast(jrt.NN(tmp142).GetRawRoot__O()); var tmp144 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp144 = A_arbace_a2g_reach_A_const_40; var tmp145 any = jrt.NN(tmp144).Invoke_O__O(tg__14); var tmp146 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp146 = A_arbace_a2g_reach_A_const_41; tmp6 = tmp143.Invoke_O_O_O__O(c__3, tmp145, jrt.NN(tmp146).Invoke_O__O(tg__14)) }
//line :389:1
								break L7 }; case 4: var tmp147 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp147 = A_arbace_a2g_reach_A_const_214; if any(G__214000302__13_) == any(tmp147.Ref()) { var ab__14_3 any; var tmp148 *lang.Keyword










									A_arbace_a2g_reach_A_Init(); tmp148 = A_arbace_a2g_reach_A_const_199; ab__14_3 = lang.RT_Get_O_O__O(jrt.NN(tmp148).Invoke_O__O(st__10), lang.Tuple_Create_O_O__IPersistentVector(Lit_241, desc__5))
//line :389:1
									var temp__1927000414__auto____15_3 any; var tmp149 *lang.Keyword











									A_arbace_a2g_reach_A_Init(); tmp149 = A_arbace_a2g_reach_A_const_204; temp__1927000414__auto____15_3 = jrt.NN(tmp149).Invoke_O__O(ab__14_3); if jrt.A2g_Truth(temp__1927000414__auto____15_3) { var call__16_3 any = temp__1927000414__auto____15_3; var tmp150 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp150 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp150).GetRawRoot__O()).Invoke_O__O(call__16_3) }
//line :389:1
									var seq_214000311__15 any; var tmp151 *lang.Var












									A_arbace_a2g_reach_A_Init(); tmp151 = A_arbace_a2g_reach_A_const_20; var tmp152 lang.IFn = lang.IFn_Cast(jrt.NN(tmp151).GetRawRoot__O()); var tmp153 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp153 = A_arbace_a2g_reach_A_const_203; seq_214000311__15 = tmp152.Invoke_O__O(jrt.NN(tmp153).Invoke_O__O(st__10))
//line :389:1
									var chunk_214000312__16 any; var count_214000313__17 int64 = 0; var i_214000314__18 int64 = 0; L10: for {












										if lang.Numbers_Lt_J_J__Z(i_214000314__18, count_214000313__17) { var i__19_3 any = lang.Indexed_Cast(chunk_214000312__16).Nth_I__O(lang.RT_IntCast_J__I(i_214000314__18)); var tmp154 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp154 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp154).GetRawRoot__O()).Invoke_O__O(i__19_3); seq_214000311__15, chunk_214000312__16, count_214000313__17, i_214000314__18 = seq_214000311__15, chunk_214000312__16, count_214000313__17, lang.Numbers_Unchecked_inc_J__J(i_214000314__18); continue L10 } else { var temp__1927000414__auto____19_3 any; var tmp155 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp155 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____19_3 = lang.IFn_Cast(jrt.NN(tmp155).GetRawRoot__O()).Invoke_O__O(seq_214000311__15); if jrt.A2g_Truth(temp__1927000414__auto____19_3) { var seq_214000311__20 any = temp__1927000414__auto____19_3; var tmp156 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp156 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp156).GetRawRoot__O()).Invoke_O__O(seq_214000311__20)) { var c__1927000678__auto____21_3 any; var tmp157 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp157 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____21_3 = lang.IFn_Cast(jrt.NN(tmp157).GetRawRoot__O()).Invoke_O__O(seq_214000311__20); var tmp158 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp158 = A_arbace_a2g_reach_A_const_26; seq_214000311__15, chunk_214000312__16, count_214000313__17, i_214000314__18 = lang.IFn_Cast(jrt.NN(tmp158).GetRawRoot__O()).Invoke_O__O(seq_214000311__20), c__1927000678__auto____21_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____21_3))), int64(lang.RT_IntCast_J__I(0)); continue L10 } else { var i__21_3 any; var tmp159 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp159 = A_arbace_a2g_reach_A_const_24; i__21_3 = lang.IFn_Cast(jrt.NN(tmp159).GetRawRoot__O()).Invoke_O__O(seq_214000311__20); var tmp160 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp160 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp160).GetRawRoot__O()).Invoke_O__O(i__21_3); var tmp161 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp161 = A_arbace_a2g_reach_A_const_28; seq_214000311__15, chunk_214000312__16, count_214000313__17, i_214000314__18 = lang.IFn_Cast(jrt.NN(tmp161).GetRawRoot__O()).Invoke_O__O(seq_214000311__20), nil, 0, 0; continue L10 } } else { tmp6 = nil } }
//line :389:1
										break L10 }; break L7 }; case 7: var tmp162 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp162 = A_arbace_a2g_reach_A_const_220; if any(G__214000302__13_) == any(tmp162.Ref()) { var seq_214000315__14 any; var tmp163 *lang.Var




											A_arbace_a2g_reach_A_Init(); tmp163 = A_arbace_a2g_reach_A_const_20; var tmp164 lang.IFn = lang.IFn_Cast(jrt.NN(tmp163).GetRawRoot__O()); var tmp165 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp165 = A_arbace_a2g_reach_A_const_221; seq_214000315__14 = tmp164.Invoke_O__O(jrt.NN(tmp165).Invoke_O__O(d__9))
//line :389:1
											var chunk_214000316__15 any; var count_214000317__16 int64 = 0; var i_214000318__17 int64 = 0; L11: for {




												if lang.Numbers_Lt_J_J__Z(i_214000318__17, count_214000317__16) { var cm__18 any = lang.Indexed_Cast(chunk_214000316__15).Nth_I__O(lang.RT_IntCast_J__I(i_214000318__17)); var tmp166 *lang.Var
													A_arbace_a2g_reach_A_Init(); tmp166 = A_arbace_a2g_reach_A_const_148; var tmp167 lang.IFn = lang.IFn_Cast(jrt.NN(tmp166).GetRawRoot__O()); var tmp168 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp168 = A_arbace_a2g_reach_A_const_41; if jrt.A2g_Truth(tmp167.Invoke_O__O(jrt.NN(tmp168).Invoke_O__O(cm__18))) {
														var tmp169 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp169 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp169).GetRawRoot__O()).Invoke_O_O_O__O(Lit_247, Lit_294, Lit_295)
														var tmp170 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp170 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp170).GetRawRoot__O()).Invoke_O_O_O__O(Lit_247, Lit_296, Lit_297)
														var tmp171 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp171 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp171).GetRawRoot__O()).Invoke_O_O_O__O(Lit_247, Lit_298, Lit_299) }
//line :394:1
													seq_214000315__14, chunk_214000316__15, count_214000317__16, i_214000318__17 = seq_214000315__14, chunk_214000316__15, count_214000317__16, lang.Numbers_Unchecked_inc_J__J(i_214000318__17); continue L11 } else { var temp__1927000414__auto____18 any; var tmp172 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp172 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____18 = lang.IFn_Cast(jrt.NN(tmp172).GetRawRoot__O()).Invoke_O__O(seq_214000315__14); if jrt.A2g_Truth(temp__1927000414__auto____18) { var seq_214000315__19 any = temp__1927000414__auto____18; var tmp173 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp173 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp173).GetRawRoot__O()).Invoke_O__O(seq_214000315__19)) { var c__1927000678__auto____20 any; var tmp174 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp174 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____20 = lang.IFn_Cast(jrt.NN(tmp174).GetRawRoot__O()).Invoke_O__O(seq_214000315__19); var tmp175 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp175 = A_arbace_a2g_reach_A_const_26; seq_214000315__14, chunk_214000316__15, count_214000317__16, i_214000318__17 = lang.IFn_Cast(jrt.NN(tmp175).GetRawRoot__O()).Invoke_O__O(seq_214000315__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L11 } else { var cm__20 any; var tmp176 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp176 = A_arbace_a2g_reach_A_const_24; cm__20 = lang.IFn_Cast(jrt.NN(tmp176).GetRawRoot__O()).Invoke_O__O(seq_214000315__19)
														var tmp177 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp177 = A_arbace_a2g_reach_A_const_148; var tmp178 lang.IFn = lang.IFn_Cast(jrt.NN(tmp177).GetRawRoot__O()); var tmp179 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp179 = A_arbace_a2g_reach_A_const_41; if jrt.A2g_Truth(tmp178.Invoke_O__O(jrt.NN(tmp179).Invoke_O__O(cm__20))) {
															var tmp180 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp180 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp180).GetRawRoot__O()).Invoke_O_O_O__O(Lit_247, Lit_294, Lit_295)
															var tmp181 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp181 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp181).GetRawRoot__O()).Invoke_O_O_O__O(Lit_247, Lit_296, Lit_297)
															var tmp182 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp182 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp182).GetRawRoot__O()).Invoke_O_O_O__O(Lit_247, Lit_298, Lit_299) }
//line :394:1
														var tmp183 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp183 = A_arbace_a2g_reach_A_const_28; seq_214000315__14, chunk_214000316__15, count_214000317__16, i_214000318__17 = lang.IFn_Cast(jrt.NN(tmp183).GetRawRoot__O()).Invoke_O__O(seq_214000315__19), nil, 0, 0; continue L11 } } else { tmp6 = nil } }
//line :389:1
												break L11 }; break L7 }; default:}; tmp6 = nil} } else {
//line :387:1
													var tmp184 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp184 = A_arbace_a2g_reach_A_const_31; if tmp184 != nil { var seq_214000319__13 any; var tmp185 *lang.Var
















														A_arbace_a2g_reach_A_Init(); tmp185 = A_arbace_a2g_reach_A_const_20; var tmp186 lang.IFn = lang.IFn_Cast(jrt.NN(tmp185).GetRawRoot__O()); var tmp187 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp187 = A_arbace_a2g_reach_A_const_222; seq_214000319__13 = tmp186.Invoke_O__O(lang.IFn_Cast(jrt.NN(tmp187).GetRawRoot__O()).Invoke_O__O(k__6))
//line :387:1
														var chunk_214000320__14 any; var count_214000321__15 int64 = 0; var i_214000322__16 int64 = 0; L12: for {
















															if lang.Numbers_Lt_J_J__Z(i_214000322__16, count_214000321__15) { var nd__17_2 any = lang.Indexed_Cast(chunk_214000320__14).Nth_I__O(lang.RT_IntCast_J__I(i_214000322__16)); var tmp188 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp188 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp188).GetRawRoot__O()).Invoke_O__O(nd__17_2); seq_214000319__13, chunk_214000320__14, count_214000321__15, i_214000322__16 = seq_214000319__13, chunk_214000320__14, count_214000321__15, lang.Numbers_Unchecked_inc_J__J(i_214000322__16); continue L12 } else { var temp__1927000414__auto____17_3 any; var tmp189 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp189 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____17_3 = lang.IFn_Cast(jrt.NN(tmp189).GetRawRoot__O()).Invoke_O__O(seq_214000319__13); if jrt.A2g_Truth(temp__1927000414__auto____17_3) { var seq_214000319__18 any = temp__1927000414__auto____17_3; var tmp190 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp190 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp190).GetRawRoot__O()).Invoke_O__O(seq_214000319__18)) { var c__1927000678__auto____19_3 any; var tmp191 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp191 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____19_3 = lang.IFn_Cast(jrt.NN(tmp191).GetRawRoot__O()).Invoke_O__O(seq_214000319__18); var tmp192 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp192 = A_arbace_a2g_reach_A_const_26; seq_214000319__13, chunk_214000320__14, count_214000321__15, i_214000322__16 = lang.IFn_Cast(jrt.NN(tmp192).GetRawRoot__O()).Invoke_O__O(seq_214000319__18), c__1927000678__auto____19_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19_3))), int64(lang.RT_IntCast_J__I(0)); continue L12 } else { var nd__19_2 any; var tmp193 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp193 = A_arbace_a2g_reach_A_const_24; nd__19_2 = lang.IFn_Cast(jrt.NN(tmp193).GetRawRoot__O()).Invoke_O__O(seq_214000319__18); var tmp194 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp194 = A_arbace_a2g_reach_A_const_215; lang.IFn_Cast(jrt.NN(tmp194).GetRawRoot__O()).Invoke_O__O(nd__19_2); var tmp195 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp195 = A_arbace_a2g_reach_A_const_28; seq_214000319__13, chunk_214000320__14, count_214000321__15, i_214000322__16 = lang.IFn_Cast(jrt.NN(tmp195).GetRawRoot__O()).Invoke_O__O(seq_214000319__18), nil, 0, 0; continue L12 } } else { tmp6 = nil } }
//line :387:1
															break L12 } } else { tmp6 = nil } }} }; return nil }(); var tmp197 /*line :367:1*/*lang.Var;
	A_arbace_a2g_reach_A_Init(); tmp197 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp197).GetRawRoot__O()).Invoke__O(); if /*line :367:1*/ tmp196 != nil { panic(tmp196) }; return tmp6 }






































func A_arbace_a2g_reach_run_A_New() *A_arbace_a2g_reach_run_A { A_arbace_a2g_reach_run_A_Init(); t := &A_arbace_a2g_reach_run_A{}; t.Ctor(); return t }
//line :406:1
func (t *A_arbace_a2g_reach_run_A) Ctor() {}
//line :406:1
func (t *A_arbace_a2g_reach_run_A) Invoke_O_O__O(self, p__214000324__0 any) any { var map__214000325__2 any = p__214000324__0; var map__214000325__3 any; if lang.ISeq_InstanceOf(map__214000325__2) { var tmp1 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp1 = A_arbace_a2g_reach_A_const_28; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(map__214000325__2)) { var tmp2 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_124; map__214000325__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(map__214000325__2), jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp3 = A_arbace_a2g_reach_A_const_20; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()).Invoke_O__O(map__214000325__2)) { var tmp4 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp4 = A_arbace_a2g_reach_A_const_24; map__214000325__3 = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke_O__O(map__214000325__2) } else { lang.PersistentArrayMap_Init(); map__214000325__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000325__3 = map__214000325__2 }; var roots__4 any; var tmp5 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_223; roots__4 = lang.RT_Get_O_O__O(map__214000325__3, tmp5.Ref()); var instantiate__5 any; var tmp6 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_224; instantiate__5 = lang.RT_Get_O_O__O(map__214000325__3, tmp6.Ref()); var classes__6 any; var tmp7 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_170; classes__6 = lang.RT_Get_O_O__O(map__214000325__3, tmp7.Ref()); var slice_QMARK___7 any; var tmp8 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_225; slice_QMARK___7 = lang.RT_Get_O_O__O(map__214000325__3, tmp8.Ref()); var fis__8 any; var tmp9 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_226; fis__8 = lang.RT_Get_O_O__O(map__214000325__3, tmp9.Ref()); var state__9 any; var tmp10 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_86; state__9 = lang.RT_Get_O_O__O(map__214000325__3, tmp10.Ref()); var st__10 any; var or__1927000174__auto____10 any = state__9; if






	jrt.A2g_Truth(or__1927000174__auto____10) { st__10 = or__1927000174__auto____10 } else { var tmp11 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_88; var tmp12 any = tmp11.Ref(); var tmp13 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_227; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp15 = lang.PersistentHashSet_EMPTY; var tmp16 any = tmp14.Invoke_O__O(tmp15.Ref()); var tmp17 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_97; var tmp18 any = tmp17.Ref(); var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_227; var tmp20 lang.IFn = lang.IFn_Cast(jrt.NN(tmp19).GetRawRoot__O()); var tmp21 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp21 = lang.PersistentHashSet_EMPTY; var tmp22 any = tmp20.Invoke_O__O(tmp21.Ref()); var tmp23 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp23 = A_arbace_a2g_reach_A_const_98; var tmp24 any = tmp23.Ref(); var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_227; var tmp26 lang.IFn = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()); var tmp27 *lang.PersistentVector; lang.PersistentVector_Init(); tmp27 = lang.PersistentVector_EMPTY; var tmp28 any = tmp26.Invoke_O__O(tmp27.Ref()); var tmp29 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_106; var tmp30 any = tmp29.Ref(); var tmp31 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_227; var tmp32 lang.IFn = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()); var tmp33 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp33 = lang.PersistentHashSet_EMPTY; var tmp34 any = tmp32.Invoke_O__O(tmp33.Ref()); var tmp35 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_112; var tmp36 any = tmp35.Ref(); var tmp37 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_227; var tmp38 lang.IFn = lang.IFn_Cast(jrt.NN(tmp37).GetRawRoot__O()); var tmp39 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp39 = lang.PersistentHashSet_EMPTY; var tmp40 any = tmp38.Invoke_O__O(tmp39.Ref()); var tmp41 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_104; var tmp42 any = tmp41.Ref(); var tmp43 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp43 = A_arbace_a2g_reach_A_const_227; var tmp44 lang.IFn = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()); var tmp45 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp45 = lang.PersistentArrayMap_EMPTY; var tmp46 any = tmp44.Invoke_O__O(tmp45.Ref()); var tmp47 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp47 = A_arbace_a2g_reach_A_const_107; var tmp48 any = tmp47.Ref(); var tmp49 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp49 = A_arbace_a2g_reach_A_const_227; var tmp50 lang.IFn = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()); var tmp51 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp51 = lang.PersistentArrayMap_EMPTY; var tmp52 any = tmp50.Invoke_O__O(tmp51.Ref()); var tmp53 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp53 = A_arbace_a2g_reach_A_const_100; var tmp54 any = tmp53.Ref(); var tmp55 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp55 = A_arbace_a2g_reach_A_const_227; var tmp56 lang.IFn = lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()); var tmp57 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp57 = lang.PersistentHashSet_EMPTY; var tmp58 any = tmp56.Invoke_O__O(tmp57.Ref()); var tmp59 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp59 = A_arbace_a2g_reach_A_const_61; var tmp60 any = tmp59.Ref(); var tmp61 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp61 = A_arbace_a2g_reach_A_const_227; var tmp62 lang.IFn = lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()); var tmp63 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp63 = lang.PersistentArrayMap_EMPTY; var tmp64 any = tmp62.Invoke_O__O(tmp63.Ref()); var tmp65 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp65 = A_arbace_a2g_reach_A_const_94; var tmp66 any = tmp65.Ref(); var tmp67 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp67 = A_arbace_a2g_reach_A_const_227; var tmp68 lang.IFn = lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()); var tmp69 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp69 = lang.PersistentArrayMap_EMPTY; var tmp70 any = tmp68.Invoke_O__O(tmp69.Ref()); var tmp71 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp71 = A_arbace_a2g_reach_A_const_82; var tmp72 any = tmp71.Ref(); var tmp73 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp73 = A_arbace_a2g_reach_A_const_227; var tmp74 lang.IFn = lang.IFn_Cast(jrt.NN(tmp73).GetRawRoot__O()); var tmp75 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp75 = lang.PersistentArrayMap_EMPTY; var tmp76 any = tmp74.Invoke_O__O(tmp75.Ref()); var tmp77 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp77 = A_arbace_a2g_reach_A_const_114; var tmp78 any = tmp77.Ref(); var tmp79 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp79 = A_arbace_a2g_reach_A_const_227; var tmp80 lang.IFn = lang.IFn_Cast(jrt.NN(tmp79).GetRawRoot__O()); var tmp81 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp81 = lang.PersistentHashSet_EMPTY; st__10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp12, tmp16, tmp18, tmp22, tmp24, tmp28, tmp30, tmp34, tmp36, tmp40, tmp42, tmp46, tmp48, tmp52, tmp54, tmp58, tmp60, tmp64, tmp66, tmp70, tmp72, tmp76, tmp78, tmp80.Invoke_O__O(tmp81.Ref()))) }; var tmp82 /*line :418:1*/*lang.Var; A_arbace_a2g_reach_A_Init(); tmp82 = A_arbace_a2g_reach_A_const_89; var tmp83 lang.IFn = lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()); var tmp84 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp84 = A_arbace_a2g_reach_A_const_90; var tmp85 lang.IFn = lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()); var tmp86 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp86 = A_arbace_a2g_reach_A_const_62; var tmp87 any = tmp86.Ref(); var tmp88 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp88 = A_arbace_a2g_reach_A_const_85; var tmp89 any = tmp88.Ref(); var tmp90 any; var or__1927000174__auto____11 any = slice_QMARK___7; if
	jrt.A2g_Truth(or__1927000174__auto____11) { tmp90 = or__1927000174__auto____11 } else { var tmp91 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp91 = A_arbace_a2g_reach_A_const_233; var tmp92 lang.IFn = lang.IFn_Cast(jrt.NN(tmp91).GetRawRoot__O()); var tmp93 *jrt.Boolean; jrt.Boolean_Init(); tmp93 = jrt.Boolean_TRUE; tmp90 = tmp92.Invoke_O__O(tmp93.Ref()) }; var tmp94 any = tmp90; var tmp95 /*line :418:1*/*lang.Var; A_arbace_a2g_reach_A_Init(); tmp95 = A_arbace_a2g_reach_A_const_68; var tmp96 any = tmp95.Ref(); var tmp97 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp97 = A_arbace_a2g_reach_A_const_87; var tmp98 lang.IFn = lang.IFn_Cast(jrt.NN(tmp97).GetRawRoot__O()); var tmp99 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp99 = A_arbace_a2g_reach_A_const_68; var tmp100 any = jrt.NN(tmp99).Get__O(); var tmp101 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp101 = A_arbace_a2g_reach_A_const_88; var tmp102 any = tmp101.Ref(); var tmp103 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp103 = A_arbace_a2g_reach_A_const_88; tmp83.Invoke_O__O(tmp85.Invoke_O_O_O_O_O_O__O(tmp87, st__10, tmp89, tmp94, tmp96, tmp98.Invoke_O_O_O__O(tmp100, tmp102, jrt.NN(tmp103).Invoke_O__O(st__10)))); var tmp104 any = A_arbace_a2g_reach_run_fn__214000327_A_New_O_O_O_O_O(classes__6, instantiate__5, fis__8, roots__4, st__10); var tmp105 *jrt.Class; A_arbace_a2g_reach_run_fn__214000327_A_Init(); tmp105 = A_arbace_a2g_reach_run_fn__214000327_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp104, tmp105, nil).Invoke__O(); var tmp106 /*line :406:1*/*lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp106 = A_arbace_a2g_reach_A_const_88; var tmp107 any = tmp106.Ref(); var tmp108 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp108 = A_arbace_a2g_reach_A_const_13; var tmp109 lang.IFn = lang.IFn_Cast(jrt.NN(tmp108).GetRawRoot__O()); var tmp110 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp110 = A_arbace_a2g_reach_A_const_88; var tmp111 any = tmp109.Invoke_O__O(jrt.NN(tmp110).Invoke_O__O(st__10)); var tmp112 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp112 = A_arbace_a2g_reach_A_const_97; var tmp113 any = tmp112.Ref(); var tmp114 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp114 = A_arbace_a2g_reach_A_const_13; var tmp115 lang.IFn = lang.IFn_Cast(jrt.NN(tmp114).GetRawRoot__O()); var tmp116 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp116 = A_arbace_a2g_reach_A_const_97; var tmp117 any = tmp115.Invoke_O__O(jrt.NN(tmp116).Invoke_O__O(st__10)); var tmp118 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp118 = A_arbace_a2g_reach_A_const_106; var tmp119 any = tmp118.Ref(); var tmp120 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp120 = A_arbace_a2g_reach_A_const_13; var tmp121 lang.IFn = lang.IFn_Cast(jrt.NN(tmp120).GetRawRoot__O()); var tmp122 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp122 = A_arbace_a2g_reach_A_const_106; var tmp123 any = tmp121.Invoke_O__O(jrt.NN(tmp122).Invoke_O__O(st__10)); var tmp124 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp124 = A_arbace_a2g_reach_A_const_61; var tmp125 any = tmp124.Ref(); var tmp126 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp126 = A_arbace_a2g_reach_A_const_13; var tmp127 lang.IFn = lang.IFn_Cast(jrt.NN(tmp126).GetRawRoot__O()); var tmp128 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp128 = A_arbace_a2g_reach_A_const_61; var tmp129 any = tmp127.Invoke_O__O(jrt.NN(tmp128).Invoke_O__O(st__10)); var tmp130 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp130 = A_arbace_a2g_reach_A_const_94; var tmp131 any = tmp130.Ref(); var tmp132 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp132 = A_arbace_a2g_reach_A_const_13; var tmp133 lang.IFn = lang.IFn_Cast(jrt.NN(tmp132).GetRawRoot__O()); var tmp134 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp134 = A_arbace_a2g_reach_A_const_94; var tmp135 any = tmp133.Invoke_O__O(jrt.NN(tmp134).Invoke_O__O(st__10)); var tmp136 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp136 = A_arbace_a2g_reach_A_const_82; var tmp137 any = tmp136.Ref(); var tmp138 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp138 = A_arbace_a2g_reach_A_const_13; var tmp139 lang.IFn = lang.IFn_Cast(jrt.NN(tmp138).GetRawRoot__O()); var tmp140 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp140 = A_arbace_a2g_reach_A_const_82; var tmp141 any = tmp139.Invoke_O__O(jrt.NN(tmp140).Invoke_O__O(st__10)); var tmp142 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp142 = A_arbace_a2g_reach_A_const_112; var tmp143 any = tmp142.Ref(); var tmp144 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp144 = A_arbace_a2g_reach_A_const_13; var tmp145 lang.IFn = lang.IFn_Cast(jrt.NN(tmp144).GetRawRoot__O()); var tmp146 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp146 = A_arbace_a2g_reach_A_const_112; var tmp147 any = tmp145.Invoke_O__O(jrt.NN(tmp146).Invoke_O__O(st__10)); var tmp148 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp148 = A_arbace_a2g_reach_A_const_86; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp107, tmp111, tmp113, tmp117, tmp119, tmp123, tmp125, tmp129, tmp131, tmp135, tmp137, tmp141, tmp143, tmp147, tmp148.Ref(), st__10)) }











func A_arbace_a2g_reach_run_fn__214000327_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_reach_run_fn__214000327_A { A_arbace_a2g_reach_run_fn__214000327_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000327_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :418:1
func (t *A_arbace_a2g_reach_run_fn__214000327_A) Ctor_O_O_O_O_O(c__classes, c__instantiate, c__fis, c__roots, c__st any) { t.F_classes = c__classes; t.F_instantiate = c__instantiate; t.F_fis = c__fis; t.F_roots = c__roots; t.F_st = c__st }
//line :418:1
func (t *A_arbace_a2g_reach_run_fn__214000327_A) Invoke_O__O(self any) any { for { var tmp1 any; tmp83 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_214000328__3 any; var tmp2 *lang.Var


	A_arbace_a2g_reach_A_Init(); tmp2 = A_arbace_a2g_reach_A_const_20; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any; var t_ any = t.F_classes; t.F_classes = nil; tmp4 = t_; seq_214000328__3 = tmp3.Invoke_O__O(tmp4)
//line :418:1
	var chunk_214000329__4 any; var count_214000330__5 int64 = 0; var i_214000331__6 int64 = 0; L2: for {


		if lang.Numbers_Lt_J_J__Z(i_214000331__6, count_214000330__5) { var c__7 any = lang.Indexed_Cast(chunk_214000329__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000331__6)); var tmp5 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp5 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()).Invoke_O__O(c__7); seq_214000328__3, chunk_214000329__4, count_214000330__5, i_214000331__6 = seq_214000328__3, chunk_214000329__4, count_214000330__5, lang.Numbers_Unchecked_inc_J__J(i_214000331__6); continue L2 } else { var temp__1927000414__auto____7 any; var tmp6 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp6 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____7 = lang.IFn_Cast(jrt.NN(tmp6).GetRawRoot__O()).Invoke_O__O(seq_214000328__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_214000328__8 any = temp__1927000414__auto____7; var tmp7 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp7 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()).Invoke_O__O(seq_214000328__8)) { var c__1927000678__auto____9 any; var tmp8 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp8 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____9 = lang.IFn_Cast(jrt.NN(tmp8).GetRawRoot__O()).Invoke_O__O(seq_214000328__8); var tmp9 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp9 = A_arbace_a2g_reach_A_const_26; seq_214000328__3, chunk_214000329__4, count_214000330__5, i_214000331__6 = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()).Invoke_O__O(seq_214000328__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var c__9 any; var tmp10 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp10 = A_arbace_a2g_reach_A_const_24; c__9 = lang.IFn_Cast(jrt.NN(tmp10).GetRawRoot__O()).Invoke_O__O(seq_214000328__8); var tmp11 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp11 = A_arbace_a2g_reach_A_const_79; lang.IFn_Cast(jrt.NN(tmp11).GetRawRoot__O()).Invoke_O__O(c__9); var tmp12 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp12 = A_arbace_a2g_reach_A_const_28; seq_214000328__3, chunk_214000329__4, count_214000330__5, i_214000331__6 = lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke_O__O(seq_214000328__8), nil, 0, 0; continue L2 } } }
//line :418:1
		break L2 }; var seq_214000332__3 any; var tmp13 *lang.Var



	A_arbace_a2g_reach_A_Init(); tmp13 = A_arbace_a2g_reach_A_const_20; var tmp14 lang.IFn = lang.IFn_Cast(jrt.NN(tmp13).GetRawRoot__O()); var tmp15 any; var t__2 any = t.F_roots; t.F_roots = nil; tmp15 = t__2; seq_214000332__3 = tmp14.Invoke_O__O(tmp15)
//line :418:1
	var chunk_214000333__4 any; var count_214000334__5 int64 = 0; var i_214000335__6 int64 = 0; L3: for {



		if lang.Numbers_Lt_J_J__Z(i_214000335__6, count_214000334__5) { var vec__214000336__7 any = lang.Indexed_Cast(chunk_214000333__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000335__6)); var c__8 any = lang.RT_Nth_O_I_O__O(vec__214000336__7, lang.RT_IntCast_J__I(0), nil); var name__9 any = lang.RT_Nth_O_I_O__O(vec__214000336__7, lang.RT_IntCast_J__I(1), nil); var desc__10 any = lang.RT_Nth_O_I_O__O(vec__214000336__7, lang.RT_IntCast_J__I(2), nil); var k__11 any = vec__214000336__7; var tmp16 *lang.Var
			A_arbace_a2g_reach_A_Init(); tmp16 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp16).GetRawRoot__O()).Invoke_O__O(c__8)) {
				var tmp17 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp17 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp17).GetRawRoot__O()).Invoke_O__O(k__11)

				var tmp18 any; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z(Lit_241, name__9); if and__1927000168__auto____12 { var tmp19 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp19 = A_arbace_a2g_reach_A_const_85; tmp18 = lang.IFn_Cast(jrt.NN(tmp19).Get__O()).Invoke_O__O(c__8) } else { tmp18 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() }; if jrt.A2g_Truth(tmp18) { var tmp20 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp20 = A_arbace_a2g_reach_A_const_162; lang.IFn_Cast(jrt.NN(tmp20).GetRawRoot__O()).Invoke_O__O(c__8)
				}



				var tmp21 any; A_arbace_a2g_reach_A_Init(); tmp21 = A_arbace_a2g_reach_A_const_228; if jrt.A2g_Truth(lang.IFn_Cast(tmp21).Invoke_O__O(name__9)) { } else { var temp__1927000414__auto____12 any; var tmp22 *lang.Var
					A_arbace_a2g_reach_A_Init(); tmp22 = A_arbace_a2g_reach_A_const_206; temp__1927000414__auto____12 = lang.IFn_Cast(jrt.NN(tmp22).GetRawRoot__O()).Invoke_O_O_O__O(c__8, name__9, desc__10); if jrt.A2g_Truth(temp__1927000414__auto____12) { var mm__13 any = temp__1927000414__auto____12; var tmp23 any; var or__1927000174__auto____14 any; var tmp24 *lang.Var
						A_arbace_a2g_reach_A_Init(); tmp24 = A_arbace_a2g_reach_A_const_45; or__1927000174__auto____14 = lang.IFn_Cast(jrt.NN(tmp24).GetRawRoot__O()).Invoke_O__O(mm__13); if jrt.A2g_Truth(or__1927000174__auto____14) { tmp23 = or__1927000174__auto____14 } else { var tmp25 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp25 = A_arbace_a2g_reach_A_const_46; tmp23 = lang.IFn_Cast(jrt.NN(tmp25).GetRawRoot__O()).Invoke_O__O(mm__13) }; if jrt.A2g_Truth(tmp23) { } else {
							var tmp26 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp26 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp26).GetRawRoot__O()).Invoke_O_O_O__O(c__8, name__9, desc__10) } } } }
//line :422:1
			seq_214000332__3, chunk_214000333__4, count_214000334__5, i_214000335__6 = seq_214000332__3, chunk_214000333__4, count_214000334__5, lang.Numbers_Unchecked_inc_J__J(i_214000335__6); continue L3 } else { var temp__1927000414__auto____7_2 any; var tmp27 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp27 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____7_2 = lang.IFn_Cast(jrt.NN(tmp27).GetRawRoot__O()).Invoke_O__O(seq_214000332__3); if jrt.A2g_Truth(temp__1927000414__auto____7_2) { var seq_214000332__8 any = temp__1927000414__auto____7_2; var tmp28 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp28 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp28).GetRawRoot__O()).Invoke_O__O(seq_214000332__8)) { var c__1927000678__auto____9_2 any; var tmp29 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp29 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____9_2 = lang.IFn_Cast(jrt.NN(tmp29).GetRawRoot__O()).Invoke_O__O(seq_214000332__8); var tmp30 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp30 = A_arbace_a2g_reach_A_const_26; seq_214000332__3, chunk_214000333__4, count_214000334__5, i_214000335__6 = lang.IFn_Cast(jrt.NN(tmp30).GetRawRoot__O()).Invoke_O__O(seq_214000332__8), c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__214000339__9 any; var tmp31 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp31 = A_arbace_a2g_reach_A_const_24; vec__214000339__9 = lang.IFn_Cast(jrt.NN(tmp31).GetRawRoot__O()).Invoke_O__O(seq_214000332__8); var c__10 any = lang.RT_Nth_O_I_O__O(vec__214000339__9, lang.RT_IntCast_J__I(0), nil); var name__11 any = lang.RT_Nth_O_I_O__O(vec__214000339__9, lang.RT_IntCast_J__I(1), nil); var desc__12 any = lang.RT_Nth_O_I_O__O(vec__214000339__9, lang.RT_IntCast_J__I(2), nil); var k__13 any = vec__214000339__9; var tmp32 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp32 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp32).GetRawRoot__O()).Invoke_O__O(c__10)) {
					var tmp33 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp33 = A_arbace_a2g_reach_A_const_99; lang.IFn_Cast(jrt.NN(tmp33).GetRawRoot__O()).Invoke_O__O(k__13)

					var tmp34 any; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z(Lit_241, name__11); if and__1927000168__auto____14 { var tmp35 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp35 = A_arbace_a2g_reach_A_const_85; tmp34 = lang.IFn_Cast(jrt.NN(tmp35).Get__O()).Invoke_O__O(c__10) } else { tmp34 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() }; if jrt.A2g_Truth(tmp34) { var tmp36 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp36 = A_arbace_a2g_reach_A_const_162; lang.IFn_Cast(jrt.NN(tmp36).GetRawRoot__O()).Invoke_O__O(c__10)
					}



					var tmp37 any; A_arbace_a2g_reach_A_Init(); tmp37 = A_arbace_a2g_reach_A_const_229; if jrt.A2g_Truth(lang.IFn_Cast(tmp37).Invoke_O__O(name__11)) { } else { var temp__1927000414__auto____14 any; var tmp38 *lang.Var
						A_arbace_a2g_reach_A_Init(); tmp38 = A_arbace_a2g_reach_A_const_206; temp__1927000414__auto____14 = lang.IFn_Cast(jrt.NN(tmp38).GetRawRoot__O()).Invoke_O_O_O__O(c__10, name__11, desc__12); if jrt.A2g_Truth(temp__1927000414__auto____14) { var mm__15 any = temp__1927000414__auto____14; var tmp39 any; var or__1927000174__auto____16 any; var tmp40 *lang.Var
							A_arbace_a2g_reach_A_Init(); tmp40 = A_arbace_a2g_reach_A_const_45; or__1927000174__auto____16 = lang.IFn_Cast(jrt.NN(tmp40).GetRawRoot__O()).Invoke_O__O(mm__15); if jrt.A2g_Truth(or__1927000174__auto____16) { tmp39 = or__1927000174__auto____16 } else { var tmp41 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp41 = A_arbace_a2g_reach_A_const_46; tmp39 = lang.IFn_Cast(jrt.NN(tmp41).GetRawRoot__O()).Invoke_O__O(mm__15) }; if jrt.A2g_Truth(tmp39) { } else {
								var tmp42 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp42 = A_arbace_a2g_reach_A_const_141; lang.IFn_Cast(jrt.NN(tmp42).GetRawRoot__O()).Invoke_O_O_O__O(c__10, name__11, desc__12) } } } }
//line :422:1
				var tmp43 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp43 = A_arbace_a2g_reach_A_const_28; seq_214000332__3, chunk_214000333__4, count_214000334__5, i_214000335__6 = lang.IFn_Cast(jrt.NN(tmp43).GetRawRoot__O()).Invoke_O__O(seq_214000332__8), nil, 0, 0; continue L3 } } }
//line :418:1
		break L3 }; var seq_214000342__3 any; var tmp44 *lang.Var
















	A_arbace_a2g_reach_A_Init(); tmp44 = A_arbace_a2g_reach_A_const_20; var tmp45 lang.IFn = lang.IFn_Cast(jrt.NN(tmp44).GetRawRoot__O()); var tmp46 any; var t__3 any = t.F_instantiate; t.F_instantiate = nil; tmp46 = t__3; seq_214000342__3 = tmp45.Invoke_O__O(tmp46)
//line :418:1
	var chunk_214000343__4 any; var count_214000344__5 int64 = 0; var i_214000345__6 int64 = 0; L4: for {
















		if lang.Numbers_Lt_J_J__Z(i_214000345__6, count_214000344__5) { var c__7_2 any = lang.Indexed_Cast(chunk_214000343__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000345__6)); var tmp47 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp47 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp47).GetRawRoot__O()).Invoke_O__O(c__7_2)) { var tmp48 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp48 = A_arbace_a2g_reach_A_const_162; lang.IFn_Cast(jrt.NN(tmp48).GetRawRoot__O()).Invoke_O__O(c__7_2) }; seq_214000342__3, chunk_214000343__4, count_214000344__5, i_214000345__6 = seq_214000342__3, chunk_214000343__4, count_214000344__5, lang.Numbers_Unchecked_inc_J__J(i_214000345__6); continue L4 } else { var temp__1927000414__auto____7_3 any; var tmp49 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp49 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____7_3 = lang.IFn_Cast(jrt.NN(tmp49).GetRawRoot__O()).Invoke_O__O(seq_214000342__3); if jrt.A2g_Truth(temp__1927000414__auto____7_3) { var seq_214000342__8 any = temp__1927000414__auto____7_3; var tmp50 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp50 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp50).GetRawRoot__O()).Invoke_O__O(seq_214000342__8)) { var c__1927000678__auto____9_3 any; var tmp51 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp51 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____9_3 = lang.IFn_Cast(jrt.NN(tmp51).GetRawRoot__O()).Invoke_O__O(seq_214000342__8); var tmp52 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp52 = A_arbace_a2g_reach_A_const_26; seq_214000342__3, chunk_214000343__4, count_214000344__5, i_214000345__6 = lang.IFn_Cast(jrt.NN(tmp52).GetRawRoot__O()).Invoke_O__O(seq_214000342__8), c__1927000678__auto____9_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9_3))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var c__9_2 any; var tmp53 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp53 = A_arbace_a2g_reach_A_const_24; c__9_2 = lang.IFn_Cast(jrt.NN(tmp53).GetRawRoot__O()).Invoke_O__O(seq_214000342__8); var tmp54 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp54 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp54).GetRawRoot__O()).Invoke_O__O(c__9_2)) { var tmp55 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp55 = A_arbace_a2g_reach_A_const_162; lang.IFn_Cast(jrt.NN(tmp55).GetRawRoot__O()).Invoke_O__O(c__9_2) }; var tmp56 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp56 = A_arbace_a2g_reach_A_const_28; seq_214000342__3, chunk_214000343__4, count_214000344__5, i_214000345__6 = lang.IFn_Cast(jrt.NN(tmp56).GetRawRoot__O()).Invoke_O__O(seq_214000342__8), nil, 0, 0; continue L4 } } }
//line :418:1
		break L4 }; var seq_214000346__3 any; var tmp57 *lang.Var


















	A_arbace_a2g_reach_A_Init(); tmp57 = A_arbace_a2g_reach_A_const_20; var tmp58 lang.IFn = lang.IFn_Cast(jrt.NN(tmp57).GetRawRoot__O()); var tmp59 any; var t__4 any = t.F_fis; t.F_fis = nil; tmp59 = t__4; seq_214000346__3 = tmp58.Invoke_O__O(tmp59)
//line :418:1
	var chunk_214000347__4 any; var count_214000348__5 int64 = 0; var i_214000349__6 int64 = 0; L5: for {


















		if lang.Numbers_Lt_J_J__Z(i_214000349__6, count_214000348__5) { var fi__7 any = lang.Indexed_Cast(chunk_214000347__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000349__6)); var tmp60 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp60 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp60).GetRawRoot__O()).Invoke_O__O(fi__7)) { var tmp61 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp61 = A_arbace_a2g_reach_A_const_164; lang.IFn_Cast(jrt.NN(tmp61).GetRawRoot__O()).Invoke_O__O(fi__7) }; seq_214000346__3, chunk_214000347__4, count_214000348__5, i_214000349__6 = seq_214000346__3, chunk_214000347__4, count_214000348__5, lang.Numbers_Unchecked_inc_J__J(i_214000349__6); continue L5 } else { var temp__1927000414__auto____7_4 any; var tmp62 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp62 = A_arbace_a2g_reach_A_const_20; temp__1927000414__auto____7_4 = lang.IFn_Cast(jrt.NN(tmp62).GetRawRoot__O()).Invoke_O__O(seq_214000346__3); if jrt.A2g_Truth(temp__1927000414__auto____7_4) { var seq_214000346__8 any = temp__1927000414__auto____7_4; var tmp63 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp63 = A_arbace_a2g_reach_A_const_22; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp63).GetRawRoot__O()).Invoke_O__O(seq_214000346__8)) { var c__1927000678__auto____9_4 any; var tmp64 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp64 = A_arbace_a2g_reach_A_const_23; c__1927000678__auto____9_4 = lang.IFn_Cast(jrt.NN(tmp64).GetRawRoot__O()).Invoke_O__O(seq_214000346__8); var tmp65 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp65 = A_arbace_a2g_reach_A_const_26; seq_214000346__3, chunk_214000347__4, count_214000348__5, i_214000349__6 = lang.IFn_Cast(jrt.NN(tmp65).GetRawRoot__O()).Invoke_O__O(seq_214000346__8), c__1927000678__auto____9_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9_4))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var fi__9 any; var tmp66 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp66 = A_arbace_a2g_reach_A_const_24; fi__9 = lang.IFn_Cast(jrt.NN(tmp66).GetRawRoot__O()).Invoke_O__O(seq_214000346__8); var tmp67 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp67 = A_arbace_a2g_reach_A_const_79; if jrt.A2g_Truth(lang.IFn_Cast(jrt.NN(tmp67).GetRawRoot__O()).Invoke_O__O(fi__9)) { var tmp68 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp68 = A_arbace_a2g_reach_A_const_164; lang.IFn_Cast(jrt.NN(tmp68).GetRawRoot__O()).Invoke_O__O(fi__9) }; var tmp69 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp69 = A_arbace_a2g_reach_A_const_28; seq_214000346__3, chunk_214000347__4, count_214000348__5, i_214000349__6 = lang.IFn_Cast(jrt.NN(tmp69).GetRawRoot__O()).Invoke_O__O(seq_214000346__8), nil, 0, 0; continue L5 } } }
//line :418:1
		break L5 }; L6: for { var temp__1927000414__auto____3 any; var tmp70 *lang.Var




















			A_arbace_a2g_reach_A_Init(); tmp70 = A_arbace_a2g_reach_A_const_24; var tmp71 lang.IFn = lang.IFn_Cast(jrt.NN(tmp70).GetRawRoot__O()); var tmp72 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp72 = A_arbace_a2g_reach_A_const_13; var tmp73 lang.IFn = lang.IFn_Cast(jrt.NN(tmp72).GetRawRoot__O()); var tmp74 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp74 = A_arbace_a2g_reach_A_const_98; temp__1927000414__auto____3 = tmp71.Invoke_O__O(tmp73.Invoke_O__O(jrt.NN(tmp74).Invoke_O__O(t.F_st))); if jrt.A2g_Truth(temp__1927000414__auto____3) { var k__4 any = temp__1927000414__auto____3; var tmp75 *lang.Var
				A_arbace_a2g_reach_A_Init(); tmp75 = A_arbace_a2g_reach_A_const_60; var tmp76 lang.IFn = lang.IFn_Cast(jrt.NN(tmp75).GetRawRoot__O()); var tmp77 *lang.Keyword; A_arbace_a2g_reach_A_Init(); tmp77 = A_arbace_a2g_reach_A_const_98; var tmp78 any = jrt.NN(tmp77).Invoke_O__O(t.F_st); var tmp79 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp79 = A_arbace_a2g_reach_A_const_231; var tmp80 any = jrt.NN(tmp79).GetRawRoot__O(); var tmp81 any; A_arbace_a2g_reach_A_Init(); tmp81 = A_arbace_a2g_reach_A_const_232; tmp76.Invoke_O_O_O__O(tmp78, tmp80, tmp81)
				var tmp82 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp82 = A_arbace_a2g_reach_A_const_230; lang.IFn_Cast(jrt.NN(tmp82).GetRawRoot__O()).Invoke_O__O(k__4)
				continue L6 } else {
//line :439:1
					tmp1 = nil }
//line :418:1
			break L6 } }; return nil }(); var tmp84 *lang.Var; A_arbace_a2g_reach_A_Init(); tmp84 = A_arbace_a2g_reach_A_const_80; lang.IFn_Cast(jrt.NN(tmp84).GetRawRoot__O()).Invoke__O(); if tmp83 != nil { panic(tmp83) }; return tmp1 }; panic("a2g: unreachable") }







type A_arbace_a2g_reach_A struct{ jrt.Object }

var A_arbace_a2g_reach_A_const_0 *lang.Var

var A_arbace_a2g_reach_A_const_1 *lang.Var

var A_arbace_a2g_reach_A_const_2 any

var A_arbace_a2g_reach_A_const_3 any

var A_arbace_a2g_reach_A_const_4 any

var A_arbace_a2g_reach_A_const_5 any

var A_arbace_a2g_reach_A_const_6 any

var A_arbace_a2g_reach_A_const_7 any

var A_arbace_a2g_reach_A_const_8 any

var A_arbace_a2g_reach_A_const_9 any

var A_arbace_a2g_reach_A_const_10 any

var A_arbace_a2g_reach_A_const_11 any

var A_arbace_a2g_reach_A_const_12 *lang.Var

var A_arbace_a2g_reach_A_const_13 *lang.Var

var A_arbace_a2g_reach_A_const_14 *lang.Var

var A_arbace_a2g_reach_A_const_15 any

var A_arbace_a2g_reach_A_const_16 *lang.Var

var A_arbace_a2g_reach_A_const_17 *lang.Var

var A_arbace_a2g_reach_A_const_18 *lang.Var

var A_arbace_a2g_reach_A_const_19 *lang.Keyword

var A_arbace_a2g_reach_A_const_20 *lang.Var

var A_arbace_a2g_reach_A_const_21 *lang.Var

var A_arbace_a2g_reach_A_const_22 *lang.Var

var A_arbace_a2g_reach_A_const_23 *lang.Var

var A_arbace_a2g_reach_A_const_24 *lang.Var

var A_arbace_a2g_reach_A_const_25 any

var A_arbace_a2g_reach_A_const_26 *lang.Var

var A_arbace_a2g_reach_A_const_27 any

var A_arbace_a2g_reach_A_const_28 *lang.Var

var A_arbace_a2g_reach_A_const_29 *lang.Var

var A_arbace_a2g_reach_A_const_30 *lang.Var

var A_arbace_a2g_reach_A_const_31 *lang.Keyword

var A_arbace_a2g_reach_A_const_32 any

var A_arbace_a2g_reach_A_const_33 any

var A_arbace_a2g_reach_A_const_34 any

var A_arbace_a2g_reach_A_const_35 any

var A_arbace_a2g_reach_A_const_36 *lang.Var

var A_arbace_a2g_reach_A_const_37 *lang.Var

var A_arbace_a2g_reach_A_const_38 *lang.Var

var A_arbace_a2g_reach_A_const_39 *lang.Var

var A_arbace_a2g_reach_A_const_40 *lang.Keyword

var A_arbace_a2g_reach_A_const_41 *lang.Keyword

var A_arbace_a2g_reach_A_const_42 *lang.Keyword

var A_arbace_a2g_reach_A_const_43 *lang.Var

var A_arbace_a2g_reach_A_const_44 *lang.Var

var A_arbace_a2g_reach_A_const_45 *lang.Var

var A_arbace_a2g_reach_A_const_46 *lang.Var

var A_arbace_a2g_reach_A_const_47 *lang.Var

var A_arbace_a2g_reach_A_const_48 *lang.Var

var A_arbace_a2g_reach_A_const_49 *lang.Var

var A_arbace_a2g_reach_A_const_50 *lang.Var

var A_arbace_a2g_reach_A_const_51 *lang.Var

var A_arbace_a2g_reach_A_const_52 *lang.Var

var A_arbace_a2g_reach_A_const_53 *lang.Var

var A_arbace_a2g_reach_A_const_54 *lang.Var

var A_arbace_a2g_reach_A_const_55 *lang.Var

var A_arbace_a2g_reach_A_const_56 *lang.Keyword

var A_arbace_a2g_reach_A_const_57 *lang.Var

var A_arbace_a2g_reach_A_const_58 *lang.Var

var A_arbace_a2g_reach_A_const_59 *lang.Var

var A_arbace_a2g_reach_A_const_60 *lang.Var

var A_arbace_a2g_reach_A_const_61 *lang.Keyword

var A_arbace_a2g_reach_A_const_62 *lang.Var

var A_arbace_a2g_reach_A_const_63 *lang.Var

var A_arbace_a2g_reach_A_const_64 *lang.Var

var A_arbace_a2g_reach_A_const_65 *lang.Var

var A_arbace_a2g_reach_A_const_66 *lang.Var

var A_arbace_a2g_reach_A_const_67 *lang.Keyword

var A_arbace_a2g_reach_A_const_68 *lang.Var

var A_arbace_a2g_reach_A_const_69 *lang.Var

var A_arbace_a2g_reach_A_const_70 *lang.Keyword

var A_arbace_a2g_reach_A_const_71 *lang.Keyword

var A_arbace_a2g_reach_A_const_72 *lang.Var

var A_arbace_a2g_reach_A_const_73 *lang.Keyword

var A_arbace_a2g_reach_A_const_74 *lang.Var

var A_arbace_a2g_reach_A_const_75 *lang.Var

var A_arbace_a2g_reach_A_const_76 *lang.Var

var A_arbace_a2g_reach_A_const_77 *lang.Var

var A_arbace_a2g_reach_A_const_78 *lang.Keyword

var A_arbace_a2g_reach_A_const_79 *lang.Var

var A_arbace_a2g_reach_A_const_80 *lang.Var

var A_arbace_a2g_reach_A_const_81 *lang.Var

var A_arbace_a2g_reach_A_const_82 *lang.Keyword

var A_arbace_a2g_reach_A_const_83 *lang.Var

var A_arbace_a2g_reach_A_const_84 *lang.Keyword

var A_arbace_a2g_reach_A_const_85 *lang.Var

var A_arbace_a2g_reach_A_const_86 *lang.Keyword

var A_arbace_a2g_reach_A_const_87 *lang.Var

var A_arbace_a2g_reach_A_const_88 *lang.Keyword

var A_arbace_a2g_reach_A_const_89 *lang.Var

var A_arbace_a2g_reach_A_const_90 *lang.Var

var A_arbace_a2g_reach_A_const_91 *lang.Var

var A_arbace_a2g_reach_A_const_92 *lang.Keyword

var A_arbace_a2g_reach_A_const_93 *lang.Keyword

var A_arbace_a2g_reach_A_const_94 *lang.Keyword

var A_arbace_a2g_reach_A_const_95 *lang.Var

var A_arbace_a2g_reach_A_const_96 *lang.Var

var A_arbace_a2g_reach_A_const_97 *lang.Keyword

var A_arbace_a2g_reach_A_const_98 *lang.Keyword

var A_arbace_a2g_reach_A_const_99 *lang.Var

var A_arbace_a2g_reach_A_const_100 *lang.Keyword

var A_arbace_a2g_reach_A_const_101 *lang.Var

var A_arbace_a2g_reach_A_const_102 *lang.Var

var A_arbace_a2g_reach_A_const_103 *lang.Var

var A_arbace_a2g_reach_A_const_104 *lang.Keyword

var A_arbace_a2g_reach_A_const_105 *lang.Var

var A_arbace_a2g_reach_A_const_106 *lang.Keyword

var A_arbace_a2g_reach_A_const_107 *lang.Keyword

var A_arbace_a2g_reach_A_const_108 *lang.Var

var A_arbace_a2g_reach_A_const_109 *lang.Var

var A_arbace_a2g_reach_A_const_110 *lang.Var

var A_arbace_a2g_reach_A_const_111 *lang.Var

var A_arbace_a2g_reach_A_const_112 *lang.Keyword

var A_arbace_a2g_reach_A_const_113 *lang.Var

var A_arbace_a2g_reach_A_const_114 *lang.Keyword

var A_arbace_a2g_reach_A_const_115 *lang.Var

var A_arbace_a2g_reach_A_const_116 *lang.Keyword

var A_arbace_a2g_reach_A_const_117 *lang.Var

var A_arbace_a2g_reach_A_const_118 *lang.Var

var A_arbace_a2g_reach_A_const_119 *lang.Var

var A_arbace_a2g_reach_A_const_120 *lang.Keyword

var A_arbace_a2g_reach_A_const_121 *lang.Keyword

var A_arbace_a2g_reach_A_const_122 *lang.Keyword

var A_arbace_a2g_reach_A_const_123 *lang.Keyword

var A_arbace_a2g_reach_A_const_124 *lang.Var

var A_arbace_a2g_reach_A_const_125 *lang.Keyword

var A_arbace_a2g_reach_A_const_126 any

var A_arbace_a2g_reach_A_const_127 *lang.Var

var A_arbace_a2g_reach_A_const_128 *lang.Keyword

var A_arbace_a2g_reach_A_const_129 *lang.Var

var A_arbace_a2g_reach_A_const_130 *lang.Keyword

var A_arbace_a2g_reach_A_const_131 *lang.Keyword

var A_arbace_a2g_reach_A_const_132 *lang.Keyword

var A_arbace_a2g_reach_A_const_133 *lang.Keyword

var A_arbace_a2g_reach_A_const_134 *lang.Var

var A_arbace_a2g_reach_A_const_135 *lang.Keyword

var A_arbace_a2g_reach_A_const_136 *lang.Keyword

var A_arbace_a2g_reach_A_const_137 *lang.Keyword

var A_arbace_a2g_reach_A_const_138 *lang.Keyword

var A_arbace_a2g_reach_A_const_139 *lang.Keyword

var A_arbace_a2g_reach_A_const_140 *lang.Keyword

var A_arbace_a2g_reach_A_const_141 *lang.Var

var A_arbace_a2g_reach_A_const_142 *lang.Keyword

var A_arbace_a2g_reach_A_const_143 *lang.Keyword

var A_arbace_a2g_reach_A_const_144 *lang.Keyword

var A_arbace_a2g_reach_A_const_145 *lang.Keyword

var A_arbace_a2g_reach_A_const_146 *lang.Keyword

var A_arbace_a2g_reach_A_const_147 *lang.Var

var A_arbace_a2g_reach_A_const_148 *lang.Var

var A_arbace_a2g_reach_A_const_149 *lang.Keyword

var A_arbace_a2g_reach_A_const_150 *lang.Keyword

var A_arbace_a2g_reach_A_const_151 *lang.Keyword

var A_arbace_a2g_reach_A_const_152 *lang.Keyword

var A_arbace_a2g_reach_A_const_153 *lang.Keyword

var A_arbace_a2g_reach_A_const_154 *lang.Var

var A_arbace_a2g_reach_A_const_155 *lang.Var

var A_arbace_a2g_reach_A_const_156 *lang.Keyword

var A_arbace_a2g_reach_A_const_157 *lang.Keyword

var A_arbace_a2g_reach_A_const_158 *lang.Keyword

var A_arbace_a2g_reach_A_const_159 *lang.Keyword

var A_arbace_a2g_reach_A_const_160 *lang.Keyword

var A_arbace_a2g_reach_A_const_161 *lang.Keyword

var A_arbace_a2g_reach_A_const_162 *lang.Var

var A_arbace_a2g_reach_A_const_163 *lang.Keyword

var A_arbace_a2g_reach_A_const_164 *lang.Var

var A_arbace_a2g_reach_A_const_165 *lang.Keyword

var A_arbace_a2g_reach_A_const_166 *lang.Keyword

var A_arbace_a2g_reach_A_const_167 *lang.Var

var A_arbace_a2g_reach_A_const_168 *lang.Keyword

var A_arbace_a2g_reach_A_const_169 *lang.Keyword

var A_arbace_a2g_reach_A_const_170 *lang.Keyword

var A_arbace_a2g_reach_A_const_171 *lang.Keyword

var A_arbace_a2g_reach_A_const_172 *lang.Keyword

var A_arbace_a2g_reach_A_const_173 *lang.Keyword

var A_arbace_a2g_reach_A_const_174 *lang.Keyword

var A_arbace_a2g_reach_A_const_175 *lang.Var

var A_arbace_a2g_reach_A_const_176 *lang.Keyword

var A_arbace_a2g_reach_A_const_177 *lang.Var

var A_arbace_a2g_reach_A_const_178 *lang.Var

var A_arbace_a2g_reach_A_const_179 *lang.Keyword

var A_arbace_a2g_reach_A_const_180 *lang.Var

var A_arbace_a2g_reach_A_const_181 *lang.Keyword

var A_arbace_a2g_reach_A_const_182 *lang.Keyword

var A_arbace_a2g_reach_A_const_183 *lang.Keyword

var A_arbace_a2g_reach_A_const_184 *lang.Keyword

var A_arbace_a2g_reach_A_const_185 *lang.Keyword

var A_arbace_a2g_reach_A_const_186 *lang.Keyword

var A_arbace_a2g_reach_A_const_187 *lang.Var

var A_arbace_a2g_reach_A_const_188 *lang.Keyword

var A_arbace_a2g_reach_A_const_189 *lang.Var

var A_arbace_a2g_reach_A_const_190 *lang.Keyword

var A_arbace_a2g_reach_A_const_191 *lang.Keyword

var A_arbace_a2g_reach_A_const_192 *lang.Var

var A_arbace_a2g_reach_A_const_193 *lang.Var

var A_arbace_a2g_reach_A_const_194 *lang.Keyword

var A_arbace_a2g_reach_A_const_195 *lang.Keyword

var A_arbace_a2g_reach_A_const_196 *lang.Keyword

var A_arbace_a2g_reach_A_const_197 *lang.Keyword

var A_arbace_a2g_reach_A_const_198 *lang.Var

var A_arbace_a2g_reach_A_const_199 *lang.Keyword

var A_arbace_a2g_reach_A_const_200 *lang.Keyword

var A_arbace_a2g_reach_A_const_201 *lang.Keyword

var A_arbace_a2g_reach_A_const_202 *lang.Keyword

var A_arbace_a2g_reach_A_const_203 *lang.Keyword

var A_arbace_a2g_reach_A_const_204 *lang.Keyword

var A_arbace_a2g_reach_A_const_205 *lang.Keyword

var A_arbace_a2g_reach_A_const_206 *lang.Var

var A_arbace_a2g_reach_A_const_207 *lang.Keyword

var A_arbace_a2g_reach_A_const_208 *lang.Keyword

var A_arbace_a2g_reach_A_const_209 *lang.Keyword

var A_arbace_a2g_reach_A_const_210 *lang.Keyword

var A_arbace_a2g_reach_A_const_211 *lang.Keyword

var A_arbace_a2g_reach_A_const_212 *lang.Keyword

var A_arbace_a2g_reach_A_const_213 *lang.Keyword

var A_arbace_a2g_reach_A_const_214 *lang.Keyword

var A_arbace_a2g_reach_A_const_215 *lang.Var

var A_arbace_a2g_reach_A_const_216 *lang.Keyword

var A_arbace_a2g_reach_A_const_217 *lang.Keyword

var A_arbace_a2g_reach_A_const_218 *lang.Keyword

var A_arbace_a2g_reach_A_const_219 *lang.Var

var A_arbace_a2g_reach_A_const_220 *lang.Keyword

var A_arbace_a2g_reach_A_const_221 *lang.Keyword

var A_arbace_a2g_reach_A_const_222 *lang.Var

var A_arbace_a2g_reach_A_const_223 *lang.Keyword

var A_arbace_a2g_reach_A_const_224 *lang.Keyword

var A_arbace_a2g_reach_A_const_225 *lang.Keyword

var A_arbace_a2g_reach_A_const_226 *lang.Keyword

var A_arbace_a2g_reach_A_const_227 *lang.Var

var A_arbace_a2g_reach_A_const_228 any

var A_arbace_a2g_reach_A_const_229 any

var A_arbace_a2g_reach_A_const_230 *lang.Var

var A_arbace_a2g_reach_A_const_231 *lang.Var

var A_arbace_a2g_reach_A_const_232 any

var A_arbace_a2g_reach_A_const_233 *lang.Var

var A_arbace_a2g_reach_A_init jrt.ClassInit

func A_arbace_a2g_reach_A_Init() { if !A_arbace_a2g_reach_A_init.Done() { A_arbace_a2g_reach_A_init.Run(A_arbace_a2g_reach_A_clinit) } }

func A_arbace_a2g_reach_A_clinit() { A_arbace_a2g_reach_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_a2g_reach_A_const_1 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_a2g_reach_A_const_2 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_a2g_reach_A_const_3 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_3).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_5).Ref()); A_arbace_a2g_reach_A_const_4 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_6).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_7).Ref()); A_arbace_a2g_reach_A_const_5 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_8).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_9).Ref()); A_arbace_a2g_reach_A_const_6 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_10).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_11).Ref()); A_arbace_a2g_reach_A_const_7 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_13).Ref()); A_arbace_a2g_reach_A_const_8 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_14).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_15).Ref()); A_arbace_a2g_reach_A_const_9 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_16).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_17).Ref()); A_arbace_a2g_reach_A_const_10 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_18).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_19).Ref()); A_arbace_a2g_reach_A_const_11 = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_4).Ref(), lang.Symbol_Intern_String_String__Symbol(nil, Lit_21).Ref()); A_arbace_a2g_reach_A_const_12 = lang.RT_Var_String_String__Var(Lit_0, Lit_22); A_arbace_a2g_reach_A_const_13 = lang.RT_Var_String_String__Var(Lit_0, Lit_23); A_arbace_a2g_reach_A_const_14 = lang.RT_Var_String_String__Var(Lit_0, Lit_24); A_arbace_a2g_reach_A_const_15 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_25)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(), Lit_27))); A_arbace_a2g_reach_A_const_16 = lang.RT_Var_String_String__Var(Lit_0, Lit_28); A_arbace_a2g_reach_A_const_17 = lang.RT_Var_String_String__Var(Lit_0, Lit_29); A_arbace_a2g_reach_A_const_18 = lang.RT_Var_String_String__Var(Lit_0, Lit_30); A_arbace_a2g_reach_A_const_19 = lang.RT_Keyword_String_String__Keyword(nil, Lit_31); A_arbace_a2g_reach_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_32); A_arbace_a2g_reach_A_const_21 = lang.RT_Var_String_String__Var(Lit_0, Lit_33); A_arbace_a2g_reach_A_const_22 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_a2g_reach_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_a2g_reach_A_const_24 = lang.RT_Var_String_String__Var(Lit_0, Lit_36); A_arbace_a2g_reach_A_const_25 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref())).Ref(); A_arbace_a2g_reach_A_const_26 = lang.RT_Var_String_String__Var(Lit_0, Lit_50); A_arbace_a2g_reach_A_const_27 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_38).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_39).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_41).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_42).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_43).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_45).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_47).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_49).Ref())).Ref(); A_arbace_a2g_reach_A_const_28 = lang.RT_Var_String_String__Var(Lit_0, Lit_51); A_arbace_a2g_reach_A_const_29 = lang.RT_Var_String_String__Var(Lit_25, Lit_52); A_arbace_a2g_reach_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_53); A_arbace_a2g_reach_A_const_31 = lang.RT_Keyword_String_String__Keyword(nil, Lit_54); A_arbace_a2g_reach_A_const_32 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref())).Ref(); A_arbace_a2g_reach_A_const_33 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_56).Ref())).Ref(); A_arbace_a2g_reach_A_const_34 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_37).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_40).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_44).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_55).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_48).Ref())).Ref(); A_arbace_a2g_reach_A_const_35 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_56).Ref())).Ref(); A_arbace_a2g_reach_A_const_36 = lang.RT_Var_String_String__Var(Lit_0, Lit_57); A_arbace_a2g_reach_A_const_37 = lang.RT_Var_String_String__Var(Lit_0, Lit_58); A_arbace_a2g_reach_A_const_38 = lang.RT_Var_String_String__Var(Lit_0, Lit_59); A_arbace_a2g_reach_A_const_39 = lang.RT_Var_String_String__Var(Lit_8, Lit_60); A_arbace_a2g_reach_A_const_40 = lang.RT_Keyword_String_String__Keyword(nil, Lit_61); A_arbace_a2g_reach_A_const_41 = lang.RT_Keyword_String_String__Keyword(nil, Lit_62); A_arbace_a2g_reach_A_const_42 = lang.RT_Keyword_String_String__Keyword(nil, Lit_63); A_arbace_a2g_reach_A_const_43 = lang.RT_Var_String_String__Var(Lit_8, Lit_64); A_arbace_a2g_reach_A_const_44 = lang.RT_Var_String_String__Var(Lit_12, Lit_65); A_arbace_a2g_reach_A_const_45 = lang.RT_Var_String_String__Var(Lit_12, Lit_66); A_arbace_a2g_reach_A_const_46 = lang.RT_Var_String_String__Var(Lit_12, Lit_67); A_arbace_a2g_reach_A_const_47 = lang.RT_Var_String_String__Var(Lit_0, Lit_68); A_arbace_a2g_reach_A_const_48 = lang.RT_Var_String_String__Var(Lit_0, Lit_69); A_arbace_a2g_reach_A_const_49 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_a2g_reach_A_const_50 = lang.RT_Var_String_String__Var(Lit_0, Lit_71); A_arbace_a2g_reach_A_const_51 = lang.RT_Var_String_String__Var(Lit_0, Lit_72); A_arbace_a2g_reach_A_const_52 = lang.RT_Var_String_String__Var(Lit_0, Lit_73); A_arbace_a2g_reach_A_const_53 = lang.RT_Var_String_String__Var(Lit_0, Lit_74); A_arbace_a2g_reach_A_const_54 = lang.RT_Var_String_String__Var(Lit_0, Lit_75); A_arbace_a2g_reach_A_const_55 = lang.RT_Var_String_String__Var(Lit_0, Lit_76); A_arbace_a2g_reach_A_const_56 = lang.RT_Keyword_String_String__Keyword(nil, Lit_77); A_arbace_a2g_reach_A_const_57 = lang.RT_Var_String_String__Var(Lit_8, Lit_78); A_arbace_a2g_reach_A_const_58 = lang.RT_Var_String_String__Var(Lit_8, Lit_79); A_arbace_a2g_reach_A_const_59 = lang.RT_Var_String_String__Var(Lit_25, Lit_80); A_arbace_a2g_reach_A_const_60 = lang.RT_Var_String_String__Var(Lit_0, Lit_81); A_arbace_a2g_reach_A_const_61 = lang.RT_Keyword_String_String__Keyword(nil, Lit_82); A_arbace_a2g_reach_A_const_62 = lang.RT_Var_String_String__Var(Lit_25, Lit_83); A_arbace_a2g_reach_A_const_63 = lang.RT_Var_String_String__Var(Lit_0, Lit_84); A_arbace_a2g_reach_A_const_64 = lang.RT_Var_String_String__Var(Lit_0, Lit_85); A_arbace_a2g_reach_A_const_65 = lang.RT_Var_String_String__Var(Lit_12, Lit_86); A_arbace_a2g_reach_A_const_66 = lang.RT_Var_String_String__Var(Lit_14, Lit_87); A_arbace_a2g_reach_A_const_67 = lang.RT_Keyword_String_String__Keyword(nil, Lit_19); A_arbace_a2g_reach_A_const_68 = lang.RT_Var_String_String__Var(Lit_12, Lit_88); A_arbace_a2g_reach_A_const_69 = lang.RT_Var_String_String__Var(Lit_12, Lit_89); A_arbace_a2g_reach_A_const_70 = lang.RT_Keyword_String_String__Keyword(nil, Lit_90); A_arbace_a2g_reach_A_const_71 = lang.RT_Keyword_String_String__Keyword(nil, Lit_91); A_arbace_a2g_reach_A_const_72 = lang.RT_Var_String_String__Var(Lit_14, Lit_92); A_arbace_a2g_reach_A_const_73 = lang.RT_Keyword_String_String__Keyword(nil, Lit_93); A_arbace_a2g_reach_A_const_74 = lang.RT_Var_String_String__Var(Lit_12, Lit_94); A_arbace_a2g_reach_A_const_75 = lang.RT_Var_String_String__Var(Lit_12, Lit_95); A_arbace_a2g_reach_A_const_76 = lang.RT_Var_String_String__Var(Lit_12, Lit_96); A_arbace_a2g_reach_A_const_77 = lang.RT_Var_String_String__Var(Lit_10, Lit_97); A_arbace_a2g_reach_A_const_78 = lang.RT_Keyword_String_String__Keyword(nil, Lit_98); A_arbace_a2g_reach_A_const_79 = lang.RT_Var_String_String__Var(Lit_25, Lit_99); A_arbace_a2g_reach_A_const_80 = lang.RT_Var_String_String__Var(Lit_0, Lit_100); A_arbace_a2g_reach_A_const_81 = lang.RT_Var_String_String__Var(Lit_12, Lit_101); A_arbace_a2g_reach_A_const_82 = lang.RT_Keyword_String_String__Keyword(nil, Lit_102); A_arbace_a2g_reach_A_const_83 = lang.RT_Var_String_String__Var(Lit_25, Lit_103); A_arbace_a2g_reach_A_const_84 = lang.RT_Keyword_String_String__Keyword(nil, Lit_104); A_arbace_a2g_reach_A_const_85 = lang.RT_Var_String_String__Var(Lit_25, Lit_105); A_arbace_a2g_reach_A_const_86 = lang.RT_Keyword_String_String__Keyword(nil, Lit_106); A_arbace_a2g_reach_A_const_87 = lang.RT_Var_String_String__Var(Lit_0, Lit_107); A_arbace_a2g_reach_A_const_88 = lang.RT_Keyword_String_String__Keyword(nil, Lit_108); A_arbace_a2g_reach_A_const_89 = lang.RT_Var_String_String__Var(Lit_0, Lit_109); A_arbace_a2g_reach_A_const_90 = lang.RT_Var_String_String__Var(Lit_0, Lit_110); A_arbace_a2g_reach_A_const_91 = lang.RT_Var_String_String__Var(Lit_0, Lit_111); A_arbace_a2g_reach_A_const_92 = lang.RT_Keyword_String_String__Keyword(nil, Lit_112); A_arbace_a2g_reach_A_const_93 = lang.RT_Keyword_String_String__Keyword(nil, Lit_113); A_arbace_a2g_reach_A_const_94 = lang.RT_Keyword_String_String__Keyword(nil, Lit_114); A_arbace_a2g_reach_A_const_95 = lang.RT_Var_String_String__Var(Lit_3, Lit_115); A_arbace_a2g_reach_A_const_96 = lang.RT_Var_String_String__Var(Lit_12, Lit_116); A_arbace_a2g_reach_A_const_97 = lang.RT_Keyword_String_String__Keyword(nil, Lit_117); A_arbace_a2g_reach_A_const_98 = lang.RT_Keyword_String_String__Keyword(nil, Lit_118); A_arbace_a2g_reach_A_const_99 = lang.RT_Var_String_String__Var(Lit_25, Lit_119); A_arbace_a2g_reach_A_const_100 = lang.RT_Keyword_String_String__Keyword(nil, Lit_120); A_arbace_a2g_reach_A_const_101 = lang.RT_Var_String_String__Var(Lit_25, Lit_121); A_arbace_a2g_reach_A_const_102 = lang.RT_Var_String_String__Var(Lit_0, Lit_122); A_arbace_a2g_reach_A_const_103 = lang.RT_Var_String_String__Var(Lit_0, Lit_123); A_arbace_a2g_reach_A_const_104 = lang.RT_Keyword_String_String__Keyword(nil, Lit_124); A_arbace_a2g_reach_A_const_105 = lang.RT_Var_String_String__Var(Lit_25, Lit_125); A_arbace_a2g_reach_A_const_106 = lang.RT_Keyword_String_String__Keyword(nil, Lit_126); A_arbace_a2g_reach_A_const_107 = lang.RT_Keyword_String_String__Keyword(nil, Lit_127); A_arbace_a2g_reach_A_const_108 = lang.RT_Var_String_String__Var(Lit_25, Lit_128); A_arbace_a2g_reach_A_const_109 = lang.RT_Var_String_String__Var(Lit_25, Lit_129); A_arbace_a2g_reach_A_const_110 = lang.RT_Var_String_String__Var(Lit_0, Lit_130); A_arbace_a2g_reach_A_const_111 = lang.RT_Var_String_String__Var(Lit_25, Lit_131); A_arbace_a2g_reach_A_const_112 = lang.RT_Keyword_String_String__Keyword(nil, Lit_132); A_arbace_a2g_reach_A_const_113 = lang.RT_Var_String_String__Var(Lit_0, Lit_133); A_arbace_a2g_reach_A_const_114 = lang.RT_Keyword_String_String__Keyword(nil, Lit_134); A_arbace_a2g_reach_A_const_115 = lang.RT_Var_String_String__Var(Lit_12, Lit_135); A_arbace_a2g_reach_A_const_116 = lang.RT_Keyword_String_String__Keyword(nil, Lit_136); A_arbace_a2g_reach_A_const_117 = lang.RT_Var_String_String__Var(Lit_25, Lit_137); A_arbace_a2g_reach_A_const_118 = lang.RT_Var_String_String__Var(Lit_12, Lit_138); A_arbace_a2g_reach_A_const_119 = lang.RT_Var_String_String__Var(Lit_12, Lit_139); A_arbace_a2g_reach_A_const_120 = lang.RT_Keyword_String_String__Keyword(nil, Lit_140); A_arbace_a2g_reach_A_const_121 = lang.RT_Keyword_String_String__Keyword(nil, Lit_141); A_arbace_a2g_reach_A_const_122 = lang.RT_Keyword_String_String__Keyword(nil, Lit_142); A_arbace_a2g_reach_A_const_123 = lang.RT_Keyword_String_String__Keyword(nil, Lit_143); A_arbace_a2g_reach_A_const_124 = lang.RT_Var_String_String__Var(Lit_0, Lit_144); A_arbace_a2g_reach_A_const_125 = lang.RT_Keyword_String_String__Keyword(nil, Lit_145); A_arbace_a2g_reach_A_const_126 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.ConstRefArray("[0,5,s9:fullFences13:loadLoadFences12:releaseFences15:storeStoreFences12:acquireFence", []*jrt.Class{jrt.Object_class})).Ref(); A_arbace_a2g_reach_A_const_127 = lang.RT_Var_String_String__Var(Lit_16, Lit_146); A_arbace_a2g_reach_A_const_128 = lang.RT_Keyword_String_String__Keyword(nil, Lit_147); A_arbace_a2g_reach_A_const_129 = lang.RT_Var_String_String__Var(Lit_25, Lit_148); A_arbace_a2g_reach_A_const_130 = lang.RT_Keyword_String_String__Keyword(nil, Lit_149); A_arbace_a2g_reach_A_const_131 = lang.RT_Keyword_String_String__Keyword(nil, Lit_42); A_arbace_a2g_reach_A_const_132 = lang.RT_Keyword_String_String__Keyword(nil, Lit_150); A_arbace_a2g_reach_A_const_133 = lang.RT_Keyword_String_String__Keyword(nil, Lit_151); A_arbace_a2g_reach_A_const_134 = lang.RT_Var_String_String__Var(Lit_25, Lit_152); A_arbace_a2g_reach_A_const_135 = lang.RT_Keyword_String_String__Keyword(nil, Lit_153); A_arbace_a2g_reach_A_const_136 = lang.RT_Keyword_String_String__Keyword(nil, Lit_154); A_arbace_a2g_reach_A_const_137 = lang.RT_Keyword_String_String__Keyword(nil, Lit_155); A_arbace_a2g_reach_A_const_138 = lang.RT_Keyword_String_String__Keyword(nil, Lit_156); A_arbace_a2g_reach_A_const_139 = lang.RT_Keyword_String_String__Keyword(nil, Lit_157); A_arbace_a2g_reach_A_const_140 = lang.RT_Keyword_String_String__Keyword(nil, Lit_158); A_arbace_a2g_reach_A_const_141 = lang.RT_Var_String_String__Var(Lit_25, Lit_159); A_arbace_a2g_reach_A_const_142 = lang.RT_Keyword_String_String__Keyword(nil, Lit_55); A_arbace_a2g_reach_A_const_143 = lang.RT_Keyword_String_String__Keyword(nil, Lit_56); A_arbace_a2g_reach_A_const_144 = lang.RT_Keyword_String_String__Keyword(nil, Lit_160); A_arbace_a2g_reach_A_const_145 = lang.RT_Keyword_String_String__Keyword(nil, Lit_161); A_arbace_a2g_reach_A_const_146 = lang.RT_Keyword_String_String__Keyword(nil, Lit_162); A_arbace_a2g_reach_A_const_147 = lang.RT_Var_String_String__Var(Lit_10, Lit_163); A_arbace_a2g_reach_A_const_148 = lang.RT_Var_String_String__Var(Lit_6, Lit_164); A_arbace_a2g_reach_A_const_149 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_a2g_reach_A_const_150 = lang.RT_Keyword_String_String__Keyword(nil, Lit_165); A_arbace_a2g_reach_A_const_151 = lang.RT_Keyword_String_String__Keyword(nil, Lit_166); A_arbace_a2g_reach_A_const_152 = lang.RT_Keyword_String_String__Keyword(nil, Lit_167); A_arbace_a2g_reach_A_const_153 = lang.RT_Keyword_String_String__Keyword(nil, Lit_168); A_arbace_a2g_reach_A_const_154 = lang.RT_Var_String_String__Var(Lit_6, Lit_169); A_arbace_a2g_reach_A_const_155 = lang.RT_Var_String_String__Var(Lit_6, Lit_170); A_arbace_a2g_reach_A_const_156 = lang.RT_Keyword_String_String__Keyword(nil, Lit_171); A_arbace_a2g_reach_A_const_157 = lang.RT_Keyword_String_String__Keyword(nil, Lit_172); A_arbace_a2g_reach_A_const_158 = lang.RT_Keyword_String_String__Keyword(nil, Lit_173); A_arbace_a2g_reach_A_const_159 = lang.RT_Keyword_String_String__Keyword(nil, Lit_174); A_arbace_a2g_reach_A_const_160 = lang.RT_Keyword_String_String__Keyword(nil, Lit_175); A_arbace_a2g_reach_A_const_161 = lang.RT_Keyword_String_String__Keyword(nil, Lit_176); A_arbace_a2g_reach_A_const_162 = lang.RT_Var_String_String__Var(Lit_25, Lit_177); A_arbace_a2g_reach_A_const_163 = lang.RT_Keyword_String_String__Keyword(nil, Lit_178); A_arbace_a2g_reach_A_const_164 = lang.RT_Var_String_String__Var(Lit_25, Lit_179); A_arbace_a2g_reach_A_const_165 = lang.RT_Keyword_String_String__Keyword(nil, Lit_180); A_arbace_a2g_reach_A_const_166 = lang.RT_Keyword_String_String__Keyword(nil, Lit_181); A_arbace_a2g_reach_A_const_167 = lang.RT_Var_String_String__Var(Lit_14, Lit_182); A_arbace_a2g_reach_A_const_168 = lang.RT_Keyword_String_String__Keyword(nil, Lit_183); A_arbace_a2g_reach_A_const_169 = lang.RT_Keyword_String_String__Keyword(nil, Lit_184); A_arbace_a2g_reach_A_const_170 = lang.RT_Keyword_String_String__Keyword(nil, Lit_185); A_arbace_a2g_reach_A_const_171 = lang.RT_Keyword_String_String__Keyword(nil, Lit_186); A_arbace_a2g_reach_A_const_172 = lang.RT_Keyword_String_String__Keyword(nil, Lit_187); A_arbace_a2g_reach_A_const_173 = lang.RT_Keyword_String_String__Keyword(nil, Lit_188); A_arbace_a2g_reach_A_const_174 = lang.RT_Keyword_String_String__Keyword(nil, Lit_189); A_arbace_a2g_reach_A_const_175 = lang.RT_Var_String_String__Var(Lit_6, Lit_190); A_arbace_a2g_reach_A_const_176 = lang.RT_Keyword_String_String__Keyword(nil, Lit_191); A_arbace_a2g_reach_A_const_177 = lang.RT_Var_String_String__Var(Lit_6, Lit_192); A_arbace_a2g_reach_A_const_178 = lang.RT_Var_String_String__Var(Lit_0, Lit_193); A_arbace_a2g_reach_A_const_179 = lang.RT_Keyword_String_String__Keyword(nil, Lit_194); A_arbace_a2g_reach_A_const_180 = lang.RT_Var_String_String__Var(Lit_25, Lit_195); A_arbace_a2g_reach_A_const_181 = lang.RT_Keyword_String_String__Keyword(nil, Lit_196); A_arbace_a2g_reach_A_const_182 = lang.RT_Keyword_String_String__Keyword(nil, Lit_197); A_arbace_a2g_reach_A_const_183 = lang.RT_Keyword_String_String__Keyword(nil, Lit_198); A_arbace_a2g_reach_A_const_184 = lang.RT_Keyword_String_String__Keyword(nil, Lit_199); A_arbace_a2g_reach_A_const_185 = lang.RT_Keyword_String_String__Keyword(nil, Lit_41); A_arbace_a2g_reach_A_const_186 = lang.RT_Keyword_String_String__Keyword(nil, Lit_200); A_arbace_a2g_reach_A_const_187 = lang.RT_Var_String_String__Var(Lit_25, Lit_201); A_arbace_a2g_reach_A_const_188 = lang.RT_Keyword_String_String__Keyword(nil, Lit_202); A_arbace_a2g_reach_A_const_189 = lang.RT_Var_String_String__Var(Lit_25, Lit_203); A_arbace_a2g_reach_A_const_190 = lang.RT_Keyword_String_String__Keyword(nil, Lit_204); A_arbace_a2g_reach_A_const_191 = lang.RT_Keyword_String_String__Keyword(nil, Lit_205); A_arbace_a2g_reach_A_const_192 = lang.RT_Var_String_String__Var(Lit_25, Lit_206); A_arbace_a2g_reach_A_const_193 = lang.RT_Var_String_String__Var(Lit_12, Lit_207); A_arbace_a2g_reach_A_const_194 = lang.RT_Keyword_String_String__Keyword(nil, Lit_208); A_arbace_a2g_reach_A_const_195 = lang.RT_Keyword_String_String__Keyword(nil, Lit_209); A_arbace_a2g_reach_A_const_196 = lang.RT_Keyword_String_String__Keyword(nil, Lit_210); A_arbace_a2g_reach_A_const_197 = lang.RT_Keyword_String_String__Keyword(nil, Lit_211); A_arbace_a2g_reach_A_const_198 = lang.RT_Var_String_String__Var(Lit_25, Lit_212); A_arbace_a2g_reach_A_const_199 = lang.RT_Keyword_String_String__Keyword(nil, Lit_213); A_arbace_a2g_reach_A_const_200 = lang.RT_Keyword_String_String__Keyword(nil, Lit_214); A_arbace_a2g_reach_A_const_201 = lang.RT_Keyword_String_String__Keyword(nil, Lit_215); A_arbace_a2g_reach_A_const_202 = lang.RT_Keyword_String_String__Keyword(nil, Lit_216); A_arbace_a2g_reach_A_const_203 = lang.RT_Keyword_String_String__Keyword(nil, Lit_217); A_arbace_a2g_reach_A_const_204 = lang.RT_Keyword_String_String__Keyword(nil, Lit_218); A_arbace_a2g_reach_A_const_205 = lang.RT_Keyword_String_String__Keyword(nil, Lit_219); A_arbace_a2g_reach_A_const_206 = lang.RT_Var_String_String__Var(Lit_12, Lit_220); A_arbace_a2g_reach_A_const_207 = lang.RT_Keyword_String_String__Keyword(nil, Lit_221); A_arbace_a2g_reach_A_const_208 = lang.RT_Keyword_String_String__Keyword(nil, Lit_222); A_arbace_a2g_reach_A_const_209 = lang.RT_Keyword_String_String__Keyword(nil, Lit_223); A_arbace_a2g_reach_A_const_210 = lang.RT_Keyword_String_String__Keyword(nil, Lit_224); A_arbace_a2g_reach_A_const_211 = lang.RT_Keyword_String_String__Keyword(nil, Lit_225); A_arbace_a2g_reach_A_const_212 = lang.RT_Keyword_String_String__Keyword(nil, Lit_226); A_arbace_a2g_reach_A_const_213 = lang.RT_Keyword_String_String__Keyword(nil, Lit_227); A_arbace_a2g_reach_A_const_214 = lang.RT_Keyword_String_String__Keyword(nil, Lit_228); A_arbace_a2g_reach_A_const_215 = lang.RT_Var_String_String__Var(Lit_25, Lit_229); A_arbace_a2g_reach_A_const_216 = lang.RT_Keyword_String_String__Keyword(nil, Lit_230); A_arbace_a2g_reach_A_const_217 = lang.RT_Keyword_String_String__Keyword(nil, Lit_46); A_arbace_a2g_reach_A_const_218 = lang.RT_Keyword_String_String__Keyword(nil, Lit_231); A_arbace_a2g_reach_A_const_219 = lang.RT_Var_String_String__Var(Lit_6, Lit_232); A_arbace_a2g_reach_A_const_220 = lang.RT_Keyword_String_String__Keyword(nil, Lit_233); A_arbace_a2g_reach_A_const_221 = lang.RT_Keyword_String_String__Keyword(nil, Lit_234); A_arbace_a2g_reach_A_const_222 = lang.RT_Var_String_String__Var(Lit_25, Lit_235); A_arbace_a2g_reach_A_const_223 = lang.RT_Keyword_String_String__Keyword(nil, Lit_236); A_arbace_a2g_reach_A_const_224 = lang.RT_Keyword_String_String__Keyword(nil, Lit_237); A_arbace_a2g_reach_A_const_225 = lang.RT_Keyword_String_String__Keyword(nil, Lit_238); A_arbace_a2g_reach_A_const_226 = lang.RT_Keyword_String_String__Keyword(nil, Lit_239); A_arbace_a2g_reach_A_const_227 = lang.RT_Var_String_String__Var(Lit_0, Lit_240); A_arbace_a2g_reach_A_const_228 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_241, Lit_242)).Ref(); A_arbace_a2g_reach_A_const_229 = lang.PersistentHashSet_Create_O1__PersistentHashSet(jrt.RefArrayOf(jrt.Object_class, Lit_241, Lit_242)).Ref(); A_arbace_a2g_reach_A_const_230 = lang.RT_Var_String_String__Var(Lit_25, Lit_243); A_arbace_a2g_reach_A_const_231 = lang.RT_Var_String_String__Var(Lit_0, Lit_244); A_arbace_a2g_reach_A_const_232 = jrt.Long_ValueOf_J__Long(1).Ref(); A_arbace_a2g_reach_A_const_233 = lang.RT_Var_String_String__Var(Lit_0, Lit_245) }

func A_arbace_a2g_reach_A_New() *A_arbace_a2g_reach_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach_A) Ctor() {}

func (t *A_arbace_a2g_reach_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_A_class }

func (t *A_arbace_a2g_reach_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_A); return ok }

func A_arbace_a2g_reach_A_Cast(x any) *A_arbace_a2g_reach_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_A_class)) }; return v }



type A_arbace_a2g_reach_check_hw_call_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Is_Compiler_AOTF4() {}

var A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_check_hw_call_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_check_hw_call_BANG__A_Init() { if !A_arbace_a2g_reach_check_hw_call_BANG__A_init.Done() { A_arbace_a2g_reach_check_hw_call_BANG__A_init.Run(A_arbace_a2g_reach_check_hw_call_BANG__A_clinit) } }

func A_arbace_a2g_reach_check_hw_call_BANG__A_clinit() { A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_246, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_check_hw_call_BANG__A_class }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_check_hw_call_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_check_hw_call_BANG__A); return ok }

func A_arbace_a2g_reach_check_hw_call_BANG__A_Cast(x any) *A_arbace_a2g_reach_check_hw_call_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_check_hw_call_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_check_hw_call_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A struct{ jrt.Object; F_mm any }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_fn_class *jrt.Class

var A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_init jrt.ClassInit

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_Init() { if !A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_init.Done() { A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_init.Run(A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_clinit) } }

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_clinit() { A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_251, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_class }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A); return ok }

func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_Cast(x any) *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_check_hw_call_BANG__fn__214000181_A_class)) }; return v }



type A_arbace_a2g_reach_class_of_desc_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_class_of_desc_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_class_of_desc_A_fn_class *jrt.Class

var A_arbace_a2g_reach_class_of_desc_A_init jrt.ClassInit

func A_arbace_a2g_reach_class_of_desc_A_Init() { if !A_arbace_a2g_reach_class_of_desc_A_init.Done() { A_arbace_a2g_reach_class_of_desc_A_init.Run(A_arbace_a2g_reach_class_of_desc_A_clinit) } }

func A_arbace_a2g_reach_class_of_desc_A_clinit() { A_arbace_a2g_reach_class_of_desc_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_252, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_class_of_desc_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_class_of_desc_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_class_of_desc_A_class }

func (t *A_arbace_a2g_reach_class_of_desc_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_class_of_desc_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_class_of_desc_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_class_of_desc_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_class_of_desc_A); return ok }

func A_arbace_a2g_reach_class_of_desc_A_Cast(x any) *A_arbace_a2g_reach_class_of_desc_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_class_of_desc_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_class_of_desc_A_class)) }; return v }



type A_arbace_a2g_reach_eval214000004_A struct{ jrt.Object }

func A_arbace_a2g_reach_eval214000004_A_New() *A_arbace_a2g_reach_eval214000004_A { t := &A_arbace_a2g_reach_eval214000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach_eval214000004_A) Ctor() {}

func (t *A_arbace_a2g_reach_eval214000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_eval214000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_eval214000004_A_class }

func (t *A_arbace_a2g_reach_eval214000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_eval214000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_eval214000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_eval214000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_eval214000004_A); return ok }

func A_arbace_a2g_reach_eval214000004_A_Cast(x any) *A_arbace_a2g_reach_eval214000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_eval214000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_eval214000004_A_class)) }; return v }



type A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class *jrt.Class

var A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_init jrt.ClassInit

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_Init() { if !A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_init.Done() { A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_init.Run(A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_clinit) } }

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_clinit() { A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_253, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_class }

func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A); return ok }

func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_Cast(x any) *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_class)) }; return v }



type A_arbace_a2g_reach_eval214000008_A struct{ jrt.Object }

func A_arbace_a2g_reach_eval214000008_A_New() *A_arbace_a2g_reach_eval214000008_A { t := &A_arbace_a2g_reach_eval214000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach_eval214000008_A) Ctor() {}

func (t *A_arbace_a2g_reach_eval214000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_eval214000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_eval214000008_A_class }

func (t *A_arbace_a2g_reach_eval214000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_eval214000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_eval214000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_eval214000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_eval214000008_A); return ok }

func A_arbace_a2g_reach_eval214000008_A_Cast(x any) *A_arbace_a2g_reach_eval214000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_eval214000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_eval214000008_A_class)) }; return v }



type A_arbace_a2g_reach_eval214000008_fn__214000009_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class *jrt.Class

var A_arbace_a2g_reach_eval214000008_fn__214000009_A_init jrt.ClassInit

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_Init() { if !A_arbace_a2g_reach_eval214000008_fn__214000009_A_init.Done() { A_arbace_a2g_reach_eval214000008_fn__214000009_A_init.Run(A_arbace_a2g_reach_eval214000008_fn__214000009_A_clinit) } }

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_clinit() { A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_254, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_eval214000008_fn__214000009_A_class }

func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_eval214000008_fn__214000009_A); return ok }

func A_arbace_a2g_reach_eval214000008_fn__214000009_A_Cast(x any) *A_arbace_a2g_reach_eval214000008_fn__214000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_eval214000008_fn__214000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_eval214000008_fn__214000009_A_class)) }; return v }



type A_arbace_a2g_reach_external_keys_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_external_keys_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_external_keys_A_fn_class *jrt.Class

var A_arbace_a2g_reach_external_keys_A_init jrt.ClassInit

func A_arbace_a2g_reach_external_keys_A_Init() { if !A_arbace_a2g_reach_external_keys_A_init.Done() { A_arbace_a2g_reach_external_keys_A_init.Run(A_arbace_a2g_reach_external_keys_A_clinit) } }

func A_arbace_a2g_reach_external_keys_A_clinit() { A_arbace_a2g_reach_external_keys_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_255, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_external_keys_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_external_keys_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_external_keys_A_class }

func (t *A_arbace_a2g_reach_external_keys_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_external_keys_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_external_keys_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_external_keys_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_external_keys_A); return ok }

func A_arbace_a2g_reach_external_keys_A_Cast(x any) *A_arbace_a2g_reach_external_keys_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_external_keys_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_external_keys_A_class)) }; return v }



type A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_fn_class *jrt.Class

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_init jrt.ClassInit

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_Init() { if !A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_init.Done() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_init.Run(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_clinit) } }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_clinit() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_256, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_class }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A); return ok }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_Cast(x any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_external_keys_iter__214000112__214000118_A_class)) }; return v }



type A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A struct{ jrt.Object; F_s__214000113, F_iter__214000112 any }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_fn_class *jrt.Class

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_init jrt.ClassInit

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_Init() { if !A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_init.Done() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_init.Run(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_clinit) } }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_clinit() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_257, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_class }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A); return ok }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_Cast(x any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_A_class)) }; return v }



type A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_fn_class *jrt.Class

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_init jrt.ClassInit

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_Init() { if !A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_init.Done() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_init.Run(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_clinit) } }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_clinit() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_258, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_class }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A); return ok }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_Cast(x any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_A_class)) }; return v }



type A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A struct{ jrt.Object; F_iter__214000114, F_s__214000115 any }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_fn_class *jrt.Class

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_init jrt.ClassInit

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_Init() { if !A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_init.Done() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_init.Run(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_clinit) } }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_clinit() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_259, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_class }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A); return ok }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_Cast(x any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_A_class)) }; return v }



type A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A struct{ jrt.Object; F_b__214000117 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_fn_class *jrt.Class

var A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_init jrt.ClassInit

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_Init() { if !A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_init.Done() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_init.Run(A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_clinit) } }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_clinit() { A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_260, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_class }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A); return ok }

func A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_Cast(x any) *A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_external_keys_iter__214000112__214000118_fn__214000119_iter__214000114__214000120_fn__214000121_fn__214000122_A_class)) }; return v }



type A_arbace_a2g_reach_hw_has_field_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_reach_hw_has_field_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_reach_hw_has_field_QMARK__A_Init() { if !A_arbace_a2g_reach_hw_has_field_QMARK__A_init.Done() { A_arbace_a2g_reach_hw_has_field_QMARK__A_init.Run(A_arbace_a2g_reach_hw_has_field_QMARK__A_clinit) } }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_clinit() { A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_261, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_hw_has_field_QMARK__A_class }

func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_hw_has_field_QMARK__A); return ok }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_Cast(x any) *A_arbace_a2g_reach_hw_has_field_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_hw_has_field_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_hw_has_field_QMARK__A_class)) }; return v }



type A_arbace_a2g_reach_hw_has_static_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_reach_hw_has_static_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_reach_hw_has_static_QMARK__A_Init() { if !A_arbace_a2g_reach_hw_has_static_QMARK__A_init.Done() { A_arbace_a2g_reach_hw_has_static_QMARK__A_init.Run(A_arbace_a2g_reach_hw_has_static_QMARK__A_clinit) } }

func A_arbace_a2g_reach_hw_has_static_QMARK__A_clinit() { A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_262, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_hw_has_static_QMARK__A_class }

func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_hw_has_static_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_hw_has_static_QMARK__A); return ok }

func A_arbace_a2g_reach_hw_has_static_QMARK__A_Cast(x any) *A_arbace_a2g_reach_hw_has_static_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_hw_has_static_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_hw_has_static_QMARK__A_class)) }; return v }



type A_arbace_a2g_reach_init_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_init_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_init_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_init_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_init_BANG__A_Init() { if !A_arbace_a2g_reach_init_BANG__A_init.Done() { A_arbace_a2g_reach_init_BANG__A_init.Run(A_arbace_a2g_reach_init_BANG__A_clinit) } }

func A_arbace_a2g_reach_init_BANG__A_clinit() { A_arbace_a2g_reach_init_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_264, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_init_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_init_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_init_BANG__A_class }

func (t *A_arbace_a2g_reach_init_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_init_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_init_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_init_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_init_BANG__A); return ok }

func A_arbace_a2g_reach_init_BANG__A_Cast(x any) *A_arbace_a2g_reach_init_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_init_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_init_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_instantiate_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_instantiate_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_instantiate_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_instantiate_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_instantiate_BANG__A_Init() { if !A_arbace_a2g_reach_instantiate_BANG__A_init.Done() { A_arbace_a2g_reach_instantiate_BANG__A_init.Run(A_arbace_a2g_reach_instantiate_BANG__A_clinit) } }

func A_arbace_a2g_reach_instantiate_BANG__A_clinit() { A_arbace_a2g_reach_instantiate_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_266, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_instantiate_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_instantiate_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_instantiate_BANG__A_class }

func (t *A_arbace_a2g_reach_instantiate_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_instantiate_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_instantiate_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_instantiate_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_instantiate_BANG__A); return ok }

func A_arbace_a2g_reach_instantiate_BANG__A_Cast(x any) *A_arbace_a2g_reach_instantiate_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_instantiate_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_instantiate_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_java_impl_of_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_reach_java_impl_of_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_A_Init() { if !A_arbace_a2g_reach_java_impl_of_A_init.Done() { A_arbace_a2g_reach_java_impl_of_A_init.Run(A_arbace_a2g_reach_java_impl_of_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_A_clinit() { A_arbace_a2g_reach_java_impl_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_267, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_A); return ok }

func A_arbace_a2g_reach_java_impl_of_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_fn__214000052_A struct{ jrt.Object; F_name, F_desc, F_n any }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_fn__214000052_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_fn__214000052_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_Init() { if !A_arbace_a2g_reach_java_impl_of_fn__214000052_A_init.Done() { A_arbace_a2g_reach_java_impl_of_fn__214000052_A_init.Run(A_arbace_a2g_reach_java_impl_of_fn__214000052_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_clinit() { A_arbace_a2g_reach_java_impl_of_fn__214000052_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_268, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_fn__214000052_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000052_A); return ok }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_fn__214000052_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000052_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_fn__214000052_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A struct{ jrt.Object; F_name, F_desc any }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_Init() { if !A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_init.Done() { A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_init.Run(A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_clinit() { A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_269, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A); return ok }

func A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_fn__214000052_fn__214000053_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_fn__214000056_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_fn__214000056_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_Init() { if !A_arbace_a2g_reach_java_impl_of_fn__214000056_A_init.Done() { A_arbace_a2g_reach_java_impl_of_fn__214000056_A_init.Run(A_arbace_a2g_reach_java_impl_of_fn__214000056_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_clinit() { A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_270, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_fn__214000056_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000056_A); return ok }

func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_fn__214000056_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000056_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_fn__214000056_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_fn__214000072_A struct{ jrt.Object; F_cands any }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_fn__214000072_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_fn__214000072_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_Init() { if !A_arbace_a2g_reach_java_impl_of_fn__214000072_A_init.Done() { A_arbace_a2g_reach_java_impl_of_fn__214000072_A_init.Run(A_arbace_a2g_reach_java_impl_of_fn__214000072_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_clinit() { A_arbace_a2g_reach_java_impl_of_fn__214000072_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_271, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_fn__214000072_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000072_A); return ok }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_fn__214000072_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000072_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_fn__214000072_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A struct{ jrt.Object; F_x any }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_Init() { if !A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_init.Done() { A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_init.Run(A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_clinit() { A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_272, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A); return ok }

func A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_fn__214000072_fn__214000073_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A struct{ jrt.Object; F_name, F_desc, F_n any }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_Init() { if !A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_init.Done() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_init.Run(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_clinit() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_273, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A); return ok }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A struct{ jrt.Object; F_iter__214000058, F_s__214000059, F_name, F_desc, F_n any }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_Init() { if !A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_init.Done() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_init.Run(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_clinit() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_274, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A); return ok }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A struct{ jrt.Object; F_name, F_b__214000061, F_desc, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_Init() { if !A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_init.Done() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_init.Run(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_clinit() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_275, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A); return ok }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A struct{ jrt.Object; F_name, F_desc any }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_Init() { if !A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_init.Done() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_init.Run(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_clinit() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_276, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A); return ok }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000064_fn__214000065_A_class)) }; return v }



type A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A struct{ jrt.Object; F_name, F_desc any }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_fn_class *jrt.Class

var A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_init jrt.ClassInit

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_Init() { if !A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_init.Done() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_init.Run(A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_clinit) } }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_clinit() { A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_277, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_class }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A); return ok }

func A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_Cast(x any) *A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_java_impl_of_iter__214000058__214000062_fn__214000063_fn__214000068_A_class)) }; return v }



type A_arbace_a2g_reach_lambda_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_lambda_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_lambda_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_lambda_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_lambda_BANG__A_Init() { if !A_arbace_a2g_reach_lambda_BANG__A_init.Done() { A_arbace_a2g_reach_lambda_BANG__A_init.Run(A_arbace_a2g_reach_lambda_BANG__A_clinit) } }

func A_arbace_a2g_reach_lambda_BANG__A_clinit() { A_arbace_a2g_reach_lambda_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_278, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_lambda_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_lambda_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_lambda_BANG__A_class }

func (t *A_arbace_a2g_reach_lambda_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_lambda_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_lambda_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_lambda_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_lambda_BANG__A); return ok }

func A_arbace_a2g_reach_lambda_BANG__A_Cast(x any) *A_arbace_a2g_reach_lambda_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_lambda_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_lambda_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_method_code_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_method_code_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_method_code_A_fn_class *jrt.Class

var A_arbace_a2g_reach_method_code_A_init jrt.ClassInit

func A_arbace_a2g_reach_method_code_A_Init() { if !A_arbace_a2g_reach_method_code_A_init.Done() { A_arbace_a2g_reach_method_code_A_init.Run(A_arbace_a2g_reach_method_code_A_clinit) } }

func A_arbace_a2g_reach_method_code_A_clinit() { A_arbace_a2g_reach_method_code_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_279, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_method_code_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_method_code_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_method_code_A_class }

func (t *A_arbace_a2g_reach_method_code_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_method_code_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_method_code_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_method_code_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_method_code_A); return ok }

func A_arbace_a2g_reach_method_code_A_Cast(x any) *A_arbace_a2g_reach_method_code_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_method_code_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_method_code_A_class)) }; return v }



type A_arbace_a2g_reach_node_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_node_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_node_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_reach_node_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_reach_node_QMARK__A_Init() { if !A_arbace_a2g_reach_node_QMARK__A_init.Done() { A_arbace_a2g_reach_node_QMARK__A_init.Run(A_arbace_a2g_reach_node_QMARK__A_clinit) } }

func A_arbace_a2g_reach_node_QMARK__A_clinit() { A_arbace_a2g_reach_node_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_280, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_node_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_node_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_node_QMARK__A_class }

func (t *A_arbace_a2g_reach_node_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_node_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_node_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_node_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_node_QMARK__A); return ok }

func A_arbace_a2g_reach_node_QMARK__A_Cast(x any) *A_arbace_a2g_reach_node_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_node_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_node_QMARK__A_class)) }; return v }



type A_arbace_a2g_reach_note_unavailable_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_note_unavailable_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_note_unavailable_BANG__A_Init() { if !A_arbace_a2g_reach_note_unavailable_BANG__A_init.Done() { A_arbace_a2g_reach_note_unavailable_BANG__A_init.Run(A_arbace_a2g_reach_note_unavailable_BANG__A_clinit) } }

func A_arbace_a2g_reach_note_unavailable_BANG__A_clinit() { A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_281, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_note_unavailable_BANG__A_class }

func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_note_unavailable_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_note_unavailable_BANG__A); return ok }

func A_arbace_a2g_reach_note_unavailable_BANG__A_Cast(x any) *A_arbace_a2g_reach_note_unavailable_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_note_unavailable_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_note_unavailable_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_reach_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_reach_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_reach_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_reach_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_reach_BANG__A_Init() { if !A_arbace_a2g_reach_reach_BANG__A_init.Done() { A_arbace_a2g_reach_reach_BANG__A_init.Run(A_arbace_a2g_reach_reach_BANG__A_clinit) } }

func A_arbace_a2g_reach_reach_BANG__A_clinit() { A_arbace_a2g_reach_reach_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_282, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_reach_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_reach_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_reach_BANG__A_class }

func (t *A_arbace_a2g_reach_reach_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_reach_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_reach_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_reach_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_reach_BANG__A); return ok }

func A_arbace_a2g_reach_reach_BANG__A_Cast(x any) *A_arbace_a2g_reach_reach_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_reach_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_reach_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_run_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_run_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_run_A_fn_class *jrt.Class

var A_arbace_a2g_reach_run_A_init jrt.ClassInit

func A_arbace_a2g_reach_run_A_Init() { if !A_arbace_a2g_reach_run_A_init.Done() { A_arbace_a2g_reach_run_A_init.Run(A_arbace_a2g_reach_run_A_clinit) } }

func A_arbace_a2g_reach_run_A_clinit() { A_arbace_a2g_reach_run_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_283, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_run_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_run_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_run_A_class }

func (t *A_arbace_a2g_reach_run_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_run_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_run_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_run_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_run_A); return ok }

func A_arbace_a2g_reach_run_A_Cast(x any) *A_arbace_a2g_reach_run_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_run_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_run_A_class)) }; return v }



type A_arbace_a2g_reach_run_fn__214000327_A struct{ jrt.Object; F_classes, F_instantiate, F_fis, F_roots, F_st any }

func (t *A_arbace_a2g_reach_run_fn__214000327_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_run_fn__214000327_A_fn_class *jrt.Class

var A_arbace_a2g_reach_run_fn__214000327_A_init jrt.ClassInit

func A_arbace_a2g_reach_run_fn__214000327_A_Init() { if !A_arbace_a2g_reach_run_fn__214000327_A_init.Done() { A_arbace_a2g_reach_run_fn__214000327_A_init.Run(A_arbace_a2g_reach_run_fn__214000327_A_clinit) } }

func A_arbace_a2g_reach_run_fn__214000327_A_clinit() { A_arbace_a2g_reach_run_fn__214000327_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_284, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_run_fn__214000327_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_run_fn__214000327_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_run_fn__214000327_A_class }

func (t *A_arbace_a2g_reach_run_fn__214000327_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_run_fn__214000327_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_run_fn__214000327_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_run_fn__214000327_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_run_fn__214000327_A); return ok }

func A_arbace_a2g_reach_run_fn__214000327_A_Cast(x any) *A_arbace_a2g_reach_run_fn__214000327_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_run_fn__214000327_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_run_fn__214000327_A_class)) }; return v }



type A_arbace_a2g_reach_scan_code_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_code_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_code_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_code_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_code_BANG__A_Init() { if !A_arbace_a2g_reach_scan_code_BANG__A_init.Done() { A_arbace_a2g_reach_scan_code_BANG__A_init.Run(A_arbace_a2g_reach_scan_code_BANG__A_clinit) } }

func A_arbace_a2g_reach_scan_code_BANG__A_clinit() { A_arbace_a2g_reach_scan_code_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_285, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_code_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_code_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_code_BANG__A_class }

func (t *A_arbace_a2g_reach_scan_code_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_code_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_code_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_code_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_code_BANG__A); return ok }

func A_arbace_a2g_reach_scan_code_BANG__A_Cast(x any) *A_arbace_a2g_reach_scan_code_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_code_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_code_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_scan_method_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_method_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_method_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_method_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_method_BANG__A_Init() { if !A_arbace_a2g_reach_scan_method_BANG__A_init.Done() { A_arbace_a2g_reach_scan_method_BANG__A_init.Run(A_arbace_a2g_reach_scan_method_BANG__A_clinit) } }

func A_arbace_a2g_reach_scan_method_BANG__A_clinit() { A_arbace_a2g_reach_scan_method_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_286, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_method_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_method_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_method_BANG__A_class }

func (t *A_arbace_a2g_reach_scan_method_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_method_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_method_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_method_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_method_BANG__A); return ok }

func A_arbace_a2g_reach_scan_method_BANG__A_Cast(x any) *A_arbace_a2g_reach_scan_method_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_method_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_method_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__A_init.Run(A_arbace_a2g_reach_scan_node_BANG__A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__A_clinit() { A_arbace_a2g_reach_scan_node_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_300, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_init.Run(A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_clinit() { A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_318, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__fn__214000211_A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_init.Run(A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_clinit() { A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_319, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__pat__214000224_A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_init.Run(A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_clinit() { A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_320, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__pat__214000242_A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_init.Run(A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_clinit() { A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_321, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__pat__214000248_A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_init.Run(A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_clinit() { A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_322, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__pat__214000254_A_class)) }; return v }



type A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_fn_class *jrt.Class

var A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_init jrt.ClassInit

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_Init() { if !A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_init.Done() { A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_init.Run(A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_clinit) } }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_clinit() { A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_323, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_class }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A); return ok }

func A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_Cast(x any) *A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_scan_node_BANG__pat__214000260_A_class)) }; return v }



type A_arbace_a2g_reach_supertypes_of_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_supertypes_of_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_supertypes_of_A_fn_class *jrt.Class

var A_arbace_a2g_reach_supertypes_of_A_init jrt.ClassInit

func A_arbace_a2g_reach_supertypes_of_A_Init() { if !A_arbace_a2g_reach_supertypes_of_A_init.Done() { A_arbace_a2g_reach_supertypes_of_A_init.Run(A_arbace_a2g_reach_supertypes_of_A_clinit) } }

func A_arbace_a2g_reach_supertypes_of_A_clinit() { A_arbace_a2g_reach_supertypes_of_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_324, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_supertypes_of_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_supertypes_of_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_supertypes_of_A_class }

func (t *A_arbace_a2g_reach_supertypes_of_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_supertypes_of_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_supertypes_of_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_supertypes_of_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_supertypes_of_A); return ok }

func A_arbace_a2g_reach_supertypes_of_A_Cast(x any) *A_arbace_a2g_reach_supertypes_of_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_supertypes_of_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_supertypes_of_A_class)) }; return v }



type A_arbace_a2g_reach_supertypes_of_fn__214000130_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_supertypes_of_fn__214000130_A_fn_class *jrt.Class

var A_arbace_a2g_reach_supertypes_of_fn__214000130_A_init jrt.ClassInit

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_Init() { if !A_arbace_a2g_reach_supertypes_of_fn__214000130_A_init.Done() { A_arbace_a2g_reach_supertypes_of_fn__214000130_A_init.Run(A_arbace_a2g_reach_supertypes_of_fn__214000130_A_clinit) } }

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_clinit() { A_arbace_a2g_reach_supertypes_of_fn__214000130_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_325, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_supertypes_of_fn__214000130_A_class }

func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_supertypes_of_fn__214000130_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_supertypes_of_fn__214000130_A); return ok }

func A_arbace_a2g_reach_supertypes_of_fn__214000130_A_Cast(x any) *A_arbace_a2g_reach_supertypes_of_fn__214000130_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_supertypes_of_fn__214000130_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_supertypes_of_fn__214000130_A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_use_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_use_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__A_Init() { if !A_arbace_a2g_reach_use_BANG__A_init.Done() { A_arbace_a2g_reach_use_BANG__A_init.Run(A_arbace_a2g_reach_use_BANG__A_clinit) } }

func A_arbace_a2g_reach_use_BANG__A_clinit() { A_arbace_a2g_reach_use_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_326, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__A_class }

func (t *A_arbace_a2g_reach_use_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__A); return ok }

func A_arbace_a2g_reach_use_BANG__A_Cast(x any) *A_arbace_a2g_reach_use_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__fn__214000080_A struct{ jrt.Object; F_sup any }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_use_BANG__fn__214000080_A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__fn__214000080_A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_Init() { if !A_arbace_a2g_reach_use_BANG__fn__214000080_A_init.Done() { A_arbace_a2g_reach_use_BANG__fn__214000080_A_init.Run(A_arbace_a2g_reach_use_BANG__fn__214000080_A_clinit) } }

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_clinit() { A_arbace_a2g_reach_use_BANG__fn__214000080_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_335, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__fn__214000080_A_class }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000080_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000080_A); return ok }

func A_arbace_a2g_reach_use_BANG__fn__214000080_A_Cast(x any) *A_arbace_a2g_reach_use_BANG__fn__214000080_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000080_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__fn__214000080_A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__fn__214000086_A struct{ jrt.Object; F_i any }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__fn__214000086_A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_Init() { if !A_arbace_a2g_reach_use_BANG__fn__214000086_A_init.Done() { A_arbace_a2g_reach_use_BANG__fn__214000086_A_init.Run(A_arbace_a2g_reach_use_BANG__fn__214000086_A_clinit) } }

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_clinit() { A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_336, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__fn__214000086_A_class }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000086_A); return ok }

func A_arbace_a2g_reach_use_BANG__fn__214000086_A_Cast(x any) *A_arbace_a2g_reach_use_BANG__fn__214000086_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000086_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__fn__214000086_A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__fn__214000088_A struct{ jrt.Object; F_i any }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__fn__214000088_A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_Init() { if !A_arbace_a2g_reach_use_BANG__fn__214000088_A_init.Done() { A_arbace_a2g_reach_use_BANG__fn__214000088_A_init.Run(A_arbace_a2g_reach_use_BANG__fn__214000088_A_clinit) } }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_clinit() { A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_337, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__fn__214000088_A_class }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000088_A); return ok }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_Cast(x any) *A_arbace_a2g_reach_use_BANG__fn__214000088_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000088_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__fn__214000088_A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__fn__214000090_A struct{ jrt.Object; F_o any }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_use_BANG__fn__214000090_A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__fn__214000090_A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_Init() { if !A_arbace_a2g_reach_use_BANG__fn__214000090_A_init.Done() { A_arbace_a2g_reach_use_BANG__fn__214000090_A_init.Run(A_arbace_a2g_reach_use_BANG__fn__214000090_A_clinit) } }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_clinit() { A_arbace_a2g_reach_use_BANG__fn__214000090_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_338, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__fn__214000090_A_class }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000090_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000090_A); return ok }

func A_arbace_a2g_reach_use_BANG__fn__214000090_A_Cast(x any) *A_arbace_a2g_reach_use_BANG__fn__214000090_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000090_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__fn__214000090_A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__fn__214000096_A struct{ jrt.Object; F_i any }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__fn__214000096_A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_Init() { if !A_arbace_a2g_reach_use_BANG__fn__214000096_A_init.Done() { A_arbace_a2g_reach_use_BANG__fn__214000096_A_init.Run(A_arbace_a2g_reach_use_BANG__fn__214000096_A_clinit) } }

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_clinit() { A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_339, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__fn__214000096_A_class }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000096_A); return ok }

func A_arbace_a2g_reach_use_BANG__fn__214000096_A_Cast(x any) *A_arbace_a2g_reach_use_BANG__fn__214000096_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000096_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__fn__214000096_A_class)) }; return v }



type A_arbace_a2g_reach_use_BANG__fn__214000098_A struct{ jrt.Object; F_i any }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_use_BANG__fn__214000098_A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_BANG__fn__214000098_A_init jrt.ClassInit

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_Init() { if !A_arbace_a2g_reach_use_BANG__fn__214000098_A_init.Done() { A_arbace_a2g_reach_use_BANG__fn__214000098_A_init.Run(A_arbace_a2g_reach_use_BANG__fn__214000098_A_clinit) } }

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_clinit() { A_arbace_a2g_reach_use_BANG__fn__214000098_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_340, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_BANG__fn__214000098_A_class }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_BANG__fn__214000098_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000098_A); return ok }

func A_arbace_a2g_reach_use_BANG__fn__214000098_A_Cast(x any) *A_arbace_a2g_reach_use_BANG__fn__214000098_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_BANG__fn__214000098_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_BANG__fn__214000098_A_class)) }; return v }



type A_arbace_a2g_reach_use_desc_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_use_desc_BANG__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_use_desc_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_use_desc_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_use_desc_BANG__A_Init() { if !A_arbace_a2g_reach_use_desc_BANG__A_init.Done() { A_arbace_a2g_reach_use_desc_BANG__A_init.Run(A_arbace_a2g_reach_use_desc_BANG__A_clinit) } }

func A_arbace_a2g_reach_use_desc_BANG__A_clinit() { A_arbace_a2g_reach_use_desc_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_341, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_use_desc_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_use_desc_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_use_desc_BANG__A_class }

func (t *A_arbace_a2g_reach_use_desc_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_use_desc_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_use_desc_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_use_desc_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_use_desc_BANG__A); return ok }

func A_arbace_a2g_reach_use_desc_BANG__A_Cast(x any) *A_arbace_a2g_reach_use_desc_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_use_desc_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_use_desc_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_vcall_BANG__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_vcall_BANG__A) Is_Compiler_AOTF3() {}

var A_arbace_a2g_reach_vcall_BANG__A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcall_BANG__A_init jrt.ClassInit

func A_arbace_a2g_reach_vcall_BANG__A_Init() { if !A_arbace_a2g_reach_vcall_BANG__A_init.Done() { A_arbace_a2g_reach_vcall_BANG__A_init.Run(A_arbace_a2g_reach_vcall_BANG__A_clinit) } }

func A_arbace_a2g_reach_vcall_BANG__A_clinit() { A_arbace_a2g_reach_vcall_BANG__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_342, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcall_BANG__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcall_BANG__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcall_BANG__A_class }

func (t *A_arbace_a2g_reach_vcall_BANG__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcall_BANG__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcall_BANG__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcall_BANG__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcall_BANG__A); return ok }

func A_arbace_a2g_reach_vcall_BANG__A_Cast(x any) *A_arbace_a2g_reach_vcall_BANG__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcall_BANG__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcall_BANG__A_class)) }; return v }



type A_arbace_a2g_reach_vcall_BANG__fn__214000168_A struct{ jrt.Object; F_o any }

func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_Init() { if !A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_init.Done() { A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_init.Run(A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_clinit) } }

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_clinit() { A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_343, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_class }

func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcall_BANG__fn__214000168_A); return ok }

func A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_Cast(x any) *A_arbace_a2g_reach_vcall_BANG__fn__214000168_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcall_BANG__fn__214000168_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcall_BANG__fn__214000168_A_class)) }; return v }



type A_arbace_a2g_reach_vcalls_on_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_vcalls_on_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_vcalls_on_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcalls_on_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcalls_on_A_Init() { if !A_arbace_a2g_reach_vcalls_on_A_init.Done() { A_arbace_a2g_reach_vcalls_on_A_init.Run(A_arbace_a2g_reach_vcalls_on_A_clinit) } }

func A_arbace_a2g_reach_vcalls_on_A_clinit() { A_arbace_a2g_reach_vcalls_on_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_344, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcalls_on_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcalls_on_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcalls_on_A_class }

func (t *A_arbace_a2g_reach_vcalls_on_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcalls_on_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcalls_on_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcalls_on_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcalls_on_A); return ok }

func A_arbace_a2g_reach_vcalls_on_A_Cast(x any) *A_arbace_a2g_reach_vcalls_on_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcalls_on_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcalls_on_A_class)) }; return v }



type A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A struct{ jrt.Object; F_by any }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_Init() { if !A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_init.Done() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_init.Run(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_clinit) } }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_clinit() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_345, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_class }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A); return ok }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_Cast(x any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_A_class)) }; return v }



type A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A struct{ jrt.Object; F_s__214000134, F_by, F_iter__214000133 any }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_Init() { if !A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_init.Done() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_init.Run(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_clinit) } }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_clinit() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_346, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_class }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A); return ok }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_Cast(x any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_A_class)) }; return v }



type A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_Init() { if !A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_init.Done() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_init.Run(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_clinit) } }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_clinit() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_347, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_class }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A); return ok }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_Cast(x any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_A_class)) }; return v }



type A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A struct{ jrt.Object; F_iter__214000135, F_s__214000136 any }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_Init() { if !A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_init.Done() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_init.Run(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_clinit) } }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_clinit() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_348, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_class }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A); return ok }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_Cast(x any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_A_class)) }; return v }



type A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A struct{ jrt.Object; F_b__214000138 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) Is_Compiler_AOTF0() {}

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_fn_class *jrt.Class

var A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_init jrt.ClassInit

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_Init() { if !A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_init.Done() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_init.Run(A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_clinit) } }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_clinit() { A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_349, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_class }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A); return ok }

func A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_Cast(x any) *A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vcalls_on_iter__214000133__214000139_fn__214000140_iter__214000135__214000141_fn__214000142_fn__214000143_A_class)) }; return v }



type A_arbace_a2g_reach_vh_call_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_vh_call_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_reach_vh_call_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_reach_vh_call_QMARK__A_Init() { if !A_arbace_a2g_reach_vh_call_QMARK__A_init.Done() { A_arbace_a2g_reach_vh_call_QMARK__A_init.Run(A_arbace_a2g_reach_vh_call_QMARK__A_clinit) } }

func A_arbace_a2g_reach_vh_call_QMARK__A_clinit() { A_arbace_a2g_reach_vh_call_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_350, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vh_call_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vh_call_QMARK__A_class }

func (t *A_arbace_a2g_reach_vh_call_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vh_call_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vh_call_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vh_call_QMARK__A); return ok }

func A_arbace_a2g_reach_vh_call_QMARK__A_Cast(x any) *A_arbace_a2g_reach_vh_call_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vh_call_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vh_call_QMARK__A_class)) }; return v }



type A_arbace_a2g_reach_vh_const_QMARK__A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_vh_const_QMARK__A_fn_class *jrt.Class

var A_arbace_a2g_reach_vh_const_QMARK__A_init jrt.ClassInit

func A_arbace_a2g_reach_vh_const_QMARK__A_Init() { if !A_arbace_a2g_reach_vh_const_QMARK__A_init.Done() { A_arbace_a2g_reach_vh_const_QMARK__A_init.Run(A_arbace_a2g_reach_vh_const_QMARK__A_clinit) } }

func A_arbace_a2g_reach_vh_const_QMARK__A_clinit() { A_arbace_a2g_reach_vh_const_QMARK__A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_354, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_vh_const_QMARK__A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_vh_const_QMARK__A_class }

func (t *A_arbace_a2g_reach_vh_const_QMARK__A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_vh_const_QMARK__A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_vh_const_QMARK__A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_vh_const_QMARK__A); return ok }

func A_arbace_a2g_reach_vh_const_QMARK__A_Cast(x any) *A_arbace_a2g_reach_vh_const_QMARK__A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_vh_const_QMARK__A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_vh_const_QMARK__A_class)) }; return v }



type A_arbace_a2g_reach_walk_nodes_A struct{ jrt.Object }

func (t *A_arbace_a2g_reach_walk_nodes_A) Is_Compiler_AOTF2() {}

var A_arbace_a2g_reach_walk_nodes_A_fn_class *jrt.Class

var A_arbace_a2g_reach_walk_nodes_A_init jrt.ClassInit

func A_arbace_a2g_reach_walk_nodes_A_Init() { if !A_arbace_a2g_reach_walk_nodes_A_init.Done() { A_arbace_a2g_reach_walk_nodes_A_init.Run(A_arbace_a2g_reach_walk_nodes_A_clinit) } }

func A_arbace_a2g_reach_walk_nodes_A_clinit() { A_arbace_a2g_reach_walk_nodes_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_355, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_walk_nodes_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_walk_nodes_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_walk_nodes_A_class }

func (t *A_arbace_a2g_reach_walk_nodes_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_walk_nodes_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_walk_nodes_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_walk_nodes_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_walk_nodes_A); return ok }

func A_arbace_a2g_reach_walk_nodes_A_Cast(x any) *A_arbace_a2g_reach_walk_nodes_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_walk_nodes_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_walk_nodes_A_class)) }; return v }



type A_arbace_a2g_reach_walk_nodes_walk__214000013_A struct{ jrt.Object; F_f, F_walk_val any }

func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class *jrt.Class

var A_arbace_a2g_reach_walk_nodes_walk__214000013_A_init jrt.ClassInit

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_Init() { if !A_arbace_a2g_reach_walk_nodes_walk__214000013_A_init.Done() { A_arbace_a2g_reach_walk_nodes_walk__214000013_A_init.Run(A_arbace_a2g_reach_walk_nodes_walk__214000013_A_clinit) } }

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_clinit() { A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_356, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_walk_nodes_walk__214000013_A_class }

func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_walk_nodes_walk__214000013_A); return ok }

func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_Cast(x any) *A_arbace_a2g_reach_walk_nodes_walk__214000013_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_walk_nodes_walk__214000013_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_walk_nodes_walk__214000013_A_class)) }; return v }



type A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A struct{ jrt.Object; F_walk, F_walk_val any }

func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class *jrt.Class

var A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_init jrt.ClassInit

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_Init() { if !A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_init.Done() { A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_init.Run(A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_clinit) } }

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_clinit() { A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_357, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_class }

func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A); return ok }

func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_Cast(x any) *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_class)) }; return v }



type A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A struct{ jrt.Object; F_walk, F_walk_plain any }

func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Is_Compiler_AOTF1() {}

var A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class *jrt.Class

var A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_init jrt.ClassInit

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_Init() { if !A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_init.Done() { A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_init.Run(A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_clinit) } }

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_clinit() { A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_358, lang.Compiler_AOTFn_class) }

func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_class }

func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A); return ok }

func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_Cast(x any) *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_class)) }; return v }
