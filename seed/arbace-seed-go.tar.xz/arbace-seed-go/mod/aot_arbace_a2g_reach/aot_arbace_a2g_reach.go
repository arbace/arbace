//line aot_arbace_a2g_reach.ae:1
package aot_arbace_a2g_reach

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_New() *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_a2g_reach_A_const_1.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_2); tmp3 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_0.GetRawRoot__O()).Invoke_O_O_O_O_O_O_O_O_O__O(A_arbace_a2g_reach_A_const_3, A_arbace_a2g_reach_A_const_4, A_arbace_a2g_reach_A_const_5, A_arbace_a2g_reach_A_const_6, A_arbace_a2g_reach_A_const_7, A_arbace_a2g_reach_A_const_8, A_arbace_a2g_reach_A_const_9, A_arbace_a2g_reach_A_const_10, A_arbace_a2g_reach_A_const_11); return nil }(); lang.Var_PopThreadBindings__V(); if tmp4 != nil { panic(tmp4) }; return tmp3 }
//line :1:1
func A_arbace_a2g_reach_eval214000008_fn__214000009_A_New() *A_arbace_a2g_reach_eval214000008_fn__214000009_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_eval214000008_fn__214000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_a2g_reach_eval214000008_fn__214000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_12.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_16), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), A_arbace_a2g_reach_A_const_15) }



















func A_arbace_a2g_reach_node_QMARK__A_New() *A_arbace_a2g_reach_node_QMARK__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_node_QMARK__A{}; t.Ctor(); return t }
//line :21:1
func (t *A_arbace_a2g_reach_node_QMARK__A) Ctor() {}
//line :21:1
func (t *A_arbace_a2g_reach_node_QMARK__A) Invoke_O_O__O(self, x__0 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_17.GetRawRoot__O()).Invoke_O__O(x__0); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(x__0, A_arbace_a2g_reach_A_const_19) } else { return and__1927000168__auto____2 } }

func A_arbace_a2g_reach_walk_nodes_A_New() *A_arbace_a2g_reach_walk_nodes_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_A{}; t.Ctor(); return t }
//line :23:1
func (t *A_arbace_a2g_reach_walk_nodes_A) Ctor() {}
//line :23:1
func (t *A_arbace_a2g_reach_walk_nodes_A) Invoke_O_O_O__O(self, f__0, node__1 any) any { var body_walk__3 *A_arbace_a2g_reach_walk_nodes_walk__214000013_A = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_New_O_O(f__0, nil); var body_walk_val__4 *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_New_O_O(nil, nil); var body_walk_plain__5 *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_New_O_O(nil, nil); var walk__3 any; var tmp1 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_95, false); A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class = fncls__1d; tmp1 = fncls__1d } else { tmp1 = fncls__1 }; walk__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk__3), tmp1, nil); var walk_val__4 any; var tmp2 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_96, false); A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class = fncls__2d; tmp2 = fncls__2d } else { tmp2 = fncls__2 }; walk_val__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk_val__4), tmp2, nil); var walk_plain__5 any; var tmp3 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class; if fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_97, false); A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class = fncls__3d; tmp3 = fncls__3d } else { tmp3 = fncls__3 }; walk_plain__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_walk_plain__5), tmp3, nil); body_walk__3.F_walk_val = walk_val__4; body_walk_val__4.F_walk = walk__3; body_walk_val__4.F_walk_plain = walk_plain__5; body_walk_plain__5.F_walk = walk__3; body_walk_plain__5.F_walk_val = walk_val__4; if




















	jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_29.GetRawRoot__O()).Invoke_O__O(node__1)) { return lang.IFn_Cast(walk__3).Invoke_O__O(node__1) } else { return nil } }
//line :27:1
func A_arbace_a2g_reach_walk_nodes_walk__214000013_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_walk_nodes_walk__214000013_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_walk__214000013_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Ctor_O_O(c__f, c__walk_val any) { t.F_f = c__f; t.F_walk_val = c__walk_val }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk__214000013_A) Invoke_O_O__O(self, n__1 any) any {
	lang.IFn_Cast(t.F_f).Invoke_O__O(n__1)
//line :27:1
	{ var seq_214000014__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(n__1); var chunk_214000015__3 any; var count_214000016__4 int64 = 0; var i_214000017__5 int64 = 0; L1: for {

		if lang.Numbers_Lt_J_J__Z(i_214000017__5, count_214000016__4) { var vec__214000018__6 any = lang.Indexed_Cast(chunk_214000015__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000017__5)); var k__7 any = lang.RT_Nth_O_I_O__O(vec__214000018__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__214000018__6, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_25).Invoke_O__O(k__7))) {

			lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__8)
//line :29:1
			seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = seq_214000014__2, chunk_214000015__3, count_214000016__4, lang.Numbers_Unchecked_inc_J__J(i_214000017__5); continue L1 } else { seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = seq_214000014__2, chunk_214000015__3, count_214000016__4, lang.Numbers_Unchecked_inc_J__J(i_214000017__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000014__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000014__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000014__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000014__7); seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000014__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__214000021__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000014__7); var k__9 any = lang.RT_Nth_O_I_O__O(vec__214000021__8, lang.RT_IntCast_J__I(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__214000021__8, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_27).Invoke_O__O(k__9))) {

				lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__10)
//line :29:1
				seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000014__7), nil, 0, 0; continue L1 } else { seq_214000014__2, chunk_214000015__3, count_214000016__4, i_214000017__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000014__7), nil, 0, 0; continue L1 } } } else { return nil } } } }
//line :27:1
	panic("a2g: unreachable") }
//line :27:1
func A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Ctor_O_O(c__walk, c__walk_val any) { t.F_walk = c__walk; t.F_walk_val = c__walk_val }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A) Invoke_O_O__O(self, mp__1 any) any { { var seq_214000032__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(mp__1); var chunk_214000033__3 any; var count_214000034__4 int64 = 0; var i_214000035__5 int64 = 0; L1: for {












	if lang.Numbers_Lt_J_J__Z(i_214000035__5, count_214000034__4) { var vec__214000036__6 any = lang.Indexed_Cast(chunk_214000033__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000035__5)); var k__7 any = lang.RT_Nth_O_I_O__O(vec__214000036__6, lang.RT_IntCast_J__I(0), nil); var v__8 any = lang.RT_Nth_O_I_O__O(vec__214000036__6, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_32).Invoke_O__O(k__7))) {
		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_29.GetRawRoot__O()).Invoke_O__O(v__8)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(v__8) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_30.GetRawRoot__O()).Invoke_O__O(v__8)) {
			lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__8) } else {
//line :41:1
				var tmp1 any; var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_17.GetRawRoot__O()).Invoke_O__O(v__8)

				if jrt.A2g_Truth(and__1927000168__auto____9) { tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_33).Invoke_O__O(k__7) } else { tmp1 = and__1927000168__auto____9 }
//line :41:1
				if jrt.A2g_Truth(tmp1) {

					lang.IFn_Cast(self).Invoke_O__O(v__8) } } }
//line :40:1
		seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = seq_214000032__2, chunk_214000033__3, count_214000034__4, lang.Numbers_Unchecked_inc_J__J(i_214000035__5); continue L1 } else { seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = seq_214000032__2, chunk_214000033__3, count_214000034__4, lang.Numbers_Unchecked_inc_J__J(i_214000035__5); continue L1 } } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000032__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000032__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000032__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000032__7); seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000032__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var vec__214000039__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000032__7); var k__9 any = lang.RT_Nth_O_I_O__O(vec__214000039__8, lang.RT_IntCast_J__I(0), nil); var v__10 any = lang.RT_Nth_O_I_O__O(vec__214000039__8, lang.RT_IntCast_J__I(1), nil); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_34).Invoke_O__O(k__9))) {
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_29.GetRawRoot__O()).Invoke_O__O(v__10)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(v__10) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_30.GetRawRoot__O()).Invoke_O__O(v__10)) {
				lang.IFn_Cast(t.F_walk_val).Invoke_O__O(v__10) } else {
//line :41:1
					var tmp2 any; var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_17.GetRawRoot__O()).Invoke_O__O(v__10)

					if jrt.A2g_Truth(and__1927000168__auto____11) { tmp2 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_35).Invoke_O__O(k__9) } else { tmp2 = and__1927000168__auto____11 }
//line :41:1
					if jrt.A2g_Truth(tmp2) {

						lang.IFn_Cast(self).Invoke_O__O(v__10) } } }
//line :40:1
			seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000032__7), nil, 0, 0; continue L1 } else { seq_214000032__2, chunk_214000033__3, count_214000034__4, i_214000035__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000032__7), nil, 0, 0; continue L1 } } } else { return nil } } } }; /*line :27:1*/panic("a2g: unreachable") }
//line :27:1
func A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A{}; t.Ctor_O_O(p0, p1); return t }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Ctor_O_O(c__walk, c__walk_plain any) { t.F_walk = c__walk; t.F_walk_plain = c__walk_plain }
//line :27:1
func (t *A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A) Invoke_O_O__O(self, v__1 any) any {





	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_29.GetRawRoot__O()).Invoke_O__O(v__1)) { return lang.IFn_Cast(t.F_walk).Invoke_O__O(v__1) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_30.GetRawRoot__O()).Invoke_O__O(v__1)) { var seq_214000026__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(v__1); var chunk_214000027__3 any; var count_214000028__4 int64 = 0; var i_214000029__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z(i_214000029__5, count_214000028__4) { var x__6 any = lang.Indexed_Cast(chunk_214000027__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000029__5))
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_29.GetRawRoot__O()).Invoke_O__O(x__6)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(x__6) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_17.GetRawRoot__O()).Invoke_O__O(x__6)) {
				lang.IFn_Cast(t.F_walk_plain).Invoke_O__O(x__6) } else {
//line :35:1
					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_30.GetRawRoot__O()).Invoke_O__O(x__6)) {

						lang.IFn_Cast(self).Invoke_O__O(x__6) } } }
//line :34:1
			seq_214000026__2, chunk_214000027__3, count_214000028__4, i_214000029__5 = seq_214000026__2, chunk_214000027__3, count_214000028__4, lang.Numbers_Unchecked_inc_J__J(i_214000029__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000026__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000026__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000026__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000026__7); seq_214000026__2, chunk_214000027__3, count_214000028__4, i_214000029__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000026__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var x__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000026__7)
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_29.GetRawRoot__O()).Invoke_O__O(x__8)) { lang.IFn_Cast(t.F_walk).Invoke_O__O(x__8) } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_17.GetRawRoot__O()).Invoke_O__O(x__8)) {
					lang.IFn_Cast(t.F_walk_plain).Invoke_O__O(x__8) } else {
//line :35:1
						if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_30.GetRawRoot__O()).Invoke_O__O(x__8)) {

							lang.IFn_Cast(self).Invoke_O__O(x__8) } } }
//line :34:1
				seq_214000026__2, chunk_214000027__3, count_214000028__4, i_214000029__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000026__7), nil, 0, 0; continue L1 } } else { return nil } } } } else {
//line :33:1
					if A_arbace_a2g_reach_A_const_31 != nil { return nil } else { return nil } } }
//line :27:1
	panic("a2g: unreachable")
}


























func A_arbace_a2g_reach_find_method_of_A_New() *A_arbace_a2g_reach_find_method_of_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_find_method_of_A{}; t.Ctor(); return t }
//line :55:1
func (t *A_arbace_a2g_reach_find_method_of_A) Ctor() {}
//line :55:1
func (t *A_arbace_a2g_reach_find_method_of_A) Invoke_O_O_O_O__O(self, c__0, name__1, desc__2 any) any { var temp__1927000408__auto____4 any = A_arbace_a2g_reach_A_const_36.Get__O(); if
													jrt.A2g_Truth(temp__1927000408__auto____4) { var cache__5 any = temp__1927000408__auto____4; var ix__6 any; var or__1927000174__auto____6 any = jrt.HashMap_Cast(cache__5).Get_O__O(c__0)
														if jrt.A2g_Truth(or__1927000174__auto____6) { ix__6 = or__1927000174__auto____6 } else { var ix__7 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_37.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_reach_find_method_of_fn__214000045_A_New(); var tmp3 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_a2g_reach_find_method_of_fn__214000045_A_fn_class
															if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_12, false); A_arbace_a2g_reach_find_method_of_fn__214000045_A_fn_class = fncls__4d; tmp3 = fncls__4d } else { tmp3 = fncls__4 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; var tmp6 any = tmp5.Ref(); var tmp7 *lang.Keyword = A_arbace_a2g_reach_A_const_42; ix__7 = tmp1.Invoke_O_O_O__O(tmp4, tmp6, tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_43.GetRawRoot__O()).Invoke_O__O(c__0)))

			jrt.HashMap_Cast(cache__5).Put_O_O__O(c__0, ix__7)
//line :57:1
			ix__6 = ix__7
		}



		return lang.RT_Get_O_O__O(ix__6, lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2)) } else {
			var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_38.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_reach_find_method_of_fn__214000047_A_New_O_O(name__1, desc__2); var tmp10 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_a2g_reach_find_method_of_fn__214000047_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_13, false); A_arbace_a2g_reach_find_method_of_fn__214000047_A_fn_class = fncls__5d; tmp10 = fncls__5d } else { tmp10 = fncls__5 }; var tmp11 *lang.Keyword = A_arbace_a2g_reach_A_const_42; return tmp8.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil), tmp11.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_43.GetRawRoot__O()).Invoke_O__O(c__0))) } }
//line :58:1
func A_arbace_a2g_reach_find_method_of_fn__214000045_A_New() *A_arbace_a2g_reach_find_method_of_fn__214000045_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_find_method_of_fn__214000045_A{}; t.Ctor(); return t }
//line :58:1
func (t *A_arbace_a2g_reach_find_method_of_fn__214000045_A) Ctor() {}
//line :58:1
func (t *A_arbace_a2g_reach_find_method_of_fn__214000045_A) Invoke_O_O_O__O(self, ix__1, mm__2 any) any { var k__3 any = lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_40.Invoke_O__O(mm__2), A_arbace_a2g_reach_A_const_41.Invoke_O__O(mm__2)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(ix__1, k__3)) { return ix__1 } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_39.GetRawRoot__O()).Invoke_O_O_O__O(ix__1, k__3, mm__2) } }




func A_arbace_a2g_reach_find_method_of_fn__214000047_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_find_method_of_fn__214000047_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_find_method_of_fn__214000047_A{}; t.Ctor_O_O(p0, p1); return t }
//line :63:1
func (t *A_arbace_a2g_reach_find_method_of_fn__214000047_A) Ctor_O_O(c__name, c__desc any) { t.F_name = c__name; t.F_desc = c__desc }
//line :63:1
func (t *A_arbace_a2g_reach_find_method_of_fn__214000047_A) Invoke_O_O__O(self, p1__214000044_SHARP___1 any) any { var tmp1 bool; var tmp2 any = t.F_name; var and__1927000168__auto____2 bool = lang.Util_Equiv_O_O__Z(tmp2, A_arbace_a2g_reach_A_const_40.Invoke_O__O(p1__214000044_SHARP___1)); if and__1927000168__auto____2 { var tmp3 any = t.F_desc; tmp1 = lang.Util_Equiv_O_O__Z(tmp3, A_arbace_a2g_reach_A_const_41.Invoke_O__O(p1__214000044_SHARP___1)) } else { tmp1 = and__1927000168__auto____2 }; if tmp1 { return p1__214000044_SHARP___1 } else { return nil } }

func A_arbace_a2g_reach_java_impl_of_A_New() *A_arbace_a2g_reach_java_impl_of_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_A{}; t.Ctor(); return t }
//line :65:1
func (t *A_arbace_a2g_reach_java_impl_of_A) Ctor() {}
//line :65:1
func (t *A_arbace_a2g_reach_java_impl_of_A) Invoke_O_O_O__O(self, n__0, p__214000052__1 any) any { var vec__214000053__3 any = p__214000052__1; var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000053__3, lang.RT_IntCast_J__I(0), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000053__3, lang.RT_IntCast_J__I(1), nil); var or__1927000174__auto____6 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_New_O_O_O(name__4, desc__5, n__0); var tmp3 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class; if



	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_18, false); A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class = fncls__9d; tmp3 = fncls__9d } else { tmp3 = fncls__9 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_57.GetRawRoot__O()); var tmp6 any = A_arbace_a2g_reach_A_const_58.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_59.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_reach_java_impl_of_fn__214000058_A_New(); var tmp9 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_a2g_reach_java_impl_of_fn__214000058_A_fn_class; if



	fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_19, false); A_arbace_a2g_reach_java_impl_of_fn__214000058_A_fn_class = fncls__10d; tmp9 = fncls__10d } else { tmp9 = fncls__10 }; or__1927000174__auto____6 = /*line :69:1*/tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(tmp6, tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), n__0))); if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else { var cands__7 any; var iter__1927001039__auto____7 any; var tmp10 any = A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A_New_O_O_O(name__4, desc__5, n__0); var tmp11 *jrt.Class
		var fncls__8 /*line :69:1*/*jrt.Class = A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A_fn_class




		if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_20, false); A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A_fn_class = fncls__8d; tmp11 = fncls__8d } else { tmp11 = fncls__8 }; iter__1927001039__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); cands__7 = lang.IFn_Cast(iter__1927001039__auto____7).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_61.GetRawRoot__O()).Invoke_O__O(n__0))
//line :69:1
		var cands__8 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_56.GetRawRoot__O()); var tmp13 any = A_arbace_a2g_reach_java_impl_of_fn__214000070_A_New_O(cands__7); var tmp14 *jrt.Class
		var fncls__12 /*line :69:1*/*jrt.Class = A_arbace_a2g_reach_java_impl_of_fn__214000070_A_fn_class









		if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_21, false); A_arbace_a2g_reach_java_impl_of_fn__214000070_A_fn_class = fncls__12d; tmp14 = fncls__12d } else { tmp14 = fncls__12 }; cands__8 = tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), cands__7)
//line :69:1
		var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(cands__8)










		if jrt.A2g_Truth(temp__1927000414__auto____9) { var c__10 any = temp__1927000414__auto____9; return lang.Tuple_Create_O_O_O__IPersistentVector(c__10, name__4, desc__5) } else { return nil } } }
//line :69:1
func A_arbace_a2g_reach_java_impl_of_fn__214000056_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_java_impl_of_fn__214000056_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000056_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :69:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :69:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000056_A) Invoke_O_O__O(self, c__1 any) any { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_47.GetRawRoot__O()).Invoke_O_O_O__O(c__1, t.F_name, t.F_desc); if
												jrt.A2g_Truth(temp__1927000414__auto____2) { var mm__3 any = temp__1927000414__auto____2; var tmp1 any; var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__3))
													if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_48.GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(or__1927000174__auto____6) { tmp1 = or__1927000174__auto____6 } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(c__1, t.F_n)).Ref() } } else { tmp1 = and__1927000168__auto____5 } } else { tmp1 = and__1927000168__auto____4 }; if jrt.A2g_Truth(tmp1) { return lang.Tuple_Create_O_O_O__IPersistentVector(c__1, t.F_name, t.F_desc) } else { return nil } } else {
//line :70:1
			return nil } }


func A_arbace_a2g_reach_java_impl_of_fn__214000058_A_New() *A_arbace_a2g_reach_java_impl_of_fn__214000058_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000058_A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000058_A) Ctor() {}
//line :73:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000058_A) Invoke_O_O__O(self, p1__214000050_SHARP___1 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_60; return tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_43.GetRawRoot__O()).Invoke_O__O(p1__214000050_SHARP___1)) }
func A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :74:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A) Ctor_O_O_O(c__name, c__desc, c__n any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n }
//line :74:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A) Invoke_O_O__O(self, s__214000061__1 any) any { var tmp1 any = A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A_New_O_O_O_O_O(t.F_name, t.F_desc, t.F_n, self, s__214000061__1); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_23, false); A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :74:1
func A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :74:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A) Ctor_O_O_O_O_O(c__name, c__desc, c__n, c__iter__214000060, c__s__214000061 any) { t.F_name = c__name; t.F_desc = c__desc; t.F_n = c__n; t.F_iter__214000060 = c__iter__214000060; t.F_s__214000061 = c__s__214000061 }
//line :74:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A) Invoke_O__O(self any) any { { var s__214000061__1 any; var t_ any = t.F_s__214000061; t.F_s__214000061 = nil; s__214000061__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000061__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000061__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(s__214000061__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(s__214000061__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000063__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A_New_O_O_O_O_I_O(t.F_name, b__214000063__6, t.F_desc, t.F_n, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_24, false); A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__214000060); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000063__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(s__214000061__3))) } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000063__6), nil) } } else { var c__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(s__214000061__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(c__4, t.F_n)
														if jrt.A2g_Truth(and__1927000168__auto____5) { tmp4 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_46.GetRawRoot__O()).Invoke_O__O(c__4) } else { tmp4 = and__1927000168__auto____5 }
//line :74:1
	if jrt.A2g_Truth(tmp4) { var mm__5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_47.GetRawRoot__O()).Invoke_O_O_O__O(c__4, t.F_name, t.F_desc); var tmp5 any
		var and__1927000168__auto____6 any = mm__5

		if jrt.A2g_Truth(and__1927000168__auto____6) { var and__1927000168__auto____7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_48.GetRawRoot__O()).Invoke_O__O(mm__5)); if jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__5)); if jrt.A2g_Truth(and__1927000168__auto____8) { tmp5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__5)) } else { tmp5 = and__1927000168__auto____8 } } else { tmp5 = and__1927000168__auto____7 } } else { tmp5 = and__1927000168__auto____6 }
//line :74:1
		if jrt.A2g_Truth(tmp5) { var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__214000060); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_53.GetRawRoot__O()).Invoke_O_O__O(c__4, tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000061__3))) } else { s__214000061__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000061__3); continue L1 } } else { s__214000061__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000061__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :74:1
func A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A_New_O_O_O_O_I_O(p0, p1, p2, p3 any, p4 int32, p5 any) *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A{}; t.Ctor_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5); return t }
//line :74:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A) Ctor_O_O_O_O_I_O(c__name, c__b__214000063, c__desc, c__n any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_name = c__name; t.F_b__214000063 = c__b__214000063; t.F_desc = c__desc; t.F_n = c__n; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :74:1
func (t *A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A) Invoke_O__O(self any) any { { var i__214000062__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000062__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var c__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000062__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(c__2, t.F_n)
																if jrt.A2g_Truth(and__1927000168__auto____3) { tmp2 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_46.GetRawRoot__O()).Invoke_O__O(c__2) } else { tmp2 = and__1927000168__auto____3 }
//line :74:1
	if jrt.A2g_Truth(tmp2) { var mm__3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_47.GetRawRoot__O()).Invoke_O_O_O__O(c__2, t.F_name, t.F_desc); var tmp3 any
		var and__1927000168__auto____4 any = mm__3

		if jrt.A2g_Truth(and__1927000168__auto____4) { var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_48.GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__3)); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp3 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__3)) } else { tmp3 = and__1927000168__auto____6 } } else { tmp3 = and__1927000168__auto____5 } } else { tmp3 = and__1927000168__auto____4 }
//line :74:1
		if jrt.A2g_Truth(tmp3) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_51.GetRawRoot__O()).Invoke_O_O__O(t.F_b__214000063, c__2); i__214000062__1 = lang.Numbers_Unchecked_inc_J__J(i__214000062__1); continue L1 } else { i__214000062__1 = lang.Numbers_Unchecked_inc_J__J(i__214000062__1); continue L1 } } else { i__214000062__1 = lang.Numbers_Unchecked_inc_J__J(i__214000062__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }




func A_arbace_a2g_reach_java_impl_of_fn__214000070_A_New_O(p0 any) *A_arbace_a2g_reach_java_impl_of_fn__214000070_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000070_A{}; t.Ctor_O(p0); return t }
//line :79:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000070_A) Ctor_O(c__cands any) { t.F_cands = c__cands }
//line :79:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000070_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A_New_O(x__1); var tmp3 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A_fn_class; if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_22, false); A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A_fn_class = fncls__11d; tmp3 = fncls__11d } else { tmp3 = fncls__11 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), t.F_cands) }
//line :79:1
func A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A_New_O(p0 any) *A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A{}; t.Ctor_O(p0); return t }
//line :79:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A) Ctor_O(c__x any) { t.F_x = c__x }
//line :79:1
func (t *A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A) Invoke_O_O__O(self, p1__214000051_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(p1__214000051_SHARP___1, t.F_x); if jrt.A2g_Truth(and__1927000168__auto____2) { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_62.GetRawRoot__O()).Invoke_O_O__O(p1__214000051_SHARP___1, t.F_x) } else { return and__1927000168__auto____2 } }












func A_arbace_a2g_reach_note_unavailable_BANG__A_New() *A_arbace_a2g_reach_note_unavailable_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_note_unavailable_BANG__A{}; t.Ctor(); return t }
//line :92:1
func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Ctor() {}
//line :92:1
func (t *A_arbace_a2g_reach_note_unavailable_BANG__A) Invoke_O_O__O(self, why__0 any) any {
	if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_63.Get__O()) {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()); var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_65; var tmp3 any = tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()); var tmp4 any = A_arbace_a2g_reach_A_const_67.GetRawRoot__O(); var tmp5 any = A_arbace_a2g_reach_A_const_63.Get__O(); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_68.GetRawRoot__O()); var tmp7 any = A_arbace_a2g_reach_A_const_14.GetRawRoot__O(); var tmp8 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp8 = lang.PersistentHashSet_EMPTY; return tmp1.Invoke_O_O_O_O_O__O(tmp3, tmp4, tmp5, tmp6.Invoke_O_O__O(tmp7, tmp8.Ref()), why__0) } else {
//line :93:1
			return nil
		}
}


func A_arbace_a2g_reach_hw_has_static_QMARK__A_New() *A_arbace_a2g_reach_hw_has_static_QMARK__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_hw_has_static_QMARK__A{}; t.Ctor(); return t }
//line :98:1
func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Ctor() {}
//line :98:1
func (t *A_arbace_a2g_reach_hw_has_static_QMARK__A) Invoke_O_O_O_O__O(self, cls__0, name__1, desc__2 any) any { var g__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_69.GetRawRoot__O()).Invoke_O__O(cls__0); var base__5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_70.GetRawRoot__O()).Invoke_O_O__O(name__1, desc__2); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_71; var scan__6 any = tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_72.Get__O()); var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_74.Invoke_O__O(scan__6), lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, nil, Lit_15, nil), jrt.RefArrayOf(jrt.Object_class, g__4, nil, base__5)).Ref()); if



	jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else {
		return lang.IFn_Cast(A_arbace_a2g_reach_A_const_73.GetRawRoot__O()).Invoke_O_O__O(cls__0, base__5) } }

func A_arbace_a2g_reach_hw_has_field_QMARK__A_New() *A_arbace_a2g_reach_hw_has_field_QMARK__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_hw_has_field_QMARK__A{}; t.Ctor(); return t }
//line :105:1
func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Ctor() {}
//line :105:1
func (t *A_arbace_a2g_reach_hw_has_field_QMARK__A) Invoke_O_O_O_O__O(self, cls__0, fname__1, static_QMARK___2 any) any { var g__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_69.GetRawRoot__O()).Invoke_O__O(cls__0); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_71; var scan__5 any = tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_72.Get__O()); if


	jrt.A2g_Truth(static_QMARK___2) { var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_75.Invoke_O__O(scan__5), lang.IFn_Cast(A_arbace_a2g_reach_A_const_76.GetRawRoot__O()).Invoke_O_O__O(g__4, fname__1))
		if jrt.A2g_Truth(or__1927000174__auto____6) { return or__1927000174__auto____6 } else {
			return lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_77.Invoke_O__O(scan__5), lang.IFn_Cast(A_arbace_a2g_reach_A_const_76.GetRawRoot__O()).Invoke_O_O__O(g__4, fname__1)) } } else {
//line :108:1
				jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } }




func A_arbace_a2g_reach_use_BANG__A_New() *A_arbace_a2g_reach_use_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__A{}; t.Ctor(); return t }
//line :113:1
func (t *A_arbace_a2g_reach_use_BANG__A) Ctor() {}
//line :113:1
func (t *A_arbace_a2g_reach_use_BANG__A) Invoke_O_O__O(self, n__0 any) any {



	if lang.Util_Identical_O_O__Z(n__0, nil) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if lang.Util_Equiv_O_O__Z(n__0, Lit_1) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_78.GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_86; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), n__0)) {



		var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_86; lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil, lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), n__0))).Ref())
//line :117:1
		jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var tmp3 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_79.GetRawRoot__O()).Invoke_O__O(n__0)




			if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_88; tmp3 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_79.GetRawRoot__O()).Invoke_O__O(n__0))) } else { tmp3 = and__1927000168__auto____2 }
//line :117:1
			if jrt.A2g_Truth(tmp3) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { var tmp5 any; var and__1927000168__auto____2_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_79.GetRawRoot__O()).Invoke_O__O(n__0)






				if jrt.A2g_Truth(and__1927000168__auto____2_2) { tmp5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_89.Get__O()).Invoke_O__O(n__0)) } else { tmp5 = and__1927000168__auto____2_2 }
//line :117:1
				if jrt.A2g_Truth(tmp5) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_80.GetRawRoot__O()).Invoke_O__O(n__0)) { var d__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(n__0); var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_82; var temp__1927000408__auto____3 any = tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_90.Invoke_O__O(d__2)))









					if jrt.A2g_Truth(temp__1927000408__auto____3) { var why__4 any = temp__1927000408__auto____3; var tmp7 *lang.Keyword = A_arbace_a2g_reach_A_const_86
						lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp7.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_39.GetRawRoot__O(), n__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, why__4)).Ref())
						lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_74), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil)).Ref())
//line :127:1
						jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else {




							var tmp8 *lang.Keyword = A_arbace_a2g_reach_A_const_91; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp8.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), n__0)
//line :127:1
							var sup__4 any = A_arbace_a2g_reach_A_const_60.Invoke_O__O(d__2); var ok__5 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O())
							var tmp10 any = A_arbace_a2g_reach_A_const_63





							lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp9.Invoke_O_O__O(tmp10, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_75, Lit_65))); var tmp11 any = A_arbace_a2g_reach_use_BANG__fn__214000078_A_New_O(sup__4); var tmp12 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_a2g_reach_use_BANG__fn__214000078_A_fn_class; if fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_76, false); A_arbace_a2g_reach_use_BANG__fn__214000078_A_fn_class = fncls__13d; tmp12 = fncls__13d } else { tmp12 = fncls__13 }; ok__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil).Invoke__O()
							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(ok__5)) {
								var tmp13 *lang.Keyword = A_arbace_a2g_reach_A_const_91; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp13.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_94.GetRawRoot__O(), n__0)
								var tmp14 *lang.Keyword = A_arbace_a2g_reach_A_const_86; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O_O__O(tmp14.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_39.GetRawRoot__O(), n__0, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_77, nil, Lit_78), jrt.RefArrayOf(jrt.Object_class, nil, sup__4, nil)).Ref())
								lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_79, nil, Lit_78), jrt.RefArrayOf(jrt.Object_class, nil, n__0, nil, sup__4, nil)).Ref())
//line :135:1
								jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { var seq_214000080__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_96.Invoke_O__O(d__2)); var chunk_214000081__7 any; var count_214000082__8 int64 = 0; var i_214000083__9 int64 = 0; L1: for {





									if lang.Numbers_Lt_J_J__Z(i_214000083__9, count_214000082__8) { var i__10 any = lang.Indexed_Cast(chunk_214000081__7).Nth_I__O(lang.RT_IntCast_J__I(i_214000083__9)); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_reach_A_const_63; lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp15.Invoke_O_O__O(tmp16, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_75, Lit_65))); var tmp17 any = A_arbace_a2g_reach_use_BANG__fn__214000084_A_New_O(i__10); var tmp18 *jrt.Class; var fncls__15 *jrt.Class = A_arbace_a2g_reach_use_BANG__fn__214000084_A_fn_class; if fncls__15 == nil { var fncls__15d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_80, false); A_arbace_a2g_reach_use_BANG__fn__214000084_A_fn_class = fncls__15d; tmp18 = fncls__15d } else { tmp18 = fncls__15 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O(); seq_214000080__6, chunk_214000081__7, count_214000082__8, i_214000083__9 = seq_214000080__6, chunk_214000081__7, count_214000082__8, lang.Numbers_Unchecked_inc_J__J(i_214000083__9); continue L1 } else { var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000080__6); if jrt.A2g_Truth(temp__1927000414__auto____10) { var seq_214000080__11 any = temp__1927000414__auto____10; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000080__11)) { var c__1927000678__auto____12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000080__11); seq_214000080__6, chunk_214000081__7, count_214000082__8, i_214000083__9 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000080__11), c__1927000678__auto____12, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____12))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var i__12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000080__11); var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()); var tmp20 any = A_arbace_a2g_reach_A_const_63; lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O_O__O(tmp20, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_75, Lit_65))); var tmp21 any = A_arbace_a2g_reach_use_BANG__fn__214000086_A_New_O(i__12); var tmp22 *jrt.Class; var fncls__16 *jrt.Class = A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class; if fncls__16 == nil { var fncls__16d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_81, false); A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class = fncls__16d; tmp22 = fncls__16d } else { tmp22 = fncls__16 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil).Invoke__O(); seq_214000080__6, chunk_214000081__7, count_214000082__8, i_214000083__9 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000080__11), nil, 0, 0; continue L1 } } }
//line :135:1
									break L1 }; var temp__1927000414__auto____6 any = A_arbace_a2g_reach_A_const_95.Invoke_O__O(d__2)







									if jrt.A2g_Truth(temp__1927000414__auto____6) { var o__7 any = temp__1927000414__auto____6; var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()); var tmp24 any = A_arbace_a2g_reach_A_const_63; lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp23.Invoke_O_O__O(tmp24, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_75, Lit_65))); var tmp25 any = A_arbace_a2g_reach_use_BANG__fn__214000088_A_New_O(o__7); var tmp26 *jrt.Class; var fncls__14 *jrt.Class = A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class; if fncls__14 == nil { var fncls__14d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_82, false); A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class = fncls__14d; tmp26 = fncls__14d } else { tmp26 = fncls__14 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil).Invoke__O() }
//line :135:1
									jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } } else {
//line :117:1
										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_79.GetRawRoot__O()).Invoke_O__O(n__0)) { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_85.GetRawRoot__O()).Invoke_O__O(n__0)) {































											var tmp27 *lang.Keyword = A_arbace_a2g_reach_A_const_91; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp27.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), n__0)
//line :117:1
											var tmp28 *lang.Keyword = A_arbace_a2g_reach_A_const_96; var seq_214000090__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(tmp28.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_43.GetRawRoot__O()).Invoke_O__O(n__0))); var chunk_214000091__3 any; var count_214000092__4 int64 = 0; var i_214000093__5 int64 = 0; L2: for {
































												if lang.Numbers_Lt_J_J__Z(i_214000093__5, count_214000092__4) { var i__6 any = lang.Indexed_Cast(chunk_214000091__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000093__5)); var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()); var tmp30 any = A_arbace_a2g_reach_A_const_63; lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp29.Invoke_O_O__O(tmp30, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_75, Lit_65))); var tmp31 any = A_arbace_a2g_reach_use_BANG__fn__214000094_A_New_O(i__6); var tmp32 *jrt.Class; var fncls__17 *jrt.Class = A_arbace_a2g_reach_use_BANG__fn__214000094_A_fn_class; if fncls__17 == nil { var fncls__17d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_83, false); A_arbace_a2g_reach_use_BANG__fn__214000094_A_fn_class = fncls__17d; tmp32 = fncls__17d } else { tmp32 = fncls__17 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp31, tmp32, nil).Invoke__O(); seq_214000090__2, chunk_214000091__3, count_214000092__4, i_214000093__5 = seq_214000090__2, chunk_214000091__3, count_214000092__4, lang.Numbers_Unchecked_inc_J__J(i_214000093__5); continue L2 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000090__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_214000090__7 any = temp__1927000414__auto____6_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000090__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000090__7); seq_214000090__2, chunk_214000091__3, count_214000092__4, i_214000093__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000090__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var i__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000090__7); var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()); var tmp34 any = A_arbace_a2g_reach_A_const_63; lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(tmp33.Invoke_O_O__O(tmp34, lang.Tuple_Create_O_O_O__IPersistentVector(n__0, Lit_75, Lit_65))); var tmp35 any = A_arbace_a2g_reach_use_BANG__fn__214000096_A_New_O(i__8); var tmp36 *jrt.Class; var fncls__18 *jrt.Class = A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class; if fncls__18 == nil { var fncls__18d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_84, false); A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class = fncls__18d; tmp36 = fncls__18d } else { tmp36 = fncls__18 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil).Invoke__O(); seq_214000090__2, chunk_214000091__3, count_214000092__4, i_214000093__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000090__7), nil, 0, 0; continue L2 } } }
//line :117:1
												break L2 }; jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } else { if A_arbace_a2g_reach_A_const_31 != nil {


































													var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()); var tmp38 *lang.Keyword = A_arbace_a2g_reach_A_const_97; var tmp39 any = tmp38.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()); var tmp40 any = A_arbace_a2g_reach_A_const_67.GetRawRoot__O(); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_68.GetRawRoot__O()); var tmp42 any = A_arbace_a2g_reach_A_const_14.GetRawRoot__O(); var tmp43 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp43 = lang.PersistentHashSet_EMPTY; tmp37.Invoke_O_O_O_O_O__O(tmp39, tmp40, n__0, tmp41.Invoke_O_O__O(tmp42, tmp43.Ref()), A_arbace_a2g_reach_A_const_63.Get__O())
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_72, nil, Lit_85), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_reach_A_const_98.GetRawRoot__O()).Invoke_O_O_O__O(n__0, Lit_5, Lit_4), nil)).Ref())
//line :117:1
													jrt.Boolean_Init(); return jrt.Boolean_FALSE.Ref() } else { return nil
													}
												}
										}
									}
				}
			}
		}
	}
	}
	}
}





func A_arbace_a2g_reach_use_BANG__fn__214000078_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000078_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000078_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000078_A) Ctor_O(c__sup any) { t.F_sup = c__sup }
//line :134:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000078_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_sup; t.F_sup = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }






func A_arbace_a2g_reach_use_BANG__fn__214000084_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000084_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000084_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000084_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :141:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000084_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :141:1
func A_arbace_a2g_reach_use_BANG__fn__214000086_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000086_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000086_A{}; t.Ctor_O(p0); return t }
//line :141:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :141:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000086_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }

func A_arbace_a2g_reach_use_BANG__fn__214000088_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000088_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000088_A{}; t.Ctor_O(p0); return t }
//line :143:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Ctor_O(c__o any) { t.F_o = c__o }
//line :143:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000088_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_o; t.F_o = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }






func A_arbace_a2g_reach_use_BANG__fn__214000094_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000094_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000094_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000094_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :150:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000094_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }
//line :150:1
func A_arbace_a2g_reach_use_BANG__fn__214000096_A_New_O(p0 any) *A_arbace_a2g_reach_use_BANG__fn__214000096_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_BANG__fn__214000096_A{}; t.Ctor_O(p0); return t }
//line :150:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Ctor_O(c__i any) { t.F_i = c__i }
//line :150:1
func (t *A_arbace_a2g_reach_use_BANG__fn__214000096_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_i; t.F_i = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }





func A_arbace_a2g_reach_use_desc_BANG__A_New() *A_arbace_a2g_reach_use_desc_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_use_desc_BANG__A{}; t.Ctor(); return t }
//line :156:1
func (t *A_arbace_a2g_reach_use_desc_BANG__A) Ctor() {}
//line :156:1
func (t *A_arbace_a2g_reach_use_desc_BANG__A) Invoke_O_O__O(self, d__0 any) any { { var seq_214000099__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_99.GetRawRoot__O()).Invoke_O__O(d__0)); var chunk_214000100__3 any; var count_214000101__4 int64 = 0; var i_214000102__5 int64 = 0; L1: for {
										if lang.Numbers_Lt_J_J__Z(i_214000102__5, count_214000101__4) { var c__6 any = lang.Indexed_Cast(chunk_214000100__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000102__5)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__6); seq_214000099__2, chunk_214000100__3, count_214000101__4, i_214000102__5 = seq_214000099__2, chunk_214000100__3, count_214000101__4, lang.Numbers_Unchecked_inc_J__J(i_214000102__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000099__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000099__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000099__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000099__7); seq_214000099__2, chunk_214000100__3, count_214000101__4, i_214000102__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000099__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000099__7); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__8); seq_214000099__2, chunk_214000100__3, count_214000101__4, i_214000102__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000099__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :156:1*/panic("a2g: unreachable") }


func A_arbace_a2g_reach_reach_BANG__A_New() *A_arbace_a2g_reach_reach_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_reach_BANG__A{}; t.Ctor(); return t }
//line :159:1
func (t *A_arbace_a2g_reach_reach_BANG__A) Ctor() {}
//line :159:1
func (t *A_arbace_a2g_reach_reach_BANG__A) Invoke_O_O__O(self, p__214000104__0 any) any { var vec__214000105__2 any = p__214000104__0; var c__3 any = lang.RT_Nth_O_I_O__O(vec__214000105__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000105__2, lang.RT_IntCast_J__I(1), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000105__2, lang.RT_IntCast_J__I(2), nil); var k__6 any = vec__214000105__2; var tmp1 any; var and__1927000168__auto____7 any = c__3; _ = name__4; _ = desc__5; if


	jrt.A2g_Truth(and__1927000168__auto____7) { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_78.GetRawRoot__O()).Invoke_O__O(c__3); if jrt.A2g_Truth(and__1927000168__auto____8) { var and__1927000168__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(c__3); if jrt.A2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_89.Get__O()).Invoke_O__O(c__3); if jrt.A2g_Truth(and__1927000168__auto____10) { var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_100; tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), k__6)) } else { tmp1 = and__1927000168__auto____10 } } else { tmp1 = and__1927000168__auto____9 } } else { tmp1 = and__1927000168__auto____8 } } else { tmp1 = and__1927000168__auto____7 }; if jrt.A2g_Truth(tmp1) {
		var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_100; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), k__6)
		var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_101; return lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), k__6) } else {
//line :162:1
			return nil } }



func A_arbace_a2g_reach_init_BANG__A_New() *A_arbace_a2g_reach_init_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_init_BANG__A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_a2g_reach_init_BANG__A) Ctor() {}
//line :166:1
func (t *A_arbace_a2g_reach_init_BANG__A) Invoke_O_O__O(self, c__0 any) any {


	var tmp1 any; var and__1927000168__auto____2 any = c__0; if jrt.A2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_78.GetRawRoot__O()).Invoke_O__O(c__0); if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(c__0); if jrt.A2g_Truth(and__1927000168__auto____4) { var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_103; tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), c__0)) } else { tmp1 = and__1927000168__auto____4 } } else { tmp1 = and__1927000168__auto____3 } } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_103; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), c__0)
//line :169:1
		var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_60; var temp__1927000414__auto____2 any = tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(c__0))

		if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__3 any = temp__1927000414__auto____2; lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(s__3) }
		return lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(c__0, Lit_16, Lit_17)) } else {
//line :169:1
			return nil
		}
}


func A_arbace_a2g_reach_external_keys_A_New() *A_arbace_a2g_reach_external_keys_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_external_keys_A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_a2g_reach_external_keys_A) Ctor() {}
//line :174:1
func (t *A_arbace_a2g_reach_external_keys_A) Invoke_O_O__O(self, d__0 any) any { var iter__1927001039__auto____2 any; var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A_New(); var tmp2 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A_fn_class; if



	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_6, false); A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A_fn_class = fncls__23d; tmp2 = fncls__23d } else { tmp2 = fncls__23 }; iter__1927001039__auto____2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); return lang.IFn_Cast(iter__1927001039__auto____2).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_61.GetRawRoot__O()).Invoke_O__O(d__0)) }
//line :178:1
func A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A_New() *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A) Ctor() {}
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A) Invoke_O_O__O(self, s__214000111__1 any) any { var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A_New_O_O(s__214000111__1, self); var tmp2 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A_fn_class; if fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_7, false); A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A_fn_class = fncls__22d; tmp2 = fncls__22d } else { tmp2 = fncls__22 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :178:1
func A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A) Ctor_O_O(c__s__214000111, c__iter__214000110 any) { t.F_s__214000111 = c__s__214000111; t.F_iter__214000110 = c__iter__214000110 }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A) Invoke_O__O(self any) any { { var s__214000111__1 any; var t_ any = t.F_s__214000111; t.F_s__214000111 = nil; s__214000111__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000111__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var s__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var tmp1 any; var or__1927000174__auto____5 bool = lang.Util_Equiv_O_O__Z(s__4, Lit_1)
														if or__1927000174__auto____5 { tmp1 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5).Ref() } else { tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_79.GetRawRoot__O()).Invoke_O__O(s__4) }
//line :178:1
	if jrt.A2g_Truth(tmp1) { var iterys__1927001035__auto____5 any; var tmp2 any = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A_New(); var tmp3 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A_fn_class; if fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_8, false); A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A_fn_class = fncls__21d; tmp3 = fncls__21d } else { tmp3 = fncls__21 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_42; var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_43.GetRawRoot__O()).Invoke_O__O(s__4)))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__214000110); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_105.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000111__1))) } else { s__214000111__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000111__1); continue L1 } } else { s__214000111__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000111__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :178:1
func A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A_New() *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A) Ctor() {}
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A) Invoke_O_O__O(self, s__214000113__1 any) any { var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A_New_O_O(s__214000113__1, self); var tmp2 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A_fn_class; if fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_9, false); A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A_fn_class = fncls__20d; tmp2 = fncls__20d } else { tmp2 = fncls__20 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :178:1
func A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A{}; t.Ctor_O_O(p0, p1); return t }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A) Ctor_O_O(c__s__214000113, c__iter__214000112 any) { t.F_s__214000113 = c__s__214000113; t.F_iter__214000112 = c__iter__214000112 }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A) Invoke_O__O(self any) any { { var s__214000113__1 any; var t_ any = t.F_s__214000113; t.F_s__214000113 = nil; s__214000113__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000113__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000113__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(s__214000113__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(s__214000113__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000115__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A_New_O_I_O(b__214000115__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_10, false); A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A_fn_class = fncls__19d; tmp2 = fncls__19d } else { tmp2 = fncls__19 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__214000112); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000115__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(s__214000113__3))) } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000115__6), nil) } } else { var mm__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(s__214000113__3); var tmp4 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__4))


	if jrt.A2g_Truth(and__1927000168__auto____5) { var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__4)); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp4 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_11, A_arbace_a2g_reach_A_const_40.Invoke_O__O(mm__4)) } else { tmp4 = and__1927000168__auto____6 } } else { tmp4 = and__1927000168__auto____5 }
//line :178:1
	if jrt.A2g_Truth(tmp4) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__214000112); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_53.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_40.Invoke_O__O(mm__4), A_arbace_a2g_reach_A_const_41.Invoke_O__O(mm__4)), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000113__3))) } else { s__214000113__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000113__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :178:1
func A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A) Ctor_O_I_O(c__b__214000115 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__214000115 = c__b__214000115; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :178:1
func (t *A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A) Invoke_O__O(self any) any { { var i__214000114__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000114__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var mm__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000114__1)); var tmp2 any; var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__2))


	if jrt.A2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__2)); if jrt.A2g_Truth(and__1927000168__auto____4) { tmp2 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(Lit_11, A_arbace_a2g_reach_A_const_40.Invoke_O__O(mm__2)) } else { tmp2 = and__1927000168__auto____4 } } else { tmp2 = and__1927000168__auto____3 }
//line :178:1
	if jrt.A2g_Truth(tmp2) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_51.GetRawRoot__O()); var tmp4 any = t.F_b__214000115; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_40.Invoke_O__O(mm__2), A_arbace_a2g_reach_A_const_41.Invoke_O__O(mm__2))); i__214000114__1 = lang.Numbers_Unchecked_inc_J__J(i__214000114__1); continue L1 } else { i__214000114__1 = lang.Numbers_Unchecked_inc_J__J(i__214000114__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }





func A_arbace_a2g_reach_supertypes_of_A_New() *A_arbace_a2g_reach_supertypes_of_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_supertypes_of_A{}; t.Ctor(); return t }
//line :184:1
func (t *A_arbace_a2g_reach_supertypes_of_A) Ctor() {}
//line :184:1
func (t *A_arbace_a2g_reach_supertypes_of_A) Invoke_O_O__O(self, d__0 any) any { var s__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_61.GetRawRoot__O()).Invoke_O__O(d__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_38.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_reach_supertypes_of_fn__214000128_A_New(); var tmp3 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_a2g_reach_supertypes_of_fn__214000128_A_fn_class; if



	fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_71, false); A_arbace_a2g_reach_supertypes_of_fn__214000128_A_fn_class = fncls__24d; tmp3 = fncls__24d } else { tmp3 = fncls__24 }; if jrt.A2g_Truth(tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), s__2)) { return s__2 } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_14.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_106.GetRawRoot__O()).Invoke_O__O(s__2), Lit_1) } }
//line :188:1
func A_arbace_a2g_reach_supertypes_of_fn__214000128_A_New() *A_arbace_a2g_reach_supertypes_of_fn__214000128_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_supertypes_of_fn__214000128_A{}; t.Ctor(); return t }
//line :188:1
func (t *A_arbace_a2g_reach_supertypes_of_fn__214000128_A) Ctor() {}
//line :188:1
func (t *A_arbace_a2g_reach_supertypes_of_fn__214000128_A) Invoke_O_O__O(self, p1__214000127_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean(lang.Util_Equiv_O_O__Z(Lit_1, p1__214000127_SHARP___1)).Ref() }

func A_arbace_a2g_reach_vcalls_on_A_New() *A_arbace_a2g_reach_vcalls_on_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_A{}; t.Ctor(); return t }
//line :190:1
func (t *A_arbace_a2g_reach_vcalls_on_A) Ctor() {}
//line :190:1
func (t *A_arbace_a2g_reach_vcalls_on_A) Invoke_O_O__O(self, d__0 any) any { var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_107; var by__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())); var iter__1927001039__auto____3 any; var tmp2 any = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A_New_O(by__2); var tmp3 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A_fn_class; if




	fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_87, false); A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A_fn_class = fncls__29d; tmp3 = fncls__29d } else { tmp3 = fncls__29 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); return lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_108.GetRawRoot__O()).Invoke_O__O(d__0)) }
//line :195:1
func A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A_New_O(p0 any) *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A{}; t.Ctor_O(p0); return t }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A) Ctor_O(c__by any) { t.F_by = c__by }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A) Invoke_O_O__O(self, s__214000132__1 any) any { var tmp1 any = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A_New_O_O_O(s__214000132__1, t.F_by, self); var tmp2 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A_fn_class; if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_88, false); A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A_fn_class = fncls__28d; tmp2 = fncls__28d } else { tmp2 = fncls__28 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :195:1
func A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A) Ctor_O_O_O(c__s__214000132, c__by, c__iter__214000131 any) { t.F_s__214000132 = c__s__214000132; t.F_by = c__by; t.F_iter__214000131 = c__iter__214000131 }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A) Invoke_O__O(self any) any { { var s__214000132__1 any; var t_ any = t.F_s__214000132; t.F_s__214000132 = nil; s__214000132__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000132__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var s__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A_New(); var tmp2 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A_fn_class; if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_89, false); A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A_fn_class = fncls__27d; tmp2 = fncls__27d } else { tmp2 = fncls__27 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.RT_Get_O_O__O(t.F_by, s__4))); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__214000131); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_105.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000132__1))) } else { s__214000132__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000132__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :195:1
func A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A_New() *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A{}; t.Ctor(); return t }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A) Ctor() {}
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A) Invoke_O_O__O(self, s__214000134__1 any) any { var tmp1 any = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A_New_O_O(s__214000134__1, self); var tmp2 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A_fn_class; if fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_90, false); A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A_fn_class = fncls__26d; tmp2 = fncls__26d } else { tmp2 = fncls__26 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :195:1
func A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A_New_O_O(p0, p1 any) *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A{}; t.Ctor_O_O(p0, p1); return t }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A) Ctor_O_O(c__s__214000134, c__iter__214000133 any) { t.F_s__214000134 = c__s__214000134; t.F_iter__214000133 = c__iter__214000133 }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A) Invoke_O__O(self any) any { { var s__214000134__1 any; var t_ any = t.F_s__214000134; t.F_s__214000134 = nil; s__214000134__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000134__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000134__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(s__214000134__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(s__214000134__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000136__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A_New_O_I_O(b__214000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A_fn_class; if fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_91, false); A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A_fn_class = fncls__25d; tmp2 = fncls__25d } else { tmp2 = fncls__25 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__214000133); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000136__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(s__214000134__3))) } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000136__6), nil) } } else { var nd__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(s__214000134__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__214000133); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_53.GetRawRoot__O()).Invoke_O_O__O(nd__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000134__3))) } } else { return nil } } }; panic("a2g: unreachable") }
//line :195:1
func A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A) Ctor_O_I_O(c__b__214000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__214000136 = c__b__214000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :195:1
func (t *A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A) Invoke_O__O(self any) any { { var i__214000135__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nd__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000135__1)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_51.GetRawRoot__O()).Invoke_O_O__O(t.F_b__214000136, nd__2); i__214000135__1 = lang.Numbers_Unchecked_inc_J__J(i__214000135__1); continue L1 } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }

func A_arbace_a2g_reach_instantiate_BANG__A_New() *A_arbace_a2g_reach_instantiate_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_instantiate_BANG__A{}; t.Ctor(); return t }
//line :197:1
func (t *A_arbace_a2g_reach_instantiate_BANG__A) Ctor() {}
//line :197:1
func (t *A_arbace_a2g_reach_instantiate_BANG__A) Invoke_O_O__O(self, d__0 any) any {

	{ var tmp1 any; var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_78.GetRawRoot__O()).Invoke_O__O(d__0); if jrt.A2g_Truth(and__1927000168__auto____2) { var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_109; tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), d__0)) } else { tmp1 = and__1927000168__auto____2 }; if jrt.A2g_Truth(tmp1) {
		var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_109; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), d__0)
//line :199:1
		var seq_214000148__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_108.GetRawRoot__O()).Invoke_O__O(d__0)); var chunk_214000149__3 any; var count_214000150__4 int64 = 0; var i_214000151__5 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z(i_214000151__5, count_214000150__4) { var s__6 any = lang.Indexed_Cast(chunk_214000149__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000151__5)); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()); var tmp5 *lang.Keyword = A_arbace_a2g_reach_A_const_110; var tmp6 any = tmp5.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()); var tmp7 any = A_arbace_a2g_reach_A_const_67.GetRawRoot__O(); var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_68.GetRawRoot__O()); var tmp9 any = A_arbace_a2g_reach_A_const_14.GetRawRoot__O(); var tmp10 *lang.PersistentVector
				lang.PersistentVector_Init(); tmp10 = lang.PersistentVector_EMPTY; tmp4.Invoke_O_O_O_O_O__O(tmp6, tmp7, s__6, tmp8.Invoke_O_O__O(tmp9, tmp10.Ref()), d__0)
//line :201:1
				seq_214000148__2, chunk_214000149__3, count_214000150__4, i_214000151__5 = seq_214000148__2, chunk_214000149__3, count_214000150__4, lang.Numbers_Unchecked_inc_J__J(i_214000151__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000148__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000148__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000148__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000148__7); seq_214000148__2, chunk_214000149__3, count_214000150__4, i_214000151__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000148__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var s__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000148__7); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()); var tmp12 *lang.Keyword = A_arbace_a2g_reach_A_const_110; var tmp13 any = tmp12.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()); var tmp14 any = A_arbace_a2g_reach_A_const_67.GetRawRoot__O(); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_68.GetRawRoot__O()); var tmp16 any = A_arbace_a2g_reach_A_const_14.GetRawRoot__O(); var tmp17 *lang.PersistentVector
					lang.PersistentVector_Init(); tmp17 = lang.PersistentVector_EMPTY; tmp11.Invoke_O_O_O_O_O__O(tmp13, tmp14, s__8, tmp15.Invoke_O_O__O(tmp16, tmp17.Ref()), d__0)
//line :201:1
					seq_214000148__2, chunk_214000149__3, count_214000150__4, i_214000151__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000148__7), nil, 0, 0; continue L1 } } }
//line :199:1
			break L1 }; var seq_214000152__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_111.GetRawRoot__O()).Invoke_O__O(d__0)); var chunk_214000153__3 any; var count_214000154__4 int64 = 0; var i_214000155__5 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z(i_214000155__5, count_214000154__4) { var nd__6 any = lang.Indexed_Cast(chunk_214000153__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000155__5)); var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(d__0, nd__6)
					if jrt.A2g_Truth(temp__1927000414__auto____7) { var k__8 any = temp__1927000414__auto____7; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(k__8) }
//line :203:1
					seq_214000152__2, chunk_214000153__3, count_214000154__4, i_214000155__5 = seq_214000152__2, chunk_214000153__3, count_214000154__4, lang.Numbers_Unchecked_inc_J__J(i_214000155__5); continue L2 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000152__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_214000152__7 any = temp__1927000414__auto____6_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000152__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000152__7); seq_214000152__2, chunk_214000153__3, count_214000154__4, i_214000155__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000152__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var nd__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000152__7); var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(d__0, nd__8)
						if jrt.A2g_Truth(temp__1927000414__auto____9) { var k__10 any = temp__1927000414__auto____9; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(k__10) }
//line :203:1
						seq_214000152__2, chunk_214000153__3, count_214000154__4, i_214000155__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000152__7), nil, 0, 0; continue L2 } } }
//line :199:1
				break L2 }; var seq_214000156__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_114.GetRawRoot__O()).Invoke_O__O(d__0))); var chunk_214000157__3 any; var count_214000158__4 int64 = 0; var i_214000159__5 int64 = 0; L3: for {





					if lang.Numbers_Lt_J_J__Z(i_214000159__5, count_214000158__4) { var k__6 any = lang.Indexed_Cast(chunk_214000157__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000159__5)); var temp__1927000414__auto____7_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(d__0, k__6)
						if jrt.A2g_Truth(temp__1927000414__auto____7_2) { var impl__8 any = temp__1927000414__auto____7_2; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__8) }
//line :205:1
						seq_214000156__2, chunk_214000157__3, count_214000158__4, i_214000159__5 = seq_214000156__2, chunk_214000157__3, count_214000158__4, lang.Numbers_Unchecked_inc_J__J(i_214000159__5); continue L3 } else { var temp__1927000414__auto____6_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000156__2); if jrt.A2g_Truth(temp__1927000414__auto____6_3) { var seq_214000156__7 any = temp__1927000414__auto____6_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000156__7)) { var c__1927000678__auto____8_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000156__7); seq_214000156__2, chunk_214000157__3, count_214000158__4, i_214000159__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000156__7), c__1927000678__auto____8_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_3))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var k__8_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000156__7); var temp__1927000414__auto____9_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(d__0, k__8_2)
							if jrt.A2g_Truth(temp__1927000414__auto____9_2) { var impl__10 any = temp__1927000414__auto____9_2; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__10) }
//line :205:1
							seq_214000156__2, chunk_214000157__3, count_214000158__4, i_214000159__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000156__7), nil, 0, 0; continue L3 } } else { return nil } } } } else {
//line :199:1
								return nil } }
//line :197:1
	panic("a2g: unreachable")
}









func A_arbace_a2g_reach_vcall_BANG__A_New() *A_arbace_a2g_reach_vcall_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcall_BANG__A{}; t.Ctor(); return t }
//line :208:1
func (t *A_arbace_a2g_reach_vcall_BANG__A) Ctor() {}
//line :208:1
func (t *A_arbace_a2g_reach_vcall_BANG__A) Invoke_O_O_O_O__O(self, o__0, name__1, desc__2 any) any { { var k__4 any = lang.Tuple_Create_O_O_O__IPersistentVector(o__0, name__1, desc__2)
													var tmp1 /*line :208:1*/*lang.Keyword = A_arbace_a2g_reach_A_const_115



	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), k__4)) { return nil } else {
		var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_115; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), k__4)
		var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_107; var tmp5 any = tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()); var tmp6 any = A_arbace_a2g_reach_A_const_67.GetRawRoot__O(); var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_68.GetRawRoot__O()); var tmp8 any = A_arbace_a2g_reach_A_const_14.GetRawRoot__O(); var tmp9 *lang.PersistentVector; lang.PersistentVector_Init(); tmp9 = lang.PersistentVector_EMPTY; tmp3.Invoke_O_O_O_O_O__O(tmp5, tmp6, o__0, tmp7.Invoke_O_O__O(tmp8, tmp9.Ref()), lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2))
//line :212:1
		var seq_214000162__5 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_105.GetRawRoot__O()); var tmp12 *lang.Keyword = A_arbace_a2g_reach_A_const_110; var tmp13 any = lang.RT_Get_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp12.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), o__0); var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_116.GetRawRoot__O()); var tmp15 any = A_arbace_a2g_reach_vcall_BANG__fn__214000166_A_New_O(o__0); var tmp16 *jrt.Class
		var fncls__30 /*line :212:1*/*jrt.Class = A_arbace_a2g_reach_vcall_BANG__fn__214000166_A_fn_class



		if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_86, false); A_arbace_a2g_reach_vcall_BANG__fn__214000166_A_fn_class = fncls__30d; tmp16 = fncls__30d } else { tmp16 = fncls__30 }
//line :215:1
		var tmp17 *lang.Keyword = A_arbace_a2g_reach_A_const_117; seq_214000162__5 = tmp10.Invoke_O__O(tmp11.Invoke_O_O__O(tmp13, tmp14.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil), lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp17.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())))))
//line :212:1
		var chunk_214000163__6 any; var count_214000164__7 int64 = 0; var i_214000165__8 int64 = 0; L1: for {


			if lang.Numbers_Lt_J_J__Z(i_214000165__8, count_214000164__7) { var d__9 any = lang.Indexed_Cast(chunk_214000163__6).Nth_I__O(lang.RT_IntCast_J__I(i_214000165__8)); var temp__1927000414__auto____10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(d__9, lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2))

				if jrt.A2g_Truth(temp__1927000414__auto____10) { var impl__11 any = temp__1927000414__auto____10; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__11) }
//line :215:1
				seq_214000162__5, chunk_214000163__6, count_214000164__7, i_214000165__8 = seq_214000162__5, chunk_214000163__6, count_214000164__7, lang.Numbers_Unchecked_inc_J__J(i_214000165__8); continue L1 } else { var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000162__5); if jrt.A2g_Truth(temp__1927000414__auto____9) { var seq_214000162__10 any = temp__1927000414__auto____9; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000162__10)) { var c__1927000678__auto____11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000162__10); seq_214000162__5, chunk_214000163__6, count_214000164__7, i_214000165__8 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000162__10), c__1927000678__auto____11, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____11))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var d__11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000162__10); var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(d__11, lang.Tuple_Create_O_O__IPersistentVector(name__1, desc__2))

					if jrt.A2g_Truth(temp__1927000414__auto____12) { var impl__13 any = temp__1927000414__auto____12; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__13) }
//line :215:1
					seq_214000162__5, chunk_214000163__6, count_214000164__7, i_214000165__8 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000162__10), nil, 0, 0; continue L1 } } else { return nil } } } } }; /*line :208:1*/panic("a2g: unreachable") }







func A_arbace_a2g_reach_vcall_BANG__fn__214000166_A_New_O(p0 any) *A_arbace_a2g_reach_vcall_BANG__fn__214000166_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vcall_BANG__fn__214000166_A{}; t.Ctor_O(p0); return t }
//line :216:1
func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000166_A) Ctor_O(c__o any) { t.F_o = c__o }
//line :216:1
func (t *A_arbace_a2g_reach_vcall_BANG__fn__214000166_A) Invoke_O_O__O(self, p1__214000161_SHARP___1 any) any { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_62.GetRawRoot__O()).Invoke_O_O__O(p1__214000161_SHARP___1, t.F_o) }


func A_arbace_a2g_reach_lambda_BANG__A_New() *A_arbace_a2g_reach_lambda_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_lambda_BANG__A{}; t.Ctor(); return t }
//line :219:1
func (t *A_arbace_a2g_reach_lambda_BANG__A) Ctor() {}
//line :219:1
func (t *A_arbace_a2g_reach_lambda_BANG__A) Invoke_O_O__O(self, fi__0 any) any {



	{ var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_117; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O())), fi__0)) { return nil } else {
		var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_117; lang.IFn_Cast(A_arbace_a2g_reach_A_const_64.GetRawRoot__O()).Invoke_O_O_O__O(tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_66.Get__O()), A_arbace_a2g_reach_A_const_14.GetRawRoot__O(), fi__0)
//line :223:1
		var seq_214000169__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_111.GetRawRoot__O()).Invoke_O__O(fi__0)); var chunk_214000170__3 any; var count_214000171__4 int64 = 0; var i_214000172__5 int64 = 0; L1: for {

			if lang.Numbers_Lt_J_J__Z(i_214000172__5, count_214000171__4) { var nd__6 any = lang.Indexed_Cast(chunk_214000170__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000172__5)); var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(fi__0, nd__6)
				if jrt.A2g_Truth(temp__1927000414__auto____7) { var impl__8 any = temp__1927000414__auto____7; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__8) }
//line :225:1
				seq_214000169__2, chunk_214000170__3, count_214000171__4, i_214000172__5 = seq_214000169__2, chunk_214000170__3, count_214000171__4, lang.Numbers_Unchecked_inc_J__J(i_214000172__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000169__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000169__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000169__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000169__7); seq_214000169__2, chunk_214000170__3, count_214000171__4, i_214000172__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000169__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var nd__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000169__7); var temp__1927000414__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(fi__0, nd__8)
					if jrt.A2g_Truth(temp__1927000414__auto____9) { var impl__10 any = temp__1927000414__auto____9; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__10) }
//line :225:1
					seq_214000169__2, chunk_214000170__3, count_214000171__4, i_214000172__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000169__7), nil, 0, 0; continue L1 } } }
//line :223:1
			break L1 }; var seq_214000173__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_113.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_114.GetRawRoot__O()).Invoke_O__O(fi__0))); var chunk_214000174__3 any; var count_214000175__4 int64 = 0; var i_214000176__5 int64 = 0; L2: for {



				if lang.Numbers_Lt_J_J__Z(i_214000176__5, count_214000175__4) { var k__6 any = lang.Indexed_Cast(chunk_214000174__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000176__5)); var temp__1927000414__auto____7_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(fi__0, k__6)
					if jrt.A2g_Truth(temp__1927000414__auto____7_2) { var impl__8_2 any = temp__1927000414__auto____7_2; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__8_2) }
//line :227:1
					seq_214000173__2, chunk_214000174__3, count_214000175__4, i_214000176__5 = seq_214000173__2, chunk_214000174__3, count_214000175__4, lang.Numbers_Unchecked_inc_J__J(i_214000176__5); continue L2 } else { var temp__1927000414__auto____6_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000173__2); if jrt.A2g_Truth(temp__1927000414__auto____6_2) { var seq_214000173__7 any = temp__1927000414__auto____6_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000173__7)) { var c__1927000678__auto____8_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000173__7); seq_214000173__2, chunk_214000174__3, count_214000175__4, i_214000176__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000173__7), c__1927000678__auto____8_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8_2))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var k__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000173__7); var temp__1927000414__auto____9_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_112.GetRawRoot__O()).Invoke_O_O__O(fi__0, k__8)
						if jrt.A2g_Truth(temp__1927000414__auto____9_2) { var impl__10_2 any = temp__1927000414__auto____9_2; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(impl__10_2) }
//line :227:1
						seq_214000173__2, chunk_214000174__3, count_214000175__4, i_214000176__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000173__7), nil, 0, 0; continue L2 } } else { return nil } } } } }
//line :219:1
	panic("a2g: unreachable")
}









func A_arbace_a2g_reach_check_hw_call_BANG__A_New() *A_arbace_a2g_reach_check_hw_call_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_check_hw_call_BANG__A{}; t.Ctor(); return t }
//line :230:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Ctor() {}
//line :230:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__A) Invoke_O_O_O_O_O__O(self, owner__0, name__1, desc__2, kind__3 any) any {


	var tmp1 any; var and__1927000168__auto____5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_118.GetRawRoot__O()).Invoke_O__O(owner__0); if jrt.A2g_Truth(and__1927000168__auto____5) { tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(owner__0, Lit_1) } else { tmp1 = and__1927000168__auto____5 }; if jrt.A2g_Truth(tmp1) { var mm__5 any = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, A_arbace_a2g_reach_A_const_40, name__1, A_arbace_a2g_reach_A_const_41, desc__2)); var tmp2 any

		if lang.Util_Equiv_O_O__Z(kind__3, A_arbace_a2g_reach_A_const_119) {
			tmp2 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_120.GetRawRoot__O()).Invoke_O_O_O__O(owner__0, name__1, desc__2) } else {
//line :235:1
				var or__1927000174__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_121.GetRawRoot__O()).Invoke_O_O__O(owner__0, mm__5)

				if jrt.A2g_Truth(or__1927000174__auto____6) { tmp2 = or__1927000174__auto____6 } else {

					var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_38.GetRawRoot__O()); var tmp4 any = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A_New_O(mm__5); var tmp5 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_2, false); A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A_fn_class = fncls__31d; tmp5 = fncls__31d } else { tmp5 = fncls__31 }; tmp2 = tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_61.GetRawRoot__O()).Invoke_O__O(owner__0))) } }
//line :235:1
		if jrt.A2g_Truth(tmp2) { return nil } else {





			return lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_3, nil, Lit_4, nil, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_reach_A_const_98.GetRawRoot__O()).Invoke_O_O_O__O(owner__0, Lit_5, Lit_4), nil, name__1, desc__2)).Ref()) } } else {
//line :233:1
				return nil
			}
}



func A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A_New_O(p0 any) *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A{}; t.Ctor_O(p0); return t }
//line :239:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A) Ctor_O(c__mm any) { t.F_mm = c__mm }
//line :239:1
func (t *A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A) Invoke_O_O__O(self, p1__214000178_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_122.GetRawRoot__O()).Invoke_O__O(p1__214000178_SHARP___1); if jrt.A2g_Truth(and__1927000168__auto____2) { var or__1927000174__auto____3 bool = lang.Util_Equiv_O_O__Z(p1__214000178_SHARP___1, Lit_1); if or__1927000174__auto____3 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3).Ref() } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_121.GetRawRoot__O()).Invoke_O_O__O(p1__214000178_SHARP___1, t.F_mm) } } else { return and__1927000168__auto____2 } }



func A_arbace_a2g_reach_class_of_desc_A_New() *A_arbace_a2g_reach_class_of_desc_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_class_of_desc_A{}; t.Ctor(); return t }
//line :243:1
func (t *A_arbace_a2g_reach_class_of_desc_A) Ctor() {}
//line :243:1
func (t *A_arbace_a2g_reach_class_of_desc_A) Invoke_O_O__O(self, d__0 any) any { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_99.GetRawRoot__O()).Invoke_O__O(d__0)) }

func A_arbace_a2g_reach_vh_const_QMARK__A_New() *A_arbace_a2g_reach_vh_const_QMARK__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vh_const_QMARK__A{}; t.Ctor(); return t }
//line :245:1
func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Ctor() {}
//line :245:1
func (t *A_arbace_a2g_reach_vh_const_QMARK__A) Invoke_O_O__O(self, f__0 any) any {


	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()); var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_123; var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_124; var tmp4 any = tmp2.Invoke_O__O(tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_72.Get__O())); var tmp5 any; var or__1927000174__auto____2 any = A_arbace_a2g_reach_A_const_125.Invoke_O__O(f__0); if jrt.A2g_Truth(or__1927000174__auto____2) { tmp5 = or__1927000174__auto____2 } else { tmp5 = A_arbace_a2g_reach_A_const_126.Invoke_O__O(f__0) }; return tmp1.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(tmp5, A_arbace_a2g_reach_A_const_40.Invoke_O__O(f__0)))
}
func A_arbace_a2g_reach_vh_call_QMARK__A_New() *A_arbace_a2g_reach_vh_call_QMARK__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_vh_call_QMARK__A{}; t.Ctor(); return t }
//line :250:1
func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Ctor() {}
//line :250:1
func (t *A_arbace_a2g_reach_vh_call_QMARK__A) Invoke_O_O__O(self, node__0 any) any { var map__214000184__2 any = node__0; var map__214000184__3 any; if



	lang.ISeq_InstanceOf(map__214000184__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(map__214000184__2)) { map__214000184__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_reach_A_const_127.GetRawRoot__O()).Invoke_O__O(map__214000184__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(map__214000184__2)) { map__214000184__3 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(map__214000184__2) } else { lang.PersistentArrayMap_Init(); map__214000184__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000184__3 = map__214000184__2 }; var owner__4 any = /*line :250:1*/lang.RT_Get_O_O__O(map__214000184__3, A_arbace_a2g_reach_A_const_126); var kind__5 any = lang.RT_Get_O_O__O(map__214000184__3, A_arbace_a2g_reach_A_const_128); var name__6 any = lang.RT_Get_O_O__O(map__214000184__3, A_arbace_a2g_reach_A_const_40); var or__1927000174__auto____7 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_reach_A_const_119, kind__5); if and__1927000168__auto____7 {




		var and__1927000168__auto____8 bool = lang.Util_Equiv_O_O__Z(Lit_92, owner__4); if and__1927000168__auto____8 {
			or__1927000174__auto____7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_129).Invoke_O__O(name__6) } else {
//line :255:1
				or__1927000174__auto____7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____8).Ref() } } else { or__1927000174__auto____7 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____7).Ref() }; if jrt.A2g_Truth(or__1927000174__auto____7) { return or__1927000174__auto____7 } else { var or__1927000174__auto____8 bool; var and__1927000168__auto____8_2 bool = lang.Util_Equiv_O_O__Z(A_arbace_a2g_reach_A_const_119, kind__5)

					if and__1927000168__auto____8_2 { var and__1927000168__auto____9 bool = lang.Util_Equiv_O_O__Z(Lit_93, owner__4); if and__1927000168__auto____9 { or__1927000174__auto____8 = lang.Util_Equiv_O_O__Z(Lit_94, name__6) } else { or__1927000174__auto____8 = and__1927000168__auto____9 } } else { or__1927000174__auto____8 = and__1927000168__auto____8_2 }
//line :255:1
					if or__1927000174__auto____8 { return jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____8).Ref() } else { var and__1927000168__auto____9_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_119, kind__5)


						if jrt.A2g_Truth(and__1927000168__auto____9_2) { var and__1927000168__auto____10 bool = lang.Util_Equiv_O_O__Z(Lit_92, owner__4); if and__1927000168__auto____10 { var tg__11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_130.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_133.Invoke_O__O(node__0)); var tmp1 any = A_arbace_a2g_reach_A_const_131; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z(tmp1, A_arbace_a2g_reach_A_const_19.Invoke_O__O(tg__11))

							if and__1927000168__auto____12 { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_132.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_134.Invoke_O__O(tg__11)) } else { return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() } } else {
//line :258:1
								return jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____10).Ref() } } else { return and__1927000168__auto____9_2 } } } }



func A_arbace_a2g_reach_scan_node_BANG__A_New() *A_arbace_a2g_reach_scan_node_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__A{}; t.Ctor(); return t }
//line :262:1
func (t *A_arbace_a2g_reach_scan_node_BANG__A) Ctor() {}
//line :262:1
func (t *A_arbace_a2g_reach_scan_node_BANG__A) Invoke_O_O__O(self, node__0 any) any { { var node__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_130.GetRawRoot__O()).Invoke_O__O(node__0); var G__214000187__3_ any = A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)

L1: switch { default: switch lang.Util_Hash_O__I(G__214000187__3_) >> 19 & 255 { case 0: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_136) {












































	lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(node__2))
//line :264:1
	break L1 }; case 3: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_138) {














































		lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_147.Invoke_O__O(node__2))
//line :264:1
		break L1 }; case 32: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_139) { var f__4 any = A_arbace_a2g_reach_A_const_134.Invoke_O__O(node__2); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp2 any; var or__1927000174__auto____5 any = A_arbace_a2g_reach_A_const_125.Invoke_O__O(f__4)











































			if jrt.A2g_Truth(or__1927000174__auto____5) { tmp2 = or__1927000174__auto____5 } else { tmp2 = A_arbace_a2g_reach_A_const_126.Invoke_O__O(f__4) }; tmp1.Invoke_O__O(tmp2); lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_41.Invoke_O__O(f__4))
//line :264:1
			break L1 }; case 42: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_140) {
































				lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(node__2))
				var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_41; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_142.Invoke_O__O(node__2), Lit_11, tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_152.Invoke_O__O(node__2))))
//line :264:1
				break L1 }; case 47: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_148) { var seq_214000188__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_155.Invoke_O__O(node__2)); var chunk_214000189__5 any; var count_214000190__6 int64 = 0; var i_214000191__7 int64 = 0; L2: for {
























































					if lang.Numbers_Lt_J_J__Z(i_214000191__7, count_214000190__6) { var p__8 any = lang.Indexed_Cast(chunk_214000189__5).Nth_I__O(lang.RT_IntCast_J__I(i_214000191__7)); if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_149.Invoke_O__O(p__8)) { var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_147; var ty__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_149.Invoke_O__O(p__8))); var tmp5 any; var and__1927000168__auto____10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_151.GetRawRoot__O()).Invoke_O__O(ty__9)

						if jrt.A2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(ty__9, A_arbace_a2g_reach_A_const_156); if jrt.A2g_Truth(and__1927000168__auto____11) { tmp5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(ty__9, Lit_45) } else { tmp5 = and__1927000168__auto____11 } } else { tmp5 = and__1927000168__auto____10 }
//line :321:1
						if jrt.A2g_Truth(tmp5) {


							var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()); var tmp7 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_157.GetRawRoot__O()).Invoke_O__O(ty__9)) { tmp7 = Lit_1 } else { tmp7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_158.GetRawRoot__O()).Invoke_O__O(ty__9) }; tmp6.Invoke_O_O_O__O(tmp7, Lit_43, Lit_44)
//line :321:1
							seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = seq_214000188__4, chunk_214000189__5, count_214000190__6, lang.Numbers_Unchecked_inc_J__J(i_214000191__7); continue L2 } else { seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = seq_214000188__4, chunk_214000189__5, count_214000190__6, lang.Numbers_Unchecked_inc_J__J(i_214000191__7); continue L2 } } else { seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = seq_214000188__4, chunk_214000189__5, count_214000190__6, lang.Numbers_Unchecked_inc_J__J(i_214000191__7); continue L2 } } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000188__4); if jrt.A2g_Truth(temp__1927000414__auto____8) { var seq_214000188__9 any = temp__1927000414__auto____8; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000188__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000188__9); seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000188__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var p__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000188__9); if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_149.Invoke_O__O(p__10)) { var tmp8 *lang.Keyword = A_arbace_a2g_reach_A_const_147; var ty__11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_150.GetRawRoot__O()).Invoke_O__O(tmp8.Invoke_O__O(A_arbace_a2g_reach_A_const_149.Invoke_O__O(p__10))); var tmp9 any; var and__1927000168__auto____12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_151.GetRawRoot__O()).Invoke_O__O(ty__11)

								if jrt.A2g_Truth(and__1927000168__auto____12) { var and__1927000168__auto____13 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(ty__11, A_arbace_a2g_reach_A_const_156); if jrt.A2g_Truth(and__1927000168__auto____13) { tmp9 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_45.GetRawRoot__O()).Invoke_O_O__O(ty__11, Lit_45) } else { tmp9 = and__1927000168__auto____13 } } else { tmp9 = and__1927000168__auto____12 }
//line :321:1
								if jrt.A2g_Truth(tmp9) {


									var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()); var tmp11 any; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_157.GetRawRoot__O()).Invoke_O__O(ty__11)) { tmp11 = Lit_1 } else { tmp11 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_158.GetRawRoot__O()).Invoke_O__O(ty__11) }; tmp10.Invoke_O_O_O__O(tmp11, Lit_43, Lit_44)
//line :321:1
									seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000188__9), nil, 0, 0; continue L2 } else { seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000188__9), nil, 0, 0; continue L2 } } else { seq_214000188__4, chunk_214000189__5, count_214000190__6, i_214000191__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000188__9), nil, 0, 0; continue L2 } } } }
//line :264:1
					break L2 }; break L1 }; case 53: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_153) {





























































						if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_154.Invoke_O__O(node__2)) { } else {
							lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(Lit_46)
							lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_46, Lit_47, Lit_48)
							lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_46, Lit_49, Lit_50) }
//line :264:1
						break L1 }; case 63: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_159) {













































							lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(node__2))
//line :264:1
							break L1 }; case 74: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_160) {












































								lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(node__2))
//line :264:1
								break L1 }; case 75: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_161) {














































									lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_147.Invoke_O__O(node__2))
//line :264:1
									break L1 }; case 126: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_162) {


















































										if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_168.Invoke_O__O(node__2))) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_167.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_168.Invoke_O__O(node__2)) }; lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2))
//line :264:1
										var G__214000192__4_ any = A_arbace_a2g_reach_A_const_128.Invoke_O__O(node__2)



















































									L3: switch { default: switch lang.Util_Hash_O__I(G__214000192__4_) >> 5 & 3 { case 0: if any(G__214000192__4_) == any(A_arbace_a2g_reach_A_const_163) {



										lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_40.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_41.Invoke_O__O(node__2))
//line :316:1
										break L3 }; case 1: if any(G__214000192__4_) == any(A_arbace_a2g_reach_A_const_164) {

											lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), Lit_11, A_arbace_a2g_reach_A_const_41.Invoke_O__O(node__2)))
											lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2))
//line :316:1
											break L3 }; case 2: if any(G__214000192__4_) == any(A_arbace_a2g_reach_A_const_166) {



												lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_40.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_41.Invoke_O__O(node__2))
//line :316:1
												break L3 }; case 3: if any(G__214000192__4_) == any(A_arbace_a2g_reach_A_const_119) {
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_40.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_41.Invoke_O__O(node__2)))
//line :316:1
													break L3 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000192__4_)))))}
//line :264:1
										break L1 }; case 155: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_164) { var c__4 any = A_arbace_a2g_reach_A_const_142.Invoke_O__O(node__2); var ok__5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__4)
























											if jrt.A2g_Truth(ok__5) {
												lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(c__4)
												var tmp12 *lang.Keyword = A_arbace_a2g_reach_A_const_41; lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(c__4, Lit_11, tmp12.Invoke_O__O(A_arbace_a2g_reach_A_const_152.Invoke_O__O(node__2))))
												lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(c__4)
												if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_118.GetRawRoot__O()).Invoke_O__O(c__4)) { var g__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_69.GetRawRoot__O()).Invoke_O__O(c__4)
													var tmp13 /*line :293:1*/*lang.Keyword = A_arbace_a2g_reach_A_const_74
													var tmp14 /*line :293:1*/*lang.Keyword = A_arbace_a2g_reach_A_const_71
													var tmp15 /*line :293:1*/*lang.Keyword = A_arbace_a2g_reach_A_const_41

													if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(tmp13.Invoke_O__O(tmp14.Invoke_O__O(A_arbace_a2g_reach_A_const_72.Get__O())), lang.IFn_Cast(A_arbace_a2g_reach_A_const_170.GetRawRoot__O()).Invoke_O_O__O(g__6, tmp15.Invoke_O__O(A_arbace_a2g_reach_A_const_152.Invoke_O__O(node__2))))) { } else {
														var tmp16 *lang.Keyword = A_arbace_a2g_reach_A_const_41; lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_51, nil, nil), jrt.RefArrayOf(jrt.Object_class, nil, c__4, tmp16.Invoke_O__O(A_arbace_a2g_reach_A_const_152.Invoke_O__O(node__2)))).Ref()) } } }
//line :264:1
											break L1 }; case 156: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_169) { var seq_214000193__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_172.Invoke_O__O(node__2)); var chunk_214000194__5 any; var count_214000195__6 int64 = 0; var i_214000196__7 int64 = 0; L4: for {















































												if lang.Numbers_Lt_J_J__Z(i_214000196__7, count_214000195__6) { var c__8 any = lang.Indexed_Cast(chunk_214000194__5).Nth_I__O(lang.RT_IntCast_J__I(i_214000196__7)); var seq_214000201__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_173.Invoke_O__O(c__8)); var chunk_214000202__10 any; var count_214000203__11 int64 = 0; var i_214000204__12 int64 = 0; L5: for { if lang.Numbers_Lt_J_J__Z(i_214000204__12, count_214000203__11) { var cls__13 any = lang.Indexed_Cast(chunk_214000202__10).Nth_I__O(lang.RT_IntCast_J__I(i_214000204__12)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(cls__13); seq_214000201__9, chunk_214000202__10, count_214000203__11, i_214000204__12 = seq_214000201__9, chunk_214000202__10, count_214000203__11, lang.Numbers_Unchecked_inc_J__J(i_214000204__12); continue L5 } else { var temp__1927000414__auto____13 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000201__9); if jrt.A2g_Truth(temp__1927000414__auto____13) { var seq_214000201__14 any = temp__1927000414__auto____13; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000201__14)) { var c__1927000678__auto____15 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000201__14); seq_214000201__9, chunk_214000202__10, count_214000203__11, i_214000204__12 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000201__14), c__1927000678__auto____15, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____15))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var cls__15 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000201__14); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(cls__15); seq_214000201__9, chunk_214000202__10, count_214000203__11, i_214000204__12 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000201__14), nil, 0, 0; continue L5 } } }; break L5 }; seq_214000193__4, chunk_214000194__5, count_214000195__6, i_214000196__7 = seq_214000193__4, chunk_214000194__5, count_214000195__6, lang.Numbers_Unchecked_inc_J__J(i_214000196__7); continue L4 } else { var temp__1927000414__auto____8_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000193__4); if jrt.A2g_Truth(temp__1927000414__auto____8_2) { var seq_214000193__9 any = temp__1927000414__auto____8_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000193__9)) { var c__1927000678__auto____10_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000193__9); seq_214000193__4, chunk_214000194__5, count_214000195__6, i_214000196__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000193__9), c__1927000678__auto____10_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var c__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000193__9); var seq_214000197__11 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_173.Invoke_O__O(c__10)); var chunk_214000198__12 any; var count_214000199__13 int64 = 0; var i_214000200__14 int64 = 0; L6: for { if lang.Numbers_Lt_J_J__Z(i_214000200__14, count_214000199__13) { var cls__15_2 any = lang.Indexed_Cast(chunk_214000198__12).Nth_I__O(lang.RT_IntCast_J__I(i_214000200__14)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(cls__15_2); seq_214000197__11, chunk_214000198__12, count_214000199__13, i_214000200__14 = seq_214000197__11, chunk_214000198__12, count_214000199__13, lang.Numbers_Unchecked_inc_J__J(i_214000200__14); continue L6 } else { var temp__1927000414__auto____15 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000197__11); if jrt.A2g_Truth(temp__1927000414__auto____15) { var seq_214000197__16 any = temp__1927000414__auto____15; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000197__16)) { var c__1927000678__auto____17 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000197__16); seq_214000197__11, chunk_214000198__12, count_214000199__13, i_214000200__14 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000197__16), c__1927000678__auto____17, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____17))), int64(lang.RT_IntCast_J__I(0)); continue L6 } else { var cls__17 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000197__16); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(cls__17); seq_214000197__11, chunk_214000198__12, count_214000199__13, i_214000200__14 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000197__16), nil, 0, 0; continue L6 } } }; break L6 }; seq_214000193__4, chunk_214000194__5, count_214000195__6, i_214000196__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000193__9), nil, 0, 0; continue L4 } } }
//line :264:1
												break L4 }; break L1 }; case 161: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_171) {
















































													if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_168.Invoke_O__O(node__2))) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_167.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_168.Invoke_O__O(node__2)) }
//line :264:1
													var seq_214000205__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_175.Invoke_O__O(node__2)); var chunk_214000206__5 any; var count_214000207__6 int64 = 0; var i_214000208__7 int64 = 0; L7: for {
















































														if lang.Numbers_Lt_J_J__Z(i_214000208__7, count_214000207__6) { var mk__8 any = lang.Indexed_Cast(chunk_214000206__5).Nth_I__O(lang.RT_IntCast_J__I(i_214000208__7)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(mk__8); seq_214000205__4, chunk_214000206__5, count_214000207__6, i_214000208__7 = seq_214000205__4, chunk_214000206__5, count_214000207__6, lang.Numbers_Unchecked_inc_J__J(i_214000208__7); continue L7 } else { var temp__1927000414__auto____8_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000205__4); if jrt.A2g_Truth(temp__1927000414__auto____8_3) { var seq_214000205__9 any = temp__1927000414__auto____8_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000205__9)) { var c__1927000678__auto____10_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000205__9); seq_214000205__4, chunk_214000206__5, count_214000207__6, i_214000208__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000205__9), c__1927000678__auto____10_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____10_3))), int64(lang.RT_IntCast_J__I(0)); continue L7 } else { var mk__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000205__9); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(mk__10); seq_214000205__4, chunk_214000206__5, count_214000207__6, i_214000208__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000205__9), nil, 0, 0; continue L7 } } }
//line :264:1
														break L7 }; break L1 }; case 170: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_174) { var f__4_2 any = A_arbace_a2g_reach_A_const_134.Invoke_O__O(node__2); var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()); var tmp18 any; var or__1927000174__auto____5_2 any = A_arbace_a2g_reach_A_const_125.Invoke_O__O(f__4_2)











































															if jrt.A2g_Truth(or__1927000174__auto____5_2) { tmp18 = or__1927000174__auto____5_2 } else { tmp18 = A_arbace_a2g_reach_A_const_126.Invoke_O__O(f__4_2) }; tmp17.Invoke_O__O(tmp18); lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_41.Invoke_O__O(f__4_2))
//line :264:1
															break L1 }; case 185: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_176) {







































































																lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_35))
																var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()); var tmp20 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_35); var tmp21 *jrt.String; var tmp22 any = A_arbace_a2g_reach_A_const_179; if lang.Util_Equiv_O_O__Z(tmp22, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) { tmp21 = Lit_52 } else { tmp21 = Lit_53 }; var tmp23 any = tmp21.Ref(); var tmp24 *jrt.String; var tmp25 any = A_arbace_a2g_reach_A_const_179
																if lang.Util_Equiv_O_O__Z(tmp25, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) { tmp24 = Lit_50 } else { tmp24 = Lit_50 }
//line :337:1
																tmp19.Invoke_O_O_O__O(tmp20, tmp23, tmp24.Ref())

																var tmp26 any = A_arbace_a2g_reach_A_const_176; if lang.Util_Equiv_O_O__Z(tmp26, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) {
																	lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_54))
																	lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_54), Lit_55, lang.IFn_Cast(A_arbace_a2g_reach_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_181.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_a2g_reach_A_const_182.Invoke_O__O(node__2))).Ref(), Lit_56), Lit_56)) }
//line :264:1
																break L1 }; case 191: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_177) { var fi__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_158.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_147.Invoke_O__O(node__2)); var fni__5 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_57)



















































































																	lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_54))
																	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(fi__4)) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_167.GetRawRoot__O()).Invoke_O__O(fi__4) }
																	if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(fni__5)) {
																		lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(fni__5)
																		lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(fni__5, A_arbace_a2g_reach_A_const_184.Invoke_O__O(node__2), A_arbace_a2g_reach_A_const_185.Invoke_O__O(node__2))) }
//line :264:1
																	break L1 }; case 192: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_141) {





































































																		var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_183.GetRawRoot__O()); var tmp28 any = A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A_New(); var tmp29 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_58, false); A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A_fn_class = fncls__35d; tmp29 = fncls__35d } else { tmp29 = fncls__35 }; tmp27.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil), nil)
//line :264:1
																		break L1 }; case 193: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_179) {







































































																			lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_35))
																			var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()); var tmp31 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_35); var tmp32 *jrt.String; var tmp33 any = A_arbace_a2g_reach_A_const_179; if lang.Util_Equiv_O_O__Z(tmp33, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) { tmp32 = Lit_52 } else { tmp32 = Lit_53 }; var tmp34 any = tmp32.Ref(); var tmp35 *jrt.String; var tmp36 any = A_arbace_a2g_reach_A_const_179
																			if lang.Util_Equiv_O_O__Z(tmp36, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) { tmp35 = Lit_50 } else { tmp35 = Lit_50 }
//line :337:1
																			tmp30.Invoke_O_O_O__O(tmp31, tmp34, tmp35.Ref())

																			var tmp37 any = A_arbace_a2g_reach_A_const_176; if lang.Util_Equiv_O_O__Z(tmp37, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) {
																				lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_54))
																				lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_54), Lit_55, lang.IFn_Cast(A_arbace_a2g_reach_A_const_180.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_181.GetRawRoot__O()).Invoke_O_O__O(jrt.Integer_ValueOf_I__Integer(lang.RT_Count_O__I(A_arbace_a2g_reach_A_const_182.Invoke_O__O(node__2))).Ref(), Lit_56), Lit_56)) }
//line :264:1
																			break L1 }; case 194: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_186) { var f__4_3 any = A_arbace_a2g_reach_A_const_134.Invoke_O__O(node__2); var o__5 any; var or__1927000174__auto____5_3 any = A_arbace_a2g_reach_A_const_125.Invoke_O__O(f__4_3)




































																				if jrt.A2g_Truth(or__1927000174__auto____5_3) { o__5 = or__1927000174__auto____5_3 } else { o__5 = A_arbace_a2g_reach_A_const_126.Invoke_O__O(f__4_3) }
																				var tmp38 any; var and__1927000168__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_132.GetRawRoot__O()).Invoke_O__O(f__4_3)); if jrt.A2g_Truth(and__1927000168__auto____6) { tmp38 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(o__5) } else { tmp38 = and__1927000168__auto____6 }; if jrt.A2g_Truth(tmp38) {
																					lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(o__5)
																					lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_41.Invoke_O__O(f__4_3))
																					var tmp39 any; var and__1927000168__auto____6_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_118.GetRawRoot__O()).Invoke_O__O(o__5); if jrt.A2g_Truth(and__1927000168__auto____6_2) { var tmp40 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()); var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_195.GetRawRoot__O()); var tmp42 any = A_arbace_a2g_reach_A_const_40.Invoke_O__O(f__4_3); var tmp43 *jrt.Boolean; jrt.Boolean_Init(); tmp43 = jrt.Boolean_TRUE; tmp39 = tmp40.Invoke_O__O(tmp41.Invoke_O_O_O__O(o__5, tmp42, tmp43.Ref())) } else { tmp39 = and__1927000168__auto____6_2 }; if jrt.A2g_Truth(tmp39) {
																						lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, o__5, nil, A_arbace_a2g_reach_A_const_40.Invoke_O__O(f__4_3))).Ref()) } }
//line :264:1
																				break L1 }; case 209: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_187) { var mm__4 any = A_arbace_a2g_reach_A_const_188.Invoke_O__O(node__2); var mowner__5 any; var or__1927000174__auto____5_4 any = A_arbace_a2g_reach_A_const_126.Invoke_O__O(mm__4)


																					if jrt.A2g_Truth(or__1927000174__auto____5_4) { mowner__5 = or__1927000174__auto____5_4 } else { mowner__5 = A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2) }
//line :264:1
																					var map__214000211__6 any = node__2; var map__214000211__7 any

																					if lang.ISeq_InstanceOf(map__214000211__6) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(map__214000211__6)) { map__214000211__7 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_reach_A_const_127.GetRawRoot__O()).Invoke_O__O(map__214000211__6), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(map__214000211__6)) { map__214000211__7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(map__214000211__6) } else { lang.PersistentArrayMap_Init(); map__214000211__7 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000211__7 = map__214000211__6 }
//line :264:1
																					var name__8 any = lang.RT_Get_O_O__O(map__214000211__7, A_arbace_a2g_reach_A_const_40); var desc__9 any = lang.RT_Get_O_O__O(map__214000211__7, A_arbace_a2g_reach_A_const_41)




																					if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_189.Invoke_O__O(node__2)) {
																						lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2)) } else {
//line :269:1
																							if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_190.GetRawRoot__O()).Invoke_O__O(node__2)) { var seq_214000213__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_196.GetRawRoot__O()).Invoke_O__O(desc__9)); var chunk_214000214__11 any; var count_214000215__12 int64 = 0; var i_214000216__13 int64 = 0; L8: for {

																								if lang.Numbers_Lt_J_J__Z(i_214000216__13, count_214000215__12) { var c__14 any = lang.Indexed_Cast(chunk_214000214__11).Nth_I__O(lang.RT_IntCast_J__I(i_214000216__13)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__14); seq_214000213__10, chunk_214000214__11, count_214000215__12, i_214000216__13 = seq_214000213__10, chunk_214000214__11, count_214000215__12, lang.Numbers_Unchecked_inc_J__J(i_214000216__13); continue L8 } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000213__10); if jrt.A2g_Truth(temp__1927000414__auto____14) { var seq_214000213__15 any = temp__1927000414__auto____14; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000213__15)) { var c__1927000678__auto____16 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000213__15); seq_214000213__10, chunk_214000214__11, count_214000215__12, i_214000216__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000213__15), c__1927000678__auto____16, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var c__16 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000213__15); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__16); seq_214000213__10, chunk_214000214__11, count_214000215__12, i_214000216__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000213__15), nil, 0, 0; continue L8 } } }
//line :269:1
																								break L8 } } else { if A_arbace_a2g_reach_A_const_31 != nil {




																									lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2))
																									lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(mowner__5)
																									lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_60, nil, Lit_61), jrt.RefArrayOf(jrt.Object_class, nil, A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), nil)).Ref())
//line :269:1
																									var seq_214000217__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_196.GetRawRoot__O()).Invoke_O__O(desc__9)); var chunk_214000218__11 any; var count_214000219__12 int64 = 0; var i_214000220__13 int64 = 0; L9: for {







																										if lang.Numbers_Lt_J_J__Z(i_214000220__13, count_214000219__12) { var c__14_2 any = lang.Indexed_Cast(chunk_214000218__11).Nth_I__O(lang.RT_IntCast_J__I(i_214000220__13)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__14_2); seq_214000217__10, chunk_214000218__11, count_214000219__12, i_214000220__13 = seq_214000217__10, chunk_214000218__11, count_214000219__12, lang.Numbers_Unchecked_inc_J__J(i_214000220__13); continue L9 } else { var temp__1927000414__auto____14_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000217__10); if jrt.A2g_Truth(temp__1927000414__auto____14_2) { var seq_214000217__15 any = temp__1927000414__auto____14_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000217__15)) { var c__1927000678__auto____16_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000217__15); seq_214000217__10, chunk_214000218__11, count_214000219__12, i_214000220__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000217__15), c__1927000678__auto____16_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16_2))), int64(lang.RT_IntCast_J__I(0)); continue L9 } else { var c__16_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000217__15); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__16_2); seq_214000217__10, chunk_214000218__11, count_214000219__12, i_214000220__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000217__15), nil, 0, 0; continue L9 } } }
//line :269:1
																										break L9 }; var G__214000221__10_ any = A_arbace_a2g_reach_A_const_128.Invoke_O__O(node__2)








																								L10: switch { default: switch lang.Util_Hash_O__I(G__214000221__10_) >> 4 & 7 { case 3: if any(G__214000221__10_) == any(A_arbace_a2g_reach_A_const_191) {




																									var tmp44 any; var and__1927000168__auto____11_2 any = mm__4; if jrt.A2g_Truth(and__1927000168__auto____11_2) { tmp44 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__4) } else { tmp44 = and__1927000168__auto____11_2 }; if jrt.A2g_Truth(tmp44) {
																										lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9)) } else {
																											lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), name__8, desc__9)
																											lang.IFn_Cast(A_arbace_a2g_reach_A_const_192.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), name__8, desc__9, A_arbace_a2g_reach_A_const_194) }
//line :278:1
																									break L10 }; case 5: if any(G__214000221__10_) == any(A_arbace_a2g_reach_A_const_193) {


																										lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_192.GetRawRoot__O()).Invoke_O_O_O_O__O(mowner__5, name__8, desc__9, A_arbace_a2g_reach_A_const_193)
//line :278:1
																										break L10 }; case 6: if any(G__214000221__10_) == any(A_arbace_a2g_reach_A_const_194) {




																											var tmp45 any; var and__1927000168__auto____11_3 any = mm__4; if jrt.A2g_Truth(and__1927000168__auto____11_3) { tmp45 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__4) } else { tmp45 = and__1927000168__auto____11_3 }; if jrt.A2g_Truth(tmp45) {
																												lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9)) } else {
																													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), name__8, desc__9)
																													lang.IFn_Cast(A_arbace_a2g_reach_A_const_192.GetRawRoot__O()).Invoke_O_O_O_O__O(A_arbace_a2g_reach_A_const_126.Invoke_O__O(node__2), name__8, desc__9, A_arbace_a2g_reach_A_const_194) }
//line :278:1
																											break L10 }; case 7: if any(G__214000221__10_) == any(A_arbace_a2g_reach_A_const_119) {
																												lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(mowner__5); lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(mowner__5, name__8, desc__9))
																												lang.IFn_Cast(A_arbace_a2g_reach_A_const_192.GetRawRoot__O()).Invoke_O_O_O_O__O(mowner__5, name__8, desc__9, A_arbace_a2g_reach_A_const_119)
//line :278:1
																												break L10 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000221__10_)))))} } } }
//line :264:1
																					break L1 }; case 222: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_131) { var f__4_4 any = A_arbace_a2g_reach_A_const_134.Invoke_O__O(node__2); var o__5_2 any; var or__1927000174__auto____5_5 any = A_arbace_a2g_reach_A_const_125.Invoke_O__O(f__4_4)




































																						if jrt.A2g_Truth(or__1927000174__auto____5_5) { o__5_2 = or__1927000174__auto____5_5 } else { o__5_2 = A_arbace_a2g_reach_A_const_126.Invoke_O__O(f__4_4) }
																						var tmp46 any; var and__1927000168__auto____6_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_132.GetRawRoot__O()).Invoke_O__O(f__4_4)); if jrt.A2g_Truth(and__1927000168__auto____6_3) { tmp46 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(o__5_2) } else { tmp46 = and__1927000168__auto____6_3 }; if jrt.A2g_Truth(tmp46) {
																							lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(o__5_2)
																							lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_41.Invoke_O__O(f__4_4))
																							var tmp47 any; var and__1927000168__auto____6_4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_118.GetRawRoot__O()).Invoke_O__O(o__5_2); if jrt.A2g_Truth(and__1927000168__auto____6_4) { var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_195.GetRawRoot__O()); var tmp50 any = A_arbace_a2g_reach_A_const_40.Invoke_O__O(f__4_4); var tmp51 *jrt.Boolean; jrt.Boolean_Init(); tmp51 = jrt.Boolean_TRUE; tmp47 = tmp48.Invoke_O__O(tmp49.Invoke_O_O_O__O(o__5_2, tmp50, tmp51.Ref())) } else { tmp47 = and__1927000168__auto____6_4 }; if jrt.A2g_Truth(tmp47) {
																								lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_59, nil, Lit_4, nil), jrt.RefArrayOf(jrt.Object_class, nil, o__5_2, nil, A_arbace_a2g_reach_A_const_40.Invoke_O__O(f__4_4))).Ref()) } }
//line :264:1
																						break L1 }; case 239: if any(G__214000187__3_) == any(A_arbace_a2g_reach_A_const_197) {

































































																							lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(Lit_62)
//line :264:1
																							var d__4 any; var tmp52 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_63, nil, Lit_64); var tmp53 any; var or__1927000174__auto____7 any = A_arbace_a2g_reach_A_const_198.Invoke_O__O(node__2)


































































																							if jrt.A2g_Truth(or__1927000174__auto____7) { tmp53 = or__1927000174__auto____7 } else { tmp53 = Lit_65 }; d__4 = lang.Compiler_AOT_StrConcat_String1_O1__String(tmp52, jrt.RefArrayOf(jrt.Object_class, nil, tmp53, nil)).Ref()
																							lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(Lit_62, Lit_11, d__4))
																							lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(Lit_62)
//line :264:1
																							break L1 }; default:
}
}
























































































	var tmp54 any = A_arbace_a2g_reach_A_const_141; if lang.Util_Equiv_O_O__Z(tmp54, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) { var body_pat__3 *A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A_New(); var pat__3 any; var tmp55 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_66, false); A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A_fn_class = fncls__33d; tmp55 = fncls__33d } else { tmp55 = fncls__33 }; pat__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_pat__3), tmp55, nil)




		lang.IFn_Cast(pat__3).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(node__2)) }
	var tmp56 any = A_arbace_a2g_reach_A_const_135; if lang.Util_Equiv_O_O__Z(tmp56, A_arbace_a2g_reach_A_const_19.Invoke_O__O(node__2)) { var seq_214000228__3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_199.Invoke_O__O(node__2)); var chunk_214000229__4 any; var count_214000230__5 int64 = 0; var i_214000231__6 int64 = 0; L11: for {
		if lang.Numbers_Lt_J_J__Z(i_214000231__6, count_214000230__5) { var c__7 any = lang.Indexed_Cast(chunk_214000229__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000231__6)); var seq_214000236__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_200.Invoke_O__O(c__7)); var chunk_214000237__9 any; var count_214000238__10 int64 = 0; var i_214000239__11 int64 = 0; L12: for { if lang.Numbers_Lt_J_J__Z(i_214000239__11, count_214000238__10) { var l__12 any = lang.Indexed_Cast(chunk_214000237__9).Nth_I__O(lang.RT_IntCast_J__I(i_214000239__11)); if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__12)) { var body_pat__13 *A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A_New(); var pat__13 any; var tmp57 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A_fn_class; if fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_67, false); A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A_fn_class = fncls__37d; tmp57 = fncls__37d } else { tmp57 = fncls__37 }; pat__13 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_pat__13), tmp57, nil)




			lang.IFn_Cast(pat__13).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__12))
//line :362:1
			seq_214000236__8, chunk_214000237__9, count_214000238__10, i_214000239__11 = seq_214000236__8, chunk_214000237__9, count_214000238__10, lang.Numbers_Unchecked_inc_J__J(i_214000239__11); continue L12 } else { seq_214000236__8, chunk_214000237__9, count_214000238__10, i_214000239__11 = seq_214000236__8, chunk_214000237__9, count_214000238__10, lang.Numbers_Unchecked_inc_J__J(i_214000239__11); continue L12 } } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000236__8); if jrt.A2g_Truth(temp__1927000414__auto____12) { var seq_214000236__13 any = temp__1927000414__auto____12; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000236__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000236__13); seq_214000236__8, chunk_214000237__9, count_214000238__10, i_214000239__11 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000236__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I(0)); continue L12 } else { var l__14 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000236__13); if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__14)) { var body_pat__15 *A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A_New(); var pat__15 any; var tmp58 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A_fn_class; if fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_68, false); A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A_fn_class = fncls__38d; tmp58 = fncls__38d } else { tmp58 = fncls__38 }; pat__15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_pat__15), tmp58, nil)




				lang.IFn_Cast(pat__15).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__14))
//line :362:1
				seq_214000236__8, chunk_214000237__9, count_214000238__10, i_214000239__11 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000236__13), nil, 0, 0; continue L12 } else { seq_214000236__8, chunk_214000237__9, count_214000238__10, i_214000239__11 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000236__13), nil, 0, 0; continue L12 } } } }; break L12 }; seq_214000228__3, chunk_214000229__4, count_214000230__5, i_214000231__6 = seq_214000228__3, chunk_214000229__4, count_214000230__5, lang.Numbers_Unchecked_inc_J__J(i_214000231__6); continue L11 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000228__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_214000228__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000228__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000228__8); seq_214000228__3, chunk_214000229__4, count_214000230__5, i_214000231__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000228__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L11 } else { var c__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000228__8); var seq_214000232__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_200.Invoke_O__O(c__9)); var chunk_214000233__11 any; var count_214000234__12 int64 = 0; var i_214000235__13 int64 = 0; L13: for { if lang.Numbers_Lt_J_J__Z(i_214000235__13, count_214000234__12) { var l__14_2 any = lang.Indexed_Cast(chunk_214000233__11).Nth_I__O(lang.RT_IntCast_J__I(i_214000235__13)); if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__14_2)) { var body_pat__15_2 *A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A_New(); var pat__15_2 any; var tmp59 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A_fn_class; if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_69, false); A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A_fn_class = fncls__39d; tmp59 = fncls__39d } else { tmp59 = fncls__39 }; pat__15_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_pat__15_2), tmp59, nil)




					lang.IFn_Cast(pat__15_2).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__14_2))
//line :362:1
					seq_214000232__10, chunk_214000233__11, count_214000234__12, i_214000235__13 = seq_214000232__10, chunk_214000233__11, count_214000234__12, lang.Numbers_Unchecked_inc_J__J(i_214000235__13); continue L13 } else { seq_214000232__10, chunk_214000233__11, count_214000234__12, i_214000235__13 = seq_214000232__10, chunk_214000233__11, count_214000234__12, lang.Numbers_Unchecked_inc_J__J(i_214000235__13); continue L13 } } else { var temp__1927000414__auto____14_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000232__10); if jrt.A2g_Truth(temp__1927000414__auto____14_3) { var seq_214000232__15 any = temp__1927000414__auto____14_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000232__15)) { var c__1927000678__auto____16_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000232__15); seq_214000232__10, chunk_214000233__11, count_214000234__12, i_214000235__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000232__15), c__1927000678__auto____16_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____16_3))), int64(lang.RT_IntCast_J__I(0)); continue L13 } else { var l__16 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000232__15); if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__16)) { var body_pat__17 *A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A = A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A_New(); var pat__17 any; var tmp60 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A_fn_class; if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_70, false); A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A_fn_class = fncls__40d; tmp60 = fncls__40d } else { tmp60 = fncls__40 }; pat__17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(any(body_pat__17), tmp60, nil)




						lang.IFn_Cast(pat__17).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(l__16))
//line :362:1
						seq_214000232__10, chunk_214000233__11, count_214000234__12, i_214000235__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000232__15), nil, 0, 0; continue L13 } else { seq_214000232__10, chunk_214000233__11, count_214000234__12, i_214000235__13 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000232__15), nil, 0, 0; continue L13 } } } }; break L13 }; seq_214000228__3, chunk_214000229__4, count_214000230__5, i_214000231__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000228__8), nil, 0, 0; continue L11 } } else { return nil } } } } else {
//line :361:1
							return nil } }; /*line :262:1*/panic("a2g: unreachable") }







































































func A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A_New() *A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A{}; t.Ctor(); return t }
//line :334:1
func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A) Ctor() {}
//line :334:1
func (t *A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A) Invoke_O_O__O(self, ___1 any) any { return nil }





















func A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A) Ctor() {}
//line :356:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A) Invoke_O_O__O(self, p__1 any) any { lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(p__1)); { var seq_214000223__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_143.Invoke_O__O(p__1)); var chunk_214000224__3 any; var count_214000225__4 int64 = 0; var i_214000226__5 int64 = 0; L1: for {
												if lang.Numbers_Lt_J_J__Z(i_214000226__5, count_214000225__4) { var c__6 any = lang.Indexed_Cast(chunk_214000224__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000226__5)); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_41
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(c__6)), tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(c__6)), tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(c__6)))
													lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(c__6))
//line :357:1
		seq_214000223__2, chunk_214000224__3, count_214000225__4, i_214000226__5 = seq_214000223__2, chunk_214000224__3, count_214000225__4, lang.Numbers_Unchecked_inc_J__J(i_214000226__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000223__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000223__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000223__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000223__7); seq_214000223__2, chunk_214000224__3, count_214000225__4, i_214000226__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000223__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000223__7); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp5 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_41
			lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(c__8)), tmp5.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(c__8)), tmp6.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(c__8)))
			lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(c__8))
//line :357:1
			seq_214000223__2, chunk_214000224__3, count_214000225__4, i_214000226__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000223__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :356:1*/panic("a2g: unreachable") }






func A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A) Ctor() {}
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A) Invoke_O_O__O(self, p__1 any) any { lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(p__1)); { var seq_214000241__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_143.Invoke_O__O(p__1)); var chunk_214000242__3 any; var count_214000243__4 int64 = 0; var i_214000244__5 int64 = 0; L1: for {
												if lang.Numbers_Lt_J_J__Z(i_214000244__5, count_214000243__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000242__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000244__5)); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_41
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)))
													lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__6))
//line :364:1
		seq_214000241__2, chunk_214000242__3, count_214000243__4, i_214000244__5 = seq_214000241__2, chunk_214000242__3, count_214000243__4, lang.Numbers_Unchecked_inc_J__J(i_214000244__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000241__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000241__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000241__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000241__7); seq_214000241__2, chunk_214000242__3, count_214000243__4, i_214000244__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000241__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000241__7); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp5 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_41
			lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp5.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp6.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)))
			lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__8))
//line :364:1
			seq_214000241__2, chunk_214000242__3, count_214000243__4, i_214000244__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000241__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :363:1*/panic("a2g: unreachable") }
//line :363:1
func A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A) Ctor() {}
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A) Invoke_O_O__O(self, p__1 any) any { lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(p__1)); { var seq_214000247__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_143.Invoke_O__O(p__1)); var chunk_214000248__3 any; var count_214000249__4 int64 = 0; var i_214000250__5 int64 = 0; L1: for {
												if lang.Numbers_Lt_J_J__Z(i_214000250__5, count_214000249__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000248__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000250__5)); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_41
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)))
													lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__6))
//line :364:1
		seq_214000247__2, chunk_214000248__3, count_214000249__4, i_214000250__5 = seq_214000247__2, chunk_214000248__3, count_214000249__4, lang.Numbers_Unchecked_inc_J__J(i_214000250__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000247__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000247__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000247__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000247__7); seq_214000247__2, chunk_214000248__3, count_214000249__4, i_214000250__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000247__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000247__7); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp5 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_41
			lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp5.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp6.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)))
			lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__8))
//line :364:1
			seq_214000247__2, chunk_214000248__3, count_214000249__4, i_214000250__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000247__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :363:1*/panic("a2g: unreachable") }
//line :363:1
func A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A) Ctor() {}
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A) Invoke_O_O__O(self, p__1 any) any { lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(p__1)); { var seq_214000253__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_143.Invoke_O__O(p__1)); var chunk_214000254__3 any; var count_214000255__4 int64 = 0; var i_214000256__5 int64 = 0; L1: for {
												if lang.Numbers_Lt_J_J__Z(i_214000256__5, count_214000255__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000254__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000256__5)); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_41
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)))
													lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__6))
//line :364:1
		seq_214000253__2, chunk_214000254__3, count_214000255__4, i_214000256__5 = seq_214000253__2, chunk_214000254__3, count_214000255__4, lang.Numbers_Unchecked_inc_J__J(i_214000256__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000253__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000253__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000253__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000253__7); seq_214000253__2, chunk_214000254__3, count_214000255__4, i_214000256__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000253__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000253__7); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp5 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_41
			lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp5.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp6.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)))
			lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__8))
//line :364:1
			seq_214000253__2, chunk_214000254__3, count_214000255__4, i_214000256__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000253__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :363:1*/panic("a2g: unreachable") }
//line :363:1
func A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A_New() *A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A{}; t.Ctor(); return t }
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A) Ctor() {}
//line :363:1
func (t *A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A) Invoke_O_O__O(self, p__1 any) any { lang.IFn_Cast(A_arbace_a2g_reach_A_const_137.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_142.Invoke_O__O(p__1)); { var seq_214000259__2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_143.Invoke_O__O(p__1)); var chunk_214000260__3 any; var count_214000261__4 int64 = 0; var i_214000262__5 int64 = 0; L1: for {
												if lang.Numbers_Lt_J_J__Z(i_214000262__5, count_214000261__4) { var cc__6 any = lang.Indexed_Cast(chunk_214000260__3).Nth_I__O(lang.RT_IntCast_J__I(i_214000262__5)); var tmp1 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp2 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp3 *lang.Keyword = A_arbace_a2g_reach_A_const_41
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp1.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp2.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)), tmp3.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__6)))
													lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__6))
//line :364:1
		seq_214000259__2, chunk_214000260__3, count_214000261__4, i_214000262__5 = seq_214000259__2, chunk_214000260__3, count_214000261__4, lang.Numbers_Unchecked_inc_J__J(i_214000262__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000259__2); if jrt.A2g_Truth(temp__1927000414__auto____6) { var seq_214000259__7 any = temp__1927000414__auto____6; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000259__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000259__7); seq_214000259__2, chunk_214000260__3, count_214000261__4, i_214000262__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000259__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cc__8 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000259__7); var tmp4 *lang.Keyword = A_arbace_a2g_reach_A_const_126; var tmp5 *lang.Keyword = A_arbace_a2g_reach_A_const_40; var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_41
			lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(tmp4.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp5.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)), tmp6.Invoke_O__O(A_arbace_a2g_reach_A_const_145.Invoke_O__O(cc__8)))
			lang.IFn_Cast(self).Invoke_O__O(A_arbace_a2g_reach_A_const_146.Invoke_O__O(cc__8))
//line :364:1
			seq_214000259__2, chunk_214000260__3, count_214000261__4, i_214000262__5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000259__7), nil, 0, 0; continue L1 } } else { return nil } } } }; /*line :363:1*/panic("a2g: unreachable") }
















func A_arbace_a2g_reach_flatten_code_A_New() *A_arbace_a2g_reach_flatten_code_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_flatten_code_A{}; t.Ctor(); return t }
//line :380:1
func (t *A_arbace_a2g_reach_flatten_code_A) Ctor() {}
//line :380:1
func (t *A_arbace_a2g_reach_flatten_code_A) Invoke_O_O__O(self, node__0 any) any { var acc__2 any = jrt.ArrayList_New(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_183.GetRawRoot__O()); var tmp2 any = A_arbace_a2g_reach_flatten_code_fn__214000265_A_New_O(acc__2); var tmp3 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_a2g_reach_flatten_code_fn__214000265_A_fn_class; if



	fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_14, false); A_arbace_a2g_reach_flatten_code_fn__214000265_A_fn_class = fncls__41d; tmp3 = fncls__41d } else { tmp3 = fncls__41 }; tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), node__0); return /*line :385:1*/ lang.IFn_Cast(A_arbace_a2g_reach_A_const_106.GetRawRoot__O()).Invoke_O__O(acc__2) }
//line :384:1
func A_arbace_a2g_reach_flatten_code_fn__214000265_A_New_O(p0 any) *A_arbace_a2g_reach_flatten_code_fn__214000265_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_flatten_code_fn__214000265_A{}; t.Ctor_O(p0); return t }
//line :384:1
func (t *A_arbace_a2g_reach_flatten_code_fn__214000265_A) Ctor_O(c__acc any) { t.F_acc = c__acc }
//line :384:1
func (t *A_arbace_a2g_reach_flatten_code_fn__214000265_A) Invoke_O_O__O(self, n__1 any) any { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_18.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_201.GetRawRoot__O(), A_arbace_a2g_reach_A_const_19.Invoke_O__O(n__1))) { return jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.ArrayList_Cast(t.F_acc)).Add_O__Z(n__1)).Ref() } else { return nil } }


func A_arbace_a2g_reach_scan_code_BANG__A_New() *A_arbace_a2g_reach_scan_code_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_code_BANG__A{}; t.Ctor(); return t }
//line :387:1
func (t *A_arbace_a2g_reach_scan_code_BANG__A) Ctor() {}
//line :387:1
func (t *A_arbace_a2g_reach_scan_code_BANG__A) Invoke_O_O__O(self, node__0 any) any { var flat__2 any = A_arbace_a2g_reach_A_const_202.Get__O(); var temp__1927000408__auto____3 any; var and__1927000168__auto____3 any = flat__2; if

	jrt.A2g_Truth(and__1927000168__auto____3) { temp__1927000408__auto____3 = jrt.NN(jrt.IdentityHashMap_Cast(flat__2)).Get_O__O(node__0) } else { temp__1927000408__auto____3 = and__1927000168__auto____3 }; if jrt.A2g_Truth(temp__1927000408__auto____3) { var ns__4 any = temp__1927000408__auto____3
		return lang.IFn_Cast(A_arbace_a2g_reach_A_const_203.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_204.GetRawRoot__O(), ns__4) } else {
			return lang.IFn_Cast(A_arbace_a2g_reach_A_const_183.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_204.GetRawRoot__O(), node__0) } }

func A_arbace_a2g_reach_method_code_A_New() *A_arbace_a2g_reach_method_code_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_method_code_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_a2g_reach_method_code_A) Ctor() {}
//line :393:1
func (t *A_arbace_a2g_reach_method_code_A) Invoke_O_O__O(self, p__214000269__0 any) any { var vec__214000270__2 any = p__214000269__0; var c__3 any = lang.RT_Nth_O_I_O__O(vec__214000270__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000270__2, lang.RT_IntCast_J__I(1), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000270__2, lang.RT_IntCast_J__I(2), nil); var d__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(c__3); var st__7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_90.Invoke_O__O(d__6)); if




	lang.Util_Equiv_O_O__Z(name__4, Lit_16) {
		return lang.IFn_Cast(A_arbace_a2g_reach_A_const_106.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_206.Invoke_O__O(st__7)) } else {
//line :398:1
			var ab__8 any = lang.RT_Get_O_O__O(A_arbace_a2g_reach_A_const_205.Invoke_O__O(st__7), lang.Tuple_Create_O_O__IPersistentVector(name__4, desc__5))


			if lang.Util_Equiv_O_O__Z(name__4, Lit_11) {
				var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_106.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_105.GetRawRoot__O()); var tmp3 any = A_arbace_a2g_reach_A_const_207.Invoke_O__O(ab__8); var tmp4 any = lang.Tuple_Create_O__IPersistentVector(A_arbace_a2g_reach_A_const_210.Invoke_O__O(ab__8)); var tmp5 any; if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_208.Invoke_O__O(ab__8)) { tmp5 = A_arbace_a2g_reach_A_const_209.Invoke_O__O(st__7) } else { tmp5 = nil }; return tmp1.Invoke_O__O(tmp2.Invoke_O_O_O_O__O(tmp3, tmp4, tmp5, lang.Tuple_Create_O__IPersistentVector(A_arbace_a2g_reach_A_const_211.Invoke_O__O(ab__8)))) } else {
					if jrt.A2g_Truth(ab__8) { return lang.Tuple_Create_O__IPersistentVector(A_arbace_a2g_reach_A_const_211.Invoke_O__O(ab__8)) } else { lang.PersistentVector_Init(); return lang.PersistentVector_EMPTY.Ref() } } } }

func A_arbace_a2g_reach_scan_method_BANG__A_New() *A_arbace_a2g_reach_scan_method_BANG__A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_scan_method_BANG__A{}; t.Ctor(); return t }
//line :405:1
func (t *A_arbace_a2g_reach_scan_method_BANG__A) Ctor() {}
//line :405:1
func (t *A_arbace_a2g_reach_scan_method_BANG__A) Invoke_O_O__O(self, p__214000274__0 any) any { var vec__214000275__2 any = p__214000274__0; var c__3 any = lang.RT_Nth_O_I_O__O(vec__214000275__2, lang.RT_IntCast_J__I(0), nil); var name__4 any = lang.RT_Nth_O_I_O__O(vec__214000275__2, lang.RT_IntCast_J__I(1), nil); var desc__5 any = lang.RT_Nth_O_I_O__O(vec__214000275__2, lang.RT_IntCast_J__I(2), nil); var k__6 any = vec__214000275__2;
												lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_63, k__6)); var tmp1 any; tmp3 := /*line :405:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var d__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(c__3); var st__10 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_90.Invoke_O__O(d__9)); var mm__11 any



		if lang.Util_Equiv_O_O__Z(name__4, Lit_16) { mm__11 = nil } else { mm__11 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(c__3, name__4, desc__5) }
//line :405:1
		var temp__1927000414__auto____12 any = A_arbace_a2g_reach_A_const_82.Invoke_O__O(st__10)




		if jrt.A2g_Truth(temp__1927000414__auto____12) { var why__13 any = temp__1927000414__auto____12; lang.IFn_Cast(A_arbace_a2g_reach_A_const_87.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_31, nil), jrt.RefArrayOf(jrt.Object_class, nil, why__13)).Ref()) }
		if jrt.A2g_Truth(mm__11) { var seq_214000278__12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_196.GetRawRoot__O()).Invoke_O__O(desc__5)); var chunk_214000279__13 any; var count_214000280__14 int64 = 0; var i_214000281__15 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z(i_214000281__15, count_214000280__14) { var cl__16 any = lang.Indexed_Cast(chunk_214000279__13).Nth_I__O(lang.RT_IntCast_J__I(i_214000281__15)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(cl__16); seq_214000278__12, chunk_214000279__13, count_214000280__14, i_214000281__15 = seq_214000278__12, chunk_214000279__13, count_214000280__14, lang.Numbers_Unchecked_inc_J__J(i_214000281__15); continue L1 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000278__12); if jrt.A2g_Truth(temp__1927000414__auto____16) { var seq_214000278__17 any = temp__1927000414__auto____16; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000278__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000278__17); seq_214000278__12, chunk_214000279__13, count_214000280__14, i_214000281__15 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000278__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I(0)); continue L1 } else { var cl__18 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000278__17); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(cl__18); seq_214000278__12, chunk_214000279__13, count_214000280__14, i_214000281__15 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000278__17), nil, 0, 0; continue L1 } } }
//line :411:1
			break L1 } }
//line :405:1
		var G__214000282__12_ any = name__4







	L2: switch { default: switch lang.Util_Hash_O__I(G__214000282__12_) { case -1944711511: if lang.Util_Equiv_O_O__Z(G__214000282__12_, Lit_16) { var seq_214000283__13 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_206.Invoke_O__O(st__10)); var chunk_214000284__14 any; var count_214000285__15 int64 = 0; var i_214000286__16 int64 = 0; L3: for {

		if lang.Numbers_Lt_J_J__Z(i_214000286__16, count_214000285__15) { var nd__17 any = lang.Indexed_Cast(chunk_214000284__14).Nth_I__O(lang.RT_IntCast_J__I(i_214000286__16)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(nd__17); seq_214000283__13, chunk_214000284__14, count_214000285__15, i_214000286__16 = seq_214000283__13, chunk_214000284__14, count_214000285__15, lang.Numbers_Unchecked_inc_J__J(i_214000286__16); continue L3 } else { var temp__1927000414__auto____17 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000283__13); if jrt.A2g_Truth(temp__1927000414__auto____17) { var seq_214000283__18 any = temp__1927000414__auto____17; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000283__18)) { var c__1927000678__auto____19 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000283__18); seq_214000283__13, chunk_214000284__14, count_214000285__15, i_214000286__16 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000283__18), c__1927000678__auto____19, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var nd__19 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000283__18); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(nd__19); seq_214000283__13, chunk_214000284__14, count_214000285__15, i_214000286__16 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000283__18), nil, 0, 0; continue L3 } } }
//line :413:1
		break L3
	}

		if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_222.Invoke_O__O(st__10))) {
			lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32))
//line :416:1
			var seq_214000287__13 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_222.Invoke_O__O(st__10)); var chunk_214000288__14 any; var count_214000289__15 int64 = 0; var i_214000290__16 int64 = 0; L4: for {

				if lang.Numbers_Lt_J_J__Z(i_214000290__16, count_214000289__15) { var vec__214000291__17 any = lang.Indexed_Cast(chunk_214000288__14).Nth_I__O(lang.RT_IntCast_J__I(i_214000290__16)); var ___18 any = lang.RT_Nth_O_I_O__O(vec__214000291__17, lang.RT_IntCast_J__I(0), nil); var map__214000294__19 any = lang.RT_Nth_O_I_O__O(vec__214000291__17, lang.RT_IntCast_J__I(1), nil); var map__214000294__20 any; _ = ___18; if lang.ISeq_InstanceOf(map__214000294__19) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(map__214000294__19)) { map__214000294__20 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_reach_A_const_127.GetRawRoot__O()).Invoke_O__O(map__214000294__19), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(map__214000294__19)) { map__214000294__20 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(map__214000294__19) } else { lang.PersistentArrayMap_Init(); map__214000294__20 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000294__20 = map__214000294__19 }; var init__21 any = lang.RT_Get_O_O__O(map__214000294__20, A_arbace_a2g_reach_A_const_209); var G__214000296__22_ any = A_arbace_a2g_reach_A_const_128.Invoke_O__O(init__21)
				L5: switch { default: switch lang.Util_Hash_O__I(G__214000296__22_) >> 0 & 1 { case 0: if any(G__214000296__22_) == any(A_arbace_a2g_reach_A_const_223) {
					lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32))
					lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32), Lit_33, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_reach_A_const_225.GetRawRoot__O()).Invoke_O__O(Lit_35))).Ref()))
//line :419:1
					break L5 }; case 1: if any(G__214000296__22_) == any(A_arbace_a2g_reach_A_const_224) {


						lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32))
						lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32), Lit_36, Lit_37))
//line :419:1
						break L5 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000296__22_)))))}
//line :418:1
					seq_214000287__13, chunk_214000288__14, count_214000289__15, i_214000290__16 = seq_214000287__13, chunk_214000288__14, count_214000289__15, lang.Numbers_Unchecked_inc_J__J(i_214000290__16); continue L4 } else { var temp__1927000414__auto____17_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000287__13); if jrt.A2g_Truth(temp__1927000414__auto____17_2) { var seq_214000287__18 any = temp__1927000414__auto____17_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000287__18)) { var c__1927000678__auto____19_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000287__18); seq_214000287__13, chunk_214000288__14, count_214000289__15, i_214000290__16 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000287__18), c__1927000678__auto____19_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19_2))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var vec__214000297__19 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000287__18); var ___20 any = lang.RT_Nth_O_I_O__O(vec__214000297__19, lang.RT_IntCast_J__I(0), nil); var map__214000300__21 any = lang.RT_Nth_O_I_O__O(vec__214000297__19, lang.RT_IntCast_J__I(1), nil); var map__214000300__22 any; _ = ___20; if lang.ISeq_InstanceOf(map__214000300__21) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(map__214000300__21)) { map__214000300__22 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_reach_A_const_127.GetRawRoot__O()).Invoke_O__O(map__214000300__21), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(map__214000300__21)) { map__214000300__22 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(map__214000300__21) } else { lang.PersistentArrayMap_Init(); map__214000300__22 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000300__22 = map__214000300__21 }; var init__23 any = lang.RT_Get_O_O__O(map__214000300__22, A_arbace_a2g_reach_A_const_209); var G__214000302__24_ any = A_arbace_a2g_reach_A_const_128.Invoke_O__O(init__23)
					L6: switch { default: switch lang.Util_Hash_O__I(G__214000302__24_) >> 0 & 1 { case 0: if any(G__214000302__24_) == any(A_arbace_a2g_reach_A_const_223) {
						lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32))
						lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32), Lit_33, lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_34, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_a2g_reach_A_const_225.GetRawRoot__O()).Invoke_O__O(Lit_35))).Ref()))
//line :419:1
						break L6 }; case 1: if any(G__214000302__24_) == any(A_arbace_a2g_reach_A_const_224) {


							lang.IFn_Cast(A_arbace_a2g_reach_A_const_104.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32))
							lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.IFn_Cast(A_arbace_a2g_reach_A_const_178.GetRawRoot__O()).Invoke_O__O(Lit_32), Lit_36, Lit_37))
//line :419:1
							break L6 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_38, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__214000302__24_)))))}
//line :418:1
						seq_214000287__13, chunk_214000288__14, count_214000289__15, i_214000290__16 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000287__18), nil, 0, 0; continue L4 } } }
//line :416:1
				break L4
			}
		}





		var tmp2 any; var or__1927000174__auto____13 any = A_arbace_a2g_reach_A_const_213.Invoke_O__O(st__10); if jrt.A2g_Truth(or__1927000174__auto____13) { tmp2 = or__1927000174__auto____13 } else { tmp2 = A_arbace_a2g_reach_A_const_214.Invoke_O__O(st__10) }; if jrt.A2g_Truth(tmp2) { tmp1 = nil } else { tmp1 = nil }
//line :413:1
		break L2 }; default:
	}










		if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_215.Invoke_O__O(mm__11)) { var G__214000303__13_ any = A_arbace_a2g_reach_A_const_215.Invoke_O__O(mm__11)

		L7: switch { default: switch lang.Util_Hash_O__I(G__214000303__13_) >> 0 & 7 { case 0: if any(G__214000303__13_) == any(A_arbace_a2g_reach_A_const_216) { var ab__14 any = lang.RT_Get_O_O__O(A_arbace_a2g_reach_A_const_205.Invoke_O__O(st__10), lang.Tuple_Create_O_O__IPersistentVector(Lit_11, desc__5)); var temp__1927000414__auto____15 any = A_arbace_a2g_reach_A_const_210.Invoke_O__O(ab__14)











			if jrt.A2g_Truth(temp__1927000414__auto____15) { var call__16 any = temp__1927000414__auto____15; lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(call__16) }
//line :427:1
			var seq_214000304__15 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_209.Invoke_O__O(st__10)); var chunk_214000305__16 any; var count_214000306__17 int64 = 0; var i_214000307__18 int64 = 0; L8: for {












				if lang.Numbers_Lt_J_J__Z(i_214000307__18, count_214000306__17) { var i__19 any = lang.Indexed_Cast(chunk_214000305__16).Nth_I__O(lang.RT_IntCast_J__I(i_214000307__18)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(i__19); seq_214000304__15, chunk_214000305__16, count_214000306__17, i_214000307__18 = seq_214000304__15, chunk_214000305__16, count_214000306__17, lang.Numbers_Unchecked_inc_J__J(i_214000307__18); continue L8 } else { var temp__1927000414__auto____19 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000304__15); if jrt.A2g_Truth(temp__1927000414__auto____19) { var seq_214000304__20 any = temp__1927000414__auto____19; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000304__20)) { var c__1927000678__auto____21 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000304__20); seq_214000304__15, chunk_214000305__16, count_214000306__17, i_214000307__18 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000304__20), c__1927000678__auto____21, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____21))), int64(lang.RT_IntCast_J__I(0)); continue L8 } else { var i__21 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000304__20); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(i__21); seq_214000304__15, chunk_214000305__16, count_214000306__17, i_214000307__18 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000304__20), nil, 0, 0; continue L8 } } else { tmp1 = nil } }
//line :427:1
				break L8 }; break L7 }; case 2: if any(G__214000303__13_) == any(A_arbace_a2g_reach_A_const_217) { var ab__14_2 any = lang.RT_Get_O_O__O(A_arbace_a2g_reach_A_const_205.Invoke_O__O(st__10), lang.Tuple_Create_O_O__IPersistentVector(Lit_11, desc__5)); var temp__1927000414__auto____15_2 any = A_arbace_a2g_reach_A_const_210.Invoke_O__O(ab__14_2)











					if jrt.A2g_Truth(temp__1927000414__auto____15_2) { var call__16_2 any = temp__1927000414__auto____15_2; lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(call__16_2) }
//line :427:1
					var seq_214000308__15 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_209.Invoke_O__O(st__10)); var chunk_214000309__16 any; var count_214000310__17 int64 = 0; var i_214000311__18 int64 = 0; L9: for {












						if lang.Numbers_Lt_J_J__Z(i_214000311__18, count_214000310__17) { var i__19_2 any = lang.Indexed_Cast(chunk_214000309__16).Nth_I__O(lang.RT_IntCast_J__I(i_214000311__18)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(i__19_2); seq_214000308__15, chunk_214000309__16, count_214000310__17, i_214000311__18 = seq_214000308__15, chunk_214000309__16, count_214000310__17, lang.Numbers_Unchecked_inc_J__J(i_214000311__18); continue L9 } else { var temp__1927000414__auto____19_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000308__15); if jrt.A2g_Truth(temp__1927000414__auto____19_2) { var seq_214000308__20 any = temp__1927000414__auto____19_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000308__20)) { var c__1927000678__auto____21_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000308__20); seq_214000308__15, chunk_214000309__16, count_214000310__17, i_214000311__18 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000308__20), c__1927000678__auto____21_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____21_2))), int64(lang.RT_IntCast_J__I(0)); continue L9 } else { var i__21_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000308__20); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(i__21_2); seq_214000308__15, chunk_214000309__16, count_214000310__17, i_214000311__18 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000308__20), nil, 0, 0; continue L9 } } else { tmp1 = nil } }
//line :427:1
						break L9 }; break L7 }; case 3: if any(G__214000303__13_) == any(A_arbace_a2g_reach_A_const_218) { var tg__14 any = A_arbace_a2g_reach_A_const_219.Invoke_O__O(mm__11)

							if jrt.A2g_Truth(A_arbace_a2g_reach_A_const_193.Invoke_O__O(mm__11)) {
								tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(A_arbace_a2g_reach_A_const_126.Invoke_O__O(tg__14), A_arbace_a2g_reach_A_const_40.Invoke_O__O(tg__14), A_arbace_a2g_reach_A_const_41.Invoke_O__O(tg__14))) } else {
									tmp1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(c__3, A_arbace_a2g_reach_A_const_40.Invoke_O__O(tg__14), A_arbace_a2g_reach_A_const_41.Invoke_O__O(tg__14)) }
//line :427:1
							break L7 }; case 4: if any(G__214000303__13_) == any(A_arbace_a2g_reach_A_const_220) { var ab__14_3 any = lang.RT_Get_O_O__O(A_arbace_a2g_reach_A_const_205.Invoke_O__O(st__10), lang.Tuple_Create_O_O__IPersistentVector(Lit_11, desc__5)); var temp__1927000414__auto____15_3 any = A_arbace_a2g_reach_A_const_210.Invoke_O__O(ab__14_3)











								if jrt.A2g_Truth(temp__1927000414__auto____15_3) { var call__16_3 any = temp__1927000414__auto____15_3; lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(call__16_3) }
//line :427:1
								var seq_214000312__15 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_209.Invoke_O__O(st__10)); var chunk_214000313__16 any; var count_214000314__17 int64 = 0; var i_214000315__18 int64 = 0; L10: for {












									if lang.Numbers_Lt_J_J__Z(i_214000315__18, count_214000314__17) { var i__19_3 any = lang.Indexed_Cast(chunk_214000313__16).Nth_I__O(lang.RT_IntCast_J__I(i_214000315__18)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(i__19_3); seq_214000312__15, chunk_214000313__16, count_214000314__17, i_214000315__18 = seq_214000312__15, chunk_214000313__16, count_214000314__17, lang.Numbers_Unchecked_inc_J__J(i_214000315__18); continue L10 } else { var temp__1927000414__auto____19_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000312__15); if jrt.A2g_Truth(temp__1927000414__auto____19_3) { var seq_214000312__20 any = temp__1927000414__auto____19_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000312__20)) { var c__1927000678__auto____21_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000312__20); seq_214000312__15, chunk_214000313__16, count_214000314__17, i_214000315__18 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000312__20), c__1927000678__auto____21_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____21_3))), int64(lang.RT_IntCast_J__I(0)); continue L10 } else { var i__21_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000312__20); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(i__21_3); seq_214000312__15, chunk_214000313__16, count_214000314__17, i_214000315__18 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000312__20), nil, 0, 0; continue L10 } } else { tmp1 = nil } }
//line :427:1
									break L10 }; break L7 }; case 7: if any(G__214000303__13_) == any(A_arbace_a2g_reach_A_const_226) { var seq_214000316__14 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_227.Invoke_O__O(d__9)); var chunk_214000317__15 any; var count_214000318__16 int64 = 0; var i_214000319__17 int64 = 0; L11: for {




										if lang.Numbers_Lt_J_J__Z(i_214000319__17, count_214000318__16) { var cm__18 any = lang.Indexed_Cast(chunk_214000317__15).Nth_I__O(lang.RT_IntCast_J__I(i_214000319__17))
											if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_41.Invoke_O__O(cm__18))) {
												lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_1, Lit_39, Lit_40)
												lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_1, Lit_41, Lit_42)
												lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_1, Lit_43, Lit_44) }
//line :432:1
											seq_214000316__14, chunk_214000317__15, count_214000318__16, i_214000319__17 = seq_214000316__14, chunk_214000317__15, count_214000318__16, lang.Numbers_Unchecked_inc_J__J(i_214000319__17); continue L11 } else { var temp__1927000414__auto____18 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000316__14); if jrt.A2g_Truth(temp__1927000414__auto____18) { var seq_214000316__19 any = temp__1927000414__auto____18; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000316__19)) { var c__1927000678__auto____20 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000316__19); seq_214000316__14, chunk_214000317__15, count_214000318__16, i_214000319__17 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000316__19), c__1927000678__auto____20, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____20))), int64(lang.RT_IntCast_J__I(0)); continue L11 } else { var cm__20 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000316__19)
												if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_151.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_41.Invoke_O__O(cm__20))) {
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_1, Lit_39, Lit_40)
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_1, Lit_41, Lit_42)
													lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(Lit_1, Lit_43, Lit_44) }
//line :432:1
												seq_214000316__14, chunk_214000317__15, count_214000318__16, i_214000319__17 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000316__19), nil, 0, 0; continue L11 } } else { tmp1 = nil } }
//line :427:1
										break L11 }; break L7 }; default:}; tmp1 = nil} } else {
//line :425:1
											if A_arbace_a2g_reach_A_const_31 != nil { var seq_214000320__13 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_228.GetRawRoot__O()).Invoke_O__O(k__6)); var chunk_214000321__14 any; var count_214000322__15 int64 = 0; var i_214000323__16 int64 = 0; L12: for {
















												if lang.Numbers_Lt_J_J__Z(i_214000323__16, count_214000322__15) { var nd__17_2 any = lang.Indexed_Cast(chunk_214000321__14).Nth_I__O(lang.RT_IntCast_J__I(i_214000323__16)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(nd__17_2); seq_214000320__13, chunk_214000321__14, count_214000322__15, i_214000323__16 = seq_214000320__13, chunk_214000321__14, count_214000322__15, lang.Numbers_Unchecked_inc_J__J(i_214000323__16); continue L12 } else { var temp__1927000414__auto____17_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000320__13); if jrt.A2g_Truth(temp__1927000414__auto____17_3) { var seq_214000320__18 any = temp__1927000414__auto____17_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000320__18)) { var c__1927000678__auto____19_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000320__18); seq_214000320__13, chunk_214000321__14, count_214000322__15, i_214000323__16 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000320__18), c__1927000678__auto____19_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____19_3))), int64(lang.RT_IntCast_J__I(0)); continue L12 } else { var nd__19_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000320__18); lang.IFn_Cast(A_arbace_a2g_reach_A_const_221.GetRawRoot__O()).Invoke_O__O(nd__19_2); seq_214000320__13, chunk_214000321__14, count_214000322__15, i_214000323__16 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000320__18), nil, 0, 0; continue L12 } } else { tmp1 = nil } }
//line :425:1
												break L12 } } else { tmp1 = nil } }} }; return nil }(); /*line :406:1*/lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if /*line :405:1*/ tmp3 != nil { panic(tmp3) }; return tmp1 }






































func A_arbace_a2g_reach_run_A_New() *A_arbace_a2g_reach_run_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_A{}; t.Ctor(); return t }
//line :444:1
func (t *A_arbace_a2g_reach_run_A) Ctor() {}
//line :444:1
func (t *A_arbace_a2g_reach_run_A) Invoke_O_O__O(self, p__214000325__0 any) any { var map__214000326__2 any = p__214000325__0; var map__214000326__3 any; if lang.ISeq_InstanceOf(map__214000326__2) { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(map__214000326__2)) { map__214000326__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap(jrt.A2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_a2g_reach_A_const_127.GetRawRoot__O()).Invoke_O__O(map__214000326__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(map__214000326__2)) { map__214000326__3 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(map__214000326__2) } else { lang.PersistentArrayMap_Init(); map__214000326__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__214000326__3 = map__214000326__2 }; var roots__4 any = lang.RT_Get_O_O__O(map__214000326__3, A_arbace_a2g_reach_A_const_229); var instantiate__5 any = lang.RT_Get_O_O__O(map__214000326__3, A_arbace_a2g_reach_A_const_230); var classes__6 any = lang.RT_Get_O_O__O(map__214000326__3, A_arbace_a2g_reach_A_const_173); var slice_QMARK___7 any = lang.RT_Get_O_O__O(map__214000326__3, A_arbace_a2g_reach_A_const_231); var fis__8 any = lang.RT_Get_O_O__O(map__214000326__3, A_arbace_a2g_reach_A_const_232); var state__9 any = lang.RT_Get_O_O__O(map__214000326__3, A_arbace_a2g_reach_A_const_90); var st__10 any; var or__1927000174__auto____10 any = state__9; if






	jrt.A2g_Truth(or__1927000174__auto____10) { st__10 = or__1927000174__auto____10 } else { var tmp1 any = A_arbace_a2g_reach_A_const_91; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp3 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp3 = lang.PersistentHashSet_EMPTY; var tmp4 any = tmp2.Invoke_O__O(tmp3.Ref()); var tmp5 any = A_arbace_a2g_reach_A_const_100; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp7 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp7 = lang.PersistentHashSet_EMPTY; var tmp8 any = tmp6.Invoke_O__O(tmp7.Ref()); var tmp9 any = A_arbace_a2g_reach_A_const_101; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp11 *lang.PersistentVector; lang.PersistentVector_Init(); tmp11 = lang.PersistentVector_EMPTY; var tmp12 any = tmp10.Invoke_O__O(tmp11.Ref()); var tmp13 any = A_arbace_a2g_reach_A_const_109; var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp15 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp15 = lang.PersistentHashSet_EMPTY; var tmp16 any = tmp14.Invoke_O__O(tmp15.Ref()); var tmp17 any = A_arbace_a2g_reach_A_const_115; var tmp18 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp19 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp19 = lang.PersistentHashSet_EMPTY; var tmp20 any = tmp18.Invoke_O__O(tmp19.Ref()); var tmp21 any = A_arbace_a2g_reach_A_const_107; var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp23 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp23 = lang.PersistentArrayMap_EMPTY; var tmp24 any = tmp22.Invoke_O__O(tmp23.Ref()); var tmp25 any = A_arbace_a2g_reach_A_const_110; var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp27 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp27 = lang.PersistentArrayMap_EMPTY; var tmp28 any = tmp26.Invoke_O__O(tmp27.Ref()); var tmp29 any = A_arbace_a2g_reach_A_const_103; var tmp30 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp31 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp31 = lang.PersistentHashSet_EMPTY; var tmp32 any = tmp30.Invoke_O__O(tmp31.Ref()); var tmp33 any = A_arbace_a2g_reach_A_const_65; var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp35 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp35 = lang.PersistentArrayMap_EMPTY; var tmp36 any = tmp34.Invoke_O__O(tmp35.Ref()); var tmp37 any = A_arbace_a2g_reach_A_const_97; var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp39 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp39 = lang.PersistentArrayMap_EMPTY; var tmp40 any = tmp38.Invoke_O__O(tmp39.Ref()); var tmp41 any = A_arbace_a2g_reach_A_const_86; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp43 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp43 = lang.PersistentArrayMap_EMPTY; var tmp44 any = tmp42.Invoke_O__O(tmp43.Ref()); var tmp45 any = A_arbace_a2g_reach_A_const_117; var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_233.GetRawRoot__O()); var tmp47 *lang.PersistentHashSet; lang.PersistentHashSet_Init(); tmp47 = lang.PersistentHashSet_EMPTY; st__10 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp4, tmp5, tmp8, tmp9, tmp12, tmp13, tmp16, tmp17, tmp20, tmp21, tmp24, tmp25, tmp28, tmp29, tmp32, tmp33, tmp36, tmp37, tmp40, tmp41, tmp44, tmp45, tmp46.Invoke_O__O(tmp47.Ref()))) }; var tmp48 lang.IFn =




	lang.IFn_Cast(A_arbace_a2g_reach_A_const_92.GetRawRoot__O()); var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_93.GetRawRoot__O()); var tmp50 any = A_arbace_a2g_reach_A_const_66; var tmp51 any = A_arbace_a2g_reach_A_const_89; var tmp52 any; var or__1927000174__auto____11 any = slice_QMARK___7; if
	jrt.A2g_Truth(or__1927000174__auto____11) { tmp52 = or__1927000174__auto____11 } else { var tmp53 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_242.GetRawRoot__O()); var tmp54 *jrt.Boolean; jrt.Boolean_Init(); tmp54 = jrt.Boolean_TRUE; tmp52 = tmp53.Invoke_O__O(tmp54.Ref()) }; var tmp55 any = tmp52; var tmp56 any = A_arbace_a2g_reach_A_const_72; var tmp57 lang.IFn = /*line :456:1*/lang.IFn_Cast(A_arbace_a2g_reach_A_const_39.GetRawRoot__O()); var tmp58 any = A_arbace_a2g_reach_A_const_72.Get__O(); var tmp59 any = A_arbace_a2g_reach_A_const_91; var tmp60 any = tmp57.Invoke_O_O_O__O(tmp58, tmp59, A_arbace_a2g_reach_A_const_91.Invoke_O__O(st__10)); var tmp61 any = A_arbace_a2g_reach_A_const_202; var tmp62 any = jrt.IdentityHashMap_New(); var tmp63 any = A_arbace_a2g_reach_A_const_36; tmp48.Invoke_O__O(tmp49.Invoke_O_O_O_O_O_O_O_O_O_O__O(tmp50, st__10, tmp51, tmp55, tmp56, tmp60, tmp61, tmp62, tmp63, jrt.HashMap_New())); var tmp64 any = A_arbace_a2g_reach_run_fn__214000328_A_New_O_O_O_O_O(classes__6, instantiate__5, fis__8, roots__4, st__10); var tmp65 *jrt.Class; var fncls__51 *jrt.Class = A_arbace_a2g_reach_run_fn__214000328_A_fn_class; if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_25, false); A_arbace_a2g_reach_run_fn__214000328_A_fn_class = fncls__51d; tmp65 = fncls__51d } else { tmp65 = fncls__51 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp64, tmp65, nil).Invoke__O(); var tmp66 any = A_arbace_a2g_reach_A_const_91; var tmp67 any = /*line :444:1*/lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_91.Invoke_O__O(st__10)); var tmp68 any = A_arbace_a2g_reach_A_const_100; var tmp69 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_100.Invoke_O__O(st__10)); var tmp70 any = A_arbace_a2g_reach_A_const_109; var tmp71 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_109.Invoke_O__O(st__10)); var tmp72 any = A_arbace_a2g_reach_A_const_65; var tmp73 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_65.Invoke_O__O(st__10)); var tmp74 any = A_arbace_a2g_reach_A_const_97; var tmp75 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_97.Invoke_O__O(st__10)); var tmp76 any = A_arbace_a2g_reach_A_const_86; var tmp77 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_86.Invoke_O__O(st__10)); var tmp78 any = A_arbace_a2g_reach_A_const_115; return lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp66, tmp67, tmp68, tmp69, tmp70, tmp71, tmp72, tmp73, tmp74, tmp75, tmp76, tmp77, tmp78, lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_115.Invoke_O__O(st__10)), A_arbace_a2g_reach_A_const_90, st__10)) }











func A_arbace_a2g_reach_run_fn__214000328_A_New_O_O_O_O_O(p0, p1, p2, p3, p4 any) *A_arbace_a2g_reach_run_fn__214000328_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000328_A{}; t.Ctor_O_O_O_O_O(p0, p1, p2, p3, p4); return t }
//line :456:1
func (t *A_arbace_a2g_reach_run_fn__214000328_A) Ctor_O_O_O_O_O(c__classes, c__instantiate, c__fis, c__roots, c__st any) { t.F_classes = c__classes; t.F_instantiate = c__instantiate; t.F_fis = c__fis; t.F_roots = c__roots; t.F_st = c__st }
//line :456:1
func (t *A_arbace_a2g_reach_run_fn__214000328_A) Invoke_O__O(self any) any { for { var tmp1 any; tmp21 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var seq_214000329__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_classes




	t.F_classes = nil; tmp3 = t_; seq_214000329__3 = tmp2.Invoke_O__O(tmp3)
//line :456:1
	var chunk_214000330__4 any; var count_214000331__5 int64 = 0; var i_214000332__6 int64 = 0; L2: for {




		if lang.Numbers_Lt_J_J__Z(i_214000332__6, count_214000331__5) { var c__7 any = lang.Indexed_Cast(chunk_214000330__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000332__6)); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__7); seq_214000329__3, chunk_214000330__4, count_214000331__5, i_214000332__6 = seq_214000329__3, chunk_214000330__4, count_214000331__5, lang.Numbers_Unchecked_inc_J__J(i_214000332__6); continue L2 } else { var temp__1927000414__auto____7 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000329__3); if jrt.A2g_Truth(temp__1927000414__auto____7) { var seq_214000329__8 any = temp__1927000414__auto____7; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000329__8)) { var c__1927000678__auto____9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000329__8); seq_214000329__3, chunk_214000330__4, count_214000331__5, i_214000332__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000329__8), c__1927000678__auto____9, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9))), int64(lang.RT_IntCast_J__I(0)); continue L2 } else { var c__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000329__8); lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__9); seq_214000329__3, chunk_214000330__4, count_214000331__5, i_214000332__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000329__8), nil, 0, 0; continue L2 } } }
//line :456:1
		break L2 }; var seq_214000333__3 any; var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()); var tmp5 any; var t__2 any = t.F_roots





	t.F_roots = nil; tmp5 = t__2; seq_214000333__3 = tmp4.Invoke_O__O(tmp5)
//line :456:1
	var chunk_214000334__4 any; var count_214000335__5 int64 = 0; var i_214000336__6 int64 = 0; L3: for {





		if lang.Numbers_Lt_J_J__Z(i_214000336__6, count_214000335__5) { var vec__214000337__7 any = lang.Indexed_Cast(chunk_214000334__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000336__6)); var c__8 any = lang.RT_Nth_O_I_O__O(vec__214000337__7, lang.RT_IntCast_J__I(0), nil); var name__9 any = lang.RT_Nth_O_I_O__O(vec__214000337__7, lang.RT_IntCast_J__I(1), nil); var desc__10 any = lang.RT_Nth_O_I_O__O(vec__214000337__7, lang.RT_IntCast_J__I(2), nil); var k__11 any = vec__214000337__7
			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__8)) {
				lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(k__11)

				var tmp6 any; var and__1927000168__auto____12 bool = lang.Util_Equiv_O_O__Z(Lit_11, name__9); if and__1927000168__auto____12 { tmp6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_89.Get__O()).Invoke_O__O(c__8) } else { tmp6 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____12).Ref() }; if jrt.A2g_Truth(tmp6) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(c__8)
				}



				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_234).Invoke_O__O(name__9)) { } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(c__8, name__9, desc__10)
					if jrt.A2g_Truth(temp__1927000414__auto____12) { var mm__13 any = temp__1927000414__auto____12; var tmp7 any; var or__1927000174__auto____14 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__13)
						if jrt.A2g_Truth(or__1927000174__auto____14) { tmp7 = or__1927000174__auto____14 } else { tmp7 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__13) }; if jrt.A2g_Truth(tmp7) { } else {
							lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(c__8, name__9, desc__10) } } } }
//line :462:1
			seq_214000333__3, chunk_214000334__4, count_214000335__5, i_214000336__6 = seq_214000333__3, chunk_214000334__4, count_214000335__5, lang.Numbers_Unchecked_inc_J__J(i_214000336__6); continue L3 } else { var temp__1927000414__auto____7_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000333__3); if jrt.A2g_Truth(temp__1927000414__auto____7_2) { var seq_214000333__8 any = temp__1927000414__auto____7_2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000333__8)) { var c__1927000678__auto____9_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000333__8); seq_214000333__3, chunk_214000334__4, count_214000335__5, i_214000336__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000333__8), c__1927000678__auto____9_2, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9_2))), int64(lang.RT_IntCast_J__I(0)); continue L3 } else { var vec__214000340__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000333__8); var c__10 any = lang.RT_Nth_O_I_O__O(vec__214000340__9, lang.RT_IntCast_J__I(0), nil); var name__11 any = lang.RT_Nth_O_I_O__O(vec__214000340__9, lang.RT_IntCast_J__I(1), nil); var desc__12 any = lang.RT_Nth_O_I_O__O(vec__214000340__9, lang.RT_IntCast_J__I(2), nil); var k__13 any = vec__214000340__9
				if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__10)) {
					lang.IFn_Cast(A_arbace_a2g_reach_A_const_102.GetRawRoot__O()).Invoke_O__O(k__13)

					var tmp8 any; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z(Lit_11, name__11); if and__1927000168__auto____14 { tmp8 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_89.Get__O()).Invoke_O__O(c__10) } else { tmp8 = jrt.Boolean_ValueOf_Z__Boolean(and__1927000168__auto____14).Ref() }; if jrt.A2g_Truth(tmp8) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(c__10)
					}



					if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_235).Invoke_O__O(name__11)) { } else { var temp__1927000414__auto____14 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_212.GetRawRoot__O()).Invoke_O_O_O__O(c__10, name__11, desc__12)
						if jrt.A2g_Truth(temp__1927000414__auto____14) { var mm__15 any = temp__1927000414__auto____14; var tmp9 any; var or__1927000174__auto____16 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_49.GetRawRoot__O()).Invoke_O__O(mm__15)
							if jrt.A2g_Truth(or__1927000174__auto____16) { tmp9 = or__1927000174__auto____16 } else { tmp9 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_50.GetRawRoot__O()).Invoke_O__O(mm__15) }; if jrt.A2g_Truth(tmp9) { } else {
								lang.IFn_Cast(A_arbace_a2g_reach_A_const_144.GetRawRoot__O()).Invoke_O_O_O__O(c__10, name__11, desc__12) } } } }
//line :462:1
				seq_214000333__3, chunk_214000334__4, count_214000335__5, i_214000336__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000333__8), nil, 0, 0; continue L3 } } }
//line :456:1
		break L3 }; var seq_214000343__3 any; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()); var tmp11 any; var t__3 any = t.F_instantiate


















	t.F_instantiate = nil; tmp11 = t__3; seq_214000343__3 = tmp10.Invoke_O__O(tmp11)
//line :456:1
	var chunk_214000344__4 any; var count_214000345__5 int64 = 0; var i_214000346__6 int64 = 0; L4: for {


















		if lang.Numbers_Lt_J_J__Z(i_214000346__6, count_214000345__5) { var c__7_2 any = lang.Indexed_Cast(chunk_214000344__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000346__6)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__7_2)) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(c__7_2) }; seq_214000343__3, chunk_214000344__4, count_214000345__5, i_214000346__6 = seq_214000343__3, chunk_214000344__4, count_214000345__5, lang.Numbers_Unchecked_inc_J__J(i_214000346__6); continue L4 } else { var temp__1927000414__auto____7_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000343__3); if jrt.A2g_Truth(temp__1927000414__auto____7_3) { var seq_214000343__8 any = temp__1927000414__auto____7_3; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000343__8)) { var c__1927000678__auto____9_3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000343__8); seq_214000343__3, chunk_214000344__4, count_214000345__5, i_214000346__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000343__8), c__1927000678__auto____9_3, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9_3))), int64(lang.RT_IntCast_J__I(0)); continue L4 } else { var c__9_2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000343__8); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(c__9_2)) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_165.GetRawRoot__O()).Invoke_O__O(c__9_2) }; seq_214000343__3, chunk_214000344__4, count_214000345__5, i_214000346__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000343__8), nil, 0, 0; continue L4 } } }
//line :456:1
		break L4 }; var seq_214000347__3 any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()); var tmp13 any; var t__4 any = t.F_fis




















	t.F_fis = nil; tmp13 = t__4; seq_214000347__3 = tmp12.Invoke_O__O(tmp13)
//line :456:1
	var chunk_214000348__4 any; var count_214000349__5 int64 = 0; var i_214000350__6 int64 = 0; L5: for {




















		if lang.Numbers_Lt_J_J__Z(i_214000350__6, count_214000349__5) { var fi__7 any = lang.Indexed_Cast(chunk_214000348__4).Nth_I__O(lang.RT_IntCast_J__I(i_214000350__6)); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(fi__7)) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_167.GetRawRoot__O()).Invoke_O__O(fi__7) }; seq_214000347__3, chunk_214000348__4, count_214000349__5, i_214000350__6 = seq_214000347__3, chunk_214000348__4, count_214000349__5, lang.Numbers_Unchecked_inc_J__J(i_214000350__6); continue L5 } else { var temp__1927000414__auto____7_4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_214000347__3); if jrt.A2g_Truth(temp__1927000414__auto____7_4) { var seq_214000347__8 any = temp__1927000414__auto____7_4; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(seq_214000347__8)) { var c__1927000678__auto____9_4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(seq_214000347__8); seq_214000347__3, chunk_214000348__4, count_214000349__5, i_214000350__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(seq_214000347__8), c__1927000678__auto____9_4, int64(lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927000678__auto____9_4))), int64(lang.RT_IntCast_J__I(0)); continue L5 } else { var fi__9 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(seq_214000347__8); if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_83.GetRawRoot__O()).Invoke_O__O(fi__9)) { lang.IFn_Cast(A_arbace_a2g_reach_A_const_167.GetRawRoot__O()).Invoke_O__O(fi__9) }; seq_214000347__3, chunk_214000348__4, count_214000349__5, i_214000350__6 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_28.GetRawRoot__O()).Invoke_O__O(seq_214000347__8), nil, 0, 0; continue L5 } } }
//line :456:1
		break L5 }; L6: for { var batch__3 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(A_arbace_a2g_reach_A_const_101.Invoke_O__O(t.F_st))


























			if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(batch__3)) {
				var tmp14 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_236.GetRawRoot__O()); var tmp15 any = A_arbace_a2g_reach_A_const_101.Invoke_O__O(t.F_st); var tmp16 *lang.PersistentVector; lang.PersistentVector_Init(); tmp16 = lang.PersistentVector_EMPTY; tmp14.Invoke_O_O__O(tmp15, tmp16.Ref())
//line :483:1
				var seen__4 any = jrt.IdentityHashMap_New(); var roots__5 any; var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_106.GetRawRoot__O()); var tmp18 any; var iter__1927001039__auto____5 any; var tmp19 any = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A_New_O(seen__4); var tmp20 *jrt.Class
				var fncls__50 /*line :483:1*/*jrt.Class = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A_fn_class


				if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_26, false); A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A_fn_class = fncls__50d; tmp20 = fncls__50d } else { tmp20 = fncls__50 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp19, tmp20, nil); tmp18 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(batch__3); roots__5 = tmp17.Invoke_O__O(tmp18)
//line :483:1
				var flats__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_237.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_239.GetRawRoot__O()).Invoke__O(), A_arbace_a2g_reach_A_const_240.GetRawRoot__O(), roots__5); var n__1927000701__auto____7 int64 = lang.RT_LongCast_I__J(lang.RT_Count_O__I(roots__5)); var i__8 int64 = 0; L7: for {









					if lang.Numbers_Lt_J_J__Z(i__8, n__1927000701__auto____7) {
						jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_a2g_reach_A_const_202.Get__O())).Put_O_O__O(lang.RT_Nth_O_I__O(roots__5, lang.RT_IntCast_J__I(i__8)), lang.RT_Nth_O_I__O(flats__6, lang.RT_IntCast_J__I(i__8)))
//line :493:1
						i__8 = lang.Numbers_Unchecked_inc_J__J(i__8); continue L7 }
//line :483:1
					break L7
				}










				lang.IFn_Cast(A_arbace_a2g_reach_A_const_203.GetRawRoot__O()).Invoke_O_O__O(A_arbace_a2g_reach_A_const_241.GetRawRoot__O(), batch__3)
				continue L6 } else {
//line :483:1
					tmp1 = nil }
//line :456:1
			break L6 } }; return nil }(); lang.IFn_Cast(A_arbace_a2g_reach_A_const_84.GetRawRoot__O()).Invoke__O(); if tmp21 != nil { panic(tmp21) }; return tmp1 }; panic("a2g: unreachable") }





























func A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A_New_O(p0 any) *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A{}; t.Ctor_O(p0); return t }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A) Invoke_O_O__O(self, s__214000352__1 any) any { var tmp1 any = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A_New_O_O_O(s__214000352__1, t.F_seen, self); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_27, false); A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A) Ctor_O_O_O(c__s__214000352, c__seen, c__iter__214000351 any) { t.F_s__214000352 = c__s__214000352; t.F_seen = c__seen; t.F_iter__214000351 = c__iter__214000351 }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A) Invoke_O__O(self any) any { { var s__214000352__1 any; var t_ any = t.F_s__214000352; t.F_s__214000352 = nil; s__214000352__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000352__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var k__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A_New_O(t.F_seen); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_28, false); A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp5 any
															if lang.Util_Equiv_O_O__Z(Lit_16, lang.IFn_Cast(A_arbace_a2g_reach_A_const_238.GetRawRoot__O()).Invoke_O__O(k__4)) {
																var tmp6 *lang.Keyword = A_arbace_a2g_reach_A_const_206; var tmp7 *lang.Keyword = A_arbace_a2g_reach_A_const_90; tmp5 = tmp6.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_13.GetRawRoot__O()).Invoke_O__O(tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_81.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(k__4))))) } else {
																	tmp5 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_228.GetRawRoot__O()).Invoke_O__O(k__4) }
//line :486:1
	fs__1927001036__auto____6 = tmp3.Invoke_O__O(tmp4.Invoke_O__O(tmp5)); if jrt.A2g_Truth(fs__1927001036__auto____6) { var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__214000351); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_105.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000352__1))) } else { s__214000352__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000352__1); continue L1 } } else { return nil } } }; panic("a2g: unreachable") }
//line :486:1
func A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A_New_O(p0 any) *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A{}; t.Ctor_O(p0); return t }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A) Ctor_O(c__seen any) { t.F_seen = c__seen }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A) Invoke_O_O__O(self, s__214000354__1 any) any { var tmp1 any = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A_New_O_O_O(s__214000354__1, t.F_seen, self); var tmp2 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A_fn_class; if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_29, false); A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A_fn_class = fncls__47d; tmp2 = fncls__47d } else { tmp2 = fncls__47 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A_New_O_O_O(p0, p1, p2 any) *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A) Ctor_O_O_O(c__s__214000354, c__seen, c__iter__214000353 any) { t.F_s__214000354 = c__s__214000354; t.F_seen = c__seen; t.F_iter__214000353 = c__iter__214000353 }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A) Invoke_O__O(self any) any { { var s__214000354__1 any; var t_ any = t.F_s__214000354; t.F_s__214000354 = nil; s__214000354__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_20.GetRawRoot__O()).Invoke_O__O(s__214000354__1); if jrt.A2g_Truth(temp__1927000414__auto____2) { var s__214000354__3 any = temp__1927000414__auto____2; if jrt.A2g_Truth(lang.IFn_Cast(A_arbace_a2g_reach_A_const_22.GetRawRoot__O()).Invoke_O__O(s__214000354__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_23.GetRawRoot__O()).Invoke_O__O(s__214000354__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I(lang.RT_Count_O__I(c__1927001037__auto____4)); var b__214000356__6 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_44.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A_New_O_O_I_O(b__214000356__6, t.F_seen, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A_fn_class; if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class(Lit_30, false); A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A_fn_class = fncls__46d; tmp2 = fncls__46d } else { tmp2 = fncls__46 }; if jrt.A2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__214000353); return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000356__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_26.GetRawRoot__O()).Invoke_O__O(s__214000354__3))) } else { return lang.IFn_Cast(A_arbace_a2g_reach_A_const_52.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_54.GetRawRoot__O()).Invoke_O__O(b__214000356__6), nil) } } else { var nd__4 any = lang.IFn_Cast(A_arbace_a2g_reach_A_const_24.GetRawRoot__O()).Invoke_O__O(s__214000354__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()); var tmp5 *jrt.Boolean; var or__1927000174__auto____5 bool = jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_a2g_reach_A_const_202.Get__O())).ContainsKey_O__Z(nd__4)



	if or__1927000174__auto____5 { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____5) } else { tmp5 = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).ContainsKey_O__Z(nd__4)) }
//line :486:1
	if jrt.A2g_Truth(tmp4.Invoke_O__O(tmp5.Ref())) { var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_53.GetRawRoot__O()); var tmp7 any; var tmp8 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(t.F_seen); var tmp9 *jrt.Boolean




		jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; jrt.NN(tmp8).Put_O_O__O(nd__4, tmp9.Ref())
//line :486:1
		tmp7 = nd__4; var tmp10 lang.IFn = lang.IFn_Cast(t.F_iter__214000353); return tmp6.Invoke_O_O__O(tmp7, tmp10.Invoke_O__O(lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000354__3))) } else { s__214000354__1 = lang.IFn_Cast(A_arbace_a2g_reach_A_const_55.GetRawRoot__O()).Invoke_O__O(s__214000354__3); continue L1 } } } else { return nil } } }; panic("a2g: unreachable") }
//line :486:1
func A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A) Ctor_O_O_I_O(c__b__214000356, c__seen any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__214000356 = c__b__214000356; t.F_seen = c__seen; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :486:1
func (t *A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A) Invoke_O__O(self any) any { { var i__214000355__1 int64 = lang.RT_LongCast_I__J(lang.RT_IntCast_J__I(0)); L1: for { if lang.Numbers_Lt_J_J__Z(i__214000355__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var nd__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I(i__214000355__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_21.GetRawRoot__O()); var tmp3 *jrt.Boolean; var or__1927000174__auto____3 bool = jrt.NN(jrt.IdentityHashMap_Cast(A_arbace_a2g_reach_A_const_202.Get__O())).ContainsKey_O__Z(nd__2)



	if or__1927000174__auto____3 { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(or__1927000174__auto____3) } else { tmp3 = jrt.Boolean_ValueOf_Z__Boolean(jrt.NN(jrt.IdentityHashMap_Cast(t.F_seen)).ContainsKey_O__Z(nd__2)) }
//line :486:1
	if jrt.A2g_Truth(tmp2.Invoke_O__O(tmp3.Ref())) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_a2g_reach_A_const_51.GetRawRoot__O()); var tmp5 any = t.F_b__214000356; var tmp6 any; var tmp7 *jrt.IdentityHashMap = jrt.IdentityHashMap_Cast(t.F_seen); var tmp8 *jrt.Boolean




		jrt.Boolean_Init(); tmp8 = jrt.Boolean_TRUE; jrt.NN(tmp7).Put_O_O__O(nd__2, tmp8.Ref())
//line :486:1
		tmp6 = nd__2; tmp4.Invoke_O_O__O(tmp5, tmp6); i__214000355__1 = lang.Numbers_Unchecked_inc_J__J(i__214000355__1); continue L1 } else { i__214000355__1 = lang.Numbers_Unchecked_inc_J__J(i__214000355__1); continue L1 } } else { jrt.Boolean_Init(); return jrt.Boolean_TRUE.Ref() } } }; panic("a2g: unreachable") }































type A_arbace_a2g_reach_A struct{ jrt.Object }

var A_arbace_a2g_reach_A_const_pool *jrt.RefArray

var A_arbace_a2g_reach_A_const_0 *lang.Var

var A_arbace_a2g_reach_A_const_1 *lang.Var

var A_arbace_a2g_reach_A_const_2 any

var A_arbace_a2g_reach_A_const_3 any

var A_arbace_a2g_reach_A_const_4 any

var A_arbace_a2g_reach_A_const_5 any

var A_arbace_a2g_reach_A_const_6 any

var A_arbace_a2g_reach_A_const_7 any

var A_arbace_a2g_reach_A_const_8 any

var A_arbace_a2g_reach_A_const_9 any

var A_arbace_a2g_reach_A_const_10 any

var A_arbace_a2g_reach_A_const_11 any

var A_arbace_a2g_reach_A_const_12 *lang.Var

var A_arbace_a2g_reach_A_const_13 *lang.Var

var A_arbace_a2g_reach_A_const_14 *lang.Var

var A_arbace_a2g_reach_A_const_15 any

var A_arbace_a2g_reach_A_const_16 *lang.Var

var A_arbace_a2g_reach_A_const_17 *lang.Var

var A_arbace_a2g_reach_A_const_18 *lang.Var

var A_arbace_a2g_reach_A_const_19 *lang.Keyword

var A_arbace_a2g_reach_A_const_20 *lang.Var

var A_arbace_a2g_reach_A_const_21 *lang.Var

var A_arbace_a2g_reach_A_const_22 *lang.Var

var A_arbace_a2g_reach_A_const_23 *lang.Var

var A_arbace_a2g_reach_A_const_24 *lang.Var

var A_arbace_a2g_reach_A_const_25 any

var A_arbace_a2g_reach_A_const_26 *lang.Var

var A_arbace_a2g_reach_A_const_27 any

var A_arbace_a2g_reach_A_const_28 *lang.Var

var A_arbace_a2g_reach_A_const_29 *lang.Var

var A_arbace_a2g_reach_A_const_30 *lang.Var

var A_arbace_a2g_reach_A_const_31 *lang.Keyword

var A_arbace_a2g_reach_A_const_32 any

var A_arbace_a2g_reach_A_const_33 any

var A_arbace_a2g_reach_A_const_34 any

var A_arbace_a2g_reach_A_const_35 any

var A_arbace_a2g_reach_A_const_36 *lang.Var

var A_arbace_a2g_reach_A_const_37 *lang.Var

var A_arbace_a2g_reach_A_const_38 *lang.Var

var A_arbace_a2g_reach_A_const_39 *lang.Var

var A_arbace_a2g_reach_A_const_40 *lang.Keyword

var A_arbace_a2g_reach_A_const_41 *lang.Keyword

var A_arbace_a2g_reach_A_const_42 *lang.Keyword

var A_arbace_a2g_reach_A_const_43 *lang.Var

var A_arbace_a2g_reach_A_const_44 *lang.Var

var A_arbace_a2g_reach_A_const_45 *lang.Var

var A_arbace_a2g_reach_A_const_46 *lang.Var

var A_arbace_a2g_reach_A_const_47 *lang.Var

var A_arbace_a2g_reach_A_const_48 *lang.Var

var A_arbace_a2g_reach_A_const_49 *lang.Var

var A_arbace_a2g_reach_A_const_50 *lang.Var

var A_arbace_a2g_reach_A_const_51 *lang.Var

var A_arbace_a2g_reach_A_const_52 *lang.Var

var A_arbace_a2g_reach_A_const_53 *lang.Var

var A_arbace_a2g_reach_A_const_54 *lang.Var

var A_arbace_a2g_reach_A_const_55 *lang.Var

var A_arbace_a2g_reach_A_const_56 *lang.Var

var A_arbace_a2g_reach_A_const_57 *lang.Var

var A_arbace_a2g_reach_A_const_58 *lang.Var

var A_arbace_a2g_reach_A_const_59 *lang.Var

var A_arbace_a2g_reach_A_const_60 *lang.Keyword

var A_arbace_a2g_reach_A_const_61 *lang.Var

var A_arbace_a2g_reach_A_const_62 *lang.Var

var A_arbace_a2g_reach_A_const_63 *lang.Var

var A_arbace_a2g_reach_A_const_64 *lang.Var

var A_arbace_a2g_reach_A_const_65 *lang.Keyword

var A_arbace_a2g_reach_A_const_66 *lang.Var

var A_arbace_a2g_reach_A_const_67 *lang.Var

var A_arbace_a2g_reach_A_const_68 *lang.Var

var A_arbace_a2g_reach_A_const_69 *lang.Var

var A_arbace_a2g_reach_A_const_70 *lang.Var

var A_arbace_a2g_reach_A_const_71 *lang.Keyword

var A_arbace_a2g_reach_A_const_72 *lang.Var

var A_arbace_a2g_reach_A_const_73 *lang.Var

var A_arbace_a2g_reach_A_const_74 *lang.Keyword

var A_arbace_a2g_reach_A_const_75 *lang.Keyword

var A_arbace_a2g_reach_A_const_76 *lang.Var

var A_arbace_a2g_reach_A_const_77 *lang.Keyword

var A_arbace_a2g_reach_A_const_78 *lang.Var

var A_arbace_a2g_reach_A_const_79 *lang.Var

var A_arbace_a2g_reach_A_const_80 *lang.Var

var A_arbace_a2g_reach_A_const_81 *lang.Var

var A_arbace_a2g_reach_A_const_82 *lang.Keyword

var A_arbace_a2g_reach_A_const_83 *lang.Var

var A_arbace_a2g_reach_A_const_84 *lang.Var

var A_arbace_a2g_reach_A_const_85 *lang.Var

var A_arbace_a2g_reach_A_const_86 *lang.Keyword

var A_arbace_a2g_reach_A_const_87 *lang.Var

var A_arbace_a2g_reach_A_const_88 *lang.Keyword

var A_arbace_a2g_reach_A_const_89 *lang.Var

var A_arbace_a2g_reach_A_const_90 *lang.Keyword

var A_arbace_a2g_reach_A_const_91 *lang.Keyword

var A_arbace_a2g_reach_A_const_92 *lang.Var

var A_arbace_a2g_reach_A_const_93 *lang.Var

var A_arbace_a2g_reach_A_const_94 *lang.Var

var A_arbace_a2g_reach_A_const_95 *lang.Keyword

var A_arbace_a2g_reach_A_const_96 *lang.Keyword

var A_arbace_a2g_reach_A_const_97 *lang.Keyword

var A_arbace_a2g_reach_A_const_98 *lang.Var

var A_arbace_a2g_reach_A_const_99 *lang.Var

var A_arbace_a2g_reach_A_const_100 *lang.Keyword

var A_arbace_a2g_reach_A_const_101 *lang.Keyword

var A_arbace_a2g_reach_A_const_102 *lang.Var

var A_arbace_a2g_reach_A_const_103 *lang.Keyword

var A_arbace_a2g_reach_A_const_104 *lang.Var

var A_arbace_a2g_reach_A_const_105 *lang.Var

var A_arbace_a2g_reach_A_const_106 *lang.Var

var A_arbace_a2g_reach_A_const_107 *lang.Keyword

var A_arbace_a2g_reach_A_const_108 *lang.Var

var A_arbace_a2g_reach_A_const_109 *lang.Keyword

var A_arbace_a2g_reach_A_const_110 *lang.Keyword

var A_arbace_a2g_reach_A_const_111 *lang.Var

var A_arbace_a2g_reach_A_const_112 *lang.Var

var A_arbace_a2g_reach_A_const_113 *lang.Var

var A_arbace_a2g_reach_A_const_114 *lang.Var

var A_arbace_a2g_reach_A_const_115 *lang.Keyword

var A_arbace_a2g_reach_A_const_116 *lang.Var

var A_arbace_a2g_reach_A_const_117 *lang.Keyword

var A_arbace_a2g_reach_A_const_118 *lang.Var

var A_arbace_a2g_reach_A_const_119 *lang.Keyword

var A_arbace_a2g_reach_A_const_120 *lang.Var

var A_arbace_a2g_reach_A_const_121 *lang.Var

var A_arbace_a2g_reach_A_const_122 *lang.Var

var A_arbace_a2g_reach_A_const_123 *lang.Keyword

var A_arbace_a2g_reach_A_const_124 *lang.Keyword

var A_arbace_a2g_reach_A_const_125 *lang.Keyword

var A_arbace_a2g_reach_A_const_126 *lang.Keyword

var A_arbace_a2g_reach_A_const_127 *lang.Var

var A_arbace_a2g_reach_A_const_128 *lang.Keyword

var A_arbace_a2g_reach_A_const_129 any

var A_arbace_a2g_reach_A_const_130 *lang.Var

var A_arbace_a2g_reach_A_const_131 *lang.Keyword

var A_arbace_a2g_reach_A_const_132 *lang.Var

var A_arbace_a2g_reach_A_const_133 *lang.Keyword

var A_arbace_a2g_reach_A_const_134 *lang.Keyword

var A_arbace_a2g_reach_A_const_135 *lang.Keyword

var A_arbace_a2g_reach_A_const_136 *lang.Keyword

var A_arbace_a2g_reach_A_const_137 *lang.Var

var A_arbace_a2g_reach_A_const_138 *lang.Keyword

var A_arbace_a2g_reach_A_const_139 *lang.Keyword

var A_arbace_a2g_reach_A_const_140 *lang.Keyword

var A_arbace_a2g_reach_A_const_141 *lang.Keyword

var A_arbace_a2g_reach_A_const_142 *lang.Keyword

var A_arbace_a2g_reach_A_const_143 *lang.Keyword

var A_arbace_a2g_reach_A_const_144 *lang.Var

var A_arbace_a2g_reach_A_const_145 *lang.Keyword

var A_arbace_a2g_reach_A_const_146 *lang.Keyword

var A_arbace_a2g_reach_A_const_147 *lang.Keyword

var A_arbace_a2g_reach_A_const_148 *lang.Keyword

var A_arbace_a2g_reach_A_const_149 *lang.Keyword

var A_arbace_a2g_reach_A_const_150 *lang.Var

var A_arbace_a2g_reach_A_const_151 *lang.Var

var A_arbace_a2g_reach_A_const_152 *lang.Keyword

var A_arbace_a2g_reach_A_const_153 *lang.Keyword

var A_arbace_a2g_reach_A_const_154 *lang.Keyword

var A_arbace_a2g_reach_A_const_155 *lang.Keyword

var A_arbace_a2g_reach_A_const_156 *lang.Keyword

var A_arbace_a2g_reach_A_const_157 *lang.Var

var A_arbace_a2g_reach_A_const_158 *lang.Var

var A_arbace_a2g_reach_A_const_159 *lang.Keyword

var A_arbace_a2g_reach_A_const_160 *lang.Keyword

var A_arbace_a2g_reach_A_const_161 *lang.Keyword

var A_arbace_a2g_reach_A_const_162 *lang.Keyword

var A_arbace_a2g_reach_A_const_163 *lang.Keyword

var A_arbace_a2g_reach_A_const_164 *lang.Keyword

var A_arbace_a2g_reach_A_const_165 *lang.Var

var A_arbace_a2g_reach_A_const_166 *lang.Keyword

var A_arbace_a2g_reach_A_const_167 *lang.Var

var A_arbace_a2g_reach_A_const_168 *lang.Keyword

var A_arbace_a2g_reach_A_const_169 *lang.Keyword

var A_arbace_a2g_reach_A_const_170 *lang.Var

var A_arbace_a2g_reach_A_const_171 *lang.Keyword

var A_arbace_a2g_reach_A_const_172 *lang.Keyword

var A_arbace_a2g_reach_A_const_173 *lang.Keyword

var A_arbace_a2g_reach_A_const_174 *lang.Keyword

var A_arbace_a2g_reach_A_const_175 *lang.Keyword

var A_arbace_a2g_reach_A_const_176 *lang.Keyword

var A_arbace_a2g_reach_A_const_177 *lang.Keyword

var A_arbace_a2g_reach_A_const_178 *lang.Var

var A_arbace_a2g_reach_A_const_179 *lang.Keyword

var A_arbace_a2g_reach_A_const_180 *lang.Var

var A_arbace_a2g_reach_A_const_181 *lang.Var

var A_arbace_a2g_reach_A_const_182 *lang.Keyword

var A_arbace_a2g_reach_A_const_183 *lang.Var

var A_arbace_a2g_reach_A_const_184 *lang.Keyword

var A_arbace_a2g_reach_A_const_185 *lang.Keyword

var A_arbace_a2g_reach_A_const_186 *lang.Keyword

var A_arbace_a2g_reach_A_const_187 *lang.Keyword

var A_arbace_a2g_reach_A_const_188 *lang.Keyword

var A_arbace_a2g_reach_A_const_189 *lang.Keyword

var A_arbace_a2g_reach_A_const_190 *lang.Var

var A_arbace_a2g_reach_A_const_191 *lang.Keyword

var A_arbace_a2g_reach_A_const_192 *lang.Var

var A_arbace_a2g_reach_A_const_193 *lang.Keyword

var A_arbace_a2g_reach_A_const_194 *lang.Keyword

var A_arbace_a2g_reach_A_const_195 *lang.Var

var A_arbace_a2g_reach_A_const_196 *lang.Var

var A_arbace_a2g_reach_A_const_197 *lang.Keyword

var A_arbace_a2g_reach_A_const_198 *lang.Keyword

var A_arbace_a2g_reach_A_const_199 *lang.Keyword

var A_arbace_a2g_reach_A_const_200 *lang.Keyword

var A_arbace_a2g_reach_A_const_201 *lang.Var

var A_arbace_a2g_reach_A_const_202 *lang.Var

var A_arbace_a2g_reach_A_const_203 *lang.Var

var A_arbace_a2g_reach_A_const_204 *lang.Var

var A_arbace_a2g_reach_A_const_205 *lang.Keyword

var A_arbace_a2g_reach_A_const_206 *lang.Keyword

var A_arbace_a2g_reach_A_const_207 *lang.Keyword

var A_arbace_a2g_reach_A_const_208 *lang.Keyword

var A_arbace_a2g_reach_A_const_209 *lang.Keyword

var A_arbace_a2g_reach_A_const_210 *lang.Keyword

var A_arbace_a2g_reach_A_const_211 *lang.Keyword

var A_arbace_a2g_reach_A_const_212 *lang.Var

var A_arbace_a2g_reach_A_const_213 *lang.Keyword

var A_arbace_a2g_reach_A_const_214 *lang.Keyword

var A_arbace_a2g_reach_A_const_215 *lang.Keyword

var A_arbace_a2g_reach_A_const_216 *lang.Keyword

var A_arbace_a2g_reach_A_const_217 *lang.Keyword

var A_arbace_a2g_reach_A_const_218 *lang.Keyword

var A_arbace_a2g_reach_A_const_219 *lang.Keyword

var A_arbace_a2g_reach_A_const_220 *lang.Keyword

var A_arbace_a2g_reach_A_const_221 *lang.Var

var A_arbace_a2g_reach_A_const_222 *lang.Keyword

var A_arbace_a2g_reach_A_const_223 *lang.Keyword

var A_arbace_a2g_reach_A_const_224 *lang.Keyword

var A_arbace_a2g_reach_A_const_225 *lang.Var

var A_arbace_a2g_reach_A_const_226 *lang.Keyword

var A_arbace_a2g_reach_A_const_227 *lang.Keyword

var A_arbace_a2g_reach_A_const_228 *lang.Var

var A_arbace_a2g_reach_A_const_229 *lang.Keyword

var A_arbace_a2g_reach_A_const_230 *lang.Keyword

var A_arbace_a2g_reach_A_const_231 *lang.Keyword

var A_arbace_a2g_reach_A_const_232 *lang.Keyword

var A_arbace_a2g_reach_A_const_233 *lang.Var

var A_arbace_a2g_reach_A_const_234 any

var A_arbace_a2g_reach_A_const_235 any

var A_arbace_a2g_reach_A_const_236 *lang.Var

var A_arbace_a2g_reach_A_const_237 *lang.Var

var A_arbace_a2g_reach_A_const_238 *lang.Var

var A_arbace_a2g_reach_A_const_239 *lang.Var

var A_arbace_a2g_reach_A_const_240 *lang.Var

var A_arbace_a2g_reach_A_const_241 *lang.Var

var A_arbace_a2g_reach_A_const_242 *lang.Var

var A_arbace_a2g_reach_A_init jrt.ClassInit

func A_arbace_a2g_reach_A_Init() { if !A_arbace_a2g_reach_A_init.Done() { A_arbace_a2g_reach_A_init.Run(A_arbace_a2g_reach_A_clinit) } }

func A_arbace_a2g_reach_A_clinit() { A_arbace_a2g_reach_A_clinit_p0(); A_arbace_a2g_reach_A_clinit_p1(); A_arbace_a2g_reach_A_clinit_p2(); A_arbace_a2g_reach_A_clinit_p3(); A_arbace_a2g_reach_A_clinit_p4(); A_arbace_a2g_reach_A_clinit_p5(); A_arbace_a2g_reach_A_clinit_p6(); A_arbace_a2g_reach_A_clinit_p7(); A_arbace_a2g_reach_A_clinit_p8(); A_arbace_a2g_reach_A_clinit_p9(); A_arbace_a2g_reach_A_clinit_p10(); A_arbace_a2g_reach_A_clinit_p11(); A_arbace_a2g_reach_A_clinit_p12(); A_arbace_a2g_reach_A_clinit_p13(); A_arbace_a2g_reach_A_clinit_p14(); A_arbace_a2g_reach_A_clinit_p15(); A_arbace_a2g_reach_A_clinit_p16(); A_arbace_a2g_reach_A_clinit_p17(); A_arbace_a2g_reach_A_clinit_p18(); A_arbace_a2g_reach_A_clinit_p19() }

func A_arbace_a2g_reach_A_clinit_p0() { A_arbace_a2g_reach_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1(Lit_0, 382); A_arbace_a2g_reach_A_const_0 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[139]); A_arbace_a2g_reach_A_const_1 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[140]); A_arbace_a2g_reach_A_const_2 = A_arbace_a2g_reach_A_const_pool.A[141]; A_arbace_a2g_reach_A_const_3 = A_arbace_a2g_reach_A_const_pool.A[142]; A_arbace_a2g_reach_A_const_4 = A_arbace_a2g_reach_A_const_pool.A[143]; A_arbace_a2g_reach_A_const_5 = A_arbace_a2g_reach_A_const_pool.A[144]; A_arbace_a2g_reach_A_const_6 = A_arbace_a2g_reach_A_const_pool.A[145]; A_arbace_a2g_reach_A_const_7 = A_arbace_a2g_reach_A_const_pool.A[146]; A_arbace_a2g_reach_A_const_8 = A_arbace_a2g_reach_A_const_pool.A[147]; A_arbace_a2g_reach_A_const_9 = A_arbace_a2g_reach_A_const_pool.A[148]; A_arbace_a2g_reach_A_const_10 = A_arbace_a2g_reach_A_const_pool.A[149]; A_arbace_a2g_reach_A_const_11 = A_arbace_a2g_reach_A_const_pool.A[150]; A_arbace_a2g_reach_A_const_12 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[151]); A_arbace_a2g_reach_A_const_13 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[152]) }

func A_arbace_a2g_reach_A_clinit_p1() { A_arbace_a2g_reach_A_const_14 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[153]); A_arbace_a2g_reach_A_const_15 = A_arbace_a2g_reach_A_const_pool.A[154]; A_arbace_a2g_reach_A_const_16 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[155]); A_arbace_a2g_reach_A_const_17 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[156]); A_arbace_a2g_reach_A_const_18 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[157]); A_arbace_a2g_reach_A_const_19 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[158]); A_arbace_a2g_reach_A_const_20 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[159]); A_arbace_a2g_reach_A_const_21 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[160]); A_arbace_a2g_reach_A_const_22 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[161]); A_arbace_a2g_reach_A_const_23 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[162]); A_arbace_a2g_reach_A_const_24 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[163]); A_arbace_a2g_reach_A_const_25 = A_arbace_a2g_reach_A_const_pool.A[164] }

func A_arbace_a2g_reach_A_clinit_p2() { A_arbace_a2g_reach_A_const_26 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[165]); A_arbace_a2g_reach_A_const_27 = A_arbace_a2g_reach_A_const_pool.A[166]; A_arbace_a2g_reach_A_const_28 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[167]); A_arbace_a2g_reach_A_const_29 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[168]); A_arbace_a2g_reach_A_const_30 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[169]); A_arbace_a2g_reach_A_const_31 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[170]); A_arbace_a2g_reach_A_const_32 = A_arbace_a2g_reach_A_const_pool.A[171]; A_arbace_a2g_reach_A_const_33 = A_arbace_a2g_reach_A_const_pool.A[172]; A_arbace_a2g_reach_A_const_34 = A_arbace_a2g_reach_A_const_pool.A[173]; A_arbace_a2g_reach_A_const_35 = A_arbace_a2g_reach_A_const_pool.A[174]; A_arbace_a2g_reach_A_const_36 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[175]); A_arbace_a2g_reach_A_const_37 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[176]); A_arbace_a2g_reach_A_const_38 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[177]) }

func A_arbace_a2g_reach_A_clinit_p3() { A_arbace_a2g_reach_A_const_39 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[178]); A_arbace_a2g_reach_A_const_40 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[179]); A_arbace_a2g_reach_A_const_41 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[180]); A_arbace_a2g_reach_A_const_42 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[181]); A_arbace_a2g_reach_A_const_43 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[182]); A_arbace_a2g_reach_A_const_44 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[183]); A_arbace_a2g_reach_A_const_45 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[184]); A_arbace_a2g_reach_A_const_46 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[185]); A_arbace_a2g_reach_A_const_47 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[186]); A_arbace_a2g_reach_A_const_48 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[187]); A_arbace_a2g_reach_A_const_49 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[188]); A_arbace_a2g_reach_A_const_50 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[189]) }

func A_arbace_a2g_reach_A_clinit_p4() { A_arbace_a2g_reach_A_const_51 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[190]); A_arbace_a2g_reach_A_const_52 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[191]); A_arbace_a2g_reach_A_const_53 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[192]); A_arbace_a2g_reach_A_const_54 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[193]); A_arbace_a2g_reach_A_const_55 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[194]); A_arbace_a2g_reach_A_const_56 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[195]); A_arbace_a2g_reach_A_const_57 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[196]); A_arbace_a2g_reach_A_const_58 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[197]); A_arbace_a2g_reach_A_const_59 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[198]); A_arbace_a2g_reach_A_const_60 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[199]); A_arbace_a2g_reach_A_const_61 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[200]); A_arbace_a2g_reach_A_const_62 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[201]) }

func A_arbace_a2g_reach_A_clinit_p5() { A_arbace_a2g_reach_A_const_63 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[202]); A_arbace_a2g_reach_A_const_64 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[203]); A_arbace_a2g_reach_A_const_65 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[204]); A_arbace_a2g_reach_A_const_66 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[205]); A_arbace_a2g_reach_A_const_67 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[206]); A_arbace_a2g_reach_A_const_68 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[207]); A_arbace_a2g_reach_A_const_69 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[208]); A_arbace_a2g_reach_A_const_70 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[209]); A_arbace_a2g_reach_A_const_71 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[210]); A_arbace_a2g_reach_A_const_72 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[211]); A_arbace_a2g_reach_A_const_73 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[212]); A_arbace_a2g_reach_A_const_74 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[213]) }

func A_arbace_a2g_reach_A_clinit_p6() { A_arbace_a2g_reach_A_const_75 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[214]); A_arbace_a2g_reach_A_const_76 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[215]); A_arbace_a2g_reach_A_const_77 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[216]); A_arbace_a2g_reach_A_const_78 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[217]); A_arbace_a2g_reach_A_const_79 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[218]); A_arbace_a2g_reach_A_const_80 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[219]); A_arbace_a2g_reach_A_const_81 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[220]); A_arbace_a2g_reach_A_const_82 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[221]); A_arbace_a2g_reach_A_const_83 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[222]); A_arbace_a2g_reach_A_const_84 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[223]); A_arbace_a2g_reach_A_const_85 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[224]); A_arbace_a2g_reach_A_const_86 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[225]) }

func A_arbace_a2g_reach_A_clinit_p7() { A_arbace_a2g_reach_A_const_87 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[226]); A_arbace_a2g_reach_A_const_88 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[227]); A_arbace_a2g_reach_A_const_89 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[228]); A_arbace_a2g_reach_A_const_90 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[229]); A_arbace_a2g_reach_A_const_91 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[230]); A_arbace_a2g_reach_A_const_92 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[231]); A_arbace_a2g_reach_A_const_93 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[232]); A_arbace_a2g_reach_A_const_94 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[233]); A_arbace_a2g_reach_A_const_95 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[234]); A_arbace_a2g_reach_A_const_96 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[235]); A_arbace_a2g_reach_A_const_97 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[236]); A_arbace_a2g_reach_A_const_98 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[237]) }

func A_arbace_a2g_reach_A_clinit_p8() { A_arbace_a2g_reach_A_const_99 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[238]); A_arbace_a2g_reach_A_const_100 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[239]); A_arbace_a2g_reach_A_const_101 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[240]); A_arbace_a2g_reach_A_const_102 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[241]); A_arbace_a2g_reach_A_const_103 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[242]); A_arbace_a2g_reach_A_const_104 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[243]); A_arbace_a2g_reach_A_const_105 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[244]); A_arbace_a2g_reach_A_const_106 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[245]); A_arbace_a2g_reach_A_const_107 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[246]); A_arbace_a2g_reach_A_const_108 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[247]); A_arbace_a2g_reach_A_const_109 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[248]); A_arbace_a2g_reach_A_const_110 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[249]) }

func A_arbace_a2g_reach_A_clinit_p9() { A_arbace_a2g_reach_A_const_111 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[250]); A_arbace_a2g_reach_A_const_112 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[251]); A_arbace_a2g_reach_A_const_113 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[252]); A_arbace_a2g_reach_A_const_114 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[253]); A_arbace_a2g_reach_A_const_115 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[254]); A_arbace_a2g_reach_A_const_116 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[255]); A_arbace_a2g_reach_A_const_117 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[256]); A_arbace_a2g_reach_A_const_118 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[257]); A_arbace_a2g_reach_A_const_119 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[258]); A_arbace_a2g_reach_A_const_120 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[259]); A_arbace_a2g_reach_A_const_121 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[260]); A_arbace_a2g_reach_A_const_122 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[261]) }

func A_arbace_a2g_reach_A_clinit_p10() { A_arbace_a2g_reach_A_const_123 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[262]); A_arbace_a2g_reach_A_const_124 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[263]); A_arbace_a2g_reach_A_const_125 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[264]); A_arbace_a2g_reach_A_const_126 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[265]); A_arbace_a2g_reach_A_const_127 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[266]); A_arbace_a2g_reach_A_const_128 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[267]); A_arbace_a2g_reach_A_const_129 = A_arbace_a2g_reach_A_const_pool.A[268]; A_arbace_a2g_reach_A_const_130 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[269]); A_arbace_a2g_reach_A_const_131 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[270]); A_arbace_a2g_reach_A_const_132 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[271]); A_arbace_a2g_reach_A_const_133 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[272]); A_arbace_a2g_reach_A_const_134 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[273]) }

func A_arbace_a2g_reach_A_clinit_p11() { A_arbace_a2g_reach_A_const_135 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[274]); A_arbace_a2g_reach_A_const_136 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[275]); A_arbace_a2g_reach_A_const_137 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[276]); A_arbace_a2g_reach_A_const_138 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[277]); A_arbace_a2g_reach_A_const_139 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[278]); A_arbace_a2g_reach_A_const_140 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[279]); A_arbace_a2g_reach_A_const_141 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[280]); A_arbace_a2g_reach_A_const_142 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[281]); A_arbace_a2g_reach_A_const_143 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[282]); A_arbace_a2g_reach_A_const_144 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[283]); A_arbace_a2g_reach_A_const_145 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[284]); A_arbace_a2g_reach_A_const_146 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[285]) }

func A_arbace_a2g_reach_A_clinit_p12() { A_arbace_a2g_reach_A_const_147 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[286]); A_arbace_a2g_reach_A_const_148 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[287]); A_arbace_a2g_reach_A_const_149 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[288]); A_arbace_a2g_reach_A_const_150 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[289]); A_arbace_a2g_reach_A_const_151 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[290]); A_arbace_a2g_reach_A_const_152 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[291]); A_arbace_a2g_reach_A_const_153 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[292]); A_arbace_a2g_reach_A_const_154 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[293]); A_arbace_a2g_reach_A_const_155 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[294]); A_arbace_a2g_reach_A_const_156 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[295]); A_arbace_a2g_reach_A_const_157 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[296]); A_arbace_a2g_reach_A_const_158 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[297]) }

func A_arbace_a2g_reach_A_clinit_p13() { A_arbace_a2g_reach_A_const_159 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[298]); A_arbace_a2g_reach_A_const_160 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[299]); A_arbace_a2g_reach_A_const_161 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[300]); A_arbace_a2g_reach_A_const_162 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[301]); A_arbace_a2g_reach_A_const_163 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[302]); A_arbace_a2g_reach_A_const_164 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[303]); A_arbace_a2g_reach_A_const_165 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[304]); A_arbace_a2g_reach_A_const_166 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[305]); A_arbace_a2g_reach_A_const_167 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[306]); A_arbace_a2g_reach_A_const_168 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[307]); A_arbace_a2g_reach_A_const_169 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[308]); A_arbace_a2g_reach_A_const_170 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[309]) }

func A_arbace_a2g_reach_A_clinit_p14() { A_arbace_a2g_reach_A_const_171 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[310]); A_arbace_a2g_reach_A_const_172 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[311]); A_arbace_a2g_reach_A_const_173 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[312]); A_arbace_a2g_reach_A_const_174 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[313]); A_arbace_a2g_reach_A_const_175 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[314]); A_arbace_a2g_reach_A_const_176 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[315]); A_arbace_a2g_reach_A_const_177 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[316]); A_arbace_a2g_reach_A_const_178 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[317]); A_arbace_a2g_reach_A_const_179 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[318]); A_arbace_a2g_reach_A_const_180 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[319]); A_arbace_a2g_reach_A_const_181 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[320]); A_arbace_a2g_reach_A_const_182 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[321]) }

func A_arbace_a2g_reach_A_clinit_p15() { A_arbace_a2g_reach_A_const_183 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[322]); A_arbace_a2g_reach_A_const_184 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[323]); A_arbace_a2g_reach_A_const_185 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[324]); A_arbace_a2g_reach_A_const_186 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[325]); A_arbace_a2g_reach_A_const_187 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[326]); A_arbace_a2g_reach_A_const_188 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[327]); A_arbace_a2g_reach_A_const_189 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[328]); A_arbace_a2g_reach_A_const_190 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[329]); A_arbace_a2g_reach_A_const_191 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[330]); A_arbace_a2g_reach_A_const_192 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[331]); A_arbace_a2g_reach_A_const_193 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[332]); A_arbace_a2g_reach_A_const_194 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[333]) }

func A_arbace_a2g_reach_A_clinit_p16() { A_arbace_a2g_reach_A_const_195 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[334]); A_arbace_a2g_reach_A_const_196 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[335]); A_arbace_a2g_reach_A_const_197 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[336]); A_arbace_a2g_reach_A_const_198 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[337]); A_arbace_a2g_reach_A_const_199 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[338]); A_arbace_a2g_reach_A_const_200 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[339]); A_arbace_a2g_reach_A_const_201 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[340]); A_arbace_a2g_reach_A_const_202 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[341]); A_arbace_a2g_reach_A_const_203 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[342]); A_arbace_a2g_reach_A_const_204 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[343]); A_arbace_a2g_reach_A_const_205 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[344]); A_arbace_a2g_reach_A_const_206 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[345]) }

func A_arbace_a2g_reach_A_clinit_p17() { A_arbace_a2g_reach_A_const_207 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[346]); A_arbace_a2g_reach_A_const_208 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[347]); A_arbace_a2g_reach_A_const_209 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[348]); A_arbace_a2g_reach_A_const_210 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[349]); A_arbace_a2g_reach_A_const_211 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[350]); A_arbace_a2g_reach_A_const_212 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[351]); A_arbace_a2g_reach_A_const_213 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[352]); A_arbace_a2g_reach_A_const_214 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[353]); A_arbace_a2g_reach_A_const_215 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[354]); A_arbace_a2g_reach_A_const_216 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[355]); A_arbace_a2g_reach_A_const_217 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[356]); A_arbace_a2g_reach_A_const_218 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[357]) }

func A_arbace_a2g_reach_A_clinit_p18() { A_arbace_a2g_reach_A_const_219 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[358]); A_arbace_a2g_reach_A_const_220 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[359]); A_arbace_a2g_reach_A_const_221 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[360]); A_arbace_a2g_reach_A_const_222 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[361]); A_arbace_a2g_reach_A_const_223 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[362]); A_arbace_a2g_reach_A_const_224 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[363]); A_arbace_a2g_reach_A_const_225 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[364]); A_arbace_a2g_reach_A_const_226 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[365]); A_arbace_a2g_reach_A_const_227 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[366]); A_arbace_a2g_reach_A_const_228 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[367]); A_arbace_a2g_reach_A_const_229 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[368]); A_arbace_a2g_reach_A_const_230 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[369]) }

func A_arbace_a2g_reach_A_clinit_p19() { A_arbace_a2g_reach_A_const_231 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[370]); A_arbace_a2g_reach_A_const_232 = lang.Keyword_Cast(A_arbace_a2g_reach_A_const_pool.A[371]); A_arbace_a2g_reach_A_const_233 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[372]); A_arbace_a2g_reach_A_const_234 = A_arbace_a2g_reach_A_const_pool.A[373]; A_arbace_a2g_reach_A_const_235 = A_arbace_a2g_reach_A_const_pool.A[374]; A_arbace_a2g_reach_A_const_236 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[375]); A_arbace_a2g_reach_A_const_237 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[376]); A_arbace_a2g_reach_A_const_238 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[377]); A_arbace_a2g_reach_A_const_239 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[378]); A_arbace_a2g_reach_A_const_240 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[379]); A_arbace_a2g_reach_A_const_241 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[380]); A_arbace_a2g_reach_A_const_242 = lang.Var_Cast(A_arbace_a2g_reach_A_const_pool.A[381]) }

func A_arbace_a2g_reach_A_New() *A_arbace_a2g_reach_A { A_arbace_a2g_reach_A_Init(); t := &A_arbace_a2g_reach_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach_A) Ctor() {}

func (t *A_arbace_a2g_reach_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_A_class }

func (t *A_arbace_a2g_reach_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_A); return ok }

func A_arbace_a2g_reach_A_Cast(x any) *A_arbace_a2g_reach_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_A_class)) }; return v }



type A_arbace_a2g_reach_check_hw_call_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_check_hw_call_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A struct{ a2g_header uint64; F_mm any }

var A_arbace_a2g_reach_check_hw_call_BANG__fn__214000179_A_fn_class *jrt.Class



type A_arbace_a2g_reach_class_of_desc_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_class_of_desc_A_fn_class *jrt.Class



type A_arbace_a2g_reach_eval214000004_A struct{ jrt.Object }

func A_arbace_a2g_reach_eval214000004_A_New() *A_arbace_a2g_reach_eval214000004_A { t := &A_arbace_a2g_reach_eval214000004_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach_eval214000004_A) Ctor() {}

func (t *A_arbace_a2g_reach_eval214000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_eval214000004_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_eval214000004_A_class }

func (t *A_arbace_a2g_reach_eval214000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_eval214000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_eval214000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_eval214000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_eval214000004_A); return ok }

func A_arbace_a2g_reach_eval214000004_A_Cast(x any) *A_arbace_a2g_reach_eval214000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_eval214000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_eval214000004_A_class)) }; return v }



type A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_eval214000004_loading__1927001464__auto____214000005_A_fn_class *jrt.Class



type A_arbace_a2g_reach_eval214000008_A struct{ jrt.Object }

func A_arbace_a2g_reach_eval214000008_A_New() *A_arbace_a2g_reach_eval214000008_A { t := &A_arbace_a2g_reach_eval214000008_A{}; t.Ctor(); return t }

func (t *A_arbace_a2g_reach_eval214000008_A) Ctor() {}

func (t *A_arbace_a2g_reach_eval214000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_a2g_reach_eval214000008_A) GetClass__Class() *jrt.Class { return A_arbace_a2g_reach_eval214000008_A_class }

func (t *A_arbace_a2g_reach_eval214000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_a2g_reach_eval214000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_a2g_reach_eval214000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_a2g_reach_eval214000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_a2g_reach_eval214000008_A); return ok }

func A_arbace_a2g_reach_eval214000008_A_Cast(x any) *A_arbace_a2g_reach_eval214000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_a2g_reach_eval214000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_a2g_reach_eval214000008_A_class)) }; return v }



type A_arbace_a2g_reach_eval214000008_fn__214000009_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_eval214000008_fn__214000009_A_fn_class *jrt.Class



type A_arbace_a2g_reach_external_keys_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_external_keys_A_fn_class *jrt.Class



type A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_external_keys_iter__214000110__214000116_A_fn_class *jrt.Class



type A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A struct{ a2g_header uint64; F_s__214000111, F_iter__214000110 any }

var A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_A_fn_class *jrt.Class



type A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_A_fn_class *jrt.Class



type A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A struct{ a2g_header uint64; F_s__214000113, F_iter__214000112 any }

var A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_A_fn_class *jrt.Class



type A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A struct{ a2g_header uint64; F_b__214000115 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_reach_external_keys_iter__214000110__214000116_fn__214000117_iter__214000112__214000118_fn__214000119_fn__214000120_A_fn_class *jrt.Class



type A_arbace_a2g_reach_find_method_of_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_find_method_of_A_fn_class *jrt.Class



type A_arbace_a2g_reach_find_method_of_fn__214000045_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_find_method_of_fn__214000045_A_fn_class *jrt.Class



type A_arbace_a2g_reach_find_method_of_fn__214000047_A struct{ a2g_header uint64; F_name, F_desc any }

var A_arbace_a2g_reach_find_method_of_fn__214000047_A_fn_class *jrt.Class



type A_arbace_a2g_reach_flatten_code_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_flatten_code_A_fn_class *jrt.Class



type A_arbace_a2g_reach_flatten_code_fn__214000265_A struct{ a2g_header uint64; F_acc any }

var A_arbace_a2g_reach_flatten_code_fn__214000265_A_fn_class *jrt.Class



type A_arbace_a2g_reach_hw_has_field_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_hw_has_field_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_reach_hw_has_static_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_hw_has_static_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_reach_init_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_init_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_instantiate_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_instantiate_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_java_impl_of_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_fn__214000056_A struct{ a2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_a2g_reach_java_impl_of_fn__214000056_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_fn__214000058_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_java_impl_of_fn__214000058_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_fn__214000070_A struct{ a2g_header uint64; F_cands any }

var A_arbace_a2g_reach_java_impl_of_fn__214000070_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A struct{ a2g_header uint64; F_x any }

var A_arbace_a2g_reach_java_impl_of_fn__214000070_fn__214000071_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A struct{ a2g_header uint64; F_name, F_desc, F_n any }

var A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A struct{ a2g_header uint64; F_name, F_desc, F_n, F_iter__214000060, F_s__214000061 any }

var A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_A_fn_class *jrt.Class



type A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A struct{ a2g_header uint64; F_name, F_b__214000063, F_desc, F_n any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_reach_java_impl_of_iter__214000060__214000064_fn__214000065_fn__214000066_A_fn_class *jrt.Class



type A_arbace_a2g_reach_lambda_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_lambda_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_method_code_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_method_code_A_fn_class *jrt.Class



type A_arbace_a2g_reach_node_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_node_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_reach_note_unavailable_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_note_unavailable_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_reach_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_reach_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_run_A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_fn__214000328_A struct{ a2g_header uint64; F_classes, F_instantiate, F_fis, F_roots, F_st any }

var A_arbace_a2g_reach_run_fn__214000328_A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A struct{ a2g_header uint64; F_seen any }

var A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A struct{ a2g_header uint64; F_s__214000352, F_seen, F_iter__214000351 any }

var A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A struct{ a2g_header uint64; F_seen any }

var A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A struct{ a2g_header uint64; F_s__214000354, F_seen, F_iter__214000353 any }

var A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_A_fn_class *jrt.Class



type A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A struct{ a2g_header uint64; F_b__214000356, F_seen any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_reach_run_fn__214000328_iter__214000351__214000357_fn__214000358_iter__214000353__214000359_fn__214000360_fn__214000361_A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_code_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_code_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_method_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_method_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__fn__214000209_A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000222_A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000240_A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000246_A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000252_A_fn_class *jrt.Class



type A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_scan_node_BANG__pat__214000258_A_fn_class *jrt.Class



type A_arbace_a2g_reach_supertypes_of_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_supertypes_of_A_fn_class *jrt.Class



type A_arbace_a2g_reach_supertypes_of_fn__214000128_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_supertypes_of_fn__214000128_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_use_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__fn__214000078_A struct{ a2g_header uint64; F_sup any }

var A_arbace_a2g_reach_use_BANG__fn__214000078_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__fn__214000084_A struct{ a2g_header uint64; F_i any }

var A_arbace_a2g_reach_use_BANG__fn__214000084_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__fn__214000086_A struct{ a2g_header uint64; F_i any }

var A_arbace_a2g_reach_use_BANG__fn__214000086_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__fn__214000088_A struct{ a2g_header uint64; F_o any }

var A_arbace_a2g_reach_use_BANG__fn__214000088_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__fn__214000094_A struct{ a2g_header uint64; F_i any }

var A_arbace_a2g_reach_use_BANG__fn__214000094_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_BANG__fn__214000096_A struct{ a2g_header uint64; F_i any }

var A_arbace_a2g_reach_use_BANG__fn__214000096_A_fn_class *jrt.Class



type A_arbace_a2g_reach_use_desc_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_use_desc_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcall_BANG__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_vcall_BANG__A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcall_BANG__fn__214000166_A struct{ a2g_header uint64; F_o any }

var A_arbace_a2g_reach_vcall_BANG__fn__214000166_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcalls_on_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_vcalls_on_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A struct{ a2g_header uint64; F_by any }

var A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A struct{ a2g_header uint64; F_s__214000132, F_by, F_iter__214000131 any }

var A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A struct{ a2g_header uint64; F_s__214000134, F_iter__214000133 any }

var A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A struct{ a2g_header uint64; F_b__214000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_a2g_reach_vcalls_on_iter__214000131__214000137_fn__214000138_iter__214000133__214000139_fn__214000140_fn__214000141_A_fn_class *jrt.Class



type A_arbace_a2g_reach_vh_call_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_vh_call_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_reach_vh_const_QMARK__A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_vh_const_QMARK__A_fn_class *jrt.Class



type A_arbace_a2g_reach_walk_nodes_A struct{ a2g_header uint64 }

var A_arbace_a2g_reach_walk_nodes_A_fn_class *jrt.Class



type A_arbace_a2g_reach_walk_nodes_walk__214000013_A struct{ a2g_header uint64; F_f, F_walk_val any }

var A_arbace_a2g_reach_walk_nodes_walk__214000013_A_fn_class *jrt.Class



type A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A struct{ a2g_header uint64; F_walk, F_walk_val any }

var A_arbace_a2g_reach_walk_nodes_walk_plain__214000031_A_fn_class *jrt.Class



type A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A struct{ a2g_header uint64; F_walk, F_walk_plain any }

var A_arbace_a2g_reach_walk_nodes_walk_val__214000025_A_fn_class *jrt.Class
