//line aot_arbace_build_go.ae:1
package aot_arbace_build_go

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_New() *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_build_go_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_1); lang.IFn_Cast(A_arbace_build_go_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_3, A_arbace_build_go_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_58)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_59)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_60)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_61)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_62)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_63)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_build_go_eval1901000008_fn__1901000009_A_New() *A_arbace_build_go_eval1901000008_fn__1901000009_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000008_fn__1901000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_5.GetRawRoot__O()); var tmp2 any; var root_10 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_11 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_10, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_12 lang.IFn; if linked_11 == nil { ifn_12 = lang.IFn_Cast(root_10) } else { ifn_12 = nil }; var arg_13 any = A_arbace_build_go_A_const_7; if linked_11 == nil { tmp2 = ifn_12.Invoke_O__O(arg_13) } else { tmp2 = linked_11.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_10, arg_13) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_build_go_A_const_8.GetRawRoot__O(), A_arbace_build_go_A_const_9) }






























































func A_arbace_build_go_fail_A_New() *A_arbace_build_go_fail_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_fail_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_build_go_fail_A) Ctor() {}
//line :64:1
func (t *A_arbace_build_go_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__1901000012__1 any) any { var vec__1901000013__3 any = p__1901000012__1; var data__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000013__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_25 any = A_arbace_build_go_A_const_10.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_27 lang.IFn; if
												linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = msg__0; var arg_29 any; var root_20 any = A_arbace_build_go_A_const_11.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_22 lang.IFn; if linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = A_arbace_build_go_A_const_12; var arg_24 any = data__4; if linked_21 == nil { arg_29 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { arg_29 = linked_21.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; if linked_26 == nil { tmp1 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { tmp1 = linked_26.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; /*line :64:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }





func A_arbace_build_go_data_dir_QMARK__A_New() *A_arbace_build_go_data_dir_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Ctor() {}
//line :70:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.NN(jrt.File_Cast(f__1)).GetParentFile__File().Ref(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(jrt.NN(jrt.File_Cast(d__3)).GetAbsoluteFile__File().Ref(), jrt.NN(jrt.File_Cast(dir__0)).GetAbsoluteFile__File().Ref()) }; if tmp1 { return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_57).IsFile__Z() { return jrt.Boolean_TRUE.Ref() } else { if A_arbace_build_go_A_const_13 != nil {

		d__3 = jrt.NN(jrt.File_Cast(d__3)).GetParentFile__File().Ref(); continue L1 } else {
//line :75:1
			return nil } } } } }; /*line :70:1*/panic("j2g: unreachable") }








func A_arbace_build_go_clj_files_A_New() *A_arbace_build_go_clj_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_build_go_clj_files_A) Ctor() {}
//line :79:1
func (t *A_arbace_build_go_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var root_55 any = A_arbace_build_go_A_const_14.GetRawRoot__O(); var linked_56 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_55, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_57 lang.IFn; if linked_56 == nil { ifn_57 = lang.IFn_Cast(root_55) } else { ifn_57 = nil }; var arg_58 any; var tmp1 any = A_arbace_build_go_clj_files_fn__1901000020_A_New(); var tmp2 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000020_A_fn_class; if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_build_go_clj_files_fn__1901000020_A_fn_class = fncls__30d; tmp2 = fncls__30d } else { tmp2 = fncls__30 }; arg_58 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_59 any; var root_50 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_52 lang.IFn
//line :81:1
	if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any; var tmp3 any = A_arbace_build_go_clj_files_fn__1901000022_A_New_O(dir__0); var tmp4 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000022_A_fn_class; if fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_build_go_clj_files_fn__1901000022_A_fn_class = fncls__45d; tmp4 = fncls__45d } else { tmp4 = fncls__45 }; arg_53 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_54 any; var root_46 any = A_arbace_build_go_A_const_19.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_48 lang.IFn
//line :80:1
	if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any = dir__0; if linked_47 == nil { arg_54 = ifn_48.Invoke_O__O(arg_49) } else { arg_54 = linked_47.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_46, arg_49) }
	if linked_51 == nil { arg_59 = ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { arg_59 = linked_51.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_50, arg_53, arg_54)
	}
	if linked_56 == nil { return ifn_57.Invoke_O_O__O(arg_58, arg_59) } else { return linked_56.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_55, arg_58, arg_59) } }
//line :81:1
func A_arbace_build_go_clj_files_fn__1901000022_A_New_O(p0 any) *A_arbace_build_go_clj_files_fn__1901000022_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000022_A{}; t.Ctor_O(p0); return t }
//line :81:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :81:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Invoke_O_O__O(self, p1__1901000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_31 any = A_arbace_build_go_A_const_16.GetRawRoot__O(); var linked_32 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_31, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_33 lang.IFn; if linked_32 == nil { ifn_33 = lang.IFn_Cast(root_31) } else { ifn_33 = nil }; var arg_34 any = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).GetName__String().Ref(); var arg_35 any = Lit_50; if linked_32 == nil { and__1927000168__auto____3 = ifn_33.Invoke_O_O__O(arg_34, arg_35) } else { and__1927000168__auto____3 = linked_32.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_31, arg_34, arg_35) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
														var root_41 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any; var root_36 any = A_arbace_build_go_A_const_18.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, A_arbace_build_go_data_dir_QMARK__A_fn_class); var ifn_38 lang.IFn; if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any = t.F_dir; var arg_40 any = p1__1901000018_SHARP___1; if linked_37 == nil { arg_44 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { arg_44 = linked_37.(*A_arbace_build_go_data_dir_QMARK__A).Invoke_O_O_O__O(root_36, arg_39, arg_40) }; if linked_42 == nil { return ifn_43.Invoke_O__O(arg_44) } else { return linked_42.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_41, arg_44) } } else {
//line :81:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_build_go_clj_files_fn__1901000020_A_New() *A_arbace_build_go_clj_files_fn__1901000020_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000020_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Ctor() {}
//line :83:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Invoke_O_O__O(self, p1__1901000019_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000019_SHARP___1)).GetPath__String().Ref() }

func A_arbace_build_go_package_file_QMARK__A_New() *A_arbace_build_go_package_file_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_build_go_package_file_QMARK__A) Ctor() {}
//line :85:1
func (t *A_arbace_build_go_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var root_74 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_75 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_74, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_76 lang.IFn; if




	linked_75 == nil { ifn_76 = lang.IFn_Cast(root_74) } else { ifn_76 = nil }; var arg_77 any; var root_69 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any; var tmp1 any = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New(); var tmp2 *jrt.Class; var fncls__68 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class; if fncls__68 == nil { var fncls__68d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class = fncls__68d; tmp2 = fncls__68d } else { tmp2 = fncls__68 }; arg_72 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_73 any = forms__3; if linked_70 == nil { arg_77 = ifn_71.Invoke_O_O__O(arg_72, arg_73) } else { arg_77 = linked_70.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_69, arg_72, arg_73) }; if linked_75 == nil { ns_form__4 = ifn_76.Invoke_O__O(arg_77) } else { ns_form__4 = linked_75.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_74, arg_77) }; var aliases__5 any; if
	jrt.J2g_Truth(ns_form__4) { aliases__5 = A_arbace_build_go_A_const_23.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp3 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_112 any = A_arbace_build_go_A_const_24.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any; var tmp4 any = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(aliases__5); var tmp5 *jrt.Class; var fncls__111 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class; if fncls__111 == nil { var fncls__111d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class = fncls__111d; tmp5 = fncls__111d } else { tmp5 = fncls__111 }; arg_115 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_116 any = forms__3; if linked_113 == nil { tmp3 = ifn_114.Invoke_O_O__O(arg_115, arg_116) } else { tmp3 = linked_113.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_112, arg_115, arg_116) } } else {
//line :93:1
			tmp3 = and__1927000168__auto____6 }; return /*line :92:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() }
//line :90:1
func A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New() *A_arbace_build_go_package_file_QMARK__fn__1901000027_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000027_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Ctor() {}
//line :90:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Invoke_O_O__O(self, p1__1901000025_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_60 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_62 lang.IFn; if linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any = p1__1901000025_SHARP___1; if linked_61 == nil { and__1927000168__auto____2 = ifn_62.Invoke_O__O(arg_63) } else { and__1927000168__auto____2 = linked_61.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_60, arg_63) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_build_go_A_const_22; var tmp2 any; var root_64 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any = p1__1901000025_SHARP___1; if linked_65 == nil { tmp2 = ifn_66.Invoke_O__O(arg_67) } else { tmp2 = linked_65.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_64, arg_67) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(p0 any) *A_arbace_build_go_package_file_QMARK__fn__1901000029_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000029_A{}; t.Ctor_O(p0); return t }
//line :94:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :94:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Invoke_O_O__O(self, p1__1901000026_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_78 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any = p1__1901000026_SHARP___1; if linked_79 == nil { and__1927000168__auto____2 = ifn_80.Invoke_O__O(arg_81) } else { and__1927000168__auto____2 = linked_79.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_78, arg_81) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_86 any = A_arbace_build_go_A_const_25.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any; var root_82 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_83 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_82, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_84 lang.IFn; if linked_83 == nil { ifn_84 = lang.IFn_Cast(root_82) } else { ifn_84 = nil }; var arg_85 any = p1__1901000026_SHARP___1; if linked_83 == nil { arg_89 = ifn_84.Invoke_O__O(arg_85) } else { arg_89 = linked_83.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_82, arg_85) }; if linked_87 == nil { and__1927000168__auto____3 = ifn_88.Invoke_O__O(arg_89) } else { and__1927000168__auto____3 = linked_87.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool; var tmp1 any; var root_94 any = A_arbace_build_go_A_const_26.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_96 lang.IFn
															if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any; var root_90 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any = p1__1901000026_SHARP___1; if linked_91 == nil { arg_97 = ifn_92.Invoke_O__O(arg_93) } else { arg_97 = linked_91.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_90, arg_93) }; if linked_95 == nil { tmp1 = ifn_96.Invoke_O__O(arg_97) } else { tmp1 = linked_95.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_94, arg_97) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(Lit_83, tmp1)
//line :94:1
	if and__1927000168__auto____4 {

		var root_106 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = t.F_aliases; var arg_110 any; var root_102 any = A_arbace_build_go_A_const_28.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any; var root_98 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_100 lang.IFn; if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any = p1__1901000026_SHARP___1; if linked_99 == nil { arg_105 = ifn_100.Invoke_O__O(arg_101) } else { arg_105 = linked_99.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_98, arg_101) }; if linked_103 == nil { arg_110 = ifn_104.Invoke_O__O(arg_105) } else { arg_110 = linked_103.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_102, arg_105) }; if linked_107 == nil { return ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { return linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else {
//line :94:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_build_go_rel_path_A_New() *A_arbace_build_go_rel_path_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_rel_path_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_build_go_rel_path_A) Ctor() {}
//line :101:1
func (t *A_arbace_build_go_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	var root_117 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = jrt.NN(jrt.NN(jrt.File_Cast(base__0)).GetAbsoluteFile__File()).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).ToPath__Path()); if linked_118 == nil { return ifn_119.Invoke_O__O(arg_120) } else { return linked_118.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_117, arg_120)
	} }
func A_arbace_build_go_packages_A_New() *A_arbace_build_go_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_build_go_packages_A) Ctor() {}
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O_O__O(self, dir__0, roots__1, print_cache__2 any) any { var own__4 any; var root_121 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_build_go_root_packages_A_fn_class); var ifn_123 lang.IFn; if








	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = dir__0; var arg_125 any = print_cache__2; if linked_122 == nil { own__4 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { own__4 = linked_122.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; var more__5 any; var iter__1927001039__auto____5 any; var tmp1 any = /*line :104:1*/A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(print_cache__2); var tmp2 *jrt.Class; var fncls__242 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class; if









	fncls__242 == nil { var fncls__242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class = fncls__242d; tmp2 = fncls__242d } else { tmp2 = fncls__242 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); more__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(roots__1); var pkgs__6 any; var root_248 any = /*line :104:1*/A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_249 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_248, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_250 lang.IFn; if













	linked_249 == nil { ifn_250 = lang.IFn_Cast(root_248) } else { ifn_250 = nil }; var arg_251 any; var root_243 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = own__4; var arg_247 any = more__5; if linked_244 == nil { arg_251 = ifn_245.Invoke_O_O__O(arg_246, arg_247) } else { arg_251 = linked_244.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_243, arg_246, arg_247) }; if linked_249 == nil { pkgs__6 = ifn_250.Invoke_O__O(arg_251) } else { pkgs__6 = linked_249.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_248, arg_251) }; var seq_1901000050__7 any; var root_257 any = /*line :104:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_257, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_259 lang.IFn; if














	linked_258 == nil { ifn_259 = lang.IFn_Cast(root_257) } else { ifn_259 = nil }; var arg_260 any; var root_252 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = A_arbace_build_go_A_const_46; var arg_256 any = pkgs__6; if linked_253 == nil { arg_260 = ifn_254.Invoke_O_O__O(arg_255, arg_256) } else { arg_260 = linked_253.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_252, arg_255, arg_256) }; if linked_258 == nil { seq_1901000050__7 = ifn_259.Invoke_O__O(arg_260) } else { seq_1901000050__7 = linked_258.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_257, arg_260) }; var chunk_1901000051__8 any; var count_1901000052__9 int64 = 0; var i_1901000053__10 int64 = 0; L1:
//line :104:1
	for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000053__10, count_1901000052__9) { var vec__1901000054__11 any = lang.Indexed_Cast(chunk_1901000051__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000053__10)); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__13)), 1) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp5 any; var root_283 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_283, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_285 lang.IFn
			if linked_284 == nil { ifn_285 = lang.IFn_Cast(root_283) } else { ifn_285 = nil }; var arg_286 any = Lit_87; var arg_287 any; var root_278 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_279 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_278, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_280 lang.IFn; if linked_279 == nil { ifn_280 = lang.IFn_Cast(root_278) } else { ifn_280 = nil }; var arg_281 any; var tmp6 any = A_arbace_build_go_packages_fn__1901000057_A_New(); var tmp7 *jrt.Class; var fncls__277 *jrt.Class = A_arbace_build_go_packages_fn__1901000057_A_fn_class; if fncls__277 == nil { var fncls__277d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_build_go_packages_fn__1901000057_A_fn_class = fncls__277d; tmp7 = fncls__277d } else { tmp7 = fncls__277 }; arg_281 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_282 any = ps__13; if linked_279 == nil { arg_287 = ifn_280.Invoke_O_O__O(arg_281, arg_282) } else { arg_287 = linked_279.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_278, arg_281, arg_282) }; if linked_284 == nil { tmp5 = ifn_285.Invoke_O_O__O(arg_286, arg_287) } else { tmp5 = linked_284.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_283, arg_286, arg_287) }
//line :120:1
			tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__12, nil, tmp5)).Ref())
//line :119:1
			seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } else { seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_261 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = seq_1901000050__7; if linked_262 == nil { temp__1927000414__auto____11 = ifn_263.Invoke_O__O(arg_264) } else { temp__1927000414__auto____11 = linked_262.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_261, arg_264) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000050__12 any = temp__1927000414__auto____11; var tmp8 any; var root_265 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = seq_1901000050__12; if linked_266 == nil { tmp8 = ifn_267.Invoke_O__O(arg_268) } else { tmp8 = linked_266.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____13 any; var root_269 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = seq_1901000050__12; if linked_270 == nil { c__1927000678__auto____13 = ifn_271.Invoke_O__O(arg_272) } else { c__1927000678__auto____13 = linked_270.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_269, arg_272) }; var tmp9 any; var root_292 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1901000050__12; if linked_293 == nil { tmp9 = ifn_294.Invoke_O__O(arg_295) } else { tmp9 = linked_293.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_292, arg_295) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp9, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000059__13 any; var root_273 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = seq_1901000050__12; if linked_274 == nil { vec__1901000059__13 = ifn_275.Invoke_O__O(arg_276) } else { vec__1901000059__13 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__15)), 1) {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp12 any; var root_302 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_304 lang.IFn
				if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = Lit_87; var arg_306 any; var root_297 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_298 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_297, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_299 lang.IFn; if linked_298 == nil { ifn_299 = lang.IFn_Cast(root_297) } else { ifn_299 = nil }; var arg_300 any; var tmp13 any = A_arbace_build_go_packages_fn__1901000062_A_New(); var tmp14 *jrt.Class; var fncls__296 *jrt.Class = A_arbace_build_go_packages_fn__1901000062_A_fn_class; if fncls__296 == nil { var fncls__296d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_build_go_packages_fn__1901000062_A_fn_class = fncls__296d; tmp14 = fncls__296d } else { tmp14 = fncls__296 }; arg_300 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_301 any = ps__15; if linked_298 == nil { arg_306 = ifn_299.Invoke_O_O__O(arg_300, arg_301) } else { arg_306 = linked_298.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_297, arg_300, arg_301) }; if linked_303 == nil { tmp12 = ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { tmp12 = linked_303.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) }
//line :120:1
				tmp10.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, path__14, nil, tmp12)).Ref())
//line :119:1
				var tmp15 any; var root_311 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = seq_1901000050__12; if linked_312 == nil { tmp15 = ifn_313.Invoke_O__O(arg_314) } else { tmp15 = linked_312.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_311, arg_314) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp15, nil, 0, 0; continue L1 } else { var tmp16 any; var root_315 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = seq_1901000050__12; if linked_316 == nil { tmp16 = ifn_317.Invoke_O__O(arg_318) } else { tmp16 = linked_316.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_315, arg_318) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp16, nil, 0, 0; continue L1 } } } }
//line :104:1
		break L1 }; return pkgs__6 }
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any {






	var root_319 any = A_arbace_build_go_A_const_52.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_build_go_packages_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = dir__0; var arg_323 any = roots__1; var arg_324 any; if linked_320 == nil { return ifn_321.Invoke_O_O_O__O(arg_322, arg_323, arg_324) } else { return linked_320.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_319, arg_322, arg_323, arg_324) } }
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O__O(self, dir__0 any) any {





	var root_325 any = A_arbace_build_go_A_const_52.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_build_go_packages_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = dir__0; var arg_329 any; var arg_330 any; if linked_326 == nil { return ifn_327.Invoke_O_O_O__O(arg_328, arg_329, arg_330) } else { return linked_326.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_325, arg_328, arg_329, arg_330)
	}
}

func A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(p0 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_A{}; t.Ctor_O(p0); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Ctor_O(c__print_cache any) { t.F_print_cache = c__print_cache }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Invoke_O_O__O(self, s__1901000035__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(self, t.F_print_cache, s__1901000035__1); var tmp2 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class = fncls__241d; tmp2 = fncls__241d } else { tmp2 = fncls__241 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Ctor_O_O_O(c__iter__1901000034, c__print_cache, c__s__1901000035 any) { t.F_iter__1901000034 = c__iter__1901000034; t.F_print_cache = c__print_cache; t.F_s__1901000035 = c__s__1901000035 }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Invoke_O__O(self any) any { { var s__1901000035__1 any; var t_ any = t.F_s__1901000035; t.F_s__1901000035 = nil; s__1901000035__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_126 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = s__1901000035__1; if linked_127 == nil { temp__1927000414__auto____2 = ifn_128.Invoke_O__O(arg_129) } else { temp__1927000414__auto____2 = linked_127.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_126, arg_129) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_130 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = xs__1927001018__auto____3; if linked_131 == nil { r__4 = ifn_132.Invoke_O__O(arg_133) } else { r__4 = linked_131.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_130, arg_133) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New(); var tmp2 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class = fncls__214d; tmp2 = fncls__214d } else { tmp2 = fncls__214 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_224 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_219 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_build_go_root_packages_A_fn_class); var ifn_221 lang.IFn
														if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any; var tmp5 any; var root_215 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any = r__4; if linked_216 == nil { tmp5 = ifn_217.Invoke_O__O(arg_218) } else { tmp5 = linked_216.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_215, arg_218) }; arg_222 = jrt.File_New_String(jrt.String_Cast(tmp5)); var arg_223 any = t.F_print_cache; if linked_220 == nil { tmp4 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { tmp4 = linked_220.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }
//line :114:1
	arg_227 = tmp3.Invoke_O__O(tmp4); if linked_225 == nil { fs__1927001036__auto____6 = ifn_226.Invoke_O__O(arg_227) } else { fs__1927001036__auto____6 = linked_225.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_224, arg_227) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_232 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_233 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_232, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_234 lang.IFn; if linked_233 == nil { ifn_234 = lang.IFn_Cast(root_232) } else { ifn_234 = nil }; var arg_235 any = fs__1927001036__auto____6; var arg_236 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000034); var tmp7 any; var root_228 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = s__1901000035__1; if linked_229 == nil { tmp7 = ifn_230.Invoke_O__O(arg_231) } else { tmp7 = linked_229.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_228, arg_231) }; arg_236 = tmp6.Invoke_O__O(tmp7); if linked_233 == nil { return ifn_234.Invoke_O_O__O(arg_235, arg_236) } else { return linked_233.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_232, arg_235, arg_236) } } else { var tmp8 any; var root_237 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = s__1901000035__1; if linked_238 == nil { tmp8 = ifn_239.Invoke_O__O(arg_240) } else { tmp8 = linked_238.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_237, arg_240) }; s__1901000035__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New() *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Ctor() {}
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Invoke_O_O__O(self, s__1901000037__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(self, s__1901000037__1); var tmp2 *jrt.Class; var fncls__213 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class; if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class = fncls__213d; tmp2 = fncls__213d } else { tmp2 = fncls__213 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(p0, p1 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Ctor_O_O(c__iter__1901000036, c__s__1901000037 any) { t.F_iter__1901000036 = c__iter__1901000036; t.F_s__1901000037 = c__s__1901000037 }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Invoke_O__O(self any) any { { var s__1901000037__1 any; var t_ any = t.F_s__1901000037; t.F_s__1901000037 = nil; s__1901000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_134 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1901000037__1; if linked_135 == nil { temp__1927000414__auto____2 = ifn_136.Invoke_O__O(arg_137) } else { temp__1927000414__auto____2 = linked_135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_138 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1901000037__3; if linked_139 == nil { tmp1 = ifn_140.Invoke_O__O(arg_141) } else { tmp1 = linked_139.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_142 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = s__1901000037__3; if linked_143 == nil { c__1927001037__auto____4 = ifn_144.Invoke_O__O(arg_145) } else { c__1927001037__auto____4 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_142, arg_145) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000039__6 any; var root_146 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_147 == nil { b__1901000039__6 = ifn_148.Invoke_O__O(arg_149) } else { b__1901000039__6 = linked_147.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_146, arg_149) }; var tmp2 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(b__1901000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_173 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_174 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_173, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_175 lang.IFn; if linked_174 == nil { ifn_175 = lang.IFn_Cast(root_173) } else { ifn_175 = nil }; var arg_176 any; var root_165 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any = b__1901000039__6; if linked_166 == nil { arg_176 = ifn_167.Invoke_O__O(arg_168) } else { arg_176 = linked_166.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_165, arg_168) }; var arg_177 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp5 any; var root_169 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_170 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_169, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_171 lang.IFn; if linked_170 == nil { ifn_171 = lang.IFn_Cast(root_169) } else { ifn_171 = nil }; var arg_172 any = s__1901000037__3; if linked_170 == nil { tmp5 = ifn_171.Invoke_O__O(arg_172) } else { tmp5 = linked_170.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_169, arg_172) }; arg_177 = tmp4.Invoke_O__O(tmp5); if linked_174 == nil { return ifn_175.Invoke_O_O__O(arg_176, arg_177) } else { return linked_174.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_173, arg_176, arg_177) } } else { var root_182 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_183 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_182, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_184 lang.IFn; if linked_183 == nil { ifn_184 = lang.IFn_Cast(root_182) } else { ifn_184 = nil }; var arg_185 any; var root_178 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any = b__1901000039__6; if linked_179 == nil { arg_185 = ifn_180.Invoke_O__O(arg_181) } else { arg_185 = linked_179.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_178, arg_181) }; var arg_186 any; if linked_183 == nil { return ifn_184.Invoke_O_O__O(arg_185, arg_186) } else { return linked_183.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_182, arg_185, arg_186) } } } else { var pkg__4 any; var root_187 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = s__1901000037__3; if linked_188 == nil { pkg__4 = ifn_189.Invoke_O__O(arg_190) } else { pkg__4 = linked_188.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_187, arg_190) }; var tmp6 any; var root_195 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_196 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_195, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_197 lang.IFn

	if linked_196 == nil { ifn_197 = lang.IFn_Cast(root_195) } else { ifn_197 = nil }; var arg_198 any = Lit_94; var arg_199 any; var root_191 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_193 lang.IFn; if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__4); if linked_192 == nil { arg_199 = ifn_193.Invoke_O__O(arg_194) } else { arg_199 = linked_192.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_191, arg_194) }; if linked_196 == nil { tmp6 = ifn_197.Invoke_O_O__O(arg_198, arg_199) } else { tmp6 = linked_196.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_195, arg_198, arg_199) }
//line :114:1
	if jrt.J2g_Truth(tmp6) { var root_204 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_204, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_206 lang.IFn; if linked_205 == nil { ifn_206 = lang.IFn_Cast(root_204) } else { ifn_206 = nil }; var arg_207 any = pkg__4; var arg_208 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp8 any; var root_200 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = s__1901000037__3; if linked_201 == nil { tmp8 = ifn_202.Invoke_O__O(arg_203) } else { tmp8 = linked_201.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_200, arg_203) }; arg_208 = tmp7.Invoke_O__O(tmp8); if linked_205 == nil { return ifn_206.Invoke_O_O__O(arg_207, arg_208) } else { return linked_205.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_204, arg_207, arg_208) } } else { var tmp9 any; var root_209 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = s__1901000037__3; if linked_210 == nil { tmp9 = ifn_211.Invoke_O__O(arg_212) } else { tmp9 = linked_210.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_209, arg_212) }; s__1901000037__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Ctor_O_I_O(c__b__1901000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000039 = c__b__1901000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Invoke_O__O(self any) any { { var i__1901000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000038__1)); var tmp2 any; var root_154 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_156 lang.IFn

	if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = Lit_94; var arg_158 any; var root_150 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__2); if linked_151 == nil { arg_158 = ifn_152.Invoke_O__O(arg_153) } else { arg_158 = linked_151.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_150, arg_153) }; if linked_155 == nil { tmp2 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { tmp2 = linked_155.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }
//line :114:1
	if jrt.J2g_Truth(tmp2) { var root_159 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = t.F_b__1901000039; var arg_163 any = pkg__2; if linked_160 == nil { ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { linked_160.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } else { i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_build_go_packages_fn__1901000057_A_New() *A_arbace_build_go_packages_fn__1901000057_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000057_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Ctor() {}
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }
//line :121:1
func A_arbace_build_go_packages_fn__1901000062_A_New() *A_arbace_build_go_packages_fn__1901000062_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000062_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Ctor() {}
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }


func A_arbace_build_go_read_all_A_New() *A_arbace_build_go_read_all_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_read_all_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var root_342 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_344 lang.IFn; if




	linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any; var root_332 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_332, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_334 lang.IFn; if linked_333 == nil { ifn_334 = lang.IFn_Cast(root_332) } else { ifn_334 = nil }; var arg_335 any; var tmp1 any = A_arbace_build_go_read_all_fn__1901000066_A_New(); var tmp2 *jrt.Class; var fncls__331 *jrt.Class = A_arbace_build_go_read_all_fn__1901000066_A_fn_class; if fncls__331 == nil { var fncls__331d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_build_go_read_all_fn__1901000066_A_fn_class = fncls__331d; tmp2 = fncls__331d } else { tmp2 = fncls__331 }; arg_335 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_336 any = files__0; if linked_333 == nil { arg_345 = ifn_334.Invoke_O_O__O(arg_335, arg_336) } else { arg_345 = linked_333.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_332, arg_335, arg_336) }; var arg_346 any; var root_337 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_337, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_339 lang.IFn; if
	linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var arg_341 any = files__0; if linked_338 == nil { arg_346 = ifn_339.Invoke_O_O__O(arg_340, arg_341) } else { arg_346 = linked_338.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_337, arg_340, arg_341) }; if /*line :129:1*/ linked_343 == nil { cache__2 = ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { cache__2 = linked_343.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) }; var tmp3 any =

	A_arbace_build_go_read_all_fn__1901000068_A_New_O(cache__2); var tmp4 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_build_go_read_all_fn__1901000068_A_fn_class; if fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_build_go_read_all_fn__1901000068_A_fn_class = fncls__356d; tmp4 = fncls__356d } else { tmp4 = fncls__356 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }
//line :129:1
func A_arbace_build_go_read_all_fn__1901000066_A_New() *A_arbace_build_go_read_all_fn__1901000066_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000066_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Ctor() {}
//line :129:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Invoke_O_O__O(self, p1__1901000065_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000065_SHARP___1)).GetAbsolutePath__String().Ref() }

func A_arbace_build_go_read_all_fn__1901000068_A_New_O(p0 any) *A_arbace_build_go_read_all_fn__1901000068_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000068_A{}; t.Ctor_O(p0); return t }
//line :131:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :131:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__1)).GetAbsolutePath__String().Ref(); var tmp1 any; var root_347 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_349 lang.IFn; if

	linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = t.F_cache; var arg_351 any = k__2; if linked_348 == nil { tmp1 = ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { tmp1 = linked_348.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_347, arg_350, arg_351) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_cache, k__2) } else { var root_352 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = f__1; if linked_353 == nil { return ifn_354.Invoke_O__O(arg_355) } else { return linked_353.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_352, arg_355) } } }

func A_arbace_build_go_hex_A_New() *A_arbace_build_go_hex_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_build_go_hex_A) Ctor() {}
//line :135:1
func (t *A_arbace_build_go_hex_A) Invoke_O_O__O(self, bs__0 any) any {
	var root_373 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_374 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_373, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_375 lang.IFn; if linked_374 == nil { ifn_375 = lang.IFn_Cast(root_373) } else { ifn_375 = nil }; var arg_376 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_377 any; var root_368 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_369 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_368, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_370 lang.IFn; if linked_369 == nil { ifn_370 = lang.IFn_Cast(root_368) } else { ifn_370 = nil }; var arg_371 any; var tmp1 any = A_arbace_build_go_hex_fn__1901000072_A_New(); var tmp2 *jrt.Class; var fncls__367 *jrt.Class = A_arbace_build_go_hex_fn__1901000072_A_fn_class; if fncls__367 == nil { var fncls__367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_build_go_hex_fn__1901000072_A_fn_class = fncls__367d; tmp2 = fncls__367d } else { tmp2 = fncls__367 }; arg_371 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_372 any = bs__0; if linked_369 == nil { arg_377 = ifn_370.Invoke_O_O__O(arg_371, arg_372) } else { arg_377 = linked_369.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_368, arg_371, arg_372) }; if linked_374 == nil { return ifn_375.Invoke_O_O__O(arg_376, arg_377) } else { return linked_374.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_373, arg_376, arg_377) } }
//line :136:1
func A_arbace_build_go_hex_fn__1901000072_A_New() *A_arbace_build_go_hex_fn__1901000072_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_fn__1901000072_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Ctor() {}
//line :136:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Invoke_O_O__O(self, p1__1901000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_357 any = p1__1901000071_SHARP___1; var na_358 int64 = 255; if jrt.Long_InstanceOf(na_357) { var n0_359 int64 = jrt.NN(jrt.Long_Cast(na_357)).LongValue__J(); var n1_360 int64 = na_358; tmp2 = n0_359 & n1_360 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_357, na_358) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_file_sha_A_New() *A_arbace_build_go_file_sha_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_file_sha_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_build_go_file_sha_A) Ctor() {}
//line :138:1
func (t *A_arbace_build_go_file_sha_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		var root_378 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, A_arbace_build_go_hex_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref(); if linked_379 == nil { return ifn_380.Invoke_O__O(arg_381) } else { return linked_379.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_378, arg_381) } } else {
//line :141:1
			return nil
		}
}
func A_arbace_build_go_collect_package_A_New() *A_arbace_build_go_collect_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_build_go_collect_package_A) Ctor() {}
//line :144:1
func (t *A_arbace_build_go_collect_package_A) Invoke_O_O_O_O__O(self, dir__0, f__1, read_fn__2 any) any { var read__4 any; var root_382 any = A_arbace_build_go_A_const_59.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_384 lang.IFn; if



	linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = lang.PersistentVector_EMPTY.Ref(); if linked_383 == nil { read__4 = ifn_384.Invoke_O__O(arg_385) } else { read__4 = linked_383.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_382, arg_385) }; var pkg__5 any; var root_393 any = /*line :144:1*/A_arbace_build_go_A_const_60.GetRawRoot__O(); var linked_394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_393, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_395 lang.IFn; if




	linked_394 == nil { ifn_395 = lang.IFn_Cast(root_393) } else { ifn_395 = nil }; var arg_396 any = f__1; var arg_397 any; var tmp1 any = A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(read_fn__2, read__4); var tmp2 *jrt.Class; var fncls__392 *jrt.Class = A_arbace_build_go_collect_package_fn__1901000076_A_fn_class; if fncls__392 == nil { var fncls__392d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_build_go_collect_package_fn__1901000076_A_fn_class = fncls__392d; tmp2 = fncls__392d } else { tmp2 = fncls__392 }; arg_397 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_394 == nil { pkg__5 = ifn_395.Invoke_O_O__O(arg_396, arg_397) } else { pkg__5 = linked_394.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_393, arg_396, arg_397) }; var tmp3 /*line :144:1*/*lang.Keyword = A_arbace_build_go_A_const_46; var path__6 any = tmp3.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__5)); var tmp4 any; var root_412 any = A_arbace_build_go_A_const_65.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_414 lang.IFn; if






	linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = path__6; if linked_413 == nil { tmp4 = ifn_414.Invoke_O__O(arg_415) } else { tmp4 = linked_413.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(tmp4) { } else {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_55); var tmp7 any; var root_416 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_416, A_arbace_build_go_rel_path_A_fn_class); var ifn_418 lang.IFn; if linked_417 == nil { ifn_418 = lang.IFn_Cast(root_416) } else { ifn_418 = nil }; var arg_419 any = dir__0; var arg_420 any = f__1; if linked_417 == nil { tmp7 = ifn_418.Invoke_O_O__O(arg_419, arg_420) } else { tmp7 = linked_417.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_416, arg_419, arg_420) }; tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref()) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp9 any = A_arbace_build_go_A_const_50; var tmp10 any = A_arbace_build_go_A_const_46; var tmp11 any = A_arbace_build_go_A_const_64; var tmp12 any; var root_398 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_400 lang.IFn; if linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = read__4; if linked_399 == nil { tmp12 = ifn_400.Invoke_O__O(arg_401) } else { tmp12 = linked_399.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_398, arg_401) }; return tmp8.Invoke_O_O_O_O_O_O_O__O(pkg__5, tmp9, f__1, tmp10, path__6, tmp11, tmp12) }
//line :149:1
func A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(p0, p1 any) *A_arbace_build_go_collect_package_fn__1901000076_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_fn__1901000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :149:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Invoke_O_O__O(self, file__1 any) any { var root_386 any = A_arbace_build_go_A_const_61.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_386, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_388 lang.IFn; if linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = t.F_read; var arg_390 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_391 any = file__1; if linked_387 == nil { ifn_388.Invoke_O_O_O__O(arg_389, arg_390, arg_391) } else { linked_387.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_386, arg_389, arg_390, arg_391) }; return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }











func A_arbace_build_go_collect_index_file_A_New() *A_arbace_build_go_collect_index_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_index_file_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_build_go_collect_index_file_A) Ctor() {}
//line :161:1
func (t *A_arbace_build_go_collect_index_file_A) Invoke_O_O_O_O__O(self, print_cache__0, host_id__1, dir__2 any) any { var md__4 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51);

	jrt.MessageDigest_Cast(md__4).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil), jrt.RefArrayOf(jrt.Object_class, host_id__1, nil, jrt.NN(jrt.File_Cast(dir__2)).GetPath__String().Ref()))).GetBytes_String__B1(Lit_52)); var tmp1 /*line :161:1*/*jrt.Class = A_arbace_build_go_A_const_67; var tmp2 any; var root_425 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_427 lang.IFn; if


	linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = print_cache__0; if linked_426 == nil { tmp2 = ifn_427.Invoke_O__O(arg_428) } else { tmp2 = linked_426.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_425, arg_428) }; var tmp3 any = /*line :161:1*/jrt.File_New_String_String(jrt.String_Cast(tmp2), Lit_53); var tmp4 any; var root_429 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_build_go_hex_A_fn_class); var ifn_431 lang.IFn; if


	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = jrt.MessageDigest_Cast(md__4).Digest__B1().Ref(); if linked_430 == nil { tmp4 = ifn_431.Invoke_O__O(arg_432) } else { tmp4 = linked_430.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_429, arg_432) }; return /*line :161:1*/ lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)) }




func A_arbace_build_go_read_index_A_New() *A_arbace_build_go_read_index_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_index_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_build_go_read_index_A) Ctor() {}
//line :166:1
func (t *A_arbace_build_go_read_index_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
//line :169:1
		var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1901000080__4 any; var root_433 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_435 lang.IFn

			if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = f__0; if linked_434 == nil { vec__1901000080__4 = ifn_435.Invoke_O__O(arg_436) } else { vec__1901000080__4 = linked_434.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_433, arg_436) }
//line :169:1
			var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp2 any; var root_437 any = A_arbace_build_go_A_const_68.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_439 lang.IFn

			if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = m__5; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(tmp2) { tmp1 = m__5 } else { tmp1 = nil } }; return nil }()
//line :169:1
		if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_build_go_write_index_BANG__A_New() *A_arbace_build_go_write_index_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_build_go_write_index_BANG__A) Ctor() {}
//line :174:1
func (t *A_arbace_build_go_write_index_BANG__A) Invoke_O_O_O__O(self, f__0, index__1 any) any { var printed__3 any; var tmp1 any = A_arbace_build_go_write_index_BANG__printed__1901000087_A_New(); var tmp2 *jrt.Class; var fncls__461 *jrt.Class = A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class; if



	fncls__461 == nil { var fncls__461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class = fncls__461d; tmp2 = fncls__461d } else { tmp2 = fncls__461 }; printed__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var ok_QMARK___4 any; var tmp3 any = /*line :174:1*/A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(printed__3); var tmp4 *jrt.Class; var fncls__466 *jrt.Class = A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class; if



	fncls__466 == nil { var fncls__466d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class = fncls__466d; tmp4 = fncls__466d } else { tmp4 = fncls__466 }; ok_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var index__5 any; var root_487 any = /*line :174:1*/A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_488 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_487, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_489 lang.IFn; if





	linked_488 == nil { ifn_489 = lang.IFn_Cast(root_487) } else { ifn_489 = nil }; var arg_490 any = index__1; var arg_491 any = A_arbace_build_go_A_const_78; var arg_492 any; var tmp5 any = A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(ok_QMARK___4); var tmp6 *jrt.Class; var fncls__486 *jrt.Class = A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class; if fncls__486 == nil { var fncls__486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class = fncls__486d; tmp6 = fncls__486d } else { tmp6 = fncls__486 }; arg_492 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_488 == nil { index__5 = ifn_489.Invoke_O_O_O__O(arg_490, arg_491, arg_492) } else { index__5 = linked_488.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_487, arg_490, arg_491, arg_492) }; var tmp__6 any = /*line :174:1*/jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));







	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File()).Mkdirs__Z());
	lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(tmp__6, lang.IFn_Cast(printed__3).Invoke_O__O(index__5)); if
	jrt.NN(jrt.File_Cast(tmp__6)).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__6)).Delete__Z()).Ref() } }
//line :178:1
func A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Ctor_O(c__printed any) { t.F_printed = c__printed }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Invoke_O_O__O(self, p1__1901000085_SHARP___1 any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var tmp2 any; var root_462 any = A_arbace_build_go_A_const_76.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = lang.IFn_Cast(t.F_printed).Invoke_O__O(p1__1901000085_SHARP___1); if linked_463 == nil { tmp2 = ifn_464.Invoke_O__O(arg_465) } else { tmp2 = linked_463.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_462, arg_465) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__1901000085_SHARP___1, tmp2)).Ref() }
//line :178:1
	return nil }(); if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :178:1
func A_arbace_build_go_write_index_BANG__printed__1901000087_A_New() *A_arbace_build_go_write_index_BANG__printed__1901000087_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__printed__1901000087_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Ctor() {}
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Invoke_O_O__O(self, p1__1901000084_SHARP___1 any) any { var root_457 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; var arg_460 any = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_build_go_A_const_73, jrt.Boolean_TRUE.Ref(), A_arbace_build_go_A_const_74, nil, A_arbace_build_go_A_const_75, nil); if linked_458 == nil { ifn_459.Invoke_O__O(arg_460) } else { linked_458.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_457, arg_460) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(p1__1901000084_SHARP___1); return nil }(); var root_445 any = A_arbace_build_go_A_const_70.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; if linked_446 == nil { ifn_447.Invoke__O() } else { linked_446.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_445) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__fn__1901000091_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__fn__1901000091_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Ctor_O(c__ok_QMARK_ any) { t.F_ok_QMARK_ = c__ok_QMARK_ }
//line :180:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Invoke_O_O__O(self, p1__1901000086_SHARP___1 any) any { var root_480 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_480, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_482 lang.IFn; if linked_481 == nil { ifn_482 = lang.IFn_Cast(root_480) } else { ifn_482 = nil }; var arg_483 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_484 any; var root_476 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_476, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_478 lang.IFn; if linked_477 == nil { ifn_478 = lang.IFn_Cast(root_476) } else { ifn_478 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()); var tmp2 any = t.F_ok_QMARK_; var tmp3 any = A_arbace_build_go_A_const_82; var arg_479 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_build_go_A_const_83.GetRawRoot__O()); if linked_477 == nil { arg_484 = ifn_478.Invoke_O__O(arg_479) } else { arg_484 = linked_477.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_476, arg_479) }; var arg_485 any = p1__1901000086_SHARP___1; if linked_481 == nil { return ifn_482.Invoke_O_O_O__O(arg_483, arg_484, arg_485) } else { return linked_481.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_480, arg_483, arg_484, arg_485) } }





func A_arbace_build_go_root_packages_A_New() *A_arbace_build_go_root_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_build_go_root_packages_A) Ctor() {}
//line :186:1
func (t *A_arbace_build_go_root_packages_A) Invoke_O_O_O__O(self, dir__0, print_cache__1 any) any { var root__3 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_132); if




	jrt.NN(jrt.File_Cast(root__3)).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_133, nil, Lit_134), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref(), nil)).Ref()) }; var files__4 any; var root_498 any = /*line :186:1*/A_arbace_build_go_A_const_85.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, A_arbace_build_go_clj_files_A_fn_class); var ifn_500 lang.IFn; if






	linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = root__3; if linked_499 == nil { files__4 = ifn_500.Invoke_O__O(arg_501) } else { files__4 = linked_499.(*A_arbace_build_go_clj_files_A).Invoke_O_O__O(root_498, arg_501) }; var host_id__5 any = /*line :186:1*/jrt.System_Getenv_String__String(Lit_107).Ref(); var index_file__6 any; var tmp1 any; var and__1927000168__auto____6 any = print_cache__1; if








	jrt.J2g_Truth(and__1927000168__auto____6) { var root_502 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = host_id__5; if linked_503 == nil { tmp1 = ifn_504.Invoke_O__O(arg_505) } else { tmp1 = linked_503.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_502, arg_505) } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { var root_506 any = A_arbace_build_go_A_const_86.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_build_go_collect_index_file_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = print_cache__1; var arg_510 any = host_id__5; var arg_511 any = dir__0; if linked_507 == nil { index_file__6 = ifn_508.Invoke_O_O_O__O(arg_509, arg_510, arg_511) } else { index_file__6 = linked_507.(*A_arbace_build_go_collect_index_file_A).Invoke_O_O_O_O__O(root_506, arg_509, arg_510, arg_511) } } else { index_file__6 = nil }; var index__7 any; if
	jrt.J2g_Truth(index_file__6) { var or__1927000174__auto____7 any; var root_512 any = A_arbace_build_go_A_const_87.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_build_go_read_index_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = index_file__6; if linked_513 == nil { or__1927000174__auto____7 = ifn_514.Invoke_O__O(arg_515) } else { or__1927000174__auto____7 = linked_513.(*A_arbace_build_go_read_index_A).Invoke_O_O__O(root_512, arg_515) }; if jrt.J2g_Truth(or__1927000174__auto____7) { index__7 = or__1927000174__auto____7 } else { index__7 = lang.PersistentArrayMap_EMPTY.Ref() } } else { index__7 = nil }; var shas__8 any; if
	jrt.J2g_Truth(index_file__6) { var m__8 any; var root_527 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_529 lang.IFn
		if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any; var root_517 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_518 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_517, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_519 lang.IFn; if linked_518 == nil { ifn_519 = lang.IFn_Cast(root_517) } else { ifn_519 = nil }; var arg_520 any; var tmp2 any = A_arbace_build_go_root_packages_fn__1901000099_A_New(); var tmp3 *jrt.Class; var fncls__516 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000099_A_fn_class; if fncls__516 == nil { var fncls__516d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_build_go_root_packages_fn__1901000099_A_fn_class = fncls__516d; tmp3 = fncls__516d } else { tmp3 = fncls__516 }; arg_520 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_521 any = files__4; if linked_518 == nil { arg_530 = ifn_519.Invoke_O_O__O(arg_520, arg_521) } else { arg_530 = linked_518.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_517, arg_520, arg_521) }; var arg_531 any; var root_522 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_523 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_522, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_524 lang.IFn; if linked_523 == nil { ifn_524 = lang.IFn_Cast(root_522) } else { ifn_524 = nil }; var arg_525 any = A_arbace_build_go_A_const_88.GetRawRoot__O(); var arg_526 any = files__4; if linked_523 == nil { arg_531 = ifn_524.Invoke_O_O__O(arg_525, arg_526) } else { arg_531 = linked_523.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_522, arg_525, arg_526) }; if linked_528 == nil { m__8 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { m__8 = linked_528.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }
		var tmp4 any = A_arbace_build_go_root_packages_fn__1901000101_A_New_O(m__8); var tmp5 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000101_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_build_go_root_packages_fn__1901000101_A_fn_class = fncls__541d; tmp5 = fncls__541d } else { tmp5 = fncls__541 }; shas__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
//line :197:1
			shas__8 = nil }; var valid__9 any; if


	jrt.J2g_Truth(index_file__6) {
		var root_617 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_617, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_619 lang.IFn; if linked_618 == nil { ifn_619 = lang.IFn_Cast(root_617) } else { ifn_619 = nil }; var arg_620 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_621 any; var iter__1927001039__auto____9 any; var tmp6 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(shas__8); var tmp7 *jrt.Class; var fncls__616 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class; if fncls__616 == nil { var fncls__616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class = fncls__616d; tmp7 = fncls__616d } else { tmp7 = fncls__616 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_621 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_build_go_A_const_78.Invoke_O__O(index__7)); if linked_618 == nil { valid__9 = ifn_619.Invoke_O_O__O(arg_620, arg_621) } else { valid__9 = linked_618.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_617, arg_620, arg_621) } } else {
//line :200:1
			valid__9 = nil }; var covered__10 any; var root_708 any = /*line :186:1*/A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_708, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_710 lang.IFn; if

















	linked_709 == nil { ifn_710 = lang.IFn_Cast(root_708) } else { ifn_710 = nil }; var arg_711 any; var iter__1927001039__auto____10 any; var tmp8 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New(); var tmp9 *jrt.Class; var fncls__707 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class; if fncls__707 == nil { var fncls__707d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class = fncls__707d; tmp9 = fncls__707d } else { tmp9 = fncls__707 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_711 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(valid__9); if linked_709 == nil { covered__10 = ifn_710.Invoke_O__O(arg_711) } else { covered__10 = linked_709.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_708, arg_711) }; var pf_index__11 any = /*line :186:1*/A_arbace_build_go_A_const_91.Invoke_O__O(index__7); var known_QMARK___12 any; var tmp10 any = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(index_file__6, pf_index__11, shas__8); var tmp11 *jrt.Class; var fncls__717 *jrt.Class = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class; if






	fncls__717 == nil { var fncls__717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class = fncls__717d; tmp11 = fncls__717d } else { tmp11 = fncls__717 }; known_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var read_fn__13 any; var root_728 any = /*line :186:1*/A_arbace_build_go_A_const_92.GetRawRoot__O(); var linked_729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_728, A_arbace_build_go_read_all_A_fn_class); var ifn_730 lang.IFn; if




















	linked_729 == nil { ifn_730 = lang.IFn_Cast(root_728) } else { ifn_730 = nil }; var arg_731 any; var root_723 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_723, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_725 lang.IFn; if linked_724 == nil { ifn_725 = lang.IFn_Cast(root_723) } else { ifn_725 = nil }; var arg_726 any; var tmp12 any = A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(covered__10, known_QMARK___12); var tmp13 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000158_A_fn_class; if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_build_go_root_packages_fn__1901000158_A_fn_class = fncls__722d; tmp13 = fncls__722d } else { tmp13 = fncls__722 }; arg_726 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_727 any = files__4; if linked_724 == nil { arg_731 = ifn_725.Invoke_O_O__O(arg_726, arg_727) } else { arg_731 = linked_724.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_723, arg_726, arg_727) }; if linked_729 == nil { read_fn__13 = ifn_730.Invoke_O__O(arg_731) } else { read_fn__13 = linked_729.(*A_arbace_build_go_read_all_A).Invoke_O_O__O(root_728, arg_731) }; var pkg_file_QMARK___14 any; var tmp14 any = /*line :186:1*/A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(read_fn__13, known_QMARK___12, pf_index__11, shas__8); var tmp15 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class; if





















	fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class = fncls__737d; tmp15 = fncls__737d } else { tmp15 = fncls__737 }; pkg_file_QMARK___14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var pkgs__15 any; var root_867 any = /*line :186:1*/A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_869 lang.IFn; if























	linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any; var iter__1927001039__auto____15 any; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(pkg_file_QMARK___14, read_fn__13, dir__0, valid__9); var tmp17 *jrt.Class; var fncls__866 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class; if fncls__866 == nil { var fncls__866d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class = fncls__866d; tmp17 = fncls__866d } else { tmp17 = fncls__866 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); arg_870 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__4); if linked_868 == nil { pkgs__15 = ifn_869.Invoke_O__O(arg_870) } else { pkgs__15 = linked_868.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_867, arg_870) }; var tmp18 any; var root_875 any =




	A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = pkgs__15; if linked_876 == nil { tmp18 = ifn_877.Invoke_O__O(arg_878) } else { tmp18 = linked_876.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_875, arg_878) }; if jrt.J2g_Truth(tmp18) {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref())).Ref()) }; var seq_1901000180__16 any; var root_888 any = /*line :186:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_888, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_890 lang.IFn; if






























	linked_889 == nil { ifn_890 = lang.IFn_Cast(root_888) } else { ifn_890 = nil }; var arg_891 any; var root_883 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_885 lang.IFn; if linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any = A_arbace_build_go_A_const_46; var arg_887 any = pkgs__15; if linked_884 == nil { arg_891 = ifn_885.Invoke_O_O__O(arg_886, arg_887) } else { arg_891 = linked_884.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_883, arg_886, arg_887) }; if linked_889 == nil { seq_1901000180__16 = ifn_890.Invoke_O__O(arg_891) } else { seq_1901000180__16 = linked_889.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_888, arg_891) }; var chunk_1901000181__17 any; var count_1901000182__18 int64 = 0; var i_1901000183__19 int64 = 0; L1:
//line :186:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000183__19, count_1901000182__18) { var vec__1901000184__20 any = lang.Indexed_Cast(chunk_1901000181__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000183__19)); var path__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__22)), 1) {
			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp21 any; var root_1084 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1084, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1086 lang.IFn
			if linked_1085 == nil { ifn_1086 = lang.IFn_Cast(root_1084) } else { ifn_1086 = nil }; var arg_1087 any = Lit_87; var arg_1088 any; var root_1079 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1080 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1079, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1081 lang.IFn; if linked_1080 == nil { ifn_1081 = lang.IFn_Cast(root_1079) } else { ifn_1081 = nil }; var arg_1082 any; var tmp22 any = A_arbace_build_go_root_packages_fn__1901000187_A_New_O(dir__0); var tmp23 *jrt.Class; var fncls__1078 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000187_A_fn_class; if fncls__1078 == nil { var fncls__1078d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_build_go_root_packages_fn__1901000187_A_fn_class = fncls__1078d; tmp23 = fncls__1078d } else { tmp23 = fncls__1078 }; arg_1082 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1083 any = ps__22; if linked_1080 == nil { arg_1088 = ifn_1081.Invoke_O_O__O(arg_1082, arg_1083) } else { arg_1088 = linked_1080.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1079, arg_1082, arg_1083) }; if linked_1085 == nil { tmp21 = ifn_1086.Invoke_O_O__O(arg_1087, arg_1088) } else { tmp21 = linked_1085.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1084, arg_1087, arg_1088) }
//line :218:1
			tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, path__21, nil, tmp21)).Ref())
//line :217:1
			seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } else { seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } } else { var temp__1927000414__auto____20 any; var root_892 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = seq_1901000180__16; if linked_893 == nil { temp__1927000414__auto____20 = ifn_894.Invoke_O__O(arg_895) } else { temp__1927000414__auto____20 = linked_893.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_892, arg_895) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1901000180__21 any = temp__1927000414__auto____20; var tmp24 any; var root_896 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = seq_1901000180__21; if linked_897 == nil { tmp24 = ifn_898.Invoke_O__O(arg_899) } else { tmp24 = linked_897.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_896, arg_899) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____22 any; var root_900 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = seq_1901000180__21; if linked_901 == nil { c__1927000678__auto____22 = ifn_902.Invoke_O__O(arg_903) } else { c__1927000678__auto____22 = linked_901.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_900, arg_903) }; var tmp25 any; var root_1093 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = seq_1901000180__21; if linked_1094 == nil { tmp25 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp25 = linked_1094.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1093, arg_1096) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp25, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000189__22 any; var root_904 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = seq_1901000180__21; if linked_905 == nil { vec__1901000189__22 = ifn_906.Invoke_O__O(arg_907) } else { vec__1901000189__22 = linked_905.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_904, arg_907) }; var path__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__24)), 1) {
				var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp27 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp28 any; var root_1108 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1108, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1110 lang.IFn
				if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any = Lit_87; var arg_1112 any; var root_1103 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any; var tmp29 any = A_arbace_build_go_root_packages_fn__1901000192_A_New_O(dir__0); var tmp30 *jrt.Class; var fncls__1102 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000192_A_fn_class; if fncls__1102 == nil { var fncls__1102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_build_go_root_packages_fn__1901000192_A_fn_class = fncls__1102d; tmp30 = fncls__1102d } else { tmp30 = fncls__1102 }; arg_1106 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var arg_1107 any = ps__24; if linked_1104 == nil { arg_1112 = ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { arg_1112 = linked_1104.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) }; if linked_1109 == nil { tmp28 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { tmp28 = linked_1109.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }
//line :218:1
				tmp26.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp27, jrt.RefArrayOf(jrt.Object_class, nil, path__23, nil, tmp28)).Ref())
//line :217:1
				var tmp31 any; var root_1117 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = seq_1901000180__21; if linked_1118 == nil { tmp31 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp31 = linked_1118.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1117, arg_1120) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp31, nil, 0, 0; continue L1 } else { var tmp32 any; var root_1121 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = seq_1901000180__21; if linked_1122 == nil { tmp32 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp32 = linked_1122.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1121, arg_1124) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp32, nil, 0, 0; continue L1 } } } }
//line :186:1
		break L1 }; if

































	jrt.J2g_Truth(index_file__6) { var index_SINGLEQUOTE___16 any; var tmp33 any = A_arbace_build_go_A_const_91; var tmp34 any; var root_974 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_974, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_976 lang.IFn
		if linked_975 == nil { ifn_976 = lang.IFn_Cast(root_974) } else { ifn_976 = nil }; var arg_977 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_978 any; var iter__1927001039__auto____16 any; var tmp35 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(pkg_file_QMARK___14, shas__8); var tmp36 *jrt.Class; var fncls__973 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class
		if fncls__973 == nil { var fncls__973d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class = fncls__973d; tmp36 = fncls__973d } else { tmp36 = fncls__973 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_978 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(files__4)
//line :221:1
		if linked_975 == nil { tmp34 = ifn_976.Invoke_O_O__O(arg_977, arg_978) } else { tmp34 = linked_975.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_974, arg_977, arg_978) }
//line :220:1
		var tmp37 any = tmp34; var tmp38 any = A_arbace_build_go_A_const_78; var tmp39 any; var root_1063 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1065 lang.IFn



		if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_1067 any; var iter__1927001039__auto____16_2 any; var tmp40 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(shas__8); var tmp41 *jrt.Class; var fncls__1062 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class
		if fncls__1062 == nil { var fncls__1062d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class = fncls__1062d; tmp41 = fncls__1062d } else { tmp41 = fncls__1062 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); arg_1067 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(pkgs__15)
//line :224:1
		if linked_1064 == nil { tmp39 = ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { tmp39 = linked_1064.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) }
//line :220:1
		index_SINGLEQUOTE___16 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp37, tmp38, tmp39))








		if lang.Util_Equiv_O_O__Z_NoInit(index_SINGLEQUOTE___16, index__7) { } else {
			var root_1068 any = A_arbace_build_go_A_const_101.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, A_arbace_build_go_write_index_BANG__A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = index_file__6; var arg_1072 any = index_SINGLEQUOTE___16; if linked_1069 == nil { ifn_1070.Invoke_O_O__O(arg_1071, arg_1072) } else { linked_1069.(*A_arbace_build_go_write_index_BANG__A).Invoke_O_O_O__O(root_1068, arg_1071, arg_1072) } } }; return pkgs__15 }
//line :193:1
func A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_known_QMARK___1901000156_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_known_QMARK___1901000156_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :193:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Ctor_O_O_O(c__index_file, c__pf_index, c__shas any) { t.F_index_file = c__index_file; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :193:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Invoke_O_O__O(self, p1__1901000095_SHARP___1 any) any { var and__1927000168__auto____2 any = t.F_index_file; if












	jrt.J2g_Truth(and__1927000168__auto____2) { var root_712 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = t.F_pf_index; var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); var arg_716 any = tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000095_SHARP___1)).GetPath__String().Ref()); if linked_713 == nil { return ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { return linked_713.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_712, arg_715, arg_716) } } else { return and__1927000168__auto____2 } }
//line :198:1
func A_arbace_build_go_root_packages_fn__1901000099_A_New() *A_arbace_build_go_root_packages_fn__1901000099_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000099_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Ctor() {}
//line :198:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Invoke_O_O__O(self, p1__1901000094_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000094_SHARP___1)).GetPath__String().Ref() }
func A_arbace_build_go_root_packages_fn__1901000101_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000101_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000101_A{}; t.Ctor_O(p0); return t }
//line :199:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :199:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_532 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = t.F_m; var arg_536 any = path__1; if linked_533 == nil { tmp1 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { tmp1 = linked_533.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_m, path__1) } else { var root_537 any = A_arbace_build_go_A_const_88.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_build_go_file_sha_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = jrt.File_New_String(jrt.String_Cast(path__1)); if linked_538 == nil { return ifn_539.Invoke_O__O(arg_540) } else { return linked_538.(*A_arbace_build_go_file_sha_A).Invoke_O_O__O(root_537, arg_540) } } }

func A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Invoke_O_O__O(self, s__1901000104__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(s__1901000104__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__615 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class; if fncls__615 == nil { var fncls__615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class = fncls__615d; tmp2 = fncls__615d } else { tmp2 = fncls__615 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :201:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Ctor_O_O_O(c__s__1901000104, c__iter__1901000103, c__shas any) { t.F_s__1901000104 = c__s__1901000104; t.F_iter__1901000103 = c__iter__1901000103; t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Invoke_O__O(self any) any { { var s__1901000104__1 any; var t_ any = t.F_s__1901000104; t.F_s__1901000104 = nil; s__1901000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_542 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = s__1901000104__1; if linked_543 == nil { temp__1927000414__auto____2 = ifn_544.Invoke_O__O(arg_545) } else { temp__1927000414__auto____2 = linked_543.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_542, arg_545) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_546 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_548 lang.IFn; if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any = s__1901000104__3; if linked_547 == nil { tmp1 = ifn_548.Invoke_O__O(arg_549) } else { tmp1 = linked_547.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_546, arg_549) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_550 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_551 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_550, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_552 lang.IFn; if linked_551 == nil { ifn_552 = lang.IFn_Cast(root_550) } else { ifn_552 = nil }; var arg_553 any = s__1901000104__3; if linked_551 == nil { c__1927001037__auto____4 = ifn_552.Invoke_O__O(arg_553) } else { c__1927001037__auto____4 = linked_551.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_550, arg_553) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000106__6 any; var root_554 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_555 == nil { b__1901000106__6 = ifn_556.Invoke_O__O(arg_557) } else { b__1901000106__6 = linked_555.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_554, arg_557) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(b__1901000106__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__569 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class; if fncls__569 == nil { var fncls__569d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class = fncls__569d; tmp3 = fncls__569d } else { tmp3 = fncls__569 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_578 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_579 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_578, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_580 lang.IFn; if linked_579 == nil { ifn_580 = lang.IFn_Cast(root_578) } else { ifn_580 = nil }; var arg_581 any; var root_570 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_570, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_572 lang.IFn; if linked_571 == nil { ifn_572 = lang.IFn_Cast(root_570) } else { ifn_572 = nil }; var arg_573 any = b__1901000106__6; if linked_571 == nil { arg_581 = ifn_572.Invoke_O__O(arg_573) } else { arg_581 = linked_571.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_570, arg_573) }; var arg_582 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp5 any; var root_574 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = s__1901000104__3; if linked_575 == nil { tmp5 = ifn_576.Invoke_O__O(arg_577) } else { tmp5 = linked_575.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_574, arg_577) }; arg_582 = tmp4.Invoke_O__O(tmp5); if linked_579 == nil { return ifn_580.Invoke_O_O__O(arg_581, arg_582) } else { return linked_579.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_578, arg_581, arg_582) } } else { var root_587 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var root_583 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = b__1901000106__6; if linked_584 == nil { arg_590 = ifn_585.Invoke_O__O(arg_586) } else { arg_590 = linked_584.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_583, arg_586) }; var arg_591 any; if linked_588 == nil { return ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { return linked_588.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) } } } else { var vec__1901000120__4 any; var root_592 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = s__1901000104__3; if linked_593 == nil { vec__1901000120__4 = ifn_594.Invoke_O__O(arg_595) } else { vec__1901000120__4 = linked_593.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_592, arg_595) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_597 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_599 lang.IFn
															if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any; var tmp7 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(t.F_shas); var tmp8 *jrt.Class; var fncls__596 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class; if fncls__596 == nil { var fncls__596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class = fncls__596d; tmp8 = fncls__596d } else { tmp8 = fncls__596 }; arg_600 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_601 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__6); if linked_598 == nil { tmp6 = ifn_599.Invoke_O_O__O(arg_600, arg_601) } else { tmp6 = linked_598.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_597, arg_600, arg_601) }
//line :201:1
	if jrt.J2g_Truth(tmp6) { var root_606 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_607 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_606, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_608 lang.IFn; if linked_607 == nil { ifn_608 = lang.IFn_Cast(root_606) } else { ifn_608 = nil }; var arg_609 any = lang.Tuple_Create_O_O__IPersistentVector(path__5, e__6); var arg_610 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp10 any; var root_602 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = s__1901000104__3; if linked_603 == nil { tmp10 = ifn_604.Invoke_O__O(arg_605) } else { tmp10 = linked_603.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_602, arg_605) }; arg_610 = tmp9.Invoke_O__O(tmp10); if linked_607 == nil { return ifn_608.Invoke_O_O__O(arg_609, arg_610) } else { return linked_607.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_606, arg_609, arg_610) } } else { var tmp11 any; var root_611 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_611, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_613 lang.IFn; if linked_612 == nil { ifn_613 = lang.IFn_Cast(root_611) } else { ifn_613 = nil }; var arg_614 any = s__1901000104__3; if linked_612 == nil { tmp11 = ifn_613.Invoke_O__O(arg_614) } else { tmp11 = linked_612.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_611, arg_614) }; s__1901000104__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :201:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Ctor_O_I_O_O(c__b__1901000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000106 = c__b__1901000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Invoke_O__O(self any) any { { var i__1901000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000105__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_559 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_561 lang.IFn
																	if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any; var tmp3 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(t.F_shas); var tmp4 *jrt.Class; var fncls__558 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class; if fncls__558 == nil { var fncls__558d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class = fncls__558d; tmp4 = fncls__558d } else { tmp4 = fncls__558 }; arg_562 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_563 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__4); if linked_560 == nil { tmp2 = ifn_561.Invoke_O_O__O(arg_562, arg_563) } else { tmp2 = linked_560.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_559, arg_562, arg_563) }
//line :201:1
	if jrt.J2g_Truth(tmp2) { var root_564 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_564, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_566 lang.IFn; if linked_565 == nil { ifn_566 = lang.IFn_Cast(root_564) } else { ifn_566 = nil }; var arg_567 any = t.F_b__1901000106; var arg_568 any = lang.Tuple_Create_O_O__IPersistentVector(path__3, e__4); if linked_565 == nil { ifn_566.Invoke_O_O__O(arg_567, arg_568) } else { linked_565.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_564, arg_567, arg_568) }; i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } else { i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Invoke_O_O__O(self, p__1901000113__1 any) any { var vec__1901000115__2 any = p__1901000113__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }
//line :202:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Invoke_O_O__O(self, p__1901000123__1 any) any { var vec__1901000125__2 any = p__1901000123__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }

func A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Ctor() {}
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Invoke_O_O__O(self, s__1901000132__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(self, s__1901000132__1); var tmp2 *jrt.Class; var fncls__706 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class; if fncls__706 == nil { var fncls__706d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class = fncls__706d; tmp2 = fncls__706d } else { tmp2 = fncls__706 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Ctor_O_O(c__iter__1901000131, c__s__1901000132 any) { t.F_iter__1901000131 = c__iter__1901000131; t.F_s__1901000132 = c__s__1901000132 }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Invoke_O__O(self any) any { { var s__1901000132__1 any; var t_ any = t.F_s__1901000132; t.F_s__1901000132 = nil; s__1901000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_622 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any = s__1901000132__1; if linked_623 == nil { temp__1927000414__auto____2 = ifn_624.Invoke_O__O(arg_625) } else { temp__1927000414__auto____2 = linked_623.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_622, arg_625) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1901000139__4 any; var root_626 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = xs__1927001018__auto____3; if linked_627 == nil { vec__1901000139__4 = ifn_628.Invoke_O__O(arg_629) } else { vec__1901000139__4 = linked_627.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_626, arg_629) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New(); var tmp2 *jrt.Class; var fncls__688 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class; _ = ___5; if fncls__688 == nil { var fncls__688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class = fncls__688d; tmp2 = fncls__688d } else { tmp2 = fncls__688 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var root_689 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_689, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_691 lang.IFn; if linked_690 == nil { ifn_691 = lang.IFn_Cast(root_689) } else { ifn_691 = nil }; var arg_692 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(e__6)); if linked_690 == nil { fs__1927001036__auto____8 = ifn_691.Invoke_O__O(arg_692) } else { fs__1927001036__auto____8 = linked_690.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_689, arg_692) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_697 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = fs__1927001036__auto____8; var arg_701 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000131); var tmp4 any; var root_693 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = s__1901000132__1; if linked_694 == nil { tmp4 = ifn_695.Invoke_O__O(arg_696) } else { tmp4 = linked_694.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_693, arg_696) }; arg_701 = tmp3.Invoke_O__O(tmp4); if linked_698 == nil { return ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { return linked_698.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) } } else { var tmp5 any; var root_702 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = s__1901000132__1; if linked_703 == nil { tmp5 = ifn_704.Invoke_O__O(arg_705) } else { tmp5 = linked_703.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_702, arg_705) }; s__1901000132__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Ctor() {}
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Invoke_O_O__O(self, s__1901000134__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(self, s__1901000134__1); var tmp2 *jrt.Class; var fncls__687 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class; if fncls__687 == nil { var fncls__687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class = fncls__687d; tmp2 = fncls__687d } else { tmp2 = fncls__687 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Ctor_O_O(c__iter__1901000133, c__s__1901000134 any) { t.F_iter__1901000133 = c__iter__1901000133; t.F_s__1901000134 = c__s__1901000134 }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Invoke_O__O(self any) any { { var s__1901000134__1 any; var t_ any = t.F_s__1901000134; t.F_s__1901000134 = nil; s__1901000134__1 = t_; for { var temp__1927000414__auto____2 any; var root_630 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = s__1901000134__1; if linked_631 == nil { temp__1927000414__auto____2 = ifn_632.Invoke_O__O(arg_633) } else { temp__1927000414__auto____2 = linked_631.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_630, arg_633) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000134__3 any = temp__1927000414__auto____2; var tmp1 any; var root_634 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = s__1901000134__3; if linked_635 == nil { tmp1 = ifn_636.Invoke_O__O(arg_637) } else { tmp1 = linked_635.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_634, arg_637) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_638 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = s__1901000134__3; if linked_639 == nil { c__1927001037__auto____4 = ifn_640.Invoke_O__O(arg_641) } else { c__1927001037__auto____4 = linked_639.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_638, arg_641) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000136__6 any; var root_642 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_643 == nil { b__1901000136__6 = ifn_644.Invoke_O__O(arg_645) } else { b__1901000136__6 = linked_643.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_642, arg_645) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(b__1901000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__651 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class; if fncls__651 == nil { var fncls__651d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class = fncls__651d; tmp3 = fncls__651d } else { tmp3 = fncls__651 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_660 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_660, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_662 lang.IFn; if linked_661 == nil { ifn_662 = lang.IFn_Cast(root_660) } else { ifn_662 = nil }; var arg_663 any; var root_652 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_652, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_654 lang.IFn; if linked_653 == nil { ifn_654 = lang.IFn_Cast(root_652) } else { ifn_654 = nil }; var arg_655 any = b__1901000136__6; if linked_653 == nil { arg_663 = ifn_654.Invoke_O__O(arg_655) } else { arg_663 = linked_653.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_652, arg_655) }; var arg_664 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp5 any; var root_656 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any = s__1901000134__3; if linked_657 == nil { tmp5 = ifn_658.Invoke_O__O(arg_659) } else { tmp5 = linked_657.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_656, arg_659) }; arg_664 = tmp4.Invoke_O__O(tmp5); if linked_661 == nil { return ifn_662.Invoke_O_O__O(arg_663, arg_664) } else { return linked_661.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_660, arg_663, arg_664) } } else { var root_669 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any; var root_665 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = b__1901000136__6; if linked_666 == nil { arg_672 = ifn_667.Invoke_O__O(arg_668) } else { arg_672 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_665, arg_668) }; var arg_673 any; if linked_670 == nil { return ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { return linked_670.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) } } } else { var vec__1901000149__4 any; var root_674 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = s__1901000134__3; if linked_675 == nil { vec__1901000149__4 = ifn_676.Invoke_O__O(arg_677) } else { vec__1901000149__4 = linked_675.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_674, arg_677) }; var rp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000149__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_682 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = rp__5; var arg_686 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp7 any; var root_678 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = s__1901000134__3; if linked_679 == nil { tmp7 = ifn_680.Invoke_O__O(arg_681) } else { tmp7 = linked_679.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_678, arg_681) }; arg_686 = tmp6.Invoke_O__O(tmp7); if linked_683 == nil { return ifn_684.Invoke_O_O__O(arg_685, arg_686) } else { return linked_683.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_682, arg_685, arg_686) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Ctor_O_I_O(c__b__1901000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000136 = c__b__1901000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Invoke_O__O(self any) any { { var i__1901000135__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000145__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000135__1)); var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000145__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_646 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = t.F_b__1901000136; var arg_650 any = rp__3; if linked_647 == nil { ifn_648.Invoke_O_O__O(arg_649, arg_650) } else { linked_647.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_646, arg_649, arg_650) }; i__1901000135__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000135__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_fn__1901000158_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Ctor_O_O(c__covered, c__known_QMARK_ any) { t.F_covered = c__covered; t.F_known_QMARK_ = c__known_QMARK_ }
//line :207:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Invoke_O_O__O(self, p1__1901000096_SHARP___1 any) any { var root_718 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any; var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(p1__1901000096_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_covered); arg_721 = tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000096_SHARP___1)).GetPath__String().Ref()) } else { arg_721 = and__1927000168__auto____2 }; if linked_719 == nil { return ifn_720.Invoke_O__O(arg_721) } else { return linked_719.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_718, arg_721) } }
func A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :208:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Ctor_O_O_O_O(c__read_fn, c__known_QMARK_, c__pf_index, c__shas any) { t.F_read_fn = c__read_fn; t.F_known_QMARK_ = c__known_QMARK_; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :208:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Invoke_O_O__O(self, f__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(f__1)) { var tmp1 any = t.F_pf_index; var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__1)).GetPath__String().Ref())) } else { var root_732 any = A_arbace_build_go_A_const_93.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, A_arbace_build_go_package_file_QMARK__A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = f__1; var arg_736 any = t.F_read_fn; if linked_733 == nil { return ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { return linked_733.(*A_arbace_build_go_package_file_QMARK__A).Invoke_O_O_O__O(root_732, arg_735, arg_736) } } }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Invoke_O_O__O(self, s__1901000163__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(t.F_pkg_file_QMARK_, t.F_read_fn, t.F_dir, t.F_valid, s__1901000163__1, self); var tmp2 *jrt.Class; var fncls__865 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class; if fncls__865 == nil { var fncls__865d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class = fncls__865d; tmp2 = fncls__865d } else { tmp2 = fncls__865 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :210:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Ctor_O_O_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid, c__s__1901000163, c__iter__1901000162 any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid; t.F_s__1901000163 = c__s__1901000163; t.F_iter__1901000162 = c__iter__1901000162 }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Invoke_O__O(self any) any { { var s__1901000163__1 any; var t_ any = t.F_s__1901000163; t.F_s__1901000163 = nil; s__1901000163__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_738 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_740 lang.IFn; if linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any = s__1901000163__1; if linked_739 == nil { temp__1927000414__auto____2 = ifn_740.Invoke_O__O(arg_741) } else { temp__1927000414__auto____2 = linked_739.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_738, arg_741) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000163__3 any = temp__1927000414__auto____2; var tmp1 any; var root_742 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__1901000163__3; if linked_743 == nil { tmp1 = ifn_744.Invoke_O__O(arg_745) } else { tmp1 = linked_743.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_746 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = s__1901000163__3; if linked_747 == nil { c__1927001037__auto____4 = ifn_748.Invoke_O__O(arg_749) } else { c__1927001037__auto____4 = linked_747.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_746, arg_749) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000165__6 any; var root_750 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_751 == nil { b__1901000165__6 = ifn_752.Invoke_O__O(arg_753) } else { b__1901000165__6 = linked_751.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_750, arg_753) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(t.F_pkg_file_QMARK_, t.F_read_fn, b__1901000165__6, t.F_dir, t.F_valid, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__792 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class; if fncls__792 == nil { var fncls__792d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class = fncls__792d; tmp3 = fncls__792d } else { tmp3 = fncls__792 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_801 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_802 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_801, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_803 lang.IFn; if linked_802 == nil { ifn_803 = lang.IFn_Cast(root_801) } else { ifn_803 = nil }; var arg_804 any; var root_793 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_794 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_793, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_795 lang.IFn; if linked_794 == nil { ifn_795 = lang.IFn_Cast(root_793) } else { ifn_795 = nil }; var arg_796 any = b__1901000165__6; if linked_794 == nil { arg_804 = ifn_795.Invoke_O__O(arg_796) } else { arg_804 = linked_794.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_793, arg_796) }; var arg_805 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp5 any; var root_797 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any = s__1901000163__3; if linked_798 == nil { tmp5 = ifn_799.Invoke_O__O(arg_800) } else { tmp5 = linked_798.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_797, arg_800) }; arg_805 = tmp4.Invoke_O__O(tmp5); if linked_802 == nil { return ifn_803.Invoke_O_O__O(arg_804, arg_805) } else { return linked_802.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_801, arg_804, arg_805) } } else { var root_810 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var root_806 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = b__1901000165__6; if linked_807 == nil { arg_813 = ifn_808.Invoke_O__O(arg_809) } else { arg_813 = linked_807.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_806, arg_809) }; var arg_814 any; if linked_811 == nil { return ifn_812.Invoke_O_O__O(arg_813, arg_814) } else { return linked_811.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_810, arg_813, arg_814) } } } else { var f__4 any; var root_815 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = s__1901000163__3; if linked_816 == nil { f__4 = ifn_817.Invoke_O__O(arg_818) } else { f__4 = linked_816.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_815, arg_818) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4)) { var root_856 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_856, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_858 lang.IFn; if linked_857 == nil { ifn_858 = lang.IFn_Cast(root_856) } else { ifn_858 = nil }; var arg_859 any; var tmp6 any = t.F_valid; var temp__1927000408__auto____5 any = lang.RT_Get_O_O__O_NoInit(tmp6, jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref())
															if jrt.J2g_Truth(temp__1927000408__auto____5) { var e__6 any = temp__1927000408__auto____5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_82.Invoke_O__O(e__6); var tmp9 any = A_arbace_build_go_A_const_50; var tmp10 any = A_arbace_build_go_A_const_64; var tmp11 any; var root_824 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_825 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_824, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_826 lang.IFn
																if linked_825 == nil { ifn_826 = lang.IFn_Cast(root_824) } else { ifn_826 = nil }; var arg_827 any; var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New(); var tmp13 *jrt.Class; var fncls__823 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class; if fncls__823 == nil { var fncls__823d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class = fncls__823d; tmp13 = fncls__823d } else { tmp13 = fncls__823 }; arg_827 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_828 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__6); if linked_825 == nil { tmp11 = ifn_826.Invoke_O_O__O(arg_827, arg_828) } else { tmp11 = linked_825.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_824, arg_827, arg_828) }; var tmp14 any = tmp11; var tmp15 any = A_arbace_build_go_A_const_95; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(f__4, t.F_dir); var tmp17 *jrt.Class; var fncls__835 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class
																if fncls__835 == nil { var fncls__835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class = fncls__835d; tmp17 = fncls__835d } else { tmp17 = fncls__835 }
//line :212:1
		arg_859 = tmp7.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp9, f__4, tmp10, tmp14, tmp15, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil))) } else {

			var root_846 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_846, A_arbace_build_go_collect_package_A_fn_class); var ifn_848 lang.IFn; if linked_847 == nil { ifn_848 = lang.IFn_Cast(root_846) } else { ifn_848 = nil }; var arg_849 any = t.F_dir; var arg_850 any = f__4; var arg_851 any = t.F_read_fn; if linked_847 == nil { arg_859 = ifn_848.Invoke_O_O_O__O(arg_849, arg_850, arg_851) } else { arg_859 = linked_847.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_846, arg_849, arg_850, arg_851) } }
//line :210:1
	var arg_860 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp19 any; var root_852 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_852, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_854 lang.IFn; if linked_853 == nil { ifn_854 = lang.IFn_Cast(root_852) } else { ifn_854 = nil }; var arg_855 any = s__1901000163__3; if linked_853 == nil { tmp19 = ifn_854.Invoke_O__O(arg_855) } else { tmp19 = linked_853.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_852, arg_855) }; arg_860 = tmp18.Invoke_O__O(tmp19); if linked_857 == nil { return ifn_858.Invoke_O_O__O(arg_859, arg_860) } else { return linked_857.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_856, arg_859, arg_860) } } else { var tmp20 any; var root_861 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__1901000163__3; if linked_862 == nil { tmp20 = ifn_863.Invoke_O__O(arg_864) } else { tmp20 = linked_862.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_861, arg_864) }; s__1901000163__1 = tmp20; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :210:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Ctor_O_O_O_O_O_I_O(c__pkg_file_QMARK_, c__read_fn, c__b__1901000165, c__dir, c__valid any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_b__1901000165 = c__b__1901000165; t.F_dir = c__dir; t.F_valid = c__valid; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Invoke_O__O(self any) any { { var i__1901000164__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000164__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000164__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2)) { var root_787 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = t.F_b__1901000165; var arg_791 any; var tmp2 any = t.F_valid; var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O_NoInit(tmp2, jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref())
																	if jrt.J2g_Truth(temp__1927000408__auto____3) { var e__4 any = temp__1927000408__auto____3; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_82.Invoke_O__O(e__4); var tmp5 any = A_arbace_build_go_A_const_50; var tmp6 any = A_arbace_build_go_A_const_64; var tmp7 any; var root_759 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_760 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_759, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_761 lang.IFn
																		if linked_760 == nil { ifn_761 = lang.IFn_Cast(root_759) } else { ifn_761 = nil }; var arg_762 any; var tmp8 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New(); var tmp9 *jrt.Class; var fncls__758 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class; if fncls__758 == nil { var fncls__758d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class = fncls__758d; tmp9 = fncls__758d } else { tmp9 = fncls__758 }; arg_762 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_763 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__4); if linked_760 == nil { tmp7 = ifn_761.Invoke_O_O__O(arg_762, arg_763) } else { tmp7 = linked_760.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_759, arg_762, arg_763) }; var tmp10 any = tmp7; var tmp11 any = A_arbace_build_go_A_const_95; var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(f__2, t.F_dir); var tmp13 *jrt.Class; var fncls__770 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class
																		if fncls__770 == nil { var fncls__770d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class = fncls__770d; tmp13 = fncls__770d } else { tmp13 = fncls__770 }
//line :212:1
		arg_791 = tmp3.Invoke_O_O_O_O_O_O_O__O(tmp4, tmp5, f__2, tmp6, tmp10, tmp11, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))) } else {

			var root_781 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_781, A_arbace_build_go_collect_package_A_fn_class); var ifn_783 lang.IFn; if linked_782 == nil { ifn_783 = lang.IFn_Cast(root_781) } else { ifn_783 = nil }; var arg_784 any = t.F_dir; var arg_785 any = f__2; var arg_786 any = t.F_read_fn; if linked_782 == nil { arg_791 = ifn_783.Invoke_O_O_O__O(arg_784, arg_785, arg_786) } else { arg_791 = linked_782.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_781, arg_784, arg_785, arg_786) } }
//line :210:1
	if linked_788 == nil { ifn_789.Invoke_O_O__O(arg_790, arg_791) } else { linked_788.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_787, arg_790, arg_791) }; i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } else { i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Ctor() {}
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_754 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = p1__1901000097_SHARP___1; if linked_755 == nil { tmp1 = ifn_756.Invoke_O__O(arg_757) } else { tmp1 = linked_755.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_754, arg_757) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
//line :212:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Ctor() {}
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_819 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = p1__1901000097_SHARP___1; if linked_820 == nil { tmp1 = ifn_821.Invoke_O__O(arg_822) } else { tmp1 = linked_820.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_819, arg_822) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Invoke_O__O(self any) any { var root_764 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_764, A_arbace_build_go_collect_package_A_fn_class); var ifn_766 lang.IFn; if linked_765 == nil { ifn_766 = lang.IFn_Cast(root_764) } else { ifn_766 = nil }; var arg_767 any; var t_ any = t.F_dir; t.F_dir = nil; arg_767 = t_; var arg_768 any; var t__2 any = t.F_f; t.F_f = nil; arg_768 = t__2; var arg_769 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); if linked_765 == nil { return ifn_766.Invoke_O_O_O__O(arg_767, arg_768, arg_769) } else { return linked_765.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_764, arg_767, arg_768, arg_769) } }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Invoke_O__O(self any) any { var root_829 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_build_go_collect_package_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var t_ any = t.F_dir; t.F_dir = nil; arg_832 = t_; var arg_833 any; var t__2 any = t.F_f; t.F_f = nil; arg_833 = t__2; var arg_834 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); if linked_830 == nil { return ifn_831.Invoke_O_O_O__O(arg_832, arg_833, arg_834) } else { return linked_830.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_829, arg_832, arg_833, arg_834) } }





func A_arbace_build_go_root_packages_fn__1901000187_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000187_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000187_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1073 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1074 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1073, A_arbace_build_go_rel_path_A_fn_class); var ifn_1075 lang.IFn; if linked_1074 == nil { ifn_1075 = lang.IFn_Cast(root_1073) } else { ifn_1075 = nil }; var arg_1076 any = t.F_dir; var arg_1077 any = A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1074 == nil { return ifn_1075.Invoke_O_O__O(arg_1076, arg_1077) } else { return linked_1074.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1073, arg_1076, arg_1077) } }
//line :219:1
func A_arbace_build_go_root_packages_fn__1901000192_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000192_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000192_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1097 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1097, A_arbace_build_go_rel_path_A_fn_class); var ifn_1099 lang.IFn; if linked_1098 == nil { ifn_1099 = lang.IFn_Cast(root_1097) } else { ifn_1099 = nil }; var arg_1100 any = t.F_dir; var arg_1101 any = A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1098 == nil { return ifn_1099.Invoke_O_O__O(arg_1100, arg_1101) } else { return linked_1098.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1097, arg_1100, arg_1101) } }


func A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Ctor_O_O(c__pkg_file_QMARK_, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Invoke_O_O__O(self, s__1901000195__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(t.F_pkg_file_QMARK_, s__1901000195__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__972 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class; if fncls__972 == nil { var fncls__972d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class = fncls__972d; tmp2 = fncls__972d } else { tmp2 = fncls__972 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :222:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__s__1901000195, c__iter__1901000194, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_s__1901000195 = c__s__1901000195; t.F_iter__1901000194 = c__iter__1901000194; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Invoke_O__O(self any) any { { var s__1901000195__1 any; var t_ any = t.F_s__1901000195; t.F_s__1901000195 = nil; s__1901000195__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_911 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = s__1901000195__1; if linked_912 == nil { temp__1927000414__auto____2 = ifn_913.Invoke_O__O(arg_914) } else { temp__1927000414__auto____2 = linked_912.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_911, arg_914) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000195__3 any = temp__1927000414__auto____2; var tmp1 any; var root_915 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = s__1901000195__3; if linked_916 == nil { tmp1 = ifn_917.Invoke_O__O(arg_918) } else { tmp1 = linked_916.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_915, arg_918) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_919 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_919, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_921 lang.IFn; if linked_920 == nil { ifn_921 = lang.IFn_Cast(root_919) } else { ifn_921 = nil }; var arg_922 any = s__1901000195__3; if linked_920 == nil { c__1927001037__auto____4 = ifn_921.Invoke_O__O(arg_922) } else { c__1927001037__auto____4 = linked_920.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_919, arg_922) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000197__6 any; var root_923 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_923, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_925 lang.IFn; if linked_924 == nil { ifn_925 = lang.IFn_Cast(root_923) } else { ifn_925 = nil }; var arg_926 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_924 == nil { b__1901000197__6 = ifn_925.Invoke_O__O(arg_926) } else { b__1901000197__6 = linked_924.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_923, arg_926) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(t.F_pkg_file_QMARK_, b__1901000197__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__932 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class; if fncls__932 == nil { var fncls__932d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class = fncls__932d; tmp3 = fncls__932d } else { tmp3 = fncls__932 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_941 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_941, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_943 lang.IFn; if linked_942 == nil { ifn_943 = lang.IFn_Cast(root_941) } else { ifn_943 = nil }; var arg_944 any; var root_933 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_933, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_935 lang.IFn; if linked_934 == nil { ifn_935 = lang.IFn_Cast(root_933) } else { ifn_935 = nil }; var arg_936 any = b__1901000197__6; if linked_934 == nil { arg_944 = ifn_935.Invoke_O__O(arg_936) } else { arg_944 = linked_934.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_933, arg_936) }; var arg_945 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp5 any; var root_937 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_937, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_939 lang.IFn; if linked_938 == nil { ifn_939 = lang.IFn_Cast(root_937) } else { ifn_939 = nil }; var arg_940 any = s__1901000195__3; if linked_938 == nil { tmp5 = ifn_939.Invoke_O__O(arg_940) } else { tmp5 = linked_938.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_937, arg_940) }; arg_945 = tmp4.Invoke_O__O(tmp5); if linked_942 == nil { return ifn_943.Invoke_O_O__O(arg_944, arg_945) } else { return linked_942.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_941, arg_944, arg_945) } } else { var root_950 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any; var root_946 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_946, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_948 lang.IFn; if linked_947 == nil { ifn_948 = lang.IFn_Cast(root_946) } else { ifn_948 = nil }; var arg_949 any = b__1901000197__6; if linked_947 == nil { arg_953 = ifn_948.Invoke_O__O(arg_949) } else { arg_953 = linked_947.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_946, arg_949) }; var arg_954 any; if linked_951 == nil { return ifn_952.Invoke_O_O__O(arg_953, arg_954) } else { return linked_951.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_950, arg_953, arg_954) } } } else { var f__4 any; var root_955 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = s__1901000195__3; if linked_956 == nil { f__4 = ifn_957.Invoke_O__O(arg_958) } else { f__4 = linked_956.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_955, arg_958) }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__5 any = tmp6.Invoke_O__O(jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__5) { var root_963 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any = lang.Tuple_Create_O_O__IPersistentVector(sha__5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4))).Ref()); var arg_967 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp8 any; var root_959 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = s__1901000195__3; if linked_960 == nil { tmp8 = ifn_961.Invoke_O__O(arg_962) } else { tmp8 = linked_960.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_959, arg_962) }; arg_967 = tmp7.Invoke_O__O(tmp8); if linked_964 == nil { return ifn_965.Invoke_O_O__O(arg_966, arg_967) } else { return linked_964.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_963, arg_966, arg_967) } } else { var tmp9 any; var root_968 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = s__1901000195__3; if linked_969 == nil { tmp9 = ifn_970.Invoke_O__O(arg_971) } else { tmp9 = linked_969.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_968, arg_971) }; s__1901000195__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :222:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Ctor_O_O_I_O_O(c__pkg_file_QMARK_, c__b__1901000197 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_b__1901000197 = c__b__1901000197; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Invoke_O__O(self any) any { { var i__1901000196__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__3 any = tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__3) { var root_927 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = t.F_b__1901000197; var arg_931 any = lang.Tuple_Create_O_O__IPersistentVector(sha__3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2))).Ref()); if linked_928 == nil { ifn_929.Invoke_O_O__O(arg_930, arg_931) } else { linked_928.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_927, arg_930, arg_931) }; i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } else { i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Invoke_O_O__O(self, s__1901000205__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(s__1901000205__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__1061 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class; if fncls__1061 == nil { var fncls__1061d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class = fncls__1061d; tmp2 = fncls__1061d } else { tmp2 = fncls__1061 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Ctor_O_O_O(c__s__1901000205, c__iter__1901000204, c__shas any) { t.F_s__1901000205 = c__s__1901000205; t.F_iter__1901000204 = c__iter__1901000204; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Invoke_O__O(self any) any { { var s__1901000205__1 any; var t_ any = t.F_s__1901000205; t.F_s__1901000205 = nil; s__1901000205__1 = t_; for { var temp__1927000414__auto____2 any; var root_982 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_984 lang.IFn; if linked_983 == nil { ifn_984 = lang.IFn_Cast(root_982) } else { ifn_984 = nil }; var arg_985 any = s__1901000205__1; if linked_983 == nil { temp__1927000414__auto____2 = ifn_984.Invoke_O__O(arg_985) } else { temp__1927000414__auto____2 = linked_983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_982, arg_985) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_986 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_986, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_988 lang.IFn; if linked_987 == nil { ifn_988 = lang.IFn_Cast(root_986) } else { ifn_988 = nil }; var arg_989 any = s__1901000205__3; if linked_987 == nil { tmp1 = ifn_988.Invoke_O__O(arg_989) } else { tmp1 = linked_987.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_986, arg_989) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_990 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_990, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_992 lang.IFn; if linked_991 == nil { ifn_992 = lang.IFn_Cast(root_990) } else { ifn_992 = nil }; var arg_993 any = s__1901000205__3; if linked_991 == nil { c__1927001037__auto____4 = ifn_992.Invoke_O__O(arg_993) } else { c__1927001037__auto____4 = linked_991.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_990, arg_993) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000207__6 any; var root_994 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_994, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_996 lang.IFn; if linked_995 == nil { ifn_996 = lang.IFn_Cast(root_994) } else { ifn_996 = nil }; var arg_997 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_995 == nil { b__1901000207__6 = ifn_996.Invoke_O__O(arg_997) } else { b__1901000207__6 = linked_995.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_994, arg_997) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(b__1901000207__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__1014 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class; if fncls__1014 == nil { var fncls__1014d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class = fncls__1014d; tmp3 = fncls__1014d } else { tmp3 = fncls__1014 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1023 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1024 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1023, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1025 lang.IFn; if linked_1024 == nil { ifn_1025 = lang.IFn_Cast(root_1023) } else { ifn_1025 = nil }; var arg_1026 any; var root_1015 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = b__1901000207__6; if linked_1016 == nil { arg_1026 = ifn_1017.Invoke_O__O(arg_1018) } else { arg_1026 = linked_1016.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1015, arg_1018) }; var arg_1027 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp5 any; var root_1019 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1020 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1019, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1021 lang.IFn; if linked_1020 == nil { ifn_1021 = lang.IFn_Cast(root_1019) } else { ifn_1021 = nil }; var arg_1022 any = s__1901000205__3; if linked_1020 == nil { tmp5 = ifn_1021.Invoke_O__O(arg_1022) } else { tmp5 = linked_1020.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1019, arg_1022) }; arg_1027 = tmp4.Invoke_O__O(tmp5); if linked_1024 == nil { return ifn_1025.Invoke_O_O__O(arg_1026, arg_1027) } else { return linked_1024.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1023, arg_1026, arg_1027) } } else { var root_1032 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any; var root_1028 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1028, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1030 lang.IFn; if linked_1029 == nil { ifn_1030 = lang.IFn_Cast(root_1028) } else { ifn_1030 = nil }; var arg_1031 any = b__1901000207__6; if linked_1029 == nil { arg_1035 = ifn_1030.Invoke_O__O(arg_1031) } else { arg_1035 = linked_1029.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1028, arg_1031) }; var arg_1036 any; if linked_1033 == nil { return ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { return linked_1033.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) } } } else { var pkg__4 any; var root_1037 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = s__1901000205__3; if linked_1038 == nil { pkg__4 = ifn_1039.Invoke_O__O(arg_1040) } else { pkg__4 = linked_1038.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1037, arg_1040) }; var root_1056 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1057 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1056, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1058 lang.IFn; if linked_1057 == nil { ifn_1058 = lang.IFn_Cast(root_1056) } else { ifn_1058 = nil }; var arg_1059 any; var tmp6 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(pkg__4))).GetPath__String().Ref(); var tmp7 any = A_arbace_build_go_A_const_64; var tmp8 any; var root_1042 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1044 lang.IFn

	if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any; var tmp9 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(t.F_shas); var tmp10 *jrt.Class; var fncls__1041 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class; if fncls__1041 == nil { var fncls__1041d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class = fncls__1041d; tmp10 = fncls__1041d } else { tmp10 = fncls__1041 }; arg_1045 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1046 any = A_arbace_build_go_A_const_64.Invoke_O__O(pkg__4); if linked_1043 == nil { tmp8 = ifn_1044.Invoke_O_O__O(arg_1045, arg_1046) } else { tmp8 = linked_1043.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1042, arg_1045, arg_1046) }
//line :225:1
	var tmp11 any = tmp8; var tmp12 any = A_arbace_build_go_A_const_82; var tmp13 any; var root_1047 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1047, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1049 lang.IFn


	if linked_1048 == nil { ifn_1049 = lang.IFn_Cast(root_1047) } else { ifn_1049 = nil }; var arg_1050 any = pkg__4; var arg_1051 any = A_arbace_build_go_A_const_100; if linked_1048 == nil { tmp13 = ifn_1049.Invoke_O_O__O(arg_1050, arg_1051) } else { tmp13 = linked_1048.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1047, arg_1050, arg_1051) }
//line :225:1
	arg_1059 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp11, tmp12, tmp13))); var arg_1060 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp15 any; var root_1052 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1052, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1054 lang.IFn; if linked_1053 == nil { ifn_1054 = lang.IFn_Cast(root_1052) } else { ifn_1054 = nil }; var arg_1055 any = s__1901000205__3; if linked_1053 == nil { tmp15 = ifn_1054.Invoke_O__O(arg_1055) } else { tmp15 = linked_1053.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1052, arg_1055) }; arg_1060 = tmp14.Invoke_O__O(tmp15); if linked_1057 == nil { return ifn_1058.Invoke_O_O__O(arg_1059, arg_1060) } else { return linked_1057.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1056, arg_1059, arg_1060) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Ctor_O_I_O_O(c__b__1901000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000207 = c__b__1901000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Invoke_O__O(self any) any { { var i__1901000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000206__1)); var root_1009 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = t.F_b__1901000207; var arg_1013 any; var tmp2 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(pkg__2))).GetPath__String().Ref(); var tmp3 any = A_arbace_build_go_A_const_64; var tmp4 any; var root_999 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1001 lang.IFn

	if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any; var tmp5 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(t.F_shas); var tmp6 *jrt.Class; var fncls__998 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class; if fncls__998 == nil { var fncls__998d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class = fncls__998d; tmp6 = fncls__998d } else { tmp6 = fncls__998 }; arg_1002 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1003 any = A_arbace_build_go_A_const_64.Invoke_O__O(pkg__2); if linked_1000 == nil { tmp4 = ifn_1001.Invoke_O_O__O(arg_1002, arg_1003) } else { tmp4 = linked_1000.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_999, arg_1002, arg_1003) }
//line :225:1
	var tmp7 any = tmp4; var tmp8 any = A_arbace_build_go_A_const_82; var tmp9 any; var root_1004 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1006 lang.IFn


	if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any = pkg__2; var arg_1008 any = A_arbace_build_go_A_const_99; if linked_1005 == nil { tmp9 = ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { tmp9 = linked_1005.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) }
//line :225:1
	arg_1013 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp7, tmp8, tmp9))); if linked_1010 == nil { ifn_1011.Invoke_O_O__O(arg_1012, arg_1013) } else { linked_1010.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1009, arg_1012, arg_1013) }; i__1901000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }
//line :227:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }





func A_arbace_build_go_collected_package_A_New() *A_arbace_build_go_collected_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collected_package_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_build_go_collected_package_A) Ctor() {}
//line :233:1
func (t *A_arbace_build_go_collected_package_A) Invoke_O_O__O(self, pkg__0 any) any { var temp__1927000408__auto____2 any = A_arbace_build_go_A_const_95.Invoke_O__O(pkg__0); if



	jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var c__4 any; var root_1125 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1127 lang.IFn
		if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = d__3; if linked_1126 == nil { c__4 = ifn_1127.Invoke_O__O(arg_1128) } else { c__4 = linked_1126.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1125, arg_1128) }
		var tmp1 any; var root_1129 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = c__4; var arg_1133 any = A_arbace_build_go_A_const_102; if linked_1130 == nil { tmp1 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp1 = linked_1130.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }; var tmp2 any = tmp1; var tmp3 any; var root_1134 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = pkg__0; var arg_1138 any = A_arbace_build_go_A_const_103; if linked_1135 == nil { tmp3 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { tmp3 = linked_1135.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_56), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__0), nil)).Ref()) }
//line :237:1
		return c__4 } else { return pkg__0 } }






func A_arbace_build_go_read_program_edn_A_New() *A_arbace_build_go_read_program_edn_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_program_edn_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_build_go_read_program_edn_A) Ctor() {}
//line :244:1
func (t *A_arbace_build_go_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_130); if

	jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var forms__3 any; var root_1143 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_1145 lang.IFn
		if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = f__2; if linked_1144 == nil { forms__3 = ifn_1145.Invoke_O__O(arg_1146) } else { forms__3 = linked_1144.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_1143, arg_1146) }
		var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(forms__3))); if and__1927000168__auto____4 { var root_1155 any = A_arbace_build_go_A_const_68.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any; var root_1151 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any = forms__3; if linked_1152 == nil { arg_1158 = ifn_1153.Invoke_O__O(arg_1154) } else { arg_1158 = linked_1152.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1151, arg_1154) }; if linked_1156 == nil { tmp1 = ifn_1157.Invoke_O__O(arg_1158) } else { tmp1 = linked_1156.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1155, arg_1158) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_131) }
		var root_1147 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = forms__3; if linked_1148 == nil { return ifn_1149.Invoke_O__O(arg_1150) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1147, arg_1150) } } else {
//line :246:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_build_go_run_A_New() *A_arbace_build_go_run_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_run_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_build_go_run_A) Ctor() {}
//line :253:1
func (t *A_arbace_build_go_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any; var tmp1 any; var root_1163 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1165 lang.IFn; if



	linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1167 any = cmd__0; if linked_1164 == nil { tmp1 = ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { tmp1 = linked_1164.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) }; pb__5 = /*line :253:1*/jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp1));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :253:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_1901000221__7 any; var root_1172 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1174 lang.IFn; if






	linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = env__2; if linked_1173 == nil { seq_1901000221__7 = ifn_1174.Invoke_O__O(arg_1175) } else { seq_1901000221__7 = linked_1173.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1172, arg_1175) }; var chunk_1901000222__8 any; var count_1901000223__9 int64 = 0; var i_1901000224__10 int64 = 0; L1:
//line :253:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000224__10, count_1901000223__9) { var vec__1901000225__11 any = lang.Indexed_Cast(chunk_1901000222__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000224__10)); var k__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000224__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1176 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = seq_1901000221__7; if linked_1177 == nil { temp__1927000414__auto____11 = ifn_1178.Invoke_O__O(arg_1179) } else { temp__1927000414__auto____11 = linked_1177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1176, arg_1179) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000221__12 any = temp__1927000414__auto____11; var tmp2 any; var root_1180 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = seq_1901000221__12; if linked_1181 == nil { tmp2 = ifn_1182.Invoke_O__O(arg_1183) } else { tmp2 = linked_1181.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1180, arg_1183) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____13 any; var root_1184 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = seq_1901000221__12; if linked_1185 == nil { c__1927000678__auto____13 = ifn_1186.Invoke_O__O(arg_1187) } else { c__1927000678__auto____13 = linked_1185.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1184, arg_1187) }; var tmp3 any; var root_1192 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = seq_1901000221__12; if linked_1193 == nil { tmp3 = ifn_1194.Invoke_O__O(arg_1195) } else { tmp3 = linked_1193.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1192, arg_1195) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp3, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000228__13 any; var root_1188 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = seq_1901000221__12; if linked_1189 == nil { vec__1901000228__13 = ifn_1190.Invoke_O__O(arg_1191) } else { vec__1901000228__13 = linked_1189.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1188, arg_1191) }; var k__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); var tmp4 any; var root_1196 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq_1901000221__12; if linked_1197 == nil { tmp4 = ifn_1198.Invoke_O__O(arg_1199) } else { tmp4 = linked_1197.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1196, arg_1199) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp4, nil, 0, 0; continue L1 } } }
//line :253:1
		break L1 }; if







	jrt.J2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :261:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())
//line :261:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_build_go_go_env_A_New() *A_arbace_build_go_go_env_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_env_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_build_go_go_env_A) Ctor() {}
//line :271:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z_NoInit(goos__2, Lit_28) { var tmp4 *lang.Keyword = A_arbace_build_go_A_const_46; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_64, tmp4.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()))) } else { tmp3 = nil }
//line :277:1
	var tmp5 any = tmp3; var tmp6 any
	var G__1901000232__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1901000232__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_65) { tmp6 = A_arbace_build_go_A_const_106; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_5) { tmp6 = A_arbace_build_go_A_const_107; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1901000232__4_)))))}
//line :277:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :271:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	var root_1207 any = A_arbace_build_go_A_const_108.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, A_arbace_build_go_go_env_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = goroot__0; var arg_1211 any = arch__1; var arg_1212 any = Lit_38; if linked_1208 == nil { return ifn_1209.Invoke_O_O_O__O(arg_1210, arg_1211, arg_1212) } else { return linked_1208.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_1207, arg_1210, arg_1211, arg_1212)
	}
}
























func A_arbace_build_go_go_mod_cache_A_New() *A_arbace_build_go_go_mod_cache_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_mod_cache_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_build_go_go_mod_cache_A) Ctor() {}
//line :302:1
func (t *A_arbace_build_go_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000234__2 any; var root_1213 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, A_arbace_build_go_run_A_fn_class); var ifn_1215 lang.IFn; if
											linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_67, Lit_68); var arg_1217 any = jrt.File_New_String(Lit_69); var arg_1218 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_70, goroot__0, Lit_71, Lit_72)); var arg_1219 any = jrt.Boolean_FALSE.Ref(); if linked_1214 == nil { vec__1901000234__2 = ifn_1215.Invoke_O_O_O_O__O(arg_1216, arg_1217, arg_1218, arg_1219) } else { vec__1901000234__2 = linked_1214.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1213, arg_1216, arg_1217, arg_1218, arg_1219) }; var status__3 any = /*line :302:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_1228 any = status__3; if


	jrt.Long_InstanceOf(na_1228) { var n0_1229 int64 = jrt.NN(jrt.Long_Cast(na_1228)).LongValue__J(); tmp1 = n0_1229 == 0 } else { if jrt.Double_InstanceOf(na_1228) { var n0_1229_2 float64 = jrt.NN(jrt.Double_Cast(na_1228)).DoubleValue__D(); tmp1 = n0_1229_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_1228) } }; if tmp1 { } else { lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; var root_1224 any =
	A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1224, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any; var root_1220 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1220, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any = out__4; if linked_1221 == nil { arg_1227 = ifn_1222.Invoke_O__O(arg_1223) } else { arg_1227 = linked_1221.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1220, arg_1223) }; if linked_1225 == nil { return ifn_1226.Invoke_O__O(arg_1227) } else { return linked_1225.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1224, arg_1227) } }

func A_arbace_build_go_h1_of_file_A_New() *A_arbace_build_go_h1_of_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_build_go_h1_of_file_A) Ctor() {}
//line :308:1
func (t *A_arbace_build_go_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_A_New(); var tmp2 *jrt.Class; var fncls__1255 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class; if


	fncls__1255 == nil { var fncls__1255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class = fncls__1255d; tmp2 = fncls__1255d } else { tmp2 = fncls__1255 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var sha__4 any; var tmp3 any = /*line :308:1*/A_arbace_build_go_h1_of_file_sha__1901000243_A_New(); var tmp4 *jrt.Class; var fncls__1256 *jrt.Class = A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class; if



	fncls__1256 == nil { var fncls__1256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class = fncls__1256d; tmp4 = fncls__1256d } else { tmp4 = fncls__1256 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var summary__5 any = /*line :308:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :314:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_77, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.J2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_52).Ref()), jrt.Prim_byte.ArrayClass())).Ref())).Ref() }
//line :311:1
func A_arbace_build_go_h1_of_file_hex__1901000239_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Invoke_O_O__O(self, b__1 any) any { var root_1250 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1254 any; var root_1245 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1246 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1245, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1247 lang.IFn; if linked_1246 == nil { ifn_1247 = lang.IFn_Cast(root_1245) } else { ifn_1247 = nil }; var arg_1248 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New(); var tmp2 *jrt.Class; var fncls__1244 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class; if fncls__1244 == nil { var fncls__1244d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class = fncls__1244d; tmp2 = fncls__1244d } else { tmp2 = fncls__1244 }; arg_1248 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1249 any = b__1; if linked_1246 == nil { arg_1254 = ifn_1247.Invoke_O_O__O(arg_1248, arg_1249) } else { arg_1254 = linked_1246.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1245, arg_1248, arg_1249) }; if linked_1251 == nil { return ifn_1252.Invoke_O_O__O(arg_1253, arg_1254) } else { return linked_1251.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1250, arg_1253, arg_1254) } }
//line :311:1
func A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Invoke_O_O__O(self, p1__1901000238_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_1234 any = p1__1901000238_SHARP___1; var na_1235 int64 = 255; if jrt.Long_InstanceOf(na_1234) { var n0_1236 int64 = jrt.NN(jrt.Long_Cast(na_1234)).LongValue__J(); var n1_1237 int64 = na_1235; tmp2 = n0_1236 & n1_1237 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1234, na_1235) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }
func A_arbace_build_go_h1_of_file_sha__1901000243_A_New() *A_arbace_build_go_h1_of_file_sha__1901000243_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_sha__1901000243_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Ctor() {}
//line :312:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51).Digest_B1__B1(jrt.J2g_CastArray[*jrt.ByteArray](b__1, jrt.Prim_byte.ArrayClass())).Ref() }



func A_arbace_build_go_tamago_go_sum_A_New() *A_arbace_build_go_tamago_go_sum_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_tamago_go_sum_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_build_go_tamago_go_sum_A) Ctor() {}
//line :316:1
func (t *A_arbace_build_go_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__1901000246__2 any = A_arbace_build_go_A_const_105.GetRawRoot__O(); var map__1901000246__3 any; if



	lang.ISeq_InstanceOf(map__1901000246__2) { var tmp1 any; var root_1257 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = map__1901000246__2; if linked_1258 == nil { tmp1 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp1 = linked_1258.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1257, arg_1260) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1261 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = map__1901000246__2; if linked_1262 == nil { tmp2 = ifn_1263.Invoke_O__O(arg_1264) } else { tmp2 = linked_1262.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1261, arg_1264) }; map__1901000246__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1265 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = map__1901000246__2; if linked_1266 == nil { tmp3 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp3 = linked_1266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1265, arg_1268) }; if jrt.J2g_Truth(tmp3) { var root_1269 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = map__1901000246__2; if linked_1270 == nil { map__1901000246__3 = ifn_1271.Invoke_O__O(arg_1272) } else { map__1901000246__3 = linked_1270.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1269, arg_1272) } } else { map__1901000246__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000246__3 = map__1901000246__2 }; var path__4 any = /*line :316:1*/lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_46); var version__5 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_112); var zip__6 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_113); var mod__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_114); var dir__8 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_169, nil, Lit_170); var tmp5 any; var root_1273 any = A_arbace_build_go_A_const_115.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_build_go_go_mod_cache_A_fn_class); var ifn_1275 lang.IFn; if




	linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = goroot__0; if linked_1274 == nil { tmp5 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp5 = linked_1274.(*A_arbace_build_go_go_mod_cache_A).Invoke_O_O__O(root_1273, arg_1276) }; dir__8 = /*line :316:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_171), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_172), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp6 bool; var and__1927000168__auto____11 bool = jrt.NN(jrt.File_Cast(zf__9)).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(mf__10)).IsFile__Z(); if and__1927000168__auto____12 { tmp6 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_173), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp6 = and__1927000168__auto____12 } } else { tmp6 = and__1927000168__auto____11 }; if tmp6 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_174, nil, Lit_175, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.NN(jrt.File_Cast(dir__8)).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any; var root_1285 any = /*line :316:1*/A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1287 lang.IFn; if









	linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(zf__9); if linked_1286 == nil { zh__12 = ifn_1287.Invoke_O__O(arg_1288) } else { zh__12 = linked_1286.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1285, arg_1288) }; var mh__13 any; var root_1289 any = /*line :316:1*/A_arbace_build_go_A_const_116.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, A_arbace_build_go_h1_of_file_A_fn_class); var ifn_1291 lang.IFn; if










	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(mf__10)).ToPath__Path()).Ref(); var arg_1293 any = Lit_99; if linked_1290 == nil { mh__13 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { mh__13 = linked_1290.(*A_arbace_build_go_h1_of_file_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; var tmp7 bool; var and__1927000168__auto____14 bool =
	lang.Util_Equiv_O_O__Z_NoInit(zh__12, zip__6); if and__1927000168__auto____14 { tmp7 = lang.Util_Equiv_O_O__Z_NoInit(mh__13, mod__7) } else { tmp7 = and__1927000168__auto____14 }; if tmp7 { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :330:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_build_go_toolchain_lang_A_New() *A_arbace_build_go_toolchain_lang_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_toolchain_lang_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_build_go_toolchain_lang_A) Ctor() {}
//line :332:1
func (t *A_arbace_build_go_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000249__2 any; var root_1298 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, A_arbace_build_go_run_A_fn_class); var ifn_1300 lang.IFn; if


	linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_67, Lit_177); var arg_1302 any = jrt.File_New_String(Lit_69); var arg_1303 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_70, goroot__0, Lit_71, Lit_72)); var arg_1304 any = jrt.Boolean_FALSE.Ref(); if linked_1299 == nil { vec__1901000249__2 = ifn_1300.Invoke_O_O_O_O__O(arg_1301, arg_1302, arg_1303, arg_1304) } else { vec__1901000249__2 = linked_1299.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1298, arg_1301, arg_1302, arg_1303, arg_1304) }; var status__3 any = /*line :332:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any; var root_1309 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1309, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1311 lang.IFn; if




	linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any; var root_1305 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1305, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1307 lang.IFn; if linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any = out__4; if linked_1306 == nil { arg_1312 = ifn_1307.Invoke_O__O(arg_1308) } else { arg_1312 = linked_1306.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1305, arg_1308) }; if linked_1310 == nil { v__5 = ifn_1311.Invoke_O__O(arg_1312) } else { v__5 = linked_1310.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1309, arg_1312) }; var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool; var na_1313 any = status__3; if
	jrt.Long_InstanceOf(na_1313) { var n0_1314 int64 = jrt.NN(jrt.Long_Cast(na_1313)).LongValue__J(); and__1927000168__auto____6 = n0_1314 == 0 } else { if jrt.Double_InstanceOf(na_1313) { var n0_1314_2 float64 = jrt.NN(jrt.Double_Cast(na_1313)).DoubleValue__D(); and__1927000168__auto____6 = n0_1314_2 == 0.0 } else { and__1927000168__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_1313) } }; if and__1927000168__auto____6 { var root_1315 any = A_arbace_build_go_A_const_117.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = A_arbace_build_go_A_const_118; var arg_1319 any = v__5; if linked_1316 == nil { temp__1927000408__auto____6 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { temp__1927000408__auto____6 = linked_1316.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) } } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__1901000252__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___8; return l__9 } else {

		return lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_178, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_build_go_program_A_New() *A_arbace_build_go_program_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_build_go_program_A) Ctor() {}
//line :342:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__1901000259__2 any) any { var map__1901000260__4 any = p__1901000259__2; var map__1901000260__5 any; if lang.ISeq_InstanceOf(map__1901000260__4) { var tmp1 any; var root_1324 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = map__1901000260__4; if linked_1325 == nil { tmp1 = ifn_1326.Invoke_O__O(arg_1327) } else { tmp1 = linked_1325.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1324, arg_1327) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1328 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = map__1901000260__4; if linked_1329 == nil { tmp2 = ifn_1330.Invoke_O__O(arg_1331) } else { tmp2 = linked_1329.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1328, arg_1331) }; map__1901000260__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1332 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = map__1901000260__4; if linked_1333 == nil { tmp3 = ifn_1334.Invoke_O__O(arg_1335) } else { tmp3 = linked_1333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1332, arg_1335) }; if jrt.J2g_Truth(tmp3) { var root_1336 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = map__1901000260__4; if linked_1337 == nil { map__1901000260__5 = ifn_1338.Invoke_O__O(arg_1339) } else { map__1901000260__5 = linked_1337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1336, arg_1339) } } else { map__1901000260__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000260__5 = map__1901000260__4 }; var opts__6 any = map__1901000260__5; var library_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_119); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_120); var pkgs__9 any; var root_1340 any = A_arbace_build_go_A_const_52.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, A_arbace_build_go_packages_A_fn_class); var ifn_1342 lang.IFn; if









	linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = dir__0; var arg_1344 any = roots__8; var arg_1345 any = A_arbace_build_go_A_const_121.Invoke_O__O(opts__6); if linked_1341 == nil { pkgs__9 = ifn_1342.Invoke_O_O_O__O(arg_1343, arg_1344, arg_1345) } else { pkgs__9 = linked_1341.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_1340, arg_1343, arg_1344, arg_1345) }; var mains__10 any; var G__1901000262__10_ any; var root_1351 any = /*line :342:1*/A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1353 lang.IFn; if










	linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any; var tmp4 any = A_arbace_build_go_program_fn__1901000263_A_New(); var tmp5 *jrt.Class; var fncls__1350 *jrt.Class = A_arbace_build_go_program_fn__1901000263_A_fn_class; if fncls__1350 == nil { var fncls__1350d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_build_go_program_fn__1901000263_A_fn_class = fncls__1350d; tmp5 = fncls__1350d } else { tmp5 = fncls__1350 }; arg_1354 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1355 any = pkgs__9; if linked_1352 == nil { G__1901000262__10_ = ifn_1353.Invoke_O_O__O(arg_1354, arg_1355) } else { G__1901000262__10_ = linked_1352.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1351, arg_1354, arg_1355) }; if jrt.J2g_Truth(A_arbace_build_go_A_const_122.Invoke_O__O(opts__6)) {
		var root_1357 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1358 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1357, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1359 lang.IFn; if linked_1358 == nil { ifn_1359 = lang.IFn_Cast(root_1357) } else { ifn_1359 = nil }; var arg_1360 any; var tmp6 any = A_arbace_build_go_program_fn__1901000265_A_New_O(opts__6); var tmp7 *jrt.Class; var fncls__1356 *jrt.Class = A_arbace_build_go_program_fn__1901000265_A_fn_class; if fncls__1356 == nil { var fncls__1356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_build_go_program_fn__1901000265_A_fn_class = fncls__1356d; tmp7 = fncls__1356d } else { tmp7 = fncls__1356 }; arg_1360 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1361 any = G__1901000262__10_; if linked_1358 == nil { mains__10 = ifn_1359.Invoke_O_O__O(arg_1360, arg_1361) } else { mains__10 = linked_1358.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1357, arg_1360, arg_1361) } } else {
//line :353:1
			mains__10 = G__1901000262__10_ }; var ___11 any; var tmp8 any; var or__1927000174__auto____11 bool = /*line :342:1*/lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(mains__10))); _ = ___11; if or__1927000174__auto____11 {












				tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 any; var root_1362 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = mains__10; if linked_1363 == nil { or__1927000174__auto____13 = ifn_1364.Invoke_O__O(arg_1365) } else { or__1927000174__auto____13 = linked_1363.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1362, arg_1365) }; if jrt.J2g_Truth(or__1927000174__auto____13) { tmp8 = or__1927000174__auto____13 } else { tmp8 = A_arbace_build_go_A_const_123.Invoke_O__O(opts__6) } } else { tmp8 = and__1927000168__auto____12 } }; if jrt.J2g_Truth(tmp8) { ___11 = nil } else {
					var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_120, nil, nil); var tmp11 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(mains__10)).Ref(); var tmp12 *jrt.String; var tmp13 any; var root_1366 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1367 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1366, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1368 lang.IFn
					if linked_1367 == nil { ifn_1368 = lang.IFn_Cast(root_1366) } else { ifn_1368 = nil }; var arg_1369 any = mains__10; if linked_1367 == nil { tmp13 = ifn_1368.Invoke_O__O(arg_1369) } else { tmp13 = linked_1367.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1366, arg_1369) }; if jrt.J2g_Truth(tmp13) { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil); var tmp15 any; var root_1375 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1375, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1377 lang.IFn; if linked_1376 == nil { ifn_1377 = lang.IFn_Cast(root_1375) } else { ifn_1377 = nil }; var arg_1378 any = Lit_87; var arg_1379 any; var root_1370 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1372 lang.IFn; if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = A_arbace_build_go_A_const_46; var arg_1374 any = mains__10; if linked_1371 == nil { arg_1379 = ifn_1372.Invoke_O_O__O(arg_1373, arg_1374) } else { arg_1379 = linked_1371.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1370, arg_1373, arg_1374) }; if linked_1376 == nil { tmp15 = ifn_1377.Invoke_O_O__O(arg_1378, arg_1379) } else { tmp15 = linked_1376.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1375, arg_1378, arg_1379) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :356:1
					___11 = tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, tmp12.Ref())).Ref()) }; var main__12 any; var root_1384 any = /*line :342:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1386 lang.IFn; if















	linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = mains__10; if linked_1385 == nil { main__12 = ifn_1386.Invoke_O__O(arg_1387) } else { main__12 = linked_1385.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1384, arg_1387) }; var edn__13 any; var root_1388 any = /*line :342:1*/A_arbace_build_go_A_const_124.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, A_arbace_build_go_read_program_edn_A_fn_class); var ifn_1390 lang.IFn; if
















	linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = dir__0; if linked_1389 == nil { edn__13 = ifn_1390.Invoke_O__O(arg_1391) } else { edn__13 = linked_1389.(*A_arbace_build_go_read_program_edn_A).Invoke_O_O__O(root_1388, arg_1391) }; var module__14 any; var or__1927000174__auto____14 any = /*line :342:1*/A_arbace_build_go_A_const_123.Invoke_O__O(edn__13); if

















	jrt.J2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_build_go_A_const_123.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_build_go_A_const_46.Invoke_O__O(main__12); if jrt.J2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_121) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :342:1*/A_arbace_build_go_A_const_125.Invoke_O__O(edn__13); if





















	jrt.J2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_build_go_A_const_125.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z_NoInit(module__14, Lit_98) { golang__15 = nil } else { var root_1396 any = A_arbace_build_go_A_const_126.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, A_arbace_build_go_toolchain_lang_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = goroot__1; if linked_1397 == nil { golang__15 = ifn_1398.Invoke_O__O(arg_1399) } else { golang__15 = linked_1397.(*A_arbace_build_go_toolchain_lang_A).Invoke_O_O__O(root_1396, arg_1399) } } } }; var pkgs__16 any; var root_1523 any = /*line :342:1*/A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1525 lang.IFn; if






















	linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any; var iter__1927001039__auto____16 any; var tmp16 any = A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(module__14); var tmp17 *jrt.Class; var fncls__1522 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class; if fncls__1522 == nil { var fncls__1522d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class = fncls__1522d; tmp17 = fncls__1522d } else { tmp17 = fncls__1522 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); arg_1526 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); if linked_1524 == nil { pkgs__16 = ifn_1525.Invoke_O__O(arg_1526) } else { pkgs__16 = linked_1524.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1523, arg_1526) }; var tmp18 any = A_arbace_build_go_A_const_123; var tmp19 any = A_arbace_build_go_A_const_125; var tmp20 any; var root_1527 any = /*line :342:1*/A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1529 lang.IFn; if
































	linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = golang__15; if linked_1528 == nil { tmp20 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp20 = linked_1528.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1527, arg_1530) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_build_go_A_const_78; var tmp23 any = A_arbace_build_go_A_const_130; var tmp24 any; var root_1541 any = /*line :342:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1542 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1541, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1543 lang.IFn; if

































	linked_1542 == nil { ifn_1543 = lang.IFn_Cast(root_1541) } else { ifn_1543 = nil }; var arg_1544 any; var root_1536 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1536, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1538 lang.IFn; if linked_1537 == nil { ifn_1538 = lang.IFn_Cast(root_1536) } else { ifn_1538 = nil }; var arg_1539 any; var tmp25 any = A_arbace_build_go_program_fn__1901000277_A_New(); var tmp26 *jrt.Class; var fncls__1535 *jrt.Class = A_arbace_build_go_program_fn__1901000277_A_fn_class; if fncls__1535 == nil { var fncls__1535d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_build_go_program_fn__1901000277_A_fn_class = fncls__1535d; tmp26 = fncls__1535d } else { tmp26 = fncls__1535 }; arg_1539 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_1540 any = pkgs__16; if linked_1537 == nil { arg_1544 = ifn_1538.Invoke_O_O__O(arg_1539, arg_1540) } else { arg_1544 = linked_1537.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1536, arg_1539, arg_1540) }; if linked_1542 == nil { tmp24 = ifn_1543.Invoke_O__O(arg_1544) } else { tmp24 = linked_1542.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1541, arg_1544) }; return /*line :342:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, module__14, tmp19, tmp21, tmp22, pkgs__16, tmp23, tmp24)) }
//line :342:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {







	var root_1545 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, A_arbace_build_go_program_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = dir__0; var arg_1549 any = goroot__1; var arg_1550 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1546 == nil { return ifn_1547.Invoke_O_O_O__O(arg_1548, arg_1549, arg_1550) } else { return linked_1546.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_1545, arg_1548, arg_1549, arg_1550)
	}
}
func A_arbace_build_go_program_fn__1901000263_A_New() *A_arbace_build_go_program_fn__1901000263_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000263_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Ctor() {}
//line :353:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Invoke_O_O__O(self, p1__1901000256_SHARP___1 any) any { var tmp1 any; var root_1346 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1348 lang.IFn; if linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000256_SHARP___1); if linked_1347 == nil { tmp1 = ifn_1348.Invoke_O__O(arg_1349) } else { tmp1 = linked_1347.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1346, arg_1349) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_94, tmp1)).Ref() }
func A_arbace_build_go_program_fn__1901000265_A_New_O(p0 any) *A_arbace_build_go_program_fn__1901000265_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000265_A{}; t.Ctor_O(p0); return t }
//line :354:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :354:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Invoke_O_O__O(self, p1__1901000257_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_122.Invoke_O__O(t.F_opts), A_arbace_build_go_A_const_46.Invoke_O__O(p1__1901000257_SHARP___1))).Ref() }










func A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(p0 any) *A_arbace_build_go_program_iter__1901000267__1901000271_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Invoke_O_O__O(self, s__1901000268__1 any) any { var tmp1 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(self, t.F_module, s__1901000268__1); var tmp2 *jrt.Class; var fncls__1521 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class; if fncls__1521 == nil { var fncls__1521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class = fncls__1521d; tmp2 = fncls__1521d } else { tmp2 = fncls__1521 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Ctor_O_O_O(c__iter__1901000267, c__module, c__s__1901000268 any) { t.F_iter__1901000267 = c__iter__1901000267; t.F_module = c__module; t.F_s__1901000268 = c__s__1901000268 }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Invoke_O__O(self any) any { { var s__1901000268__1 any; var t_ any = t.F_s__1901000268; t.F_s__1901000268 = nil; s__1901000268__1 = t_; for { var temp__1927000414__auto____2 any; var root_1400 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1402 lang.IFn; if linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = s__1901000268__1; if linked_1401 == nil { temp__1927000414__auto____2 = ifn_1402.Invoke_O__O(arg_1403) } else { temp__1927000414__auto____2 = linked_1401.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1400, arg_1403) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000268__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1404 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = s__1901000268__3; if linked_1405 == nil { tmp1 = ifn_1406.Invoke_O__O(arg_1407) } else { tmp1 = linked_1405.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1404, arg_1407) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1408 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = s__1901000268__3; if linked_1409 == nil { c__1927001037__auto____4 = ifn_1410.Invoke_O__O(arg_1411) } else { c__1927001037__auto____4 = linked_1409.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1408, arg_1411) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000270__6 any; var root_1412 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1413 == nil { b__1901000270__6 = ifn_1414.Invoke_O__O(arg_1415) } else { b__1901000270__6 = linked_1413.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1412, arg_1415) }; var tmp2 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(b__1901000270__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1453 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class; if fncls__1453 == nil { var fncls__1453d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class = fncls__1453d; tmp3 = fncls__1453d } else { tmp3 = fncls__1453 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1462 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1462, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1464 lang.IFn; if linked_1463 == nil { ifn_1464 = lang.IFn_Cast(root_1462) } else { ifn_1464 = nil }; var arg_1465 any; var root_1454 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = b__1901000270__6; if linked_1455 == nil { arg_1465 = ifn_1456.Invoke_O__O(arg_1457) } else { arg_1465 = linked_1455.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1454, arg_1457) }; var arg_1466 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp5 any; var root_1458 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any = s__1901000268__3; if linked_1459 == nil { tmp5 = ifn_1460.Invoke_O__O(arg_1461) } else { tmp5 = linked_1459.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1458, arg_1461) }; arg_1466 = tmp4.Invoke_O__O(tmp5); if linked_1463 == nil { return ifn_1464.Invoke_O_O__O(arg_1465, arg_1466) } else { return linked_1463.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1462, arg_1465, arg_1466) } } else { var root_1471 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any; var root_1467 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = b__1901000270__6; if linked_1468 == nil { arg_1474 = ifn_1469.Invoke_O__O(arg_1470) } else { arg_1474 = linked_1468.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1467, arg_1470) }; var arg_1475 any; if linked_1472 == nil { return ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { return linked_1472.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) } } } else { var pkg__4 any; var root_1476 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = s__1901000268__3; if linked_1477 == nil { pkg__4 = ifn_1478.Invoke_O__O(arg_1479) } else { pkg__4 = linked_1477.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1476, arg_1479) }; var root_1516 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1516, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1518 lang.IFn; if linked_1517 == nil { ifn_1518 = lang.IFn_Cast(root_1516) } else { ifn_1518 = nil }; var arg_1519 any; var path__5 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_98) {


		var root_1480 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = pkg__4; var arg_1484 any = A_arbace_build_go_A_const_127; var arg_1485 any = path__5; if linked_1481 == nil { arg_1519 = ifn_1482.Invoke_O_O_O__O(arg_1483, arg_1484, arg_1485) } else { arg_1519 = linked_1481.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1480, arg_1483, arg_1484, arg_1485) } } else {
//line :367:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__5, t.F_module) {



				var root_1486 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1487 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1486, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1488 lang.IFn; if linked_1487 == nil { ifn_1488 = lang.IFn_Cast(root_1486) } else { ifn_1488 = nil }; var arg_1489 any = pkg__4; var arg_1490 any = A_arbace_build_go_A_const_127; var arg_1491 any = Lit_96; if linked_1487 == nil { arg_1519 = ifn_1488.Invoke_O_O_O__O(arg_1489, arg_1490, arg_1491) } else { arg_1519 = linked_1487.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1486, arg_1489, arg_1490, arg_1491) } } else {
//line :367:1
					var tmp6 any; var root_1492 any = A_arbace_build_go_A_const_128.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1494 lang.IFn




					if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = path__5; var arg_1496 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1493 == nil { tmp6 = ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { tmp6 = linked_1493.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) }
//line :367:1
					if jrt.J2g_Truth(tmp6) {





						var root_1502 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1503 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1502, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1504 lang.IFn; if linked_1503 == nil { ifn_1504 = lang.IFn_Cast(root_1502) } else { ifn_1504 = nil }; var arg_1505 any = pkg__4; var arg_1506 any = A_arbace_build_go_A_const_127; var arg_1507 any; var root_1497 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = path__5; var arg_1501 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1498 == nil { arg_1507 = ifn_1499.Invoke_O_O__O(arg_1500, arg_1501) } else { arg_1507 = linked_1498.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1497, arg_1500, arg_1501) }; if linked_1503 == nil { arg_1519 = ifn_1504.Invoke_O_O_O__O(arg_1505, arg_1506, arg_1507) } else { arg_1519 = linked_1503.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1502, arg_1505, arg_1506, arg_1507) } } else {
//line :367:1
							if A_arbace_build_go_A_const_13 != nil {






								arg_1519 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :367:1
									arg_1519 = nil } } } }
//line :365:1
	var arg_1520 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp8 any; var root_1512 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = s__1901000268__3; if linked_1513 == nil { tmp8 = ifn_1514.Invoke_O__O(arg_1515) } else { tmp8 = linked_1513.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1512, arg_1515) }; arg_1520 = tmp7.Invoke_O__O(tmp8); if linked_1517 == nil { return ifn_1518.Invoke_O_O__O(arg_1519, arg_1520) } else { return linked_1517.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1516, arg_1519, arg_1520) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Ctor_O_I_O_O(c__b__1901000270 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__1901000270 = c__b__1901000270; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Invoke_O__O(self any) any { { var i__1901000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000269__1)); var root_1448 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = t.F_b__1901000270; var arg_1452 any; var path__3 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_98) {


		var root_1416 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = pkg__2; var arg_1420 any = A_arbace_build_go_A_const_127; var arg_1421 any = path__3; if linked_1417 == nil { arg_1452 = ifn_1418.Invoke_O_O_O__O(arg_1419, arg_1420, arg_1421) } else { arg_1452 = linked_1417.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1416, arg_1419, arg_1420, arg_1421) } } else {
//line :367:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__3, t.F_module) {



				var root_1422 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any = pkg__2; var arg_1426 any = A_arbace_build_go_A_const_127; var arg_1427 any = Lit_96; if linked_1423 == nil { arg_1452 = ifn_1424.Invoke_O_O_O__O(arg_1425, arg_1426, arg_1427) } else { arg_1452 = linked_1423.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1422, arg_1425, arg_1426, arg_1427) } } else {
//line :367:1
					var tmp2 any; var root_1428 any = A_arbace_build_go_A_const_128.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1430 lang.IFn




					if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = path__3; var arg_1432 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1429 == nil { tmp2 = ifn_1430.Invoke_O_O__O(arg_1431, arg_1432) } else { tmp2 = linked_1429.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1428, arg_1431, arg_1432) }
//line :367:1
					if jrt.J2g_Truth(tmp2) {





						var root_1438 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1439 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1438, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1440 lang.IFn; if linked_1439 == nil { ifn_1440 = lang.IFn_Cast(root_1438) } else { ifn_1440 = nil }; var arg_1441 any = pkg__2; var arg_1442 any = A_arbace_build_go_A_const_127; var arg_1443 any; var root_1433 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1433, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1435 lang.IFn; if linked_1434 == nil { ifn_1435 = lang.IFn_Cast(root_1433) } else { ifn_1435 = nil }; var arg_1436 any = path__3; var arg_1437 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1434 == nil { arg_1443 = ifn_1435.Invoke_O_O__O(arg_1436, arg_1437) } else { arg_1443 = linked_1434.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1433, arg_1436, arg_1437) }; if linked_1439 == nil { arg_1452 = ifn_1440.Invoke_O_O_O__O(arg_1441, arg_1442, arg_1443) } else { arg_1452 = linked_1439.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1438, arg_1441, arg_1442, arg_1443) } } else {
//line :367:1
							if A_arbace_build_go_A_const_13 != nil {






								arg_1452 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :367:1
									arg_1452 = nil } } } }
//line :365:1
	if linked_1449 == nil { ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { linked_1449.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; i__1901000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000269__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_build_go_program_fn__1901000277_A_New() *A_arbace_build_go_program_fn__1901000277_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000277_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Ctor() {}
//line :376:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Invoke_O_O__O(self, p1__1901000258_SHARP___1 any) any { var tmp1 any; var root_1531 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1533 lang.IFn; if linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000258_SHARP___1); if linked_1532 == nil { tmp1 = ifn_1533.Invoke_O__O(arg_1534) } else { tmp1 = linked_1532.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1531, arg_1534) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_94, tmp1)).Ref() }




func A_arbace_build_go_sha256_A_New() *A_arbace_build_go_sha256_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_build_go_sha256_A) Ctor() {}
//line :381:1
func (t *A_arbace_build_go_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51); var root_1567 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1568 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1567, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1569 lang.IFn; if

	linked_1568 == nil { ifn_1569 = lang.IFn_Cast(root_1567) } else { ifn_1569 = nil }; var arg_1570 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1571 any; var root_1562 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1563 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1562, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1564 lang.IFn; if linked_1563 == nil { ifn_1564 = lang.IFn_Cast(root_1562) } else { ifn_1564 = nil }; var arg_1565 any; var tmp1 any = A_arbace_build_go_sha256_fn__1901000281_A_New(); var tmp2 *jrt.Class; var fncls__1561 *jrt.Class = A_arbace_build_go_sha256_fn__1901000281_A_fn_class; if fncls__1561 == nil { var fncls__1561d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_build_go_sha256_fn__1901000281_A_fn_class = fncls__1561d; tmp2 = fncls__1561d } else { tmp2 = fncls__1561 }; arg_1565 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1566 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref(); if linked_1563 == nil { arg_1571 = ifn_1564.Invoke_O_O__O(arg_1565, arg_1566) } else { arg_1571 = linked_1563.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1562, arg_1565, arg_1566) }; if linked_1568 == nil { return ifn_1569.Invoke_O_O__O(arg_1570, arg_1571) } else { return linked_1568.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1567, arg_1570, arg_1571) } }
//line :383:1
func A_arbace_build_go_sha256_fn__1901000281_A_New() *A_arbace_build_go_sha256_fn__1901000281_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_fn__1901000281_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Ctor() {}
//line :383:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Invoke_O_O__O(self, p1__1901000280_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_1551 any = p1__1901000280_SHARP___1; var na_1552 int64 = 255; if jrt.Long_InstanceOf(na_1551) { var n0_1553 int64 = jrt.NN(jrt.Long_Cast(na_1551)).LongValue__J(); var n1_1554 int64 = na_1552; tmp2 = n0_1553 & n1_1554 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1551, na_1552) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_copy_file_A_New() *A_arbace_build_go_copy_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_copy_file_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_build_go_copy_file_A) Ctor() {}
//line :385:1
func (t *A_arbace_build_go_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 any; var root_1572 any = A_arbace_build_go_A_const_132.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_1574 lang.IFn
	if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = A_arbace_build_go_A_const_133; var arg_1576 any; var tmp4 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp4 = jrt.StandardCopyOption_REPLACE_EXISTING; arg_1576 = lang.Tuple_Create_O__IPersistentVector(tmp4.Ref()); if linked_1573 == nil { tmp3 = ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { tmp3 = linked_1573.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) }
//line :387:1
	return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.J2g_CastArray[*jrt.RefArray](tmp3, jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_build_go_forms_dir_A_New() *A_arbace_build_go_forms_dir_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_forms_dir_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_build_go_forms_dir_A) Ctor() {}
//line :390:1
func (t *A_arbace_build_go_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_build_go_A_const_50.Invoke_O__O(pkg__0); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp1 *jrt.File = jrt.NN(jrt.File_Cast(f__2)).GetParentFile__File(); var tmp2 any; var root_1577 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1579 lang.IFn; if





	linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = n__3; var arg_1581 any = A_arbace_build_go_A_const_134; var arg_1582 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref(); if linked_1578 == nil { tmp2 = ifn_1579.Invoke_O_O_O__O(arg_1580, arg_1581, arg_1582) } else { tmp2 = linked_1578.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1577, arg_1580, arg_1581, arg_1582) }; return /*line :390:1*/ jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2)) }







func A_arbace_build_go_with_line_files_A_New() *A_arbace_build_go_with_line_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_A{}; t.Ctor(); return t }
//line :398:1
func (t *A_arbace_build_go_with_line_files_A) Ctor() {}
//line :398:1
func (t *A_arbace_build_go_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any; var root_1583 any = A_arbace_build_go_A_const_135.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, A_arbace_build_go_forms_dir_A_fn_class); var ifn_1585 lang.IFn; if





	linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = pkg__0; if linked_1584 == nil { fdir__2 = ifn_1585.Invoke_O__O(arg_1586) } else { fdir__2 = linked_1584.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_1583, arg_1586) }; var root_1610 any =
	A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_1611 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1610, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1612 lang.IFn; if linked_1611 == nil { ifn_1612 = lang.IFn_Cast(root_1610) } else { ifn_1612 = nil }; var arg_1613 any = pkg__0; var arg_1614 any = A_arbace_build_go_A_const_136; var arg_1615 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(fdir__2); var tmp2 *jrt.Class; var fncls__1609 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class; if fncls__1609 == nil { var fncls__1609d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class = fncls__1609d; tmp2 = fncls__1609d } else { tmp2 = fncls__1609 }; arg_1615 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1611 == nil { return ifn_1612.Invoke_O_O_O__O(arg_1613, arg_1614, arg_1615) } else { return linked_1611.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1610, arg_1613, arg_1614, arg_1615) } }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Invoke_O_O__O(self, fs__1 any) any { var root_1604 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(t.F_fdir); var tmp2 *jrt.Class; var fncls__1603 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class; if fncls__1603 == nil { var fncls__1603d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class = fncls__1603d; tmp2 = fncls__1603d } else { tmp2 = fncls__1603 }; arg_1607 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1608 any = fs__1; if linked_1605 == nil { return ifn_1606.Invoke_O_O__O(arg_1607, arg_1608) } else { return linked_1605.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1604, arg_1607, arg_1608) } }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Invoke_O_O__O(self, p1__1901000286_SHARP___1 any) any { var root_1597 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_1598 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1597, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1599 lang.IFn; if linked_1598 == nil { ifn_1599 = lang.IFn_Cast(root_1597) } else { ifn_1599 = nil }; var arg_1600 any = p1__1901000286_SHARP___1; var arg_1601 any = A_arbace_build_go_A_const_137; var arg_1602 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(t.F_fdir); var tmp2 *jrt.Class; var fncls__1596 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class; if fncls__1596 == nil { var fncls__1596d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class = fncls__1596d; tmp2 = fncls__1596d } else { tmp2 = fncls__1596 }; arg_1602 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1598 == nil { return ifn_1599.Invoke_O_O_O__O(arg_1600, arg_1601, arg_1602) } else { return linked_1598.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1597, arg_1600, arg_1601, arg_1602) } }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Invoke_O_O__O(self, s__1 any) any { var root_1591 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, A_arbace_build_go_rel_path_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = t.F_fdir; var arg_1595 any; var tmp1 any; var root_1587 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = s__1; if linked_1588 == nil { tmp1 = ifn_1589.Invoke_O__O(arg_1590) } else { tmp1 = linked_1588.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1587, arg_1590) }; arg_1595 = jrt.File_New_String(jrt.String_Cast(tmp1)); if linked_1592 == nil { return ifn_1593.Invoke_O_O__O(arg_1594, arg_1595) } else { return linked_1592.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1591, arg_1594, arg_1595) } }



func A_arbace_build_go_print_cache_key_A_New() *A_arbace_build_go_print_cache_key_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_build_go_print_cache_key_A) Ctor() {}
//line :409:1
func (t *A_arbace_build_go_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51); var add__7 any; var tmp1 any = A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(md__6); var tmp2 *jrt.Class; var fncls__1616 *jrt.Class = A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class; if





	fncls__1616 == nil { var fncls__1616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class = fncls__1616d; tmp2 = fncls__1616d } else { tmp2 = fncls__1616 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0); var tmp3 lang.IFn =
	lang.IFn_Cast(add__7); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_A_const_138.Invoke_O__O(opts__3); var tmp6 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_build_go_A_const_139.Invoke_O__O(opts__3))).Ref(); var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tests__4)).Ref(); var tmp8 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp9 any; var root_1658 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1659 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1658, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1660 lang.IFn; if linked_1659 == nil { ifn_1660 = lang.IFn_Cast(root_1658) } else { ifn_1660 = nil }; var arg_1661 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__1); if linked_1659 == nil { tmp9 = ifn_1660.Invoke_O__O(arg_1661) } else { tmp9 = linked_1659.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1658, arg_1661) }; tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp5, tmp6, tmp7, tmp8, tmp9))); var seq_1901000297__8 any; var root_1638 any = /*line :409:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1640 lang.IFn; if








	linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1); if linked_1639 == nil { seq_1901000297__8 = ifn_1640.Invoke_O__O(arg_1641) } else { seq_1901000297__8 = linked_1639.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1638, arg_1641) }; var chunk_1901000298__9 any; var count_1901000299__10 int64 = 0; var i_1901000300__11 int64 = 0; L1:
//line :409:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000300__11, count_1901000299__10) { var f__12 any = lang.Indexed_Cast(chunk_1901000298__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000300__11)); var tmp10 lang.IFn = lang.IFn_Cast(add__7); var tmp11 any; var root_1666 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, A_arbace_build_go_rel_path_A_fn_class); var ifn_1668 lang.IFn
			if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any = dir__2; var arg_1670 any = f__12; if linked_1667 == nil { tmp11 = ifn_1668.Invoke_O_O__O(arg_1669, arg_1670) } else { tmp11 = linked_1667.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1666, arg_1669, arg_1670) }; tmp10.Invoke_O__O(tmp11)
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__12)).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_96)
//line :418:1
			seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000300__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_1642 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = seq_1901000297__8; if linked_1643 == nil { temp__1927000414__auto____12 = ifn_1644.Invoke_O__O(arg_1645) } else { temp__1927000414__auto____12 = linked_1643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1642, arg_1645) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1901000297__13 any = temp__1927000414__auto____12; var tmp12 any; var root_1646 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = seq_1901000297__13; if linked_1647 == nil { tmp12 = ifn_1648.Invoke_O__O(arg_1649) } else { tmp12 = linked_1647.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1646, arg_1649) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____14 any; var root_1650 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = seq_1901000297__13; if linked_1651 == nil { c__1927000678__auto____14 = ifn_1652.Invoke_O__O(arg_1653) } else { c__1927000678__auto____14 = linked_1651.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1650, arg_1653) }; var tmp13 any; var root_1671 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = seq_1901000297__13; if linked_1672 == nil { tmp13 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp13 = linked_1672.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1671, arg_1674) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp13, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__14 any; var root_1654 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = seq_1901000297__13; if linked_1655 == nil { f__14 = ifn_1656.Invoke_O__O(arg_1657) } else { f__14 = linked_1655.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1654, arg_1657) }
				var tmp14 lang.IFn = lang.IFn_Cast(add__7); var tmp15 any; var root_1675 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, A_arbace_build_go_rel_path_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = dir__2; var arg_1679 any = f__14; if linked_1676 == nil { tmp15 = ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { tmp15 = linked_1676.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) }; tmp14.Invoke_O__O(tmp15)
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__14)).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_96)
//line :418:1
				var tmp16 any; var root_1680 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = seq_1901000297__13; if linked_1681 == nil { tmp16 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp16 = linked_1681.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1680, arg_1683) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp16, nil, 0, 0; continue L1 } } }
//line :409:1
		break L1 }; var root_1633 any =












	A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1637 any; var root_1628 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1629 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1628, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1630 lang.IFn; if linked_1629 == nil { ifn_1630 = lang.IFn_Cast(root_1628) } else { ifn_1630 = nil }; var arg_1631 any; var tmp17 any = A_arbace_build_go_print_cache_key_fn__1901000301_A_New(); var tmp18 *jrt.Class; var fncls__1627 *jrt.Class = A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class; if fncls__1627 == nil { var fncls__1627d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class = fncls__1627d; tmp18 = fncls__1627d } else { tmp18 = fncls__1627 }; arg_1631 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1632 any = jrt.MessageDigest_Cast(md__6).Digest__B1().Ref(); if linked_1629 == nil { arg_1637 = ifn_1630.Invoke_O_O__O(arg_1631, arg_1632) } else { arg_1637 = linked_1629.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1628, arg_1631, arg_1632) }; if linked_1634 == nil { return ifn_1635.Invoke_O_O__O(arg_1636, arg_1637) } else { return linked_1634.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1633, arg_1636, arg_1637) } }
//line :415:1
func A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(p0 any) *A_arbace_build_go_print_cache_key_add__1901000295_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_add__1901000295_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :415:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_52)); return nil }






func A_arbace_build_go_print_cache_key_fn__1901000301_A_New() *A_arbace_build_go_print_cache_key_fn__1901000301_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_fn__1901000301_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Ctor() {}
//line :422:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Invoke_O_O__O(self, p1__1901000294_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_1617 any = p1__1901000294_SHARP___1; var na_1618 int64 = 255; if jrt.Long_InstanceOf(na_1617) { var n0_1619 int64 = jrt.NN(jrt.Long_Cast(na_1617)).LongValue__J(); var n1_1620 int64 = na_1618; tmp2 = n0_1619 & n1_1620 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1617, na_1618) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_cached_texts_A_New() *A_arbace_build_go_cached_texts_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_A{}; t.Ctor(); return t }
//line :424:1
func (t *A_arbace_build_go_cached_texts_A) Ctor() {}
//line :424:1
func (t *A_arbace_build_go_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_42); if





	jrt.NN(jrt.File_Cast(names__2)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(entry__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var root_1766 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_1767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1766, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1768 lang.IFn; if linked_1767 == nil { ifn_1768 = lang.IFn_Cast(root_1766) } else { ifn_1768 = nil }; var arg_1769 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_1770 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(entry__0); var tmp2 *jrt.Class; var fncls__1757 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class
		if fncls__1757 == nil { var fncls__1757d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class = fncls__1757d; tmp2 = fncls__1757d } else { tmp2 = fncls__1757 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1762 any = A_arbace_build_go_A_const_140.GetRawRoot__O(); var linked_1763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1762, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_1764 lang.IFn; if linked_1763 == nil { ifn_1764 = lang.IFn_Cast(root_1762) } else { ifn_1764 = nil }; var arg_1765 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(names__2); if linked_1763 == nil { tmp4 = ifn_1764.Invoke_O__O(arg_1765) } else { tmp4 = linked_1763.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_1762, arg_1765) }; arg_1770 = tmp3.Invoke_O__O(tmp4)
//line :432:1
		if linked_1767 == nil { return ifn_1768.Invoke_O_O__O(arg_1769, arg_1770) } else { return linked_1767.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1766, arg_1769, arg_1770) } } else {
//line :430:1
			return nil } }


func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(p0 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A{}; t.Ctor_O(p0); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Invoke_O_O__O(self, s__1901000305__1 any) any { var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(s__1901000305__1, self, t.F_entry); var tmp2 *jrt.Class; var fncls__1756 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class; if fncls__1756 == nil { var fncls__1756d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class = fncls__1756d; tmp2 = fncls__1756d } else { tmp2 = fncls__1756 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :433:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Ctor_O_O_O(c__s__1901000305, c__iter__1901000304, c__entry any) { t.F_s__1901000305 = c__s__1901000305; t.F_iter__1901000304 = c__iter__1901000304; t.F_entry = c__entry }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Invoke_O__O(self any) any { { var s__1901000305__1 any; var t_ any = t.F_s__1901000305; t.F_s__1901000305 = nil; s__1901000305__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1687 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1687, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1689 lang.IFn; if linked_1688 == nil { ifn_1689 = lang.IFn_Cast(root_1687) } else { ifn_1689 = nil }; var arg_1690 any = s__1901000305__1; if linked_1688 == nil { temp__1927000414__auto____2 = ifn_1689.Invoke_O__O(arg_1690) } else { temp__1927000414__auto____2 = linked_1688.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1687, arg_1690) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000305__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1691 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1692 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1691, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1693 lang.IFn; if linked_1692 == nil { ifn_1693 = lang.IFn_Cast(root_1691) } else { ifn_1693 = nil }; var arg_1694 any = s__1901000305__3; if linked_1692 == nil { tmp1 = ifn_1693.Invoke_O__O(arg_1694) } else { tmp1 = linked_1692.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1691, arg_1694) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1695 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any = s__1901000305__3; if linked_1696 == nil { c__1927001037__auto____4 = ifn_1697.Invoke_O__O(arg_1698) } else { c__1927001037__auto____4 = linked_1696.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1695, arg_1698) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000307__6 any; var root_1699 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1699, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1701 lang.IFn; if linked_1700 == nil { ifn_1701 = lang.IFn_Cast(root_1699) } else { ifn_1701 = nil }; var arg_1702 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1700 == nil { b__1901000307__6 = ifn_1701.Invoke_O__O(arg_1702) } else { b__1901000307__6 = linked_1700.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1699, arg_1702) }; var tmp2 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(b__1901000307__6, t.F_entry, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1712 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class; if fncls__1712 == nil { var fncls__1712d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class = fncls__1712d; tmp3 = fncls__1712d } else { tmp3 = fncls__1712 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1721 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1721, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1723 lang.IFn; if linked_1722 == nil { ifn_1723 = lang.IFn_Cast(root_1721) } else { ifn_1723 = nil }; var arg_1724 any; var root_1713 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1713, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1715 lang.IFn; if linked_1714 == nil { ifn_1715 = lang.IFn_Cast(root_1713) } else { ifn_1715 = nil }; var arg_1716 any = b__1901000307__6; if linked_1714 == nil { arg_1724 = ifn_1715.Invoke_O__O(arg_1716) } else { arg_1724 = linked_1714.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1713, arg_1716) }; var arg_1725 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp5 any; var root_1717 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1718 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1717, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1719 lang.IFn; if linked_1718 == nil { ifn_1719 = lang.IFn_Cast(root_1717) } else { ifn_1719 = nil }; var arg_1720 any = s__1901000305__3; if linked_1718 == nil { tmp5 = ifn_1719.Invoke_O__O(arg_1720) } else { tmp5 = linked_1718.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1717, arg_1720) }; arg_1725 = tmp4.Invoke_O__O(tmp5); if linked_1722 == nil { return ifn_1723.Invoke_O_O__O(arg_1724, arg_1725) } else { return linked_1722.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1721, arg_1724, arg_1725) } } else { var root_1730 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1730, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1732 lang.IFn; if linked_1731 == nil { ifn_1732 = lang.IFn_Cast(root_1730) } else { ifn_1732 = nil }; var arg_1733 any; var root_1726 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any = b__1901000307__6; if linked_1727 == nil { arg_1733 = ifn_1728.Invoke_O__O(arg_1729) } else { arg_1733 = linked_1727.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1726, arg_1729) }; var arg_1734 any; if linked_1731 == nil { return ifn_1732.Invoke_O_O__O(arg_1733, arg_1734) } else { return linked_1731.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1730, arg_1733, arg_1734) } } } else { var n__4 any; var root_1735 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = s__1901000305__3; if linked_1736 == nil { n__4 = ifn_1737.Invoke_O__O(arg_1738) } else { n__4 = linked_1736.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1735, arg_1738) }; var tmp6 any; var root_1739 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1741 lang.IFn; if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = n__4; if linked_1740 == nil { tmp6 = ifn_1741.Invoke_O__O(arg_1742) } else { tmp6 = linked_1740.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1739, arg_1742) }; if jrt.J2g_Truth(tmp6) { var root_1747 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1748 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1747, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1749 lang.IFn; if linked_1748 == nil { ifn_1749 = lang.IFn_Cast(root_1747) } else { ifn_1749 = nil }; var tmp7 *jrt.File = jrt.File_Cast(t.F_entry); var arg_1750 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, jrt.File_New_File_String(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4)))); var arg_1751 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp9 any; var root_1743 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1743, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1745 lang.IFn; if linked_1744 == nil { ifn_1745 = lang.IFn_Cast(root_1743) } else { ifn_1745 = nil }; var arg_1746 any = s__1901000305__3; if linked_1744 == nil { tmp9 = ifn_1745.Invoke_O__O(arg_1746) } else { tmp9 = linked_1744.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1743, arg_1746) }; arg_1751 = tmp8.Invoke_O__O(tmp9); if linked_1748 == nil { return ifn_1749.Invoke_O_O__O(arg_1750, arg_1751) } else { return linked_1748.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1747, arg_1750, arg_1751) } } else { var tmp10 any; var root_1752 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1753 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1752, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1754 lang.IFn; if linked_1753 == nil { ifn_1754 = lang.IFn_Cast(root_1752) } else { ifn_1754 = nil }; var arg_1755 any = s__1901000305__3; if linked_1753 == nil { tmp10 = ifn_1754.Invoke_O__O(arg_1755) } else { tmp10 = linked_1753.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1752, arg_1755) }; s__1901000305__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :433:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Ctor_O_O_I_O(c__b__1901000307, c__entry any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000307 = c__b__1901000307; t.F_entry = c__entry; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Invoke_O__O(self any) any { { var i__1901000306__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000306__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000306__1)); var tmp2 any; var root_1703 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1703, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1705 lang.IFn; if linked_1704 == nil { ifn_1705 = lang.IFn_Cast(root_1703) } else { ifn_1705 = nil }; var arg_1706 any = n__2; if linked_1704 == nil { tmp2 = ifn_1705.Invoke_O__O(arg_1706) } else { tmp2 = linked_1704.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1703, arg_1706) }; if jrt.J2g_Truth(tmp2) { var root_1707 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1707, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1709 lang.IFn; if linked_1708 == nil { ifn_1709 = lang.IFn_Cast(root_1707) } else { ifn_1709 = nil }; var arg_1710 any = t.F_b__1901000307; var tmp3 *jrt.File = jrt.File_Cast(t.F_entry); var arg_1711 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, jrt.File_New_File_String(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2)))); if linked_1708 == nil { ifn_1709.Invoke_O_O__O(arg_1710, arg_1711) } else { linked_1708.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1707, arg_1710, arg_1711) }; i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } else { i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_cache_texts_BANG__A_New() *A_arbace_build_go_cache_texts_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Ctor() {}
//line :436:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.NN(jrt.File_Cast(entry__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(entry__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__3)).Mkdirs__Z()); var seq_1901000316__4 any; var root_1775 any = /*line :436:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1777 lang.IFn; if




	linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = texts__1; if linked_1776 == nil { seq_1901000316__4 = ifn_1777.Invoke_O__O(arg_1778) } else { seq_1901000316__4 = linked_1776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1775, arg_1778) }; var chunk_1901000317__5 any; var count_1901000318__6 int64 = 0; var i_1901000319__7 int64 = 0; L1:
//line :436:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000319__7, count_1901000318__6) { var vec__1901000320__8 any = lang.Indexed_Cast(chunk_1901000317__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000319__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000319__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1779 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = seq_1901000316__4; if linked_1780 == nil { temp__1927000414__auto____8 = ifn_1781.Invoke_O__O(arg_1782) } else { temp__1927000414__auto____8 = linked_1780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1779, arg_1782) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1901000316__9 any = temp__1927000414__auto____8; var tmp1 any; var root_1783 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = seq_1901000316__9; if linked_1784 == nil { tmp1 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp1 = linked_1784.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1783, arg_1786) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_1787 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = seq_1901000316__9; if linked_1788 == nil { c__1927000678__auto____10 = ifn_1789.Invoke_O__O(arg_1790) } else { c__1927000678__auto____10 = linked_1788.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1787, arg_1790) }; var tmp2 any; var root_1819 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = seq_1901000316__9; if linked_1820 == nil { tmp2 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp2 = linked_1820.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1819, arg_1822) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000323__10 any; var root_1791 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = seq_1901000316__9; if linked_1792 == nil { vec__1901000323__10 = ifn_1793.Invoke_O__O(arg_1794) } else { vec__1901000323__10 = linked_1792.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1791, arg_1794) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); var tmp3 any; var root_1828 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = seq_1901000316__9; if linked_1829 == nil { tmp3 = ifn_1830.Invoke_O__O(arg_1831) } else { tmp3 = linked_1829.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1828, arg_1831) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :436:1
		break L1 }; var tmp4 lang.IFn =





	lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp5 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_42); var tmp6 any; var root_1805 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1805, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1807 lang.IFn; if linked_1806 == nil { ifn_1807 = lang.IFn_Cast(root_1805) } else { ifn_1807 = nil }; var arg_1808 any; var root_1800 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any; var tmp7 any = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New(); var tmp8 *jrt.Class; var fncls__1795 *jrt.Class = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class; if fncls__1795 == nil { var fncls__1795d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class = fncls__1795d; tmp8 = fncls__1795d } else { tmp8 = fncls__1795 }; arg_1803 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1804 any; var root_1796 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = texts__1; if linked_1797 == nil { arg_1804 = ifn_1798.Invoke_O__O(arg_1799) } else { arg_1804 = linked_1797.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1796, arg_1799) }; if linked_1801 == nil { arg_1808 = ifn_1802.Invoke_O_O__O(arg_1803, arg_1804) } else { arg_1808 = linked_1801.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1800, arg_1803, arg_1804) }; if linked_1806 == nil { tmp6 = ifn_1807.Invoke_O__O(arg_1808) } else { tmp6 = linked_1806.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_1805, arg_1808) }; tmp4.Invoke_O_O__O(tmp5, tmp6); if
	jrt.NN(jrt.File_Cast(tmp__3)).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { var root_1771 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, A_arbace_build_go_delete_tree_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = tmp__3; if linked_1772 == nil { return ifn_1773.Invoke_O__O(arg_1774) } else { return linked_1772.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_1771, arg_1774) } } }
//line :442:1
func A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New() *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__fn__1901000326_A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Ctor() {}
//line :442:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Invoke_O_O__O(self, p1__1901000315_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, p1__1901000315_SHARP___1, nil)).Ref() }


func A_arbace_build_go_print_module_A_New() *A_arbace_build_go_print_module_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_build_go_print_module_A) Ctor() {}
//line :445:1
func (t *A_arbace_build_go_print_module_A) Invoke_O_O_O_O_O__O(self, p__1901000331__0, dir__1, out__2, p__1901000332__3 any) any { var map__1901000333__5 any = p__1901000331__0; var map__1901000333__6 any; if lang.ISeq_InstanceOf(map__1901000333__5) { var tmp1 any; var root_1832 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = map__1901000333__5; if linked_1833 == nil { tmp1 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp1 = linked_1833.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1832, arg_1835) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1836 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = map__1901000333__5; if linked_1837 == nil { tmp2 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp2 = linked_1837.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1836, arg_1839) }; map__1901000333__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_1840 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = map__1901000333__5; if linked_1841 == nil { tmp3 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp3 = linked_1841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1840, arg_1843) }; if jrt.J2g_Truth(tmp3) { var root_1844 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = map__1901000333__5; if linked_1845 == nil { map__1901000333__6 = ifn_1846.Invoke_O__O(arg_1847) } else { map__1901000333__6 = linked_1845.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1844, arg_1847) } } else { map__1901000333__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000333__6 = map__1901000333__5 }; var module__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_123); var packages__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_78); var golang__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_125); var map__1901000335__10 any = p__1901000332__3; var map__1901000335__11 any; if lang.ISeq_InstanceOf(map__1901000335__10) { var tmp4 any; var root_1848 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = map__1901000335__10; if linked_1849 == nil { tmp4 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp4 = linked_1849.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1848, arg_1851) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1852 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = map__1901000335__10; if linked_1853 == nil { tmp5 = ifn_1854.Invoke_O__O(arg_1855) } else { tmp5 = linked_1853.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1852, arg_1855) }; map__1901000335__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp5, jrt.Object_class.ArrayClass())).Ref() } else { var tmp6 any; var root_1856 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = map__1901000335__10; if linked_1857 == nil { tmp6 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp6 = linked_1857.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1856, arg_1859) }; if jrt.J2g_Truth(tmp6) { var root_1860 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = map__1901000335__10; if linked_1861 == nil { map__1901000335__11 = ifn_1862.Invoke_O__O(arg_1863) } else { map__1901000335__11 = linked_1861.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1860, arg_1863) } } else { map__1901000335__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000335__11 = map__1901000335__10 }; var layout__12 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_138); var line_file__13 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_139); var tests__14 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_143); var goos__15 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_144); var goroot__16 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_145); var goos_dir__17 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_146); var print_cache__18 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_121);









	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(out__2)).Mkdirs__Z()); if
	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_98) { } else {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp8 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_99); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil, Lit_101, nil, Lit_44, nil); var tmp10 *jrt.String
		if lang.Util_Equiv_O_O__Z_NoInit(goos__15, Lit_28) {
			var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_103, nil, Lit_44, nil); var tmp12 *lang.Keyword = A_arbace_build_go_A_const_46; var tmp13 any = tmp12.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp14 *lang.Keyword = A_arbace_build_go_A_const_112; var tmp15 any = tmp14.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp16 *jrt.String

			if jrt.J2g_Truth(goos_dir__17) {
				var tmp17 *jrt.RefArray = jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}); var tmp18 *lang.Keyword = A_arbace_build_go_A_const_46; var tmp19 any = tmp18.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp20 *lang.Keyword = A_arbace_build_go_A_const_112; var tmp21 any = tmp20.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp22 any; var root_2263 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2265 lang.IFn

				if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any = goos_dir__17; if linked_2264 == nil { tmp22 = ifn_2265.Invoke_O__O(arg_2266) } else { tmp22 = linked_2264.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2263, arg_2266) }
//line :462:1
				tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil, tmp21, nil, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp22)).GetAbsoluteFile__File()).GetPath__String().Ref(), nil)) } else {
//line :461:1
					tmp16 = nil }
//line :459:1
			tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp15, nil, tmp16.Ref())) } else {
//line :458:1
				tmp10 = nil }
//line :457:1
		tmp7.Invoke_O_O__O(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__9, nil, tmp10.Ref())).Ref()) }; var tmp23 any; var and__1927000168__auto____19 bool =







	lang.Util_Equiv_O_O__Z_NoInit(goos__15, Lit_28); if and__1927000168__auto____19 { var root_2272 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = goos_dir__17; if linked_2273 == nil { tmp23 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp23 = linked_2273.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2272, arg_2275) } } else { tmp23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }; if jrt.J2g_Truth(tmp23) {
		var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp25 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_104); var tmp26 any; var root_2276 any = A_arbace_build_go_A_const_163.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2276, A_arbace_build_go_tamago_go_sum_A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = goroot__16; if linked_2277 == nil { tmp26 = ifn_2278.Invoke_O__O(arg_2279) } else { tmp26 = linked_2277.(*A_arbace_build_go_tamago_go_sum_A).Invoke_O_O__O(root_2276, arg_2279) }; tmp24.Invoke_O_O__O(tmp25, tmp26) }; var root_2259 any =
	A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2259, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2261 lang.IFn; if linked_2260 == nil { ifn_2261 = lang.IFn_Cast(root_2259) } else { ifn_2261 = nil }; var arg_2262 any; var root_2254 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2254, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2256 lang.IFn; if
	linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any; if lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_98) { arg_2257 = nil } else { arg_2257 = A_arbace_build_go_A_const_147 }; var arg_2258 any; var root_2249 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2251 lang.IFn; if
	linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var arg_2253 any; var root_2244 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_2245 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2244, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_2246 lang.IFn; if linked_2245 == nil { ifn_2246 = lang.IFn_Cast(root_2244) } else { ifn_2246 = nil }; var arg_2247 any; var tmp27 any = A_arbace_build_go_print_module_fn__1901000337_A_New_O_O_O_O_O_O(dir__1, out__2, tests__14, line_file__13, layout__12, print_cache__18); var tmp28 *jrt.Class; var fncls__2243 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_A_fn_class; if
	fncls__2243 == nil { var fncls__2243d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_build_go_print_module_fn__1901000337_A_fn_class = fncls__2243d; tmp28 = fncls__2243d } else { tmp28 = fncls__2243 }; arg_2247 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_2248 any = packages__8; if /*line :469:1*/ linked_2245 == nil { arg_2253 = ifn_2246.Invoke_O_O__O(arg_2247, arg_2248) } else { arg_2253 = linked_2245.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_2244, arg_2247, arg_2248) }; if linked_2250 == nil { arg_2258 = ifn_2251.Invoke_O_O__O(arg_2252, arg_2253) } else { arg_2258 = linked_2250.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2249, arg_2252, arg_2253) }; if /*line :468:1*/ linked_2255 == nil { arg_2262 = ifn_2256.Invoke_O_O__O(arg_2257, arg_2258) } else { arg_2262 = linked_2255.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2254, arg_2257, arg_2258) }; if /*line :467:1*/ linked_2260 == nil { return ifn_2261.Invoke_O__O(arg_2262) } else { return linked_2260.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2259, arg_2262) } }


func A_arbace_build_go_print_module_fn__1901000337_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_print_module_fn__1901000337_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :470:1
func (t *A_arbace_build_go_print_module_fn__1901000337_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :470:1
func (t *A_arbace_build_go_print_module_fn__1901000337_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z_NoInit(Lit_96, A_arbace_build_go_A_const_127.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_build_go_A_const_127.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__1901000338__3_ any; var tmp2 any = A_arbace_build_go_A_const_138; var tmp3 any; var or__1927000174__auto____3 any = /*line :470:1*/t.F_layout; if

	jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.J2g_Truth(t.F_line_file) { tmp3 = A_arbace_build_go_A_const_148 } else { tmp3 = A_arbace_build_go_A_const_149 } }; G__1901000338__3_ = /*line :470:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.J2g_Truth(t.F_line_file) {
		var root_1864 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = G__1901000338__3_; var arg_1868 any = A_arbace_build_go_A_const_139; var arg_1869 any = jrt.Boolean_TRUE.Ref(); if linked_1865 == nil { opts__3 = ifn_1866.Invoke_O_O_O__O(arg_1867, arg_1868, arg_1869) } else { opts__3 = linked_1865.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1864, arg_1867, arg_1868, arg_1869) } } else {
//line :472:1
			opts__3 = G__1901000338__3_ }; var test_files__4 any; var root_1875 any = /*line :470:1*/A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1877 lang.IFn; if



	linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any; var root_1870 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_150; var arg_1874 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_1871 == nil { arg_1878 = ifn_1872.Invoke_O_O__O(arg_1873, arg_1874) } else { arg_1878 = linked_1871.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1870, arg_1873, arg_1874) }; if linked_1876 == nil { test_files__4 = ifn_1877.Invoke_O__O(arg_1878) } else { test_files__4 = linked_1876.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1875, arg_1878) }; var printable__5 any; var tmp5 any = /*line :470:1*/A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_New_O_O(test_files__4, t.F_tests); var tmp6 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class; if
	fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class = fncls__1900d; tmp6 = fncls__1900d } else { tmp6 = fncls__1900 }; printable__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var host_id__6 any = /*line :470:1*/jrt.System_Getenv_String__String(Lit_107).Ref(); var entry__7 any; var tmp7 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.J2g_Truth(and__1927000168__auto____7) { var root_1901 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = host_id__6; if linked_1902 == nil { tmp7 = ifn_1903.Invoke_O__O(arg_1904) } else { tmp7 = linked_1902.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1901, arg_1904) } } else { tmp7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp7) { var k__7 any; var root_1905 any = A_arbace_build_go_A_const_152.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, A_arbace_build_go_print_cache_key_A_fn_class); var ifn_1907 lang.IFn
		if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = host_id__6; var arg_1909 any = pkg__1; var arg_1910 any = t.F_dir; var arg_1911 any = opts__3; var arg_1912 any = t.F_tests; if linked_1906 == nil { k__7 = ifn_1907.Invoke_O_O_O_O_O__O(arg_1908, arg_1909, arg_1910, arg_1911, arg_1912) } else { k__7 = linked_1906.(*A_arbace_build_go_print_cache_key_A).Invoke_O_O_O_O_O_O__O(root_1905, arg_1908, arg_1909, arg_1910, arg_1911, arg_1912) }
//line :479:1
		var tmp8 *jrt.Class = A_arbace_build_go_A_const_67; var tmp9 any; var root_1913 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1915 lang.IFn

		if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = t.F_print_cache; if linked_1914 == nil { tmp9 = ifn_1915.Invoke_O__O(arg_1916) } else { tmp9 = linked_1914.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1913, arg_1916) }
//line :479:1
		var tmp10 *jrt.String = jrt.String_Cast(tmp9); var tmp11 any; var root_1917 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1919 lang.IFn

		if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = k__7; var arg_1921 any = A_arbace_build_go_A_const_134; var arg_1922 any = A_arbace_build_go_A_const_153; if linked_1918 == nil { tmp11 = ifn_1919.Invoke_O_O_O__O(arg_1920, arg_1921, arg_1922) } else { tmp11 = linked_1918.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1917, arg_1920, arg_1921, arg_1922) }
//line :479:1
		entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp8, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(tmp10, jrt.String_Cast(tmp11)), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.J2g_Truth(entry__7) { var root_1923 any = A_arbace_build_go_A_const_154.GetRawRoot__O(); var linked_1924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1923, A_arbace_build_go_cached_texts_A_fn_class); var ifn_1925 lang.IFn; if linked_1924 == nil { ifn_1925 = lang.IFn_Cast(root_1923) } else { ifn_1925 = nil }; var arg_1926 any = entry__7; if linked_1924 == nil { or__1927000174__auto____8 = ifn_1925.Invoke_O__O(arg_1926) } else { or__1927000174__auto____8 = linked_1924.(*A_arbace_build_go_cached_texts_A).Invoke_O_O__O(root_1923, arg_1926) } } else { or__1927000174__auto____8 = nil }; if jrt.J2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var root_1935 any = A_arbace_build_go_A_const_155.GetRawRoot__O(); var linked_1936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1935, aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A_fn_class); var ifn_1937 lang.IFn
		if linked_1936 == nil { ifn_1937 = lang.IFn_Cast(root_1935) } else { ifn_1937 = nil }; var arg_1938 any; var G__1901000345__9_ any; var tmp12 lang.IFn = lang.IFn_Cast(printable__5); var tmp13 any; var root_1931 any = A_arbace_build_go_A_const_157.GetRawRoot__O(); var linked_1932 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1931, A_arbace_build_go_collected_package_A_fn_class); var ifn_1933 lang.IFn; if linked_1932 == nil { ifn_1933 = lang.IFn_Cast(root_1931) } else { ifn_1933 = nil }; var arg_1934 any = pkg__1; if linked_1932 == nil { tmp13 = ifn_1933.Invoke_O__O(arg_1934) } else { tmp13 = linked_1932.(*A_arbace_build_go_collected_package_A).Invoke_O_O__O(root_1931, arg_1934) }; G__1901000345__9_ = tmp12.Invoke_O__O(tmp13); if jrt.J2g_Truth(t.F_line_file) { var root_1927 any = A_arbace_build_go_A_const_156.GetRawRoot__O(); var linked_1928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1927, A_arbace_build_go_with_line_files_A_fn_class); var ifn_1929 lang.IFn; if linked_1928 == nil { ifn_1929 = lang.IFn_Cast(root_1927) } else { ifn_1929 = nil }; var arg_1930 any = G__1901000345__9_; if linked_1928 == nil { arg_1938 = ifn_1929.Invoke_O__O(arg_1930) } else { arg_1938 = linked_1928.(*A_arbace_build_go_with_line_files_A).Invoke_O_O__O(root_1927, arg_1930) } } else { arg_1938 = G__1901000345__9_ }; var arg_1939 any = opts__3; if linked_1936 == nil { t__9 = ifn_1937.Invoke_O_O__O(arg_1938, arg_1939) } else { t__9 = linked_1936.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A).Invoke_O_O_O__O(root_1935, arg_1938, arg_1939) }
		if jrt.J2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(entry__7)).GetParentFile__File()).Mkdirs__Z())
			var root_1980 any = A_arbace_build_go_A_const_160.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, A_arbace_build_go_cache_texts_BANG__A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = entry__7; var arg_1984 any = t__9; if linked_1981 == nil { ifn_1982.Invoke_O_O__O(arg_1983, arg_1984) } else { linked_1981.(*A_arbace_build_go_cache_texts_BANG__A).Invoke_O_O_O__O(root_1980, arg_1983, arg_1984) } }
//line :482:1
		texts__8 = t__9 }; var declared__9 any; var tmp14 /*line :470:1*/*lang.Keyword = A_arbace_build_go_A_const_136; var temp__1927000414__auto____9 any = tmp14.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if

















	jrt.J2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var root_1940 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1941 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1940, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1942 lang.IFn
		if linked_1941 == nil { ifn_1942 = lang.IFn_Cast(root_1940) } else { ifn_1942 = nil }; var arg_1943 any = fs__10; var arg_1944 any; if jrt.J2g_Truth(t.F_tests) { var tmp15 *lang.Keyword = A_arbace_build_go_A_const_150; arg_1944 = tmp15.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)) } else { arg_1944 = nil }; if linked_1941 == nil { declared__9 = ifn_1942.Invoke_O_O__O(arg_1943, arg_1944) } else { declared__9 = linked_1941.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1940, arg_1943, arg_1944) } } else {
//line :488:1
			declared__9 = nil }; var rel__10 any; var tmp16 any = /*line :470:1*/A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_New_O(pkg__1); var tmp17 *jrt.Class; var fncls__1945 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class; if
	fncls__1945 == nil { var fncls__1945d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class = fncls__1945d; tmp17 = fncls__1945d } else { tmp17 = fncls__1945 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var src__11 any; var root_1946 any = /*line :470:1*/A_arbace_build_go_A_const_135.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, A_arbace_build_go_forms_dir_A_fn_class); var ifn_1948 lang.IFn; if




















	linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any = pkg__1; if linked_1947 == nil { src__11 = ifn_1948.Invoke_O__O(arg_1949) } else { src__11 = linked_1947.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_1946, arg_1949) }; var tmp18 any; var and__1927000168__auto____12 any = declared__9; if
	jrt.J2g_Truth(and__1927000168__auto____12) { var root_2002 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any; var root_1990 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any; var root_1985 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1986 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1985, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1987 lang.IFn; if linked_1986 == nil { ifn_1987 = lang.IFn_Cast(root_1985) } else { ifn_1987 = nil }; var arg_1988 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1989 any = declared__9; if linked_1986 == nil { arg_1993 = ifn_1987.Invoke_O_O__O(arg_1988, arg_1989) } else { arg_1993 = linked_1986.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1985, arg_1988, arg_1989) }; if linked_1991 == nil { arg_2005 = ifn_1992.Invoke_O__O(arg_1993) } else { arg_2005 = linked_1991.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1990, arg_1993) }; var arg_2006 any; var root_1998 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any; var root_1994 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = texts__8; if linked_1995 == nil { arg_2001 = ifn_1996.Invoke_O__O(arg_1997) } else { arg_2001 = linked_1995.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1994, arg_1997) }; if linked_1999 == nil { arg_2006 = ifn_2000.Invoke_O__O(arg_2001) } else { arg_2006 = linked_1999.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1998, arg_2001) }; if linked_2003 == nil { tmp18 = ifn_2004.Invoke_O_O__O(arg_2005, arg_2006) } else { tmp18 = linked_2003.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2002, arg_2005, arg_2006) } } else { tmp18 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp18) {
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_109, nil, Lit_110, nil); var tmp21 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp22 any = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(declared__9); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()); var tmp24 any; var root_2015 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2015, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2017 lang.IFn
		if linked_2016 == nil { ifn_2017 = lang.IFn_Cast(root_2015) } else { ifn_2017 = nil }; var arg_2018 any; var root_2011 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any = texts__8; if linked_2012 == nil { arg_2018 = ifn_2013.Invoke_O__O(arg_2014) } else { arg_2018 = linked_2012.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2011, arg_2014) }; if linked_2016 == nil { tmp24 = ifn_2017.Invoke_O__O(arg_2018) } else { tmp24 = linked_2016.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2015, arg_2018) }
//line :493:1
		tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, tmp22, nil, tmp23.Invoke_O__O(tmp24))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(pdir__2)).Mkdirs__Z()); var seq_1901000348__12 any; var root_2027 any = /*line :470:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2028 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2027, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2029 lang.IFn; if

























	linked_2028 == nil { ifn_2029 = lang.IFn_Cast(root_2027) } else { ifn_2029 = nil }; var arg_2030 any = texts__8; if linked_2028 == nil { seq_1901000348__12 = ifn_2029.Invoke_O__O(arg_2030) } else { seq_1901000348__12 = linked_2028.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2027, arg_2030) }; var chunk_1901000349__13 any; var count_1901000350__14 int64 = 0; var i_1901000351__15 int64 = 0; L1:
//line :470:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000351__15, count_1901000350__14) { var vec__1901000352__16 any = lang.Indexed_Cast(chunk_1901000349__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000351__15)); var n__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000352__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000352__16, lang.RT_IntCast_J__I_NoInit(1), nil)
			if jrt.File_InstanceOf(text__18) {
				var root_2087 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2087, A_arbace_build_go_copy_file_A_fn_class); var ifn_2089 lang.IFn; if linked_2088 == nil { ifn_2089 = lang.IFn_Cast(root_2087) } else { ifn_2089 = nil }; var arg_2090 any = text__18; var arg_2091 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)); if linked_2088 == nil { ifn_2089.Invoke_O_O__O(arg_2090, arg_2091) } else { linked_2088.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2087, arg_2090, arg_2091) } } else {
					lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18) }
//line :496:1
			seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000351__15); continue L1 } else { var temp__1927000414__auto____16 any; var root_2031 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = seq_1901000348__12; if linked_2032 == nil { temp__1927000414__auto____16 = ifn_2033.Invoke_O__O(arg_2034) } else { temp__1927000414__auto____16 = linked_2032.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2031, arg_2034) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1901000348__17 any = temp__1927000414__auto____16; var tmp25 any; var root_2035 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2035, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2037 lang.IFn; if linked_2036 == nil { ifn_2037 = lang.IFn_Cast(root_2035) } else { ifn_2037 = nil }; var arg_2038 any = seq_1901000348__17; if linked_2036 == nil { tmp25 = ifn_2037.Invoke_O__O(arg_2038) } else { tmp25 = linked_2036.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2035, arg_2038) }; if jrt.J2g_Truth(tmp25) { var c__1927000678__auto____18 any; var root_2039 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any = seq_1901000348__17; if linked_2040 == nil { c__1927000678__auto____18 = ifn_2041.Invoke_O__O(arg_2042) } else { c__1927000678__auto____18 = linked_2040.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2039, arg_2042) }; var tmp26 any; var root_2097 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2098 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2097, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2099 lang.IFn; if linked_2098 == nil { ifn_2099 = lang.IFn_Cast(root_2097) } else { ifn_2099 = nil }; var arg_2100 any = seq_1901000348__17; if linked_2098 == nil { tmp26 = ifn_2099.Invoke_O__O(arg_2100) } else { tmp26 = linked_2098.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2097, arg_2100) }; seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = tmp26, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000355__18 any; var root_2043 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2043, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2045 lang.IFn; if linked_2044 == nil { ifn_2045 = lang.IFn_Cast(root_2043) } else { ifn_2045 = nil }; var arg_2046 any = seq_1901000348__17; if linked_2044 == nil { vec__1901000355__18 = ifn_2045.Invoke_O__O(arg_2046) } else { vec__1901000355__18 = linked_2044.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2043, arg_2046) }; var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000355__18, lang.RT_IntCast_J__I_NoInit(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000355__18, lang.RT_IntCast_J__I_NoInit(1), nil)
				if jrt.File_InstanceOf(text__20) {
					var root_2101 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2101, A_arbace_build_go_copy_file_A_fn_class); var ifn_2103 lang.IFn; if linked_2102 == nil { ifn_2103 = lang.IFn_Cast(root_2101) } else { ifn_2103 = nil }; var arg_2104 any = text__20; var arg_2105 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)); if linked_2102 == nil { ifn_2103.Invoke_O_O__O(arg_2104, arg_2105) } else { linked_2102.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2101, arg_2104, arg_2105) } } else {
						lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20) }
//line :496:1
				var tmp27 any; var root_2111 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2111, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2113 lang.IFn; if linked_2112 == nil { ifn_2113 = lang.IFn_Cast(root_2111) } else { ifn_2113 = nil }; var arg_2114 any = seq_1901000348__17; if linked_2112 == nil { tmp27 = ifn_2113.Invoke_O__O(arg_2114) } else { tmp27 = linked_2112.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2111, arg_2114) }; seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = tmp27, nil, 0, 0; continue L1 } } }
//line :470:1
		break L1 }; var seq_1901000358__12 any; var root_2047 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2048 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2047, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2049 lang.IFn; if





























	linked_2048 == nil { ifn_2049 = lang.IFn_Cast(root_2047) } else { ifn_2049 = nil }; var tmp28 *lang.Keyword = A_arbace_build_go_A_const_158; var arg_2050 any = tmp28.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_2048 == nil { seq_1901000358__12 = ifn_2049.Invoke_O__O(arg_2050) } else { seq_1901000358__12 = linked_2048.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2047, arg_2050) }; var chunk_1901000359__13 any; var count_1901000360__14 int64 = 0; var i_1901000361__15 int64 = 0; L2:
//line :470:1
	for {





























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000361__15, count_1901000360__14) { var f__16 any = lang.Indexed_Cast(chunk_1901000359__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000361__15)); var root_2123 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2123, A_arbace_build_go_copy_file_A_fn_class); var ifn_2125 lang.IFn
			if linked_2124 == nil { ifn_2125 = lang.IFn_Cast(root_2123) } else { ifn_2125 = nil }; var arg_2126 any; var tmp29 *jrt.File = jrt.File_Cast(src__11); var tmp30 any; var root_2115 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2116 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2115, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2117 lang.IFn; if linked_2116 == nil { ifn_2117 = lang.IFn_Cast(root_2115) } else { ifn_2117 = nil }; var arg_2118 any = f__16; if linked_2116 == nil { tmp30 = ifn_2117.Invoke_O__O(arg_2118) } else { tmp30 = linked_2116.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2115, arg_2118) }; arg_2126 = jrt.File_New_File_String(tmp29, jrt.String_Cast(tmp30)); var arg_2127 any; var tmp31 *jrt.File = jrt.File_Cast(pdir__2); var tmp32 any; var root_2119 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2120 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2119, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2121 lang.IFn; if linked_2120 == nil { ifn_2121 = lang.IFn_Cast(root_2119) } else { ifn_2121 = nil }; var arg_2122 any = f__16; if linked_2120 == nil { tmp32 = ifn_2121.Invoke_O__O(arg_2122) } else { tmp32 = linked_2120.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2119, arg_2122) }; arg_2127 = jrt.File_New_File_String(tmp31, jrt.String_Cast(tmp32)); if linked_2124 == nil { ifn_2125.Invoke_O_O__O(arg_2126, arg_2127) } else { linked_2124.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2123, arg_2126, arg_2127) }
//line :500:1
			seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000361__15); continue L2 } else { var temp__1927000414__auto____16_2 any; var root_2051 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2052 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2051, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2053 lang.IFn; if linked_2052 == nil { ifn_2053 = lang.IFn_Cast(root_2051) } else { ifn_2053 = nil }; var arg_2054 any = seq_1901000358__12; if linked_2052 == nil { temp__1927000414__auto____16_2 = ifn_2053.Invoke_O__O(arg_2054) } else { temp__1927000414__auto____16_2 = linked_2052.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2051, arg_2054) }; if jrt.J2g_Truth(temp__1927000414__auto____16_2) { var seq_1901000358__17 any = temp__1927000414__auto____16_2; var tmp33 any; var root_2055 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2056 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2055, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2057 lang.IFn; if linked_2056 == nil { ifn_2057 = lang.IFn_Cast(root_2055) } else { ifn_2057 = nil }; var arg_2058 any = seq_1901000358__17; if linked_2056 == nil { tmp33 = ifn_2057.Invoke_O__O(arg_2058) } else { tmp33 = linked_2056.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2055, arg_2058) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____18_2 any; var root_2059 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2060 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2059, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2061 lang.IFn; if linked_2060 == nil { ifn_2061 = lang.IFn_Cast(root_2059) } else { ifn_2061 = nil }; var arg_2062 any = seq_1901000358__17; if linked_2060 == nil { c__1927000678__auto____18_2 = ifn_2061.Invoke_O__O(arg_2062) } else { c__1927000678__auto____18_2 = linked_2060.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2059, arg_2062) }; var tmp34 any; var root_2128 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = seq_1901000358__17; if linked_2129 == nil { tmp34 = ifn_2130.Invoke_O__O(arg_2131) } else { tmp34 = linked_2129.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2128, arg_2131) }; seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = tmp34, c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var f__18 any; var root_2063 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2064 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2063, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2065 lang.IFn; if linked_2064 == nil { ifn_2065 = lang.IFn_Cast(root_2063) } else { ifn_2065 = nil }; var arg_2066 any = seq_1901000358__17; if linked_2064 == nil { f__18 = ifn_2065.Invoke_O__O(arg_2066) } else { f__18 = linked_2064.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2063, arg_2066) }
				var root_2140 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2140, A_arbace_build_go_copy_file_A_fn_class); var ifn_2142 lang.IFn; if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any; var tmp35 *jrt.File = jrt.File_Cast(src__11); var tmp36 any; var root_2132 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2132, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = f__18; if linked_2133 == nil { tmp36 = ifn_2134.Invoke_O__O(arg_2135) } else { tmp36 = linked_2133.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2132, arg_2135) }; arg_2143 = jrt.File_New_File_String(tmp35, jrt.String_Cast(tmp36)); var arg_2144 any; var tmp37 *jrt.File = jrt.File_Cast(pdir__2); var tmp38 any; var root_2136 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2137 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2136, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2138 lang.IFn; if linked_2137 == nil { ifn_2138 = lang.IFn_Cast(root_2136) } else { ifn_2138 = nil }; var arg_2139 any = f__18; if linked_2137 == nil { tmp38 = ifn_2138.Invoke_O__O(arg_2139) } else { tmp38 = linked_2137.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2136, arg_2139) }; arg_2144 = jrt.File_New_File_String(tmp37, jrt.String_Cast(tmp38)); if linked_2141 == nil { ifn_2142.Invoke_O_O__O(arg_2143, arg_2144) } else { linked_2141.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2140, arg_2143, arg_2144) }
//line :500:1
				var tmp39 any; var root_2145 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2146 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2145, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2147 lang.IFn; if linked_2146 == nil { ifn_2147 = lang.IFn_Cast(root_2145) } else { ifn_2147 = nil }; var arg_2148 any = seq_1901000358__17; if linked_2146 == nil { tmp39 = ifn_2147.Invoke_O__O(arg_2148) } else { tmp39 = linked_2146.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2145, arg_2148) }; seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = tmp39, nil, 0, 0; continue L2 } } }
//line :470:1
		break L2 }; var seq_1901000362__12 any; var root_2067 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2068 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2067, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2069 lang.IFn; if































	linked_2068 == nil { ifn_2069 = lang.IFn_Cast(root_2067) } else { ifn_2069 = nil }; var tmp40 *lang.Keyword = A_arbace_build_go_A_const_159; var arg_2070 any = tmp40.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_2068 == nil { seq_1901000362__12 = ifn_2069.Invoke_O__O(arg_2070) } else { seq_1901000362__12 = linked_2068.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2067, arg_2070) }; var chunk_1901000363__13 any; var count_1901000364__14 int64 = 0; var i_1901000365__15 int64 = 0; L3:
//line :470:1
	for {































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000365__15, count_1901000364__14) { var vec__1901000366__16 any = lang.Indexed_Cast(chunk_1901000363__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000365__15)); var f__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000366__16, lang.RT_IntCast_J__I_NoInit(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000366__16, lang.RT_IntCast_J__I_NoInit(1), nil); var from__19 any; var tmp41 *jrt.File = jrt.File_Cast(src__11); var tmp42 any; var root_2149 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2150 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2149, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2151 lang.IFn
			if linked_2150 == nil { ifn_2151 = lang.IFn_Cast(root_2149) } else { ifn_2151 = nil }; var arg_2152 any = f__17; if linked_2150 == nil { tmp42 = ifn_2151.Invoke_O__O(arg_2152) } else { tmp42 = linked_2150.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2149, arg_2152) }
//line :502:1
			from__19 = jrt.File_New_File_String(tmp41, jrt.String_Cast(tmp42))

			if jrt.NN(jrt.File_Cast(from__19)).IsFile__Z() { } else {
				var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp45 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp46 any; var root_2162 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_2163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2162, A_arbace_build_go_rel_path_A_fn_class); var ifn_2164 lang.IFn; if linked_2163 == nil { ifn_2164 = lang.IFn_Cast(root_2162) } else { ifn_2164 = nil }; var arg_2165 any = t.F_dir; var arg_2166 any = from__19; if linked_2163 == nil { tmp46 = ifn_2164.Invoke_O_O__O(arg_2165, arg_2166) } else { tmp46 = linked_2163.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2162, arg_2165, arg_2166) }; tmp43.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp44, jrt.RefArrayOf(jrt.Object_class, tmp45, nil, tmp46)).Ref()) }
			var tmp47 any; var and__1927000168__auto____20 any = h__18; if jrt.J2g_Truth(and__1927000168__auto____20) { var root_2179 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2181 lang.IFn; if linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any; var root_2171 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, A_arbace_build_go_sha256_A_fn_class); var ifn_2173 lang.IFn; if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any = from__19; if linked_2172 == nil { arg_2182 = ifn_2173.Invoke_O__O(arg_2174) } else { arg_2182 = linked_2172.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2171, arg_2174) }; var arg_2183 any; var root_2175 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = h__18; if linked_2176 == nil { arg_2183 = ifn_2177.Invoke_O__O(arg_2178) } else { arg_2183 = linked_2176.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2175, arg_2178) }; if linked_2180 == nil { tmp47 = ifn_2181.Invoke_O_O__O(arg_2182, arg_2183) } else { tmp47 = linked_2180.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2179, arg_2182, arg_2183) } } else { tmp47 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp47) {
				var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp49 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113, nil, Lit_114, nil); var tmp50 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp51 any; var root_2184 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2184, A_arbace_build_go_sha256_A_fn_class); var ifn_2186 lang.IFn; if linked_2185 == nil { ifn_2186 = lang.IFn_Cast(root_2184) } else { ifn_2186 = nil }; var arg_2187 any = from__19; if linked_2185 == nil { tmp51 = ifn_2186.Invoke_O__O(arg_2187) } else { tmp51 = linked_2185.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2184, arg_2187) }; tmp48.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp49, jrt.RefArrayOf(jrt.Object_class, tmp50, nil, f__17, nil, tmp51, nil, h__18)).Ref())
			}
			var root_2157 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2158 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2157, A_arbace_build_go_copy_file_A_fn_class); var ifn_2159 lang.IFn; if linked_2158 == nil { ifn_2159 = lang.IFn_Cast(root_2157) } else { ifn_2159 = nil }; var arg_2160 any = from__19; var arg_2161 any; var tmp52 *jrt.File = jrt.File_Cast(pdir__2); var tmp53 any; var root_2153 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2154 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2153, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2155 lang.IFn; if linked_2154 == nil { ifn_2155 = lang.IFn_Cast(root_2153) } else { ifn_2155 = nil }; var arg_2156 any = f__17; if linked_2154 == nil { tmp53 = ifn_2155.Invoke_O__O(arg_2156) } else { tmp53 = linked_2154.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2153, arg_2156) }; arg_2161 = jrt.File_New_File_String(tmp52, jrt.String_Cast(tmp53)); if linked_2158 == nil { ifn_2159.Invoke_O_O__O(arg_2160, arg_2161) } else { linked_2158.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2157, arg_2160, arg_2161) }
//line :502:1
			seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000365__15); continue L3 } else { var temp__1927000414__auto____16_3 any; var root_2071 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2072 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2071, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2073 lang.IFn; if linked_2072 == nil { ifn_2073 = lang.IFn_Cast(root_2071) } else { ifn_2073 = nil }; var arg_2074 any = seq_1901000362__12; if linked_2072 == nil { temp__1927000414__auto____16_3 = ifn_2073.Invoke_O__O(arg_2074) } else { temp__1927000414__auto____16_3 = linked_2072.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2071, arg_2074) }; if jrt.J2g_Truth(temp__1927000414__auto____16_3) { var seq_1901000362__17 any = temp__1927000414__auto____16_3; var tmp54 any; var root_2075 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = seq_1901000362__17; if linked_2076 == nil { tmp54 = ifn_2077.Invoke_O__O(arg_2078) } else { tmp54 = linked_2076.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2075, arg_2078) }; if jrt.J2g_Truth(tmp54) { var c__1927000678__auto____18_3 any; var root_2079 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2081 lang.IFn; if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any = seq_1901000362__17; if linked_2080 == nil { c__1927000678__auto____18_3 = ifn_2081.Invoke_O__O(arg_2082) } else { c__1927000678__auto____18_3 = linked_2080.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2079, arg_2082) }; var tmp55 any; var root_2192 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2192, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2194 lang.IFn; if linked_2193 == nil { ifn_2194 = lang.IFn_Cast(root_2192) } else { ifn_2194 = nil }; var arg_2195 any = seq_1901000362__17; if linked_2193 == nil { tmp55 = ifn_2194.Invoke_O__O(arg_2195) } else { tmp55 = linked_2193.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2192, arg_2195) }; seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = tmp55, c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1901000369__18 any; var root_2083 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any = seq_1901000362__17; if linked_2084 == nil { vec__1901000369__18 = ifn_2085.Invoke_O__O(arg_2086) } else { vec__1901000369__18 = linked_2084.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2083, arg_2086) }; var f__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000369__18, lang.RT_IntCast_J__I_NoInit(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000369__18, lang.RT_IntCast_J__I_NoInit(1), nil); var from__21 any; var tmp56 *jrt.File = jrt.File_Cast(src__11); var tmp57 any; var root_2196 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2196, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2198 lang.IFn
				if linked_2197 == nil { ifn_2198 = lang.IFn_Cast(root_2196) } else { ifn_2198 = nil }; var arg_2199 any = f__19; if linked_2197 == nil { tmp57 = ifn_2198.Invoke_O__O(arg_2199) } else { tmp57 = linked_2197.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2196, arg_2199) }
//line :502:1
				from__21 = jrt.File_New_File_String(tmp56, jrt.String_Cast(tmp57))

				if jrt.NN(jrt.File_Cast(from__21)).IsFile__Z() { } else {
					var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp59 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp60 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp61 any; var root_2209 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_2210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2209, A_arbace_build_go_rel_path_A_fn_class); var ifn_2211 lang.IFn; if linked_2210 == nil { ifn_2211 = lang.IFn_Cast(root_2209) } else { ifn_2211 = nil }; var arg_2212 any = t.F_dir; var arg_2213 any = from__21; if linked_2210 == nil { tmp61 = ifn_2211.Invoke_O_O__O(arg_2212, arg_2213) } else { tmp61 = linked_2210.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2209, arg_2212, arg_2213) }; tmp58.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp59, jrt.RefArrayOf(jrt.Object_class, tmp60, nil, tmp61)).Ref()) }
				var tmp62 any; var and__1927000168__auto____22 any = h__20; if jrt.J2g_Truth(and__1927000168__auto____22) { var root_2226 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2227 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2226, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2228 lang.IFn; if linked_2227 == nil { ifn_2228 = lang.IFn_Cast(root_2226) } else { ifn_2228 = nil }; var arg_2229 any; var root_2218 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, A_arbace_build_go_sha256_A_fn_class); var ifn_2220 lang.IFn; if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any = from__21; if linked_2219 == nil { arg_2229 = ifn_2220.Invoke_O__O(arg_2221) } else { arg_2229 = linked_2219.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2218, arg_2221) }; var arg_2230 any; var root_2222 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2222, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2224 lang.IFn; if linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = h__20; if linked_2223 == nil { arg_2230 = ifn_2224.Invoke_O__O(arg_2225) } else { arg_2230 = linked_2223.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2222, arg_2225) }; if linked_2227 == nil { tmp62 = ifn_2228.Invoke_O_O__O(arg_2229, arg_2230) } else { tmp62 = linked_2227.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2226, arg_2229, arg_2230) } } else { tmp62 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp62) {
					var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp64 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113, nil, Lit_114, nil); var tmp65 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp66 any; var root_2231 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, A_arbace_build_go_sha256_A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = from__21; if linked_2232 == nil { tmp66 = ifn_2233.Invoke_O__O(arg_2234) } else { tmp66 = linked_2232.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2231, arg_2234) }; tmp63.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp64, jrt.RefArrayOf(jrt.Object_class, tmp65, nil, f__19, nil, tmp66, nil, h__20)).Ref())
				}
				var root_2204 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2204, A_arbace_build_go_copy_file_A_fn_class); var ifn_2206 lang.IFn; if linked_2205 == nil { ifn_2206 = lang.IFn_Cast(root_2204) } else { ifn_2206 = nil }; var arg_2207 any = from__21; var arg_2208 any; var tmp67 *jrt.File = jrt.File_Cast(pdir__2); var tmp68 any; var root_2200 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2201 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2200, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2202 lang.IFn; if linked_2201 == nil { ifn_2202 = lang.IFn_Cast(root_2200) } else { ifn_2202 = nil }; var arg_2203 any = f__19; if linked_2201 == nil { tmp68 = ifn_2202.Invoke_O__O(arg_2203) } else { tmp68 = linked_2201.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2200, arg_2203) }; arg_2208 = jrt.File_New_File_String(tmp67, jrt.String_Cast(tmp68)); if linked_2205 == nil { ifn_2206.Invoke_O_O__O(arg_2207, arg_2208) } else { linked_2205.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2204, arg_2207, arg_2208) }
//line :502:1
				var tmp69 any; var root_2239 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = seq_1901000362__17; if linked_2240 == nil { tmp69 = ifn_2241.Invoke_O__O(arg_2242) } else { tmp69 = linked_2240.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2239, arg_2242) }; seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = tmp69, nil, 0, 0; continue L3 } } }
//line :470:1
		break L3 }; var root_1975 any =







































	A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1976 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1975, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1977 lang.IFn; if linked_1976 == nil { ifn_1977 = lang.IFn_Cast(root_1975) } else { ifn_1977 = nil }; var arg_1978 any = rel__10; var arg_1979 any; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp71 any; var root_1950 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1950, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1952 lang.IFn; if linked_1951 == nil { ifn_1952 = lang.IFn_Cast(root_1950) } else { ifn_1952 = nil }; var arg_1953 any = texts__8; if linked_1951 == nil { tmp71 = ifn_1952.Invoke_O__O(arg_1953) } else { tmp71 = linked_1951.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1950, arg_1953) }; var tmp72 any = tmp71; var tmp73 any; var root_1954 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1955 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1954, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1956 lang.IFn; if linked_1955 == nil { ifn_1956 = lang.IFn_Cast(root_1954) } else { ifn_1956 = nil }; var arg_1957 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp74 *lang.Keyword = A_arbace_build_go_A_const_158; var arg_1958 any = tmp74.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_1955 == nil { tmp73 = ifn_1956.Invoke_O_O__O(arg_1957, arg_1958) } else { tmp73 = linked_1955.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1954, arg_1957, arg_1958) }; var tmp75 any = tmp73; var tmp76 any; var root_1964 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1965 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1964, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1966 lang.IFn; if
	linked_1965 == nil { ifn_1966 = lang.IFn_Cast(root_1964) } else { ifn_1966 = nil }; var arg_1967 any; var root_1959 any = A_arbace_build_go_A_const_81.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1963 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); if linked_1960 == nil { arg_1967 = ifn_1961.Invoke_O_O__O(arg_1962, arg_1963) } else { arg_1967 = linked_1960.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1959, arg_1962, arg_1963) }; var tmp77 *lang.Keyword = A_arbace_build_go_A_const_159; var arg_1968 any = tmp77.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_1965 == nil { tmp76 = ifn_1966.Invoke_O_O__O(arg_1967, arg_1968) } else { tmp76 = linked_1965.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1964, arg_1967, arg_1968) }; arg_1979 = /*line :510:1*/tmp70.Invoke_O_O_O__O(tmp72, tmp75, tmp76); if linked_1976 == nil { return ifn_1977.Invoke_O_O__O(arg_1978, arg_1979) } else { return linked_1976.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1975, arg_1978, arg_1979) } }
//line :471:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A{}; t.Ctor_O_O(p0, p1); return t }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A) Ctor_O_O(c__test_files, c__tests any) { t.F_test_files = c__test_files; t.F_tests = c__tests }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A) Invoke_O_O__O(self, p1__1901000329_SHARP___1 any) any {



	if jrt.J2g_Truth(t.F_tests) { return p1__1901000329_SHARP___1 } else {

		var root_1894 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_1895 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1894, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1896 lang.IFn; if linked_1895 == nil { ifn_1896 = lang.IFn_Cast(root_1894) } else { ifn_1896 = nil }; var arg_1897 any = p1__1901000329_SHARP___1; var arg_1898 any = A_arbace_build_go_A_const_136; var arg_1899 any; var tmp1 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_New_O(t.F_test_files); var tmp2 *jrt.Class; var fncls__1893 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class; if fncls__1893 == nil { var fncls__1893d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class = fncls__1893d; tmp2 = fncls__1893d } else { tmp2 = fncls__1893 }; arg_1899 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1895 == nil { return ifn_1896.Invoke_O_O_O__O(arg_1897, arg_1898, arg_1899) } else { return linked_1895.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1894, arg_1897, arg_1898, arg_1899) } } }
//line :471:1
func A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A{}; t.Ctor_O(p0); return t }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A) Invoke_O_O__O(self, p1__1901000330_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_96, A_arbace_build_go_A_const_127.Invoke_O__O(t.F_pkg)) { return p1__1901000330_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_127.Invoke_O__O(t.F_pkg), nil, p1__1901000330_SHARP___1)).Ref() } }
//line :477:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A{}; t.Ctor_O(p0); return t }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A) Invoke_O_O__O(self, fs__1 any) any { var root_1888 any = A_arbace_build_go_A_const_151.GetRawRoot__O(); var linked_1889 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1888, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_1890 lang.IFn; if linked_1889 == nil { ifn_1890 = lang.IFn_Cast(root_1888) } else { ifn_1890 = nil }; var arg_1891 any; var tmp1 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_New_O(t.F_test_files); var tmp2 *jrt.Class; var fncls__1887 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class; if fncls__1887 == nil { var fncls__1887d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class = fncls__1887d; tmp2 = fncls__1887d } else { tmp2 = fncls__1887 }; arg_1891 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1892 any = fs__1; if linked_1889 == nil { return ifn_1890.Invoke_O_O__O(arg_1891, arg_1892) } else { return linked_1889.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_1888, arg_1891, arg_1892) } }
//line :477:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A{}; t.Ctor_O(p0); return t }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A) Invoke_O_O__O(self, f__1 any) any { var root_1883 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); var tmp2 any; var root_1879 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = A_arbace_build_go_A_const_36.Invoke_O__O(f__1); if linked_1880 == nil { tmp2 = ifn_1881.Invoke_O__O(arg_1882) } else { tmp2 = linked_1880.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1879, arg_1882) }; arg_1886 = tmp1.Invoke_O__O(tmp2); if linked_1884 == nil { return ifn_1885.Invoke_O__O(arg_1886) } else { return linked_1884.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1883, arg_1886) } }







































func A_arbace_build_go_delete_tree_A_New() *A_arbace_build_go_delete_tree_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_delete_tree_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_build_go_delete_tree_A) Ctor() {}
//line :517:1
func (t *A_arbace_build_go_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.NN(jrt.File_Cast(f__0)).IsDirectory__Z() { var seq_1901000374__2 any; var root_2285 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2287 lang.IFn
		if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = jrt.NN(jrt.File_Cast(f__0)).ListFiles__File1().Ref(); if linked_2286 == nil { seq_1901000374__2 = ifn_2287.Invoke_O__O(arg_2288) } else { seq_1901000374__2 = linked_2286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2285, arg_2288) }
//line :518:1
		var chunk_1901000375__3 any; var count_1901000376__4 int64 = 0; var i_1901000377__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000377__5, count_1901000376__4) { var c__6 any = lang.Indexed_Cast(chunk_1901000375__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000377__5)); var root_2305 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = c__6; if linked_2306 == nil { ifn_2307.Invoke_O__O(arg_2308) } else { linked_2306.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2305, arg_2308) }; seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000377__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_2289 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = seq_1901000374__2; if linked_2290 == nil { temp__1927000414__auto____6 = ifn_2291.Invoke_O__O(arg_2292) } else { temp__1927000414__auto____6 = linked_2290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2289, arg_2292) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1901000374__7 any = temp__1927000414__auto____6; var tmp1 any; var root_2293 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = seq_1901000374__7; if linked_2294 == nil { tmp1 = ifn_2295.Invoke_O__O(arg_2296) } else { tmp1 = linked_2294.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2293, arg_2296) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_2297 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = seq_1901000374__7; if linked_2298 == nil { c__1927000678__auto____8 = ifn_2299.Invoke_O__O(arg_2300) } else { c__1927000678__auto____8 = linked_2298.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2297, arg_2300) }; var tmp2 any; var root_2309 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2311 lang.IFn; if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = seq_1901000374__7; if linked_2310 == nil { tmp2 = ifn_2311.Invoke_O__O(arg_2312) } else { tmp2 = linked_2310.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2309, arg_2312) }; seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_2301 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = seq_1901000374__7; if linked_2302 == nil { c__8 = ifn_2303.Invoke_O__O(arg_2304) } else { c__8 = linked_2302.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2301, arg_2304) }; var root_2313 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = c__8; if linked_2314 == nil { ifn_2315.Invoke_O__O(arg_2316) } else { linked_2314.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2313, arg_2316) }; var tmp3 any; var root_2317 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = seq_1901000374__7; if linked_2318 == nil { tmp3 = ifn_2319.Invoke_O__O(arg_2320) } else { tmp3 = linked_2318.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2317, arg_2320) }; seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :518:1
			break L1
		} }
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).Delete__Z()).Ref()
}
func A_arbace_build_go_build_A_New() *A_arbace_build_go_build_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_build_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_build_go_build_A) Ctor() {}
//line :522:1
func (t *A_arbace_build_go_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__1901000379__3 any) any { var map__1901000380__5 any = p__1901000379__3; var map__1901000380__6 any; if lang.ISeq_InstanceOf(map__1901000380__5) { var tmp1 any; var root_2321 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = map__1901000380__5; if linked_2322 == nil { tmp1 = ifn_2323.Invoke_O__O(arg_2324) } else { tmp1 = linked_2322.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2321, arg_2324) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2325 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = map__1901000380__5; if linked_2326 == nil { tmp2 = ifn_2327.Invoke_O__O(arg_2328) } else { tmp2 = linked_2326.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2325, arg_2328) }; map__1901000380__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](tmp2, jrt.Object_class.ArrayClass())).Ref() } else { var tmp3 any; var root_2329 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = map__1901000380__5; if linked_2330 == nil { tmp3 = ifn_2331.Invoke_O__O(arg_2332) } else { tmp3 = linked_2330.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2329, arg_2332) }; if jrt.J2g_Truth(tmp3) { var root_2333 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2335 lang.IFn; if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = map__1901000380__5; if linked_2334 == nil { map__1901000380__6 = ifn_2335.Invoke_O__O(arg_2336) } else { map__1901000380__6 = linked_2334.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2333, arg_2336) } } else { map__1901000380__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000380__6 = map__1901000380__5 }; var opts__7 any = map__1901000380__6; var work__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000380__6, A_arbace_build_go_A_const_164); var goroot__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000380__6, A_arbace_build_go_A_const_145); var prog__10 any; var root_2337 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, A_arbace_build_go_program_A_fn_class); var ifn_2339 lang.IFn; if



	linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = dir__0; var arg_2341 any = goroot__9; var arg_2342 any = opts__7; if linked_2338 == nil { prog__10 = ifn_2339.Invoke_O_O_O__O(arg_2340, arg_2341, arg_2342) } else { prog__10 = linked_2338.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2337, arg_2340, arg_2341, arg_2342) }; var main__11 any = /*line :522:1*/A_arbace_build_go_A_const_130.Invoke_O__O(prog__10); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_165; var config__12 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z_NoInit(work__8, nil); var work__14 any; if







	jrt.J2g_Truth(work__8) { var tmp5 any; var root_2343 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2345 lang.IFn
		if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = work__8; if linked_2344 == nil { tmp5 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp5 = linked_2344.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2343, arg_2346) }
//line :530:1
		work__14 = jrt.File_New_String(jrt.String_Cast(tmp5)) } else {

			var tmp6 *jrt.String = Lit_27; var tmp7 any; var root_2347 any = A_arbace_build_go_A_const_166.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = A_arbace_build_go_A_const_167; var arg_2351 any = A_arbace_build_go_A_const_134; if linked_2348 == nil { tmp7 = ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { tmp7 = linked_2348.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }; work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(tmp6, jrt.J2g_CastArray[*jrt.RefArray](tmp7, jrt.FileAttribute_class.ArrayClass())).ToFile__File().Ref() }; var tmp8 any; tmp23 := /*line :522:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_24)












				if jrt.NN(jrt.File_Cast(mod__17)).Exists__Z() { var root_2405 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2407 lang.IFn; if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any = mod__17; if linked_2406 == nil { ifn_2407.Invoke_O__O(arg_2408) } else { linked_2406.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2405, arg_2408) } }
				var root_2409 any = A_arbace_build_go_A_const_173.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, A_arbace_build_go_print_module_A_fn_class); var ifn_2411 lang.IFn; if linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = prog__10; var arg_2413 any = dir__0; var arg_2414 any = mod__17; var arg_2415 any = opts__7; if linked_2410 == nil { ifn_2411.Invoke_O_O_O_O__O(arg_2412, arg_2413, arg_2414, arg_2415) } else { linked_2410.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2409, arg_2412, arg_2413, arg_2414, arg_2415) }
//line :522:1
				var tags__18 any = A_arbace_build_go_A_const_168.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_144.Invoke_O__O(opts__7), Lit_28); var cmd__20 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_30, Lit_31, Lit_32); var tmp11 lang.IPersistentVector; var tmp12 any; var root_2352 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2354 lang.IFn

















				if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = tags__18; if linked_2353 == nil { tmp12 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp12 = linked_2353.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2352, arg_2355) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_2356 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = Lit_34; var arg_2360 any = tags__18; if linked_2357 == nil { tmp13 = ifn_2358.Invoke_O_O__O(arg_2359, arg_2360) } else { tmp13 = linked_2357.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2356, arg_2359, arg_2360) }; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_33, tmp13) } else { tmp11 = nil }
//line :539:1
				var tmp14 any = tmp11; var tmp15 lang.IPersistentVector

				if tamago_QMARK___19 { tmp15 = lang.Tuple_Create_O_O__IPersistentVector(Lit_35, A_arbace_build_go_A_const_169.GetRawRoot__O()) } else { tmp15 = nil }
//line :539:1
				var tmp16 any = tmp15; var tmp17 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_build_go_A_const_170.Invoke_O__O(opts__7)


				if jrt.J2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; var tmp18 any; var root_2361 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2363 lang.IFn
					if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = o__21; if linked_2362 == nil { tmp18 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp18 = linked_2362.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2361, arg_2364) }
//line :542:1
					tmp17 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp18)).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp17 = nil }
//line :539:1
				var tmp19 any = tmp17; var tmp20 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_build_go_A_const_171.Invoke_O__O(opts__7)




				if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; var tmp21 any; var root_2365 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2367 lang.IFn
					if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = f__21; if linked_2366 == nil { tmp21 = ifn_2367.Invoke_O__O(arg_2368) } else { tmp21 = linked_2366.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2365, arg_2368) }
//line :544:1
					tmp20 = lang.Tuple_Create_O_O__IPersistentVector(Lit_37, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp21)).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp20 = nil }
//line :539:1
				cmd__20 = tmp9.Invoke_O_O_O_O_O_O__O(tmp10, tmp14, tmp16, tmp19, tmp20, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.NN(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File()).GetPath__String().Ref(), A_arbace_build_go_A_const_46.Invoke_O__O(main__11)))
//line :522:1
				var env__21 any; var G__1901000385__21_ any; var root_2378 any = A_arbace_build_go_A_const_108.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, A_arbace_build_go_go_env_A_fn_class); var ifn_2380 lang.IFn
























				if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any = goroot__9; var arg_2382 any = arch__1; var arg_2383 any; var or__1927000174__auto____21 any = A_arbace_build_go_A_const_144.Invoke_O__O(opts__7); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_2383 = or__1927000174__auto____21 } else { arg_2383 = Lit_38 }; if linked_2379 == nil { G__1901000385__21_ = ifn_2380.Invoke_O_O_O__O(arg_2381, arg_2382, arg_2383) } else { G__1901000385__21_ = linked_2379.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_2378, arg_2381, arg_2382, arg_2383) }; var tmp22 any; var root_2384 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2386 lang.IFn
				if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = A_arbace_build_go_A_const_172.Invoke_O__O(config__12); if linked_2385 == nil { tmp22 = ifn_2386.Invoke_O__O(arg_2387) } else { tmp22 = linked_2385.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2384, arg_2387) }
//line :547:1
				if jrt.J2g_Truth(tmp22) {
					var root_2388 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = G__1901000385__21_; var arg_2392 any = Lit_39; var arg_2393 any = A_arbace_build_go_A_const_172.Invoke_O__O(config__12); if linked_2389 == nil { env__21 = ifn_2390.Invoke_O_O_O__O(arg_2391, arg_2392, arg_2393) } else { env__21 = linked_2389.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2388, arg_2391, arg_2392, arg_2393) } } else {
//line :547:1
						env__21 = G__1901000385__21_ }
//line :522:1
				var vec__1901000382__22 any; var root_2394 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, A_arbace_build_go_run_A_fn_class); var ifn_2396 lang.IFn


























				if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = cmd__20; var arg_2398 any = mod__17; var arg_2399 any = env__21; var arg_2400 any = jrt.Boolean_TRUE.Ref(); if linked_2395 == nil { vec__1901000382__22 = ifn_2396.Invoke_O_O_O_O__O(arg_2397, arg_2398, arg_2399, arg_2400) } else { vec__1901000382__22 = linked_2395.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_2394, arg_2397, arg_2398, arg_2399, arg_2400) }
//line :522:1
				var status__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000382__22, lang.RT_IntCast_J__I_NoInit(0), nil); tmp8 = status__23 }; return nil }(); if tmp_QMARK___13 {





























					var root_2401 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = work__14; if linked_2402 == nil { ifn_2403.Invoke_O__O(arg_2404) } else { linked_2402.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2401, arg_2404) } }; if /*line :522:1*/ tmp23 != nil { panic(tmp23) }; return tmp8 }































func A_arbace_build_go__main_A_New() *A_arbace_build_go__main_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_A{}; t.Ctor(); return t }
//line :554:1
func (t *A_arbace_build_go__main_A) Ctor() {}
//line :554:1
func (t *A_arbace_build_go__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :554:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_174, Lit_5, A_arbace_build_go_A_const_145, goroot__2)); L1: for { var G__1901000387__6_ any; var root_2416 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2418 lang.IFn




		if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = as__4; if linked_2417 == nil { G__1901000387__6_ = ifn_2418.Invoke_O__O(arg_2419) } else { G__1901000387__6_ = linked_2417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2416, arg_2419) }; switch lang.Util_Hash_O__I_NoInit(G__1901000387__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_6) {











			var tmp1 any; var root_2490 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = as__4; if linked_2491 == nil { tmp1 = ifn_2492.Invoke_O__O(arg_2493) } else { tmp1 = linked_2491.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2490, arg_2493) }; var tmp2 any = tmp1; var tmp3 any; var root_2498 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2500 lang.IFn; if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = opts__5; var arg_2502 any = A_arbace_build_go_A_const_123; var arg_2503 any; var root_2494 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = as__4; if linked_2495 == nil { arg_2503 = ifn_2496.Invoke_O__O(arg_2497) } else { arg_2503 = linked_2495.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2494, arg_2497) }; if linked_2499 == nil { tmp3 = ifn_2500.Invoke_O_O_O__O(arg_2501, arg_2502, arg_2503) } else { tmp3 = linked_2499.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2498, arg_2501, arg_2502, arg_2503) }; as__4, opts__5 = tmp2, tmp3; continue L1 }
//line :559:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_7) {









			var tmp4 any; var root_2504 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2506 lang.IFn; if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = as__4; if linked_2505 == nil { tmp4 = ifn_2506.Invoke_O__O(arg_2507) } else { tmp4 = linked_2505.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2504, arg_2507) }; var tmp5 any = tmp4; var tmp6 any; var root_2508 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = opts__5; var arg_2512 any = A_arbace_build_go_A_const_175; var arg_2513 any = jrt.Boolean_TRUE.Ref(); if linked_2509 == nil { tmp6 = ifn_2510.Invoke_O_O_O__O(arg_2511, arg_2512, arg_2513) } else { tmp6 = linked_2509.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2508, arg_2511, arg_2512, arg_2513) }; as__4, opts__5 = tmp5, tmp6; continue L1 }
//line :559:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_8) {










			var tmp7 any; var root_2514 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = as__4; if linked_2515 == nil { tmp7 = ifn_2516.Invoke_O__O(arg_2517) } else { tmp7 = linked_2515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2514, arg_2517) }; var tmp8 any = tmp7; var tmp9 any; var root_2518 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = opts__5; var arg_2522 any = A_arbace_build_go_A_const_143; var arg_2523 any = jrt.Boolean_TRUE.Ref(); if linked_2519 == nil { tmp9 = ifn_2520.Invoke_O_O_O__O(arg_2521, arg_2522, arg_2523) } else { tmp9 = linked_2519.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2518, arg_2521, arg_2522, arg_2523) }; as__4, opts__5 = tmp8, tmp9; continue L1 }
//line :559:1
		case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_9) {






			var tmp10 any; var root_2524 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2526 lang.IFn; if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = as__4; if linked_2525 == nil { tmp10 = ifn_2526.Invoke_O__O(arg_2527) } else { tmp10 = linked_2525.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2524, arg_2527) }; var tmp11 any = tmp10; var tmp12 any; var root_2532 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2533 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2532, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2534 lang.IFn; if linked_2533 == nil { ifn_2534 = lang.IFn_Cast(root_2532) } else { ifn_2534 = nil }; var arg_2535 any = opts__5; var arg_2536 any = A_arbace_build_go_A_const_164; var arg_2537 any; var root_2528 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = as__4; if linked_2529 == nil { arg_2537 = ifn_2530.Invoke_O__O(arg_2531) } else { arg_2537 = linked_2529.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2528, arg_2531) }; if linked_2533 == nil { tmp12 = ifn_2534.Invoke_O_O_O__O(arg_2535, arg_2536, arg_2537) } else { tmp12 = linked_2533.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2532, arg_2535, arg_2536, arg_2537) }; as__4, opts__5 = tmp11, tmp12; continue L1 }
//line :559:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_10) {




			var tmp13 any; var root_2538 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2538, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2540 lang.IFn; if linked_2539 == nil { ifn_2540 = lang.IFn_Cast(root_2538) } else { ifn_2540 = nil }; var arg_2541 any = as__4; if linked_2539 == nil { tmp13 = ifn_2540.Invoke_O__O(arg_2541) } else { tmp13 = linked_2539.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2538, arg_2541) }; var tmp14 any = tmp13; var tmp15 any; var root_2550 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2551 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2550, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2552 lang.IFn; if linked_2551 == nil { ifn_2552 = lang.IFn_Cast(root_2550) } else { ifn_2552 = nil }; var arg_2553 any = opts__5; var arg_2554 any = A_arbace_build_go_A_const_138; var arg_2555 any; var root_2546 any = A_arbace_build_go_A_const_189.GetRawRoot__O(); var linked_2547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2546, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2548 lang.IFn; if linked_2547 == nil { ifn_2548 = lang.IFn_Cast(root_2546) } else { ifn_2548 = nil }; var arg_2549 any; var root_2542 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2544 lang.IFn; if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any = as__4; if linked_2543 == nil { arg_2549 = ifn_2544.Invoke_O__O(arg_2545) } else { arg_2549 = linked_2543.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2542, arg_2545) }; if linked_2547 == nil { arg_2555 = ifn_2548.Invoke_O__O(arg_2549) } else { arg_2555 = linked_2547.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2546, arg_2549) }; if linked_2551 == nil { tmp15 = ifn_2552.Invoke_O_O_O__O(arg_2553, arg_2554, arg_2555) } else { tmp15 = linked_2551.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2550, arg_2553, arg_2554, arg_2555) }; as__4, opts__5 = tmp14, tmp15; continue L1 }
//line :559:1
		case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_11) {













			var tmp16 any; var root_2556 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = as__4; if linked_2557 == nil { tmp16 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp16 = linked_2557.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2556, arg_2559) }; var tmp17 any = tmp16; var tmp18 any; var root_2564 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2565 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2564, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2566 lang.IFn; if linked_2565 == nil { ifn_2566 = lang.IFn_Cast(root_2564) } else { ifn_2566 = nil }; var arg_2567 any = opts__5; var arg_2568 any = A_arbace_build_go_A_const_146; var arg_2569 any; var root_2560 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = as__4; if linked_2561 == nil { arg_2569 = ifn_2562.Invoke_O__O(arg_2563) } else { arg_2569 = linked_2561.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2560, arg_2563) }; if linked_2565 == nil { tmp18 = ifn_2566.Invoke_O_O_O__O(arg_2567, arg_2568, arg_2569) } else { tmp18 = linked_2565.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2564, arg_2567, arg_2568, arg_2569) }; as__4, opts__5 = tmp17, tmp18; continue L1 }
//line :559:1
		case 30: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_12) {



			var tmp19 any; var root_2570 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = as__4; if linked_2571 == nil { tmp19 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp19 = linked_2571.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2570, arg_2573) }; var tmp20 any = tmp19; var tmp21 any; var root_2578 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2579 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2578, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2580 lang.IFn; if linked_2579 == nil { ifn_2580 = lang.IFn_Cast(root_2578) } else { ifn_2580 = nil }; var arg_2581 any = opts__5; var arg_2582 any = A_arbace_build_go_A_const_176; var arg_2583 any; var root_2574 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any = as__4; if linked_2575 == nil { arg_2583 = ifn_2576.Invoke_O__O(arg_2577) } else { arg_2583 = linked_2575.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2574, arg_2577) }; if linked_2579 == nil { tmp21 = ifn_2580.Invoke_O_O_O__O(arg_2581, arg_2582, arg_2583) } else { tmp21 = linked_2579.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2578, arg_2581, arg_2582, arg_2583) }; as__4, opts__5 = tmp20, tmp21; continue L1 }
//line :559:1
		case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_13) {
			var tmp22 any; var root_2584 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any = as__4; if linked_2585 == nil { tmp22 = ifn_2586.Invoke_O__O(arg_2587) } else { tmp22 = linked_2585.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2584, arg_2587) }; var tmp23 any = tmp22; var tmp24 any; var root_2592 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2593 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2592, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2594 lang.IFn; if linked_2593 == nil { ifn_2594 = lang.IFn_Cast(root_2592) } else { ifn_2594 = nil }; var arg_2595 any = opts__5; var arg_2596 any = A_arbace_build_go_A_const_174; var arg_2597 any; var root_2588 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = as__4; if linked_2589 == nil { arg_2597 = ifn_2590.Invoke_O__O(arg_2591) } else { arg_2597 = linked_2589.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2588, arg_2591) }; if linked_2593 == nil { tmp24 = ifn_2594.Invoke_O_O_O__O(arg_2595, arg_2596, arg_2597) } else { tmp24 = linked_2593.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2592, arg_2595, arg_2596, arg_2597) }; as__4, opts__5 = tmp23, tmp24; continue L1 }
//line :559:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_14) {





			var tmp25 any; var root_2598 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any = as__4; if linked_2599 == nil { tmp25 = ifn_2600.Invoke_O__O(arg_2601) } else { tmp25 = linked_2599.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2598, arg_2601) }; var tmp26 any = tmp25; var tmp27 any; var root_2602 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2602, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = opts__5; var arg_2606 any = A_arbace_build_go_A_const_139; var arg_2607 any = jrt.Boolean_TRUE.Ref(); if linked_2603 == nil { tmp27 = ifn_2604.Invoke_O_O_O__O(arg_2605, arg_2606, arg_2607) } else { tmp27 = linked_2603.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2602, arg_2605, arg_2606, arg_2607) }; as__4, opts__5 = tmp26, tmp27; continue L1 }
//line :559:1
		case 38: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_15) {

			var tmp28 any; var root_2608 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = as__4; if linked_2609 == nil { tmp28 = ifn_2610.Invoke_O__O(arg_2611) } else { tmp28 = linked_2609.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2608, arg_2611) }; var tmp29 any = tmp28; var tmp30 any; var root_2616 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2617 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2616, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2618 lang.IFn; if linked_2617 == nil { ifn_2618 = lang.IFn_Cast(root_2616) } else { ifn_2618 = nil }; var arg_2619 any = opts__5; var arg_2620 any = A_arbace_build_go_A_const_144; var arg_2621 any; var root_2612 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = as__4; if linked_2613 == nil { arg_2621 = ifn_2614.Invoke_O__O(arg_2615) } else { arg_2621 = linked_2613.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2612, arg_2615) }; if linked_2617 == nil { tmp30 = ifn_2618.Invoke_O_O_O__O(arg_2619, arg_2620, arg_2621) } else { tmp30 = linked_2617.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2616, arg_2619, arg_2620, arg_2621) }; as__4, opts__5 = tmp29, tmp30; continue L1 }
//line :559:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_16) {


			var tmp31 any; var root_2622 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = as__4; if linked_2623 == nil { tmp31 = ifn_2624.Invoke_O__O(arg_2625) } else { tmp31 = linked_2623.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2622, arg_2625) }; var tmp32 any = tmp31; var tmp33 any; var root_2635 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = opts__5; var arg_2639 any = A_arbace_build_go_A_const_120; var arg_2640 any; var root_2626 any = A_arbace_build_go_A_const_190.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_2630 any = lang.PersistentVector_EMPTY.Ref(); if linked_2627 == nil { arg_2640 = ifn_2628.Invoke_O_O__O(arg_2629, arg_2630) } else { arg_2640 = linked_2627.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_2626, arg_2629, arg_2630) }; var arg_2641 any; var root_2631 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = as__4; if linked_2632 == nil { arg_2641 = ifn_2633.Invoke_O__O(arg_2634) } else { arg_2641 = linked_2632.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2631, arg_2634) }; if linked_2636 == nil { tmp33 = ifn_2637.Invoke_O_O_O_O__O(arg_2638, arg_2639, arg_2640, arg_2641) } else { tmp33 = linked_2636.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2635, arg_2638, arg_2639, arg_2640, arg_2641) }; as__4, opts__5 = tmp32, tmp33; continue L1 }
//line :559:1
		case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_17) {







			var tmp34 any; var root_2642 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = as__4; if linked_2643 == nil { tmp34 = ifn_2644.Invoke_O__O(arg_2645) } else { tmp34 = linked_2643.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2642, arg_2645) }; var tmp35 any = tmp34; var tmp36 any; var root_2650 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2651 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2650, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2652 lang.IFn; if linked_2651 == nil { ifn_2652 = lang.IFn_Cast(root_2650) } else { ifn_2652 = nil }; var arg_2653 any = opts__5; var arg_2654 any = A_arbace_build_go_A_const_170; var arg_2655 any; var root_2646 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = as__4; if linked_2647 == nil { arg_2655 = ifn_2648.Invoke_O__O(arg_2649) } else { arg_2655 = linked_2647.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2646, arg_2649) }; if linked_2651 == nil { tmp36 = ifn_2652.Invoke_O_O_O__O(arg_2653, arg_2654, arg_2655) } else { tmp36 = linked_2651.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2650, arg_2653, arg_2654, arg_2655) }; as__4, opts__5 = tmp35, tmp36; continue L1 }
//line :559:1
		case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_18) {














			var tmp37 any; var root_2656 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2656, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2658 lang.IFn; if linked_2657 == nil { ifn_2658 = lang.IFn_Cast(root_2656) } else { ifn_2658 = nil }; var arg_2659 any = as__4; if linked_2657 == nil { tmp37 = ifn_2658.Invoke_O__O(arg_2659) } else { tmp37 = linked_2657.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2656, arg_2659) }; var tmp38 any = tmp37; var tmp39 any; var root_2664 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2664, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2666 lang.IFn; if linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = opts__5; var arg_2668 any = A_arbace_build_go_A_const_121; var arg_2669 any; var root_2660 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any = as__4; if linked_2661 == nil { arg_2669 = ifn_2662.Invoke_O__O(arg_2663) } else { arg_2669 = linked_2661.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2660, arg_2663) }; if linked_2665 == nil { tmp39 = ifn_2666.Invoke_O_O_O__O(arg_2667, arg_2668, arg_2669) } else { tmp39 = linked_2665.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2664, arg_2667, arg_2668, arg_2669) }; as__4, opts__5 = tmp38, tmp39; continue L1 }
//line :559:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_19) {












			var tmp40 any; var root_2670 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = as__4; if linked_2671 == nil { tmp40 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp40 = linked_2671.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2670, arg_2673) }; var tmp41 any = tmp40; var tmp42 any; var root_2678 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2679 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2678, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2680 lang.IFn; if linked_2679 == nil { ifn_2680 = lang.IFn_Cast(root_2678) } else { ifn_2680 = nil }; var arg_2681 any = opts__5; var arg_2682 any = A_arbace_build_go_A_const_122; var arg_2683 any; var root_2674 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = as__4; if linked_2675 == nil { arg_2683 = ifn_2676.Invoke_O__O(arg_2677) } else { arg_2683 = linked_2675.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2674, arg_2677) }; if linked_2679 == nil { tmp42 = ifn_2680.Invoke_O_O_O__O(arg_2681, arg_2682, arg_2683) } else { tmp42 = linked_2679.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2678, arg_2681, arg_2682, arg_2683) }; as__4, opts__5 = tmp41, tmp42; continue L1 }
//line :559:1
		case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_20) {








			var tmp43 any; var root_2684 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = as__4; if linked_2685 == nil { tmp43 = ifn_2686.Invoke_O__O(arg_2687) } else { tmp43 = linked_2685.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2684, arg_2687) }; var tmp44 any = tmp43; var tmp45 any; var root_2692 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2693 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2692, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2694 lang.IFn; if linked_2693 == nil { ifn_2694 = lang.IFn_Cast(root_2692) } else { ifn_2694 = nil }; var arg_2695 any = opts__5; var arg_2696 any = A_arbace_build_go_A_const_171; var arg_2697 any; var root_2688 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2690 lang.IFn; if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = as__4; if linked_2689 == nil { arg_2697 = ifn_2690.Invoke_O__O(arg_2691) } else { arg_2697 = linked_2689.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2688, arg_2691) }; if linked_2693 == nil { tmp45 = ifn_2694.Invoke_O_O_O__O(arg_2695, arg_2696, arg_2697) } else { tmp45 = linked_2693.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2692, arg_2695, arg_2696, arg_2697) }; as__4, opts__5 = tmp44, tmp45; continue L1 }
//line :559:1
		default:
		}















		var tmp46 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_2707 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any; var root_2702 any = A_arbace_build_go_A_const_128.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any; var root_2698 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2700 lang.IFn; if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any = as__4; if linked_2699 == nil { arg_2705 = ifn_2700.Invoke_O__O(arg_2701) } else { arg_2705 = linked_2699.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2698, arg_2701) }; var arg_2706 any = Lit_21; if linked_2703 == nil { arg_2710 = ifn_2704.Invoke_O_O__O(arg_2705, arg_2706) } else { arg_2710 = linked_2703.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2702, arg_2705, arg_2706) }; if linked_2708 == nil { and__1927000168__auto____8 = ifn_2709.Invoke_O__O(arg_2710) } else { and__1927000168__auto____8 = linked_2708.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2707, arg_2710) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191); var and__1927000168__auto____9 any = tmp47.Invoke_O__O(A_arbace_build_go_A_const_174.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_2711 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2713 lang.IFn

			if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = A_arbace_build_go_A_const_192; var arg_2715 any = A_arbace_build_go_A_const_144.Invoke_O__O(opts__5); if linked_2712 == nil { and__1927000168__auto____10 = ifn_2713.Invoke_O_O__O(arg_2714, arg_2715) } else { and__1927000168__auto____10 = linked_2712.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2711, arg_2714, arg_2715) }
//line :576:1
			if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_2716 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2718 lang.IFn


				if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = A_arbace_build_go_A_const_193; var arg_2720 any = A_arbace_build_go_A_const_138.Invoke_O__O(opts__5); if linked_2717 == nil { and__1927000168__auto____11 = ifn_2718.Invoke_O_O__O(arg_2719, arg_2720) } else { and__1927000168__auto____11 = linked_2717.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2716, arg_2719, arg_2720) }
//line :576:1
				if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_2721 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2723 lang.IFn



					if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = A_arbace_build_go_A_const_175.Invoke_O__O(opts__5); if linked_2722 == nil { or__1927000174__auto____12 = ifn_2723.Invoke_O__O(arg_2724) } else { or__1927000174__auto____12 = linked_2722.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2721, arg_2724) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp46 = or__1927000174__auto____12 } else { tmp46 = A_arbace_build_go_A_const_164.Invoke_O__O(opts__5) } } else {
//line :576:1
						tmp46 = and__1927000168__auto____11 } } else { tmp46 = and__1927000168__auto____10 } } else { tmp46 = and__1927000168__auto____9 } } else { tmp46 = and__1927000168__auto____8 } } else { tmp46 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp46) { } else {




							var root_2738 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2738, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2740 lang.IFn; if linked_2739 == nil { ifn_2740 = lang.IFn_Cast(root_2738) } else { ifn_2740 = nil }; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()); var tmp49 any = A_arbace_build_go_A_const_185; var arg_2741 any = tmp48.Invoke_O_O__O(tmp49, A_arbace_build_go_A_const_186.Get__O()); if linked_2739 == nil { ifn_2740.Invoke_O__O(arg_2741) } else { linked_2739.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2738, arg_2741) }; var tmp50 any = A_arbace_build_go__main_fn__1901000388_A_New_O(usage__3); var tmp51 *jrt.Class; var fncls__2732 *jrt.Class = A_arbace_build_go__main_fn__1901000388_A_fn_class; if fncls__2732 == nil { var fncls__2732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_build_go__main_fn__1901000388_A_fn_class = fncls__2732d; tmp51 = fncls__2732d } else { tmp51 = fncls__2732 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil).Invoke__O()
							jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :559:1
		var dir__7 any; var tmp52 any; var root_2421 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2423 lang.IFn























		if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = as__4; if linked_2422 == nil { tmp52 = ifn_2423.Invoke_O__O(arg_2424) } else { tmp52 = linked_2422.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2421, arg_2424) }
//line :559:1
		dir__7 = jrt.File_New_String(jrt.String_Cast(tmp52)); var status__8 any; var tmp53 any = A_arbace_build_go__main_fn__1901000390_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp54 *jrt.Class
		var fncls__2489 /*line :559:1*/*jrt.Class = A_arbace_build_go__main_fn__1901000390_A_fn_class
























		if fncls__2489 == nil { var fncls__2489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_build_go__main_fn__1901000390_A_fn_class = fncls__2489d; tmp54 = fncls__2489d } else { tmp54 = fncls__2489 }; status__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O()















		var root_2742 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; if linked_2743 == nil { ifn_2744.Invoke__O() } else { linked_2743.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2742) }
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__8)); return nil } }; /*line :554:1*/panic("j2g: unreachable") }


























func A_arbace_build_go__main_fn__1901000388_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000388_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000388_A{}; t.Ctor_O(p0); return t }
//line :581:1
func (t *A_arbace_build_go__main_fn__1901000388_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :581:1
func (t *A_arbace_build_go__main_fn__1901000388_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_2729 any = A_arbace_build_go_A_const_70.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; if linked_2730 == nil { ifn_2731.Invoke__O() } else { linked_2730.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2729) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_build_go__main_fn__1901000390_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go__main_fn__1901000390_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000390_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :584:1
func (t *A_arbace_build_go__main_fn__1901000390_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :584:1
func (t *A_arbace_build_go__main_fn__1901000390_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.J2g_Truth(A_arbace_build_go_A_const_175.Invoke_O__O(t.F_opts)) { var prog__3 any; var root_2425 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, A_arbace_build_go_program_A_fn_class); var ifn_2427 lang.IFn
											if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = t.F_dir; var arg_2429 any; var t_ any = t.F_goroot; t.F_goroot = nil; arg_2429 = t_; var tmp2 any = A_arbace_build_go_A_const_119; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any = A_arbace_build_go_A_const_123; var tmp5 any = A_arbace_build_go_A_const_123.Invoke_O__O(t.F_opts); var tmp6 any = A_arbace_build_go_A_const_120; var arg_2430 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, A_arbace_build_go_A_const_120.Invoke_O__O(t.F_opts))); if linked_2426 == nil { prog__3 = ifn_2427.Invoke_O_O_O__O(arg_2428, arg_2429, arg_2430) } else { prog__3 = linked_2426.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2425, arg_2428, arg_2429, arg_2430) }
//line :585:1
		var mod__4 any; var tmp7 any; var root_2431 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2433 lang.IFn

		if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = A_arbace_build_go_A_const_164.Invoke_O__O(t.F_opts); if linked_2432 == nil { tmp7 = ifn_2433.Invoke_O__O(arg_2434) } else { tmp7 = linked_2432.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2431, arg_2434) }
//line :585:1
		mod__4 = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(tmp7)), Lit_24)


		if jrt.NN(jrt.File_Cast(mod__4)).Exists__Z() { var root_2457 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2459 lang.IFn; if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = mod__4; if linked_2458 == nil { ifn_2459.Invoke_O__O(arg_2460) } else { linked_2458.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2457, arg_2460) } }
		var root_2461 any = A_arbace_build_go_A_const_173.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, A_arbace_build_go_print_module_A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = prog__3; var arg_2465 any; var t__2 any = t.F_dir; t.F_dir = nil; arg_2465 = t__2; var arg_2466 any = mod__4; var arg_2467 any; var t__3 any = t.F_opts; t.F_opts = nil; arg_2467 = t__3; if linked_2462 == nil { ifn_2463.Invoke_O_O_O_O__O(arg_2464, arg_2465, arg_2466, arg_2467) } else { linked_2462.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2461, arg_2464, arg_2465, arg_2466, arg_2467) }
//line :585:1
		tmp1 = A_arbace_build_go_A_const_134 } else { var prog_main__3 any





			if jrt.J2g_Truth(A_arbace_build_go_A_const_176.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp8 *lang.Keyword = A_arbace_build_go_A_const_130; var tmp9 any; var root_2435 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, A_arbace_build_go_program_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = t.F_dir; var arg_2439 any; var t__4 any = t.F_goroot; t.F_goroot = nil; arg_2439 = t__4; var arg_2440 any = t.F_opts; if linked_2436 == nil { tmp9 = ifn_2437.Invoke_O_O_O__O(arg_2438, arg_2439, arg_2440) } else { tmp9 = linked_2436.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2435, arg_2438, arg_2439, arg_2440) }; prog_main__3 = tmp8.Invoke_O__O(tmp9) }
//line :585:1
			var out__4 any; var tmp10 *jrt.Class = A_arbace_build_go_A_const_67; var tmp11 any; var or__1927000174__auto____4 any = A_arbace_build_go_A_const_176.Invoke_O__O(t.F_opts)






			if jrt.J2g_Truth(or__1927000174__auto____4) { tmp11 = or__1927000174__auto____4 } else {
				var root_2446 any = A_arbace_build_go_A_const_177.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any; var root_2441 any = A_arbace_build_go_A_const_178.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = A_arbace_build_go_A_const_46.Invoke_O__O(prog_main__3); var arg_2445 any = A_arbace_build_go_A_const_179; if linked_2442 == nil { arg_2449 = ifn_2443.Invoke_O_O__O(arg_2444, arg_2445) } else { arg_2449 = linked_2442.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2441, arg_2444, arg_2445) }; if linked_2447 == nil { tmp11 = ifn_2448.Invoke_O__O(arg_2449) } else { tmp11 = linked_2447.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_2446, arg_2449) } }
//line :585:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11))








			var root_2450 any = A_arbace_build_go_A_const_180.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, A_arbace_build_go_build_A_fn_class); var ifn_2452 lang.IFn; if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any; var t__5 any = t.F_dir; t.F_dir = nil; arg_2453 = t__5; var arg_2454 any = A_arbace_build_go_A_const_174.Invoke_O__O(t.F_opts); var arg_2455 any = out__4; var arg_2456 any; var t__6 any = t.F_opts; t.F_opts = nil; arg_2456 = t__6; if linked_2451 == nil { tmp1 = ifn_2452.Invoke_O_O_O_O__O(arg_2453, arg_2454, arg_2455, arg_2456) } else { tmp1 = linked_2451.(*A_arbace_build_go_build_A).Invoke_O_O_O_O_O__O(root_2450, arg_2453, arg_2454, arg_2455, arg_2456) } }
//line :584:1
	return nil }(); if tmp12 != nil { if lang.ExceptionInfo_InstanceOf(tmp12) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp12); var tmp13 *lang.Keyword = A_arbace_build_go_A_const_181; var tmp14 any; var root_2468 any = A_arbace_build_go_A_const_182.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2470 lang.IFn











		if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = e__3; if linked_2469 == nil { tmp14 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp14 = linked_2469.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2468, arg_2471) }; if jrt.J2g_Truth(tmp13.Invoke_O__O(tmp14)) {
			var root_2485 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()); var tmp16 any = A_arbace_build_go_A_const_185; var arg_2488 any = tmp15.Invoke_O_O__O(tmp16, A_arbace_build_go_A_const_186.Get__O()); if linked_2486 == nil { ifn_2487.Invoke_O__O(arg_2488) } else { linked_2486.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2485, arg_2488) }; var tmp17 any = A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_New_O(e__3); var tmp18 *jrt.Class; var fncls__2479 *jrt.Class = A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class; if fncls__2479 == nil { var fncls__2479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class = fncls__2479d; tmp18 = fncls__2479d } else { tmp18 = fncls__2479 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :596:1
			tmp1 = A_arbace_build_go_A_const_183 } else { panic(jrt.Thrown(e__3)) } } else {
//line :584:1
				panic(tmp12) } }; return tmp1 }












func A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000390_fn__1901000391_A{}; t.Ctor_O(p0); return t }
//line :597:1
func (t *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :597:1
func (t *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_184.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); var root_2476 any = A_arbace_build_go_A_const_70.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; if linked_2477 == nil { ifn_2478.Invoke__O() } else { linked_2477.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2476) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }

















































































































































type A_arbace_build_go_A struct{ jrt.Object }

var A_arbace_build_go_A_const_pool *jrt.RefArray

var A_arbace_build_go_A_const_0 *lang.Var

var A_arbace_build_go_A_const_1 any

var A_arbace_build_go_A_const_2 *lang.Var

var A_arbace_build_go_A_const_3 any

var A_arbace_build_go_A_const_4 any

var A_arbace_build_go_A_const_5 *lang.Var

var A_arbace_build_go_A_const_6 *lang.Var

var A_arbace_build_go_A_const_7 *lang.Var

var A_arbace_build_go_A_const_8 *lang.Var

var A_arbace_build_go_A_const_9 any

var A_arbace_build_go_A_const_10 *lang.Var

var A_arbace_build_go_A_const_11 *lang.Var

var A_arbace_build_go_A_const_12 any

var A_arbace_build_go_A_const_13 *lang.Keyword

var A_arbace_build_go_A_const_14 *lang.Var

var A_arbace_build_go_A_const_15 *lang.Var

var A_arbace_build_go_A_const_16 *lang.Var

var A_arbace_build_go_A_const_17 *lang.Var

var A_arbace_build_go_A_const_18 *lang.Var

var A_arbace_build_go_A_const_19 *lang.Var

var A_arbace_build_go_A_const_20 *lang.Var

var A_arbace_build_go_A_const_21 *lang.Var

var A_arbace_build_go_A_const_22 any

var A_arbace_build_go_A_const_23 *lang.Var

var A_arbace_build_go_A_const_24 *lang.Var

var A_arbace_build_go_A_const_25 *lang.Var

var A_arbace_build_go_A_const_26 *lang.Var

var A_arbace_build_go_A_const_27 *lang.Var

var A_arbace_build_go_A_const_28 *lang.Var

var A_arbace_build_go_A_const_29 *lang.Var

var A_arbace_build_go_A_const_30 *lang.Var

var A_arbace_build_go_A_const_31 *lang.Var

var A_arbace_build_go_A_const_32 *lang.Var

var A_arbace_build_go_A_const_33 *lang.Var

var A_arbace_build_go_A_const_34 *lang.Var

var A_arbace_build_go_A_const_35 *lang.Var

var A_arbace_build_go_A_const_36 *lang.Keyword

var A_arbace_build_go_A_const_37 *lang.Var

var A_arbace_build_go_A_const_38 *lang.Var

var A_arbace_build_go_A_const_39 *lang.Var

var A_arbace_build_go_A_const_40 *lang.Var

var A_arbace_build_go_A_const_41 *lang.Var

var A_arbace_build_go_A_const_42 *lang.Var

var A_arbace_build_go_A_const_43 *lang.Var

var A_arbace_build_go_A_const_44 *lang.Var

var A_arbace_build_go_A_const_45 *lang.Var

var A_arbace_build_go_A_const_46 *lang.Keyword

var A_arbace_build_go_A_const_47 *lang.Var

var A_arbace_build_go_A_const_48 *lang.Var

var A_arbace_build_go_A_const_49 *lang.Var

var A_arbace_build_go_A_const_50 *lang.Keyword

var A_arbace_build_go_A_const_51 *lang.Var

var A_arbace_build_go_A_const_52 *lang.Var

var A_arbace_build_go_A_const_53 *lang.Var

var A_arbace_build_go_A_const_54 *lang.Var

var A_arbace_build_go_A_const_55 *lang.Var

var A_arbace_build_go_A_const_56 *lang.Var

var A_arbace_build_go_A_const_57 *lang.Var

var A_arbace_build_go_A_const_58 *lang.Var

var A_arbace_build_go_A_const_59 *lang.Var

var A_arbace_build_go_A_const_60 *lang.Var

var A_arbace_build_go_A_const_61 *lang.Var

var A_arbace_build_go_A_const_62 *lang.Keyword

var A_arbace_build_go_A_const_63 *lang.Var

var A_arbace_build_go_A_const_64 *lang.Keyword

var A_arbace_build_go_A_const_65 *lang.Var

var A_arbace_build_go_A_const_66 *lang.Var

var A_arbace_build_go_A_const_67 *jrt.Class

var A_arbace_build_go_A_const_68 *lang.Var

var A_arbace_build_go_A_const_69 *lang.Var

var A_arbace_build_go_A_const_70 *lang.Var

var A_arbace_build_go_A_const_71 *lang.Var

var A_arbace_build_go_A_const_72 *lang.Var

var A_arbace_build_go_A_const_73 *lang.Var

var A_arbace_build_go_A_const_74 *lang.Var

var A_arbace_build_go_A_const_75 *lang.Var

var A_arbace_build_go_A_const_76 *lang.Var

var A_arbace_build_go_A_const_77 *lang.Var

var A_arbace_build_go_A_const_78 *lang.Keyword

var A_arbace_build_go_A_const_79 *lang.Var

var A_arbace_build_go_A_const_80 *lang.Var

var A_arbace_build_go_A_const_81 *lang.Var

var A_arbace_build_go_A_const_82 *lang.Keyword

var A_arbace_build_go_A_const_83 *lang.Var

var A_arbace_build_go_A_const_84 *lang.Var

var A_arbace_build_go_A_const_85 *lang.Var

var A_arbace_build_go_A_const_86 *lang.Var

var A_arbace_build_go_A_const_87 *lang.Var

var A_arbace_build_go_A_const_88 *lang.Var

var A_arbace_build_go_A_const_89 *lang.Var

var A_arbace_build_go_A_const_90 *lang.Var

var A_arbace_build_go_A_const_91 *lang.Keyword

var A_arbace_build_go_A_const_92 *lang.Var

var A_arbace_build_go_A_const_93 *lang.Var

var A_arbace_build_go_A_const_94 *lang.Var

var A_arbace_build_go_A_const_95 *lang.Keyword

var A_arbace_build_go_A_const_96 *lang.Var

var A_arbace_build_go_A_const_97 *lang.Var

var A_arbace_build_go_A_const_98 *lang.Var

var A_arbace_build_go_A_const_99 any

var A_arbace_build_go_A_const_100 any

var A_arbace_build_go_A_const_101 *lang.Var

var A_arbace_build_go_A_const_102 any

var A_arbace_build_go_A_const_103 any

var A_arbace_build_go_A_const_104 *lang.Var

var A_arbace_build_go_A_const_105 *lang.Var

var A_arbace_build_go_A_const_106 any

var A_arbace_build_go_A_const_107 any

var A_arbace_build_go_A_const_108 *lang.Var

var A_arbace_build_go_A_const_109 *lang.Var

var A_arbace_build_go_A_const_110 *lang.Var

var A_arbace_build_go_A_const_111 *lang.Var

var A_arbace_build_go_A_const_112 *lang.Keyword

var A_arbace_build_go_A_const_113 *lang.Keyword

var A_arbace_build_go_A_const_114 *lang.Keyword

var A_arbace_build_go_A_const_115 *lang.Var

var A_arbace_build_go_A_const_116 *lang.Var

var A_arbace_build_go_A_const_117 *lang.Var

var A_arbace_build_go_A_const_118 any

var A_arbace_build_go_A_const_119 *lang.Keyword

var A_arbace_build_go_A_const_120 *lang.Keyword

var A_arbace_build_go_A_const_121 *lang.Keyword

var A_arbace_build_go_A_const_122 *lang.Keyword

var A_arbace_build_go_A_const_123 *lang.Keyword

var A_arbace_build_go_A_const_124 *lang.Var

var A_arbace_build_go_A_const_125 *lang.Keyword

var A_arbace_build_go_A_const_126 *lang.Var

var A_arbace_build_go_A_const_127 *lang.Keyword

var A_arbace_build_go_A_const_128 *lang.Var

var A_arbace_build_go_A_const_129 *lang.Var

var A_arbace_build_go_A_const_130 *lang.Keyword

var A_arbace_build_go_A_const_131 *lang.Var

var A_arbace_build_go_A_const_132 *lang.Var

var A_arbace_build_go_A_const_133 *jrt.Class

var A_arbace_build_go_A_const_134 any

var A_arbace_build_go_A_const_135 *lang.Var

var A_arbace_build_go_A_const_136 *lang.Keyword

var A_arbace_build_go_A_const_137 *lang.Keyword

var A_arbace_build_go_A_const_138 *lang.Keyword

var A_arbace_build_go_A_const_139 *lang.Keyword

var A_arbace_build_go_A_const_140 *lang.Var

var A_arbace_build_go_A_const_141 *lang.Var

var A_arbace_build_go_A_const_142 *lang.Var

var A_arbace_build_go_A_const_143 *lang.Keyword

var A_arbace_build_go_A_const_144 *lang.Keyword

var A_arbace_build_go_A_const_145 *lang.Keyword

var A_arbace_build_go_A_const_146 *lang.Keyword

var A_arbace_build_go_A_const_147 any

var A_arbace_build_go_A_const_148 *lang.Keyword

var A_arbace_build_go_A_const_149 *lang.Keyword

var A_arbace_build_go_A_const_150 *lang.Keyword

var A_arbace_build_go_A_const_151 *lang.Var

var A_arbace_build_go_A_const_152 *lang.Var

var A_arbace_build_go_A_const_153 any

var A_arbace_build_go_A_const_154 *lang.Var

var A_arbace_build_go_A_const_155 *lang.Var

var A_arbace_build_go_A_const_156 *lang.Var

var A_arbace_build_go_A_const_157 *lang.Var

var A_arbace_build_go_A_const_158 *lang.Keyword

var A_arbace_build_go_A_const_159 *lang.Keyword

var A_arbace_build_go_A_const_160 *lang.Var

var A_arbace_build_go_A_const_161 *lang.Var

var A_arbace_build_go_A_const_162 *lang.Var

var A_arbace_build_go_A_const_163 *lang.Var

var A_arbace_build_go_A_const_164 *lang.Keyword

var A_arbace_build_go_A_const_165 *lang.Keyword

var A_arbace_build_go_A_const_166 *lang.Var

var A_arbace_build_go_A_const_167 *jrt.Class

var A_arbace_build_go_A_const_168 *lang.Keyword

var A_arbace_build_go_A_const_169 *lang.Var

var A_arbace_build_go_A_const_170 *lang.Keyword

var A_arbace_build_go_A_const_171 *lang.Keyword

var A_arbace_build_go_A_const_172 *lang.Keyword

var A_arbace_build_go_A_const_173 *lang.Var

var A_arbace_build_go_A_const_174 *lang.Keyword

var A_arbace_build_go_A_const_175 *lang.Keyword

var A_arbace_build_go_A_const_176 *lang.Keyword

var A_arbace_build_go_A_const_177 *lang.Var

var A_arbace_build_go_A_const_178 *lang.Var

var A_arbace_build_go_A_const_179 any

var A_arbace_build_go_A_const_180 *lang.Var

var A_arbace_build_go_A_const_181 *lang.Keyword

var A_arbace_build_go_A_const_182 *lang.Var

var A_arbace_build_go_A_const_183 any

var A_arbace_build_go_A_const_184 *lang.Var

var A_arbace_build_go_A_const_185 *lang.Var

var A_arbace_build_go_A_const_186 *lang.Var

var A_arbace_build_go_A_const_187 *lang.Var

var A_arbace_build_go_A_const_188 *lang.Var

var A_arbace_build_go_A_const_189 *lang.Var

var A_arbace_build_go_A_const_190 *lang.Var

var A_arbace_build_go_A_const_191 any

var A_arbace_build_go_A_const_192 any

var A_arbace_build_go_A_const_193 any

var A_arbace_build_go_A_const_194 *lang.Var

var A_arbace_build_go_A_init jrt.ClassInit

func A_arbace_build_go_A_Init() { if !A_arbace_build_go_A_init.Done() { A_arbace_build_go_A_init.Run(A_arbace_build_go_A_clinit) } }

func A_arbace_build_go_A_clinit() { A_arbace_build_go_A_clinit_p0(); A_arbace_build_go_A_clinit_p1(); A_arbace_build_go_A_clinit_p2(); A_arbace_build_go_A_clinit_p3(); A_arbace_build_go_A_clinit_p4(); A_arbace_build_go_A_clinit_p5(); A_arbace_build_go_A_clinit_p6(); A_arbace_build_go_A_clinit_p7(); A_arbace_build_go_A_clinit_p8(); A_arbace_build_go_A_clinit_p9(); A_arbace_build_go_A_clinit_p10(); A_arbace_build_go_A_clinit_p11(); A_arbace_build_go_A_clinit_p12(); A_arbace_build_go_A_clinit_p13(); A_arbace_build_go_A_clinit_p14(); A_arbace_build_go_A_clinit_p15(); A_arbace_build_go_A_clinit_p16() }

func A_arbace_build_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_build_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 247); A_arbace_build_go_A_const_0 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[52]); A_arbace_build_go_A_const_1 = A_arbace_build_go_A_const_pool.A[53]; A_arbace_build_go_A_const_2 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[54]); A_arbace_build_go_A_const_3 = A_arbace_build_go_A_const_pool.A[55]; A_arbace_build_go_A_const_4 = A_arbace_build_go_A_const_pool.A[56]; A_arbace_build_go_A_const_5 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[57]); A_arbace_build_go_A_const_6 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[58]); A_arbace_build_go_A_const_7 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[59]); A_arbace_build_go_A_const_8 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[60]); A_arbace_build_go_A_const_9 = A_arbace_build_go_A_const_pool.A[61]; A_arbace_build_go_A_const_10 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[62]); A_arbace_build_go_A_const_11 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[63]) }

func A_arbace_build_go_A_clinit_p1() { A_arbace_build_go_A_const_12 = A_arbace_build_go_A_const_pool.A[64]; A_arbace_build_go_A_const_13 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[65]); A_arbace_build_go_A_const_14 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[66]); A_arbace_build_go_A_const_15 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[67]); A_arbace_build_go_A_const_16 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[68]); A_arbace_build_go_A_const_17 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[69]); A_arbace_build_go_A_const_18 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[70]); A_arbace_build_go_A_const_19 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[71]); A_arbace_build_go_A_const_20 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[72]); A_arbace_build_go_A_const_21 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[73]); A_arbace_build_go_A_const_22 = A_arbace_build_go_A_const_pool.A[74]; A_arbace_build_go_A_const_23 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[75]) }

func A_arbace_build_go_A_clinit_p2() { A_arbace_build_go_A_const_24 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[76]); A_arbace_build_go_A_const_25 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[77]); A_arbace_build_go_A_const_26 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[78]); A_arbace_build_go_A_const_27 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[79]); A_arbace_build_go_A_const_28 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[80]); A_arbace_build_go_A_const_29 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[81]); A_arbace_build_go_A_const_30 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[82]); A_arbace_build_go_A_const_31 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[83]); A_arbace_build_go_A_const_32 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[84]); A_arbace_build_go_A_const_33 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[85]); A_arbace_build_go_A_const_34 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[86]); A_arbace_build_go_A_const_35 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[87]) }

func A_arbace_build_go_A_clinit_p3() { A_arbace_build_go_A_const_36 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[88]); A_arbace_build_go_A_const_37 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[89]); A_arbace_build_go_A_const_38 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[90]); A_arbace_build_go_A_const_39 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[91]); A_arbace_build_go_A_const_40 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[92]); A_arbace_build_go_A_const_41 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[93]); A_arbace_build_go_A_const_42 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[94]); A_arbace_build_go_A_const_43 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[95]); A_arbace_build_go_A_const_44 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[96]); A_arbace_build_go_A_const_45 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[97]); A_arbace_build_go_A_const_46 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[98]); A_arbace_build_go_A_const_47 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[99]) }

func A_arbace_build_go_A_clinit_p4() { A_arbace_build_go_A_const_48 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[100]); A_arbace_build_go_A_const_49 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[101]); A_arbace_build_go_A_const_50 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[102]); A_arbace_build_go_A_const_51 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[103]); A_arbace_build_go_A_const_52 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[104]); A_arbace_build_go_A_const_53 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[105]); A_arbace_build_go_A_const_54 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[106]); A_arbace_build_go_A_const_55 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[107]); A_arbace_build_go_A_const_56 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[108]); A_arbace_build_go_A_const_57 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[109]); A_arbace_build_go_A_const_58 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[110]); A_arbace_build_go_A_const_59 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[111]) }

func A_arbace_build_go_A_clinit_p5() { A_arbace_build_go_A_const_60 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[112]); A_arbace_build_go_A_const_61 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[113]); A_arbace_build_go_A_const_62 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[114]); A_arbace_build_go_A_const_63 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[115]); A_arbace_build_go_A_const_64 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[116]); A_arbace_build_go_A_const_65 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[117]); A_arbace_build_go_A_const_66 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[118]); A_arbace_build_go_A_const_67 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[119]); A_arbace_build_go_A_const_68 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[120]); A_arbace_build_go_A_const_69 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[121]); A_arbace_build_go_A_const_70 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[122]); A_arbace_build_go_A_const_71 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[123]) }

func A_arbace_build_go_A_clinit_p6() { A_arbace_build_go_A_const_72 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[124]); A_arbace_build_go_A_const_73 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[125]); A_arbace_build_go_A_const_74 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[126]); A_arbace_build_go_A_const_75 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[127]); A_arbace_build_go_A_const_76 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[128]); A_arbace_build_go_A_const_77 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[129]); A_arbace_build_go_A_const_78 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[130]); A_arbace_build_go_A_const_79 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[131]); A_arbace_build_go_A_const_80 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[132]); A_arbace_build_go_A_const_81 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[133]); A_arbace_build_go_A_const_82 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[134]); A_arbace_build_go_A_const_83 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[135]) }

func A_arbace_build_go_A_clinit_p7() { A_arbace_build_go_A_const_84 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[136]); A_arbace_build_go_A_const_85 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[137]); A_arbace_build_go_A_const_86 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[138]); A_arbace_build_go_A_const_87 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[139]); A_arbace_build_go_A_const_88 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[140]); A_arbace_build_go_A_const_89 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[141]); A_arbace_build_go_A_const_90 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[142]); A_arbace_build_go_A_const_91 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[143]); A_arbace_build_go_A_const_92 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[144]); A_arbace_build_go_A_const_93 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[145]); A_arbace_build_go_A_const_94 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[146]); A_arbace_build_go_A_const_95 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[147]) }

func A_arbace_build_go_A_clinit_p8() { A_arbace_build_go_A_const_96 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[148]); A_arbace_build_go_A_const_97 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[149]); A_arbace_build_go_A_const_98 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[150]); A_arbace_build_go_A_const_99 = A_arbace_build_go_A_const_pool.A[151]; A_arbace_build_go_A_const_100 = A_arbace_build_go_A_const_pool.A[152]; A_arbace_build_go_A_const_101 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[153]); A_arbace_build_go_A_const_102 = A_arbace_build_go_A_const_pool.A[154]; A_arbace_build_go_A_const_103 = A_arbace_build_go_A_const_pool.A[155]; A_arbace_build_go_A_const_104 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[156]); A_arbace_build_go_A_const_105 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[157]); A_arbace_build_go_A_const_106 = A_arbace_build_go_A_const_pool.A[158]; A_arbace_build_go_A_const_107 = A_arbace_build_go_A_const_pool.A[159]; A_arbace_build_go_A_const_108 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[160]) }

func A_arbace_build_go_A_clinit_p9() { A_arbace_build_go_A_const_109 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[161]); A_arbace_build_go_A_const_110 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[162]); A_arbace_build_go_A_const_111 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[163]); A_arbace_build_go_A_const_112 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[164]); A_arbace_build_go_A_const_113 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[165]); A_arbace_build_go_A_const_114 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[166]); A_arbace_build_go_A_const_115 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[167]); A_arbace_build_go_A_const_116 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[168]); A_arbace_build_go_A_const_117 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[169]); A_arbace_build_go_A_const_118 = A_arbace_build_go_A_const_pool.A[170]; A_arbace_build_go_A_const_119 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[171]); A_arbace_build_go_A_const_120 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[172]) }

func A_arbace_build_go_A_clinit_p10() { A_arbace_build_go_A_const_121 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[173]); A_arbace_build_go_A_const_122 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[174]); A_arbace_build_go_A_const_123 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[175]); A_arbace_build_go_A_const_124 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[176]); A_arbace_build_go_A_const_125 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[177]); A_arbace_build_go_A_const_126 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[178]); A_arbace_build_go_A_const_127 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[179]); A_arbace_build_go_A_const_128 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[180]); A_arbace_build_go_A_const_129 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[181]); A_arbace_build_go_A_const_130 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[182]); A_arbace_build_go_A_const_131 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[183]); A_arbace_build_go_A_const_132 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[184]) }

func A_arbace_build_go_A_clinit_p11() { A_arbace_build_go_A_const_133 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[185]); A_arbace_build_go_A_const_134 = A_arbace_build_go_A_const_pool.A[186]; A_arbace_build_go_A_const_135 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[187]); A_arbace_build_go_A_const_136 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[188]); A_arbace_build_go_A_const_137 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[189]); A_arbace_build_go_A_const_138 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[190]); A_arbace_build_go_A_const_139 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[191]); A_arbace_build_go_A_const_140 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[192]); A_arbace_build_go_A_const_141 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[193]); A_arbace_build_go_A_const_142 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[194]); A_arbace_build_go_A_const_143 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[195]); A_arbace_build_go_A_const_144 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[196]) }

func A_arbace_build_go_A_clinit_p12() { A_arbace_build_go_A_const_145 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[197]); A_arbace_build_go_A_const_146 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[198]); A_arbace_build_go_A_const_147 = A_arbace_build_go_A_const_pool.A[199]; A_arbace_build_go_A_const_148 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[200]); A_arbace_build_go_A_const_149 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[201]); A_arbace_build_go_A_const_150 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[202]); A_arbace_build_go_A_const_151 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[203]); A_arbace_build_go_A_const_152 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[204]); A_arbace_build_go_A_const_153 = A_arbace_build_go_A_const_pool.A[205]; A_arbace_build_go_A_const_154 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[206]); A_arbace_build_go_A_const_155 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[207]); A_arbace_build_go_A_const_156 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[208]) }

func A_arbace_build_go_A_clinit_p13() { A_arbace_build_go_A_const_157 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[209]); A_arbace_build_go_A_const_158 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[210]); A_arbace_build_go_A_const_159 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[211]); A_arbace_build_go_A_const_160 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[212]); A_arbace_build_go_A_const_161 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[213]); A_arbace_build_go_A_const_162 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[214]); A_arbace_build_go_A_const_163 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[215]); A_arbace_build_go_A_const_164 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[216]); A_arbace_build_go_A_const_165 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[217]); A_arbace_build_go_A_const_166 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[218]); A_arbace_build_go_A_const_167 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[219]); A_arbace_build_go_A_const_168 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[220]) }

func A_arbace_build_go_A_clinit_p14() { A_arbace_build_go_A_const_169 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[221]); A_arbace_build_go_A_const_170 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[222]); A_arbace_build_go_A_const_171 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[223]); A_arbace_build_go_A_const_172 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[224]); A_arbace_build_go_A_const_173 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[225]); A_arbace_build_go_A_const_174 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[226]); A_arbace_build_go_A_const_175 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[227]); A_arbace_build_go_A_const_176 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[228]); A_arbace_build_go_A_const_177 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[229]); A_arbace_build_go_A_const_178 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[230]); A_arbace_build_go_A_const_179 = A_arbace_build_go_A_const_pool.A[231]; A_arbace_build_go_A_const_180 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[232]) }

func A_arbace_build_go_A_clinit_p15() { A_arbace_build_go_A_const_181 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[233]); A_arbace_build_go_A_const_182 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[234]); A_arbace_build_go_A_const_183 = A_arbace_build_go_A_const_pool.A[235]; A_arbace_build_go_A_const_184 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[236]); A_arbace_build_go_A_const_185 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[237]); A_arbace_build_go_A_const_186 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[238]); A_arbace_build_go_A_const_187 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[239]); A_arbace_build_go_A_const_188 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[240]); A_arbace_build_go_A_const_189 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[241]); A_arbace_build_go_A_const_190 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[242]); A_arbace_build_go_A_const_191 = A_arbace_build_go_A_const_pool.A[243]; A_arbace_build_go_A_const_192 = A_arbace_build_go_A_const_pool.A[244]; A_arbace_build_go_A_const_193 = A_arbace_build_go_A_const_pool.A[245] }

func A_arbace_build_go_A_clinit_p16() { A_arbace_build_go_A_const_194 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[246]) }

func A_arbace_build_go_A_New() *A_arbace_build_go_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_A) Ctor() {}

func (t *A_arbace_build_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_A_class }

func (t *A_arbace_build_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_A); return ok }

func A_arbace_build_go_A_Cast(x any) *A_arbace_build_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_A_class)) }; return v }



type A_arbace_build_go__main_A struct{ j2g_header uint64 }

var A_arbace_build_go__main_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000388_A struct{ j2g_header uint64; F_usage any }

var A_arbace_build_go__main_fn__1901000388_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000390_A struct{ j2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_build_go__main_fn__1901000390_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000390_fn__1901000391_A struct{ j2g_header uint64; F_e any }

var A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class *jrt.Class



type A_arbace_build_go_build_A struct{ j2g_header uint64 }

var A_arbace_build_go_build_A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__fn__1901000326_A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_A struct{ j2g_header uint64 }

var A_arbace_build_go_cached_texts_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A struct{ j2g_header uint64; F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A struct{ j2g_header uint64; F_s__1901000305, F_iter__1901000304, F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A struct{ j2g_header uint64; F_b__1901000307, F_entry any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000020_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_fn__1901000020_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000022_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_clj_files_fn__1901000022_A_fn_class *jrt.Class



type A_arbace_build_go_collect_index_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_index_file_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_package_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_fn__1901000076_A struct{ j2g_header uint64; F_read_fn, F_read any }

var A_arbace_build_go_collect_package_fn__1901000076_A_fn_class *jrt.Class



type A_arbace_build_go_collected_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collected_package_A_fn_class *jrt.Class



type A_arbace_build_go_copy_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_copy_file_A_fn_class *jrt.Class



type A_arbace_build_go_data_dir_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_delete_tree_A struct{ j2g_header uint64 }

var A_arbace_build_go_delete_tree_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000004_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000004_A_New() *A_arbace_build_go_eval1901000004_A { t := &A_arbace_build_go_eval1901000004_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000004_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000004_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000004_A_class }

func (t *A_arbace_build_go_eval1901000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000004_A); return ok }

func A_arbace_build_go_eval1901000004_A_Cast(x any) *A_arbace_build_go_eval1901000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000004_A_class)) }; return v }



type A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000008_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000008_A_New() *A_arbace_build_go_eval1901000008_A { t := &A_arbace_build_go_eval1901000008_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000008_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000008_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000008_A_class }

func (t *A_arbace_build_go_eval1901000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000008_A); return ok }

func A_arbace_build_go_eval1901000008_A_Cast(x any) *A_arbace_build_go_eval1901000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000008_A_class)) }; return v }



type A_arbace_build_go_eval1901000008_fn__1901000009_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000008_fn__1901000009_A_fn_class *jrt.Class



type A_arbace_build_go_fail_A struct{ j2g_header uint64 }

var A_arbace_build_go_fail_A_fn_class *jrt.Class



type A_arbace_build_go_file_sha_A struct{ j2g_header uint64 }

var A_arbace_build_go_file_sha_A_fn_class *jrt.Class



type A_arbace_build_go_forms_dir_A struct{ j2g_header uint64 }

var A_arbace_build_go_forms_dir_A_fn_class *jrt.Class



type A_arbace_build_go_go_env_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_env_A_fn_class *jrt.Class



type A_arbace_build_go_go_mod_cache_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_sha__1901000243_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class *jrt.Class



type A_arbace_build_go_hex_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_A_fn_class *jrt.Class



type A_arbace_build_go_hex_fn__1901000072_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_fn__1901000072_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000027_A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000029_A struct{ j2g_header uint64; F_aliases any }

var A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class *jrt.Class



type A_arbace_build_go_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000057_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000057_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000062_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000062_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_A struct{ j2g_header uint64; F_print_cache any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A struct{ j2g_header uint64; F_iter__1901000034, F_print_cache, F_s__1901000035 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A struct{ j2g_header uint64; F_iter__1901000036, F_s__1901000037 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A struct{ j2g_header uint64; F_b__1901000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_add__1901000295_A struct{ j2g_header uint64; F_md any }

var A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_fn__1901000301_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_A struct{ j2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_build_go_print_module_fn__1901000337_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A struct{ j2g_header uint64; F_test_files, F_tests any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class *jrt.Class



type A_arbace_build_go_program_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000263_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000263_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000265_A struct{ j2g_header uint64; F_opts any }

var A_arbace_build_go_program_fn__1901000265_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000277_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000277_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_A struct{ j2g_header uint64; F_module any }

var A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A struct{ j2g_header uint64; F_iter__1901000267, F_module, F_s__1901000268 any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A struct{ j2g_header uint64; F_b__1901000270 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000066_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_fn__1901000066_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000068_A struct{ j2g_header uint64; F_cache any }

var A_arbace_build_go_read_all_fn__1901000068_A_fn_class *jrt.Class



type A_arbace_build_go_read_index_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_index_A_fn_class *jrt.Class



type A_arbace_build_go_read_program_edn_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_program_edn_A_fn_class *jrt.Class



type A_arbace_build_go_rel_path_A struct{ j2g_header uint64 }

var A_arbace_build_go_rel_path_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000099_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_fn__1901000099_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000101_A struct{ j2g_header uint64; F_m any }

var A_arbace_build_go_root_packages_fn__1901000101_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000158_A struct{ j2g_header uint64; F_covered, F_known_QMARK_ any }

var A_arbace_build_go_root_packages_fn__1901000158_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000187_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000187_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000192_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000192_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A struct{ j2g_header uint64; F_s__1901000104, F_iter__1901000103, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A struct{ j2g_header uint64; F_b__1901000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A struct{ j2g_header uint64; F_iter__1901000131, F_s__1901000132 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A struct{ j2g_header uint64; F_iter__1901000133, F_s__1901000134 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A struct{ j2g_header uint64; F_b__1901000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid, F_s__1901000163, F_iter__1901000162 any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_b__1901000165, F_dir, F_valid any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_s__1901000195, F_iter__1901000194, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_b__1901000197 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A struct{ j2g_header uint64; F_s__1901000205, F_iter__1901000204, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A struct{ j2g_header uint64; F_b__1901000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_known_QMARK___1901000156_A struct{ j2g_header uint64; F_index_file, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A struct{ j2g_header uint64; F_read_fn, F_known_QMARK_, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class *jrt.Class



type A_arbace_build_go_run_A struct{ j2g_header uint64 }

var A_arbace_build_go_run_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_fn__1901000281_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_fn__1901000281_A_fn_class *jrt.Class



type A_arbace_build_go_tamago_go_sum_A struct{ j2g_header uint64 }

var A_arbace_build_go_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_build_go_toolchain_lang_A struct{ j2g_header uint64 }

var A_arbace_build_go_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_with_line_files_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__fn__1901000091_A struct{ j2g_header uint64; F_ok_QMARK_ any }

var A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A struct{ j2g_header uint64; F_printed any }

var A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__printed__1901000087_A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class *jrt.Class
