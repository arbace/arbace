//line aot_arbace_build_go.ae:1
package aot_arbace_build_go

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_New() *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_build_go_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_1); lang.IFn_Cast(A_arbace_build_go_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_3, A_arbace_build_go_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_59)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_60)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_61)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_62)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_63)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_64)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_build_go_eval1901000008_fn__1901000009_A_New() *A_arbace_build_go_eval1901000008_fn__1901000009_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000008_fn__1901000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_build_go_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_build_go_A_const_8.GetRawRoot__O(), A_arbace_build_go_A_const_9) }

































































func A_arbace_build_go_fail_A_New() *A_arbace_build_go_fail_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_fail_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_build_go_fail_A) Ctor() {}
//line :67:1
func (t *A_arbace_build_go_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__1901000012__1 any) any { var vec__1901000013__3 any = p__1901000012__1; var data__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000013__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_20 any = A_arbace_build_go_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_22 lang.IFn; if
												linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = msg__0; var arg_24 any; var root_25 any = A_arbace_build_go_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_build_go_A_const_12; var arg_29 any = data__4; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; /*line :67:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }





func A_arbace_build_go_data_dir_QMARK__A_New() *A_arbace_build_go_data_dir_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Ctor() {}
//line :73:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.File_Cast(f__1).GetParentFile__File(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(jrt.File_Cast(d__3).GetAbsoluteFile__File(), jrt.File_Cast(dir__0).GetAbsoluteFile__File()) }; if tmp1 { return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_58).IsFile__Z() { return jrt.Boolean_TRUE.Ref() } else { if A_arbace_build_go_A_const_13 != nil {

		d__3 = jrt.File_Cast(d__3).GetParentFile__File(); continue L1 } else {
//line :78:1
			return nil } } } } }; /*line :73:1*/panic("j2g: unreachable") }








func A_arbace_build_go_clj_files_A_New() *A_arbace_build_go_clj_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_build_go_clj_files_A) Ctor() {}
//line :82:1
func (t *A_arbace_build_go_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var root_30 any = A_arbace_build_go_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var fnbody__36 any = A_arbace_build_go_clj_files_fn__1901000020_A_New(); var tmp1 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000020_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_49, false, nil); A_arbace_build_go_clj_files_fn__1901000020_A_fn_class = fncls__35d; tmp1 = fncls__35d } else { tmp1 = fncls__35 }; arg_33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__36, tmp1, nil); var arg_34 any; var root_37 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_38 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_37, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_39 lang.IFn
//line :84:1
	if linked_38 == nil { ifn_39 = lang.IFn_Cast(root_37) } else { ifn_39 = nil }; var arg_40 any; var fnbody__57 any = A_arbace_build_go_clj_files_fn__1901000022_A_New_O(dir__0); var tmp2 *jrt.Class; var fncls__56 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000022_A_fn_class; if fncls__56 == nil { var fncls__56d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_50, false, fnbody__57); A_arbace_build_go_clj_files_fn__1901000022_A_fn_class = fncls__56d; tmp2 = fncls__56d } else { tmp2 = fncls__56 }; arg_40 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__57, tmp2, nil); var arg_41 any; var root_58 any = A_arbace_build_go_A_const_19.GetRawRoot__O(); var linked_59 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_58, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_60 lang.IFn
//line :83:1
	if linked_59 == nil { ifn_60 = lang.IFn_Cast(root_58) } else { ifn_60 = nil }; var arg_61 any = dir__0; if linked_59 == nil { arg_41 = ifn_60.Invoke_O__O(arg_61) } else { arg_41 = linked_59.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_58, arg_61) }
	if linked_38 == nil { arg_34 = ifn_39.Invoke_O_O__O(arg_40, arg_41) } else { arg_34 = linked_38.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_37, arg_40, arg_41)
	}
	if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
//line :84:1
func A_arbace_build_go_clj_files_fn__1901000022_A_New_O(p0 any) *A_arbace_build_go_clj_files_fn__1901000022_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000022_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :84:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Invoke_O_O__O(self, p1__1901000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.File_Cast(p1__1901000018_SHARP___1).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_42 any = A_arbace_build_go_A_const_16.GetRawRoot__O(); var linked_43 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_42, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_44 lang.IFn; if linked_43 == nil { ifn_44 = lang.IFn_Cast(root_42) } else { ifn_44 = nil }; var arg_45 any = jrt.File_Cast(p1__1901000018_SHARP___1).GetName__String().Ref(); var arg_46 any = Lit_51; if linked_43 == nil { and__1927000168__auto____3 = ifn_44.Invoke_O_O__O(arg_45, arg_46) } else { and__1927000168__auto____3 = linked_43.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_42, arg_45, arg_46) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
														var root_47 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_48 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_47, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_49 lang.IFn; if linked_48 == nil { ifn_49 = lang.IFn_Cast(root_47) } else { ifn_49 = nil }; var arg_50 any; var root_51 any = A_arbace_build_go_A_const_18.GetRawRoot__O(); var linked_52 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_51, A_arbace_build_go_data_dir_QMARK__A_fn_class); var ifn_53 lang.IFn; if linked_52 == nil { ifn_53 = lang.IFn_Cast(root_51) } else { ifn_53 = nil }; var arg_54 any = t.F_dir; var arg_55 any = p1__1901000018_SHARP___1; if linked_52 == nil { arg_50 = ifn_53.Invoke_O_O__O(arg_54, arg_55) } else { arg_50 = linked_52.(*A_arbace_build_go_data_dir_QMARK__A).Invoke_O_O_O__O(root_51, arg_54, arg_55) }; if linked_48 == nil { return ifn_49.Invoke_O__O(arg_50) } else { return linked_48.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_47, arg_50) } } else {
//line :84:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_build_go_clj_files_fn__1901000020_A_New() *A_arbace_build_go_clj_files_fn__1901000020_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000020_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Ctor() {}
//line :86:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Invoke_O_O__O(self, p1__1901000019_SHARP___1 any) any { return jrt.File_Cast(p1__1901000019_SHARP___1).GetPath__String().Ref() }

func A_arbace_build_go_package_file_QMARK__A_New() *A_arbace_build_go_package_file_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_build_go_package_file_QMARK__A) Ctor() {}
//line :88:1
func (t *A_arbace_build_go_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var root_62 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_63 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_62, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_64 lang.IFn; if




	linked_63 == nil { ifn_64 = lang.IFn_Cast(root_62) } else { ifn_64 = nil }; var arg_65 any; var root_66 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_67 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_66, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_68 lang.IFn; if linked_67 == nil { ifn_68 = lang.IFn_Cast(root_66) } else { ifn_68 = nil }; var arg_69 any; var fnbody__80 any = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New(); var tmp1 *jrt.Class; var fncls__79 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class; if fncls__79 == nil { var fncls__79d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_82, false, nil); A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class = fncls__79d; tmp1 = fncls__79d } else { tmp1 = fncls__79 }; arg_69 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__80, tmp1, nil); var arg_70 any = forms__3; if linked_67 == nil { arg_65 = ifn_68.Invoke_O_O__O(arg_69, arg_70) } else { arg_65 = linked_67.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_66, arg_69, arg_70) }; if linked_63 == nil { ns_form__4 = ifn_64.Invoke_O__O(arg_65) } else { ns_form__4 = linked_63.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_62, arg_65) }; var aliases__5 any; if
	jrt.J2g_Truth(ns_form__4) { aliases__5 = A_arbace_build_go_A_const_23.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp2 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_81 any = A_arbace_build_go_A_const_24.GetRawRoot__O(); var linked_82 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_81, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_83 lang.IFn; if linked_82 == nil { ifn_83 = lang.IFn_Cast(root_81) } else { ifn_83 = nil }; var arg_84 any; var fnbody__120 any = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(aliases__5); var tmp3 *jrt.Class; var fncls__119 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class; if fncls__119 == nil { var fncls__119d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_83, false, fnbody__120); A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class = fncls__119d; tmp3 = fncls__119d } else { tmp3 = fncls__119 }; arg_84 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__120, tmp3, nil); var arg_85 any = forms__3; if linked_82 == nil { tmp2 = ifn_83.Invoke_O_O__O(arg_84, arg_85) } else { tmp2 = linked_82.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_81, arg_84, arg_85) } } else {
//line :96:1
			tmp2 = and__1927000168__auto____6 }; return /*line :95:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp2)).Ref() }
//line :93:1
func A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New() *A_arbace_build_go_package_file_QMARK__fn__1901000027_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000027_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Ctor() {}
//line :93:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Invoke_O_O__O(self, p1__1901000025_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_71 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_72 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_71, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_73 lang.IFn; if linked_72 == nil { ifn_73 = lang.IFn_Cast(root_71) } else { ifn_73 = nil }; var arg_74 any = p1__1901000025_SHARP___1; if linked_72 == nil { and__1927000168__auto____2 = ifn_73.Invoke_O__O(arg_74) } else { and__1927000168__auto____2 = linked_72.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_71, arg_74) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_build_go_A_const_22; var tmp2 any; var root_75 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_76 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_75, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_77 lang.IFn; if linked_76 == nil { ifn_77 = lang.IFn_Cast(root_75) } else { ifn_77 = nil }; var arg_78 any = p1__1901000025_SHARP___1; if linked_76 == nil { tmp2 = ifn_77.Invoke_O__O(arg_78) } else { tmp2 = linked_76.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_75, arg_78) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(p0 any) *A_arbace_build_go_package_file_QMARK__fn__1901000029_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000029_A{}; t.Ctor_O(p0); return t }
//line :97:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :97:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Invoke_O_O__O(self, p1__1901000026_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_86 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_87 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_86, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_88 lang.IFn; if linked_87 == nil { ifn_88 = lang.IFn_Cast(root_86) } else { ifn_88 = nil }; var arg_89 any = p1__1901000026_SHARP___1; if linked_87 == nil { and__1927000168__auto____2 = ifn_88.Invoke_O__O(arg_89) } else { and__1927000168__auto____2 = linked_87.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_86, arg_89) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_90 any = A_arbace_build_go_A_const_25.GetRawRoot__O(); var linked_91 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_90, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_92 lang.IFn; if linked_91 == nil { ifn_92 = lang.IFn_Cast(root_90) } else { ifn_92 = nil }; var arg_93 any; var root_94 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_95 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_94, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_96 lang.IFn; if linked_95 == nil { ifn_96 = lang.IFn_Cast(root_94) } else { ifn_96 = nil }; var arg_97 any = p1__1901000026_SHARP___1; if linked_95 == nil { arg_93 = ifn_96.Invoke_O__O(arg_97) } else { arg_93 = linked_95.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_94, arg_97) }; if linked_91 == nil { and__1927000168__auto____3 = ifn_92.Invoke_O__O(arg_93) } else { and__1927000168__auto____3 = linked_91.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_90, arg_93) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool; var tmp1 any; var root_98 any = A_arbace_build_go_A_const_26.GetRawRoot__O(); var linked_99 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_98, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_100 lang.IFn
															if linked_99 == nil { ifn_100 = lang.IFn_Cast(root_98) } else { ifn_100 = nil }; var arg_101 any; var root_102 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_104 lang.IFn; if linked_103 == nil { ifn_104 = lang.IFn_Cast(root_102) } else { ifn_104 = nil }; var arg_105 any = p1__1901000026_SHARP___1; if linked_103 == nil { arg_101 = ifn_104.Invoke_O__O(arg_105) } else { arg_101 = linked_103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_102, arg_105) }; if linked_99 == nil { tmp1 = ifn_100.Invoke_O__O(arg_101) } else { tmp1 = linked_99.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_98, arg_101) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(Lit_84, tmp1)
//line :97:1
	if and__1927000168__auto____4 {

		var root_106 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_106, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_108 lang.IFn; if linked_107 == nil { ifn_108 = lang.IFn_Cast(root_106) } else { ifn_108 = nil }; var arg_109 any = t.F_aliases; var arg_110 any; var root_111 any = A_arbace_build_go_A_const_28.GetRawRoot__O(); var linked_112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_111, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_113 lang.IFn; if linked_112 == nil { ifn_113 = lang.IFn_Cast(root_111) } else { ifn_113 = nil }; var arg_114 any; var root_115 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_115, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_117 lang.IFn; if linked_116 == nil { ifn_117 = lang.IFn_Cast(root_115) } else { ifn_117 = nil }; var arg_118 any = p1__1901000026_SHARP___1; if linked_116 == nil { arg_114 = ifn_117.Invoke_O__O(arg_118) } else { arg_114 = linked_116.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_115, arg_118) }; if linked_112 == nil { arg_110 = ifn_113.Invoke_O__O(arg_114) } else { arg_110 = linked_112.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_111, arg_114) }; if linked_107 == nil { return ifn_108.Invoke_O_O__O(arg_109, arg_110) } else { return linked_107.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_106, arg_109, arg_110) } } else {
//line :97:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_build_go_rel_path_A_New() *A_arbace_build_go_rel_path_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_rel_path_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_build_go_rel_path_A) Ctor() {}
//line :104:1
func (t *A_arbace_build_go_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	var root_121 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_121, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_123 lang.IFn; if linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = jrt.File_Cast(base__0).GetAbsoluteFile__File().ToPath__Path().Relativize_Path__Path(jrt.File_Cast(f__1).GetAbsoluteFile__File().ToPath__Path()); if linked_122 == nil { return ifn_123.Invoke_O__O(arg_124) } else { return linked_122.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_121, arg_124)
	} }
func A_arbace_build_go_packages_A_New() *A_arbace_build_go_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_build_go_packages_A) Ctor() {}
//line :107:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O_O__O(self, dir__0, roots__1, print_cache__2 any) any { var own__4 any; var root_125 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_125, A_arbace_build_go_root_packages_A_fn_class); var ifn_127 lang.IFn; if








	linked_126 == nil { ifn_127 = lang.IFn_Cast(root_125) } else { ifn_127 = nil }; var arg_128 any = dir__0; var arg_129 any = print_cache__2; if linked_126 == nil { own__4 = ifn_127.Invoke_O_O__O(arg_128, arg_129) } else { own__4 = linked_126.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_125, arg_128, arg_129) }; var more__5 any; var iter__1927001039__auto____5 any; var fnbody__263 any = /*line :107:1*/A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(print_cache__2); var tmp1 *jrt.Class; var fncls__262 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class; if









	fncls__262 == nil { var fncls__262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_85, false, fnbody__263); A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class = fncls__262d; tmp1 = fncls__262d } else { tmp1 = fncls__262 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__263, tmp1, nil); more__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(roots__1); var pkgs__6 any; var root_264 any = /*line :107:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_266 lang.IFn; if













	linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_268 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = own__4; var arg_272 any = more__5; if linked_269 == nil { arg_267 = ifn_270.Invoke_O_O__O(arg_271, arg_272) } else { arg_267 = linked_269.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_268, arg_271, arg_272) }; if linked_265 == nil { pkgs__6 = ifn_266.Invoke_O__O(arg_267) } else { pkgs__6 = linked_265.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_264, arg_267) }; var seq_1901000050__7 any; var root_273 any = /*line :107:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_275 lang.IFn; if














	linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any; var root_277 any = A_arbace_build_go_A_const_47.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = A_arbace_build_go_A_const_48; var arg_281 any = pkgs__6; if linked_278 == nil { arg_276 = ifn_279.Invoke_O_O__O(arg_280, arg_281) } else { arg_276 = linked_278.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_277, arg_280, arg_281) }; if linked_274 == nil { seq_1901000050__7 = ifn_275.Invoke_O__O(arg_276) } else { seq_1901000050__7 = linked_274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_273, arg_276) }; var chunk_1901000051__8 any; var count_1901000052__9 int64 = 0; var i_1901000053__10 int64 = 0; L1:
//line :107:1
	for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000053__10, count_1901000052__9) { var vec__1901000054__11 any = lang.Indexed_Cast(chunk_1901000051__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000053__10)); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__13)), 1) {
			var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp4 any; var root_302 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_303 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_302, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_304 lang.IFn
			if linked_303 == nil { ifn_304 = lang.IFn_Cast(root_302) } else { ifn_304 = nil }; var arg_305 any = Lit_88; var arg_306 any; var root_307 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_308 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_307, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_309 lang.IFn; if linked_308 == nil { ifn_309 = lang.IFn_Cast(root_307) } else { ifn_309 = nil }; var arg_310 any; var fnbody__313 any = A_arbace_build_go_packages_fn__1901000057_A_New(); var tmp5 *jrt.Class; var fncls__312 *jrt.Class = A_arbace_build_go_packages_fn__1901000057_A_fn_class; if fncls__312 == nil { var fncls__312d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_89, false, nil); A_arbace_build_go_packages_fn__1901000057_A_fn_class = fncls__312d; tmp5 = fncls__312d } else { tmp5 = fncls__312 }; arg_310 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__313, tmp5, nil); var arg_311 any = ps__13; if linked_308 == nil { arg_306 = ifn_309.Invoke_O_O__O(arg_310, arg_311) } else { arg_306 = linked_308.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_307, arg_310, arg_311) }; if linked_303 == nil { tmp4 = ifn_304.Invoke_O_O__O(arg_305, arg_306) } else { tmp4 = linked_303.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_302, arg_305, arg_306) }
//line :123:1
			tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, path__12, nil, tmp4)).Ref())
//line :122:1
			seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } else { seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_282 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_282, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_284 lang.IFn; if linked_283 == nil { ifn_284 = lang.IFn_Cast(root_282) } else { ifn_284 = nil }; var arg_285 any = seq_1901000050__7; if linked_283 == nil { temp__1927000414__auto____11 = ifn_284.Invoke_O__O(arg_285) } else { temp__1927000414__auto____11 = linked_283.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_282, arg_285) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000050__12 any = temp__1927000414__auto____11; var tmp6 any; var root_286 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any = seq_1901000050__12; if linked_287 == nil { tmp6 = ifn_288.Invoke_O__O(arg_289) } else { tmp6 = linked_287.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_286, arg_289) }; if jrt.J2g_Truth(tmp6) { var c__1927000678__auto____13 any; var root_290 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_291 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_290, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_292 lang.IFn; if linked_291 == nil { ifn_292 = lang.IFn_Cast(root_290) } else { ifn_292 = nil }; var arg_293 any = seq_1901000050__12; if linked_291 == nil { c__1927000678__auto____13 = ifn_292.Invoke_O__O(arg_293) } else { c__1927000678__auto____13 = linked_291.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_290, arg_293) }; var tmp7 any; var root_314 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_315 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_314, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_316 lang.IFn; if linked_315 == nil { ifn_316 = lang.IFn_Cast(root_314) } else { ifn_316 = nil }; var arg_317 any = seq_1901000050__12; if linked_315 == nil { tmp7 = ifn_316.Invoke_O__O(arg_317) } else { tmp7 = linked_315.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_314, arg_317) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp7, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000059__13 any; var root_294 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_295 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_294, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_296 lang.IFn; if linked_295 == nil { ifn_296 = lang.IFn_Cast(root_294) } else { ifn_296 = nil }; var arg_297 any = seq_1901000050__12; if linked_295 == nil { vec__1901000059__13 = ifn_296.Invoke_O__O(arg_297) } else { vec__1901000059__13 = linked_295.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_294, arg_297) }; var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__15)), 1) {
				var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp10 any; var root_322 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_322, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_324 lang.IFn
				if linked_323 == nil { ifn_324 = lang.IFn_Cast(root_322) } else { ifn_324 = nil }; var arg_325 any = Lit_88; var arg_326 any; var root_327 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any; var fnbody__333 any = A_arbace_build_go_packages_fn__1901000062_A_New(); var tmp11 *jrt.Class; var fncls__332 *jrt.Class = A_arbace_build_go_packages_fn__1901000062_A_fn_class; if fncls__332 == nil { var fncls__332d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_90, false, nil); A_arbace_build_go_packages_fn__1901000062_A_fn_class = fncls__332d; tmp11 = fncls__332d } else { tmp11 = fncls__332 }; arg_330 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__333, tmp11, nil); var arg_331 any = ps__15; if linked_328 == nil { arg_326 = ifn_329.Invoke_O_O__O(arg_330, arg_331) } else { arg_326 = linked_328.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_327, arg_330, arg_331) }; if linked_323 == nil { tmp10 = ifn_324.Invoke_O_O__O(arg_325, arg_326) } else { tmp10 = linked_323.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_322, arg_325, arg_326) }
//line :123:1
				tmp8.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, path__14, nil, tmp10)).Ref())
//line :122:1
				var tmp12 any; var root_334 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_334, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_336 lang.IFn; if linked_335 == nil { ifn_336 = lang.IFn_Cast(root_334) } else { ifn_336 = nil }; var arg_337 any = seq_1901000050__12; if linked_335 == nil { tmp12 = ifn_336.Invoke_O__O(arg_337) } else { tmp12 = linked_335.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_334, arg_337) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp12, nil, 0, 0; continue L1 } else { var tmp13 any; var root_338 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_338, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_340 lang.IFn; if linked_339 == nil { ifn_340 = lang.IFn_Cast(root_338) } else { ifn_340 = nil }; var arg_341 any = seq_1901000050__12; if linked_339 == nil { tmp13 = ifn_340.Invoke_O__O(arg_341) } else { tmp13 = linked_339.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_338, arg_341) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp13, nil, 0, 0; continue L1 } } } }
//line :107:1
		break L1 }; return pkgs__6 }
//line :107:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any {






	var root_342 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_342, A_arbace_build_go_packages_A_fn_class); var ifn_344 lang.IFn; if linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = dir__0; var arg_346 any = roots__1; var arg_347 any; if linked_343 == nil { return ifn_344.Invoke_O_O_O__O(arg_345, arg_346, arg_347) } else { return linked_343.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_342, arg_345, arg_346, arg_347) } }
//line :107:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O__O(self, dir__0 any) any {





	var root_348 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_348, A_arbace_build_go_packages_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any = dir__0; var arg_352 any; var arg_353 any; if linked_349 == nil { return ifn_350.Invoke_O_O_O__O(arg_351, arg_352, arg_353) } else { return linked_349.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_348, arg_351, arg_352, arg_353)
	}
}

func A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(p0 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Ctor_O(c__print_cache any) { t.F_print_cache = c__print_cache }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Invoke_O_O__O(self, s__1901000035__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__261 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(self, t.F_print_cache, s__1901000035__1); var tmp2 *jrt.Class; var fncls__260 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class; if fncls__260 == nil { var fncls__260d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_91, false, fnbody__261); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class = fncls__260d; tmp2 = fncls__260d } else { tmp2 = fncls__260 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__261, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Ctor_O_O_O(c__iter__1901000034, c__print_cache, c__s__1901000035 any) { t.F_iter__1901000034 = c__iter__1901000034; t.F_print_cache = c__print_cache; t.F_s__1901000035 = c__s__1901000035 }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Invoke_O__O(self any) any { { var s__1901000035__1 any; var t_ any = t.F_s__1901000035; t.F_s__1901000035 = nil; s__1901000035__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_130 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = s__1901000035__1; if linked_131 == nil { temp__1927000414__auto____2 = ifn_132.Invoke_O__O(arg_133) } else { temp__1927000414__auto____2 = linked_131.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_130, arg_133) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_134 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = xs__1927001018__auto____3; if linked_135 == nil { r__4 = ifn_136.Invoke_O__O(arg_137) } else { r__4 = linked_135.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_134, arg_137) }; var iterys__1927001035__auto____5 any; var fnbody__233 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New(); var tmp1 *jrt.Class; var fncls__232 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class; if fncls__232 == nil { var fncls__232d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_92, false, nil); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class = fncls__232d; tmp1 = fncls__232d } else { tmp1 = fncls__232 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__233, tmp1, nil); var fs__1927001036__auto____6 any; var root_234 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_236 lang.IFn; if linked_235 == nil { ifn_236 = lang.IFn_Cast(root_234) } else { ifn_236 = nil }; var arg_237 any; var tmp2 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp3 any; var root_238 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_238, A_arbace_build_go_root_packages_A_fn_class); var ifn_240 lang.IFn
														if linked_239 == nil { ifn_240 = lang.IFn_Cast(root_238) } else { ifn_240 = nil }; var arg_241 any; var tmp4 any; var root_243 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_245 lang.IFn; if linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any = r__4; if linked_244 == nil { tmp4 = ifn_245.Invoke_O__O(arg_246) } else { tmp4 = linked_244.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_243, arg_246) }; arg_241 = jrt.File_New_String(jrt.String_Cast(tmp4)); var arg_242 any = t.F_print_cache; if linked_239 == nil { tmp3 = ifn_240.Invoke_O_O__O(arg_241, arg_242) } else { tmp3 = linked_239.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_238, arg_241, arg_242) }
//line :117:1
	arg_237 = tmp2.Invoke_O__O(tmp3); if linked_235 == nil { fs__1927001036__auto____6 = ifn_236.Invoke_O__O(arg_237) } else { fs__1927001036__auto____6 = linked_235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_234, arg_237) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_247 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = fs__1927001036__auto____6; var arg_251 any; var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1901000034); var tmp6 any; var root_252 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_254 lang.IFn; if linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any = s__1901000035__1; if linked_253 == nil { tmp6 = ifn_254.Invoke_O__O(arg_255) } else { tmp6 = linked_253.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_252, arg_255) }; arg_251 = tmp5.Invoke_O__O(tmp6); if linked_248 == nil { return ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { return linked_248.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) } } else { var tmp7 any; var root_256 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = s__1901000035__1; if linked_257 == nil { tmp7 = ifn_258.Invoke_O__O(arg_259) } else { tmp7 = linked_257.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_256, arg_259) }; s__1901000035__1 = tmp7; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New() *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Ctor() {}
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Invoke_O_O__O(self, s__1901000037__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__231 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(self, s__1901000037__1); var tmp2 *jrt.Class; var fncls__230 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class; if fncls__230 == nil { var fncls__230d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_93, false, fnbody__231); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class = fncls__230d; tmp2 = fncls__230d } else { tmp2 = fncls__230 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__231, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(p0, p1 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Ctor_O_O(c__iter__1901000036, c__s__1901000037 any) { t.F_iter__1901000036 = c__iter__1901000036; t.F_s__1901000037 = c__s__1901000037 }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Invoke_O__O(self any) any { { var s__1901000037__1 any; var t_ any = t.F_s__1901000037; t.F_s__1901000037 = nil; s__1901000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_138 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1901000037__1; if linked_139 == nil { temp__1927000414__auto____2 = ifn_140.Invoke_O__O(arg_141) } else { temp__1927000414__auto____2 = linked_139.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_142 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = s__1901000037__3; if linked_143 == nil { tmp1 = ifn_144.Invoke_O__O(arg_145) } else { tmp1 = linked_143.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_142, arg_145) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_146 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = s__1901000037__3; if linked_147 == nil { c__1927001037__auto____4 = ifn_148.Invoke_O__O(arg_149) } else { c__1927001037__auto____4 = linked_147.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_146, arg_149) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000039__6 any; var root_150 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_152 lang.IFn; if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_151 == nil { b__1901000039__6 = ifn_152.Invoke_O__O(arg_153) } else { b__1901000039__6 = linked_151.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_150, arg_153) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__175 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(b__1901000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__174 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class; if fncls__174 == nil { var fncls__174d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_94, false, fnbody__175); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class = fncls__174d; tmp3 = fncls__174d } else { tmp3 = fncls__174 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__175, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_176 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any; var root_181 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_182 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_181, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_183 lang.IFn; if linked_182 == nil { ifn_183 = lang.IFn_Cast(root_181) } else { ifn_183 = nil }; var arg_184 any = b__1901000039__6; if linked_182 == nil { arg_179 = ifn_183.Invoke_O__O(arg_184) } else { arg_179 = linked_182.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_181, arg_184) }; var arg_180 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp5 any; var root_185 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_185, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_187 lang.IFn; if linked_186 == nil { ifn_187 = lang.IFn_Cast(root_185) } else { ifn_187 = nil }; var arg_188 any = s__1901000037__3; if linked_186 == nil { tmp5 = ifn_187.Invoke_O__O(arg_188) } else { tmp5 = linked_186.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_185, arg_188) }; arg_180 = tmp4.Invoke_O__O(tmp5); if linked_177 == nil { return ifn_178.Invoke_O_O__O(arg_179, arg_180) } else { return linked_177.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_176, arg_179, arg_180) } } else { var root_189 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any; var root_194 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_195 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_194, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_196 lang.IFn; if linked_195 == nil { ifn_196 = lang.IFn_Cast(root_194) } else { ifn_196 = nil }; var arg_197 any = b__1901000039__6; if linked_195 == nil { arg_192 = ifn_196.Invoke_O__O(arg_197) } else { arg_192 = linked_195.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_194, arg_197) }; var arg_193 any; if linked_190 == nil { return ifn_191.Invoke_O_O__O(arg_192, arg_193) } else { return linked_190.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_189, arg_192, arg_193) } } } else { var pkg__4 any; var root_198 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_199 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_198, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_200 lang.IFn; if linked_199 == nil { ifn_200 = lang.IFn_Cast(root_198) } else { ifn_200 = nil }; var arg_201 any = s__1901000037__3; if linked_199 == nil { pkg__4 = ifn_200.Invoke_O__O(arg_201) } else { pkg__4 = linked_199.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_198, arg_201) }; var tmp6 any; var root_202 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_204 lang.IFn

	if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = Lit_95; var arg_206 any; var root_207 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_208 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_207, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_209 lang.IFn; if linked_208 == nil { ifn_209 = lang.IFn_Cast(root_207) } else { ifn_209 = nil }; var arg_210 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__4); if linked_208 == nil { arg_206 = ifn_209.Invoke_O__O(arg_210) } else { arg_206 = linked_208.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_207, arg_210) }; if linked_203 == nil { tmp6 = ifn_204.Invoke_O_O__O(arg_205, arg_206) } else { tmp6 = linked_203.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_202, arg_205, arg_206) }
//line :117:1
	if jrt.J2g_Truth(tmp6) { var root_211 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_213 lang.IFn; if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any; var root_216 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_217 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_216, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_218 lang.IFn


		if linked_217 == nil { ifn_218 = lang.IFn_Cast(root_216) } else { ifn_218 = nil }; var arg_219 any = pkg__4; var arg_220 any = A_arbace_build_go_A_const_39; var arg_221 any = jrt.Boolean_TRUE.Ref(); if linked_217 == nil { arg_214 = ifn_218.Invoke_O_O_O__O(arg_219, arg_220, arg_221) } else { arg_214 = linked_217.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_216, arg_219, arg_220, arg_221) }
//line :117:1
		var arg_215 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp8 any; var root_222 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_223 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_222, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_224 lang.IFn; if linked_223 == nil { ifn_224 = lang.IFn_Cast(root_222) } else { ifn_224 = nil }; var arg_225 any = s__1901000037__3; if linked_223 == nil { tmp8 = ifn_224.Invoke_O__O(arg_225) } else { tmp8 = linked_223.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_222, arg_225) }; arg_215 = tmp7.Invoke_O__O(tmp8); if linked_212 == nil { return ifn_213.Invoke_O_O__O(arg_214, arg_215) } else { return linked_212.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_211, arg_214, arg_215) } } else { var tmp9 any; var root_226 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_227 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_226, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_228 lang.IFn; if linked_227 == nil { ifn_228 = lang.IFn_Cast(root_226) } else { ifn_228 = nil }; var arg_229 any = s__1901000037__3; if linked_227 == nil { tmp9 = ifn_228.Invoke_O__O(arg_229) } else { tmp9 = linked_227.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_226, arg_229) }; s__1901000037__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Ctor_O_I_O(c__b__1901000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000039 = c__b__1901000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Invoke_O__O(self any) any { { var i__1901000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000038__1)); var tmp2 any; var root_154 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_155 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_154, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_156 lang.IFn

	if linked_155 == nil { ifn_156 = lang.IFn_Cast(root_154) } else { ifn_156 = nil }; var arg_157 any = Lit_95; var arg_158 any; var root_159 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__2); if linked_160 == nil { arg_158 = ifn_161.Invoke_O__O(arg_162) } else { arg_158 = linked_160.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_159, arg_162) }; if linked_155 == nil { tmp2 = ifn_156.Invoke_O_O__O(arg_157, arg_158) } else { tmp2 = linked_155.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_154, arg_157, arg_158) }
//line :117:1
	if jrt.J2g_Truth(tmp2) { var root_163 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_163, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_165 lang.IFn; if linked_164 == nil { ifn_165 = lang.IFn_Cast(root_163) } else { ifn_165 = nil }; var arg_166 any = t.F_b__1901000039; var arg_167 any; var root_168 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_168, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_170 lang.IFn


		if linked_169 == nil { ifn_170 = lang.IFn_Cast(root_168) } else { ifn_170 = nil }; var arg_171 any = pkg__2; var arg_172 any = A_arbace_build_go_A_const_39; var arg_173 any = jrt.Boolean_TRUE.Ref(); if linked_169 == nil { arg_167 = ifn_170.Invoke_O_O_O__O(arg_171, arg_172, arg_173) } else { arg_167 = linked_169.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_168, arg_171, arg_172, arg_173) }
//line :117:1
		if linked_164 == nil { ifn_165.Invoke_O_O__O(arg_166, arg_167) } else { linked_164.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_163, arg_166, arg_167) }; i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } else { i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_build_go_packages_fn__1901000057_A_New() *A_arbace_build_go_packages_fn__1901000057_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000057_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000033_SHARP___1)).GetPath__String().Ref() }
//line :124:1
func A_arbace_build_go_packages_fn__1901000062_A_New() *A_arbace_build_go_packages_fn__1901000062_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000062_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000033_SHARP___1)).GetPath__String().Ref() }


func A_arbace_build_go_read_all_A_New() *A_arbace_build_go_read_all_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_build_go_read_all_A) Ctor() {}
//line :127:1
func (t *A_arbace_build_go_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var root_354 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_356 lang.IFn; if




	linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any; var root_359 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_361 lang.IFn; if linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any; var fnbody__365 any = A_arbace_build_go_read_all_fn__1901000066_A_New(); var tmp1 *jrt.Class; var fncls__364 *jrt.Class = A_arbace_build_go_read_all_fn__1901000066_A_fn_class; if fncls__364 == nil { var fncls__364d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_138, false, nil); A_arbace_build_go_read_all_fn__1901000066_A_fn_class = fncls__364d; tmp1 = fncls__364d } else { tmp1 = fncls__364 }; arg_362 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__365, tmp1, nil); var arg_363 any = files__0; if linked_360 == nil { arg_357 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { arg_357 = linked_360.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; var arg_358 any; var root_366 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_367 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_366, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_368 lang.IFn; if
	linked_367 == nil { ifn_368 = lang.IFn_Cast(root_366) } else { ifn_368 = nil }; var arg_369 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var arg_370 any = files__0; if linked_367 == nil { arg_358 = ifn_368.Invoke_O_O__O(arg_369, arg_370) } else { arg_358 = linked_367.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_366, arg_369, arg_370) }; if /*line :132:1*/ linked_355 == nil { cache__2 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { cache__2 = linked_355.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; var fnbody__381 any =

	A_arbace_build_go_read_all_fn__1901000068_A_New_O(cache__2); var tmp2 *jrt.Class; var fncls__380 *jrt.Class = A_arbace_build_go_read_all_fn__1901000068_A_fn_class; if fncls__380 == nil { var fncls__380d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_139, false, fnbody__381); A_arbace_build_go_read_all_fn__1901000068_A_fn_class = fncls__380d; tmp2 = fncls__380d } else { tmp2 = fncls__380 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__381, tmp2, nil) }
//line :132:1
func A_arbace_build_go_read_all_fn__1901000066_A_New() *A_arbace_build_go_read_all_fn__1901000066_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000066_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Ctor() {}
//line :132:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Invoke_O_O__O(self, p1__1901000065_SHARP___1 any) any { return jrt.File_Cast(p1__1901000065_SHARP___1).GetAbsolutePath__String().Ref() }

func A_arbace_build_go_read_all_fn__1901000068_A_New_O(p0 any) *A_arbace_build_go_read_all_fn__1901000068_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000068_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :134:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.File_Cast(f__1).GetAbsolutePath__String().Ref(); var tmp1 any; var root_371 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_372 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_371, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_373 lang.IFn; if

	linked_372 == nil { ifn_373 = lang.IFn_Cast(root_371) } else { ifn_373 = nil }; var arg_374 any = t.F_cache; var arg_375 any = k__2; if linked_372 == nil { tmp1 = ifn_373.Invoke_O_O__O(arg_374, arg_375) } else { tmp1 = linked_372.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_371, arg_374, arg_375) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_cache, k__2) } else { var root_376 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var linked_377 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_376, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_378 lang.IFn; if linked_377 == nil { ifn_378 = lang.IFn_Cast(root_376) } else { ifn_378 = nil }; var arg_379 any = f__1; if linked_377 == nil { return ifn_378.Invoke_O__O(arg_379) } else { return linked_377.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_376, arg_379) } } }

func A_arbace_build_go_hex_A_New() *A_arbace_build_go_hex_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_build_go_hex_A) Ctor() {}
//line :138:1
func (t *A_arbace_build_go_hex_A) Invoke_O_O__O(self, bs__0 any) any {
	var root_382 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_384 lang.IFn; if linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_386 any; var root_387 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_388 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_387, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_389 lang.IFn; if linked_388 == nil { ifn_389 = lang.IFn_Cast(root_387) } else { ifn_389 = nil }; var arg_390 any; var fnbody__403 any = A_arbace_build_go_hex_fn__1901000072_A_New(); var tmp1 *jrt.Class; var fncls__402 *jrt.Class = A_arbace_build_go_hex_fn__1901000072_A_fn_class; if fncls__402 == nil { var fncls__402d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_81, false, nil); A_arbace_build_go_hex_fn__1901000072_A_fn_class = fncls__402d; tmp1 = fncls__402d } else { tmp1 = fncls__402 }; arg_390 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__403, tmp1, nil); var arg_391 any = bs__0; if linked_388 == nil { arg_386 = ifn_389.Invoke_O_O__O(arg_390, arg_391) } else { arg_386 = linked_388.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_387, arg_390, arg_391) }; if linked_383 == nil { return ifn_384.Invoke_O_O__O(arg_385, arg_386) } else { return linked_383.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_382, arg_385, arg_386) } }
//line :139:1
func A_arbace_build_go_hex_fn__1901000072_A_New() *A_arbace_build_go_hex_fn__1901000072_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_fn__1901000072_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Ctor() {}
//line :139:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Invoke_O_O__O(self, p1__1901000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_397 any = p1__1901000071_SHARP___1; var na_398 int64 = 255; if jrt.Long_InstanceOf(na_397) { var n0_399 int64 = jrt.NN(jrt.Long_Cast(na_397)).LongValue__J(); var n1_400 int64 = na_398; tmp2 = n0_399 & n1_400 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_397, na_398) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_file_sha_A_New() *A_arbace_build_go_file_sha_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_file_sha_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_build_go_file_sha_A) Ctor() {}
//line :141:1
func (t *A_arbace_build_go_file_sha_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.File_Cast(f__0).IsFile__Z() {
		var root_404 any = A_arbace_build_go_A_const_60.GetRawRoot__O(); var linked_405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_404, A_arbace_build_go_hex_A_fn_class); var ifn_406 lang.IFn; if linked_405 == nil { ifn_406 = lang.IFn_Cast(root_404) } else { ifn_406 = nil }; var arg_407 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__0).ToPath__Path())).Ref(); if linked_405 == nil { return ifn_406.Invoke_O__O(arg_407) } else { return linked_405.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_404, arg_407) } } else {
//line :144:1
			return nil
		}
}
func A_arbace_build_go_collect_package_A_New() *A_arbace_build_go_collect_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_build_go_collect_package_A) Ctor() {}
//line :147:1
func (t *A_arbace_build_go_collect_package_A) Invoke_O_O_O_O__O(self, dir__0, f__1, read_fn__2 any) any { var read__4 any; var root_408 any = A_arbace_build_go_A_const_61.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_410 lang.IFn; if



	linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = lang.PersistentVector_EMPTY.Ref(); if linked_409 == nil { read__4 = ifn_410.Invoke_O__O(arg_411) } else { read__4 = linked_409.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_408, arg_411) }; var pkg__5 any; var root_412 any = /*line :147:1*/A_arbace_build_go_A_const_62.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_414 lang.IFn; if




	linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = f__1; var arg_416 any; var fnbody__424 any = A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(read_fn__2, read__4); var tmp1 *jrt.Class; var fncls__423 *jrt.Class = A_arbace_build_go_collect_package_fn__1901000076_A_fn_class; if fncls__423 == nil { var fncls__423d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_55, false, fnbody__424); A_arbace_build_go_collect_package_fn__1901000076_A_fn_class = fncls__423d; tmp1 = fncls__423d } else { tmp1 = fncls__423 }; arg_416 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__424, tmp1, nil); if linked_413 == nil { pkg__5 = ifn_414.Invoke_O_O__O(arg_415, arg_416) } else { pkg__5 = linked_413.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_412, arg_415, arg_416) }; var tmp2 /*line :147:1*/*lang.Keyword = A_arbace_build_go_A_const_48; var path__6 any = tmp2.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__5)); var tmp3 any; var root_439 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_440 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_439, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_441 lang.IFn; if






	linked_440 == nil { ifn_441 = lang.IFn_Cast(root_439) } else { ifn_441 = nil }; var arg_442 any = path__6; if linked_440 == nil { tmp3 = ifn_441.Invoke_O__O(arg_442) } else { tmp3 = linked_440.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_439, arg_442) }; if jrt.J2g_Truth(tmp3) { } else {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56); var tmp6 any; var root_447 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_448 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_447, A_arbace_build_go_rel_path_A_fn_class); var ifn_449 lang.IFn; if linked_448 == nil { ifn_449 = lang.IFn_Cast(root_447) } else { ifn_449 = nil }; var arg_450 any = dir__0; var arg_451 any = f__1; if linked_448 == nil { tmp6 = ifn_449.Invoke_O_O__O(arg_450, arg_451) } else { tmp6 = linked_448.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_447, arg_450, arg_451) }; tmp4.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, tmp6, nil)).Ref()) }; var tmp7 lang.IFn =
	lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_52; var tmp9 any = A_arbace_build_go_A_const_48; var tmp10 any = A_arbace_build_go_A_const_65; var tmp11 any; var root_435 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_435, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_437 lang.IFn; if linked_436 == nil { ifn_437 = lang.IFn_Cast(root_435) } else { ifn_437 = nil }; var arg_438 any = read__4; if linked_436 == nil { tmp11 = ifn_437.Invoke_O__O(arg_438) } else { tmp11 = linked_436.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_435, arg_438) }; return tmp7.Invoke_O_O_O_O_O_O_O__O(pkg__5, tmp8, f__1, tmp9, path__6, tmp10, tmp11) }
//line :152:1
func A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(p0, p1 any) *A_arbace_build_go_collect_package_fn__1901000076_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_fn__1901000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :152:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Invoke_O_O__O(self, file__1 any) any { var root_417 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_418 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_417, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_419 lang.IFn; if linked_418 == nil { ifn_419 = lang.IFn_Cast(root_417) } else { ifn_419 = nil }; var arg_420 any = t.F_read; var arg_421 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_422 any = file__1; if linked_418 == nil { ifn_419.Invoke_O_O_O__O(arg_420, arg_421, arg_422) } else { linked_418.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_417, arg_420, arg_421, arg_422) }; return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }











func A_arbace_build_go_collect_index_file_A_New() *A_arbace_build_go_collect_index_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_index_file_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_build_go_collect_index_file_A) Ctor() {}
//line :164:1
func (t *A_arbace_build_go_collect_index_file_A) Invoke_O_O_O_O__O(self, print_cache__0, host_id__1, dir__2 any) any { var md__4 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52);

	jrt.MessageDigest_Cast(md__4).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, host_id__1, nil, jrt.File_Cast(dir__2).GetPath__String().Ref()))).GetBytes_String__B1(Lit_53)); var tmp1 /*line :164:1*/*jrt.Class = A_arbace_build_go_A_const_68; var tmp2 any; var root_452 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_453 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_452, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_454 lang.IFn; if


	linked_453 == nil { ifn_454 = lang.IFn_Cast(root_452) } else { ifn_454 = nil }; var arg_455 any = print_cache__0; if linked_453 == nil { tmp2 = ifn_454.Invoke_O__O(arg_455) } else { tmp2 = linked_453.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_452, arg_455) }; var tmp3 any = /*line :164:1*/jrt.File_New_String_String(jrt.String_Cast(tmp2), Lit_54); var tmp4 any; var root_456 any = A_arbace_build_go_A_const_60.GetRawRoot__O(); var linked_457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_456, A_arbace_build_go_hex_A_fn_class); var ifn_458 lang.IFn; if


	linked_457 == nil { ifn_458 = lang.IFn_Cast(root_456) } else { ifn_458 = nil }; var arg_459 any = jrt.MessageDigest_Cast(md__4).Digest__B1().Ref(); if linked_457 == nil { tmp4 = ifn_458.Invoke_O__O(arg_459) } else { tmp4 = linked_457.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_456, arg_459) }; return /*line :164:1*/ lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)) }




func A_arbace_build_go_read_index_A_New() *A_arbace_build_go_read_index_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_index_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_build_go_read_index_A) Ctor() {}
//line :169:1
func (t *A_arbace_build_go_read_index_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.File_Cast(f__0).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__0).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
//line :172:1
		var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1901000080__4 any; var root_460 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_462 lang.IFn

			if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = f__0; if linked_461 == nil { vec__1901000080__4 = ifn_462.Invoke_O__O(arg_463) } else { vec__1901000080__4 = linked_461.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_460, arg_463) }
//line :172:1
			var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp2 any; var root_464 any = A_arbace_build_go_A_const_69.GetRawRoot__O(); var linked_465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_464, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_466 lang.IFn

			if linked_465 == nil { ifn_466 = lang.IFn_Cast(root_464) } else { ifn_466 = nil }; var arg_467 any = m__5; if linked_465 == nil { tmp2 = ifn_466.Invoke_O__O(arg_467) } else { tmp2 = linked_465.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_464, arg_467) }; if jrt.J2g_Truth(tmp2) { tmp1 = m__5 } else { tmp1 = nil } }; return nil }()
//line :172:1
		if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_build_go_write_index_BANG__A_New() *A_arbace_build_go_write_index_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_build_go_write_index_BANG__A) Ctor() {}
//line :177:1
func (t *A_arbace_build_go_write_index_BANG__A) Invoke_O_O_O__O(self, f__0, index__1 any) any { var printed__3 any; var fnbody__489 any = A_arbace_build_go_write_index_BANG__printed__1901000087_A_New(); var tmp1 *jrt.Class; var fncls__488 *jrt.Class = A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class; if



	fncls__488 == nil { var fncls__488d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_192, false, nil); A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class = fncls__488d; tmp1 = fncls__488d } else { tmp1 = fncls__488 }; printed__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__489, tmp1, nil); var ok_QMARK___4 any; var fnbody__495 any = /*line :177:1*/A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(printed__3); var tmp2 *jrt.Class; var fncls__494 *jrt.Class = A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class; if



	fncls__494 == nil { var fncls__494d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_193, false, fnbody__495); A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class = fncls__494d; tmp2 = fncls__494d } else { tmp2 = fncls__494 }; ok_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__495, tmp2, nil); var index__5 any; var root_496 any = /*line :177:1*/A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_497 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_496, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_498 lang.IFn; if





	linked_497 == nil { ifn_498 = lang.IFn_Cast(root_496) } else { ifn_498 = nil }; var arg_499 any = index__1; var arg_500 any = A_arbace_build_go_A_const_79; var arg_501 any; var fnbody__522 any = A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(ok_QMARK___4); var tmp3 *jrt.Class; var fncls__521 *jrt.Class = A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class; if fncls__521 == nil { var fncls__521d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_194, false, fnbody__522); A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class = fncls__521d; tmp3 = fncls__521d } else { tmp3 = fncls__521 }; arg_501 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__522, tmp3, nil); if linked_497 == nil { index__5 = ifn_498.Invoke_O_O_O__O(arg_499, arg_500, arg_501) } else { index__5 = linked_497.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_496, arg_499, arg_500, arg_501) }; var tmp__6 any = /*line :177:1*/jrt.File_New_File_String(jrt.File_Cast(f__0).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, jrt.File_Cast(f__0).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));







	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__0).GetParentFile__File().Mkdirs__Z());
	lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(tmp__6, lang.IFn_Cast(printed__3).Invoke_O__O(index__5)); if
	jrt.File_Cast(tmp__6).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(tmp__6).Delete__Z()).Ref() } }
//line :181:1
func A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Ctor_O(c__printed any) { t.F_printed = c__printed }
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Invoke_O_O__O(self, p1__1901000085_SHARP___1 any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var tmp2 any; var root_490 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_490, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_492 lang.IFn; if linked_491 == nil { ifn_492 = lang.IFn_Cast(root_490) } else { ifn_492 = nil }; var arg_493 any = lang.IFn_Cast(t.F_printed).Invoke_O__O(p1__1901000085_SHARP___1); if linked_491 == nil { tmp2 = ifn_492.Invoke_O__O(arg_493) } else { tmp2 = linked_491.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_490, arg_493) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__1901000085_SHARP___1, tmp2)).Ref() }
//line :181:1
	return nil }(); if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :181:1
func A_arbace_build_go_write_index_BANG__printed__1901000087_A_New() *A_arbace_build_go_write_index_BANG__printed__1901000087_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__printed__1901000087_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Ctor() {}
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Invoke_O_O__O(self, p1__1901000084_SHARP___1 any) any { var root_475 any = A_arbace_build_go_A_const_72.GetRawRoot__O(); var linked_476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_475, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_477 lang.IFn; if linked_476 == nil { ifn_477 = lang.IFn_Cast(root_475) } else { ifn_477 = nil }; var arg_478 any = lang.IFn_Cast(A_arbace_build_go_A_const_73.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_build_go_A_const_74, jrt.Boolean_TRUE.Ref(), A_arbace_build_go_A_const_75, nil, A_arbace_build_go_A_const_76, nil); if linked_476 == nil { ifn_477.Invoke_O__O(arg_478) } else { linked_476.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_475, arg_478) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke_O__O(p1__1901000084_SHARP___1); return nil }(); var root_472 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_473 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_472, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_474 lang.IFn; if linked_473 == nil { ifn_474 = lang.IFn_Cast(root_472) } else { ifn_474 = nil }; if linked_473 == nil { ifn_474.Invoke__O() } else { linked_473.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_472) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__fn__1901000091_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__fn__1901000091_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Ctor_O(c__ok_QMARK_ any) { t.F_ok_QMARK_ = c__ok_QMARK_ }
//line :183:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Invoke_O_O__O(self, p1__1901000086_SHARP___1 any) any { var root_502 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_506 any; var root_511 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_512 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_511, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_513 lang.IFn; if linked_512 == nil { ifn_513 = lang.IFn_Cast(root_511) } else { ifn_513 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_82.GetRawRoot__O()); var tmp2 any = t.F_ok_QMARK_; var tmp3 any = A_arbace_build_go_A_const_83; var arg_514 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_build_go_A_const_84.GetRawRoot__O()); if linked_512 == nil { arg_506 = ifn_513.Invoke_O__O(arg_514) } else { arg_506 = linked_512.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_511, arg_514) }; var arg_507 any = p1__1901000086_SHARP___1; if linked_503 == nil { return ifn_504.Invoke_O_O_O__O(arg_505, arg_506, arg_507) } else { return linked_503.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_502, arg_505, arg_506, arg_507) } }





func A_arbace_build_go_root_packages_A_New() *A_arbace_build_go_root_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_build_go_root_packages_A) Ctor() {}
//line :189:1
func (t *A_arbace_build_go_root_packages_A) Invoke_O_O_O__O(self, dir__0, print_cache__1 any) any { var root__3 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_142); if




	jrt.File_Cast(root__3).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil, Lit_144), jrt.RefArrayOf(jrt.Object_class, nil, jrt.File_Cast(root__3).GetPath__String().Ref(), nil)).Ref()) }; var files__4 any; var root_528 any = /*line :189:1*/A_arbace_build_go_A_const_86.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, A_arbace_build_go_clj_files_A_fn_class); var ifn_530 lang.IFn; if






	linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any = root__3; if linked_529 == nil { files__4 = ifn_530.Invoke_O__O(arg_531) } else { files__4 = linked_529.(*A_arbace_build_go_clj_files_A).Invoke_O_O__O(root_528, arg_531) }; var host_id__5 any = /*line :189:1*/jrt.System_Getenv_String__String(Lit_113).Ref(); var index_file__6 any; var tmp1 any; var and__1927000168__auto____6 any = print_cache__1; if








	jrt.J2g_Truth(and__1927000168__auto____6) { var root_532 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = host_id__5; if linked_533 == nil { tmp1 = ifn_534.Invoke_O__O(arg_535) } else { tmp1 = linked_533.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_532, arg_535) } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { var root_536 any = A_arbace_build_go_A_const_87.GetRawRoot__O(); var linked_537 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_536, A_arbace_build_go_collect_index_file_A_fn_class); var ifn_538 lang.IFn; if linked_537 == nil { ifn_538 = lang.IFn_Cast(root_536) } else { ifn_538 = nil }; var arg_539 any = print_cache__1; var arg_540 any = host_id__5; var arg_541 any = dir__0; if linked_537 == nil { index_file__6 = ifn_538.Invoke_O_O_O__O(arg_539, arg_540, arg_541) } else { index_file__6 = linked_537.(*A_arbace_build_go_collect_index_file_A).Invoke_O_O_O_O__O(root_536, arg_539, arg_540, arg_541) } } else { index_file__6 = nil }; var index__7 any; if
	jrt.J2g_Truth(index_file__6) { var or__1927000174__auto____7 any; var root_542 any = A_arbace_build_go_A_const_88.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, A_arbace_build_go_read_index_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = index_file__6; if linked_543 == nil { or__1927000174__auto____7 = ifn_544.Invoke_O__O(arg_545) } else { or__1927000174__auto____7 = linked_543.(*A_arbace_build_go_read_index_A).Invoke_O_O__O(root_542, arg_545) }; if jrt.J2g_Truth(or__1927000174__auto____7) { index__7 = or__1927000174__auto____7 } else { index__7 = lang.PersistentArrayMap_EMPTY.Ref() } } else { index__7 = nil }; var shas__8 any; if
	jrt.J2g_Truth(index_file__6) { var m__8 any; var root_546 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_546, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_548 lang.IFn
		if linked_547 == nil { ifn_548 = lang.IFn_Cast(root_546) } else { ifn_548 = nil }; var arg_549 any; var root_551 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any; var fnbody__557 any = A_arbace_build_go_root_packages_fn__1901000099_A_New(); var tmp2 *jrt.Class; var fncls__556 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000099_A_fn_class; if fncls__556 == nil { var fncls__556d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_145, false, nil); A_arbace_build_go_root_packages_fn__1901000099_A_fn_class = fncls__556d; tmp2 = fncls__556d } else { tmp2 = fncls__556 }; arg_554 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__557, tmp2, nil); var arg_555 any = files__4; if linked_552 == nil { arg_549 = ifn_553.Invoke_O_O__O(arg_554, arg_555) } else { arg_549 = linked_552.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_551, arg_554, arg_555) }; var arg_550 any; var root_558 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_559 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_558, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_560 lang.IFn; if linked_559 == nil { ifn_560 = lang.IFn_Cast(root_558) } else { ifn_560 = nil }; var arg_561 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var arg_562 any = files__4; if linked_559 == nil { arg_550 = ifn_560.Invoke_O_O__O(arg_561, arg_562) } else { arg_550 = linked_559.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_558, arg_561, arg_562) }; if linked_547 == nil { m__8 = ifn_548.Invoke_O_O__O(arg_549, arg_550) } else { m__8 = linked_547.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_546, arg_549, arg_550) }
		var fnbody__573 any = A_arbace_build_go_root_packages_fn__1901000101_A_New_O(m__8); var tmp3 *jrt.Class; var fncls__572 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000101_A_fn_class; if fncls__572 == nil { var fncls__572d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_146, false, fnbody__573); A_arbace_build_go_root_packages_fn__1901000101_A_fn_class = fncls__572d; tmp3 = fncls__572d } else { tmp3 = fncls__572 }; shas__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__573, tmp3, nil) } else {
//line :200:1
			shas__8 = nil }; var valid__9 any; if


	jrt.J2g_Truth(index_file__6) {
		var root_574 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_574, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_576 lang.IFn; if linked_575 == nil { ifn_576 = lang.IFn_Cast(root_574) } else { ifn_576 = nil }; var arg_577 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_578 any; var iter__1927001039__auto____9 any; var fnbody__658 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(shas__8); var tmp4 *jrt.Class; var fncls__657 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class; if fncls__657 == nil { var fncls__657d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_147, false, fnbody__658); A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class = fncls__657d; tmp4 = fncls__657d } else { tmp4 = fncls__657 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__658, tmp4, nil); arg_578 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_build_go_A_const_79.Invoke_O__O(index__7)); if linked_575 == nil { valid__9 = ifn_576.Invoke_O_O__O(arg_577, arg_578) } else { valid__9 = linked_575.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_574, arg_577, arg_578) } } else {
//line :203:1
			valid__9 = nil }; var covered__10 any; var root_659 any = /*line :189:1*/A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_660 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_659, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_661 lang.IFn; if

















	linked_660 == nil { ifn_661 = lang.IFn_Cast(root_659) } else { ifn_661 = nil }; var arg_662 any; var iter__1927001039__auto____10 any; var fnbody__753 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New(); var tmp5 *jrt.Class; var fncls__752 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class; if fncls__752 == nil { var fncls__752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_148, false, nil); A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class = fncls__752d; tmp5 = fncls__752d } else { tmp5 = fncls__752 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__753, tmp5, nil); arg_662 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(valid__9); if linked_660 == nil { covered__10 = ifn_661.Invoke_O__O(arg_662) } else { covered__10 = linked_660.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_659, arg_662) }; var pf_index__11 any = /*line :189:1*/A_arbace_build_go_A_const_92.Invoke_O__O(index__7); var known_QMARK___12 any; var fnbody__760 any = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(index_file__6, pf_index__11, shas__8); var tmp6 *jrt.Class; var fncls__759 *jrt.Class = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class; if






	fncls__759 == nil { var fncls__759d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_149, false, fnbody__760); A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class = fncls__759d; tmp6 = fncls__759d } else { tmp6 = fncls__759 }; known_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__760, tmp6, nil); var read_fn__13 any; var root_761 any = /*line :189:1*/A_arbace_build_go_A_const_93.GetRawRoot__O(); var linked_762 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_761, A_arbace_build_go_read_all_A_fn_class); var ifn_763 lang.IFn; if




















	linked_762 == nil { ifn_763 = lang.IFn_Cast(root_761) } else { ifn_763 = nil }; var arg_764 any; var root_765 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_765, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_767 lang.IFn; if linked_766 == nil { ifn_767 = lang.IFn_Cast(root_765) } else { ifn_767 = nil }; var arg_768 any; var fnbody__775 any = A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(covered__10, known_QMARK___12); var tmp7 *jrt.Class; var fncls__774 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000158_A_fn_class; if fncls__774 == nil { var fncls__774d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_150, false, fnbody__775); A_arbace_build_go_root_packages_fn__1901000158_A_fn_class = fncls__774d; tmp7 = fncls__774d } else { tmp7 = fncls__774 }; arg_768 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__775, tmp7, nil); var arg_769 any = files__4; if linked_766 == nil { arg_764 = ifn_767.Invoke_O_O__O(arg_768, arg_769) } else { arg_764 = linked_766.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_765, arg_768, arg_769) }; if linked_762 == nil { read_fn__13 = ifn_763.Invoke_O__O(arg_764) } else { read_fn__13 = linked_762.(*A_arbace_build_go_read_all_A).Invoke_O_O__O(root_761, arg_764) }; var pkg_file_QMARK___14 any; var fnbody__782 any = /*line :189:1*/A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(read_fn__13, known_QMARK___12, pf_index__11, shas__8); var tmp8 *jrt.Class; var fncls__781 *jrt.Class = A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class; if





















	fncls__781 == nil { var fncls__781d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_151, false, fnbody__782); A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class = fncls__781d; tmp8 = fncls__781d } else { tmp8 = fncls__781 }; pkg_file_QMARK___14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__782, tmp8, nil); var pkgs__15 any; var root_783 any = /*line :189:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_785 lang.IFn; if























	linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any; var iter__1927001039__auto____15 any; var fnbody__922 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(pkg_file_QMARK___14, read_fn__13, dir__0, valid__9); var tmp9 *jrt.Class; var fncls__921 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class; if fncls__921 == nil { var fncls__921d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_152, false, fnbody__922); A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class = fncls__921d; tmp9 = fncls__921d } else { tmp9 = fncls__921 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__922, tmp9, nil); arg_786 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__4); if linked_784 == nil { pkgs__15 = ifn_785.Invoke_O__O(arg_786) } else { pkgs__15 = linked_784.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_783, arg_786) }; var tmp10 any; var root_927 any =




	A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_928 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_927, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_929 lang.IFn; if linked_928 == nil { ifn_929 = lang.IFn_Cast(root_927) } else { ifn_929 = nil }; var arg_930 any = pkgs__15; if linked_928 == nil { tmp10 = ifn_929.Invoke_O__O(arg_930) } else { tmp10 = linked_928.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_927, arg_930) }; if jrt.J2g_Truth(tmp10) {
		lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_153, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.File_Cast(root__3).GetPath__String().Ref())).Ref()) }; var seq_1901000180__16 any; var root_935 any = /*line :189:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_936 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_935, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_937 lang.IFn; if






























	linked_936 == nil { ifn_937 = lang.IFn_Cast(root_935) } else { ifn_937 = nil }; var arg_938 any; var root_939 any = A_arbace_build_go_A_const_47.GetRawRoot__O(); var linked_940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_939, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_941 lang.IFn; if linked_940 == nil { ifn_941 = lang.IFn_Cast(root_939) } else { ifn_941 = nil }; var arg_942 any = A_arbace_build_go_A_const_48; var arg_943 any = pkgs__15; if linked_940 == nil { arg_938 = ifn_941.Invoke_O_O__O(arg_942, arg_943) } else { arg_938 = linked_940.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_939, arg_942, arg_943) }; if linked_936 == nil { seq_1901000180__16 = ifn_937.Invoke_O__O(arg_938) } else { seq_1901000180__16 = linked_936.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_935, arg_938) }; var chunk_1901000181__17 any; var count_1901000182__18 int64 = 0; var i_1901000183__19 int64 = 0; L1:
//line :189:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000183__19, count_1901000182__18) { var vec__1901000184__20 any = lang.Indexed_Cast(chunk_1901000181__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000183__19)); var path__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__22)), 1) {
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp13 any; var root_1137 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1139 lang.IFn
			if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = Lit_88; var arg_1141 any; var root_1142 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1143 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1142, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1144 lang.IFn; if linked_1143 == nil { ifn_1144 = lang.IFn_Cast(root_1142) } else { ifn_1144 = nil }; var arg_1145 any; var fnbody__1153 any = A_arbace_build_go_root_packages_fn__1901000187_A_New_O(dir__0); var tmp14 *jrt.Class; var fncls__1152 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000187_A_fn_class; if fncls__1152 == nil { var fncls__1152d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_154, false, fnbody__1153); A_arbace_build_go_root_packages_fn__1901000187_A_fn_class = fncls__1152d; tmp14 = fncls__1152d } else { tmp14 = fncls__1152 }; arg_1145 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1153, tmp14, nil); var arg_1146 any = ps__22; if linked_1143 == nil { arg_1141 = ifn_1144.Invoke_O_O__O(arg_1145, arg_1146) } else { arg_1141 = linked_1143.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1142, arg_1145, arg_1146) }; if linked_1138 == nil { tmp13 = ifn_1139.Invoke_O_O__O(arg_1140, arg_1141) } else { tmp13 = linked_1138.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1137, arg_1140, arg_1141) }
//line :221:1
			tmp11.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, path__21, nil, tmp13)).Ref())
//line :220:1
			seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } else { seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } } else { var temp__1927000414__auto____20 any; var root_944 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = seq_1901000180__16; if linked_945 == nil { temp__1927000414__auto____20 = ifn_946.Invoke_O__O(arg_947) } else { temp__1927000414__auto____20 = linked_945.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_944, arg_947) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1901000180__21 any = temp__1927000414__auto____20; var tmp15 any; var root_948 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_949 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_948, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_950 lang.IFn; if linked_949 == nil { ifn_950 = lang.IFn_Cast(root_948) } else { ifn_950 = nil }; var arg_951 any = seq_1901000180__21; if linked_949 == nil { tmp15 = ifn_950.Invoke_O__O(arg_951) } else { tmp15 = linked_949.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_948, arg_951) }; if jrt.J2g_Truth(tmp15) { var c__1927000678__auto____22 any; var root_952 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_952, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_954 lang.IFn; if linked_953 == nil { ifn_954 = lang.IFn_Cast(root_952) } else { ifn_954 = nil }; var arg_955 any = seq_1901000180__21; if linked_953 == nil { c__1927000678__auto____22 = ifn_954.Invoke_O__O(arg_955) } else { c__1927000678__auto____22 = linked_953.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_952, arg_955) }; var tmp16 any; var root_1154 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1154, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1156 lang.IFn; if linked_1155 == nil { ifn_1156 = lang.IFn_Cast(root_1154) } else { ifn_1156 = nil }; var arg_1157 any = seq_1901000180__21; if linked_1155 == nil { tmp16 = ifn_1156.Invoke_O__O(arg_1157) } else { tmp16 = linked_1155.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1154, arg_1157) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp16, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000189__22 any; var root_956 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = seq_1901000180__21; if linked_957 == nil { vec__1901000189__22 = ifn_958.Invoke_O__O(arg_959) } else { vec__1901000189__22 = linked_957.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_956, arg_959) }; var path__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__24)), 1) {
				var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp19 any; var root_1162 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1163 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1162, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1164 lang.IFn
				if linked_1163 == nil { ifn_1164 = lang.IFn_Cast(root_1162) } else { ifn_1164 = nil }; var arg_1165 any = Lit_88; var arg_1166 any; var root_1167 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any; var fnbody__1178 any = A_arbace_build_go_root_packages_fn__1901000192_A_New_O(dir__0); var tmp20 *jrt.Class; var fncls__1177 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000192_A_fn_class; if fncls__1177 == nil { var fncls__1177d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_155, false, fnbody__1178); A_arbace_build_go_root_packages_fn__1901000192_A_fn_class = fncls__1177d; tmp20 = fncls__1177d } else { tmp20 = fncls__1177 }; arg_1170 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1178, tmp20, nil); var arg_1171 any = ps__24; if linked_1168 == nil { arg_1166 = ifn_1169.Invoke_O_O__O(arg_1170, arg_1171) } else { arg_1166 = linked_1168.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1167, arg_1170, arg_1171) }; if linked_1163 == nil { tmp19 = ifn_1164.Invoke_O_O__O(arg_1165, arg_1166) } else { tmp19 = linked_1163.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1162, arg_1165, arg_1166) }
//line :221:1
				tmp17.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, nil, path__23, nil, tmp19)).Ref())
//line :220:1
				var tmp21 any; var root_1179 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1179, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1181 lang.IFn; if linked_1180 == nil { ifn_1181 = lang.IFn_Cast(root_1179) } else { ifn_1181 = nil }; var arg_1182 any = seq_1901000180__21; if linked_1180 == nil { tmp21 = ifn_1181.Invoke_O__O(arg_1182) } else { tmp21 = linked_1180.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1179, arg_1182) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp21, nil, 0, 0; continue L1 } else { var tmp22 any; var root_1183 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1183, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1185 lang.IFn; if linked_1184 == nil { ifn_1185 = lang.IFn_Cast(root_1183) } else { ifn_1185 = nil }; var arg_1186 any = seq_1901000180__21; if linked_1184 == nil { tmp22 = ifn_1185.Invoke_O__O(arg_1186) } else { tmp22 = linked_1184.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1183, arg_1186) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp22, nil, 0, 0; continue L1 } } } }
//line :189:1
		break L1 }; if

































	jrt.J2g_Truth(index_file__6) { var index_SINGLEQUOTE___16 any; var tmp23 any = A_arbace_build_go_A_const_92; var tmp24 any; var root_960 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_962 lang.IFn
		if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_964 any; var iter__1927001039__auto____16 any; var fnbody__1033 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(pkg_file_QMARK___14, shas__8); var tmp25 *jrt.Class; var fncls__1032 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class
		if fncls__1032 == nil { var fncls__1032d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_156, false, fnbody__1033); A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class = fncls__1032d; tmp25 = fncls__1032d } else { tmp25 = fncls__1032 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1033, tmp25, nil); arg_964 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(files__4)
//line :224:1
		if linked_961 == nil { tmp24 = ifn_962.Invoke_O_O__O(arg_963, arg_964) } else { tmp24 = linked_961.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_960, arg_963, arg_964) }
//line :223:1
		var tmp26 any = tmp24; var tmp27 any = A_arbace_build_go_A_const_79; var tmp28 any; var root_1034 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_1035 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1034, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1036 lang.IFn



		if linked_1035 == nil { ifn_1036 = lang.IFn_Cast(root_1034) } else { ifn_1036 = nil }; var arg_1037 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_1038 any; var iter__1927001039__auto____16_2 any; var fnbody__1127 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(shas__8); var tmp29 *jrt.Class; var fncls__1126 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class
		if fncls__1126 == nil { var fncls__1126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_157, false, fnbody__1127); A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class = fncls__1126d; tmp29 = fncls__1126d } else { tmp29 = fncls__1126 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1127, tmp29, nil); arg_1038 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(pkgs__15)
//line :227:1
		if linked_1035 == nil { tmp28 = ifn_1036.Invoke_O_O__O(arg_1037, arg_1038) } else { tmp28 = linked_1035.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1034, arg_1037, arg_1038) }
//line :223:1
		index_SINGLEQUOTE___16 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp23, tmp26, tmp27, tmp28))








		if lang.Util_Equiv_O_O__Z_NoInit(index_SINGLEQUOTE___16, index__7) { } else {
			var root_1128 any = A_arbace_build_go_A_const_102.GetRawRoot__O(); var linked_1129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1128, A_arbace_build_go_write_index_BANG__A_fn_class); var ifn_1130 lang.IFn; if linked_1129 == nil { ifn_1130 = lang.IFn_Cast(root_1128) } else { ifn_1130 = nil }; var arg_1131 any = index_file__6; var arg_1132 any = index_SINGLEQUOTE___16; if linked_1129 == nil { ifn_1130.Invoke_O_O__O(arg_1131, arg_1132) } else { linked_1129.(*A_arbace_build_go_write_index_BANG__A).Invoke_O_O_O__O(root_1128, arg_1131, arg_1132) } } }; return pkgs__15 }
//line :196:1
func A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_known_QMARK___1901000156_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_known_QMARK___1901000156_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :196:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Ctor_O_O_O(c__index_file, c__pf_index, c__shas any) { t.F_index_file = c__index_file; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :196:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Invoke_O_O__O(self, p1__1901000095_SHARP___1 any) any { var and__1927000168__auto____2 any = t.F_index_file; if












	jrt.J2g_Truth(and__1927000168__auto____2) { var root_754 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = t.F_pf_index; var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); var arg_758 any = tmp1.Invoke_O__O(jrt.File_Cast(p1__1901000095_SHARP___1).GetPath__String().Ref()); if linked_755 == nil { return ifn_756.Invoke_O_O__O(arg_757, arg_758) } else { return linked_755.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_754, arg_757, arg_758) } } else { return and__1927000168__auto____2 } }
//line :201:1
func A_arbace_build_go_root_packages_fn__1901000099_A_New() *A_arbace_build_go_root_packages_fn__1901000099_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000099_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Ctor() {}
//line :201:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Invoke_O_O__O(self, p1__1901000094_SHARP___1 any) any { return jrt.File_Cast(p1__1901000094_SHARP___1).GetPath__String().Ref() }
func A_arbace_build_go_root_packages_fn__1901000101_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000101_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000101_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :202:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_563 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = t.F_m; var arg_567 any = path__1; if linked_564 == nil { tmp1 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { tmp1 = linked_564.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_m, path__1) } else { var root_568 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var linked_569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_568, A_arbace_build_go_file_sha_A_fn_class); var ifn_570 lang.IFn; if linked_569 == nil { ifn_570 = lang.IFn_Cast(root_568) } else { ifn_570 = nil }; var arg_571 any = jrt.File_New_String(jrt.String_Cast(path__1)); if linked_569 == nil { return ifn_570.Invoke_O__O(arg_571) } else { return linked_569.(*A_arbace_build_go_file_sha_A).Invoke_O_O__O(root_568, arg_571) } } }

func A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_A{}; t.Ctor_O(p0); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Invoke_O_O__O(self, s__1901000104__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__656 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(s__1901000104__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__655 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class; if fncls__655 == nil { var fncls__655d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_158, false, fnbody__656); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class = fncls__655d; tmp2 = fncls__655d } else { tmp2 = fncls__655 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__656, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Ctor_O_O_O(c__s__1901000104, c__iter__1901000103, c__shas any) { t.F_s__1901000104 = c__s__1901000104; t.F_iter__1901000103 = c__iter__1901000103; t.F_shas = c__shas }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Invoke_O__O(self any) any { { var s__1901000104__1 any; var t_ any = t.F_s__1901000104; t.F_s__1901000104 = nil; s__1901000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_579 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_580 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_579, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_581 lang.IFn; if linked_580 == nil { ifn_581 = lang.IFn_Cast(root_579) } else { ifn_581 = nil }; var arg_582 any = s__1901000104__1; if linked_580 == nil { temp__1927000414__auto____2 = ifn_581.Invoke_O__O(arg_582) } else { temp__1927000414__auto____2 = linked_580.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_579, arg_582) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_583 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_583, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_585 lang.IFn; if linked_584 == nil { ifn_585 = lang.IFn_Cast(root_583) } else { ifn_585 = nil }; var arg_586 any = s__1901000104__3; if linked_584 == nil { tmp1 = ifn_585.Invoke_O__O(arg_586) } else { tmp1 = linked_584.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_583, arg_586) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_587 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any = s__1901000104__3; if linked_588 == nil { c__1927001037__auto____4 = ifn_589.Invoke_O__O(arg_590) } else { c__1927001037__auto____4 = linked_588.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_587, arg_590) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000106__6 any; var root_591 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_591, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_593 lang.IFn; if linked_592 == nil { ifn_593 = lang.IFn_Cast(root_591) } else { ifn_593 = nil }; var arg_594 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_592 == nil { b__1901000106__6 = ifn_593.Invoke_O__O(arg_594) } else { b__1901000106__6 = linked_592.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_591, arg_594) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__608 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(b__1901000106__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__607 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class; if fncls__607 == nil { var fncls__607d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_159, false, fnbody__608); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class = fncls__607d; tmp3 = fncls__607d } else { tmp3 = fncls__607 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__608, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_609 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any; var root_614 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_615 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_614, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_616 lang.IFn; if linked_615 == nil { ifn_616 = lang.IFn_Cast(root_614) } else { ifn_616 = nil }; var arg_617 any = b__1901000106__6; if linked_615 == nil { arg_612 = ifn_616.Invoke_O__O(arg_617) } else { arg_612 = linked_615.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_614, arg_617) }; var arg_613 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp5 any; var root_618 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_618, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_620 lang.IFn; if linked_619 == nil { ifn_620 = lang.IFn_Cast(root_618) } else { ifn_620 = nil }; var arg_621 any = s__1901000104__3; if linked_619 == nil { tmp5 = ifn_620.Invoke_O__O(arg_621) } else { tmp5 = linked_619.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_618, arg_621) }; arg_613 = tmp4.Invoke_O__O(tmp5); if linked_610 == nil { return ifn_611.Invoke_O_O__O(arg_612, arg_613) } else { return linked_610.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_609, arg_612, arg_613) } } else { var root_622 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_624 lang.IFn; if linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var root_627 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_627, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_629 lang.IFn; if linked_628 == nil { ifn_629 = lang.IFn_Cast(root_627) } else { ifn_629 = nil }; var arg_630 any = b__1901000106__6; if linked_628 == nil { arg_625 = ifn_629.Invoke_O__O(arg_630) } else { arg_625 = linked_628.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_627, arg_630) }; var arg_626 any; if linked_623 == nil { return ifn_624.Invoke_O_O__O(arg_625, arg_626) } else { return linked_623.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_622, arg_625, arg_626) } } } else { var vec__1901000120__4 any; var root_631 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_631, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_633 lang.IFn; if linked_632 == nil { ifn_633 = lang.IFn_Cast(root_631) } else { ifn_633 = nil }; var arg_634 any = s__1901000104__3; if linked_632 == nil { vec__1901000120__4 = ifn_633.Invoke_O__O(arg_634) } else { vec__1901000120__4 = linked_632.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_631, arg_634) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_635 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_635, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_637 lang.IFn
															if linked_636 == nil { ifn_637 = lang.IFn_Cast(root_635) } else { ifn_637 = nil }; var arg_638 any; var fnbody__641 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(t.F_shas); var tmp7 *jrt.Class; var fncls__640 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class; if fncls__640 == nil { var fncls__640d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_160, false, fnbody__641); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class = fncls__640d; tmp7 = fncls__640d } else { tmp7 = fncls__640 }; arg_638 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__641, tmp7, nil); var arg_639 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__6); if linked_636 == nil { tmp6 = ifn_637.Invoke_O_O__O(arg_638, arg_639) } else { tmp6 = linked_636.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_635, arg_638, arg_639) }
//line :204:1
	if jrt.J2g_Truth(tmp6) { var root_642 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = lang.Tuple_Create_O_O__IPersistentVector(path__5, e__6); var arg_646 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp9 any; var root_647 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_647, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_649 lang.IFn; if linked_648 == nil { ifn_649 = lang.IFn_Cast(root_647) } else { ifn_649 = nil }; var arg_650 any = s__1901000104__3; if linked_648 == nil { tmp9 = ifn_649.Invoke_O__O(arg_650) } else { tmp9 = linked_648.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_647, arg_650) }; arg_646 = tmp8.Invoke_O__O(tmp9); if linked_643 == nil { return ifn_644.Invoke_O_O__O(arg_645, arg_646) } else { return linked_643.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_642, arg_645, arg_646) } } else { var tmp10 any; var root_651 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_651, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_653 lang.IFn; if linked_652 == nil { ifn_653 = lang.IFn_Cast(root_651) } else { ifn_653 = nil }; var arg_654 any = s__1901000104__3; if linked_652 == nil { tmp10 = ifn_653.Invoke_O__O(arg_654) } else { tmp10 = linked_652.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_651, arg_654) }; s__1901000104__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Ctor_O_I_O_O(c__b__1901000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000106 = c__b__1901000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Invoke_O__O(self any) any { { var i__1901000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000105__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_595 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_595, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_597 lang.IFn
																	if linked_596 == nil { ifn_597 = lang.IFn_Cast(root_595) } else { ifn_597 = nil }; var arg_598 any; var fnbody__601 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(t.F_shas); var tmp3 *jrt.Class; var fncls__600 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class; if fncls__600 == nil { var fncls__600d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_161, false, fnbody__601); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class = fncls__600d; tmp3 = fncls__600d } else { tmp3 = fncls__600 }; arg_598 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__601, tmp3, nil); var arg_599 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__4); if linked_596 == nil { tmp2 = ifn_597.Invoke_O_O__O(arg_598, arg_599) } else { tmp2 = linked_596.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_595, arg_598, arg_599) }
//line :204:1
	if jrt.J2g_Truth(tmp2) { var root_602 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_602, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_604 lang.IFn; if linked_603 == nil { ifn_604 = lang.IFn_Cast(root_602) } else { ifn_604 = nil }; var arg_605 any = t.F_b__1901000106; var arg_606 any = lang.Tuple_Create_O_O__IPersistentVector(path__3, e__4); if linked_603 == nil { ifn_604.Invoke_O_O__O(arg_605, arg_606) } else { linked_603.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_602, arg_605, arg_606) }; i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } else { i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A{}; t.Ctor_O(p0); return t }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Invoke_O_O__O(self, p__1901000113__1 any) any { var vec__1901000115__2 any = p__1901000113__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }
//line :205:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A{}; t.Ctor_O(p0); return t }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Invoke_O_O__O(self, p__1901000123__1 any) any { var vec__1901000125__2 any = p__1901000123__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }

func A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Ctor() {}
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Invoke_O_O__O(self, s__1901000132__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__751 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(self, s__1901000132__1); var tmp2 *jrt.Class; var fncls__750 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class; if fncls__750 == nil { var fncls__750d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_162, false, fnbody__751); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class = fncls__750d; tmp2 = fncls__750d } else { tmp2 = fncls__750 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__751, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Ctor_O_O(c__iter__1901000131, c__s__1901000132 any) { t.F_iter__1901000131 = c__iter__1901000131; t.F_s__1901000132 = c__s__1901000132 }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Invoke_O__O(self any) any { { var s__1901000132__1 any; var t_ any = t.F_s__1901000132; t.F_s__1901000132 = nil; s__1901000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_663 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_664 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_663, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_665 lang.IFn; if linked_664 == nil { ifn_665 = lang.IFn_Cast(root_663) } else { ifn_665 = nil }; var arg_666 any = s__1901000132__1; if linked_664 == nil { temp__1927000414__auto____2 = ifn_665.Invoke_O__O(arg_666) } else { temp__1927000414__auto____2 = linked_664.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_663, arg_666) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1901000139__4 any; var root_667 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_668 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_667, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_669 lang.IFn; if linked_668 == nil { ifn_669 = lang.IFn_Cast(root_667) } else { ifn_669 = nil }; var arg_670 any = xs__1927001018__auto____3; if linked_668 == nil { vec__1901000139__4 = ifn_669.Invoke_O__O(arg_670) } else { vec__1901000139__4 = linked_668.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_667, arg_670) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var fnbody__732 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New(); var tmp1 *jrt.Class; var fncls__731 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class; _ = ___5; if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_163, false, nil); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class = fncls__731d; tmp1 = fncls__731d } else { tmp1 = fncls__731 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__732, tmp1, nil); var fs__1927001036__auto____8 any; var root_733 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_733, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_735 lang.IFn; if linked_734 == nil { ifn_735 = lang.IFn_Cast(root_733) } else { ifn_735 = nil }; var arg_736 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_build_go_A_const_65.Invoke_O__O(e__6)); if linked_734 == nil { fs__1927001036__auto____8 = ifn_735.Invoke_O__O(arg_736) } else { fs__1927001036__auto____8 = linked_734.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_733, arg_736) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_737 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_738 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_737, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_739 lang.IFn; if linked_738 == nil { ifn_739 = lang.IFn_Cast(root_737) } else { ifn_739 = nil }; var arg_740 any = fs__1927001036__auto____8; var arg_741 any; var tmp2 lang.IFn = lang.IFn_Cast(t.F_iter__1901000131); var tmp3 any; var root_742 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__1901000132__1; if linked_743 == nil { tmp3 = ifn_744.Invoke_O__O(arg_745) } else { tmp3 = linked_743.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_742, arg_745) }; arg_741 = tmp2.Invoke_O__O(tmp3); if linked_738 == nil { return ifn_739.Invoke_O_O__O(arg_740, arg_741) } else { return linked_738.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_737, arg_740, arg_741) } } else { var tmp4 any; var root_746 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = s__1901000132__1; if linked_747 == nil { tmp4 = ifn_748.Invoke_O__O(arg_749) } else { tmp4 = linked_747.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_746, arg_749) }; s__1901000132__1 = tmp4; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Ctor() {}
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Invoke_O_O__O(self, s__1901000134__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__730 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(self, s__1901000134__1); var tmp2 *jrt.Class; var fncls__729 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class; if fncls__729 == nil { var fncls__729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_164, false, fnbody__730); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class = fncls__729d; tmp2 = fncls__729d } else { tmp2 = fncls__729 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__730, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Ctor_O_O(c__iter__1901000133, c__s__1901000134 any) { t.F_iter__1901000133 = c__iter__1901000133; t.F_s__1901000134 = c__s__1901000134 }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Invoke_O__O(self any) any { { var s__1901000134__1 any; var t_ any = t.F_s__1901000134; t.F_s__1901000134 = nil; s__1901000134__1 = t_; for { var temp__1927000414__auto____2 any; var root_671 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_671, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_673 lang.IFn; if linked_672 == nil { ifn_673 = lang.IFn_Cast(root_671) } else { ifn_673 = nil }; var arg_674 any = s__1901000134__1; if linked_672 == nil { temp__1927000414__auto____2 = ifn_673.Invoke_O__O(arg_674) } else { temp__1927000414__auto____2 = linked_672.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_671, arg_674) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000134__3 any = temp__1927000414__auto____2; var tmp1 any; var root_675 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_675, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_677 lang.IFn; if linked_676 == nil { ifn_677 = lang.IFn_Cast(root_675) } else { ifn_677 = nil }; var arg_678 any = s__1901000134__3; if linked_676 == nil { tmp1 = ifn_677.Invoke_O__O(arg_678) } else { tmp1 = linked_676.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_675, arg_678) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_679 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_680 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_679, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_681 lang.IFn; if linked_680 == nil { ifn_681 = lang.IFn_Cast(root_679) } else { ifn_681 = nil }; var arg_682 any = s__1901000134__3; if linked_680 == nil { c__1927001037__auto____4 = ifn_681.Invoke_O__O(arg_682) } else { c__1927001037__auto____4 = linked_680.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_679, arg_682) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000136__6 any; var root_683 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_684 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_683, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_685 lang.IFn; if linked_684 == nil { ifn_685 = lang.IFn_Cast(root_683) } else { ifn_685 = nil }; var arg_686 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_684 == nil { b__1901000136__6 = ifn_685.Invoke_O__O(arg_686) } else { b__1901000136__6 = linked_684.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_683, arg_686) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__693 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(b__1901000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__692 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class; if fncls__692 == nil { var fncls__692d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_165, false, fnbody__693); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class = fncls__692d; tmp3 = fncls__692d } else { tmp3 = fncls__692 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__693, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_694 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any; var root_699 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = b__1901000136__6; if linked_700 == nil { arg_697 = ifn_701.Invoke_O__O(arg_702) } else { arg_697 = linked_700.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_699, arg_702) }; var arg_698 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp5 any; var root_703 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_703, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_705 lang.IFn; if linked_704 == nil { ifn_705 = lang.IFn_Cast(root_703) } else { ifn_705 = nil }; var arg_706 any = s__1901000134__3; if linked_704 == nil { tmp5 = ifn_705.Invoke_O__O(arg_706) } else { tmp5 = linked_704.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_703, arg_706) }; arg_698 = tmp4.Invoke_O__O(tmp5); if linked_695 == nil { return ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { return linked_695.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_694, arg_697, arg_698) } } else { var root_707 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_707, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_709 lang.IFn; if linked_708 == nil { ifn_709 = lang.IFn_Cast(root_707) } else { ifn_709 = nil }; var arg_710 any; var root_712 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = b__1901000136__6; if linked_713 == nil { arg_710 = ifn_714.Invoke_O__O(arg_715) } else { arg_710 = linked_713.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_712, arg_715) }; var arg_711 any; if linked_708 == nil { return ifn_709.Invoke_O_O__O(arg_710, arg_711) } else { return linked_708.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_707, arg_710, arg_711) } } } else { var vec__1901000149__4 any; var root_716 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_716, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_718 lang.IFn; if linked_717 == nil { ifn_718 = lang.IFn_Cast(root_716) } else { ifn_718 = nil }; var arg_719 any = s__1901000134__3; if linked_717 == nil { vec__1901000149__4 = ifn_718.Invoke_O__O(arg_719) } else { vec__1901000149__4 = linked_717.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_716, arg_719) }; var rp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000149__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_720 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_720, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_722 lang.IFn; if linked_721 == nil { ifn_722 = lang.IFn_Cast(root_720) } else { ifn_722 = nil }; var arg_723 any = rp__5; var arg_724 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp7 any; var root_725 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_726 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_725, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_727 lang.IFn; if linked_726 == nil { ifn_727 = lang.IFn_Cast(root_725) } else { ifn_727 = nil }; var arg_728 any = s__1901000134__3; if linked_726 == nil { tmp7 = ifn_727.Invoke_O__O(arg_728) } else { tmp7 = linked_726.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_725, arg_728) }; arg_724 = tmp6.Invoke_O__O(tmp7); if linked_721 == nil { return ifn_722.Invoke_O_O__O(arg_723, arg_724) } else { return linked_721.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_720, arg_723, arg_724) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Ctor_O_I_O(c__b__1901000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000136 = c__b__1901000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Invoke_O__O(self any) any { { var i__1901000135__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000145__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000135__1)); var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000145__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_687 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = t.F_b__1901000136; var arg_691 any = rp__3; if linked_688 == nil { ifn_689.Invoke_O_O__O(arg_690, arg_691) } else { linked_688.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_687, arg_690, arg_691) }; i__1901000135__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000135__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_fn__1901000158_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Ctor_O_O(c__covered, c__known_QMARK_ any) { t.F_covered = c__covered; t.F_known_QMARK_ = c__known_QMARK_ }
//line :210:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Invoke_O_O__O(self, p1__1901000096_SHARP___1 any) any { var root_770 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any; var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(p1__1901000096_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_covered); arg_773 = tmp1.Invoke_O__O(jrt.File_Cast(p1__1901000096_SHARP___1).GetPath__String().Ref()) } else { arg_773 = and__1927000168__auto____2 }; if linked_771 == nil { return ifn_772.Invoke_O__O(arg_773) } else { return linked_771.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_770, arg_773) } }
func A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :211:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Ctor_O_O_O_O(c__read_fn, c__known_QMARK_, c__pf_index, c__shas any) { t.F_read_fn = c__read_fn; t.F_known_QMARK_ = c__known_QMARK_; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :211:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Invoke_O_O__O(self, f__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(f__1)) { var tmp1 any = t.F_pf_index; var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2.Invoke_O__O(jrt.File_Cast(f__1).GetPath__String().Ref())) } else { var root_776 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_776, A_arbace_build_go_package_file_QMARK__A_fn_class); var ifn_778 lang.IFn; if linked_777 == nil { ifn_778 = lang.IFn_Cast(root_776) } else { ifn_778 = nil }; var arg_779 any = f__1; var arg_780 any = t.F_read_fn; if linked_777 == nil { return ifn_778.Invoke_O_O__O(arg_779, arg_780) } else { return linked_777.(*A_arbace_build_go_package_file_QMARK__A).Invoke_O_O_O__O(root_776, arg_779, arg_780) } } }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Invoke_O_O__O(self, s__1901000163__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__920 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(t.F_pkg_file_QMARK_, t.F_read_fn, t.F_dir, t.F_valid, s__1901000163__1, self); var tmp2 *jrt.Class; var fncls__919 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class; if fncls__919 == nil { var fncls__919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_166, false, fnbody__920); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class = fncls__919d; tmp2 = fncls__919d } else { tmp2 = fncls__919 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__920, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Ctor_O_O_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid, c__s__1901000163, c__iter__1901000162 any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid; t.F_s__1901000163 = c__s__1901000163; t.F_iter__1901000162 = c__iter__1901000162 }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Invoke_O__O(self any) any { { var s__1901000163__1 any; var t_ any = t.F_s__1901000163; t.F_s__1901000163 = nil; s__1901000163__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_787 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_787, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_789 lang.IFn; if linked_788 == nil { ifn_789 = lang.IFn_Cast(root_787) } else { ifn_789 = nil }; var arg_790 any = s__1901000163__1; if linked_788 == nil { temp__1927000414__auto____2 = ifn_789.Invoke_O__O(arg_790) } else { temp__1927000414__auto____2 = linked_788.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_787, arg_790) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000163__3 any = temp__1927000414__auto____2; var tmp1 any; var root_791 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_791, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_793 lang.IFn; if linked_792 == nil { ifn_793 = lang.IFn_Cast(root_791) } else { ifn_793 = nil }; var arg_794 any = s__1901000163__3; if linked_792 == nil { tmp1 = ifn_793.Invoke_O__O(arg_794) } else { tmp1 = linked_792.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_791, arg_794) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_795 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any = s__1901000163__3; if linked_796 == nil { c__1927001037__auto____4 = ifn_797.Invoke_O__O(arg_798) } else { c__1927001037__auto____4 = linked_796.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_795, arg_798) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000165__6 any; var root_799 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_800 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_799, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_801 lang.IFn; if linked_800 == nil { ifn_801 = lang.IFn_Cast(root_799) } else { ifn_801 = nil }; var arg_802 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_800 == nil { b__1901000165__6 = ifn_801.Invoke_O__O(arg_802) } else { b__1901000165__6 = linked_800.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_799, arg_802) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__844 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(t.F_pkg_file_QMARK_, t.F_read_fn, b__1901000165__6, t.F_dir, t.F_valid, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__843 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class; if fncls__843 == nil { var fncls__843d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_167, false, fnbody__844); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class = fncls__843d; tmp3 = fncls__843d } else { tmp3 = fncls__843 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__844, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_845 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_845, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_847 lang.IFn; if linked_846 == nil { ifn_847 = lang.IFn_Cast(root_845) } else { ifn_847 = nil }; var arg_848 any; var root_850 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_852 lang.IFn; if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any = b__1901000165__6; if linked_851 == nil { arg_848 = ifn_852.Invoke_O__O(arg_853) } else { arg_848 = linked_851.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_850, arg_853) }; var arg_849 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp5 any; var root_854 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_855 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_854, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_856 lang.IFn; if linked_855 == nil { ifn_856 = lang.IFn_Cast(root_854) } else { ifn_856 = nil }; var arg_857 any = s__1901000163__3; if linked_855 == nil { tmp5 = ifn_856.Invoke_O__O(arg_857) } else { tmp5 = linked_855.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_854, arg_857) }; arg_849 = tmp4.Invoke_O__O(tmp5); if linked_846 == nil { return ifn_847.Invoke_O_O__O(arg_848, arg_849) } else { return linked_846.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_845, arg_848, arg_849) } } else { var root_858 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_859 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_858, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_860 lang.IFn; if linked_859 == nil { ifn_860 = lang.IFn_Cast(root_858) } else { ifn_860 = nil }; var arg_861 any; var root_863 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_864 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_863, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_865 lang.IFn; if linked_864 == nil { ifn_865 = lang.IFn_Cast(root_863) } else { ifn_865 = nil }; var arg_866 any = b__1901000165__6; if linked_864 == nil { arg_861 = ifn_865.Invoke_O__O(arg_866) } else { arg_861 = linked_864.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_863, arg_866) }; var arg_862 any; if linked_859 == nil { return ifn_860.Invoke_O_O__O(arg_861, arg_862) } else { return linked_859.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_858, arg_861, arg_862) } } } else { var f__4 any; var root_867 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = s__1901000163__3; if linked_868 == nil { f__4 = ifn_869.Invoke_O__O(arg_870) } else { f__4 = linked_868.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_867, arg_870) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4)) { var root_871 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_872 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_871, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_873 lang.IFn; if linked_872 == nil { ifn_873 = lang.IFn_Cast(root_871) } else { ifn_873 = nil }; var arg_874 any; var tmp6 any = t.F_valid; var temp__1927000408__auto____5 any = lang.RT_Get_O_O__O_NoInit(tmp6, jrt.File_Cast(f__4).GetPath__String().Ref())
															if jrt.J2g_Truth(temp__1927000408__auto____5) { var e__6 any = temp__1927000408__auto____5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_83.Invoke_O__O(e__6); var tmp9 any = A_arbace_build_go_A_const_52; var tmp10 any = A_arbace_build_go_A_const_65; var tmp11 any; var root_886 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_887 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_886, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_888 lang.IFn
																if linked_887 == nil { ifn_888 = lang.IFn_Cast(root_886) } else { ifn_888 = nil }; var arg_889 any; var fnbody__896 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New(); var tmp12 *jrt.Class; var fncls__895 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class; if fncls__895 == nil { var fncls__895d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_168, false, nil); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class = fncls__895d; tmp12 = fncls__895d } else { tmp12 = fncls__895 }; arg_889 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__896, tmp12, nil); var arg_890 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__6); if linked_887 == nil { tmp11 = ifn_888.Invoke_O_O__O(arg_889, arg_890) } else { tmp11 = linked_887.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_886, arg_889, arg_890) }; var tmp13 any = tmp11; var tmp14 any = A_arbace_build_go_A_const_96; var tmp15 *lang.Compiler_AOTFn; var fnbody__904 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(f__4, t.F_dir); var tmp16 *jrt.Class; var fncls__903 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class
																if fncls__903 == nil { var fncls__903d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_169, false, fnbody__904); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class = fncls__903d; tmp16 = fncls__903d } else { tmp16 = fncls__903 }; tmp15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__904, tmp16, nil)
//line :215:1
		arg_874 = tmp7.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp9, f__4, tmp10, tmp13, tmp14, lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp15))) } else {

			var root_905 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_905, A_arbace_build_go_collect_package_A_fn_class); var ifn_907 lang.IFn; if linked_906 == nil { ifn_907 = lang.IFn_Cast(root_905) } else { ifn_907 = nil }; var arg_908 any = t.F_dir; var arg_909 any = f__4; var arg_910 any = t.F_read_fn; if linked_906 == nil { arg_874 = ifn_907.Invoke_O_O_O__O(arg_908, arg_909, arg_910) } else { arg_874 = linked_906.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_905, arg_908, arg_909, arg_910) } }
//line :213:1
	var arg_875 any; var tmp17 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp18 any; var root_911 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_912 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_911, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_913 lang.IFn; if linked_912 == nil { ifn_913 = lang.IFn_Cast(root_911) } else { ifn_913 = nil }; var arg_914 any = s__1901000163__3; if linked_912 == nil { tmp18 = ifn_913.Invoke_O__O(arg_914) } else { tmp18 = linked_912.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_911, arg_914) }; arg_875 = tmp17.Invoke_O__O(tmp18); if linked_872 == nil { return ifn_873.Invoke_O_O__O(arg_874, arg_875) } else { return linked_872.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_871, arg_874, arg_875) } } else { var tmp19 any; var root_915 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_915, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_917 lang.IFn; if linked_916 == nil { ifn_917 = lang.IFn_Cast(root_915) } else { ifn_917 = nil }; var arg_918 any = s__1901000163__3; if linked_916 == nil { tmp19 = ifn_917.Invoke_O__O(arg_918) } else { tmp19 = linked_916.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_915, arg_918) }; s__1901000163__1 = tmp19; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Ctor_O_O_O_O_O_I_O(c__pkg_file_QMARK_, c__read_fn, c__b__1901000165, c__dir, c__valid any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_b__1901000165 = c__b__1901000165; t.F_dir = c__dir; t.F_valid = c__valid; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Invoke_O__O(self any) any { { var i__1901000164__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000164__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000164__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2)) { var root_803 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_804 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_803, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_805 lang.IFn; if linked_804 == nil { ifn_805 = lang.IFn_Cast(root_803) } else { ifn_805 = nil }; var arg_806 any = t.F_b__1901000165; var arg_807 any; var tmp2 any = t.F_valid; var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O_NoInit(tmp2, jrt.File_Cast(f__2).GetPath__String().Ref())
																	if jrt.J2g_Truth(temp__1927000408__auto____3) { var e__4 any = temp__1927000408__auto____3; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_83.Invoke_O__O(e__4); var tmp5 any = A_arbace_build_go_A_const_52; var tmp6 any = A_arbace_build_go_A_const_65; var tmp7 any; var root_818 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_820 lang.IFn
																		if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any; var fnbody__828 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New(); var tmp8 *jrt.Class; var fncls__827 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class; if fncls__827 == nil { var fncls__827d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_170, false, nil); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class = fncls__827d; tmp8 = fncls__827d } else { tmp8 = fncls__827 }; arg_821 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__828, tmp8, nil); var arg_822 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__4); if linked_819 == nil { tmp7 = ifn_820.Invoke_O_O__O(arg_821, arg_822) } else { tmp7 = linked_819.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_818, arg_821, arg_822) }; var tmp9 any = tmp7; var tmp10 any = A_arbace_build_go_A_const_96; var tmp11 *lang.Compiler_AOTFn; var fnbody__836 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(f__2, t.F_dir); var tmp12 *jrt.Class; var fncls__835 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class
																		if fncls__835 == nil { var fncls__835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_171, false, fnbody__836); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class = fncls__835d; tmp12 = fncls__835d } else { tmp12 = fncls__835 }; tmp11 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__836, tmp12, nil)
//line :215:1
		arg_807 = tmp3.Invoke_O_O_O_O_O_O_O__O(tmp4, tmp5, f__2, tmp6, tmp9, tmp10, lang.Delay_New_IFn(Up_Compiler_AOTFn_IFn(tmp11))) } else {

			var root_837 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_837, A_arbace_build_go_collect_package_A_fn_class); var ifn_839 lang.IFn; if linked_838 == nil { ifn_839 = lang.IFn_Cast(root_837) } else { ifn_839 = nil }; var arg_840 any = t.F_dir; var arg_841 any = f__2; var arg_842 any = t.F_read_fn; if linked_838 == nil { arg_807 = ifn_839.Invoke_O_O_O__O(arg_840, arg_841, arg_842) } else { arg_807 = linked_838.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_837, arg_840, arg_841, arg_842) } }
//line :213:1
	if linked_804 == nil { ifn_805.Invoke_O_O__O(arg_806, arg_807) } else { linked_804.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_803, arg_806, arg_807) }; i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } else { i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Ctor() {}
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_823 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any = p1__1901000097_SHARP___1; if linked_824 == nil { tmp1 = ifn_825.Invoke_O__O(arg_826) } else { tmp1 = linked_824.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_823, arg_826) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
//line :215:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Ctor() {}
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_891 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_891, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_893 lang.IFn; if linked_892 == nil { ifn_893 = lang.IFn_Cast(root_891) } else { ifn_893 = nil }; var arg_894 any = p1__1901000097_SHARP___1; if linked_892 == nil { tmp1 = ifn_893.Invoke_O__O(arg_894) } else { tmp1 = linked_892.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_891, arg_894) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Invoke_O__O(self any) any { var root_829 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_830 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_829, A_arbace_build_go_collect_package_A_fn_class); var ifn_831 lang.IFn; if linked_830 == nil { ifn_831 = lang.IFn_Cast(root_829) } else { ifn_831 = nil }; var arg_832 any; var t_ any = t.F_dir; t.F_dir = nil; arg_832 = t_; var arg_833 any; var t__2 any = t.F_f; t.F_f = nil; arg_833 = t__2; var arg_834 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); if linked_830 == nil { return ifn_831.Invoke_O_O_O__O(arg_832, arg_833, arg_834) } else { return linked_830.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_829, arg_832, arg_833, arg_834) } }
//line :216:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Invoke_O__O(self any) any { var root_897 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_898 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_897, A_arbace_build_go_collect_package_A_fn_class); var ifn_899 lang.IFn; if linked_898 == nil { ifn_899 = lang.IFn_Cast(root_897) } else { ifn_899 = nil }; var arg_900 any; var t_ any = t.F_dir; t.F_dir = nil; arg_900 = t_; var arg_901 any; var t__2 any = t.F_f; t.F_f = nil; arg_901 = t__2; var arg_902 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); if linked_898 == nil { return ifn_899.Invoke_O_O_O__O(arg_900, arg_901, arg_902) } else { return linked_898.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_897, arg_900, arg_901, arg_902) } }





func A_arbace_build_go_root_packages_fn__1901000187_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000187_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000187_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1147 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, A_arbace_build_go_rel_path_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = t.F_dir; var arg_1151 any = A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1148 == nil { return ifn_1149.Invoke_O_O__O(arg_1150, arg_1151) } else { return linked_1148.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1147, arg_1150, arg_1151) } }
//line :222:1
func A_arbace_build_go_root_packages_fn__1901000192_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000192_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000192_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1172 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, A_arbace_build_go_rel_path_A_fn_class); var ifn_1174 lang.IFn; if linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = t.F_dir; var arg_1176 any = A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1173 == nil { return ifn_1174.Invoke_O_O__O(arg_1175, arg_1176) } else { return linked_1173.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1172, arg_1175, arg_1176) } }


func A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Ctor_O_O(c__pkg_file_QMARK_, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Invoke_O_O__O(self, s__1901000195__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1031 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(t.F_pkg_file_QMARK_, s__1901000195__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__1030 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class; if fncls__1030 == nil { var fncls__1030d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_172, false, fnbody__1031); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class = fncls__1030d; tmp2 = fncls__1030d } else { tmp2 = fncls__1030 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1031, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__s__1901000195, c__iter__1901000194, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_s__1901000195 = c__s__1901000195; t.F_iter__1901000194 = c__iter__1901000194; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Invoke_O__O(self any) any { { var s__1901000195__1 any; var t_ any = t.F_s__1901000195; t.F_s__1901000195 = nil; s__1901000195__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_968 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = s__1901000195__1; if linked_969 == nil { temp__1927000414__auto____2 = ifn_970.Invoke_O__O(arg_971) } else { temp__1927000414__auto____2 = linked_969.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_968, arg_971) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000195__3 any = temp__1927000414__auto____2; var tmp1 any; var root_972 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = s__1901000195__3; if linked_973 == nil { tmp1 = ifn_974.Invoke_O__O(arg_975) } else { tmp1 = linked_973.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_972, arg_975) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_976 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = s__1901000195__3; if linked_977 == nil { c__1927001037__auto____4 = ifn_978.Invoke_O__O(arg_979) } else { c__1927001037__auto____4 = linked_977.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_976, arg_979) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000197__6 any; var root_980 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_980, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_982 lang.IFn; if linked_981 == nil { ifn_982 = lang.IFn_Cast(root_980) } else { ifn_982 = nil }; var arg_983 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_981 == nil { b__1901000197__6 = ifn_982.Invoke_O__O(arg_983) } else { b__1901000197__6 = linked_981.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_980, arg_983) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__990 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(t.F_pkg_file_QMARK_, b__1901000197__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__989 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class; if fncls__989 == nil { var fncls__989d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_173, false, fnbody__990); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class = fncls__989d; tmp3 = fncls__989d } else { tmp3 = fncls__989 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__990, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_991 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any; var root_996 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_997 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_996, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_998 lang.IFn; if linked_997 == nil { ifn_998 = lang.IFn_Cast(root_996) } else { ifn_998 = nil }; var arg_999 any = b__1901000197__6; if linked_997 == nil { arg_994 = ifn_998.Invoke_O__O(arg_999) } else { arg_994 = linked_997.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_996, arg_999) }; var arg_995 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp5 any; var root_1000 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1000, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1002 lang.IFn; if linked_1001 == nil { ifn_1002 = lang.IFn_Cast(root_1000) } else { ifn_1002 = nil }; var arg_1003 any = s__1901000195__3; if linked_1001 == nil { tmp5 = ifn_1002.Invoke_O__O(arg_1003) } else { tmp5 = linked_1001.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1000, arg_1003) }; arg_995 = tmp4.Invoke_O__O(tmp5); if linked_992 == nil { return ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { return linked_992.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) } } else { var root_1004 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1005 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1004, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1006 lang.IFn; if linked_1005 == nil { ifn_1006 = lang.IFn_Cast(root_1004) } else { ifn_1006 = nil }; var arg_1007 any; var root_1009 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1009, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1011 lang.IFn; if linked_1010 == nil { ifn_1011 = lang.IFn_Cast(root_1009) } else { ifn_1011 = nil }; var arg_1012 any = b__1901000197__6; if linked_1010 == nil { arg_1007 = ifn_1011.Invoke_O__O(arg_1012) } else { arg_1007 = linked_1010.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1009, arg_1012) }; var arg_1008 any; if linked_1005 == nil { return ifn_1006.Invoke_O_O__O(arg_1007, arg_1008) } else { return linked_1005.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1004, arg_1007, arg_1008) } } } else { var f__4 any; var root_1013 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1014 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1013, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1015 lang.IFn; if linked_1014 == nil { ifn_1015 = lang.IFn_Cast(root_1013) } else { ifn_1015 = nil }; var arg_1016 any = s__1901000195__3; if linked_1014 == nil { f__4 = ifn_1015.Invoke_O__O(arg_1016) } else { f__4 = linked_1014.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1013, arg_1016) }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__5 any = tmp6.Invoke_O__O(jrt.File_Cast(f__4).GetPath__String().Ref()); if jrt.J2g_Truth(sha__5) { var root_1017 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1018 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1017, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1019 lang.IFn; if linked_1018 == nil { ifn_1019 = lang.IFn_Cast(root_1017) } else { ifn_1019 = nil }; var arg_1020 any = lang.Tuple_Create_O_O__IPersistentVector(sha__5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4))).Ref()); var arg_1021 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp8 any; var root_1022 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1022, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1024 lang.IFn; if linked_1023 == nil { ifn_1024 = lang.IFn_Cast(root_1022) } else { ifn_1024 = nil }; var arg_1025 any = s__1901000195__3; if linked_1023 == nil { tmp8 = ifn_1024.Invoke_O__O(arg_1025) } else { tmp8 = linked_1023.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1022, arg_1025) }; arg_1021 = tmp7.Invoke_O__O(tmp8); if linked_1018 == nil { return ifn_1019.Invoke_O_O__O(arg_1020, arg_1021) } else { return linked_1018.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1017, arg_1020, arg_1021) } } else { var tmp9 any; var root_1026 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1028 lang.IFn; if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = s__1901000195__3; if linked_1027 == nil { tmp9 = ifn_1028.Invoke_O__O(arg_1029) } else { tmp9 = linked_1027.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1026, arg_1029) }; s__1901000195__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Ctor_O_O_I_O_O(c__pkg_file_QMARK_, c__b__1901000197 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_b__1901000197 = c__b__1901000197; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Invoke_O__O(self any) any { { var i__1901000196__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__3 any = tmp2.Invoke_O__O(jrt.File_Cast(f__2).GetPath__String().Ref()); if jrt.J2g_Truth(sha__3) { var root_984 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_985 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_984, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_986 lang.IFn; if linked_985 == nil { ifn_986 = lang.IFn_Cast(root_984) } else { ifn_986 = nil }; var arg_987 any = t.F_b__1901000197; var arg_988 any = lang.Tuple_Create_O_O__IPersistentVector(sha__3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2))).Ref()); if linked_985 == nil { ifn_986.Invoke_O_O__O(arg_987, arg_988) } else { linked_985.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_984, arg_987, arg_988) }; i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } else { i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Invoke_O_O__O(self, s__1901000205__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1125 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(s__1901000205__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__1124 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class; if fncls__1124 == nil { var fncls__1124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_174, false, fnbody__1125); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class = fncls__1124d; tmp2 = fncls__1124d } else { tmp2 = fncls__1124 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1125, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :228:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Ctor_O_O_O(c__s__1901000205, c__iter__1901000204, c__shas any) { t.F_s__1901000205 = c__s__1901000205; t.F_iter__1901000204 = c__iter__1901000204; t.F_shas = c__shas }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Invoke_O__O(self any) any { { var s__1901000205__1 any; var t_ any = t.F_s__1901000205; t.F_s__1901000205 = nil; s__1901000205__1 = t_; for { var temp__1927000414__auto____2 any; var root_1042 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = s__1901000205__1; if linked_1043 == nil { temp__1927000414__auto____2 = ifn_1044.Invoke_O__O(arg_1045) } else { temp__1927000414__auto____2 = linked_1043.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1042, arg_1045) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1046 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any = s__1901000205__3; if linked_1047 == nil { tmp1 = ifn_1048.Invoke_O__O(arg_1049) } else { tmp1 = linked_1047.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1046, arg_1049) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1050 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = s__1901000205__3; if linked_1051 == nil { c__1927001037__auto____4 = ifn_1052.Invoke_O__O(arg_1053) } else { c__1927001037__auto____4 = linked_1051.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1050, arg_1053) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000207__6 any; var root_1054 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1055 == nil { b__1901000207__6 = ifn_1056.Invoke_O__O(arg_1057) } else { b__1901000207__6 = linked_1055.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1054, arg_1057) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1076 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(b__1901000207__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__1075 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class; if fncls__1075 == nil { var fncls__1075d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_175, false, fnbody__1076); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class = fncls__1075d; tmp3 = fncls__1075d } else { tmp3 = fncls__1075 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1076, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1077 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1079 lang.IFn; if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any; var root_1082 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any = b__1901000207__6; if linked_1083 == nil { arg_1080 = ifn_1084.Invoke_O__O(arg_1085) } else { arg_1080 = linked_1083.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1082, arg_1085) }; var arg_1081 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp5 any; var root_1086 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1086, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1088 lang.IFn; if linked_1087 == nil { ifn_1088 = lang.IFn_Cast(root_1086) } else { ifn_1088 = nil }; var arg_1089 any = s__1901000205__3; if linked_1087 == nil { tmp5 = ifn_1088.Invoke_O__O(arg_1089) } else { tmp5 = linked_1087.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1086, arg_1089) }; arg_1081 = tmp4.Invoke_O__O(tmp5); if linked_1078 == nil { return ifn_1079.Invoke_O_O__O(arg_1080, arg_1081) } else { return linked_1078.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1077, arg_1080, arg_1081) } } else { var root_1090 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1090, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1092 lang.IFn; if linked_1091 == nil { ifn_1092 = lang.IFn_Cast(root_1090) } else { ifn_1092 = nil }; var arg_1093 any; var root_1095 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1096 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1095, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1097 lang.IFn; if linked_1096 == nil { ifn_1097 = lang.IFn_Cast(root_1095) } else { ifn_1097 = nil }; var arg_1098 any = b__1901000207__6; if linked_1096 == nil { arg_1093 = ifn_1097.Invoke_O__O(arg_1098) } else { arg_1093 = linked_1096.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1095, arg_1098) }; var arg_1094 any; if linked_1091 == nil { return ifn_1092.Invoke_O_O__O(arg_1093, arg_1094) } else { return linked_1091.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1090, arg_1093, arg_1094) } } } else { var pkg__4 any; var root_1099 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = s__1901000205__3; if linked_1100 == nil { pkg__4 = ifn_1101.Invoke_O__O(arg_1102) } else { pkg__4 = linked_1100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1099, arg_1102) }; var root_1103 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1103, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1105 lang.IFn; if linked_1104 == nil { ifn_1105 = lang.IFn_Cast(root_1103) } else { ifn_1105 = nil }; var arg_1106 any; var tmp6 any = jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(pkg__4)).GetPath__String().Ref(); var tmp7 any = A_arbace_build_go_A_const_65; var tmp8 any; var root_1108 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_1109 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1108, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1110 lang.IFn

	if linked_1109 == nil { ifn_1110 = lang.IFn_Cast(root_1108) } else { ifn_1110 = nil }; var arg_1111 any; var fnbody__1114 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(t.F_shas); var tmp9 *jrt.Class; var fncls__1113 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class; if fncls__1113 == nil { var fncls__1113d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_176, false, fnbody__1114); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class = fncls__1113d; tmp9 = fncls__1113d } else { tmp9 = fncls__1113 }; arg_1111 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1114, tmp9, nil); var arg_1112 any = A_arbace_build_go_A_const_65.Invoke_O__O(pkg__4); if linked_1109 == nil { tmp8 = ifn_1110.Invoke_O_O__O(arg_1111, arg_1112) } else { tmp8 = linked_1109.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1108, arg_1111, arg_1112) }
//line :228:1
	var tmp10 any = tmp8; var tmp11 any = A_arbace_build_go_A_const_83; var tmp12 any; var root_1115 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1116 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1115, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1117 lang.IFn


	if linked_1116 == nil { ifn_1117 = lang.IFn_Cast(root_1115) } else { ifn_1117 = nil }; var arg_1118 any = pkg__4; var arg_1119 any = A_arbace_build_go_A_const_101; if linked_1116 == nil { tmp12 = ifn_1117.Invoke_O_O__O(arg_1118, arg_1119) } else { tmp12 = linked_1116.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1115, arg_1118, arg_1119) }
//line :228:1
	arg_1106 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp10, tmp11, tmp12))); var arg_1107 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp14 any; var root_1120 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1120, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1122 lang.IFn; if linked_1121 == nil { ifn_1122 = lang.IFn_Cast(root_1120) } else { ifn_1122 = nil }; var arg_1123 any = s__1901000205__3; if linked_1121 == nil { tmp14 = ifn_1122.Invoke_O__O(arg_1123) } else { tmp14 = linked_1121.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1120, arg_1123) }; arg_1107 = tmp13.Invoke_O__O(tmp14); if linked_1104 == nil { return ifn_1105.Invoke_O_O__O(arg_1106, arg_1107) } else { return linked_1104.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1103, arg_1106, arg_1107) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :228:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Ctor_O_I_O_O(c__b__1901000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000207 = c__b__1901000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Invoke_O__O(self any) any { { var i__1901000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000206__1)); var root_1058 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any = t.F_b__1901000207; var arg_1062 any; var tmp2 any = jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(pkg__2)).GetPath__String().Ref(); var tmp3 any = A_arbace_build_go_A_const_65; var tmp4 any; var root_1063 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1065 lang.IFn

	if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any; var fnbody__1069 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(t.F_shas); var tmp5 *jrt.Class; var fncls__1068 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class; if fncls__1068 == nil { var fncls__1068d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_177, false, fnbody__1069); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class = fncls__1068d; tmp5 = fncls__1068d } else { tmp5 = fncls__1068 }; arg_1066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1069, tmp5, nil); var arg_1067 any = A_arbace_build_go_A_const_65.Invoke_O__O(pkg__2); if linked_1064 == nil { tmp4 = ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { tmp4 = linked_1064.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) }
//line :228:1
	var tmp6 any = tmp4; var tmp7 any = A_arbace_build_go_A_const_83; var tmp8 any; var root_1070 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1070, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1072 lang.IFn


	if linked_1071 == nil { ifn_1072 = lang.IFn_Cast(root_1070) } else { ifn_1072 = nil }; var arg_1073 any = pkg__2; var arg_1074 any = A_arbace_build_go_A_const_100; if linked_1071 == nil { tmp8 = ifn_1072.Invoke_O_O__O(arg_1073, arg_1074) } else { tmp8 = linked_1071.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1070, arg_1073, arg_1074) }
//line :228:1
	arg_1062 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp6, tmp7, tmp8))); if linked_1059 == nil { ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { linked_1059.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) }; i__1901000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.File_Cast(r__1).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.File_Cast(r__1).GetPath__String().Ref())) }
//line :230:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.File_Cast(r__1).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.File_Cast(r__1).GetPath__String().Ref())) }





func A_arbace_build_go_collected_package_A_New() *A_arbace_build_go_collected_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collected_package_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_build_go_collected_package_A) Ctor() {}
//line :236:1
func (t *A_arbace_build_go_collected_package_A) Invoke_O_O__O(self, pkg__0 any) any { var temp__1927000408__auto____2 any = A_arbace_build_go_A_const_96.Invoke_O__O(pkg__0); if



	jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var c__4 any; var root_1187 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_1188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1187, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1189 lang.IFn
		if linked_1188 == nil { ifn_1189 = lang.IFn_Cast(root_1187) } else { ifn_1189 = nil }; var arg_1190 any = d__3; if linked_1188 == nil { c__4 = ifn_1189.Invoke_O__O(arg_1190) } else { c__4 = linked_1188.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1187, arg_1190) }
		var tmp1 any; var root_1191 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1191, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1193 lang.IFn; if linked_1192 == nil { ifn_1193 = lang.IFn_Cast(root_1191) } else { ifn_1193 = nil }; var arg_1194 any = c__4; var arg_1195 any = A_arbace_build_go_A_const_103; if linked_1192 == nil { tmp1 = ifn_1193.Invoke_O_O__O(arg_1194, arg_1195) } else { tmp1 = linked_1192.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1191, arg_1194, arg_1195) }; var tmp2 any = tmp1; var tmp3 any; var root_1196 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = pkg__0; var arg_1200 any = A_arbace_build_go_A_const_104; if linked_1197 == nil { tmp3 = ifn_1198.Invoke_O_O__O(arg_1199, arg_1200) } else { tmp3 = linked_1197.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1196, arg_1199, arg_1200) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_57), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_48.Invoke_O__O(pkg__0), nil)).Ref()) }
//line :240:1
		return c__4 } else { return pkg__0 } }






func A_arbace_build_go_read_program_edn_A_New() *A_arbace_build_go_read_program_edn_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_program_edn_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_build_go_read_program_edn_A) Ctor() {}
//line :247:1
func (t *A_arbace_build_go_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_140); if

	jrt.File_Cast(f__2).IsFile__Z() { var forms__3 any; var root_1205 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var linked_1206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1205, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_1207 lang.IFn
		if linked_1206 == nil { ifn_1207 = lang.IFn_Cast(root_1205) } else { ifn_1207 = nil }; var arg_1208 any = f__2; if linked_1206 == nil { forms__3 = ifn_1207.Invoke_O__O(arg_1208) } else { forms__3 = linked_1206.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_1205, arg_1208) }
		var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(forms__3))); if and__1927000168__auto____4 { var root_1213 any = A_arbace_build_go_A_const_69.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1215 lang.IFn; if linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any; var root_1217 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1217, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1219 lang.IFn; if linked_1218 == nil { ifn_1219 = lang.IFn_Cast(root_1217) } else { ifn_1219 = nil }; var arg_1220 any = forms__3; if linked_1218 == nil { arg_1216 = ifn_1219.Invoke_O__O(arg_1220) } else { arg_1216 = linked_1218.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1217, arg_1220) }; if linked_1214 == nil { tmp1 = ifn_1215.Invoke_O__O(arg_1216) } else { tmp1 = linked_1214.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1213, arg_1216) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(Lit_141) }
		var root_1209 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1209, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1211 lang.IFn; if linked_1210 == nil { ifn_1211 = lang.IFn_Cast(root_1209) } else { ifn_1211 = nil }; var arg_1212 any = forms__3; if linked_1210 == nil { return ifn_1211.Invoke_O__O(arg_1212) } else { return linked_1210.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1209, arg_1212) } } else {
//line :249:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_build_go_run_A_New() *A_arbace_build_go_run_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_run_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_build_go_run_A) Ctor() {}
//line :256:1
func (t *A_arbace_build_go_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any; var tmp1 any; var root_1225 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1225, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1227 lang.IFn; if



	linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1229 any = cmd__0; if linked_1226 == nil { tmp1 = ifn_1227.Invoke_O_O__O(arg_1228, arg_1229) } else { tmp1 = linked_1226.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1225, arg_1228, arg_1229) }; pb__5 = /*line :256:1*/jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp1));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :256:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_1901000221__7 any; var root_1234 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1236 lang.IFn; if






	linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = env__2; if linked_1235 == nil { seq_1901000221__7 = ifn_1236.Invoke_O__O(arg_1237) } else { seq_1901000221__7 = linked_1235.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1234, arg_1237) }; var chunk_1901000222__8 any; var count_1901000223__9 int64 = 0; var i_1901000224__10 int64 = 0; L1:
//line :256:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000224__10, count_1901000223__9) { var vec__1901000225__11 any = lang.Indexed_Cast(chunk_1901000222__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000224__10)); var k__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000224__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1238 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1239 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1238, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1240 lang.IFn; if linked_1239 == nil { ifn_1240 = lang.IFn_Cast(root_1238) } else { ifn_1240 = nil }; var arg_1241 any = seq_1901000221__7; if linked_1239 == nil { temp__1927000414__auto____11 = ifn_1240.Invoke_O__O(arg_1241) } else { temp__1927000414__auto____11 = linked_1239.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1238, arg_1241) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000221__12 any = temp__1927000414__auto____11; var tmp2 any; var root_1242 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1242, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1244 lang.IFn; if linked_1243 == nil { ifn_1244 = lang.IFn_Cast(root_1242) } else { ifn_1244 = nil }; var arg_1245 any = seq_1901000221__12; if linked_1243 == nil { tmp2 = ifn_1244.Invoke_O__O(arg_1245) } else { tmp2 = linked_1243.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1242, arg_1245) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____13 any; var root_1246 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = seq_1901000221__12; if linked_1247 == nil { c__1927000678__auto____13 = ifn_1248.Invoke_O__O(arg_1249) } else { c__1927000678__auto____13 = linked_1247.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1246, arg_1249) }; var tmp3 any; var root_1254 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1254, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1256 lang.IFn; if linked_1255 == nil { ifn_1256 = lang.IFn_Cast(root_1254) } else { ifn_1256 = nil }; var arg_1257 any = seq_1901000221__12; if linked_1255 == nil { tmp3 = ifn_1256.Invoke_O__O(arg_1257) } else { tmp3 = linked_1255.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1254, arg_1257) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp3, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000228__13 any; var root_1250 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1251 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1250, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1252 lang.IFn; if linked_1251 == nil { ifn_1252 = lang.IFn_Cast(root_1250) } else { ifn_1252 = nil }; var arg_1253 any = seq_1901000221__12; if linked_1251 == nil { vec__1901000228__13 = ifn_1252.Invoke_O__O(arg_1253) } else { vec__1901000228__13 = linked_1251.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1250, arg_1253) }; var k__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); var tmp4 any; var root_1258 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1258, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1260 lang.IFn; if linked_1259 == nil { ifn_1260 = lang.IFn_Cast(root_1258) } else { ifn_1260 = nil }; var arg_1261 any = seq_1901000221__12; if linked_1259 == nil { tmp4 = ifn_1260.Invoke_O__O(arg_1261) } else { tmp4 = linked_1259.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1258, arg_1261) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp4, nil, 0, 0; continue L1 } } }
//line :256:1
		break L1 }; if







	jrt.J2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :264:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())
//line :264:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_105.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_build_go_go_env_A_New() *A_arbace_build_go_go_env_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_env_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_build_go_go_env_A) Ctor() {}
//line :274:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z_NoInit(goos__2, Lit_29) { var tmp4 *lang.Keyword = A_arbace_build_go_A_const_48; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_65, tmp4.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()))) } else { tmp3 = nil }
//line :280:1
	var tmp5 any = tmp3; var tmp6 any
	var G__1901000232__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1901000232__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_66) { tmp6 = A_arbace_build_go_A_const_107; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_5) { tmp6 = A_arbace_build_go_A_const_108; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1901000232__4_)))))}
//line :280:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :274:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	var root_1269 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, A_arbace_build_go_go_env_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = goroot__0; var arg_1273 any = arch__1; var arg_1274 any = Lit_39; if linked_1270 == nil { return ifn_1271.Invoke_O_O_O__O(arg_1272, arg_1273, arg_1274) } else { return linked_1270.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_1269, arg_1272, arg_1273, arg_1274)
	}
}
























func A_arbace_build_go_go_mod_cache_A_New() *A_arbace_build_go_go_mod_cache_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_mod_cache_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_build_go_go_mod_cache_A) Ctor() {}
//line :305:1
func (t *A_arbace_build_go_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000234__2 any; var root_1275 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1275, A_arbace_build_go_run_A_fn_class); var ifn_1277 lang.IFn; if
											linked_1276 == nil { ifn_1277 = lang.IFn_Cast(root_1275) } else { ifn_1277 = nil }; var arg_1278 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_68, Lit_69); var arg_1279 any = jrt.File_New_String(Lit_70); var arg_1280 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_71, goroot__0, Lit_72, Lit_73)); var arg_1281 any = jrt.Boolean_FALSE.Ref(); if linked_1276 == nil { vec__1901000234__2 = ifn_1277.Invoke_O_O_O_O__O(arg_1278, arg_1279, arg_1280, arg_1281) } else { vec__1901000234__2 = linked_1276.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1275, arg_1278, arg_1279, arg_1280, arg_1281) }; var status__3 any = /*line :305:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_1290 any = status__3; if


	jrt.Long_InstanceOf(na_1290) { var n0_1291 int64 = jrt.NN(jrt.Long_Cast(na_1290)).LongValue__J(); tmp1 = n0_1291 == 0 } else { if jrt.Double_InstanceOf(na_1290) { var n0_1291_2 float64 = jrt.NN(jrt.Double_Cast(na_1290)).DoubleValue__D(); tmp1 = n0_1291_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_1290) } }; if tmp1 { } else { lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; var root_1282 any =
	A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1283 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1282, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1284 lang.IFn; if linked_1283 == nil { ifn_1284 = lang.IFn_Cast(root_1282) } else { ifn_1284 = nil }; var arg_1285 any; var root_1286 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1287 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1286, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1288 lang.IFn; if linked_1287 == nil { ifn_1288 = lang.IFn_Cast(root_1286) } else { ifn_1288 = nil }; var arg_1289 any = out__4; if linked_1287 == nil { arg_1285 = ifn_1288.Invoke_O__O(arg_1289) } else { arg_1285 = linked_1287.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1286, arg_1289) }; if linked_1283 == nil { return ifn_1284.Invoke_O__O(arg_1285) } else { return linked_1283.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1282, arg_1285) } }

func A_arbace_build_go_h1_of_file_A_New() *A_arbace_build_go_h1_of_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var fnbody__1319 any = A_arbace_build_go_h1_of_file_hex__1901000239_A_New(); var tmp1 *jrt.Class; var fncls__1318 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class; if


	fncls__1318 == nil { var fncls__1318d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_75, false, nil); A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class = fncls__1318d; tmp1 = fncls__1318d } else { tmp1 = fncls__1318 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1319, tmp1, nil); var sha__4 any; var fnbody__1321 any = /*line :311:1*/A_arbace_build_go_h1_of_file_sha__1901000243_A_New(); var tmp2 *jrt.Class; var fncls__1320 *jrt.Class = A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class; if



	fncls__1320 == nil { var fncls__1320d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_76, false, nil); A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class = fncls__1320d; tmp2 = fncls__1320d } else { tmp2 = fncls__1320 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1321, tmp2, nil); var summary__5 any = /*line :311:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_77, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :317:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_78, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.ByteArray_Cast(lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_53).Ref()))).Ref())).Ref() }
//line :314:1
func A_arbace_build_go_h1_of_file_hex__1901000239_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Ctor() {}
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Invoke_O_O__O(self, b__1 any) any { var root_1296 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_1297 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1296, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1298 lang.IFn; if linked_1297 == nil { ifn_1298 = lang.IFn_Cast(root_1296) } else { ifn_1298 = nil }; var arg_1299 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1300 any; var root_1301 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1301, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1303 lang.IFn; if linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any; var fnbody__1317 any = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New(); var tmp1 *jrt.Class; var fncls__1316 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class; if fncls__1316 == nil { var fncls__1316d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_79, false, nil); A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class = fncls__1316d; tmp1 = fncls__1316d } else { tmp1 = fncls__1316 }; arg_1304 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1317, tmp1, nil); var arg_1305 any = b__1; if linked_1302 == nil { arg_1300 = ifn_1303.Invoke_O_O__O(arg_1304, arg_1305) } else { arg_1300 = linked_1302.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1301, arg_1304, arg_1305) }; if linked_1297 == nil { return ifn_1298.Invoke_O_O__O(arg_1299, arg_1300) } else { return linked_1297.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1296, arg_1299, arg_1300) } }
//line :314:1
func A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Ctor() {}
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Invoke_O_O__O(self, p1__1901000238_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_1311 any = p1__1901000238_SHARP___1; var na_1312 int64 = 255; if jrt.Long_InstanceOf(na_1311) { var n0_1313 int64 = jrt.NN(jrt.Long_Cast(na_1311)).LongValue__J(); var n1_1314 int64 = na_1312; tmp2 = n0_1313 & n1_1314 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1311, na_1312) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }
func A_arbace_build_go_h1_of_file_sha__1901000243_A_New() *A_arbace_build_go_h1_of_file_sha__1901000243_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_sha__1901000243_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Ctor() {}
//line :315:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52).Digest_B1__B1(jrt.ByteArray_Cast(b__1)).Ref() }



func A_arbace_build_go_tamago_go_sum_A_New() *A_arbace_build_go_tamago_go_sum_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_tamago_go_sum_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_build_go_tamago_go_sum_A) Ctor() {}
//line :319:1
func (t *A_arbace_build_go_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__1901000246__2 any = A_arbace_build_go_A_const_106.GetRawRoot__O(); var map__1901000246__3 any; if



	lang.ISeq_InstanceOf(map__1901000246__2) { var tmp1 any; var root_1322 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1323 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1322, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1324 lang.IFn; if linked_1323 == nil { ifn_1324 = lang.IFn_Cast(root_1322) } else { ifn_1324 = nil }; var arg_1325 any = map__1901000246__2; if linked_1323 == nil { tmp1 = ifn_1324.Invoke_O__O(arg_1325) } else { tmp1 = linked_1323.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1322, arg_1325) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1326 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1327 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1326, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1328 lang.IFn; if linked_1327 == nil { ifn_1328 = lang.IFn_Cast(root_1326) } else { ifn_1328 = nil }; var arg_1329 any = map__1901000246__2; if linked_1327 == nil { tmp2 = ifn_1328.Invoke_O__O(arg_1329) } else { tmp2 = linked_1327.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1326, arg_1329) }; map__1901000246__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1330 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1331 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1330, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1332 lang.IFn; if linked_1331 == nil { ifn_1332 = lang.IFn_Cast(root_1330) } else { ifn_1332 = nil }; var arg_1333 any = map__1901000246__2; if linked_1331 == nil { tmp3 = ifn_1332.Invoke_O__O(arg_1333) } else { tmp3 = linked_1331.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1330, arg_1333) }; if jrt.J2g_Truth(tmp3) { var root_1334 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1335 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1334, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1336 lang.IFn; if linked_1335 == nil { ifn_1336 = lang.IFn_Cast(root_1334) } else { ifn_1336 = nil }; var arg_1337 any = map__1901000246__2; if linked_1335 == nil { map__1901000246__3 = ifn_1336.Invoke_O__O(arg_1337) } else { map__1901000246__3 = linked_1335.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1334, arg_1337) } } else { map__1901000246__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000246__3 = map__1901000246__2 }; var path__4 any = /*line :319:1*/lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_48); var version__5 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_113); var zip__6 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_114); var mod__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_115); var dir__8 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_179, nil, Lit_180); var tmp5 any; var root_1338 any = A_arbace_build_go_A_const_116.GetRawRoot__O(); var linked_1339 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1338, A_arbace_build_go_go_mod_cache_A_fn_class); var ifn_1340 lang.IFn; if




	linked_1339 == nil { ifn_1340 = lang.IFn_Cast(root_1338) } else { ifn_1340 = nil }; var arg_1341 any = goroot__0; if linked_1339 == nil { tmp5 = ifn_1340.Invoke_O__O(arg_1341) } else { tmp5 = linked_1339.(*A_arbace_build_go_go_mod_cache_A).Invoke_O_O__O(root_1338, arg_1341) }; dir__8 = /*line :319:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_181), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_182), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp6 bool; var and__1927000168__auto____11 bool = jrt.File_Cast(zf__9).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.File_Cast(mf__10).IsFile__Z(); if and__1927000168__auto____12 { tmp6 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_183), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp6 = and__1927000168__auto____12 } } else { tmp6 = and__1927000168__auto____11 }; if tmp6 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_184, nil, Lit_185, nil, Lit_186), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.File_Cast(dir__8).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any; var root_1346 any = /*line :319:1*/A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1348 lang.IFn; if









	linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any = lang.IFn_Cast(A_arbace_build_go_A_const_105.GetRawRoot__O()).Invoke_O__O(zf__9); if linked_1347 == nil { zh__12 = ifn_1348.Invoke_O__O(arg_1349) } else { zh__12 = linked_1347.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1346, arg_1349) }; var mh__13 any; var root_1354 any = /*line :319:1*/A_arbace_build_go_A_const_117.GetRawRoot__O(); var linked_1355 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1354, A_arbace_build_go_h1_of_file_A_fn_class); var ifn_1356 lang.IFn; if










	linked_1355 == nil { ifn_1356 = lang.IFn_Cast(root_1354) } else { ifn_1356 = nil }; var arg_1357 any = jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(mf__10).ToPath__Path()).Ref(); var arg_1358 any = Lit_104; if linked_1355 == nil { mh__13 = ifn_1356.Invoke_O_O__O(arg_1357, arg_1358) } else { mh__13 = linked_1355.(*A_arbace_build_go_h1_of_file_A).Invoke_O_O_O__O(root_1354, arg_1357, arg_1358) }; var tmp7 bool; var and__1927000168__auto____14 bool =
	lang.Util_Equiv_O_O__Z_NoInit(zh__12, zip__6); if and__1927000168__auto____14 { tmp7 = lang.Util_Equiv_O_O__Z_NoInit(mh__13, mod__7) } else { tmp7 = and__1927000168__auto____14 }; if tmp7 { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :333:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_build_go_toolchain_lang_A_New() *A_arbace_build_go_toolchain_lang_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_toolchain_lang_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_build_go_toolchain_lang_A) Ctor() {}
//line :335:1
func (t *A_arbace_build_go_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000249__2 any; var root_1363 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1363, A_arbace_build_go_run_A_fn_class); var ifn_1365 lang.IFn; if


	linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_68, Lit_187); var arg_1367 any = jrt.File_New_String(Lit_70); var arg_1368 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_71, goroot__0, Lit_72, Lit_73)); var arg_1369 any = jrt.Boolean_FALSE.Ref(); if linked_1364 == nil { vec__1901000249__2 = ifn_1365.Invoke_O_O_O_O__O(arg_1366, arg_1367, arg_1368, arg_1369) } else { vec__1901000249__2 = linked_1364.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1363, arg_1366, arg_1367, arg_1368, arg_1369) }; var status__3 any = /*line :335:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any; var root_1370 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1372 lang.IFn; if




	linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any; var root_1374 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = out__4; if linked_1375 == nil { arg_1373 = ifn_1376.Invoke_O__O(arg_1377) } else { arg_1373 = linked_1375.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1374, arg_1377) }; if linked_1371 == nil { v__5 = ifn_1372.Invoke_O__O(arg_1373) } else { v__5 = linked_1371.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1370, arg_1373) }; var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool; var na_1378 any = status__3; if
	jrt.Long_InstanceOf(na_1378) { var n0_1379 int64 = jrt.NN(jrt.Long_Cast(na_1378)).LongValue__J(); and__1927000168__auto____6 = n0_1379 == 0 } else { if jrt.Double_InstanceOf(na_1378) { var n0_1379_2 float64 = jrt.NN(jrt.Double_Cast(na_1378)).DoubleValue__D(); and__1927000168__auto____6 = n0_1379_2 == 0.0 } else { and__1927000168__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_1378) } }; if and__1927000168__auto____6 { var root_1380 any = A_arbace_build_go_A_const_118.GetRawRoot__O(); var linked_1381 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1380, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1382 lang.IFn; if linked_1381 == nil { ifn_1382 = lang.IFn_Cast(root_1380) } else { ifn_1382 = nil }; var arg_1383 any = A_arbace_build_go_A_const_119; var arg_1384 any = v__5; if linked_1381 == nil { temp__1927000408__auto____6 = ifn_1382.Invoke_O_O__O(arg_1383, arg_1384) } else { temp__1927000408__auto____6 = linked_1381.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1380, arg_1383, arg_1384) } } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__1901000252__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___8; return l__9 } else {

		return lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_188, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_build_go_program_A_New() *A_arbace_build_go_program_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_build_go_program_A) Ctor() {}
//line :345:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__1901000259__2 any) any { var map__1901000260__4 any = p__1901000259__2; var map__1901000260__5 any; if lang.ISeq_InstanceOf(map__1901000260__4) { var tmp1 any; var root_1389 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1390 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1389, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1391 lang.IFn; if linked_1390 == nil { ifn_1391 = lang.IFn_Cast(root_1389) } else { ifn_1391 = nil }; var arg_1392 any = map__1901000260__4; if linked_1390 == nil { tmp1 = ifn_1391.Invoke_O__O(arg_1392) } else { tmp1 = linked_1390.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1389, arg_1392) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1393 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1394 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1393, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1395 lang.IFn; if linked_1394 == nil { ifn_1395 = lang.IFn_Cast(root_1393) } else { ifn_1395 = nil }; var arg_1396 any = map__1901000260__4; if linked_1394 == nil { tmp2 = ifn_1395.Invoke_O__O(arg_1396) } else { tmp2 = linked_1394.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1393, arg_1396) }; map__1901000260__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1397 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1398 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1397, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1399 lang.IFn; if linked_1398 == nil { ifn_1399 = lang.IFn_Cast(root_1397) } else { ifn_1399 = nil }; var arg_1400 any = map__1901000260__4; if linked_1398 == nil { tmp3 = ifn_1399.Invoke_O__O(arg_1400) } else { tmp3 = linked_1398.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1397, arg_1400) }; if jrt.J2g_Truth(tmp3) { var root_1401 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1401, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1403 lang.IFn; if linked_1402 == nil { ifn_1403 = lang.IFn_Cast(root_1401) } else { ifn_1403 = nil }; var arg_1404 any = map__1901000260__4; if linked_1402 == nil { map__1901000260__5 = ifn_1403.Invoke_O__O(arg_1404) } else { map__1901000260__5 = linked_1402.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1401, arg_1404) } } else { map__1901000260__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000260__5 = map__1901000260__4 }; var opts__6 any = map__1901000260__5; var library_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_120); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_121); var pkgs__9 any; var root_1405 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_1406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1405, A_arbace_build_go_packages_A_fn_class); var ifn_1407 lang.IFn; if









	linked_1406 == nil { ifn_1407 = lang.IFn_Cast(root_1405) } else { ifn_1407 = nil }; var arg_1408 any = dir__0; var arg_1409 any = roots__8; var arg_1410 any = A_arbace_build_go_A_const_122.Invoke_O__O(opts__6); if linked_1406 == nil { pkgs__9 = ifn_1407.Invoke_O_O_O__O(arg_1408, arg_1409, arg_1410) } else { pkgs__9 = linked_1406.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_1405, arg_1408, arg_1409, arg_1410) }; var mains__10 any; var G__1901000262__10_ any; var root_1411 any = /*line :345:1*/A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1412 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1411, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1413 lang.IFn; if










	linked_1412 == nil { ifn_1413 = lang.IFn_Cast(root_1411) } else { ifn_1413 = nil }; var arg_1414 any; var fnbody__1421 any = A_arbace_build_go_program_fn__1901000263_A_New(); var tmp4 *jrt.Class; var fncls__1420 *jrt.Class = A_arbace_build_go_program_fn__1901000263_A_fn_class; if fncls__1420 == nil { var fncls__1420d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_128, false, nil); A_arbace_build_go_program_fn__1901000263_A_fn_class = fncls__1420d; tmp4 = fncls__1420d } else { tmp4 = fncls__1420 }; arg_1414 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1421, tmp4, nil); var arg_1415 any = pkgs__9; if linked_1412 == nil { G__1901000262__10_ = ifn_1413.Invoke_O_O__O(arg_1414, arg_1415) } else { G__1901000262__10_ = linked_1412.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1411, arg_1414, arg_1415) }; if jrt.J2g_Truth(A_arbace_build_go_A_const_123.Invoke_O__O(opts__6)) {
		var root_1422 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1423 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1422, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1424 lang.IFn; if linked_1423 == nil { ifn_1424 = lang.IFn_Cast(root_1422) } else { ifn_1424 = nil }; var arg_1425 any; var fnbody__1428 any = A_arbace_build_go_program_fn__1901000265_A_New_O(opts__6); var tmp5 *jrt.Class; var fncls__1427 *jrt.Class = A_arbace_build_go_program_fn__1901000265_A_fn_class; if fncls__1427 == nil { var fncls__1427d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_129, false, fnbody__1428); A_arbace_build_go_program_fn__1901000265_A_fn_class = fncls__1427d; tmp5 = fncls__1427d } else { tmp5 = fncls__1427 }; arg_1425 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1428, tmp5, nil); var arg_1426 any = G__1901000262__10_; if linked_1423 == nil { mains__10 = ifn_1424.Invoke_O_O__O(arg_1425, arg_1426) } else { mains__10 = linked_1423.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1422, arg_1425, arg_1426) } } else {
//line :356:1
			mains__10 = G__1901000262__10_ }; var ___11 any; var tmp6 any; var or__1927000174__auto____11 bool = /*line :345:1*/lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(mains__10))); _ = ___11; if or__1927000174__auto____11 {












				tmp6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 any; var root_1429 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1429, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1431 lang.IFn; if linked_1430 == nil { ifn_1431 = lang.IFn_Cast(root_1429) } else { ifn_1431 = nil }; var arg_1432 any = mains__10; if linked_1430 == nil { or__1927000174__auto____13 = ifn_1431.Invoke_O__O(arg_1432) } else { or__1927000174__auto____13 = linked_1430.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1429, arg_1432) }; if jrt.J2g_Truth(or__1927000174__auto____13) { tmp6 = or__1927000174__auto____13 } else { tmp6 = A_arbace_build_go_A_const_124.Invoke_O__O(opts__6) } } else { tmp6 = and__1927000168__auto____12 } }; if jrt.J2g_Truth(tmp6) { ___11 = nil } else {
					var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp8 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_130, nil, nil); var tmp9 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(mains__10)).Ref(); var tmp10 *jrt.String; var tmp11 any; var root_1437 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1439 lang.IFn
					if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = mains__10; if linked_1438 == nil { tmp11 = ifn_1439.Invoke_O__O(arg_1440) } else { tmp11 = linked_1438.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1437, arg_1440) }; if jrt.J2g_Truth(tmp11) { var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_87, nil); var tmp13 any; var root_1441 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1441, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1443 lang.IFn; if linked_1442 == nil { ifn_1443 = lang.IFn_Cast(root_1441) } else { ifn_1443 = nil }; var arg_1444 any = Lit_88; var arg_1445 any; var root_1446 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1446, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1448 lang.IFn; if linked_1447 == nil { ifn_1448 = lang.IFn_Cast(root_1446) } else { ifn_1448 = nil }; var arg_1449 any = A_arbace_build_go_A_const_48; var arg_1450 any = mains__10; if linked_1447 == nil { arg_1445 = ifn_1448.Invoke_O_O__O(arg_1449, arg_1450) } else { arg_1445 = linked_1447.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1446, arg_1449, arg_1450) }; if linked_1442 == nil { tmp13 = ifn_1443.Invoke_O_O__O(arg_1444, arg_1445) } else { tmp13 = linked_1442.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1441, arg_1444, arg_1445) }; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, tmp13)) } else { tmp10 = nil }
//line :359:1
					___11 = tmp7.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp8, jrt.RefArrayOf(jrt.Object_class, nil, tmp9, tmp10.Ref())).Ref()) }; var main__12 any; var root_1451 any = /*line :345:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1451, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1453 lang.IFn; if















	linked_1452 == nil { ifn_1453 = lang.IFn_Cast(root_1451) } else { ifn_1453 = nil }; var arg_1454 any = mains__10; if linked_1452 == nil { main__12 = ifn_1453.Invoke_O__O(arg_1454) } else { main__12 = linked_1452.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1451, arg_1454) }; var edn__13 any; var root_1455 any = /*line :345:1*/A_arbace_build_go_A_const_125.GetRawRoot__O(); var linked_1456 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1455, A_arbace_build_go_read_program_edn_A_fn_class); var ifn_1457 lang.IFn; if
















	linked_1456 == nil { ifn_1457 = lang.IFn_Cast(root_1455) } else { ifn_1457 = nil }; var arg_1458 any = dir__0; if linked_1456 == nil { edn__13 = ifn_1457.Invoke_O__O(arg_1458) } else { edn__13 = linked_1456.(*A_arbace_build_go_read_program_edn_A).Invoke_O_O__O(root_1455, arg_1458) }; var module__14 any; var or__1927000174__auto____14 any = /*line :345:1*/A_arbace_build_go_A_const_124.Invoke_O__O(edn__13); if

















	jrt.J2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_build_go_A_const_124.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_build_go_A_const_48.Invoke_O__O(main__12); if jrt.J2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(Lit_131) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :345:1*/A_arbace_build_go_A_const_126.Invoke_O__O(edn__13); if





















	jrt.J2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_build_go_A_const_126.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z_NoInit(module__14, Lit_103) { golang__15 = nil } else { var root_1463 any = A_arbace_build_go_A_const_127.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, A_arbace_build_go_toolchain_lang_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = goroot__1; if linked_1464 == nil { golang__15 = ifn_1465.Invoke_O__O(arg_1466) } else { golang__15 = linked_1464.(*A_arbace_build_go_toolchain_lang_A).Invoke_O_O__O(root_1463, arg_1466) } } } }; var pkgs__16 any; var root_1467 any = /*line :345:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1469 lang.IFn; if






















	linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any; var iter__1927001039__auto____16 any; var fnbody__1640 any = A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(module__14); var tmp14 *jrt.Class; var fncls__1639 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class; if fncls__1639 == nil { var fncls__1639d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_132, false, fnbody__1640); A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class = fncls__1639d; tmp14 = fncls__1639d } else { tmp14 = fncls__1639 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1640, tmp14, nil); arg_1470 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); if linked_1468 == nil { pkgs__16 = ifn_1469.Invoke_O__O(arg_1470) } else { pkgs__16 = linked_1468.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1467, arg_1470) }; var tmp15 any = A_arbace_build_go_A_const_124; var tmp16 any = A_arbace_build_go_A_const_126; var tmp17 any; var root_1641 any = /*line :345:1*/A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1642 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1641, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1643 lang.IFn; if






































	linked_1642 == nil { ifn_1643 = lang.IFn_Cast(root_1641) } else { ifn_1643 = nil }; var arg_1644 any = golang__15; if linked_1642 == nil { tmp17 = ifn_1643.Invoke_O__O(arg_1644) } else { tmp17 = linked_1642.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1641, arg_1644) }; var tmp18 any = tmp17; var tmp19 any = A_arbace_build_go_A_const_79; var tmp20 any = A_arbace_build_go_A_const_133; var tmp21 any; var root_1645 any = /*line :345:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1647 lang.IFn; if







































	linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any; var root_1649 any = A_arbace_build_go_A_const_134.GetRawRoot__O(); var linked_1650 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1649, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1651 lang.IFn; if linked_1650 == nil { ifn_1651 = lang.IFn_Cast(root_1649) } else { ifn_1651 = nil }; var arg_1652 any; var root_1653 any = A_arbace_build_go_A_const_135.GetRawRoot__O(); var linked_1654 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1653, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1655 lang.IFn; if linked_1654 == nil { ifn_1655 = lang.IFn_Cast(root_1653) } else { ifn_1655 = nil }; var arg_1656 any; var root_1657 any = A_arbace_build_go_A_const_136.GetRawRoot__O(); var linked_1658 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1657, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1659 lang.IFn; if linked_1658 == nil { ifn_1659 = lang.IFn_Cast(root_1657) } else { ifn_1659 = nil }; var arg_1660 any = A_arbace_build_go_A_const_124; var arg_1661 any = pkgs__16; if linked_1658 == nil { arg_1656 = ifn_1659.Invoke_O_O__O(arg_1660, arg_1661) } else { arg_1656 = linked_1658.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1657, arg_1660, arg_1661) }; if linked_1654 == nil { arg_1652 = ifn_1655.Invoke_O__O(arg_1656) } else { arg_1652 = linked_1654.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1653, arg_1656) }; if linked_1650 == nil { arg_1648 = ifn_1651.Invoke_O__O(arg_1652) } else { arg_1648 = linked_1650.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1649, arg_1652) }; if linked_1646 == nil { tmp21 = ifn_1647.Invoke_O__O(arg_1648) } else { tmp21 = linked_1646.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1645, arg_1648) }; var tmp22 any = tmp21; var tmp23 any = A_arbace_build_go_A_const_137; var tmp24 any; var root_1662 any = /*line :345:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1664 lang.IFn; if








































	linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any; var root_1666 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1668 lang.IFn; if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any; var fnbody__1676 any = A_arbace_build_go_program_fn__1901000277_A_New(); var tmp25 *jrt.Class; var fncls__1675 *jrt.Class = A_arbace_build_go_program_fn__1901000277_A_fn_class; if fncls__1675 == nil { var fncls__1675d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_133, false, nil); A_arbace_build_go_program_fn__1901000277_A_fn_class = fncls__1675d; tmp25 = fncls__1675d } else { tmp25 = fncls__1675 }; arg_1669 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1676, tmp25, nil); var arg_1670 any = pkgs__16; if linked_1667 == nil { arg_1665 = ifn_1668.Invoke_O_O__O(arg_1669, arg_1670) } else { arg_1665 = linked_1667.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1666, arg_1669, arg_1670) }; if linked_1663 == nil { tmp24 = ifn_1664.Invoke_O__O(arg_1665) } else { tmp24 = linked_1663.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1662, arg_1665) }; return /*line :345:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp15, module__14, tmp16, tmp18, tmp19, pkgs__16, tmp20, tmp22, tmp23, tmp24)) }
//line :345:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {







	var root_1677 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, A_arbace_build_go_program_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = dir__0; var arg_1681 any = goroot__1; var arg_1682 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1678 == nil { return ifn_1679.Invoke_O_O_O__O(arg_1680, arg_1681, arg_1682) } else { return linked_1678.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_1677, arg_1680, arg_1681, arg_1682)
	}
}
func A_arbace_build_go_program_fn__1901000263_A_New() *A_arbace_build_go_program_fn__1901000263_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000263_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Ctor() {}
//line :356:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Invoke_O_O__O(self, p1__1901000256_SHARP___1 any) any { var tmp1 any; var root_1416 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000256_SHARP___1); if linked_1417 == nil { tmp1 = ifn_1418.Invoke_O__O(arg_1419) } else { tmp1 = linked_1417.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1416, arg_1419) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_95, tmp1)).Ref() }
func A_arbace_build_go_program_fn__1901000265_A_New_O(p0 any) *A_arbace_build_go_program_fn__1901000265_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000265_A{}; t.Ctor_O(p0); return t }
//line :357:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :357:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Invoke_O_O__O(self, p1__1901000257_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_123.Invoke_O__O(t.F_opts), A_arbace_build_go_A_const_48.Invoke_O__O(p1__1901000257_SHARP___1))).Ref() }










func A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(p0 any) *A_arbace_build_go_program_iter__1901000267__1901000271_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Invoke_O_O__O(self, s__1901000268__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1638 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(self, t.F_module, s__1901000268__1); var tmp2 *jrt.Class; var fncls__1637 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class; if fncls__1637 == nil { var fncls__1637d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_134, false, fnbody__1638); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class = fncls__1637d; tmp2 = fncls__1637d } else { tmp2 = fncls__1637 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1638, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :368:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Ctor_O_O_O(c__iter__1901000267, c__module, c__s__1901000268 any) { t.F_iter__1901000267 = c__iter__1901000267; t.F_module = c__module; t.F_s__1901000268 = c__s__1901000268 }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Invoke_O__O(self any) any { { var s__1901000268__1 any; var t_ any = t.F_s__1901000268; t.F_s__1901000268 = nil; s__1901000268__1 = t_; for { var temp__1927000414__auto____2 any; var root_1471 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any = s__1901000268__1; if linked_1472 == nil { temp__1927000414__auto____2 = ifn_1473.Invoke_O__O(arg_1474) } else { temp__1927000414__auto____2 = linked_1472.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1471, arg_1474) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000268__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1475 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1476 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1475, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1477 lang.IFn; if linked_1476 == nil { ifn_1477 = lang.IFn_Cast(root_1475) } else { ifn_1477 = nil }; var arg_1478 any = s__1901000268__3; if linked_1476 == nil { tmp1 = ifn_1477.Invoke_O__O(arg_1478) } else { tmp1 = linked_1476.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1475, arg_1478) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1479 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1480 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1479, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1481 lang.IFn; if linked_1480 == nil { ifn_1481 = lang.IFn_Cast(root_1479) } else { ifn_1481 = nil }; var arg_1482 any = s__1901000268__3; if linked_1480 == nil { c__1927001037__auto____4 = ifn_1481.Invoke_O__O(arg_1482) } else { c__1927001037__auto____4 = linked_1480.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1479, arg_1482) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000270__6 any; var root_1483 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1484 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1483, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1485 lang.IFn; if linked_1484 == nil { ifn_1485 = lang.IFn_Cast(root_1483) } else { ifn_1485 = nil }; var arg_1486 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1484 == nil { b__1901000270__6 = ifn_1485.Invoke_O__O(arg_1486) } else { b__1901000270__6 = linked_1484.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1483, arg_1486) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1547 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(b__1901000270__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1546 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class; if fncls__1546 == nil { var fncls__1546d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_135, false, fnbody__1547); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class = fncls__1546d; tmp3 = fncls__1546d } else { tmp3 = fncls__1546 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1547, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1548 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1548, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1550 lang.IFn; if linked_1549 == nil { ifn_1550 = lang.IFn_Cast(root_1548) } else { ifn_1550 = nil }; var arg_1551 any; var root_1553 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1554 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1553, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1555 lang.IFn; if linked_1554 == nil { ifn_1555 = lang.IFn_Cast(root_1553) } else { ifn_1555 = nil }; var arg_1556 any = b__1901000270__6; if linked_1554 == nil { arg_1551 = ifn_1555.Invoke_O__O(arg_1556) } else { arg_1551 = linked_1554.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1553, arg_1556) }; var arg_1552 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp5 any; var root_1557 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1558 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1557, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1559 lang.IFn; if linked_1558 == nil { ifn_1559 = lang.IFn_Cast(root_1557) } else { ifn_1559 = nil }; var arg_1560 any = s__1901000268__3; if linked_1558 == nil { tmp5 = ifn_1559.Invoke_O__O(arg_1560) } else { tmp5 = linked_1558.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1557, arg_1560) }; arg_1552 = tmp4.Invoke_O__O(tmp5); if linked_1549 == nil { return ifn_1550.Invoke_O_O__O(arg_1551, arg_1552) } else { return linked_1549.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1548, arg_1551, arg_1552) } } else { var root_1561 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1562 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1561, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1563 lang.IFn; if linked_1562 == nil { ifn_1563 = lang.IFn_Cast(root_1561) } else { ifn_1563 = nil }; var arg_1564 any; var root_1566 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1566, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1568 lang.IFn; if linked_1567 == nil { ifn_1568 = lang.IFn_Cast(root_1566) } else { ifn_1568 = nil }; var arg_1569 any = b__1901000270__6; if linked_1567 == nil { arg_1564 = ifn_1568.Invoke_O__O(arg_1569) } else { arg_1564 = linked_1567.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1566, arg_1569) }; var arg_1565 any; if linked_1562 == nil { return ifn_1563.Invoke_O_O__O(arg_1564, arg_1565) } else { return linked_1562.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1561, arg_1564, arg_1565) } } } else { var pkg__4 any; var root_1570 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1570, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1572 lang.IFn; if linked_1571 == nil { ifn_1572 = lang.IFn_Cast(root_1570) } else { ifn_1572 = nil }; var arg_1573 any = s__1901000268__3; if linked_1571 == nil { pkg__4 = ifn_1572.Invoke_O__O(arg_1573) } else { pkg__4 = linked_1571.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1570, arg_1573) }; var root_1574 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1575 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1574, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1576 lang.IFn; if linked_1575 == nil { ifn_1576 = lang.IFn_Cast(root_1574) } else { ifn_1576 = nil }; var arg_1577 any; var path__5 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_103) {


		var root_1579 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1580 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1579, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1581 lang.IFn; if linked_1580 == nil { ifn_1581 = lang.IFn_Cast(root_1579) } else { ifn_1581 = nil }; var arg_1582 any = pkg__4; var arg_1583 any = A_arbace_build_go_A_const_128; var arg_1584 any = path__5; if linked_1580 == nil { arg_1577 = ifn_1581.Invoke_O_O_O__O(arg_1582, arg_1583, arg_1584) } else { arg_1577 = linked_1580.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1579, arg_1582, arg_1583, arg_1584) } } else {
//line :370:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__5, t.F_module) {



				var root_1585 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1586 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1585, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1587 lang.IFn; if linked_1586 == nil { ifn_1587 = lang.IFn_Cast(root_1585) } else { ifn_1587 = nil }; var arg_1588 any = pkg__4; var arg_1589 any = A_arbace_build_go_A_const_128; var arg_1590 any = Lit_97; if linked_1586 == nil { arg_1577 = ifn_1587.Invoke_O_O_O__O(arg_1588, arg_1589, arg_1590) } else { arg_1577 = linked_1586.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1585, arg_1588, arg_1589, arg_1590) } } else {
//line :370:1
					var tmp6 any; var root_1591 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1593 lang.IFn




					if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any = path__5; var arg_1595 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_123), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1592 == nil { tmp6 = ifn_1593.Invoke_O_O__O(arg_1594, arg_1595) } else { tmp6 = linked_1592.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1591, arg_1594, arg_1595) }
//line :370:1
					if jrt.J2g_Truth(tmp6) {





						var root_1596 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1597 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1596, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1598 lang.IFn; if linked_1597 == nil { ifn_1598 = lang.IFn_Cast(root_1596) } else { ifn_1598 = nil }; var arg_1599 any = pkg__4; var arg_1600 any = A_arbace_build_go_A_const_128; var arg_1601 any; var root_1602 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_1603 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1602, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1604 lang.IFn; if linked_1603 == nil { ifn_1604 = lang.IFn_Cast(root_1602) } else { ifn_1604 = nil }; var arg_1605 any = path__5; var arg_1606 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1603 == nil { arg_1601 = ifn_1604.Invoke_O_O__O(arg_1605, arg_1606) } else { arg_1601 = linked_1603.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1602, arg_1605, arg_1606) }; if linked_1597 == nil { arg_1577 = ifn_1598.Invoke_O_O_O__O(arg_1599, arg_1600, arg_1601) } else { arg_1577 = linked_1597.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1596, arg_1599, arg_1600, arg_1601) } } else {
//line :370:1
							var tmp7 any; var and__1927000168__auto____6 any = A_arbace_build_go_A_const_39.Invoke_O__O(pkg__4)










							if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1607 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_1608 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1607, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1609 lang.IFn; if linked_1608 == nil { ifn_1609 = lang.IFn_Cast(root_1607) } else { ifn_1609 = nil }; var arg_1610 any = t.F_module; var arg_1611 any = Lit_103; if linked_1608 == nil { tmp7 = ifn_1609.Invoke_O_O__O(arg_1610, arg_1611) } else { tmp7 = linked_1608.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1607, arg_1610, arg_1611) } } else { tmp7 = and__1927000168__auto____6 }
//line :370:1
							if jrt.J2g_Truth(tmp7) {











								var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp9 any = A_arbace_build_go_A_const_128; var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5)).Ref(); var tmp11 any = A_arbace_build_go_A_const_124; var tmp12 any; var root_1620 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1621 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1620, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1622 lang.IFn; if linked_1621 == nil { ifn_1622 = lang.IFn_Cast(root_1620) } else { ifn_1622 = nil }; var arg_1623 any; var root_1624 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1624, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1626 lang.IFn; if linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = path__5; var arg_1628 any = A_arbace_build_go_A_const_132; if linked_1625 == nil { arg_1623 = ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { arg_1623 = linked_1625.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) }; if linked_1621 == nil { tmp12 = ifn_1622.Invoke_O__O(arg_1623) } else { tmp12 = linked_1621.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1620, arg_1623) }; arg_1577 = tmp8.Invoke_O_O_O_O_O__O(pkg__4, tmp9, tmp10, tmp11, tmp12) } else {
//line :370:1
									if A_arbace_build_go_A_const_13 != nil {












										arg_1577 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :370:1
											arg_1577 = nil } } } } }
//line :368:1
	var arg_1578 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp14 any; var root_1633 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1633, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1635 lang.IFn; if linked_1634 == nil { ifn_1635 = lang.IFn_Cast(root_1633) } else { ifn_1635 = nil }; var arg_1636 any = s__1901000268__3; if linked_1634 == nil { tmp14 = ifn_1635.Invoke_O__O(arg_1636) } else { tmp14 = linked_1634.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1633, arg_1636) }; arg_1578 = tmp13.Invoke_O__O(tmp14); if linked_1575 == nil { return ifn_1576.Invoke_O_O__O(arg_1577, arg_1578) } else { return linked_1575.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1574, arg_1577, arg_1578) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :368:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Ctor_O_I_O_O(c__b__1901000270 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__1901000270 = c__b__1901000270; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Invoke_O__O(self any) any { { var i__1901000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000269__1)); var root_1487 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1488 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1487, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1489 lang.IFn; if linked_1488 == nil { ifn_1489 = lang.IFn_Cast(root_1487) } else { ifn_1489 = nil }; var arg_1490 any = t.F_b__1901000270; var arg_1491 any; var path__3 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_103) {


		var root_1492 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any = pkg__2; var arg_1496 any = A_arbace_build_go_A_const_128; var arg_1497 any = path__3; if linked_1493 == nil { arg_1491 = ifn_1494.Invoke_O_O_O__O(arg_1495, arg_1496, arg_1497) } else { arg_1491 = linked_1493.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1492, arg_1495, arg_1496, arg_1497) } } else {
//line :370:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__3, t.F_module) {



				var root_1498 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1499 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1498, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1500 lang.IFn; if linked_1499 == nil { ifn_1500 = lang.IFn_Cast(root_1498) } else { ifn_1500 = nil }; var arg_1501 any = pkg__2; var arg_1502 any = A_arbace_build_go_A_const_128; var arg_1503 any = Lit_97; if linked_1499 == nil { arg_1491 = ifn_1500.Invoke_O_O_O__O(arg_1501, arg_1502, arg_1503) } else { arg_1491 = linked_1499.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1498, arg_1501, arg_1502, arg_1503) } } else {
//line :370:1
					var tmp2 any; var root_1504 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1504, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1506 lang.IFn




					if linked_1505 == nil { ifn_1506 = lang.IFn_Cast(root_1504) } else { ifn_1506 = nil }; var arg_1507 any = path__3; var arg_1508 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_123), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1505 == nil { tmp2 = ifn_1506.Invoke_O_O__O(arg_1507, arg_1508) } else { tmp2 = linked_1505.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1504, arg_1507, arg_1508) }
//line :370:1
					if jrt.J2g_Truth(tmp2) {





						var root_1509 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1510 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1509, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1511 lang.IFn; if linked_1510 == nil { ifn_1511 = lang.IFn_Cast(root_1509) } else { ifn_1511 = nil }; var arg_1512 any = pkg__2; var arg_1513 any = A_arbace_build_go_A_const_128; var arg_1514 any; var root_1515 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_1516 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1515, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1517 lang.IFn; if linked_1516 == nil { ifn_1517 = lang.IFn_Cast(root_1515) } else { ifn_1517 = nil }; var arg_1518 any = path__3; var arg_1519 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1516 == nil { arg_1514 = ifn_1517.Invoke_O_O__O(arg_1518, arg_1519) } else { arg_1514 = linked_1516.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1515, arg_1518, arg_1519) }; if linked_1510 == nil { arg_1491 = ifn_1511.Invoke_O_O_O__O(arg_1512, arg_1513, arg_1514) } else { arg_1491 = linked_1510.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1509, arg_1512, arg_1513, arg_1514) } } else {
//line :370:1
							var tmp3 any; var and__1927000168__auto____4 any = A_arbace_build_go_A_const_39.Invoke_O__O(pkg__2)










							if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1520 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_1521 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1520, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1522 lang.IFn; if linked_1521 == nil { ifn_1522 = lang.IFn_Cast(root_1520) } else { ifn_1522 = nil }; var arg_1523 any = t.F_module; var arg_1524 any = Lit_103; if linked_1521 == nil { tmp3 = ifn_1522.Invoke_O_O__O(arg_1523, arg_1524) } else { tmp3 = linked_1521.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1520, arg_1523, arg_1524) } } else { tmp3 = and__1927000168__auto____4 }
//line :370:1
							if jrt.J2g_Truth(tmp3) {











								var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_A_const_128; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3)).Ref(); var tmp7 any = A_arbace_build_go_A_const_124; var tmp8 any; var root_1533 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1534 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1533, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1535 lang.IFn; if linked_1534 == nil { ifn_1535 = lang.IFn_Cast(root_1533) } else { ifn_1535 = nil }; var arg_1536 any; var root_1537 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_1538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1537, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1539 lang.IFn; if linked_1538 == nil { ifn_1539 = lang.IFn_Cast(root_1537) } else { ifn_1539 = nil }; var arg_1540 any = path__3; var arg_1541 any = A_arbace_build_go_A_const_132; if linked_1538 == nil { arg_1536 = ifn_1539.Invoke_O_O__O(arg_1540, arg_1541) } else { arg_1536 = linked_1538.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_1537, arg_1540, arg_1541) }; if linked_1534 == nil { tmp8 = ifn_1535.Invoke_O__O(arg_1536) } else { tmp8 = linked_1534.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1533, arg_1536) }; arg_1491 = tmp4.Invoke_O_O_O_O_O__O(pkg__2, tmp5, tmp6, tmp7, tmp8) } else {
//line :370:1
									if A_arbace_build_go_A_const_13 != nil {












										arg_1491 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :370:1
											arg_1491 = nil } } } } }
//line :368:1
	if linked_1488 == nil { ifn_1489.Invoke_O_O__O(arg_1490, arg_1491) } else { linked_1488.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1487, arg_1490, arg_1491) }; i__1901000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000269__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_build_go_program_fn__1901000277_A_New() *A_arbace_build_go_program_fn__1901000277_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000277_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Ctor() {}
//line :386:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Invoke_O_O__O(self, p1__1901000258_SHARP___1 any) any { var tmp1 any; var root_1671 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000258_SHARP___1); if linked_1672 == nil { tmp1 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp1 = linked_1672.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1671, arg_1674) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_95, tmp1)).Ref() }




func A_arbace_build_go_sha256_A_New() *A_arbace_build_go_sha256_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_build_go_sha256_A) Ctor() {}
//line :391:1
func (t *A_arbace_build_go_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52); var root_1683 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_1684 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1683, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1685 lang.IFn; if

	linked_1684 == nil { ifn_1685 = lang.IFn_Cast(root_1683) } else { ifn_1685 = nil }; var arg_1686 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1687 any; var root_1688 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1688, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1690 lang.IFn; if linked_1689 == nil { ifn_1690 = lang.IFn_Cast(root_1688) } else { ifn_1690 = nil }; var arg_1691 any; var fnbody__1704 any = A_arbace_build_go_sha256_fn__1901000281_A_New(); var tmp1 *jrt.Class; var fncls__1703 *jrt.Class = A_arbace_build_go_sha256_fn__1901000281_A_fn_class; if fncls__1703 == nil { var fncls__1703d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_178, false, nil); A_arbace_build_go_sha256_fn__1901000281_A_fn_class = fncls__1703d; tmp1 = fncls__1703d } else { tmp1 = fncls__1703 }; arg_1691 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1704, tmp1, nil); var arg_1692 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__0).ToPath__Path())).Ref(); if linked_1689 == nil { arg_1687 = ifn_1690.Invoke_O_O__O(arg_1691, arg_1692) } else { arg_1687 = linked_1689.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1688, arg_1691, arg_1692) }; if linked_1684 == nil { return ifn_1685.Invoke_O_O__O(arg_1686, arg_1687) } else { return linked_1684.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1683, arg_1686, arg_1687) } }
//line :393:1
func A_arbace_build_go_sha256_fn__1901000281_A_New() *A_arbace_build_go_sha256_fn__1901000281_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_fn__1901000281_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Ctor() {}
//line :393:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Invoke_O_O__O(self, p1__1901000280_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_1698 any = p1__1901000280_SHARP___1; var na_1699 int64 = 255; if jrt.Long_InstanceOf(na_1698) { var n0_1700 int64 = jrt.NN(jrt.Long_Cast(na_1698)).LongValue__J(); var n1_1701 int64 = na_1699; tmp2 = n0_1700 & n1_1701 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1698, na_1699) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_copy_file_A_New() *A_arbace_build_go_copy_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_copy_file_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_build_go_copy_file_A) Ctor() {}
//line :395:1
func (t *A_arbace_build_go_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(to__1).GetParentFile__File().Mkdirs__Z())
	var tmp1 jrt.Path = jrt.File_Cast(from__0).ToPath__Path(); var tmp2 jrt.Path = jrt.File_Cast(to__1).ToPath__Path(); var tmp3 any; var root_1705 any = A_arbace_build_go_A_const_139.GetRawRoot__O(); var linked_1706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1705, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_1707 lang.IFn
	if linked_1706 == nil { ifn_1707 = lang.IFn_Cast(root_1705) } else { ifn_1707 = nil }; var arg_1708 any = A_arbace_build_go_A_const_140; var arg_1709 any; var tmp4 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp4 = jrt.StandardCopyOption_REPLACE_EXISTING; arg_1709 = lang.Tuple_Create_O__IPersistentVector(tmp4.Ref()); if linked_1706 == nil { tmp3 = ifn_1707.Invoke_O_O__O(arg_1708, arg_1709) } else { tmp3 = linked_1706.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_1705, arg_1708, arg_1709) }
//line :397:1
	return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.RefArray_Cast(tmp3, jrt.CopyOption_class))
}

func A_arbace_build_go_forms_dir_A_New() *A_arbace_build_go_forms_dir_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_forms_dir_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_build_go_forms_dir_A) Ctor() {}
//line :400:1
func (t *A_arbace_build_go_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_build_go_A_const_52.Invoke_O__O(pkg__0); var n__3 any = jrt.File_Cast(f__2).GetName__String().Ref(); var tmp1 jrt.File_I = jrt.File_Cast(f__2).GetParentFile__File(); var tmp2 any; var root_1710 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_1711 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1710, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1712 lang.IFn; if





	linked_1711 == nil { ifn_1712 = lang.IFn_Cast(root_1710) } else { ifn_1712 = nil }; var arg_1713 any = n__3; var arg_1714 any = A_arbace_build_go_A_const_141; var arg_1715 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref(); if linked_1711 == nil { tmp2 = ifn_1712.Invoke_O_O_O__O(arg_1713, arg_1714, arg_1715) } else { tmp2 = linked_1711.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1710, arg_1713, arg_1714, arg_1715) }; return /*line :400:1*/ jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2)) }







func A_arbace_build_go_with_line_files_A_New() *A_arbace_build_go_with_line_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_build_go_with_line_files_A) Ctor() {}
//line :408:1
func (t *A_arbace_build_go_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any; var root_1716 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1716, A_arbace_build_go_forms_dir_A_fn_class); var ifn_1718 lang.IFn; if





	linked_1717 == nil { ifn_1718 = lang.IFn_Cast(root_1716) } else { ifn_1718 = nil }; var arg_1719 any = pkg__0; if linked_1717 == nil { fdir__2 = ifn_1718.Invoke_O__O(arg_1719) } else { fdir__2 = linked_1717.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_1716, arg_1719) }; var root_1720 any =
	A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_1721 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1720, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1722 lang.IFn; if linked_1721 == nil { ifn_1722 = lang.IFn_Cast(root_1720) } else { ifn_1722 = nil }; var arg_1723 any = pkg__0; var arg_1724 any = A_arbace_build_go_A_const_143; var arg_1725 any; var fnbody__1751 any = A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(fdir__2); var tmp1 *jrt.Class; var fncls__1750 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class; if fncls__1750 == nil { var fncls__1750d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_189, false, fnbody__1751); A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class = fncls__1750d; tmp1 = fncls__1750d } else { tmp1 = fncls__1750 }; arg_1725 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1751, tmp1, nil); if linked_1721 == nil { return ifn_1722.Invoke_O_O_O__O(arg_1723, arg_1724, arg_1725) } else { return linked_1721.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1720, arg_1723, arg_1724, arg_1725) } }
//line :415:1
func A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Invoke_O_O__O(self, fs__1 any) any { var root_1726 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_1727 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1726, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1728 lang.IFn; if linked_1727 == nil { ifn_1728 = lang.IFn_Cast(root_1726) } else { ifn_1728 = nil }; var arg_1729 any; var fnbody__1749 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(t.F_fdir); var tmp1 *jrt.Class; var fncls__1748 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class; if fncls__1748 == nil { var fncls__1748d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_190, false, fnbody__1749); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class = fncls__1748d; tmp1 = fncls__1748d } else { tmp1 = fncls__1748 }; arg_1729 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1749, tmp1, nil); var arg_1730 any = fs__1; if linked_1727 == nil { return ifn_1728.Invoke_O_O__O(arg_1729, arg_1730) } else { return linked_1727.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1726, arg_1729, arg_1730) } }
//line :415:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Invoke_O_O__O(self, p1__1901000286_SHARP___1 any) any { var root_1731 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any = p1__1901000286_SHARP___1; var arg_1735 any = A_arbace_build_go_A_const_144; var arg_1736 any; var fnbody__1747 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(t.F_fdir); var tmp1 *jrt.Class; var fncls__1746 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class; if fncls__1746 == nil { var fncls__1746d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_191, false, fnbody__1747); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class = fncls__1746d; tmp1 = fncls__1746d } else { tmp1 = fncls__1746 }; arg_1736 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1747, tmp1, nil); if linked_1732 == nil { return ifn_1733.Invoke_O_O_O__O(arg_1734, arg_1735, arg_1736) } else { return linked_1732.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1731, arg_1734, arg_1735, arg_1736) } }
//line :415:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Invoke_O_O__O(self, s__1 any) any { var root_1737 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1738 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1737, A_arbace_build_go_rel_path_A_fn_class); var ifn_1739 lang.IFn; if linked_1738 == nil { ifn_1739 = lang.IFn_Cast(root_1737) } else { ifn_1739 = nil }; var arg_1740 any = t.F_fdir; var arg_1741 any; var tmp1 any; var root_1742 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1743 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1742, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1744 lang.IFn; if linked_1743 == nil { ifn_1744 = lang.IFn_Cast(root_1742) } else { ifn_1744 = nil }; var arg_1745 any = s__1; if linked_1743 == nil { tmp1 = ifn_1744.Invoke_O__O(arg_1745) } else { tmp1 = linked_1743.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1742, arg_1745) }; arg_1741 = jrt.File_New_String(jrt.String_Cast(tmp1)); if linked_1738 == nil { return ifn_1739.Invoke_O_O__O(arg_1740, arg_1741) } else { return linked_1738.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1737, arg_1740, arg_1741) } }



func A_arbace_build_go_print_cache_key_A_New() *A_arbace_build_go_print_cache_key_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_build_go_print_cache_key_A) Ctor() {}
//line :419:1
func (t *A_arbace_build_go_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52); var add__7 any; var fnbody__1753 any = A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(md__6); var tmp1 *jrt.Class; var fncls__1752 *jrt.Class = A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class; if





	fncls__1752 == nil { var fncls__1752d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_96, false, fnbody__1753); A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class = fncls__1752d; tmp1 = fncls__1752d } else { tmp1 = fncls__1752 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1753, tmp1, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0); var tmp2 lang.IFn =
	lang.IFn_Cast(add__7); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_145.Invoke_O__O(opts__3); var tmp5 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_build_go_A_const_146.Invoke_O__O(opts__3))).Ref(); var tmp6 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tests__4)).Ref(); var tmp7 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp8 any; var root_1800 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__1); if linked_1801 == nil { tmp8 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp8 = linked_1801.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1800, arg_1803) }; tmp2.Invoke_O__O(tmp3.Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp4, tmp5, tmp6, tmp7, tmp8))); var seq_1901000297__8 any; var root_1776 any = /*line :419:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1776, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1778 lang.IFn; if








	linked_1777 == nil { ifn_1778 = lang.IFn_Cast(root_1776) } else { ifn_1778 = nil }; var arg_1779 any = A_arbace_build_go_A_const_65.Invoke_O__O(pkg__1); if linked_1777 == nil { seq_1901000297__8 = ifn_1778.Invoke_O__O(arg_1779) } else { seq_1901000297__8 = linked_1777.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1776, arg_1779) }; var chunk_1901000298__9 any; var count_1901000299__10 int64 = 0; var i_1901000300__11 int64 = 0; L1:
//line :419:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000300__11, count_1901000299__10) { var f__12 any = lang.Indexed_Cast(chunk_1901000298__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000300__11)); var tmp9 lang.IFn = lang.IFn_Cast(add__7); var tmp10 any; var root_1804 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, A_arbace_build_go_rel_path_A_fn_class); var ifn_1806 lang.IFn
			if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any = dir__2; var arg_1808 any = f__12; if linked_1805 == nil { tmp10 = ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { tmp10 = linked_1805.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) }; tmp9.Invoke_O__O(tmp10)
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__12).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_97)
//line :428:1
			seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000300__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_1780 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1780, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1782 lang.IFn; if linked_1781 == nil { ifn_1782 = lang.IFn_Cast(root_1780) } else { ifn_1782 = nil }; var arg_1783 any = seq_1901000297__8; if linked_1781 == nil { temp__1927000414__auto____12 = ifn_1782.Invoke_O__O(arg_1783) } else { temp__1927000414__auto____12 = linked_1781.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1780, arg_1783) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1901000297__13 any = temp__1927000414__auto____12; var tmp11 any; var root_1784 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1785 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1784, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1786 lang.IFn; if linked_1785 == nil { ifn_1786 = lang.IFn_Cast(root_1784) } else { ifn_1786 = nil }; var arg_1787 any = seq_1901000297__13; if linked_1785 == nil { tmp11 = ifn_1786.Invoke_O__O(arg_1787) } else { tmp11 = linked_1785.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1784, arg_1787) }; if jrt.J2g_Truth(tmp11) { var c__1927000678__auto____14 any; var root_1788 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1789 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1788, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1790 lang.IFn; if linked_1789 == nil { ifn_1790 = lang.IFn_Cast(root_1788) } else { ifn_1790 = nil }; var arg_1791 any = seq_1901000297__13; if linked_1789 == nil { c__1927000678__auto____14 = ifn_1790.Invoke_O__O(arg_1791) } else { c__1927000678__auto____14 = linked_1789.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1788, arg_1791) }; var tmp12 any; var root_1809 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = seq_1901000297__13; if linked_1810 == nil { tmp12 = ifn_1811.Invoke_O__O(arg_1812) } else { tmp12 = linked_1810.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1809, arg_1812) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp12, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__14 any; var root_1792 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1793 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1792, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1794 lang.IFn; if linked_1793 == nil { ifn_1794 = lang.IFn_Cast(root_1792) } else { ifn_1794 = nil }; var arg_1795 any = seq_1901000297__13; if linked_1793 == nil { f__14 = ifn_1794.Invoke_O__O(arg_1795) } else { f__14 = linked_1793.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1792, arg_1795) }
				var tmp13 lang.IFn = lang.IFn_Cast(add__7); var tmp14 any; var root_1813 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, A_arbace_build_go_rel_path_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = dir__2; var arg_1817 any = f__14; if linked_1814 == nil { tmp14 = ifn_1815.Invoke_O_O__O(arg_1816, arg_1817) } else { tmp14 = linked_1814.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1813, arg_1816, arg_1817) }; tmp13.Invoke_O__O(tmp14)
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.File_Cast(f__14).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_97)
//line :428:1
				var tmp15 any; var root_1818 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1818, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1820 lang.IFn; if linked_1819 == nil { ifn_1820 = lang.IFn_Cast(root_1818) } else { ifn_1820 = nil }; var arg_1821 any = seq_1901000297__13; if linked_1819 == nil { tmp15 = ifn_1820.Invoke_O__O(arg_1821) } else { tmp15 = linked_1819.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1818, arg_1821) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp15, nil, 0, 0; continue L1 } } }
//line :419:1
		break L1 }; var root_1754 any =












	A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_1755 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1754, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1756 lang.IFn; if linked_1755 == nil { ifn_1756 = lang.IFn_Cast(root_1754) } else { ifn_1756 = nil }; var arg_1757 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1758 any; var root_1759 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1760 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1759, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1761 lang.IFn; if linked_1760 == nil { ifn_1761 = lang.IFn_Cast(root_1759) } else { ifn_1761 = nil }; var arg_1762 any; var fnbody__1775 any = A_arbace_build_go_print_cache_key_fn__1901000301_A_New(); var tmp16 *jrt.Class; var fncls__1774 *jrt.Class = A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class; if fncls__1774 == nil { var fncls__1774d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_98, false, nil); A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class = fncls__1774d; tmp16 = fncls__1774d } else { tmp16 = fncls__1774 }; arg_1762 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1775, tmp16, nil); var arg_1763 any = jrt.MessageDigest_Cast(md__6).Digest__B1().Ref(); if linked_1760 == nil { arg_1758 = ifn_1761.Invoke_O_O__O(arg_1762, arg_1763) } else { arg_1758 = linked_1760.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1759, arg_1762, arg_1763) }; if linked_1755 == nil { return ifn_1756.Invoke_O_O__O(arg_1757, arg_1758) } else { return linked_1755.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1754, arg_1757, arg_1758) } }
//line :425:1
func A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(p0 any) *A_arbace_build_go_print_cache_key_add__1901000295_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_add__1901000295_A{}; t.Ctor_O(p0); return t }
//line :425:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :425:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_53)); return nil }






func A_arbace_build_go_print_cache_key_fn__1901000301_A_New() *A_arbace_build_go_print_cache_key_fn__1901000301_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_fn__1901000301_A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Ctor() {}
//line :432:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Invoke_O_O__O(self, p1__1901000294_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_1769 any = p1__1901000294_SHARP___1; var na_1770 int64 = 255; if jrt.Long_InstanceOf(na_1769) { var n0_1771 int64 = jrt.NN(jrt.Long_Cast(na_1769)).LongValue__J(); var n1_1772 int64 = na_1770; tmp2 = n0_1771 & n1_1772 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1769, na_1770) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_cached_texts_A_New() *A_arbace_build_go_cached_texts_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_build_go_cached_texts_A) Ctor() {}
//line :434:1
func (t *A_arbace_build_go_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_43); if





	jrt.File_Cast(names__2).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(entry__0).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var root_1822 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_1823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1822, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1824 lang.IFn; if linked_1823 == nil { ifn_1824 = lang.IFn_Cast(root_1822) } else { ifn_1824 = nil }; var arg_1825 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_1826 any; var iter__1927001039__auto____3 any; var fnbody__1903 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(entry__0); var tmp1 *jrt.Class; var fncls__1902 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class
		if fncls__1902 == nil { var fncls__1902d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_46, false, fnbody__1903); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class = fncls__1902d; tmp1 = fncls__1902d } else { tmp1 = fncls__1902 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1903, tmp1, nil); var tmp2 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp3 any; var root_1904 any = A_arbace_build_go_A_const_147.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any = lang.IFn_Cast(A_arbace_build_go_A_const_105.GetRawRoot__O()).Invoke_O__O(names__2); if linked_1905 == nil { tmp3 = ifn_1906.Invoke_O__O(arg_1907) } else { tmp3 = linked_1905.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_1904, arg_1907) }; arg_1826 = tmp2.Invoke_O__O(tmp3)
//line :442:1
		if linked_1823 == nil { return ifn_1824.Invoke_O_O__O(arg_1825, arg_1826) } else { return linked_1823.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1822, arg_1825, arg_1826) } } else {
//line :440:1
			return nil } }


func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(p0 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A{}; t.Ctor_O(p0); return t }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Invoke_O_O__O(self, s__1901000305__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__1901 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(s__1901000305__1, self, t.F_entry); var tmp2 *jrt.Class; var fncls__1900 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class; if fncls__1900 == nil { var fncls__1900d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_47, false, fnbody__1901); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class = fncls__1900d; tmp2 = fncls__1900d } else { tmp2 = fncls__1900 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1901, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :443:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Ctor_O_O_O(c__s__1901000305, c__iter__1901000304, c__entry any) { t.F_s__1901000305 = c__s__1901000305; t.F_iter__1901000304 = c__iter__1901000304; t.F_entry = c__entry }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Invoke_O__O(self any) any { { var s__1901000305__1 any; var t_ any = t.F_s__1901000305; t.F_s__1901000305 = nil; s__1901000305__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1830 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = s__1901000305__1; if linked_1831 == nil { temp__1927000414__auto____2 = ifn_1832.Invoke_O__O(arg_1833) } else { temp__1927000414__auto____2 = linked_1831.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1830, arg_1833) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000305__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1834 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1835 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1834, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1836 lang.IFn; if linked_1835 == nil { ifn_1836 = lang.IFn_Cast(root_1834) } else { ifn_1836 = nil }; var arg_1837 any = s__1901000305__3; if linked_1835 == nil { tmp1 = ifn_1836.Invoke_O__O(arg_1837) } else { tmp1 = linked_1835.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1834, arg_1837) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1838 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1839 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1838, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1840 lang.IFn; if linked_1839 == nil { ifn_1840 = lang.IFn_Cast(root_1838) } else { ifn_1840 = nil }; var arg_1841 any = s__1901000305__3; if linked_1839 == nil { c__1927001037__auto____4 = ifn_1840.Invoke_O__O(arg_1841) } else { c__1927001037__auto____4 = linked_1839.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1838, arg_1841) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000307__6 any; var root_1842 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1843 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1842, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1844 lang.IFn; if linked_1843 == nil { ifn_1844 = lang.IFn_Cast(root_1842) } else { ifn_1844 = nil }; var arg_1845 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1843 == nil { b__1901000307__6 = ifn_1844.Invoke_O__O(arg_1845) } else { b__1901000307__6 = linked_1843.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1842, arg_1845) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__1856 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(b__1901000307__6, t.F_entry, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1855 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class; if fncls__1855 == nil { var fncls__1855d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_48, false, fnbody__1856); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class = fncls__1855d; tmp3 = fncls__1855d } else { tmp3 = fncls__1855 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1856, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_1857 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1857, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1859 lang.IFn; if linked_1858 == nil { ifn_1859 = lang.IFn_Cast(root_1857) } else { ifn_1859 = nil }; var arg_1860 any; var root_1862 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1863 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1862, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1864 lang.IFn; if linked_1863 == nil { ifn_1864 = lang.IFn_Cast(root_1862) } else { ifn_1864 = nil }; var arg_1865 any = b__1901000307__6; if linked_1863 == nil { arg_1860 = ifn_1864.Invoke_O__O(arg_1865) } else { arg_1860 = linked_1863.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1862, arg_1865) }; var arg_1861 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp5 any; var root_1866 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1867 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1866, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1868 lang.IFn; if linked_1867 == nil { ifn_1868 = lang.IFn_Cast(root_1866) } else { ifn_1868 = nil }; var arg_1869 any = s__1901000305__3; if linked_1867 == nil { tmp5 = ifn_1868.Invoke_O__O(arg_1869) } else { tmp5 = linked_1867.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1866, arg_1869) }; arg_1861 = tmp4.Invoke_O__O(tmp5); if linked_1858 == nil { return ifn_1859.Invoke_O_O__O(arg_1860, arg_1861) } else { return linked_1858.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1857, arg_1860, arg_1861) } } else { var root_1870 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1871 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1870, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1872 lang.IFn; if linked_1871 == nil { ifn_1872 = lang.IFn_Cast(root_1870) } else { ifn_1872 = nil }; var arg_1873 any; var root_1875 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1875, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1877 lang.IFn; if linked_1876 == nil { ifn_1877 = lang.IFn_Cast(root_1875) } else { ifn_1877 = nil }; var arg_1878 any = b__1901000307__6; if linked_1876 == nil { arg_1873 = ifn_1877.Invoke_O__O(arg_1878) } else { arg_1873 = linked_1876.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1875, arg_1878) }; var arg_1874 any; if linked_1871 == nil { return ifn_1872.Invoke_O_O__O(arg_1873, arg_1874) } else { return linked_1871.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1870, arg_1873, arg_1874) } } } else { var n__4 any; var root_1879 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1880 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1879, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1881 lang.IFn; if linked_1880 == nil { ifn_1881 = lang.IFn_Cast(root_1879) } else { ifn_1881 = nil }; var arg_1882 any = s__1901000305__3; if linked_1880 == nil { n__4 = ifn_1881.Invoke_O__O(arg_1882) } else { n__4 = linked_1880.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1879, arg_1882) }; var tmp6 any; var root_1883 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = n__4; if linked_1884 == nil { tmp6 = ifn_1885.Invoke_O__O(arg_1886) } else { tmp6 = linked_1884.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1883, arg_1886) }; if jrt.J2g_Truth(tmp6) { var root_1887 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1887, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1889 lang.IFn; if linked_1888 == nil { ifn_1889 = lang.IFn_Cast(root_1887) } else { ifn_1889 = nil }; var tmp7 jrt.File_I = jrt.File_Cast(t.F_entry); var arg_1890 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, jrt.File_New_File_String(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4)))); var arg_1891 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp9 any; var root_1892 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = s__1901000305__3; if linked_1893 == nil { tmp9 = ifn_1894.Invoke_O__O(arg_1895) } else { tmp9 = linked_1893.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1892, arg_1895) }; arg_1891 = tmp8.Invoke_O__O(tmp9); if linked_1888 == nil { return ifn_1889.Invoke_O_O__O(arg_1890, arg_1891) } else { return linked_1888.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1887, arg_1890, arg_1891) } } else { var tmp10 any; var root_1896 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1896, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1898 lang.IFn; if linked_1897 == nil { ifn_1898 = lang.IFn_Cast(root_1896) } else { ifn_1898 = nil }; var arg_1899 any = s__1901000305__3; if linked_1897 == nil { tmp10 = ifn_1898.Invoke_O__O(arg_1899) } else { tmp10 = linked_1897.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1896, arg_1899) }; s__1901000305__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :443:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Ctor_O_O_I_O(c__b__1901000307, c__entry any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000307 = c__b__1901000307; t.F_entry = c__entry; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Invoke_O__O(self any) any { { var i__1901000306__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000306__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000306__1)); var tmp2 any; var root_1846 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1847 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1846, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1848 lang.IFn; if linked_1847 == nil { ifn_1848 = lang.IFn_Cast(root_1846) } else { ifn_1848 = nil }; var arg_1849 any = n__2; if linked_1847 == nil { tmp2 = ifn_1848.Invoke_O__O(arg_1849) } else { tmp2 = linked_1847.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1846, arg_1849) }; if jrt.J2g_Truth(tmp2) { var root_1850 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1851 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1850, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1852 lang.IFn; if linked_1851 == nil { ifn_1852 = lang.IFn_Cast(root_1850) } else { ifn_1852 = nil }; var arg_1853 any = t.F_b__1901000307; var tmp3 jrt.File_I = jrt.File_Cast(t.F_entry); var arg_1854 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, jrt.File_New_File_String(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2)))); if linked_1851 == nil { ifn_1852.Invoke_O_O__O(arg_1853, arg_1854) } else { linked_1851.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1850, arg_1853, arg_1854) }; i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } else { i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_cache_texts_BANG__A_New() *A_arbace_build_go_cache_texts_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Ctor() {}
//line :446:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.File_Cast(entry__0).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, jrt.File_Cast(entry__0).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(tmp__3).Mkdirs__Z()); var seq_1901000316__4 any; var root_1916 any = /*line :446:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1916, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1918 lang.IFn; if




	linked_1917 == nil { ifn_1918 = lang.IFn_Cast(root_1916) } else { ifn_1918 = nil }; var arg_1919 any = texts__1; if linked_1917 == nil { seq_1901000316__4 = ifn_1918.Invoke_O__O(arg_1919) } else { seq_1901000316__4 = linked_1917.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1916, arg_1919) }; var chunk_1901000317__5 any; var count_1901000318__6 int64 = 0; var i_1901000319__7 int64 = 0; L1:
//line :446:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000319__7, count_1901000318__6) { var vec__1901000320__8 any = lang.Indexed_Cast(chunk_1901000317__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000319__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000319__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1920 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = seq_1901000316__4; if linked_1921 == nil { temp__1927000414__auto____8 = ifn_1922.Invoke_O__O(arg_1923) } else { temp__1927000414__auto____8 = linked_1921.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1920, arg_1923) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1901000316__9 any = temp__1927000414__auto____8; var tmp1 any; var root_1924 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1926 lang.IFn; if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = seq_1901000316__9; if linked_1925 == nil { tmp1 = ifn_1926.Invoke_O__O(arg_1927) } else { tmp1 = linked_1925.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1924, arg_1927) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_1928 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1928, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1930 lang.IFn; if linked_1929 == nil { ifn_1930 = lang.IFn_Cast(root_1928) } else { ifn_1930 = nil }; var arg_1931 any = seq_1901000316__9; if linked_1929 == nil { c__1927000678__auto____10 = ifn_1930.Invoke_O__O(arg_1931) } else { c__1927000678__auto____10 = linked_1929.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1928, arg_1931) }; var tmp2 any; var root_1961 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1961, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1963 lang.IFn; if linked_1962 == nil { ifn_1963 = lang.IFn_Cast(root_1961) } else { ifn_1963 = nil }; var arg_1964 any = seq_1901000316__9; if linked_1962 == nil { tmp2 = ifn_1963.Invoke_O__O(arg_1964) } else { tmp2 = linked_1962.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1961, arg_1964) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000323__10 any; var root_1932 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1934 lang.IFn; if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = seq_1901000316__9; if linked_1933 == nil { vec__1901000323__10 = ifn_1934.Invoke_O__O(arg_1935) } else { vec__1901000323__10 = linked_1933.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1932, arg_1935) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); var tmp3 any; var root_1970 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1970, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1972 lang.IFn; if linked_1971 == nil { ifn_1972 = lang.IFn_Cast(root_1970) } else { ifn_1972 = nil }; var arg_1973 any = seq_1901000316__9; if linked_1971 == nil { tmp3 = ifn_1972.Invoke_O__O(arg_1973) } else { tmp3 = linked_1971.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1970, arg_1973) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :446:1
		break L1 }; var tmp4 lang.IFn =





	lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()); var tmp5 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_43); var tmp6 any; var root_1941 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1942 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1941, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1943 lang.IFn; if linked_1942 == nil { ifn_1943 = lang.IFn_Cast(root_1941) } else { ifn_1943 = nil }; var arg_1944 any; var root_1945 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1946 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1945, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1947 lang.IFn; if linked_1946 == nil { ifn_1947 = lang.IFn_Cast(root_1945) } else { ifn_1947 = nil }; var arg_1948 any; var fnbody__1951 any = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New(); var tmp7 *jrt.Class; var fncls__1950 *jrt.Class = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class; if fncls__1950 == nil { var fncls__1950d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_44, false, nil); A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class = fncls__1950d; tmp7 = fncls__1950d } else { tmp7 = fncls__1950 }; arg_1948 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__1951, tmp7, nil); var arg_1949 any; var root_1952 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_1953 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1952, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1954 lang.IFn; if linked_1953 == nil { ifn_1954 = lang.IFn_Cast(root_1952) } else { ifn_1954 = nil }; var arg_1955 any = texts__1; if linked_1953 == nil { arg_1949 = ifn_1954.Invoke_O__O(arg_1955) } else { arg_1949 = linked_1953.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1952, arg_1955) }; if linked_1946 == nil { arg_1944 = ifn_1947.Invoke_O_O__O(arg_1948, arg_1949) } else { arg_1944 = linked_1946.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1945, arg_1948, arg_1949) }; if linked_1942 == nil { tmp6 = ifn_1943.Invoke_O__O(arg_1944) } else { tmp6 = linked_1942.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_1941, arg_1944) }; tmp4.Invoke_O_O__O(tmp5, tmp6); if
	jrt.File_Cast(tmp__3).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { var root_1912 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_1913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1912, A_arbace_build_go_delete_tree_A_fn_class); var ifn_1914 lang.IFn; if linked_1913 == nil { ifn_1914 = lang.IFn_Cast(root_1912) } else { ifn_1914 = nil }; var arg_1915 any = tmp__3; if linked_1913 == nil { return ifn_1914.Invoke_O__O(arg_1915) } else { return linked_1913.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_1912, arg_1915) } } }
//line :452:1
func A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New() *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__fn__1901000326_A{}; t.Ctor(); return t }
//line :452:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Ctor() {}
//line :452:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Invoke_O_O__O(self, p1__1901000315_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, p1__1901000315_SHARP___1, nil)).Ref() }


func A_arbace_build_go_print_module_A_New() *A_arbace_build_go_print_module_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_A{}; t.Ctor(); return t }
//line :455:1
func (t *A_arbace_build_go_print_module_A) Ctor() {}
//line :455:1
func (t *A_arbace_build_go_print_module_A) Invoke_O_O_O_O_O__O(self, p__1901000331__0, dir__1, out__2, p__1901000332__3 any) any { var map__1901000333__5 any = p__1901000331__0; var map__1901000333__6 any; if lang.ISeq_InstanceOf(map__1901000333__5) { var tmp1 any; var root_1974 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = map__1901000333__5; if linked_1975 == nil { tmp1 = ifn_1976.Invoke_O__O(arg_1977) } else { tmp1 = linked_1975.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1974, arg_1977) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1978 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = map__1901000333__5; if linked_1979 == nil { tmp2 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp2 = linked_1979.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1978, arg_1981) }; map__1901000333__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1982 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any = map__1901000333__5; if linked_1983 == nil { tmp3 = ifn_1984.Invoke_O__O(arg_1985) } else { tmp3 = linked_1983.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1982, arg_1985) }; if jrt.J2g_Truth(tmp3) { var root_1986 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1987 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1986, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1988 lang.IFn; if linked_1987 == nil { ifn_1988 = lang.IFn_Cast(root_1986) } else { ifn_1988 = nil }; var arg_1989 any = map__1901000333__5; if linked_1987 == nil { map__1901000333__6 = ifn_1988.Invoke_O__O(arg_1989) } else { map__1901000333__6 = linked_1987.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1986, arg_1989) } } else { map__1901000333__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000333__6 = map__1901000333__5 }; var module__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_124); var packages__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_79); var modules__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_133); var golang__10 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_126); var map__1901000335__11 any = p__1901000332__3; var map__1901000335__12 any; if lang.ISeq_InstanceOf(map__1901000335__11) { var tmp4 any; var root_1990 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1991 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1990, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1992 lang.IFn; if linked_1991 == nil { ifn_1992 = lang.IFn_Cast(root_1990) } else { ifn_1992 = nil }; var arg_1993 any = map__1901000335__11; if linked_1991 == nil { tmp4 = ifn_1992.Invoke_O__O(arg_1993) } else { tmp4 = linked_1991.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1990, arg_1993) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1994 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = map__1901000335__11; if linked_1995 == nil { tmp5 = ifn_1996.Invoke_O__O(arg_1997) } else { tmp5 = linked_1995.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1994, arg_1997) }; map__1901000335__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp5)).Ref() } else { var tmp6 any; var root_1998 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1999 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1998, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2000 lang.IFn; if linked_1999 == nil { ifn_2000 = lang.IFn_Cast(root_1998) } else { ifn_2000 = nil }; var arg_2001 any = map__1901000335__11; if linked_1999 == nil { tmp6 = ifn_2000.Invoke_O__O(arg_2001) } else { tmp6 = linked_1999.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1998, arg_2001) }; if jrt.J2g_Truth(tmp6) { var root_2002 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2003 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2002, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2004 lang.IFn; if linked_2003 == nil { ifn_2004 = lang.IFn_Cast(root_2002) } else { ifn_2004 = nil }; var arg_2005 any = map__1901000335__11; if linked_2003 == nil { map__1901000335__12 = ifn_2004.Invoke_O__O(arg_2005) } else { map__1901000335__12 = linked_2003.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2002, arg_2005) } } else { map__1901000335__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000335__12 = map__1901000335__11 }; var layout__13 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_145); var line_file__14 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_146); var tests__15 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_150); var goos__16 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_151); var goroot__17 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_152); var goos_dir__18 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_153); var print_cache__19 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_122);









	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(out__2).Mkdirs__Z()); var seq_1901000337__20 any; var root_2473 any = /*line :455:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2475 lang.IFn; if











	linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = modules__9; if linked_2474 == nil { seq_1901000337__20 = ifn_2475.Invoke_O__O(arg_2476) } else { seq_1901000337__20 = linked_2474.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2473, arg_2476) }; var chunk_1901000338__21 any; var count_1901000339__22 int64 = 0; var i_1901000340__23 int64 = 0; L1:
//line :455:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000340__23, count_1901000339__22) { var m__24 any = lang.Indexed_Cast(chunk_1901000338__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000340__23))
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__24))).Mkdirs__Z())
			lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__24, nil))), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, nil, m__24, nil, golang__10, nil)).Ref())
//line :467:1
			seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, i_1901000340__23 = seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000340__23); continue L1 } else { var temp__1927000414__auto____24 any; var root_2477 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = seq_1901000337__20; if linked_2478 == nil { temp__1927000414__auto____24 = ifn_2479.Invoke_O__O(arg_2480) } else { temp__1927000414__auto____24 = linked_2478.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2477, arg_2480) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1901000337__25 any = temp__1927000414__auto____24; var tmp7 any; var root_2481 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2482 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2481, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2483 lang.IFn; if linked_2482 == nil { ifn_2483 = lang.IFn_Cast(root_2481) } else { ifn_2483 = nil }; var arg_2484 any = seq_1901000337__25; if linked_2482 == nil { tmp7 = ifn_2483.Invoke_O__O(arg_2484) } else { tmp7 = linked_2482.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2481, arg_2484) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____26 any; var root_2485 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2485, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2487 lang.IFn; if linked_2486 == nil { ifn_2487 = lang.IFn_Cast(root_2485) } else { ifn_2487 = nil }; var arg_2488 any = seq_1901000337__25; if linked_2486 == nil { c__1927000678__auto____26 = ifn_2487.Invoke_O__O(arg_2488) } else { c__1927000678__auto____26 = linked_2486.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2485, arg_2488) }; var tmp8 any; var root_2590 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2591 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2590, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2592 lang.IFn; if linked_2591 == nil { ifn_2592 = lang.IFn_Cast(root_2590) } else { ifn_2592 = nil }; var arg_2593 any = seq_1901000337__25; if linked_2591 == nil { tmp8 = ifn_2592.Invoke_O__O(arg_2593) } else { tmp8 = linked_2591.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2590, arg_2593) }; seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, i_1901000340__23 = tmp8, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var m__26 any; var root_2489 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2490 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2489, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2491 lang.IFn; if linked_2490 == nil { ifn_2491 = lang.IFn_Cast(root_2489) } else { ifn_2491 = nil }; var arg_2492 any = seq_1901000337__25; if linked_2490 == nil { m__26 = ifn_2491.Invoke_O__O(arg_2492) } else { m__26 = linked_2490.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2489, arg_2492) }
				jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__26))).Mkdirs__Z())
				lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__26, nil))), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, nil, m__26, nil, golang__10, nil)).Ref())
//line :467:1
				var tmp9 any; var root_2599 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2599, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2601 lang.IFn; if linked_2600 == nil { ifn_2601 = lang.IFn_Cast(root_2599) } else { ifn_2601 = nil }; var arg_2602 any = seq_1901000337__25; if linked_2600 == nil { tmp9 = ifn_2601.Invoke_O__O(arg_2602) } else { tmp9 = linked_2600.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2599, arg_2602) }; seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, i_1901000340__23 = tmp9, nil, 0, 0; continue L1 } } }
//line :455:1
		break L1 }; if














	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_103) { } else {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()); var tmp11 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_104); var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_45, nil, nil); var tmp13 *jrt.String; var tmp14 any; var root_2498 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2498, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2500 lang.IFn
		if linked_2499 == nil { ifn_2500 = lang.IFn_Cast(root_2498) } else { ifn_2500 = nil }; var arg_2501 any = modules__9; if linked_2499 == nil { tmp14 = ifn_2500.Invoke_O__O(arg_2501) } else { tmp14 = linked_2499.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2498, arg_2501) }; if jrt.J2g_Truth(tmp14) {
			var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_105, nil); var tmp16 any; var root_2502 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_2503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2502, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2504 lang.IFn
			if linked_2503 == nil { ifn_2504 = lang.IFn_Cast(root_2502) } else { ifn_2504 = nil }; var arg_2505 any; var iter__1927001039__auto____29 any; var fnbody__2567 any = A_arbace_build_go_print_module_iter__1901000341__1901000345_A_New(); var tmp17 *jrt.Class; var fncls__2566 *jrt.Class = A_arbace_build_go_print_module_iter__1901000341__1901000345_A_fn_class; if fncls__2566 == nil { var fncls__2566d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_106, false, nil); A_arbace_build_go_print_module_iter__1901000341__1901000345_A_fn_class = fncls__2566d; tmp17 = fncls__2566d } else { tmp17 = fncls__2566 }; iter__1927001039__auto____29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2567, tmp17, nil); arg_2505 = lang.IFn_Cast(iter__1927001039__auto____29).Invoke_O__O(modules__9); if linked_2503 == nil { tmp16 = ifn_2504.Invoke_O__O(arg_2505) } else { tmp16 = linked_2503.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_2502, arg_2505) }
//line :473:1
			tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)) } else {
//line :472:1
				tmp13 = nil }
//line :471:1
		var tmp18 any = tmp13.Ref(); var tmp19 *jrt.String



		if lang.Util_Equiv_O_O__Z_NoInit(goos__16, Lit_29) {
			var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_107, nil, Lit_108, nil, Lit_45, nil); var tmp21 *lang.Keyword = A_arbace_build_go_A_const_48; var tmp22 any = tmp21.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp23 *lang.Keyword = A_arbace_build_go_A_const_113; var tmp24 any = tmp23.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp25 *jrt.String

			if jrt.J2g_Truth(goos_dir__18) {
				var tmp26 *jrt.RefArray = jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}); var tmp27 *lang.Keyword = A_arbace_build_go_A_const_48; var tmp28 any = tmp27.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp29 *lang.Keyword = A_arbace_build_go_A_const_113; var tmp30 any = tmp29.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp31 any; var root_2568 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2569 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2568, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2570 lang.IFn

				if linked_2569 == nil { ifn_2570 = lang.IFn_Cast(root_2568) } else { ifn_2570 = nil }; var arg_2571 any = goos_dir__18; if linked_2569 == nil { tmp31 = ifn_2570.Invoke_O__O(arg_2571) } else { tmp31 = linked_2569.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2568, arg_2571) }
//line :479:1
				tmp25 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp26, jrt.RefArrayOf(jrt.Object_class, nil, tmp28, nil, tmp30, nil, jrt.File_New_String(jrt.String_Cast(tmp31)).GetAbsoluteFile__File().GetPath__String().Ref(), nil)) } else {
//line :478:1
					tmp25 = nil }
//line :476:1
			tmp19 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, tmp22, nil, tmp24, nil, tmp25.Ref())) } else {
//line :475:1
				tmp19 = nil }
//line :471:1
		tmp10.Invoke_O_O__O(tmp11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__10, nil, tmp18, tmp19.Ref())).Ref()) }; var tmp32 any; var and__1927000168__auto____20 bool =










	lang.Util_Equiv_O_O__Z_NoInit(goos__16, Lit_29); if and__1927000168__auto____20 { var root_2572 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2572, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2574 lang.IFn; if linked_2573 == nil { ifn_2574 = lang.IFn_Cast(root_2572) } else { ifn_2574 = nil }; var arg_2575 any = goos_dir__18; if linked_2573 == nil { tmp32 = ifn_2574.Invoke_O__O(arg_2575) } else { tmp32 = linked_2573.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2572, arg_2575) } } else { tmp32 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____20).Ref() }; if jrt.J2g_Truth(tmp32) {
		var tmp33 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()); var tmp34 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_109); var tmp35 any; var root_2581 any = A_arbace_build_go_A_const_170.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2581, A_arbace_build_go_tamago_go_sum_A_fn_class); var ifn_2583 lang.IFn; if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = goroot__17; if linked_2582 == nil { tmp35 = ifn_2583.Invoke_O__O(arg_2584) } else { tmp35 = linked_2582.(*A_arbace_build_go_tamago_go_sum_A).Invoke_O_O__O(root_2581, arg_2584) }; tmp33.Invoke_O_O__O(tmp34, tmp35) }; var root_2006 any =
	A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2008 lang.IFn; if linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any; var tmp36 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()); var tmp37 any; if
	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_103) { tmp37 = nil } else { tmp37 = A_arbace_build_go_A_const_154 }; var tmp38 any = tmp37; var tmp39 any; var iter__1927001039__auto____20 any; var fnbody__2077 any = A_arbace_build_go_print_module_iter__1901000351__1901000355_A_New(); var tmp40 *jrt.Class; var fncls__2076 *jrt.Class = A_arbace_build_go_print_module_iter__1901000351__1901000355_A_fn_class; if
	fncls__2076 == nil { var fncls__2076d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_110, false, nil); A_arbace_build_go_print_module_iter__1901000351__1901000355_A_fn_class = fncls__2076d; tmp40 = fncls__2076d } else { tmp40 = fncls__2076 }; iter__1927001039__auto____20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2077, tmp40, nil); tmp39 = lang.IFn_Cast(iter__1927001039__auto____20).Invoke_O__O(modules__9); var tmp41 any = tmp39; var tmp42 any; var root_2078 any = /*line :485:1*/A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2080 lang.IFn; if

	linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var arg_2082 any; var root_2083 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_2084 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2083, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_2085 lang.IFn; if linked_2084 == nil { ifn_2085 = lang.IFn_Cast(root_2083) } else { ifn_2085 = nil }; var arg_2086 any; var fnbody__2472 any = A_arbace_build_go_print_module_fn__1901000361_A_New_O_O_O_O_O_O(dir__1, out__2, tests__15, line_file__14, layout__13, print_cache__19); var tmp43 *jrt.Class; var fncls__2471 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_A_fn_class; if
	fncls__2471 == nil { var fncls__2471d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_111, false, fnbody__2472); A_arbace_build_go_print_module_fn__1901000361_A_fn_class = fncls__2471d; tmp43 = fncls__2471d } else { tmp43 = fncls__2471 }; arg_2086 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2472, tmp43, nil); var arg_2087 any = packages__8; if /*line :487:1*/ linked_2084 == nil { arg_2082 = ifn_2085.Invoke_O_O__O(arg_2086, arg_2087) } else { arg_2082 = linked_2084.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_2083, arg_2086, arg_2087) }; if linked_2079 == nil { tmp42 = ifn_2080.Invoke_O_O__O(arg_2081, arg_2082) } else { tmp42 = linked_2079.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2078, arg_2081, arg_2082) }; arg_2009 = /*line :485:1*/tmp36.Invoke_O_O_O__O(tmp38, tmp41, tmp42); if /*line :484:1*/ linked_2007 == nil { return ifn_2008.Invoke_O__O(arg_2009) } else { return linked_2007.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2006, arg_2009) } }
//line :474:1
func A_arbace_build_go_print_module_iter__1901000341__1901000345_A_New() *A_arbace_build_go_print_module_iter__1901000341__1901000345_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000341__1901000345_A{}; t.Ctor(); return t }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_A) Ctor() {}
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_A) Invoke_O_O__O(self, s__1901000342__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2565 any = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_New_O_O(self, s__1901000342__1); var tmp2 *jrt.Class; var fncls__2564 *jrt.Class = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_fn_class; if fncls__2564 == nil { var fncls__2564d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_124, false, fnbody__2565); A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_fn_class = fncls__2564d; tmp2 = fncls__2564d } else { tmp2 = fncls__2564 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2565, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :474:1
func A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A{}; t.Ctor_O_O(p0, p1); return t }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A) Ctor_O_O(c__iter__1901000341, c__s__1901000342 any) { t.F_iter__1901000341 = c__iter__1901000341; t.F_s__1901000342 = c__s__1901000342 }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A) Invoke_O__O(self any) any { { var s__1901000342__1 any; var t_ any = t.F_s__1901000342; t.F_s__1901000342 = nil; s__1901000342__1 = t_; for { var temp__1927000414__auto____2 any; var root_2506 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2506, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2508 lang.IFn; if linked_2507 == nil { ifn_2508 = lang.IFn_Cast(root_2506) } else { ifn_2508 = nil }; var arg_2509 any = s__1901000342__1; if linked_2507 == nil { temp__1927000414__auto____2 = ifn_2508.Invoke_O__O(arg_2509) } else { temp__1927000414__auto____2 = linked_2507.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2506, arg_2509) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000342__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2510 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2512 lang.IFn; if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = s__1901000342__3; if linked_2511 == nil { tmp1 = ifn_2512.Invoke_O__O(arg_2513) } else { tmp1 = linked_2511.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2510, arg_2513) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2514 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = s__1901000342__3; if linked_2515 == nil { c__1927001037__auto____4 = ifn_2516.Invoke_O__O(arg_2517) } else { c__1927001037__auto____4 = linked_2515.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2514, arg_2517) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000344__6 any; var root_2518 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2519 == nil { b__1901000344__6 = ifn_2520.Invoke_O__O(arg_2521) } else { b__1901000344__6 = linked_2519.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2518, arg_2521) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2528 any = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_New_O_I_O(b__1901000344__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2527 *jrt.Class = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_fn_class; if fncls__2527 == nil { var fncls__2527d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_125, false, fnbody__2528); A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_fn_class = fncls__2527d; tmp3 = fncls__2527d } else { tmp3 = fncls__2527 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2528, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2529 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2530 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2529, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2531 lang.IFn; if linked_2530 == nil { ifn_2531 = lang.IFn_Cast(root_2529) } else { ifn_2531 = nil }; var arg_2532 any; var root_2534 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = b__1901000344__6; if linked_2535 == nil { arg_2532 = ifn_2536.Invoke_O__O(arg_2537) } else { arg_2532 = linked_2535.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2534, arg_2537) }; var arg_2533 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000341); var tmp5 any; var root_2538 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2538, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2540 lang.IFn; if linked_2539 == nil { ifn_2540 = lang.IFn_Cast(root_2538) } else { ifn_2540 = nil }; var arg_2541 any = s__1901000342__3; if linked_2539 == nil { tmp5 = ifn_2540.Invoke_O__O(arg_2541) } else { tmp5 = linked_2539.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2538, arg_2541) }; arg_2533 = tmp4.Invoke_O__O(tmp5); if linked_2530 == nil { return ifn_2531.Invoke_O_O__O(arg_2532, arg_2533) } else { return linked_2530.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2529, arg_2532, arg_2533) } } else { var root_2542 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2544 lang.IFn; if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any; var root_2547 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = b__1901000344__6; if linked_2548 == nil { arg_2545 = ifn_2549.Invoke_O__O(arg_2550) } else { arg_2545 = linked_2548.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2547, arg_2550) }; var arg_2546 any; if linked_2543 == nil { return ifn_2544.Invoke_O_O__O(arg_2545, arg_2546) } else { return linked_2543.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2542, arg_2545, arg_2546) } } } else { var m__4 any; var root_2551 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = s__1901000342__3; if linked_2552 == nil { m__4 = ifn_2553.Invoke_O__O(arg_2554) } else { m__4 = linked_2552.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2551, arg_2554) }; var root_2555 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s8:require ns16: v0.0.0\nreplace ns15: => ./_modules/ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, m__4, nil, m__4, nil, m__4, nil)).Ref(); var arg_2559 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000341); var tmp7 any; var root_2560 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = s__1901000342__3; if linked_2561 == nil { tmp7 = ifn_2562.Invoke_O__O(arg_2563) } else { tmp7 = linked_2561.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2560, arg_2563) }; arg_2559 = tmp6.Invoke_O__O(tmp7); if linked_2556 == nil { return ifn_2557.Invoke_O_O__O(arg_2558, arg_2559) } else { return linked_2556.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2555, arg_2558, arg_2559) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :474:1
func A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A) Ctor_O_I_O(c__b__1901000344 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000344 = c__b__1901000344; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A) Invoke_O__O(self any) any { { var i__1901000343__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000343__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000343__1)); var root_2522 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_2523 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2522, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2524 lang.IFn; if linked_2523 == nil { ifn_2524 = lang.IFn_Cast(root_2522) } else { ifn_2524 = nil }; var arg_2525 any = t.F_b__1901000344; var arg_2526 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s8:require ns16: v0.0.0\nreplace ns15: => ./_modules/ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, m__2, nil, m__2, nil, m__2, nil)).Ref(); if linked_2523 == nil { ifn_2524.Invoke_O_O__O(arg_2525, arg_2526) } else { linked_2523.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2522, arg_2525, arg_2526) }; i__1901000343__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000343__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_build_go_print_module_iter__1901000351__1901000355_A_New() *A_arbace_build_go_print_module_iter__1901000351__1901000355_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000351__1901000355_A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_A) Ctor() {}
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_A) Invoke_O_O__O(self, s__1901000352__1 any) any { var tmp1 *lang.Compiler_AOTFn; var fnbody__2075 any = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_New_O_O(self, s__1901000352__1); var tmp2 *jrt.Class; var fncls__2074 *jrt.Class = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_fn_class; if fncls__2074 == nil { var fncls__2074d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_126, false, fnbody__2075); A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_fn_class = fncls__2074d; tmp2 = fncls__2074d } else { tmp2 = fncls__2074 }; tmp1 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2075, tmp2, nil); return lang.LazySeq_New_IFn(Up_Compiler_AOTFn_IFn(tmp1)) }
//line :486:1
func A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A{}; t.Ctor_O_O(p0, p1); return t }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A) Ctor_O_O(c__iter__1901000351, c__s__1901000352 any) { t.F_iter__1901000351 = c__iter__1901000351; t.F_s__1901000352 = c__s__1901000352 }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A) Invoke_O__O(self any) any { { var s__1901000352__1 any; var t_ any = t.F_s__1901000352; t.F_s__1901000352 = nil; s__1901000352__1 = t_; for { var temp__1927000414__auto____2 any; var root_2016 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = s__1901000352__1; if linked_2017 == nil { temp__1927000414__auto____2 = ifn_2018.Invoke_O__O(arg_2019) } else { temp__1927000414__auto____2 = linked_2017.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2016, arg_2019) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000352__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2020 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2020, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2022 lang.IFn; if linked_2021 == nil { ifn_2022 = lang.IFn_Cast(root_2020) } else { ifn_2022 = nil }; var arg_2023 any = s__1901000352__3; if linked_2021 == nil { tmp1 = ifn_2022.Invoke_O__O(arg_2023) } else { tmp1 = linked_2021.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2020, arg_2023) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2024 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2025 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2024, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2026 lang.IFn; if linked_2025 == nil { ifn_2026 = lang.IFn_Cast(root_2024) } else { ifn_2026 = nil }; var arg_2027 any = s__1901000352__3; if linked_2025 == nil { c__1927001037__auto____4 = ifn_2026.Invoke_O__O(arg_2027) } else { c__1927001037__auto____4 = linked_2025.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2024, arg_2027) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000354__6 any; var root_2028 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_2029 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2028, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2030 lang.IFn; if linked_2029 == nil { ifn_2030 = lang.IFn_Cast(root_2028) } else { ifn_2030 = nil }; var arg_2031 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2029 == nil { b__1901000354__6 = ifn_2030.Invoke_O__O(arg_2031) } else { b__1901000354__6 = linked_2029.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2028, arg_2031) }; var tmp2 *lang.Compiler_AOTFn; var fnbody__2038 any = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_New_O_I_O(b__1901000354__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2037 *jrt.Class = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_fn_class; if fncls__2037 == nil { var fncls__2037d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_127, false, fnbody__2038); A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_fn_class = fncls__2037d; tmp3 = fncls__2037d } else { tmp3 = fncls__2037 }; tmp2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2038, tmp3, nil); if jrt.J2g_Truth(Up_Compiler_AOTFn_IFn(tmp2).Invoke__O()) { var root_2039 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2039, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2041 lang.IFn; if linked_2040 == nil { ifn_2041 = lang.IFn_Cast(root_2039) } else { ifn_2041 = nil }; var arg_2042 any; var root_2044 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_2045 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2044, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2046 lang.IFn; if linked_2045 == nil { ifn_2046 = lang.IFn_Cast(root_2044) } else { ifn_2046 = nil }; var arg_2047 any = b__1901000354__6; if linked_2045 == nil { arg_2042 = ifn_2046.Invoke_O__O(arg_2047) } else { arg_2042 = linked_2045.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2044, arg_2047) }; var arg_2043 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000351); var tmp5 any; var root_2048 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2048, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2050 lang.IFn; if linked_2049 == nil { ifn_2050 = lang.IFn_Cast(root_2048) } else { ifn_2050 = nil }; var arg_2051 any = s__1901000352__3; if linked_2049 == nil { tmp5 = ifn_2050.Invoke_O__O(arg_2051) } else { tmp5 = linked_2049.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2048, arg_2051) }; arg_2043 = tmp4.Invoke_O__O(tmp5); if linked_2040 == nil { return ifn_2041.Invoke_O_O__O(arg_2042, arg_2043) } else { return linked_2040.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2039, arg_2042, arg_2043) } } else { var root_2052 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2052, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2054 lang.IFn; if linked_2053 == nil { ifn_2054 = lang.IFn_Cast(root_2052) } else { ifn_2054 = nil }; var arg_2055 any; var root_2057 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2059 lang.IFn; if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = b__1901000354__6; if linked_2058 == nil { arg_2055 = ifn_2059.Invoke_O__O(arg_2060) } else { arg_2055 = linked_2058.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2057, arg_2060) }; var arg_2056 any; if linked_2053 == nil { return ifn_2054.Invoke_O_O__O(arg_2055, arg_2056) } else { return linked_2053.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2052, arg_2055, arg_2056) } } } else { var m__4 any; var root_2061 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2062 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2061, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2063 lang.IFn; if linked_2062 == nil { ifn_2063 = lang.IFn_Cast(root_2061) } else { ifn_2063 = nil }; var arg_2064 any = s__1901000352__3; if linked_2062 == nil { m__4 = ifn_2063.Invoke_O__O(arg_2064) } else { m__4 = linked_2062.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2061, arg_2064) }; var root_2065 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2067 lang.IFn; if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__4, nil)).Ref(); var arg_2069 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000351); var tmp7 any; var root_2070 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = s__1901000352__3; if linked_2071 == nil { tmp7 = ifn_2072.Invoke_O__O(arg_2073) } else { tmp7 = linked_2071.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2070, arg_2073) }; arg_2069 = tmp6.Invoke_O__O(tmp7); if linked_2066 == nil { return ifn_2067.Invoke_O_O__O(arg_2068, arg_2069) } else { return linked_2066.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2065, arg_2068, arg_2069) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :486:1
func A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A) Ctor_O_I_O(c__b__1901000354 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000354 = c__b__1901000354; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A) Invoke_O__O(self any) any { { var i__1901000353__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000353__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000353__1)); var root_2032 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_2033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2032, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2034 lang.IFn; if linked_2033 == nil { ifn_2034 = lang.IFn_Cast(root_2032) } else { ifn_2034 = nil }; var arg_2035 any = t.F_b__1901000354; var arg_2036 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__2, nil)).Ref(); if linked_2033 == nil { ifn_2034.Invoke_O_O__O(arg_2035, arg_2036) } else { linked_2033.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2032, arg_2035, arg_2036) }; i__1901000353__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000353__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_print_module_fn__1901000361_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_print_module_fn__1901000361_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :488:1
func (t *A_arbace_build_go_print_module_fn__1901000361_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :488:1
func (t *A_arbace_build_go_print_module_fn__1901000361_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z_NoInit(Lit_97, A_arbace_build_go_A_const_128.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 jrt.File_I = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_build_go_A_const_128.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__1901000362__3_ any; var tmp2 any = A_arbace_build_go_A_const_145; var tmp3 any; var or__1927000174__auto____3 any = /*line :488:1*/t.F_layout; if

	jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.J2g_Truth(t.F_line_file) { tmp3 = A_arbace_build_go_A_const_155 } else { tmp3 = A_arbace_build_go_A_const_156 } }; G__1901000362__3_ = /*line :488:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.J2g_Truth(t.F_line_file) {
		var root_2088 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2088, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = G__1901000362__3_; var arg_2092 any = A_arbace_build_go_A_const_146; var arg_2093 any = jrt.Boolean_TRUE.Ref(); if linked_2089 == nil { opts__3 = ifn_2090.Invoke_O_O_O__O(arg_2091, arg_2092, arg_2093) } else { opts__3 = linked_2089.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2088, arg_2091, arg_2092, arg_2093) } } else {
//line :490:1
			opts__3 = G__1901000362__3_ }; var test_files__4 any; var root_2094 any = /*line :488:1*/A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2096 lang.IFn; if



	linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any; var root_2098 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_157; var arg_2102 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2099 == nil { arg_2097 = ifn_2100.Invoke_O_O__O(arg_2101, arg_2102) } else { arg_2097 = linked_2099.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2098, arg_2101, arg_2102) }; if linked_2095 == nil { test_files__4 = ifn_2096.Invoke_O__O(arg_2097) } else { test_files__4 = linked_2095.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2094, arg_2097) }; var printable__5 any; var fnbody__2127 any = /*line :488:1*/A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_New_O_O(test_files__4, t.F_tests); var tmp5 *jrt.Class; var fncls__2126 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_fn_class; if
	fncls__2126 == nil { var fncls__2126d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_112, false, fnbody__2127); A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_fn_class = fncls__2126d; tmp5 = fncls__2126d } else { tmp5 = fncls__2126 }; printable__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2127, tmp5, nil); var host_id__6 any = /*line :488:1*/jrt.System_Getenv_String__String(Lit_113).Ref(); var entry__7 any; var tmp6 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.J2g_Truth(and__1927000168__auto____7) { var root_2128 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2129 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2128, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2130 lang.IFn; if linked_2129 == nil { ifn_2130 = lang.IFn_Cast(root_2128) } else { ifn_2130 = nil }; var arg_2131 any = host_id__6; if linked_2129 == nil { tmp6 = ifn_2130.Invoke_O__O(arg_2131) } else { tmp6 = linked_2129.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2128, arg_2131) } } else { tmp6 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp6) { var k__7 any; var root_2132 any = A_arbace_build_go_A_const_159.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, A_arbace_build_go_print_cache_key_A_fn_class); var ifn_2134 lang.IFn
		if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = host_id__6; var arg_2136 any = pkg__1; var arg_2137 any = t.F_dir; var arg_2138 any = opts__3; var arg_2139 any = t.F_tests; if linked_2133 == nil { k__7 = ifn_2134.Invoke_O_O_O_O_O__O(arg_2135, arg_2136, arg_2137, arg_2138, arg_2139) } else { k__7 = linked_2133.(*A_arbace_build_go_print_cache_key_A).Invoke_O_O_O_O_O_O__O(root_2132, arg_2135, arg_2136, arg_2137, arg_2138, arg_2139) }
//line :497:1
		var tmp7 *jrt.Class = A_arbace_build_go_A_const_68; var tmp8 any; var root_2140 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2141 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2140, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2142 lang.IFn

		if linked_2141 == nil { ifn_2142 = lang.IFn_Cast(root_2140) } else { ifn_2142 = nil }; var arg_2143 any = t.F_print_cache; if linked_2141 == nil { tmp8 = ifn_2142.Invoke_O__O(arg_2143) } else { tmp8 = linked_2141.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2140, arg_2143) }
//line :497:1
		var tmp9 *jrt.String = jrt.String_Cast(tmp8); var tmp10 any; var root_2144 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_2145 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2144, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2146 lang.IFn

		if linked_2145 == nil { ifn_2146 = lang.IFn_Cast(root_2144) } else { ifn_2146 = nil }; var arg_2147 any = k__7; var arg_2148 any = A_arbace_build_go_A_const_141; var arg_2149 any = A_arbace_build_go_A_const_160; if linked_2145 == nil { tmp10 = ifn_2146.Invoke_O_O_O__O(arg_2147, arg_2148, arg_2149) } else { tmp10 = linked_2145.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2144, arg_2147, arg_2148, arg_2149) }
//line :497:1
		entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp7, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(tmp9, jrt.String_Cast(tmp10)), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.J2g_Truth(entry__7) { var root_2150 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2151 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2150, A_arbace_build_go_cached_texts_A_fn_class); var ifn_2152 lang.IFn; if linked_2151 == nil { ifn_2152 = lang.IFn_Cast(root_2150) } else { ifn_2152 = nil }; var arg_2153 any = entry__7; if linked_2151 == nil { or__1927000174__auto____8 = ifn_2152.Invoke_O__O(arg_2153) } else { or__1927000174__auto____8 = linked_2151.(*A_arbace_build_go_cached_texts_A).Invoke_O_O__O(root_2150, arg_2153) } } else { or__1927000174__auto____8 = nil }; if jrt.J2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var root_2154 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2155 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2154, aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A_fn_class); var ifn_2156 lang.IFn
		if linked_2155 == nil { ifn_2156 = lang.IFn_Cast(root_2154) } else { ifn_2156 = nil }; var arg_2157 any; var G__1901000369__9_ any; var tmp11 lang.IFn = lang.IFn_Cast(printable__5); var tmp12 any; var root_2163 any = A_arbace_build_go_A_const_164.GetRawRoot__O(); var linked_2164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2163, A_arbace_build_go_collected_package_A_fn_class); var ifn_2165 lang.IFn; if linked_2164 == nil { ifn_2165 = lang.IFn_Cast(root_2163) } else { ifn_2165 = nil }; var arg_2166 any = pkg__1; if linked_2164 == nil { tmp12 = ifn_2165.Invoke_O__O(arg_2166) } else { tmp12 = linked_2164.(*A_arbace_build_go_collected_package_A).Invoke_O_O__O(root_2163, arg_2166) }; G__1901000369__9_ = tmp11.Invoke_O__O(tmp12); if jrt.J2g_Truth(t.F_line_file) { var root_2159 any = A_arbace_build_go_A_const_163.GetRawRoot__O(); var linked_2160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2159, A_arbace_build_go_with_line_files_A_fn_class); var ifn_2161 lang.IFn; if linked_2160 == nil { ifn_2161 = lang.IFn_Cast(root_2159) } else { ifn_2161 = nil }; var arg_2162 any = G__1901000369__9_; if linked_2160 == nil { arg_2157 = ifn_2161.Invoke_O__O(arg_2162) } else { arg_2157 = linked_2160.(*A_arbace_build_go_with_line_files_A).Invoke_O_O__O(root_2159, arg_2162) } } else { arg_2157 = G__1901000369__9_ }; var arg_2158 any = opts__3; if linked_2155 == nil { t__9 = ifn_2156.Invoke_O_O__O(arg_2157, arg_2158) } else { t__9 = linked_2155.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A).Invoke_O_O_O__O(root_2154, arg_2157, arg_2158) }
		if jrt.J2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(entry__7).GetParentFile__File().Mkdirs__Z())
			var root_2208 any = A_arbace_build_go_A_const_167.GetRawRoot__O(); var linked_2209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2208, A_arbace_build_go_cache_texts_BANG__A_fn_class); var ifn_2210 lang.IFn; if linked_2209 == nil { ifn_2210 = lang.IFn_Cast(root_2208) } else { ifn_2210 = nil }; var arg_2211 any = entry__7; var arg_2212 any = t__9; if linked_2209 == nil { ifn_2210.Invoke_O_O__O(arg_2211, arg_2212) } else { linked_2209.(*A_arbace_build_go_cache_texts_BANG__A).Invoke_O_O_O__O(root_2208, arg_2211, arg_2212) } }
//line :500:1
		texts__8 = t__9 }; var declared__9 any; var tmp13 /*line :488:1*/*lang.Keyword = A_arbace_build_go_A_const_143; var temp__1927000414__auto____9 any = tmp13.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if

















	jrt.J2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var root_2167 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_2168 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2167, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2169 lang.IFn
		if linked_2168 == nil { ifn_2169 = lang.IFn_Cast(root_2167) } else { ifn_2169 = nil }; var arg_2170 any = fs__10; var arg_2171 any; if jrt.J2g_Truth(t.F_tests) { var tmp14 *lang.Keyword = A_arbace_build_go_A_const_157; arg_2171 = tmp14.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)) } else { arg_2171 = nil }; if linked_2168 == nil { declared__9 = ifn_2169.Invoke_O_O__O(arg_2170, arg_2171) } else { declared__9 = linked_2168.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2167, arg_2170, arg_2171) } } else {
//line :506:1
			declared__9 = nil }; var rel__10 any; var fnbody__2173 any = /*line :488:1*/A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_New_O(pkg__1); var tmp15 *jrt.Class; var fncls__2172 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_fn_class; if
	fncls__2172 == nil { var fncls__2172d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_114, false, fnbody__2173); A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_fn_class = fncls__2172d; tmp15 = fncls__2172d } else { tmp15 = fncls__2172 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2173, tmp15, nil); var src__11 any; var root_2174 any = /*line :488:1*/A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_2175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2174, A_arbace_build_go_forms_dir_A_fn_class); var ifn_2176 lang.IFn; if




















	linked_2175 == nil { ifn_2176 = lang.IFn_Cast(root_2174) } else { ifn_2176 = nil }; var arg_2177 any = pkg__1; if linked_2175 == nil { src__11 = ifn_2176.Invoke_O__O(arg_2177) } else { src__11 = linked_2175.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_2174, arg_2177) }; var tmp16 any; var and__1927000168__auto____12 any = declared__9; if
	jrt.J2g_Truth(and__1927000168__auto____12) { var root_2213 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2214 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2213, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2215 lang.IFn; if linked_2214 == nil { ifn_2215 = lang.IFn_Cast(root_2213) } else { ifn_2215 = nil }; var arg_2216 any; var root_2218 any = A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_2219 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2218, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2220 lang.IFn; if linked_2219 == nil { ifn_2220 = lang.IFn_Cast(root_2218) } else { ifn_2220 = nil }; var arg_2221 any; var root_2222 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2223 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2222, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2224 lang.IFn; if linked_2223 == nil { ifn_2224 = lang.IFn_Cast(root_2222) } else { ifn_2224 = nil }; var arg_2225 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_2226 any = declared__9; if linked_2223 == nil { arg_2221 = ifn_2224.Invoke_O_O__O(arg_2225, arg_2226) } else { arg_2221 = linked_2223.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2222, arg_2225, arg_2226) }; if linked_2219 == nil { arg_2216 = ifn_2220.Invoke_O__O(arg_2221) } else { arg_2216 = linked_2219.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2218, arg_2221) }; var arg_2217 any; var root_2227 any = A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any; var root_2231 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = texts__8; if linked_2232 == nil { arg_2230 = ifn_2233.Invoke_O__O(arg_2234) } else { arg_2230 = linked_2232.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2231, arg_2234) }; if linked_2228 == nil { arg_2217 = ifn_2229.Invoke_O__O(arg_2230) } else { arg_2217 = linked_2228.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2227, arg_2230) }; if linked_2214 == nil { tmp16 = ifn_2215.Invoke_O_O__O(arg_2216, arg_2217) } else { tmp16 = linked_2214.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2213, arg_2216, arg_2217) } } else { tmp16 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp16) {
		var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp18 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_115, nil, Lit_116, nil); var tmp19 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp20 any = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke_O__O(declared__9); var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()); var tmp22 any; var root_2247 any = A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_2248 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2247, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2249 lang.IFn
		if linked_2248 == nil { ifn_2249 = lang.IFn_Cast(root_2247) } else { ifn_2249 = nil }; var arg_2250 any; var root_2251 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_2252 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2251, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2253 lang.IFn; if linked_2252 == nil { ifn_2253 = lang.IFn_Cast(root_2251) } else { ifn_2253 = nil }; var arg_2254 any = texts__8; if linked_2252 == nil { arg_2250 = ifn_2253.Invoke_O__O(arg_2254) } else { arg_2250 = linked_2252.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2251, arg_2254) }; if linked_2248 == nil { tmp22 = ifn_2249.Invoke_O__O(arg_2250) } else { tmp22 = linked_2248.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2247, arg_2250) }
//line :511:1
		tmp17.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp18, jrt.RefArrayOf(jrt.Object_class, tmp19, nil, tmp20, nil, tmp21.Invoke_O__O(tmp22))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(pdir__2).Mkdirs__Z()); var seq_1901000372__12 any; var root_2255 any = /*line :488:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2255, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2257 lang.IFn; if

























	linked_2256 == nil { ifn_2257 = lang.IFn_Cast(root_2255) } else { ifn_2257 = nil }; var arg_2258 any = texts__8; if linked_2256 == nil { seq_1901000372__12 = ifn_2257.Invoke_O__O(arg_2258) } else { seq_1901000372__12 = linked_2256.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2255, arg_2258) }; var chunk_1901000373__13 any; var count_1901000374__14 int64 = 0; var i_1901000375__15 int64 = 0; L1:
//line :488:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000375__15, count_1901000374__14) { var vec__1901000376__16 any = lang.Indexed_Cast(chunk_1901000373__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000375__15)); var n__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000376__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000376__16, lang.RT_IntCast_J__I_NoInit(1), nil)
			if jrt.File_InstanceOf(text__18) {
				var root_2315 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2315, A_arbace_build_go_copy_file_A_fn_class); var ifn_2317 lang.IFn; if linked_2316 == nil { ifn_2317 = lang.IFn_Cast(root_2315) } else { ifn_2317 = nil }; var arg_2318 any = text__18; var arg_2319 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)); if linked_2316 == nil { ifn_2317.Invoke_O_O__O(arg_2318, arg_2319) } else { linked_2316.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2315, arg_2318, arg_2319) } } else {
					lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18) }
//line :514:1
			seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, i_1901000375__15 = seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000375__15); continue L1 } else { var temp__1927000414__auto____16 any; var root_2259 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2260 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2259, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2261 lang.IFn; if linked_2260 == nil { ifn_2261 = lang.IFn_Cast(root_2259) } else { ifn_2261 = nil }; var arg_2262 any = seq_1901000372__12; if linked_2260 == nil { temp__1927000414__auto____16 = ifn_2261.Invoke_O__O(arg_2262) } else { temp__1927000414__auto____16 = linked_2260.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2259, arg_2262) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1901000372__17 any = temp__1927000414__auto____16; var tmp23 any; var root_2263 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any = seq_1901000372__17; if linked_2264 == nil { tmp23 = ifn_2265.Invoke_O__O(arg_2266) } else { tmp23 = linked_2264.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2263, arg_2266) }; if jrt.J2g_Truth(tmp23) { var c__1927000678__auto____18 any; var root_2267 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2267, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2269 lang.IFn; if linked_2268 == nil { ifn_2269 = lang.IFn_Cast(root_2267) } else { ifn_2269 = nil }; var arg_2270 any = seq_1901000372__17; if linked_2268 == nil { c__1927000678__auto____18 = ifn_2269.Invoke_O__O(arg_2270) } else { c__1927000678__auto____18 = linked_2268.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2267, arg_2270) }; var tmp24 any; var root_2325 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = seq_1901000372__17; if linked_2326 == nil { tmp24 = ifn_2327.Invoke_O__O(arg_2328) } else { tmp24 = linked_2326.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2325, arg_2328) }; seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, i_1901000375__15 = tmp24, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000379__18 any; var root_2271 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2272 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2271, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2273 lang.IFn; if linked_2272 == nil { ifn_2273 = lang.IFn_Cast(root_2271) } else { ifn_2273 = nil }; var arg_2274 any = seq_1901000372__17; if linked_2272 == nil { vec__1901000379__18 = ifn_2273.Invoke_O__O(arg_2274) } else { vec__1901000379__18 = linked_2272.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2271, arg_2274) }; var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000379__18, lang.RT_IntCast_J__I_NoInit(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000379__18, lang.RT_IntCast_J__I_NoInit(1), nil)
				if jrt.File_InstanceOf(text__20) {
					var root_2329 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, A_arbace_build_go_copy_file_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = text__20; var arg_2333 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)); if linked_2330 == nil { ifn_2331.Invoke_O_O__O(arg_2332, arg_2333) } else { linked_2330.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2329, arg_2332, arg_2333) } } else {
						lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20) }
//line :514:1
				var tmp25 any; var root_2339 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2340 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2339, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2341 lang.IFn; if linked_2340 == nil { ifn_2341 = lang.IFn_Cast(root_2339) } else { ifn_2341 = nil }; var arg_2342 any = seq_1901000372__17; if linked_2340 == nil { tmp25 = ifn_2341.Invoke_O__O(arg_2342) } else { tmp25 = linked_2340.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2339, arg_2342) }; seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, i_1901000375__15 = tmp25, nil, 0, 0; continue L1 } } }
//line :488:1
		break L1 }; var seq_1901000382__12 any; var root_2275 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2276 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2275, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2277 lang.IFn; if





























	linked_2276 == nil { ifn_2277 = lang.IFn_Cast(root_2275) } else { ifn_2277 = nil }; var tmp26 *lang.Keyword = A_arbace_build_go_A_const_165; var arg_2278 any = tmp26.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2276 == nil { seq_1901000382__12 = ifn_2277.Invoke_O__O(arg_2278) } else { seq_1901000382__12 = linked_2276.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2275, arg_2278) }; var chunk_1901000383__13 any; var count_1901000384__14 int64 = 0; var i_1901000385__15 int64 = 0; L2:
//line :488:1
	for {





























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000385__15, count_1901000384__14) { var f__16 any = lang.Indexed_Cast(chunk_1901000383__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000385__15)); var root_2343 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2343, A_arbace_build_go_copy_file_A_fn_class); var ifn_2345 lang.IFn
			if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any; var tmp27 jrt.File_I = jrt.File_Cast(src__11); var tmp28 any; var root_2348 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2350 lang.IFn; if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = f__16; if linked_2349 == nil { tmp28 = ifn_2350.Invoke_O__O(arg_2351) } else { tmp28 = linked_2349.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2348, arg_2351) }; arg_2346 = jrt.File_New_File_String(tmp27, jrt.String_Cast(tmp28)); var arg_2347 any; var tmp29 jrt.File_I = jrt.File_Cast(pdir__2); var tmp30 any; var root_2352 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2352, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = f__16; if linked_2353 == nil { tmp30 = ifn_2354.Invoke_O__O(arg_2355) } else { tmp30 = linked_2353.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2352, arg_2355) }; arg_2347 = jrt.File_New_File_String(tmp29, jrt.String_Cast(tmp30)); if linked_2344 == nil { ifn_2345.Invoke_O_O__O(arg_2346, arg_2347) } else { linked_2344.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2343, arg_2346, arg_2347) }
//line :518:1
			seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, i_1901000385__15 = seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000385__15); continue L2 } else { var temp__1927000414__auto____16_2 any; var root_2279 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2280 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2279, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2281 lang.IFn; if linked_2280 == nil { ifn_2281 = lang.IFn_Cast(root_2279) } else { ifn_2281 = nil }; var arg_2282 any = seq_1901000382__12; if linked_2280 == nil { temp__1927000414__auto____16_2 = ifn_2281.Invoke_O__O(arg_2282) } else { temp__1927000414__auto____16_2 = linked_2280.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2279, arg_2282) }; if jrt.J2g_Truth(temp__1927000414__auto____16_2) { var seq_1901000382__17 any = temp__1927000414__auto____16_2; var tmp31 any; var root_2283 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2284 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2283, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2285 lang.IFn; if linked_2284 == nil { ifn_2285 = lang.IFn_Cast(root_2283) } else { ifn_2285 = nil }; var arg_2286 any = seq_1901000382__17; if linked_2284 == nil { tmp31 = ifn_2285.Invoke_O__O(arg_2286) } else { tmp31 = linked_2284.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2283, arg_2286) }; if jrt.J2g_Truth(tmp31) { var c__1927000678__auto____18_2 any; var root_2287 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2288 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2287, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2289 lang.IFn; if linked_2288 == nil { ifn_2289 = lang.IFn_Cast(root_2287) } else { ifn_2289 = nil }; var arg_2290 any = seq_1901000382__17; if linked_2288 == nil { c__1927000678__auto____18_2 = ifn_2289.Invoke_O__O(arg_2290) } else { c__1927000678__auto____18_2 = linked_2288.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2287, arg_2290) }; var tmp32 any; var root_2356 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2356, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2358 lang.IFn; if linked_2357 == nil { ifn_2358 = lang.IFn_Cast(root_2356) } else { ifn_2358 = nil }; var arg_2359 any = seq_1901000382__17; if linked_2357 == nil { tmp32 = ifn_2358.Invoke_O__O(arg_2359) } else { tmp32 = linked_2357.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2356, arg_2359) }; seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, i_1901000385__15 = tmp32, c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var f__18 any; var root_2291 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2292 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2291, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2293 lang.IFn; if linked_2292 == nil { ifn_2293 = lang.IFn_Cast(root_2291) } else { ifn_2293 = nil }; var arg_2294 any = seq_1901000382__17; if linked_2292 == nil { f__18 = ifn_2293.Invoke_O__O(arg_2294) } else { f__18 = linked_2292.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2291, arg_2294) }
				var root_2360 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2361 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2360, A_arbace_build_go_copy_file_A_fn_class); var ifn_2362 lang.IFn; if linked_2361 == nil { ifn_2362 = lang.IFn_Cast(root_2360) } else { ifn_2362 = nil }; var arg_2363 any; var tmp33 jrt.File_I = jrt.File_Cast(src__11); var tmp34 any; var root_2365 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2365, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = f__18; if linked_2366 == nil { tmp34 = ifn_2367.Invoke_O__O(arg_2368) } else { tmp34 = linked_2366.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2365, arg_2368) }; arg_2363 = jrt.File_New_File_String(tmp33, jrt.String_Cast(tmp34)); var arg_2364 any; var tmp35 jrt.File_I = jrt.File_Cast(pdir__2); var tmp36 any; var root_2369 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2370 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2369, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2371 lang.IFn; if linked_2370 == nil { ifn_2371 = lang.IFn_Cast(root_2369) } else { ifn_2371 = nil }; var arg_2372 any = f__18; if linked_2370 == nil { tmp36 = ifn_2371.Invoke_O__O(arg_2372) } else { tmp36 = linked_2370.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2369, arg_2372) }; arg_2364 = jrt.File_New_File_String(tmp35, jrt.String_Cast(tmp36)); if linked_2361 == nil { ifn_2362.Invoke_O_O__O(arg_2363, arg_2364) } else { linked_2361.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2360, arg_2363, arg_2364) }
//line :518:1
				var tmp37 any; var root_2373 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2374 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2373, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2375 lang.IFn; if linked_2374 == nil { ifn_2375 = lang.IFn_Cast(root_2373) } else { ifn_2375 = nil }; var arg_2376 any = seq_1901000382__17; if linked_2374 == nil { tmp37 = ifn_2375.Invoke_O__O(arg_2376) } else { tmp37 = linked_2374.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2373, arg_2376) }; seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, i_1901000385__15 = tmp37, nil, 0, 0; continue L2 } } }
//line :488:1
		break L2 }; var seq_1901000386__12 any; var root_2295 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2296 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2295, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2297 lang.IFn; if































	linked_2296 == nil { ifn_2297 = lang.IFn_Cast(root_2295) } else { ifn_2297 = nil }; var tmp38 *lang.Keyword = A_arbace_build_go_A_const_166; var arg_2298 any = tmp38.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2296 == nil { seq_1901000386__12 = ifn_2297.Invoke_O__O(arg_2298) } else { seq_1901000386__12 = linked_2296.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2295, arg_2298) }; var chunk_1901000387__13 any; var count_1901000388__14 int64 = 0; var i_1901000389__15 int64 = 0; L3:
//line :488:1
	for {































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000389__15, count_1901000388__14) { var vec__1901000390__16 any = lang.Indexed_Cast(chunk_1901000387__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000389__15)); var f__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000390__16, lang.RT_IntCast_J__I_NoInit(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000390__16, lang.RT_IntCast_J__I_NoInit(1), nil); var from__19 any; var tmp39 jrt.File_I = jrt.File_Cast(src__11); var tmp40 any; var root_2377 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2378 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2377, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2379 lang.IFn
			if linked_2378 == nil { ifn_2379 = lang.IFn_Cast(root_2377) } else { ifn_2379 = nil }; var arg_2380 any = f__17; if linked_2378 == nil { tmp40 = ifn_2379.Invoke_O__O(arg_2380) } else { tmp40 = linked_2378.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2377, arg_2380) }
//line :520:1
			from__19 = jrt.File_New_File_String(tmp39, jrt.String_Cast(tmp40))

			if jrt.File_Cast(from__19).IsFile__Z() { } else {
				var tmp41 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp42 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil); var tmp43 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp44 any; var root_2394 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, A_arbace_build_go_rel_path_A_fn_class); var ifn_2396 lang.IFn; if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = t.F_dir; var arg_2398 any = from__19; if linked_2395 == nil { tmp44 = ifn_2396.Invoke_O_O__O(arg_2397, arg_2398) } else { tmp44 = linked_2395.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2394, arg_2397, arg_2398) }; tmp41.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp42, jrt.RefArrayOf(jrt.Object_class, tmp43, nil, tmp44)).Ref()) }
			var tmp45 any; var and__1927000168__auto____20 any = h__18; if jrt.J2g_Truth(and__1927000168__auto____20) { var root_2399 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2400 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2399, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2401 lang.IFn; if linked_2400 == nil { ifn_2401 = lang.IFn_Cast(root_2399) } else { ifn_2401 = nil }; var arg_2402 any; var root_2404 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2404, A_arbace_build_go_sha256_A_fn_class); var ifn_2406 lang.IFn; if linked_2405 == nil { ifn_2406 = lang.IFn_Cast(root_2404) } else { ifn_2406 = nil }; var arg_2407 any = from__19; if linked_2405 == nil { arg_2402 = ifn_2406.Invoke_O__O(arg_2407) } else { arg_2402 = linked_2405.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2404, arg_2407) }; var arg_2403 any; var root_2408 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any = h__18; if linked_2409 == nil { arg_2403 = ifn_2410.Invoke_O__O(arg_2411) } else { arg_2403 = linked_2409.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2408, arg_2411) }; if linked_2400 == nil { tmp45 = ifn_2401.Invoke_O_O__O(arg_2402, arg_2403) } else { tmp45 = linked_2400.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2399, arg_2402, arg_2403) } } else { tmp45 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp45) {
				var tmp46 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp47 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_118, nil, Lit_119, nil, Lit_120, nil); var tmp48 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp49 any; var root_2416 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, A_arbace_build_go_sha256_A_fn_class); var ifn_2418 lang.IFn; if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = from__19; if linked_2417 == nil { tmp49 = ifn_2418.Invoke_O__O(arg_2419) } else { tmp49 = linked_2417.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2416, arg_2419) }; tmp46.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp47, jrt.RefArrayOf(jrt.Object_class, tmp48, nil, f__17, nil, tmp49, nil, h__18)).Ref())
			}
			var root_2381 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2382 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2381, A_arbace_build_go_copy_file_A_fn_class); var ifn_2383 lang.IFn; if linked_2382 == nil { ifn_2383 = lang.IFn_Cast(root_2381) } else { ifn_2383 = nil }; var arg_2384 any = from__19; var arg_2385 any; var tmp50 jrt.File_I = jrt.File_Cast(pdir__2); var tmp51 any; var root_2386 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2387 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2386, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2388 lang.IFn; if linked_2387 == nil { ifn_2388 = lang.IFn_Cast(root_2386) } else { ifn_2388 = nil }; var arg_2389 any = f__17; if linked_2387 == nil { tmp51 = ifn_2388.Invoke_O__O(arg_2389) } else { tmp51 = linked_2387.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2386, arg_2389) }; arg_2385 = jrt.File_New_File_String(tmp50, jrt.String_Cast(tmp51)); if linked_2382 == nil { ifn_2383.Invoke_O_O__O(arg_2384, arg_2385) } else { linked_2382.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2381, arg_2384, arg_2385) }
//line :520:1
			seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, i_1901000389__15 = seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000389__15); continue L3 } else { var temp__1927000414__auto____16_3 any; var root_2299 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2300 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2299, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2301 lang.IFn; if linked_2300 == nil { ifn_2301 = lang.IFn_Cast(root_2299) } else { ifn_2301 = nil }; var arg_2302 any = seq_1901000386__12; if linked_2300 == nil { temp__1927000414__auto____16_3 = ifn_2301.Invoke_O__O(arg_2302) } else { temp__1927000414__auto____16_3 = linked_2300.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2299, arg_2302) }; if jrt.J2g_Truth(temp__1927000414__auto____16_3) { var seq_1901000386__17 any = temp__1927000414__auto____16_3; var tmp52 any; var root_2303 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2304 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2303, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2305 lang.IFn; if linked_2304 == nil { ifn_2305 = lang.IFn_Cast(root_2303) } else { ifn_2305 = nil }; var arg_2306 any = seq_1901000386__17; if linked_2304 == nil { tmp52 = ifn_2305.Invoke_O__O(arg_2306) } else { tmp52 = linked_2304.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2303, arg_2306) }; if jrt.J2g_Truth(tmp52) { var c__1927000678__auto____18_3 any; var root_2307 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2308 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2307, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2309 lang.IFn; if linked_2308 == nil { ifn_2309 = lang.IFn_Cast(root_2307) } else { ifn_2309 = nil }; var arg_2310 any = seq_1901000386__17; if linked_2308 == nil { c__1927000678__auto____18_3 = ifn_2309.Invoke_O__O(arg_2310) } else { c__1927000678__auto____18_3 = linked_2308.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2307, arg_2310) }; var tmp53 any; var root_2420 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2420, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2422 lang.IFn; if linked_2421 == nil { ifn_2422 = lang.IFn_Cast(root_2420) } else { ifn_2422 = nil }; var arg_2423 any = seq_1901000386__17; if linked_2421 == nil { tmp53 = ifn_2422.Invoke_O__O(arg_2423) } else { tmp53 = linked_2421.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2420, arg_2423) }; seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, i_1901000389__15 = tmp53, c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1901000393__18 any; var root_2311 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2311, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2313 lang.IFn; if linked_2312 == nil { ifn_2313 = lang.IFn_Cast(root_2311) } else { ifn_2313 = nil }; var arg_2314 any = seq_1901000386__17; if linked_2312 == nil { vec__1901000393__18 = ifn_2313.Invoke_O__O(arg_2314) } else { vec__1901000393__18 = linked_2312.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2311, arg_2314) }; var f__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000393__18, lang.RT_IntCast_J__I_NoInit(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000393__18, lang.RT_IntCast_J__I_NoInit(1), nil); var from__21 any; var tmp54 jrt.File_I = jrt.File_Cast(src__11); var tmp55 any; var root_2424 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2425 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2424, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2426 lang.IFn
				if linked_2425 == nil { ifn_2426 = lang.IFn_Cast(root_2424) } else { ifn_2426 = nil }; var arg_2427 any = f__19; if linked_2425 == nil { tmp55 = ifn_2426.Invoke_O__O(arg_2427) } else { tmp55 = linked_2425.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2424, arg_2427) }
//line :520:1
				from__21 = jrt.File_New_File_String(tmp54, jrt.String_Cast(tmp55))

				if jrt.File_Cast(from__21).IsFile__Z() { } else {
					var tmp56 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp57 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil); var tmp58 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp59 any; var root_2441 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, A_arbace_build_go_rel_path_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = t.F_dir; var arg_2445 any = from__21; if linked_2442 == nil { tmp59 = ifn_2443.Invoke_O_O__O(arg_2444, arg_2445) } else { tmp59 = linked_2442.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2441, arg_2444, arg_2445) }; tmp56.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp57, jrt.RefArrayOf(jrt.Object_class, tmp58, nil, tmp59)).Ref()) }
				var tmp60 any; var and__1927000168__auto____22 any = h__20; if jrt.J2g_Truth(and__1927000168__auto____22) { var root_2446 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2447 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2446, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2448 lang.IFn; if linked_2447 == nil { ifn_2448 = lang.IFn_Cast(root_2446) } else { ifn_2448 = nil }; var arg_2449 any; var root_2451 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, A_arbace_build_go_sha256_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any = from__21; if linked_2452 == nil { arg_2449 = ifn_2453.Invoke_O__O(arg_2454) } else { arg_2449 = linked_2452.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2451, arg_2454) }; var arg_2450 any; var root_2455 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2456 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2455, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2457 lang.IFn; if linked_2456 == nil { ifn_2457 = lang.IFn_Cast(root_2455) } else { ifn_2457 = nil }; var arg_2458 any = h__20; if linked_2456 == nil { arg_2450 = ifn_2457.Invoke_O__O(arg_2458) } else { arg_2450 = linked_2456.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2455, arg_2458) }; if linked_2447 == nil { tmp60 = ifn_2448.Invoke_O_O__O(arg_2449, arg_2450) } else { tmp60 = linked_2447.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2446, arg_2449, arg_2450) } } else { tmp60 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp60) {
					var tmp61 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp62 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_118, nil, Lit_119, nil, Lit_120, nil); var tmp63 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp64 any; var root_2463 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2463, A_arbace_build_go_sha256_A_fn_class); var ifn_2465 lang.IFn; if linked_2464 == nil { ifn_2465 = lang.IFn_Cast(root_2463) } else { ifn_2465 = nil }; var arg_2466 any = from__21; if linked_2464 == nil { tmp64 = ifn_2465.Invoke_O__O(arg_2466) } else { tmp64 = linked_2464.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2463, arg_2466) }; tmp61.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp62, jrt.RefArrayOf(jrt.Object_class, tmp63, nil, f__19, nil, tmp64, nil, h__20)).Ref())
				}
				var root_2428 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2428, A_arbace_build_go_copy_file_A_fn_class); var ifn_2430 lang.IFn; if linked_2429 == nil { ifn_2430 = lang.IFn_Cast(root_2428) } else { ifn_2430 = nil }; var arg_2431 any = from__21; var arg_2432 any; var tmp65 jrt.File_I = jrt.File_Cast(pdir__2); var tmp66 any; var root_2433 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = f__19; if linked_2434 == nil { tmp66 = ifn_2435.Invoke_O__O(arg_2436) } else { tmp66 = linked_2434.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2433, arg_2436) }; arg_2432 = jrt.File_New_File_String(tmp65, jrt.String_Cast(tmp66)); if linked_2429 == nil { ifn_2430.Invoke_O_O__O(arg_2431, arg_2432) } else { linked_2429.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2428, arg_2431, arg_2432) }
//line :520:1
				var tmp67 any; var root_2467 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2467, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2469 lang.IFn; if linked_2468 == nil { ifn_2469 = lang.IFn_Cast(root_2467) } else { ifn_2469 = nil }; var arg_2470 any = seq_1901000386__17; if linked_2468 == nil { tmp67 = ifn_2469.Invoke_O__O(arg_2470) } else { tmp67 = linked_2468.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2467, arg_2470) }; seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, i_1901000389__15 = tmp67, nil, 0, 0; continue L3 } } }
//line :488:1
		break L3 }; var root_2178 any =







































	A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2179 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2178, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2180 lang.IFn; if linked_2179 == nil { ifn_2180 = lang.IFn_Cast(root_2178) } else { ifn_2180 = nil }; var arg_2181 any = rel__10; var arg_2182 any; var tmp68 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()); var tmp69 any; var root_2189 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_2190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2189, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2191 lang.IFn; if linked_2190 == nil { ifn_2191 = lang.IFn_Cast(root_2189) } else { ifn_2191 = nil }; var arg_2192 any = texts__8; if linked_2190 == nil { tmp69 = ifn_2191.Invoke_O__O(arg_2192) } else { tmp69 = linked_2190.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2189, arg_2192) }; var tmp70 any = tmp69; var tmp71 any; var root_2193 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2194 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2193, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2195 lang.IFn; if linked_2194 == nil { ifn_2195 = lang.IFn_Cast(root_2193) } else { ifn_2195 = nil }; var arg_2196 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp72 *lang.Keyword = A_arbace_build_go_A_const_165; var arg_2197 any = tmp72.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2194 == nil { tmp71 = ifn_2195.Invoke_O_O__O(arg_2196, arg_2197) } else { tmp71 = linked_2194.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2193, arg_2196, arg_2197) }; var tmp73 any = tmp71; var tmp74 any; var root_2198 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2199 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2198, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2200 lang.IFn; if
	linked_2199 == nil { ifn_2200 = lang.IFn_Cast(root_2198) } else { ifn_2200 = nil }; var arg_2201 any; var root_2203 any = A_arbace_build_go_A_const_82.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_2207 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); if linked_2204 == nil { arg_2201 = ifn_2205.Invoke_O_O__O(arg_2206, arg_2207) } else { arg_2201 = linked_2204.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2203, arg_2206, arg_2207) }; var tmp75 *lang.Keyword = A_arbace_build_go_A_const_166; var arg_2202 any = tmp75.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2199 == nil { tmp74 = ifn_2200.Invoke_O_O__O(arg_2201, arg_2202) } else { tmp74 = linked_2199.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2198, arg_2201, arg_2202) }; arg_2182 = /*line :528:1*/tmp68.Invoke_O_O_O__O(tmp70, tmp73, tmp74); if linked_2179 == nil { return ifn_2180.Invoke_O_O__O(arg_2181, arg_2182) } else { return linked_2179.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2178, arg_2181, arg_2182) } }
//line :489:1
func A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A) Ctor_O_O(c__test_files, c__tests any) { t.F_test_files = c__test_files; t.F_tests = c__tests }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A) Invoke_O_O__O(self, p1__1901000329_SHARP___1 any) any {



	if jrt.J2g_Truth(t.F_tests) { return p1__1901000329_SHARP___1 } else {

		var root_2103 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_2104 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2103, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2105 lang.IFn; if linked_2104 == nil { ifn_2105 = lang.IFn_Cast(root_2103) } else { ifn_2105 = nil }; var arg_2106 any = p1__1901000329_SHARP___1; var arg_2107 any = A_arbace_build_go_A_const_143; var arg_2108 any; var fnbody__2125 any = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_New_O(t.F_test_files); var tmp1 *jrt.Class; var fncls__2124 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_fn_class; if fncls__2124 == nil { var fncls__2124d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_121, false, fnbody__2125); A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_fn_class = fncls__2124d; tmp1 = fncls__2124d } else { tmp1 = fncls__2124 }; arg_2108 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2125, tmp1, nil); if linked_2104 == nil { return ifn_2105.Invoke_O_O_O__O(arg_2106, arg_2107, arg_2108) } else { return linked_2104.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_2103, arg_2106, arg_2107, arg_2108) } } }
//line :489:1
func A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A{}; t.Ctor_O(p0); return t }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A) Invoke_O_O__O(self, p1__1901000330_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_97, A_arbace_build_go_A_const_128.Invoke_O__O(t.F_pkg)) { return p1__1901000330_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_123, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_128.Invoke_O__O(t.F_pkg), nil, p1__1901000330_SHARP___1)).Ref() } }
//line :495:1
func A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A{}; t.Ctor_O(p0); return t }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A) Invoke_O_O__O(self, fs__1 any) any { var root_2109 any = A_arbace_build_go_A_const_158.GetRawRoot__O(); var linked_2110 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2109, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_2111 lang.IFn; if linked_2110 == nil { ifn_2111 = lang.IFn_Cast(root_2109) } else { ifn_2111 = nil }; var arg_2112 any; var fnbody__2123 any = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_New_O(t.F_test_files); var tmp1 *jrt.Class; var fncls__2122 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_fn_class; if fncls__2122 == nil { var fncls__2122d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_122, false, fnbody__2123); A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_fn_class = fncls__2122d; tmp1 = fncls__2122d } else { tmp1 = fncls__2122 }; arg_2112 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2123, tmp1, nil); var arg_2113 any = fs__1; if linked_2110 == nil { return ifn_2111.Invoke_O_O__O(arg_2112, arg_2113) } else { return linked_2110.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_2109, arg_2112, arg_2113) } }
//line :495:1
func A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A{}; t.Ctor_O(p0); return t }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A) Invoke_O_O__O(self, f__1 any) any { var root_2114 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2115 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2114, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2116 lang.IFn; if linked_2115 == nil { ifn_2116 = lang.IFn_Cast(root_2114) } else { ifn_2116 = nil }; var arg_2117 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); var tmp2 any; var root_2118 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2118, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2120 lang.IFn; if linked_2119 == nil { ifn_2120 = lang.IFn_Cast(root_2118) } else { ifn_2120 = nil }; var arg_2121 any = A_arbace_build_go_A_const_36.Invoke_O__O(f__1); if linked_2119 == nil { tmp2 = ifn_2120.Invoke_O__O(arg_2121) } else { tmp2 = linked_2119.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2118, arg_2121) }; arg_2117 = tmp1.Invoke_O__O(tmp2); if linked_2115 == nil { return ifn_2116.Invoke_O__O(arg_2117) } else { return linked_2115.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2114, arg_2117) } }







































func A_arbace_build_go_delete_tree_A_New() *A_arbace_build_go_delete_tree_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_delete_tree_A{}; t.Ctor(); return t }
//line :535:1
func (t *A_arbace_build_go_delete_tree_A) Ctor() {}
//line :535:1
func (t *A_arbace_build_go_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.File_Cast(f__0).IsDirectory__Z() { var seq_1901000398__2 any; var root_2603 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2604 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2603, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2605 lang.IFn
		if linked_2604 == nil { ifn_2605 = lang.IFn_Cast(root_2603) } else { ifn_2605 = nil }; var arg_2606 any = jrt.File_Cast(f__0).ListFiles__File1().Ref(); if linked_2604 == nil { seq_1901000398__2 = ifn_2605.Invoke_O__O(arg_2606) } else { seq_1901000398__2 = linked_2604.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2603, arg_2606) }
//line :536:1
		var chunk_1901000399__3 any; var count_1901000400__4 int64 = 0; var i_1901000401__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000401__5, count_1901000400__4) { var c__6 any = lang.Indexed_Cast(chunk_1901000399__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000401__5)); var root_2623 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2623, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2625 lang.IFn; if linked_2624 == nil { ifn_2625 = lang.IFn_Cast(root_2623) } else { ifn_2625 = nil }; var arg_2626 any = c__6; if linked_2624 == nil { ifn_2625.Invoke_O__O(arg_2626) } else { linked_2624.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2623, arg_2626) }; seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, i_1901000401__5 = seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000401__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_2607 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2607, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2609 lang.IFn; if linked_2608 == nil { ifn_2609 = lang.IFn_Cast(root_2607) } else { ifn_2609 = nil }; var arg_2610 any = seq_1901000398__2; if linked_2608 == nil { temp__1927000414__auto____6 = ifn_2609.Invoke_O__O(arg_2610) } else { temp__1927000414__auto____6 = linked_2608.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2607, arg_2610) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1901000398__7 any = temp__1927000414__auto____6; var tmp1 any; var root_2611 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2612 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2611, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2613 lang.IFn; if linked_2612 == nil { ifn_2613 = lang.IFn_Cast(root_2611) } else { ifn_2613 = nil }; var arg_2614 any = seq_1901000398__7; if linked_2612 == nil { tmp1 = ifn_2613.Invoke_O__O(arg_2614) } else { tmp1 = linked_2612.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2611, arg_2614) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_2615 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2616 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2615, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2617 lang.IFn; if linked_2616 == nil { ifn_2617 = lang.IFn_Cast(root_2615) } else { ifn_2617 = nil }; var arg_2618 any = seq_1901000398__7; if linked_2616 == nil { c__1927000678__auto____8 = ifn_2617.Invoke_O__O(arg_2618) } else { c__1927000678__auto____8 = linked_2616.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2615, arg_2618) }; var tmp2 any; var root_2627 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2627, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2629 lang.IFn; if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any = seq_1901000398__7; if linked_2628 == nil { tmp2 = ifn_2629.Invoke_O__O(arg_2630) } else { tmp2 = linked_2628.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2627, arg_2630) }; seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, i_1901000401__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_2619 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2619, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2621 lang.IFn; if linked_2620 == nil { ifn_2621 = lang.IFn_Cast(root_2619) } else { ifn_2621 = nil }; var arg_2622 any = seq_1901000398__7; if linked_2620 == nil { c__8 = ifn_2621.Invoke_O__O(arg_2622) } else { c__8 = linked_2620.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2619, arg_2622) }; var root_2631 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2632 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2631, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2633 lang.IFn; if linked_2632 == nil { ifn_2633 = lang.IFn_Cast(root_2631) } else { ifn_2633 = nil }; var arg_2634 any = c__8; if linked_2632 == nil { ifn_2633.Invoke_O__O(arg_2634) } else { linked_2632.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2631, arg_2634) }; var tmp3 any; var root_2635 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2636 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2635, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2637 lang.IFn; if linked_2636 == nil { ifn_2637 = lang.IFn_Cast(root_2635) } else { ifn_2637 = nil }; var arg_2638 any = seq_1901000398__7; if linked_2636 == nil { tmp3 = ifn_2637.Invoke_O__O(arg_2638) } else { tmp3 = linked_2636.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2635, arg_2638) }; seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, i_1901000401__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :536:1
			break L1
		} }
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_Cast(f__0).Delete__Z()).Ref()
}
func A_arbace_build_go_build_A_New() *A_arbace_build_go_build_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_build_A{}; t.Ctor(); return t }
//line :540:1
func (t *A_arbace_build_go_build_A) Ctor() {}
//line :540:1
func (t *A_arbace_build_go_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__1901000403__3 any) any { var map__1901000404__5 any = p__1901000403__3; var map__1901000404__6 any; if lang.ISeq_InstanceOf(map__1901000404__5) { var tmp1 any; var root_2639 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2640 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2639, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2641 lang.IFn; if linked_2640 == nil { ifn_2641 = lang.IFn_Cast(root_2639) } else { ifn_2641 = nil }; var arg_2642 any = map__1901000404__5; if linked_2640 == nil { tmp1 = ifn_2641.Invoke_O__O(arg_2642) } else { tmp1 = linked_2640.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2639, arg_2642) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2643 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_2644 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2643, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2645 lang.IFn; if linked_2644 == nil { ifn_2645 = lang.IFn_Cast(root_2643) } else { ifn_2645 = nil }; var arg_2646 any = map__1901000404__5; if linked_2644 == nil { tmp2 = ifn_2645.Invoke_O__O(arg_2646) } else { tmp2 = linked_2644.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2643, arg_2646) }; map__1901000404__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2647 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2648 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2647, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2649 lang.IFn; if linked_2648 == nil { ifn_2649 = lang.IFn_Cast(root_2647) } else { ifn_2649 = nil }; var arg_2650 any = map__1901000404__5; if linked_2648 == nil { tmp3 = ifn_2649.Invoke_O__O(arg_2650) } else { tmp3 = linked_2648.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2647, arg_2650) }; if jrt.J2g_Truth(tmp3) { var root_2651 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2652 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2651, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2653 lang.IFn; if linked_2652 == nil { ifn_2653 = lang.IFn_Cast(root_2651) } else { ifn_2653 = nil }; var arg_2654 any = map__1901000404__5; if linked_2652 == nil { map__1901000404__6 = ifn_2653.Invoke_O__O(arg_2654) } else { map__1901000404__6 = linked_2652.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2651, arg_2654) } } else { map__1901000404__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000404__6 = map__1901000404__5 }; var opts__7 any = map__1901000404__6; var work__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000404__6, A_arbace_build_go_A_const_171); var goroot__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000404__6, A_arbace_build_go_A_const_152); var prog__10 any; var root_2655 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_2656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2655, A_arbace_build_go_program_A_fn_class); var ifn_2657 lang.IFn; if



	linked_2656 == nil { ifn_2657 = lang.IFn_Cast(root_2655) } else { ifn_2657 = nil }; var arg_2658 any = dir__0; var arg_2659 any = goroot__9; var arg_2660 any = opts__7; if linked_2656 == nil { prog__10 = ifn_2657.Invoke_O_O_O__O(arg_2658, arg_2659, arg_2660) } else { prog__10 = linked_2656.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2655, arg_2658, arg_2659, arg_2660) }; var main__11 any = /*line :540:1*/A_arbace_build_go_A_const_137.Invoke_O__O(prog__10); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_172; var config__12 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z_NoInit(work__8, nil); var work__14 any; if







	jrt.J2g_Truth(work__8) { var tmp5 any; var root_2661 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2662 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2661, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2663 lang.IFn
		if linked_2662 == nil { ifn_2663 = lang.IFn_Cast(root_2661) } else { ifn_2663 = nil }; var arg_2664 any = work__8; if linked_2662 == nil { tmp5 = ifn_2663.Invoke_O__O(arg_2664) } else { tmp5 = linked_2662.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2661, arg_2664) }
//line :548:1
		work__14 = jrt.File_New_String(jrt.String_Cast(tmp5)) } else {

			var tmp6 *jrt.String = Lit_28; var tmp7 any; var root_2665 any = A_arbace_build_go_A_const_173.GetRawRoot__O(); var linked_2666 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2665, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_2667 lang.IFn; if linked_2666 == nil { ifn_2667 = lang.IFn_Cast(root_2665) } else { ifn_2667 = nil }; var arg_2668 any = A_arbace_build_go_A_const_174; var arg_2669 any = A_arbace_build_go_A_const_141; if linked_2666 == nil { tmp7 = ifn_2667.Invoke_O_O__O(arg_2668, arg_2669) } else { tmp7 = linked_2666.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_2665, arg_2668, arg_2669) }; work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(tmp6, jrt.RefArray_Cast(tmp7, jrt.FileAttribute_class)).ToFile__File() }; var tmp8 any; tmp23 := /*line :540:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_25)












				if jrt.File_Cast(mod__17).Exists__Z() { var root_2724 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2724, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2726 lang.IFn; if linked_2725 == nil { ifn_2726 = lang.IFn_Cast(root_2724) } else { ifn_2726 = nil }; var arg_2727 any = mod__17; if linked_2725 == nil { ifn_2726.Invoke_O__O(arg_2727) } else { linked_2725.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2724, arg_2727) } }
				var root_2728 any = A_arbace_build_go_A_const_181.GetRawRoot__O(); var linked_2729 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2728, A_arbace_build_go_print_module_A_fn_class); var ifn_2730 lang.IFn; if linked_2729 == nil { ifn_2730 = lang.IFn_Cast(root_2728) } else { ifn_2730 = nil }; var arg_2731 any = prog__10; var arg_2732 any = dir__0; var arg_2733 any = mod__17; var arg_2734 any = opts__7; if linked_2729 == nil { ifn_2730.Invoke_O_O_O_O__O(arg_2731, arg_2732, arg_2733, arg_2734) } else { linked_2729.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2728, arg_2731, arg_2732, arg_2733, arg_2734) }
//line :540:1
				var tags__18 any = A_arbace_build_go_A_const_175.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_151.Invoke_O__O(opts__7), Lit_29); var cmd__20 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_31, Lit_32, Lit_33); var tmp11 lang.IPersistentVector; var tmp12 any; var root_2680 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2682 lang.IFn

















				if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = tags__18; if linked_2681 == nil { tmp12 = ifn_2682.Invoke_O__O(arg_2683) } else { tmp12 = linked_2681.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2680, arg_2683) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_2684 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = Lit_35; var arg_2688 any = tags__18; if linked_2685 == nil { tmp13 = ifn_2686.Invoke_O_O__O(arg_2687, arg_2688) } else { tmp13 = linked_2685.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2684, arg_2687, arg_2688) }; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_34, tmp13) } else { tmp11 = nil }
//line :557:1
				var tmp14 any = tmp11; var tmp15 lang.IPersistentVector

				if tamago_QMARK___19 { tmp15 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, A_arbace_build_go_A_const_176.GetRawRoot__O()) } else { tmp15 = nil }
//line :557:1
				var tmp16 any = tmp15; var tmp17 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_build_go_A_const_177.Invoke_O__O(opts__7)


				if jrt.J2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; var tmp18 any; var root_2689 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2689, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2691 lang.IFn
					if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any = o__21; if linked_2690 == nil { tmp18 = ifn_2691.Invoke_O__O(arg_2692) } else { tmp18 = linked_2690.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2689, arg_2692) }
//line :560:1
					tmp17 = lang.Tuple_Create_O_O__IPersistentVector(Lit_37, jrt.File_New_String(jrt.String_Cast(tmp18)).GetAbsoluteFile__File().GetPath__String().Ref()) } else { tmp17 = nil }
//line :557:1
				var tmp19 any = tmp17; var tmp20 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_build_go_A_const_178.Invoke_O__O(opts__7)




				if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; var tmp21 any; var root_2693 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2694 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2693, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2695 lang.IFn
					if linked_2694 == nil { ifn_2695 = lang.IFn_Cast(root_2693) } else { ifn_2695 = nil }; var arg_2696 any = f__21; if linked_2694 == nil { tmp21 = ifn_2695.Invoke_O__O(arg_2696) } else { tmp21 = linked_2694.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2693, arg_2696) }
//line :562:1
					tmp20 = lang.Tuple_Create_O_O__IPersistentVector(Lit_38, jrt.File_New_String(jrt.String_Cast(tmp21)).GetAbsoluteFile__File().GetPath__String().Ref()) } else { tmp20 = nil }
//line :557:1
				cmd__20 = tmp9.Invoke_O_O_O_O_O_O_O__O(tmp10, tmp14, tmp16, tmp19, tmp20, A_arbace_build_go_A_const_179.Invoke_O__O(opts__7), lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.File_Cast(out__2).GetAbsoluteFile__File().GetPath__String().Ref(), A_arbace_build_go_A_const_48.Invoke_O__O(main__11)))
//line :540:1
				var env__21 any; var G__1901000409__21_ any; var root_2697 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_2698 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2697, A_arbace_build_go_go_env_A_fn_class); var ifn_2699 lang.IFn

























				if linked_2698 == nil { ifn_2699 = lang.IFn_Cast(root_2697) } else { ifn_2699 = nil }; var arg_2700 any = goroot__9; var arg_2701 any = arch__1; var arg_2702 any; var or__1927000174__auto____21 any = A_arbace_build_go_A_const_151.Invoke_O__O(opts__7); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_2702 = or__1927000174__auto____21 } else { arg_2702 = Lit_39 }; if linked_2698 == nil { G__1901000409__21_ = ifn_2699.Invoke_O_O_O__O(arg_2700, arg_2701, arg_2702) } else { G__1901000409__21_ = linked_2698.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_2697, arg_2700, arg_2701, arg_2702) }; var tmp22 any; var root_2703 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2704 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2703, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2705 lang.IFn
				if linked_2704 == nil { ifn_2705 = lang.IFn_Cast(root_2703) } else { ifn_2705 = nil }; var arg_2706 any = A_arbace_build_go_A_const_180.Invoke_O__O(config__12); if linked_2704 == nil { tmp22 = ifn_2705.Invoke_O__O(arg_2706) } else { tmp22 = linked_2704.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2703, arg_2706) }
//line :566:1
				if jrt.J2g_Truth(tmp22) {
					var root_2707 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = G__1901000409__21_; var arg_2711 any = Lit_40; var arg_2712 any = A_arbace_build_go_A_const_180.Invoke_O__O(config__12); if linked_2708 == nil { env__21 = ifn_2709.Invoke_O_O_O__O(arg_2710, arg_2711, arg_2712) } else { env__21 = linked_2708.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2707, arg_2710, arg_2711, arg_2712) } } else {
//line :566:1
						env__21 = G__1901000409__21_ }
//line :540:1
				var vec__1901000406__22 any; var root_2713 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_2714 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2713, A_arbace_build_go_run_A_fn_class); var ifn_2715 lang.IFn



























				if linked_2714 == nil { ifn_2715 = lang.IFn_Cast(root_2713) } else { ifn_2715 = nil }; var arg_2716 any = cmd__20; var arg_2717 any = mod__17; var arg_2718 any = env__21; var arg_2719 any = jrt.Boolean_TRUE.Ref(); if linked_2714 == nil { vec__1901000406__22 = ifn_2715.Invoke_O_O_O_O__O(arg_2716, arg_2717, arg_2718, arg_2719) } else { vec__1901000406__22 = linked_2714.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_2713, arg_2716, arg_2717, arg_2718, arg_2719) }
//line :540:1
				var status__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000406__22, lang.RT_IntCast_J__I_NoInit(0), nil); tmp8 = status__23 }; return nil }(); if tmp_QMARK___13 {






























					var root_2720 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2721 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2720, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2722 lang.IFn; if linked_2721 == nil { ifn_2722 = lang.IFn_Cast(root_2720) } else { ifn_2722 = nil }; var arg_2723 any = work__14; if linked_2721 == nil { ifn_2722.Invoke_O__O(arg_2723) } else { linked_2721.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2720, arg_2723) } }; if /*line :540:1*/ tmp23 != nil { panic(tmp23) }; return tmp8 }
































func A_arbace_build_go__main_A_New() *A_arbace_build_go__main_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_build_go__main_A) Ctor() {}
//line :573:1
func (t *A_arbace_build_go__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :573:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_182, Lit_5, A_arbace_build_go_A_const_152, goroot__2)); L1: for { var G__1901000411__6_ any; var root_2735 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2736 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2735, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2737 lang.IFn




		if linked_2736 == nil { ifn_2737 = lang.IFn_Cast(root_2735) } else { ifn_2737 = nil }; var arg_2738 any = as__4; if linked_2736 == nil { G__1901000411__6_ = ifn_2737.Invoke_O__O(arg_2738) } else { G__1901000411__6_ = linked_2736.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2735, arg_2738) }; switch lang.Util_Hash_O__I_NoInit(G__1901000411__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_6) {












			var tmp1 any; var root_2811 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2812 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2811, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2813 lang.IFn; if linked_2812 == nil { ifn_2813 = lang.IFn_Cast(root_2811) } else { ifn_2813 = nil }; var arg_2814 any = as__4; if linked_2812 == nil { tmp1 = ifn_2813.Invoke_O__O(arg_2814) } else { tmp1 = linked_2812.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2811, arg_2814) }; var tmp2 any = tmp1; var tmp3 any; var root_2815 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2816 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2815, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2817 lang.IFn; if linked_2816 == nil { ifn_2817 = lang.IFn_Cast(root_2815) } else { ifn_2817 = nil }; var arg_2818 any = opts__5; var arg_2819 any = A_arbace_build_go_A_const_124; var arg_2820 any; var root_2821 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2821, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2823 lang.IFn; if linked_2822 == nil { ifn_2823 = lang.IFn_Cast(root_2821) } else { ifn_2823 = nil }; var arg_2824 any = as__4; if linked_2822 == nil { arg_2820 = ifn_2823.Invoke_O__O(arg_2824) } else { arg_2820 = linked_2822.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2821, arg_2824) }; if linked_2816 == nil { tmp3 = ifn_2817.Invoke_O_O_O__O(arg_2818, arg_2819, arg_2820) } else { tmp3 = linked_2816.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2815, arg_2818, arg_2819, arg_2820) }; as__4, opts__5 = tmp2, tmp3; continue L1 }
//line :578:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_7) {










			var tmp4 any; var root_2825 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2826 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2825, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2827 lang.IFn; if linked_2826 == nil { ifn_2827 = lang.IFn_Cast(root_2825) } else { ifn_2827 = nil }; var arg_2828 any = as__4; if linked_2826 == nil { tmp4 = ifn_2827.Invoke_O__O(arg_2828) } else { tmp4 = linked_2826.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2825, arg_2828) }; var tmp5 any = tmp4; var tmp6 any; var root_2829 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2830 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2829, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2831 lang.IFn; if linked_2830 == nil { ifn_2831 = lang.IFn_Cast(root_2829) } else { ifn_2831 = nil }; var arg_2832 any = opts__5; var arg_2833 any = A_arbace_build_go_A_const_183; var arg_2834 any = jrt.Boolean_TRUE.Ref(); if linked_2830 == nil { tmp6 = ifn_2831.Invoke_O_O_O__O(arg_2832, arg_2833, arg_2834) } else { tmp6 = linked_2830.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2829, arg_2832, arg_2833, arg_2834) }; as__4, opts__5 = tmp5, tmp6; continue L1 }
//line :578:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_8) {











			var tmp7 any; var root_2835 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2835, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2837 lang.IFn; if linked_2836 == nil { ifn_2837 = lang.IFn_Cast(root_2835) } else { ifn_2837 = nil }; var arg_2838 any = as__4; if linked_2836 == nil { tmp7 = ifn_2837.Invoke_O__O(arg_2838) } else { tmp7 = linked_2836.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2835, arg_2838) }; var tmp8 any = tmp7; var tmp9 any; var root_2839 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2840 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2839, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2841 lang.IFn; if linked_2840 == nil { ifn_2841 = lang.IFn_Cast(root_2839) } else { ifn_2841 = nil }; var arg_2842 any = opts__5; var arg_2843 any = A_arbace_build_go_A_const_150; var arg_2844 any = jrt.Boolean_TRUE.Ref(); if linked_2840 == nil { tmp9 = ifn_2841.Invoke_O_O_O__O(arg_2842, arg_2843, arg_2844) } else { tmp9 = linked_2840.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2839, arg_2842, arg_2843, arg_2844) }; as__4, opts__5 = tmp8, tmp9; continue L1 }
//line :578:1
		case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_9) {






			var tmp10 any; var root_2845 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2846 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2845, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2847 lang.IFn; if linked_2846 == nil { ifn_2847 = lang.IFn_Cast(root_2845) } else { ifn_2847 = nil }; var arg_2848 any = as__4; if linked_2846 == nil { tmp10 = ifn_2847.Invoke_O__O(arg_2848) } else { tmp10 = linked_2846.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2845, arg_2848) }; var tmp11 any = tmp10; var tmp12 any; var root_2849 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2850 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2849, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2851 lang.IFn; if linked_2850 == nil { ifn_2851 = lang.IFn_Cast(root_2849) } else { ifn_2851 = nil }; var arg_2852 any = opts__5; var arg_2853 any = A_arbace_build_go_A_const_171; var arg_2854 any; var root_2855 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2855, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2857 lang.IFn; if linked_2856 == nil { ifn_2857 = lang.IFn_Cast(root_2855) } else { ifn_2857 = nil }; var arg_2858 any = as__4; if linked_2856 == nil { arg_2854 = ifn_2857.Invoke_O__O(arg_2858) } else { arg_2854 = linked_2856.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2855, arg_2858) }; if linked_2850 == nil { tmp12 = ifn_2851.Invoke_O_O_O__O(arg_2852, arg_2853, arg_2854) } else { tmp12 = linked_2850.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2849, arg_2852, arg_2853, arg_2854) }; as__4, opts__5 = tmp11, tmp12; continue L1 }
//line :578:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_10) {




			var tmp13 any; var root_2859 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2860 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2859, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2861 lang.IFn; if linked_2860 == nil { ifn_2861 = lang.IFn_Cast(root_2859) } else { ifn_2861 = nil }; var arg_2862 any = as__4; if linked_2860 == nil { tmp13 = ifn_2861.Invoke_O__O(arg_2862) } else { tmp13 = linked_2860.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2859, arg_2862) }; var tmp14 any = tmp13; var tmp15 any; var root_2863 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2864 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2863, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2865 lang.IFn; if linked_2864 == nil { ifn_2865 = lang.IFn_Cast(root_2863) } else { ifn_2865 = nil }; var arg_2866 any = opts__5; var arg_2867 any = A_arbace_build_go_A_const_145; var arg_2868 any; var root_2869 any = A_arbace_build_go_A_const_196.GetRawRoot__O(); var linked_2870 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2869, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2871 lang.IFn; if linked_2870 == nil { ifn_2871 = lang.IFn_Cast(root_2869) } else { ifn_2871 = nil }; var arg_2872 any; var root_2873 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2873, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2875 lang.IFn; if linked_2874 == nil { ifn_2875 = lang.IFn_Cast(root_2873) } else { ifn_2875 = nil }; var arg_2876 any = as__4; if linked_2874 == nil { arg_2872 = ifn_2875.Invoke_O__O(arg_2876) } else { arg_2872 = linked_2874.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2873, arg_2876) }; if linked_2870 == nil { arg_2868 = ifn_2871.Invoke_O__O(arg_2872) } else { arg_2868 = linked_2870.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2869, arg_2872) }; if linked_2864 == nil { tmp15 = ifn_2865.Invoke_O_O_O__O(arg_2866, arg_2867, arg_2868) } else { tmp15 = linked_2864.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2863, arg_2866, arg_2867, arg_2868) }; as__4, opts__5 = tmp14, tmp15; continue L1 }
//line :578:1
		case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_11) {














			var tmp16 any; var root_2877 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2877, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2879 lang.IFn; if linked_2878 == nil { ifn_2879 = lang.IFn_Cast(root_2877) } else { ifn_2879 = nil }; var arg_2880 any = as__4; if linked_2878 == nil { tmp16 = ifn_2879.Invoke_O__O(arg_2880) } else { tmp16 = linked_2878.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2877, arg_2880) }; var tmp17 any = tmp16; var tmp18 any; var root_2881 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var arg_2884 any = opts__5; var arg_2885 any = A_arbace_build_go_A_const_153; var arg_2886 any; var root_2887 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2887, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2889 lang.IFn; if linked_2888 == nil { ifn_2889 = lang.IFn_Cast(root_2887) } else { ifn_2889 = nil }; var arg_2890 any = as__4; if linked_2888 == nil { arg_2886 = ifn_2889.Invoke_O__O(arg_2890) } else { arg_2886 = linked_2888.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2887, arg_2890) }; if linked_2882 == nil { tmp18 = ifn_2883.Invoke_O_O_O__O(arg_2884, arg_2885, arg_2886) } else { tmp18 = linked_2882.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2881, arg_2884, arg_2885, arg_2886) }; as__4, opts__5 = tmp17, tmp18; continue L1 }
//line :578:1
		case 30: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_12) {



			var tmp19 any; var root_2891 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = as__4; if linked_2892 == nil { tmp19 = ifn_2893.Invoke_O__O(arg_2894) } else { tmp19 = linked_2892.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2891, arg_2894) }; var tmp20 any = tmp19; var tmp21 any; var root_2895 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = opts__5; var arg_2899 any = A_arbace_build_go_A_const_184; var arg_2900 any; var root_2901 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2901, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2903 lang.IFn; if linked_2902 == nil { ifn_2903 = lang.IFn_Cast(root_2901) } else { ifn_2903 = nil }; var arg_2904 any = as__4; if linked_2902 == nil { arg_2900 = ifn_2903.Invoke_O__O(arg_2904) } else { arg_2900 = linked_2902.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2901, arg_2904) }; if linked_2896 == nil { tmp21 = ifn_2897.Invoke_O_O_O__O(arg_2898, arg_2899, arg_2900) } else { tmp21 = linked_2896.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2895, arg_2898, arg_2899, arg_2900) }; as__4, opts__5 = tmp20, tmp21; continue L1 }
//line :578:1
		case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_13) {
			var tmp22 any; var root_2905 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2907 lang.IFn; if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any = as__4; if linked_2906 == nil { tmp22 = ifn_2907.Invoke_O__O(arg_2908) } else { tmp22 = linked_2906.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2905, arg_2908) }; var tmp23 any = tmp22; var tmp24 any; var root_2909 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2909, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2911 lang.IFn; if linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var arg_2912 any = opts__5; var arg_2913 any = A_arbace_build_go_A_const_182; var arg_2914 any; var root_2915 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2916 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2915, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2917 lang.IFn; if linked_2916 == nil { ifn_2917 = lang.IFn_Cast(root_2915) } else { ifn_2917 = nil }; var arg_2918 any = as__4; if linked_2916 == nil { arg_2914 = ifn_2917.Invoke_O__O(arg_2918) } else { arg_2914 = linked_2916.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2915, arg_2918) }; if linked_2910 == nil { tmp24 = ifn_2911.Invoke_O_O_O__O(arg_2912, arg_2913, arg_2914) } else { tmp24 = linked_2910.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2909, arg_2912, arg_2913, arg_2914) }; as__4, opts__5 = tmp23, tmp24; continue L1 }
//line :578:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_14) {





			var tmp25 any; var root_2919 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = as__4; if linked_2920 == nil { tmp25 = ifn_2921.Invoke_O__O(arg_2922) } else { tmp25 = linked_2920.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2919, arg_2922) }; var tmp26 any = tmp25; var tmp27 any; var root_2923 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2924 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2923, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2925 lang.IFn; if linked_2924 == nil { ifn_2925 = lang.IFn_Cast(root_2923) } else { ifn_2925 = nil }; var arg_2926 any = opts__5; var arg_2927 any = A_arbace_build_go_A_const_146; var arg_2928 any = jrt.Boolean_TRUE.Ref(); if linked_2924 == nil { tmp27 = ifn_2925.Invoke_O_O_O__O(arg_2926, arg_2927, arg_2928) } else { tmp27 = linked_2924.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2923, arg_2926, arg_2927, arg_2928) }; as__4, opts__5 = tmp26, tmp27; continue L1 }
//line :578:1
		case 38: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_15) {

			var tmp28 any; var root_2929 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2929, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2931 lang.IFn; if linked_2930 == nil { ifn_2931 = lang.IFn_Cast(root_2929) } else { ifn_2931 = nil }; var arg_2932 any = as__4; if linked_2930 == nil { tmp28 = ifn_2931.Invoke_O__O(arg_2932) } else { tmp28 = linked_2930.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2929, arg_2932) }; var tmp29 any = tmp28; var tmp30 any; var root_2933 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2934 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2933, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2935 lang.IFn; if linked_2934 == nil { ifn_2935 = lang.IFn_Cast(root_2933) } else { ifn_2935 = nil }; var arg_2936 any = opts__5; var arg_2937 any = A_arbace_build_go_A_const_151; var arg_2938 any; var root_2939 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = as__4; if linked_2940 == nil { arg_2938 = ifn_2941.Invoke_O__O(arg_2942) } else { arg_2938 = linked_2940.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2939, arg_2942) }; if linked_2934 == nil { tmp30 = ifn_2935.Invoke_O_O_O__O(arg_2936, arg_2937, arg_2938) } else { tmp30 = linked_2934.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2933, arg_2936, arg_2937, arg_2938) }; as__4, opts__5 = tmp29, tmp30; continue L1 }
//line :578:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_16) {


			var tmp31 any; var root_2943 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = as__4; if linked_2944 == nil { tmp31 = ifn_2945.Invoke_O__O(arg_2946) } else { tmp31 = linked_2944.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2943, arg_2946) }; var tmp32 any = tmp31; var tmp33 any; var root_2947 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = opts__5; var arg_2951 any = A_arbace_build_go_A_const_121; var arg_2952 any; var root_2954 any = A_arbace_build_go_A_const_197.GetRawRoot__O(); var linked_2955 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2954, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_2956 lang.IFn; if linked_2955 == nil { ifn_2956 = lang.IFn_Cast(root_2954) } else { ifn_2956 = nil }; var arg_2957 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_2958 any = lang.PersistentVector_EMPTY.Ref(); if linked_2955 == nil { arg_2952 = ifn_2956.Invoke_O_O__O(arg_2957, arg_2958) } else { arg_2952 = linked_2955.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_2954, arg_2957, arg_2958) }; var arg_2953 any; var root_2959 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2959, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2961 lang.IFn; if linked_2960 == nil { ifn_2961 = lang.IFn_Cast(root_2959) } else { ifn_2961 = nil }; var arg_2962 any = as__4; if linked_2960 == nil { arg_2953 = ifn_2961.Invoke_O__O(arg_2962) } else { arg_2953 = linked_2960.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2959, arg_2962) }; if linked_2948 == nil { tmp33 = ifn_2949.Invoke_O_O_O_O__O(arg_2950, arg_2951, arg_2952, arg_2953) } else { tmp33 = linked_2948.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2947, arg_2950, arg_2951, arg_2952, arg_2953) }; as__4, opts__5 = tmp32, tmp33; continue L1 }
//line :578:1
		case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_17) {







			var tmp34 any; var root_2963 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2963, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2965 lang.IFn; if linked_2964 == nil { ifn_2965 = lang.IFn_Cast(root_2963) } else { ifn_2965 = nil }; var arg_2966 any = as__4; if linked_2964 == nil { tmp34 = ifn_2965.Invoke_O__O(arg_2966) } else { tmp34 = linked_2964.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2963, arg_2966) }; var tmp35 any = tmp34; var tmp36 any; var root_2967 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2968 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2967, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2969 lang.IFn; if linked_2968 == nil { ifn_2969 = lang.IFn_Cast(root_2967) } else { ifn_2969 = nil }; var arg_2970 any = opts__5; var arg_2971 any = A_arbace_build_go_A_const_177; var arg_2972 any; var root_2973 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2973, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2975 lang.IFn; if linked_2974 == nil { ifn_2975 = lang.IFn_Cast(root_2973) } else { ifn_2975 = nil }; var arg_2976 any = as__4; if linked_2974 == nil { arg_2972 = ifn_2975.Invoke_O__O(arg_2976) } else { arg_2972 = linked_2974.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2973, arg_2976) }; if linked_2968 == nil { tmp36 = ifn_2969.Invoke_O_O_O__O(arg_2970, arg_2971, arg_2972) } else { tmp36 = linked_2968.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2967, arg_2970, arg_2971, arg_2972) }; as__4, opts__5 = tmp35, tmp36; continue L1 }
//line :578:1
		case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_18) {















			var tmp37 any; var root_2977 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2978 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2977, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2979 lang.IFn; if linked_2978 == nil { ifn_2979 = lang.IFn_Cast(root_2977) } else { ifn_2979 = nil }; var arg_2980 any = as__4; if linked_2978 == nil { tmp37 = ifn_2979.Invoke_O__O(arg_2980) } else { tmp37 = linked_2978.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2977, arg_2980) }; var tmp38 any = tmp37; var tmp39 any; var root_2981 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2982 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2981, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2983 lang.IFn; if linked_2982 == nil { ifn_2983 = lang.IFn_Cast(root_2981) } else { ifn_2983 = nil }; var arg_2984 any = opts__5; var arg_2985 any = A_arbace_build_go_A_const_122; var arg_2986 any; var root_2987 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2987, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2989 lang.IFn; if linked_2988 == nil { ifn_2989 = lang.IFn_Cast(root_2987) } else { ifn_2989 = nil }; var arg_2990 any = as__4; if linked_2988 == nil { arg_2986 = ifn_2989.Invoke_O__O(arg_2990) } else { arg_2986 = linked_2988.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2987, arg_2990) }; if linked_2982 == nil { tmp39 = ifn_2983.Invoke_O_O_O__O(arg_2984, arg_2985, arg_2986) } else { tmp39 = linked_2982.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2981, arg_2984, arg_2985, arg_2986) }; as__4, opts__5 = tmp38, tmp39; continue L1 }
//line :578:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_19) {













			var tmp40 any; var root_2991 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2991, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2993 lang.IFn; if linked_2992 == nil { ifn_2993 = lang.IFn_Cast(root_2991) } else { ifn_2993 = nil }; var arg_2994 any = as__4; if linked_2992 == nil { tmp40 = ifn_2993.Invoke_O__O(arg_2994) } else { tmp40 = linked_2992.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2991, arg_2994) }; var tmp41 any = tmp40; var tmp42 any; var root_2995 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2996 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2995, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2997 lang.IFn; if linked_2996 == nil { ifn_2997 = lang.IFn_Cast(root_2995) } else { ifn_2997 = nil }; var arg_2998 any = opts__5; var arg_2999 any = A_arbace_build_go_A_const_123; var arg_3000 any; var root_3001 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_3002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3001, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3003 lang.IFn; if linked_3002 == nil { ifn_3003 = lang.IFn_Cast(root_3001) } else { ifn_3003 = nil }; var arg_3004 any = as__4; if linked_3002 == nil { arg_3000 = ifn_3003.Invoke_O__O(arg_3004) } else { arg_3000 = linked_3002.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3001, arg_3004) }; if linked_2996 == nil { tmp42 = ifn_2997.Invoke_O_O_O__O(arg_2998, arg_2999, arg_3000) } else { tmp42 = linked_2996.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2995, arg_2998, arg_2999, arg_3000) }; as__4, opts__5 = tmp41, tmp42; continue L1 }
//line :578:1
		case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_20) {









			var tmp43 any; var root_3005 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_3006 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3005, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3007 lang.IFn; if linked_3006 == nil { ifn_3007 = lang.IFn_Cast(root_3005) } else { ifn_3007 = nil }; var arg_3008 any = as__4; if linked_3006 == nil { tmp43 = ifn_3007.Invoke_O__O(arg_3008) } else { tmp43 = linked_3006.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3005, arg_3008) }; var tmp44 any = tmp43; var tmp45 any; var root_3009 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_3010 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3009, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_3011 lang.IFn; if linked_3010 == nil { ifn_3011 = lang.IFn_Cast(root_3009) } else { ifn_3011 = nil }; var arg_3012 any = opts__5; var arg_3013 any = A_arbace_build_go_A_const_179; var arg_3014 any; var root_3016 any = A_arbace_build_go_A_const_197.GetRawRoot__O(); var linked_3017 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3016, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_3018 lang.IFn; if linked_3017 == nil { ifn_3018 = lang.IFn_Cast(root_3016) } else { ifn_3018 = nil }; var arg_3019 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_3020 any = lang.PersistentVector_EMPTY.Ref(); if linked_3017 == nil { arg_3014 = ifn_3018.Invoke_O_O__O(arg_3019, arg_3020) } else { arg_3014 = linked_3017.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_3016, arg_3019, arg_3020) }; var arg_3015 any; var root_3021 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_3022 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3021, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3023 lang.IFn; if linked_3022 == nil { ifn_3023 = lang.IFn_Cast(root_3021) } else { ifn_3023 = nil }; var arg_3024 any = as__4; if linked_3022 == nil { arg_3015 = ifn_3023.Invoke_O__O(arg_3024) } else { arg_3015 = linked_3022.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3021, arg_3024) }; if linked_3010 == nil { tmp45 = ifn_3011.Invoke_O_O_O_O__O(arg_3012, arg_3013, arg_3014, arg_3015) } else { tmp45 = linked_3010.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_3009, arg_3012, arg_3013, arg_3014, arg_3015) }; as__4, opts__5 = tmp44, tmp45; continue L1 }
//line :578:1
		case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_21) {








			var tmp46 any; var root_3025 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_3026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3025, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_3027 lang.IFn; if linked_3026 == nil { ifn_3027 = lang.IFn_Cast(root_3025) } else { ifn_3027 = nil }; var arg_3028 any = as__4; if linked_3026 == nil { tmp46 = ifn_3027.Invoke_O__O(arg_3028) } else { tmp46 = linked_3026.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_3025, arg_3028) }; var tmp47 any = tmp46; var tmp48 any; var root_3029 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_3030 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_3029, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_3031 lang.IFn; if linked_3030 == nil { ifn_3031 = lang.IFn_Cast(root_3029) } else { ifn_3031 = nil }; var arg_3032 any = opts__5; var arg_3033 any = A_arbace_build_go_A_const_178; var arg_3034 any; var root_3035 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_3036 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3035, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_3037 lang.IFn; if linked_3036 == nil { ifn_3037 = lang.IFn_Cast(root_3035) } else { ifn_3037 = nil }; var arg_3038 any = as__4; if linked_3036 == nil { arg_3034 = ifn_3037.Invoke_O__O(arg_3038) } else { arg_3034 = linked_3036.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_3035, arg_3038) }; if linked_3030 == nil { tmp48 = ifn_3031.Invoke_O_O_O__O(arg_3032, arg_3033, arg_3034) } else { tmp48 = linked_3030.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_3029, arg_3032, arg_3033, arg_3034) }; as__4, opts__5 = tmp47, tmp48; continue L1 }
//line :578:1
		default:
		}
















		var tmp49 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_3039 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_3040 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3039, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3041 lang.IFn; if linked_3040 == nil { ifn_3041 = lang.IFn_Cast(root_3039) } else { ifn_3041 = nil }; var arg_3042 any; var root_3043 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_3044 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3043, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_3045 lang.IFn; if linked_3044 == nil { ifn_3045 = lang.IFn_Cast(root_3043) } else { ifn_3045 = nil }; var arg_3046 any; var root_3048 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_3049 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3048, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_3050 lang.IFn; if linked_3049 == nil { ifn_3050 = lang.IFn_Cast(root_3048) } else { ifn_3050 = nil }; var arg_3051 any = as__4; if linked_3049 == nil { arg_3046 = ifn_3050.Invoke_O__O(arg_3051) } else { arg_3046 = linked_3049.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_3048, arg_3051) }; var arg_3047 any = Lit_22; if linked_3044 == nil { arg_3042 = ifn_3045.Invoke_O_O__O(arg_3046, arg_3047) } else { arg_3042 = linked_3044.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_3043, arg_3046, arg_3047) }; if linked_3040 == nil { and__1927000168__auto____8 = ifn_3041.Invoke_O__O(arg_3042) } else { and__1927000168__auto____8 = linked_3040.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3039, arg_3042) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_198); var and__1927000168__auto____9 any = tmp50.Invoke_O__O(A_arbace_build_go_A_const_182.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_3052 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_3053 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3052, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3054 lang.IFn

			if linked_3053 == nil { ifn_3054 = lang.IFn_Cast(root_3052) } else { ifn_3054 = nil }; var arg_3055 any = A_arbace_build_go_A_const_199; var arg_3056 any = A_arbace_build_go_A_const_151.Invoke_O__O(opts__5); if linked_3053 == nil { and__1927000168__auto____10 = ifn_3054.Invoke_O_O__O(arg_3055, arg_3056) } else { and__1927000168__auto____10 = linked_3053.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3052, arg_3055, arg_3056) }
//line :596:1
			if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_3057 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_3058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3057, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_3059 lang.IFn


				if linked_3058 == nil { ifn_3059 = lang.IFn_Cast(root_3057) } else { ifn_3059 = nil }; var arg_3060 any = A_arbace_build_go_A_const_200; var arg_3061 any = A_arbace_build_go_A_const_145.Invoke_O__O(opts__5); if linked_3058 == nil { and__1927000168__auto____11 = ifn_3059.Invoke_O_O__O(arg_3060, arg_3061) } else { and__1927000168__auto____11 = linked_3058.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_3057, arg_3060, arg_3061) }
//line :596:1
				if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_3062 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_3063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3062, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_3064 lang.IFn



					if linked_3063 == nil { ifn_3064 = lang.IFn_Cast(root_3062) } else { ifn_3064 = nil }; var arg_3065 any = A_arbace_build_go_A_const_183.Invoke_O__O(opts__5); if linked_3063 == nil { or__1927000174__auto____12 = ifn_3064.Invoke_O__O(arg_3065) } else { or__1927000174__auto____12 = linked_3063.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_3062, arg_3065) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp49 = or__1927000174__auto____12 } else { tmp49 = A_arbace_build_go_A_const_171.Invoke_O__O(opts__5) } } else {
//line :596:1
						tmp49 = and__1927000168__auto____11 } } else { tmp49 = and__1927000168__auto____10 } } else { tmp49 = and__1927000168__auto____9 } } else { tmp49 = and__1927000168__auto____8 } } else { tmp49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp49) { } else {




							var root_3075 any = A_arbace_build_go_A_const_72.GetRawRoot__O(); var linked_3076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3075, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_3077 lang.IFn; if linked_3076 == nil { ifn_3077 = lang.IFn_Cast(root_3075) } else { ifn_3077 = nil }; var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_73.GetRawRoot__O()); var tmp52 any = A_arbace_build_go_A_const_192; var arg_3078 any = tmp51.Invoke_O_O__O(tmp52, A_arbace_build_go_A_const_193.Get__O()); if linked_3076 == nil { ifn_3077.Invoke_O__O(arg_3078) } else { linked_3076.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_3075, arg_3078) }; var tmp53 *lang.Compiler_AOTFn; var fnbody__3074 any = A_arbace_build_go__main_fn__1901000412_A_New_O(usage__3); var tmp54 *jrt.Class; var fncls__3073 *jrt.Class = A_arbace_build_go__main_fn__1901000412_A_fn_class; if fncls__3073 == nil { var fncls__3073d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_23, false, fnbody__3074); A_arbace_build_go__main_fn__1901000412_A_fn_class = fncls__3073d; tmp54 = fncls__3073d } else { tmp54 = fncls__3073 }; tmp53 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__3074, tmp54, nil); Up_Compiler_AOTFn_IFn(tmp53).Invoke__O()
							jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :578:1
		var dir__7 any; var tmp55 any; var root_2740 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2740, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2742 lang.IFn
























		if linked_2741 == nil { ifn_2742 = lang.IFn_Cast(root_2740) } else { ifn_2742 = nil }; var arg_2743 any = as__4; if linked_2741 == nil { tmp55 = ifn_2742.Invoke_O__O(arg_2743) } else { tmp55 = linked_2741.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2740, arg_2743) }
//line :578:1
		dir__7 = jrt.File_New_String(jrt.String_Cast(tmp55)); var status__8 any; var tmp56 *lang.Compiler_AOTFn; var fnbody__2810 any = A_arbace_build_go__main_fn__1901000414_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp57 *jrt.Class
		var fncls__2809 /*line :578:1*/*jrt.Class = A_arbace_build_go__main_fn__1901000414_A_fn_class

























		if fncls__2809 == nil { var fncls__2809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_24, false, fnbody__2810); A_arbace_build_go__main_fn__1901000414_A_fn_class = fncls__2809d; tmp57 = fncls__2809d } else { tmp57 = fncls__2809 }; tmp56 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2810, tmp57, nil); status__8 = Up_Compiler_AOTFn_IFn(tmp56).Invoke__O()















		var root_3084 any = A_arbace_build_go_A_const_201.GetRawRoot__O(); var linked_3085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3084, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_3086 lang.IFn; if linked_3085 == nil { ifn_3086 = lang.IFn_Cast(root_3084) } else { ifn_3086 = nil }; if linked_3085 == nil { ifn_3086.Invoke__O() } else { linked_3085.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_3084) }
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__8)); return nil } }; /*line :573:1*/panic("j2g: unreachable") }



























func A_arbace_build_go__main_fn__1901000412_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000412_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000412_A{}; t.Ctor_O(p0); return t }
//line :601:1
func (t *A_arbace_build_go__main_fn__1901000412_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :601:1
func (t *A_arbace_build_go__main_fn__1901000412_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_3070 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_3071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3070, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_3072 lang.IFn; if linked_3071 == nil { ifn_3072 = lang.IFn_Cast(root_3070) } else { ifn_3072 = nil }; if linked_3071 == nil { ifn_3072.Invoke__O() } else { linked_3071.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_3070) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_build_go__main_fn__1901000414_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go__main_fn__1901000414_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000414_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :604:1
func (t *A_arbace_build_go__main_fn__1901000414_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :604:1
func (t *A_arbace_build_go__main_fn__1901000414_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.J2g_Truth(A_arbace_build_go_A_const_183.Invoke_O__O(t.F_opts)) { var prog__3 any; var root_2744 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_2745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2744, A_arbace_build_go_program_A_fn_class); var ifn_2746 lang.IFn
											if linked_2745 == nil { ifn_2746 = lang.IFn_Cast(root_2744) } else { ifn_2746 = nil }; var arg_2747 any = t.F_dir; var arg_2748 any; var t_ any = t.F_goroot; t.F_goroot = nil; arg_2748 = t_; var tmp2 any = A_arbace_build_go_A_const_120; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any = A_arbace_build_go_A_const_124; var tmp5 any = A_arbace_build_go_A_const_124.Invoke_O__O(t.F_opts); var tmp6 any = A_arbace_build_go_A_const_121; var arg_2749 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, A_arbace_build_go_A_const_121.Invoke_O__O(t.F_opts))); if linked_2745 == nil { prog__3 = ifn_2746.Invoke_O_O_O__O(arg_2747, arg_2748, arg_2749) } else { prog__3 = linked_2745.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2744, arg_2747, arg_2748, arg_2749) }
//line :605:1
		var mod__4 any; var tmp7 any; var root_2750 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2751 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2750, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2752 lang.IFn

		if linked_2751 == nil { ifn_2752 = lang.IFn_Cast(root_2750) } else { ifn_2752 = nil }; var arg_2753 any = A_arbace_build_go_A_const_171.Invoke_O__O(t.F_opts); if linked_2751 == nil { tmp7 = ifn_2752.Invoke_O__O(arg_2753) } else { tmp7 = linked_2751.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2750, arg_2753) }
//line :605:1
		mod__4 = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(tmp7)), Lit_25)


		if jrt.File_Cast(mod__4).Exists__Z() { var root_2776 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2777 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2776, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2778 lang.IFn; if linked_2777 == nil { ifn_2778 = lang.IFn_Cast(root_2776) } else { ifn_2778 = nil }; var arg_2779 any = mod__4; if linked_2777 == nil { ifn_2778.Invoke_O__O(arg_2779) } else { linked_2777.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2776, arg_2779) } }
		var root_2780 any = A_arbace_build_go_A_const_181.GetRawRoot__O(); var linked_2781 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2780, A_arbace_build_go_print_module_A_fn_class); var ifn_2782 lang.IFn; if linked_2781 == nil { ifn_2782 = lang.IFn_Cast(root_2780) } else { ifn_2782 = nil }; var arg_2783 any = prog__3; var arg_2784 any; var t__2 any = t.F_dir; t.F_dir = nil; arg_2784 = t__2; var arg_2785 any = mod__4; var arg_2786 any; var t__3 any = t.F_opts; t.F_opts = nil; arg_2786 = t__3; if linked_2781 == nil { ifn_2782.Invoke_O_O_O_O__O(arg_2783, arg_2784, arg_2785, arg_2786) } else { linked_2781.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2780, arg_2783, arg_2784, arg_2785, arg_2786) }
//line :605:1
		tmp1 = A_arbace_build_go_A_const_141 } else { var prog_main__3 any





			if jrt.J2g_Truth(A_arbace_build_go_A_const_184.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp8 *lang.Keyword = A_arbace_build_go_A_const_137; var tmp9 any; var root_2754 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_2755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2754, A_arbace_build_go_program_A_fn_class); var ifn_2756 lang.IFn; if linked_2755 == nil { ifn_2756 = lang.IFn_Cast(root_2754) } else { ifn_2756 = nil }; var arg_2757 any = t.F_dir; var arg_2758 any; var t__4 any = t.F_goroot; t.F_goroot = nil; arg_2758 = t__4; var arg_2759 any = t.F_opts; if linked_2755 == nil { tmp9 = ifn_2756.Invoke_O_O_O__O(arg_2757, arg_2758, arg_2759) } else { tmp9 = linked_2755.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2754, arg_2757, arg_2758, arg_2759) }; prog_main__3 = tmp8.Invoke_O__O(tmp9) }
//line :605:1
			var out__4 any; var tmp10 *jrt.Class = A_arbace_build_go_A_const_68; var tmp11 any; var or__1927000174__auto____4 any = A_arbace_build_go_A_const_184.Invoke_O__O(t.F_opts)






			if jrt.J2g_Truth(or__1927000174__auto____4) { tmp11 = or__1927000174__auto____4 } else {
				var root_2760 any = A_arbace_build_go_A_const_185.GetRawRoot__O(); var linked_2761 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2760, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_2762 lang.IFn; if linked_2761 == nil { ifn_2762 = lang.IFn_Cast(root_2760) } else { ifn_2762 = nil }; var arg_2763 any; var root_2764 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2765 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2764, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2766 lang.IFn; if linked_2765 == nil { ifn_2766 = lang.IFn_Cast(root_2764) } else { ifn_2766 = nil }; var arg_2767 any = A_arbace_build_go_A_const_48.Invoke_O__O(prog_main__3); var arg_2768 any = A_arbace_build_go_A_const_186; if linked_2765 == nil { arg_2763 = ifn_2766.Invoke_O_O__O(arg_2767, arg_2768) } else { arg_2763 = linked_2765.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2764, arg_2767, arg_2768) }; if linked_2761 == nil { tmp11 = ifn_2762.Invoke_O__O(arg_2763) } else { tmp11 = linked_2761.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_2760, arg_2763) } }
//line :605:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11))








			var root_2769 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2769, A_arbace_build_go_build_A_fn_class); var ifn_2771 lang.IFn; if linked_2770 == nil { ifn_2771 = lang.IFn_Cast(root_2769) } else { ifn_2771 = nil }; var arg_2772 any; var t__5 any = t.F_dir; t.F_dir = nil; arg_2772 = t__5; var arg_2773 any = A_arbace_build_go_A_const_182.Invoke_O__O(t.F_opts); var arg_2774 any = out__4; var arg_2775 any; var t__6 any = t.F_opts; t.F_opts = nil; arg_2775 = t__6; if linked_2770 == nil { tmp1 = ifn_2771.Invoke_O_O_O_O__O(arg_2772, arg_2773, arg_2774, arg_2775) } else { tmp1 = linked_2770.(*A_arbace_build_go_build_A).Invoke_O_O_O_O_O__O(root_2769, arg_2772, arg_2773, arg_2774, arg_2775) } }
//line :604:1
	return nil }(); if tmp12 != nil { if lang.ExceptionInfo_InstanceOf(tmp12) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp12); var tmp13 *lang.Keyword = A_arbace_build_go_A_const_188; var tmp14 any; var root_2787 any = A_arbace_build_go_A_const_189.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2789 lang.IFn











		if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any = e__3; if linked_2788 == nil { tmp14 = ifn_2789.Invoke_O__O(arg_2790) } else { tmp14 = linked_2788.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2787, arg_2790) }; if jrt.J2g_Truth(tmp13.Invoke_O__O(tmp14)) {
			var root_2800 any = A_arbace_build_go_A_const_72.GetRawRoot__O(); var linked_2801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2800, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2802 lang.IFn; if linked_2801 == nil { ifn_2802 = lang.IFn_Cast(root_2800) } else { ifn_2802 = nil }; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_73.GetRawRoot__O()); var tmp16 any = A_arbace_build_go_A_const_192; var arg_2803 any = tmp15.Invoke_O_O__O(tmp16, A_arbace_build_go_A_const_193.Get__O()); if linked_2801 == nil { ifn_2802.Invoke_O__O(arg_2803) } else { linked_2801.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2800, arg_2803) }; var tmp17 *lang.Compiler_AOTFn; var fnbody__2799 any = A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_New_O(e__3); var tmp18 *jrt.Class; var fncls__2798 *jrt.Class = A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_fn_class; if fncls__2798 == nil { var fncls__2798d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z_O__Class_NoInit(Lit_26, false, fnbody__2799); A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_fn_class = fncls__2798d; tmp18 = fncls__2798d } else { tmp18 = fncls__2798 }; tmp17 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(fnbody__2799, tmp18, nil); Up_Compiler_AOTFn_IFn(tmp17).Invoke__O()
//line :616:1
			tmp1 = A_arbace_build_go_A_const_190 } else { panic(jrt.Thrown(e__3)) } } else {
//line :604:1
				panic(tmp12) } }; return tmp1 }












func A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000414_fn__1901000415_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000414_fn__1901000415_A{}; t.Ctor_O(p0); return t }
//line :617:1
func (t *A_arbace_build_go__main_fn__1901000414_fn__1901000415_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :617:1
func (t *A_arbace_build_go__main_fn__1901000414_fn__1901000415_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); var root_2795 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2795, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2797 lang.IFn; if linked_2796 == nil { ifn_2797 = lang.IFn_Cast(root_2795) } else { ifn_2797 = nil }; if linked_2796 == nil { ifn_2797.Invoke__O() } else { linked_2796.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2795) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }




































































































































































type A_arbace_build_go_A struct{ jrt.Object }

var A_arbace_build_go_A_const_pool *jrt.RefArray

var A_arbace_build_go_A_const_0 *lang.Var

var A_arbace_build_go_A_const_1 any

var A_arbace_build_go_A_const_2 *lang.Var

var A_arbace_build_go_A_const_3 any

var A_arbace_build_go_A_const_4 any

var A_arbace_build_go_A_const_5 *lang.Var

var A_arbace_build_go_A_const_6 *lang.Var

var A_arbace_build_go_A_const_7 *lang.Var

var A_arbace_build_go_A_const_8 *lang.Var

var A_arbace_build_go_A_const_9 any

var A_arbace_build_go_A_const_10 *lang.Var

var A_arbace_build_go_A_const_11 *lang.Var

var A_arbace_build_go_A_const_12 any

var A_arbace_build_go_A_const_13 *lang.Keyword

var A_arbace_build_go_A_const_14 *lang.Var

var A_arbace_build_go_A_const_15 *lang.Var

var A_arbace_build_go_A_const_16 *lang.Var

var A_arbace_build_go_A_const_17 *lang.Var

var A_arbace_build_go_A_const_18 *lang.Var

var A_arbace_build_go_A_const_19 *lang.Var

var A_arbace_build_go_A_const_20 *lang.Var

var A_arbace_build_go_A_const_21 *lang.Var

var A_arbace_build_go_A_const_22 any

var A_arbace_build_go_A_const_23 *lang.Var

var A_arbace_build_go_A_const_24 *lang.Var

var A_arbace_build_go_A_const_25 *lang.Var

var A_arbace_build_go_A_const_26 *lang.Var

var A_arbace_build_go_A_const_27 *lang.Var

var A_arbace_build_go_A_const_28 *lang.Var

var A_arbace_build_go_A_const_29 *lang.Var

var A_arbace_build_go_A_const_30 *lang.Var

var A_arbace_build_go_A_const_31 *lang.Var

var A_arbace_build_go_A_const_32 *lang.Var

var A_arbace_build_go_A_const_33 *lang.Var

var A_arbace_build_go_A_const_34 *lang.Var

var A_arbace_build_go_A_const_35 *lang.Var

var A_arbace_build_go_A_const_36 *lang.Keyword

var A_arbace_build_go_A_const_37 *lang.Var

var A_arbace_build_go_A_const_38 *lang.Var

var A_arbace_build_go_A_const_39 *lang.Keyword

var A_arbace_build_go_A_const_40 *lang.Var

var A_arbace_build_go_A_const_41 *lang.Var

var A_arbace_build_go_A_const_42 *lang.Var

var A_arbace_build_go_A_const_43 *lang.Var

var A_arbace_build_go_A_const_44 *lang.Var

var A_arbace_build_go_A_const_45 *lang.Var

var A_arbace_build_go_A_const_46 *lang.Var

var A_arbace_build_go_A_const_47 *lang.Var

var A_arbace_build_go_A_const_48 *lang.Keyword

var A_arbace_build_go_A_const_49 *lang.Var

var A_arbace_build_go_A_const_50 *lang.Var

var A_arbace_build_go_A_const_51 *lang.Var

var A_arbace_build_go_A_const_52 *lang.Keyword

var A_arbace_build_go_A_const_53 *lang.Var

var A_arbace_build_go_A_const_54 *lang.Var

var A_arbace_build_go_A_const_55 *lang.Var

var A_arbace_build_go_A_const_56 *lang.Var

var A_arbace_build_go_A_const_57 *lang.Var

var A_arbace_build_go_A_const_58 *lang.Var

var A_arbace_build_go_A_const_59 *lang.Var

var A_arbace_build_go_A_const_60 *lang.Var

var A_arbace_build_go_A_const_61 *lang.Var

var A_arbace_build_go_A_const_62 *lang.Var

var A_arbace_build_go_A_const_63 *lang.Var

var A_arbace_build_go_A_const_64 *lang.Keyword

var A_arbace_build_go_A_const_65 *lang.Keyword

var A_arbace_build_go_A_const_66 *lang.Var

var A_arbace_build_go_A_const_67 *lang.Var

var A_arbace_build_go_A_const_68 *jrt.Class

var A_arbace_build_go_A_const_69 *lang.Var

var A_arbace_build_go_A_const_70 *lang.Var

var A_arbace_build_go_A_const_71 *lang.Var

var A_arbace_build_go_A_const_72 *lang.Var

var A_arbace_build_go_A_const_73 *lang.Var

var A_arbace_build_go_A_const_74 *lang.Var

var A_arbace_build_go_A_const_75 *lang.Var

var A_arbace_build_go_A_const_76 *lang.Var

var A_arbace_build_go_A_const_77 *lang.Var

var A_arbace_build_go_A_const_78 *lang.Var

var A_arbace_build_go_A_const_79 *lang.Keyword

var A_arbace_build_go_A_const_80 *lang.Var

var A_arbace_build_go_A_const_81 *lang.Var

var A_arbace_build_go_A_const_82 *lang.Var

var A_arbace_build_go_A_const_83 *lang.Keyword

var A_arbace_build_go_A_const_84 *lang.Var

var A_arbace_build_go_A_const_85 *lang.Var

var A_arbace_build_go_A_const_86 *lang.Var

var A_arbace_build_go_A_const_87 *lang.Var

var A_arbace_build_go_A_const_88 *lang.Var

var A_arbace_build_go_A_const_89 *lang.Var

var A_arbace_build_go_A_const_90 *lang.Var

var A_arbace_build_go_A_const_91 *lang.Var

var A_arbace_build_go_A_const_92 *lang.Keyword

var A_arbace_build_go_A_const_93 *lang.Var

var A_arbace_build_go_A_const_94 *lang.Var

var A_arbace_build_go_A_const_95 *lang.Var

var A_arbace_build_go_A_const_96 *lang.Keyword

var A_arbace_build_go_A_const_97 *lang.Var

var A_arbace_build_go_A_const_98 *lang.Var

var A_arbace_build_go_A_const_99 *lang.Var

var A_arbace_build_go_A_const_100 any

var A_arbace_build_go_A_const_101 any

var A_arbace_build_go_A_const_102 *lang.Var

var A_arbace_build_go_A_const_103 any

var A_arbace_build_go_A_const_104 any

var A_arbace_build_go_A_const_105 *lang.Var

var A_arbace_build_go_A_const_106 *lang.Var

var A_arbace_build_go_A_const_107 any

var A_arbace_build_go_A_const_108 any

var A_arbace_build_go_A_const_109 *lang.Var

var A_arbace_build_go_A_const_110 *lang.Var

var A_arbace_build_go_A_const_111 *lang.Var

var A_arbace_build_go_A_const_112 *lang.Var

var A_arbace_build_go_A_const_113 *lang.Keyword

var A_arbace_build_go_A_const_114 *lang.Keyword

var A_arbace_build_go_A_const_115 *lang.Keyword

var A_arbace_build_go_A_const_116 *lang.Var

var A_arbace_build_go_A_const_117 *lang.Var

var A_arbace_build_go_A_const_118 *lang.Var

var A_arbace_build_go_A_const_119 any

var A_arbace_build_go_A_const_120 *lang.Keyword

var A_arbace_build_go_A_const_121 *lang.Keyword

var A_arbace_build_go_A_const_122 *lang.Keyword

var A_arbace_build_go_A_const_123 *lang.Keyword

var A_arbace_build_go_A_const_124 *lang.Keyword

var A_arbace_build_go_A_const_125 *lang.Var

var A_arbace_build_go_A_const_126 *lang.Keyword

var A_arbace_build_go_A_const_127 *lang.Var

var A_arbace_build_go_A_const_128 *lang.Keyword

var A_arbace_build_go_A_const_129 *lang.Var

var A_arbace_build_go_A_const_130 *lang.Var

var A_arbace_build_go_A_const_131 *lang.Var

var A_arbace_build_go_A_const_132 any

var A_arbace_build_go_A_const_133 *lang.Keyword

var A_arbace_build_go_A_const_134 *lang.Var

var A_arbace_build_go_A_const_135 *lang.Var

var A_arbace_build_go_A_const_136 *lang.Var

var A_arbace_build_go_A_const_137 *lang.Keyword

var A_arbace_build_go_A_const_138 *lang.Var

var A_arbace_build_go_A_const_139 *lang.Var

var A_arbace_build_go_A_const_140 *jrt.Class

var A_arbace_build_go_A_const_141 any

var A_arbace_build_go_A_const_142 *lang.Var

var A_arbace_build_go_A_const_143 *lang.Keyword

var A_arbace_build_go_A_const_144 *lang.Keyword

var A_arbace_build_go_A_const_145 *lang.Keyword

var A_arbace_build_go_A_const_146 *lang.Keyword

var A_arbace_build_go_A_const_147 *lang.Var

var A_arbace_build_go_A_const_148 *lang.Var

var A_arbace_build_go_A_const_149 *lang.Var

var A_arbace_build_go_A_const_150 *lang.Keyword

var A_arbace_build_go_A_const_151 *lang.Keyword

var A_arbace_build_go_A_const_152 *lang.Keyword

var A_arbace_build_go_A_const_153 *lang.Keyword

var A_arbace_build_go_A_const_154 any

var A_arbace_build_go_A_const_155 *lang.Keyword

var A_arbace_build_go_A_const_156 *lang.Keyword

var A_arbace_build_go_A_const_157 *lang.Keyword

var A_arbace_build_go_A_const_158 *lang.Var

var A_arbace_build_go_A_const_159 *lang.Var

var A_arbace_build_go_A_const_160 any

var A_arbace_build_go_A_const_161 *lang.Var

var A_arbace_build_go_A_const_162 *lang.Var

var A_arbace_build_go_A_const_163 *lang.Var

var A_arbace_build_go_A_const_164 *lang.Var

var A_arbace_build_go_A_const_165 *lang.Keyword

var A_arbace_build_go_A_const_166 *lang.Keyword

var A_arbace_build_go_A_const_167 *lang.Var

var A_arbace_build_go_A_const_168 *lang.Var

var A_arbace_build_go_A_const_169 *lang.Var

var A_arbace_build_go_A_const_170 *lang.Var

var A_arbace_build_go_A_const_171 *lang.Keyword

var A_arbace_build_go_A_const_172 *lang.Keyword

var A_arbace_build_go_A_const_173 *lang.Var

var A_arbace_build_go_A_const_174 *jrt.Class

var A_arbace_build_go_A_const_175 *lang.Keyword

var A_arbace_build_go_A_const_176 *lang.Var

var A_arbace_build_go_A_const_177 *lang.Keyword

var A_arbace_build_go_A_const_178 *lang.Keyword

var A_arbace_build_go_A_const_179 *lang.Keyword

var A_arbace_build_go_A_const_180 *lang.Keyword

var A_arbace_build_go_A_const_181 *lang.Var

var A_arbace_build_go_A_const_182 *lang.Keyword

var A_arbace_build_go_A_const_183 *lang.Keyword

var A_arbace_build_go_A_const_184 *lang.Keyword

var A_arbace_build_go_A_const_185 *lang.Var

var A_arbace_build_go_A_const_186 any

var A_arbace_build_go_A_const_187 *lang.Var

var A_arbace_build_go_A_const_188 *lang.Keyword

var A_arbace_build_go_A_const_189 *lang.Var

var A_arbace_build_go_A_const_190 any

var A_arbace_build_go_A_const_191 *lang.Var

var A_arbace_build_go_A_const_192 *lang.Var

var A_arbace_build_go_A_const_193 *lang.Var

var A_arbace_build_go_A_const_194 *lang.Var

var A_arbace_build_go_A_const_195 *lang.Var

var A_arbace_build_go_A_const_196 *lang.Var

var A_arbace_build_go_A_const_197 *lang.Var

var A_arbace_build_go_A_const_198 any

var A_arbace_build_go_A_const_199 any

var A_arbace_build_go_A_const_200 any

var A_arbace_build_go_A_const_201 *lang.Var

var A_arbace_build_go_A_init jrt.ClassInit

func A_arbace_build_go_A_Init() { if !A_arbace_build_go_A_init.Done() { A_arbace_build_go_A_init.Run(A_arbace_build_go_A_clinit) } }

func A_arbace_build_go_A_clinit() { A_arbace_build_go_A_clinit_p0(); A_arbace_build_go_A_clinit_p1(); A_arbace_build_go_A_clinit_p2(); A_arbace_build_go_A_clinit_p3(); A_arbace_build_go_A_clinit_p4(); A_arbace_build_go_A_clinit_p5(); A_arbace_build_go_A_clinit_p6(); A_arbace_build_go_A_clinit_p7(); A_arbace_build_go_A_clinit_p8(); A_arbace_build_go_A_clinit_p9(); A_arbace_build_go_A_clinit_p10(); A_arbace_build_go_A_clinit_p11(); A_arbace_build_go_A_clinit_p12(); A_arbace_build_go_A_clinit_p13(); A_arbace_build_go_A_clinit_p14(); A_arbace_build_go_A_clinit_p15(); A_arbace_build_go_A_clinit_p16() }

func A_arbace_build_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_build_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 257); A_arbace_build_go_A_const_0 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[55]); A_arbace_build_go_A_const_1 = A_arbace_build_go_A_const_pool.A[56]; A_arbace_build_go_A_const_2 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[57]); A_arbace_build_go_A_const_3 = A_arbace_build_go_A_const_pool.A[58]; A_arbace_build_go_A_const_4 = A_arbace_build_go_A_const_pool.A[59]; A_arbace_build_go_A_const_5 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[60]); A_arbace_build_go_A_const_6 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[61]); A_arbace_build_go_A_const_7 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[62]); A_arbace_build_go_A_const_8 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[63]); A_arbace_build_go_A_const_9 = A_arbace_build_go_A_const_pool.A[64]; A_arbace_build_go_A_const_10 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[65]); A_arbace_build_go_A_const_11 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[66]) }

func A_arbace_build_go_A_clinit_p1() { A_arbace_build_go_A_const_12 = A_arbace_build_go_A_const_pool.A[67]; A_arbace_build_go_A_const_13 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[68]); A_arbace_build_go_A_const_14 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[69]); A_arbace_build_go_A_const_15 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[70]); A_arbace_build_go_A_const_16 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[71]); A_arbace_build_go_A_const_17 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[72]); A_arbace_build_go_A_const_18 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[73]); A_arbace_build_go_A_const_19 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[74]); A_arbace_build_go_A_const_20 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[75]); A_arbace_build_go_A_const_21 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[76]); A_arbace_build_go_A_const_22 = A_arbace_build_go_A_const_pool.A[77]; A_arbace_build_go_A_const_23 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[78]) }

func A_arbace_build_go_A_clinit_p2() { A_arbace_build_go_A_const_24 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[79]); A_arbace_build_go_A_const_25 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[80]); A_arbace_build_go_A_const_26 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[81]); A_arbace_build_go_A_const_27 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[82]); A_arbace_build_go_A_const_28 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[83]); A_arbace_build_go_A_const_29 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[84]); A_arbace_build_go_A_const_30 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[85]); A_arbace_build_go_A_const_31 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[86]); A_arbace_build_go_A_const_32 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[87]); A_arbace_build_go_A_const_33 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[88]); A_arbace_build_go_A_const_34 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[89]); A_arbace_build_go_A_const_35 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[90]) }

func A_arbace_build_go_A_clinit_p3() { A_arbace_build_go_A_const_36 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[91]); A_arbace_build_go_A_const_37 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[92]); A_arbace_build_go_A_const_38 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[93]); A_arbace_build_go_A_const_39 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[94]); A_arbace_build_go_A_const_40 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[95]); A_arbace_build_go_A_const_41 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[96]); A_arbace_build_go_A_const_42 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[97]); A_arbace_build_go_A_const_43 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[98]); A_arbace_build_go_A_const_44 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[99]); A_arbace_build_go_A_const_45 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[100]); A_arbace_build_go_A_const_46 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[101]); A_arbace_build_go_A_const_47 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[102]) }

func A_arbace_build_go_A_clinit_p4() { A_arbace_build_go_A_const_48 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[103]); A_arbace_build_go_A_const_49 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[104]); A_arbace_build_go_A_const_50 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[105]); A_arbace_build_go_A_const_51 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[106]); A_arbace_build_go_A_const_52 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[107]); A_arbace_build_go_A_const_53 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[108]); A_arbace_build_go_A_const_54 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[109]); A_arbace_build_go_A_const_55 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[110]); A_arbace_build_go_A_const_56 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[111]); A_arbace_build_go_A_const_57 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[112]); A_arbace_build_go_A_const_58 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[113]); A_arbace_build_go_A_const_59 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[114]) }

func A_arbace_build_go_A_clinit_p5() { A_arbace_build_go_A_const_60 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[115]); A_arbace_build_go_A_const_61 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[116]); A_arbace_build_go_A_const_62 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[117]); A_arbace_build_go_A_const_63 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[118]); A_arbace_build_go_A_const_64 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[119]); A_arbace_build_go_A_const_65 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[120]); A_arbace_build_go_A_const_66 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[121]); A_arbace_build_go_A_const_67 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[122]); A_arbace_build_go_A_const_68 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[123]); A_arbace_build_go_A_const_69 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[124]); A_arbace_build_go_A_const_70 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[125]); A_arbace_build_go_A_const_71 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[126]) }

func A_arbace_build_go_A_clinit_p6() { A_arbace_build_go_A_const_72 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[127]); A_arbace_build_go_A_const_73 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[128]); A_arbace_build_go_A_const_74 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[129]); A_arbace_build_go_A_const_75 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[130]); A_arbace_build_go_A_const_76 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[131]); A_arbace_build_go_A_const_77 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[132]); A_arbace_build_go_A_const_78 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[133]); A_arbace_build_go_A_const_79 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[134]); A_arbace_build_go_A_const_80 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[135]); A_arbace_build_go_A_const_81 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[136]); A_arbace_build_go_A_const_82 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[137]); A_arbace_build_go_A_const_83 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[138]) }

func A_arbace_build_go_A_clinit_p7() { A_arbace_build_go_A_const_84 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[139]); A_arbace_build_go_A_const_85 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[140]); A_arbace_build_go_A_const_86 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[141]); A_arbace_build_go_A_const_87 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[142]); A_arbace_build_go_A_const_88 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[143]); A_arbace_build_go_A_const_89 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[144]); A_arbace_build_go_A_const_90 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[145]); A_arbace_build_go_A_const_91 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[146]); A_arbace_build_go_A_const_92 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[147]); A_arbace_build_go_A_const_93 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[148]); A_arbace_build_go_A_const_94 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[149]); A_arbace_build_go_A_const_95 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[150]) }

func A_arbace_build_go_A_clinit_p8() { A_arbace_build_go_A_const_96 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[151]); A_arbace_build_go_A_const_97 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[152]); A_arbace_build_go_A_const_98 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[153]); A_arbace_build_go_A_const_99 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[154]); A_arbace_build_go_A_const_100 = A_arbace_build_go_A_const_pool.A[155]; A_arbace_build_go_A_const_101 = A_arbace_build_go_A_const_pool.A[156]; A_arbace_build_go_A_const_102 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[157]); A_arbace_build_go_A_const_103 = A_arbace_build_go_A_const_pool.A[158]; A_arbace_build_go_A_const_104 = A_arbace_build_go_A_const_pool.A[159]; A_arbace_build_go_A_const_105 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[160]); A_arbace_build_go_A_const_106 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[161]); A_arbace_build_go_A_const_107 = A_arbace_build_go_A_const_pool.A[162]; A_arbace_build_go_A_const_108 = A_arbace_build_go_A_const_pool.A[163] }

func A_arbace_build_go_A_clinit_p9() { A_arbace_build_go_A_const_109 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[164]); A_arbace_build_go_A_const_110 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[165]); A_arbace_build_go_A_const_111 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[166]); A_arbace_build_go_A_const_112 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[167]); A_arbace_build_go_A_const_113 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[168]); A_arbace_build_go_A_const_114 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[169]); A_arbace_build_go_A_const_115 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[170]); A_arbace_build_go_A_const_116 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[171]); A_arbace_build_go_A_const_117 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[172]); A_arbace_build_go_A_const_118 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[173]); A_arbace_build_go_A_const_119 = A_arbace_build_go_A_const_pool.A[174]; A_arbace_build_go_A_const_120 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[175]) }

func A_arbace_build_go_A_clinit_p10() { A_arbace_build_go_A_const_121 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[176]); A_arbace_build_go_A_const_122 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[177]); A_arbace_build_go_A_const_123 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[178]); A_arbace_build_go_A_const_124 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[179]); A_arbace_build_go_A_const_125 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[180]); A_arbace_build_go_A_const_126 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[181]); A_arbace_build_go_A_const_127 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[182]); A_arbace_build_go_A_const_128 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[183]); A_arbace_build_go_A_const_129 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[184]); A_arbace_build_go_A_const_130 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[185]); A_arbace_build_go_A_const_131 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[186]); A_arbace_build_go_A_const_132 = A_arbace_build_go_A_const_pool.A[187] }

func A_arbace_build_go_A_clinit_p11() { A_arbace_build_go_A_const_133 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[188]); A_arbace_build_go_A_const_134 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[189]); A_arbace_build_go_A_const_135 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[190]); A_arbace_build_go_A_const_136 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[191]); A_arbace_build_go_A_const_137 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[192]); A_arbace_build_go_A_const_138 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[193]); A_arbace_build_go_A_const_139 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[194]); A_arbace_build_go_A_const_140 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[195]); A_arbace_build_go_A_const_141 = A_arbace_build_go_A_const_pool.A[196]; A_arbace_build_go_A_const_142 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[197]); A_arbace_build_go_A_const_143 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[198]); A_arbace_build_go_A_const_144 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[199]) }

func A_arbace_build_go_A_clinit_p12() { A_arbace_build_go_A_const_145 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[200]); A_arbace_build_go_A_const_146 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[201]); A_arbace_build_go_A_const_147 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[202]); A_arbace_build_go_A_const_148 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[203]); A_arbace_build_go_A_const_149 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[204]); A_arbace_build_go_A_const_150 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[205]); A_arbace_build_go_A_const_151 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[206]); A_arbace_build_go_A_const_152 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[207]); A_arbace_build_go_A_const_153 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[208]); A_arbace_build_go_A_const_154 = A_arbace_build_go_A_const_pool.A[209]; A_arbace_build_go_A_const_155 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[210]); A_arbace_build_go_A_const_156 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[211]) }

func A_arbace_build_go_A_clinit_p13() { A_arbace_build_go_A_const_157 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[212]); A_arbace_build_go_A_const_158 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[213]); A_arbace_build_go_A_const_159 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[214]); A_arbace_build_go_A_const_160 = A_arbace_build_go_A_const_pool.A[215]; A_arbace_build_go_A_const_161 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[216]); A_arbace_build_go_A_const_162 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[217]); A_arbace_build_go_A_const_163 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[218]); A_arbace_build_go_A_const_164 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[219]); A_arbace_build_go_A_const_165 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[220]); A_arbace_build_go_A_const_166 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[221]); A_arbace_build_go_A_const_167 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[222]); A_arbace_build_go_A_const_168 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[223]) }

func A_arbace_build_go_A_clinit_p14() { A_arbace_build_go_A_const_169 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[224]); A_arbace_build_go_A_const_170 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[225]); A_arbace_build_go_A_const_171 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[226]); A_arbace_build_go_A_const_172 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[227]); A_arbace_build_go_A_const_173 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[228]); A_arbace_build_go_A_const_174 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[229]); A_arbace_build_go_A_const_175 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[230]); A_arbace_build_go_A_const_176 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[231]); A_arbace_build_go_A_const_177 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[232]); A_arbace_build_go_A_const_178 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[233]); A_arbace_build_go_A_const_179 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[234]); A_arbace_build_go_A_const_180 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[235]) }

func A_arbace_build_go_A_clinit_p15() { A_arbace_build_go_A_const_181 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[236]); A_arbace_build_go_A_const_182 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[237]); A_arbace_build_go_A_const_183 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[238]); A_arbace_build_go_A_const_184 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[239]); A_arbace_build_go_A_const_185 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[240]); A_arbace_build_go_A_const_186 = A_arbace_build_go_A_const_pool.A[241]; A_arbace_build_go_A_const_187 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[242]); A_arbace_build_go_A_const_188 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[243]); A_arbace_build_go_A_const_189 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[244]); A_arbace_build_go_A_const_190 = A_arbace_build_go_A_const_pool.A[245]; A_arbace_build_go_A_const_191 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[246]); A_arbace_build_go_A_const_192 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[247]) }

func A_arbace_build_go_A_clinit_p16() { A_arbace_build_go_A_const_193 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[248]); A_arbace_build_go_A_const_194 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[249]); A_arbace_build_go_A_const_195 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[250]); A_arbace_build_go_A_const_196 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[251]); A_arbace_build_go_A_const_197 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[252]); A_arbace_build_go_A_const_198 = A_arbace_build_go_A_const_pool.A[253]; A_arbace_build_go_A_const_199 = A_arbace_build_go_A_const_pool.A[254]; A_arbace_build_go_A_const_200 = A_arbace_build_go_A_const_pool.A[255]; A_arbace_build_go_A_const_201 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[256]) }

func A_arbace_build_go_A_New() *A_arbace_build_go_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_A) Ctor() {}

func (t *A_arbace_build_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_A_class }

func (t *A_arbace_build_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_A); return ok }

func A_arbace_build_go_A_Cast(x any) *A_arbace_build_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_A_class)) }; return v }



type A_arbace_build_go__main_A struct{ j2g_header uint64 }

var A_arbace_build_go__main_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000412_A struct{ j2g_header uint64; F_usage any }

var A_arbace_build_go__main_fn__1901000412_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000414_A struct{ j2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_build_go__main_fn__1901000414_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000414_fn__1901000415_A struct{ j2g_header uint64; F_e any }

var A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_fn_class *jrt.Class



type A_arbace_build_go_build_A struct{ j2g_header uint64 }

var A_arbace_build_go_build_A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__fn__1901000326_A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_A struct{ j2g_header uint64 }

var A_arbace_build_go_cached_texts_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A struct{ j2g_header uint64; F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A struct{ j2g_header uint64; F_s__1901000305, F_iter__1901000304, F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A struct{ j2g_header uint64; F_b__1901000307, F_entry any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000020_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_fn__1901000020_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000022_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_clj_files_fn__1901000022_A_fn_class *jrt.Class



type A_arbace_build_go_collect_index_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_index_file_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_package_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_fn__1901000076_A struct{ j2g_header uint64; F_read_fn, F_read any }

var A_arbace_build_go_collect_package_fn__1901000076_A_fn_class *jrt.Class



type A_arbace_build_go_collected_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collected_package_A_fn_class *jrt.Class



type A_arbace_build_go_copy_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_copy_file_A_fn_class *jrt.Class



type A_arbace_build_go_data_dir_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_delete_tree_A struct{ j2g_header uint64 }

var A_arbace_build_go_delete_tree_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000004_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000004_A_New() *A_arbace_build_go_eval1901000004_A { t := &A_arbace_build_go_eval1901000004_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000004_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000004_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000004_A_class }

func (t *A_arbace_build_go_eval1901000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000004_A); return ok }

func A_arbace_build_go_eval1901000004_A_Cast(x any) *A_arbace_build_go_eval1901000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000004_A_class)) }; return v }



type A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000008_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000008_A_New() *A_arbace_build_go_eval1901000008_A { t := &A_arbace_build_go_eval1901000008_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000008_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000008_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000008_A_class }

func (t *A_arbace_build_go_eval1901000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000008_A); return ok }

func A_arbace_build_go_eval1901000008_A_Cast(x any) *A_arbace_build_go_eval1901000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000008_A_class)) }; return v }



type A_arbace_build_go_eval1901000008_fn__1901000009_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000008_fn__1901000009_A_fn_class *jrt.Class



type A_arbace_build_go_fail_A struct{ j2g_header uint64 }

var A_arbace_build_go_fail_A_fn_class *jrt.Class



type A_arbace_build_go_file_sha_A struct{ j2g_header uint64 }

var A_arbace_build_go_file_sha_A_fn_class *jrt.Class



type A_arbace_build_go_forms_dir_A struct{ j2g_header uint64 }

var A_arbace_build_go_forms_dir_A_fn_class *jrt.Class



type A_arbace_build_go_go_env_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_env_A_fn_class *jrt.Class



type A_arbace_build_go_go_mod_cache_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_sha__1901000243_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class *jrt.Class



type A_arbace_build_go_hex_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_A_fn_class *jrt.Class



type A_arbace_build_go_hex_fn__1901000072_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_fn__1901000072_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000027_A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000029_A struct{ j2g_header uint64; F_aliases any }

var A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class *jrt.Class



type A_arbace_build_go_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000057_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000057_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000062_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000062_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_A struct{ j2g_header uint64; F_print_cache any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A struct{ j2g_header uint64; F_iter__1901000034, F_print_cache, F_s__1901000035 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A struct{ j2g_header uint64; F_iter__1901000036, F_s__1901000037 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A struct{ j2g_header uint64; F_b__1901000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_add__1901000295_A struct{ j2g_header uint64; F_md any }

var A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_fn__1901000301_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_A struct{ j2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_build_go_print_module_fn__1901000361_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A struct{ j2g_header uint64; F_test_files, F_tests any }

var A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000341__1901000345_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_iter__1901000341__1901000345_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A struct{ j2g_header uint64; F_iter__1901000341, F_s__1901000342 any }

var A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A struct{ j2g_header uint64; F_b__1901000344 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000351__1901000355_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_iter__1901000351__1901000355_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A struct{ j2g_header uint64; F_iter__1901000351, F_s__1901000352 any }

var A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A struct{ j2g_header uint64; F_b__1901000354 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_fn_class *jrt.Class



type A_arbace_build_go_program_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000263_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000263_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000265_A struct{ j2g_header uint64; F_opts any }

var A_arbace_build_go_program_fn__1901000265_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000277_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000277_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_A struct{ j2g_header uint64; F_module any }

var A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A struct{ j2g_header uint64; F_iter__1901000267, F_module, F_s__1901000268 any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A struct{ j2g_header uint64; F_b__1901000270 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000066_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_fn__1901000066_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000068_A struct{ j2g_header uint64; F_cache any }

var A_arbace_build_go_read_all_fn__1901000068_A_fn_class *jrt.Class



type A_arbace_build_go_read_index_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_index_A_fn_class *jrt.Class



type A_arbace_build_go_read_program_edn_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_program_edn_A_fn_class *jrt.Class



type A_arbace_build_go_rel_path_A struct{ j2g_header uint64 }

var A_arbace_build_go_rel_path_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000099_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_fn__1901000099_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000101_A struct{ j2g_header uint64; F_m any }

var A_arbace_build_go_root_packages_fn__1901000101_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000158_A struct{ j2g_header uint64; F_covered, F_known_QMARK_ any }

var A_arbace_build_go_root_packages_fn__1901000158_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000187_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000187_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000192_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000192_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A struct{ j2g_header uint64; F_s__1901000104, F_iter__1901000103, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A struct{ j2g_header uint64; F_b__1901000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A struct{ j2g_header uint64; F_iter__1901000131, F_s__1901000132 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A struct{ j2g_header uint64; F_iter__1901000133, F_s__1901000134 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A struct{ j2g_header uint64; F_b__1901000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid, F_s__1901000163, F_iter__1901000162 any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_b__1901000165, F_dir, F_valid any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_s__1901000195, F_iter__1901000194, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_b__1901000197 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A struct{ j2g_header uint64; F_s__1901000205, F_iter__1901000204, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A struct{ j2g_header uint64; F_b__1901000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_known_QMARK___1901000156_A struct{ j2g_header uint64; F_index_file, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A struct{ j2g_header uint64; F_read_fn, F_known_QMARK_, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class *jrt.Class



type A_arbace_build_go_run_A struct{ j2g_header uint64 }

var A_arbace_build_go_run_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_fn__1901000281_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_fn__1901000281_A_fn_class *jrt.Class



type A_arbace_build_go_tamago_go_sum_A struct{ j2g_header uint64 }

var A_arbace_build_go_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_build_go_toolchain_lang_A struct{ j2g_header uint64 }

var A_arbace_build_go_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_with_line_files_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__fn__1901000091_A struct{ j2g_header uint64; F_ok_QMARK_ any }

var A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A struct{ j2g_header uint64; F_printed any }

var A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__printed__1901000087_A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class *jrt.Class
