//line aot_arbace_build_go.ae:1
package aot_arbace_build_go

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_New() *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_build_go_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_1); lang.IFn_Cast(A_arbace_build_go_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_3, A_arbace_build_go_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_59)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_60)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_61)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_62)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_63)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_64)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_build_go_eval1901000008_fn__1901000009_A_New() *A_arbace_build_go_eval1901000008_fn__1901000009_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000008_fn__1901000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_build_go_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_build_go_A_const_8.GetRawRoot__O(), A_arbace_build_go_A_const_9) }

































































func A_arbace_build_go_fail_A_New() *A_arbace_build_go_fail_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_fail_A{}; t.Ctor(); return t }
//line :67:1
func (t *A_arbace_build_go_fail_A) Ctor() {}
//line :67:1
func (t *A_arbace_build_go_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__1901000012__1 any) any { var vec__1901000013__3 any = p__1901000012__1; var data__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000013__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_20 any = A_arbace_build_go_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_22 lang.IFn; if
												linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = msg__0; var arg_24 any; var root_25 any = A_arbace_build_go_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_build_go_A_const_12; var arg_29 any = data__4; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; /*line :67:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }





func A_arbace_build_go_data_dir_QMARK__A_New() *A_arbace_build_go_data_dir_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :73:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Ctor() {}
//line :73:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.NN(jrt.File_Cast(f__1)).GetParentFile__File().Ref(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(jrt.NN(jrt.File_Cast(d__3)).GetAbsoluteFile__File().Ref(), jrt.NN(jrt.File_Cast(dir__0)).GetAbsoluteFile__File().Ref()) }; if tmp1 { return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_58).IsFile__Z() { return jrt.Boolean_TRUE.Ref() } else { if A_arbace_build_go_A_const_13 != nil {

		d__3 = jrt.NN(jrt.File_Cast(d__3)).GetParentFile__File().Ref(); continue L1 } else {
//line :78:1
			return nil } } } } }; /*line :73:1*/panic("j2g: unreachable") }








func A_arbace_build_go_clj_files_A_New() *A_arbace_build_go_clj_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_A{}; t.Ctor(); return t }
//line :82:1
func (t *A_arbace_build_go_clj_files_A) Ctor() {}
//line :82:1
func (t *A_arbace_build_go_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var root_30 any = A_arbace_build_go_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var tmp1 any = A_arbace_build_go_clj_files_fn__1901000020_A_New(); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000020_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_build_go_clj_files_fn__1901000020_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; arg_33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_34 any; var root_36 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_38 lang.IFn
//line :84:1
	if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var tmp3 any = A_arbace_build_go_clj_files_fn__1901000022_A_New_O(dir__0); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000022_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_50, false); A_arbace_build_go_clj_files_fn__1901000022_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; arg_39 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_40 any; var root_56 any = A_arbace_build_go_A_const_19.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_58 lang.IFn
//line :83:1
	if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = dir__0; if linked_57 == nil { arg_40 = ifn_58.Invoke_O__O(arg_59) } else { arg_40 = linked_57.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_56, arg_59) }
	if linked_37 == nil { arg_34 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { arg_34 = linked_37.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_36, arg_39, arg_40)
	}
	if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
//line :84:1
func A_arbace_build_go_clj_files_fn__1901000022_A_New_O(p0 any) *A_arbace_build_go_clj_files_fn__1901000022_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000022_A{}; t.Ctor_O(p0); return t }
//line :84:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :84:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Invoke_O_O__O(self, p1__1901000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_41 any = A_arbace_build_go_A_const_16.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).GetName__String().Ref(); var arg_45 any = Lit_51; if linked_42 == nil { and__1927000168__auto____3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { and__1927000168__auto____3 = linked_42.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
														var root_46 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var root_50 any = A_arbace_build_go_A_const_18.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_build_go_data_dir_QMARK__A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = t.F_dir; var arg_54 any = p1__1901000018_SHARP___1; if linked_51 == nil { arg_49 = ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { arg_49 = linked_51.(*A_arbace_build_go_data_dir_QMARK__A).Invoke_O_O_O__O(root_50, arg_53, arg_54) }; if linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_46, arg_49) } } else {
//line :84:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_build_go_clj_files_fn__1901000020_A_New() *A_arbace_build_go_clj_files_fn__1901000020_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000020_A{}; t.Ctor(); return t }
//line :86:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Ctor() {}
//line :86:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Invoke_O_O__O(self, p1__1901000019_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000019_SHARP___1)).GetPath__String().Ref() }

func A_arbace_build_go_package_file_QMARK__A_New() *A_arbace_build_go_package_file_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__A{}; t.Ctor(); return t }
//line :88:1
func (t *A_arbace_build_go_package_file_QMARK__A) Ctor() {}
//line :88:1
func (t *A_arbace_build_go_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var root_60 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_62 lang.IFn; if




	linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp1 any = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New(); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_68 any = forms__3; if linked_65 == nil { arg_63 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if linked_61 == nil { ns_form__4 = ifn_62.Invoke_O__O(arg_63) } else { ns_form__4 = linked_61.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_60, arg_63) }; var aliases__5 any; if
	jrt.J2g_Truth(ns_form__4) { aliases__5 = A_arbace_build_go_A_const_23.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp3 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_78 any = A_arbace_build_go_A_const_24.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var tmp4 any = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(aliases__5); var tmp5 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_83, false); A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class = fncls__116d; tmp5 = fncls__116d } else { tmp5 = fncls__116 }; arg_81 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_82 any = forms__3; if linked_79 == nil { tmp3 = ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { tmp3 = linked_79.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) } } else {
//line :96:1
			tmp3 = and__1927000168__auto____6 }; return /*line :95:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() }
//line :93:1
func A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New() *A_arbace_build_go_package_file_QMARK__fn__1901000027_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000027_A{}; t.Ctor(); return t }
//line :93:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Ctor() {}
//line :93:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Invoke_O_O__O(self, p1__1901000025_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_69 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = p1__1901000025_SHARP___1; if linked_70 == nil { and__1927000168__auto____2 = ifn_71.Invoke_O__O(arg_72) } else { and__1927000168__auto____2 = linked_70.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_build_go_A_const_22; var tmp2 any; var root_73 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = p1__1901000025_SHARP___1; if linked_74 == nil { tmp2 = ifn_75.Invoke_O__O(arg_76) } else { tmp2 = linked_74.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_73, arg_76) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(p0 any) *A_arbace_build_go_package_file_QMARK__fn__1901000029_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000029_A{}; t.Ctor_O(p0); return t }
//line :97:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :97:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Invoke_O_O__O(self, p1__1901000026_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_83 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = p1__1901000026_SHARP___1; if linked_84 == nil { and__1927000168__auto____2 = ifn_85.Invoke_O__O(arg_86) } else { and__1927000168__auto____2 = linked_84.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_87 any = A_arbace_build_go_A_const_25.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_91 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = p1__1901000026_SHARP___1; if linked_92 == nil { arg_90 = ifn_93.Invoke_O__O(arg_94) } else { arg_90 = linked_92.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_91, arg_94) }; if linked_88 == nil { and__1927000168__auto____3 = ifn_89.Invoke_O__O(arg_90) } else { and__1927000168__auto____3 = linked_88.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool; var tmp1 any; var root_95 any = A_arbace_build_go_A_const_26.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_97 lang.IFn
															if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_99 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = p1__1901000026_SHARP___1; if linked_100 == nil { arg_98 = ifn_101.Invoke_O__O(arg_102) } else { arg_98 = linked_100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_99, arg_102) }; if linked_96 == nil { tmp1 = ifn_97.Invoke_O__O(arg_98) } else { tmp1 = linked_96.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_95, arg_98) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(Lit_84, tmp1)
//line :97:1
	if and__1927000168__auto____4 {

		var root_103 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = t.F_aliases; var arg_107 any; var root_108 any = A_arbace_build_go_A_const_28.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var root_112 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = p1__1901000026_SHARP___1; if linked_113 == nil { arg_111 = ifn_114.Invoke_O__O(arg_115) } else { arg_111 = linked_113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_112, arg_115) }; if linked_109 == nil { arg_107 = ifn_110.Invoke_O__O(arg_111) } else { arg_107 = linked_109.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_108, arg_111) }; if linked_104 == nil { return ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { return linked_104.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_103, arg_106, arg_107) } } else {
//line :97:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_build_go_rel_path_A_New() *A_arbace_build_go_rel_path_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_rel_path_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_build_go_rel_path_A) Ctor() {}
//line :104:1
func (t *A_arbace_build_go_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	var root_117 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = jrt.NN(jrt.NN(jrt.File_Cast(base__0)).GetAbsoluteFile__File()).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).ToPath__Path()); if linked_118 == nil { return ifn_119.Invoke_O__O(arg_120) } else { return linked_118.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_117, arg_120)
	} }
func A_arbace_build_go_packages_A_New() *A_arbace_build_go_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_A{}; t.Ctor(); return t }
//line :107:1
func (t *A_arbace_build_go_packages_A) Ctor() {}
//line :107:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O_O__O(self, dir__0, roots__1, print_cache__2 any) any { var own__4 any; var root_121 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_build_go_root_packages_A_fn_class); var ifn_123 lang.IFn; if








	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = dir__0; var arg_125 any = print_cache__2; if linked_122 == nil { own__4 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { own__4 = linked_122.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; var more__5 any; var iter__1927001039__auto____5 any; var tmp1 any = /*line :107:1*/A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(print_cache__2); var tmp2 *jrt.Class; var fncls__254 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class; if









	fncls__254 == nil { var fncls__254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_85, false); A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class = fncls__254d; tmp2 = fncls__254d } else { tmp2 = fncls__254 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); more__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(roots__1); var pkgs__6 any; var root_255 any = /*line :107:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_256 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_255, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_257 lang.IFn; if













	linked_256 == nil { ifn_257 = lang.IFn_Cast(root_255) } else { ifn_257 = nil }; var arg_258 any; var root_259 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_260 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_259, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_261 lang.IFn; if linked_260 == nil { ifn_261 = lang.IFn_Cast(root_259) } else { ifn_261 = nil }; var arg_262 any = own__4; var arg_263 any = more__5; if linked_260 == nil { arg_258 = ifn_261.Invoke_O_O__O(arg_262, arg_263) } else { arg_258 = linked_260.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_259, arg_262, arg_263) }; if linked_256 == nil { pkgs__6 = ifn_257.Invoke_O__O(arg_258) } else { pkgs__6 = linked_256.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_255, arg_258) }; var seq_1901000050__7 any; var root_264 any = /*line :107:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_265 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_264, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_266 lang.IFn; if














	linked_265 == nil { ifn_266 = lang.IFn_Cast(root_264) } else { ifn_266 = nil }; var arg_267 any; var root_268 any = A_arbace_build_go_A_const_47.GetRawRoot__O(); var linked_269 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_268, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_270 lang.IFn; if linked_269 == nil { ifn_270 = lang.IFn_Cast(root_268) } else { ifn_270 = nil }; var arg_271 any = A_arbace_build_go_A_const_48; var arg_272 any = pkgs__6; if linked_269 == nil { arg_267 = ifn_270.Invoke_O_O__O(arg_271, arg_272) } else { arg_267 = linked_269.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_268, arg_271, arg_272) }; if linked_265 == nil { seq_1901000050__7 = ifn_266.Invoke_O__O(arg_267) } else { seq_1901000050__7 = linked_265.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_264, arg_267) }; var chunk_1901000051__8 any; var count_1901000052__9 int64 = 0; var i_1901000053__10 int64 = 0; L1:
//line :107:1
	for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000053__10, count_1901000052__9) { var vec__1901000054__11 any = lang.Indexed_Cast(chunk_1901000051__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000053__10)); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__13)), 1) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp5 any; var root_293 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_293, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_295 lang.IFn
			if linked_294 == nil { ifn_295 = lang.IFn_Cast(root_293) } else { ifn_295 = nil }; var arg_296 any = Lit_88; var arg_297 any; var root_298 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_299 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_298, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_300 lang.IFn; if linked_299 == nil { ifn_300 = lang.IFn_Cast(root_298) } else { ifn_300 = nil }; var arg_301 any; var tmp6 any = A_arbace_build_go_packages_fn__1901000057_A_New(); var tmp7 *jrt.Class; var fncls__303 *jrt.Class = A_arbace_build_go_packages_fn__1901000057_A_fn_class; if fncls__303 == nil { var fncls__303d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_build_go_packages_fn__1901000057_A_fn_class = fncls__303d; tmp7 = fncls__303d } else { tmp7 = fncls__303 }; arg_301 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_302 any = ps__13; if linked_299 == nil { arg_297 = ifn_300.Invoke_O_O__O(arg_301, arg_302) } else { arg_297 = linked_299.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_298, arg_301, arg_302) }; if linked_294 == nil { tmp5 = ifn_295.Invoke_O_O__O(arg_296, arg_297) } else { tmp5 = linked_294.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_293, arg_296, arg_297) }
//line :123:1
			tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__12, nil, tmp5)).Ref())
//line :122:1
			seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } else { seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_273 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = seq_1901000050__7; if linked_274 == nil { temp__1927000414__auto____11 = ifn_275.Invoke_O__O(arg_276) } else { temp__1927000414__auto____11 = linked_274.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_273, arg_276) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000050__12 any = temp__1927000414__auto____11; var tmp8 any; var root_277 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_277, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_279 lang.IFn; if linked_278 == nil { ifn_279 = lang.IFn_Cast(root_277) } else { ifn_279 = nil }; var arg_280 any = seq_1901000050__12; if linked_278 == nil { tmp8 = ifn_279.Invoke_O__O(arg_280) } else { tmp8 = linked_278.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_277, arg_280) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____13 any; var root_281 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_283 lang.IFn; if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = seq_1901000050__12; if linked_282 == nil { c__1927000678__auto____13 = ifn_283.Invoke_O__O(arg_284) } else { c__1927000678__auto____13 = linked_282.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_281, arg_284) }; var tmp9 any; var root_304 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_305 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_304, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_306 lang.IFn; if linked_305 == nil { ifn_306 = lang.IFn_Cast(root_304) } else { ifn_306 = nil }; var arg_307 any = seq_1901000050__12; if linked_305 == nil { tmp9 = ifn_306.Invoke_O__O(arg_307) } else { tmp9 = linked_305.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_304, arg_307) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp9, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000059__13 any; var root_285 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_285, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_287 lang.IFn; if linked_286 == nil { ifn_287 = lang.IFn_Cast(root_285) } else { ifn_287 = nil }; var arg_288 any = seq_1901000050__12; if linked_286 == nil { vec__1901000059__13 = ifn_287.Invoke_O__O(arg_288) } else { vec__1901000059__13 = linked_286.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_285, arg_288) }; var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__15)), 1) {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp12 any; var root_312 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_313 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_312, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_314 lang.IFn
				if linked_313 == nil { ifn_314 = lang.IFn_Cast(root_312) } else { ifn_314 = nil }; var arg_315 any = Lit_88; var arg_316 any; var root_317 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_318 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_317, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_319 lang.IFn; if linked_318 == nil { ifn_319 = lang.IFn_Cast(root_317) } else { ifn_319 = nil }; var arg_320 any; var tmp13 any = A_arbace_build_go_packages_fn__1901000062_A_New(); var tmp14 *jrt.Class; var fncls__322 *jrt.Class = A_arbace_build_go_packages_fn__1901000062_A_fn_class; if fncls__322 == nil { var fncls__322d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_build_go_packages_fn__1901000062_A_fn_class = fncls__322d; tmp14 = fncls__322d } else { tmp14 = fncls__322 }; arg_320 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_321 any = ps__15; if linked_318 == nil { arg_316 = ifn_319.Invoke_O_O__O(arg_320, arg_321) } else { arg_316 = linked_318.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_317, arg_320, arg_321) }; if linked_313 == nil { tmp12 = ifn_314.Invoke_O_O__O(arg_315, arg_316) } else { tmp12 = linked_313.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_312, arg_315, arg_316) }
//line :123:1
				tmp10.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, path__14, nil, tmp12)).Ref())
//line :122:1
				var tmp15 any; var root_323 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_324 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_323, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_325 lang.IFn; if linked_324 == nil { ifn_325 = lang.IFn_Cast(root_323) } else { ifn_325 = nil }; var arg_326 any = seq_1901000050__12; if linked_324 == nil { tmp15 = ifn_325.Invoke_O__O(arg_326) } else { tmp15 = linked_324.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_323, arg_326) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp15, nil, 0, 0; continue L1 } else { var tmp16 any; var root_327 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_327, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_329 lang.IFn; if linked_328 == nil { ifn_329 = lang.IFn_Cast(root_327) } else { ifn_329 = nil }; var arg_330 any = seq_1901000050__12; if linked_328 == nil { tmp16 = ifn_329.Invoke_O__O(arg_330) } else { tmp16 = linked_328.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_327, arg_330) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp16, nil, 0, 0; continue L1 } } } }
//line :107:1
		break L1 }; return pkgs__6 }
//line :107:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any {






	var root_331 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, A_arbace_build_go_packages_A_fn_class); var ifn_333 lang.IFn; if linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any = dir__0; var arg_335 any = roots__1; var arg_336 any; if linked_332 == nil { return ifn_333.Invoke_O_O_O__O(arg_334, arg_335, arg_336) } else { return linked_332.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_331, arg_334, arg_335, arg_336) } }
//line :107:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O__O(self, dir__0 any) any {





	var root_337 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_337, A_arbace_build_go_packages_A_fn_class); var ifn_339 lang.IFn; if linked_338 == nil { ifn_339 = lang.IFn_Cast(root_337) } else { ifn_339 = nil }; var arg_340 any = dir__0; var arg_341 any; var arg_342 any; if linked_338 == nil { return ifn_339.Invoke_O_O_O__O(arg_340, arg_341, arg_342) } else { return linked_338.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_337, arg_340, arg_341, arg_342)
	}
}

func A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(p0 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_A{}; t.Ctor_O(p0); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Ctor_O(c__print_cache any) { t.F_print_cache = c__print_cache }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Invoke_O_O__O(self, s__1901000035__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(self, t.F_print_cache, s__1901000035__1); var tmp2 *jrt.Class; var fncls__253 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class; if fncls__253 == nil { var fncls__253d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class = fncls__253d; tmp2 = fncls__253d } else { tmp2 = fncls__253 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Ctor_O_O_O(c__iter__1901000034, c__print_cache, c__s__1901000035 any) { t.F_iter__1901000034 = c__iter__1901000034; t.F_print_cache = c__print_cache; t.F_s__1901000035 = c__s__1901000035 }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Invoke_O__O(self any) any { { var s__1901000035__1 any; var t_ any = t.F_s__1901000035; t.F_s__1901000035 = nil; s__1901000035__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_126 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = s__1901000035__1; if linked_127 == nil { temp__1927000414__auto____2 = ifn_128.Invoke_O__O(arg_129) } else { temp__1927000414__auto____2 = linked_127.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_126, arg_129) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_130 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = xs__1927001018__auto____3; if linked_131 == nil { r__4 = ifn_132.Invoke_O__O(arg_133) } else { r__4 = linked_131.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_130, arg_133) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New(); var tmp2 *jrt.Class; var fncls__226 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class; if fncls__226 == nil { var fncls__226d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class = fncls__226d; tmp2 = fncls__226d } else { tmp2 = fncls__226 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_227 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_227, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_229 lang.IFn; if linked_228 == nil { ifn_229 = lang.IFn_Cast(root_227) } else { ifn_229 = nil }; var arg_230 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_231 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_231, A_arbace_build_go_root_packages_A_fn_class); var ifn_233 lang.IFn
														if linked_232 == nil { ifn_233 = lang.IFn_Cast(root_231) } else { ifn_233 = nil }; var arg_234 any; var tmp5 any; var root_236 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_236, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_238 lang.IFn; if linked_237 == nil { ifn_238 = lang.IFn_Cast(root_236) } else { ifn_238 = nil }; var arg_239 any = r__4; if linked_237 == nil { tmp5 = ifn_238.Invoke_O__O(arg_239) } else { tmp5 = linked_237.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_236, arg_239) }; arg_234 = jrt.File_New_String(jrt.String_Cast(tmp5)); var arg_235 any = t.F_print_cache; if linked_232 == nil { tmp4 = ifn_233.Invoke_O_O__O(arg_234, arg_235) } else { tmp4 = linked_232.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_231, arg_234, arg_235) }
//line :117:1
	arg_230 = tmp3.Invoke_O__O(tmp4); if linked_228 == nil { fs__1927001036__auto____6 = ifn_229.Invoke_O__O(arg_230) } else { fs__1927001036__auto____6 = linked_228.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_227, arg_230) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_240 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_241 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_240, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_242 lang.IFn; if linked_241 == nil { ifn_242 = lang.IFn_Cast(root_240) } else { ifn_242 = nil }; var arg_243 any = fs__1927001036__auto____6; var arg_244 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000034); var tmp7 any; var root_245 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_246 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_245, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_247 lang.IFn; if linked_246 == nil { ifn_247 = lang.IFn_Cast(root_245) } else { ifn_247 = nil }; var arg_248 any = s__1901000035__1; if linked_246 == nil { tmp7 = ifn_247.Invoke_O__O(arg_248) } else { tmp7 = linked_246.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_245, arg_248) }; arg_244 = tmp6.Invoke_O__O(tmp7); if linked_241 == nil { return ifn_242.Invoke_O_O__O(arg_243, arg_244) } else { return linked_241.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_240, arg_243, arg_244) } } else { var tmp8 any; var root_249 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_249, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_251 lang.IFn; if linked_250 == nil { ifn_251 = lang.IFn_Cast(root_249) } else { ifn_251 = nil }; var arg_252 any = s__1901000035__1; if linked_250 == nil { tmp8 = ifn_251.Invoke_O__O(arg_252) } else { tmp8 = linked_250.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_249, arg_252) }; s__1901000035__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New() *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A{}; t.Ctor(); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Ctor() {}
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Invoke_O_O__O(self, s__1901000037__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(self, s__1901000037__1); var tmp2 *jrt.Class; var fncls__225 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class; if fncls__225 == nil { var fncls__225d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class = fncls__225d; tmp2 = fncls__225d } else { tmp2 = fncls__225 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(p0, p1 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Ctor_O_O(c__iter__1901000036, c__s__1901000037 any) { t.F_iter__1901000036 = c__iter__1901000036; t.F_s__1901000037 = c__s__1901000037 }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Invoke_O__O(self any) any { { var s__1901000037__1 any; var t_ any = t.F_s__1901000037; t.F_s__1901000037 = nil; s__1901000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_134 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1901000037__1; if linked_135 == nil { temp__1927000414__auto____2 = ifn_136.Invoke_O__O(arg_137) } else { temp__1927000414__auto____2 = linked_135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_138 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1901000037__3; if linked_139 == nil { tmp1 = ifn_140.Invoke_O__O(arg_141) } else { tmp1 = linked_139.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_142 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = s__1901000037__3; if linked_143 == nil { c__1927001037__auto____4 = ifn_144.Invoke_O__O(arg_145) } else { c__1927001037__auto____4 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_142, arg_145) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000039__6 any; var root_146 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_147 == nil { b__1901000039__6 = ifn_148.Invoke_O__O(arg_149) } else { b__1901000039__6 = linked_147.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_146, arg_149) }; var tmp2 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(b__1901000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__170 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class; if fncls__170 == nil { var fncls__170d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_94, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class = fncls__170d; tmp3 = fncls__170d } else { tmp3 = fncls__170 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_171 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_171, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_173 lang.IFn; if linked_172 == nil { ifn_173 = lang.IFn_Cast(root_171) } else { ifn_173 = nil }; var arg_174 any; var root_176 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_176, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_178 lang.IFn; if linked_177 == nil { ifn_178 = lang.IFn_Cast(root_176) } else { ifn_178 = nil }; var arg_179 any = b__1901000039__6; if linked_177 == nil { arg_174 = ifn_178.Invoke_O__O(arg_179) } else { arg_174 = linked_177.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_176, arg_179) }; var arg_175 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp5 any; var root_180 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_180, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_182 lang.IFn; if linked_181 == nil { ifn_182 = lang.IFn_Cast(root_180) } else { ifn_182 = nil }; var arg_183 any = s__1901000037__3; if linked_181 == nil { tmp5 = ifn_182.Invoke_O__O(arg_183) } else { tmp5 = linked_181.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_180, arg_183) }; arg_175 = tmp4.Invoke_O__O(tmp5); if linked_172 == nil { return ifn_173.Invoke_O_O__O(arg_174, arg_175) } else { return linked_172.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_171, arg_174, arg_175) } } else { var root_184 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_184, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_186 lang.IFn; if linked_185 == nil { ifn_186 = lang.IFn_Cast(root_184) } else { ifn_186 = nil }; var arg_187 any; var root_189 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_190 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_189, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_191 lang.IFn; if linked_190 == nil { ifn_191 = lang.IFn_Cast(root_189) } else { ifn_191 = nil }; var arg_192 any = b__1901000039__6; if linked_190 == nil { arg_187 = ifn_191.Invoke_O__O(arg_192) } else { arg_187 = linked_190.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_189, arg_192) }; var arg_188 any; if linked_185 == nil { return ifn_186.Invoke_O_O__O(arg_187, arg_188) } else { return linked_185.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_184, arg_187, arg_188) } } } else { var pkg__4 any; var root_193 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_194 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_193, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_195 lang.IFn; if linked_194 == nil { ifn_195 = lang.IFn_Cast(root_193) } else { ifn_195 = nil }; var arg_196 any = s__1901000037__3; if linked_194 == nil { pkg__4 = ifn_195.Invoke_O__O(arg_196) } else { pkg__4 = linked_194.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_193, arg_196) }; var tmp6 any; var root_197 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_198 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_197, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_199 lang.IFn

	if linked_198 == nil { ifn_199 = lang.IFn_Cast(root_197) } else { ifn_199 = nil }; var arg_200 any = Lit_95; var arg_201 any; var root_202 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_203 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_202, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_204 lang.IFn; if linked_203 == nil { ifn_204 = lang.IFn_Cast(root_202) } else { ifn_204 = nil }; var arg_205 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__4); if linked_203 == nil { arg_201 = ifn_204.Invoke_O__O(arg_205) } else { arg_201 = linked_203.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_202, arg_205) }; if linked_198 == nil { tmp6 = ifn_199.Invoke_O_O__O(arg_200, arg_201) } else { tmp6 = linked_198.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_197, arg_200, arg_201) }
//line :117:1
	if jrt.J2g_Truth(tmp6) { var root_206 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_207 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_206, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_208 lang.IFn; if linked_207 == nil { ifn_208 = lang.IFn_Cast(root_206) } else { ifn_208 = nil }; var arg_209 any; var root_211 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_212 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_211, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_213 lang.IFn


		if linked_212 == nil { ifn_213 = lang.IFn_Cast(root_211) } else { ifn_213 = nil }; var arg_214 any = pkg__4; var arg_215 any = A_arbace_build_go_A_const_39; var arg_216 any = jrt.Boolean_TRUE.Ref(); if linked_212 == nil { arg_209 = ifn_213.Invoke_O_O_O__O(arg_214, arg_215, arg_216) } else { arg_209 = linked_212.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_211, arg_214, arg_215, arg_216) }
//line :117:1
		var arg_210 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp8 any; var root_217 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_218 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_217, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_219 lang.IFn; if linked_218 == nil { ifn_219 = lang.IFn_Cast(root_217) } else { ifn_219 = nil }; var arg_220 any = s__1901000037__3; if linked_218 == nil { tmp8 = ifn_219.Invoke_O__O(arg_220) } else { tmp8 = linked_218.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_217, arg_220) }; arg_210 = tmp7.Invoke_O__O(tmp8); if linked_207 == nil { return ifn_208.Invoke_O_O__O(arg_209, arg_210) } else { return linked_207.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_206, arg_209, arg_210) } } else { var tmp9 any; var root_221 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_222 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_221, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_223 lang.IFn; if linked_222 == nil { ifn_223 = lang.IFn_Cast(root_221) } else { ifn_223 = nil }; var arg_224 any = s__1901000037__3; if linked_222 == nil { tmp9 = ifn_223.Invoke_O__O(arg_224) } else { tmp9 = linked_222.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_221, arg_224) }; s__1901000037__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :117:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Ctor_O_I_O(c__b__1901000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000039 = c__b__1901000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :117:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Invoke_O__O(self any) any { { var i__1901000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000038__1)); var tmp2 any; var root_150 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_152 lang.IFn

	if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = Lit_95; var arg_154 any; var root_155 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__2); if linked_156 == nil { arg_154 = ifn_157.Invoke_O__O(arg_158) } else { arg_154 = linked_156.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_155, arg_158) }; if linked_151 == nil { tmp2 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { tmp2 = linked_151.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }
//line :117:1
	if jrt.J2g_Truth(tmp2) { var root_159 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = t.F_b__1901000039; var arg_163 any; var root_164 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_165 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_164, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_166 lang.IFn


		if linked_165 == nil { ifn_166 = lang.IFn_Cast(root_164) } else { ifn_166 = nil }; var arg_167 any = pkg__2; var arg_168 any = A_arbace_build_go_A_const_39; var arg_169 any = jrt.Boolean_TRUE.Ref(); if linked_165 == nil { arg_163 = ifn_166.Invoke_O_O_O__O(arg_167, arg_168, arg_169) } else { arg_163 = linked_165.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_164, arg_167, arg_168, arg_169) }
//line :117:1
		if linked_160 == nil { ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { linked_160.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } else { i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_build_go_packages_fn__1901000057_A_New() *A_arbace_build_go_packages_fn__1901000057_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000057_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }
//line :124:1
func A_arbace_build_go_packages_fn__1901000062_A_New() *A_arbace_build_go_packages_fn__1901000062_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000062_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }


func A_arbace_build_go_read_all_A_New() *A_arbace_build_go_read_all_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_A{}; t.Ctor(); return t }
//line :127:1
func (t *A_arbace_build_go_read_all_A) Ctor() {}
//line :127:1
func (t *A_arbace_build_go_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var root_343 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_344 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_343, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_345 lang.IFn; if




	linked_344 == nil { ifn_345 = lang.IFn_Cast(root_343) } else { ifn_345 = nil }; var arg_346 any; var root_348 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_348, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_350 lang.IFn; if linked_349 == nil { ifn_350 = lang.IFn_Cast(root_348) } else { ifn_350 = nil }; var arg_351 any; var tmp1 any = A_arbace_build_go_read_all_fn__1901000066_A_New(); var tmp2 *jrt.Class; var fncls__353 *jrt.Class = A_arbace_build_go_read_all_fn__1901000066_A_fn_class; if fncls__353 == nil { var fncls__353d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_build_go_read_all_fn__1901000066_A_fn_class = fncls__353d; tmp2 = fncls__353d } else { tmp2 = fncls__353 }; arg_351 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_352 any = files__0; if linked_349 == nil { arg_346 = ifn_350.Invoke_O_O__O(arg_351, arg_352) } else { arg_346 = linked_349.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_348, arg_351, arg_352) }; var arg_347 any; var root_354 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_355 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_354, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_356 lang.IFn; if
	linked_355 == nil { ifn_356 = lang.IFn_Cast(root_354) } else { ifn_356 = nil }; var arg_357 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var arg_358 any = files__0; if linked_355 == nil { arg_347 = ifn_356.Invoke_O_O__O(arg_357, arg_358) } else { arg_347 = linked_355.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_354, arg_357, arg_358) }; if /*line :132:1*/ linked_344 == nil { cache__2 = ifn_345.Invoke_O_O__O(arg_346, arg_347) } else { cache__2 = linked_344.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_343, arg_346, arg_347) }; var tmp3 any =

	A_arbace_build_go_read_all_fn__1901000068_A_New_O(cache__2); var tmp4 *jrt.Class; var fncls__368 *jrt.Class = A_arbace_build_go_read_all_fn__1901000068_A_fn_class; if fncls__368 == nil { var fncls__368d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_build_go_read_all_fn__1901000068_A_fn_class = fncls__368d; tmp4 = fncls__368d } else { tmp4 = fncls__368 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }
//line :132:1
func A_arbace_build_go_read_all_fn__1901000066_A_New() *A_arbace_build_go_read_all_fn__1901000066_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000066_A{}; t.Ctor(); return t }
//line :132:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Ctor() {}
//line :132:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Invoke_O_O__O(self, p1__1901000065_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000065_SHARP___1)).GetAbsolutePath__String().Ref() }

func A_arbace_build_go_read_all_fn__1901000068_A_New_O(p0 any) *A_arbace_build_go_read_all_fn__1901000068_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000068_A{}; t.Ctor_O(p0); return t }
//line :134:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :134:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__1)).GetAbsolutePath__String().Ref(); var tmp1 any; var root_359 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_360 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_359, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_361 lang.IFn; if

	linked_360 == nil { ifn_361 = lang.IFn_Cast(root_359) } else { ifn_361 = nil }; var arg_362 any = t.F_cache; var arg_363 any = k__2; if linked_360 == nil { tmp1 = ifn_361.Invoke_O_O__O(arg_362, arg_363) } else { tmp1 = linked_360.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_359, arg_362, arg_363) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_cache, k__2) } else { var root_364 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var linked_365 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_364, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_366 lang.IFn; if linked_365 == nil { ifn_366 = lang.IFn_Cast(root_364) } else { ifn_366 = nil }; var arg_367 any = f__1; if linked_365 == nil { return ifn_366.Invoke_O__O(arg_367) } else { return linked_365.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_364, arg_367) } } }

func A_arbace_build_go_hex_A_New() *A_arbace_build_go_hex_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_build_go_hex_A) Ctor() {}
//line :138:1
func (t *A_arbace_build_go_hex_A) Invoke_O_O__O(self, bs__0 any) any {
	var root_369 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_370 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_369, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_371 lang.IFn; if linked_370 == nil { ifn_371 = lang.IFn_Cast(root_369) } else { ifn_371 = nil }; var arg_372 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_373 any; var root_374 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_374, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_376 lang.IFn; if linked_375 == nil { ifn_376 = lang.IFn_Cast(root_374) } else { ifn_376 = nil }; var arg_377 any; var tmp1 any = A_arbace_build_go_hex_fn__1901000072_A_New(); var tmp2 *jrt.Class; var fncls__389 *jrt.Class = A_arbace_build_go_hex_fn__1901000072_A_fn_class; if fncls__389 == nil { var fncls__389d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_build_go_hex_fn__1901000072_A_fn_class = fncls__389d; tmp2 = fncls__389d } else { tmp2 = fncls__389 }; arg_377 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_378 any = bs__0; if linked_375 == nil { arg_373 = ifn_376.Invoke_O_O__O(arg_377, arg_378) } else { arg_373 = linked_375.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_374, arg_377, arg_378) }; if linked_370 == nil { return ifn_371.Invoke_O_O__O(arg_372, arg_373) } else { return linked_370.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_369, arg_372, arg_373) } }
//line :139:1
func A_arbace_build_go_hex_fn__1901000072_A_New() *A_arbace_build_go_hex_fn__1901000072_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_fn__1901000072_A{}; t.Ctor(); return t }
//line :139:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Ctor() {}
//line :139:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Invoke_O_O__O(self, p1__1901000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_384 any = p1__1901000071_SHARP___1; var na_385 int64 = 255; if jrt.Long_InstanceOf(na_384) { var n0_386 int64 = jrt.NN(jrt.Long_Cast(na_384)).LongValue__J(); var n1_387 int64 = na_385; tmp2 = n0_386 & n1_387 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_384, na_385) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_file_sha_A_New() *A_arbace_build_go_file_sha_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_file_sha_A{}; t.Ctor(); return t }
//line :141:1
func (t *A_arbace_build_go_file_sha_A) Ctor() {}
//line :141:1
func (t *A_arbace_build_go_file_sha_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		var root_390 any = A_arbace_build_go_A_const_60.GetRawRoot__O(); var linked_391 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_390, A_arbace_build_go_hex_A_fn_class); var ifn_392 lang.IFn; if linked_391 == nil { ifn_392 = lang.IFn_Cast(root_390) } else { ifn_392 = nil }; var arg_393 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref(); if linked_391 == nil { return ifn_392.Invoke_O__O(arg_393) } else { return linked_391.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_390, arg_393) } } else {
//line :144:1
			return nil
		}
}
func A_arbace_build_go_collect_package_A_New() *A_arbace_build_go_collect_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_A{}; t.Ctor(); return t }
//line :147:1
func (t *A_arbace_build_go_collect_package_A) Ctor() {}
//line :147:1
func (t *A_arbace_build_go_collect_package_A) Invoke_O_O_O_O__O(self, dir__0, f__1, read_fn__2 any) any { var read__4 any; var root_394 any = A_arbace_build_go_A_const_61.GetRawRoot__O(); var linked_395 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_394, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_396 lang.IFn; if



	linked_395 == nil { ifn_396 = lang.IFn_Cast(root_394) } else { ifn_396 = nil }; var arg_397 any = lang.PersistentVector_EMPTY.Ref(); if linked_395 == nil { read__4 = ifn_396.Invoke_O__O(arg_397) } else { read__4 = linked_395.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_394, arg_397) }; var pkg__5 any; var root_398 any = /*line :147:1*/A_arbace_build_go_A_const_62.GetRawRoot__O(); var linked_399 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_398, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_400 lang.IFn; if




	linked_399 == nil { ifn_400 = lang.IFn_Cast(root_398) } else { ifn_400 = nil }; var arg_401 any = f__1; var arg_402 any; var tmp1 any = A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(read_fn__2, read__4); var tmp2 *jrt.Class; var fncls__409 *jrt.Class = A_arbace_build_go_collect_package_fn__1901000076_A_fn_class; if fncls__409 == nil { var fncls__409d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_55, false); A_arbace_build_go_collect_package_fn__1901000076_A_fn_class = fncls__409d; tmp2 = fncls__409d } else { tmp2 = fncls__409 }; arg_402 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_399 == nil { pkg__5 = ifn_400.Invoke_O_O__O(arg_401, arg_402) } else { pkg__5 = linked_399.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_398, arg_401, arg_402) }; var tmp3 /*line :147:1*/*lang.Keyword = A_arbace_build_go_A_const_48; var path__6 any = tmp3.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__5)); var tmp4 any; var root_424 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_424, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_426 lang.IFn; if






	linked_425 == nil { ifn_426 = lang.IFn_Cast(root_424) } else { ifn_426 = nil }; var arg_427 any = path__6; if linked_425 == nil { tmp4 = ifn_426.Invoke_O__O(arg_427) } else { tmp4 = linked_425.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_424, arg_427) }; if jrt.J2g_Truth(tmp4) { } else {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_56); var tmp7 any; var root_432 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_432, A_arbace_build_go_rel_path_A_fn_class); var ifn_434 lang.IFn; if linked_433 == nil { ifn_434 = lang.IFn_Cast(root_432) } else { ifn_434 = nil }; var arg_435 any = dir__0; var arg_436 any = f__1; if linked_433 == nil { tmp7 = ifn_434.Invoke_O_O__O(arg_435, arg_436) } else { tmp7 = linked_433.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_432, arg_435, arg_436) }; tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref()) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp9 any = A_arbace_build_go_A_const_52; var tmp10 any = A_arbace_build_go_A_const_48; var tmp11 any = A_arbace_build_go_A_const_65; var tmp12 any; var root_420 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = read__4; if linked_421 == nil { tmp12 = ifn_422.Invoke_O__O(arg_423) } else { tmp12 = linked_421.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_420, arg_423) }; return tmp8.Invoke_O_O_O_O_O_O_O__O(pkg__5, tmp9, f__1, tmp10, path__6, tmp11, tmp12) }
//line :152:1
func A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(p0, p1 any) *A_arbace_build_go_collect_package_fn__1901000076_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_fn__1901000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :152:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :152:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Invoke_O_O__O(self, file__1 any) any { var root_403 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_404 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_403, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_405 lang.IFn; if linked_404 == nil { ifn_405 = lang.IFn_Cast(root_403) } else { ifn_405 = nil }; var arg_406 any = t.F_read; var arg_407 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_408 any = file__1; if linked_404 == nil { ifn_405.Invoke_O_O_O__O(arg_406, arg_407, arg_408) } else { linked_404.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_403, arg_406, arg_407, arg_408) }; return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }











func A_arbace_build_go_collect_index_file_A_New() *A_arbace_build_go_collect_index_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_index_file_A{}; t.Ctor(); return t }
//line :164:1
func (t *A_arbace_build_go_collect_index_file_A) Ctor() {}
//line :164:1
func (t *A_arbace_build_go_collect_index_file_A) Invoke_O_O_O_O__O(self, print_cache__0, host_id__1, dir__2 any) any { var md__4 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52);

	jrt.MessageDigest_Cast(md__4).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45, nil), jrt.RefArrayOf(jrt.Object_class, host_id__1, nil, jrt.NN(jrt.File_Cast(dir__2)).GetPath__String().Ref()))).GetBytes_String__B1(Lit_53)); var tmp1 /*line :164:1*/*jrt.Class = A_arbace_build_go_A_const_68; var tmp2 any; var root_437 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_439 lang.IFn; if


	linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = print_cache__0; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_437, arg_440) }; var tmp3 any = /*line :164:1*/jrt.File_New_String_String(jrt.String_Cast(tmp2), Lit_54); var tmp4 any; var root_441 any = A_arbace_build_go_A_const_60.GetRawRoot__O(); var linked_442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_441, A_arbace_build_go_hex_A_fn_class); var ifn_443 lang.IFn; if


	linked_442 == nil { ifn_443 = lang.IFn_Cast(root_441) } else { ifn_443 = nil }; var arg_444 any = jrt.MessageDigest_Cast(md__4).Digest__B1().Ref(); if linked_442 == nil { tmp4 = ifn_443.Invoke_O__O(arg_444) } else { tmp4 = linked_442.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_441, arg_444) }; return /*line :164:1*/ lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)) }




func A_arbace_build_go_read_index_A_New() *A_arbace_build_go_read_index_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_index_A{}; t.Ctor(); return t }
//line :169:1
func (t *A_arbace_build_go_read_index_A) Ctor() {}
//line :169:1
func (t *A_arbace_build_go_read_index_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
//line :172:1
		var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1901000080__4 any; var root_445 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_447 lang.IFn

			if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; var arg_448 any = f__0; if linked_446 == nil { vec__1901000080__4 = ifn_447.Invoke_O__O(arg_448) } else { vec__1901000080__4 = linked_446.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_445, arg_448) }
//line :172:1
			var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp2 any; var root_449 any = A_arbace_build_go_A_const_69.GetRawRoot__O(); var linked_450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_449, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_451 lang.IFn

			if linked_450 == nil { ifn_451 = lang.IFn_Cast(root_449) } else { ifn_451 = nil }; var arg_452 any = m__5; if linked_450 == nil { tmp2 = ifn_451.Invoke_O__O(arg_452) } else { tmp2 = linked_450.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_449, arg_452) }; if jrt.J2g_Truth(tmp2) { tmp1 = m__5 } else { tmp1 = nil } }; return nil }()
//line :172:1
		if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_build_go_write_index_BANG__A_New() *A_arbace_build_go_write_index_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__A{}; t.Ctor(); return t }
//line :177:1
func (t *A_arbace_build_go_write_index_BANG__A) Ctor() {}
//line :177:1
func (t *A_arbace_build_go_write_index_BANG__A) Invoke_O_O_O__O(self, f__0, index__1 any) any { var printed__3 any; var tmp1 any = A_arbace_build_go_write_index_BANG__printed__1901000087_A_New(); var tmp2 *jrt.Class; var fncls__473 *jrt.Class = A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class; if



	fncls__473 == nil { var fncls__473d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_192, false); A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class = fncls__473d; tmp2 = fncls__473d } else { tmp2 = fncls__473 }; printed__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var ok_QMARK___4 any; var tmp3 any = /*line :177:1*/A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(printed__3); var tmp4 *jrt.Class; var fncls__478 *jrt.Class = A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class; if



	fncls__478 == nil { var fncls__478d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_193, false); A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class = fncls__478d; tmp4 = fncls__478d } else { tmp4 = fncls__478 }; ok_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var index__5 any; var root_479 any = /*line :177:1*/A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_480 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_479, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_481 lang.IFn; if





	linked_480 == nil { ifn_481 = lang.IFn_Cast(root_479) } else { ifn_481 = nil }; var arg_482 any = index__1; var arg_483 any = A_arbace_build_go_A_const_79; var arg_484 any; var tmp5 any = A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(ok_QMARK___4); var tmp6 *jrt.Class; var fncls__504 *jrt.Class = A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class; if fncls__504 == nil { var fncls__504d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_194, false); A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class = fncls__504d; tmp6 = fncls__504d } else { tmp6 = fncls__504 }; arg_484 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_480 == nil { index__5 = ifn_481.Invoke_O_O_O__O(arg_482, arg_483, arg_484) } else { index__5 = linked_480.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_479, arg_482, arg_483, arg_484) }; var tmp__6 any = /*line :177:1*/jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));







	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File()).Mkdirs__Z());
	lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(tmp__6, lang.IFn_Cast(printed__3).Invoke_O__O(index__5)); if
	jrt.NN(jrt.File_Cast(tmp__6)).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__6)).Delete__Z()).Ref() } }
//line :181:1
func A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A{}; t.Ctor_O(p0); return t }
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Ctor_O(c__printed any) { t.F_printed = c__printed }
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Invoke_O_O__O(self, p1__1901000085_SHARP___1 any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var tmp2 any; var root_474 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_475 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_474, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_476 lang.IFn; if linked_475 == nil { ifn_476 = lang.IFn_Cast(root_474) } else { ifn_476 = nil }; var arg_477 any = lang.IFn_Cast(t.F_printed).Invoke_O__O(p1__1901000085_SHARP___1); if linked_475 == nil { tmp2 = ifn_476.Invoke_O__O(arg_477) } else { tmp2 = linked_475.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_474, arg_477) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__1901000085_SHARP___1, tmp2)).Ref() }
//line :181:1
	return nil }(); if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :181:1
func A_arbace_build_go_write_index_BANG__printed__1901000087_A_New() *A_arbace_build_go_write_index_BANG__printed__1901000087_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__printed__1901000087_A{}; t.Ctor(); return t }
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Ctor() {}
//line :181:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Invoke_O_O__O(self, p1__1901000084_SHARP___1 any) any { var root_460 any = A_arbace_build_go_A_const_72.GetRawRoot__O(); var linked_461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_460, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_462 lang.IFn; if linked_461 == nil { ifn_462 = lang.IFn_Cast(root_460) } else { ifn_462 = nil }; var arg_463 any = lang.IFn_Cast(A_arbace_build_go_A_const_73.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_build_go_A_const_74, jrt.Boolean_TRUE.Ref(), A_arbace_build_go_A_const_75, nil, A_arbace_build_go_A_const_76, nil); if linked_461 == nil { ifn_462.Invoke_O__O(arg_463) } else { linked_461.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_460, arg_463) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke_O__O(p1__1901000084_SHARP___1); return nil }(); var root_457 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_457, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_459 lang.IFn; if linked_458 == nil { ifn_459 = lang.IFn_Cast(root_457) } else { ifn_459 = nil }; if linked_458 == nil { ifn_459.Invoke__O() } else { linked_458.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_457) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__fn__1901000091_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__fn__1901000091_A{}; t.Ctor_O(p0); return t }
//line :183:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Ctor_O(c__ok_QMARK_ any) { t.F_ok_QMARK_ = c__ok_QMARK_ }
//line :183:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Invoke_O_O__O(self, p1__1901000086_SHARP___1 any) any { var root_485 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_486 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_485, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_487 lang.IFn; if linked_486 == nil { ifn_487 = lang.IFn_Cast(root_485) } else { ifn_487 = nil }; var arg_488 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_489 any; var root_494 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_495 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_494, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_496 lang.IFn; if linked_495 == nil { ifn_496 = lang.IFn_Cast(root_494) } else { ifn_496 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_82.GetRawRoot__O()); var tmp2 any = t.F_ok_QMARK_; var tmp3 any = A_arbace_build_go_A_const_83; var arg_497 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_build_go_A_const_84.GetRawRoot__O()); if linked_495 == nil { arg_489 = ifn_496.Invoke_O__O(arg_497) } else { arg_489 = linked_495.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_494, arg_497) }; var arg_490 any = p1__1901000086_SHARP___1; if linked_486 == nil { return ifn_487.Invoke_O_O_O__O(arg_488, arg_489, arg_490) } else { return linked_486.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_485, arg_488, arg_489, arg_490) } }





func A_arbace_build_go_root_packages_A_New() *A_arbace_build_go_root_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_A{}; t.Ctor(); return t }
//line :189:1
func (t *A_arbace_build_go_root_packages_A) Ctor() {}
//line :189:1
func (t *A_arbace_build_go_root_packages_A) Invoke_O_O_O__O(self, dir__0, print_cache__1 any) any { var root__3 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_142); if




	jrt.NN(jrt.File_Cast(root__3)).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil, Lit_144), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref(), nil)).Ref()) }; var files__4 any; var root_510 any = /*line :189:1*/A_arbace_build_go_A_const_86.GetRawRoot__O(); var linked_511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_510, A_arbace_build_go_clj_files_A_fn_class); var ifn_512 lang.IFn; if






	linked_511 == nil { ifn_512 = lang.IFn_Cast(root_510) } else { ifn_512 = nil }; var arg_513 any = root__3; if linked_511 == nil { files__4 = ifn_512.Invoke_O__O(arg_513) } else { files__4 = linked_511.(*A_arbace_build_go_clj_files_A).Invoke_O_O__O(root_510, arg_513) }; var host_id__5 any = /*line :189:1*/jrt.System_Getenv_String__String(Lit_113).Ref(); var index_file__6 any; var tmp1 any; var and__1927000168__auto____6 any = print_cache__1; if








	jrt.J2g_Truth(and__1927000168__auto____6) { var root_514 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_514, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_516 lang.IFn; if linked_515 == nil { ifn_516 = lang.IFn_Cast(root_514) } else { ifn_516 = nil }; var arg_517 any = host_id__5; if linked_515 == nil { tmp1 = ifn_516.Invoke_O__O(arg_517) } else { tmp1 = linked_515.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_514, arg_517) } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { var root_518 any = A_arbace_build_go_A_const_87.GetRawRoot__O(); var linked_519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_518, A_arbace_build_go_collect_index_file_A_fn_class); var ifn_520 lang.IFn; if linked_519 == nil { ifn_520 = lang.IFn_Cast(root_518) } else { ifn_520 = nil }; var arg_521 any = print_cache__1; var arg_522 any = host_id__5; var arg_523 any = dir__0; if linked_519 == nil { index_file__6 = ifn_520.Invoke_O_O_O__O(arg_521, arg_522, arg_523) } else { index_file__6 = linked_519.(*A_arbace_build_go_collect_index_file_A).Invoke_O_O_O_O__O(root_518, arg_521, arg_522, arg_523) } } else { index_file__6 = nil }; var index__7 any; if
	jrt.J2g_Truth(index_file__6) { var or__1927000174__auto____7 any; var root_524 any = A_arbace_build_go_A_const_88.GetRawRoot__O(); var linked_525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_524, A_arbace_build_go_read_index_A_fn_class); var ifn_526 lang.IFn; if linked_525 == nil { ifn_526 = lang.IFn_Cast(root_524) } else { ifn_526 = nil }; var arg_527 any = index_file__6; if linked_525 == nil { or__1927000174__auto____7 = ifn_526.Invoke_O__O(arg_527) } else { or__1927000174__auto____7 = linked_525.(*A_arbace_build_go_read_index_A).Invoke_O_O__O(root_524, arg_527) }; if jrt.J2g_Truth(or__1927000174__auto____7) { index__7 = or__1927000174__auto____7 } else { index__7 = lang.PersistentArrayMap_EMPTY.Ref() } } else { index__7 = nil }; var shas__8 any; if
	jrt.J2g_Truth(index_file__6) { var m__8 any; var root_528 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_529 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_528, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_530 lang.IFn
		if linked_529 == nil { ifn_530 = lang.IFn_Cast(root_528) } else { ifn_530 = nil }; var arg_531 any; var root_533 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_534 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_533, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_535 lang.IFn; if linked_534 == nil { ifn_535 = lang.IFn_Cast(root_533) } else { ifn_535 = nil }; var arg_536 any; var tmp2 any = A_arbace_build_go_root_packages_fn__1901000099_A_New(); var tmp3 *jrt.Class; var fncls__538 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000099_A_fn_class; if fncls__538 == nil { var fncls__538d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_build_go_root_packages_fn__1901000099_A_fn_class = fncls__538d; tmp3 = fncls__538d } else { tmp3 = fncls__538 }; arg_536 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_537 any = files__4; if linked_534 == nil { arg_531 = ifn_535.Invoke_O_O__O(arg_536, arg_537) } else { arg_531 = linked_534.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_533, arg_536, arg_537) }; var arg_532 any; var root_539 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_540 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_539, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_541 lang.IFn; if linked_540 == nil { ifn_541 = lang.IFn_Cast(root_539) } else { ifn_541 = nil }; var arg_542 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var arg_543 any = files__4; if linked_540 == nil { arg_532 = ifn_541.Invoke_O_O__O(arg_542, arg_543) } else { arg_532 = linked_540.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_539, arg_542, arg_543) }; if linked_529 == nil { m__8 = ifn_530.Invoke_O_O__O(arg_531, arg_532) } else { m__8 = linked_529.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_528, arg_531, arg_532) }
		var tmp4 any = A_arbace_build_go_root_packages_fn__1901000101_A_New_O(m__8); var tmp5 *jrt.Class; var fncls__553 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000101_A_fn_class; if fncls__553 == nil { var fncls__553d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_build_go_root_packages_fn__1901000101_A_fn_class = fncls__553d; tmp5 = fncls__553d } else { tmp5 = fncls__553 }; shas__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
//line :200:1
			shas__8 = nil }; var valid__9 any; if


	jrt.J2g_Truth(index_file__6) {
		var root_554 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_555 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_554, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_556 lang.IFn; if linked_555 == nil { ifn_556 = lang.IFn_Cast(root_554) } else { ifn_556 = nil }; var arg_557 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_558 any; var iter__1927001039__auto____9 any; var tmp6 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(shas__8); var tmp7 *jrt.Class; var fncls__633 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class; if fncls__633 == nil { var fncls__633d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class = fncls__633d; tmp7 = fncls__633d } else { tmp7 = fncls__633 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_558 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_build_go_A_const_79.Invoke_O__O(index__7)); if linked_555 == nil { valid__9 = ifn_556.Invoke_O_O__O(arg_557, arg_558) } else { valid__9 = linked_555.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_554, arg_557, arg_558) } } else {
//line :203:1
			valid__9 = nil }; var covered__10 any; var root_634 any = /*line :189:1*/A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_636 lang.IFn; if

















	linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any; var iter__1927001039__auto____10 any; var tmp8 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New(); var tmp9 *jrt.Class; var fncls__723 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class; if fncls__723 == nil { var fncls__723d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class = fncls__723d; tmp9 = fncls__723d } else { tmp9 = fncls__723 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_637 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(valid__9); if linked_635 == nil { covered__10 = ifn_636.Invoke_O__O(arg_637) } else { covered__10 = linked_635.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_634, arg_637) }; var pf_index__11 any = /*line :189:1*/A_arbace_build_go_A_const_92.Invoke_O__O(index__7); var known_QMARK___12 any; var tmp10 any = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(index_file__6, pf_index__11, shas__8); var tmp11 *jrt.Class; var fncls__729 *jrt.Class = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class; if






	fncls__729 == nil { var fncls__729d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class = fncls__729d; tmp11 = fncls__729d } else { tmp11 = fncls__729 }; known_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var read_fn__13 any; var root_730 any = /*line :189:1*/A_arbace_build_go_A_const_93.GetRawRoot__O(); var linked_731 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_730, A_arbace_build_go_read_all_A_fn_class); var ifn_732 lang.IFn; if




















	linked_731 == nil { ifn_732 = lang.IFn_Cast(root_730) } else { ifn_732 = nil }; var arg_733 any; var root_734 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_735 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_734, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_736 lang.IFn; if linked_735 == nil { ifn_736 = lang.IFn_Cast(root_734) } else { ifn_736 = nil }; var arg_737 any; var tmp12 any = A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(covered__10, known_QMARK___12); var tmp13 *jrt.Class; var fncls__743 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000158_A_fn_class; if fncls__743 == nil { var fncls__743d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_build_go_root_packages_fn__1901000158_A_fn_class = fncls__743d; tmp13 = fncls__743d } else { tmp13 = fncls__743 }; arg_737 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_738 any = files__4; if linked_735 == nil { arg_733 = ifn_736.Invoke_O_O__O(arg_737, arg_738) } else { arg_733 = linked_735.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_734, arg_737, arg_738) }; if linked_731 == nil { read_fn__13 = ifn_732.Invoke_O__O(arg_733) } else { read_fn__13 = linked_731.(*A_arbace_build_go_read_all_A).Invoke_O_O__O(root_730, arg_733) }; var pkg_file_QMARK___14 any; var tmp14 any = /*line :189:1*/A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(read_fn__13, known_QMARK___12, pf_index__11, shas__8); var tmp15 *jrt.Class; var fncls__749 *jrt.Class = A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class; if





















	fncls__749 == nil { var fncls__749d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class = fncls__749d; tmp15 = fncls__749d } else { tmp15 = fncls__749 }; pkg_file_QMARK___14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var pkgs__15 any; var root_750 any = /*line :189:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_752 lang.IFn; if























	linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any; var iter__1927001039__auto____15 any; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(pkg_file_QMARK___14, read_fn__13, dir__0, valid__9); var tmp17 *jrt.Class; var fncls__882 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class; if fncls__882 == nil { var fncls__882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class = fncls__882d; tmp17 = fncls__882d } else { tmp17 = fncls__882 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); arg_753 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__4); if linked_751 == nil { pkgs__15 = ifn_752.Invoke_O__O(arg_753) } else { pkgs__15 = linked_751.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_750, arg_753) }; var tmp18 any; var root_887 any =




	A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = pkgs__15; if linked_888 == nil { tmp18 = ifn_889.Invoke_O__O(arg_890) } else { tmp18 = linked_888.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_887, arg_890) }; if jrt.J2g_Truth(tmp18) {
		lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_153, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref())).Ref()) }; var seq_1901000180__16 any; var root_895 any = /*line :189:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_895, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_897 lang.IFn; if






























	linked_896 == nil { ifn_897 = lang.IFn_Cast(root_895) } else { ifn_897 = nil }; var arg_898 any; var root_899 any = A_arbace_build_go_A_const_47.GetRawRoot__O(); var linked_900 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_899, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_901 lang.IFn; if linked_900 == nil { ifn_901 = lang.IFn_Cast(root_899) } else { ifn_901 = nil }; var arg_902 any = A_arbace_build_go_A_const_48; var arg_903 any = pkgs__15; if linked_900 == nil { arg_898 = ifn_901.Invoke_O_O__O(arg_902, arg_903) } else { arg_898 = linked_900.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_899, arg_902, arg_903) }; if linked_896 == nil { seq_1901000180__16 = ifn_897.Invoke_O__O(arg_898) } else { seq_1901000180__16 = linked_896.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_895, arg_898) }; var chunk_1901000181__17 any; var count_1901000182__18 int64 = 0; var i_1901000183__19 int64 = 0; L1:
//line :189:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000183__19, count_1901000182__18) { var vec__1901000184__20 any = lang.Indexed_Cast(chunk_1901000181__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000183__19)); var path__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__22)), 1) {
			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp21 any; var root_1089 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1090 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1089, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1091 lang.IFn
			if linked_1090 == nil { ifn_1091 = lang.IFn_Cast(root_1089) } else { ifn_1091 = nil }; var arg_1092 any = Lit_88; var arg_1093 any; var root_1094 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1095 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1094, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1096 lang.IFn; if linked_1095 == nil { ifn_1096 = lang.IFn_Cast(root_1094) } else { ifn_1096 = nil }; var arg_1097 any; var tmp22 any = A_arbace_build_go_root_packages_fn__1901000187_A_New_O(dir__0); var tmp23 *jrt.Class; var fncls__1104 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000187_A_fn_class; if fncls__1104 == nil { var fncls__1104d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_build_go_root_packages_fn__1901000187_A_fn_class = fncls__1104d; tmp23 = fncls__1104d } else { tmp23 = fncls__1104 }; arg_1097 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1098 any = ps__22; if linked_1095 == nil { arg_1093 = ifn_1096.Invoke_O_O__O(arg_1097, arg_1098) } else { arg_1093 = linked_1095.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1094, arg_1097, arg_1098) }; if linked_1090 == nil { tmp21 = ifn_1091.Invoke_O_O__O(arg_1092, arg_1093) } else { tmp21 = linked_1090.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1089, arg_1092, arg_1093) }
//line :221:1
			tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, path__21, nil, tmp21)).Ref())
//line :220:1
			seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } else { seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } } else { var temp__1927000414__auto____20 any; var root_904 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = seq_1901000180__16; if linked_905 == nil { temp__1927000414__auto____20 = ifn_906.Invoke_O__O(arg_907) } else { temp__1927000414__auto____20 = linked_905.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_904, arg_907) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1901000180__21 any = temp__1927000414__auto____20; var tmp24 any; var root_908 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_910 lang.IFn; if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = seq_1901000180__21; if linked_909 == nil { tmp24 = ifn_910.Invoke_O__O(arg_911) } else { tmp24 = linked_909.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_908, arg_911) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____22 any; var root_912 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_913 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_912, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_914 lang.IFn; if linked_913 == nil { ifn_914 = lang.IFn_Cast(root_912) } else { ifn_914 = nil }; var arg_915 any = seq_1901000180__21; if linked_913 == nil { c__1927000678__auto____22 = ifn_914.Invoke_O__O(arg_915) } else { c__1927000678__auto____22 = linked_913.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_912, arg_915) }; var tmp25 any; var root_1105 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1106 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1105, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1107 lang.IFn; if linked_1106 == nil { ifn_1107 = lang.IFn_Cast(root_1105) } else { ifn_1107 = nil }; var arg_1108 any = seq_1901000180__21; if linked_1106 == nil { tmp25 = ifn_1107.Invoke_O__O(arg_1108) } else { tmp25 = linked_1106.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1105, arg_1108) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp25, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000189__22 any; var root_916 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = seq_1901000180__21; if linked_917 == nil { vec__1901000189__22 = ifn_918.Invoke_O__O(arg_919) } else { vec__1901000189__22 = linked_917.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_916, arg_919) }; var path__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__24)), 1) {
				var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp27 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil, Lit_87, nil); var tmp28 any; var root_1113 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1113, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1115 lang.IFn
				if linked_1114 == nil { ifn_1115 = lang.IFn_Cast(root_1113) } else { ifn_1115 = nil }; var arg_1116 any = Lit_88; var arg_1117 any; var root_1118 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1119 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1118, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1120 lang.IFn; if linked_1119 == nil { ifn_1120 = lang.IFn_Cast(root_1118) } else { ifn_1120 = nil }; var arg_1121 any; var tmp29 any = A_arbace_build_go_root_packages_fn__1901000192_A_New_O(dir__0); var tmp30 *jrt.Class; var fncls__1128 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000192_A_fn_class; if fncls__1128 == nil { var fncls__1128d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_build_go_root_packages_fn__1901000192_A_fn_class = fncls__1128d; tmp30 = fncls__1128d } else { tmp30 = fncls__1128 }; arg_1121 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var arg_1122 any = ps__24; if linked_1119 == nil { arg_1117 = ifn_1120.Invoke_O_O__O(arg_1121, arg_1122) } else { arg_1117 = linked_1119.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1118, arg_1121, arg_1122) }; if linked_1114 == nil { tmp28 = ifn_1115.Invoke_O_O__O(arg_1116, arg_1117) } else { tmp28 = linked_1114.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1113, arg_1116, arg_1117) }
//line :221:1
				tmp26.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp27, jrt.RefArrayOf(jrt.Object_class, nil, path__23, nil, tmp28)).Ref())
//line :220:1
				var tmp31 any; var root_1129 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = seq_1901000180__21; if linked_1130 == nil { tmp31 = ifn_1131.Invoke_O__O(arg_1132) } else { tmp31 = linked_1130.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1129, arg_1132) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp31, nil, 0, 0; continue L1 } else { var tmp32 any; var root_1133 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1134 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1133, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1135 lang.IFn; if linked_1134 == nil { ifn_1135 = lang.IFn_Cast(root_1133) } else { ifn_1135 = nil }; var arg_1136 any = seq_1901000180__21; if linked_1134 == nil { tmp32 = ifn_1135.Invoke_O__O(arg_1136) } else { tmp32 = linked_1134.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1133, arg_1136) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp32, nil, 0, 0; continue L1 } } } }
//line :189:1
		break L1 }; if

































	jrt.J2g_Truth(index_file__6) { var index_SINGLEQUOTE___16 any; var tmp33 any = A_arbace_build_go_A_const_92; var tmp34 any; var root_920 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_922 lang.IFn
		if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_924 any; var iter__1927001039__auto____16 any; var tmp35 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(pkg_file_QMARK___14, shas__8); var tmp36 *jrt.Class; var fncls__990 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class
		if fncls__990 == nil { var fncls__990d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class = fncls__990d; tmp36 = fncls__990d } else { tmp36 = fncls__990 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_924 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(files__4)
//line :224:1
		if linked_921 == nil { tmp34 = ifn_922.Invoke_O_O__O(arg_923, arg_924) } else { tmp34 = linked_921.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_920, arg_923, arg_924) }
//line :223:1
		var tmp37 any = tmp34; var tmp38 any = A_arbace_build_go_A_const_79; var tmp39 any; var root_991 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_993 lang.IFn



		if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_995 any; var iter__1927001039__auto____16_2 any; var tmp40 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(shas__8); var tmp41 *jrt.Class; var fncls__1079 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class
		if fncls__1079 == nil { var fncls__1079d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class = fncls__1079d; tmp41 = fncls__1079d } else { tmp41 = fncls__1079 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); arg_995 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(pkgs__15)
//line :227:1
		if linked_992 == nil { tmp39 = ifn_993.Invoke_O_O__O(arg_994, arg_995) } else { tmp39 = linked_992.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_991, arg_994, arg_995) }
//line :223:1
		index_SINGLEQUOTE___16 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp37, tmp38, tmp39))








		if lang.Util_Equiv_O_O__Z_NoInit(index_SINGLEQUOTE___16, index__7) { } else {
			var root_1080 any = A_arbace_build_go_A_const_102.GetRawRoot__O(); var linked_1081 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1080, A_arbace_build_go_write_index_BANG__A_fn_class); var ifn_1082 lang.IFn; if linked_1081 == nil { ifn_1082 = lang.IFn_Cast(root_1080) } else { ifn_1082 = nil }; var arg_1083 any = index_file__6; var arg_1084 any = index_SINGLEQUOTE___16; if linked_1081 == nil { ifn_1082.Invoke_O_O__O(arg_1083, arg_1084) } else { linked_1081.(*A_arbace_build_go_write_index_BANG__A).Invoke_O_O_O__O(root_1080, arg_1083, arg_1084) } } }; return pkgs__15 }
//line :196:1
func A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_known_QMARK___1901000156_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_known_QMARK___1901000156_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :196:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Ctor_O_O_O(c__index_file, c__pf_index, c__shas any) { t.F_index_file = c__index_file; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :196:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Invoke_O_O__O(self, p1__1901000095_SHARP___1 any) any { var and__1927000168__auto____2 any = t.F_index_file; if












	jrt.J2g_Truth(and__1927000168__auto____2) { var root_724 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_725 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_724, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_726 lang.IFn; if linked_725 == nil { ifn_726 = lang.IFn_Cast(root_724) } else { ifn_726 = nil }; var arg_727 any = t.F_pf_index; var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); var arg_728 any = tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000095_SHARP___1)).GetPath__String().Ref()); if linked_725 == nil { return ifn_726.Invoke_O_O__O(arg_727, arg_728) } else { return linked_725.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_724, arg_727, arg_728) } } else { return and__1927000168__auto____2 } }
//line :201:1
func A_arbace_build_go_root_packages_fn__1901000099_A_New() *A_arbace_build_go_root_packages_fn__1901000099_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000099_A{}; t.Ctor(); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Ctor() {}
//line :201:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Invoke_O_O__O(self, p1__1901000094_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000094_SHARP___1)).GetPath__String().Ref() }
func A_arbace_build_go_root_packages_fn__1901000101_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000101_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000101_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :202:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_544 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_545 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_544, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_546 lang.IFn; if linked_545 == nil { ifn_546 = lang.IFn_Cast(root_544) } else { ifn_546 = nil }; var arg_547 any = t.F_m; var arg_548 any = path__1; if linked_545 == nil { tmp1 = ifn_546.Invoke_O_O__O(arg_547, arg_548) } else { tmp1 = linked_545.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_544, arg_547, arg_548) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_m, path__1) } else { var root_549 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var linked_550 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_549, A_arbace_build_go_file_sha_A_fn_class); var ifn_551 lang.IFn; if linked_550 == nil { ifn_551 = lang.IFn_Cast(root_549) } else { ifn_551 = nil }; var arg_552 any = jrt.File_New_String(jrt.String_Cast(path__1)); if linked_550 == nil { return ifn_551.Invoke_O__O(arg_552) } else { return linked_550.(*A_arbace_build_go_file_sha_A).Invoke_O_O__O(root_549, arg_552) } } }

func A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_A{}; t.Ctor_O(p0); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Invoke_O_O__O(self, s__1901000104__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(s__1901000104__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__632 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class; if fncls__632 == nil { var fncls__632d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class = fncls__632d; tmp2 = fncls__632d } else { tmp2 = fncls__632 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Ctor_O_O_O(c__s__1901000104, c__iter__1901000103, c__shas any) { t.F_s__1901000104 = c__s__1901000104; t.F_iter__1901000103 = c__iter__1901000103; t.F_shas = c__shas }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Invoke_O__O(self any) any { { var s__1901000104__1 any; var t_ any = t.F_s__1901000104; t.F_s__1901000104 = nil; s__1901000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_559 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = s__1901000104__1; if linked_560 == nil { temp__1927000414__auto____2 = ifn_561.Invoke_O__O(arg_562) } else { temp__1927000414__auto____2 = linked_560.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_559, arg_562) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_563 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_565 lang.IFn; if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any = s__1901000104__3; if linked_564 == nil { tmp1 = ifn_565.Invoke_O__O(arg_566) } else { tmp1 = linked_564.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_563, arg_566) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_567 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_567, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_569 lang.IFn; if linked_568 == nil { ifn_569 = lang.IFn_Cast(root_567) } else { ifn_569 = nil }; var arg_570 any = s__1901000104__3; if linked_568 == nil { c__1927001037__auto____4 = ifn_569.Invoke_O__O(arg_570) } else { c__1927001037__auto____4 = linked_568.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_567, arg_570) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000106__6 any; var root_571 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_571, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_573 lang.IFn; if linked_572 == nil { ifn_573 = lang.IFn_Cast(root_571) } else { ifn_573 = nil }; var arg_574 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_572 == nil { b__1901000106__6 = ifn_573.Invoke_O__O(arg_574) } else { b__1901000106__6 = linked_572.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_571, arg_574) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(b__1901000106__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__586 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class; if fncls__586 == nil { var fncls__586d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class = fncls__586d; tmp3 = fncls__586d } else { tmp3 = fncls__586 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_587 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_587, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_589 lang.IFn; if linked_588 == nil { ifn_589 = lang.IFn_Cast(root_587) } else { ifn_589 = nil }; var arg_590 any; var root_592 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_593 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_592, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_594 lang.IFn; if linked_593 == nil { ifn_594 = lang.IFn_Cast(root_592) } else { ifn_594 = nil }; var arg_595 any = b__1901000106__6; if linked_593 == nil { arg_590 = ifn_594.Invoke_O__O(arg_595) } else { arg_590 = linked_593.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_592, arg_595) }; var arg_591 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp5 any; var root_596 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_597 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_596, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_598 lang.IFn; if linked_597 == nil { ifn_598 = lang.IFn_Cast(root_596) } else { ifn_598 = nil }; var arg_599 any = s__1901000104__3; if linked_597 == nil { tmp5 = ifn_598.Invoke_O__O(arg_599) } else { tmp5 = linked_597.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_596, arg_599) }; arg_591 = tmp4.Invoke_O__O(tmp5); if linked_588 == nil { return ifn_589.Invoke_O_O__O(arg_590, arg_591) } else { return linked_588.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_587, arg_590, arg_591) } } else { var root_600 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_600, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_602 lang.IFn; if linked_601 == nil { ifn_602 = lang.IFn_Cast(root_600) } else { ifn_602 = nil }; var arg_603 any; var root_605 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_606 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_605, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_607 lang.IFn; if linked_606 == nil { ifn_607 = lang.IFn_Cast(root_605) } else { ifn_607 = nil }; var arg_608 any = b__1901000106__6; if linked_606 == nil { arg_603 = ifn_607.Invoke_O__O(arg_608) } else { arg_603 = linked_606.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_605, arg_608) }; var arg_604 any; if linked_601 == nil { return ifn_602.Invoke_O_O__O(arg_603, arg_604) } else { return linked_601.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_600, arg_603, arg_604) } } } else { var vec__1901000120__4 any; var root_609 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_610 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_609, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_611 lang.IFn; if linked_610 == nil { ifn_611 = lang.IFn_Cast(root_609) } else { ifn_611 = nil }; var arg_612 any = s__1901000104__3; if linked_610 == nil { vec__1901000120__4 = ifn_611.Invoke_O__O(arg_612) } else { vec__1901000120__4 = linked_610.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_609, arg_612) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_613 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_614 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_613, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_615 lang.IFn
															if linked_614 == nil { ifn_615 = lang.IFn_Cast(root_613) } else { ifn_615 = nil }; var arg_616 any; var tmp7 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(t.F_shas); var tmp8 *jrt.Class; var fncls__618 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class; if fncls__618 == nil { var fncls__618d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class = fncls__618d; tmp8 = fncls__618d } else { tmp8 = fncls__618 }; arg_616 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_617 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__6); if linked_614 == nil { tmp6 = ifn_615.Invoke_O_O__O(arg_616, arg_617) } else { tmp6 = linked_614.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_613, arg_616, arg_617) }
//line :204:1
	if jrt.J2g_Truth(tmp6) { var root_619 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_620 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_619, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_621 lang.IFn; if linked_620 == nil { ifn_621 = lang.IFn_Cast(root_619) } else { ifn_621 = nil }; var arg_622 any = lang.Tuple_Create_O_O__IPersistentVector(path__5, e__6); var arg_623 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp10 any; var root_624 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_625 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_624, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_626 lang.IFn; if linked_625 == nil { ifn_626 = lang.IFn_Cast(root_624) } else { ifn_626 = nil }; var arg_627 any = s__1901000104__3; if linked_625 == nil { tmp10 = ifn_626.Invoke_O__O(arg_627) } else { tmp10 = linked_625.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_624, arg_627) }; arg_623 = tmp9.Invoke_O__O(tmp10); if linked_620 == nil { return ifn_621.Invoke_O_O__O(arg_622, arg_623) } else { return linked_620.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_619, arg_622, arg_623) } } else { var tmp11 any; var root_628 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_629 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_628, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_630 lang.IFn; if linked_629 == nil { ifn_630 = lang.IFn_Cast(root_628) } else { ifn_630 = nil }; var arg_631 any = s__1901000104__3; if linked_629 == nil { tmp11 = ifn_630.Invoke_O__O(arg_631) } else { tmp11 = linked_629.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_628, arg_631) }; s__1901000104__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Ctor_O_I_O_O(c__b__1901000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000106 = c__b__1901000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Invoke_O__O(self any) any { { var i__1901000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000105__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_575 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_577 lang.IFn
																	if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var tmp3 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(t.F_shas); var tmp4 *jrt.Class; var fncls__580 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class; if fncls__580 == nil { var fncls__580d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class = fncls__580d; tmp4 = fncls__580d } else { tmp4 = fncls__580 }; arg_578 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_579 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__4); if linked_576 == nil { tmp2 = ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { tmp2 = linked_576.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_575, arg_578, arg_579) }
//line :204:1
	if jrt.J2g_Truth(tmp2) { var root_581 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_582 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_581, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_583 lang.IFn; if linked_582 == nil { ifn_583 = lang.IFn_Cast(root_581) } else { ifn_583 = nil }; var arg_584 any = t.F_b__1901000106; var arg_585 any = lang.Tuple_Create_O_O__IPersistentVector(path__3, e__4); if linked_582 == nil { ifn_583.Invoke_O_O__O(arg_584, arg_585) } else { linked_582.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_581, arg_584, arg_585) }; i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } else { i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A{}; t.Ctor_O(p0); return t }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Invoke_O_O__O(self, p__1901000113__1 any) any { var vec__1901000115__2 any = p__1901000113__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }
//line :205:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A{}; t.Ctor_O(p0); return t }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :205:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Invoke_O_O__O(self, p__1901000123__1 any) any { var vec__1901000125__2 any = p__1901000123__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }

func A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Ctor() {}
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Invoke_O_O__O(self, s__1901000132__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(self, s__1901000132__1); var tmp2 *jrt.Class; var fncls__722 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class; if fncls__722 == nil { var fncls__722d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class = fncls__722d; tmp2 = fncls__722d } else { tmp2 = fncls__722 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Ctor_O_O(c__iter__1901000131, c__s__1901000132 any) { t.F_iter__1901000131 = c__iter__1901000131; t.F_s__1901000132 = c__s__1901000132 }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Invoke_O__O(self any) any { { var s__1901000132__1 any; var t_ any = t.F_s__1901000132; t.F_s__1901000132 = nil; s__1901000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_638 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = s__1901000132__1; if linked_639 == nil { temp__1927000414__auto____2 = ifn_640.Invoke_O__O(arg_641) } else { temp__1927000414__auto____2 = linked_639.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_638, arg_641) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1901000139__4 any; var root_642 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = xs__1927001018__auto____3; if linked_643 == nil { vec__1901000139__4 = ifn_644.Invoke_O__O(arg_645) } else { vec__1901000139__4 = linked_643.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_642, arg_645) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New(); var tmp2 *jrt.Class; var fncls__704 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class; _ = ___5; if fncls__704 == nil { var fncls__704d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class = fncls__704d; tmp2 = fncls__704d } else { tmp2 = fncls__704 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var root_705 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_706 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_705, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_707 lang.IFn; if linked_706 == nil { ifn_707 = lang.IFn_Cast(root_705) } else { ifn_707 = nil }; var arg_708 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_build_go_A_const_65.Invoke_O__O(e__6)); if linked_706 == nil { fs__1927001036__auto____8 = ifn_707.Invoke_O__O(arg_708) } else { fs__1927001036__auto____8 = linked_706.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_705, arg_708) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_709 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_710 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_709, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_711 lang.IFn; if linked_710 == nil { ifn_711 = lang.IFn_Cast(root_709) } else { ifn_711 = nil }; var arg_712 any = fs__1927001036__auto____8; var arg_713 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000131); var tmp4 any; var root_714 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_715 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_714, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_716 lang.IFn; if linked_715 == nil { ifn_716 = lang.IFn_Cast(root_714) } else { ifn_716 = nil }; var arg_717 any = s__1901000132__1; if linked_715 == nil { tmp4 = ifn_716.Invoke_O__O(arg_717) } else { tmp4 = linked_715.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_714, arg_717) }; arg_713 = tmp3.Invoke_O__O(tmp4); if linked_710 == nil { return ifn_711.Invoke_O_O__O(arg_712, arg_713) } else { return linked_710.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_709, arg_712, arg_713) } } else { var tmp5 any; var root_718 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_720 lang.IFn; if linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any = s__1901000132__1; if linked_719 == nil { tmp5 = ifn_720.Invoke_O__O(arg_721) } else { tmp5 = linked_719.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_718, arg_721) }; s__1901000132__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A{}; t.Ctor(); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Ctor() {}
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Invoke_O_O__O(self, s__1901000134__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(self, s__1901000134__1); var tmp2 *jrt.Class; var fncls__703 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class; if fncls__703 == nil { var fncls__703d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class = fncls__703d; tmp2 = fncls__703d } else { tmp2 = fncls__703 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Ctor_O_O(c__iter__1901000133, c__s__1901000134 any) { t.F_iter__1901000133 = c__iter__1901000133; t.F_s__1901000134 = c__s__1901000134 }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Invoke_O__O(self any) any { { var s__1901000134__1 any; var t_ any = t.F_s__1901000134; t.F_s__1901000134 = nil; s__1901000134__1 = t_; for { var temp__1927000414__auto____2 any; var root_646 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = s__1901000134__1; if linked_647 == nil { temp__1927000414__auto____2 = ifn_648.Invoke_O__O(arg_649) } else { temp__1927000414__auto____2 = linked_647.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_646, arg_649) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000134__3 any = temp__1927000414__auto____2; var tmp1 any; var root_650 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = s__1901000134__3; if linked_651 == nil { tmp1 = ifn_652.Invoke_O__O(arg_653) } else { tmp1 = linked_651.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_650, arg_653) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_654 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_654, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_656 lang.IFn; if linked_655 == nil { ifn_656 = lang.IFn_Cast(root_654) } else { ifn_656 = nil }; var arg_657 any = s__1901000134__3; if linked_655 == nil { c__1927001037__auto____4 = ifn_656.Invoke_O__O(arg_657) } else { c__1927001037__auto____4 = linked_655.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_654, arg_657) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000136__6 any; var root_658 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_659 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_658, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_660 lang.IFn; if linked_659 == nil { ifn_660 = lang.IFn_Cast(root_658) } else { ifn_660 = nil }; var arg_661 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_659 == nil { b__1901000136__6 = ifn_660.Invoke_O__O(arg_661) } else { b__1901000136__6 = linked_659.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_658, arg_661) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(b__1901000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__667 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class; if fncls__667 == nil { var fncls__667d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class = fncls__667d; tmp3 = fncls__667d } else { tmp3 = fncls__667 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_668 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_669 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_668, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_670 lang.IFn; if linked_669 == nil { ifn_670 = lang.IFn_Cast(root_668) } else { ifn_670 = nil }; var arg_671 any; var root_673 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_674 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_673, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_675 lang.IFn; if linked_674 == nil { ifn_675 = lang.IFn_Cast(root_673) } else { ifn_675 = nil }; var arg_676 any = b__1901000136__6; if linked_674 == nil { arg_671 = ifn_675.Invoke_O__O(arg_676) } else { arg_671 = linked_674.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_673, arg_676) }; var arg_672 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp5 any; var root_677 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_677, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_679 lang.IFn; if linked_678 == nil { ifn_679 = lang.IFn_Cast(root_677) } else { ifn_679 = nil }; var arg_680 any = s__1901000134__3; if linked_678 == nil { tmp5 = ifn_679.Invoke_O__O(arg_680) } else { tmp5 = linked_678.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_677, arg_680) }; arg_672 = tmp4.Invoke_O__O(tmp5); if linked_669 == nil { return ifn_670.Invoke_O_O__O(arg_671, arg_672) } else { return linked_669.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_668, arg_671, arg_672) } } else { var root_681 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_682 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_681, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_683 lang.IFn; if linked_682 == nil { ifn_683 = lang.IFn_Cast(root_681) } else { ifn_683 = nil }; var arg_684 any; var root_686 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_687 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_686, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_688 lang.IFn; if linked_687 == nil { ifn_688 = lang.IFn_Cast(root_686) } else { ifn_688 = nil }; var arg_689 any = b__1901000136__6; if linked_687 == nil { arg_684 = ifn_688.Invoke_O__O(arg_689) } else { arg_684 = linked_687.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_686, arg_689) }; var arg_685 any; if linked_682 == nil { return ifn_683.Invoke_O_O__O(arg_684, arg_685) } else { return linked_682.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_681, arg_684, arg_685) } } } else { var vec__1901000149__4 any; var root_690 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_691 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_690, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_692 lang.IFn; if linked_691 == nil { ifn_692 = lang.IFn_Cast(root_690) } else { ifn_692 = nil }; var arg_693 any = s__1901000134__3; if linked_691 == nil { vec__1901000149__4 = ifn_692.Invoke_O__O(arg_693) } else { vec__1901000149__4 = linked_691.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_690, arg_693) }; var rp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000149__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_694 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_694, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_696 lang.IFn; if linked_695 == nil { ifn_696 = lang.IFn_Cast(root_694) } else { ifn_696 = nil }; var arg_697 any = rp__5; var arg_698 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp7 any; var root_699 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_700 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_699, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_701 lang.IFn; if linked_700 == nil { ifn_701 = lang.IFn_Cast(root_699) } else { ifn_701 = nil }; var arg_702 any = s__1901000134__3; if linked_700 == nil { tmp7 = ifn_701.Invoke_O__O(arg_702) } else { tmp7 = linked_700.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_699, arg_702) }; arg_698 = tmp6.Invoke_O__O(tmp7); if linked_695 == nil { return ifn_696.Invoke_O_O__O(arg_697, arg_698) } else { return linked_695.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_694, arg_697, arg_698) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :207:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Ctor_O_I_O(c__b__1901000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000136 = c__b__1901000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :207:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Invoke_O__O(self any) any { { var i__1901000135__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000145__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000135__1)); var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000145__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_662 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_663 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_662, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_664 lang.IFn; if linked_663 == nil { ifn_664 = lang.IFn_Cast(root_662) } else { ifn_664 = nil }; var arg_665 any = t.F_b__1901000136; var arg_666 any = rp__3; if linked_663 == nil { ifn_664.Invoke_O_O__O(arg_665, arg_666) } else { linked_663.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_662, arg_665, arg_666) }; i__1901000135__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000135__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_fn__1901000158_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Ctor_O_O(c__covered, c__known_QMARK_ any) { t.F_covered = c__covered; t.F_known_QMARK_ = c__known_QMARK_ }
//line :210:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Invoke_O_O__O(self, p1__1901000096_SHARP___1 any) any { var root_739 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_739, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_741 lang.IFn; if linked_740 == nil { ifn_741 = lang.IFn_Cast(root_739) } else { ifn_741 = nil }; var arg_742 any; var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(p1__1901000096_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_covered); arg_742 = tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000096_SHARP___1)).GetPath__String().Ref()) } else { arg_742 = and__1927000168__auto____2 }; if linked_740 == nil { return ifn_741.Invoke_O__O(arg_742) } else { return linked_740.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_739, arg_742) } }
func A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :211:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Ctor_O_O_O_O(c__read_fn, c__known_QMARK_, c__pf_index, c__shas any) { t.F_read_fn = c__read_fn; t.F_known_QMARK_ = c__known_QMARK_; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :211:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Invoke_O_O__O(self, f__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(f__1)) { var tmp1 any = t.F_pf_index; var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__1)).GetPath__String().Ref())) } else { var root_744 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_744, A_arbace_build_go_package_file_QMARK__A_fn_class); var ifn_746 lang.IFn; if linked_745 == nil { ifn_746 = lang.IFn_Cast(root_744) } else { ifn_746 = nil }; var arg_747 any = f__1; var arg_748 any = t.F_read_fn; if linked_745 == nil { return ifn_746.Invoke_O_O__O(arg_747, arg_748) } else { return linked_745.(*A_arbace_build_go_package_file_QMARK__A).Invoke_O_O_O__O(root_744, arg_747, arg_748) } } }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Invoke_O_O__O(self, s__1901000163__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(t.F_pkg_file_QMARK_, t.F_read_fn, t.F_dir, t.F_valid, s__1901000163__1, self); var tmp2 *jrt.Class; var fncls__881 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class; if fncls__881 == nil { var fncls__881d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class = fncls__881d; tmp2 = fncls__881d } else { tmp2 = fncls__881 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Ctor_O_O_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid, c__s__1901000163, c__iter__1901000162 any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid; t.F_s__1901000163 = c__s__1901000163; t.F_iter__1901000162 = c__iter__1901000162 }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Invoke_O__O(self any) any { { var s__1901000163__1 any; var t_ any = t.F_s__1901000163; t.F_s__1901000163 = nil; s__1901000163__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_754 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = s__1901000163__1; if linked_755 == nil { temp__1927000414__auto____2 = ifn_756.Invoke_O__O(arg_757) } else { temp__1927000414__auto____2 = linked_755.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_754, arg_757) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000163__3 any = temp__1927000414__auto____2; var tmp1 any; var root_758 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = s__1901000163__3; if linked_759 == nil { tmp1 = ifn_760.Invoke_O__O(arg_761) } else { tmp1 = linked_759.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_758, arg_761) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_762 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_763 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_762, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_764 lang.IFn; if linked_763 == nil { ifn_764 = lang.IFn_Cast(root_762) } else { ifn_764 = nil }; var arg_765 any = s__1901000163__3; if linked_763 == nil { c__1927001037__auto____4 = ifn_764.Invoke_O__O(arg_765) } else { c__1927001037__auto____4 = linked_763.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_762, arg_765) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000165__6 any; var root_766 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_767 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_766, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_768 lang.IFn; if linked_767 == nil { ifn_768 = lang.IFn_Cast(root_766) } else { ifn_768 = nil }; var arg_769 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_767 == nil { b__1901000165__6 = ifn_768.Invoke_O__O(arg_769) } else { b__1901000165__6 = linked_767.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_766, arg_769) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(t.F_pkg_file_QMARK_, t.F_read_fn, b__1901000165__6, t.F_dir, t.F_valid, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__808 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class; if fncls__808 == nil { var fncls__808d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class = fncls__808d; tmp3 = fncls__808d } else { tmp3 = fncls__808 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_809 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_809, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_811 lang.IFn; if linked_810 == nil { ifn_811 = lang.IFn_Cast(root_809) } else { ifn_811 = nil }; var arg_812 any; var root_814 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_815 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_814, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_816 lang.IFn; if linked_815 == nil { ifn_816 = lang.IFn_Cast(root_814) } else { ifn_816 = nil }; var arg_817 any = b__1901000165__6; if linked_815 == nil { arg_812 = ifn_816.Invoke_O__O(arg_817) } else { arg_812 = linked_815.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_814, arg_817) }; var arg_813 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp5 any; var root_818 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_819 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_818, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_820 lang.IFn; if linked_819 == nil { ifn_820 = lang.IFn_Cast(root_818) } else { ifn_820 = nil }; var arg_821 any = s__1901000163__3; if linked_819 == nil { tmp5 = ifn_820.Invoke_O__O(arg_821) } else { tmp5 = linked_819.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_818, arg_821) }; arg_813 = tmp4.Invoke_O__O(tmp5); if linked_810 == nil { return ifn_811.Invoke_O_O__O(arg_812, arg_813) } else { return linked_810.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_809, arg_812, arg_813) } } else { var root_822 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_823 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_822, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_824 lang.IFn; if linked_823 == nil { ifn_824 = lang.IFn_Cast(root_822) } else { ifn_824 = nil }; var arg_825 any; var root_827 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_828 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_827, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_829 lang.IFn; if linked_828 == nil { ifn_829 = lang.IFn_Cast(root_827) } else { ifn_829 = nil }; var arg_830 any = b__1901000165__6; if linked_828 == nil { arg_825 = ifn_829.Invoke_O__O(arg_830) } else { arg_825 = linked_828.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_827, arg_830) }; var arg_826 any; if linked_823 == nil { return ifn_824.Invoke_O_O__O(arg_825, arg_826) } else { return linked_823.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_822, arg_825, arg_826) } } } else { var f__4 any; var root_831 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_832 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_831, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_833 lang.IFn; if linked_832 == nil { ifn_833 = lang.IFn_Cast(root_831) } else { ifn_833 = nil }; var arg_834 any = s__1901000163__3; if linked_832 == nil { f__4 = ifn_833.Invoke_O__O(arg_834) } else { f__4 = linked_832.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_831, arg_834) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4)) { var root_835 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_836 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_835, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_837 lang.IFn; if linked_836 == nil { ifn_837 = lang.IFn_Cast(root_835) } else { ifn_837 = nil }; var arg_838 any; var tmp6 any = t.F_valid; var temp__1927000408__auto____5 any = lang.RT_Get_O_O__O_NoInit(tmp6, jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref())
															if jrt.J2g_Truth(temp__1927000408__auto____5) { var e__6 any = temp__1927000408__auto____5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_83.Invoke_O__O(e__6); var tmp9 any = A_arbace_build_go_A_const_52; var tmp10 any = A_arbace_build_go_A_const_65; var tmp11 any; var root_850 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_851 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_850, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_852 lang.IFn
																if linked_851 == nil { ifn_852 = lang.IFn_Cast(root_850) } else { ifn_852 = nil }; var arg_853 any; var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New(); var tmp13 *jrt.Class; var fncls__859 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class; if fncls__859 == nil { var fncls__859d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class = fncls__859d; tmp13 = fncls__859d } else { tmp13 = fncls__859 }; arg_853 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_854 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__6); if linked_851 == nil { tmp11 = ifn_852.Invoke_O_O__O(arg_853, arg_854) } else { tmp11 = linked_851.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_850, arg_853, arg_854) }; var tmp14 any = tmp11; var tmp15 any = A_arbace_build_go_A_const_96; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(f__4, t.F_dir); var tmp17 *jrt.Class; var fncls__866 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class
																if fncls__866 == nil { var fncls__866d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_169, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class = fncls__866d; tmp17 = fncls__866d } else { tmp17 = fncls__866 }
//line :215:1
		arg_838 = tmp7.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp9, f__4, tmp10, tmp14, tmp15, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil))) } else {

			var root_867 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_868 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_867, A_arbace_build_go_collect_package_A_fn_class); var ifn_869 lang.IFn; if linked_868 == nil { ifn_869 = lang.IFn_Cast(root_867) } else { ifn_869 = nil }; var arg_870 any = t.F_dir; var arg_871 any = f__4; var arg_872 any = t.F_read_fn; if linked_868 == nil { arg_838 = ifn_869.Invoke_O_O_O__O(arg_870, arg_871, arg_872) } else { arg_838 = linked_868.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_867, arg_870, arg_871, arg_872) } }
//line :213:1
	var arg_839 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp19 any; var root_873 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_873, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_875 lang.IFn; if linked_874 == nil { ifn_875 = lang.IFn_Cast(root_873) } else { ifn_875 = nil }; var arg_876 any = s__1901000163__3; if linked_874 == nil { tmp19 = ifn_875.Invoke_O__O(arg_876) } else { tmp19 = linked_874.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_873, arg_876) }; arg_839 = tmp18.Invoke_O__O(tmp19); if linked_836 == nil { return ifn_837.Invoke_O_O__O(arg_838, arg_839) } else { return linked_836.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_835, arg_838, arg_839) } } else { var tmp20 any; var root_877 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_877, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_879 lang.IFn; if linked_878 == nil { ifn_879 = lang.IFn_Cast(root_877) } else { ifn_879 = nil }; var arg_880 any = s__1901000163__3; if linked_878 == nil { tmp20 = ifn_879.Invoke_O__O(arg_880) } else { tmp20 = linked_878.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_877, arg_880) }; s__1901000163__1 = tmp20; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Ctor_O_O_O_O_O_I_O(c__pkg_file_QMARK_, c__read_fn, c__b__1901000165, c__dir, c__valid any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_b__1901000165 = c__b__1901000165; t.F_dir = c__dir; t.F_valid = c__valid; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Invoke_O__O(self any) any { { var i__1901000164__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000164__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000164__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2)) { var root_770 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_771 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_770, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_772 lang.IFn; if linked_771 == nil { ifn_772 = lang.IFn_Cast(root_770) } else { ifn_772 = nil }; var arg_773 any = t.F_b__1901000165; var arg_774 any; var tmp2 any = t.F_valid; var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O_NoInit(tmp2, jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref())
																	if jrt.J2g_Truth(temp__1927000408__auto____3) { var e__4 any = temp__1927000408__auto____3; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_83.Invoke_O__O(e__4); var tmp5 any = A_arbace_build_go_A_const_52; var tmp6 any = A_arbace_build_go_A_const_65; var tmp7 any; var root_785 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_786 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_785, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_787 lang.IFn
																		if linked_786 == nil { ifn_787 = lang.IFn_Cast(root_785) } else { ifn_787 = nil }; var arg_788 any; var tmp8 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New(); var tmp9 *jrt.Class; var fncls__794 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class; if fncls__794 == nil { var fncls__794d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_170, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class = fncls__794d; tmp9 = fncls__794d } else { tmp9 = fncls__794 }; arg_788 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_789 any = A_arbace_build_go_A_const_65.Invoke_O__O(e__4); if linked_786 == nil { tmp7 = ifn_787.Invoke_O_O__O(arg_788, arg_789) } else { tmp7 = linked_786.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_785, arg_788, arg_789) }; var tmp10 any = tmp7; var tmp11 any = A_arbace_build_go_A_const_96; var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(f__2, t.F_dir); var tmp13 *jrt.Class; var fncls__801 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class
																		if fncls__801 == nil { var fncls__801d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_171, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class = fncls__801d; tmp13 = fncls__801d } else { tmp13 = fncls__801 }
//line :215:1
		arg_774 = tmp3.Invoke_O_O_O_O_O_O_O__O(tmp4, tmp5, f__2, tmp6, tmp10, tmp11, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))) } else {

			var root_802 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, A_arbace_build_go_collect_package_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = t.F_dir; var arg_806 any = f__2; var arg_807 any = t.F_read_fn; if linked_803 == nil { arg_774 = ifn_804.Invoke_O_O_O__O(arg_805, arg_806, arg_807) } else { arg_774 = linked_803.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_802, arg_805, arg_806, arg_807) } }
//line :213:1
	if linked_771 == nil { ifn_772.Invoke_O_O__O(arg_773, arg_774) } else { linked_771.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_770, arg_773, arg_774) }; i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } else { i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Ctor() {}
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_790 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = p1__1901000097_SHARP___1; if linked_791 == nil { tmp1 = ifn_792.Invoke_O__O(arg_793) } else { tmp1 = linked_791.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_790, arg_793) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
//line :215:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A{}; t.Ctor(); return t }
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Ctor() {}
//line :215:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_855 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = p1__1901000097_SHARP___1; if linked_856 == nil { tmp1 = ifn_857.Invoke_O__O(arg_858) } else { tmp1 = linked_856.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_855, arg_858) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Invoke_O__O(self any) any { var root_795 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_795, A_arbace_build_go_collect_package_A_fn_class); var ifn_797 lang.IFn; if linked_796 == nil { ifn_797 = lang.IFn_Cast(root_795) } else { ifn_797 = nil }; var arg_798 any; var t_ any = t.F_dir; t.F_dir = nil; arg_798 = t_; var arg_799 any; var t__2 any = t.F_f; t.F_f = nil; arg_799 = t__2; var arg_800 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); if linked_796 == nil { return ifn_797.Invoke_O_O_O__O(arg_798, arg_799, arg_800) } else { return linked_796.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_795, arg_798, arg_799, arg_800) } }
//line :216:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :216:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Invoke_O__O(self any) any { var root_860 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_860, A_arbace_build_go_collect_package_A_fn_class); var ifn_862 lang.IFn; if linked_861 == nil { ifn_862 = lang.IFn_Cast(root_860) } else { ifn_862 = nil }; var arg_863 any; var t_ any = t.F_dir; t.F_dir = nil; arg_863 = t_; var arg_864 any; var t__2 any = t.F_f; t.F_f = nil; arg_864 = t__2; var arg_865 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); if linked_861 == nil { return ifn_862.Invoke_O_O_O__O(arg_863, arg_864, arg_865) } else { return linked_861.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_860, arg_863, arg_864, arg_865) } }





func A_arbace_build_go_root_packages_fn__1901000187_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000187_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000187_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1099 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1099, A_arbace_build_go_rel_path_A_fn_class); var ifn_1101 lang.IFn; if linked_1100 == nil { ifn_1101 = lang.IFn_Cast(root_1099) } else { ifn_1101 = nil }; var arg_1102 any = t.F_dir; var arg_1103 any = A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1100 == nil { return ifn_1101.Invoke_O_O__O(arg_1102, arg_1103) } else { return linked_1100.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1099, arg_1102, arg_1103) } }
//line :222:1
func A_arbace_build_go_root_packages_fn__1901000192_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000192_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000192_A{}; t.Ctor_O(p0); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :222:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1123 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1124 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1123, A_arbace_build_go_rel_path_A_fn_class); var ifn_1125 lang.IFn; if linked_1124 == nil { ifn_1125 = lang.IFn_Cast(root_1123) } else { ifn_1125 = nil }; var arg_1126 any = t.F_dir; var arg_1127 any = A_arbace_build_go_A_const_52.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1124 == nil { return ifn_1125.Invoke_O_O__O(arg_1126, arg_1127) } else { return linked_1124.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1123, arg_1126, arg_1127) } }


func A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Ctor_O_O(c__pkg_file_QMARK_, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Invoke_O_O__O(self, s__1901000195__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(t.F_pkg_file_QMARK_, s__1901000195__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__989 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class; if fncls__989 == nil { var fncls__989d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_172, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class = fncls__989d; tmp2 = fncls__989d } else { tmp2 = fncls__989 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__s__1901000195, c__iter__1901000194, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_s__1901000195 = c__s__1901000195; t.F_iter__1901000194 = c__iter__1901000194; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Invoke_O__O(self any) any { { var s__1901000195__1 any; var t_ any = t.F_s__1901000195; t.F_s__1901000195 = nil; s__1901000195__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_928 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = s__1901000195__1; if linked_929 == nil { temp__1927000414__auto____2 = ifn_930.Invoke_O__O(arg_931) } else { temp__1927000414__auto____2 = linked_929.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_928, arg_931) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000195__3 any = temp__1927000414__auto____2; var tmp1 any; var root_932 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = s__1901000195__3; if linked_933 == nil { tmp1 = ifn_934.Invoke_O__O(arg_935) } else { tmp1 = linked_933.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_932, arg_935) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_936 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_936, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_938 lang.IFn; if linked_937 == nil { ifn_938 = lang.IFn_Cast(root_936) } else { ifn_938 = nil }; var arg_939 any = s__1901000195__3; if linked_937 == nil { c__1927001037__auto____4 = ifn_938.Invoke_O__O(arg_939) } else { c__1927001037__auto____4 = linked_937.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_936, arg_939) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000197__6 any; var root_940 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_941 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_940, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_942 lang.IFn; if linked_941 == nil { ifn_942 = lang.IFn_Cast(root_940) } else { ifn_942 = nil }; var arg_943 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_941 == nil { b__1901000197__6 = ifn_942.Invoke_O__O(arg_943) } else { b__1901000197__6 = linked_941.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_940, arg_943) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(t.F_pkg_file_QMARK_, b__1901000197__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__949 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class; if fncls__949 == nil { var fncls__949d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_173, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class = fncls__949d; tmp3 = fncls__949d } else { tmp3 = fncls__949 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_950 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_951 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_950, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_952 lang.IFn; if linked_951 == nil { ifn_952 = lang.IFn_Cast(root_950) } else { ifn_952 = nil }; var arg_953 any; var root_955 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_955, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_957 lang.IFn; if linked_956 == nil { ifn_957 = lang.IFn_Cast(root_955) } else { ifn_957 = nil }; var arg_958 any = b__1901000197__6; if linked_956 == nil { arg_953 = ifn_957.Invoke_O__O(arg_958) } else { arg_953 = linked_956.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_955, arg_958) }; var arg_954 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp5 any; var root_959 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_959, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_961 lang.IFn; if linked_960 == nil { ifn_961 = lang.IFn_Cast(root_959) } else { ifn_961 = nil }; var arg_962 any = s__1901000195__3; if linked_960 == nil { tmp5 = ifn_961.Invoke_O__O(arg_962) } else { tmp5 = linked_960.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_959, arg_962) }; arg_954 = tmp4.Invoke_O__O(tmp5); if linked_951 == nil { return ifn_952.Invoke_O_O__O(arg_953, arg_954) } else { return linked_951.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_950, arg_953, arg_954) } } else { var root_963 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_963, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_965 lang.IFn; if linked_964 == nil { ifn_965 = lang.IFn_Cast(root_963) } else { ifn_965 = nil }; var arg_966 any; var root_968 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_969 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_968, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_970 lang.IFn; if linked_969 == nil { ifn_970 = lang.IFn_Cast(root_968) } else { ifn_970 = nil }; var arg_971 any = b__1901000197__6; if linked_969 == nil { arg_966 = ifn_970.Invoke_O__O(arg_971) } else { arg_966 = linked_969.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_968, arg_971) }; var arg_967 any; if linked_964 == nil { return ifn_965.Invoke_O_O__O(arg_966, arg_967) } else { return linked_964.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_963, arg_966, arg_967) } } } else { var f__4 any; var root_972 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_973 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_972, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_974 lang.IFn; if linked_973 == nil { ifn_974 = lang.IFn_Cast(root_972) } else { ifn_974 = nil }; var arg_975 any = s__1901000195__3; if linked_973 == nil { f__4 = ifn_974.Invoke_O__O(arg_975) } else { f__4 = linked_973.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_972, arg_975) }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__5 any = tmp6.Invoke_O__O(jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__5) { var root_976 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_977 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_976, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_978 lang.IFn; if linked_977 == nil { ifn_978 = lang.IFn_Cast(root_976) } else { ifn_978 = nil }; var arg_979 any = lang.Tuple_Create_O_O__IPersistentVector(sha__5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4))).Ref()); var arg_980 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp8 any; var root_981 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_982 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_981, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_983 lang.IFn; if linked_982 == nil { ifn_983 = lang.IFn_Cast(root_981) } else { ifn_983 = nil }; var arg_984 any = s__1901000195__3; if linked_982 == nil { tmp8 = ifn_983.Invoke_O__O(arg_984) } else { tmp8 = linked_982.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_981, arg_984) }; arg_980 = tmp7.Invoke_O__O(tmp8); if linked_977 == nil { return ifn_978.Invoke_O_O__O(arg_979, arg_980) } else { return linked_977.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_976, arg_979, arg_980) } } else { var tmp9 any; var root_985 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_986 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_985, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_987 lang.IFn; if linked_986 == nil { ifn_987 = lang.IFn_Cast(root_985) } else { ifn_987 = nil }; var arg_988 any = s__1901000195__3; if linked_986 == nil { tmp9 = ifn_987.Invoke_O__O(arg_988) } else { tmp9 = linked_986.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_985, arg_988) }; s__1901000195__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Ctor_O_O_I_O_O(c__pkg_file_QMARK_, c__b__1901000197 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_b__1901000197 = c__b__1901000197; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Invoke_O__O(self any) any { { var i__1901000196__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__3 any = tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__3) { var root_944 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_945 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_944, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_946 lang.IFn; if linked_945 == nil { ifn_946 = lang.IFn_Cast(root_944) } else { ifn_946 = nil }; var arg_947 any = t.F_b__1901000197; var arg_948 any = lang.Tuple_Create_O_O__IPersistentVector(sha__3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2))).Ref()); if linked_945 == nil { ifn_946.Invoke_O_O__O(arg_947, arg_948) } else { linked_945.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_944, arg_947, arg_948) }; i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } else { i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_A{}; t.Ctor_O(p0); return t }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Invoke_O_O__O(self, s__1901000205__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(s__1901000205__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__1078 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class; if fncls__1078 == nil { var fncls__1078d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_174, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class = fncls__1078d; tmp2 = fncls__1078d } else { tmp2 = fncls__1078 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :228:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Ctor_O_O_O(c__s__1901000205, c__iter__1901000204, c__shas any) { t.F_s__1901000205 = c__s__1901000205; t.F_iter__1901000204 = c__iter__1901000204; t.F_shas = c__shas }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Invoke_O__O(self any) any { { var s__1901000205__1 any; var t_ any = t.F_s__1901000205; t.F_s__1901000205 = nil; s__1901000205__1 = t_; for { var temp__1927000414__auto____2 any; var root_999 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = s__1901000205__1; if linked_1000 == nil { temp__1927000414__auto____2 = ifn_1001.Invoke_O__O(arg_1002) } else { temp__1927000414__auto____2 = linked_1000.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_999, arg_1002) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1003 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = s__1901000205__3; if linked_1004 == nil { tmp1 = ifn_1005.Invoke_O__O(arg_1006) } else { tmp1 = linked_1004.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1003, arg_1006) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1007 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1008 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1007, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1009 lang.IFn; if linked_1008 == nil { ifn_1009 = lang.IFn_Cast(root_1007) } else { ifn_1009 = nil }; var arg_1010 any = s__1901000205__3; if linked_1008 == nil { c__1927001037__auto____4 = ifn_1009.Invoke_O__O(arg_1010) } else { c__1927001037__auto____4 = linked_1008.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1007, arg_1010) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000207__6 any; var root_1011 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1012 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1011, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1013 lang.IFn; if linked_1012 == nil { ifn_1013 = lang.IFn_Cast(root_1011) } else { ifn_1013 = nil }; var arg_1014 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1012 == nil { b__1901000207__6 = ifn_1013.Invoke_O__O(arg_1014) } else { b__1901000207__6 = linked_1012.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1011, arg_1014) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(b__1901000207__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__1031 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class; if fncls__1031 == nil { var fncls__1031d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_175, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class = fncls__1031d; tmp3 = fncls__1031d } else { tmp3 = fncls__1031 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1032 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1033 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1032, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1034 lang.IFn; if linked_1033 == nil { ifn_1034 = lang.IFn_Cast(root_1032) } else { ifn_1034 = nil }; var arg_1035 any; var root_1037 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1037, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1039 lang.IFn; if linked_1038 == nil { ifn_1039 = lang.IFn_Cast(root_1037) } else { ifn_1039 = nil }; var arg_1040 any = b__1901000207__6; if linked_1038 == nil { arg_1035 = ifn_1039.Invoke_O__O(arg_1040) } else { arg_1035 = linked_1038.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1037, arg_1040) }; var arg_1036 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp5 any; var root_1041 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1042 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1041, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1043 lang.IFn; if linked_1042 == nil { ifn_1043 = lang.IFn_Cast(root_1041) } else { ifn_1043 = nil }; var arg_1044 any = s__1901000205__3; if linked_1042 == nil { tmp5 = ifn_1043.Invoke_O__O(arg_1044) } else { tmp5 = linked_1042.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1041, arg_1044) }; arg_1036 = tmp4.Invoke_O__O(tmp5); if linked_1033 == nil { return ifn_1034.Invoke_O_O__O(arg_1035, arg_1036) } else { return linked_1033.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1032, arg_1035, arg_1036) } } else { var root_1045 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1046 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1045, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1047 lang.IFn; if linked_1046 == nil { ifn_1047 = lang.IFn_Cast(root_1045) } else { ifn_1047 = nil }; var arg_1048 any; var root_1050 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1050, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1052 lang.IFn; if linked_1051 == nil { ifn_1052 = lang.IFn_Cast(root_1050) } else { ifn_1052 = nil }; var arg_1053 any = b__1901000207__6; if linked_1051 == nil { arg_1048 = ifn_1052.Invoke_O__O(arg_1053) } else { arg_1048 = linked_1051.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1050, arg_1053) }; var arg_1049 any; if linked_1046 == nil { return ifn_1047.Invoke_O_O__O(arg_1048, arg_1049) } else { return linked_1046.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1045, arg_1048, arg_1049) } } } else { var pkg__4 any; var root_1054 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1054, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1056 lang.IFn; if linked_1055 == nil { ifn_1056 = lang.IFn_Cast(root_1054) } else { ifn_1056 = nil }; var arg_1057 any = s__1901000205__3; if linked_1055 == nil { pkg__4 = ifn_1056.Invoke_O__O(arg_1057) } else { pkg__4 = linked_1055.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1054, arg_1057) }; var root_1058 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1058, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1060 lang.IFn; if linked_1059 == nil { ifn_1060 = lang.IFn_Cast(root_1058) } else { ifn_1060 = nil }; var arg_1061 any; var tmp6 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(pkg__4))).GetPath__String().Ref(); var tmp7 any = A_arbace_build_go_A_const_65; var tmp8 any; var root_1063 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_1064 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1063, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1065 lang.IFn

	if linked_1064 == nil { ifn_1065 = lang.IFn_Cast(root_1063) } else { ifn_1065 = nil }; var arg_1066 any; var tmp9 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(t.F_shas); var tmp10 *jrt.Class; var fncls__1068 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class; if fncls__1068 == nil { var fncls__1068d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_176, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class = fncls__1068d; tmp10 = fncls__1068d } else { tmp10 = fncls__1068 }; arg_1066 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1067 any = A_arbace_build_go_A_const_65.Invoke_O__O(pkg__4); if linked_1064 == nil { tmp8 = ifn_1065.Invoke_O_O__O(arg_1066, arg_1067) } else { tmp8 = linked_1064.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1063, arg_1066, arg_1067) }
//line :228:1
	var tmp11 any = tmp8; var tmp12 any = A_arbace_build_go_A_const_83; var tmp13 any; var root_1069 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1069, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1071 lang.IFn


	if linked_1070 == nil { ifn_1071 = lang.IFn_Cast(root_1069) } else { ifn_1071 = nil }; var arg_1072 any = pkg__4; var arg_1073 any = A_arbace_build_go_A_const_101; if linked_1070 == nil { tmp13 = ifn_1071.Invoke_O_O__O(arg_1072, arg_1073) } else { tmp13 = linked_1070.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1069, arg_1072, arg_1073) }
//line :228:1
	arg_1061 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp11, tmp12, tmp13))); var arg_1062 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp15 any; var root_1074 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1074, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1076 lang.IFn; if linked_1075 == nil { ifn_1076 = lang.IFn_Cast(root_1074) } else { ifn_1076 = nil }; var arg_1077 any = s__1901000205__3; if linked_1075 == nil { tmp15 = ifn_1076.Invoke_O__O(arg_1077) } else { tmp15 = linked_1075.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1074, arg_1077) }; arg_1062 = tmp14.Invoke_O__O(tmp15); if linked_1059 == nil { return ifn_1060.Invoke_O_O__O(arg_1061, arg_1062) } else { return linked_1059.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1058, arg_1061, arg_1062) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :228:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Ctor_O_I_O_O(c__b__1901000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000207 = c__b__1901000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :228:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Invoke_O__O(self any) any { { var i__1901000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000206__1)); var root_1015 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1016 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1015, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1017 lang.IFn; if linked_1016 == nil { ifn_1017 = lang.IFn_Cast(root_1015) } else { ifn_1017 = nil }; var arg_1018 any = t.F_b__1901000207; var arg_1019 any; var tmp2 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_52.Invoke_O__O(pkg__2))).GetPath__String().Ref(); var tmp3 any = A_arbace_build_go_A_const_65; var tmp4 any; var root_1020 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1022 lang.IFn

	if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any; var tmp5 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(t.F_shas); var tmp6 *jrt.Class; var fncls__1025 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class; if fncls__1025 == nil { var fncls__1025d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_177, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class = fncls__1025d; tmp6 = fncls__1025d } else { tmp6 = fncls__1025 }; arg_1023 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1024 any = A_arbace_build_go_A_const_65.Invoke_O__O(pkg__2); if linked_1021 == nil { tmp4 = ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { tmp4 = linked_1021.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) }
//line :228:1
	var tmp7 any = tmp4; var tmp8 any = A_arbace_build_go_A_const_83; var tmp9 any; var root_1026 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1027 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1026, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1028 lang.IFn


	if linked_1027 == nil { ifn_1028 = lang.IFn_Cast(root_1026) } else { ifn_1028 = nil }; var arg_1029 any = pkg__2; var arg_1030 any = A_arbace_build_go_A_const_100; if linked_1027 == nil { tmp9 = ifn_1028.Invoke_O_O__O(arg_1029, arg_1030) } else { tmp9 = linked_1027.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1026, arg_1029, arg_1030) }
//line :228:1
	arg_1019 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp7, tmp8, tmp9))); if linked_1016 == nil { ifn_1017.Invoke_O_O__O(arg_1018, arg_1019) } else { linked_1016.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1015, arg_1018, arg_1019) }; i__1901000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }
//line :230:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A{}; t.Ctor_O(p0); return t }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :230:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }





func A_arbace_build_go_collected_package_A_New() *A_arbace_build_go_collected_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collected_package_A{}; t.Ctor(); return t }
//line :236:1
func (t *A_arbace_build_go_collected_package_A) Ctor() {}
//line :236:1
func (t *A_arbace_build_go_collected_package_A) Invoke_O_O__O(self, pkg__0 any) any { var temp__1927000408__auto____2 any = A_arbace_build_go_A_const_96.Invoke_O__O(pkg__0); if



	jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var c__4 any; var root_1137 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_1138 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1137, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1139 lang.IFn
		if linked_1138 == nil { ifn_1139 = lang.IFn_Cast(root_1137) } else { ifn_1139 = nil }; var arg_1140 any = d__3; if linked_1138 == nil { c__4 = ifn_1139.Invoke_O__O(arg_1140) } else { c__4 = linked_1138.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1137, arg_1140) }
		var tmp1 any; var root_1141 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1142 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1141, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1143 lang.IFn; if linked_1142 == nil { ifn_1143 = lang.IFn_Cast(root_1141) } else { ifn_1143 = nil }; var arg_1144 any = c__4; var arg_1145 any = A_arbace_build_go_A_const_103; if linked_1142 == nil { tmp1 = ifn_1143.Invoke_O_O__O(arg_1144, arg_1145) } else { tmp1 = linked_1142.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1141, arg_1144, arg_1145) }; var tmp2 any = tmp1; var tmp3 any; var root_1146 any = A_arbace_build_go_A_const_99.GetRawRoot__O(); var linked_1147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1146, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1148 lang.IFn; if linked_1147 == nil { ifn_1148 = lang.IFn_Cast(root_1146) } else { ifn_1148 = nil }; var arg_1149 any = pkg__0; var arg_1150 any = A_arbace_build_go_A_const_104; if linked_1147 == nil { tmp3 = ifn_1148.Invoke_O_O__O(arg_1149, arg_1150) } else { tmp3 = linked_1147.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1146, arg_1149, arg_1150) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_57), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_48.Invoke_O__O(pkg__0), nil)).Ref()) }
//line :240:1
		return c__4 } else { return pkg__0 } }






func A_arbace_build_go_read_program_edn_A_New() *A_arbace_build_go_read_program_edn_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_program_edn_A{}; t.Ctor(); return t }
//line :247:1
func (t *A_arbace_build_go_read_program_edn_A) Ctor() {}
//line :247:1
func (t *A_arbace_build_go_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_140); if

	jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var forms__3 any; var root_1155 any = A_arbace_build_go_A_const_57.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_1157 lang.IFn
		if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = f__2; if linked_1156 == nil { forms__3 = ifn_1157.Invoke_O__O(arg_1158) } else { forms__3 = linked_1156.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_1155, arg_1158) }
		var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(forms__3))); if and__1927000168__auto____4 { var root_1163 any = A_arbace_build_go_A_const_69.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1165 lang.IFn; if linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any; var root_1167 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1168 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1167, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1169 lang.IFn; if linked_1168 == nil { ifn_1169 = lang.IFn_Cast(root_1167) } else { ifn_1169 = nil }; var arg_1170 any = forms__3; if linked_1168 == nil { arg_1166 = ifn_1169.Invoke_O__O(arg_1170) } else { arg_1166 = linked_1168.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1167, arg_1170) }; if linked_1164 == nil { tmp1 = ifn_1165.Invoke_O__O(arg_1166) } else { tmp1 = linked_1164.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1163, arg_1166) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(Lit_141) }
		var root_1159 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1159, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1161 lang.IFn; if linked_1160 == nil { ifn_1161 = lang.IFn_Cast(root_1159) } else { ifn_1161 = nil }; var arg_1162 any = forms__3; if linked_1160 == nil { return ifn_1161.Invoke_O__O(arg_1162) } else { return linked_1160.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1159, arg_1162) } } else {
//line :249:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_build_go_run_A_New() *A_arbace_build_go_run_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_run_A{}; t.Ctor(); return t }
//line :256:1
func (t *A_arbace_build_go_run_A) Ctor() {}
//line :256:1
func (t *A_arbace_build_go_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any; var tmp1 any; var root_1175 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1176 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1175, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1177 lang.IFn; if



	linked_1176 == nil { ifn_1177 = lang.IFn_Cast(root_1175) } else { ifn_1177 = nil }; var arg_1178 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1179 any = cmd__0; if linked_1176 == nil { tmp1 = ifn_1177.Invoke_O_O__O(arg_1178, arg_1179) } else { tmp1 = linked_1176.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1175, arg_1178, arg_1179) }; pb__5 = /*line :256:1*/jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp1));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :256:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_1901000221__7 any; var root_1184 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1186 lang.IFn; if






	linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = env__2; if linked_1185 == nil { seq_1901000221__7 = ifn_1186.Invoke_O__O(arg_1187) } else { seq_1901000221__7 = linked_1185.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1184, arg_1187) }; var chunk_1901000222__8 any; var count_1901000223__9 int64 = 0; var i_1901000224__10 int64 = 0; L1:
//line :256:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000224__10, count_1901000223__9) { var vec__1901000225__11 any = lang.Indexed_Cast(chunk_1901000222__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000224__10)); var k__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000224__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1188 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = seq_1901000221__7; if linked_1189 == nil { temp__1927000414__auto____11 = ifn_1190.Invoke_O__O(arg_1191) } else { temp__1927000414__auto____11 = linked_1189.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1188, arg_1191) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000221__12 any = temp__1927000414__auto____11; var tmp2 any; var root_1192 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = seq_1901000221__12; if linked_1193 == nil { tmp2 = ifn_1194.Invoke_O__O(arg_1195) } else { tmp2 = linked_1193.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1192, arg_1195) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____13 any; var root_1196 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq_1901000221__12; if linked_1197 == nil { c__1927000678__auto____13 = ifn_1198.Invoke_O__O(arg_1199) } else { c__1927000678__auto____13 = linked_1197.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1196, arg_1199) }; var tmp3 any; var root_1204 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1205 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1204, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1206 lang.IFn; if linked_1205 == nil { ifn_1206 = lang.IFn_Cast(root_1204) } else { ifn_1206 = nil }; var arg_1207 any = seq_1901000221__12; if linked_1205 == nil { tmp3 = ifn_1206.Invoke_O__O(arg_1207) } else { tmp3 = linked_1205.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1204, arg_1207) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp3, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000228__13 any; var root_1200 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1200, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1202 lang.IFn; if linked_1201 == nil { ifn_1202 = lang.IFn_Cast(root_1200) } else { ifn_1202 = nil }; var arg_1203 any = seq_1901000221__12; if linked_1201 == nil { vec__1901000228__13 = ifn_1202.Invoke_O__O(arg_1203) } else { vec__1901000228__13 = linked_1201.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1200, arg_1203) }; var k__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); var tmp4 any; var root_1208 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1209 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1208, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1210 lang.IFn; if linked_1209 == nil { ifn_1210 = lang.IFn_Cast(root_1208) } else { ifn_1210 = nil }; var arg_1211 any = seq_1901000221__12; if linked_1209 == nil { tmp4 = ifn_1210.Invoke_O__O(arg_1211) } else { tmp4 = linked_1209.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1208, arg_1211) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp4, nil, 0, 0; continue L1 } } }
//line :256:1
		break L1 }; if







	jrt.J2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :264:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())
//line :264:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_105.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_build_go_go_env_A_New() *A_arbace_build_go_go_env_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_env_A{}; t.Ctor(); return t }
//line :274:1
func (t *A_arbace_build_go_go_env_A) Ctor() {}
//line :274:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z_NoInit(goos__2, Lit_29) { var tmp4 *lang.Keyword = A_arbace_build_go_A_const_48; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_65, tmp4.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()))) } else { tmp3 = nil }
//line :280:1
	var tmp5 any = tmp3; var tmp6 any
	var G__1901000232__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1901000232__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_66) { tmp6 = A_arbace_build_go_A_const_107; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_5) { tmp6 = A_arbace_build_go_A_const_108; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_67, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1901000232__4_)))))}
//line :280:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :274:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	var root_1219 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_1220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1219, A_arbace_build_go_go_env_A_fn_class); var ifn_1221 lang.IFn; if linked_1220 == nil { ifn_1221 = lang.IFn_Cast(root_1219) } else { ifn_1221 = nil }; var arg_1222 any = goroot__0; var arg_1223 any = arch__1; var arg_1224 any = Lit_39; if linked_1220 == nil { return ifn_1221.Invoke_O_O_O__O(arg_1222, arg_1223, arg_1224) } else { return linked_1220.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_1219, arg_1222, arg_1223, arg_1224)
	}
}
























func A_arbace_build_go_go_mod_cache_A_New() *A_arbace_build_go_go_mod_cache_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_mod_cache_A{}; t.Ctor(); return t }
//line :305:1
func (t *A_arbace_build_go_go_mod_cache_A) Ctor() {}
//line :305:1
func (t *A_arbace_build_go_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000234__2 any; var root_1225 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1226 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1225, A_arbace_build_go_run_A_fn_class); var ifn_1227 lang.IFn; if
											linked_1226 == nil { ifn_1227 = lang.IFn_Cast(root_1225) } else { ifn_1227 = nil }; var arg_1228 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_68, Lit_69); var arg_1229 any = jrt.File_New_String(Lit_70); var arg_1230 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_71, goroot__0, Lit_72, Lit_73)); var arg_1231 any = jrt.Boolean_FALSE.Ref(); if linked_1226 == nil { vec__1901000234__2 = ifn_1227.Invoke_O_O_O_O__O(arg_1228, arg_1229, arg_1230, arg_1231) } else { vec__1901000234__2 = linked_1226.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1225, arg_1228, arg_1229, arg_1230, arg_1231) }; var status__3 any = /*line :305:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_1240 any = status__3; if


	jrt.Long_InstanceOf(na_1240) { var n0_1241 int64 = jrt.NN(jrt.Long_Cast(na_1240)).LongValue__J(); tmp1 = n0_1241 == 0 } else { if jrt.Double_InstanceOf(na_1240) { var n0_1241_2 float64 = jrt.NN(jrt.Double_Cast(na_1240)).DoubleValue__D(); tmp1 = n0_1241_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_1240) } }; if tmp1 { } else { lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_74, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; var root_1232 any =
	A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1232, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1234 lang.IFn; if linked_1233 == nil { ifn_1234 = lang.IFn_Cast(root_1232) } else { ifn_1234 = nil }; var arg_1235 any; var root_1236 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1237 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1236, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1238 lang.IFn; if linked_1237 == nil { ifn_1238 = lang.IFn_Cast(root_1236) } else { ifn_1238 = nil }; var arg_1239 any = out__4; if linked_1237 == nil { arg_1235 = ifn_1238.Invoke_O__O(arg_1239) } else { arg_1235 = linked_1237.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1236, arg_1239) }; if linked_1233 == nil { return ifn_1234.Invoke_O__O(arg_1235) } else { return linked_1233.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1232, arg_1235) } }

func A_arbace_build_go_h1_of_file_A_New() *A_arbace_build_go_h1_of_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_A_New(); var tmp2 *jrt.Class; var fncls__1267 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class; if


	fncls__1267 == nil { var fncls__1267d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class = fncls__1267d; tmp2 = fncls__1267d } else { tmp2 = fncls__1267 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var sha__4 any; var tmp3 any = /*line :311:1*/A_arbace_build_go_h1_of_file_sha__1901000243_A_New(); var tmp4 *jrt.Class; var fncls__1268 *jrt.Class = A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class; if



	fncls__1268 == nil { var fncls__1268d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_76, false); A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class = fncls__1268d; tmp4 = fncls__1268d } else { tmp4 = fncls__1268 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var summary__5 any = /*line :311:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_77, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :317:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_78, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.ByteArray_Cast(lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_53).Ref()))).Ref())).Ref() }
//line :314:1
func A_arbace_build_go_h1_of_file_hex__1901000239_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Ctor() {}
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Invoke_O_O__O(self, b__1 any) any { var root_1246 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_1247 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1246, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1248 lang.IFn; if linked_1247 == nil { ifn_1248 = lang.IFn_Cast(root_1246) } else { ifn_1248 = nil }; var arg_1249 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1250 any; var root_1251 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1252 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1251, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1253 lang.IFn; if linked_1252 == nil { ifn_1253 = lang.IFn_Cast(root_1251) } else { ifn_1253 = nil }; var arg_1254 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New(); var tmp2 *jrt.Class; var fncls__1266 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class; if fncls__1266 == nil { var fncls__1266d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_79, false); A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class = fncls__1266d; tmp2 = fncls__1266d } else { tmp2 = fncls__1266 }; arg_1254 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1255 any = b__1; if linked_1252 == nil { arg_1250 = ifn_1253.Invoke_O_O__O(arg_1254, arg_1255) } else { arg_1250 = linked_1252.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1251, arg_1254, arg_1255) }; if linked_1247 == nil { return ifn_1248.Invoke_O_O__O(arg_1249, arg_1250) } else { return linked_1247.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1246, arg_1249, arg_1250) } }
//line :314:1
func A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A{}; t.Ctor(); return t }
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Ctor() {}
//line :314:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Invoke_O_O__O(self, p1__1901000238_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_1261 any = p1__1901000238_SHARP___1; var na_1262 int64 = 255; if jrt.Long_InstanceOf(na_1261) { var n0_1263 int64 = jrt.NN(jrt.Long_Cast(na_1261)).LongValue__J(); var n1_1264 int64 = na_1262; tmp2 = n0_1263 & n1_1264 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1261, na_1262) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }
func A_arbace_build_go_h1_of_file_sha__1901000243_A_New() *A_arbace_build_go_h1_of_file_sha__1901000243_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_sha__1901000243_A{}; t.Ctor(); return t }
//line :315:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Ctor() {}
//line :315:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52).Digest_B1__B1(jrt.ByteArray_Cast(b__1)).Ref() }



func A_arbace_build_go_tamago_go_sum_A_New() *A_arbace_build_go_tamago_go_sum_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_tamago_go_sum_A{}; t.Ctor(); return t }
//line :319:1
func (t *A_arbace_build_go_tamago_go_sum_A) Ctor() {}
//line :319:1
func (t *A_arbace_build_go_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__1901000246__2 any = A_arbace_build_go_A_const_106.GetRawRoot__O(); var map__1901000246__3 any; if



	lang.ISeq_InstanceOf(map__1901000246__2) { var tmp1 any; var root_1269 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = map__1901000246__2; if linked_1270 == nil { tmp1 = ifn_1271.Invoke_O__O(arg_1272) } else { tmp1 = linked_1270.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1269, arg_1272) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1273 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1275 lang.IFn; if linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = map__1901000246__2; if linked_1274 == nil { tmp2 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp2 = linked_1274.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1273, arg_1276) }; map__1901000246__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1277 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1278 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1277, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1279 lang.IFn; if linked_1278 == nil { ifn_1279 = lang.IFn_Cast(root_1277) } else { ifn_1279 = nil }; var arg_1280 any = map__1901000246__2; if linked_1278 == nil { tmp3 = ifn_1279.Invoke_O__O(arg_1280) } else { tmp3 = linked_1278.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1277, arg_1280) }; if jrt.J2g_Truth(tmp3) { var root_1281 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1283 lang.IFn; if linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = map__1901000246__2; if linked_1282 == nil { map__1901000246__3 = ifn_1283.Invoke_O__O(arg_1284) } else { map__1901000246__3 = linked_1282.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1281, arg_1284) } } else { map__1901000246__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000246__3 = map__1901000246__2 }; var path__4 any = /*line :319:1*/lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_48); var version__5 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_113); var zip__6 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_114); var mod__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_115); var dir__8 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_179, nil, Lit_180); var tmp5 any; var root_1285 any = A_arbace_build_go_A_const_116.GetRawRoot__O(); var linked_1286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1285, A_arbace_build_go_go_mod_cache_A_fn_class); var ifn_1287 lang.IFn; if




	linked_1286 == nil { ifn_1287 = lang.IFn_Cast(root_1285) } else { ifn_1287 = nil }; var arg_1288 any = goroot__0; if linked_1286 == nil { tmp5 = ifn_1287.Invoke_O__O(arg_1288) } else { tmp5 = linked_1286.(*A_arbace_build_go_go_mod_cache_A).Invoke_O_O__O(root_1285, arg_1288) }; dir__8 = /*line :319:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_181), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_182), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp6 bool; var and__1927000168__auto____11 bool = jrt.NN(jrt.File_Cast(zf__9)).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(mf__10)).IsFile__Z(); if and__1927000168__auto____12 { tmp6 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_183), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp6 = and__1927000168__auto____12 } } else { tmp6 = and__1927000168__auto____11 }; if tmp6 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_184, nil, Lit_185, nil, Lit_186), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.NN(jrt.File_Cast(dir__8)).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any; var root_1293 any = /*line :319:1*/A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1293, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1295 lang.IFn; if









	linked_1294 == nil { ifn_1295 = lang.IFn_Cast(root_1293) } else { ifn_1295 = nil }; var arg_1296 any = lang.IFn_Cast(A_arbace_build_go_A_const_105.GetRawRoot__O()).Invoke_O__O(zf__9); if linked_1294 == nil { zh__12 = ifn_1295.Invoke_O__O(arg_1296) } else { zh__12 = linked_1294.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1293, arg_1296) }; var mh__13 any; var root_1301 any = /*line :319:1*/A_arbace_build_go_A_const_117.GetRawRoot__O(); var linked_1302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1301, A_arbace_build_go_h1_of_file_A_fn_class); var ifn_1303 lang.IFn; if










	linked_1302 == nil { ifn_1303 = lang.IFn_Cast(root_1301) } else { ifn_1303 = nil }; var arg_1304 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(mf__10)).ToPath__Path()).Ref(); var arg_1305 any = Lit_104; if linked_1302 == nil { mh__13 = ifn_1303.Invoke_O_O__O(arg_1304, arg_1305) } else { mh__13 = linked_1302.(*A_arbace_build_go_h1_of_file_A).Invoke_O_O_O__O(root_1301, arg_1304, arg_1305) }; var tmp7 bool; var and__1927000168__auto____14 bool =
	lang.Util_Equiv_O_O__Z_NoInit(zh__12, zip__6); if and__1927000168__auto____14 { tmp7 = lang.Util_Equiv_O_O__Z_NoInit(mh__13, mod__7) } else { tmp7 = and__1927000168__auto____14 }; if tmp7 { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :333:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_build_go_toolchain_lang_A_New() *A_arbace_build_go_toolchain_lang_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_toolchain_lang_A{}; t.Ctor(); return t }
//line :335:1
func (t *A_arbace_build_go_toolchain_lang_A) Ctor() {}
//line :335:1
func (t *A_arbace_build_go_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000249__2 any; var root_1310 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1311 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1310, A_arbace_build_go_run_A_fn_class); var ifn_1312 lang.IFn; if


	linked_1311 == nil { ifn_1312 = lang.IFn_Cast(root_1310) } else { ifn_1312 = nil }; var arg_1313 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_68, Lit_187); var arg_1314 any = jrt.File_New_String(Lit_70); var arg_1315 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_71, goroot__0, Lit_72, Lit_73)); var arg_1316 any = jrt.Boolean_FALSE.Ref(); if linked_1311 == nil { vec__1901000249__2 = ifn_1312.Invoke_O_O_O_O__O(arg_1313, arg_1314, arg_1315, arg_1316) } else { vec__1901000249__2 = linked_1311.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1310, arg_1313, arg_1314, arg_1315, arg_1316) }; var status__3 any = /*line :335:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any; var root_1317 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1317, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1319 lang.IFn; if




	linked_1318 == nil { ifn_1319 = lang.IFn_Cast(root_1317) } else { ifn_1319 = nil }; var arg_1320 any; var root_1321 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1322 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1321, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1323 lang.IFn; if linked_1322 == nil { ifn_1323 = lang.IFn_Cast(root_1321) } else { ifn_1323 = nil }; var arg_1324 any = out__4; if linked_1322 == nil { arg_1320 = ifn_1323.Invoke_O__O(arg_1324) } else { arg_1320 = linked_1322.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1321, arg_1324) }; if linked_1318 == nil { v__5 = ifn_1319.Invoke_O__O(arg_1320) } else { v__5 = linked_1318.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1317, arg_1320) }; var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool; var na_1325 any = status__3; if
	jrt.Long_InstanceOf(na_1325) { var n0_1326 int64 = jrt.NN(jrt.Long_Cast(na_1325)).LongValue__J(); and__1927000168__auto____6 = n0_1326 == 0 } else { if jrt.Double_InstanceOf(na_1325) { var n0_1326_2 float64 = jrt.NN(jrt.Double_Cast(na_1325)).DoubleValue__D(); and__1927000168__auto____6 = n0_1326_2 == 0.0 } else { and__1927000168__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_1325) } }; if and__1927000168__auto____6 { var root_1327 any = A_arbace_build_go_A_const_118.GetRawRoot__O(); var linked_1328 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1327, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1329 lang.IFn; if linked_1328 == nil { ifn_1329 = lang.IFn_Cast(root_1327) } else { ifn_1329 = nil }; var arg_1330 any = A_arbace_build_go_A_const_119; var arg_1331 any = v__5; if linked_1328 == nil { temp__1927000408__auto____6 = ifn_1329.Invoke_O_O__O(arg_1330, arg_1331) } else { temp__1927000408__auto____6 = linked_1328.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1327, arg_1330, arg_1331) } } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__1901000252__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___8; return l__9 } else {

		return lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_188, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_build_go_program_A_New() *A_arbace_build_go_program_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_A{}; t.Ctor(); return t }
//line :345:1
func (t *A_arbace_build_go_program_A) Ctor() {}
//line :345:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__1901000259__2 any) any { var map__1901000260__4 any = p__1901000259__2; var map__1901000260__5 any; if lang.ISeq_InstanceOf(map__1901000260__4) { var tmp1 any; var root_1336 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = map__1901000260__4; if linked_1337 == nil { tmp1 = ifn_1338.Invoke_O__O(arg_1339) } else { tmp1 = linked_1337.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1336, arg_1339) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1340 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1342 lang.IFn; if linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = map__1901000260__4; if linked_1341 == nil { tmp2 = ifn_1342.Invoke_O__O(arg_1343) } else { tmp2 = linked_1341.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1340, arg_1343) }; map__1901000260__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1344 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1344, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1346 lang.IFn; if linked_1345 == nil { ifn_1346 = lang.IFn_Cast(root_1344) } else { ifn_1346 = nil }; var arg_1347 any = map__1901000260__4; if linked_1345 == nil { tmp3 = ifn_1346.Invoke_O__O(arg_1347) } else { tmp3 = linked_1345.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1344, arg_1347) }; if jrt.J2g_Truth(tmp3) { var root_1348 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1349 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1348, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1350 lang.IFn; if linked_1349 == nil { ifn_1350 = lang.IFn_Cast(root_1348) } else { ifn_1350 = nil }; var arg_1351 any = map__1901000260__4; if linked_1349 == nil { map__1901000260__5 = ifn_1350.Invoke_O__O(arg_1351) } else { map__1901000260__5 = linked_1349.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1348, arg_1351) } } else { map__1901000260__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000260__5 = map__1901000260__4 }; var opts__6 any = map__1901000260__5; var library_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_120); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_121); var pkgs__9 any; var root_1352 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_1353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1352, A_arbace_build_go_packages_A_fn_class); var ifn_1354 lang.IFn; if









	linked_1353 == nil { ifn_1354 = lang.IFn_Cast(root_1352) } else { ifn_1354 = nil }; var arg_1355 any = dir__0; var arg_1356 any = roots__8; var arg_1357 any = A_arbace_build_go_A_const_122.Invoke_O__O(opts__6); if linked_1353 == nil { pkgs__9 = ifn_1354.Invoke_O_O_O__O(arg_1355, arg_1356, arg_1357) } else { pkgs__9 = linked_1353.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_1352, arg_1355, arg_1356, arg_1357) }; var mains__10 any; var G__1901000262__10_ any; var root_1358 any = /*line :345:1*/A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1359 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1358, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1360 lang.IFn; if










	linked_1359 == nil { ifn_1360 = lang.IFn_Cast(root_1358) } else { ifn_1360 = nil }; var arg_1361 any; var tmp4 any = A_arbace_build_go_program_fn__1901000263_A_New(); var tmp5 *jrt.Class; var fncls__1367 *jrt.Class = A_arbace_build_go_program_fn__1901000263_A_fn_class; if fncls__1367 == nil { var fncls__1367d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_build_go_program_fn__1901000263_A_fn_class = fncls__1367d; tmp5 = fncls__1367d } else { tmp5 = fncls__1367 }; arg_1361 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1362 any = pkgs__9; if linked_1359 == nil { G__1901000262__10_ = ifn_1360.Invoke_O_O__O(arg_1361, arg_1362) } else { G__1901000262__10_ = linked_1359.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1358, arg_1361, arg_1362) }; if jrt.J2g_Truth(A_arbace_build_go_A_const_123.Invoke_O__O(opts__6)) {
		var root_1368 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1369 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1368, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1370 lang.IFn; if linked_1369 == nil { ifn_1370 = lang.IFn_Cast(root_1368) } else { ifn_1370 = nil }; var arg_1371 any; var tmp6 any = A_arbace_build_go_program_fn__1901000265_A_New_O(opts__6); var tmp7 *jrt.Class; var fncls__1373 *jrt.Class = A_arbace_build_go_program_fn__1901000265_A_fn_class; if fncls__1373 == nil { var fncls__1373d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_build_go_program_fn__1901000265_A_fn_class = fncls__1373d; tmp7 = fncls__1373d } else { tmp7 = fncls__1373 }; arg_1371 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1372 any = G__1901000262__10_; if linked_1369 == nil { mains__10 = ifn_1370.Invoke_O_O__O(arg_1371, arg_1372) } else { mains__10 = linked_1369.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1368, arg_1371, arg_1372) } } else {
//line :356:1
			mains__10 = G__1901000262__10_ }; var ___11 any; var tmp8 any; var or__1927000174__auto____11 bool = /*line :345:1*/lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(mains__10))); _ = ___11; if or__1927000174__auto____11 {












				tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 any; var root_1374 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = mains__10; if linked_1375 == nil { or__1927000174__auto____13 = ifn_1376.Invoke_O__O(arg_1377) } else { or__1927000174__auto____13 = linked_1375.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1374, arg_1377) }; if jrt.J2g_Truth(or__1927000174__auto____13) { tmp8 = or__1927000174__auto____13 } else { tmp8 = A_arbace_build_go_A_const_124.Invoke_O__O(opts__6) } } else { tmp8 = and__1927000168__auto____12 } }; if jrt.J2g_Truth(tmp8) { ___11 = nil } else {
					var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_130, nil, nil); var tmp11 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(mains__10)).Ref(); var tmp12 *jrt.String; var tmp13 any; var root_1382 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1383 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1382, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1384 lang.IFn
					if linked_1383 == nil { ifn_1384 = lang.IFn_Cast(root_1382) } else { ifn_1384 = nil }; var arg_1385 any = mains__10; if linked_1383 == nil { tmp13 = ifn_1384.Invoke_O__O(arg_1385) } else { tmp13 = linked_1383.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1382, arg_1385) }; if jrt.J2g_Truth(tmp13) { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_87, nil); var tmp15 any; var root_1386 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1386, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1388 lang.IFn; if linked_1387 == nil { ifn_1388 = lang.IFn_Cast(root_1386) } else { ifn_1388 = nil }; var arg_1389 any = Lit_88; var arg_1390 any; var root_1391 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1391, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1393 lang.IFn; if linked_1392 == nil { ifn_1393 = lang.IFn_Cast(root_1391) } else { ifn_1393 = nil }; var arg_1394 any = A_arbace_build_go_A_const_48; var arg_1395 any = mains__10; if linked_1392 == nil { arg_1390 = ifn_1393.Invoke_O_O__O(arg_1394, arg_1395) } else { arg_1390 = linked_1392.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1391, arg_1394, arg_1395) }; if linked_1387 == nil { tmp15 = ifn_1388.Invoke_O_O__O(arg_1389, arg_1390) } else { tmp15 = linked_1387.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1386, arg_1389, arg_1390) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :359:1
					___11 = tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, tmp12.Ref())).Ref()) }; var main__12 any; var root_1396 any = /*line :345:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1398 lang.IFn; if















	linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = mains__10; if linked_1397 == nil { main__12 = ifn_1398.Invoke_O__O(arg_1399) } else { main__12 = linked_1397.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1396, arg_1399) }; var edn__13 any; var root_1400 any = /*line :345:1*/A_arbace_build_go_A_const_125.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, A_arbace_build_go_read_program_edn_A_fn_class); var ifn_1402 lang.IFn; if
















	linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any = dir__0; if linked_1401 == nil { edn__13 = ifn_1402.Invoke_O__O(arg_1403) } else { edn__13 = linked_1401.(*A_arbace_build_go_read_program_edn_A).Invoke_O_O__O(root_1400, arg_1403) }; var module__14 any; var or__1927000174__auto____14 any = /*line :345:1*/A_arbace_build_go_A_const_124.Invoke_O__O(edn__13); if

















	jrt.J2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_build_go_A_const_124.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_build_go_A_const_48.Invoke_O__O(main__12); if jrt.J2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(Lit_131) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :345:1*/A_arbace_build_go_A_const_126.Invoke_O__O(edn__13); if





















	jrt.J2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_build_go_A_const_126.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z_NoInit(module__14, Lit_103) { golang__15 = nil } else { var root_1408 any = A_arbace_build_go_A_const_127.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, A_arbace_build_go_toolchain_lang_A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = goroot__1; if linked_1409 == nil { golang__15 = ifn_1410.Invoke_O__O(arg_1411) } else { golang__15 = linked_1409.(*A_arbace_build_go_toolchain_lang_A).Invoke_O_O__O(root_1408, arg_1411) } } } }; var pkgs__16 any; var root_1412 any = /*line :345:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1414 lang.IFn; if






















	linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any; var iter__1927001039__auto____16 any; var tmp16 any = A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(module__14); var tmp17 *jrt.Class; var fncls__1582 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class; if fncls__1582 == nil { var fncls__1582d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_132, false); A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class = fncls__1582d; tmp17 = fncls__1582d } else { tmp17 = fncls__1582 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); arg_1415 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); if linked_1413 == nil { pkgs__16 = ifn_1414.Invoke_O__O(arg_1415) } else { pkgs__16 = linked_1413.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1412, arg_1415) }; var tmp18 any = A_arbace_build_go_A_const_124; var tmp19 any = A_arbace_build_go_A_const_126; var tmp20 any; var root_1583 any = /*line :345:1*/A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1583, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1585 lang.IFn; if






































	linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = golang__15; if linked_1584 == nil { tmp20 = ifn_1585.Invoke_O__O(arg_1586) } else { tmp20 = linked_1584.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1583, arg_1586) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_build_go_A_const_79; var tmp23 any = A_arbace_build_go_A_const_133; var tmp24 any; var root_1587 any = /*line :345:1*/A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1589 lang.IFn; if







































	linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any; var root_1591 any = A_arbace_build_go_A_const_134.GetRawRoot__O(); var linked_1592 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1591, aot_arbace_core.A_arbace_core_sort_A_fn_class); var ifn_1593 lang.IFn; if linked_1592 == nil { ifn_1593 = lang.IFn_Cast(root_1591) } else { ifn_1593 = nil }; var arg_1594 any; var root_1595 any = A_arbace_build_go_A_const_135.GetRawRoot__O(); var linked_1596 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1595, aot_arbace_core.A_arbace_core_distinct_A_fn_class); var ifn_1597 lang.IFn; if linked_1596 == nil { ifn_1597 = lang.IFn_Cast(root_1595) } else { ifn_1597 = nil }; var arg_1598 any; var root_1599 any = A_arbace_build_go_A_const_136.GetRawRoot__O(); var linked_1600 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1599, aot_arbace_core.A_arbace_core_keep_A_fn_class); var ifn_1601 lang.IFn; if linked_1600 == nil { ifn_1601 = lang.IFn_Cast(root_1599) } else { ifn_1601 = nil }; var arg_1602 any = A_arbace_build_go_A_const_124; var arg_1603 any = pkgs__16; if linked_1600 == nil { arg_1598 = ifn_1601.Invoke_O_O__O(arg_1602, arg_1603) } else { arg_1598 = linked_1600.(*aot_arbace_core.A_arbace_core_keep_A).Invoke_O_O_O__O(root_1599, arg_1602, arg_1603) }; if linked_1596 == nil { arg_1594 = ifn_1597.Invoke_O__O(arg_1598) } else { arg_1594 = linked_1596.(*aot_arbace_core.A_arbace_core_distinct_A).Invoke_O_O__O(root_1595, arg_1598) }; if linked_1592 == nil { arg_1590 = ifn_1593.Invoke_O__O(arg_1594) } else { arg_1590 = linked_1592.(*aot_arbace_core.A_arbace_core_sort_A).Invoke_O_O__O(root_1591, arg_1594) }; if linked_1588 == nil { tmp24 = ifn_1589.Invoke_O__O(arg_1590) } else { tmp24 = linked_1588.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1587, arg_1590) }; var tmp25 any = tmp24; var tmp26 any = A_arbace_build_go_A_const_137; var tmp27 any; var root_1604 any = /*line :345:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1606 lang.IFn; if








































	linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any; var root_1608 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1608, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1610 lang.IFn; if linked_1609 == nil { ifn_1610 = lang.IFn_Cast(root_1608) } else { ifn_1610 = nil }; var arg_1611 any; var tmp28 any = A_arbace_build_go_program_fn__1901000277_A_New(); var tmp29 *jrt.Class; var fncls__1617 *jrt.Class = A_arbace_build_go_program_fn__1901000277_A_fn_class; if fncls__1617 == nil { var fncls__1617d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_133, false); A_arbace_build_go_program_fn__1901000277_A_fn_class = fncls__1617d; tmp29 = fncls__1617d } else { tmp29 = fncls__1617 }; arg_1611 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp28, tmp29, nil); var arg_1612 any = pkgs__16; if linked_1609 == nil { arg_1607 = ifn_1610.Invoke_O_O__O(arg_1611, arg_1612) } else { arg_1607 = linked_1609.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1608, arg_1611, arg_1612) }; if linked_1605 == nil { tmp27 = ifn_1606.Invoke_O__O(arg_1607) } else { tmp27 = linked_1605.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1604, arg_1607) }; return /*line :345:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, module__14, tmp19, tmp21, tmp22, pkgs__16, tmp23, tmp25, tmp26, tmp27)) }
//line :345:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {







	var root_1618 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_1619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1618, A_arbace_build_go_program_A_fn_class); var ifn_1620 lang.IFn; if linked_1619 == nil { ifn_1620 = lang.IFn_Cast(root_1618) } else { ifn_1620 = nil }; var arg_1621 any = dir__0; var arg_1622 any = goroot__1; var arg_1623 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1619 == nil { return ifn_1620.Invoke_O_O_O__O(arg_1621, arg_1622, arg_1623) } else { return linked_1619.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_1618, arg_1621, arg_1622, arg_1623)
	}
}
func A_arbace_build_go_program_fn__1901000263_A_New() *A_arbace_build_go_program_fn__1901000263_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000263_A{}; t.Ctor(); return t }
//line :356:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Ctor() {}
//line :356:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Invoke_O_O__O(self, p1__1901000256_SHARP___1 any) any { var tmp1 any; var root_1363 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1364 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1363, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1365 lang.IFn; if linked_1364 == nil { ifn_1365 = lang.IFn_Cast(root_1363) } else { ifn_1365 = nil }; var arg_1366 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000256_SHARP___1); if linked_1364 == nil { tmp1 = ifn_1365.Invoke_O__O(arg_1366) } else { tmp1 = linked_1364.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1363, arg_1366) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_95, tmp1)).Ref() }
func A_arbace_build_go_program_fn__1901000265_A_New_O(p0 any) *A_arbace_build_go_program_fn__1901000265_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000265_A{}; t.Ctor_O(p0); return t }
//line :357:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :357:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Invoke_O_O__O(self, p1__1901000257_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_123.Invoke_O__O(t.F_opts), A_arbace_build_go_A_const_48.Invoke_O__O(p1__1901000257_SHARP___1))).Ref() }










func A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(p0 any) *A_arbace_build_go_program_iter__1901000267__1901000271_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_A{}; t.Ctor_O(p0); return t }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Invoke_O_O__O(self, s__1901000268__1 any) any { var tmp1 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(self, t.F_module, s__1901000268__1); var tmp2 *jrt.Class; var fncls__1581 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class; if fncls__1581 == nil { var fncls__1581d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_134, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class = fncls__1581d; tmp2 = fncls__1581d } else { tmp2 = fncls__1581 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :368:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Ctor_O_O_O(c__iter__1901000267, c__module, c__s__1901000268 any) { t.F_iter__1901000267 = c__iter__1901000267; t.F_module = c__module; t.F_s__1901000268 = c__s__1901000268 }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Invoke_O__O(self any) any { { var s__1901000268__1 any; var t_ any = t.F_s__1901000268; t.F_s__1901000268 = nil; s__1901000268__1 = t_; for { var temp__1927000414__auto____2 any; var root_1416 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = s__1901000268__1; if linked_1417 == nil { temp__1927000414__auto____2 = ifn_1418.Invoke_O__O(arg_1419) } else { temp__1927000414__auto____2 = linked_1417.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1416, arg_1419) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000268__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1420 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = s__1901000268__3; if linked_1421 == nil { tmp1 = ifn_1422.Invoke_O__O(arg_1423) } else { tmp1 = linked_1421.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1420, arg_1423) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1424 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1425 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1424, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1426 lang.IFn; if linked_1425 == nil { ifn_1426 = lang.IFn_Cast(root_1424) } else { ifn_1426 = nil }; var arg_1427 any = s__1901000268__3; if linked_1425 == nil { c__1927001037__auto____4 = ifn_1426.Invoke_O__O(arg_1427) } else { c__1927001037__auto____4 = linked_1425.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1424, arg_1427) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000270__6 any; var root_1428 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1429 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1428, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1430 lang.IFn; if linked_1429 == nil { ifn_1430 = lang.IFn_Cast(root_1428) } else { ifn_1430 = nil }; var arg_1431 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1429 == nil { b__1901000270__6 = ifn_1430.Invoke_O__O(arg_1431) } else { b__1901000270__6 = linked_1429.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1428, arg_1431) }; var tmp2 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(b__1901000270__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1491 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class; if fncls__1491 == nil { var fncls__1491d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class = fncls__1491d; tmp3 = fncls__1491d } else { tmp3 = fncls__1491 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1492 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1492, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1494 lang.IFn; if linked_1493 == nil { ifn_1494 = lang.IFn_Cast(root_1492) } else { ifn_1494 = nil }; var arg_1495 any; var root_1497 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1498 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1497, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1499 lang.IFn; if linked_1498 == nil { ifn_1499 = lang.IFn_Cast(root_1497) } else { ifn_1499 = nil }; var arg_1500 any = b__1901000270__6; if linked_1498 == nil { arg_1495 = ifn_1499.Invoke_O__O(arg_1500) } else { arg_1495 = linked_1498.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1497, arg_1500) }; var arg_1496 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp5 any; var root_1501 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1503 lang.IFn; if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = s__1901000268__3; if linked_1502 == nil { tmp5 = ifn_1503.Invoke_O__O(arg_1504) } else { tmp5 = linked_1502.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1501, arg_1504) }; arg_1496 = tmp4.Invoke_O__O(tmp5); if linked_1493 == nil { return ifn_1494.Invoke_O_O__O(arg_1495, arg_1496) } else { return linked_1493.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1492, arg_1495, arg_1496) } } else { var root_1505 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1506 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1505, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1507 lang.IFn; if linked_1506 == nil { ifn_1507 = lang.IFn_Cast(root_1505) } else { ifn_1507 = nil }; var arg_1508 any; var root_1510 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1510, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1512 lang.IFn; if linked_1511 == nil { ifn_1512 = lang.IFn_Cast(root_1510) } else { ifn_1512 = nil }; var arg_1513 any = b__1901000270__6; if linked_1511 == nil { arg_1508 = ifn_1512.Invoke_O__O(arg_1513) } else { arg_1508 = linked_1511.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1510, arg_1513) }; var arg_1509 any; if linked_1506 == nil { return ifn_1507.Invoke_O_O__O(arg_1508, arg_1509) } else { return linked_1506.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1505, arg_1508, arg_1509) } } } else { var pkg__4 any; var root_1514 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1514, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1516 lang.IFn; if linked_1515 == nil { ifn_1516 = lang.IFn_Cast(root_1514) } else { ifn_1516 = nil }; var arg_1517 any = s__1901000268__3; if linked_1515 == nil { pkg__4 = ifn_1516.Invoke_O__O(arg_1517) } else { pkg__4 = linked_1515.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1514, arg_1517) }; var root_1518 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1519 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1518, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1520 lang.IFn; if linked_1519 == nil { ifn_1520 = lang.IFn_Cast(root_1518) } else { ifn_1520 = nil }; var arg_1521 any; var path__5 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_103) {


		var root_1523 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1524 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1523, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1525 lang.IFn; if linked_1524 == nil { ifn_1525 = lang.IFn_Cast(root_1523) } else { ifn_1525 = nil }; var arg_1526 any = pkg__4; var arg_1527 any = A_arbace_build_go_A_const_128; var arg_1528 any = path__5; if linked_1524 == nil { arg_1521 = ifn_1525.Invoke_O_O_O__O(arg_1526, arg_1527, arg_1528) } else { arg_1521 = linked_1524.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1523, arg_1526, arg_1527, arg_1528) } } else {
//line :370:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__5, t.F_module) {



				var root_1529 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1530 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1529, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1531 lang.IFn; if linked_1530 == nil { ifn_1531 = lang.IFn_Cast(root_1529) } else { ifn_1531 = nil }; var arg_1532 any = pkg__4; var arg_1533 any = A_arbace_build_go_A_const_128; var arg_1534 any = Lit_97; if linked_1530 == nil { arg_1521 = ifn_1531.Invoke_O_O_O__O(arg_1532, arg_1533, arg_1534) } else { arg_1521 = linked_1530.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1529, arg_1532, arg_1533, arg_1534) } } else {
//line :370:1
					var tmp6 any; var root_1535 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1537 lang.IFn




					if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any = path__5; var arg_1539 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_123), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1536 == nil { tmp6 = ifn_1537.Invoke_O_O__O(arg_1538, arg_1539) } else { tmp6 = linked_1536.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1535, arg_1538, arg_1539) }
//line :370:1
					if jrt.J2g_Truth(tmp6) {





						var root_1540 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = pkg__4; var arg_1544 any = A_arbace_build_go_A_const_128; var arg_1545 any; var root_1546 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_1547 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1546, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1548 lang.IFn; if linked_1547 == nil { ifn_1548 = lang.IFn_Cast(root_1546) } else { ifn_1548 = nil }; var arg_1549 any = path__5; var arg_1550 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1547 == nil { arg_1545 = ifn_1548.Invoke_O_O__O(arg_1549, arg_1550) } else { arg_1545 = linked_1547.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1546, arg_1549, arg_1550) }; if linked_1541 == nil { arg_1521 = ifn_1542.Invoke_O_O_O__O(arg_1543, arg_1544, arg_1545) } else { arg_1521 = linked_1541.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1540, arg_1543, arg_1544, arg_1545) } } else {
//line :370:1
							var tmp7 any; var and__1927000168__auto____6 any = A_arbace_build_go_A_const_39.Invoke_O__O(pkg__4)










							if jrt.J2g_Truth(and__1927000168__auto____6) { var root_1551 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1553 lang.IFn; if linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = t.F_module; var arg_1555 any = Lit_103; if linked_1552 == nil { tmp7 = ifn_1553.Invoke_O_O__O(arg_1554, arg_1555) } else { tmp7 = linked_1552.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1551, arg_1554, arg_1555) } } else { tmp7 = and__1927000168__auto____6 }
//line :370:1
							if jrt.J2g_Truth(tmp7) {











								var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp9 any = A_arbace_build_go_A_const_128; var tmp10 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5)).Ref(); var tmp11 any = A_arbace_build_go_A_const_124; var tmp12 any; var root_1564 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1565 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1564, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1566 lang.IFn; if linked_1565 == nil { ifn_1566 = lang.IFn_Cast(root_1564) } else { ifn_1566 = nil }; var arg_1567 any; var root_1568 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_1569 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1568, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1570 lang.IFn; if linked_1569 == nil { ifn_1570 = lang.IFn_Cast(root_1568) } else { ifn_1570 = nil }; var arg_1571 any = path__5; var arg_1572 any = A_arbace_build_go_A_const_132; if linked_1569 == nil { arg_1567 = ifn_1570.Invoke_O_O__O(arg_1571, arg_1572) } else { arg_1567 = linked_1569.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_1568, arg_1571, arg_1572) }; if linked_1565 == nil { tmp12 = ifn_1566.Invoke_O__O(arg_1567) } else { tmp12 = linked_1565.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1564, arg_1567) }; arg_1521 = tmp8.Invoke_O_O_O_O_O__O(pkg__4, tmp9, tmp10, tmp11, tmp12) } else {
//line :370:1
									if A_arbace_build_go_A_const_13 != nil {












										arg_1521 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :370:1
											arg_1521 = nil } } } } }
//line :368:1
	var arg_1522 any; var tmp13 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp14 any; var root_1577 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1579 lang.IFn; if linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = s__1901000268__3; if linked_1578 == nil { tmp14 = ifn_1579.Invoke_O__O(arg_1580) } else { tmp14 = linked_1578.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1577, arg_1580) }; arg_1522 = tmp13.Invoke_O__O(tmp14); if linked_1519 == nil { return ifn_1520.Invoke_O_O__O(arg_1521, arg_1522) } else { return linked_1519.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1518, arg_1521, arg_1522) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :368:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Ctor_O_I_O_O(c__b__1901000270 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__1901000270 = c__b__1901000270; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :368:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Invoke_O__O(self any) any { { var i__1901000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000269__1)); var root_1432 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1433 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1432, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1434 lang.IFn; if linked_1433 == nil { ifn_1434 = lang.IFn_Cast(root_1432) } else { ifn_1434 = nil }; var arg_1435 any = t.F_b__1901000270; var arg_1436 any; var path__3 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_103) {


		var root_1437 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1437, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1439 lang.IFn; if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = pkg__2; var arg_1441 any = A_arbace_build_go_A_const_128; var arg_1442 any = path__3; if linked_1438 == nil { arg_1436 = ifn_1439.Invoke_O_O_O__O(arg_1440, arg_1441, arg_1442) } else { arg_1436 = linked_1438.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1437, arg_1440, arg_1441, arg_1442) } } else {
//line :370:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__3, t.F_module) {



				var root_1443 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1444 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1443, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1445 lang.IFn; if linked_1444 == nil { ifn_1445 = lang.IFn_Cast(root_1443) } else { ifn_1445 = nil }; var arg_1446 any = pkg__2; var arg_1447 any = A_arbace_build_go_A_const_128; var arg_1448 any = Lit_97; if linked_1444 == nil { arg_1436 = ifn_1445.Invoke_O_O_O__O(arg_1446, arg_1447, arg_1448) } else { arg_1436 = linked_1444.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1443, arg_1446, arg_1447, arg_1448) } } else {
//line :370:1
					var tmp2 any; var root_1449 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1450 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1449, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1451 lang.IFn




					if linked_1450 == nil { ifn_1451 = lang.IFn_Cast(root_1449) } else { ifn_1451 = nil }; var arg_1452 any = path__3; var arg_1453 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_123), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1450 == nil { tmp2 = ifn_1451.Invoke_O_O__O(arg_1452, arg_1453) } else { tmp2 = linked_1450.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1449, arg_1452, arg_1453) }
//line :370:1
					if jrt.J2g_Truth(tmp2) {





						var root_1454 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1455 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1454, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1456 lang.IFn; if linked_1455 == nil { ifn_1456 = lang.IFn_Cast(root_1454) } else { ifn_1456 = nil }; var arg_1457 any = pkg__2; var arg_1458 any = A_arbace_build_go_A_const_128; var arg_1459 any; var root_1460 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_1461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1460, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1462 lang.IFn; if linked_1461 == nil { ifn_1462 = lang.IFn_Cast(root_1460) } else { ifn_1462 = nil }; var arg_1463 any = path__3; var arg_1464 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1461 == nil { arg_1459 = ifn_1462.Invoke_O_O__O(arg_1463, arg_1464) } else { arg_1459 = linked_1461.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1460, arg_1463, arg_1464) }; if linked_1455 == nil { arg_1436 = ifn_1456.Invoke_O_O_O__O(arg_1457, arg_1458, arg_1459) } else { arg_1436 = linked_1455.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1454, arg_1457, arg_1458, arg_1459) } } else {
//line :370:1
							var tmp3 any; var and__1927000168__auto____4 any = A_arbace_build_go_A_const_39.Invoke_O__O(pkg__2)










							if jrt.J2g_Truth(and__1927000168__auto____4) { var root_1465 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_1466 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1465, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_1467 lang.IFn; if linked_1466 == nil { ifn_1467 = lang.IFn_Cast(root_1465) } else { ifn_1467 = nil }; var arg_1468 any = t.F_module; var arg_1469 any = Lit_103; if linked_1466 == nil { tmp3 = ifn_1467.Invoke_O_O__O(arg_1468, arg_1469) } else { tmp3 = linked_1466.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_1465, arg_1468, arg_1469) } } else { tmp3 = and__1927000168__auto____4 }
//line :370:1
							if jrt.J2g_Truth(tmp3) {











								var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_A_const_128; var tmp6 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3)).Ref(); var tmp7 any = A_arbace_build_go_A_const_124; var tmp8 any; var root_1478 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1479 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1478, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1480 lang.IFn; if linked_1479 == nil { ifn_1480 = lang.IFn_Cast(root_1478) } else { ifn_1480 = nil }; var arg_1481 any; var root_1482 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_1483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1482, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_1484 lang.IFn; if linked_1483 == nil { ifn_1484 = lang.IFn_Cast(root_1482) } else { ifn_1484 = nil }; var arg_1485 any = path__3; var arg_1486 any = A_arbace_build_go_A_const_132; if linked_1483 == nil { arg_1481 = ifn_1484.Invoke_O_O__O(arg_1485, arg_1486) } else { arg_1481 = linked_1483.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_1482, arg_1485, arg_1486) }; if linked_1479 == nil { tmp8 = ifn_1480.Invoke_O__O(arg_1481) } else { tmp8 = linked_1479.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1478, arg_1481) }; arg_1436 = tmp4.Invoke_O_O_O_O_O__O(pkg__2, tmp5, tmp6, tmp7, tmp8) } else {
//line :370:1
									if A_arbace_build_go_A_const_13 != nil {












										arg_1436 = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_136, nil, Lit_137, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :370:1
											arg_1436 = nil } } } } }
//line :368:1
	if linked_1433 == nil { ifn_1434.Invoke_O_O__O(arg_1435, arg_1436) } else { linked_1433.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1432, arg_1435, arg_1436) }; i__1901000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000269__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

















func A_arbace_build_go_program_fn__1901000277_A_New() *A_arbace_build_go_program_fn__1901000277_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000277_A{}; t.Ctor(); return t }
//line :386:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Ctor() {}
//line :386:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Invoke_O_O__O(self, p1__1901000258_SHARP___1 any) any { var tmp1 any; var root_1613 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1614 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1613, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1615 lang.IFn; if linked_1614 == nil { ifn_1615 = lang.IFn_Cast(root_1613) } else { ifn_1615 = nil }; var arg_1616 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000258_SHARP___1); if linked_1614 == nil { tmp1 = ifn_1615.Invoke_O__O(arg_1616) } else { tmp1 = linked_1614.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1613, arg_1616) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_95, tmp1)).Ref() }




func A_arbace_build_go_sha256_A_New() *A_arbace_build_go_sha256_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_A{}; t.Ctor(); return t }
//line :391:1
func (t *A_arbace_build_go_sha256_A) Ctor() {}
//line :391:1
func (t *A_arbace_build_go_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52); var root_1624 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_1625 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1624, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1626 lang.IFn; if

	linked_1625 == nil { ifn_1626 = lang.IFn_Cast(root_1624) } else { ifn_1626 = nil }; var arg_1627 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1628 any; var root_1629 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1630 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1629, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1631 lang.IFn; if linked_1630 == nil { ifn_1631 = lang.IFn_Cast(root_1629) } else { ifn_1631 = nil }; var arg_1632 any; var tmp1 any = A_arbace_build_go_sha256_fn__1901000281_A_New(); var tmp2 *jrt.Class; var fncls__1644 *jrt.Class = A_arbace_build_go_sha256_fn__1901000281_A_fn_class; if fncls__1644 == nil { var fncls__1644d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_178, false); A_arbace_build_go_sha256_fn__1901000281_A_fn_class = fncls__1644d; tmp2 = fncls__1644d } else { tmp2 = fncls__1644 }; arg_1632 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1633 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref(); if linked_1630 == nil { arg_1628 = ifn_1631.Invoke_O_O__O(arg_1632, arg_1633) } else { arg_1628 = linked_1630.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1629, arg_1632, arg_1633) }; if linked_1625 == nil { return ifn_1626.Invoke_O_O__O(arg_1627, arg_1628) } else { return linked_1625.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1624, arg_1627, arg_1628) } }
//line :393:1
func A_arbace_build_go_sha256_fn__1901000281_A_New() *A_arbace_build_go_sha256_fn__1901000281_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_fn__1901000281_A{}; t.Ctor(); return t }
//line :393:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Ctor() {}
//line :393:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Invoke_O_O__O(self, p1__1901000280_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_1639 any = p1__1901000280_SHARP___1; var na_1640 int64 = 255; if jrt.Long_InstanceOf(na_1639) { var n0_1641 int64 = jrt.NN(jrt.Long_Cast(na_1639)).LongValue__J(); var n1_1642 int64 = na_1640; tmp2 = n0_1641 & n1_1642 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1639, na_1640) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_copy_file_A_New() *A_arbace_build_go_copy_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_copy_file_A{}; t.Ctor(); return t }
//line :395:1
func (t *A_arbace_build_go_copy_file_A) Ctor() {}
//line :395:1
func (t *A_arbace_build_go_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 any; var root_1645 any = A_arbace_build_go_A_const_139.GetRawRoot__O(); var linked_1646 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1645, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_1647 lang.IFn
	if linked_1646 == nil { ifn_1647 = lang.IFn_Cast(root_1645) } else { ifn_1647 = nil }; var arg_1648 any = A_arbace_build_go_A_const_140; var arg_1649 any; var tmp4 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp4 = jrt.StandardCopyOption_REPLACE_EXISTING; arg_1649 = lang.Tuple_Create_O__IPersistentVector(tmp4.Ref()); if linked_1646 == nil { tmp3 = ifn_1647.Invoke_O_O__O(arg_1648, arg_1649) } else { tmp3 = linked_1646.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_1645, arg_1648, arg_1649) }
//line :397:1
	return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.RefArray_Cast(tmp3, jrt.CopyOption_class))
}

func A_arbace_build_go_forms_dir_A_New() *A_arbace_build_go_forms_dir_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_forms_dir_A{}; t.Ctor(); return t }
//line :400:1
func (t *A_arbace_build_go_forms_dir_A) Ctor() {}
//line :400:1
func (t *A_arbace_build_go_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_build_go_A_const_52.Invoke_O__O(pkg__0); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp1 *jrt.File = jrt.NN(jrt.File_Cast(f__2)).GetParentFile__File(); var tmp2 any; var root_1650 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1652 lang.IFn; if





	linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = n__3; var arg_1654 any = A_arbace_build_go_A_const_141; var arg_1655 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref(); if linked_1651 == nil { tmp2 = ifn_1652.Invoke_O_O_O__O(arg_1653, arg_1654, arg_1655) } else { tmp2 = linked_1651.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1650, arg_1653, arg_1654, arg_1655) }; return /*line :400:1*/ jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2)) }







func A_arbace_build_go_with_line_files_A_New() *A_arbace_build_go_with_line_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_A{}; t.Ctor(); return t }
//line :408:1
func (t *A_arbace_build_go_with_line_files_A) Ctor() {}
//line :408:1
func (t *A_arbace_build_go_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any; var root_1656 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1656, A_arbace_build_go_forms_dir_A_fn_class); var ifn_1658 lang.IFn; if





	linked_1657 == nil { ifn_1658 = lang.IFn_Cast(root_1656) } else { ifn_1658 = nil }; var arg_1659 any = pkg__0; if linked_1657 == nil { fdir__2 = ifn_1658.Invoke_O__O(arg_1659) } else { fdir__2 = linked_1657.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_1656, arg_1659) }; var root_1660 any =
	A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_1661 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1660, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1662 lang.IFn; if linked_1661 == nil { ifn_1662 = lang.IFn_Cast(root_1660) } else { ifn_1662 = nil }; var arg_1663 any = pkg__0; var arg_1664 any = A_arbace_build_go_A_const_143; var arg_1665 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(fdir__2); var tmp2 *jrt.Class; var fncls__1688 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class; if fncls__1688 == nil { var fncls__1688d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_189, false); A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class = fncls__1688d; tmp2 = fncls__1688d } else { tmp2 = fncls__1688 }; arg_1665 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1661 == nil { return ifn_1662.Invoke_O_O_O__O(arg_1663, arg_1664, arg_1665) } else { return linked_1661.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1660, arg_1663, arg_1664, arg_1665) } }
//line :415:1
func A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Invoke_O_O__O(self, fs__1 any) any { var root_1666 any = A_arbace_build_go_A_const_95.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1666, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1668 lang.IFn; if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(t.F_fdir); var tmp2 *jrt.Class; var fncls__1687 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class; if fncls__1687 == nil { var fncls__1687d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_190, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class = fncls__1687d; tmp2 = fncls__1687d } else { tmp2 = fncls__1687 }; arg_1669 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1670 any = fs__1; if linked_1667 == nil { return ifn_1668.Invoke_O_O__O(arg_1669, arg_1670) } else { return linked_1667.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1666, arg_1669, arg_1670) } }
//line :415:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Invoke_O_O__O(self, p1__1901000286_SHARP___1 any) any { var root_1671 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = p1__1901000286_SHARP___1; var arg_1675 any = A_arbace_build_go_A_const_144; var arg_1676 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(t.F_fdir); var tmp2 *jrt.Class; var fncls__1686 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class; if fncls__1686 == nil { var fncls__1686d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_191, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class = fncls__1686d; tmp2 = fncls__1686d } else { tmp2 = fncls__1686 }; arg_1676 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1672 == nil { return ifn_1673.Invoke_O_O_O__O(arg_1674, arg_1675, arg_1676) } else { return linked_1672.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1671, arg_1674, arg_1675, arg_1676) } }
//line :415:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :415:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Invoke_O_O__O(self, s__1 any) any { var root_1677 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1678 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1677, A_arbace_build_go_rel_path_A_fn_class); var ifn_1679 lang.IFn; if linked_1678 == nil { ifn_1679 = lang.IFn_Cast(root_1677) } else { ifn_1679 = nil }; var arg_1680 any = t.F_fdir; var arg_1681 any; var tmp1 any; var root_1682 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1683 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1682, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1684 lang.IFn; if linked_1683 == nil { ifn_1684 = lang.IFn_Cast(root_1682) } else { ifn_1684 = nil }; var arg_1685 any = s__1; if linked_1683 == nil { tmp1 = ifn_1684.Invoke_O__O(arg_1685) } else { tmp1 = linked_1683.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1682, arg_1685) }; arg_1681 = jrt.File_New_String(jrt.String_Cast(tmp1)); if linked_1678 == nil { return ifn_1679.Invoke_O_O__O(arg_1680, arg_1681) } else { return linked_1678.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1677, arg_1680, arg_1681) } }



func A_arbace_build_go_print_cache_key_A_New() *A_arbace_build_go_print_cache_key_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_A{}; t.Ctor(); return t }
//line :419:1
func (t *A_arbace_build_go_print_cache_key_A) Ctor() {}
//line :419:1
func (t *A_arbace_build_go_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_52); var add__7 any; var tmp1 any = A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(md__6); var tmp2 *jrt.Class; var fncls__1689 *jrt.Class = A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class; if





	fncls__1689 == nil { var fncls__1689d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_96, false); A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class = fncls__1689d; tmp2 = fncls__1689d } else { tmp2 = fncls__1689 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0); var tmp3 lang.IFn =
	lang.IFn_Cast(add__7); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_A_const_145.Invoke_O__O(opts__3); var tmp6 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_build_go_A_const_146.Invoke_O__O(opts__3))).Ref(); var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tests__4)).Ref(); var tmp8 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp9 any; var root_1735 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1736 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1735, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1737 lang.IFn; if linked_1736 == nil { ifn_1737 = lang.IFn_Cast(root_1735) } else { ifn_1737 = nil }; var arg_1738 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__1); if linked_1736 == nil { tmp9 = ifn_1737.Invoke_O__O(arg_1738) } else { tmp9 = linked_1736.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1735, arg_1738) }; tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp5, tmp6, tmp7, tmp8, tmp9))); var seq_1901000297__8 any; var root_1711 any = /*line :419:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1711, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1713 lang.IFn; if








	linked_1712 == nil { ifn_1713 = lang.IFn_Cast(root_1711) } else { ifn_1713 = nil }; var arg_1714 any = A_arbace_build_go_A_const_65.Invoke_O__O(pkg__1); if linked_1712 == nil { seq_1901000297__8 = ifn_1713.Invoke_O__O(arg_1714) } else { seq_1901000297__8 = linked_1712.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1711, arg_1714) }; var chunk_1901000298__9 any; var count_1901000299__10 int64 = 0; var i_1901000300__11 int64 = 0; L1:
//line :419:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000300__11, count_1901000299__10) { var f__12 any = lang.Indexed_Cast(chunk_1901000298__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000300__11)); var tmp10 lang.IFn = lang.IFn_Cast(add__7); var tmp11 any; var root_1739 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1739, A_arbace_build_go_rel_path_A_fn_class); var ifn_1741 lang.IFn
			if linked_1740 == nil { ifn_1741 = lang.IFn_Cast(root_1739) } else { ifn_1741 = nil }; var arg_1742 any = dir__2; var arg_1743 any = f__12; if linked_1740 == nil { tmp11 = ifn_1741.Invoke_O_O__O(arg_1742, arg_1743) } else { tmp11 = linked_1740.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1739, arg_1742, arg_1743) }; tmp10.Invoke_O__O(tmp11)
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__12)).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_97)
//line :428:1
			seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000300__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_1715 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1715, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1717 lang.IFn; if linked_1716 == nil { ifn_1717 = lang.IFn_Cast(root_1715) } else { ifn_1717 = nil }; var arg_1718 any = seq_1901000297__8; if linked_1716 == nil { temp__1927000414__auto____12 = ifn_1717.Invoke_O__O(arg_1718) } else { temp__1927000414__auto____12 = linked_1716.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1715, arg_1718) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1901000297__13 any = temp__1927000414__auto____12; var tmp12 any; var root_1719 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1719, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1721 lang.IFn; if linked_1720 == nil { ifn_1721 = lang.IFn_Cast(root_1719) } else { ifn_1721 = nil }; var arg_1722 any = seq_1901000297__13; if linked_1720 == nil { tmp12 = ifn_1721.Invoke_O__O(arg_1722) } else { tmp12 = linked_1720.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1719, arg_1722) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____14 any; var root_1723 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = seq_1901000297__13; if linked_1724 == nil { c__1927000678__auto____14 = ifn_1725.Invoke_O__O(arg_1726) } else { c__1927000678__auto____14 = linked_1724.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1723, arg_1726) }; var tmp13 any; var root_1744 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = seq_1901000297__13; if linked_1745 == nil { tmp13 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp13 = linked_1745.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1744, arg_1747) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp13, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__14 any; var root_1727 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = seq_1901000297__13; if linked_1728 == nil { f__14 = ifn_1729.Invoke_O__O(arg_1730) } else { f__14 = linked_1728.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1727, arg_1730) }
				var tmp14 lang.IFn = lang.IFn_Cast(add__7); var tmp15 any; var root_1748 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, A_arbace_build_go_rel_path_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var arg_1751 any = dir__2; var arg_1752 any = f__14; if linked_1749 == nil { tmp15 = ifn_1750.Invoke_O_O__O(arg_1751, arg_1752) } else { tmp15 = linked_1749.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1748, arg_1751, arg_1752) }; tmp14.Invoke_O__O(tmp15)
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__14)).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_97)
//line :428:1
				var tmp16 any; var root_1753 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = seq_1901000297__13; if linked_1754 == nil { tmp16 = ifn_1755.Invoke_O__O(arg_1756) } else { tmp16 = linked_1754.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1753, arg_1756) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp16, nil, 0, 0; continue L1 } } }
//line :419:1
		break L1 }; var root_1690 any =












	A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_1691 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1690, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1692 lang.IFn; if linked_1691 == nil { ifn_1692 = lang.IFn_Cast(root_1690) } else { ifn_1692 = nil }; var arg_1693 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1694 any; var root_1695 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1696 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1695, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1697 lang.IFn; if linked_1696 == nil { ifn_1697 = lang.IFn_Cast(root_1695) } else { ifn_1697 = nil }; var arg_1698 any; var tmp17 any = A_arbace_build_go_print_cache_key_fn__1901000301_A_New(); var tmp18 *jrt.Class; var fncls__1710 *jrt.Class = A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class; if fncls__1710 == nil { var fncls__1710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_98, false); A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class = fncls__1710d; tmp18 = fncls__1710d } else { tmp18 = fncls__1710 }; arg_1698 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1699 any = jrt.MessageDigest_Cast(md__6).Digest__B1().Ref(); if linked_1696 == nil { arg_1694 = ifn_1697.Invoke_O_O__O(arg_1698, arg_1699) } else { arg_1694 = linked_1696.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1695, arg_1698, arg_1699) }; if linked_1691 == nil { return ifn_1692.Invoke_O_O__O(arg_1693, arg_1694) } else { return linked_1691.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1690, arg_1693, arg_1694) } }
//line :425:1
func A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(p0 any) *A_arbace_build_go_print_cache_key_add__1901000295_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_add__1901000295_A{}; t.Ctor_O(p0); return t }
//line :425:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :425:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_53)); return nil }






func A_arbace_build_go_print_cache_key_fn__1901000301_A_New() *A_arbace_build_go_print_cache_key_fn__1901000301_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_fn__1901000301_A{}; t.Ctor(); return t }
//line :432:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Ctor() {}
//line :432:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Invoke_O_O__O(self, p1__1901000294_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()); var tmp2 int64; var na_1705 any = p1__1901000294_SHARP___1; var na_1706 int64 = 255; if jrt.Long_InstanceOf(na_1705) { var n0_1707 int64 = jrt.NN(jrt.Long_Cast(na_1705)).LongValue__J(); var n1_1708 int64 = na_1706; tmp2 = n0_1707 & n1_1708 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1705, na_1706) }; return tmp1.Invoke_O_O__O(Lit_80, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_cached_texts_A_New() *A_arbace_build_go_cached_texts_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_A{}; t.Ctor(); return t }
//line :434:1
func (t *A_arbace_build_go_cached_texts_A) Ctor() {}
//line :434:1
func (t *A_arbace_build_go_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_43); if





	jrt.NN(jrt.File_Cast(names__2)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(entry__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var root_1757 any = A_arbace_build_go_A_const_80.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke__O(); var arg_1761 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(entry__0); var tmp2 *jrt.Class; var fncls__1835 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class
		if fncls__1835 == nil { var fncls__1835d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class = fncls__1835d; tmp2 = fncls__1835d } else { tmp2 = fncls__1835 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1836 any = A_arbace_build_go_A_const_147.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = lang.IFn_Cast(A_arbace_build_go_A_const_105.GetRawRoot__O()).Invoke_O__O(names__2); if linked_1837 == nil { tmp4 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp4 = linked_1837.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_1836, arg_1839) }; arg_1761 = tmp3.Invoke_O__O(tmp4)
//line :442:1
		if linked_1758 == nil { return ifn_1759.Invoke_O_O__O(arg_1760, arg_1761) } else { return linked_1758.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1757, arg_1760, arg_1761) } } else {
//line :440:1
			return nil } }


func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(p0 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A{}; t.Ctor_O(p0); return t }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Invoke_O_O__O(self, s__1901000305__1 any) any { var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(s__1901000305__1, self, t.F_entry); var tmp2 *jrt.Class; var fncls__1834 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class; if fncls__1834 == nil { var fncls__1834d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class = fncls__1834d; tmp2 = fncls__1834d } else { tmp2 = fncls__1834 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :443:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Ctor_O_O_O(c__s__1901000305, c__iter__1901000304, c__entry any) { t.F_s__1901000305 = c__s__1901000305; t.F_iter__1901000304 = c__iter__1901000304; t.F_entry = c__entry }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Invoke_O__O(self any) any { { var s__1901000305__1 any; var t_ any = t.F_s__1901000305; t.F_s__1901000305 = nil; s__1901000305__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1765 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1766 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1765, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1767 lang.IFn; if linked_1766 == nil { ifn_1767 = lang.IFn_Cast(root_1765) } else { ifn_1767 = nil }; var arg_1768 any = s__1901000305__1; if linked_1766 == nil { temp__1927000414__auto____2 = ifn_1767.Invoke_O__O(arg_1768) } else { temp__1927000414__auto____2 = linked_1766.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1765, arg_1768) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000305__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1769 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1770 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1769, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1771 lang.IFn; if linked_1770 == nil { ifn_1771 = lang.IFn_Cast(root_1769) } else { ifn_1771 = nil }; var arg_1772 any = s__1901000305__3; if linked_1770 == nil { tmp1 = ifn_1771.Invoke_O__O(arg_1772) } else { tmp1 = linked_1770.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1769, arg_1772) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1773 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1773, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1775 lang.IFn; if linked_1774 == nil { ifn_1775 = lang.IFn_Cast(root_1773) } else { ifn_1775 = nil }; var arg_1776 any = s__1901000305__3; if linked_1774 == nil { c__1927001037__auto____4 = ifn_1775.Invoke_O__O(arg_1776) } else { c__1927001037__auto____4 = linked_1774.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1773, arg_1776) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000307__6 any; var root_1777 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1777, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1779 lang.IFn; if linked_1778 == nil { ifn_1779 = lang.IFn_Cast(root_1777) } else { ifn_1779 = nil }; var arg_1780 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1778 == nil { b__1901000307__6 = ifn_1779.Invoke_O__O(arg_1780) } else { b__1901000307__6 = linked_1778.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1777, arg_1780) }; var tmp2 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(b__1901000307__6, t.F_entry, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1790 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class; if fncls__1790 == nil { var fncls__1790d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class = fncls__1790d; tmp3 = fncls__1790d } else { tmp3 = fncls__1790 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1791 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any; var root_1796 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1797 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1796, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1798 lang.IFn; if linked_1797 == nil { ifn_1798 = lang.IFn_Cast(root_1796) } else { ifn_1798 = nil }; var arg_1799 any = b__1901000307__6; if linked_1797 == nil { arg_1794 = ifn_1798.Invoke_O__O(arg_1799) } else { arg_1794 = linked_1797.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1796, arg_1799) }; var arg_1795 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp5 any; var root_1800 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any = s__1901000305__3; if linked_1801 == nil { tmp5 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp5 = linked_1801.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1800, arg_1803) }; arg_1795 = tmp4.Invoke_O__O(tmp5); if linked_1792 == nil { return ifn_1793.Invoke_O_O__O(arg_1794, arg_1795) } else { return linked_1792.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1791, arg_1794, arg_1795) } } else { var root_1804 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var root_1809 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1809, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1811 lang.IFn; if linked_1810 == nil { ifn_1811 = lang.IFn_Cast(root_1809) } else { ifn_1811 = nil }; var arg_1812 any = b__1901000307__6; if linked_1810 == nil { arg_1807 = ifn_1811.Invoke_O__O(arg_1812) } else { arg_1807 = linked_1810.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1809, arg_1812) }; var arg_1808 any; if linked_1805 == nil { return ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { return linked_1805.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) } } } else { var n__4 any; var root_1813 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1814 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1813, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1815 lang.IFn; if linked_1814 == nil { ifn_1815 = lang.IFn_Cast(root_1813) } else { ifn_1815 = nil }; var arg_1816 any = s__1901000305__3; if linked_1814 == nil { n__4 = ifn_1815.Invoke_O__O(arg_1816) } else { n__4 = linked_1814.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1813, arg_1816) }; var tmp6 any; var root_1817 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1818 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1817, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1819 lang.IFn; if linked_1818 == nil { ifn_1819 = lang.IFn_Cast(root_1817) } else { ifn_1819 = nil }; var arg_1820 any = n__4; if linked_1818 == nil { tmp6 = ifn_1819.Invoke_O__O(arg_1820) } else { tmp6 = linked_1818.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1817, arg_1820) }; if jrt.J2g_Truth(tmp6) { var root_1821 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1822 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1821, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1823 lang.IFn; if linked_1822 == nil { ifn_1823 = lang.IFn_Cast(root_1821) } else { ifn_1823 = nil }; var tmp7 *jrt.File = jrt.File_Cast(t.F_entry); var arg_1824 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, jrt.File_New_File_String(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4)))); var arg_1825 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp9 any; var root_1826 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1827 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1826, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1828 lang.IFn; if linked_1827 == nil { ifn_1828 = lang.IFn_Cast(root_1826) } else { ifn_1828 = nil }; var arg_1829 any = s__1901000305__3; if linked_1827 == nil { tmp9 = ifn_1828.Invoke_O__O(arg_1829) } else { tmp9 = linked_1827.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1826, arg_1829) }; arg_1825 = tmp8.Invoke_O__O(tmp9); if linked_1822 == nil { return ifn_1823.Invoke_O_O__O(arg_1824, arg_1825) } else { return linked_1822.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1821, arg_1824, arg_1825) } } else { var tmp10 any; var root_1830 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1831 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1830, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1832 lang.IFn; if linked_1831 == nil { ifn_1832 = lang.IFn_Cast(root_1830) } else { ifn_1832 = nil }; var arg_1833 any = s__1901000305__3; if linked_1831 == nil { tmp10 = ifn_1832.Invoke_O__O(arg_1833) } else { tmp10 = linked_1831.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1830, arg_1833) }; s__1901000305__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :443:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Ctor_O_O_I_O(c__b__1901000307, c__entry any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000307 = c__b__1901000307; t.F_entry = c__entry; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :443:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Invoke_O__O(self any) any { { var i__1901000306__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000306__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000306__1)); var tmp2 any; var root_1781 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1782 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1781, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1783 lang.IFn; if linked_1782 == nil { ifn_1783 = lang.IFn_Cast(root_1781) } else { ifn_1783 = nil }; var arg_1784 any = n__2; if linked_1782 == nil { tmp2 = ifn_1783.Invoke_O__O(arg_1784) } else { tmp2 = linked_1782.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1781, arg_1784) }; if jrt.J2g_Truth(tmp2) { var root_1785 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1786 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1785, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1787 lang.IFn; if linked_1786 == nil { ifn_1787 = lang.IFn_Cast(root_1785) } else { ifn_1787 = nil }; var arg_1788 any = t.F_b__1901000307; var tmp3 *jrt.File = jrt.File_Cast(t.F_entry); var arg_1789 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, jrt.File_New_File_String(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2)))); if linked_1786 == nil { ifn_1787.Invoke_O_O__O(arg_1788, arg_1789) } else { linked_1786.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1785, arg_1788, arg_1789) }; i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } else { i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_cache_texts_BANG__A_New() *A_arbace_build_go_cache_texts_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :446:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Ctor() {}
//line :446:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.NN(jrt.File_Cast(entry__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(entry__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__3)).Mkdirs__Z()); var seq_1901000316__4 any; var root_1848 any = /*line :446:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1850 lang.IFn; if




	linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = texts__1; if linked_1849 == nil { seq_1901000316__4 = ifn_1850.Invoke_O__O(arg_1851) } else { seq_1901000316__4 = linked_1849.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1848, arg_1851) }; var chunk_1901000317__5 any; var count_1901000318__6 int64 = 0; var i_1901000319__7 int64 = 0; L1:
//line :446:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000319__7, count_1901000318__6) { var vec__1901000320__8 any = lang.Indexed_Cast(chunk_1901000317__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000319__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000319__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1852 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = seq_1901000316__4; if linked_1853 == nil { temp__1927000414__auto____8 = ifn_1854.Invoke_O__O(arg_1855) } else { temp__1927000414__auto____8 = linked_1853.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1852, arg_1855) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1901000316__9 any = temp__1927000414__auto____8; var tmp1 any; var root_1856 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = seq_1901000316__9; if linked_1857 == nil { tmp1 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp1 = linked_1857.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1856, arg_1859) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_1860 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = seq_1901000316__9; if linked_1861 == nil { c__1927000678__auto____10 = ifn_1862.Invoke_O__O(arg_1863) } else { c__1927000678__auto____10 = linked_1861.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1860, arg_1863) }; var tmp2 any; var root_1892 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1892, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1894 lang.IFn; if linked_1893 == nil { ifn_1894 = lang.IFn_Cast(root_1892) } else { ifn_1894 = nil }; var arg_1895 any = seq_1901000316__9; if linked_1893 == nil { tmp2 = ifn_1894.Invoke_O__O(arg_1895) } else { tmp2 = linked_1893.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1892, arg_1895) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000323__10 any; var root_1864 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any = seq_1901000316__9; if linked_1865 == nil { vec__1901000323__10 = ifn_1866.Invoke_O__O(arg_1867) } else { vec__1901000323__10 = linked_1865.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1864, arg_1867) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_42, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); var tmp3 any; var root_1901 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1902 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1901, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1903 lang.IFn; if linked_1902 == nil { ifn_1903 = lang.IFn_Cast(root_1901) } else { ifn_1903 = nil }; var arg_1904 any = seq_1901000316__9; if linked_1902 == nil { tmp3 = ifn_1903.Invoke_O__O(arg_1904) } else { tmp3 = linked_1902.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1901, arg_1904) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :446:1
		break L1 }; var tmp4 lang.IFn =





	lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()); var tmp5 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_43); var tmp6 any; var root_1873 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1873, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1875 lang.IFn; if linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any; var root_1877 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1878 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1877, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1879 lang.IFn; if linked_1878 == nil { ifn_1879 = lang.IFn_Cast(root_1877) } else { ifn_1879 = nil }; var arg_1880 any; var tmp7 any = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New(); var tmp8 *jrt.Class; var fncls__1882 *jrt.Class = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class; if fncls__1882 == nil { var fncls__1882d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_44, false); A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class = fncls__1882d; tmp8 = fncls__1882d } else { tmp8 = fncls__1882 }; arg_1880 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1881 any; var root_1883 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = texts__1; if linked_1884 == nil { arg_1881 = ifn_1885.Invoke_O__O(arg_1886) } else { arg_1881 = linked_1884.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1883, arg_1886) }; if linked_1878 == nil { arg_1876 = ifn_1879.Invoke_O_O__O(arg_1880, arg_1881) } else { arg_1876 = linked_1878.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1877, arg_1880, arg_1881) }; if linked_1874 == nil { tmp6 = ifn_1875.Invoke_O__O(arg_1876) } else { tmp6 = linked_1874.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_1873, arg_1876) }; tmp4.Invoke_O_O__O(tmp5, tmp6); if
	jrt.NN(jrt.File_Cast(tmp__3)).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { var root_1844 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, A_arbace_build_go_delete_tree_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = tmp__3; if linked_1845 == nil { return ifn_1846.Invoke_O__O(arg_1847) } else { return linked_1845.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_1844, arg_1847) } } }
//line :452:1
func A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New() *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__fn__1901000326_A{}; t.Ctor(); return t }
//line :452:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Ctor() {}
//line :452:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Invoke_O_O__O(self, p1__1901000315_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, p1__1901000315_SHARP___1, nil)).Ref() }


func A_arbace_build_go_print_module_A_New() *A_arbace_build_go_print_module_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_A{}; t.Ctor(); return t }
//line :455:1
func (t *A_arbace_build_go_print_module_A) Ctor() {}
//line :455:1
func (t *A_arbace_build_go_print_module_A) Invoke_O_O_O_O_O__O(self, p__1901000331__0, dir__1, out__2, p__1901000332__3 any) any { var map__1901000333__5 any = p__1901000331__0; var map__1901000333__6 any; if lang.ISeq_InstanceOf(map__1901000333__5) { var tmp1 any; var root_1905 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1905, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1907 lang.IFn; if linked_1906 == nil { ifn_1907 = lang.IFn_Cast(root_1905) } else { ifn_1907 = nil }; var arg_1908 any = map__1901000333__5; if linked_1906 == nil { tmp1 = ifn_1907.Invoke_O__O(arg_1908) } else { tmp1 = linked_1906.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1905, arg_1908) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1909 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any = map__1901000333__5; if linked_1910 == nil { tmp2 = ifn_1911.Invoke_O__O(arg_1912) } else { tmp2 = linked_1910.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1909, arg_1912) }; map__1901000333__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1913 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = map__1901000333__5; if linked_1914 == nil { tmp3 = ifn_1915.Invoke_O__O(arg_1916) } else { tmp3 = linked_1914.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1913, arg_1916) }; if jrt.J2g_Truth(tmp3) { var root_1917 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1918 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1917, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1919 lang.IFn; if linked_1918 == nil { ifn_1919 = lang.IFn_Cast(root_1917) } else { ifn_1919 = nil }; var arg_1920 any = map__1901000333__5; if linked_1918 == nil { map__1901000333__6 = ifn_1919.Invoke_O__O(arg_1920) } else { map__1901000333__6 = linked_1918.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1917, arg_1920) } } else { map__1901000333__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000333__6 = map__1901000333__5 }; var module__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_124); var packages__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_79); var modules__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_133); var golang__10 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_126); var map__1901000335__11 any = p__1901000332__3; var map__1901000335__12 any; if lang.ISeq_InstanceOf(map__1901000335__11) { var tmp4 any; var root_1921 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_1922 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1921, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1923 lang.IFn; if linked_1922 == nil { ifn_1923 = lang.IFn_Cast(root_1921) } else { ifn_1923 = nil }; var arg_1924 any = map__1901000335__11; if linked_1922 == nil { tmp4 = ifn_1923.Invoke_O__O(arg_1924) } else { tmp4 = linked_1922.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1921, arg_1924) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1925 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_1926 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1925, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1927 lang.IFn; if linked_1926 == nil { ifn_1927 = lang.IFn_Cast(root_1925) } else { ifn_1927 = nil }; var arg_1928 any = map__1901000335__11; if linked_1926 == nil { tmp5 = ifn_1927.Invoke_O__O(arg_1928) } else { tmp5 = linked_1926.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1925, arg_1928) }; map__1901000335__12 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp5)).Ref() } else { var tmp6 any; var root_1929 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1930 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1929, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1931 lang.IFn; if linked_1930 == nil { ifn_1931 = lang.IFn_Cast(root_1929) } else { ifn_1931 = nil }; var arg_1932 any = map__1901000335__11; if linked_1930 == nil { tmp6 = ifn_1931.Invoke_O__O(arg_1932) } else { tmp6 = linked_1930.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1929, arg_1932) }; if jrt.J2g_Truth(tmp6) { var root_1933 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1934 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1933, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1935 lang.IFn; if linked_1934 == nil { ifn_1935 = lang.IFn_Cast(root_1933) } else { ifn_1935 = nil }; var arg_1936 any = map__1901000335__11; if linked_1934 == nil { map__1901000335__12 = ifn_1935.Invoke_O__O(arg_1936) } else { map__1901000335__12 = linked_1934.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1933, arg_1936) } } else { map__1901000335__12 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000335__12 = map__1901000335__11 }; var layout__13 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_145); var line_file__14 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_146); var tests__15 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_150); var goos__16 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_151); var goroot__17 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_152); var goos_dir__18 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_153); var print_cache__19 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__12, A_arbace_build_go_A_const_122);









	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(out__2)).Mkdirs__Z()); var seq_1901000337__20 any; var root_2396 any = /*line :455:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2396, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2398 lang.IFn; if











	linked_2397 == nil { ifn_2398 = lang.IFn_Cast(root_2396) } else { ifn_2398 = nil }; var arg_2399 any = modules__9; if linked_2397 == nil { seq_1901000337__20 = ifn_2398.Invoke_O__O(arg_2399) } else { seq_1901000337__20 = linked_2397.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2396, arg_2399) }; var chunk_1901000338__21 any; var count_1901000339__22 int64 = 0; var i_1901000340__23 int64 = 0; L1:
//line :455:1
	for {











		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000340__23, count_1901000339__22) { var m__24 any = lang.Indexed_Cast(chunk_1901000338__21).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000340__23))
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__24))).Mkdirs__Z())
			lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__24, nil))), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, nil, m__24, nil, golang__10, nil)).Ref())
//line :467:1
			seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, i_1901000340__23 = seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000340__23); continue L1 } else { var temp__1927000414__auto____24 any; var root_2400 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2400, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2402 lang.IFn; if linked_2401 == nil { ifn_2402 = lang.IFn_Cast(root_2400) } else { ifn_2402 = nil }; var arg_2403 any = seq_1901000337__20; if linked_2401 == nil { temp__1927000414__auto____24 = ifn_2402.Invoke_O__O(arg_2403) } else { temp__1927000414__auto____24 = linked_2401.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2400, arg_2403) }; if jrt.J2g_Truth(temp__1927000414__auto____24) { var seq_1901000337__25 any = temp__1927000414__auto____24; var tmp7 any; var root_2404 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2404, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2406 lang.IFn; if linked_2405 == nil { ifn_2406 = lang.IFn_Cast(root_2404) } else { ifn_2406 = nil }; var arg_2407 any = seq_1901000337__25; if linked_2405 == nil { tmp7 = ifn_2406.Invoke_O__O(arg_2407) } else { tmp7 = linked_2405.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2404, arg_2407) }; if jrt.J2g_Truth(tmp7) { var c__1927000678__auto____26 any; var root_2408 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2408, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2410 lang.IFn; if linked_2409 == nil { ifn_2410 = lang.IFn_Cast(root_2408) } else { ifn_2410 = nil }; var arg_2411 any = seq_1901000337__25; if linked_2409 == nil { c__1927000678__auto____26 = ifn_2410.Invoke_O__O(arg_2411) } else { c__1927000678__auto____26 = linked_2409.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2408, arg_2411) }; var tmp8 any; var root_2510 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2511 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2510, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2512 lang.IFn; if linked_2511 == nil { ifn_2512 = lang.IFn_Cast(root_2510) } else { ifn_2512 = nil }; var arg_2513 any = seq_1901000337__25; if linked_2511 == nil { tmp8 = ifn_2512.Invoke_O__O(arg_2513) } else { tmp8 = linked_2511.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2510, arg_2513) }; seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, i_1901000340__23 = tmp8, c__1927000678__auto____26, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____26))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var m__26 any; var root_2412 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2412, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2414 lang.IFn; if linked_2413 == nil { ifn_2414 = lang.IFn_Cast(root_2412) } else { ifn_2414 = nil }; var arg_2415 any = seq_1901000337__25; if linked_2413 == nil { m__26 = ifn_2414.Invoke_O__O(arg_2415) } else { m__26 = linked_2413.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2412, arg_2415) }
				jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil), jrt.RefArrayOf(jrt.Object_class, nil, m__26))).Mkdirs__Z())
				lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__26, nil))), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_45), jrt.RefArrayOf(jrt.Object_class, nil, m__26, nil, golang__10, nil)).Ref())
//line :467:1
				var tmp9 any; var root_2519 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2520 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2519, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2521 lang.IFn; if linked_2520 == nil { ifn_2521 = lang.IFn_Cast(root_2519) } else { ifn_2521 = nil }; var arg_2522 any = seq_1901000337__25; if linked_2520 == nil { tmp9 = ifn_2521.Invoke_O__O(arg_2522) } else { tmp9 = linked_2520.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2519, arg_2522) }; seq_1901000337__20, chunk_1901000338__21, count_1901000339__22, i_1901000340__23 = tmp9, nil, 0, 0; continue L1 } } }
//line :455:1
		break L1 }; if














	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_103) { } else {
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()); var tmp11 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_104); var tmp12 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_101, nil, Lit_102, nil, Lit_45, nil, nil); var tmp13 *jrt.String; var tmp14 any; var root_2421 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2423 lang.IFn
		if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = modules__9; if linked_2422 == nil { tmp14 = ifn_2423.Invoke_O__O(arg_2424) } else { tmp14 = linked_2422.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2421, arg_2424) }; if jrt.J2g_Truth(tmp14) {
			var tmp15 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_105, nil); var tmp16 any; var root_2425 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2427 lang.IFn
			if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any; var iter__1927001039__auto____29 any; var tmp17 any = A_arbace_build_go_print_module_iter__1901000341__1901000345_A_New(); var tmp18 *jrt.Class; var fncls__2487 *jrt.Class = A_arbace_build_go_print_module_iter__1901000341__1901000345_A_fn_class; if fncls__2487 == nil { var fncls__2487d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_build_go_print_module_iter__1901000341__1901000345_A_fn_class = fncls__2487d; tmp18 = fncls__2487d } else { tmp18 = fncls__2487 }; iter__1927001039__auto____29 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); arg_2428 = lang.IFn_Cast(iter__1927001039__auto____29).Invoke_O__O(modules__9); if linked_2426 == nil { tmp16 = ifn_2427.Invoke_O__O(arg_2428) } else { tmp16 = linked_2426.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_2425, arg_2428) }
//line :473:1
			tmp13 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp15, jrt.RefArrayOf(jrt.Object_class, nil, tmp16)) } else {
//line :472:1
				tmp13 = nil }
//line :471:1
		var tmp19 any = tmp13.Ref(); var tmp20 *jrt.String



		if lang.Util_Equiv_O_O__Z_NoInit(goos__16, Lit_29) {
			var tmp21 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_107, nil, Lit_108, nil, Lit_45, nil); var tmp22 *lang.Keyword = A_arbace_build_go_A_const_48; var tmp23 any = tmp22.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp24 *lang.Keyword = A_arbace_build_go_A_const_113; var tmp25 any = tmp24.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp26 *jrt.String

			if jrt.J2g_Truth(goos_dir__18) {
				var tmp27 *jrt.RefArray = jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}); var tmp28 *lang.Keyword = A_arbace_build_go_A_const_48; var tmp29 any = tmp28.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp30 *lang.Keyword = A_arbace_build_go_A_const_113; var tmp31 any = tmp30.Invoke_O__O(A_arbace_build_go_A_const_106.GetRawRoot__O()); var tmp32 any; var root_2488 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2489 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2488, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2490 lang.IFn

				if linked_2489 == nil { ifn_2490 = lang.IFn_Cast(root_2488) } else { ifn_2490 = nil }; var arg_2491 any = goos_dir__18; if linked_2489 == nil { tmp32 = ifn_2490.Invoke_O__O(arg_2491) } else { tmp32 = linked_2489.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2488, arg_2491) }
//line :479:1
				tmp26 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp27, jrt.RefArrayOf(jrt.Object_class, nil, tmp29, nil, tmp31, nil, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp32)).GetAbsoluteFile__File()).GetPath__String().Ref(), nil)) } else {
//line :478:1
					tmp26 = nil }
//line :476:1
			tmp20 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp21, jrt.RefArrayOf(jrt.Object_class, nil, tmp23, nil, tmp25, nil, tmp26.Ref())) } else {
//line :475:1
				tmp20 = nil }
//line :471:1
		tmp10.Invoke_O_O__O(tmp11, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp12, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__10, nil, tmp19, tmp20.Ref())).Ref()) }; var tmp33 any; var and__1927000168__auto____20 bool =










	lang.Util_Equiv_O_O__Z_NoInit(goos__16, Lit_29); if and__1927000168__auto____20 { var root_2492 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2493 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2492, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2494 lang.IFn; if linked_2493 == nil { ifn_2494 = lang.IFn_Cast(root_2492) } else { ifn_2494 = nil }; var arg_2495 any = goos_dir__18; if linked_2493 == nil { tmp33 = ifn_2494.Invoke_O__O(arg_2495) } else { tmp33 = linked_2493.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2492, arg_2495) } } else { tmp33 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____20).Ref() }; if jrt.J2g_Truth(tmp33) {
		var tmp34 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()); var tmp35 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_109); var tmp36 any; var root_2501 any = A_arbace_build_go_A_const_170.GetRawRoot__O(); var linked_2502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2501, A_arbace_build_go_tamago_go_sum_A_fn_class); var ifn_2503 lang.IFn; if linked_2502 == nil { ifn_2503 = lang.IFn_Cast(root_2501) } else { ifn_2503 = nil }; var arg_2504 any = goroot__17; if linked_2502 == nil { tmp36 = ifn_2503.Invoke_O__O(arg_2504) } else { tmp36 = linked_2502.(*A_arbace_build_go_tamago_go_sum_A).Invoke_O_O__O(root_2501, arg_2504) }; tmp34.Invoke_O_O__O(tmp35, tmp36) }; var root_1937 any =
	A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_1938 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1937, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1939 lang.IFn; if linked_1938 == nil { ifn_1939 = lang.IFn_Cast(root_1937) } else { ifn_1939 = nil }; var arg_1940 any; var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()); var tmp38 any; if
	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_103) { tmp38 = nil } else { tmp38 = A_arbace_build_go_A_const_154 }; var tmp39 any = tmp38; var tmp40 any; var iter__1927001039__auto____20 any; var tmp41 any = A_arbace_build_go_print_module_iter__1901000351__1901000355_A_New(); var tmp42 *jrt.Class; var fncls__2005 *jrt.Class = A_arbace_build_go_print_module_iter__1901000351__1901000355_A_fn_class; if
	fncls__2005 == nil { var fncls__2005d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_110, false); A_arbace_build_go_print_module_iter__1901000351__1901000355_A_fn_class = fncls__2005d; tmp42 = fncls__2005d } else { tmp42 = fncls__2005 }; iter__1927001039__auto____20 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp41, tmp42, nil); tmp40 = lang.IFn_Cast(iter__1927001039__auto____20).Invoke_O__O(modules__9); var tmp43 any = tmp40; var tmp44 any; var root_2006 any = /*line :485:1*/A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_2007 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2006, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_2008 lang.IFn; if

	linked_2007 == nil { ifn_2008 = lang.IFn_Cast(root_2006) } else { ifn_2008 = nil }; var arg_2009 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var arg_2010 any; var root_2011 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_2012 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2011, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_2013 lang.IFn; if linked_2012 == nil { ifn_2013 = lang.IFn_Cast(root_2011) } else { ifn_2013 = nil }; var arg_2014 any; var tmp45 any = A_arbace_build_go_print_module_fn__1901000361_A_New_O_O_O_O_O_O(dir__1, out__2, tests__15, line_file__14, layout__13, print_cache__19); var tmp46 *jrt.Class; var fncls__2395 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_A_fn_class; if
	fncls__2395 == nil { var fncls__2395d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_111, false); A_arbace_build_go_print_module_fn__1901000361_A_fn_class = fncls__2395d; tmp46 = fncls__2395d } else { tmp46 = fncls__2395 }; arg_2014 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil); var arg_2015 any = packages__8; if /*line :487:1*/ linked_2012 == nil { arg_2010 = ifn_2013.Invoke_O_O__O(arg_2014, arg_2015) } else { arg_2010 = linked_2012.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_2011, arg_2014, arg_2015) }; if linked_2007 == nil { tmp44 = ifn_2008.Invoke_O_O__O(arg_2009, arg_2010) } else { tmp44 = linked_2007.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_2006, arg_2009, arg_2010) }; arg_1940 = /*line :485:1*/tmp37.Invoke_O_O_O__O(tmp39, tmp43, tmp44); if /*line :484:1*/ linked_1938 == nil { return ifn_1939.Invoke_O__O(arg_1940) } else { return linked_1938.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1937, arg_1940) } }
//line :474:1
func A_arbace_build_go_print_module_iter__1901000341__1901000345_A_New() *A_arbace_build_go_print_module_iter__1901000341__1901000345_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000341__1901000345_A{}; t.Ctor(); return t }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_A) Ctor() {}
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_A) Invoke_O_O__O(self, s__1901000342__1 any) any { var tmp1 any = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_New_O_O(self, s__1901000342__1); var tmp2 *jrt.Class; var fncls__2486 *jrt.Class = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_fn_class; if fncls__2486 == nil { var fncls__2486d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_fn_class = fncls__2486d; tmp2 = fncls__2486d } else { tmp2 = fncls__2486 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :474:1
func A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A{}; t.Ctor_O_O(p0, p1); return t }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A) Ctor_O_O(c__iter__1901000341, c__s__1901000342 any) { t.F_iter__1901000341 = c__iter__1901000341; t.F_s__1901000342 = c__s__1901000342 }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A) Invoke_O__O(self any) any { { var s__1901000342__1 any; var t_ any = t.F_s__1901000342; t.F_s__1901000342 = nil; s__1901000342__1 = t_; for { var temp__1927000414__auto____2 any; var root_2429 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2429, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2431 lang.IFn; if linked_2430 == nil { ifn_2431 = lang.IFn_Cast(root_2429) } else { ifn_2431 = nil }; var arg_2432 any = s__1901000342__1; if linked_2430 == nil { temp__1927000414__auto____2 = ifn_2431.Invoke_O__O(arg_2432) } else { temp__1927000414__auto____2 = linked_2430.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2429, arg_2432) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000342__3 any = temp__1927000414__auto____2; var tmp1 any; var root_2433 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2433, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2435 lang.IFn; if linked_2434 == nil { ifn_2435 = lang.IFn_Cast(root_2433) } else { ifn_2435 = nil }; var arg_2436 any = s__1901000342__3; if linked_2434 == nil { tmp1 = ifn_2435.Invoke_O__O(arg_2436) } else { tmp1 = linked_2434.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2433, arg_2436) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_2437 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2437, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2439 lang.IFn; if linked_2438 == nil { ifn_2439 = lang.IFn_Cast(root_2437) } else { ifn_2439 = nil }; var arg_2440 any = s__1901000342__3; if linked_2438 == nil { c__1927001037__auto____4 = ifn_2439.Invoke_O__O(arg_2440) } else { c__1927001037__auto____4 = linked_2438.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2437, arg_2440) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000344__6 any; var root_2441 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_2442 == nil { b__1901000344__6 = ifn_2443.Invoke_O__O(arg_2444) } else { b__1901000344__6 = linked_2442.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_2441, arg_2444) }; var tmp2 any = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_New_O_I_O(b__1901000344__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__2450 *jrt.Class = A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_fn_class; if fncls__2450 == nil { var fncls__2450d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_fn_class = fncls__2450d; tmp3 = fncls__2450d } else { tmp3 = fncls__2450 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_2451 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2452 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2451, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2453 lang.IFn; if linked_2452 == nil { ifn_2453 = lang.IFn_Cast(root_2451) } else { ifn_2453 = nil }; var arg_2454 any; var root_2456 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_2457 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2456, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2458 lang.IFn; if linked_2457 == nil { ifn_2458 = lang.IFn_Cast(root_2456) } else { ifn_2458 = nil }; var arg_2459 any = b__1901000344__6; if linked_2457 == nil { arg_2454 = ifn_2458.Invoke_O__O(arg_2459) } else { arg_2454 = linked_2457.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2456, arg_2459) }; var arg_2455 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000341); var tmp5 any; var root_2460 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2461 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2460, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2462 lang.IFn; if linked_2461 == nil { ifn_2462 = lang.IFn_Cast(root_2460) } else { ifn_2462 = nil }; var arg_2463 any = s__1901000342__3; if linked_2461 == nil { tmp5 = ifn_2462.Invoke_O__O(arg_2463) } else { tmp5 = linked_2461.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2460, arg_2463) }; arg_2455 = tmp4.Invoke_O__O(tmp5); if linked_2452 == nil { return ifn_2453.Invoke_O_O__O(arg_2454, arg_2455) } else { return linked_2452.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2451, arg_2454, arg_2455) } } else { var root_2464 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2465 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2464, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_2466 lang.IFn; if linked_2465 == nil { ifn_2466 = lang.IFn_Cast(root_2464) } else { ifn_2466 = nil }; var arg_2467 any; var root_2469 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_2470 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2469, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_2471 lang.IFn; if linked_2470 == nil { ifn_2471 = lang.IFn_Cast(root_2469) } else { ifn_2471 = nil }; var arg_2472 any = b__1901000344__6; if linked_2470 == nil { arg_2467 = ifn_2471.Invoke_O__O(arg_2472) } else { arg_2467 = linked_2470.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_2469, arg_2472) }; var arg_2468 any; if linked_2465 == nil { return ifn_2466.Invoke_O_O__O(arg_2467, arg_2468) } else { return linked_2465.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_2464, arg_2467, arg_2468) } } } else { var m__4 any; var root_2473 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2473, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2475 lang.IFn; if linked_2474 == nil { ifn_2475 = lang.IFn_Cast(root_2473) } else { ifn_2475 = nil }; var arg_2476 any = s__1901000342__3; if linked_2474 == nil { m__4 = ifn_2475.Invoke_O__O(arg_2476) } else { m__4 = linked_2474.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2473, arg_2476) }; var root_2477 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_2478 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2477, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_2479 lang.IFn; if linked_2478 == nil { ifn_2479 = lang.IFn_Cast(root_2477) } else { ifn_2479 = nil }; var arg_2480 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s8:require ns16: v0.0.0\nreplace ns15: => ./_modules/ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, m__4, nil, m__4, nil, m__4, nil)).Ref(); var arg_2481 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000341); var tmp7 any; var root_2482 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2482, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2484 lang.IFn; if linked_2483 == nil { ifn_2484 = lang.IFn_Cast(root_2482) } else { ifn_2484 = nil }; var arg_2485 any = s__1901000342__3; if linked_2483 == nil { tmp7 = ifn_2484.Invoke_O__O(arg_2485) } else { tmp7 = linked_2483.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2482, arg_2485) }; arg_2481 = tmp6.Invoke_O__O(tmp7); if linked_2478 == nil { return ifn_2479.Invoke_O_O__O(arg_2480, arg_2481) } else { return linked_2478.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_2477, arg_2480, arg_2481) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :474:1
func A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A) Ctor_O_I_O(c__b__1901000344 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000344 = c__b__1901000344; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :474:1
func (t *A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A) Invoke_O__O(self any) any { { var i__1901000343__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000343__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000343__1)); var root_2445 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = t.F_b__1901000344; var arg_2449 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s8:require ns16: v0.0.0\nreplace ns15: => ./_modules/ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, m__2, nil, m__2, nil, m__2, nil)).Ref(); if linked_2446 == nil { ifn_2447.Invoke_O_O__O(arg_2448, arg_2449) } else { linked_2446.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_2445, arg_2448, arg_2449) }; i__1901000343__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000343__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }











func A_arbace_build_go_print_module_iter__1901000351__1901000355_A_New() *A_arbace_build_go_print_module_iter__1901000351__1901000355_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000351__1901000355_A{}; t.Ctor(); return t }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_A) Ctor() {}
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_A) Invoke_O_O__O(self, s__1901000352__1 any) any { var tmp1 any = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_New_O_O(self, s__1901000352__1); var tmp2 *jrt.Class; var fncls__2004 *jrt.Class = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_fn_class; if fncls__2004 == nil { var fncls__2004d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_126, false); A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_fn_class = fncls__2004d; tmp2 = fncls__2004d } else { tmp2 = fncls__2004 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :486:1
func A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A{}; t.Ctor_O_O(p0, p1); return t }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A) Ctor_O_O(c__iter__1901000351, c__s__1901000352 any) { t.F_iter__1901000351 = c__iter__1901000351; t.F_s__1901000352 = c__s__1901000352 }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A) Invoke_O__O(self any) any { { var s__1901000352__1 any; var t_ any = t.F_s__1901000352; t.F_s__1901000352 = nil; s__1901000352__1 = t_; for { var temp__1927000414__auto____2 any; var root_1947 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1947, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1949 lang.IFn; if linked_1948 == nil { ifn_1949 = lang.IFn_Cast(root_1947) } else { ifn_1949 = nil }; var arg_1950 any = s__1901000352__1; if linked_1948 == nil { temp__1927000414__auto____2 = ifn_1949.Invoke_O__O(arg_1950) } else { temp__1927000414__auto____2 = linked_1948.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1947, arg_1950) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000352__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1951 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = s__1901000352__3; if linked_1952 == nil { tmp1 = ifn_1953.Invoke_O__O(arg_1954) } else { tmp1 = linked_1952.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1951, arg_1954) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1955 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = s__1901000352__3; if linked_1956 == nil { c__1927001037__auto____4 = ifn_1957.Invoke_O__O(arg_1958) } else { c__1927001037__auto____4 = linked_1956.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1955, arg_1958) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000354__6 any; var root_1959 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1961 lang.IFn; if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1960 == nil { b__1901000354__6 = ifn_1961.Invoke_O__O(arg_1962) } else { b__1901000354__6 = linked_1960.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1959, arg_1962) }; var tmp2 any = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_New_O_I_O(b__1901000354__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1968 *jrt.Class = A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_fn_class; if fncls__1968 == nil { var fncls__1968d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_127, false); A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_fn_class = fncls__1968d; tmp3 = fncls__1968d } else { tmp3 = fncls__1968 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1969 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any; var root_1974 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1975 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1974, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1976 lang.IFn; if linked_1975 == nil { ifn_1976 = lang.IFn_Cast(root_1974) } else { ifn_1976 = nil }; var arg_1977 any = b__1901000354__6; if linked_1975 == nil { arg_1972 = ifn_1976.Invoke_O__O(arg_1977) } else { arg_1972 = linked_1975.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1974, arg_1977) }; var arg_1973 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000351); var tmp5 any; var root_1978 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1979 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1978, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1980 lang.IFn; if linked_1979 == nil { ifn_1980 = lang.IFn_Cast(root_1978) } else { ifn_1980 = nil }; var arg_1981 any = s__1901000352__3; if linked_1979 == nil { tmp5 = ifn_1980.Invoke_O__O(arg_1981) } else { tmp5 = linked_1979.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1978, arg_1981) }; arg_1973 = tmp4.Invoke_O__O(tmp5); if linked_1970 == nil { return ifn_1971.Invoke_O_O__O(arg_1972, arg_1973) } else { return linked_1970.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1969, arg_1972, arg_1973) } } else { var root_1982 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1983 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1982, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1984 lang.IFn; if linked_1983 == nil { ifn_1984 = lang.IFn_Cast(root_1982) } else { ifn_1984 = nil }; var arg_1985 any; var root_1987 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1987, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1989 lang.IFn; if linked_1988 == nil { ifn_1989 = lang.IFn_Cast(root_1987) } else { ifn_1989 = nil }; var arg_1990 any = b__1901000354__6; if linked_1988 == nil { arg_1985 = ifn_1989.Invoke_O__O(arg_1990) } else { arg_1985 = linked_1988.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1987, arg_1990) }; var arg_1986 any; if linked_1983 == nil { return ifn_1984.Invoke_O_O__O(arg_1985, arg_1986) } else { return linked_1983.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1982, arg_1985, arg_1986) } } } else { var m__4 any; var root_1991 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1991, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1993 lang.IFn; if linked_1992 == nil { ifn_1993 = lang.IFn_Cast(root_1991) } else { ifn_1993 = nil }; var arg_1994 any = s__1901000352__3; if linked_1992 == nil { m__4 = ifn_1993.Invoke_O__O(arg_1994) } else { m__4 = linked_1992.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1991, arg_1994) }; var root_1995 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1995, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1997 lang.IFn; if linked_1996 == nil { ifn_1997 = lang.IFn_Cast(root_1995) } else { ifn_1997 = nil }; var arg_1998 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__4, nil)).Ref(); var arg_1999 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000351); var tmp7 any; var root_2000 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2001 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2000, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_2002 lang.IFn; if linked_2001 == nil { ifn_2002 = lang.IFn_Cast(root_2000) } else { ifn_2002 = nil }; var arg_2003 any = s__1901000352__3; if linked_2001 == nil { tmp7 = ifn_2002.Invoke_O__O(arg_2003) } else { tmp7 = linked_2001.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_2000, arg_2003) }; arg_1999 = tmp6.Invoke_O__O(tmp7); if linked_1996 == nil { return ifn_1997.Invoke_O_O__O(arg_1998, arg_1999) } else { return linked_1996.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1995, arg_1998, arg_1999) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :486:1
func A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A) Ctor_O_I_O(c__b__1901000354 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000354 = c__b__1901000354; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :486:1
func (t *A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A) Invoke_O__O(self any) any { { var i__1901000353__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000353__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var m__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000353__1)); var root_1963 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1964 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1963, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1965 lang.IFn; if linked_1964 == nil { ifn_1965 = lang.IFn_Cast(root_1963) } else { ifn_1965 = nil }; var arg_1966 any = t.F_b__1901000354; var arg_1967 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_99, nil, Lit_100), jrt.RefArrayOf(jrt.Object_class, nil, m__2, nil)).Ref(); if linked_1964 == nil { ifn_1965.Invoke_O_O__O(arg_1966, arg_1967) } else { linked_1964.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1963, arg_1966, arg_1967) }; i__1901000353__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000353__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_print_module_fn__1901000361_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_print_module_fn__1901000361_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :488:1
func (t *A_arbace_build_go_print_module_fn__1901000361_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :488:1
func (t *A_arbace_build_go_print_module_fn__1901000361_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z_NoInit(Lit_97, A_arbace_build_go_A_const_128.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_build_go_A_const_128.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__1901000362__3_ any; var tmp2 any = A_arbace_build_go_A_const_145; var tmp3 any; var or__1927000174__auto____3 any = /*line :488:1*/t.F_layout; if

	jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.J2g_Truth(t.F_line_file) { tmp3 = A_arbace_build_go_A_const_155 } else { tmp3 = A_arbace_build_go_A_const_156 } }; G__1901000362__3_ = /*line :488:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.J2g_Truth(t.F_line_file) {
		var root_2016 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2017 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2016, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2018 lang.IFn; if linked_2017 == nil { ifn_2018 = lang.IFn_Cast(root_2016) } else { ifn_2018 = nil }; var arg_2019 any = G__1901000362__3_; var arg_2020 any = A_arbace_build_go_A_const_146; var arg_2021 any = jrt.Boolean_TRUE.Ref(); if linked_2017 == nil { opts__3 = ifn_2018.Invoke_O_O_O__O(arg_2019, arg_2020, arg_2021) } else { opts__3 = linked_2017.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2016, arg_2019, arg_2020, arg_2021) } } else {
//line :490:1
			opts__3 = G__1901000362__3_ }; var test_files__4 any; var root_2022 any = /*line :488:1*/A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2024 lang.IFn; if



	linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any; var root_2026 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2027 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2026, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2028 lang.IFn; if linked_2027 == nil { ifn_2028 = lang.IFn_Cast(root_2026) } else { ifn_2028 = nil }; var arg_2029 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_157; var arg_2030 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2027 == nil { arg_2025 = ifn_2028.Invoke_O_O__O(arg_2029, arg_2030) } else { arg_2025 = linked_2027.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2026, arg_2029, arg_2030) }; if linked_2023 == nil { test_files__4 = ifn_2024.Invoke_O__O(arg_2025) } else { test_files__4 = linked_2023.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2022, arg_2025) }; var printable__5 any; var tmp5 any = /*line :488:1*/A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_New_O_O(test_files__4, t.F_tests); var tmp6 *jrt.Class; var fncls__2052 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_fn_class; if
	fncls__2052 == nil { var fncls__2052d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_112, false); A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_fn_class = fncls__2052d; tmp6 = fncls__2052d } else { tmp6 = fncls__2052 }; printable__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var host_id__6 any = /*line :488:1*/jrt.System_Getenv_String__String(Lit_113).Ref(); var entry__7 any; var tmp7 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.J2g_Truth(and__1927000168__auto____7) { var root_2053 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2054 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2053, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2055 lang.IFn; if linked_2054 == nil { ifn_2055 = lang.IFn_Cast(root_2053) } else { ifn_2055 = nil }; var arg_2056 any = host_id__6; if linked_2054 == nil { tmp7 = ifn_2055.Invoke_O__O(arg_2056) } else { tmp7 = linked_2054.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2053, arg_2056) } } else { tmp7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp7) { var k__7 any; var root_2057 any = A_arbace_build_go_A_const_159.GetRawRoot__O(); var linked_2058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2057, A_arbace_build_go_print_cache_key_A_fn_class); var ifn_2059 lang.IFn
		if linked_2058 == nil { ifn_2059 = lang.IFn_Cast(root_2057) } else { ifn_2059 = nil }; var arg_2060 any = host_id__6; var arg_2061 any = pkg__1; var arg_2062 any = t.F_dir; var arg_2063 any = opts__3; var arg_2064 any = t.F_tests; if linked_2058 == nil { k__7 = ifn_2059.Invoke_O_O_O_O_O__O(arg_2060, arg_2061, arg_2062, arg_2063, arg_2064) } else { k__7 = linked_2058.(*A_arbace_build_go_print_cache_key_A).Invoke_O_O_O_O_O_O__O(root_2057, arg_2060, arg_2061, arg_2062, arg_2063, arg_2064) }
//line :497:1
		var tmp8 *jrt.Class = A_arbace_build_go_A_const_68; var tmp9 any; var root_2065 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2066 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2065, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2067 lang.IFn

		if linked_2066 == nil { ifn_2067 = lang.IFn_Cast(root_2065) } else { ifn_2067 = nil }; var arg_2068 any = t.F_print_cache; if linked_2066 == nil { tmp9 = ifn_2067.Invoke_O__O(arg_2068) } else { tmp9 = linked_2066.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2065, arg_2068) }
//line :497:1
		var tmp10 *jrt.String = jrt.String_Cast(tmp9); var tmp11 any; var root_2069 any = A_arbace_build_go_A_const_130.GetRawRoot__O(); var linked_2070 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2069, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_2071 lang.IFn

		if linked_2070 == nil { ifn_2071 = lang.IFn_Cast(root_2069) } else { ifn_2071 = nil }; var arg_2072 any = k__7; var arg_2073 any = A_arbace_build_go_A_const_141; var arg_2074 any = A_arbace_build_go_A_const_160; if linked_2070 == nil { tmp11 = ifn_2071.Invoke_O_O_O__O(arg_2072, arg_2073, arg_2074) } else { tmp11 = linked_2070.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_2069, arg_2072, arg_2073, arg_2074) }
//line :497:1
		entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp8, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(tmp10, jrt.String_Cast(tmp11)), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.J2g_Truth(entry__7) { var root_2075 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2076 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2075, A_arbace_build_go_cached_texts_A_fn_class); var ifn_2077 lang.IFn; if linked_2076 == nil { ifn_2077 = lang.IFn_Cast(root_2075) } else { ifn_2077 = nil }; var arg_2078 any = entry__7; if linked_2076 == nil { or__1927000174__auto____8 = ifn_2077.Invoke_O__O(arg_2078) } else { or__1927000174__auto____8 = linked_2076.(*A_arbace_build_go_cached_texts_A).Invoke_O_O__O(root_2075, arg_2078) } } else { or__1927000174__auto____8 = nil }; if jrt.J2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var root_2079 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2080 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2079, aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A_fn_class); var ifn_2081 lang.IFn
		if linked_2080 == nil { ifn_2081 = lang.IFn_Cast(root_2079) } else { ifn_2081 = nil }; var arg_2082 any; var G__1901000369__9_ any; var tmp12 lang.IFn = lang.IFn_Cast(printable__5); var tmp13 any; var root_2088 any = A_arbace_build_go_A_const_164.GetRawRoot__O(); var linked_2089 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2088, A_arbace_build_go_collected_package_A_fn_class); var ifn_2090 lang.IFn; if linked_2089 == nil { ifn_2090 = lang.IFn_Cast(root_2088) } else { ifn_2090 = nil }; var arg_2091 any = pkg__1; if linked_2089 == nil { tmp13 = ifn_2090.Invoke_O__O(arg_2091) } else { tmp13 = linked_2089.(*A_arbace_build_go_collected_package_A).Invoke_O_O__O(root_2088, arg_2091) }; G__1901000369__9_ = tmp12.Invoke_O__O(tmp13); if jrt.J2g_Truth(t.F_line_file) { var root_2084 any = A_arbace_build_go_A_const_163.GetRawRoot__O(); var linked_2085 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2084, A_arbace_build_go_with_line_files_A_fn_class); var ifn_2086 lang.IFn; if linked_2085 == nil { ifn_2086 = lang.IFn_Cast(root_2084) } else { ifn_2086 = nil }; var arg_2087 any = G__1901000369__9_; if linked_2085 == nil { arg_2082 = ifn_2086.Invoke_O__O(arg_2087) } else { arg_2082 = linked_2085.(*A_arbace_build_go_with_line_files_A).Invoke_O_O__O(root_2084, arg_2087) } } else { arg_2082 = G__1901000369__9_ }; var arg_2083 any = opts__3; if linked_2080 == nil { t__9 = ifn_2081.Invoke_O_O__O(arg_2082, arg_2083) } else { t__9 = linked_2080.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A).Invoke_O_O_O__O(root_2079, arg_2082, arg_2083) }
		if jrt.J2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(entry__7)).GetParentFile__File()).Mkdirs__Z())
			var root_2132 any = A_arbace_build_go_A_const_167.GetRawRoot__O(); var linked_2133 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2132, A_arbace_build_go_cache_texts_BANG__A_fn_class); var ifn_2134 lang.IFn; if linked_2133 == nil { ifn_2134 = lang.IFn_Cast(root_2132) } else { ifn_2134 = nil }; var arg_2135 any = entry__7; var arg_2136 any = t__9; if linked_2133 == nil { ifn_2134.Invoke_O_O__O(arg_2135, arg_2136) } else { linked_2133.(*A_arbace_build_go_cache_texts_BANG__A).Invoke_O_O_O__O(root_2132, arg_2135, arg_2136) } }
//line :500:1
		texts__8 = t__9 }; var declared__9 any; var tmp14 /*line :488:1*/*lang.Keyword = A_arbace_build_go_A_const_143; var temp__1927000414__auto____9 any = tmp14.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if

















	jrt.J2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var root_2092 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_2093 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2092, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_2094 lang.IFn
		if linked_2093 == nil { ifn_2094 = lang.IFn_Cast(root_2092) } else { ifn_2094 = nil }; var arg_2095 any = fs__10; var arg_2096 any; if jrt.J2g_Truth(t.F_tests) { var tmp15 *lang.Keyword = A_arbace_build_go_A_const_157; arg_2096 = tmp15.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)) } else { arg_2096 = nil }; if linked_2093 == nil { declared__9 = ifn_2094.Invoke_O_O__O(arg_2095, arg_2096) } else { declared__9 = linked_2093.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_2092, arg_2095, arg_2096) } } else {
//line :506:1
			declared__9 = nil }; var rel__10 any; var tmp16 any = /*line :488:1*/A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_New_O(pkg__1); var tmp17 *jrt.Class; var fncls__2097 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_fn_class; if
	fncls__2097 == nil { var fncls__2097d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_114, false); A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_fn_class = fncls__2097d; tmp17 = fncls__2097d } else { tmp17 = fncls__2097 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var src__11 any; var root_2098 any = /*line :488:1*/A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, A_arbace_build_go_forms_dir_A_fn_class); var ifn_2100 lang.IFn; if




















	linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = pkg__1; if linked_2099 == nil { src__11 = ifn_2100.Invoke_O__O(arg_2101) } else { src__11 = linked_2099.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_2098, arg_2101) }; var tmp18 any; var and__1927000168__auto____12 any = declared__9; if
	jrt.J2g_Truth(and__1927000168__auto____12) { var root_2137 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2138 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2137, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2139 lang.IFn; if linked_2138 == nil { ifn_2139 = lang.IFn_Cast(root_2137) } else { ifn_2139 = nil }; var arg_2140 any; var root_2142 any = A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_2143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2142, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2144 lang.IFn; if linked_2143 == nil { ifn_2144 = lang.IFn_Cast(root_2142) } else { ifn_2144 = nil }; var arg_2145 any; var root_2146 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2147 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2146, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2148 lang.IFn; if linked_2147 == nil { ifn_2148 = lang.IFn_Cast(root_2146) } else { ifn_2148 = nil }; var arg_2149 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_2150 any = declared__9; if linked_2147 == nil { arg_2145 = ifn_2148.Invoke_O_O__O(arg_2149, arg_2150) } else { arg_2145 = linked_2147.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2146, arg_2149, arg_2150) }; if linked_2143 == nil { arg_2140 = ifn_2144.Invoke_O__O(arg_2145) } else { arg_2140 = linked_2143.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2142, arg_2145) }; var arg_2141 any; var root_2151 any = A_arbace_build_go_A_const_91.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any; var root_2155 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_2156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2155, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2157 lang.IFn; if linked_2156 == nil { ifn_2157 = lang.IFn_Cast(root_2155) } else { ifn_2157 = nil }; var arg_2158 any = texts__8; if linked_2156 == nil { arg_2154 = ifn_2157.Invoke_O__O(arg_2158) } else { arg_2154 = linked_2156.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2155, arg_2158) }; if linked_2152 == nil { arg_2141 = ifn_2153.Invoke_O__O(arg_2154) } else { arg_2141 = linked_2152.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2151, arg_2154) }; if linked_2138 == nil { tmp18 = ifn_2139.Invoke_O_O__O(arg_2140, arg_2141) } else { tmp18 = linked_2138.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2137, arg_2140, arg_2141) } } else { tmp18 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp18) {
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_115, nil, Lit_116, nil); var tmp21 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp22 any = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke_O__O(declared__9); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()); var tmp24 any; var root_2171 any = A_arbace_build_go_A_const_46.GetRawRoot__O(); var linked_2172 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2171, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2173 lang.IFn
		if linked_2172 == nil { ifn_2173 = lang.IFn_Cast(root_2171) } else { ifn_2173 = nil }; var arg_2174 any; var root_2175 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_2176 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2175, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2177 lang.IFn; if linked_2176 == nil { ifn_2177 = lang.IFn_Cast(root_2175) } else { ifn_2177 = nil }; var arg_2178 any = texts__8; if linked_2176 == nil { arg_2174 = ifn_2177.Invoke_O__O(arg_2178) } else { arg_2174 = linked_2176.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2175, arg_2178) }; if linked_2172 == nil { tmp24 = ifn_2173.Invoke_O__O(arg_2174) } else { tmp24 = linked_2172.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2171, arg_2174) }
//line :511:1
		tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, tmp22, nil, tmp23.Invoke_O__O(tmp24))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(pdir__2)).Mkdirs__Z()); var seq_1901000372__12 any; var root_2179 any = /*line :488:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2180 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2179, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2181 lang.IFn; if

























	linked_2180 == nil { ifn_2181 = lang.IFn_Cast(root_2179) } else { ifn_2181 = nil }; var arg_2182 any = texts__8; if linked_2180 == nil { seq_1901000372__12 = ifn_2181.Invoke_O__O(arg_2182) } else { seq_1901000372__12 = linked_2180.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2179, arg_2182) }; var chunk_1901000373__13 any; var count_1901000374__14 int64 = 0; var i_1901000375__15 int64 = 0; L1:
//line :488:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000375__15, count_1901000374__14) { var vec__1901000376__16 any = lang.Indexed_Cast(chunk_1901000373__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000375__15)); var n__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000376__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000376__16, lang.RT_IntCast_J__I_NoInit(1), nil)
			if jrt.File_InstanceOf(text__18) {
				var root_2239 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2240 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2239, A_arbace_build_go_copy_file_A_fn_class); var ifn_2241 lang.IFn; if linked_2240 == nil { ifn_2241 = lang.IFn_Cast(root_2239) } else { ifn_2241 = nil }; var arg_2242 any = text__18; var arg_2243 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)); if linked_2240 == nil { ifn_2241.Invoke_O_O__O(arg_2242, arg_2243) } else { linked_2240.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2239, arg_2242, arg_2243) } } else {
					lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18) }
//line :514:1
			seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, i_1901000375__15 = seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000375__15); continue L1 } else { var temp__1927000414__auto____16 any; var root_2183 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2183, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2185 lang.IFn; if linked_2184 == nil { ifn_2185 = lang.IFn_Cast(root_2183) } else { ifn_2185 = nil }; var arg_2186 any = seq_1901000372__12; if linked_2184 == nil { temp__1927000414__auto____16 = ifn_2185.Invoke_O__O(arg_2186) } else { temp__1927000414__auto____16 = linked_2184.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2183, arg_2186) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1901000372__17 any = temp__1927000414__auto____16; var tmp25 any; var root_2187 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2187, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2189 lang.IFn; if linked_2188 == nil { ifn_2189 = lang.IFn_Cast(root_2187) } else { ifn_2189 = nil }; var arg_2190 any = seq_1901000372__17; if linked_2188 == nil { tmp25 = ifn_2189.Invoke_O__O(arg_2190) } else { tmp25 = linked_2188.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2187, arg_2190) }; if jrt.J2g_Truth(tmp25) { var c__1927000678__auto____18 any; var root_2191 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2192 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2191, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2193 lang.IFn; if linked_2192 == nil { ifn_2193 = lang.IFn_Cast(root_2191) } else { ifn_2193 = nil }; var arg_2194 any = seq_1901000372__17; if linked_2192 == nil { c__1927000678__auto____18 = ifn_2193.Invoke_O__O(arg_2194) } else { c__1927000678__auto____18 = linked_2192.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2191, arg_2194) }; var tmp26 any; var root_2249 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2250 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2249, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2251 lang.IFn; if linked_2250 == nil { ifn_2251 = lang.IFn_Cast(root_2249) } else { ifn_2251 = nil }; var arg_2252 any = seq_1901000372__17; if linked_2250 == nil { tmp26 = ifn_2251.Invoke_O__O(arg_2252) } else { tmp26 = linked_2250.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2249, arg_2252) }; seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, i_1901000375__15 = tmp26, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000379__18 any; var root_2195 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = seq_1901000372__17; if linked_2196 == nil { vec__1901000379__18 = ifn_2197.Invoke_O__O(arg_2198) } else { vec__1901000379__18 = linked_2196.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2195, arg_2198) }; var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000379__18, lang.RT_IntCast_J__I_NoInit(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000379__18, lang.RT_IntCast_J__I_NoInit(1), nil)
				if jrt.File_InstanceOf(text__20) {
					var root_2253 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2254 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2253, A_arbace_build_go_copy_file_A_fn_class); var ifn_2255 lang.IFn; if linked_2254 == nil { ifn_2255 = lang.IFn_Cast(root_2253) } else { ifn_2255 = nil }; var arg_2256 any = text__20; var arg_2257 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)); if linked_2254 == nil { ifn_2255.Invoke_O_O__O(arg_2256, arg_2257) } else { linked_2254.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2253, arg_2256, arg_2257) } } else {
						lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20) }
//line :514:1
				var tmp27 any; var root_2263 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2264 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2263, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2265 lang.IFn; if linked_2264 == nil { ifn_2265 = lang.IFn_Cast(root_2263) } else { ifn_2265 = nil }; var arg_2266 any = seq_1901000372__17; if linked_2264 == nil { tmp27 = ifn_2265.Invoke_O__O(arg_2266) } else { tmp27 = linked_2264.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2263, arg_2266) }; seq_1901000372__12, chunk_1901000373__13, count_1901000374__14, i_1901000375__15 = tmp27, nil, 0, 0; continue L1 } } }
//line :488:1
		break L1 }; var seq_1901000382__12 any; var root_2199 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2201 lang.IFn; if





























	linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var tmp28 *lang.Keyword = A_arbace_build_go_A_const_165; var arg_2202 any = tmp28.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2200 == nil { seq_1901000382__12 = ifn_2201.Invoke_O__O(arg_2202) } else { seq_1901000382__12 = linked_2200.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2199, arg_2202) }; var chunk_1901000383__13 any; var count_1901000384__14 int64 = 0; var i_1901000385__15 int64 = 0; L2:
//line :488:1
	for {





























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000385__15, count_1901000384__14) { var f__16 any = lang.Indexed_Cast(chunk_1901000383__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000385__15)); var root_2267 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2268 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2267, A_arbace_build_go_copy_file_A_fn_class); var ifn_2269 lang.IFn
			if linked_2268 == nil { ifn_2269 = lang.IFn_Cast(root_2267) } else { ifn_2269 = nil }; var arg_2270 any; var tmp29 *jrt.File = jrt.File_Cast(src__11); var tmp30 any; var root_2272 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = f__16; if linked_2273 == nil { tmp30 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp30 = linked_2273.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2272, arg_2275) }; arg_2270 = jrt.File_New_File_String(tmp29, jrt.String_Cast(tmp30)); var arg_2271 any; var tmp31 *jrt.File = jrt.File_Cast(pdir__2); var tmp32 any; var root_2276 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2277 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2276, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2278 lang.IFn; if linked_2277 == nil { ifn_2278 = lang.IFn_Cast(root_2276) } else { ifn_2278 = nil }; var arg_2279 any = f__16; if linked_2277 == nil { tmp32 = ifn_2278.Invoke_O__O(arg_2279) } else { tmp32 = linked_2277.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2276, arg_2279) }; arg_2271 = jrt.File_New_File_String(tmp31, jrt.String_Cast(tmp32)); if linked_2268 == nil { ifn_2269.Invoke_O_O__O(arg_2270, arg_2271) } else { linked_2268.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2267, arg_2270, arg_2271) }
//line :518:1
			seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, i_1901000385__15 = seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000385__15); continue L2 } else { var temp__1927000414__auto____16_2 any; var root_2203 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2204 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2203, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2205 lang.IFn; if linked_2204 == nil { ifn_2205 = lang.IFn_Cast(root_2203) } else { ifn_2205 = nil }; var arg_2206 any = seq_1901000382__12; if linked_2204 == nil { temp__1927000414__auto____16_2 = ifn_2205.Invoke_O__O(arg_2206) } else { temp__1927000414__auto____16_2 = linked_2204.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2203, arg_2206) }; if jrt.J2g_Truth(temp__1927000414__auto____16_2) { var seq_1901000382__17 any = temp__1927000414__auto____16_2; var tmp33 any; var root_2207 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = seq_1901000382__17; if linked_2208 == nil { tmp33 = ifn_2209.Invoke_O__O(arg_2210) } else { tmp33 = linked_2208.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2207, arg_2210) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____18_2 any; var root_2211 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = seq_1901000382__17; if linked_2212 == nil { c__1927000678__auto____18_2 = ifn_2213.Invoke_O__O(arg_2214) } else { c__1927000678__auto____18_2 = linked_2212.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2211, arg_2214) }; var tmp34 any; var root_2280 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2281 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2280, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2282 lang.IFn; if linked_2281 == nil { ifn_2282 = lang.IFn_Cast(root_2280) } else { ifn_2282 = nil }; var arg_2283 any = seq_1901000382__17; if linked_2281 == nil { tmp34 = ifn_2282.Invoke_O__O(arg_2283) } else { tmp34 = linked_2281.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2280, arg_2283) }; seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, i_1901000385__15 = tmp34, c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var f__18 any; var root_2215 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2217 lang.IFn; if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = seq_1901000382__17; if linked_2216 == nil { f__18 = ifn_2217.Invoke_O__O(arg_2218) } else { f__18 = linked_2216.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2215, arg_2218) }
				var root_2284 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2285 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2284, A_arbace_build_go_copy_file_A_fn_class); var ifn_2286 lang.IFn; if linked_2285 == nil { ifn_2286 = lang.IFn_Cast(root_2284) } else { ifn_2286 = nil }; var arg_2287 any; var tmp35 *jrt.File = jrt.File_Cast(src__11); var tmp36 any; var root_2289 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = f__18; if linked_2290 == nil { tmp36 = ifn_2291.Invoke_O__O(arg_2292) } else { tmp36 = linked_2290.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2289, arg_2292) }; arg_2287 = jrt.File_New_File_String(tmp35, jrt.String_Cast(tmp36)); var arg_2288 any; var tmp37 *jrt.File = jrt.File_Cast(pdir__2); var tmp38 any; var root_2293 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = f__18; if linked_2294 == nil { tmp38 = ifn_2295.Invoke_O__O(arg_2296) } else { tmp38 = linked_2294.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2293, arg_2296) }; arg_2288 = jrt.File_New_File_String(tmp37, jrt.String_Cast(tmp38)); if linked_2285 == nil { ifn_2286.Invoke_O_O__O(arg_2287, arg_2288) } else { linked_2285.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2284, arg_2287, arg_2288) }
//line :518:1
				var tmp39 any; var root_2297 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = seq_1901000382__17; if linked_2298 == nil { tmp39 = ifn_2299.Invoke_O__O(arg_2300) } else { tmp39 = linked_2298.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2297, arg_2300) }; seq_1901000382__12, chunk_1901000383__13, count_1901000384__14, i_1901000385__15 = tmp39, nil, 0, 0; continue L2 } } }
//line :488:1
		break L2 }; var seq_1901000386__12 any; var root_2219 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2221 lang.IFn; if































	linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var tmp40 *lang.Keyword = A_arbace_build_go_A_const_166; var arg_2222 any = tmp40.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2220 == nil { seq_1901000386__12 = ifn_2221.Invoke_O__O(arg_2222) } else { seq_1901000386__12 = linked_2220.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2219, arg_2222) }; var chunk_1901000387__13 any; var count_1901000388__14 int64 = 0; var i_1901000389__15 int64 = 0; L3:
//line :488:1
	for {































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000389__15, count_1901000388__14) { var vec__1901000390__16 any = lang.Indexed_Cast(chunk_1901000387__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000389__15)); var f__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000390__16, lang.RT_IntCast_J__I_NoInit(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000390__16, lang.RT_IntCast_J__I_NoInit(1), nil); var from__19 any; var tmp41 *jrt.File = jrt.File_Cast(src__11); var tmp42 any; var root_2301 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2303 lang.IFn
			if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = f__17; if linked_2302 == nil { tmp42 = ifn_2303.Invoke_O__O(arg_2304) } else { tmp42 = linked_2302.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2301, arg_2304) }
//line :520:1
			from__19 = jrt.File_New_File_String(tmp41, jrt.String_Cast(tmp42))

			if jrt.NN(jrt.File_Cast(from__19)).IsFile__Z() { } else {
				var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil); var tmp45 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp46 any; var root_2318 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_2319 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2318, A_arbace_build_go_rel_path_A_fn_class); var ifn_2320 lang.IFn; if linked_2319 == nil { ifn_2320 = lang.IFn_Cast(root_2318) } else { ifn_2320 = nil }; var arg_2321 any = t.F_dir; var arg_2322 any = from__19; if linked_2319 == nil { tmp46 = ifn_2320.Invoke_O_O__O(arg_2321, arg_2322) } else { tmp46 = linked_2319.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2318, arg_2321, arg_2322) }; tmp43.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp44, jrt.RefArrayOf(jrt.Object_class, tmp45, nil, tmp46)).Ref()) }
			var tmp47 any; var and__1927000168__auto____20 any = h__18; if jrt.J2g_Truth(and__1927000168__auto____20) { var root_2323 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2324 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2323, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2325 lang.IFn; if linked_2324 == nil { ifn_2325 = lang.IFn_Cast(root_2323) } else { ifn_2325 = nil }; var arg_2326 any; var root_2328 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2328, A_arbace_build_go_sha256_A_fn_class); var ifn_2330 lang.IFn; if linked_2329 == nil { ifn_2330 = lang.IFn_Cast(root_2328) } else { ifn_2330 = nil }; var arg_2331 any = from__19; if linked_2329 == nil { arg_2326 = ifn_2330.Invoke_O__O(arg_2331) } else { arg_2326 = linked_2329.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2328, arg_2331) }; var arg_2327 any; var root_2332 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2333 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2332, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2334 lang.IFn; if linked_2333 == nil { ifn_2334 = lang.IFn_Cast(root_2332) } else { ifn_2334 = nil }; var arg_2335 any = h__18; if linked_2333 == nil { arg_2327 = ifn_2334.Invoke_O__O(arg_2335) } else { arg_2327 = linked_2333.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2332, arg_2335) }; if linked_2324 == nil { tmp47 = ifn_2325.Invoke_O_O__O(arg_2326, arg_2327) } else { tmp47 = linked_2324.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2323, arg_2326, arg_2327) } } else { tmp47 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp47) {
				var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp49 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_118, nil, Lit_119, nil, Lit_120, nil); var tmp50 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp51 any; var root_2340 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2340, A_arbace_build_go_sha256_A_fn_class); var ifn_2342 lang.IFn; if linked_2341 == nil { ifn_2342 = lang.IFn_Cast(root_2340) } else { ifn_2342 = nil }; var arg_2343 any = from__19; if linked_2341 == nil { tmp51 = ifn_2342.Invoke_O__O(arg_2343) } else { tmp51 = linked_2341.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2340, arg_2343) }; tmp48.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp49, jrt.RefArrayOf(jrt.Object_class, tmp50, nil, f__17, nil, tmp51, nil, h__18)).Ref())
			}
			var root_2305 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, A_arbace_build_go_copy_file_A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = from__19; var arg_2309 any; var tmp52 *jrt.File = jrt.File_Cast(pdir__2); var tmp53 any; var root_2310 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2311 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2310, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2312 lang.IFn; if linked_2311 == nil { ifn_2312 = lang.IFn_Cast(root_2310) } else { ifn_2312 = nil }; var arg_2313 any = f__17; if linked_2311 == nil { tmp53 = ifn_2312.Invoke_O__O(arg_2313) } else { tmp53 = linked_2311.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2310, arg_2313) }; arg_2309 = jrt.File_New_File_String(tmp52, jrt.String_Cast(tmp53)); if linked_2306 == nil { ifn_2307.Invoke_O_O__O(arg_2308, arg_2309) } else { linked_2306.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2305, arg_2308, arg_2309) }
//line :520:1
			seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, i_1901000389__15 = seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000389__15); continue L3 } else { var temp__1927000414__auto____16_3 any; var root_2223 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2224 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2223, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2225 lang.IFn; if linked_2224 == nil { ifn_2225 = lang.IFn_Cast(root_2223) } else { ifn_2225 = nil }; var arg_2226 any = seq_1901000386__12; if linked_2224 == nil { temp__1927000414__auto____16_3 = ifn_2225.Invoke_O__O(arg_2226) } else { temp__1927000414__auto____16_3 = linked_2224.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2223, arg_2226) }; if jrt.J2g_Truth(temp__1927000414__auto____16_3) { var seq_1901000386__17 any = temp__1927000414__auto____16_3; var tmp54 any; var root_2227 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2228 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2227, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2229 lang.IFn; if linked_2228 == nil { ifn_2229 = lang.IFn_Cast(root_2227) } else { ifn_2229 = nil }; var arg_2230 any = seq_1901000386__17; if linked_2228 == nil { tmp54 = ifn_2229.Invoke_O__O(arg_2230) } else { tmp54 = linked_2228.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2227, arg_2230) }; if jrt.J2g_Truth(tmp54) { var c__1927000678__auto____18_3 any; var root_2231 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2232 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2231, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2233 lang.IFn; if linked_2232 == nil { ifn_2233 = lang.IFn_Cast(root_2231) } else { ifn_2233 = nil }; var arg_2234 any = seq_1901000386__17; if linked_2232 == nil { c__1927000678__auto____18_3 = ifn_2233.Invoke_O__O(arg_2234) } else { c__1927000678__auto____18_3 = linked_2232.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2231, arg_2234) }; var tmp55 any; var root_2344 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2345 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2344, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2346 lang.IFn; if linked_2345 == nil { ifn_2346 = lang.IFn_Cast(root_2344) } else { ifn_2346 = nil }; var arg_2347 any = seq_1901000386__17; if linked_2345 == nil { tmp55 = ifn_2346.Invoke_O__O(arg_2347) } else { tmp55 = linked_2345.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2344, arg_2347) }; seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, i_1901000389__15 = tmp55, c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1901000393__18 any; var root_2235 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2236 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2235, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2237 lang.IFn; if linked_2236 == nil { ifn_2237 = lang.IFn_Cast(root_2235) } else { ifn_2237 = nil }; var arg_2238 any = seq_1901000386__17; if linked_2236 == nil { vec__1901000393__18 = ifn_2237.Invoke_O__O(arg_2238) } else { vec__1901000393__18 = linked_2236.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2235, arg_2238) }; var f__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000393__18, lang.RT_IntCast_J__I_NoInit(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000393__18, lang.RT_IntCast_J__I_NoInit(1), nil); var from__21 any; var tmp56 *jrt.File = jrt.File_Cast(src__11); var tmp57 any; var root_2348 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2349 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2348, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2350 lang.IFn
				if linked_2349 == nil { ifn_2350 = lang.IFn_Cast(root_2348) } else { ifn_2350 = nil }; var arg_2351 any = f__19; if linked_2349 == nil { tmp57 = ifn_2350.Invoke_O__O(arg_2351) } else { tmp57 = linked_2349.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2348, arg_2351) }
//line :520:1
				from__21 = jrt.File_New_File_String(tmp56, jrt.String_Cast(tmp57))

				if jrt.NN(jrt.File_Cast(from__21)).IsFile__Z() { } else {
					var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp59 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil); var tmp60 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp61 any; var root_2365 any = A_arbace_build_go_A_const_67.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, A_arbace_build_go_rel_path_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = t.F_dir; var arg_2369 any = from__21; if linked_2366 == nil { tmp61 = ifn_2367.Invoke_O_O__O(arg_2368, arg_2369) } else { tmp61 = linked_2366.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2365, arg_2368, arg_2369) }; tmp58.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp59, jrt.RefArrayOf(jrt.Object_class, tmp60, nil, tmp61)).Ref()) }
				var tmp62 any; var and__1927000168__auto____22 any = h__20; if jrt.J2g_Truth(and__1927000168__auto____22) { var root_2370 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2372 lang.IFn; if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any; var root_2375 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2376 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2375, A_arbace_build_go_sha256_A_fn_class); var ifn_2377 lang.IFn; if linked_2376 == nil { ifn_2377 = lang.IFn_Cast(root_2375) } else { ifn_2377 = nil }; var arg_2378 any = from__21; if linked_2376 == nil { arg_2373 = ifn_2377.Invoke_O__O(arg_2378) } else { arg_2373 = linked_2376.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2375, arg_2378) }; var arg_2374 any; var root_2379 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2379, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2381 lang.IFn; if linked_2380 == nil { ifn_2381 = lang.IFn_Cast(root_2379) } else { ifn_2381 = nil }; var arg_2382 any = h__20; if linked_2380 == nil { arg_2374 = ifn_2381.Invoke_O__O(arg_2382) } else { arg_2374 = linked_2380.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2379, arg_2382) }; if linked_2371 == nil { tmp62 = ifn_2372.Invoke_O_O__O(arg_2373, arg_2374) } else { tmp62 = linked_2371.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2370, arg_2373, arg_2374) } } else { tmp62 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp62) {
					var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp64 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_118, nil, Lit_119, nil, Lit_120, nil); var tmp65 any = A_arbace_build_go_A_const_48.Invoke_O__O(pkg__1); var tmp66 any; var root_2387 any = A_arbace_build_go_A_const_169.GetRawRoot__O(); var linked_2388 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2387, A_arbace_build_go_sha256_A_fn_class); var ifn_2389 lang.IFn; if linked_2388 == nil { ifn_2389 = lang.IFn_Cast(root_2387) } else { ifn_2389 = nil }; var arg_2390 any = from__21; if linked_2388 == nil { tmp66 = ifn_2389.Invoke_O__O(arg_2390) } else { tmp66 = linked_2388.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2387, arg_2390) }; tmp63.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp64, jrt.RefArrayOf(jrt.Object_class, tmp65, nil, f__19, nil, tmp66, nil, h__20)).Ref())
				}
				var root_2352 any = A_arbace_build_go_A_const_168.GetRawRoot__O(); var linked_2353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2352, A_arbace_build_go_copy_file_A_fn_class); var ifn_2354 lang.IFn; if linked_2353 == nil { ifn_2354 = lang.IFn_Cast(root_2352) } else { ifn_2354 = nil }; var arg_2355 any = from__21; var arg_2356 any; var tmp67 *jrt.File = jrt.File_Cast(pdir__2); var tmp68 any; var root_2357 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2358 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2357, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2359 lang.IFn; if linked_2358 == nil { ifn_2359 = lang.IFn_Cast(root_2357) } else { ifn_2359 = nil }; var arg_2360 any = f__19; if linked_2358 == nil { tmp68 = ifn_2359.Invoke_O__O(arg_2360) } else { tmp68 = linked_2358.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2357, arg_2360) }; arg_2356 = jrt.File_New_File_String(tmp67, jrt.String_Cast(tmp68)); if linked_2353 == nil { ifn_2354.Invoke_O_O__O(arg_2355, arg_2356) } else { linked_2353.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2352, arg_2355, arg_2356) }
//line :520:1
				var tmp69 any; var root_2391 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2392 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2391, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2393 lang.IFn; if linked_2392 == nil { ifn_2393 = lang.IFn_Cast(root_2391) } else { ifn_2393 = nil }; var arg_2394 any = seq_1901000386__17; if linked_2392 == nil { tmp69 = ifn_2393.Invoke_O__O(arg_2394) } else { tmp69 = linked_2392.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2391, arg_2394) }; seq_1901000386__12, chunk_1901000387__13, count_1901000388__14, i_1901000389__15 = tmp69, nil, 0, 0; continue L3 } } }
//line :488:1
		break L3 }; var root_2102 any =







































	A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = rel__10; var arg_2106 any; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()); var tmp71 any; var root_2113 any = A_arbace_build_go_A_const_149.GetRawRoot__O(); var linked_2114 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2113, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2115 lang.IFn; if linked_2114 == nil { ifn_2115 = lang.IFn_Cast(root_2113) } else { ifn_2115 = nil }; var arg_2116 any = texts__8; if linked_2114 == nil { tmp71 = ifn_2115.Invoke_O__O(arg_2116) } else { tmp71 = linked_2114.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2113, arg_2116) }; var tmp72 any = tmp71; var tmp73 any; var root_2117 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2117, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2119 lang.IFn; if linked_2118 == nil { ifn_2119 = lang.IFn_Cast(root_2117) } else { ifn_2119 = nil }; var arg_2120 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp74 *lang.Keyword = A_arbace_build_go_A_const_165; var arg_2121 any = tmp74.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2118 == nil { tmp73 = ifn_2119.Invoke_O_O__O(arg_2120, arg_2121) } else { tmp73 = linked_2118.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2117, arg_2120, arg_2121) }; var tmp75 any = tmp73; var tmp76 any; var root_2122 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2123 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2122, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2124 lang.IFn; if
	linked_2123 == nil { ifn_2124 = lang.IFn_Cast(root_2122) } else { ifn_2124 = nil }; var arg_2125 any; var root_2127 any = A_arbace_build_go_A_const_82.GetRawRoot__O(); var linked_2128 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2127, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_2129 lang.IFn; if linked_2128 == nil { ifn_2129 = lang.IFn_Cast(root_2127) } else { ifn_2129 = nil }; var arg_2130 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_2131 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); if linked_2128 == nil { arg_2125 = ifn_2129.Invoke_O_O__O(arg_2130, arg_2131) } else { arg_2125 = linked_2128.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_2127, arg_2130, arg_2131) }; var tmp77 *lang.Keyword = A_arbace_build_go_A_const_166; var arg_2126 any = tmp77.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1)); if linked_2123 == nil { tmp76 = ifn_2124.Invoke_O_O__O(arg_2125, arg_2126) } else { tmp76 = linked_2123.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2122, arg_2125, arg_2126) }; arg_2106 = /*line :528:1*/tmp70.Invoke_O_O_O__O(tmp72, tmp75, tmp76); if linked_2103 == nil { return ifn_2104.Invoke_O_O__O(arg_2105, arg_2106) } else { return linked_2103.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2102, arg_2105, arg_2106) } }
//line :489:1
func A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A{}; t.Ctor_O_O(p0, p1); return t }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A) Ctor_O_O(c__test_files, c__tests any) { t.F_test_files = c__test_files; t.F_tests = c__tests }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A) Invoke_O_O__O(self, p1__1901000329_SHARP___1 any) any {



	if jrt.J2g_Truth(t.F_tests) { return p1__1901000329_SHARP___1 } else {

		var root_2031 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_2032 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2031, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2033 lang.IFn; if linked_2032 == nil { ifn_2033 = lang.IFn_Cast(root_2031) } else { ifn_2033 = nil }; var arg_2034 any = p1__1901000329_SHARP___1; var arg_2035 any = A_arbace_build_go_A_const_143; var arg_2036 any; var tmp1 any = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_New_O(t.F_test_files); var tmp2 *jrt.Class; var fncls__2051 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_fn_class; if fncls__2051 == nil { var fncls__2051d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_121, false); A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_fn_class = fncls__2051d; tmp2 = fncls__2051d } else { tmp2 = fncls__2051 }; arg_2036 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_2032 == nil { return ifn_2033.Invoke_O_O_O__O(arg_2034, arg_2035, arg_2036) } else { return linked_2032.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_2031, arg_2034, arg_2035, arg_2036) } } }
//line :489:1
func A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A{}; t.Ctor_O(p0); return t }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :489:1
func (t *A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A) Invoke_O_O__O(self, p1__1901000330_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_97, A_arbace_build_go_A_const_128.Invoke_O__O(t.F_pkg)) { return p1__1901000330_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_123, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_128.Invoke_O__O(t.F_pkg), nil, p1__1901000330_SHARP___1)).Ref() } }
//line :495:1
func A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A{}; t.Ctor_O(p0); return t }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A) Invoke_O_O__O(self, fs__1 any) any { var root_2037 any = A_arbace_build_go_A_const_158.GetRawRoot__O(); var linked_2038 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2037, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_2039 lang.IFn; if linked_2038 == nil { ifn_2039 = lang.IFn_Cast(root_2037) } else { ifn_2039 = nil }; var arg_2040 any; var tmp1 any = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_New_O(t.F_test_files); var tmp2 *jrt.Class; var fncls__2050 *jrt.Class = A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_fn_class; if fncls__2050 == nil { var fncls__2050d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_fn_class = fncls__2050d; tmp2 = fncls__2050d } else { tmp2 = fncls__2050 }; arg_2040 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_2041 any = fs__1; if linked_2038 == nil { return ifn_2039.Invoke_O_O__O(arg_2040, arg_2041) } else { return linked_2038.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_2037, arg_2040, arg_2041) } }
//line :495:1
func A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A{}; t.Ctor_O(p0); return t }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :495:1
func (t *A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A) Invoke_O_O__O(self, f__1 any) any { var root_2042 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); var tmp2 any; var root_2046 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2048 lang.IFn; if linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = A_arbace_build_go_A_const_36.Invoke_O__O(f__1); if linked_2047 == nil { tmp2 = ifn_2048.Invoke_O__O(arg_2049) } else { tmp2 = linked_2047.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2046, arg_2049) }; arg_2045 = tmp1.Invoke_O__O(tmp2); if linked_2043 == nil { return ifn_2044.Invoke_O__O(arg_2045) } else { return linked_2043.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2042, arg_2045) } }







































func A_arbace_build_go_delete_tree_A_New() *A_arbace_build_go_delete_tree_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_delete_tree_A{}; t.Ctor(); return t }
//line :535:1
func (t *A_arbace_build_go_delete_tree_A) Ctor() {}
//line :535:1
func (t *A_arbace_build_go_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.NN(jrt.File_Cast(f__0)).IsDirectory__Z() { var seq_1901000398__2 any; var root_2523 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2524 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2523, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2525 lang.IFn
		if linked_2524 == nil { ifn_2525 = lang.IFn_Cast(root_2523) } else { ifn_2525 = nil }; var arg_2526 any = jrt.NN(jrt.File_Cast(f__0)).ListFiles__File1().Ref(); if linked_2524 == nil { seq_1901000398__2 = ifn_2525.Invoke_O__O(arg_2526) } else { seq_1901000398__2 = linked_2524.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2523, arg_2526) }
//line :536:1
		var chunk_1901000399__3 any; var count_1901000400__4 int64 = 0; var i_1901000401__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000401__5, count_1901000400__4) { var c__6 any = lang.Indexed_Cast(chunk_1901000399__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000401__5)); var root_2543 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2544 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2543, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2545 lang.IFn; if linked_2544 == nil { ifn_2545 = lang.IFn_Cast(root_2543) } else { ifn_2545 = nil }; var arg_2546 any = c__6; if linked_2544 == nil { ifn_2545.Invoke_O__O(arg_2546) } else { linked_2544.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2543, arg_2546) }; seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, i_1901000401__5 = seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000401__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_2527 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2528 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2527, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2529 lang.IFn; if linked_2528 == nil { ifn_2529 = lang.IFn_Cast(root_2527) } else { ifn_2529 = nil }; var arg_2530 any = seq_1901000398__2; if linked_2528 == nil { temp__1927000414__auto____6 = ifn_2529.Invoke_O__O(arg_2530) } else { temp__1927000414__auto____6 = linked_2528.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2527, arg_2530) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1901000398__7 any = temp__1927000414__auto____6; var tmp1 any; var root_2531 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2531, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2533 lang.IFn; if linked_2532 == nil { ifn_2533 = lang.IFn_Cast(root_2531) } else { ifn_2533 = nil }; var arg_2534 any = seq_1901000398__7; if linked_2532 == nil { tmp1 = ifn_2533.Invoke_O__O(arg_2534) } else { tmp1 = linked_2532.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2531, arg_2534) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_2535 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2535, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2537 lang.IFn; if linked_2536 == nil { ifn_2537 = lang.IFn_Cast(root_2535) } else { ifn_2537 = nil }; var arg_2538 any = seq_1901000398__7; if linked_2536 == nil { c__1927000678__auto____8 = ifn_2537.Invoke_O__O(arg_2538) } else { c__1927000678__auto____8 = linked_2536.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2535, arg_2538) }; var tmp2 any; var root_2547 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_2548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2547, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2549 lang.IFn; if linked_2548 == nil { ifn_2549 = lang.IFn_Cast(root_2547) } else { ifn_2549 = nil }; var arg_2550 any = seq_1901000398__7; if linked_2548 == nil { tmp2 = ifn_2549.Invoke_O__O(arg_2550) } else { tmp2 = linked_2548.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2547, arg_2550) }; seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, i_1901000401__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_2539 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2540 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2539, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2541 lang.IFn; if linked_2540 == nil { ifn_2541 = lang.IFn_Cast(root_2539) } else { ifn_2541 = nil }; var arg_2542 any = seq_1901000398__7; if linked_2540 == nil { c__8 = ifn_2541.Invoke_O__O(arg_2542) } else { c__8 = linked_2540.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2539, arg_2542) }; var root_2551 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2551, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2553 lang.IFn; if linked_2552 == nil { ifn_2553 = lang.IFn_Cast(root_2551) } else { ifn_2553 = nil }; var arg_2554 any = c__8; if linked_2552 == nil { ifn_2553.Invoke_O__O(arg_2554) } else { linked_2552.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2551, arg_2554) }; var tmp3 any; var root_2555 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2555, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2557 lang.IFn; if linked_2556 == nil { ifn_2557 = lang.IFn_Cast(root_2555) } else { ifn_2557 = nil }; var arg_2558 any = seq_1901000398__7; if linked_2556 == nil { tmp3 = ifn_2557.Invoke_O__O(arg_2558) } else { tmp3 = linked_2556.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2555, arg_2558) }; seq_1901000398__2, chunk_1901000399__3, count_1901000400__4, i_1901000401__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :536:1
			break L1
		} }
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).Delete__Z()).Ref()
}
func A_arbace_build_go_build_A_New() *A_arbace_build_go_build_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_build_A{}; t.Ctor(); return t }
//line :540:1
func (t *A_arbace_build_go_build_A) Ctor() {}
//line :540:1
func (t *A_arbace_build_go_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__1901000403__3 any) any { var map__1901000404__5 any = p__1901000403__3; var map__1901000404__6 any; if lang.ISeq_InstanceOf(map__1901000404__5) { var tmp1 any; var root_2559 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2559, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2561 lang.IFn; if linked_2560 == nil { ifn_2561 = lang.IFn_Cast(root_2559) } else { ifn_2561 = nil }; var arg_2562 any = map__1901000404__5; if linked_2560 == nil { tmp1 = ifn_2561.Invoke_O__O(arg_2562) } else { tmp1 = linked_2560.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2559, arg_2562) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2563 any = A_arbace_build_go_A_const_112.GetRawRoot__O(); var linked_2564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2563, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2565 lang.IFn; if linked_2564 == nil { ifn_2565 = lang.IFn_Cast(root_2563) } else { ifn_2565 = nil }; var arg_2566 any = map__1901000404__5; if linked_2564 == nil { tmp2 = ifn_2565.Invoke_O__O(arg_2566) } else { tmp2 = linked_2564.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2563, arg_2566) }; map__1901000404__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2567 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2568 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2567, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2569 lang.IFn; if linked_2568 == nil { ifn_2569 = lang.IFn_Cast(root_2567) } else { ifn_2569 = nil }; var arg_2570 any = map__1901000404__5; if linked_2568 == nil { tmp3 = ifn_2569.Invoke_O__O(arg_2570) } else { tmp3 = linked_2568.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2567, arg_2570) }; if jrt.J2g_Truth(tmp3) { var root_2571 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2572 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2571, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2573 lang.IFn; if linked_2572 == nil { ifn_2573 = lang.IFn_Cast(root_2571) } else { ifn_2573 = nil }; var arg_2574 any = map__1901000404__5; if linked_2572 == nil { map__1901000404__6 = ifn_2573.Invoke_O__O(arg_2574) } else { map__1901000404__6 = linked_2572.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2571, arg_2574) } } else { map__1901000404__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000404__6 = map__1901000404__5 }; var opts__7 any = map__1901000404__6; var work__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000404__6, A_arbace_build_go_A_const_171); var goroot__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000404__6, A_arbace_build_go_A_const_152); var prog__10 any; var root_2575 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_2576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2575, A_arbace_build_go_program_A_fn_class); var ifn_2577 lang.IFn; if



	linked_2576 == nil { ifn_2577 = lang.IFn_Cast(root_2575) } else { ifn_2577 = nil }; var arg_2578 any = dir__0; var arg_2579 any = goroot__9; var arg_2580 any = opts__7; if linked_2576 == nil { prog__10 = ifn_2577.Invoke_O_O_O__O(arg_2578, arg_2579, arg_2580) } else { prog__10 = linked_2576.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2575, arg_2578, arg_2579, arg_2580) }; var main__11 any = /*line :540:1*/A_arbace_build_go_A_const_137.Invoke_O__O(prog__10); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_172; var config__12 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z_NoInit(work__8, nil); var work__14 any; if







	jrt.J2g_Truth(work__8) { var tmp5 any; var root_2581 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2582 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2581, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2583 lang.IFn
		if linked_2582 == nil { ifn_2583 = lang.IFn_Cast(root_2581) } else { ifn_2583 = nil }; var arg_2584 any = work__8; if linked_2582 == nil { tmp5 = ifn_2583.Invoke_O__O(arg_2584) } else { tmp5 = linked_2582.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2581, arg_2584) }
//line :548:1
		work__14 = jrt.File_New_String(jrt.String_Cast(tmp5)) } else {

			var tmp6 *jrt.String = Lit_28; var tmp7 any; var root_2585 any = A_arbace_build_go_A_const_173.GetRawRoot__O(); var linked_2586 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2585, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_2587 lang.IFn; if linked_2586 == nil { ifn_2587 = lang.IFn_Cast(root_2585) } else { ifn_2587 = nil }; var arg_2588 any = A_arbace_build_go_A_const_174; var arg_2589 any = A_arbace_build_go_A_const_141; if linked_2586 == nil { tmp7 = ifn_2587.Invoke_O_O__O(arg_2588, arg_2589) } else { tmp7 = linked_2586.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_2585, arg_2588, arg_2589) }; work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(tmp6, jrt.RefArray_Cast(tmp7, jrt.FileAttribute_class)).ToFile__File().Ref() }; var tmp8 any; tmp23 := /*line :540:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_25)












				if jrt.NN(jrt.File_Cast(mod__17)).Exists__Z() { var root_2644 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2645 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2644, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2646 lang.IFn; if linked_2645 == nil { ifn_2646 = lang.IFn_Cast(root_2644) } else { ifn_2646 = nil }; var arg_2647 any = mod__17; if linked_2645 == nil { ifn_2646.Invoke_O__O(arg_2647) } else { linked_2645.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2644, arg_2647) } }
				var root_2648 any = A_arbace_build_go_A_const_181.GetRawRoot__O(); var linked_2649 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2648, A_arbace_build_go_print_module_A_fn_class); var ifn_2650 lang.IFn; if linked_2649 == nil { ifn_2650 = lang.IFn_Cast(root_2648) } else { ifn_2650 = nil }; var arg_2651 any = prog__10; var arg_2652 any = dir__0; var arg_2653 any = mod__17; var arg_2654 any = opts__7; if linked_2649 == nil { ifn_2650.Invoke_O_O_O_O__O(arg_2651, arg_2652, arg_2653, arg_2654) } else { linked_2649.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2648, arg_2651, arg_2652, arg_2653, arg_2654) }
//line :540:1
				var tags__18 any = A_arbace_build_go_A_const_175.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_151.Invoke_O__O(opts__7), Lit_29); var cmd__20 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_30), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_31, Lit_32, Lit_33); var tmp11 lang.IPersistentVector; var tmp12 any; var root_2600 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2601 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2600, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2602 lang.IFn

















				if linked_2601 == nil { ifn_2602 = lang.IFn_Cast(root_2600) } else { ifn_2602 = nil }; var arg_2603 any = tags__18; if linked_2601 == nil { tmp12 = ifn_2602.Invoke_O__O(arg_2603) } else { tmp12 = linked_2601.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2600, arg_2603) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_2604 any = A_arbace_build_go_A_const_50.GetRawRoot__O(); var linked_2605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2604, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2606 lang.IFn; if linked_2605 == nil { ifn_2606 = lang.IFn_Cast(root_2604) } else { ifn_2606 = nil }; var arg_2607 any = Lit_35; var arg_2608 any = tags__18; if linked_2605 == nil { tmp13 = ifn_2606.Invoke_O_O__O(arg_2607, arg_2608) } else { tmp13 = linked_2605.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2604, arg_2607, arg_2608) }; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_34, tmp13) } else { tmp11 = nil }
//line :557:1
				var tmp14 any = tmp11; var tmp15 lang.IPersistentVector

				if tamago_QMARK___19 { tmp15 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, A_arbace_build_go_A_const_176.GetRawRoot__O()) } else { tmp15 = nil }
//line :557:1
				var tmp16 any = tmp15; var tmp17 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_build_go_A_const_177.Invoke_O__O(opts__7)


				if jrt.J2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; var tmp18 any; var root_2609 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2610 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2609, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2611 lang.IFn
					if linked_2610 == nil { ifn_2611 = lang.IFn_Cast(root_2609) } else { ifn_2611 = nil }; var arg_2612 any = o__21; if linked_2610 == nil { tmp18 = ifn_2611.Invoke_O__O(arg_2612) } else { tmp18 = linked_2610.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2609, arg_2612) }
//line :560:1
					tmp17 = lang.Tuple_Create_O_O__IPersistentVector(Lit_37, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp18)).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp17 = nil }
//line :557:1
				var tmp19 any = tmp17; var tmp20 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_build_go_A_const_178.Invoke_O__O(opts__7)




				if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; var tmp21 any; var root_2613 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2614 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2613, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2615 lang.IFn
					if linked_2614 == nil { ifn_2615 = lang.IFn_Cast(root_2613) } else { ifn_2615 = nil }; var arg_2616 any = f__21; if linked_2614 == nil { tmp21 = ifn_2615.Invoke_O__O(arg_2616) } else { tmp21 = linked_2614.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2613, arg_2616) }
//line :562:1
					tmp20 = lang.Tuple_Create_O_O__IPersistentVector(Lit_38, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp21)).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp20 = nil }
//line :557:1
				cmd__20 = tmp9.Invoke_O_O_O_O_O_O_O__O(tmp10, tmp14, tmp16, tmp19, tmp20, A_arbace_build_go_A_const_179.Invoke_O__O(opts__7), lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.NN(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File()).GetPath__String().Ref(), A_arbace_build_go_A_const_48.Invoke_O__O(main__11)))
//line :540:1
				var env__21 any; var G__1901000409__21_ any; var root_2617 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_2618 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2617, A_arbace_build_go_go_env_A_fn_class); var ifn_2619 lang.IFn

























				if linked_2618 == nil { ifn_2619 = lang.IFn_Cast(root_2617) } else { ifn_2619 = nil }; var arg_2620 any = goroot__9; var arg_2621 any = arch__1; var arg_2622 any; var or__1927000174__auto____21 any = A_arbace_build_go_A_const_151.Invoke_O__O(opts__7); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_2622 = or__1927000174__auto____21 } else { arg_2622 = Lit_39 }; if linked_2618 == nil { G__1901000409__21_ = ifn_2619.Invoke_O_O_O__O(arg_2620, arg_2621, arg_2622) } else { G__1901000409__21_ = linked_2618.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_2617, arg_2620, arg_2621, arg_2622) }; var tmp22 any; var root_2623 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2624 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2623, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2625 lang.IFn
				if linked_2624 == nil { ifn_2625 = lang.IFn_Cast(root_2623) } else { ifn_2625 = nil }; var arg_2626 any = A_arbace_build_go_A_const_180.Invoke_O__O(config__12); if linked_2624 == nil { tmp22 = ifn_2625.Invoke_O__O(arg_2626) } else { tmp22 = linked_2624.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2623, arg_2626) }
//line :566:1
				if jrt.J2g_Truth(tmp22) {
					var root_2627 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2628 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2627, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2629 lang.IFn; if linked_2628 == nil { ifn_2629 = lang.IFn_Cast(root_2627) } else { ifn_2629 = nil }; var arg_2630 any = G__1901000409__21_; var arg_2631 any = Lit_40; var arg_2632 any = A_arbace_build_go_A_const_180.Invoke_O__O(config__12); if linked_2628 == nil { env__21 = ifn_2629.Invoke_O_O_O__O(arg_2630, arg_2631, arg_2632) } else { env__21 = linked_2628.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2627, arg_2630, arg_2631, arg_2632) } } else {
//line :566:1
						env__21 = G__1901000409__21_ }
//line :540:1
				var vec__1901000406__22 any; var root_2633 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, A_arbace_build_go_run_A_fn_class); var ifn_2635 lang.IFn



























				if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = cmd__20; var arg_2637 any = mod__17; var arg_2638 any = env__21; var arg_2639 any = jrt.Boolean_TRUE.Ref(); if linked_2634 == nil { vec__1901000406__22 = ifn_2635.Invoke_O_O_O_O__O(arg_2636, arg_2637, arg_2638, arg_2639) } else { vec__1901000406__22 = linked_2634.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_2633, arg_2636, arg_2637, arg_2638, arg_2639) }
//line :540:1
				var status__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000406__22, lang.RT_IntCast_J__I_NoInit(0), nil); tmp8 = status__23 }; return nil }(); if tmp_QMARK___13 {






























					var root_2640 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2641 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2640, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2642 lang.IFn; if linked_2641 == nil { ifn_2642 = lang.IFn_Cast(root_2640) } else { ifn_2642 = nil }; var arg_2643 any = work__14; if linked_2641 == nil { ifn_2642.Invoke_O__O(arg_2643) } else { linked_2641.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2640, arg_2643) } }; if /*line :540:1*/ tmp23 != nil { panic(tmp23) }; return tmp8 }
































func A_arbace_build_go__main_A_New() *A_arbace_build_go__main_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_A{}; t.Ctor(); return t }
//line :573:1
func (t *A_arbace_build_go__main_A) Ctor() {}
//line :573:1
func (t *A_arbace_build_go__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :573:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_182, Lit_5, A_arbace_build_go_A_const_152, goroot__2)); L1: for { var G__1901000411__6_ any; var root_2655 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2656 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2655, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2657 lang.IFn




		if linked_2656 == nil { ifn_2657 = lang.IFn_Cast(root_2655) } else { ifn_2657 = nil }; var arg_2658 any = as__4; if linked_2656 == nil { G__1901000411__6_ = ifn_2657.Invoke_O__O(arg_2658) } else { G__1901000411__6_ = linked_2656.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2655, arg_2658) }; switch lang.Util_Hash_O__I_NoInit(G__1901000411__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_6) {












			var tmp1 any; var root_2729 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; var arg_2732 any = as__4; if linked_2730 == nil { tmp1 = ifn_2731.Invoke_O__O(arg_2732) } else { tmp1 = linked_2730.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2729, arg_2732) }; var tmp2 any = tmp1; var tmp3 any; var root_2733 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2733, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2735 lang.IFn; if linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var arg_2736 any = opts__5; var arg_2737 any = A_arbace_build_go_A_const_124; var arg_2738 any; var root_2739 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2740 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2739, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2741 lang.IFn; if linked_2740 == nil { ifn_2741 = lang.IFn_Cast(root_2739) } else { ifn_2741 = nil }; var arg_2742 any = as__4; if linked_2740 == nil { arg_2738 = ifn_2741.Invoke_O__O(arg_2742) } else { arg_2738 = linked_2740.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2739, arg_2742) }; if linked_2734 == nil { tmp3 = ifn_2735.Invoke_O_O_O__O(arg_2736, arg_2737, arg_2738) } else { tmp3 = linked_2734.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2733, arg_2736, arg_2737, arg_2738) }; as__4, opts__5 = tmp2, tmp3; continue L1 }
//line :578:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_7) {










			var tmp4 any; var root_2743 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2744 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2743, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2745 lang.IFn; if linked_2744 == nil { ifn_2745 = lang.IFn_Cast(root_2743) } else { ifn_2745 = nil }; var arg_2746 any = as__4; if linked_2744 == nil { tmp4 = ifn_2745.Invoke_O__O(arg_2746) } else { tmp4 = linked_2744.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2743, arg_2746) }; var tmp5 any = tmp4; var tmp6 any; var root_2747 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2748 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2747, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2749 lang.IFn; if linked_2748 == nil { ifn_2749 = lang.IFn_Cast(root_2747) } else { ifn_2749 = nil }; var arg_2750 any = opts__5; var arg_2751 any = A_arbace_build_go_A_const_183; var arg_2752 any = jrt.Boolean_TRUE.Ref(); if linked_2748 == nil { tmp6 = ifn_2749.Invoke_O_O_O__O(arg_2750, arg_2751, arg_2752) } else { tmp6 = linked_2748.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2747, arg_2750, arg_2751, arg_2752) }; as__4, opts__5 = tmp5, tmp6; continue L1 }
//line :578:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_8) {











			var tmp7 any; var root_2753 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2753, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2755 lang.IFn; if linked_2754 == nil { ifn_2755 = lang.IFn_Cast(root_2753) } else { ifn_2755 = nil }; var arg_2756 any = as__4; if linked_2754 == nil { tmp7 = ifn_2755.Invoke_O__O(arg_2756) } else { tmp7 = linked_2754.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2753, arg_2756) }; var tmp8 any = tmp7; var tmp9 any; var root_2757 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2758 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2757, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2759 lang.IFn; if linked_2758 == nil { ifn_2759 = lang.IFn_Cast(root_2757) } else { ifn_2759 = nil }; var arg_2760 any = opts__5; var arg_2761 any = A_arbace_build_go_A_const_150; var arg_2762 any = jrt.Boolean_TRUE.Ref(); if linked_2758 == nil { tmp9 = ifn_2759.Invoke_O_O_O__O(arg_2760, arg_2761, arg_2762) } else { tmp9 = linked_2758.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2757, arg_2760, arg_2761, arg_2762) }; as__4, opts__5 = tmp8, tmp9; continue L1 }
//line :578:1
		case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_9) {






			var tmp10 any; var root_2763 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2763, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2765 lang.IFn; if linked_2764 == nil { ifn_2765 = lang.IFn_Cast(root_2763) } else { ifn_2765 = nil }; var arg_2766 any = as__4; if linked_2764 == nil { tmp10 = ifn_2765.Invoke_O__O(arg_2766) } else { tmp10 = linked_2764.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2763, arg_2766) }; var tmp11 any = tmp10; var tmp12 any; var root_2767 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2768 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2767, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2769 lang.IFn; if linked_2768 == nil { ifn_2769 = lang.IFn_Cast(root_2767) } else { ifn_2769 = nil }; var arg_2770 any = opts__5; var arg_2771 any = A_arbace_build_go_A_const_171; var arg_2772 any; var root_2773 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2774 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2773, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2775 lang.IFn; if linked_2774 == nil { ifn_2775 = lang.IFn_Cast(root_2773) } else { ifn_2775 = nil }; var arg_2776 any = as__4; if linked_2774 == nil { arg_2772 = ifn_2775.Invoke_O__O(arg_2776) } else { arg_2772 = linked_2774.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2773, arg_2776) }; if linked_2768 == nil { tmp12 = ifn_2769.Invoke_O_O_O__O(arg_2770, arg_2771, arg_2772) } else { tmp12 = linked_2768.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2767, arg_2770, arg_2771, arg_2772) }; as__4, opts__5 = tmp11, tmp12; continue L1 }
//line :578:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_10) {




			var tmp13 any; var root_2777 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2778 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2777, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2779 lang.IFn; if linked_2778 == nil { ifn_2779 = lang.IFn_Cast(root_2777) } else { ifn_2779 = nil }; var arg_2780 any = as__4; if linked_2778 == nil { tmp13 = ifn_2779.Invoke_O__O(arg_2780) } else { tmp13 = linked_2778.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2777, arg_2780) }; var tmp14 any = tmp13; var tmp15 any; var root_2781 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2782 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2781, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2783 lang.IFn; if linked_2782 == nil { ifn_2783 = lang.IFn_Cast(root_2781) } else { ifn_2783 = nil }; var arg_2784 any = opts__5; var arg_2785 any = A_arbace_build_go_A_const_145; var arg_2786 any; var root_2787 any = A_arbace_build_go_A_const_196.GetRawRoot__O(); var linked_2788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2787, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2789 lang.IFn; if linked_2788 == nil { ifn_2789 = lang.IFn_Cast(root_2787) } else { ifn_2789 = nil }; var arg_2790 any; var root_2791 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2791, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2793 lang.IFn; if linked_2792 == nil { ifn_2793 = lang.IFn_Cast(root_2791) } else { ifn_2793 = nil }; var arg_2794 any = as__4; if linked_2792 == nil { arg_2790 = ifn_2793.Invoke_O__O(arg_2794) } else { arg_2790 = linked_2792.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2791, arg_2794) }; if linked_2788 == nil { arg_2786 = ifn_2789.Invoke_O__O(arg_2790) } else { arg_2786 = linked_2788.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2787, arg_2790) }; if linked_2782 == nil { tmp15 = ifn_2783.Invoke_O_O_O__O(arg_2784, arg_2785, arg_2786) } else { tmp15 = linked_2782.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2781, arg_2784, arg_2785, arg_2786) }; as__4, opts__5 = tmp14, tmp15; continue L1 }
//line :578:1
		case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_11) {














			var tmp16 any; var root_2795 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2796 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2795, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2797 lang.IFn; if linked_2796 == nil { ifn_2797 = lang.IFn_Cast(root_2795) } else { ifn_2797 = nil }; var arg_2798 any = as__4; if linked_2796 == nil { tmp16 = ifn_2797.Invoke_O__O(arg_2798) } else { tmp16 = linked_2796.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2795, arg_2798) }; var tmp17 any = tmp16; var tmp18 any; var root_2799 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2800 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2799, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2801 lang.IFn; if linked_2800 == nil { ifn_2801 = lang.IFn_Cast(root_2799) } else { ifn_2801 = nil }; var arg_2802 any = opts__5; var arg_2803 any = A_arbace_build_go_A_const_153; var arg_2804 any; var root_2805 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2806 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2805, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2807 lang.IFn; if linked_2806 == nil { ifn_2807 = lang.IFn_Cast(root_2805) } else { ifn_2807 = nil }; var arg_2808 any = as__4; if linked_2806 == nil { arg_2804 = ifn_2807.Invoke_O__O(arg_2808) } else { arg_2804 = linked_2806.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2805, arg_2808) }; if linked_2800 == nil { tmp18 = ifn_2801.Invoke_O_O_O__O(arg_2802, arg_2803, arg_2804) } else { tmp18 = linked_2800.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2799, arg_2802, arg_2803, arg_2804) }; as__4, opts__5 = tmp17, tmp18; continue L1 }
//line :578:1
		case 30: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_12) {



			var tmp19 any; var root_2809 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2810 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2809, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2811 lang.IFn; if linked_2810 == nil { ifn_2811 = lang.IFn_Cast(root_2809) } else { ifn_2811 = nil }; var arg_2812 any = as__4; if linked_2810 == nil { tmp19 = ifn_2811.Invoke_O__O(arg_2812) } else { tmp19 = linked_2810.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2809, arg_2812) }; var tmp20 any = tmp19; var tmp21 any; var root_2813 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2814 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2813, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2815 lang.IFn; if linked_2814 == nil { ifn_2815 = lang.IFn_Cast(root_2813) } else { ifn_2815 = nil }; var arg_2816 any = opts__5; var arg_2817 any = A_arbace_build_go_A_const_184; var arg_2818 any; var root_2819 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2819, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2821 lang.IFn; if linked_2820 == nil { ifn_2821 = lang.IFn_Cast(root_2819) } else { ifn_2821 = nil }; var arg_2822 any = as__4; if linked_2820 == nil { arg_2818 = ifn_2821.Invoke_O__O(arg_2822) } else { arg_2818 = linked_2820.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2819, arg_2822) }; if linked_2814 == nil { tmp21 = ifn_2815.Invoke_O_O_O__O(arg_2816, arg_2817, arg_2818) } else { tmp21 = linked_2814.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2813, arg_2816, arg_2817, arg_2818) }; as__4, opts__5 = tmp20, tmp21; continue L1 }
//line :578:1
		case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_13) {
			var tmp22 any; var root_2823 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2823, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2825 lang.IFn; if linked_2824 == nil { ifn_2825 = lang.IFn_Cast(root_2823) } else { ifn_2825 = nil }; var arg_2826 any = as__4; if linked_2824 == nil { tmp22 = ifn_2825.Invoke_O__O(arg_2826) } else { tmp22 = linked_2824.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2823, arg_2826) }; var tmp23 any = tmp22; var tmp24 any; var root_2827 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2828 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2827, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2829 lang.IFn; if linked_2828 == nil { ifn_2829 = lang.IFn_Cast(root_2827) } else { ifn_2829 = nil }; var arg_2830 any = opts__5; var arg_2831 any = A_arbace_build_go_A_const_182; var arg_2832 any; var root_2833 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2834 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2833, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2835 lang.IFn; if linked_2834 == nil { ifn_2835 = lang.IFn_Cast(root_2833) } else { ifn_2835 = nil }; var arg_2836 any = as__4; if linked_2834 == nil { arg_2832 = ifn_2835.Invoke_O__O(arg_2836) } else { arg_2832 = linked_2834.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2833, arg_2836) }; if linked_2828 == nil { tmp24 = ifn_2829.Invoke_O_O_O__O(arg_2830, arg_2831, arg_2832) } else { tmp24 = linked_2828.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2827, arg_2830, arg_2831, arg_2832) }; as__4, opts__5 = tmp23, tmp24; continue L1 }
//line :578:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_14) {





			var tmp25 any; var root_2837 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_2838 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2837, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2839 lang.IFn; if linked_2838 == nil { ifn_2839 = lang.IFn_Cast(root_2837) } else { ifn_2839 = nil }; var arg_2840 any = as__4; if linked_2838 == nil { tmp25 = ifn_2839.Invoke_O__O(arg_2840) } else { tmp25 = linked_2838.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2837, arg_2840) }; var tmp26 any = tmp25; var tmp27 any; var root_2841 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2842 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2841, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2843 lang.IFn; if linked_2842 == nil { ifn_2843 = lang.IFn_Cast(root_2841) } else { ifn_2843 = nil }; var arg_2844 any = opts__5; var arg_2845 any = A_arbace_build_go_A_const_146; var arg_2846 any = jrt.Boolean_TRUE.Ref(); if linked_2842 == nil { tmp27 = ifn_2843.Invoke_O_O_O__O(arg_2844, arg_2845, arg_2846) } else { tmp27 = linked_2842.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2841, arg_2844, arg_2845, arg_2846) }; as__4, opts__5 = tmp26, tmp27; continue L1 }
//line :578:1
		case 38: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_15) {

			var tmp28 any; var root_2847 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2848 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2847, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2849 lang.IFn; if linked_2848 == nil { ifn_2849 = lang.IFn_Cast(root_2847) } else { ifn_2849 = nil }; var arg_2850 any = as__4; if linked_2848 == nil { tmp28 = ifn_2849.Invoke_O__O(arg_2850) } else { tmp28 = linked_2848.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2847, arg_2850) }; var tmp29 any = tmp28; var tmp30 any; var root_2851 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2852 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2851, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2853 lang.IFn; if linked_2852 == nil { ifn_2853 = lang.IFn_Cast(root_2851) } else { ifn_2853 = nil }; var arg_2854 any = opts__5; var arg_2855 any = A_arbace_build_go_A_const_151; var arg_2856 any; var root_2857 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2858 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2857, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2859 lang.IFn; if linked_2858 == nil { ifn_2859 = lang.IFn_Cast(root_2857) } else { ifn_2859 = nil }; var arg_2860 any = as__4; if linked_2858 == nil { arg_2856 = ifn_2859.Invoke_O__O(arg_2860) } else { arg_2856 = linked_2858.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2857, arg_2860) }; if linked_2852 == nil { tmp30 = ifn_2853.Invoke_O_O_O__O(arg_2854, arg_2855, arg_2856) } else { tmp30 = linked_2852.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2851, arg_2854, arg_2855, arg_2856) }; as__4, opts__5 = tmp29, tmp30; continue L1 }
//line :578:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_16) {


			var tmp31 any; var root_2861 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2861, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2863 lang.IFn; if linked_2862 == nil { ifn_2863 = lang.IFn_Cast(root_2861) } else { ifn_2863 = nil }; var arg_2864 any = as__4; if linked_2862 == nil { tmp31 = ifn_2863.Invoke_O__O(arg_2864) } else { tmp31 = linked_2862.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2861, arg_2864) }; var tmp32 any = tmp31; var tmp33 any; var root_2865 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_2866 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2865, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2867 lang.IFn; if linked_2866 == nil { ifn_2867 = lang.IFn_Cast(root_2865) } else { ifn_2867 = nil }; var arg_2868 any = opts__5; var arg_2869 any = A_arbace_build_go_A_const_121; var arg_2870 any; var root_2872 any = A_arbace_build_go_A_const_197.GetRawRoot__O(); var linked_2873 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2872, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_2874 lang.IFn; if linked_2873 == nil { ifn_2874 = lang.IFn_Cast(root_2872) } else { ifn_2874 = nil }; var arg_2875 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_2876 any = lang.PersistentVector_EMPTY.Ref(); if linked_2873 == nil { arg_2870 = ifn_2874.Invoke_O_O__O(arg_2875, arg_2876) } else { arg_2870 = linked_2873.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_2872, arg_2875, arg_2876) }; var arg_2871 any; var root_2877 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2878 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2877, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2879 lang.IFn; if linked_2878 == nil { ifn_2879 = lang.IFn_Cast(root_2877) } else { ifn_2879 = nil }; var arg_2880 any = as__4; if linked_2878 == nil { arg_2871 = ifn_2879.Invoke_O__O(arg_2880) } else { arg_2871 = linked_2878.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2877, arg_2880) }; if linked_2866 == nil { tmp33 = ifn_2867.Invoke_O_O_O_O__O(arg_2868, arg_2869, arg_2870, arg_2871) } else { tmp33 = linked_2866.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2865, arg_2868, arg_2869, arg_2870, arg_2871) }; as__4, opts__5 = tmp32, tmp33; continue L1 }
//line :578:1
		case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_17) {







			var tmp34 any; var root_2881 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2882 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2881, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2883 lang.IFn; if linked_2882 == nil { ifn_2883 = lang.IFn_Cast(root_2881) } else { ifn_2883 = nil }; var arg_2884 any = as__4; if linked_2882 == nil { tmp34 = ifn_2883.Invoke_O__O(arg_2884) } else { tmp34 = linked_2882.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2881, arg_2884) }; var tmp35 any = tmp34; var tmp36 any; var root_2885 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2886 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2885, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2887 lang.IFn; if linked_2886 == nil { ifn_2887 = lang.IFn_Cast(root_2885) } else { ifn_2887 = nil }; var arg_2888 any = opts__5; var arg_2889 any = A_arbace_build_go_A_const_177; var arg_2890 any; var root_2891 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2892 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2891, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2893 lang.IFn; if linked_2892 == nil { ifn_2893 = lang.IFn_Cast(root_2891) } else { ifn_2893 = nil }; var arg_2894 any = as__4; if linked_2892 == nil { arg_2890 = ifn_2893.Invoke_O__O(arg_2894) } else { arg_2890 = linked_2892.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2891, arg_2894) }; if linked_2886 == nil { tmp36 = ifn_2887.Invoke_O_O_O__O(arg_2888, arg_2889, arg_2890) } else { tmp36 = linked_2886.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2885, arg_2888, arg_2889, arg_2890) }; as__4, opts__5 = tmp35, tmp36; continue L1 }
//line :578:1
		case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_18) {















			var tmp37 any; var root_2895 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2896 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2895, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2897 lang.IFn; if linked_2896 == nil { ifn_2897 = lang.IFn_Cast(root_2895) } else { ifn_2897 = nil }; var arg_2898 any = as__4; if linked_2896 == nil { tmp37 = ifn_2897.Invoke_O__O(arg_2898) } else { tmp37 = linked_2896.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2895, arg_2898) }; var tmp38 any = tmp37; var tmp39 any; var root_2899 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2900 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2899, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2901 lang.IFn; if linked_2900 == nil { ifn_2901 = lang.IFn_Cast(root_2899) } else { ifn_2901 = nil }; var arg_2902 any = opts__5; var arg_2903 any = A_arbace_build_go_A_const_122; var arg_2904 any; var root_2905 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2906 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2905, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2907 lang.IFn; if linked_2906 == nil { ifn_2907 = lang.IFn_Cast(root_2905) } else { ifn_2907 = nil }; var arg_2908 any = as__4; if linked_2906 == nil { arg_2904 = ifn_2907.Invoke_O__O(arg_2908) } else { arg_2904 = linked_2906.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2905, arg_2908) }; if linked_2900 == nil { tmp39 = ifn_2901.Invoke_O_O_O__O(arg_2902, arg_2903, arg_2904) } else { tmp39 = linked_2900.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2899, arg_2902, arg_2903, arg_2904) }; as__4, opts__5 = tmp38, tmp39; continue L1 }
//line :578:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_19) {













			var tmp40 any; var root_2909 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2909, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2911 lang.IFn; if linked_2910 == nil { ifn_2911 = lang.IFn_Cast(root_2909) } else { ifn_2911 = nil }; var arg_2912 any = as__4; if linked_2910 == nil { tmp40 = ifn_2911.Invoke_O__O(arg_2912) } else { tmp40 = linked_2910.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2909, arg_2912) }; var tmp41 any = tmp40; var tmp42 any; var root_2913 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2913, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2915 lang.IFn; if linked_2914 == nil { ifn_2915 = lang.IFn_Cast(root_2913) } else { ifn_2915 = nil }; var arg_2916 any = opts__5; var arg_2917 any = A_arbace_build_go_A_const_123; var arg_2918 any; var root_2919 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2920 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2919, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2921 lang.IFn; if linked_2920 == nil { ifn_2921 = lang.IFn_Cast(root_2919) } else { ifn_2921 = nil }; var arg_2922 any = as__4; if linked_2920 == nil { arg_2918 = ifn_2921.Invoke_O__O(arg_2922) } else { arg_2918 = linked_2920.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2919, arg_2922) }; if linked_2914 == nil { tmp42 = ifn_2915.Invoke_O_O_O__O(arg_2916, arg_2917, arg_2918) } else { tmp42 = linked_2914.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2913, arg_2916, arg_2917, arg_2918) }; as__4, opts__5 = tmp41, tmp42; continue L1 }
//line :578:1
		case 57: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_20) {









			var tmp43 any; var root_2923 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2924 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2923, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2925 lang.IFn; if linked_2924 == nil { ifn_2925 = lang.IFn_Cast(root_2923) } else { ifn_2925 = nil }; var arg_2926 any = as__4; if linked_2924 == nil { tmp43 = ifn_2925.Invoke_O__O(arg_2926) } else { tmp43 = linked_2924.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2923, arg_2926) }; var tmp44 any = tmp43; var tmp45 any; var root_2927 any = A_arbace_build_go_A_const_78.GetRawRoot__O(); var linked_2928 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2927, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2929 lang.IFn; if linked_2928 == nil { ifn_2929 = lang.IFn_Cast(root_2927) } else { ifn_2929 = nil }; var arg_2930 any = opts__5; var arg_2931 any = A_arbace_build_go_A_const_179; var arg_2932 any; var root_2934 any = A_arbace_build_go_A_const_197.GetRawRoot__O(); var linked_2935 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2934, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_2936 lang.IFn; if linked_2935 == nil { ifn_2936 = lang.IFn_Cast(root_2934) } else { ifn_2936 = nil }; var arg_2937 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_2938 any = lang.PersistentVector_EMPTY.Ref(); if linked_2935 == nil { arg_2932 = ifn_2936.Invoke_O_O__O(arg_2937, arg_2938) } else { arg_2932 = linked_2935.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_2934, arg_2937, arg_2938) }; var arg_2933 any; var root_2939 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2940 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2939, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2941 lang.IFn; if linked_2940 == nil { ifn_2941 = lang.IFn_Cast(root_2939) } else { ifn_2941 = nil }; var arg_2942 any = as__4; if linked_2940 == nil { arg_2933 = ifn_2941.Invoke_O__O(arg_2942) } else { arg_2933 = linked_2940.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2939, arg_2942) }; if linked_2928 == nil { tmp45 = ifn_2929.Invoke_O_O_O_O__O(arg_2930, arg_2931, arg_2932, arg_2933) } else { tmp45 = linked_2928.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2927, arg_2930, arg_2931, arg_2932, arg_2933) }; as__4, opts__5 = tmp44, tmp45; continue L1 }
//line :578:1
		case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000411__6_, Lit_21) {








			var tmp46 any; var root_2943 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2943, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2945 lang.IFn; if linked_2944 == nil { ifn_2945 = lang.IFn_Cast(root_2943) } else { ifn_2945 = nil }; var arg_2946 any = as__4; if linked_2944 == nil { tmp46 = ifn_2945.Invoke_O__O(arg_2946) } else { tmp46 = linked_2944.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2943, arg_2946) }; var tmp47 any = tmp46; var tmp48 any; var root_2947 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_2948 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2947, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2949 lang.IFn; if linked_2948 == nil { ifn_2949 = lang.IFn_Cast(root_2947) } else { ifn_2949 = nil }; var arg_2950 any = opts__5; var arg_2951 any = A_arbace_build_go_A_const_178; var arg_2952 any; var root_2953 any = A_arbace_build_go_A_const_195.GetRawRoot__O(); var linked_2954 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2953, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2955 lang.IFn; if linked_2954 == nil { ifn_2955 = lang.IFn_Cast(root_2953) } else { ifn_2955 = nil }; var arg_2956 any = as__4; if linked_2954 == nil { arg_2952 = ifn_2955.Invoke_O__O(arg_2956) } else { arg_2952 = linked_2954.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2953, arg_2956) }; if linked_2948 == nil { tmp48 = ifn_2949.Invoke_O_O_O__O(arg_2950, arg_2951, arg_2952) } else { tmp48 = linked_2948.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2947, arg_2950, arg_2951, arg_2952) }; as__4, opts__5 = tmp47, tmp48; continue L1 }
//line :578:1
		default:
		}
















		var tmp49 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_2957 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2958 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2957, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2959 lang.IFn; if linked_2958 == nil { ifn_2959 = lang.IFn_Cast(root_2957) } else { ifn_2959 = nil }; var arg_2960 any; var root_2961 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_2962 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2961, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2963 lang.IFn; if linked_2962 == nil { ifn_2963 = lang.IFn_Cast(root_2961) } else { ifn_2963 = nil }; var arg_2964 any; var root_2966 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2967 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2966, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2968 lang.IFn; if linked_2967 == nil { ifn_2968 = lang.IFn_Cast(root_2966) } else { ifn_2968 = nil }; var arg_2969 any = as__4; if linked_2967 == nil { arg_2964 = ifn_2968.Invoke_O__O(arg_2969) } else { arg_2964 = linked_2967.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2966, arg_2969) }; var arg_2965 any = Lit_22; if linked_2962 == nil { arg_2960 = ifn_2963.Invoke_O_O__O(arg_2964, arg_2965) } else { arg_2960 = linked_2962.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2961, arg_2964, arg_2965) }; if linked_2958 == nil { and__1927000168__auto____8 = ifn_2959.Invoke_O__O(arg_2960) } else { and__1927000168__auto____8 = linked_2958.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2957, arg_2960) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp50 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_198); var and__1927000168__auto____9 any = tmp50.Invoke_O__O(A_arbace_build_go_A_const_182.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_2970 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_2971 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2970, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2972 lang.IFn

			if linked_2971 == nil { ifn_2972 = lang.IFn_Cast(root_2970) } else { ifn_2972 = nil }; var arg_2973 any = A_arbace_build_go_A_const_199; var arg_2974 any = A_arbace_build_go_A_const_151.Invoke_O__O(opts__5); if linked_2971 == nil { and__1927000168__auto____10 = ifn_2972.Invoke_O_O__O(arg_2973, arg_2974) } else { and__1927000168__auto____10 = linked_2971.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2970, arg_2973, arg_2974) }
//line :596:1
			if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_2975 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_2976 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2975, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2977 lang.IFn


				if linked_2976 == nil { ifn_2977 = lang.IFn_Cast(root_2975) } else { ifn_2977 = nil }; var arg_2978 any = A_arbace_build_go_A_const_200; var arg_2979 any = A_arbace_build_go_A_const_145.Invoke_O__O(opts__5); if linked_2976 == nil { and__1927000168__auto____11 = ifn_2977.Invoke_O_O__O(arg_2978, arg_2979) } else { and__1927000168__auto____11 = linked_2976.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2975, arg_2978, arg_2979) }
//line :596:1
				if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_2980 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2980, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2982 lang.IFn



					if linked_2981 == nil { ifn_2982 = lang.IFn_Cast(root_2980) } else { ifn_2982 = nil }; var arg_2983 any = A_arbace_build_go_A_const_183.Invoke_O__O(opts__5); if linked_2981 == nil { or__1927000174__auto____12 = ifn_2982.Invoke_O__O(arg_2983) } else { or__1927000174__auto____12 = linked_2981.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2980, arg_2983) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp49 = or__1927000174__auto____12 } else { tmp49 = A_arbace_build_go_A_const_171.Invoke_O__O(opts__5) } } else {
//line :596:1
						tmp49 = and__1927000168__auto____11 } } else { tmp49 = and__1927000168__auto____10 } } else { tmp49 = and__1927000168__auto____9 } } else { tmp49 = and__1927000168__auto____8 } } else { tmp49 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp49) { } else {




							var root_2992 any = A_arbace_build_go_A_const_72.GetRawRoot__O(); var linked_2993 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2992, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2994 lang.IFn; if linked_2993 == nil { ifn_2994 = lang.IFn_Cast(root_2992) } else { ifn_2994 = nil }; var tmp51 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_73.GetRawRoot__O()); var tmp52 any = A_arbace_build_go_A_const_192; var arg_2995 any = tmp51.Invoke_O_O__O(tmp52, A_arbace_build_go_A_const_193.Get__O()); if linked_2993 == nil { ifn_2994.Invoke_O__O(arg_2995) } else { linked_2993.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2992, arg_2995) }; var tmp53 any = A_arbace_build_go__main_fn__1901000412_A_New_O(usage__3); var tmp54 *jrt.Class; var fncls__2991 *jrt.Class = A_arbace_build_go__main_fn__1901000412_A_fn_class; if fncls__2991 == nil { var fncls__2991d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_build_go__main_fn__1901000412_A_fn_class = fncls__2991d; tmp54 = fncls__2991d } else { tmp54 = fncls__2991 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O()
							jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :578:1
		var dir__7 any; var tmp55 any; var root_2660 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2662 lang.IFn
























		if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any = as__4; if linked_2661 == nil { tmp55 = ifn_2662.Invoke_O__O(arg_2663) } else { tmp55 = linked_2661.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2660, arg_2663) }
//line :578:1
		dir__7 = jrt.File_New_String(jrt.String_Cast(tmp55)); var status__8 any; var tmp56 any = A_arbace_build_go__main_fn__1901000414_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp57 *jrt.Class
		var fncls__2728 /*line :578:1*/*jrt.Class = A_arbace_build_go__main_fn__1901000414_A_fn_class

























		if fncls__2728 == nil { var fncls__2728d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_24, false); A_arbace_build_go__main_fn__1901000414_A_fn_class = fncls__2728d; tmp57 = fncls__2728d } else { tmp57 = fncls__2728 }; status__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp56, tmp57, nil).Invoke__O()















		var root_3001 any = A_arbace_build_go_A_const_201.GetRawRoot__O(); var linked_3002 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_3001, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_3003 lang.IFn; if linked_3002 == nil { ifn_3003 = lang.IFn_Cast(root_3001) } else { ifn_3003 = nil }; if linked_3002 == nil { ifn_3003.Invoke__O() } else { linked_3002.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_3001) }
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__8)); return nil } }; /*line :573:1*/panic("j2g: unreachable") }



























func A_arbace_build_go__main_fn__1901000412_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000412_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000412_A{}; t.Ctor_O(p0); return t }
//line :601:1
func (t *A_arbace_build_go__main_fn__1901000412_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :601:1
func (t *A_arbace_build_go__main_fn__1901000412_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_2988 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2989 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2988, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2990 lang.IFn; if linked_2989 == nil { ifn_2990 = lang.IFn_Cast(root_2988) } else { ifn_2990 = nil }; if linked_2989 == nil { ifn_2990.Invoke__O() } else { linked_2989.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2988) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_build_go__main_fn__1901000414_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go__main_fn__1901000414_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000414_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :604:1
func (t *A_arbace_build_go__main_fn__1901000414_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :604:1
func (t *A_arbace_build_go__main_fn__1901000414_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.J2g_Truth(A_arbace_build_go_A_const_183.Invoke_O__O(t.F_opts)) { var prog__3 any; var root_2664 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_2665 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2664, A_arbace_build_go_program_A_fn_class); var ifn_2666 lang.IFn
											if linked_2665 == nil { ifn_2666 = lang.IFn_Cast(root_2664) } else { ifn_2666 = nil }; var arg_2667 any = t.F_dir; var arg_2668 any; var t_ any = t.F_goroot; t.F_goroot = nil; arg_2668 = t_; var tmp2 any = A_arbace_build_go_A_const_120; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any = A_arbace_build_go_A_const_124; var tmp5 any = A_arbace_build_go_A_const_124.Invoke_O__O(t.F_opts); var tmp6 any = A_arbace_build_go_A_const_121; var arg_2669 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, A_arbace_build_go_A_const_121.Invoke_O__O(t.F_opts))); if linked_2665 == nil { prog__3 = ifn_2666.Invoke_O_O_O__O(arg_2667, arg_2668, arg_2669) } else { prog__3 = linked_2665.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2664, arg_2667, arg_2668, arg_2669) }
//line :605:1
		var mod__4 any; var tmp7 any; var root_2670 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2672 lang.IFn

		if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = A_arbace_build_go_A_const_171.Invoke_O__O(t.F_opts); if linked_2671 == nil { tmp7 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp7 = linked_2671.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2670, arg_2673) }
//line :605:1
		mod__4 = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(tmp7)), Lit_25)


		if jrt.NN(jrt.File_Cast(mod__4)).Exists__Z() { var root_2696 any = A_arbace_build_go_A_const_148.GetRawRoot__O(); var linked_2697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2696, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2698 lang.IFn; if linked_2697 == nil { ifn_2698 = lang.IFn_Cast(root_2696) } else { ifn_2698 = nil }; var arg_2699 any = mod__4; if linked_2697 == nil { ifn_2698.Invoke_O__O(arg_2699) } else { linked_2697.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2696, arg_2699) } }
		var root_2700 any = A_arbace_build_go_A_const_181.GetRawRoot__O(); var linked_2701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2700, A_arbace_build_go_print_module_A_fn_class); var ifn_2702 lang.IFn; if linked_2701 == nil { ifn_2702 = lang.IFn_Cast(root_2700) } else { ifn_2702 = nil }; var arg_2703 any = prog__3; var arg_2704 any; var t__2 any = t.F_dir; t.F_dir = nil; arg_2704 = t__2; var arg_2705 any = mod__4; var arg_2706 any; var t__3 any = t.F_opts; t.F_opts = nil; arg_2706 = t__3; if linked_2701 == nil { ifn_2702.Invoke_O_O_O_O__O(arg_2703, arg_2704, arg_2705, arg_2706) } else { linked_2701.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2700, arg_2703, arg_2704, arg_2705, arg_2706) }
//line :605:1
		tmp1 = A_arbace_build_go_A_const_141 } else { var prog_main__3 any





			if jrt.J2g_Truth(A_arbace_build_go_A_const_184.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp8 *lang.Keyword = A_arbace_build_go_A_const_137; var tmp9 any; var root_2674 any = A_arbace_build_go_A_const_138.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2674, A_arbace_build_go_program_A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = t.F_dir; var arg_2678 any; var t__4 any = t.F_goroot; t.F_goroot = nil; arg_2678 = t__4; var arg_2679 any = t.F_opts; if linked_2675 == nil { tmp9 = ifn_2676.Invoke_O_O_O__O(arg_2677, arg_2678, arg_2679) } else { tmp9 = linked_2675.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2674, arg_2677, arg_2678, arg_2679) }; prog_main__3 = tmp8.Invoke_O__O(tmp9) }
//line :605:1
			var out__4 any; var tmp10 *jrt.Class = A_arbace_build_go_A_const_68; var tmp11 any; var or__1927000174__auto____4 any = A_arbace_build_go_A_const_184.Invoke_O__O(t.F_opts)






			if jrt.J2g_Truth(or__1927000174__auto____4) { tmp11 = or__1927000174__auto____4 } else {
				var root_2680 any = A_arbace_build_go_A_const_185.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any; var root_2684 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = A_arbace_build_go_A_const_48.Invoke_O__O(prog_main__3); var arg_2688 any = A_arbace_build_go_A_const_186; if linked_2685 == nil { arg_2683 = ifn_2686.Invoke_O_O__O(arg_2687, arg_2688) } else { arg_2683 = linked_2685.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2684, arg_2687, arg_2688) }; if linked_2681 == nil { tmp11 = ifn_2682.Invoke_O__O(arg_2683) } else { tmp11 = linked_2681.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_2680, arg_2683) } }
//line :605:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11))








			var root_2689 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2690 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2689, A_arbace_build_go_build_A_fn_class); var ifn_2691 lang.IFn; if linked_2690 == nil { ifn_2691 = lang.IFn_Cast(root_2689) } else { ifn_2691 = nil }; var arg_2692 any; var t__5 any = t.F_dir; t.F_dir = nil; arg_2692 = t__5; var arg_2693 any = A_arbace_build_go_A_const_182.Invoke_O__O(t.F_opts); var arg_2694 any = out__4; var arg_2695 any; var t__6 any = t.F_opts; t.F_opts = nil; arg_2695 = t__6; if linked_2690 == nil { tmp1 = ifn_2691.Invoke_O_O_O_O__O(arg_2692, arg_2693, arg_2694, arg_2695) } else { tmp1 = linked_2690.(*A_arbace_build_go_build_A).Invoke_O_O_O_O_O__O(root_2689, arg_2692, arg_2693, arg_2694, arg_2695) } }
//line :604:1
	return nil }(); if tmp12 != nil { if lang.ExceptionInfo_InstanceOf(tmp12) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp12); var tmp13 *lang.Keyword = A_arbace_build_go_A_const_188; var tmp14 any; var root_2707 any = A_arbace_build_go_A_const_189.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2709 lang.IFn











		if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = e__3; if linked_2708 == nil { tmp14 = ifn_2709.Invoke_O__O(arg_2710) } else { tmp14 = linked_2708.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2707, arg_2710) }; if jrt.J2g_Truth(tmp13.Invoke_O__O(tmp14)) {
			var root_2719 any = A_arbace_build_go_A_const_72.GetRawRoot__O(); var linked_2720 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2719, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2721 lang.IFn; if linked_2720 == nil { ifn_2721 = lang.IFn_Cast(root_2719) } else { ifn_2721 = nil }; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_73.GetRawRoot__O()); var tmp16 any = A_arbace_build_go_A_const_192; var arg_2722 any = tmp15.Invoke_O_O__O(tmp16, A_arbace_build_go_A_const_193.Get__O()); if linked_2720 == nil { ifn_2721.Invoke_O__O(arg_2722) } else { linked_2720.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2719, arg_2722) }; var tmp17 any = A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_New_O(e__3); var tmp18 *jrt.Class; var fncls__2718 *jrt.Class = A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_fn_class; if fncls__2718 == nil { var fncls__2718d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_26, false); A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_fn_class = fncls__2718d; tmp18 = fncls__2718d } else { tmp18 = fncls__2718 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :616:1
			tmp1 = A_arbace_build_go_A_const_190 } else { panic(jrt.Thrown(e__3)) } } else {
//line :604:1
				panic(tmp12) } }; return tmp1 }












func A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000414_fn__1901000415_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000414_fn__1901000415_A{}; t.Ctor_O(p0); return t }
//line :617:1
func (t *A_arbace_build_go__main_fn__1901000414_fn__1901000415_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :617:1
func (t *A_arbace_build_go__main_fn__1901000414_fn__1901000415_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_27, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); var root_2715 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2716 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2715, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2717 lang.IFn; if linked_2716 == nil { ifn_2717 = lang.IFn_Cast(root_2715) } else { ifn_2717 = nil }; if linked_2716 == nil { ifn_2717.Invoke__O() } else { linked_2716.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2715) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }




































































































































































type A_arbace_build_go_A struct{ jrt.Object }

var A_arbace_build_go_A_const_pool *jrt.RefArray

var A_arbace_build_go_A_const_0 *lang.Var

var A_arbace_build_go_A_const_1 any

var A_arbace_build_go_A_const_2 *lang.Var

var A_arbace_build_go_A_const_3 any

var A_arbace_build_go_A_const_4 any

var A_arbace_build_go_A_const_5 *lang.Var

var A_arbace_build_go_A_const_6 *lang.Var

var A_arbace_build_go_A_const_7 *lang.Var

var A_arbace_build_go_A_const_8 *lang.Var

var A_arbace_build_go_A_const_9 any

var A_arbace_build_go_A_const_10 *lang.Var

var A_arbace_build_go_A_const_11 *lang.Var

var A_arbace_build_go_A_const_12 any

var A_arbace_build_go_A_const_13 *lang.Keyword

var A_arbace_build_go_A_const_14 *lang.Var

var A_arbace_build_go_A_const_15 *lang.Var

var A_arbace_build_go_A_const_16 *lang.Var

var A_arbace_build_go_A_const_17 *lang.Var

var A_arbace_build_go_A_const_18 *lang.Var

var A_arbace_build_go_A_const_19 *lang.Var

var A_arbace_build_go_A_const_20 *lang.Var

var A_arbace_build_go_A_const_21 *lang.Var

var A_arbace_build_go_A_const_22 any

var A_arbace_build_go_A_const_23 *lang.Var

var A_arbace_build_go_A_const_24 *lang.Var

var A_arbace_build_go_A_const_25 *lang.Var

var A_arbace_build_go_A_const_26 *lang.Var

var A_arbace_build_go_A_const_27 *lang.Var

var A_arbace_build_go_A_const_28 *lang.Var

var A_arbace_build_go_A_const_29 *lang.Var

var A_arbace_build_go_A_const_30 *lang.Var

var A_arbace_build_go_A_const_31 *lang.Var

var A_arbace_build_go_A_const_32 *lang.Var

var A_arbace_build_go_A_const_33 *lang.Var

var A_arbace_build_go_A_const_34 *lang.Var

var A_arbace_build_go_A_const_35 *lang.Var

var A_arbace_build_go_A_const_36 *lang.Keyword

var A_arbace_build_go_A_const_37 *lang.Var

var A_arbace_build_go_A_const_38 *lang.Var

var A_arbace_build_go_A_const_39 *lang.Keyword

var A_arbace_build_go_A_const_40 *lang.Var

var A_arbace_build_go_A_const_41 *lang.Var

var A_arbace_build_go_A_const_42 *lang.Var

var A_arbace_build_go_A_const_43 *lang.Var

var A_arbace_build_go_A_const_44 *lang.Var

var A_arbace_build_go_A_const_45 *lang.Var

var A_arbace_build_go_A_const_46 *lang.Var

var A_arbace_build_go_A_const_47 *lang.Var

var A_arbace_build_go_A_const_48 *lang.Keyword

var A_arbace_build_go_A_const_49 *lang.Var

var A_arbace_build_go_A_const_50 *lang.Var

var A_arbace_build_go_A_const_51 *lang.Var

var A_arbace_build_go_A_const_52 *lang.Keyword

var A_arbace_build_go_A_const_53 *lang.Var

var A_arbace_build_go_A_const_54 *lang.Var

var A_arbace_build_go_A_const_55 *lang.Var

var A_arbace_build_go_A_const_56 *lang.Var

var A_arbace_build_go_A_const_57 *lang.Var

var A_arbace_build_go_A_const_58 *lang.Var

var A_arbace_build_go_A_const_59 *lang.Var

var A_arbace_build_go_A_const_60 *lang.Var

var A_arbace_build_go_A_const_61 *lang.Var

var A_arbace_build_go_A_const_62 *lang.Var

var A_arbace_build_go_A_const_63 *lang.Var

var A_arbace_build_go_A_const_64 *lang.Keyword

var A_arbace_build_go_A_const_65 *lang.Keyword

var A_arbace_build_go_A_const_66 *lang.Var

var A_arbace_build_go_A_const_67 *lang.Var

var A_arbace_build_go_A_const_68 *jrt.Class

var A_arbace_build_go_A_const_69 *lang.Var

var A_arbace_build_go_A_const_70 *lang.Var

var A_arbace_build_go_A_const_71 *lang.Var

var A_arbace_build_go_A_const_72 *lang.Var

var A_arbace_build_go_A_const_73 *lang.Var

var A_arbace_build_go_A_const_74 *lang.Var

var A_arbace_build_go_A_const_75 *lang.Var

var A_arbace_build_go_A_const_76 *lang.Var

var A_arbace_build_go_A_const_77 *lang.Var

var A_arbace_build_go_A_const_78 *lang.Var

var A_arbace_build_go_A_const_79 *lang.Keyword

var A_arbace_build_go_A_const_80 *lang.Var

var A_arbace_build_go_A_const_81 *lang.Var

var A_arbace_build_go_A_const_82 *lang.Var

var A_arbace_build_go_A_const_83 *lang.Keyword

var A_arbace_build_go_A_const_84 *lang.Var

var A_arbace_build_go_A_const_85 *lang.Var

var A_arbace_build_go_A_const_86 *lang.Var

var A_arbace_build_go_A_const_87 *lang.Var

var A_arbace_build_go_A_const_88 *lang.Var

var A_arbace_build_go_A_const_89 *lang.Var

var A_arbace_build_go_A_const_90 *lang.Var

var A_arbace_build_go_A_const_91 *lang.Var

var A_arbace_build_go_A_const_92 *lang.Keyword

var A_arbace_build_go_A_const_93 *lang.Var

var A_arbace_build_go_A_const_94 *lang.Var

var A_arbace_build_go_A_const_95 *lang.Var

var A_arbace_build_go_A_const_96 *lang.Keyword

var A_arbace_build_go_A_const_97 *lang.Var

var A_arbace_build_go_A_const_98 *lang.Var

var A_arbace_build_go_A_const_99 *lang.Var

var A_arbace_build_go_A_const_100 any

var A_arbace_build_go_A_const_101 any

var A_arbace_build_go_A_const_102 *lang.Var

var A_arbace_build_go_A_const_103 any

var A_arbace_build_go_A_const_104 any

var A_arbace_build_go_A_const_105 *lang.Var

var A_arbace_build_go_A_const_106 *lang.Var

var A_arbace_build_go_A_const_107 any

var A_arbace_build_go_A_const_108 any

var A_arbace_build_go_A_const_109 *lang.Var

var A_arbace_build_go_A_const_110 *lang.Var

var A_arbace_build_go_A_const_111 *lang.Var

var A_arbace_build_go_A_const_112 *lang.Var

var A_arbace_build_go_A_const_113 *lang.Keyword

var A_arbace_build_go_A_const_114 *lang.Keyword

var A_arbace_build_go_A_const_115 *lang.Keyword

var A_arbace_build_go_A_const_116 *lang.Var

var A_arbace_build_go_A_const_117 *lang.Var

var A_arbace_build_go_A_const_118 *lang.Var

var A_arbace_build_go_A_const_119 any

var A_arbace_build_go_A_const_120 *lang.Keyword

var A_arbace_build_go_A_const_121 *lang.Keyword

var A_arbace_build_go_A_const_122 *lang.Keyword

var A_arbace_build_go_A_const_123 *lang.Keyword

var A_arbace_build_go_A_const_124 *lang.Keyword

var A_arbace_build_go_A_const_125 *lang.Var

var A_arbace_build_go_A_const_126 *lang.Keyword

var A_arbace_build_go_A_const_127 *lang.Var

var A_arbace_build_go_A_const_128 *lang.Keyword

var A_arbace_build_go_A_const_129 *lang.Var

var A_arbace_build_go_A_const_130 *lang.Var

var A_arbace_build_go_A_const_131 *lang.Var

var A_arbace_build_go_A_const_132 any

var A_arbace_build_go_A_const_133 *lang.Keyword

var A_arbace_build_go_A_const_134 *lang.Var

var A_arbace_build_go_A_const_135 *lang.Var

var A_arbace_build_go_A_const_136 *lang.Var

var A_arbace_build_go_A_const_137 *lang.Keyword

var A_arbace_build_go_A_const_138 *lang.Var

var A_arbace_build_go_A_const_139 *lang.Var

var A_arbace_build_go_A_const_140 *jrt.Class

var A_arbace_build_go_A_const_141 any

var A_arbace_build_go_A_const_142 *lang.Var

var A_arbace_build_go_A_const_143 *lang.Keyword

var A_arbace_build_go_A_const_144 *lang.Keyword

var A_arbace_build_go_A_const_145 *lang.Keyword

var A_arbace_build_go_A_const_146 *lang.Keyword

var A_arbace_build_go_A_const_147 *lang.Var

var A_arbace_build_go_A_const_148 *lang.Var

var A_arbace_build_go_A_const_149 *lang.Var

var A_arbace_build_go_A_const_150 *lang.Keyword

var A_arbace_build_go_A_const_151 *lang.Keyword

var A_arbace_build_go_A_const_152 *lang.Keyword

var A_arbace_build_go_A_const_153 *lang.Keyword

var A_arbace_build_go_A_const_154 any

var A_arbace_build_go_A_const_155 *lang.Keyword

var A_arbace_build_go_A_const_156 *lang.Keyword

var A_arbace_build_go_A_const_157 *lang.Keyword

var A_arbace_build_go_A_const_158 *lang.Var

var A_arbace_build_go_A_const_159 *lang.Var

var A_arbace_build_go_A_const_160 any

var A_arbace_build_go_A_const_161 *lang.Var

var A_arbace_build_go_A_const_162 *lang.Var

var A_arbace_build_go_A_const_163 *lang.Var

var A_arbace_build_go_A_const_164 *lang.Var

var A_arbace_build_go_A_const_165 *lang.Keyword

var A_arbace_build_go_A_const_166 *lang.Keyword

var A_arbace_build_go_A_const_167 *lang.Var

var A_arbace_build_go_A_const_168 *lang.Var

var A_arbace_build_go_A_const_169 *lang.Var

var A_arbace_build_go_A_const_170 *lang.Var

var A_arbace_build_go_A_const_171 *lang.Keyword

var A_arbace_build_go_A_const_172 *lang.Keyword

var A_arbace_build_go_A_const_173 *lang.Var

var A_arbace_build_go_A_const_174 *jrt.Class

var A_arbace_build_go_A_const_175 *lang.Keyword

var A_arbace_build_go_A_const_176 *lang.Var

var A_arbace_build_go_A_const_177 *lang.Keyword

var A_arbace_build_go_A_const_178 *lang.Keyword

var A_arbace_build_go_A_const_179 *lang.Keyword

var A_arbace_build_go_A_const_180 *lang.Keyword

var A_arbace_build_go_A_const_181 *lang.Var

var A_arbace_build_go_A_const_182 *lang.Keyword

var A_arbace_build_go_A_const_183 *lang.Keyword

var A_arbace_build_go_A_const_184 *lang.Keyword

var A_arbace_build_go_A_const_185 *lang.Var

var A_arbace_build_go_A_const_186 any

var A_arbace_build_go_A_const_187 *lang.Var

var A_arbace_build_go_A_const_188 *lang.Keyword

var A_arbace_build_go_A_const_189 *lang.Var

var A_arbace_build_go_A_const_190 any

var A_arbace_build_go_A_const_191 *lang.Var

var A_arbace_build_go_A_const_192 *lang.Var

var A_arbace_build_go_A_const_193 *lang.Var

var A_arbace_build_go_A_const_194 *lang.Var

var A_arbace_build_go_A_const_195 *lang.Var

var A_arbace_build_go_A_const_196 *lang.Var

var A_arbace_build_go_A_const_197 *lang.Var

var A_arbace_build_go_A_const_198 any

var A_arbace_build_go_A_const_199 any

var A_arbace_build_go_A_const_200 any

var A_arbace_build_go_A_const_201 *lang.Var

var A_arbace_build_go_A_init jrt.ClassInit

func A_arbace_build_go_A_Init() { if !A_arbace_build_go_A_init.Done() { A_arbace_build_go_A_init.Run(A_arbace_build_go_A_clinit) } }

func A_arbace_build_go_A_clinit() { A_arbace_build_go_A_clinit_p0(); A_arbace_build_go_A_clinit_p1(); A_arbace_build_go_A_clinit_p2(); A_arbace_build_go_A_clinit_p3(); A_arbace_build_go_A_clinit_p4(); A_arbace_build_go_A_clinit_p5(); A_arbace_build_go_A_clinit_p6(); A_arbace_build_go_A_clinit_p7(); A_arbace_build_go_A_clinit_p8(); A_arbace_build_go_A_clinit_p9(); A_arbace_build_go_A_clinit_p10(); A_arbace_build_go_A_clinit_p11(); A_arbace_build_go_A_clinit_p12(); A_arbace_build_go_A_clinit_p13(); A_arbace_build_go_A_clinit_p14(); A_arbace_build_go_A_clinit_p15(); A_arbace_build_go_A_clinit_p16() }

func A_arbace_build_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_build_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 257); A_arbace_build_go_A_const_0 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[55]); A_arbace_build_go_A_const_1 = A_arbace_build_go_A_const_pool.A[56]; A_arbace_build_go_A_const_2 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[57]); A_arbace_build_go_A_const_3 = A_arbace_build_go_A_const_pool.A[58]; A_arbace_build_go_A_const_4 = A_arbace_build_go_A_const_pool.A[59]; A_arbace_build_go_A_const_5 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[60]); A_arbace_build_go_A_const_6 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[61]); A_arbace_build_go_A_const_7 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[62]); A_arbace_build_go_A_const_8 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[63]); A_arbace_build_go_A_const_9 = A_arbace_build_go_A_const_pool.A[64]; A_arbace_build_go_A_const_10 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[65]); A_arbace_build_go_A_const_11 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[66]) }

func A_arbace_build_go_A_clinit_p1() { A_arbace_build_go_A_const_12 = A_arbace_build_go_A_const_pool.A[67]; A_arbace_build_go_A_const_13 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[68]); A_arbace_build_go_A_const_14 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[69]); A_arbace_build_go_A_const_15 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[70]); A_arbace_build_go_A_const_16 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[71]); A_arbace_build_go_A_const_17 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[72]); A_arbace_build_go_A_const_18 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[73]); A_arbace_build_go_A_const_19 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[74]); A_arbace_build_go_A_const_20 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[75]); A_arbace_build_go_A_const_21 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[76]); A_arbace_build_go_A_const_22 = A_arbace_build_go_A_const_pool.A[77]; A_arbace_build_go_A_const_23 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[78]) }

func A_arbace_build_go_A_clinit_p2() { A_arbace_build_go_A_const_24 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[79]); A_arbace_build_go_A_const_25 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[80]); A_arbace_build_go_A_const_26 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[81]); A_arbace_build_go_A_const_27 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[82]); A_arbace_build_go_A_const_28 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[83]); A_arbace_build_go_A_const_29 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[84]); A_arbace_build_go_A_const_30 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[85]); A_arbace_build_go_A_const_31 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[86]); A_arbace_build_go_A_const_32 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[87]); A_arbace_build_go_A_const_33 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[88]); A_arbace_build_go_A_const_34 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[89]); A_arbace_build_go_A_const_35 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[90]) }

func A_arbace_build_go_A_clinit_p3() { A_arbace_build_go_A_const_36 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[91]); A_arbace_build_go_A_const_37 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[92]); A_arbace_build_go_A_const_38 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[93]); A_arbace_build_go_A_const_39 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[94]); A_arbace_build_go_A_const_40 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[95]); A_arbace_build_go_A_const_41 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[96]); A_arbace_build_go_A_const_42 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[97]); A_arbace_build_go_A_const_43 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[98]); A_arbace_build_go_A_const_44 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[99]); A_arbace_build_go_A_const_45 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[100]); A_arbace_build_go_A_const_46 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[101]); A_arbace_build_go_A_const_47 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[102]) }

func A_arbace_build_go_A_clinit_p4() { A_arbace_build_go_A_const_48 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[103]); A_arbace_build_go_A_const_49 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[104]); A_arbace_build_go_A_const_50 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[105]); A_arbace_build_go_A_const_51 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[106]); A_arbace_build_go_A_const_52 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[107]); A_arbace_build_go_A_const_53 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[108]); A_arbace_build_go_A_const_54 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[109]); A_arbace_build_go_A_const_55 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[110]); A_arbace_build_go_A_const_56 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[111]); A_arbace_build_go_A_const_57 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[112]); A_arbace_build_go_A_const_58 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[113]); A_arbace_build_go_A_const_59 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[114]) }

func A_arbace_build_go_A_clinit_p5() { A_arbace_build_go_A_const_60 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[115]); A_arbace_build_go_A_const_61 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[116]); A_arbace_build_go_A_const_62 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[117]); A_arbace_build_go_A_const_63 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[118]); A_arbace_build_go_A_const_64 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[119]); A_arbace_build_go_A_const_65 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[120]); A_arbace_build_go_A_const_66 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[121]); A_arbace_build_go_A_const_67 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[122]); A_arbace_build_go_A_const_68 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[123]); A_arbace_build_go_A_const_69 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[124]); A_arbace_build_go_A_const_70 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[125]); A_arbace_build_go_A_const_71 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[126]) }

func A_arbace_build_go_A_clinit_p6() { A_arbace_build_go_A_const_72 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[127]); A_arbace_build_go_A_const_73 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[128]); A_arbace_build_go_A_const_74 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[129]); A_arbace_build_go_A_const_75 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[130]); A_arbace_build_go_A_const_76 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[131]); A_arbace_build_go_A_const_77 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[132]); A_arbace_build_go_A_const_78 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[133]); A_arbace_build_go_A_const_79 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[134]); A_arbace_build_go_A_const_80 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[135]); A_arbace_build_go_A_const_81 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[136]); A_arbace_build_go_A_const_82 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[137]); A_arbace_build_go_A_const_83 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[138]) }

func A_arbace_build_go_A_clinit_p7() { A_arbace_build_go_A_const_84 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[139]); A_arbace_build_go_A_const_85 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[140]); A_arbace_build_go_A_const_86 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[141]); A_arbace_build_go_A_const_87 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[142]); A_arbace_build_go_A_const_88 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[143]); A_arbace_build_go_A_const_89 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[144]); A_arbace_build_go_A_const_90 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[145]); A_arbace_build_go_A_const_91 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[146]); A_arbace_build_go_A_const_92 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[147]); A_arbace_build_go_A_const_93 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[148]); A_arbace_build_go_A_const_94 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[149]); A_arbace_build_go_A_const_95 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[150]) }

func A_arbace_build_go_A_clinit_p8() { A_arbace_build_go_A_const_96 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[151]); A_arbace_build_go_A_const_97 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[152]); A_arbace_build_go_A_const_98 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[153]); A_arbace_build_go_A_const_99 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[154]); A_arbace_build_go_A_const_100 = A_arbace_build_go_A_const_pool.A[155]; A_arbace_build_go_A_const_101 = A_arbace_build_go_A_const_pool.A[156]; A_arbace_build_go_A_const_102 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[157]); A_arbace_build_go_A_const_103 = A_arbace_build_go_A_const_pool.A[158]; A_arbace_build_go_A_const_104 = A_arbace_build_go_A_const_pool.A[159]; A_arbace_build_go_A_const_105 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[160]); A_arbace_build_go_A_const_106 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[161]); A_arbace_build_go_A_const_107 = A_arbace_build_go_A_const_pool.A[162]; A_arbace_build_go_A_const_108 = A_arbace_build_go_A_const_pool.A[163] }

func A_arbace_build_go_A_clinit_p9() { A_arbace_build_go_A_const_109 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[164]); A_arbace_build_go_A_const_110 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[165]); A_arbace_build_go_A_const_111 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[166]); A_arbace_build_go_A_const_112 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[167]); A_arbace_build_go_A_const_113 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[168]); A_arbace_build_go_A_const_114 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[169]); A_arbace_build_go_A_const_115 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[170]); A_arbace_build_go_A_const_116 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[171]); A_arbace_build_go_A_const_117 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[172]); A_arbace_build_go_A_const_118 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[173]); A_arbace_build_go_A_const_119 = A_arbace_build_go_A_const_pool.A[174]; A_arbace_build_go_A_const_120 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[175]) }

func A_arbace_build_go_A_clinit_p10() { A_arbace_build_go_A_const_121 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[176]); A_arbace_build_go_A_const_122 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[177]); A_arbace_build_go_A_const_123 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[178]); A_arbace_build_go_A_const_124 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[179]); A_arbace_build_go_A_const_125 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[180]); A_arbace_build_go_A_const_126 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[181]); A_arbace_build_go_A_const_127 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[182]); A_arbace_build_go_A_const_128 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[183]); A_arbace_build_go_A_const_129 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[184]); A_arbace_build_go_A_const_130 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[185]); A_arbace_build_go_A_const_131 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[186]); A_arbace_build_go_A_const_132 = A_arbace_build_go_A_const_pool.A[187] }

func A_arbace_build_go_A_clinit_p11() { A_arbace_build_go_A_const_133 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[188]); A_arbace_build_go_A_const_134 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[189]); A_arbace_build_go_A_const_135 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[190]); A_arbace_build_go_A_const_136 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[191]); A_arbace_build_go_A_const_137 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[192]); A_arbace_build_go_A_const_138 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[193]); A_arbace_build_go_A_const_139 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[194]); A_arbace_build_go_A_const_140 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[195]); A_arbace_build_go_A_const_141 = A_arbace_build_go_A_const_pool.A[196]; A_arbace_build_go_A_const_142 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[197]); A_arbace_build_go_A_const_143 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[198]); A_arbace_build_go_A_const_144 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[199]) }

func A_arbace_build_go_A_clinit_p12() { A_arbace_build_go_A_const_145 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[200]); A_arbace_build_go_A_const_146 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[201]); A_arbace_build_go_A_const_147 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[202]); A_arbace_build_go_A_const_148 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[203]); A_arbace_build_go_A_const_149 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[204]); A_arbace_build_go_A_const_150 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[205]); A_arbace_build_go_A_const_151 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[206]); A_arbace_build_go_A_const_152 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[207]); A_arbace_build_go_A_const_153 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[208]); A_arbace_build_go_A_const_154 = A_arbace_build_go_A_const_pool.A[209]; A_arbace_build_go_A_const_155 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[210]); A_arbace_build_go_A_const_156 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[211]) }

func A_arbace_build_go_A_clinit_p13() { A_arbace_build_go_A_const_157 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[212]); A_arbace_build_go_A_const_158 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[213]); A_arbace_build_go_A_const_159 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[214]); A_arbace_build_go_A_const_160 = A_arbace_build_go_A_const_pool.A[215]; A_arbace_build_go_A_const_161 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[216]); A_arbace_build_go_A_const_162 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[217]); A_arbace_build_go_A_const_163 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[218]); A_arbace_build_go_A_const_164 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[219]); A_arbace_build_go_A_const_165 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[220]); A_arbace_build_go_A_const_166 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[221]); A_arbace_build_go_A_const_167 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[222]); A_arbace_build_go_A_const_168 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[223]) }

func A_arbace_build_go_A_clinit_p14() { A_arbace_build_go_A_const_169 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[224]); A_arbace_build_go_A_const_170 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[225]); A_arbace_build_go_A_const_171 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[226]); A_arbace_build_go_A_const_172 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[227]); A_arbace_build_go_A_const_173 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[228]); A_arbace_build_go_A_const_174 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[229]); A_arbace_build_go_A_const_175 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[230]); A_arbace_build_go_A_const_176 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[231]); A_arbace_build_go_A_const_177 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[232]); A_arbace_build_go_A_const_178 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[233]); A_arbace_build_go_A_const_179 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[234]); A_arbace_build_go_A_const_180 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[235]) }

func A_arbace_build_go_A_clinit_p15() { A_arbace_build_go_A_const_181 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[236]); A_arbace_build_go_A_const_182 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[237]); A_arbace_build_go_A_const_183 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[238]); A_arbace_build_go_A_const_184 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[239]); A_arbace_build_go_A_const_185 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[240]); A_arbace_build_go_A_const_186 = A_arbace_build_go_A_const_pool.A[241]; A_arbace_build_go_A_const_187 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[242]); A_arbace_build_go_A_const_188 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[243]); A_arbace_build_go_A_const_189 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[244]); A_arbace_build_go_A_const_190 = A_arbace_build_go_A_const_pool.A[245]; A_arbace_build_go_A_const_191 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[246]); A_arbace_build_go_A_const_192 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[247]) }

func A_arbace_build_go_A_clinit_p16() { A_arbace_build_go_A_const_193 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[248]); A_arbace_build_go_A_const_194 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[249]); A_arbace_build_go_A_const_195 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[250]); A_arbace_build_go_A_const_196 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[251]); A_arbace_build_go_A_const_197 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[252]); A_arbace_build_go_A_const_198 = A_arbace_build_go_A_const_pool.A[253]; A_arbace_build_go_A_const_199 = A_arbace_build_go_A_const_pool.A[254]; A_arbace_build_go_A_const_200 = A_arbace_build_go_A_const_pool.A[255]; A_arbace_build_go_A_const_201 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[256]) }

func A_arbace_build_go_A_New() *A_arbace_build_go_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_A) Ctor() {}

func (t *A_arbace_build_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_A_class }

func (t *A_arbace_build_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_A); return ok }

func A_arbace_build_go_A_Cast(x any) *A_arbace_build_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_A_class)) }; return v }



type A_arbace_build_go__main_A struct{ j2g_header uint64 }

var A_arbace_build_go__main_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000412_A struct{ j2g_header uint64; F_usage any }

var A_arbace_build_go__main_fn__1901000412_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000414_A struct{ j2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_build_go__main_fn__1901000414_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000414_fn__1901000415_A struct{ j2g_header uint64; F_e any }

var A_arbace_build_go__main_fn__1901000414_fn__1901000415_A_fn_class *jrt.Class



type A_arbace_build_go_build_A struct{ j2g_header uint64 }

var A_arbace_build_go_build_A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__fn__1901000326_A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_A struct{ j2g_header uint64 }

var A_arbace_build_go_cached_texts_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A struct{ j2g_header uint64; F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A struct{ j2g_header uint64; F_s__1901000305, F_iter__1901000304, F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A struct{ j2g_header uint64; F_b__1901000307, F_entry any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000020_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_fn__1901000020_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000022_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_clj_files_fn__1901000022_A_fn_class *jrt.Class



type A_arbace_build_go_collect_index_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_index_file_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_package_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_fn__1901000076_A struct{ j2g_header uint64; F_read_fn, F_read any }

var A_arbace_build_go_collect_package_fn__1901000076_A_fn_class *jrt.Class



type A_arbace_build_go_collected_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collected_package_A_fn_class *jrt.Class



type A_arbace_build_go_copy_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_copy_file_A_fn_class *jrt.Class



type A_arbace_build_go_data_dir_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_delete_tree_A struct{ j2g_header uint64 }

var A_arbace_build_go_delete_tree_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000004_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000004_A_New() *A_arbace_build_go_eval1901000004_A { t := &A_arbace_build_go_eval1901000004_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000004_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000004_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000004_A_class }

func (t *A_arbace_build_go_eval1901000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000004_A); return ok }

func A_arbace_build_go_eval1901000004_A_Cast(x any) *A_arbace_build_go_eval1901000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000004_A_class)) }; return v }



type A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000008_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000008_A_New() *A_arbace_build_go_eval1901000008_A { t := &A_arbace_build_go_eval1901000008_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000008_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000008_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000008_A_class }

func (t *A_arbace_build_go_eval1901000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000008_A); return ok }

func A_arbace_build_go_eval1901000008_A_Cast(x any) *A_arbace_build_go_eval1901000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000008_A_class)) }; return v }



type A_arbace_build_go_eval1901000008_fn__1901000009_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000008_fn__1901000009_A_fn_class *jrt.Class



type A_arbace_build_go_fail_A struct{ j2g_header uint64 }

var A_arbace_build_go_fail_A_fn_class *jrt.Class



type A_arbace_build_go_file_sha_A struct{ j2g_header uint64 }

var A_arbace_build_go_file_sha_A_fn_class *jrt.Class



type A_arbace_build_go_forms_dir_A struct{ j2g_header uint64 }

var A_arbace_build_go_forms_dir_A_fn_class *jrt.Class



type A_arbace_build_go_go_env_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_env_A_fn_class *jrt.Class



type A_arbace_build_go_go_mod_cache_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_sha__1901000243_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class *jrt.Class



type A_arbace_build_go_hex_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_A_fn_class *jrt.Class



type A_arbace_build_go_hex_fn__1901000072_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_fn__1901000072_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000027_A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000029_A struct{ j2g_header uint64; F_aliases any }

var A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class *jrt.Class



type A_arbace_build_go_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000057_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000057_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000062_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000062_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_A struct{ j2g_header uint64; F_print_cache any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A struct{ j2g_header uint64; F_iter__1901000034, F_print_cache, F_s__1901000035 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A struct{ j2g_header uint64; F_iter__1901000036, F_s__1901000037 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A struct{ j2g_header uint64; F_b__1901000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_add__1901000295_A struct{ j2g_header uint64; F_md any }

var A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_fn__1901000301_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_A struct{ j2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_build_go_print_module_fn__1901000361_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A struct{ j2g_header uint64; F_test_files, F_tests any }

var A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000361_printable__1901000363_fn__1901000364_fn__1901000365_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_build_go_print_module_fn__1901000361_rel__1901000370_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000341__1901000345_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_iter__1901000341__1901000345_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A struct{ j2g_header uint64; F_iter__1901000341, F_s__1901000342 any }

var A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A struct{ j2g_header uint64; F_b__1901000344 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_print_module_iter__1901000341__1901000345_fn__1901000346_fn__1901000347_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000351__1901000355_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_iter__1901000351__1901000355_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A struct{ j2g_header uint64; F_iter__1901000351, F_s__1901000352 any }

var A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A struct{ j2g_header uint64; F_b__1901000354 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_print_module_iter__1901000351__1901000355_fn__1901000356_fn__1901000357_A_fn_class *jrt.Class



type A_arbace_build_go_program_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000263_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000263_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000265_A struct{ j2g_header uint64; F_opts any }

var A_arbace_build_go_program_fn__1901000265_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000277_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000277_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_A struct{ j2g_header uint64; F_module any }

var A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A struct{ j2g_header uint64; F_iter__1901000267, F_module, F_s__1901000268 any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A struct{ j2g_header uint64; F_b__1901000270 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000066_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_fn__1901000066_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000068_A struct{ j2g_header uint64; F_cache any }

var A_arbace_build_go_read_all_fn__1901000068_A_fn_class *jrt.Class



type A_arbace_build_go_read_index_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_index_A_fn_class *jrt.Class



type A_arbace_build_go_read_program_edn_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_program_edn_A_fn_class *jrt.Class



type A_arbace_build_go_rel_path_A struct{ j2g_header uint64 }

var A_arbace_build_go_rel_path_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000099_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_fn__1901000099_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000101_A struct{ j2g_header uint64; F_m any }

var A_arbace_build_go_root_packages_fn__1901000101_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000158_A struct{ j2g_header uint64; F_covered, F_known_QMARK_ any }

var A_arbace_build_go_root_packages_fn__1901000158_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000187_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000187_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000192_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000192_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A struct{ j2g_header uint64; F_s__1901000104, F_iter__1901000103, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A struct{ j2g_header uint64; F_b__1901000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A struct{ j2g_header uint64; F_iter__1901000131, F_s__1901000132 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A struct{ j2g_header uint64; F_iter__1901000133, F_s__1901000134 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A struct{ j2g_header uint64; F_b__1901000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid, F_s__1901000163, F_iter__1901000162 any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_b__1901000165, F_dir, F_valid any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_s__1901000195, F_iter__1901000194, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_b__1901000197 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A struct{ j2g_header uint64; F_s__1901000205, F_iter__1901000204, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A struct{ j2g_header uint64; F_b__1901000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_known_QMARK___1901000156_A struct{ j2g_header uint64; F_index_file, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A struct{ j2g_header uint64; F_read_fn, F_known_QMARK_, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class *jrt.Class



type A_arbace_build_go_run_A struct{ j2g_header uint64 }

var A_arbace_build_go_run_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_fn__1901000281_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_fn__1901000281_A_fn_class *jrt.Class



type A_arbace_build_go_tamago_go_sum_A struct{ j2g_header uint64 }

var A_arbace_build_go_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_build_go_toolchain_lang_A struct{ j2g_header uint64 }

var A_arbace_build_go_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_with_line_files_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__fn__1901000091_A struct{ j2g_header uint64; F_ok_QMARK_ any }

var A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A struct{ j2g_header uint64; F_printed any }

var A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__printed__1901000087_A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class *jrt.Class
