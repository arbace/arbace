//line aot_arbace_build_go.ae:1
package aot_arbace_build_go

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_New() *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_build_go_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_2); lang.IFn_Cast(A_arbace_build_go_A_const_1.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_3, A_arbace_build_go_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_58)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_59)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_60)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_61)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_62)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_63)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_build_go_eval1901000008_fn__1901000009_A_New() *A_arbace_build_go_eval1901000008_fn__1901000009_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000008_fn__1901000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_build_go_A_const_5.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_6.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_9), A_arbace_build_go_A_const_7.GetRawRoot__O(), A_arbace_build_go_A_const_8) }






























































func A_arbace_build_go_fail_A_New() *A_arbace_build_go_fail_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_fail_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_build_go_fail_A) Ctor() {}
//line :64:1
func (t *A_arbace_build_go_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__1901000012__1 any) any { var vec__1901000013__3 any = p__1901000012__1; var data__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000013__3, lang.RT_IntCast_J__I_NoInit(0), nil); panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_10.GetRawRoot__O()).Invoke_O_O__O(msg__0, lang.IFn_Cast(A_arbace_build_go_A_const_11.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_12, data__4))))) }





func A_arbace_build_go_data_dir_QMARK__A_New() *A_arbace_build_go_data_dir_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Ctor() {}
//line :70:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.NN(jrt.File_Cast(f__1)).GetParentFile__File().Ref(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(jrt.NN(jrt.File_Cast(d__3)).GetAbsoluteFile__File().Ref(), jrt.NN(jrt.File_Cast(dir__0)).GetAbsoluteFile__File().Ref()) }; if tmp1 { return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_57).IsFile__Z() { return jrt.Boolean_TRUE.Ref() } else { if A_arbace_build_go_A_const_13 != nil {

		d__3 = jrt.NN(jrt.File_Cast(d__3)).GetParentFile__File().Ref(); continue L1 } else {
//line :75:1
			return nil } } } } }; /*line :70:1*/panic("j2g: unreachable") }








func A_arbace_build_go_clj_files_A_New() *A_arbace_build_go_clj_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_build_go_clj_files_A) Ctor() {}
//line :79:1
func (t *A_arbace_build_go_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_14.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_clj_files_fn__1901000020_A_New(); var tmp3 *jrt.Class; var fncls__1 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000020_A_fn_class; if fncls__1 == nil { var fncls__1d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_build_go_clj_files_fn__1901000020_A_fn_class = fncls__1d; tmp3 = fncls__1d } else { tmp3 = fncls__1 }; var tmp4 any = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()); var tmp6 any = A_arbace_build_go_clj_files_fn__1901000022_A_New_O(dir__0); var tmp7 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000022_A_fn_class
//line :81:1
	if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_build_go_clj_files_fn__1901000022_A_fn_class = fncls__2d; tmp7 = fncls__2d } else { tmp7 = fncls__2
	}
	return tmp1.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), lang.IFn_Cast(A_arbace_build_go_A_const_19.GetRawRoot__O()).Invoke_O__O(dir__0))) }
//line :81:1
func A_arbace_build_go_clj_files_fn__1901000022_A_New_O(p0 any) *A_arbace_build_go_clj_files_fn__1901000022_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000022_A{}; t.Ctor_O(p0); return t }
//line :81:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :81:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Invoke_O_O__O(self, p1__1901000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_build_go_A_const_16.GetRawRoot__O()).Invoke_O_O__O(jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).GetName__String().Ref(), Lit_50); if jrt.J2g_Truth(and__1927000168__auto____3) {
														return lang.IFn_Cast(A_arbace_build_go_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_18.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, p1__1901000018_SHARP___1)) } else {
//line :81:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_build_go_clj_files_fn__1901000020_A_New() *A_arbace_build_go_clj_files_fn__1901000020_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000020_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Ctor() {}
//line :83:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Invoke_O_O__O(self, p1__1901000019_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000019_SHARP___1)).GetPath__String().Ref() }

func A_arbace_build_go_package_file_QMARK__A_New() *A_arbace_build_go_package_file_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_build_go_package_file_QMARK__A) Ctor() {}
//line :85:1
func (t *A_arbace_build_go_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()); var tmp3 any = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New(); var tmp4 *jrt.Class; var fncls__3 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class; if




	fncls__3 == nil { var fncls__3d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class = fncls__3d; tmp4 = fncls__3d } else { tmp4 = fncls__3 }; ns_form__4 = tmp1.Invoke_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), forms__3)); var aliases__5 any; if
	jrt.J2g_Truth(ns_form__4) { aliases__5 = A_arbace_build_go_A_const_21.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp5 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.J2g_Truth(and__1927000168__auto____6) {
		var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_22.GetRawRoot__O()); var tmp7 any = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(aliases__5); var tmp8 *jrt.Class; var fncls__4 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class; if fncls__4 == nil { var fncls__4d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class = fncls__4d; tmp8 = fncls__4d } else { tmp8 = fncls__4 }; tmp5 = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), forms__3) } else {
//line :93:1
			tmp5 = and__1927000168__auto____6 }; return /*line :92:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp5)).Ref() }
//line :90:1
func A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New() *A_arbace_build_go_package_file_QMARK__fn__1901000027_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000027_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Ctor() {}
//line :90:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Invoke_O_O__O(self, p1__1901000025_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_23.GetRawRoot__O()).Invoke_O__O(p1__1901000025_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_build_go_A_const_24; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__1901000025_SHARP___1))).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(p0 any) *A_arbace_build_go_package_file_QMARK__fn__1901000029_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000029_A{}; t.Ctor_O(p0); return t }
//line :94:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :94:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Invoke_O_O__O(self, p1__1901000026_SHARP___1 any) any { var and__1927000168__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_23.GetRawRoot__O()).Invoke_O__O(p1__1901000026_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any = lang.IFn_Cast(A_arbace_build_go_A_const_25.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__1901000026_SHARP___1)); if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool = lang.Util_Equiv_O_O__Z_NoInit(Lit_83, lang.IFn_Cast(A_arbace_build_go_A_const_26.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__1901000026_SHARP___1))); if and__1927000168__auto____4 {

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_27.GetRawRoot__O()); var tmp2 any = t.F_aliases; return tmp1.Invoke_O_O__O(tmp2, lang.IFn_Cast(A_arbace_build_go_A_const_28.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__1901000026_SHARP___1))) } else {
//line :94:1
		return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_build_go_rel_path_A_New() *A_arbace_build_go_rel_path_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_rel_path_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_build_go_rel_path_A) Ctor() {}
//line :101:1
func (t *A_arbace_build_go_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	return lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.NN(jrt.File_Cast(base__0)).GetAbsoluteFile__File()).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).ToPath__Path()))
}
func A_arbace_build_go_packages_A_New() *A_arbace_build_go_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_build_go_packages_A) Ctor() {}
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O_O__O(self, dir__0, roots__1, print_cache__2 any) any { var own__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_30.GetRawRoot__O()).Invoke_O_O__O(dir__0, print_cache__2); var more__5 any; var iter__1927001039__auto____5 any; var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(print_cache__2); var tmp2 *jrt.Class; var fncls__9 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class; if









	fncls__9 == nil { var fncls__9d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class = fncls__9d; tmp2 = fncls__9d } else { tmp2 = fncls__9 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); more__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(roots__1); var pkgs__6 any = /*line :104:1*/lang.IFn_Cast(A_arbace_build_go_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()).Invoke_O_O__O(own__4, more__5)); var seq_1901000050__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_46, pkgs__6)); var chunk_1901000051__8 any; var count_1901000052__9 int64 = 0; var i_1901000053__10 int64 = 0; L1: for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000053__10, count_1901000052__9) { var vec__1901000054__11 any = lang.Indexed_Cast(chunk_1901000051__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000053__10)); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__13)), 1) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()); var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp7 any = A_arbace_build_go_packages_fn__1901000057_A_New(); var tmp8 *jrt.Class; var fncls__10 *jrt.Class = A_arbace_build_go_packages_fn__1901000057_A_fn_class
			if fncls__10 == nil { var fncls__10d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_build_go_packages_fn__1901000057_A_fn_class = fncls__10d; tmp8 = fncls__10d } else { tmp8 = fncls__10 }
//line :120:1
			tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__12, nil, tmp5.Invoke_O_O__O(Lit_87, tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), ps__13)))).Ref())
//line :119:1
			seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } else { seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000050__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000050__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000050__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000050__12); seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000050__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000059__13 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000050__12); var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__15)), 1) {
				var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()); var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp13 any = A_arbace_build_go_packages_fn__1901000062_A_New(); var tmp14 *jrt.Class; var fncls__11 *jrt.Class = A_arbace_build_go_packages_fn__1901000062_A_fn_class
				if fncls__11 == nil { var fncls__11d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_build_go_packages_fn__1901000062_A_fn_class = fncls__11d; tmp14 = fncls__11d } else { tmp14 = fncls__11 }
//line :120:1
				tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, path__14, nil, tmp11.Invoke_O_O__O(Lit_87, tmp12.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil), ps__15)))).Ref())
//line :119:1
				seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000050__12), nil, 0, 0; continue L1 } else { seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000050__12), nil, 0, 0; continue L1 } } } }
//line :104:1
		break L1 }; return pkgs__6 }
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any {






	return lang.IFn_Cast(A_arbace_build_go_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, roots__1, nil) }
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O__O(self, dir__0 any) any {





	return lang.IFn_Cast(A_arbace_build_go_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, nil, nil)
}


func A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(p0 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_A{}; t.Ctor_O(p0); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Ctor_O(c__print_cache any) { t.F_print_cache = c__print_cache }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Invoke_O_O__O(self, s__1901000035__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(self, t.F_print_cache, s__1901000035__1); var tmp2 *jrt.Class; var fncls__8 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class; if fncls__8 == nil { var fncls__8d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class = fncls__8d; tmp2 = fncls__8d } else { tmp2 = fncls__8 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Ctor_O_O_O(c__iter__1901000034, c__print_cache, c__s__1901000035 any) { t.F_iter__1901000034 = c__iter__1901000034; t.F_print_cache = c__print_cache; t.F_s__1901000035 = c__s__1901000035 }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Invoke_O__O(self any) any { { var s__1901000035__1 any; var t_ any = t.F_s__1901000035; t.F_s__1901000035 = nil; s__1901000035__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000035__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New(); var tmp2 *jrt.Class; var fncls__7 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class; if fncls__7 == nil { var fncls__7d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class = fncls__7d; tmp2 = fncls__7d } else { tmp2 = fncls__7 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____5).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_30.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(r__4))), t.F_print_cache))); if jrt.J2g_Truth(fs__1927001036__auto____6) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000034); return lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____6, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000035__1))) } else { s__1901000035__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000035__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New() *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Ctor() {}
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Invoke_O_O__O(self, s__1901000037__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(self, s__1901000037__1); var tmp2 *jrt.Class; var fncls__6 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class; if fncls__6 == nil { var fncls__6d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class = fncls__6d; tmp2 = fncls__6d } else { tmp2 = fncls__6 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(p0, p1 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Ctor_O_O(c__iter__1901000036, c__s__1901000037 any) { t.F_iter__1901000036 = c__iter__1901000036; t.F_s__1901000037 = c__s__1901000037 }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Invoke_O__O(self any) any { { var s__1901000037__1 any; var t_ any = t.F_s__1901000037; t.F_s__1901000037 = nil; s__1901000037__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000037__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000037__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000037__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000037__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000039__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(b__1901000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__5 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class; if fncls__5 == nil { var fncls__5d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class = fncls__5d; tmp2 = fncls__5d } else { tmp2 = fncls__5 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000039__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000037__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000039__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000037__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_94, lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_36.Invoke_O__O(pkg__4)))) { var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); return lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()).Invoke_O_O__O(pkg__4, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000037__3))) } else { s__1901000037__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000037__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Ctor_O_I_O(c__b__1901000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000039 = c__b__1901000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Invoke_O__O(self any) any { { var i__1901000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000038__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_35.GetRawRoot__O()).Invoke_O_O__O(Lit_94, lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_36.Invoke_O__O(pkg__2)))) { lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1901000039, pkg__2); i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } else { i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_build_go_packages_fn__1901000057_A_New() *A_arbace_build_go_packages_fn__1901000057_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000057_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Ctor() {}
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }
//line :121:1
func A_arbace_build_go_packages_fn__1901000062_A_New() *A_arbace_build_go_packages_fn__1901000062_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000062_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Ctor() {}
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }


func A_arbace_build_go_read_all_A_New() *A_arbace_build_go_read_all_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_read_all_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_53.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp3 any = A_arbace_build_go_read_all_fn__1901000066_A_New(); var tmp4 *jrt.Class; var fncls__13 *jrt.Class = A_arbace_build_go_read_all_fn__1901000066_A_fn_class; if




	fncls__13 == nil { var fncls__13d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_build_go_read_all_fn__1901000066_A_fn_class = fncls__13d; tmp4 = fncls__13d } else { tmp4 = fncls__13 }; cache__2 = tmp1.Invoke_O_O__O(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), files__0), lang.IFn_Cast(A_arbace_build_go_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_54.GetRawRoot__O(), files__0)); var tmp5 any =

	A_arbace_build_go_read_all_fn__1901000068_A_New_O(cache__2); var tmp6 *jrt.Class; var fncls__12 *jrt.Class = A_arbace_build_go_read_all_fn__1901000068_A_fn_class; if fncls__12 == nil { var fncls__12d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_build_go_read_all_fn__1901000068_A_fn_class = fncls__12d; tmp6 = fncls__12d } else { tmp6 = fncls__12 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil) }
//line :129:1
func A_arbace_build_go_read_all_fn__1901000066_A_New() *A_arbace_build_go_read_all_fn__1901000066_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000066_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Ctor() {}
//line :129:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Invoke_O_O__O(self, p1__1901000065_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000065_SHARP___1)).GetAbsolutePath__String().Ref() }

func A_arbace_build_go_read_all_fn__1901000068_A_New_O(p0 any) *A_arbace_build_go_read_all_fn__1901000068_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000068_A{}; t.Ctor_O(p0); return t }
//line :131:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :131:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__1)).GetAbsolutePath__String().Ref(); if

	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_27.GetRawRoot__O()).Invoke_O_O__O(t.F_cache, k__2)) { return lang.RT_Get_O_O__O_NoInit(t.F_cache, k__2) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_54.GetRawRoot__O()).Invoke_O__O(f__1) } }

func A_arbace_build_go_hex_A_New() *A_arbace_build_go_hex_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_build_go_hex_A) Ctor() {}
//line :135:1
func (t *A_arbace_build_go_hex_A) Invoke_O_O__O(self, bs__0 any) any {
	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_hex_fn__1901000072_A_New(); var tmp5 *jrt.Class; var fncls__19 *jrt.Class = A_arbace_build_go_hex_fn__1901000072_A_fn_class; if fncls__19 == nil { var fncls__19d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_build_go_hex_fn__1901000072_A_fn_class = fncls__19d; tmp5 = fncls__19d } else { tmp5 = fncls__19 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), bs__0)) }
//line :136:1
func A_arbace_build_go_hex_fn__1901000072_A_New() *A_arbace_build_go_hex_fn__1901000072_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_fn__1901000072_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Ctor() {}
//line :136:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Invoke_O_O__O(self, p1__1901000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_14 any = p1__1901000071_SHARP___1; var na_15 int64 = 255; if jrt.Long_InstanceOf(na_14) { var n0_16 int64 = jrt.NN(jrt.Long_Cast(na_14)).LongValue__J(); var n1_17 int64 = na_15; tmp2 = n0_16 & n1_17 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_14, na_15) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_file_sha_A_New() *A_arbace_build_go_file_sha_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_file_sha_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_build_go_file_sha_A) Ctor() {}
//line :138:1
func (t *A_arbace_build_go_file_sha_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		return lang.IFn_Cast(A_arbace_build_go_A_const_58.GetRawRoot__O()).Invoke_O__O(jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref()) } else {
//line :141:1
			return nil
		}
}
func A_arbace_build_go_collect_package_A_New() *A_arbace_build_go_collect_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_build_go_collect_package_A) Ctor() {}
//line :144:1
func (t *A_arbace_build_go_collect_package_A) Invoke_O_O_O_O__O(self, dir__0, f__1, read_fn__2 any) any { var read__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_59.GetRawRoot__O()).Invoke_O__O(lang.PersistentVector_EMPTY.Ref()); var pkg__5 any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_60.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(read_fn__2, read__4); var tmp3 *jrt.Class; var fncls__20 *jrt.Class = A_arbace_build_go_collect_package_fn__1901000076_A_fn_class; if




	fncls__20 == nil { var fncls__20d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_build_go_collect_package_fn__1901000076_A_fn_class = fncls__20d; tmp3 = fncls__20d } else { tmp3 = fncls__20 }; pkg__5 = tmp1.Invoke_O_O__O(f__1, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 /*line :144:1*/*lang.Keyword = A_arbace_build_go_A_const_46; var path__6 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__5)); if






	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_64.GetRawRoot__O()).Invoke_O__O(path__6)) { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_55), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__0, f__1), nil)).Ref()) }; var tmp5 lang.IFn =
	lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_build_go_A_const_50; var tmp7 any = A_arbace_build_go_A_const_46; var tmp8 any = A_arbace_build_go_A_const_66; return tmp5.Invoke_O_O_O_O_O_O_O__O(pkg__5, tmp6, f__1, tmp7, path__6, tmp8, lang.IFn_Cast(A_arbace_build_go_A_const_6.GetRawRoot__O()).Invoke_O__O(read__4)) }
//line :149:1
func A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(p0, p1 any) *A_arbace_build_go_collect_package_fn__1901000076_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_fn__1901000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :149:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Invoke_O_O__O(self, file__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp2 any = t.F_read; tmp1.Invoke_O_O_O__O(tmp2, A_arbace_build_go_A_const_7.GetRawRoot__O(), file__1); return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }











func A_arbace_build_go_collect_index_file_A_New() *A_arbace_build_go_collect_index_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_index_file_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_build_go_collect_index_file_A) Ctor() {}
//line :161:1
func (t *A_arbace_build_go_collect_index_file_A) Invoke_O_O_O_O__O(self, print_cache__0, host_id__1, dir__2 any) any { var md__4 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51);

	jrt.MessageDigest_Cast(md__4).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil), jrt.RefArrayOf(jrt.Object_class, host_id__1, nil, jrt.NN(jrt.File_Cast(dir__2)).GetPath__String().Ref()))).GetBytes_String__B1(Lit_52)); var tmp1 /*line :161:1*/*jrt.Class = A_arbace_build_go_A_const_67; return lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(print_cache__0)), Lit_53), lang.IFn_Cast(A_arbace_build_go_A_const_58.GetRawRoot__O()).Invoke_O__O(jrt.MessageDigest_Cast(md__4).Digest__B1().Ref()))) }




func A_arbace_build_go_read_index_A_New() *A_arbace_build_go_read_index_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_index_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_build_go_read_index_A) Ctor() {}
//line :166:1
func (t *A_arbace_build_go_read_index_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
//line :169:1
		var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1901000080__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_54.GetRawRoot__O()).Invoke_O__O(f__0); var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000080__4, lang.RT_IntCast_J__I_NoInit(0), nil)

			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_68.GetRawRoot__O()).Invoke_O__O(m__5)) { tmp1 = m__5 } else { tmp1 = nil } }; return nil }()
//line :169:1
		if tmp2 != nil { if true { var ___4 jrt.Throwable_I = tmp2; _ = ___4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_build_go_write_index_BANG__A_New() *A_arbace_build_go_write_index_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_build_go_write_index_BANG__A) Ctor() {}
//line :174:1
func (t *A_arbace_build_go_write_index_BANG__A) Invoke_O_O_O__O(self, f__0, index__1 any) any { var printed__3 any; var tmp1 any = A_arbace_build_go_write_index_BANG__printed__1901000087_A_New(); var tmp2 *jrt.Class; var fncls__21 *jrt.Class = A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class; if



	fncls__21 == nil { var fncls__21d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class = fncls__21d; tmp2 = fncls__21d } else { tmp2 = fncls__21 }; printed__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var ok_QMARK___4 any; var tmp3 any = /*line :174:1*/A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(printed__3); var tmp4 *jrt.Class; var fncls__22 *jrt.Class = A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class; if



	fncls__22 == nil { var fncls__22d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class = fncls__22d; tmp4 = fncls__22d } else { tmp4 = fncls__22 }; ok_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var index__5 any; var tmp5 lang.IFn = /*line :174:1*/lang.IFn_Cast(A_arbace_build_go_A_const_77.GetRawRoot__O()); var tmp6 any = A_arbace_build_go_A_const_78; var tmp7 any = A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(ok_QMARK___4); var tmp8 *jrt.Class; var fncls__23 *jrt.Class = A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class; if





	fncls__23 == nil { var fncls__23d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class = fncls__23d; tmp8 = fncls__23d } else { tmp8 = fncls__23 }; index__5 = tmp5.Invoke_O_O_O__O(index__1, tmp6, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil)); var tmp__6 any = /*line :174:1*/jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));







	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File()).Mkdirs__Z());
	lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(tmp__6, lang.IFn_Cast(printed__3).Invoke_O__O(index__5)); if
	jrt.NN(jrt.File_Cast(tmp__6)).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__6)).Delete__Z()).Ref() } }
//line :178:1
func A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Ctor_O(c__printed any) { t.F_printed = c__printed }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Invoke_O_O__O(self, p1__1901000085_SHARP___1 any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__1901000085_SHARP___1, lang.IFn_Cast(A_arbace_build_go_A_const_76.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(t.F_printed).Invoke_O__O(p1__1901000085_SHARP___1)))).Ref()
//line :178:1
	return nil }(); if tmp2 != nil { if true { var ___4 jrt.Throwable_I = tmp2; _ = ___4; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :178:1
func A_arbace_build_go_write_index_BANG__printed__1901000087_A_New() *A_arbace_build_go_write_index_BANG__printed__1901000087_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__printed__1901000087_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Ctor() {}
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Invoke_O_O__O(self, p1__1901000084_SHARP___1 any) any { lang.IFn_Cast(A_arbace_build_go_A_const_71.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_build_go_A_const_73, jrt.Boolean_TRUE.Ref(), A_arbace_build_go_A_const_74, nil, A_arbace_build_go_A_const_75, nil)); var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(p1__1901000084_SHARP___1); return nil }(); lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__fn__1901000091_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__fn__1901000091_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Ctor_O(c__ok_QMARK_ any) { t.F_ok_QMARK_ = c__ok_QMARK_ }
//line :180:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Invoke_O_O__O(self, p1__1901000086_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()); var tmp2 any = t.F_ok_QMARK_; var tmp3 any = A_arbace_build_go_A_const_82; return lang.IFn_Cast(A_arbace_build_go_A_const_79.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(), lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_build_go_A_const_83.GetRawRoot__O())), p1__1901000086_SHARP___1) }





func A_arbace_build_go_root_packages_A_New() *A_arbace_build_go_root_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_build_go_root_packages_A) Ctor() {}
//line :186:1
func (t *A_arbace_build_go_root_packages_A) Invoke_O_O_O__O(self, dir__0, print_cache__1 any) any { var root__3 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_132); if




	jrt.NN(jrt.File_Cast(root__3)).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_133, nil, Lit_134), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref(), nil)).Ref()) }; var files__4 any = /*line :186:1*/lang.IFn_Cast(A_arbace_build_go_A_const_85.GetRawRoot__O()).Invoke_O__O(root__3); var host_id__5 any = jrt.System_Getenv_String__String(Lit_107).Ref(); var index_file__6 any; var tmp1 any; var and__1927000168__auto____6 any = print_cache__1; if








	jrt.J2g_Truth(and__1927000168__auto____6) { tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(host_id__5) } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { index_file__6 = lang.IFn_Cast(A_arbace_build_go_A_const_86.GetRawRoot__O()).Invoke_O_O_O__O(print_cache__1, host_id__5, dir__0) } else { index_file__6 = nil }; var index__7 any; if
	jrt.J2g_Truth(index_file__6) { var or__1927000174__auto____7 any = lang.IFn_Cast(A_arbace_build_go_A_const_87.GetRawRoot__O()).Invoke_O__O(index_file__6); if jrt.J2g_Truth(or__1927000174__auto____7) { index__7 = or__1927000174__auto____7 } else { index__7 = lang.PersistentArrayMap_EMPTY.Ref() } } else { index__7 = nil }; var shas__8 any; if
	jrt.J2g_Truth(index_file__6) { var m__8 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_53.GetRawRoot__O()); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_root_packages_fn__1901000099_A_New(); var tmp5 *jrt.Class; var fncls__27 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000099_A_fn_class
		if fncls__27 == nil { var fncls__27d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_build_go_root_packages_fn__1901000099_A_fn_class = fncls__27d; tmp5 = fncls__27d } else { tmp5 = fncls__27 }; m__8 = tmp2.Invoke_O_O__O(tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), files__4), lang.IFn_Cast(A_arbace_build_go_A_const_55.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_88.GetRawRoot__O(), files__4))
		var tmp6 any = A_arbace_build_go_root_packages_fn__1901000101_A_New_O(m__8); var tmp7 *jrt.Class; var fncls__24 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000101_A_fn_class; if fncls__24 == nil { var fncls__24d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_build_go_root_packages_fn__1901000101_A_fn_class = fncls__24d; tmp7 = fncls__24d } else { tmp7 = fncls__24 }; shas__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil) } else {
//line :197:1
			shas__8 = nil }; var valid__9 any; if


	jrt.J2g_Truth(index_file__6) {
		var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_79.GetRawRoot__O()); var tmp9 any = lang.PersistentArrayMap_EMPTY.Ref(); var tmp10 any; var iter__1927001039__auto____9 any; var tmp11 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(shas__8); var tmp12 *jrt.Class; var fncls__32 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class; if fncls__32 == nil { var fncls__32d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class = fncls__32d; tmp12 = fncls__32d } else { tmp12 = fncls__32 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil); tmp10 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_build_go_A_const_78.Invoke_O__O(index__7)); valid__9 = tmp8.Invoke_O_O__O(tmp9, tmp10) } else {
//line :200:1
			valid__9 = nil }; var covered__10 any; var tmp13 lang.IFn = /*line :186:1*/lang.IFn_Cast(A_arbace_build_go_A_const_89.GetRawRoot__O()); var tmp14 any; var iter__1927001039__auto____10 any; var tmp15 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New(); var tmp16 *jrt.Class; var fncls__37 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class; if

















	fncls__37 == nil { var fncls__37d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class = fncls__37d; tmp16 = fncls__37d } else { tmp16 = fncls__37 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); tmp14 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(valid__9); covered__10 = tmp13.Invoke_O__O(tmp14); var pf_index__11 any = /*line :186:1*/A_arbace_build_go_A_const_90.Invoke_O__O(index__7); var known_QMARK___12 any; var tmp17 any = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(index_file__6, pf_index__11, shas__8); var tmp18 *jrt.Class; var fncls__25 *jrt.Class = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class; if






	fncls__25 == nil { var fncls__25d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class = fncls__25d; tmp18 = fncls__25d } else { tmp18 = fncls__25 }; known_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var read_fn__13 any; var tmp19 lang.IFn = /*line :186:1*/lang.IFn_Cast(A_arbace_build_go_A_const_91.GetRawRoot__O()); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()); var tmp21 any = A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(covered__10, known_QMARK___12); var tmp22 *jrt.Class; var fncls__38 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000158_A_fn_class; if




















	fncls__38 == nil { var fncls__38d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_build_go_root_packages_fn__1901000158_A_fn_class = fncls__38d; tmp22 = fncls__38d } else { tmp22 = fncls__38 }; read_fn__13 = tmp19.Invoke_O__O(tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), files__4)); var pkg_file_QMARK___14 any; var tmp23 any = /*line :186:1*/A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(read_fn__13, known_QMARK___12, pf_index__11, shas__8); var tmp24 *jrt.Class; var fncls__26 *jrt.Class = A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class; if





















	fncls__26 == nil { var fncls__26d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class = fncls__26d; tmp24 = fncls__26d } else { tmp24 = fncls__26 }; pkg_file_QMARK___14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil); var pkgs__15 any; var tmp25 lang.IFn = /*line :186:1*/lang.IFn_Cast(A_arbace_build_go_A_const_44.GetRawRoot__O()); var tmp26 any; var iter__1927001039__auto____15 any; var tmp27 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(pkg_file_QMARK___14, read_fn__13, dir__0, valid__9); var tmp28 *jrt.Class; var fncls__45 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class; if























	fncls__45 == nil { var fncls__45d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class = fncls__45d; tmp28 = fncls__45d } else { tmp28 = fncls__45 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); tmp26 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__4); pkgs__15 = tmp25.Invoke_O__O(tmp26); if




	jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_97.GetRawRoot__O()).Invoke_O__O(pkgs__15)) {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref())).Ref()) }; var seq_1901000180__16 any = /*line :186:1*/lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_45.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_46, pkgs__15)); var chunk_1901000181__17 any; var count_1901000182__18 int64 = 0; var i_1901000183__19 int64 = 0; L1: for {






























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000183__19, count_1901000182__18) { var vec__1901000184__20 any = lang.Indexed_Cast(chunk_1901000181__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000183__19)); var path__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__22)), 1) {
				var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp30 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()); var tmp32 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp33 any = A_arbace_build_go_root_packages_fn__1901000187_A_New_O(dir__0); var tmp34 *jrt.Class; var fncls__46 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000187_A_fn_class
				if fncls__46 == nil { var fncls__46d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_build_go_root_packages_fn__1901000187_A_fn_class = fncls__46d; tmp34 = fncls__46d } else { tmp34 = fncls__46 }
//line :218:1
				tmp29.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp30, jrt.RefArrayOf(jrt.Object_class, nil, path__21, nil, tmp31.Invoke_O_O__O(Lit_87, tmp32.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil), ps__22)))).Ref())
//line :217:1
				seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } else { seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } } else { var temp__1927000414__auto____20 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000180__16); if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1901000180__21 any = temp__1927000414__auto____20; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000180__21)) { var c__1927000678__auto____22 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000180__21); seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000180__21), c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000189__22 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000180__21); var path__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__24)), 1) {
					var tmp35 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp36 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp37 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()); var tmp38 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp39 any = A_arbace_build_go_root_packages_fn__1901000192_A_New_O(dir__0); var tmp40 *jrt.Class; var fncls__47 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000192_A_fn_class
					if fncls__47 == nil { var fncls__47d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_build_go_root_packages_fn__1901000192_A_fn_class = fncls__47d; tmp40 = fncls__47d } else { tmp40 = fncls__47 }
//line :218:1
					tmp35.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp36, jrt.RefArrayOf(jrt.Object_class, nil, path__23, nil, tmp37.Invoke_O_O__O(Lit_87, tmp38.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp39, tmp40, nil), ps__24)))).Ref())
//line :217:1
					seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000180__21), nil, 0, 0; continue L1 } else { seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000180__21), nil, 0, 0; continue L1 } } } }
//line :186:1
			break L1 }; if

































	jrt.J2g_Truth(index_file__6) { var index_SINGLEQUOTE___16 any; var tmp41 any = A_arbace_build_go_A_const_90; var tmp42 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_79.GetRawRoot__O()); var tmp43 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp44 any; var iter__1927001039__auto____16 any; var tmp45 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(pkg_file_QMARK___14, shas__8); var tmp46 *jrt.Class
		var fncls__50 /*line :220:1*/*jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class

		if fncls__50 == nil { var fncls__50d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class = fncls__50d; tmp46 = fncls__50d } else { tmp46 = fncls__50 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp45, tmp46, nil); tmp44 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(files__4)
//line :220:1
		var tmp47 any = tmp42.Invoke_O_O__O(tmp43, tmp44); var tmp48 any = A_arbace_build_go_A_const_78; var tmp49 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_79.GetRawRoot__O()); var tmp50 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp51 any; var iter__1927001039__auto____16_2 any; var tmp52 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(shas__8); var tmp53 *jrt.Class
		var fncls__55 /*line :220:1*/*jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class




		if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class = fncls__55d; tmp53 = fncls__55d } else { tmp53 = fncls__55 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp52, tmp53, nil); tmp51 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(pkgs__15)
//line :220:1
		index_SINGLEQUOTE___16 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp41, tmp47, tmp48, tmp49.Invoke_O_O__O(tmp50, tmp51)))








		if lang.Util_Equiv_O_O__Z_NoInit(index_SINGLEQUOTE___16, index__7) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_98.GetRawRoot__O()).Invoke_O_O__O(index_file__6, index_SINGLEQUOTE___16) } }; return pkgs__15 }
//line :193:1
func A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_known_QMARK___1901000156_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_known_QMARK___1901000156_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :193:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Ctor_O_O_O(c__index_file, c__pf_index, c__shas any) { t.F_index_file = c__index_file; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :193:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Invoke_O_O__O(self, p1__1901000095_SHARP___1 any) any { var and__1927000168__auto____2 any = t.F_index_file; if












	jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_27.GetRawRoot__O()); var tmp2 any = t.F_pf_index; var tmp3 lang.IFn = lang.IFn_Cast(t.F_shas); return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000095_SHARP___1)).GetPath__String().Ref())) } else { return and__1927000168__auto____2 } }
//line :198:1
func A_arbace_build_go_root_packages_fn__1901000099_A_New() *A_arbace_build_go_root_packages_fn__1901000099_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000099_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Ctor() {}
//line :198:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Invoke_O_O__O(self, p1__1901000094_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000094_SHARP___1)).GetPath__String().Ref() }
func A_arbace_build_go_root_packages_fn__1901000101_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000101_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000101_A{}; t.Ctor_O(p0); return t }
//line :199:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :199:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Invoke_O_O__O(self, path__1 any) any { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_27.GetRawRoot__O()).Invoke_O_O__O(t.F_m, path__1)) { return lang.RT_Get_O_O__O_NoInit(t.F_m, path__1) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_88.GetRawRoot__O()).Invoke_O__O(jrt.File_New_String(jrt.String_Cast(path__1))) } }

func A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Invoke_O_O__O(self, s__1901000104__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(s__1901000104__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__31 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class; if fncls__31 == nil { var fncls__31d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class = fncls__31d; tmp2 = fncls__31d } else { tmp2 = fncls__31 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :201:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Ctor_O_O_O(c__s__1901000104, c__iter__1901000103, c__shas any) { t.F_s__1901000104 = c__s__1901000104; t.F_iter__1901000103 = c__iter__1901000103; t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Invoke_O__O(self any) any { { var s__1901000104__1 any; var t_ any = t.F_s__1901000104; t.F_s__1901000104 = nil; s__1901000104__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000104__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000104__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000104__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000104__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000106__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(b__1901000106__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp2 *jrt.Class; var fncls__29 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class; if fncls__29 == nil { var fncls__29d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class = fncls__29d; tmp2 = fncls__29d } else { tmp2 = fncls__29 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000106__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000104__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000106__6), nil) } } else { var vec__1901000120__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000104__3); var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_93.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(t.F_shas); var tmp6 *jrt.Class; var fncls__30 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class
															if fncls__30 == nil { var fncls__30d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class = fncls__30d; tmp6 = fncls__30d } else { tmp6 = fncls__30 }
//line :201:1
	if jrt.J2g_Truth(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), A_arbace_build_go_A_const_66.Invoke_O__O(e__6))) { var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); return lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(path__5, e__6), tmp7.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000104__3))) } else { s__1901000104__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000104__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :201:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Ctor_O_I_O_O(c__b__1901000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000106 = c__b__1901000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Invoke_O__O(self any) any { { var i__1901000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000105__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_93.GetRawRoot__O()); var tmp3 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(t.F_shas); var tmp4 *jrt.Class; var fncls__28 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class
																	if fncls__28 == nil { var fncls__28d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class = fncls__28d; tmp4 = fncls__28d } else { tmp4 = fncls__28 }
//line :201:1
	if jrt.J2g_Truth(tmp2.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil), A_arbace_build_go_A_const_66.Invoke_O__O(e__4))) { var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()); var tmp6 any = t.F_b__1901000106; tmp5.Invoke_O_O__O(tmp6, lang.Tuple_Create_O_O__IPersistentVector(path__3, e__4)); i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } else { i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Invoke_O_O__O(self, p__1901000113__1 any) any { var vec__1901000115__2 any = p__1901000113__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }
//line :202:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Invoke_O_O__O(self, p__1901000123__1 any) any { var vec__1901000125__2 any = p__1901000123__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }

func A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Ctor() {}
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Invoke_O_O__O(self, s__1901000132__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(self, s__1901000132__1); var tmp2 *jrt.Class; var fncls__36 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class; if fncls__36 == nil { var fncls__36d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class = fncls__36d; tmp2 = fncls__36d } else { tmp2 = fncls__36 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Ctor_O_O(c__iter__1901000131, c__s__1901000132 any) { t.F_iter__1901000131 = c__iter__1901000131; t.F_s__1901000132 = c__s__1901000132 }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Invoke_O__O(self any) any { { var s__1901000132__1 any; var t_ any = t.F_s__1901000132; t.F_s__1901000132 = nil; s__1901000132__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000132__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1901000139__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(xs__1927001018__auto____3); var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New(); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class; _ = ___5; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_build_go_A_const_66.Invoke_O__O(e__6))); if jrt.J2g_Truth(fs__1927001036__auto____8) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000131); return lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()).Invoke_O_O__O(fs__1927001036__auto____8, tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000132__1))) } else { s__1901000132__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000132__1); continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Ctor() {}
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Invoke_O_O__O(self, s__1901000134__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(self, s__1901000134__1); var tmp2 *jrt.Class; var fncls__34 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class; if fncls__34 == nil { var fncls__34d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class = fncls__34d; tmp2 = fncls__34d } else { tmp2 = fncls__34 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Ctor_O_O(c__iter__1901000133, c__s__1901000134 any) { t.F_iter__1901000133 = c__iter__1901000133; t.F_s__1901000134 = c__s__1901000134 }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Invoke_O__O(self any) any { { var s__1901000134__1 any; var t_ any = t.F_s__1901000134; t.F_s__1901000134 = nil; s__1901000134__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000134__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000134__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000134__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000134__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000136__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(b__1901000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__33 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class; if fncls__33 == nil { var fncls__33d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class = fncls__33d; tmp2 = fncls__33d } else { tmp2 = fncls__33 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000136__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000134__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000136__6), nil) } } else { var vec__1901000149__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000134__3); var rp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000149__4, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); return lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()).Invoke_O_O__O(rp__5, tmp4.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000134__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Ctor_O_I_O(c__b__1901000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000136 = c__b__1901000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Invoke_O__O(self any) any { { var i__1901000135__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000145__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000135__1)); var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000145__2, lang.RT_IntCast_J__I_NoInit(0), nil); lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()).Invoke_O_O__O(t.F_b__1901000136, rp__3); i__1901000135__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000135__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_fn__1901000158_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Ctor_O_O(c__covered, c__known_QMARK_ any) { t.F_covered = c__covered; t.F_known_QMARK_ = c__known_QMARK_ }
//line :207:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Invoke_O_O__O(self, p1__1901000096_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_17.GetRawRoot__O()); var tmp2 any; var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(p1__1901000096_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_covered); tmp2 = tmp3.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000096_SHARP___1)).GetPath__String().Ref()) } else { tmp2 = and__1927000168__auto____2 }; return tmp1.Invoke_O__O(tmp2) }
func A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :208:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Ctor_O_O_O_O(c__read_fn, c__known_QMARK_, c__pf_index, c__shas any) { t.F_read_fn = c__read_fn; t.F_known_QMARK_ = c__known_QMARK_; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :208:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Invoke_O_O__O(self, f__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(f__1)) { var tmp1 any = t.F_pf_index; var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__1)).GetPath__String().Ref())) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_92.GetRawRoot__O()).Invoke_O_O__O(f__1, t.F_read_fn) } }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Invoke_O_O__O(self, s__1901000163__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(t.F_pkg_file_QMARK_, t.F_read_fn, t.F_dir, t.F_valid, s__1901000163__1, self); var tmp2 *jrt.Class; var fncls__44 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class; if fncls__44 == nil { var fncls__44d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class = fncls__44d; tmp2 = fncls__44d } else { tmp2 = fncls__44 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :210:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Ctor_O_O_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid, c__s__1901000163, c__iter__1901000162 any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid; t.F_s__1901000163 = c__s__1901000163; t.F_iter__1901000162 = c__iter__1901000162 }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Invoke_O__O(self any) any { { var s__1901000163__1 any; var t_ any = t.F_s__1901000163; t.F_s__1901000163 = nil; s__1901000163__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000163__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000163__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000163__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000163__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000165__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(t.F_pkg_file_QMARK_, t.F_read_fn, b__1901000165__6, t.F_dir, t.F_valid, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__41 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class; if fncls__41 == nil { var fncls__41d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class = fncls__41d; tmp2 = fncls__41d } else { tmp2 = fncls__41 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000165__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000163__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000165__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000163__3); if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4)) { var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()); var tmp5 any; var tmp6 any = t.F_valid; var temp__1927000408__auto____5 any = lang.RT_Get_O_O__O_NoInit(tmp6, jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref())
															if jrt.J2g_Truth(temp__1927000408__auto____5) { var e__6 any = temp__1927000408__auto____5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_82.Invoke_O__O(e__6); var tmp9 any = A_arbace_build_go_A_const_50; var tmp10 any = A_arbace_build_go_A_const_66; var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_95.GetRawRoot__O()); var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New(); var tmp13 *jrt.Class; var fncls__43 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class
																if fncls__43 == nil { var fncls__43d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class = fncls__43d; tmp13 = fncls__43d } else { tmp13 = fncls__43 }; var tmp14 any = tmp11.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil), A_arbace_build_go_A_const_66.Invoke_O__O(e__6)); var tmp15 any = A_arbace_build_go_A_const_96; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(f__4, t.F_dir); var tmp17 *jrt.Class; var fncls__42 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class
																if fncls__42 == nil { var fncls__42d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class = fncls__42d; tmp17 = fncls__42d } else { tmp17 = fncls__42 }
//line :212:1
		tmp5 = tmp7.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp9, f__4, tmp10, tmp14, tmp15, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil))) } else {

			tmp5 = lang.IFn_Cast(A_arbace_build_go_A_const_94.GetRawRoot__O()).Invoke_O_O_O__O(t.F_dir, f__4, t.F_read_fn) }
//line :210:1
	var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); return tmp4.Invoke_O_O__O(tmp5, tmp18.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000163__3))) } else { s__1901000163__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000163__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :210:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Ctor_O_O_O_O_O_I_O(c__pkg_file_QMARK_, c__read_fn, c__b__1901000165, c__dir, c__valid any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_b__1901000165 = c__b__1901000165; t.F_dir = c__dir; t.F_valid = c__valid; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Invoke_O__O(self any) any { { var i__1901000164__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000164__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000164__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1901000165; var tmp4 any; var tmp5 any = t.F_valid; var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O_NoInit(tmp5, jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref())
																	if jrt.J2g_Truth(temp__1927000408__auto____3) { var e__4 any = temp__1927000408__auto____3; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp7 any = A_arbace_build_go_A_const_82.Invoke_O__O(e__4); var tmp8 any = A_arbace_build_go_A_const_50; var tmp9 any = A_arbace_build_go_A_const_66; var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_95.GetRawRoot__O()); var tmp11 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New(); var tmp12 *jrt.Class; var fncls__40 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class
																		if fncls__40 == nil { var fncls__40d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class = fncls__40d; tmp12 = fncls__40d } else { tmp12 = fncls__40 }; var tmp13 any = tmp10.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp11, tmp12, nil), A_arbace_build_go_A_const_66.Invoke_O__O(e__4)); var tmp14 any = A_arbace_build_go_A_const_96; var tmp15 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(f__2, t.F_dir); var tmp16 *jrt.Class; var fncls__39 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class
																		if fncls__39 == nil { var fncls__39d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class = fncls__39d; tmp16 = fncls__39d } else { tmp16 = fncls__39 }
//line :212:1
		tmp4 = tmp6.Invoke_O_O_O_O_O_O_O__O(tmp7, tmp8, f__2, tmp9, tmp13, tmp14, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil))) } else {

			tmp4 = lang.IFn_Cast(A_arbace_build_go_A_const_94.GetRawRoot__O()).Invoke_O_O_O__O(t.F_dir, f__2, t.F_read_fn) }
//line :210:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } else { i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Ctor() {}
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { return jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__1901000097_SHARP___1))) }
//line :212:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Ctor() {}
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { return jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(p1__1901000097_SHARP___1))) }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_94.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_dir; t.F_dir = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_f; t.F_f = nil; tmp4 = t__2; return tmp1.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_build_go_A_const_54.GetRawRoot__O()) }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_94.GetRawRoot__O()); var tmp2 any; var t_ any = t.F_dir; t.F_dir = nil; tmp2 = t_; var tmp3 any = tmp2; var tmp4 any; var t__2 any = t.F_f; t.F_f = nil; tmp4 = t__2; return tmp1.Invoke_O_O_O__O(tmp3, tmp4, A_arbace_build_go_A_const_54.GetRawRoot__O()) }





func A_arbace_build_go_root_packages_fn__1901000187_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000187_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000187_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_dir; return tmp1.Invoke_O_O__O(tmp2, A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000098_SHARP___1)) }
//line :219:1
func A_arbace_build_go_root_packages_fn__1901000192_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000192_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000192_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_dir; return tmp1.Invoke_O_O__O(tmp2, A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000098_SHARP___1)) }


func A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Ctor_O_O(c__pkg_file_QMARK_, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Invoke_O_O__O(self, s__1901000195__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(t.F_pkg_file_QMARK_, s__1901000195__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__49 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class; if fncls__49 == nil { var fncls__49d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class = fncls__49d; tmp2 = fncls__49d } else { tmp2 = fncls__49 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :222:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__s__1901000195, c__iter__1901000194, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_s__1901000195 = c__s__1901000195; t.F_iter__1901000194 = c__iter__1901000194; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Invoke_O__O(self any) any { { var s__1901000195__1 any; var t_ any = t.F_s__1901000195; t.F_s__1901000195 = nil; s__1901000195__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000195__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000195__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000195__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000195__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000197__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(t.F_pkg_file_QMARK_, b__1901000197__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp2 *jrt.Class; var fncls__48 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class; if fncls__48 == nil { var fncls__48d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class = fncls__48d; tmp2 = fncls__48d } else { tmp2 = fncls__48 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000197__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000195__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000197__6), nil) } } else { var f__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000195__3); var tmp4 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__5 any = tmp4.Invoke_O__O(jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__5) { var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); return lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(sha__5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4))).Ref()), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000195__3))) } else { s__1901000195__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000195__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :222:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Ctor_O_O_I_O_O(c__pkg_file_QMARK_, c__b__1901000197 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_b__1901000197 = c__b__1901000197; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Invoke_O__O(self any) any { { var i__1901000196__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__3 any = tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__3) { var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()); var tmp4 any = t.F_b__1901000197; tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O_O__IPersistentVector(sha__3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2))).Ref())); i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } else { i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Invoke_O_O__O(self, s__1901000205__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(s__1901000205__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__54 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class; if fncls__54 == nil { var fncls__54d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class = fncls__54d; tmp2 = fncls__54d } else { tmp2 = fncls__54 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Ctor_O_O_O(c__s__1901000205, c__iter__1901000204, c__shas any) { t.F_s__1901000205 = c__s__1901000205; t.F_iter__1901000204 = c__iter__1901000204; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Invoke_O__O(self any) any { { var s__1901000205__1 any; var t_ any = t.F_s__1901000205; t.F_s__1901000205 = nil; s__1901000205__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000205__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000205__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000205__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000205__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000207__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(b__1901000207__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp2 *jrt.Class; var fncls__52 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class; if fncls__52 == nil { var fncls__52d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class = fncls__52d; tmp2 = fncls__52d } else { tmp2 = fncls__52 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000207__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000205__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000207__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000205__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()); var tmp5 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(pkg__4))).GetPath__String().Ref(); var tmp6 any = A_arbace_build_go_A_const_66; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_95.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(t.F_shas); var tmp9 *jrt.Class
															var fncls__53 /*line :225:1*/*jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class

	if fncls__53 == nil { var fncls__53d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class = fncls__53d; tmp9 = fncls__53d } else { tmp9 = fncls__53 }
//line :225:1
	var tmp10 any = tmp7.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil), A_arbace_build_go_A_const_66.Invoke_O__O(pkg__4)); var tmp11 any = A_arbace_build_go_A_const_82; var tmp12 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); return tmp4.Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(tmp5, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp6, tmp10, tmp11, lang.IFn_Cast(A_arbace_build_go_A_const_99.GetRawRoot__O()).Invoke_O_O__O(pkg__4, A_arbace_build_go_A_const_101)))), tmp12.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000205__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Ctor_O_I_O_O(c__b__1901000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000207 = c__b__1901000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Invoke_O__O(self any) any { { var i__1901000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000206__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1901000207; var tmp4 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(pkg__2))).GetPath__String().Ref(); var tmp5 any = A_arbace_build_go_A_const_66; var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_95.GetRawRoot__O()); var tmp7 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(t.F_shas); var tmp8 *jrt.Class
																	var fncls__51 /*line :225:1*/*jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class

	if fncls__51 == nil { var fncls__51d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class = fncls__51d; tmp8 = fncls__51d } else { tmp8 = fncls__51 }
//line :225:1
	var tmp9 any = tmp6.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil), A_arbace_build_go_A_const_66.Invoke_O__O(pkg__2)); var tmp10 any = A_arbace_build_go_A_const_82; tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp9, tmp10, lang.IFn_Cast(A_arbace_build_go_A_const_99.GetRawRoot__O()).Invoke_O_O__O(pkg__2, A_arbace_build_go_A_const_100))))); i__1901000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }
//line :227:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }





func A_arbace_build_go_collected_package_A_New() *A_arbace_build_go_collected_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collected_package_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_build_go_collected_package_A) Ctor() {}
//line :233:1
func (t *A_arbace_build_go_collected_package_A) Invoke_O_O__O(self, pkg__0 any) any { var temp__1927000408__auto____2 any = A_arbace_build_go_A_const_96.Invoke_O__O(pkg__0); if



	jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var c__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_6.GetRawRoot__O()).Invoke_O__O(d__3)

		if lang.Util_Equiv_O_O__Z_NoInit(lang.IFn_Cast(A_arbace_build_go_A_const_99.GetRawRoot__O()).Invoke_O_O__O(c__4, A_arbace_build_go_A_const_102), lang.IFn_Cast(A_arbace_build_go_A_const_99.GetRawRoot__O()).Invoke_O_O__O(pkg__0, A_arbace_build_go_A_const_103)) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_56), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__0), nil)).Ref()) }
//line :237:1
		return c__4 } else { return pkg__0 } }






func A_arbace_build_go_read_program_edn_A_New() *A_arbace_build_go_read_program_edn_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_program_edn_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_build_go_read_program_edn_A) Ctor() {}
//line :244:1
func (t *A_arbace_build_go_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_130); if

	jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var forms__3 any = lang.IFn_Cast(A_arbace_build_go_A_const_54.GetRawRoot__O()).Invoke_O__O(f__2); var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(forms__3)))

		if and__1927000168__auto____4 { tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_68.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(forms__3)) } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_131) }
		return lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(forms__3) } else {
//line :246:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_build_go_run_A_New() *A_arbace_build_go_run_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_run_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_build_go_run_A) Ctor() {}
//line :253:1
func (t *A_arbace_build_go_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any = jrt.ProcessBuilder_New_List(jrt.List_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_29.GetRawRoot__O(), cmd__0)));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :253:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_1901000221__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(env__2); var chunk_1901000222__8 any; var count_1901000223__9 int64 = 0; var i_1901000224__10 int64 = 0; L1: for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000224__10, count_1901000223__9) { var vec__1901000225__11 any = lang.Indexed_Cast(chunk_1901000222__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000224__10)); var k__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000224__10); continue L1 } else { var temp__1927000414__auto____11 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000221__7); if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000221__12 any = temp__1927000414__auto____11; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000221__12)) { var c__1927000678__auto____13 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000221__12); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000221__12), c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000228__13 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000221__12); var k__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000221__12), nil, 0, 0; continue L1 } } }
//line :253:1
		break L1 }; if







	jrt.J2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :261:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())
//line :261:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_build_go_go_env_A_New() *A_arbace_build_go_go_env_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_env_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_build_go_go_env_A) Ctor() {}
//line :271:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z_NoInit(goos__2, Lit_28) { var tmp4 *lang.Keyword = A_arbace_build_go_A_const_46; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_64, tmp4.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()))) } else { tmp3 = nil }
//line :277:1
	var tmp5 any = tmp3; var tmp6 any
	var G__1901000232__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1901000232__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_65) { tmp6 = A_arbace_build_go_A_const_106; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_5) { tmp6 = A_arbace_build_go_A_const_107; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1901000232__4_)))))}
//line :277:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :271:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	return lang.IFn_Cast(A_arbace_build_go_A_const_108.GetRawRoot__O()).Invoke_O_O_O__O(goroot__0, arch__1, Lit_38)
}

























func A_arbace_build_go_go_mod_cache_A_New() *A_arbace_build_go_go_mod_cache_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_mod_cache_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_build_go_go_mod_cache_A) Ctor() {}
//line :302:1
func (t *A_arbace_build_go_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000234__2 any = lang.IFn_Cast(A_arbace_build_go_A_const_109.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_67, Lit_68), jrt.File_New_String(Lit_69), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_70, goroot__0, Lit_71, Lit_72)), jrt.Boolean_FALSE.Ref()); var status__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_57 any = status__3; if


	jrt.Long_InstanceOf(na_57) { var n0_58 int64 = jrt.NN(jrt.Long_Cast(na_57)).LongValue__J(); tmp1 = n0_58 == 0 } else { if jrt.Double_InstanceOf(na_57) { var n0_58_2 float64 = jrt.NN(jrt.Double_Cast(na_57)).DoubleValue__D(); tmp1 = n0_58_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_57) } }; if tmp1 { } else { lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; return /*line :306:1*/ lang.IFn_Cast(A_arbace_build_go_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(out__4)) }

func A_arbace_build_go_h1_of_file_A_New() *A_arbace_build_go_h1_of_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_build_go_h1_of_file_A) Ctor() {}
//line :308:1
func (t *A_arbace_build_go_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_A_New(); var tmp2 *jrt.Class; var fncls__65 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class; if


	fncls__65 == nil { var fncls__65d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class = fncls__65d; tmp2 = fncls__65d } else { tmp2 = fncls__65 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var sha__4 any; var tmp3 any = /*line :308:1*/A_arbace_build_go_h1_of_file_sha__1901000243_A_New(); var tmp4 *jrt.Class; var fncls__66 *jrt.Class = A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class; if



	fncls__66 == nil { var fncls__66d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class = fncls__66d; tmp4 = fncls__66d } else { tmp4 = fncls__66 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var summary__5 any = /*line :308:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :314:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_77, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.J2g_CastArray[*jrt.ByteArray](lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_52).Ref()), jrt.Prim_byte.ArrayClass())).Ref())).Ref() }
//line :311:1
func A_arbace_build_go_h1_of_file_hex__1901000239_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Invoke_O_O__O(self, b__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New(); var tmp5 *jrt.Class; var fncls__64 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class; if fncls__64 == nil { var fncls__64d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class = fncls__64d; tmp5 = fncls__64d } else { tmp5 = fncls__64 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), b__1)) }
//line :311:1
func A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Invoke_O_O__O(self, p1__1901000238_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_59 any = p1__1901000238_SHARP___1; var na_60 int64 = 255; if jrt.Long_InstanceOf(na_59) { var n0_61 int64 = jrt.NN(jrt.Long_Cast(na_59)).LongValue__J(); var n1_62 int64 = na_60; tmp2 = n0_61 & n1_62 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_59, na_60) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }
func A_arbace_build_go_h1_of_file_sha__1901000243_A_New() *A_arbace_build_go_h1_of_file_sha__1901000243_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_sha__1901000243_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Ctor() {}
//line :312:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51).Digest_B1__B1(jrt.J2g_CastArray[*jrt.ByteArray](b__1, jrt.Prim_byte.ArrayClass())).Ref() }



func A_arbace_build_go_tamago_go_sum_A_New() *A_arbace_build_go_tamago_go_sum_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_tamago_go_sum_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_build_go_tamago_go_sum_A) Ctor() {}
//line :316:1
func (t *A_arbace_build_go_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__1901000246__2 any = A_arbace_build_go_A_const_105.GetRawRoot__O(); var map__1901000246__3 any; if



	lang.ISeq_InstanceOf(map__1901000246__2) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1901000246__2)) { map__1901000246__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_build_go_A_const_111.GetRawRoot__O()).Invoke_O__O(map__1901000246__2), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1901000246__2)) { map__1901000246__3 = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1901000246__2) } else { map__1901000246__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000246__3 = map__1901000246__2 }; var path__4 any = /*line :316:1*/lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_46); var version__5 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_112); var zip__6 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_113); var mod__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_114); var dir__8 any = jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_169, nil, Lit_170), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(A_arbace_build_go_A_const_115.GetRawRoot__O()).Invoke_O__O(goroot__0), nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_171), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_172), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp1 bool; var and__1927000168__auto____11 bool = jrt.NN(jrt.File_Cast(zf__9)).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(mf__10)).IsFile__Z(); if and__1927000168__auto____12 { tmp1 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_173), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp1 = and__1927000168__auto____12 } } else { tmp1 = and__1927000168__auto____11 }; if tmp1 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_174, nil, Lit_175, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.NN(jrt.File_Cast(dir__8)).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any = /*line :316:1*/lang.IFn_Cast(A_arbace_build_go_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(zf__9)); var mh__13 any = lang.IFn_Cast(A_arbace_build_go_A_const_116.GetRawRoot__O()).Invoke_O_O__O(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(mf__10)).ToPath__Path()).Ref(), Lit_99); var tmp2 bool; var and__1927000168__auto____14 bool = lang.Util_Equiv_O_O__Z_NoInit(zh__12, zip__6); if and__1927000168__auto____14 {











				tmp2 = lang.Util_Equiv_O_O__Z_NoInit(mh__13, mod__7) } else { tmp2 = and__1927000168__auto____14 }; if tmp2 { } else {
					lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :330:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_build_go_toolchain_lang_A_New() *A_arbace_build_go_toolchain_lang_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_toolchain_lang_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_build_go_toolchain_lang_A) Ctor() {}
//line :332:1
func (t *A_arbace_build_go_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000249__2 any = lang.IFn_Cast(A_arbace_build_go_A_const_109.GetRawRoot__O()).Invoke_O_O_O_O__O(lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_67, Lit_177), jrt.File_New_String(Lit_69), lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_70, goroot__0, Lit_71, Lit_72)), jrt.Boolean_FALSE.Ref()); var status__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any = lang.IFn_Cast(A_arbace_build_go_A_const_110.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(out__4)); var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool; var na_67 any = status__3; if





	jrt.Long_InstanceOf(na_67) { var n0_68 int64 = jrt.NN(jrt.Long_Cast(na_67)).LongValue__J(); and__1927000168__auto____6 = n0_68 == 0 } else { if jrt.Double_InstanceOf(na_67) { var n0_68_2 float64 = jrt.NN(jrt.Double_Cast(na_67)).DoubleValue__D(); and__1927000168__auto____6 = n0_68_2 == 0.0 } else { and__1927000168__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_67) } }; if and__1927000168__auto____6 { temp__1927000408__auto____6 = lang.IFn_Cast(A_arbace_build_go_A_const_117.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_118, v__5) } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__1901000252__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___8; return l__9 } else {

		return lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_178, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_build_go_program_A_New() *A_arbace_build_go_program_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_build_go_program_A) Ctor() {}
//line :342:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__1901000259__2 any) any { var map__1901000260__4 any = p__1901000259__2; var map__1901000260__5 any; if lang.ISeq_InstanceOf(map__1901000260__4) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1901000260__4)) { map__1901000260__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_build_go_A_const_111.GetRawRoot__O()).Invoke_O__O(map__1901000260__4), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1901000260__4)) { map__1901000260__5 = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1901000260__4) } else { map__1901000260__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000260__5 = map__1901000260__4 }; var opts__6 any = map__1901000260__5; var library_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_119); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_120); var pkgs__9 any = lang.IFn_Cast(A_arbace_build_go_A_const_52.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, roots__8, A_arbace_build_go_A_const_127.Invoke_O__O(opts__6)); var mains__10 any; var G__1901000262__10_ any; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_program_fn__1901000263_A_New(); var tmp3 *jrt.Class; var fncls__69 *jrt.Class = A_arbace_build_go_program_fn__1901000263_A_fn_class; if










	fncls__69 == nil { var fncls__69d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_build_go_program_fn__1901000263_A_fn_class = fncls__69d; tmp3 = fncls__69d } else { tmp3 = fncls__69 }; G__1901000262__10_ = tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), pkgs__9); if jrt.J2g_Truth(A_arbace_build_go_A_const_121.Invoke_O__O(opts__6)) {
		var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_program_fn__1901000265_A_New_O(opts__6); var tmp6 *jrt.Class; var fncls__70 *jrt.Class = A_arbace_build_go_program_fn__1901000265_A_fn_class; if fncls__70 == nil { var fncls__70d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_build_go_program_fn__1901000265_A_fn_class = fncls__70d; tmp6 = fncls__70d } else { tmp6 = fncls__70 }; mains__10 = tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), G__1901000262__10_) } else {
//line :353:1
			mains__10 = G__1901000262__10_ }; var ___11 any; var tmp7 any; var or__1927000174__auto____11 bool = /*line :342:1*/lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(mains__10))); _ = ___11; if or__1927000174__auto____11 {












				tmp7 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 any = lang.IFn_Cast(A_arbace_build_go_A_const_97.GetRawRoot__O()).Invoke_O__O(mains__10); if jrt.J2g_Truth(or__1927000174__auto____13) { tmp7 = or__1927000174__auto____13 } else { tmp7 = A_arbace_build_go_A_const_122.Invoke_O__O(opts__6) } } else { tmp7 = and__1927000168__auto____12 } }; if jrt.J2g_Truth(tmp7) { ___11 = nil } else {
					var tmp8 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_120, nil, nil); var tmp10 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(mains__10)).Ref(); var tmp11 *jrt.String
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(mains__10)) { tmp11 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_86, nil), jrt.RefArrayOf(jrt.Object_class, nil, lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()).Invoke_O_O__O(Lit_87, lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_46, mains__10)))) } else { tmp11 = nil }
//line :356:1
					___11 = tmp8.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, tmp10, tmp11.Ref())).Ref()) }; var main__12 any = /*line :342:1*/lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(mains__10); var edn__13 any = lang.IFn_Cast(A_arbace_build_go_A_const_123.GetRawRoot__O()).Invoke_O__O(dir__0); var module__14 any; var or__1927000174__auto____14 any = A_arbace_build_go_A_const_122.Invoke_O__O(edn__13); if

















	jrt.J2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_build_go_A_const_122.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_build_go_A_const_46.Invoke_O__O(main__12); if jrt.J2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_121) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :342:1*/A_arbace_build_go_A_const_124.Invoke_O__O(edn__13); if





















	jrt.J2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_build_go_A_const_124.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z_NoInit(module__14, Lit_98) { golang__15 = nil } else { golang__15 = lang.IFn_Cast(A_arbace_build_go_A_const_125.GetRawRoot__O()).Invoke_O__O(goroot__1) } } }; var pkgs__16 any; var tmp12 lang.IFn = /*line :342:1*/lang.IFn_Cast(A_arbace_build_go_A_const_44.GetRawRoot__O()); var tmp13 any; var iter__1927001039__auto____16 any; var tmp14 any = A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(module__14); var tmp15 *jrt.Class; var fncls__73 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class; if






















	fncls__73 == nil { var fncls__73d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class = fncls__73d; tmp15 = fncls__73d } else { tmp15 = fncls__73 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); tmp13 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); pkgs__16 = tmp12.Invoke_O__O(tmp13); var tmp16 any = A_arbace_build_go_A_const_122; var tmp17 any = A_arbace_build_go_A_const_124; var tmp18 any = /*line :342:1*/lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(golang__15); var tmp19 any = A_arbace_build_go_A_const_78; var tmp20 any = A_arbace_build_go_A_const_126; var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()); var tmp22 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_15.GetRawRoot__O()); var tmp23 any = A_arbace_build_go_program_fn__1901000277_A_New(); var tmp24 *jrt.Class; var fncls__74 *jrt.Class = A_arbace_build_go_program_fn__1901000277_A_fn_class; if

































	fncls__74 == nil { var fncls__74d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_build_go_program_fn__1901000277_A_fn_class = fncls__74d; tmp24 = fncls__74d } else { tmp24 = fncls__74 }; return /*line :342:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp16, module__14, tmp17, tmp18, tmp19, pkgs__16, tmp20, tmp21.Invoke_O__O(tmp22.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp23, tmp24, nil), pkgs__16)))) }
//line :342:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {







	return lang.IFn_Cast(A_arbace_build_go_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, goroot__1, lang.PersistentArrayMap_EMPTY.Ref())
}

func A_arbace_build_go_program_fn__1901000263_A_New() *A_arbace_build_go_program_fn__1901000263_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000263_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Ctor() {}
//line :353:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Invoke_O_O__O(self, p1__1901000256_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_94, lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000256_SHARP___1)))).Ref() }
func A_arbace_build_go_program_fn__1901000265_A_New_O(p0 any) *A_arbace_build_go_program_fn__1901000265_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000265_A{}; t.Ctor_O(p0); return t }
//line :354:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :354:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Invoke_O_O__O(self, p1__1901000257_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_121.Invoke_O__O(t.F_opts), A_arbace_build_go_A_const_46.Invoke_O__O(p1__1901000257_SHARP___1))).Ref() }










func A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(p0 any) *A_arbace_build_go_program_iter__1901000267__1901000271_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Invoke_O_O__O(self, s__1901000268__1 any) any { var tmp1 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(self, t.F_module, s__1901000268__1); var tmp2 *jrt.Class; var fncls__72 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class; if fncls__72 == nil { var fncls__72d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class = fncls__72d; tmp2 = fncls__72d } else { tmp2 = fncls__72 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Ctor_O_O_O(c__iter__1901000267, c__module, c__s__1901000268 any) { t.F_iter__1901000267 = c__iter__1901000267; t.F_module = c__module; t.F_s__1901000268 = c__s__1901000268 }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Invoke_O__O(self any) any { { var s__1901000268__1 any; var t_ any = t.F_s__1901000268; t.F_s__1901000268 = nil; s__1901000268__1 = t_; for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000268__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000268__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000268__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000268__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000270__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(b__1901000270__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__71 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class; if fncls__71 == nil { var fncls__71d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class = fncls__71d; tmp2 = fncls__71d } else { tmp2 = fncls__71 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000270__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000268__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000270__6), nil) } } else { var pkg__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000268__3); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()); var tmp5 any; var path__5 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_98) {


		tmp5 = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__4, A_arbace_build_go_A_const_129, path__5) } else {
//line :367:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__5, t.F_module) {



				tmp5 = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__4, A_arbace_build_go_A_const_129, Lit_96) } else {
//line :367:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_128.GetRawRoot__O()).Invoke_O_O__O(path__5, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref())) {





						var tmp6 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp7 any = A_arbace_build_go_A_const_129; tmp5 = tmp6.Invoke_O_O_O__O(pkg__4, tmp7, lang.IFn_Cast(A_arbace_build_go_A_const_130.GetRawRoot__O()).Invoke_O_O__O(path__5, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref())) } else {
//line :367:1
							if A_arbace_build_go_A_const_13 != nil {






								tmp5 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :367:1
									tmp5 = nil } } } }
//line :365:1
	var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); return tmp4.Invoke_O_O__O(tmp5, tmp8.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000268__3))) } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Ctor_O_I_O_O(c__b__1901000270 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__1901000270 = c__b__1901000270; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Invoke_O__O(self any) any { { var i__1901000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000269__1)); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1901000270; var tmp4 any; var path__3 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_98) {


		tmp4 = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__2, A_arbace_build_go_A_const_129, path__3) } else {
//line :367:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__3, t.F_module) {



				tmp4 = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(pkg__2, A_arbace_build_go_A_const_129, Lit_96) } else {
//line :367:1
					if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_128.GetRawRoot__O()).Invoke_O_O__O(path__3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref())) {





						var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_build_go_A_const_129; tmp4 = tmp5.Invoke_O_O_O__O(pkg__2, tmp6, lang.IFn_Cast(A_arbace_build_go_A_const_130.GetRawRoot__O()).Invoke_O_O__O(path__3, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref())) } else {
//line :367:1
							if A_arbace_build_go_A_const_13 != nil {






								tmp4 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :367:1
									tmp4 = nil } } } }
//line :365:1
	tmp2.Invoke_O_O__O(tmp3, tmp4); i__1901000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000269__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_build_go_program_fn__1901000277_A_New() *A_arbace_build_go_program_fn__1901000277_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000277_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Ctor() {}
//line :376:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Invoke_O_O__O(self, p1__1901000258_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_94, lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000258_SHARP___1)))).Ref() }




func A_arbace_build_go_sha256_A_New() *A_arbace_build_go_sha256_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_build_go_sha256_A) Ctor() {}
//line :381:1
func (t *A_arbace_build_go_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_56.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_sha256_fn__1901000281_A_New(); var tmp5 *jrt.Class; var fncls__80 *jrt.Class = A_arbace_build_go_sha256_fn__1901000281_A_fn_class; if

	fncls__80 == nil { var fncls__80d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_build_go_sha256_fn__1901000281_A_fn_class = fncls__80d; tmp5 = fncls__80d } else { tmp5 = fncls__80 }; return tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil), jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref())) }
//line :383:1
func A_arbace_build_go_sha256_fn__1901000281_A_New() *A_arbace_build_go_sha256_fn__1901000281_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_fn__1901000281_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Ctor() {}
//line :383:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Invoke_O_O__O(self, p1__1901000280_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_75 any = p1__1901000280_SHARP___1; var na_76 int64 = 255; if jrt.Long_InstanceOf(na_75) { var n0_77 int64 = jrt.NN(jrt.Long_Cast(na_75)).LongValue__J(); var n1_78 int64 = na_76; tmp2 = n0_77 & n1_78 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_75, na_76) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_copy_file_A_New() *A_arbace_build_go_copy_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_copy_file_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_build_go_copy_file_A) Ctor() {}
//line :385:1
func (t *A_arbace_build_go_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_132.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_133; var tmp5 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp5 = jrt.StandardCopyOption_REPLACE_EXISTING; return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.J2g_CastArray[*jrt.RefArray](tmp3.Invoke_O_O__O(tmp4, lang.Tuple_Create_O__IPersistentVector(tmp5.Ref())), jrt.CopyOption_class.ArrayClass()))
}

func A_arbace_build_go_forms_dir_A_New() *A_arbace_build_go_forms_dir_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_forms_dir_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_build_go_forms_dir_A) Ctor() {}
//line :390:1
func (t *A_arbace_build_go_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_build_go_A_const_50.Invoke_O__O(pkg__0); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_130.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_134; return jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__2)).GetParentFile__File(), jrt.String_Cast(tmp1.Invoke_O_O_O__O(n__3, tmp2, jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref()))) }







func A_arbace_build_go_with_line_files_A_New() *A_arbace_build_go_with_line_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_A{}; t.Ctor(); return t }
//line :398:1
func (t *A_arbace_build_go_with_line_files_A) Ctor() {}
//line :398:1
func (t *A_arbace_build_go_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any = lang.IFn_Cast(A_arbace_build_go_A_const_135.GetRawRoot__O()).Invoke_O__O(pkg__0); var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_136; var tmp3 any = A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(fdir__2); var tmp4 *jrt.Class; var fncls__83 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class; if






	fncls__83 == nil { var fncls__83d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class = fncls__83d; tmp4 = fncls__83d } else { tmp4 = fncls__83 }; return tmp1.Invoke_O_O_O__O(pkg__0, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_95.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(t.F_fdir); var tmp3 *jrt.Class; var fncls__82 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class; if fncls__82 == nil { var fncls__82d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class = fncls__82d; tmp3 = fncls__82d } else { tmp3 = fncls__82 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Invoke_O_O__O(self, p1__1901000286_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_137; var tmp3 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(t.F_fdir); var tmp4 *jrt.Class; var fncls__81 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class; if fncls__81 == nil { var fncls__81d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class = fncls__81d; tmp4 = fncls__81d } else { tmp4 = fncls__81 }; return tmp1.Invoke_O_O_O__O(p1__1901000286_SHARP___1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Invoke_O_O__O(self, s__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()); var tmp2 any = t.F_fdir; return tmp1.Invoke_O_O__O(tmp2, jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(s__1)))) }



func A_arbace_build_go_print_cache_key_A_New() *A_arbace_build_go_print_cache_key_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_build_go_print_cache_key_A) Ctor() {}
//line :409:1
func (t *A_arbace_build_go_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51); var add__7 any; var tmp1 any = A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(md__6); var tmp2 *jrt.Class; var fncls__84 *jrt.Class = A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class; if





	fncls__84 == nil { var fncls__84d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class = fncls__84d; tmp2 = fncls__84d } else { tmp2 = fncls__84 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0);
	lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(A_arbace_build_go_A_const_138.Invoke_O__O(opts__3), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_build_go_A_const_139.Invoke_O__O(opts__3))).Ref(), jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tests__4)).Ref(), A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1), lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_36.Invoke_O__O(pkg__1))))); var seq_1901000297__8 any = /*line :409:1*/lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_66.Invoke_O__O(pkg__1)); var chunk_1901000298__9 any; var count_1901000299__10 int64 = 0; var i_1901000300__11 int64 = 0; L1: for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000300__11, count_1901000299__10) { var f__12 any = lang.Indexed_Cast(chunk_1901000298__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000300__11))
			lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__2, f__12))
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__12)).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_96)
//line :418:1
			seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000300__11); continue L1 } else { var temp__1927000414__auto____12 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000297__8); if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1901000297__13 any = temp__1927000414__auto____12; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000297__13)) { var c__1927000678__auto____14 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000297__13); seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000297__13), c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__14 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000297__13)
				lang.IFn_Cast(add__7).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()).Invoke_O_O__O(dir__2, f__14))
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__14)).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_96)
//line :418:1
				seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000297__13), nil, 0, 0; continue L1 } } }
//line :409:1
		break L1 }; var tmp3 lang.IFn =












	lang.IFn_Cast(A_arbace_build_go_A_const_56.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp6 any = A_arbace_build_go_print_cache_key_fn__1901000301_A_New(); var tmp7 *jrt.Class; var fncls__90 *jrt.Class = A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class; if fncls__90 == nil { var fncls__90d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class = fncls__90d; tmp7 = fncls__90d } else { tmp7 = fncls__90 }; return tmp3.Invoke_O_O__O(tmp4, tmp5.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil), jrt.MessageDigest_Cast(md__6).Digest__B1().Ref())) }
//line :415:1
func A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(p0 any) *A_arbace_build_go_print_cache_key_add__1901000295_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_add__1901000295_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :415:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_52)); return nil }






func A_arbace_build_go_print_cache_key_fn__1901000301_A_New() *A_arbace_build_go_print_cache_key_fn__1901000301_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_fn__1901000301_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Ctor() {}
//line :422:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Invoke_O_O__O(self, p1__1901000294_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_85 any = p1__1901000294_SHARP___1; var na_86 int64 = 255; if jrt.Long_InstanceOf(na_85) { var n0_87 int64 = jrt.NN(jrt.Long_Cast(na_85)).LongValue__J(); var n1_88 int64 = na_86; tmp2 = n0_87 & n1_88 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_85, na_86) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_cached_texts_A_New() *A_arbace_build_go_cached_texts_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_A{}; t.Ctor(); return t }
//line :424:1
func (t *A_arbace_build_go_cached_texts_A) Ctor() {}
//line :424:1
func (t *A_arbace_build_go_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_42); if





	jrt.NN(jrt.File_Cast(names__2)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(entry__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_79.GetRawRoot__O()); var tmp2 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var tmp3 any; var iter__1927001039__auto____3 any; var tmp4 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(entry__0); var tmp5 *jrt.Class; var fncls__93 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class
		if fncls__93 == nil { var fncls__93d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class = fncls__93d; tmp5 = fncls__93d } else { tmp5 = fncls__93 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); tmp3 = lang.IFn_Cast(iter__1927001039__auto____3).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_140.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(names__2)))
//line :432:1
		return tmp1.Invoke_O_O__O(tmp2, tmp3) } else {
//line :430:1
			return nil } }


func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(p0 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A{}; t.Ctor_O(p0); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Invoke_O_O__O(self, s__1901000305__1 any) any { var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(s__1901000305__1, self, t.F_entry); var tmp2 *jrt.Class; var fncls__92 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class; if fncls__92 == nil { var fncls__92d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class = fncls__92d; tmp2 = fncls__92d } else { tmp2 = fncls__92 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :433:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Ctor_O_O_O(c__s__1901000305, c__iter__1901000304, c__entry any) { t.F_s__1901000305 = c__s__1901000305; t.F_iter__1901000304 = c__iter__1901000304; t.F_entry = c__entry }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Invoke_O__O(self any) any { { var s__1901000305__1 any; var t_ any = t.F_s__1901000305; t.F_s__1901000305 = nil; s__1901000305__1 = t_; L1: for { var temp__1927000414__auto____2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(s__1901000305__1); if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000305__3 any = temp__1927000414__auto____2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(s__1901000305__3)) { var c__1927001037__auto____4 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(s__1901000305__3); var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000307__6 any = lang.IFn_Cast(A_arbace_build_go_A_const_34.GetRawRoot__O()).Invoke_O__O(jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref()); var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(b__1901000307__6, t.F_entry, size__1927001038__auto____5, c__1927001037__auto____4); var tmp2 *jrt.Class; var fncls__91 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class; if fncls__91 == nil { var fncls__91d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class = fncls__91d; tmp2 = fncls__91d } else { tmp2 = fncls__91 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O()) { var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000307__6), tmp3.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(s__1901000305__3))) } else { return lang.IFn_Cast(A_arbace_build_go_A_const_38.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_40.GetRawRoot__O()).Invoke_O__O(b__1901000307__6), nil) } } else { var n__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(s__1901000305__3); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(n__4)) { var tmp4 *jrt.File = jrt.File_Cast(t.F_entry); var tmp5 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); return lang.IFn_Cast(A_arbace_build_go_A_const_39.GetRawRoot__O()).Invoke_O_O__O(lang.Tuple_Create_O_O__IPersistentVector(n__4, jrt.File_New_File_String(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4)))), tmp5.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000305__3))) } else { s__1901000305__1 = lang.IFn_Cast(A_arbace_build_go_A_const_42.GetRawRoot__O()).Invoke_O__O(s__1901000305__3); continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :433:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Ctor_O_O_I_O(c__b__1901000307, c__entry any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000307 = c__b__1901000307; t.F_entry = c__entry; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Invoke_O__O(self any) any { { var i__1901000306__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000306__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000306__1)); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(n__2)) { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_37.GetRawRoot__O()); var tmp3 any = t.F_b__1901000307; var tmp4 *jrt.File = jrt.File_Cast(t.F_entry); tmp2.Invoke_O_O__O(tmp3, lang.Tuple_Create_O_O__IPersistentVector(n__2, jrt.File_New_File_String(tmp4, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2))))); i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } else { i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_cache_texts_BANG__A_New() *A_arbace_build_go_cache_texts_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Ctor() {}
//line :436:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.NN(jrt.File_Cast(entry__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(entry__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__3)).Mkdirs__Z()); var seq_1901000316__4 any = /*line :436:1*/lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(texts__1); var chunk_1901000317__5 any; var count_1901000318__6 int64 = 0; var i_1901000319__7 int64 = 0; L1: for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000319__7, count_1901000318__6) { var vec__1901000320__8 any = lang.Indexed_Cast(chunk_1901000317__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000319__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000319__7); continue L1 } else { var temp__1927000414__auto____8 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000316__4); if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1901000316__9 any = temp__1927000414__auto____8; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000316__9)) { var c__1927000678__auto____10 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000316__9); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000316__9), c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000323__10 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000316__9); var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000316__9), nil, 0, 0; continue L1 } } }
//line :436:1
		break L1 }; var tmp1 lang.IFn =





	lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp2 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_42); var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New(); var tmp6 *jrt.Class; var fncls__94 *jrt.Class = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class; if fncls__94 == nil { var fncls__94d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class = fncls__94d; tmp6 = fncls__94d } else { tmp6 = fncls__94 }; tmp1.Invoke_O_O__O(tmp2, tmp3.Invoke_O__O(tmp4.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil), lang.IFn_Cast(A_arbace_build_go_A_const_142.GetRawRoot__O()).Invoke_O__O(texts__1)))); if
	jrt.NN(jrt.File_Cast(tmp__3)).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { return lang.IFn_Cast(A_arbace_build_go_A_const_141.GetRawRoot__O()).Invoke_O__O(tmp__3) } }
//line :442:1
func A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New() *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__fn__1901000326_A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Ctor() {}
//line :442:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Invoke_O_O__O(self, p1__1901000315_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, p1__1901000315_SHARP___1, nil)).Ref() }


func A_arbace_build_go_print_module_A_New() *A_arbace_build_go_print_module_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_build_go_print_module_A) Ctor() {}
//line :445:1
func (t *A_arbace_build_go_print_module_A) Invoke_O_O_O_O_O__O(self, p__1901000331__0, dir__1, out__2, p__1901000332__3 any) any { var map__1901000333__5 any = p__1901000331__0; var map__1901000333__6 any; if lang.ISeq_InstanceOf(map__1901000333__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1901000333__5)) { map__1901000333__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_build_go_A_const_111.GetRawRoot__O()).Invoke_O__O(map__1901000333__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1901000333__5)) { map__1901000333__6 = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1901000333__5) } else { map__1901000333__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000333__6 = map__1901000333__5 }; var module__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_122); var packages__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_78); var golang__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_124); var map__1901000335__10 any = p__1901000332__3; var map__1901000335__11 any; if lang.ISeq_InstanceOf(map__1901000335__10) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1901000335__10)) { map__1901000335__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_build_go_A_const_111.GetRawRoot__O()).Invoke_O__O(map__1901000335__10), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1901000335__10)) { map__1901000335__11 = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1901000335__10) } else { map__1901000335__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000335__11 = map__1901000335__10 }; var layout__12 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_138); var line_file__13 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_139); var tests__14 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_143); var goos__15 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_144); var goroot__16 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_145); var goos_dir__17 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_146); var print_cache__18 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_127);









	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(out__2)).Mkdirs__Z()); if
	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_98) { } else {
		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp2 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_99); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil, Lit_101, nil, Lit_44, nil); var tmp4 *jrt.String
		if lang.Util_Equiv_O_O__Z_NoInit(goos__15, Lit_28) {
			var tmp5 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_103, nil, Lit_44, nil); var tmp6 *lang.Keyword = A_arbace_build_go_A_const_46; var tmp7 any = tmp6.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp8 *lang.Keyword = A_arbace_build_go_A_const_112; var tmp9 any = tmp8.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp10 *jrt.String

			if jrt.J2g_Truth(goos_dir__17) {
				var tmp11 *lang.Keyword = A_arbace_build_go_A_const_46; var tmp12 *lang.Keyword = A_arbace_build_go_A_const_112; tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, nil, tmp11.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()), nil, tmp12.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()), nil, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(goos_dir__17))).GetAbsoluteFile__File()).GetPath__String().Ref(), nil)) } else {
//line :461:1
					tmp10 = nil }
//line :459:1
			tmp4 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp5, jrt.RefArrayOf(jrt.Object_class, nil, tmp7, nil, tmp9, nil, tmp10.Ref())) } else {
//line :458:1
				tmp4 = nil }
//line :457:1
		tmp1.Invoke_O_O__O(tmp2, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__9, nil, tmp4.Ref())).Ref()) }; var tmp13 any; var and__1927000168__auto____19 bool =







	lang.Util_Equiv_O_O__Z_NoInit(goos__15, Lit_28); if and__1927000168__auto____19 { tmp13 = lang.IFn_Cast(A_arbace_build_go_A_const_17.GetRawRoot__O()).Invoke_O__O(goos_dir__17) } else { tmp13 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }; if jrt.J2g_Truth(tmp13) {
		lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_104), lang.IFn_Cast(A_arbace_build_go_A_const_147.GetRawRoot__O()).Invoke_O__O(goroot__16)) }; var tmp14 lang.IFn =
	lang.IFn_Cast(A_arbace_build_go_A_const_44.GetRawRoot__O()); var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp16 any; if
	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_98) { tmp16 = nil } else { tmp16 = A_arbace_build_go_A_const_148 }; var tmp17 any = tmp16; var tmp18 lang.IFn = /*line :467:1*/lang.IFn_Cast(A_arbace_build_go_A_const_56.GetRawRoot__O()); var tmp19 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_55.GetRawRoot__O()); var tmp21 any = A_arbace_build_go_print_module_fn__1901000337_A_New_O_O_O_O_O_O(dir__1, out__2, tests__14, line_file__13, layout__12, print_cache__18); var tmp22 *jrt.Class; var fncls__99 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_A_fn_class; if


	fncls__99 == nil { var fncls__99d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_build_go_print_module_fn__1901000337_A_fn_class = fncls__99d; tmp22 = fncls__99d } else { tmp22 = fncls__99 }; return /*line :467:1*/ tmp14.Invoke_O__O(tmp15.Invoke_O_O__O(tmp17, tmp18.Invoke_O_O__O(tmp19, tmp20.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp21, tmp22, nil), packages__8)))) }


func A_arbace_build_go_print_module_fn__1901000337_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_print_module_fn__1901000337_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :470:1
func (t *A_arbace_build_go_print_module_fn__1901000337_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :470:1
func (t *A_arbace_build_go_print_module_fn__1901000337_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z_NoInit(Lit_96, A_arbace_build_go_A_const_129.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_build_go_A_const_129.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__1901000338__3_ any; var tmp2 any = A_arbace_build_go_A_const_138; var tmp3 any; var or__1927000174__auto____3 any = /*line :470:1*/t.F_layout; if

	jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.J2g_Truth(t.F_line_file) { tmp3 = A_arbace_build_go_A_const_149 } else { tmp3 = A_arbace_build_go_A_const_150 } }; G__1901000338__3_ = /*line :470:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.J2g_Truth(t.F_line_file) {
		opts__3 = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(G__1901000338__3_, A_arbace_build_go_A_const_139, jrt.Boolean_TRUE.Ref()) } else {
//line :472:1
			opts__3 = G__1901000338__3_ }; var tmp4 /*line :470:1*/*lang.Keyword = A_arbace_build_go_A_const_155; var test_files__4 any = lang.IFn_Cast(A_arbace_build_go_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_29.GetRawRoot__O(), tmp4.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1)))); var printable__5 any; var tmp5 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_New_O_O(test_files__4, t.F_tests); var tmp6 *jrt.Class; var fncls__97 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class; if
	fncls__97 == nil { var fncls__97d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class = fncls__97d; tmp6 = fncls__97d } else { tmp6 = fncls__97 }; printable__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var host_id__6 any = /*line :470:1*/jrt.System_Getenv_String__String(Lit_107).Ref(); var entry__7 any; var tmp7 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.J2g_Truth(and__1927000168__auto____7) { tmp7 = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(host_id__6) } else { tmp7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp7) { var k__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_152.GetRawRoot__O()).Invoke_O_O_O_O_O__O(host_id__6, pkg__1, t.F_dir, opts__3, t.F_tests); var tmp8 *jrt.Class = A_arbace_build_go_A_const_67; entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp8, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(t.F_print_cache)), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_130.GetRawRoot__O()).Invoke_O_O_O__O(k__7, A_arbace_build_go_A_const_134, A_arbace_build_go_A_const_156))), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.J2g_Truth(entry__7) { or__1927000174__auto____8 = lang.IFn_Cast(A_arbace_build_go_A_const_153.GetRawRoot__O()).Invoke_O__O(entry__7) } else { or__1927000174__auto____8 = nil }; if jrt.J2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_154.GetRawRoot__O()); var tmp10 any; var G__1901000345__9_ any = lang.IFn_Cast(printable__5).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_158.GetRawRoot__O()).Invoke_O__O(pkg__1))
		if jrt.J2g_Truth(t.F_line_file) { tmp10 = lang.IFn_Cast(A_arbace_build_go_A_const_157.GetRawRoot__O()).Invoke_O__O(G__1901000345__9_) } else { tmp10 = G__1901000345__9_ }; t__9 = tmp9.Invoke_O_O__O(tmp10, opts__3)
		if jrt.J2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(entry__7)).GetParentFile__File()).Mkdirs__Z())
			lang.IFn_Cast(A_arbace_build_go_A_const_159.GetRawRoot__O()).Invoke_O_O__O(entry__7, t__9) }
//line :482:1
		texts__8 = t__9 }; var declared__9 any; var tmp11 /*line :470:1*/*lang.Keyword = A_arbace_build_go_A_const_136; var temp__1927000414__auto____9 any = tmp11.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1)); if

















	jrt.J2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp13 any
		if jrt.J2g_Truth(t.F_tests) { var tmp14 *lang.Keyword = A_arbace_build_go_A_const_155; tmp13 = tmp14.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1)) } else { tmp13 = nil }; declared__9 = tmp12.Invoke_O_O__O(fs__10, tmp13) } else {
//line :488:1
			declared__9 = nil }; var rel__10 any; var tmp15 any = /*line :470:1*/A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_New_O(pkg__1); var tmp16 *jrt.Class; var fncls__98 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class; if
	fncls__98 == nil { var fncls__98d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class = fncls__98d; tmp16 = fncls__98d } else { tmp16 = fncls__98 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp15, tmp16, nil); var src__11 any = /*line :470:1*/lang.IFn_Cast(A_arbace_build_go_A_const_135.GetRawRoot__O()).Invoke_O__O(pkg__1); var tmp17 any; var and__1927000168__auto____12 any = declared__9; if





















	jrt.J2g_Truth(and__1927000168__auto____12) { tmp17 = lang.IFn_Cast(A_arbace_build_go_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_29.GetRawRoot__O(), declared__9)), lang.IFn_Cast(A_arbace_build_go_A_const_89.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_142.GetRawRoot__O()).Invoke_O__O(texts__8))) } else { tmp17 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp17) {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_109, nil, Lit_110, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1), nil, lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(declared__9), nil, lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_44.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_142.GetRawRoot__O()).Invoke_O__O(texts__8))))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(pdir__2)).Mkdirs__Z()); var seq_1901000348__12 any = /*line :470:1*/lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(texts__8); var chunk_1901000349__13 any; var count_1901000350__14 int64 = 0; var i_1901000351__15 int64 = 0; L1: for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000351__15, count_1901000350__14) { var vec__1901000352__16 any = lang.Indexed_Cast(chunk_1901000349__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000351__15)); var n__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000352__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000352__16, lang.RT_IntCast_J__I_NoInit(1), nil)
			if jrt.File_InstanceOf(text__18) {
				lang.IFn_Cast(A_arbace_build_go_A_const_160.GetRawRoot__O()).Invoke_O_O__O(text__18, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17))) } else {
					lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18) }
//line :496:1
			seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000351__15); continue L1 } else { var temp__1927000414__auto____16 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000348__12); if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1901000348__17 any = temp__1927000414__auto____16; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000348__17)) { var c__1927000678__auto____18 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000348__17); seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000348__17), c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000355__18 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000348__17); var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000355__18, lang.RT_IntCast_J__I_NoInit(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000355__18, lang.RT_IntCast_J__I_NoInit(1), nil)
				if jrt.File_InstanceOf(text__20) {
					lang.IFn_Cast(A_arbace_build_go_A_const_160.GetRawRoot__O()).Invoke_O_O__O(text__20, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19))) } else {
						lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20) }
//line :496:1
				seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000348__17), nil, 0, 0; continue L1 } } }
//line :470:1
		break L1 }; var tmp18 *lang.Keyword = A_arbace_build_go_A_const_161; var seq_1901000358__12 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(tmp18.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1))); var chunk_1901000359__13 any; var count_1901000360__14 int64 = 0; var i_1901000361__15 int64 = 0; L2: for {





























			if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000361__15, count_1901000360__14) { var f__16 any = lang.Indexed_Cast(chunk_1901000359__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000361__15))
				lang.IFn_Cast(A_arbace_build_go_A_const_160.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__16))), jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__16))))
//line :500:1
				seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000361__15); continue L2 } else { var temp__1927000414__auto____16_2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000358__12); if jrt.J2g_Truth(temp__1927000414__auto____16_2) { var seq_1901000358__17 any = temp__1927000414__auto____16_2; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000358__17)) { var c__1927000678__auto____18_2 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000358__17); seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000358__17), c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var f__18 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000358__17)
					lang.IFn_Cast(A_arbace_build_go_A_const_160.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__18))), jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__18))))
//line :500:1
					seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000358__17), nil, 0, 0; continue L2 } } }
//line :470:1
			break L2 }; var tmp19 *lang.Keyword = A_arbace_build_go_A_const_162; var seq_1901000362__12 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(tmp19.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1))); var chunk_1901000363__13 any; var count_1901000364__14 int64 = 0; var i_1901000365__15 int64 = 0; L3: for {































				if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000365__15, count_1901000364__14) { var vec__1901000366__16 any = lang.Indexed_Cast(chunk_1901000363__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000365__15)); var f__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000366__16, lang.RT_IntCast_J__I_NoInit(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000366__16, lang.RT_IntCast_J__I_NoInit(1), nil); var from__19 any = jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__17)))

					if jrt.NN(jrt.File_Cast(from__19)).IsFile__Z() { } else {
						lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1), nil, lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, from__19))).Ref()) }
					var tmp20 any; var and__1927000168__auto____20 any = h__18; if jrt.J2g_Truth(and__1927000168__auto____20) { tmp20 = lang.IFn_Cast(A_arbace_build_go_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_163.GetRawRoot__O()).Invoke_O__O(from__19), lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(h__18)) } else { tmp20 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp20) {
						lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1), nil, f__17, nil, lang.IFn_Cast(A_arbace_build_go_A_const_163.GetRawRoot__O()).Invoke_O__O(from__19), nil, h__18)).Ref())
					}
					lang.IFn_Cast(A_arbace_build_go_A_const_160.GetRawRoot__O()).Invoke_O_O__O(from__19, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__17))))
//line :502:1
					seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000365__15); continue L3 } else { var temp__1927000414__auto____16_3 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000362__12); if jrt.J2g_Truth(temp__1927000414__auto____16_3) { var seq_1901000362__17 any = temp__1927000414__auto____16_3; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000362__17)) { var c__1927000678__auto____18_3 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000362__17); seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000362__17), c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1901000369__18 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000362__17); var f__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000369__18, lang.RT_IntCast_J__I_NoInit(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000369__18, lang.RT_IntCast_J__I_NoInit(1), nil); var from__21 any = jrt.File_New_File_String(jrt.File_Cast(src__11), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__19)))

						if jrt.NN(jrt.File_Cast(from__21)).IsFile__Z() { } else {
							lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1), nil, lang.IFn_Cast(A_arbace_build_go_A_const_65.GetRawRoot__O()).Invoke_O_O__O(t.F_dir, from__21))).Ref()) }
						var tmp21 any; var and__1927000168__auto____22 any = h__20; if jrt.J2g_Truth(and__1927000168__auto____22) { tmp21 = lang.IFn_Cast(A_arbace_build_go_A_const_35.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_163.GetRawRoot__O()).Invoke_O__O(from__21), lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(h__20)) } else { tmp21 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp21) {
							lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113, nil, Lit_114, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1), nil, f__19, nil, lang.IFn_Cast(A_arbace_build_go_A_const_163.GetRawRoot__O()).Invoke_O__O(from__21), nil, h__20)).Ref())
						}
						lang.IFn_Cast(A_arbace_build_go_A_const_160.GetRawRoot__O()).Invoke_O_O__O(from__21, jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__19))))
//line :502:1
						seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000362__17), nil, 0, 0; continue L3 } } }
//line :470:1
				break L3 }; var tmp22 /*line :510:1*/*lang.Keyword = A_arbace_build_go_A_const_161; var tmp23 *lang.Keyword = A_arbace_build_go_A_const_162; return lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(rel__10, lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_142.GetRawRoot__O()).Invoke_O__O(texts__8), lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_29.GetRawRoot__O(), tmp22.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1))), lang.IFn_Cast(A_arbace_build_go_A_const_49.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_29.GetRawRoot__O(), A_arbace_build_go_A_const_20.GetRawRoot__O()), tmp23.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(pkg__1))))) }
//line :471:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A{}; t.Ctor_O_O(p0, p1); return t }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A) Ctor_O_O(c__test_files, c__tests any) { t.F_test_files = c__test_files; t.F_tests = c__tests }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A) Invoke_O_O__O(self, p1__1901000329_SHARP___1 any) any {



	if jrt.J2g_Truth(t.F_tests) { return p1__1901000329_SHARP___1 } else {

		var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_77.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_136; var tmp3 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_New_O(t.F_test_files); var tmp4 *jrt.Class; var fncls__96 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class; if fncls__96 == nil { var fncls__96d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class = fncls__96d; tmp4 = fncls__96d } else { tmp4 = fncls__96 }; return tmp1.Invoke_O_O_O__O(p1__1901000329_SHARP___1, tmp2, lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil)) } }
//line :471:1
func A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A{}; t.Ctor_O(p0); return t }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A) Invoke_O_O__O(self, p1__1901000330_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_96, A_arbace_build_go_A_const_129.Invoke_O__O(t.F_pkg)) { return p1__1901000330_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_129.Invoke_O__O(t.F_pkg), nil, p1__1901000330_SHARP___1)).Ref() } }
//line :477:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A{}; t.Ctor_O(p0); return t }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A) Invoke_O_O__O(self, fs__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_151.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_New_O(t.F_test_files); var tmp3 *jrt.Class; var fncls__95 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class; if fncls__95 == nil { var fncls__95d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class = fncls__95d; tmp3 = fncls__95d } else { tmp3 = fncls__95 }; return tmp1.Invoke_O_O__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil), fs__1) }
//line :477:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A{}; t.Ctor_O(p0); return t }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A) Invoke_O_O__O(self, f__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); return lang.IFn_Cast(A_arbace_build_go_A_const_17.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_36.Invoke_O__O(f__1)))) }







































func A_arbace_build_go_delete_tree_A_New() *A_arbace_build_go_delete_tree_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_delete_tree_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_build_go_delete_tree_A) Ctor() {}
//line :517:1
func (t *A_arbace_build_go_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.NN(jrt.File_Cast(f__0)).IsDirectory__Z() { var seq_1901000374__2 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(jrt.NN(jrt.File_Cast(f__0)).ListFiles__File1().Ref()); var chunk_1901000375__3 any; var count_1901000376__4 int64 = 0; var i_1901000377__5 int64 = 0; L1: for {
		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000377__5, count_1901000376__4) { var c__6 any = lang.Indexed_Cast(chunk_1901000375__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000377__5)); lang.IFn_Cast(A_arbace_build_go_A_const_141.GetRawRoot__O()).Invoke_O__O(c__6); seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000377__5); continue L1 } else { var temp__1927000414__auto____6 any = lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(seq_1901000374__2); if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1901000374__7 any = temp__1927000414__auto____6; if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_32.GetRawRoot__O()).Invoke_O__O(seq_1901000374__7)) { var c__1927000678__auto____8 any = lang.IFn_Cast(A_arbace_build_go_A_const_33.GetRawRoot__O()).Invoke_O__O(seq_1901000374__7); seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = lang.IFn_Cast(A_arbace_build_go_A_const_41.GetRawRoot__O()).Invoke_O__O(seq_1901000374__7), c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(seq_1901000374__7); lang.IFn_Cast(A_arbace_build_go_A_const_141.GetRawRoot__O()).Invoke_O__O(c__8); seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(seq_1901000374__7), nil, 0, 0; continue L1 } } }
//line :518:1
		break L1
	} }
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).Delete__Z()).Ref()
}
func A_arbace_build_go_build_A_New() *A_arbace_build_go_build_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_build_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_build_go_build_A) Ctor() {}
//line :522:1
func (t *A_arbace_build_go_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__1901000379__3 any) any { var map__1901000380__5 any = p__1901000379__3; var map__1901000380__6 any; if lang.ISeq_InstanceOf(map__1901000380__5) { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(map__1901000380__5)) { map__1901000380__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_build_go_A_const_111.GetRawRoot__O()).Invoke_O__O(map__1901000380__5), jrt.Object_class.ArrayClass())).Ref() } else { if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(map__1901000380__5)) { map__1901000380__6 = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(map__1901000380__5) } else { map__1901000380__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000380__6 = map__1901000380__5 }; var opts__7 any = map__1901000380__6; var work__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000380__6, A_arbace_build_go_A_const_164); var goroot__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000380__6, A_arbace_build_go_A_const_145); var prog__10 any = lang.IFn_Cast(A_arbace_build_go_A_const_131.GetRawRoot__O()).Invoke_O_O_O__O(dir__0, goroot__9, opts__7); var main__11 any = A_arbace_build_go_A_const_126.Invoke_O__O(prog__10); var tmp1 *lang.Keyword = A_arbace_build_go_A_const_165; var config__12 any = tmp1.Invoke_O__O(A_arbace_build_go_A_const_61.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z_NoInit(work__8, nil); var work__14 any; if







	jrt.J2g_Truth(work__8) { work__14 = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(work__8))) } else {

		work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(Lit_27, jrt.J2g_CastArray[*jrt.RefArray](lang.IFn_Cast(A_arbace_build_go_A_const_166.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_168, A_arbace_build_go_A_const_134), jrt.FileAttribute_class.ArrayClass())).ToFile__File().Ref() }; var tmp2 any; tmp14 := /*line :522:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_24)












			if jrt.NN(jrt.File_Cast(mod__17)).Exists__Z() { lang.IFn_Cast(A_arbace_build_go_A_const_141.GetRawRoot__O()).Invoke_O__O(mod__17) }
			lang.IFn_Cast(A_arbace_build_go_A_const_169.GetRawRoot__O()).Invoke_O_O_O_O__O(prog__10, dir__0, mod__17, opts__7)
//line :522:1
			var tags__18 any = A_arbace_build_go_A_const_167.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_144.Invoke_O__O(opts__7), Lit_28); var cmd__20 any; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp4 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_30, Lit_31, Lit_32); var tmp5 lang.IPersistentVector

















			if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(tags__18)) { tmp5 = lang.Tuple_Create_O_O__IPersistentVector(Lit_33, lang.IFn_Cast(A_arbace_build_go_A_const_48.GetRawRoot__O()).Invoke_O_O__O(Lit_34, tags__18)) } else { tmp5 = nil }
//line :539:1
			var tmp6 any = tmp5; var tmp7 lang.IPersistentVector

			if tamago_QMARK___19 { tmp7 = lang.Tuple_Create_O_O__IPersistentVector(Lit_35, A_arbace_build_go_A_const_172.GetRawRoot__O()) } else { tmp7 = nil }
//line :539:1
			var tmp8 any = tmp7; var tmp9 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_build_go_A_const_170.Invoke_O__O(opts__7)


			if jrt.J2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; tmp9 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(o__21))).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp9 = nil }
//line :539:1
			var tmp10 any = tmp9; var tmp11 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_build_go_A_const_171.Invoke_O__O(opts__7)




			if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_37, jrt.NN(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(f__21))).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp11 = nil }
//line :539:1
			cmd__20 = tmp3.Invoke_O_O_O_O_O_O__O(tmp4, tmp6, tmp8, tmp10, tmp11, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.NN(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File()).GetPath__String().Ref(), A_arbace_build_go_A_const_46.Invoke_O__O(main__11)))
//line :522:1
			var env__21 any; var G__1901000385__21_ any; var tmp12 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_108.GetRawRoot__O()); var tmp13 any; var or__1927000174__auto____21 any = A_arbace_build_go_A_const_144.Invoke_O__O(opts__7)
























			if jrt.J2g_Truth(or__1927000174__auto____21) { tmp13 = or__1927000174__auto____21 } else { tmp13 = Lit_38 }; G__1901000385__21_ = tmp12.Invoke_O_O_O__O(goroot__9, arch__1, tmp13); if jrt.J2g_Truth(lang.IFn_Cast(A_arbace_build_go_A_const_31.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_173.Invoke_O__O(config__12))) {
				env__21 = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(G__1901000385__21_, Lit_39, A_arbace_build_go_A_const_173.Invoke_O__O(config__12)) } else {
//line :547:1
					env__21 = G__1901000385__21_ }
//line :522:1
			var vec__1901000382__22 any = lang.IFn_Cast(A_arbace_build_go_A_const_109.GetRawRoot__O()).Invoke_O_O_O_O__O(cmd__20, mod__17, env__21, jrt.Boolean_TRUE.Ref()); var status__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000382__22, lang.RT_IntCast_J__I_NoInit(0), nil); tmp2 = status__23 }; return nil }(); if tmp_QMARK___13 {





























				lang.IFn_Cast(A_arbace_build_go_A_const_141.GetRawRoot__O()).Invoke_O__O(work__14) }; if /*line :522:1*/ tmp14 != nil { panic(tmp14) }; return tmp2 }































func A_arbace_build_go__main_A_New() *A_arbace_build_go__main_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_A{}; t.Ctor(); return t }
//line :554:1
func (t *A_arbace_build_go__main_A) Ctor() {}
//line :554:1
func (t *A_arbace_build_go__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :554:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_174, Lit_5, A_arbace_build_go_A_const_145, goroot__2)); L1: for { var G__1901000387__6_ any = lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4)




		switch lang.Util_Hash_O__I_NoInit(G__1901000387__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_6) {











			var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp2 any = A_arbace_build_go_A_const_122; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp1.Invoke_O_O_O__O(opts__5, tmp2, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_7) {









			as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4), lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(opts__5, A_arbace_build_go_A_const_175, jrt.Boolean_TRUE.Ref()); continue L1 }
//line :559:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_8) {










			as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4), lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(opts__5, A_arbace_build_go_A_const_143, jrt.Boolean_TRUE.Ref()); continue L1 }
//line :559:1
		case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_9) {






			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_164; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp3.Invoke_O_O_O__O(opts__5, tmp4, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_10) {




			var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp6 any = A_arbace_build_go_A_const_138; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp5.Invoke_O_O_O__O(opts__5, tmp6, lang.IFn_Cast(A_arbace_build_go_A_const_189.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4))); continue L1 }
//line :559:1
		case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_11) {













			var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_146; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp7.Invoke_O_O_O__O(opts__5, tmp8, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 30: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_12) {



			var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp10 any = A_arbace_build_go_A_const_176; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp9.Invoke_O_O_O__O(opts__5, tmp10, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_13) {
			var tmp11 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp12 any = A_arbace_build_go_A_const_174; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp11.Invoke_O_O_O__O(opts__5, tmp12, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_14) {





			as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_51.GetRawRoot__O()).Invoke_O__O(as__4), lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()).Invoke_O_O_O__O(opts__5, A_arbace_build_go_A_const_139, jrt.Boolean_TRUE.Ref()); continue L1 }
//line :559:1
		case 38: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_15) {

			var tmp13 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp14 any = A_arbace_build_go_A_const_144; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp13.Invoke_O_O_O__O(opts__5, tmp14, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_16) {


			var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_77.GetRawRoot__O()); var tmp16 any = A_arbace_build_go_A_const_120; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp15.Invoke_O_O_O_O__O(opts__5, tmp16, lang.IFn_Cast(A_arbace_build_go_A_const_190.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_7.GetRawRoot__O(), lang.PersistentVector_EMPTY.Ref()), lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_17) {







			var tmp17 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp18 any = A_arbace_build_go_A_const_170; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp17.Invoke_O_O_O__O(opts__5, tmp18, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_18) {














			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp20 any = A_arbace_build_go_A_const_127; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp19.Invoke_O_O_O__O(opts__5, tmp20, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_19) {












			var tmp21 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp22 any = A_arbace_build_go_A_const_121; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp21.Invoke_O_O_O__O(opts__5, tmp22, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_20) {








			var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_62.GetRawRoot__O()); var tmp24 any = A_arbace_build_go_A_const_171; as__4, opts__5 = lang.IFn_Cast(A_arbace_build_go_A_const_187.GetRawRoot__O()).Invoke_O__O(as__4), tmp23.Invoke_O_O_O__O(opts__5, tmp24, lang.IFn_Cast(A_arbace_build_go_A_const_188.GetRawRoot__O()).Invoke_O__O(as__4)); continue L1 }
//line :559:1
		default:
		}















		var tmp25 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any = lang.IFn_Cast(A_arbace_build_go_A_const_17.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_128.GetRawRoot__O()).Invoke_O_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4), Lit_21)); if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191); var and__1927000168__auto____9 any = tmp26.Invoke_O__O(A_arbace_build_go_A_const_174.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____9) { var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_27.GetRawRoot__O()); var tmp28 any = A_arbace_build_go_A_const_192; var and__1927000168__auto____10 any = tmp27.Invoke_O_O__O(tmp28, A_arbace_build_go_A_const_144.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____10) { var tmp29 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_27.GetRawRoot__O()); var tmp30 any = A_arbace_build_go_A_const_193; var and__1927000168__auto____11 any = tmp29.Invoke_O_O__O(tmp30, A_arbace_build_go_A_const_138.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any = lang.IFn_Cast(A_arbace_build_go_A_const_17.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_175.Invoke_O__O(opts__5))



			if jrt.J2g_Truth(or__1927000174__auto____12) { tmp25 = or__1927000174__auto____12 } else { tmp25 = A_arbace_build_go_A_const_164.Invoke_O__O(opts__5) } } else {
//line :576:1
				tmp25 = and__1927000168__auto____11 } } else { tmp25 = and__1927000168__auto____10 } } else { tmp25 = and__1927000168__auto____9 } } else { tmp25 = and__1927000168__auto____8 } } else { tmp25 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp25) { } else {




					var tmp31 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()); var tmp32 any = A_arbace_build_go_A_const_185; lang.IFn_Cast(A_arbace_build_go_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp31.Invoke_O_O__O(tmp32, A_arbace_build_go_A_const_186.Get__O())); var tmp33 any = A_arbace_build_go__main_fn__1901000388_A_New_O(usage__3); var tmp34 *jrt.Class; var fncls__103 *jrt.Class = A_arbace_build_go__main_fn__1901000388_A_fn_class; if fncls__103 == nil { var fncls__103d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_build_go__main_fn__1901000388_A_fn_class = fncls__103d; tmp34 = fncls__103d } else { tmp34 = fncls__103 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp33, tmp34, nil).Invoke__O()
					jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :559:1
		var dir__7 any = jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_20.GetRawRoot__O()).Invoke_O__O(as__4))); var status__8 any; var tmp35 any = A_arbace_build_go__main_fn__1901000390_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp36 *jrt.Class
		var fncls__102 /*line :559:1*/*jrt.Class = A_arbace_build_go__main_fn__1901000390_A_fn_class
























		if fncls__102 == nil { var fncls__102d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_build_go__main_fn__1901000390_A_fn_class = fncls__102d; tmp36 = fncls__102d } else { tmp36 = fncls__102 }; status__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil).Invoke__O()















		lang.IFn_Cast(A_arbace_build_go_A_const_194.GetRawRoot__O()).Invoke__O()
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__8)); return nil } }; /*line :554:1*/panic("j2g: unreachable") }


























func A_arbace_build_go__main_fn__1901000388_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000388_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000388_A{}; t.Ctor_O(p0); return t }
//line :581:1
func (t *A_arbace_build_go__main_fn__1901000388_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :581:1
func (t *A_arbace_build_go__main_fn__1901000388_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke__O(); if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_build_go__main_fn__1901000390_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go__main_fn__1901000390_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000390_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :584:1
func (t *A_arbace_build_go__main_fn__1901000390_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :584:1
func (t *A_arbace_build_go__main_fn__1901000390_A) Invoke_O__O(self any) any { var tmp1 any; tmp25 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.J2g_Truth(A_arbace_build_go_A_const_175.Invoke_O__O(t.F_opts)) { var prog__3 any; var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_131.GetRawRoot__O()); var tmp3 any = t.F_dir; var tmp4 any; var t_ any = t.F_goroot
											t.F_goroot = nil; tmp4 = t_; var tmp5 any = A_arbace_build_go_A_const_119; var tmp6 any = jrt.Boolean_TRUE.Ref(); var tmp7 any = A_arbace_build_go_A_const_122; var tmp8 any = A_arbace_build_go_A_const_122.Invoke_O__O(t.F_opts); var tmp9 any = A_arbace_build_go_A_const_120; prog__3 = tmp2.Invoke_O_O_O__O(tmp3, tmp4, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp5, tmp6, tmp7, tmp8, tmp9, A_arbace_build_go_A_const_120.Invoke_O__O(t.F_opts))))
//line :585:1
		var mod__4 any = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(lang.IFn_Cast(A_arbace_build_go_A_const_29.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_164.Invoke_O__O(t.F_opts)))), Lit_24)


		if jrt.NN(jrt.File_Cast(mod__4)).Exists__Z() { lang.IFn_Cast(A_arbace_build_go_A_const_141.GetRawRoot__O()).Invoke_O__O(mod__4) }
		var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_169.GetRawRoot__O()); var tmp11 any; var t__2 any = t.F_dir; t.F_dir = nil; tmp11 = t__2; var tmp12 any = tmp11; var tmp13 any; var t__3 any = t.F_opts; t.F_opts = nil; tmp13 = t__3; tmp10.Invoke_O_O_O_O__O(prog__3, tmp12, mod__4, tmp13)
//line :585:1
		tmp1 = A_arbace_build_go_A_const_134 } else { var prog_main__3 any





			if jrt.J2g_Truth(A_arbace_build_go_A_const_176.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp14 *lang.Keyword = A_arbace_build_go_A_const_126; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_131.GetRawRoot__O()); var tmp16 any = t.F_dir; var tmp17 any; var t__4 any = t.F_goroot; t.F_goroot = nil; tmp17 = t__4; prog_main__3 = tmp14.Invoke_O__O(tmp15.Invoke_O_O_O__O(tmp16, tmp17, t.F_opts)) }
//line :585:1
			var out__4 any; var tmp18 *jrt.Class = A_arbace_build_go_A_const_67; var tmp19 any; var or__1927000174__auto____4 any = A_arbace_build_go_A_const_176.Invoke_O__O(t.F_opts)






			if jrt.J2g_Truth(or__1927000174__auto____4) { tmp19 = or__1927000174__auto____4 } else {
				tmp19 = lang.IFn_Cast(A_arbace_build_go_A_const_177.GetRawRoot__O()).Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_179.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_46.Invoke_O__O(prog_main__3), A_arbace_build_go_A_const_180)) }
//line :585:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp18, jrt.RefArrayOf(jrt.Object_class, tmp19))








			var tmp20 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_178.GetRawRoot__O()); var tmp21 any; var t__5 any = t.F_dir; t.F_dir = nil; tmp21 = t__5; var tmp22 any = tmp21; var tmp23 any = A_arbace_build_go_A_const_174.Invoke_O__O(t.F_opts); var tmp24 any; var t__6 any = t.F_opts; t.F_opts = nil; tmp24 = t__6; tmp1 = tmp20.Invoke_O_O_O_O__O(tmp22, tmp23, out__4, tmp24) }
//line :584:1
	return nil }(); if tmp25 != nil { if lang.ExceptionInfo_InstanceOf(tmp25) { var e__3 *lang.ExceptionInfo = lang.ExceptionInfo_Cast(tmp25)
		var tmp26 /*line :584:1*/*lang.Keyword = A_arbace_build_go_A_const_181











		if jrt.J2g_Truth(tmp26.Invoke_O__O(lang.IFn_Cast(A_arbace_build_go_A_const_182.GetRawRoot__O()).Invoke_O__O(e__3.Ref()))) {
			var tmp27 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()); var tmp28 any = A_arbace_build_go_A_const_185; lang.IFn_Cast(A_arbace_build_go_A_const_71.GetRawRoot__O()).Invoke_O__O(tmp27.Invoke_O_O__O(tmp28, A_arbace_build_go_A_const_186.Get__O())); var tmp29 any = A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_New_O(e__3.Ref()); var tmp30 *jrt.Class; var fncls__101 *jrt.Class = A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class; if fncls__101 == nil { var fncls__101d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class = fncls__101d; tmp30 = fncls__101d } else { tmp30 = fncls__101 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil).Invoke__O()
//line :596:1
			tmp1 = A_arbace_build_go_A_const_183 } else { panic(jrt.Thrown(Up_ExceptionInfo_Throwable(e__3))) } } else {
//line :584:1
				panic(tmp25) } }; return tmp1 }












func A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000390_fn__1901000391_A{}; t.Ctor_O(p0); return t }
//line :597:1
func (t *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :597:1
func (t *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_184.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); lang.IFn_Cast(A_arbace_build_go_A_const_70.GetRawRoot__O()).Invoke__O(); if tmp5 != nil { panic(tmp5) }; return tmp1 }

















































































































































type A_arbace_build_go_A struct{ jrt.Object }

var A_arbace_build_go_A_const_pool *jrt.RefArray

var A_arbace_build_go_A_const_0 *lang.Var

var A_arbace_build_go_A_const_1 *lang.Var

var A_arbace_build_go_A_const_2 any

var A_arbace_build_go_A_const_3 any

var A_arbace_build_go_A_const_4 any

var A_arbace_build_go_A_const_5 *lang.Var

var A_arbace_build_go_A_const_6 *lang.Var

var A_arbace_build_go_A_const_7 *lang.Var

var A_arbace_build_go_A_const_8 any

var A_arbace_build_go_A_const_9 *lang.Var

var A_arbace_build_go_A_const_10 *lang.Var

var A_arbace_build_go_A_const_11 *lang.Var

var A_arbace_build_go_A_const_12 any

var A_arbace_build_go_A_const_13 *lang.Keyword

var A_arbace_build_go_A_const_14 *lang.Var

var A_arbace_build_go_A_const_15 *lang.Var

var A_arbace_build_go_A_const_16 *lang.Var

var A_arbace_build_go_A_const_17 *lang.Var

var A_arbace_build_go_A_const_18 *lang.Var

var A_arbace_build_go_A_const_19 *lang.Var

var A_arbace_build_go_A_const_20 *lang.Var

var A_arbace_build_go_A_const_21 *lang.Var

var A_arbace_build_go_A_const_22 *lang.Var

var A_arbace_build_go_A_const_23 *lang.Var

var A_arbace_build_go_A_const_24 any

var A_arbace_build_go_A_const_25 *lang.Var

var A_arbace_build_go_A_const_26 *lang.Var

var A_arbace_build_go_A_const_27 *lang.Var

var A_arbace_build_go_A_const_28 *lang.Var

var A_arbace_build_go_A_const_29 *lang.Var

var A_arbace_build_go_A_const_30 *lang.Var

var A_arbace_build_go_A_const_31 *lang.Var

var A_arbace_build_go_A_const_32 *lang.Var

var A_arbace_build_go_A_const_33 *lang.Var

var A_arbace_build_go_A_const_34 *lang.Var

var A_arbace_build_go_A_const_35 *lang.Var

var A_arbace_build_go_A_const_36 *lang.Keyword

var A_arbace_build_go_A_const_37 *lang.Var

var A_arbace_build_go_A_const_38 *lang.Var

var A_arbace_build_go_A_const_39 *lang.Var

var A_arbace_build_go_A_const_40 *lang.Var

var A_arbace_build_go_A_const_41 *lang.Var

var A_arbace_build_go_A_const_42 *lang.Var

var A_arbace_build_go_A_const_43 *lang.Var

var A_arbace_build_go_A_const_44 *lang.Var

var A_arbace_build_go_A_const_45 *lang.Var

var A_arbace_build_go_A_const_46 *lang.Keyword

var A_arbace_build_go_A_const_47 *lang.Var

var A_arbace_build_go_A_const_48 *lang.Var

var A_arbace_build_go_A_const_49 *lang.Var

var A_arbace_build_go_A_const_50 *lang.Keyword

var A_arbace_build_go_A_const_51 *lang.Var

var A_arbace_build_go_A_const_52 *lang.Var

var A_arbace_build_go_A_const_53 *lang.Var

var A_arbace_build_go_A_const_54 *lang.Var

var A_arbace_build_go_A_const_55 *lang.Var

var A_arbace_build_go_A_const_56 *lang.Var

var A_arbace_build_go_A_const_57 *lang.Var

var A_arbace_build_go_A_const_58 *lang.Var

var A_arbace_build_go_A_const_59 *lang.Var

var A_arbace_build_go_A_const_60 *lang.Var

var A_arbace_build_go_A_const_61 *lang.Keyword

var A_arbace_build_go_A_const_62 *lang.Var

var A_arbace_build_go_A_const_63 *lang.Var

var A_arbace_build_go_A_const_64 *lang.Var

var A_arbace_build_go_A_const_65 *lang.Var

var A_arbace_build_go_A_const_66 *lang.Keyword

var A_arbace_build_go_A_const_67 *jrt.Class

var A_arbace_build_go_A_const_68 *lang.Var

var A_arbace_build_go_A_const_69 *lang.Var

var A_arbace_build_go_A_const_70 *lang.Var

var A_arbace_build_go_A_const_71 *lang.Var

var A_arbace_build_go_A_const_72 *lang.Var

var A_arbace_build_go_A_const_73 *lang.Var

var A_arbace_build_go_A_const_74 *lang.Var

var A_arbace_build_go_A_const_75 *lang.Var

var A_arbace_build_go_A_const_76 *lang.Var

var A_arbace_build_go_A_const_77 *lang.Var

var A_arbace_build_go_A_const_78 *lang.Keyword

var A_arbace_build_go_A_const_79 *lang.Var

var A_arbace_build_go_A_const_80 *lang.Var

var A_arbace_build_go_A_const_81 *lang.Var

var A_arbace_build_go_A_const_82 *lang.Keyword

var A_arbace_build_go_A_const_83 *lang.Var

var A_arbace_build_go_A_const_84 *lang.Var

var A_arbace_build_go_A_const_85 *lang.Var

var A_arbace_build_go_A_const_86 *lang.Var

var A_arbace_build_go_A_const_87 *lang.Var

var A_arbace_build_go_A_const_88 *lang.Var

var A_arbace_build_go_A_const_89 *lang.Var

var A_arbace_build_go_A_const_90 *lang.Keyword

var A_arbace_build_go_A_const_91 *lang.Var

var A_arbace_build_go_A_const_92 *lang.Var

var A_arbace_build_go_A_const_93 *lang.Var

var A_arbace_build_go_A_const_94 *lang.Var

var A_arbace_build_go_A_const_95 *lang.Var

var A_arbace_build_go_A_const_96 *lang.Keyword

var A_arbace_build_go_A_const_97 *lang.Var

var A_arbace_build_go_A_const_98 *lang.Var

var A_arbace_build_go_A_const_99 *lang.Var

var A_arbace_build_go_A_const_100 any

var A_arbace_build_go_A_const_101 any

var A_arbace_build_go_A_const_102 any

var A_arbace_build_go_A_const_103 any

var A_arbace_build_go_A_const_104 *lang.Var

var A_arbace_build_go_A_const_105 *lang.Var

var A_arbace_build_go_A_const_106 any

var A_arbace_build_go_A_const_107 any

var A_arbace_build_go_A_const_108 *lang.Var

var A_arbace_build_go_A_const_109 *lang.Var

var A_arbace_build_go_A_const_110 *lang.Var

var A_arbace_build_go_A_const_111 *lang.Var

var A_arbace_build_go_A_const_112 *lang.Keyword

var A_arbace_build_go_A_const_113 *lang.Keyword

var A_arbace_build_go_A_const_114 *lang.Keyword

var A_arbace_build_go_A_const_115 *lang.Var

var A_arbace_build_go_A_const_116 *lang.Var

var A_arbace_build_go_A_const_117 *lang.Var

var A_arbace_build_go_A_const_118 any

var A_arbace_build_go_A_const_119 *lang.Keyword

var A_arbace_build_go_A_const_120 *lang.Keyword

var A_arbace_build_go_A_const_121 *lang.Keyword

var A_arbace_build_go_A_const_122 *lang.Keyword

var A_arbace_build_go_A_const_123 *lang.Var

var A_arbace_build_go_A_const_124 *lang.Keyword

var A_arbace_build_go_A_const_125 *lang.Var

var A_arbace_build_go_A_const_126 *lang.Keyword

var A_arbace_build_go_A_const_127 *lang.Keyword

var A_arbace_build_go_A_const_128 *lang.Var

var A_arbace_build_go_A_const_129 *lang.Keyword

var A_arbace_build_go_A_const_130 *lang.Var

var A_arbace_build_go_A_const_131 *lang.Var

var A_arbace_build_go_A_const_132 *lang.Var

var A_arbace_build_go_A_const_133 *jrt.Class

var A_arbace_build_go_A_const_134 any

var A_arbace_build_go_A_const_135 *lang.Var

var A_arbace_build_go_A_const_136 *lang.Keyword

var A_arbace_build_go_A_const_137 *lang.Keyword

var A_arbace_build_go_A_const_138 *lang.Keyword

var A_arbace_build_go_A_const_139 *lang.Keyword

var A_arbace_build_go_A_const_140 *lang.Var

var A_arbace_build_go_A_const_141 *lang.Var

var A_arbace_build_go_A_const_142 *lang.Var

var A_arbace_build_go_A_const_143 *lang.Keyword

var A_arbace_build_go_A_const_144 *lang.Keyword

var A_arbace_build_go_A_const_145 *lang.Keyword

var A_arbace_build_go_A_const_146 *lang.Keyword

var A_arbace_build_go_A_const_147 *lang.Var

var A_arbace_build_go_A_const_148 any

var A_arbace_build_go_A_const_149 *lang.Keyword

var A_arbace_build_go_A_const_150 *lang.Keyword

var A_arbace_build_go_A_const_151 *lang.Var

var A_arbace_build_go_A_const_152 *lang.Var

var A_arbace_build_go_A_const_153 *lang.Var

var A_arbace_build_go_A_const_154 *lang.Var

var A_arbace_build_go_A_const_155 *lang.Keyword

var A_arbace_build_go_A_const_156 any

var A_arbace_build_go_A_const_157 *lang.Var

var A_arbace_build_go_A_const_158 *lang.Var

var A_arbace_build_go_A_const_159 *lang.Var

var A_arbace_build_go_A_const_160 *lang.Var

var A_arbace_build_go_A_const_161 *lang.Keyword

var A_arbace_build_go_A_const_162 *lang.Keyword

var A_arbace_build_go_A_const_163 *lang.Var

var A_arbace_build_go_A_const_164 *lang.Keyword

var A_arbace_build_go_A_const_165 *lang.Keyword

var A_arbace_build_go_A_const_166 *lang.Var

var A_arbace_build_go_A_const_167 *lang.Keyword

var A_arbace_build_go_A_const_168 *jrt.Class

var A_arbace_build_go_A_const_169 *lang.Var

var A_arbace_build_go_A_const_170 *lang.Keyword

var A_arbace_build_go_A_const_171 *lang.Keyword

var A_arbace_build_go_A_const_172 *lang.Var

var A_arbace_build_go_A_const_173 *lang.Keyword

var A_arbace_build_go_A_const_174 *lang.Keyword

var A_arbace_build_go_A_const_175 *lang.Keyword

var A_arbace_build_go_A_const_176 *lang.Keyword

var A_arbace_build_go_A_const_177 *lang.Var

var A_arbace_build_go_A_const_178 *lang.Var

var A_arbace_build_go_A_const_179 *lang.Var

var A_arbace_build_go_A_const_180 any

var A_arbace_build_go_A_const_181 *lang.Keyword

var A_arbace_build_go_A_const_182 *lang.Var

var A_arbace_build_go_A_const_183 any

var A_arbace_build_go_A_const_184 *lang.Var

var A_arbace_build_go_A_const_185 *lang.Var

var A_arbace_build_go_A_const_186 *lang.Var

var A_arbace_build_go_A_const_187 *lang.Var

var A_arbace_build_go_A_const_188 *lang.Var

var A_arbace_build_go_A_const_189 *lang.Var

var A_arbace_build_go_A_const_190 *lang.Var

var A_arbace_build_go_A_const_191 any

var A_arbace_build_go_A_const_192 any

var A_arbace_build_go_A_const_193 any

var A_arbace_build_go_A_const_194 *lang.Var

var A_arbace_build_go_A_init jrt.ClassInit

func A_arbace_build_go_A_Init() { if !A_arbace_build_go_A_init.Done() { A_arbace_build_go_A_init.Run(A_arbace_build_go_A_clinit) } }

func A_arbace_build_go_A_clinit() { A_arbace_build_go_A_clinit_p0(); A_arbace_build_go_A_clinit_p1(); A_arbace_build_go_A_clinit_p2(); A_arbace_build_go_A_clinit_p3(); A_arbace_build_go_A_clinit_p4(); A_arbace_build_go_A_clinit_p5(); A_arbace_build_go_A_clinit_p6(); A_arbace_build_go_A_clinit_p7(); A_arbace_build_go_A_clinit_p8(); A_arbace_build_go_A_clinit_p9(); A_arbace_build_go_A_clinit_p10(); A_arbace_build_go_A_clinit_p11(); A_arbace_build_go_A_clinit_p12(); A_arbace_build_go_A_clinit_p13(); A_arbace_build_go_A_clinit_p14(); A_arbace_build_go_A_clinit_p15(); A_arbace_build_go_A_clinit_p16() }

func A_arbace_build_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_build_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 247); A_arbace_build_go_A_const_0 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[52]); A_arbace_build_go_A_const_1 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[53]); A_arbace_build_go_A_const_2 = A_arbace_build_go_A_const_pool.A[54]; A_arbace_build_go_A_const_3 = A_arbace_build_go_A_const_pool.A[55]; A_arbace_build_go_A_const_4 = A_arbace_build_go_A_const_pool.A[56]; A_arbace_build_go_A_const_5 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[57]); A_arbace_build_go_A_const_6 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[58]); A_arbace_build_go_A_const_7 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[59]); A_arbace_build_go_A_const_8 = A_arbace_build_go_A_const_pool.A[60]; A_arbace_build_go_A_const_9 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[61]); A_arbace_build_go_A_const_10 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[62]); A_arbace_build_go_A_const_11 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[63]) }

func A_arbace_build_go_A_clinit_p1() { A_arbace_build_go_A_const_12 = A_arbace_build_go_A_const_pool.A[64]; A_arbace_build_go_A_const_13 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[65]); A_arbace_build_go_A_const_14 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[66]); A_arbace_build_go_A_const_15 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[67]); A_arbace_build_go_A_const_16 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[68]); A_arbace_build_go_A_const_17 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[69]); A_arbace_build_go_A_const_18 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[70]); A_arbace_build_go_A_const_19 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[71]); A_arbace_build_go_A_const_20 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[72]); A_arbace_build_go_A_const_21 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[73]); A_arbace_build_go_A_const_22 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[74]); A_arbace_build_go_A_const_23 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[75]) }

func A_arbace_build_go_A_clinit_p2() { A_arbace_build_go_A_const_24 = A_arbace_build_go_A_const_pool.A[76]; A_arbace_build_go_A_const_25 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[77]); A_arbace_build_go_A_const_26 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[78]); A_arbace_build_go_A_const_27 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[79]); A_arbace_build_go_A_const_28 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[80]); A_arbace_build_go_A_const_29 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[81]); A_arbace_build_go_A_const_30 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[82]); A_arbace_build_go_A_const_31 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[83]); A_arbace_build_go_A_const_32 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[84]); A_arbace_build_go_A_const_33 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[85]); A_arbace_build_go_A_const_34 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[86]); A_arbace_build_go_A_const_35 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[87]) }

func A_arbace_build_go_A_clinit_p3() { A_arbace_build_go_A_const_36 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[88]); A_arbace_build_go_A_const_37 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[89]); A_arbace_build_go_A_const_38 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[90]); A_arbace_build_go_A_const_39 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[91]); A_arbace_build_go_A_const_40 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[92]); A_arbace_build_go_A_const_41 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[93]); A_arbace_build_go_A_const_42 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[94]); A_arbace_build_go_A_const_43 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[95]); A_arbace_build_go_A_const_44 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[96]); A_arbace_build_go_A_const_45 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[97]); A_arbace_build_go_A_const_46 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[98]); A_arbace_build_go_A_const_47 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[99]) }

func A_arbace_build_go_A_clinit_p4() { A_arbace_build_go_A_const_48 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[100]); A_arbace_build_go_A_const_49 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[101]); A_arbace_build_go_A_const_50 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[102]); A_arbace_build_go_A_const_51 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[103]); A_arbace_build_go_A_const_52 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[104]); A_arbace_build_go_A_const_53 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[105]); A_arbace_build_go_A_const_54 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[106]); A_arbace_build_go_A_const_55 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[107]); A_arbace_build_go_A_const_56 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[108]); A_arbace_build_go_A_const_57 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[109]); A_arbace_build_go_A_const_58 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[110]); A_arbace_build_go_A_const_59 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[111]) }

func A_arbace_build_go_A_clinit_p5() { A_arbace_build_go_A_const_60 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[112]); A_arbace_build_go_A_const_61 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[113]); A_arbace_build_go_A_const_62 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[114]); A_arbace_build_go_A_const_63 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[115]); A_arbace_build_go_A_const_64 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[116]); A_arbace_build_go_A_const_65 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[117]); A_arbace_build_go_A_const_66 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[118]); A_arbace_build_go_A_const_67 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[119]); A_arbace_build_go_A_const_68 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[120]); A_arbace_build_go_A_const_69 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[121]); A_arbace_build_go_A_const_70 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[122]); A_arbace_build_go_A_const_71 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[123]) }

func A_arbace_build_go_A_clinit_p6() { A_arbace_build_go_A_const_72 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[124]); A_arbace_build_go_A_const_73 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[125]); A_arbace_build_go_A_const_74 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[126]); A_arbace_build_go_A_const_75 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[127]); A_arbace_build_go_A_const_76 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[128]); A_arbace_build_go_A_const_77 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[129]); A_arbace_build_go_A_const_78 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[130]); A_arbace_build_go_A_const_79 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[131]); A_arbace_build_go_A_const_80 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[132]); A_arbace_build_go_A_const_81 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[133]); A_arbace_build_go_A_const_82 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[134]); A_arbace_build_go_A_const_83 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[135]) }

func A_arbace_build_go_A_clinit_p7() { A_arbace_build_go_A_const_84 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[136]); A_arbace_build_go_A_const_85 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[137]); A_arbace_build_go_A_const_86 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[138]); A_arbace_build_go_A_const_87 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[139]); A_arbace_build_go_A_const_88 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[140]); A_arbace_build_go_A_const_89 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[141]); A_arbace_build_go_A_const_90 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[142]); A_arbace_build_go_A_const_91 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[143]); A_arbace_build_go_A_const_92 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[144]); A_arbace_build_go_A_const_93 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[145]); A_arbace_build_go_A_const_94 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[146]); A_arbace_build_go_A_const_95 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[147]) }

func A_arbace_build_go_A_clinit_p8() { A_arbace_build_go_A_const_96 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[148]); A_arbace_build_go_A_const_97 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[149]); A_arbace_build_go_A_const_98 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[150]); A_arbace_build_go_A_const_99 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[151]); A_arbace_build_go_A_const_100 = A_arbace_build_go_A_const_pool.A[152]; A_arbace_build_go_A_const_101 = A_arbace_build_go_A_const_pool.A[153]; A_arbace_build_go_A_const_102 = A_arbace_build_go_A_const_pool.A[154]; A_arbace_build_go_A_const_103 = A_arbace_build_go_A_const_pool.A[155]; A_arbace_build_go_A_const_104 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[156]); A_arbace_build_go_A_const_105 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[157]); A_arbace_build_go_A_const_106 = A_arbace_build_go_A_const_pool.A[158]; A_arbace_build_go_A_const_107 = A_arbace_build_go_A_const_pool.A[159]; A_arbace_build_go_A_const_108 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[160]) }

func A_arbace_build_go_A_clinit_p9() { A_arbace_build_go_A_const_109 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[161]); A_arbace_build_go_A_const_110 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[162]); A_arbace_build_go_A_const_111 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[163]); A_arbace_build_go_A_const_112 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[164]); A_arbace_build_go_A_const_113 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[165]); A_arbace_build_go_A_const_114 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[166]); A_arbace_build_go_A_const_115 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[167]); A_arbace_build_go_A_const_116 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[168]); A_arbace_build_go_A_const_117 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[169]); A_arbace_build_go_A_const_118 = A_arbace_build_go_A_const_pool.A[170]; A_arbace_build_go_A_const_119 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[171]); A_arbace_build_go_A_const_120 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[172]) }

func A_arbace_build_go_A_clinit_p10() { A_arbace_build_go_A_const_121 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[173]); A_arbace_build_go_A_const_122 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[174]); A_arbace_build_go_A_const_123 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[175]); A_arbace_build_go_A_const_124 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[176]); A_arbace_build_go_A_const_125 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[177]); A_arbace_build_go_A_const_126 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[178]); A_arbace_build_go_A_const_127 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[179]); A_arbace_build_go_A_const_128 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[180]); A_arbace_build_go_A_const_129 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[181]); A_arbace_build_go_A_const_130 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[182]); A_arbace_build_go_A_const_131 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[183]); A_arbace_build_go_A_const_132 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[184]) }

func A_arbace_build_go_A_clinit_p11() { A_arbace_build_go_A_const_133 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[185]); A_arbace_build_go_A_const_134 = A_arbace_build_go_A_const_pool.A[186]; A_arbace_build_go_A_const_135 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[187]); A_arbace_build_go_A_const_136 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[188]); A_arbace_build_go_A_const_137 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[189]); A_arbace_build_go_A_const_138 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[190]); A_arbace_build_go_A_const_139 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[191]); A_arbace_build_go_A_const_140 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[192]); A_arbace_build_go_A_const_141 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[193]); A_arbace_build_go_A_const_142 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[194]); A_arbace_build_go_A_const_143 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[195]); A_arbace_build_go_A_const_144 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[196]) }

func A_arbace_build_go_A_clinit_p12() { A_arbace_build_go_A_const_145 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[197]); A_arbace_build_go_A_const_146 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[198]); A_arbace_build_go_A_const_147 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[199]); A_arbace_build_go_A_const_148 = A_arbace_build_go_A_const_pool.A[200]; A_arbace_build_go_A_const_149 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[201]); A_arbace_build_go_A_const_150 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[202]); A_arbace_build_go_A_const_151 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[203]); A_arbace_build_go_A_const_152 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[204]); A_arbace_build_go_A_const_153 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[205]); A_arbace_build_go_A_const_154 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[206]); A_arbace_build_go_A_const_155 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[207]); A_arbace_build_go_A_const_156 = A_arbace_build_go_A_const_pool.A[208] }

func A_arbace_build_go_A_clinit_p13() { A_arbace_build_go_A_const_157 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[209]); A_arbace_build_go_A_const_158 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[210]); A_arbace_build_go_A_const_159 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[211]); A_arbace_build_go_A_const_160 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[212]); A_arbace_build_go_A_const_161 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[213]); A_arbace_build_go_A_const_162 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[214]); A_arbace_build_go_A_const_163 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[215]); A_arbace_build_go_A_const_164 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[216]); A_arbace_build_go_A_const_165 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[217]); A_arbace_build_go_A_const_166 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[218]); A_arbace_build_go_A_const_167 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[219]); A_arbace_build_go_A_const_168 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[220]) }

func A_arbace_build_go_A_clinit_p14() { A_arbace_build_go_A_const_169 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[221]); A_arbace_build_go_A_const_170 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[222]); A_arbace_build_go_A_const_171 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[223]); A_arbace_build_go_A_const_172 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[224]); A_arbace_build_go_A_const_173 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[225]); A_arbace_build_go_A_const_174 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[226]); A_arbace_build_go_A_const_175 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[227]); A_arbace_build_go_A_const_176 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[228]); A_arbace_build_go_A_const_177 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[229]); A_arbace_build_go_A_const_178 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[230]); A_arbace_build_go_A_const_179 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[231]); A_arbace_build_go_A_const_180 = A_arbace_build_go_A_const_pool.A[232] }

func A_arbace_build_go_A_clinit_p15() { A_arbace_build_go_A_const_181 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[233]); A_arbace_build_go_A_const_182 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[234]); A_arbace_build_go_A_const_183 = A_arbace_build_go_A_const_pool.A[235]; A_arbace_build_go_A_const_184 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[236]); A_arbace_build_go_A_const_185 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[237]); A_arbace_build_go_A_const_186 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[238]); A_arbace_build_go_A_const_187 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[239]); A_arbace_build_go_A_const_188 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[240]); A_arbace_build_go_A_const_189 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[241]); A_arbace_build_go_A_const_190 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[242]); A_arbace_build_go_A_const_191 = A_arbace_build_go_A_const_pool.A[243]; A_arbace_build_go_A_const_192 = A_arbace_build_go_A_const_pool.A[244]; A_arbace_build_go_A_const_193 = A_arbace_build_go_A_const_pool.A[245] }

func A_arbace_build_go_A_clinit_p16() { A_arbace_build_go_A_const_194 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[246]) }

func A_arbace_build_go_A_New() *A_arbace_build_go_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_A) Ctor() {}

func (t *A_arbace_build_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_A_class }

func (t *A_arbace_build_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_A); return ok }

func A_arbace_build_go_A_Cast(x any) *A_arbace_build_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_A_class)) }; return v }



type A_arbace_build_go__main_A struct{ j2g_header uint64 }

var A_arbace_build_go__main_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000388_A struct{ j2g_header uint64; F_usage any }

var A_arbace_build_go__main_fn__1901000388_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000390_A struct{ j2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_build_go__main_fn__1901000390_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000390_fn__1901000391_A struct{ j2g_header uint64; F_e any }

var A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class *jrt.Class



type A_arbace_build_go_build_A struct{ j2g_header uint64 }

var A_arbace_build_go_build_A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__fn__1901000326_A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_A struct{ j2g_header uint64 }

var A_arbace_build_go_cached_texts_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A struct{ j2g_header uint64; F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A struct{ j2g_header uint64; F_s__1901000305, F_iter__1901000304, F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A struct{ j2g_header uint64; F_b__1901000307, F_entry any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000020_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_fn__1901000020_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000022_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_clj_files_fn__1901000022_A_fn_class *jrt.Class



type A_arbace_build_go_collect_index_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_index_file_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_package_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_fn__1901000076_A struct{ j2g_header uint64; F_read_fn, F_read any }

var A_arbace_build_go_collect_package_fn__1901000076_A_fn_class *jrt.Class



type A_arbace_build_go_collected_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collected_package_A_fn_class *jrt.Class



type A_arbace_build_go_copy_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_copy_file_A_fn_class *jrt.Class



type A_arbace_build_go_data_dir_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_delete_tree_A struct{ j2g_header uint64 }

var A_arbace_build_go_delete_tree_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000004_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000004_A_New() *A_arbace_build_go_eval1901000004_A { t := &A_arbace_build_go_eval1901000004_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000004_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000004_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000004_A_class }

func (t *A_arbace_build_go_eval1901000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000004_A); return ok }

func A_arbace_build_go_eval1901000004_A_Cast(x any) *A_arbace_build_go_eval1901000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000004_A_class)) }; return v }



type A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000008_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000008_A_New() *A_arbace_build_go_eval1901000008_A { t := &A_arbace_build_go_eval1901000008_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000008_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000008_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000008_A_class }

func (t *A_arbace_build_go_eval1901000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000008_A); return ok }

func A_arbace_build_go_eval1901000008_A_Cast(x any) *A_arbace_build_go_eval1901000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000008_A_class)) }; return v }



type A_arbace_build_go_eval1901000008_fn__1901000009_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000008_fn__1901000009_A_fn_class *jrt.Class



type A_arbace_build_go_fail_A struct{ j2g_header uint64 }

var A_arbace_build_go_fail_A_fn_class *jrt.Class



type A_arbace_build_go_file_sha_A struct{ j2g_header uint64 }

var A_arbace_build_go_file_sha_A_fn_class *jrt.Class



type A_arbace_build_go_forms_dir_A struct{ j2g_header uint64 }

var A_arbace_build_go_forms_dir_A_fn_class *jrt.Class



type A_arbace_build_go_go_env_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_env_A_fn_class *jrt.Class



type A_arbace_build_go_go_mod_cache_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_sha__1901000243_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class *jrt.Class



type A_arbace_build_go_hex_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_A_fn_class *jrt.Class



type A_arbace_build_go_hex_fn__1901000072_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_fn__1901000072_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000027_A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000029_A struct{ j2g_header uint64; F_aliases any }

var A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class *jrt.Class



type A_arbace_build_go_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000057_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000057_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000062_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000062_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_A struct{ j2g_header uint64; F_print_cache any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A struct{ j2g_header uint64; F_iter__1901000034, F_print_cache, F_s__1901000035 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A struct{ j2g_header uint64; F_iter__1901000036, F_s__1901000037 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A struct{ j2g_header uint64; F_b__1901000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_add__1901000295_A struct{ j2g_header uint64; F_md any }

var A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_fn__1901000301_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_A struct{ j2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_build_go_print_module_fn__1901000337_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A struct{ j2g_header uint64; F_test_files, F_tests any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class *jrt.Class



type A_arbace_build_go_program_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000263_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000263_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000265_A struct{ j2g_header uint64; F_opts any }

var A_arbace_build_go_program_fn__1901000265_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000277_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000277_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_A struct{ j2g_header uint64; F_module any }

var A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A struct{ j2g_header uint64; F_iter__1901000267, F_module, F_s__1901000268 any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A struct{ j2g_header uint64; F_b__1901000270 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000066_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_fn__1901000066_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000068_A struct{ j2g_header uint64; F_cache any }

var A_arbace_build_go_read_all_fn__1901000068_A_fn_class *jrt.Class



type A_arbace_build_go_read_index_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_index_A_fn_class *jrt.Class



type A_arbace_build_go_read_program_edn_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_program_edn_A_fn_class *jrt.Class



type A_arbace_build_go_rel_path_A struct{ j2g_header uint64 }

var A_arbace_build_go_rel_path_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000099_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_fn__1901000099_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000101_A struct{ j2g_header uint64; F_m any }

var A_arbace_build_go_root_packages_fn__1901000101_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000158_A struct{ j2g_header uint64; F_covered, F_known_QMARK_ any }

var A_arbace_build_go_root_packages_fn__1901000158_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000187_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000187_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000192_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000192_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A struct{ j2g_header uint64; F_s__1901000104, F_iter__1901000103, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A struct{ j2g_header uint64; F_b__1901000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A struct{ j2g_header uint64; F_iter__1901000131, F_s__1901000132 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A struct{ j2g_header uint64; F_iter__1901000133, F_s__1901000134 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A struct{ j2g_header uint64; F_b__1901000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid, F_s__1901000163, F_iter__1901000162 any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_b__1901000165, F_dir, F_valid any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_s__1901000195, F_iter__1901000194, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_b__1901000197 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A struct{ j2g_header uint64; F_s__1901000205, F_iter__1901000204, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A struct{ j2g_header uint64; F_b__1901000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_known_QMARK___1901000156_A struct{ j2g_header uint64; F_index_file, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A struct{ j2g_header uint64; F_read_fn, F_known_QMARK_, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class *jrt.Class



type A_arbace_build_go_run_A struct{ j2g_header uint64 }

var A_arbace_build_go_run_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_fn__1901000281_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_fn__1901000281_A_fn_class *jrt.Class



type A_arbace_build_go_tamago_go_sum_A struct{ j2g_header uint64 }

var A_arbace_build_go_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_build_go_toolchain_lang_A struct{ j2g_header uint64 }

var A_arbace_build_go_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_with_line_files_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__fn__1901000091_A struct{ j2g_header uint64; F_ok_QMARK_ any }

var A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A struct{ j2g_header uint64; F_printed any }

var A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__printed__1901000087_A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class *jrt.Class
