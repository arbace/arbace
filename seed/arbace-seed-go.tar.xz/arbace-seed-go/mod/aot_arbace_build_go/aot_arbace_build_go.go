//line aot_arbace_build_go.ae:1
package aot_arbace_build_go

import (
	"arbace/aot_arbace_core"
	"arbace/aot_arbace_repr_go_print"
	"arbace/aot_arbace_string"
	"arbace/jrt"
	"arbace/lang"
)
//line :1:1
func A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_New() *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_build_go_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_build_go_A_const_1); lang.IFn_Cast(A_arbace_build_go_A_const_2.GetRawRoot__O()).Invoke_O_O__O(A_arbace_build_go_A_const_3, A_arbace_build_go_A_const_4); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_58)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_59)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_60)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_61)); jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_62)); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_63)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :1:1
func A_arbace_build_go_eval1901000008_fn__1901000009_A_New() *A_arbace_build_go_eval1901000008_fn__1901000009_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_eval1901000008_fn__1901000009_A{}; t.Ctor(); return t }
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Ctor() {}
//line :1:1
func (t *A_arbace_build_go_eval1901000008_fn__1901000009_A) Invoke_O__O(self any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_5.GetRawRoot__O()); var tmp2 any; var root_16 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_17 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_16, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_18 lang.IFn; if linked_17 == nil { ifn_18 = lang.IFn_Cast(root_16) } else { ifn_18 = nil }; var arg_19 any = A_arbace_build_go_A_const_7; if linked_17 == nil { tmp2 = ifn_18.Invoke_O__O(arg_19) } else { tmp2 = linked_17.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_16, arg_19) }; return tmp1.Invoke_O_O_O__O(tmp2, A_arbace_build_go_A_const_8.GetRawRoot__O(), A_arbace_build_go_A_const_9) }






























































func A_arbace_build_go_fail_A_New() *A_arbace_build_go_fail_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_fail_A{}; t.Ctor(); return t }
//line :64:1
func (t *A_arbace_build_go_fail_A) Ctor() {}
//line :64:1
func (t *A_arbace_build_go_fail_A) DoInvoke_O_O_O__O(self, msg__0, p__1901000012__1 any) any { var vec__1901000013__3 any = p__1901000012__1; var data__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000013__3, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp1 any; var root_20 any = A_arbace_build_go_A_const_10.GetRawRoot__O(); var linked_21 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_20, aot_arbace_core.A_arbace_core_ex_info_A_fn_class); var ifn_22 lang.IFn; if
												linked_21 == nil { ifn_22 = lang.IFn_Cast(root_20) } else { ifn_22 = nil }; var arg_23 any = msg__0; var arg_24 any; var root_25 any = A_arbace_build_go_A_const_11.GetRawRoot__O(); var linked_26 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_25, aot_arbace_core.A_arbace_core_merge_A_fn_class); var ifn_27 lang.IFn; if linked_26 == nil { ifn_27 = lang.IFn_Cast(root_25) } else { ifn_27 = nil }; var arg_28 any = A_arbace_build_go_A_const_12; var arg_29 any = data__4; if linked_26 == nil { arg_24 = ifn_27.Invoke_O_O__O(arg_28, arg_29) } else { arg_24 = linked_26.(*aot_arbace_core.A_arbace_core_merge_A).Invoke_O_O_O__O(root_25, arg_28, arg_29) }; if linked_21 == nil { tmp1 = ifn_22.Invoke_O_O__O(arg_23, arg_24) } else { tmp1 = linked_21.(*aot_arbace_core.A_arbace_core_ex_info_A).Invoke_O_O_O__O(root_20, arg_23, arg_24) }; /*line :64:1*/panic(jrt.Thrown(jrt.Throwable_Cast(tmp1))) }





func A_arbace_build_go_data_dir_QMARK__A_New() *A_arbace_build_go_data_dir_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_data_dir_QMARK__A{}; t.Ctor(); return t }
//line :70:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Ctor() {}
//line :70:1
func (t *A_arbace_build_go_data_dir_QMARK__A) Invoke_O_O_O__O(self, dir__0, f__1 any) any { { var d__3 any = jrt.NN(jrt.File_Cast(f__1)).GetParentFile__File().Ref(); L1: for {




	var tmp1 bool; var or__1927000174__auto____4 bool = lang.Util_Identical_O_O__Z_NoInit(d__3, nil); if or__1927000174__auto____4 { tmp1 = or__1927000174__auto____4 } else { tmp1 = lang.Util_Equiv_O_O__Z_NoInit(jrt.NN(jrt.File_Cast(d__3)).GetAbsoluteFile__File().Ref(), jrt.NN(jrt.File_Cast(dir__0)).GetAbsoluteFile__File().Ref()) }; if tmp1 { return jrt.Boolean_FALSE.Ref() } else { if jrt.File_New_File_String(jrt.File_Cast(d__3), Lit_57).IsFile__Z() { return jrt.Boolean_TRUE.Ref() } else { if A_arbace_build_go_A_const_13 != nil {

		d__3 = jrt.NN(jrt.File_Cast(d__3)).GetParentFile__File().Ref(); continue L1 } else {
//line :75:1
			return nil } } } } }; /*line :70:1*/panic("j2g: unreachable") }








func A_arbace_build_go_clj_files_A_New() *A_arbace_build_go_clj_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_A{}; t.Ctor(); return t }
//line :79:1
func (t *A_arbace_build_go_clj_files_A) Ctor() {}
//line :79:1
func (t *A_arbace_build_go_clj_files_A) Invoke_O_O__O(self, dir__0 any) any {



	var root_30 any = A_arbace_build_go_A_const_14.GetRawRoot__O(); var linked_31 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_30, aot_arbace_core.A_arbace_core_sort_by_A_fn_class); var ifn_32 lang.IFn; if linked_31 == nil { ifn_32 = lang.IFn_Cast(root_30) } else { ifn_32 = nil }; var arg_33 any; var tmp1 any = A_arbace_build_go_clj_files_fn__1901000020_A_New(); var tmp2 *jrt.Class; var fncls__35 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000020_A_fn_class; if fncls__35 == nil { var fncls__35d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_48, false); A_arbace_build_go_clj_files_fn__1901000020_A_fn_class = fncls__35d; tmp2 = fncls__35d } else { tmp2 = fncls__35 }; arg_33 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_34 any; var root_36 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_37 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_36, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_38 lang.IFn
//line :81:1
	if linked_37 == nil { ifn_38 = lang.IFn_Cast(root_36) } else { ifn_38 = nil }; var arg_39 any; var tmp3 any = A_arbace_build_go_clj_files_fn__1901000022_A_New_O(dir__0); var tmp4 *jrt.Class; var fncls__55 *jrt.Class = A_arbace_build_go_clj_files_fn__1901000022_A_fn_class; if fncls__55 == nil { var fncls__55d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_49, false); A_arbace_build_go_clj_files_fn__1901000022_A_fn_class = fncls__55d; tmp4 = fncls__55d } else { tmp4 = fncls__55 }; arg_39 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_40 any; var root_56 any = A_arbace_build_go_A_const_19.GetRawRoot__O(); var linked_57 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_56, aot_arbace_core.A_arbace_core_file_seq_A_fn_class); var ifn_58 lang.IFn
//line :80:1
	if linked_57 == nil { ifn_58 = lang.IFn_Cast(root_56) } else { ifn_58 = nil }; var arg_59 any = dir__0; if linked_57 == nil { arg_40 = ifn_58.Invoke_O__O(arg_59) } else { arg_40 = linked_57.(*aot_arbace_core.A_arbace_core_file_seq_A).Invoke_O_O__O(root_56, arg_59) }
	if linked_37 == nil { arg_34 = ifn_38.Invoke_O_O__O(arg_39, arg_40) } else { arg_34 = linked_37.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_36, arg_39, arg_40)
	}
	if linked_31 == nil { return ifn_32.Invoke_O_O__O(arg_33, arg_34) } else { return linked_31.(*aot_arbace_core.A_arbace_core_sort_by_A).Invoke_O_O_O__O(root_30, arg_33, arg_34) } }
//line :81:1
func A_arbace_build_go_clj_files_fn__1901000022_A_New_O(p0 any) *A_arbace_build_go_clj_files_fn__1901000022_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000022_A{}; t.Ctor_O(p0); return t }
//line :81:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :81:1
func (t *A_arbace_build_go_clj_files_fn__1901000022_A) Invoke_O_O__O(self, p1__1901000018_SHARP___1 any) any { var and__1927000168__auto____2 bool = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).IsFile__Z(); if and__1927000168__auto____2 { var and__1927000168__auto____3 any; var root_41 any = A_arbace_build_go_A_const_16.GetRawRoot__O(); var linked_42 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_41, aot_arbace_string.A_arbace_string_ends_with_QMARK__A_fn_class); var ifn_43 lang.IFn; if linked_42 == nil { ifn_43 = lang.IFn_Cast(root_41) } else { ifn_43 = nil }; var arg_44 any = jrt.NN(jrt.File_Cast(p1__1901000018_SHARP___1)).GetName__String().Ref(); var arg_45 any = Lit_50; if linked_42 == nil { and__1927000168__auto____3 = ifn_43.Invoke_O_O__O(arg_44, arg_45) } else { and__1927000168__auto____3 = linked_42.(*aot_arbace_string.A_arbace_string_ends_with_QMARK__A).Invoke_O_O_O__O(root_41, arg_44, arg_45) }; if jrt.J2g_Truth(and__1927000168__auto____3) {
														var root_46 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_47 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_46, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_48 lang.IFn; if linked_47 == nil { ifn_48 = lang.IFn_Cast(root_46) } else { ifn_48 = nil }; var arg_49 any; var root_50 any = A_arbace_build_go_A_const_18.GetRawRoot__O(); var linked_51 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_50, A_arbace_build_go_data_dir_QMARK__A_fn_class); var ifn_52 lang.IFn; if linked_51 == nil { ifn_52 = lang.IFn_Cast(root_50) } else { ifn_52 = nil }; var arg_53 any = t.F_dir; var arg_54 any = p1__1901000018_SHARP___1; if linked_51 == nil { arg_49 = ifn_52.Invoke_O_O__O(arg_53, arg_54) } else { arg_49 = linked_51.(*A_arbace_build_go_data_dir_QMARK__A).Invoke_O_O_O__O(root_50, arg_53, arg_54) }; if linked_47 == nil { return ifn_48.Invoke_O__O(arg_49) } else { return linked_47.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_46, arg_49) } } else {
//line :81:1
		return and__1927000168__auto____3 } } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____2).Ref() } }

func A_arbace_build_go_clj_files_fn__1901000020_A_New() *A_arbace_build_go_clj_files_fn__1901000020_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_clj_files_fn__1901000020_A{}; t.Ctor(); return t }
//line :83:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Ctor() {}
//line :83:1
func (t *A_arbace_build_go_clj_files_fn__1901000020_A) Invoke_O_O__O(self, p1__1901000019_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000019_SHARP___1)).GetPath__String().Ref() }

func A_arbace_build_go_package_file_QMARK__A_New() *A_arbace_build_go_package_file_QMARK__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__A{}; t.Ctor(); return t }
//line :85:1
func (t *A_arbace_build_go_package_file_QMARK__A) Ctor() {}
//line :85:1
func (t *A_arbace_build_go_package_file_QMARK__A) Invoke_O_O_O__O(self, f__0, read_fn__1 any) any { var forms__3 any = lang.IFn_Cast(read_fn__1).Invoke_O__O(f__0); var ns_form__4 any; var root_60 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_61 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_60, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_62 lang.IFn; if




	linked_61 == nil { ifn_62 = lang.IFn_Cast(root_60) } else { ifn_62 = nil }; var arg_63 any; var root_64 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_65 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_64, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_66 lang.IFn; if linked_65 == nil { ifn_66 = lang.IFn_Cast(root_64) } else { ifn_66 = nil }; var arg_67 any; var tmp1 any = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New(); var tmp2 *jrt.Class; var fncls__77 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class; if fncls__77 == nil { var fncls__77d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_81, false); A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class = fncls__77d; tmp2 = fncls__77d } else { tmp2 = fncls__77 }; arg_67 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_68 any = forms__3; if linked_65 == nil { arg_63 = ifn_66.Invoke_O_O__O(arg_67, arg_68) } else { arg_63 = linked_65.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_64, arg_67, arg_68) }; if linked_61 == nil { ns_form__4 = ifn_62.Invoke_O__O(arg_63) } else { ns_form__4 = linked_61.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_60, arg_63) }; var aliases__5 any; if
	jrt.J2g_Truth(ns_form__4) { aliases__5 = A_arbace_build_go_A_const_23.Invoke_O__O(ns_form__4) } else { aliases__5 = nil }; var tmp3 any; var and__1927000168__auto____6 any = ns_form__4; if

	jrt.J2g_Truth(and__1927000168__auto____6) {
		var root_78 any = A_arbace_build_go_A_const_24.GetRawRoot__O(); var linked_79 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_78, aot_arbace_core.A_arbace_core_some_A_fn_class); var ifn_80 lang.IFn; if linked_79 == nil { ifn_80 = lang.IFn_Cast(root_78) } else { ifn_80 = nil }; var arg_81 any; var tmp4 any = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(aliases__5); var tmp5 *jrt.Class; var fncls__116 *jrt.Class = A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class; if fncls__116 == nil { var fncls__116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_82, false); A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class = fncls__116d; tmp5 = fncls__116d } else { tmp5 = fncls__116 }; arg_81 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_82 any = forms__3; if linked_79 == nil { tmp3 = ifn_80.Invoke_O_O__O(arg_81, arg_82) } else { tmp3 = linked_79.(*aot_arbace_core.A_arbace_core_some_A).Invoke_O_O_O__O(root_78, arg_81, arg_82) } } else {
//line :93:1
			tmp3 = and__1927000168__auto____6 }; return /*line :92:1*/ jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tmp3)).Ref() }
//line :90:1
func A_arbace_build_go_package_file_QMARK__fn__1901000027_A_New() *A_arbace_build_go_package_file_QMARK__fn__1901000027_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000027_A{}; t.Ctor(); return t }
//line :90:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Ctor() {}
//line :90:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000027_A) Invoke_O_O__O(self, p1__1901000025_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_69 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_70 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_69, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_71 lang.IFn; if linked_70 == nil { ifn_71 = lang.IFn_Cast(root_69) } else { ifn_71 = nil }; var arg_72 any = p1__1901000025_SHARP___1; if linked_70 == nil { and__1927000168__auto____2 = ifn_71.Invoke_O__O(arg_72) } else { and__1927000168__auto____2 = linked_70.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_69, arg_72) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 any = A_arbace_build_go_A_const_22; var tmp2 any; var root_73 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_74 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_73, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_75 lang.IFn; if linked_74 == nil { ifn_75 = lang.IFn_Cast(root_73) } else { ifn_75 = nil }; var arg_76 any = p1__1901000025_SHARP___1; if linked_74 == nil { tmp2 = ifn_75.Invoke_O__O(arg_76) } else { tmp2 = linked_74.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_73, arg_76) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(tmp1, tmp2)).Ref() } else { return and__1927000168__auto____2 } }



func A_arbace_build_go_package_file_QMARK__fn__1901000029_A_New_O(p0 any) *A_arbace_build_go_package_file_QMARK__fn__1901000029_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_package_file_QMARK__fn__1901000029_A{}; t.Ctor_O(p0); return t }
//line :94:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Ctor_O(c__aliases any) { t.F_aliases = c__aliases }
//line :94:1
func (t *A_arbace_build_go_package_file_QMARK__fn__1901000029_A) Invoke_O_O__O(self, p1__1901000026_SHARP___1 any) any { var and__1927000168__auto____2 any; var root_83 any = A_arbace_build_go_A_const_21.GetRawRoot__O(); var linked_84 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_83, aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A_fn_class); var ifn_85 lang.IFn; if linked_84 == nil { ifn_85 = lang.IFn_Cast(root_83) } else { ifn_85 = nil }; var arg_86 any = p1__1901000026_SHARP___1; if linked_84 == nil { and__1927000168__auto____2 = ifn_85.Invoke_O__O(arg_86) } else { and__1927000168__auto____2 = linked_84.(*aot_arbace_core.A_arbace_core_seq_QMARK___1927000030_A).Invoke_O_O__O(root_83, arg_86) }; if jrt.J2g_Truth(and__1927000168__auto____2) { var and__1927000168__auto____3 any; var root_87 any = A_arbace_build_go_A_const_25.GetRawRoot__O(); var linked_88 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_87, aot_arbace_core.A_arbace_core_symbol_QMARK__A_fn_class); var ifn_89 lang.IFn; if linked_88 == nil { ifn_89 = lang.IFn_Cast(root_87) } else { ifn_89 = nil }; var arg_90 any; var root_91 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_92 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_91, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_93 lang.IFn; if linked_92 == nil { ifn_93 = lang.IFn_Cast(root_91) } else { ifn_93 = nil }; var arg_94 any = p1__1901000026_SHARP___1; if linked_92 == nil { arg_90 = ifn_93.Invoke_O__O(arg_94) } else { arg_90 = linked_92.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_91, arg_94) }; if linked_88 == nil { and__1927000168__auto____3 = ifn_89.Invoke_O__O(arg_90) } else { and__1927000168__auto____3 = linked_88.(*aot_arbace_core.A_arbace_core_symbol_QMARK__A).Invoke_O_O__O(root_87, arg_90) }; if jrt.J2g_Truth(and__1927000168__auto____3) { var and__1927000168__auto____4 bool; var tmp1 any; var root_95 any = A_arbace_build_go_A_const_26.GetRawRoot__O(); var linked_96 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_95, aot_arbace_core.A_arbace_core_name_A_fn_class); var ifn_97 lang.IFn
															if linked_96 == nil { ifn_97 = lang.IFn_Cast(root_95) } else { ifn_97 = nil }; var arg_98 any; var root_99 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_100 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_99, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_101 lang.IFn; if linked_100 == nil { ifn_101 = lang.IFn_Cast(root_99) } else { ifn_101 = nil }; var arg_102 any = p1__1901000026_SHARP___1; if linked_100 == nil { arg_98 = ifn_101.Invoke_O__O(arg_102) } else { arg_98 = linked_100.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_99, arg_102) }; if linked_96 == nil { tmp1 = ifn_97.Invoke_O__O(arg_98) } else { tmp1 = linked_96.(*aot_arbace_core.A_arbace_core_name_A).Invoke_O_O__O(root_95, arg_98) }; and__1927000168__auto____4 = lang.Util_Equiv_O_O__Z_NoInit(Lit_83, tmp1)
//line :94:1
	if and__1927000168__auto____4 {

		var root_103 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_104 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_103, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_105 lang.IFn; if linked_104 == nil { ifn_105 = lang.IFn_Cast(root_103) } else { ifn_105 = nil }; var arg_106 any = t.F_aliases; var arg_107 any; var root_108 any = A_arbace_build_go_A_const_28.GetRawRoot__O(); var linked_109 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_108, aot_arbace_core.A_arbace_core_namespace_A_fn_class); var ifn_110 lang.IFn; if linked_109 == nil { ifn_110 = lang.IFn_Cast(root_108) } else { ifn_110 = nil }; var arg_111 any; var root_112 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_113 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_112, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_114 lang.IFn; if linked_113 == nil { ifn_114 = lang.IFn_Cast(root_112) } else { ifn_114 = nil }; var arg_115 any = p1__1901000026_SHARP___1; if linked_113 == nil { arg_111 = ifn_114.Invoke_O__O(arg_115) } else { arg_111 = linked_113.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_112, arg_115) }; if linked_109 == nil { arg_107 = ifn_110.Invoke_O__O(arg_111) } else { arg_107 = linked_109.(*aot_arbace_core.A_arbace_core_namespace_A).Invoke_O_O__O(root_108, arg_111) }; if linked_104 == nil { return ifn_105.Invoke_O_O__O(arg_106, arg_107) } else { return linked_104.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_103, arg_106, arg_107) } } else {
//line :94:1
			return jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() } } else { return and__1927000168__auto____3 } } else { return and__1927000168__auto____2 } }






func A_arbace_build_go_rel_path_A_New() *A_arbace_build_go_rel_path_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_rel_path_A{}; t.Ctor(); return t }
//line :101:1
func (t *A_arbace_build_go_rel_path_A) Ctor() {}
//line :101:1
func (t *A_arbace_build_go_rel_path_A) Invoke_O_O_O__O(self, base__0, f__1 any) any {
	var root_117 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_118 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_117, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_119 lang.IFn; if linked_118 == nil { ifn_119 = lang.IFn_Cast(root_117) } else { ifn_119 = nil }; var arg_120 any = jrt.NN(jrt.NN(jrt.File_Cast(base__0)).GetAbsoluteFile__File()).ToPath__Path().Relativize_Path__Path(jrt.NN(jrt.NN(jrt.File_Cast(f__1)).GetAbsoluteFile__File()).ToPath__Path()); if linked_118 == nil { return ifn_119.Invoke_O__O(arg_120) } else { return linked_118.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_117, arg_120)
	} }
func A_arbace_build_go_packages_A_New() *A_arbace_build_go_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_A{}; t.Ctor(); return t }
//line :104:1
func (t *A_arbace_build_go_packages_A) Ctor() {}
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O_O__O(self, dir__0, roots__1, print_cache__2 any) any { var own__4 any; var root_121 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_121, A_arbace_build_go_root_packages_A_fn_class); var ifn_123 lang.IFn; if








	linked_122 == nil { ifn_123 = lang.IFn_Cast(root_121) } else { ifn_123 = nil }; var arg_124 any = dir__0; var arg_125 any = print_cache__2; if linked_122 == nil { own__4 = ifn_123.Invoke_O_O__O(arg_124, arg_125) } else { own__4 = linked_122.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_121, arg_124, arg_125) }; var more__5 any; var iter__1927001039__auto____5 any; var tmp1 any = /*line :104:1*/A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(print_cache__2); var tmp2 *jrt.Class; var fncls__242 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class; if









	fncls__242 == nil { var fncls__242d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_84, false); A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class = fncls__242d; tmp2 = fncls__242d } else { tmp2 = fncls__242 }; iter__1927001039__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); more__5 = lang.IFn_Cast(iter__1927001039__auto____5).Invoke_O__O(roots__1); var pkgs__6 any; var root_243 any = /*line :104:1*/A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_244 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_243, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_245 lang.IFn; if













	linked_244 == nil { ifn_245 = lang.IFn_Cast(root_243) } else { ifn_245 = nil }; var arg_246 any; var root_247 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_248 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_247, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_249 lang.IFn; if linked_248 == nil { ifn_249 = lang.IFn_Cast(root_247) } else { ifn_249 = nil }; var arg_250 any = own__4; var arg_251 any = more__5; if linked_248 == nil { arg_246 = ifn_249.Invoke_O_O__O(arg_250, arg_251) } else { arg_246 = linked_248.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_247, arg_250, arg_251) }; if linked_244 == nil { pkgs__6 = ifn_245.Invoke_O__O(arg_246) } else { pkgs__6 = linked_244.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_243, arg_246) }; var seq_1901000050__7 any; var root_252 any = /*line :104:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_253 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_252, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_254 lang.IFn; if














	linked_253 == nil { ifn_254 = lang.IFn_Cast(root_252) } else { ifn_254 = nil }; var arg_255 any; var root_256 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_257 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_256, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_258 lang.IFn; if linked_257 == nil { ifn_258 = lang.IFn_Cast(root_256) } else { ifn_258 = nil }; var arg_259 any = A_arbace_build_go_A_const_46; var arg_260 any = pkgs__6; if linked_257 == nil { arg_255 = ifn_258.Invoke_O_O__O(arg_259, arg_260) } else { arg_255 = linked_257.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_256, arg_259, arg_260) }; if linked_253 == nil { seq_1901000050__7 = ifn_254.Invoke_O__O(arg_255) } else { seq_1901000050__7 = linked_253.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_252, arg_255) }; var chunk_1901000051__8 any; var count_1901000052__9 int64 = 0; var i_1901000053__10 int64 = 0; L1:
//line :104:1
	for {














		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000053__10, count_1901000052__9) { var vec__1901000054__11 any = lang.Indexed_Cast(chunk_1901000051__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000053__10)); var path__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000054__11, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__13)), 1) {
			var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp5 any; var root_281 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_281, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_283 lang.IFn
			if linked_282 == nil { ifn_283 = lang.IFn_Cast(root_281) } else { ifn_283 = nil }; var arg_284 any = Lit_87; var arg_285 any; var root_286 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_287 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_286, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_288 lang.IFn; if linked_287 == nil { ifn_288 = lang.IFn_Cast(root_286) } else { ifn_288 = nil }; var arg_289 any; var tmp6 any = A_arbace_build_go_packages_fn__1901000057_A_New(); var tmp7 *jrt.Class; var fncls__291 *jrt.Class = A_arbace_build_go_packages_fn__1901000057_A_fn_class; if fncls__291 == nil { var fncls__291d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_88, false); A_arbace_build_go_packages_fn__1901000057_A_fn_class = fncls__291d; tmp7 = fncls__291d } else { tmp7 = fncls__291 }; arg_289 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_290 any = ps__13; if linked_287 == nil { arg_285 = ifn_288.Invoke_O_O__O(arg_289, arg_290) } else { arg_285 = linked_287.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_286, arg_289, arg_290) }; if linked_282 == nil { tmp5 = ifn_283.Invoke_O_O__O(arg_284, arg_285) } else { tmp5 = linked_282.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_281, arg_284, arg_285) }
//line :120:1
			tmp3.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, nil, path__12, nil, tmp5)).Ref())
//line :119:1
			seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } else { seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000053__10); continue L1 } } else { var temp__1927000414__auto____11 any; var root_261 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_261, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_263 lang.IFn; if linked_262 == nil { ifn_263 = lang.IFn_Cast(root_261) } else { ifn_263 = nil }; var arg_264 any = seq_1901000050__7; if linked_262 == nil { temp__1927000414__auto____11 = ifn_263.Invoke_O__O(arg_264) } else { temp__1927000414__auto____11 = linked_262.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_261, arg_264) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000050__12 any = temp__1927000414__auto____11; var tmp8 any; var root_265 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_265, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_267 lang.IFn; if linked_266 == nil { ifn_267 = lang.IFn_Cast(root_265) } else { ifn_267 = nil }; var arg_268 any = seq_1901000050__12; if linked_266 == nil { tmp8 = ifn_267.Invoke_O__O(arg_268) } else { tmp8 = linked_266.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_265, arg_268) }; if jrt.J2g_Truth(tmp8) { var c__1927000678__auto____13 any; var root_269 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_269, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_271 lang.IFn; if linked_270 == nil { ifn_271 = lang.IFn_Cast(root_269) } else { ifn_271 = nil }; var arg_272 any = seq_1901000050__12; if linked_270 == nil { c__1927000678__auto____13 = ifn_271.Invoke_O__O(arg_272) } else { c__1927000678__auto____13 = linked_270.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_269, arg_272) }; var tmp9 any; var root_292 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_293 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_292, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_294 lang.IFn; if linked_293 == nil { ifn_294 = lang.IFn_Cast(root_292) } else { ifn_294 = nil }; var arg_295 any = seq_1901000050__12; if linked_293 == nil { tmp9 = ifn_294.Invoke_O__O(arg_295) } else { tmp9 = linked_293.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_292, arg_295) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp9, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000059__13 any; var root_273 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_273, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_275 lang.IFn; if linked_274 == nil { ifn_275 = lang.IFn_Cast(root_273) } else { ifn_275 = nil }; var arg_276 any = seq_1901000050__12; if linked_274 == nil { vec__1901000059__13 = ifn_275.Invoke_O__O(arg_276) } else { vec__1901000059__13 = linked_274.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_273, arg_276) }; var path__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000059__13, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__15)), 1) {
				var tmp10 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp12 any; var root_300 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_301 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_300, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_302 lang.IFn
				if linked_301 == nil { ifn_302 = lang.IFn_Cast(root_300) } else { ifn_302 = nil }; var arg_303 any = Lit_87; var arg_304 any; var root_305 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_306 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_305, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_307 lang.IFn; if linked_306 == nil { ifn_307 = lang.IFn_Cast(root_305) } else { ifn_307 = nil }; var arg_308 any; var tmp13 any = A_arbace_build_go_packages_fn__1901000062_A_New(); var tmp14 *jrt.Class; var fncls__310 *jrt.Class = A_arbace_build_go_packages_fn__1901000062_A_fn_class; if fncls__310 == nil { var fncls__310d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_89, false); A_arbace_build_go_packages_fn__1901000062_A_fn_class = fncls__310d; tmp14 = fncls__310d } else { tmp14 = fncls__310 }; arg_308 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp13, tmp14, nil); var arg_309 any = ps__15; if linked_306 == nil { arg_304 = ifn_307.Invoke_O_O__O(arg_308, arg_309) } else { arg_304 = linked_306.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_305, arg_308, arg_309) }; if linked_301 == nil { tmp12 = ifn_302.Invoke_O_O__O(arg_303, arg_304) } else { tmp12 = linked_301.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_300, arg_303, arg_304) }
//line :120:1
				tmp10.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, path__14, nil, tmp12)).Ref())
//line :119:1
				var tmp15 any; var root_311 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_312 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_311, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_313 lang.IFn; if linked_312 == nil { ifn_313 = lang.IFn_Cast(root_311) } else { ifn_313 = nil }; var arg_314 any = seq_1901000050__12; if linked_312 == nil { tmp15 = ifn_313.Invoke_O__O(arg_314) } else { tmp15 = linked_312.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_311, arg_314) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp15, nil, 0, 0; continue L1 } else { var tmp16 any; var root_315 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_315, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_317 lang.IFn; if linked_316 == nil { ifn_317 = lang.IFn_Cast(root_315) } else { ifn_317 = nil }; var arg_318 any = seq_1901000050__12; if linked_316 == nil { tmp16 = ifn_317.Invoke_O__O(arg_318) } else { tmp16 = linked_316.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_315, arg_318) }; seq_1901000050__7, chunk_1901000051__8, count_1901000052__9, i_1901000053__10 = tmp16, nil, 0, 0; continue L1 } } } }
//line :104:1
		break L1 }; return pkgs__6 }
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O_O__O(self, dir__0, roots__1 any) any {






	var root_319 any = A_arbace_build_go_A_const_52.GetRawRoot__O(); var linked_320 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_319, A_arbace_build_go_packages_A_fn_class); var ifn_321 lang.IFn; if linked_320 == nil { ifn_321 = lang.IFn_Cast(root_319) } else { ifn_321 = nil }; var arg_322 any = dir__0; var arg_323 any = roots__1; var arg_324 any; if linked_320 == nil { return ifn_321.Invoke_O_O_O__O(arg_322, arg_323, arg_324) } else { return linked_320.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_319, arg_322, arg_323, arg_324) } }
//line :104:1
func (t *A_arbace_build_go_packages_A) Invoke_O_O__O(self, dir__0 any) any {





	var root_325 any = A_arbace_build_go_A_const_52.GetRawRoot__O(); var linked_326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_325, A_arbace_build_go_packages_A_fn_class); var ifn_327 lang.IFn; if linked_326 == nil { ifn_327 = lang.IFn_Cast(root_325) } else { ifn_327 = nil }; var arg_328 any = dir__0; var arg_329 any; var arg_330 any; if linked_326 == nil { return ifn_327.Invoke_O_O_O__O(arg_328, arg_329, arg_330) } else { return linked_326.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_325, arg_328, arg_329, arg_330)
	}
}

func A_arbace_build_go_packages_iter__1901000034__1901000040_A_New_O(p0 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_A{}; t.Ctor_O(p0); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Ctor_O(c__print_cache any) { t.F_print_cache = c__print_cache }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_A) Invoke_O_O__O(self, s__1901000035__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(self, t.F_print_cache, s__1901000035__1); var tmp2 *jrt.Class; var fncls__241 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class; if fncls__241 == nil { var fncls__241d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_90, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class = fncls__241d; tmp2 = fncls__241d } else { tmp2 = fncls__241 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Ctor_O_O_O(c__iter__1901000034, c__print_cache, c__s__1901000035 any) { t.F_iter__1901000034 = c__iter__1901000034; t.F_print_cache = c__print_cache; t.F_s__1901000035 = c__s__1901000035 }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A) Invoke_O__O(self any) any { { var s__1901000035__1 any; var t_ any = t.F_s__1901000035; t.F_s__1901000035 = nil; s__1901000035__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_126 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_127 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_126, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_128 lang.IFn; if linked_127 == nil { ifn_128 = lang.IFn_Cast(root_126) } else { ifn_128 = nil }; var arg_129 any = s__1901000035__1; if linked_127 == nil { temp__1927000414__auto____2 = ifn_128.Invoke_O__O(arg_129) } else { temp__1927000414__auto____2 = linked_127.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_126, arg_129) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var r__4 any; var root_130 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_130, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_132 lang.IFn; if linked_131 == nil { ifn_132 = lang.IFn_Cast(root_130) } else { ifn_132 = nil }; var arg_133 any = xs__1927001018__auto____3; if linked_131 == nil { r__4 = ifn_132.Invoke_O__O(arg_133) } else { r__4 = linked_131.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_130, arg_133) }; var iterys__1927001035__auto____5 any; var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New(); var tmp2 *jrt.Class; var fncls__214 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class; if fncls__214 == nil { var fncls__214d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_91, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class = fncls__214d; tmp2 = fncls__214d } else { tmp2 = fncls__214 }; iterys__1927001035__auto____5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____6 any; var root_215 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_216 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_215, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_217 lang.IFn; if linked_216 == nil { ifn_217 = lang.IFn_Cast(root_215) } else { ifn_217 = nil }; var arg_218 any; var tmp3 lang.IFn = lang.IFn_Cast(iterys__1927001035__auto____5); var tmp4 any; var root_219 any = A_arbace_build_go_A_const_30.GetRawRoot__O(); var linked_220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_219, A_arbace_build_go_root_packages_A_fn_class); var ifn_221 lang.IFn
														if linked_220 == nil { ifn_221 = lang.IFn_Cast(root_219) } else { ifn_221 = nil }; var arg_222 any; var tmp5 any; var root_224 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_224, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_226 lang.IFn; if linked_225 == nil { ifn_226 = lang.IFn_Cast(root_224) } else { ifn_226 = nil }; var arg_227 any = r__4; if linked_225 == nil { tmp5 = ifn_226.Invoke_O__O(arg_227) } else { tmp5 = linked_225.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_224, arg_227) }; arg_222 = jrt.File_New_String(jrt.String_Cast(tmp5)); var arg_223 any = t.F_print_cache; if linked_220 == nil { tmp4 = ifn_221.Invoke_O_O__O(arg_222, arg_223) } else { tmp4 = linked_220.(*A_arbace_build_go_root_packages_A).Invoke_O_O_O__O(root_219, arg_222, arg_223) }
//line :114:1
	arg_218 = tmp3.Invoke_O__O(tmp4); if linked_216 == nil { fs__1927001036__auto____6 = ifn_217.Invoke_O__O(arg_218) } else { fs__1927001036__auto____6 = linked_216.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_215, arg_218) }; if jrt.J2g_Truth(fs__1927001036__auto____6) { var root_228 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_229 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_228, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_230 lang.IFn; if linked_229 == nil { ifn_230 = lang.IFn_Cast(root_228) } else { ifn_230 = nil }; var arg_231 any = fs__1927001036__auto____6; var arg_232 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000034); var tmp7 any; var root_233 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_234 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_233, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_235 lang.IFn; if linked_234 == nil { ifn_235 = lang.IFn_Cast(root_233) } else { ifn_235 = nil }; var arg_236 any = s__1901000035__1; if linked_234 == nil { tmp7 = ifn_235.Invoke_O__O(arg_236) } else { tmp7 = linked_234.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_233, arg_236) }; arg_232 = tmp6.Invoke_O__O(tmp7); if linked_229 == nil { return ifn_230.Invoke_O_O__O(arg_231, arg_232) } else { return linked_229.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_228, arg_231, arg_232) } } else { var tmp8 any; var root_237 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_238 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_237, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_239 lang.IFn; if linked_238 == nil { ifn_239 = lang.IFn_Cast(root_237) } else { ifn_239 = nil }; var arg_240 any = s__1901000035__1; if linked_238 == nil { tmp8 = ifn_239.Invoke_O__O(arg_240) } else { tmp8 = linked_238.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_237, arg_240) }; s__1901000035__1 = tmp8; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_New() *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A{}; t.Ctor(); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Ctor() {}
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A) Invoke_O_O__O(self, s__1901000037__1 any) any { var tmp1 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(self, s__1901000037__1); var tmp2 *jrt.Class; var fncls__213 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class; if fncls__213 == nil { var fncls__213d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_92, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class = fncls__213d; tmp2 = fncls__213d } else { tmp2 = fncls__213 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_New_O_O(p0, p1 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A{}; t.Ctor_O_O(p0, p1); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Ctor_O_O(c__iter__1901000036, c__s__1901000037 any) { t.F_iter__1901000036 = c__iter__1901000036; t.F_s__1901000037 = c__s__1901000037 }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A) Invoke_O__O(self any) any { { var s__1901000037__1 any; var t_ any = t.F_s__1901000037; t.F_s__1901000037 = nil; s__1901000037__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_134 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_134, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_136 lang.IFn; if linked_135 == nil { ifn_136 = lang.IFn_Cast(root_134) } else { ifn_136 = nil }; var arg_137 any = s__1901000037__1; if linked_135 == nil { temp__1927000414__auto____2 = ifn_136.Invoke_O__O(arg_137) } else { temp__1927000414__auto____2 = linked_135.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_134, arg_137) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000037__3 any = temp__1927000414__auto____2; var tmp1 any; var root_138 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_139 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_138, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_140 lang.IFn; if linked_139 == nil { ifn_140 = lang.IFn_Cast(root_138) } else { ifn_140 = nil }; var arg_141 any = s__1901000037__3; if linked_139 == nil { tmp1 = ifn_140.Invoke_O__O(arg_141) } else { tmp1 = linked_139.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_138, arg_141) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_142 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_143 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_142, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_144 lang.IFn; if linked_143 == nil { ifn_144 = lang.IFn_Cast(root_142) } else { ifn_144 = nil }; var arg_145 any = s__1901000037__3; if linked_143 == nil { c__1927001037__auto____4 = ifn_144.Invoke_O__O(arg_145) } else { c__1927001037__auto____4 = linked_143.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_142, arg_145) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000039__6 any; var root_146 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_147 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_146, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_148 lang.IFn; if linked_147 == nil { ifn_148 = lang.IFn_Cast(root_146) } else { ifn_148 = nil }; var arg_149 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_147 == nil { b__1901000039__6 = ifn_148.Invoke_O__O(arg_149) } else { b__1901000039__6 = linked_147.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_146, arg_149) }; var tmp2 any = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(b__1901000039__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__164 *jrt.Class = A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class; if fncls__164 == nil { var fncls__164d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_93, false); A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class = fncls__164d; tmp3 = fncls__164d } else { tmp3 = fncls__164 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_165 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_166 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_165, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_167 lang.IFn; if linked_166 == nil { ifn_167 = lang.IFn_Cast(root_165) } else { ifn_167 = nil }; var arg_168 any; var root_170 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_171 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_170, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_172 lang.IFn; if linked_171 == nil { ifn_172 = lang.IFn_Cast(root_170) } else { ifn_172 = nil }; var arg_173 any = b__1901000039__6; if linked_171 == nil { arg_168 = ifn_172.Invoke_O__O(arg_173) } else { arg_168 = linked_171.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_170, arg_173) }; var arg_169 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp5 any; var root_174 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_175 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_174, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_176 lang.IFn; if linked_175 == nil { ifn_176 = lang.IFn_Cast(root_174) } else { ifn_176 = nil }; var arg_177 any = s__1901000037__3; if linked_175 == nil { tmp5 = ifn_176.Invoke_O__O(arg_177) } else { tmp5 = linked_175.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_174, arg_177) }; arg_169 = tmp4.Invoke_O__O(tmp5); if linked_166 == nil { return ifn_167.Invoke_O_O__O(arg_168, arg_169) } else { return linked_166.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_165, arg_168, arg_169) } } else { var root_178 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_179 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_178, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_180 lang.IFn; if linked_179 == nil { ifn_180 = lang.IFn_Cast(root_178) } else { ifn_180 = nil }; var arg_181 any; var root_183 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_184 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_183, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_185 lang.IFn; if linked_184 == nil { ifn_185 = lang.IFn_Cast(root_183) } else { ifn_185 = nil }; var arg_186 any = b__1901000039__6; if linked_184 == nil { arg_181 = ifn_185.Invoke_O__O(arg_186) } else { arg_181 = linked_184.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_183, arg_186) }; var arg_182 any; if linked_179 == nil { return ifn_180.Invoke_O_O__O(arg_181, arg_182) } else { return linked_179.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_178, arg_181, arg_182) } } } else { var pkg__4 any; var root_187 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_188 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_187, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_189 lang.IFn; if linked_188 == nil { ifn_189 = lang.IFn_Cast(root_187) } else { ifn_189 = nil }; var arg_190 any = s__1901000037__3; if linked_188 == nil { pkg__4 = ifn_189.Invoke_O__O(arg_190) } else { pkg__4 = linked_188.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_187, arg_190) }; var tmp6 any; var root_191 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_192 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_191, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_193 lang.IFn

	if linked_192 == nil { ifn_193 = lang.IFn_Cast(root_191) } else { ifn_193 = nil }; var arg_194 any = Lit_94; var arg_195 any; var root_196 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_197 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_196, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_198 lang.IFn; if linked_197 == nil { ifn_198 = lang.IFn_Cast(root_196) } else { ifn_198 = nil }; var arg_199 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__4); if linked_197 == nil { arg_195 = ifn_198.Invoke_O__O(arg_199) } else { arg_195 = linked_197.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_196, arg_199) }; if linked_192 == nil { tmp6 = ifn_193.Invoke_O_O__O(arg_194, arg_195) } else { tmp6 = linked_192.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_191, arg_194, arg_195) }
//line :114:1
	if jrt.J2g_Truth(tmp6) { var root_200 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_201 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_200, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_202 lang.IFn; if linked_201 == nil { ifn_202 = lang.IFn_Cast(root_200) } else { ifn_202 = nil }; var arg_203 any = pkg__4; var arg_204 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000036); var tmp8 any; var root_205 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_206 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_205, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_207 lang.IFn; if linked_206 == nil { ifn_207 = lang.IFn_Cast(root_205) } else { ifn_207 = nil }; var arg_208 any = s__1901000037__3; if linked_206 == nil { tmp8 = ifn_207.Invoke_O__O(arg_208) } else { tmp8 = linked_206.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_205, arg_208) }; arg_204 = tmp7.Invoke_O__O(tmp8); if linked_201 == nil { return ifn_202.Invoke_O_O__O(arg_203, arg_204) } else { return linked_201.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_200, arg_203, arg_204) } } else { var tmp9 any; var root_209 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_210 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_209, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_211 lang.IFn; if linked_210 == nil { ifn_211 = lang.IFn_Cast(root_209) } else { ifn_211 = nil }; var arg_212 any = s__1901000037__3; if linked_210 == nil { tmp9 = ifn_211.Invoke_O__O(arg_212) } else { tmp9 = linked_210.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_209, arg_212) }; s__1901000037__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :114:1
func A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Ctor_O_I_O(c__b__1901000039 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000039 = c__b__1901000039; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :114:1
func (t *A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A) Invoke_O__O(self any) any { { var i__1901000038__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000038__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000038__1)); var tmp2 any; var root_150 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_151 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_150, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_152 lang.IFn

	if linked_151 == nil { ifn_152 = lang.IFn_Cast(root_150) } else { ifn_152 = nil }; var arg_153 any = Lit_94; var arg_154 any; var root_155 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_156 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_155, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_157 lang.IFn; if linked_156 == nil { ifn_157 = lang.IFn_Cast(root_155) } else { ifn_157 = nil }; var arg_158 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__2); if linked_156 == nil { arg_154 = ifn_157.Invoke_O__O(arg_158) } else { arg_154 = linked_156.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_155, arg_158) }; if linked_151 == nil { tmp2 = ifn_152.Invoke_O_O__O(arg_153, arg_154) } else { tmp2 = linked_151.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_150, arg_153, arg_154) }
//line :114:1
	if jrt.J2g_Truth(tmp2) { var root_159 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_160 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_159, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_161 lang.IFn; if linked_160 == nil { ifn_161 = lang.IFn_Cast(root_159) } else { ifn_161 = nil }; var arg_162 any = t.F_b__1901000039; var arg_163 any = pkg__2; if linked_160 == nil { ifn_161.Invoke_O_O__O(arg_162, arg_163) } else { linked_160.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_159, arg_162, arg_163) }; i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } else { i__1901000038__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000038__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }






func A_arbace_build_go_packages_fn__1901000057_A_New() *A_arbace_build_go_packages_fn__1901000057_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000057_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Ctor() {}
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000057_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }
//line :121:1
func A_arbace_build_go_packages_fn__1901000062_A_New() *A_arbace_build_go_packages_fn__1901000062_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_packages_fn__1901000062_A{}; t.Ctor(); return t }
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Ctor() {}
//line :121:1
func (t *A_arbace_build_go_packages_fn__1901000062_A) Invoke_O_O__O(self, p1__1901000033_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000033_SHARP___1))).GetPath__String().Ref() }


func A_arbace_build_go_read_all_A_New() *A_arbace_build_go_read_all_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_A{}; t.Ctor(); return t }
//line :124:1
func (t *A_arbace_build_go_read_all_A) Ctor() {}
//line :124:1
func (t *A_arbace_build_go_read_all_A) Invoke_O_O__O(self, files__0 any) any { var cache__2 any; var root_331 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_332 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_331, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_333 lang.IFn; if




	linked_332 == nil { ifn_333 = lang.IFn_Cast(root_331) } else { ifn_333 = nil }; var arg_334 any; var root_336 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_337 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_336, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_338 lang.IFn; if linked_337 == nil { ifn_338 = lang.IFn_Cast(root_336) } else { ifn_338 = nil }; var arg_339 any; var tmp1 any = A_arbace_build_go_read_all_fn__1901000066_A_New(); var tmp2 *jrt.Class; var fncls__341 *jrt.Class = A_arbace_build_go_read_all_fn__1901000066_A_fn_class; if fncls__341 == nil { var fncls__341d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_128, false); A_arbace_build_go_read_all_fn__1901000066_A_fn_class = fncls__341d; tmp2 = fncls__341d } else { tmp2 = fncls__341 }; arg_339 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_340 any = files__0; if linked_337 == nil { arg_334 = ifn_338.Invoke_O_O__O(arg_339, arg_340) } else { arg_334 = linked_337.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_336, arg_339, arg_340) }; var arg_335 any; var root_342 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_343 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_342, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_344 lang.IFn; if
	linked_343 == nil { ifn_344 = lang.IFn_Cast(root_342) } else { ifn_344 = nil }; var arg_345 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var arg_346 any = files__0; if linked_343 == nil { arg_335 = ifn_344.Invoke_O_O__O(arg_345, arg_346) } else { arg_335 = linked_343.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_342, arg_345, arg_346) }; if /*line :129:1*/ linked_332 == nil { cache__2 = ifn_333.Invoke_O_O__O(arg_334, arg_335) } else { cache__2 = linked_332.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_331, arg_334, arg_335) }; var tmp3 any =

	A_arbace_build_go_read_all_fn__1901000068_A_New_O(cache__2); var tmp4 *jrt.Class; var fncls__356 *jrt.Class = A_arbace_build_go_read_all_fn__1901000068_A_fn_class; if fncls__356 == nil { var fncls__356d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_129, false); A_arbace_build_go_read_all_fn__1901000068_A_fn_class = fncls__356d; tmp4 = fncls__356d } else { tmp4 = fncls__356 }; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil) }
//line :129:1
func A_arbace_build_go_read_all_fn__1901000066_A_New() *A_arbace_build_go_read_all_fn__1901000066_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000066_A{}; t.Ctor(); return t }
//line :129:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Ctor() {}
//line :129:1
func (t *A_arbace_build_go_read_all_fn__1901000066_A) Invoke_O_O__O(self, p1__1901000065_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000065_SHARP___1)).GetAbsolutePath__String().Ref() }

func A_arbace_build_go_read_all_fn__1901000068_A_New_O(p0 any) *A_arbace_build_go_read_all_fn__1901000068_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_all_fn__1901000068_A{}; t.Ctor_O(p0); return t }
//line :131:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Ctor_O(c__cache any) { t.F_cache = c__cache }
//line :131:1
func (t *A_arbace_build_go_read_all_fn__1901000068_A) Invoke_O_O__O(self, f__1 any) any { var k__2 any = jrt.NN(jrt.File_Cast(f__1)).GetAbsolutePath__String().Ref(); var tmp1 any; var root_347 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_348 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_347, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_349 lang.IFn; if

	linked_348 == nil { ifn_349 = lang.IFn_Cast(root_347) } else { ifn_349 = nil }; var arg_350 any = t.F_cache; var arg_351 any = k__2; if linked_348 == nil { tmp1 = ifn_349.Invoke_O_O__O(arg_350, arg_351) } else { tmp1 = linked_348.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_347, arg_350, arg_351) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_cache, k__2) } else { var root_352 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_353 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_352, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_354 lang.IFn; if linked_353 == nil { ifn_354 = lang.IFn_Cast(root_352) } else { ifn_354 = nil }; var arg_355 any = f__1; if linked_353 == nil { return ifn_354.Invoke_O__O(arg_355) } else { return linked_353.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_352, arg_355) } } }

func A_arbace_build_go_hex_A_New() *A_arbace_build_go_hex_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_A{}; t.Ctor(); return t }
//line :135:1
func (t *A_arbace_build_go_hex_A) Ctor() {}
//line :135:1
func (t *A_arbace_build_go_hex_A) Invoke_O_O__O(self, bs__0 any) any {
	var root_357 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_358 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_357, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_359 lang.IFn; if linked_358 == nil { ifn_359 = lang.IFn_Cast(root_357) } else { ifn_359 = nil }; var arg_360 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_361 any; var root_362 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_363 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_362, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_364 lang.IFn; if linked_363 == nil { ifn_364 = lang.IFn_Cast(root_362) } else { ifn_364 = nil }; var arg_365 any; var tmp1 any = A_arbace_build_go_hex_fn__1901000072_A_New(); var tmp2 *jrt.Class; var fncls__377 *jrt.Class = A_arbace_build_go_hex_fn__1901000072_A_fn_class; if fncls__377 == nil { var fncls__377d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_80, false); A_arbace_build_go_hex_fn__1901000072_A_fn_class = fncls__377d; tmp2 = fncls__377d } else { tmp2 = fncls__377 }; arg_365 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_366 any = bs__0; if linked_363 == nil { arg_361 = ifn_364.Invoke_O_O__O(arg_365, arg_366) } else { arg_361 = linked_363.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_362, arg_365, arg_366) }; if linked_358 == nil { return ifn_359.Invoke_O_O__O(arg_360, arg_361) } else { return linked_358.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_357, arg_360, arg_361) } }
//line :136:1
func A_arbace_build_go_hex_fn__1901000072_A_New() *A_arbace_build_go_hex_fn__1901000072_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_hex_fn__1901000072_A{}; t.Ctor(); return t }
//line :136:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Ctor() {}
//line :136:1
func (t *A_arbace_build_go_hex_fn__1901000072_A) Invoke_O_O__O(self, p1__1901000071_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_372 any = p1__1901000071_SHARP___1; var na_373 int64 = 255; if jrt.Long_InstanceOf(na_372) { var n0_374 int64 = jrt.NN(jrt.Long_Cast(na_372)).LongValue__J(); var n1_375 int64 = na_373; tmp2 = n0_374 & n1_375 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_372, na_373) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_file_sha_A_New() *A_arbace_build_go_file_sha_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_file_sha_A{}; t.Ctor(); return t }
//line :138:1
func (t *A_arbace_build_go_file_sha_A) Ctor() {}
//line :138:1
func (t *A_arbace_build_go_file_sha_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		var root_378 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_378, A_arbace_build_go_hex_A_fn_class); var ifn_380 lang.IFn; if linked_379 == nil { ifn_380 = lang.IFn_Cast(root_378) } else { ifn_380 = nil }; var arg_381 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref(); if linked_379 == nil { return ifn_380.Invoke_O__O(arg_381) } else { return linked_379.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_378, arg_381) } } else {
//line :141:1
			return nil
		}
}
func A_arbace_build_go_collect_package_A_New() *A_arbace_build_go_collect_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_A{}; t.Ctor(); return t }
//line :144:1
func (t *A_arbace_build_go_collect_package_A) Ctor() {}
//line :144:1
func (t *A_arbace_build_go_collect_package_A) Invoke_O_O_O_O__O(self, dir__0, f__1, read_fn__2 any) any { var read__4 any; var root_382 any = A_arbace_build_go_A_const_59.GetRawRoot__O(); var linked_383 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_382, aot_arbace_core.A_arbace_core_atom_A_fn_class); var ifn_384 lang.IFn; if



	linked_383 == nil { ifn_384 = lang.IFn_Cast(root_382) } else { ifn_384 = nil }; var arg_385 any = lang.PersistentVector_EMPTY.Ref(); if linked_383 == nil { read__4 = ifn_384.Invoke_O__O(arg_385) } else { read__4 = linked_383.(*aot_arbace_core.A_arbace_core_atom_A).Invoke_O_O__O(root_382, arg_385) }; var pkg__5 any; var root_386 any = /*line :144:1*/A_arbace_build_go_A_const_60.GetRawRoot__O(); var linked_387 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_386, aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A_fn_class); var ifn_388 lang.IFn; if




	linked_387 == nil { ifn_388 = lang.IFn_Cast(root_386) } else { ifn_388 = nil }; var arg_389 any = f__1; var arg_390 any; var tmp1 any = A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(read_fn__2, read__4); var tmp2 *jrt.Class; var fncls__397 *jrt.Class = A_arbace_build_go_collect_package_fn__1901000076_A_fn_class; if fncls__397 == nil { var fncls__397d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_54, false); A_arbace_build_go_collect_package_fn__1901000076_A_fn_class = fncls__397d; tmp2 = fncls__397d } else { tmp2 = fncls__397 }; arg_390 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_387 == nil { pkg__5 = ifn_388.Invoke_O_O__O(arg_389, arg_390) } else { pkg__5 = linked_387.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_collect_A).Invoke_O_O_O__O(root_386, arg_389, arg_390) }; var tmp3 /*line :144:1*/*lang.Keyword = A_arbace_build_go_A_const_46; var path__6 any = tmp3.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__5)); var tmp4 any; var root_412 any = A_arbace_build_go_A_const_65.GetRawRoot__O(); var linked_413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_412, aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A_fn_class); var ifn_414 lang.IFn; if






	linked_413 == nil { ifn_414 = lang.IFn_Cast(root_412) } else { ifn_414 = nil }; var arg_415 any = path__6; if linked_413 == nil { tmp4 = ifn_414.Invoke_O__O(arg_415) } else { tmp4 = linked_413.(*aot_arbace_core.A_arbace_core_string_QMARK___1927000034_A).Invoke_O_O__O(root_412, arg_415) }; if jrt.J2g_Truth(tmp4) { } else {
		var tmp5 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp6 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_55); var tmp7 any; var root_420 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_420, A_arbace_build_go_rel_path_A_fn_class); var ifn_422 lang.IFn; if linked_421 == nil { ifn_422 = lang.IFn_Cast(root_420) } else { ifn_422 = nil }; var arg_423 any = dir__0; var arg_424 any = f__1; if linked_421 == nil { tmp7 = ifn_422.Invoke_O_O__O(arg_423, arg_424) } else { tmp7 = linked_421.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_420, arg_423, arg_424) }; tmp5.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp6, jrt.RefArrayOf(jrt.Object_class, tmp7, nil)).Ref()) }; var tmp8 lang.IFn =
	lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp9 any = A_arbace_build_go_A_const_50; var tmp10 any = A_arbace_build_go_A_const_46; var tmp11 any = A_arbace_build_go_A_const_64; var tmp12 any; var root_408 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_408, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_410 lang.IFn; if linked_409 == nil { ifn_410 = lang.IFn_Cast(root_408) } else { ifn_410 = nil }; var arg_411 any = read__4; if linked_409 == nil { tmp12 = ifn_410.Invoke_O__O(arg_411) } else { tmp12 = linked_409.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_408, arg_411) }; return tmp8.Invoke_O_O_O_O_O_O_O__O(pkg__5, tmp9, f__1, tmp10, path__6, tmp11, tmp12) }
//line :149:1
func A_arbace_build_go_collect_package_fn__1901000076_A_New_O_O(p0, p1 any) *A_arbace_build_go_collect_package_fn__1901000076_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_package_fn__1901000076_A{}; t.Ctor_O_O(p0, p1); return t }
//line :149:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Ctor_O_O(c__read_fn, c__read any) { t.F_read_fn = c__read_fn; t.F_read = c__read }
//line :149:1
func (t *A_arbace_build_go_collect_package_fn__1901000076_A) Invoke_O_O__O(self, file__1 any) any { var root_391 any = A_arbace_build_go_A_const_61.GetRawRoot__O(); var linked_392 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_391, aot_arbace_core.A_arbace_core_swap_BANG__A_fn_class); var ifn_393 lang.IFn; if linked_392 == nil { ifn_393 = lang.IFn_Cast(root_391) } else { ifn_393 = nil }; var arg_394 any = t.F_read; var arg_395 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_396 any = file__1; if linked_392 == nil { ifn_393.Invoke_O_O_O__O(arg_394, arg_395, arg_396) } else { linked_392.(*aot_arbace_core.A_arbace_core_swap_BANG__A).Invoke_O_O_O_O__O(root_391, arg_394, arg_395, arg_396) }; return lang.IFn_Cast(t.F_read_fn).Invoke_O__O(file__1) }











func A_arbace_build_go_collect_index_file_A_New() *A_arbace_build_go_collect_index_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collect_index_file_A{}; t.Ctor(); return t }
//line :161:1
func (t *A_arbace_build_go_collect_index_file_A) Ctor() {}
//line :161:1
func (t *A_arbace_build_go_collect_index_file_A) Invoke_O_O_O_O__O(self, print_cache__0, host_id__1, dir__2 any) any { var md__4 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51);

	jrt.MessageDigest_Cast(md__4).Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44, nil), jrt.RefArrayOf(jrt.Object_class, host_id__1, nil, jrt.NN(jrt.File_Cast(dir__2)).GetPath__String().Ref()))).GetBytes_String__B1(Lit_52)); var tmp1 /*line :161:1*/*jrt.Class = A_arbace_build_go_A_const_67; var tmp2 any; var root_425 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_425, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_427 lang.IFn; if


	linked_426 == nil { ifn_427 = lang.IFn_Cast(root_425) } else { ifn_427 = nil }; var arg_428 any = print_cache__0; if linked_426 == nil { tmp2 = ifn_427.Invoke_O__O(arg_428) } else { tmp2 = linked_426.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_425, arg_428) }; var tmp3 any = /*line :161:1*/jrt.File_New_String_String(jrt.String_Cast(tmp2), Lit_53); var tmp4 any; var root_429 any = A_arbace_build_go_A_const_58.GetRawRoot__O(); var linked_430 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_429, A_arbace_build_go_hex_A_fn_class); var ifn_431 lang.IFn; if


	linked_430 == nil { ifn_431 = lang.IFn_Cast(root_429) } else { ifn_431 = nil }; var arg_432 any = jrt.MessageDigest_Cast(md__4).Digest__B1().Ref(); if linked_430 == nil { tmp4 = ifn_431.Invoke_O__O(arg_432) } else { tmp4 = linked_430.(*A_arbace_build_go_hex_A).Invoke_O_O__O(root_429, arg_432) }; return /*line :161:1*/ lang.Reflector_InvokeConstructor_Class_O1__O(tmp1, jrt.RefArrayOf(jrt.Object_class, tmp3, tmp4)) }




func A_arbace_build_go_read_index_A_New() *A_arbace_build_go_read_index_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_index_A{}; t.Ctor(); return t }
//line :166:1
func (t *A_arbace_build_go_read_index_A) Ctor() {}
//line :166:1
func (t *A_arbace_build_go_read_index_A) Invoke_O_O__O(self, f__0 any) any {


	if jrt.NN(jrt.File_Cast(f__0)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
//line :169:1
		var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var vec__1901000080__4 any; var root_433 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_434 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_433, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_435 lang.IFn

			if linked_434 == nil { ifn_435 = lang.IFn_Cast(root_433) } else { ifn_435 = nil }; var arg_436 any = f__0; if linked_434 == nil { vec__1901000080__4 = ifn_435.Invoke_O__O(arg_436) } else { vec__1901000080__4 = linked_434.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_433, arg_436) }
//line :169:1
			var m__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000080__4, lang.RT_IntCast_J__I_NoInit(0), nil); var tmp2 any; var root_437 any = A_arbace_build_go_A_const_68.GetRawRoot__O(); var linked_438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_437, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_439 lang.IFn

			if linked_438 == nil { ifn_439 = lang.IFn_Cast(root_437) } else { ifn_439 = nil }; var arg_440 any = m__5; if linked_438 == nil { tmp2 = ifn_439.Invoke_O__O(arg_440) } else { tmp2 = linked_438.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_437, arg_440) }; if jrt.J2g_Truth(tmp2) { tmp1 = m__5 } else { tmp1 = nil } }; return nil }()
//line :169:1
		if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = nil } }; return tmp1 } else { return nil
		}
}


func A_arbace_build_go_write_index_BANG__A_New() *A_arbace_build_go_write_index_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__A{}; t.Ctor(); return t }
//line :174:1
func (t *A_arbace_build_go_write_index_BANG__A) Ctor() {}
//line :174:1
func (t *A_arbace_build_go_write_index_BANG__A) Invoke_O_O_O__O(self, f__0, index__1 any) any { var printed__3 any; var tmp1 any = A_arbace_build_go_write_index_BANG__printed__1901000087_A_New(); var tmp2 *jrt.Class; var fncls__461 *jrt.Class = A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class; if



	fncls__461 == nil { var fncls__461d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_182, false); A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class = fncls__461d; tmp2 = fncls__461d } else { tmp2 = fncls__461 }; printed__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var ok_QMARK___4 any; var tmp3 any = /*line :174:1*/A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(printed__3); var tmp4 *jrt.Class; var fncls__466 *jrt.Class = A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class; if



	fncls__466 == nil { var fncls__466d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_183, false); A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class = fncls__466d; tmp4 = fncls__466d } else { tmp4 = fncls__466 }; ok_QMARK___4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var index__5 any; var root_467 any = /*line :174:1*/A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_468 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_467, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_469 lang.IFn; if





	linked_468 == nil { ifn_469 = lang.IFn_Cast(root_467) } else { ifn_469 = nil }; var arg_470 any = index__1; var arg_471 any = A_arbace_build_go_A_const_78; var arg_472 any; var tmp5 any = A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(ok_QMARK___4); var tmp6 *jrt.Class; var fncls__492 *jrt.Class = A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class; if fncls__492 == nil { var fncls__492d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_184, false); A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class = fncls__492d; tmp6 = fncls__492d } else { tmp6 = fncls__492 }; arg_472 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); if linked_468 == nil { index__5 = ifn_469.Invoke_O_O_O__O(arg_470, arg_471, arg_472) } else { index__5 = linked_468.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_467, arg_470, arg_471, arg_472) }; var tmp__6 any = /*line :174:1*/jrt.File_New_File_String(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(f__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));







	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(f__0)).GetParentFile__File()).Mkdirs__Z());
	lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(tmp__6, lang.IFn_Cast(printed__3).Invoke_O__O(index__5)); if
	jrt.NN(jrt.File_Cast(tmp__6)).RenameTo_File__Z(jrt.File_Cast(f__0)) { return nil } else { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__6)).Delete__Z()).Ref() } }
//line :178:1
func A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A{}; t.Ctor_O(p0); return t }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Ctor_O(c__printed any) { t.F_printed = c__printed }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A) Invoke_O_O__O(self, p1__1901000085_SHARP___1 any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
																{ var tmp2 any; var root_462 any = A_arbace_build_go_A_const_76.GetRawRoot__O(); var linked_463 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_462, aot_arbace_core.A_arbace_core_read_string_A_fn_class); var ifn_464 lang.IFn; if linked_463 == nil { ifn_464 = lang.IFn_Cast(root_462) } else { ifn_464 = nil }; var arg_465 any = lang.IFn_Cast(t.F_printed).Invoke_O__O(p1__1901000085_SHARP___1); if linked_463 == nil { tmp2 = ifn_464.Invoke_O__O(arg_465) } else { tmp2 = linked_463.(*aot_arbace_core.A_arbace_core_read_string_A).Invoke_O_O__O(root_462, arg_465) }; tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(p1__1901000085_SHARP___1, tmp2)).Ref() }
//line :178:1
	return nil }(); if tmp3 != nil { if true { var ___4 jrt.Throwable_I = tmp3; _ = ___4; tmp1 = jrt.Boolean_FALSE.Ref() } }; return tmp1 }
//line :178:1
func A_arbace_build_go_write_index_BANG__printed__1901000087_A_New() *A_arbace_build_go_write_index_BANG__printed__1901000087_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__printed__1901000087_A{}; t.Ctor(); return t }
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Ctor() {}
//line :178:1
func (t *A_arbace_build_go_write_index_BANG__printed__1901000087_A) Invoke_O_O__O(self, p1__1901000084_SHARP___1 any) any { var root_448 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_448, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_450 lang.IFn; if linked_449 == nil { ifn_450 = lang.IFn_Cast(root_448) } else { ifn_450 = nil }; var arg_451 any = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()).Invoke_O_O_O_O_O_O__O(A_arbace_build_go_A_const_73, jrt.Boolean_TRUE.Ref(), A_arbace_build_go_A_const_74, nil, A_arbace_build_go_A_const_75, nil); if linked_449 == nil { ifn_450.Invoke_O__O(arg_451) } else { linked_449.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_448, arg_451) }; var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(p1__1901000084_SHARP___1); return nil }(); var root_445 any = A_arbace_build_go_A_const_70.GetRawRoot__O(); var linked_446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_445, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_447 lang.IFn; if linked_446 == nil { ifn_447 = lang.IFn_Cast(root_445) } else { ifn_447 = nil }; if linked_446 == nil { ifn_447.Invoke__O() } else { linked_446.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_445) }; if tmp2 != nil { panic(tmp2) }; return tmp1 }

func A_arbace_build_go_write_index_BANG__fn__1901000091_A_New_O(p0 any) *A_arbace_build_go_write_index_BANG__fn__1901000091_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_write_index_BANG__fn__1901000091_A{}; t.Ctor_O(p0); return t }
//line :180:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Ctor_O(c__ok_QMARK_ any) { t.F_ok_QMARK_ = c__ok_QMARK_ }
//line :180:1
func (t *A_arbace_build_go_write_index_BANG__fn__1901000091_A) Invoke_O_O__O(self, p1__1901000086_SHARP___1 any) any { var root_473 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_474 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_473, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_475 lang.IFn; if linked_474 == nil { ifn_475 = lang.IFn_Cast(root_473) } else { ifn_475 = nil }; var arg_476 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_477 any; var root_482 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_483 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_482, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_484 lang.IFn; if linked_483 == nil { ifn_484 = lang.IFn_Cast(root_482) } else { ifn_484 = nil }; var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_81.GetRawRoot__O()); var tmp2 any = t.F_ok_QMARK_; var tmp3 any = A_arbace_build_go_A_const_82; var arg_485 any = tmp1.Invoke_O_O_O__O(tmp2, tmp3, A_arbace_build_go_A_const_83.GetRawRoot__O()); if linked_483 == nil { arg_477 = ifn_484.Invoke_O__O(arg_485) } else { arg_477 = linked_483.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O__O(root_482, arg_485) }; var arg_478 any = p1__1901000086_SHARP___1; if linked_474 == nil { return ifn_475.Invoke_O_O_O__O(arg_476, arg_477, arg_478) } else { return linked_474.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O_O__O(root_473, arg_476, arg_477, arg_478) } }





func A_arbace_build_go_root_packages_A_New() *A_arbace_build_go_root_packages_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_A{}; t.Ctor(); return t }
//line :186:1
func (t *A_arbace_build_go_root_packages_A) Ctor() {}
//line :186:1
func (t *A_arbace_build_go_root_packages_A) Invoke_O_O_O__O(self, dir__0, print_cache__1 any) any { var root__3 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_132); if




	jrt.NN(jrt.File_Cast(root__3)).IsDirectory__Z() { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_133, nil, Lit_134), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref(), nil)).Ref()) }; var files__4 any; var root_498 any = /*line :186:1*/A_arbace_build_go_A_const_85.GetRawRoot__O(); var linked_499 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_498, A_arbace_build_go_clj_files_A_fn_class); var ifn_500 lang.IFn; if






	linked_499 == nil { ifn_500 = lang.IFn_Cast(root_498) } else { ifn_500 = nil }; var arg_501 any = root__3; if linked_499 == nil { files__4 = ifn_500.Invoke_O__O(arg_501) } else { files__4 = linked_499.(*A_arbace_build_go_clj_files_A).Invoke_O_O__O(root_498, arg_501) }; var host_id__5 any = /*line :186:1*/jrt.System_Getenv_String__String(Lit_107).Ref(); var index_file__6 any; var tmp1 any; var and__1927000168__auto____6 any = print_cache__1; if








	jrt.J2g_Truth(and__1927000168__auto____6) { var root_502 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_503 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_502, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_504 lang.IFn; if linked_503 == nil { ifn_504 = lang.IFn_Cast(root_502) } else { ifn_504 = nil }; var arg_505 any = host_id__5; if linked_503 == nil { tmp1 = ifn_504.Invoke_O__O(arg_505) } else { tmp1 = linked_503.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_502, arg_505) } } else { tmp1 = and__1927000168__auto____6 }; if jrt.J2g_Truth(tmp1) { var root_506 any = A_arbace_build_go_A_const_86.GetRawRoot__O(); var linked_507 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_506, A_arbace_build_go_collect_index_file_A_fn_class); var ifn_508 lang.IFn; if linked_507 == nil { ifn_508 = lang.IFn_Cast(root_506) } else { ifn_508 = nil }; var arg_509 any = print_cache__1; var arg_510 any = host_id__5; var arg_511 any = dir__0; if linked_507 == nil { index_file__6 = ifn_508.Invoke_O_O_O__O(arg_509, arg_510, arg_511) } else { index_file__6 = linked_507.(*A_arbace_build_go_collect_index_file_A).Invoke_O_O_O_O__O(root_506, arg_509, arg_510, arg_511) } } else { index_file__6 = nil }; var index__7 any; if
	jrt.J2g_Truth(index_file__6) { var or__1927000174__auto____7 any; var root_512 any = A_arbace_build_go_A_const_87.GetRawRoot__O(); var linked_513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_512, A_arbace_build_go_read_index_A_fn_class); var ifn_514 lang.IFn; if linked_513 == nil { ifn_514 = lang.IFn_Cast(root_512) } else { ifn_514 = nil }; var arg_515 any = index_file__6; if linked_513 == nil { or__1927000174__auto____7 = ifn_514.Invoke_O__O(arg_515) } else { or__1927000174__auto____7 = linked_513.(*A_arbace_build_go_read_index_A).Invoke_O_O__O(root_512, arg_515) }; if jrt.J2g_Truth(or__1927000174__auto____7) { index__7 = or__1927000174__auto____7 } else { index__7 = lang.PersistentArrayMap_EMPTY.Ref() } } else { index__7 = nil }; var shas__8 any; if
	jrt.J2g_Truth(index_file__6) { var m__8 any; var root_516 any = A_arbace_build_go_A_const_53.GetRawRoot__O(); var linked_517 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_516, aot_arbace_core.A_arbace_core_zipmap_A_fn_class); var ifn_518 lang.IFn
		if linked_517 == nil { ifn_518 = lang.IFn_Cast(root_516) } else { ifn_518 = nil }; var arg_519 any; var root_521 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_522 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_521, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_523 lang.IFn; if linked_522 == nil { ifn_523 = lang.IFn_Cast(root_521) } else { ifn_523 = nil }; var arg_524 any; var tmp2 any = A_arbace_build_go_root_packages_fn__1901000099_A_New(); var tmp3 *jrt.Class; var fncls__526 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000099_A_fn_class; if fncls__526 == nil { var fncls__526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_135, false); A_arbace_build_go_root_packages_fn__1901000099_A_fn_class = fncls__526d; tmp3 = fncls__526d } else { tmp3 = fncls__526 }; arg_524 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil); var arg_525 any = files__4; if linked_522 == nil { arg_519 = ifn_523.Invoke_O_O__O(arg_524, arg_525) } else { arg_519 = linked_522.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_521, arg_524, arg_525) }; var arg_520 any; var root_527 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_527, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_529 lang.IFn; if linked_528 == nil { ifn_529 = lang.IFn_Cast(root_527) } else { ifn_529 = nil }; var arg_530 any = A_arbace_build_go_A_const_88.GetRawRoot__O(); var arg_531 any = files__4; if linked_528 == nil { arg_520 = ifn_529.Invoke_O_O__O(arg_530, arg_531) } else { arg_520 = linked_528.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_527, arg_530, arg_531) }; if linked_517 == nil { m__8 = ifn_518.Invoke_O_O__O(arg_519, arg_520) } else { m__8 = linked_517.(*aot_arbace_core.A_arbace_core_zipmap_A).Invoke_O_O_O__O(root_516, arg_519, arg_520) }
		var tmp4 any = A_arbace_build_go_root_packages_fn__1901000101_A_New_O(m__8); var tmp5 *jrt.Class; var fncls__541 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000101_A_fn_class; if fncls__541 == nil { var fncls__541d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_136, false); A_arbace_build_go_root_packages_fn__1901000101_A_fn_class = fncls__541d; tmp5 = fncls__541d } else { tmp5 = fncls__541 }; shas__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil) } else {
//line :197:1
			shas__8 = nil }; var valid__9 any; if


	jrt.J2g_Truth(index_file__6) {
		var root_542 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_543 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_542, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_544 lang.IFn; if linked_543 == nil { ifn_544 = lang.IFn_Cast(root_542) } else { ifn_544 = nil }; var arg_545 any = lang.PersistentArrayMap_EMPTY.Ref(); var arg_546 any; var iter__1927001039__auto____9 any; var tmp6 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(shas__8); var tmp7 *jrt.Class; var fncls__621 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class; if fncls__621 == nil { var fncls__621d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_137, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class = fncls__621d; tmp7 = fncls__621d } else { tmp7 = fncls__621 }; iter__1927001039__auto____9 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); arg_546 = lang.IFn_Cast(iter__1927001039__auto____9).Invoke_O__O(A_arbace_build_go_A_const_78.Invoke_O__O(index__7)); if linked_543 == nil { valid__9 = ifn_544.Invoke_O_O__O(arg_545, arg_546) } else { valid__9 = linked_543.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_542, arg_545, arg_546) } } else {
//line :200:1
			valid__9 = nil }; var covered__10 any; var root_622 any = /*line :186:1*/A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_622, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_624 lang.IFn; if

















	linked_623 == nil { ifn_624 = lang.IFn_Cast(root_622) } else { ifn_624 = nil }; var arg_625 any; var iter__1927001039__auto____10 any; var tmp8 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New(); var tmp9 *jrt.Class; var fncls__711 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class; if fncls__711 == nil { var fncls__711d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_138, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class = fncls__711d; tmp9 = fncls__711d } else { tmp9 = fncls__711 }; iter__1927001039__auto____10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); arg_625 = lang.IFn_Cast(iter__1927001039__auto____10).Invoke_O__O(valid__9); if linked_623 == nil { covered__10 = ifn_624.Invoke_O__O(arg_625) } else { covered__10 = linked_623.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_622, arg_625) }; var pf_index__11 any = /*line :186:1*/A_arbace_build_go_A_const_91.Invoke_O__O(index__7); var known_QMARK___12 any; var tmp10 any = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(index_file__6, pf_index__11, shas__8); var tmp11 *jrt.Class; var fncls__717 *jrt.Class = A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class; if






	fncls__717 == nil { var fncls__717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_139, false); A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class = fncls__717d; tmp11 = fncls__717d } else { tmp11 = fncls__717 }; known_QMARK___12 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil); var read_fn__13 any; var root_718 any = /*line :186:1*/A_arbace_build_go_A_const_92.GetRawRoot__O(); var linked_719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_718, A_arbace_build_go_read_all_A_fn_class); var ifn_720 lang.IFn; if




















	linked_719 == nil { ifn_720 = lang.IFn_Cast(root_718) } else { ifn_720 = nil }; var arg_721 any; var root_722 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_723 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_722, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_724 lang.IFn; if linked_723 == nil { ifn_724 = lang.IFn_Cast(root_722) } else { ifn_724 = nil }; var arg_725 any; var tmp12 any = A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(covered__10, known_QMARK___12); var tmp13 *jrt.Class; var fncls__731 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000158_A_fn_class; if fncls__731 == nil { var fncls__731d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_140, false); A_arbace_build_go_root_packages_fn__1901000158_A_fn_class = fncls__731d; tmp13 = fncls__731d } else { tmp13 = fncls__731 }; arg_725 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_726 any = files__4; if linked_723 == nil { arg_721 = ifn_724.Invoke_O_O__O(arg_725, arg_726) } else { arg_721 = linked_723.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_722, arg_725, arg_726) }; if linked_719 == nil { read_fn__13 = ifn_720.Invoke_O__O(arg_721) } else { read_fn__13 = linked_719.(*A_arbace_build_go_read_all_A).Invoke_O_O__O(root_718, arg_721) }; var pkg_file_QMARK___14 any; var tmp14 any = /*line :186:1*/A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(read_fn__13, known_QMARK___12, pf_index__11, shas__8); var tmp15 *jrt.Class; var fncls__737 *jrt.Class = A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class; if





















	fncls__737 == nil { var fncls__737d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_141, false); A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class = fncls__737d; tmp15 = fncls__737d } else { tmp15 = fncls__737 }; pkg_file_QMARK___14 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp14, tmp15, nil); var pkgs__15 any; var root_738 any = /*line :186:1*/A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_739 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_738, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_740 lang.IFn; if























	linked_739 == nil { ifn_740 = lang.IFn_Cast(root_738) } else { ifn_740 = nil }; var arg_741 any; var iter__1927001039__auto____15 any; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(pkg_file_QMARK___14, read_fn__13, dir__0, valid__9); var tmp17 *jrt.Class; var fncls__870 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class; if fncls__870 == nil { var fncls__870d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_142, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class = fncls__870d; tmp17 = fncls__870d } else { tmp17 = fncls__870 }; iter__1927001039__auto____15 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); arg_741 = lang.IFn_Cast(iter__1927001039__auto____15).Invoke_O__O(files__4); if linked_739 == nil { pkgs__15 = ifn_740.Invoke_O__O(arg_741) } else { pkgs__15 = linked_739.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_738, arg_741) }; var tmp18 any; var root_875 any =




	A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_876 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_875, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_877 lang.IFn; if linked_876 == nil { ifn_877 = lang.IFn_Cast(root_875) } else { ifn_877 = nil }; var arg_878 any = pkgs__15; if linked_876 == nil { tmp18 = ifn_877.Invoke_O__O(arg_878) } else { tmp18 = linked_876.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_875, arg_878) }; if jrt.J2g_Truth(tmp18) {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_143, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.File_Cast(root__3)).GetPath__String().Ref())).Ref()) }; var seq_1901000180__16 any; var root_883 any = /*line :186:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_884 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_883, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_885 lang.IFn; if






























	linked_884 == nil { ifn_885 = lang.IFn_Cast(root_883) } else { ifn_885 = nil }; var arg_886 any; var root_887 any = A_arbace_build_go_A_const_45.GetRawRoot__O(); var linked_888 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_887, aot_arbace_core.A_arbace_core_group_by_A_fn_class); var ifn_889 lang.IFn; if linked_888 == nil { ifn_889 = lang.IFn_Cast(root_887) } else { ifn_889 = nil }; var arg_890 any = A_arbace_build_go_A_const_46; var arg_891 any = pkgs__15; if linked_888 == nil { arg_886 = ifn_889.Invoke_O_O__O(arg_890, arg_891) } else { arg_886 = linked_888.(*aot_arbace_core.A_arbace_core_group_by_A).Invoke_O_O_O__O(root_887, arg_890, arg_891) }; if linked_884 == nil { seq_1901000180__16 = ifn_885.Invoke_O__O(arg_886) } else { seq_1901000180__16 = linked_884.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_883, arg_886) }; var chunk_1901000181__17 any; var count_1901000182__18 int64 = 0; var i_1901000183__19 int64 = 0; L1:
//line :186:1
	for {






























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000183__19, count_1901000182__18) { var vec__1901000184__20 any = lang.Indexed_Cast(chunk_1901000181__17).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000183__19)); var path__21 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__22 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000184__20, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__22)), 1) {
			var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp21 any; var root_1077 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1078 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1077, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1079 lang.IFn
			if linked_1078 == nil { ifn_1079 = lang.IFn_Cast(root_1077) } else { ifn_1079 = nil }; var arg_1080 any = Lit_87; var arg_1081 any; var root_1082 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1083 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1082, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1084 lang.IFn; if linked_1083 == nil { ifn_1084 = lang.IFn_Cast(root_1082) } else { ifn_1084 = nil }; var arg_1085 any; var tmp22 any = A_arbace_build_go_root_packages_fn__1901000187_A_New_O(dir__0); var tmp23 *jrt.Class; var fncls__1092 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000187_A_fn_class; if fncls__1092 == nil { var fncls__1092d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_144, false); A_arbace_build_go_root_packages_fn__1901000187_A_fn_class = fncls__1092d; tmp23 = fncls__1092d } else { tmp23 = fncls__1092 }; arg_1085 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp22, tmp23, nil); var arg_1086 any = ps__22; if linked_1083 == nil { arg_1081 = ifn_1084.Invoke_O_O__O(arg_1085, arg_1086) } else { arg_1081 = linked_1083.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1082, arg_1085, arg_1086) }; if linked_1078 == nil { tmp21 = ifn_1079.Invoke_O_O__O(arg_1080, arg_1081) } else { tmp21 = linked_1078.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1077, arg_1080, arg_1081) }
//line :218:1
			tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, nil, path__21, nil, tmp21)).Ref())
//line :217:1
			seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } else { seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000183__19); continue L1 } } else { var temp__1927000414__auto____20 any; var root_892 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_893 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_892, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_894 lang.IFn; if linked_893 == nil { ifn_894 = lang.IFn_Cast(root_892) } else { ifn_894 = nil }; var arg_895 any = seq_1901000180__16; if linked_893 == nil { temp__1927000414__auto____20 = ifn_894.Invoke_O__O(arg_895) } else { temp__1927000414__auto____20 = linked_893.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_892, arg_895) }; if jrt.J2g_Truth(temp__1927000414__auto____20) { var seq_1901000180__21 any = temp__1927000414__auto____20; var tmp24 any; var root_896 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_897 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_896, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_898 lang.IFn; if linked_897 == nil { ifn_898 = lang.IFn_Cast(root_896) } else { ifn_898 = nil }; var arg_899 any = seq_1901000180__21; if linked_897 == nil { tmp24 = ifn_898.Invoke_O__O(arg_899) } else { tmp24 = linked_897.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_896, arg_899) }; if jrt.J2g_Truth(tmp24) { var c__1927000678__auto____22 any; var root_900 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_901 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_900, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_902 lang.IFn; if linked_901 == nil { ifn_902 = lang.IFn_Cast(root_900) } else { ifn_902 = nil }; var arg_903 any = seq_1901000180__21; if linked_901 == nil { c__1927000678__auto____22 = ifn_902.Invoke_O__O(arg_903) } else { c__1927000678__auto____22 = linked_901.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_900, arg_903) }; var tmp25 any; var root_1093 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1094 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1093, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1095 lang.IFn; if linked_1094 == nil { ifn_1095 = lang.IFn_Cast(root_1093) } else { ifn_1095 = nil }; var arg_1096 any = seq_1901000180__21; if linked_1094 == nil { tmp25 = ifn_1095.Invoke_O__O(arg_1096) } else { tmp25 = linked_1094.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1093, arg_1096) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp25, c__1927000678__auto____22, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____22))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000189__22 any; var root_904 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_904, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_906 lang.IFn; if linked_905 == nil { ifn_906 = lang.IFn_Cast(root_904) } else { ifn_906 = nil }; var arg_907 any = seq_1901000180__21; if linked_905 == nil { vec__1901000189__22 = ifn_906.Invoke_O__O(arg_907) } else { vec__1901000189__22 = linked_905.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_904, arg_907) }; var path__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(0), nil); var ps__24 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000189__22, lang.RT_IntCast_J__I_NoInit(1), nil); if lang.Numbers_Gt_J_J__Z_NoInit(int64(lang.RT_Count_O__I_NoInit(ps__24)), 1) {
				var tmp26 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp27 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_85, nil, Lit_86, nil); var tmp28 any; var root_1101 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1102 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1101, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1103 lang.IFn
				if linked_1102 == nil { ifn_1103 = lang.IFn_Cast(root_1101) } else { ifn_1103 = nil }; var arg_1104 any = Lit_87; var arg_1105 any; var root_1106 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1107 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1106, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1108 lang.IFn; if linked_1107 == nil { ifn_1108 = lang.IFn_Cast(root_1106) } else { ifn_1108 = nil }; var arg_1109 any; var tmp29 any = A_arbace_build_go_root_packages_fn__1901000192_A_New_O(dir__0); var tmp30 *jrt.Class; var fncls__1116 *jrt.Class = A_arbace_build_go_root_packages_fn__1901000192_A_fn_class; if fncls__1116 == nil { var fncls__1116d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_145, false); A_arbace_build_go_root_packages_fn__1901000192_A_fn_class = fncls__1116d; tmp30 = fncls__1116d } else { tmp30 = fncls__1116 }; arg_1109 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp29, tmp30, nil); var arg_1110 any = ps__24; if linked_1107 == nil { arg_1105 = ifn_1108.Invoke_O_O__O(arg_1109, arg_1110) } else { arg_1105 = linked_1107.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1106, arg_1109, arg_1110) }; if linked_1102 == nil { tmp28 = ifn_1103.Invoke_O_O__O(arg_1104, arg_1105) } else { tmp28 = linked_1102.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1101, arg_1104, arg_1105) }
//line :218:1
				tmp26.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp27, jrt.RefArrayOf(jrt.Object_class, nil, path__23, nil, tmp28)).Ref())
//line :217:1
				var tmp31 any; var root_1117 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1118 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1117, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1119 lang.IFn; if linked_1118 == nil { ifn_1119 = lang.IFn_Cast(root_1117) } else { ifn_1119 = nil }; var arg_1120 any = seq_1901000180__21; if linked_1118 == nil { tmp31 = ifn_1119.Invoke_O__O(arg_1120) } else { tmp31 = linked_1118.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1117, arg_1120) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp31, nil, 0, 0; continue L1 } else { var tmp32 any; var root_1121 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1122 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1121, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1123 lang.IFn; if linked_1122 == nil { ifn_1123 = lang.IFn_Cast(root_1121) } else { ifn_1123 = nil }; var arg_1124 any = seq_1901000180__21; if linked_1122 == nil { tmp32 = ifn_1123.Invoke_O__O(arg_1124) } else { tmp32 = linked_1122.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1121, arg_1124) }; seq_1901000180__16, chunk_1901000181__17, count_1901000182__18, i_1901000183__19 = tmp32, nil, 0, 0; continue L1 } } } }
//line :186:1
		break L1 }; if

































	jrt.J2g_Truth(index_file__6) { var index_SINGLEQUOTE___16 any; var tmp33 any = A_arbace_build_go_A_const_91; var tmp34 any; var root_908 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_909 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_908, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_910 lang.IFn
		if linked_909 == nil { ifn_910 = lang.IFn_Cast(root_908) } else { ifn_910 = nil }; var arg_911 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_912 any; var iter__1927001039__auto____16 any; var tmp35 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(pkg_file_QMARK___14, shas__8); var tmp36 *jrt.Class; var fncls__978 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class
		if fncls__978 == nil { var fncls__978d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_146, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class = fncls__978d; tmp36 = fncls__978d } else { tmp36 = fncls__978 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp35, tmp36, nil); arg_912 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(files__4)
//line :221:1
		if linked_909 == nil { tmp34 = ifn_910.Invoke_O_O__O(arg_911, arg_912) } else { tmp34 = linked_909.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_908, arg_911, arg_912) }
//line :220:1
		var tmp37 any = tmp34; var tmp38 any = A_arbace_build_go_A_const_78; var tmp39 any; var root_979 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_980 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_979, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_981 lang.IFn



		if linked_980 == nil { ifn_981 = lang.IFn_Cast(root_979) } else { ifn_981 = nil }; var arg_982 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_983 any; var iter__1927001039__auto____16_2 any; var tmp40 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(shas__8); var tmp41 *jrt.Class; var fncls__1067 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class
		if fncls__1067 == nil { var fncls__1067d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_147, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class = fncls__1067d; tmp41 = fncls__1067d } else { tmp41 = fncls__1067 }; iter__1927001039__auto____16_2 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp40, tmp41, nil); arg_983 = lang.IFn_Cast(iter__1927001039__auto____16_2).Invoke_O__O(pkgs__15)
//line :224:1
		if linked_980 == nil { tmp39 = ifn_981.Invoke_O_O__O(arg_982, arg_983) } else { tmp39 = linked_980.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_979, arg_982, arg_983) }
//line :220:1
		index_SINGLEQUOTE___16 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp33, tmp37, tmp38, tmp39))








		if lang.Util_Equiv_O_O__Z_NoInit(index_SINGLEQUOTE___16, index__7) { } else {
			var root_1068 any = A_arbace_build_go_A_const_101.GetRawRoot__O(); var linked_1069 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1068, A_arbace_build_go_write_index_BANG__A_fn_class); var ifn_1070 lang.IFn; if linked_1069 == nil { ifn_1070 = lang.IFn_Cast(root_1068) } else { ifn_1070 = nil }; var arg_1071 any = index_file__6; var arg_1072 any = index_SINGLEQUOTE___16; if linked_1069 == nil { ifn_1070.Invoke_O_O__O(arg_1071, arg_1072) } else { linked_1069.(*A_arbace_build_go_write_index_BANG__A).Invoke_O_O_O__O(root_1068, arg_1071, arg_1072) } } }; return pkgs__15 }
//line :193:1
func A_arbace_build_go_root_packages_known_QMARK___1901000156_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_known_QMARK___1901000156_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_known_QMARK___1901000156_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :193:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Ctor_O_O_O(c__index_file, c__pf_index, c__shas any) { t.F_index_file = c__index_file; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :193:1
func (t *A_arbace_build_go_root_packages_known_QMARK___1901000156_A) Invoke_O_O__O(self, p1__1901000095_SHARP___1 any) any { var and__1927000168__auto____2 any = t.F_index_file; if












	jrt.J2g_Truth(and__1927000168__auto____2) { var root_712 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_712, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_714 lang.IFn; if linked_713 == nil { ifn_714 = lang.IFn_Cast(root_712) } else { ifn_714 = nil }; var arg_715 any = t.F_pf_index; var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); var arg_716 any = tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000095_SHARP___1)).GetPath__String().Ref()); if linked_713 == nil { return ifn_714.Invoke_O_O__O(arg_715, arg_716) } else { return linked_713.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_712, arg_715, arg_716) } } else { return and__1927000168__auto____2 } }
//line :198:1
func A_arbace_build_go_root_packages_fn__1901000099_A_New() *A_arbace_build_go_root_packages_fn__1901000099_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000099_A{}; t.Ctor(); return t }
//line :198:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Ctor() {}
//line :198:1
func (t *A_arbace_build_go_root_packages_fn__1901000099_A) Invoke_O_O__O(self, p1__1901000094_SHARP___1 any) any { return jrt.NN(jrt.File_Cast(p1__1901000094_SHARP___1)).GetPath__String().Ref() }
func A_arbace_build_go_root_packages_fn__1901000101_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000101_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000101_A{}; t.Ctor_O(p0); return t }
//line :199:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Ctor_O(c__m any) { t.F_m = c__m }
//line :199:1
func (t *A_arbace_build_go_root_packages_fn__1901000101_A) Invoke_O_O__O(self, path__1 any) any { var tmp1 any; var root_532 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_533 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_532, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_534 lang.IFn; if linked_533 == nil { ifn_534 = lang.IFn_Cast(root_532) } else { ifn_534 = nil }; var arg_535 any = t.F_m; var arg_536 any = path__1; if linked_533 == nil { tmp1 = ifn_534.Invoke_O_O__O(arg_535, arg_536) } else { tmp1 = linked_533.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_532, arg_535, arg_536) }; if jrt.J2g_Truth(tmp1) { return lang.RT_Get_O_O__O_NoInit(t.F_m, path__1) } else { var root_537 any = A_arbace_build_go_A_const_88.GetRawRoot__O(); var linked_538 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_537, A_arbace_build_go_file_sha_A_fn_class); var ifn_539 lang.IFn; if linked_538 == nil { ifn_539 = lang.IFn_Cast(root_537) } else { ifn_539 = nil }; var arg_540 any = jrt.File_New_String(jrt.String_Cast(path__1)); if linked_538 == nil { return ifn_539.Invoke_O__O(arg_540) } else { return linked_538.(*A_arbace_build_go_file_sha_A).Invoke_O_O__O(root_537, arg_540) } } }

func A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_A{}; t.Ctor_O(p0); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_A) Invoke_O_O__O(self, s__1901000104__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(s__1901000104__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__620 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class; if fncls__620 == nil { var fncls__620d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_148, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class = fncls__620d; tmp2 = fncls__620d } else { tmp2 = fncls__620 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :201:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Ctor_O_O_O(c__s__1901000104, c__iter__1901000103, c__shas any) { t.F_s__1901000104 = c__s__1901000104; t.F_iter__1901000103 = c__iter__1901000103; t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A) Invoke_O__O(self any) any { { var s__1901000104__1 any; var t_ any = t.F_s__1901000104; t.F_s__1901000104 = nil; s__1901000104__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_547 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_548 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_547, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_549 lang.IFn; if linked_548 == nil { ifn_549 = lang.IFn_Cast(root_547) } else { ifn_549 = nil }; var arg_550 any = s__1901000104__1; if linked_548 == nil { temp__1927000414__auto____2 = ifn_549.Invoke_O__O(arg_550) } else { temp__1927000414__auto____2 = linked_548.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_547, arg_550) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000104__3 any = temp__1927000414__auto____2; var tmp1 any; var root_551 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_552 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_551, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_553 lang.IFn; if linked_552 == nil { ifn_553 = lang.IFn_Cast(root_551) } else { ifn_553 = nil }; var arg_554 any = s__1901000104__3; if linked_552 == nil { tmp1 = ifn_553.Invoke_O__O(arg_554) } else { tmp1 = linked_552.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_551, arg_554) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_555 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_556 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_555, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_557 lang.IFn; if linked_556 == nil { ifn_557 = lang.IFn_Cast(root_555) } else { ifn_557 = nil }; var arg_558 any = s__1901000104__3; if linked_556 == nil { c__1927001037__auto____4 = ifn_557.Invoke_O__O(arg_558) } else { c__1927001037__auto____4 = linked_556.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_555, arg_558) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000106__6 any; var root_559 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_560 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_559, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_561 lang.IFn; if linked_560 == nil { ifn_561 = lang.IFn_Cast(root_559) } else { ifn_561 = nil }; var arg_562 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_560 == nil { b__1901000106__6 = ifn_561.Invoke_O__O(arg_562) } else { b__1901000106__6 = linked_560.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_559, arg_562) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(b__1901000106__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__574 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class; if fncls__574 == nil { var fncls__574d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_149, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class = fncls__574d; tmp3 = fncls__574d } else { tmp3 = fncls__574 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_575 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_576 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_575, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_577 lang.IFn; if linked_576 == nil { ifn_577 = lang.IFn_Cast(root_575) } else { ifn_577 = nil }; var arg_578 any; var root_580 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_580, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_582 lang.IFn; if linked_581 == nil { ifn_582 = lang.IFn_Cast(root_580) } else { ifn_582 = nil }; var arg_583 any = b__1901000106__6; if linked_581 == nil { arg_578 = ifn_582.Invoke_O__O(arg_583) } else { arg_578 = linked_581.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_580, arg_583) }; var arg_579 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp5 any; var root_584 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_584, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_586 lang.IFn; if linked_585 == nil { ifn_586 = lang.IFn_Cast(root_584) } else { ifn_586 = nil }; var arg_587 any = s__1901000104__3; if linked_585 == nil { tmp5 = ifn_586.Invoke_O__O(arg_587) } else { tmp5 = linked_585.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_584, arg_587) }; arg_579 = tmp4.Invoke_O__O(tmp5); if linked_576 == nil { return ifn_577.Invoke_O_O__O(arg_578, arg_579) } else { return linked_576.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_575, arg_578, arg_579) } } else { var root_588 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_589 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_588, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_590 lang.IFn; if linked_589 == nil { ifn_590 = lang.IFn_Cast(root_588) } else { ifn_590 = nil }; var arg_591 any; var root_593 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_594 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_593, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_595 lang.IFn; if linked_594 == nil { ifn_595 = lang.IFn_Cast(root_593) } else { ifn_595 = nil }; var arg_596 any = b__1901000106__6; if linked_594 == nil { arg_591 = ifn_595.Invoke_O__O(arg_596) } else { arg_591 = linked_594.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_593, arg_596) }; var arg_592 any; if linked_589 == nil { return ifn_590.Invoke_O_O__O(arg_591, arg_592) } else { return linked_589.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_588, arg_591, arg_592) } } } else { var vec__1901000120__4 any; var root_597 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_598 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_597, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_599 lang.IFn; if linked_598 == nil { ifn_599 = lang.IFn_Cast(root_597) } else { ifn_599 = nil }; var arg_600 any = s__1901000104__3; if linked_598 == nil { vec__1901000120__4 = ifn_599.Invoke_O__O(arg_600) } else { vec__1901000120__4 = linked_598.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_597, arg_600) }; var path__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000120__4, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp6 any; var root_601 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var linked_602 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_601, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_603 lang.IFn
															if linked_602 == nil { ifn_603 = lang.IFn_Cast(root_601) } else { ifn_603 = nil }; var arg_604 any; var tmp7 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(t.F_shas); var tmp8 *jrt.Class; var fncls__606 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class; if fncls__606 == nil { var fncls__606d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_150, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class = fncls__606d; tmp8 = fncls__606d } else { tmp8 = fncls__606 }; arg_604 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_605 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__6); if linked_602 == nil { tmp6 = ifn_603.Invoke_O_O__O(arg_604, arg_605) } else { tmp6 = linked_602.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_601, arg_604, arg_605) }
//line :201:1
	if jrt.J2g_Truth(tmp6) { var root_607 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_608 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_607, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_609 lang.IFn; if linked_608 == nil { ifn_609 = lang.IFn_Cast(root_607) } else { ifn_609 = nil }; var arg_610 any = lang.Tuple_Create_O_O__IPersistentVector(path__5, e__6); var arg_611 any; var tmp9 lang.IFn = lang.IFn_Cast(t.F_iter__1901000103); var tmp10 any; var root_612 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_613 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_612, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_614 lang.IFn; if linked_613 == nil { ifn_614 = lang.IFn_Cast(root_612) } else { ifn_614 = nil }; var arg_615 any = s__1901000104__3; if linked_613 == nil { tmp10 = ifn_614.Invoke_O__O(arg_615) } else { tmp10 = linked_613.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_612, arg_615) }; arg_611 = tmp9.Invoke_O__O(tmp10); if linked_608 == nil { return ifn_609.Invoke_O_O__O(arg_610, arg_611) } else { return linked_608.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_607, arg_610, arg_611) } } else { var tmp11 any; var root_616 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_617 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_616, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_618 lang.IFn; if linked_617 == nil { ifn_618 = lang.IFn_Cast(root_616) } else { ifn_618 = nil }; var arg_619 any = s__1901000104__3; if linked_617 == nil { tmp11 = ifn_618.Invoke_O__O(arg_619) } else { tmp11 = linked_617.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_616, arg_619) }; s__1901000104__1 = tmp11; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :201:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Ctor_O_I_O_O(c__b__1901000106 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000106 = c__b__1901000106; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :201:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A) Invoke_O__O(self any) any { { var i__1901000105__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000105__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000110__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000105__1)); var path__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(0), nil); var e__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000110__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp2 any; var root_563 any = A_arbace_build_go_A_const_89.GetRawRoot__O(); var linked_564 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_563, aot_arbace_core.A_arbace_core_every_QMARK__A_fn_class); var ifn_565 lang.IFn
																	if linked_564 == nil { ifn_565 = lang.IFn_Cast(root_563) } else { ifn_565 = nil }; var arg_566 any; var tmp3 any = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(t.F_shas); var tmp4 *jrt.Class; var fncls__568 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class; if fncls__568 == nil { var fncls__568d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_151, false); A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class = fncls__568d; tmp4 = fncls__568d } else { tmp4 = fncls__568 }; arg_566 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var arg_567 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__4); if linked_564 == nil { tmp2 = ifn_565.Invoke_O_O__O(arg_566, arg_567) } else { tmp2 = linked_564.(*aot_arbace_core.A_arbace_core_every_QMARK__A).Invoke_O_O_O__O(root_563, arg_566, arg_567) }
//line :201:1
	if jrt.J2g_Truth(tmp2) { var root_569 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_570 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_569, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_571 lang.IFn; if linked_570 == nil { ifn_571 = lang.IFn_Cast(root_569) } else { ifn_571 = nil }; var arg_572 any = t.F_b__1901000106; var arg_573 any = lang.Tuple_Create_O_O__IPersistentVector(path__3, e__4); if linked_570 == nil { ifn_571.Invoke_O_O__O(arg_572, arg_573) } else { linked_570.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_569, arg_572, arg_573) }; i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } else { i__1901000105__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000105__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A) Invoke_O_O__O(self, p__1901000113__1 any) any { var vec__1901000115__2 any = p__1901000113__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000115__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }
//line :202:1
func A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A{}; t.Ctor_O(p0); return t }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :202:1
func (t *A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A) Invoke_O_O__O(self, p__1901000123__1 any) any { var vec__1901000125__2 any = p__1901000123__1; var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(0), nil); var sha__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000125__2, lang.RT_IntCast_J__I_NoInit(1), nil); return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(sha__4, lang.IFn_Cast(t.F_shas).Invoke_O__O(rp__3))).Ref() }

func A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Ctor() {}
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_A) Invoke_O_O__O(self, s__1901000132__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(self, s__1901000132__1); var tmp2 *jrt.Class; var fncls__710 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class; if fncls__710 == nil { var fncls__710d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_152, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class = fncls__710d; tmp2 = fncls__710d } else { tmp2 = fncls__710 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Ctor_O_O(c__iter__1901000131, c__s__1901000132 any) { t.F_iter__1901000131 = c__iter__1901000131; t.F_s__1901000132 = c__s__1901000132 }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A) Invoke_O__O(self any) any { { var s__1901000132__1 any; var t_ any = t.F_s__1901000132; t.F_s__1901000132 = nil; s__1901000132__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_626 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_627 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_626, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_628 lang.IFn; if linked_627 == nil { ifn_628 = lang.IFn_Cast(root_626) } else { ifn_628 = nil }; var arg_629 any = s__1901000132__1; if linked_627 == nil { temp__1927000414__auto____2 = ifn_628.Invoke_O__O(arg_629) } else { temp__1927000414__auto____2 = linked_627.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_626, arg_629) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var xs__1927001018__auto____3 any = temp__1927000414__auto____2; var vec__1901000139__4 any; var root_630 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_631 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_630, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_632 lang.IFn; if linked_631 == nil { ifn_632 = lang.IFn_Cast(root_630) } else { ifn_632 = nil }; var arg_633 any = xs__1927001018__auto____3; if linked_631 == nil { vec__1901000139__4 = ifn_632.Invoke_O__O(arg_633) } else { vec__1901000139__4 = linked_631.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_630, arg_633) }; var ___5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(0), nil); var e__6 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000139__4, lang.RT_IntCast_J__I_NoInit(1), nil); var iterys__1927001035__auto____7 any; var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New(); var tmp2 *jrt.Class; var fncls__692 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class; _ = ___5; if fncls__692 == nil { var fncls__692d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_153, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class = fncls__692d; tmp2 = fncls__692d } else { tmp2 = fncls__692 }; iterys__1927001035__auto____7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var fs__1927001036__auto____8 any; var root_693 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_694 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_693, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_695 lang.IFn; if linked_694 == nil { ifn_695 = lang.IFn_Cast(root_693) } else { ifn_695 = nil }; var arg_696 any = lang.IFn_Cast(iterys__1927001035__auto____7).Invoke_O__O(A_arbace_build_go_A_const_64.Invoke_O__O(e__6)); if linked_694 == nil { fs__1927001036__auto____8 = ifn_695.Invoke_O__O(arg_696) } else { fs__1927001036__auto____8 = linked_694.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_693, arg_696) }; if jrt.J2g_Truth(fs__1927001036__auto____8) { var root_697 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_698 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_697, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_699 lang.IFn; if linked_698 == nil { ifn_699 = lang.IFn_Cast(root_697) } else { ifn_699 = nil }; var arg_700 any = fs__1927001036__auto____8; var arg_701 any; var tmp3 lang.IFn = lang.IFn_Cast(t.F_iter__1901000131); var tmp4 any; var root_702 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_702, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_704 lang.IFn; if linked_703 == nil { ifn_704 = lang.IFn_Cast(root_702) } else { ifn_704 = nil }; var arg_705 any = s__1901000132__1; if linked_703 == nil { tmp4 = ifn_704.Invoke_O__O(arg_705) } else { tmp4 = linked_703.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_702, arg_705) }; arg_701 = tmp3.Invoke_O__O(tmp4); if linked_698 == nil { return ifn_699.Invoke_O_O__O(arg_700, arg_701) } else { return linked_698.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_697, arg_700, arg_701) } } else { var tmp5 any; var root_706 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_707 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_706, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_708 lang.IFn; if linked_707 == nil { ifn_708 = lang.IFn_Cast(root_706) } else { ifn_708 = nil }; var arg_709 any = s__1901000132__1; if linked_707 == nil { tmp5 = ifn_708.Invoke_O__O(arg_709) } else { tmp5 = linked_707.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_706, arg_709) }; s__1901000132__1 = tmp5; continue L1 } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_New() *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A{}; t.Ctor(); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Ctor() {}
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A) Invoke_O_O__O(self, s__1901000134__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(self, s__1901000134__1); var tmp2 *jrt.Class; var fncls__691 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class; if fncls__691 == nil { var fncls__691d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_154, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class = fncls__691d; tmp2 = fncls__691d } else { tmp2 = fncls__691 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A{}; t.Ctor_O_O(p0, p1); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Ctor_O_O(c__iter__1901000133, c__s__1901000134 any) { t.F_iter__1901000133 = c__iter__1901000133; t.F_s__1901000134 = c__s__1901000134 }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A) Invoke_O__O(self any) any { { var s__1901000134__1 any; var t_ any = t.F_s__1901000134; t.F_s__1901000134 = nil; s__1901000134__1 = t_; for { var temp__1927000414__auto____2 any; var root_634 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_635 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_634, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_636 lang.IFn; if linked_635 == nil { ifn_636 = lang.IFn_Cast(root_634) } else { ifn_636 = nil }; var arg_637 any = s__1901000134__1; if linked_635 == nil { temp__1927000414__auto____2 = ifn_636.Invoke_O__O(arg_637) } else { temp__1927000414__auto____2 = linked_635.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_634, arg_637) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000134__3 any = temp__1927000414__auto____2; var tmp1 any; var root_638 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_638, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_640 lang.IFn; if linked_639 == nil { ifn_640 = lang.IFn_Cast(root_638) } else { ifn_640 = nil }; var arg_641 any = s__1901000134__3; if linked_639 == nil { tmp1 = ifn_640.Invoke_O__O(arg_641) } else { tmp1 = linked_639.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_638, arg_641) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_642 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_642, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_644 lang.IFn; if linked_643 == nil { ifn_644 = lang.IFn_Cast(root_642) } else { ifn_644 = nil }; var arg_645 any = s__1901000134__3; if linked_643 == nil { c__1927001037__auto____4 = ifn_644.Invoke_O__O(arg_645) } else { c__1927001037__auto____4 = linked_643.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_642, arg_645) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000136__6 any; var root_646 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_646, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_648 lang.IFn; if linked_647 == nil { ifn_648 = lang.IFn_Cast(root_646) } else { ifn_648 = nil }; var arg_649 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_647 == nil { b__1901000136__6 = ifn_648.Invoke_O__O(arg_649) } else { b__1901000136__6 = linked_647.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_646, arg_649) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(b__1901000136__6, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__655 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class; if fncls__655 == nil { var fncls__655d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_155, false); A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class = fncls__655d; tmp3 = fncls__655d } else { tmp3 = fncls__655 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_656 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_656, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_658 lang.IFn; if linked_657 == nil { ifn_658 = lang.IFn_Cast(root_656) } else { ifn_658 = nil }; var arg_659 any; var root_661 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_662 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_661, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_663 lang.IFn; if linked_662 == nil { ifn_663 = lang.IFn_Cast(root_661) } else { ifn_663 = nil }; var arg_664 any = b__1901000136__6; if linked_662 == nil { arg_659 = ifn_663.Invoke_O__O(arg_664) } else { arg_659 = linked_662.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_661, arg_664) }; var arg_660 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp5 any; var root_665 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_666 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_665, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_667 lang.IFn; if linked_666 == nil { ifn_667 = lang.IFn_Cast(root_665) } else { ifn_667 = nil }; var arg_668 any = s__1901000134__3; if linked_666 == nil { tmp5 = ifn_667.Invoke_O__O(arg_668) } else { tmp5 = linked_666.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_665, arg_668) }; arg_660 = tmp4.Invoke_O__O(tmp5); if linked_657 == nil { return ifn_658.Invoke_O_O__O(arg_659, arg_660) } else { return linked_657.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_656, arg_659, arg_660) } } else { var root_669 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_670 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_669, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_671 lang.IFn; if linked_670 == nil { ifn_671 = lang.IFn_Cast(root_669) } else { ifn_671 = nil }; var arg_672 any; var root_674 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_675 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_674, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_676 lang.IFn; if linked_675 == nil { ifn_676 = lang.IFn_Cast(root_674) } else { ifn_676 = nil }; var arg_677 any = b__1901000136__6; if linked_675 == nil { arg_672 = ifn_676.Invoke_O__O(arg_677) } else { arg_672 = linked_675.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_674, arg_677) }; var arg_673 any; if linked_670 == nil { return ifn_671.Invoke_O_O__O(arg_672, arg_673) } else { return linked_670.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_669, arg_672, arg_673) } } } else { var vec__1901000149__4 any; var root_678 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_679 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_678, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_680 lang.IFn; if linked_679 == nil { ifn_680 = lang.IFn_Cast(root_678) } else { ifn_680 = nil }; var arg_681 any = s__1901000134__3; if linked_679 == nil { vec__1901000149__4 = ifn_680.Invoke_O__O(arg_681) } else { vec__1901000149__4 = linked_679.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_678, arg_681) }; var rp__5 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000149__4, lang.RT_IntCast_J__I_NoInit(0), nil); var root_682 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_683 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_682, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_684 lang.IFn; if linked_683 == nil { ifn_684 = lang.IFn_Cast(root_682) } else { ifn_684 = nil }; var arg_685 any = rp__5; var arg_686 any; var tmp6 lang.IFn = lang.IFn_Cast(t.F_iter__1901000133); var tmp7 any; var root_687 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_688 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_687, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_689 lang.IFn; if linked_688 == nil { ifn_689 = lang.IFn_Cast(root_687) } else { ifn_689 = nil }; var arg_690 any = s__1901000134__3; if linked_688 == nil { tmp7 = ifn_689.Invoke_O__O(arg_690) } else { tmp7 = linked_688.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_687, arg_690) }; arg_686 = tmp6.Invoke_O__O(tmp7); if linked_683 == nil { return ifn_684.Invoke_O_O__O(arg_685, arg_686) } else { return linked_683.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_682, arg_685, arg_686) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :204:1
func A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_New_O_I_O(p0 any, p1 int32, p2 any) *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A{}; t.Ctor_O_I_O(p0, p1, p2); return t }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Ctor_O_I_O(c__b__1901000136 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000136 = c__b__1901000136; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :204:1
func (t *A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A) Invoke_O__O(self any) any { { var i__1901000135__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000135__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var vec__1901000145__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000135__1)); var rp__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000145__2, lang.RT_IntCast_J__I_NoInit(0), nil); var root_650 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_650, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_652 lang.IFn; if linked_651 == nil { ifn_652 = lang.IFn_Cast(root_650) } else { ifn_652 = nil }; var arg_653 any = t.F_b__1901000136; var arg_654 any = rp__3; if linked_651 == nil { ifn_652.Invoke_O_O__O(arg_653, arg_654) } else { linked_651.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_650, arg_653, arg_654) }; i__1901000135__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000135__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_fn__1901000158_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_fn__1901000158_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000158_A{}; t.Ctor_O_O(p0, p1); return t }
//line :207:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Ctor_O_O(c__covered, c__known_QMARK_ any) { t.F_covered = c__covered; t.F_known_QMARK_ = c__known_QMARK_ }
//line :207:1
func (t *A_arbace_build_go_root_packages_fn__1901000158_A) Invoke_O_O__O(self, p1__1901000096_SHARP___1 any) any { var root_727 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_727, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_729 lang.IFn; if linked_728 == nil { ifn_729 = lang.IFn_Cast(root_727) } else { ifn_729 = nil }; var arg_730 any; var and__1927000168__auto____2 any = lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(p1__1901000096_SHARP___1); if jrt.J2g_Truth(and__1927000168__auto____2) { var tmp1 lang.IFn = lang.IFn_Cast(t.F_covered); arg_730 = tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(p1__1901000096_SHARP___1)).GetPath__String().Ref()) } else { arg_730 = and__1927000168__auto____2 }; if linked_728 == nil { return ifn_729.Invoke_O__O(arg_730) } else { return linked_728.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_727, arg_730) } }
func A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :208:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Ctor_O_O_O_O(c__read_fn, c__known_QMARK_, c__pf_index, c__shas any) { t.F_read_fn = c__read_fn; t.F_known_QMARK_ = c__known_QMARK_; t.F_pf_index = c__pf_index; t.F_shas = c__shas }
//line :208:1
func (t *A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A) Invoke_O_O__O(self, f__1 any) any {
	if jrt.J2g_Truth(lang.IFn_Cast(t.F_known_QMARK_).Invoke_O__O(f__1)) { var tmp1 any = t.F_pf_index; var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.RT_Get_O_O__O_NoInit(tmp1, tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__1)).GetPath__String().Ref())) } else { var root_732 any = A_arbace_build_go_A_const_93.GetRawRoot__O(); var linked_733 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_732, A_arbace_build_go_package_file_QMARK__A_fn_class); var ifn_734 lang.IFn; if linked_733 == nil { ifn_734 = lang.IFn_Cast(root_732) } else { ifn_734 = nil }; var arg_735 any = f__1; var arg_736 any = t.F_read_fn; if linked_733 == nil { return ifn_734.Invoke_O_O__O(arg_735, arg_736) } else { return linked_733.(*A_arbace_build_go_package_file_QMARK__A).Invoke_O_O_O__O(root_732, arg_735, arg_736) } } }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_A) Invoke_O_O__O(self, s__1901000163__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(t.F_pkg_file_QMARK_, t.F_read_fn, t.F_dir, t.F_valid, s__1901000163__1, self); var tmp2 *jrt.Class; var fncls__869 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class; if fncls__869 == nil { var fncls__869d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_156, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class = fncls__869d; tmp2 = fncls__869d } else { tmp2 = fncls__869 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :210:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Ctor_O_O_O_O_O_O(c__pkg_file_QMARK_, c__read_fn, c__dir, c__valid, c__s__1901000163, c__iter__1901000162 any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_dir = c__dir; t.F_valid = c__valid; t.F_s__1901000163 = c__s__1901000163; t.F_iter__1901000162 = c__iter__1901000162 }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A) Invoke_O__O(self any) any { { var s__1901000163__1 any; var t_ any = t.F_s__1901000163; t.F_s__1901000163 = nil; s__1901000163__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_742 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_742, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_744 lang.IFn; if linked_743 == nil { ifn_744 = lang.IFn_Cast(root_742) } else { ifn_744 = nil }; var arg_745 any = s__1901000163__1; if linked_743 == nil { temp__1927000414__auto____2 = ifn_744.Invoke_O__O(arg_745) } else { temp__1927000414__auto____2 = linked_743.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_742, arg_745) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000163__3 any = temp__1927000414__auto____2; var tmp1 any; var root_746 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_747 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_746, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_748 lang.IFn; if linked_747 == nil { ifn_748 = lang.IFn_Cast(root_746) } else { ifn_748 = nil }; var arg_749 any = s__1901000163__3; if linked_747 == nil { tmp1 = ifn_748.Invoke_O__O(arg_749) } else { tmp1 = linked_747.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_746, arg_749) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_750 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_751 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_750, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_752 lang.IFn; if linked_751 == nil { ifn_752 = lang.IFn_Cast(root_750) } else { ifn_752 = nil }; var arg_753 any = s__1901000163__3; if linked_751 == nil { c__1927001037__auto____4 = ifn_752.Invoke_O__O(arg_753) } else { c__1927001037__auto____4 = linked_751.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_750, arg_753) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000165__6 any; var root_754 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_755 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_754, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_756 lang.IFn; if linked_755 == nil { ifn_756 = lang.IFn_Cast(root_754) } else { ifn_756 = nil }; var arg_757 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_755 == nil { b__1901000165__6 = ifn_756.Invoke_O__O(arg_757) } else { b__1901000165__6 = linked_755.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_754, arg_757) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(t.F_pkg_file_QMARK_, t.F_read_fn, b__1901000165__6, t.F_dir, t.F_valid, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__796 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class; if fncls__796 == nil { var fncls__796d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_157, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class = fncls__796d; tmp3 = fncls__796d } else { tmp3 = fncls__796 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_797 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_798 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_797, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_799 lang.IFn; if linked_798 == nil { ifn_799 = lang.IFn_Cast(root_797) } else { ifn_799 = nil }; var arg_800 any; var root_802 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_803 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_802, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_804 lang.IFn; if linked_803 == nil { ifn_804 = lang.IFn_Cast(root_802) } else { ifn_804 = nil }; var arg_805 any = b__1901000165__6; if linked_803 == nil { arg_800 = ifn_804.Invoke_O__O(arg_805) } else { arg_800 = linked_803.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_802, arg_805) }; var arg_801 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp5 any; var root_806 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_807 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_806, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_808 lang.IFn; if linked_807 == nil { ifn_808 = lang.IFn_Cast(root_806) } else { ifn_808 = nil }; var arg_809 any = s__1901000163__3; if linked_807 == nil { tmp5 = ifn_808.Invoke_O__O(arg_809) } else { tmp5 = linked_807.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_806, arg_809) }; arg_801 = tmp4.Invoke_O__O(tmp5); if linked_798 == nil { return ifn_799.Invoke_O_O__O(arg_800, arg_801) } else { return linked_798.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_797, arg_800, arg_801) } } else { var root_810 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_810, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_812 lang.IFn; if linked_811 == nil { ifn_812 = lang.IFn_Cast(root_810) } else { ifn_812 = nil }; var arg_813 any; var root_815 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_816 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_815, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_817 lang.IFn; if linked_816 == nil { ifn_817 = lang.IFn_Cast(root_815) } else { ifn_817 = nil }; var arg_818 any = b__1901000165__6; if linked_816 == nil { arg_813 = ifn_817.Invoke_O__O(arg_818) } else { arg_813 = linked_816.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_815, arg_818) }; var arg_814 any; if linked_811 == nil { return ifn_812.Invoke_O_O__O(arg_813, arg_814) } else { return linked_811.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_810, arg_813, arg_814) } } } else { var f__4 any; var root_819 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_819, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_821 lang.IFn; if linked_820 == nil { ifn_821 = lang.IFn_Cast(root_819) } else { ifn_821 = nil }; var arg_822 any = s__1901000163__3; if linked_820 == nil { f__4 = ifn_821.Invoke_O__O(arg_822) } else { f__4 = linked_820.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_819, arg_822) }; if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4)) { var root_823 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_824 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_823, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_825 lang.IFn; if linked_824 == nil { ifn_825 = lang.IFn_Cast(root_823) } else { ifn_825 = nil }; var arg_826 any; var tmp6 any = t.F_valid; var temp__1927000408__auto____5 any = lang.RT_Get_O_O__O_NoInit(tmp6, jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref())
															if jrt.J2g_Truth(temp__1927000408__auto____5) { var e__6 any = temp__1927000408__auto____5; var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp8 any = A_arbace_build_go_A_const_82.Invoke_O__O(e__6); var tmp9 any = A_arbace_build_go_A_const_50; var tmp10 any = A_arbace_build_go_A_const_64; var tmp11 any; var root_838 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_839 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_838, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_840 lang.IFn
																if linked_839 == nil { ifn_840 = lang.IFn_Cast(root_838) } else { ifn_840 = nil }; var arg_841 any; var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New(); var tmp13 *jrt.Class; var fncls__847 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class; if fncls__847 == nil { var fncls__847d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_158, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class = fncls__847d; tmp13 = fncls__847d } else { tmp13 = fncls__847 }; arg_841 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil); var arg_842 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__6); if linked_839 == nil { tmp11 = ifn_840.Invoke_O_O__O(arg_841, arg_842) } else { tmp11 = linked_839.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_838, arg_841, arg_842) }; var tmp14 any = tmp11; var tmp15 any = A_arbace_build_go_A_const_95; var tmp16 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(f__4, t.F_dir); var tmp17 *jrt.Class; var fncls__854 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class
																if fncls__854 == nil { var fncls__854d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_159, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class = fncls__854d; tmp17 = fncls__854d } else { tmp17 = fncls__854 }
//line :212:1
		arg_826 = tmp7.Invoke_O_O_O_O_O_O_O__O(tmp8, tmp9, f__4, tmp10, tmp14, tmp15, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil))) } else {

			var root_855 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_856 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_855, A_arbace_build_go_collect_package_A_fn_class); var ifn_857 lang.IFn; if linked_856 == nil { ifn_857 = lang.IFn_Cast(root_855) } else { ifn_857 = nil }; var arg_858 any = t.F_dir; var arg_859 any = f__4; var arg_860 any = t.F_read_fn; if linked_856 == nil { arg_826 = ifn_857.Invoke_O_O_O__O(arg_858, arg_859, arg_860) } else { arg_826 = linked_856.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_855, arg_858, arg_859, arg_860) } }
//line :210:1
	var arg_827 any; var tmp18 lang.IFn = lang.IFn_Cast(t.F_iter__1901000162); var tmp19 any; var root_861 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_862 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_861, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_863 lang.IFn; if linked_862 == nil { ifn_863 = lang.IFn_Cast(root_861) } else { ifn_863 = nil }; var arg_864 any = s__1901000163__3; if linked_862 == nil { tmp19 = ifn_863.Invoke_O__O(arg_864) } else { tmp19 = linked_862.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_861, arg_864) }; arg_827 = tmp18.Invoke_O__O(tmp19); if linked_824 == nil { return ifn_825.Invoke_O_O__O(arg_826, arg_827) } else { return linked_824.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_823, arg_826, arg_827) } } else { var tmp20 any; var root_865 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_866 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_865, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_867 lang.IFn; if linked_866 == nil { ifn_867 = lang.IFn_Cast(root_865) } else { ifn_867 = nil }; var arg_868 any = s__1901000163__3; if linked_866 == nil { tmp20 = ifn_867.Invoke_O__O(arg_868) } else { tmp20 = linked_866.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_865, arg_868) }; s__1901000163__1 = tmp20; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :210:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_New_O_O_O_O_O_I_O(p0, p1, p2, p3, p4 any, p5 int32, p6 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A{}; t.Ctor_O_O_O_O_O_I_O(p0, p1, p2, p3, p4, p5, p6); return t }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Ctor_O_O_O_O_O_I_O(c__pkg_file_QMARK_, c__read_fn, c__b__1901000165, c__dir, c__valid any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_read_fn = c__read_fn; t.F_b__1901000165 = c__b__1901000165; t.F_dir = c__dir; t.F_valid = c__valid; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :210:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A) Invoke_O__O(self any) any { { var i__1901000164__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000164__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000164__1)); if jrt.J2g_Truth(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2)) { var root_758 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_759 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_758, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_760 lang.IFn; if linked_759 == nil { ifn_760 = lang.IFn_Cast(root_758) } else { ifn_760 = nil }; var arg_761 any = t.F_b__1901000165; var arg_762 any; var tmp2 any = t.F_valid; var temp__1927000408__auto____3 any = lang.RT_Get_O_O__O_NoInit(tmp2, jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref())
																	if jrt.J2g_Truth(temp__1927000408__auto____3) { var e__4 any = temp__1927000408__auto____3; var tmp3 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_63.GetRawRoot__O()); var tmp4 any = A_arbace_build_go_A_const_82.Invoke_O__O(e__4); var tmp5 any = A_arbace_build_go_A_const_50; var tmp6 any = A_arbace_build_go_A_const_64; var tmp7 any; var root_773 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_774 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_773, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_775 lang.IFn
																		if linked_774 == nil { ifn_775 = lang.IFn_Cast(root_773) } else { ifn_775 = nil }; var arg_776 any; var tmp8 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New(); var tmp9 *jrt.Class; var fncls__782 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class; if fncls__782 == nil { var fncls__782d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_160, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class = fncls__782d; tmp9 = fncls__782d } else { tmp9 = fncls__782 }; arg_776 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp8, tmp9, nil); var arg_777 any = A_arbace_build_go_A_const_64.Invoke_O__O(e__4); if linked_774 == nil { tmp7 = ifn_775.Invoke_O_O__O(arg_776, arg_777) } else { tmp7 = linked_774.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_773, arg_776, arg_777) }; var tmp10 any = tmp7; var tmp11 any = A_arbace_build_go_A_const_95; var tmp12 any = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(f__2, t.F_dir); var tmp13 *jrt.Class; var fncls__789 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class
																		if fncls__789 == nil { var fncls__789d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_161, false); A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class = fncls__789d; tmp13 = fncls__789d } else { tmp13 = fncls__789 }
//line :212:1
		arg_762 = tmp3.Invoke_O_O_O_O_O_O_O__O(tmp4, tmp5, f__2, tmp6, tmp10, tmp11, lang.Delay_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp12, tmp13, nil))) } else {

			var root_790 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_791 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_790, A_arbace_build_go_collect_package_A_fn_class); var ifn_792 lang.IFn; if linked_791 == nil { ifn_792 = lang.IFn_Cast(root_790) } else { ifn_792 = nil }; var arg_793 any = t.F_dir; var arg_794 any = f__2; var arg_795 any = t.F_read_fn; if linked_791 == nil { arg_762 = ifn_792.Invoke_O_O_O__O(arg_793, arg_794, arg_795) } else { arg_762 = linked_791.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_790, arg_793, arg_794, arg_795) } }
//line :210:1
	if linked_759 == nil { ifn_760.Invoke_O_O__O(arg_761, arg_762) } else { linked_759.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_758, arg_761, arg_762) }; i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } else { i__1901000164__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000164__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Ctor() {}
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_778 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_779 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_778, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_780 lang.IFn; if linked_779 == nil { ifn_780 = lang.IFn_Cast(root_778) } else { ifn_780 = nil }; var arg_781 any = p1__1901000097_SHARP___1; if linked_779 == nil { tmp1 = ifn_780.Invoke_O__O(arg_781) } else { tmp1 = linked_779.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_778, arg_781) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
//line :212:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_New() *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A{}; t.Ctor(); return t }
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Ctor() {}
//line :212:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A) Invoke_O_O__O(self, p1__1901000097_SHARP___1 any) any { var tmp1 any; var root_843 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_844 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_843, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_845 lang.IFn; if linked_844 == nil { ifn_845 = lang.IFn_Cast(root_843) } else { ifn_845 = nil }; var arg_846 any = p1__1901000097_SHARP___1; if linked_844 == nil { tmp1 = ifn_845.Invoke_O__O(arg_846) } else { tmp1 = linked_844.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_843, arg_846) }; return jrt.File_New_String(jrt.String_Cast(tmp1)) }
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A) Invoke_O__O(self any) any { var root_783 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_783, A_arbace_build_go_collect_package_A_fn_class); var ifn_785 lang.IFn; if linked_784 == nil { ifn_785 = lang.IFn_Cast(root_783) } else { ifn_785 = nil }; var arg_786 any; var t_ any = t.F_dir; t.F_dir = nil; arg_786 = t_; var arg_787 any; var t__2 any = t.F_f; t.F_f = nil; arg_787 = t__2; var arg_788 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); if linked_784 == nil { return ifn_785.Invoke_O_O_O__O(arg_786, arg_787, arg_788) } else { return linked_784.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_783, arg_786, arg_787, arg_788) } }
//line :213:1
func A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A{}; t.Ctor_O_O(p0, p1); return t }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Ctor_O_O(c__f, c__dir any) { t.F_f = c__f; t.F_dir = c__dir }
//line :213:1
func (t *A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A) Invoke_O__O(self any) any { var root_848 any = A_arbace_build_go_A_const_96.GetRawRoot__O(); var linked_849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_848, A_arbace_build_go_collect_package_A_fn_class); var ifn_850 lang.IFn; if linked_849 == nil { ifn_850 = lang.IFn_Cast(root_848) } else { ifn_850 = nil }; var arg_851 any; var t_ any = t.F_dir; t.F_dir = nil; arg_851 = t_; var arg_852 any; var t__2 any = t.F_f; t.F_f = nil; arg_852 = t__2; var arg_853 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); if linked_849 == nil { return ifn_850.Invoke_O_O_O__O(arg_851, arg_852, arg_853) } else { return linked_849.(*A_arbace_build_go_collect_package_A).Invoke_O_O_O_O__O(root_848, arg_851, arg_852, arg_853) } }





func A_arbace_build_go_root_packages_fn__1901000187_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000187_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000187_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000187_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1087 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1088 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1087, A_arbace_build_go_rel_path_A_fn_class); var ifn_1089 lang.IFn; if linked_1088 == nil { ifn_1089 = lang.IFn_Cast(root_1087) } else { ifn_1089 = nil }; var arg_1090 any = t.F_dir; var arg_1091 any = A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1088 == nil { return ifn_1089.Invoke_O_O__O(arg_1090, arg_1091) } else { return linked_1088.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1087, arg_1090, arg_1091) } }
//line :219:1
func A_arbace_build_go_root_packages_fn__1901000192_A_New_O(p0 any) *A_arbace_build_go_root_packages_fn__1901000192_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_fn__1901000192_A{}; t.Ctor_O(p0); return t }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Ctor_O(c__dir any) { t.F_dir = c__dir }
//line :219:1
func (t *A_arbace_build_go_root_packages_fn__1901000192_A) Invoke_O_O__O(self, p1__1901000098_SHARP___1 any) any { var root_1111 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1112 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1111, A_arbace_build_go_rel_path_A_fn_class); var ifn_1113 lang.IFn; if linked_1112 == nil { ifn_1113 = lang.IFn_Cast(root_1111) } else { ifn_1113 = nil }; var arg_1114 any = t.F_dir; var arg_1115 any = A_arbace_build_go_A_const_50.Invoke_O__O(p1__1901000098_SHARP___1); if linked_1112 == nil { return ifn_1113.Invoke_O_O__O(arg_1114, arg_1115) } else { return linked_1112.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1111, arg_1114, arg_1115) } }


func A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_New_O_O(p0, p1 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_A{}; t.Ctor_O_O(p0, p1); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Ctor_O_O(c__pkg_file_QMARK_, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_A) Invoke_O_O__O(self, s__1901000195__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(t.F_pkg_file_QMARK_, s__1901000195__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__977 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class; if fncls__977 == nil { var fncls__977d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_162, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class = fncls__977d; tmp2 = fncls__977d } else { tmp2 = fncls__977 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :222:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_New_O_O_O_O(p0, p1, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A{}; t.Ctor_O_O_O_O(p0, p1, p2, p3); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Ctor_O_O_O_O(c__pkg_file_QMARK_, c__s__1901000195, c__iter__1901000194, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_s__1901000195 = c__s__1901000195; t.F_iter__1901000194 = c__iter__1901000194; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A) Invoke_O__O(self any) any { { var s__1901000195__1 any; var t_ any = t.F_s__1901000195; t.F_s__1901000195 = nil; s__1901000195__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_916 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_917 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_916, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_918 lang.IFn; if linked_917 == nil { ifn_918 = lang.IFn_Cast(root_916) } else { ifn_918 = nil }; var arg_919 any = s__1901000195__1; if linked_917 == nil { temp__1927000414__auto____2 = ifn_918.Invoke_O__O(arg_919) } else { temp__1927000414__auto____2 = linked_917.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_916, arg_919) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000195__3 any = temp__1927000414__auto____2; var tmp1 any; var root_920 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_920, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_922 lang.IFn; if linked_921 == nil { ifn_922 = lang.IFn_Cast(root_920) } else { ifn_922 = nil }; var arg_923 any = s__1901000195__3; if linked_921 == nil { tmp1 = ifn_922.Invoke_O__O(arg_923) } else { tmp1 = linked_921.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_920, arg_923) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_924 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_924, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_926 lang.IFn; if linked_925 == nil { ifn_926 = lang.IFn_Cast(root_924) } else { ifn_926 = nil }; var arg_927 any = s__1901000195__3; if linked_925 == nil { c__1927001037__auto____4 = ifn_926.Invoke_O__O(arg_927) } else { c__1927001037__auto____4 = linked_925.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_924, arg_927) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000197__6 any; var root_928 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_929 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_928, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_930 lang.IFn; if linked_929 == nil { ifn_930 = lang.IFn_Cast(root_928) } else { ifn_930 = nil }; var arg_931 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_929 == nil { b__1901000197__6 = ifn_930.Invoke_O__O(arg_931) } else { b__1901000197__6 = linked_929.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_928, arg_931) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(t.F_pkg_file_QMARK_, b__1901000197__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__937 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class; if fncls__937 == nil { var fncls__937d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_163, false); A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class = fncls__937d; tmp3 = fncls__937d } else { tmp3 = fncls__937 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_938 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_939 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_938, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_940 lang.IFn; if linked_939 == nil { ifn_940 = lang.IFn_Cast(root_938) } else { ifn_940 = nil }; var arg_941 any; var root_943 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_944 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_943, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_945 lang.IFn; if linked_944 == nil { ifn_945 = lang.IFn_Cast(root_943) } else { ifn_945 = nil }; var arg_946 any = b__1901000197__6; if linked_944 == nil { arg_941 = ifn_945.Invoke_O__O(arg_946) } else { arg_941 = linked_944.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_943, arg_946) }; var arg_942 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp5 any; var root_947 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_948 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_947, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_949 lang.IFn; if linked_948 == nil { ifn_949 = lang.IFn_Cast(root_947) } else { ifn_949 = nil }; var arg_950 any = s__1901000195__3; if linked_948 == nil { tmp5 = ifn_949.Invoke_O__O(arg_950) } else { tmp5 = linked_948.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_947, arg_950) }; arg_942 = tmp4.Invoke_O__O(tmp5); if linked_939 == nil { return ifn_940.Invoke_O_O__O(arg_941, arg_942) } else { return linked_939.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_938, arg_941, arg_942) } } else { var root_951 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_951, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_953 lang.IFn; if linked_952 == nil { ifn_953 = lang.IFn_Cast(root_951) } else { ifn_953 = nil }; var arg_954 any; var root_956 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_957 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_956, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_958 lang.IFn; if linked_957 == nil { ifn_958 = lang.IFn_Cast(root_956) } else { ifn_958 = nil }; var arg_959 any = b__1901000197__6; if linked_957 == nil { arg_954 = ifn_958.Invoke_O__O(arg_959) } else { arg_954 = linked_957.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_956, arg_959) }; var arg_955 any; if linked_952 == nil { return ifn_953.Invoke_O_O__O(arg_954, arg_955) } else { return linked_952.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_951, arg_954, arg_955) } } } else { var f__4 any; var root_960 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_961 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_960, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_962 lang.IFn; if linked_961 == nil { ifn_962 = lang.IFn_Cast(root_960) } else { ifn_962 = nil }; var arg_963 any = s__1901000195__3; if linked_961 == nil { f__4 = ifn_962.Invoke_O__O(arg_963) } else { f__4 = linked_961.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_960, arg_963) }; var tmp6 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__5 any = tmp6.Invoke_O__O(jrt.NN(jrt.File_Cast(f__4)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__5) { var root_964 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_965 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_964, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_966 lang.IFn; if linked_965 == nil { ifn_966 = lang.IFn_Cast(root_964) } else { ifn_966 = nil }; var arg_967 any = lang.Tuple_Create_O_O__IPersistentVector(sha__5, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__4))).Ref()); var arg_968 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000194); var tmp8 any; var root_969 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_970 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_969, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_971 lang.IFn; if linked_970 == nil { ifn_971 = lang.IFn_Cast(root_969) } else { ifn_971 = nil }; var arg_972 any = s__1901000195__3; if linked_970 == nil { tmp8 = ifn_971.Invoke_O__O(arg_972) } else { tmp8 = linked_970.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_969, arg_972) }; arg_968 = tmp7.Invoke_O__O(tmp8); if linked_965 == nil { return ifn_966.Invoke_O_O__O(arg_967, arg_968) } else { return linked_965.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_964, arg_967, arg_968) } } else { var tmp9 any; var root_973 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_974 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_973, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_975 lang.IFn; if linked_974 == nil { ifn_975 = lang.IFn_Cast(root_973) } else { ifn_975 = nil }; var arg_976 any = s__1901000195__3; if linked_974 == nil { tmp9 = ifn_975.Invoke_O__O(arg_976) } else { tmp9 = linked_974.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_973, arg_976) }; s__1901000195__1 = tmp9; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :222:1
func A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_New_O_O_I_O_O(p0, p1 any, p2 int32, p3, p4 any) *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A{}; t.Ctor_O_O_I_O_O(p0, p1, p2, p3, p4); return t }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Ctor_O_O_I_O_O(c__pkg_file_QMARK_, c__b__1901000197 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_pkg_file_QMARK_ = c__pkg_file_QMARK_; t.F_b__1901000197 = c__b__1901000197; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :222:1
func (t *A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A) Invoke_O__O(self any) any { { var i__1901000196__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000196__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var f__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000196__1)); var tmp2 lang.IFn = lang.IFn_Cast(t.F_shas); var sha__3 any = tmp2.Invoke_O__O(jrt.NN(jrt.File_Cast(f__2)).GetPath__String().Ref()); if jrt.J2g_Truth(sha__3) { var root_932 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_933 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_932, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_934 lang.IFn; if linked_933 == nil { ifn_934 = lang.IFn_Cast(root_932) } else { ifn_934 = nil }; var arg_935 any = t.F_b__1901000197; var arg_936 any = lang.Tuple_Create_O_O__IPersistentVector(sha__3, jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(lang.IFn_Cast(t.F_pkg_file_QMARK_).Invoke_O__O(f__2))).Ref()); if linked_933 == nil { ifn_934.Invoke_O_O__O(arg_935, arg_936) } else { linked_933.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_932, arg_935, arg_936) }; i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } else { i__1901000196__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000196__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_A{}; t.Ctor_O(p0); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_A) Invoke_O_O__O(self, s__1901000205__1 any) any { var tmp1 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(s__1901000205__1, self, t.F_shas); var tmp2 *jrt.Class; var fncls__1066 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class; if fncls__1066 == nil { var fncls__1066d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_164, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class = fncls__1066d; tmp2 = fncls__1066d } else { tmp2 = fncls__1066 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Ctor_O_O_O(c__s__1901000205, c__iter__1901000204, c__shas any) { t.F_s__1901000205 = c__s__1901000205; t.F_iter__1901000204 = c__iter__1901000204; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A) Invoke_O__O(self any) any { { var s__1901000205__1 any; var t_ any = t.F_s__1901000205; t.F_s__1901000205 = nil; s__1901000205__1 = t_; for { var temp__1927000414__auto____2 any; var root_987 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_988 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_987, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_989 lang.IFn; if linked_988 == nil { ifn_989 = lang.IFn_Cast(root_987) } else { ifn_989 = nil }; var arg_990 any = s__1901000205__1; if linked_988 == nil { temp__1927000414__auto____2 = ifn_989.Invoke_O__O(arg_990) } else { temp__1927000414__auto____2 = linked_988.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_987, arg_990) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000205__3 any = temp__1927000414__auto____2; var tmp1 any; var root_991 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_992 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_991, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_993 lang.IFn; if linked_992 == nil { ifn_993 = lang.IFn_Cast(root_991) } else { ifn_993 = nil }; var arg_994 any = s__1901000205__3; if linked_992 == nil { tmp1 = ifn_993.Invoke_O__O(arg_994) } else { tmp1 = linked_992.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_991, arg_994) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_995 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_996 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_995, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_997 lang.IFn; if linked_996 == nil { ifn_997 = lang.IFn_Cast(root_995) } else { ifn_997 = nil }; var arg_998 any = s__1901000205__3; if linked_996 == nil { c__1927001037__auto____4 = ifn_997.Invoke_O__O(arg_998) } else { c__1927001037__auto____4 = linked_996.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_995, arg_998) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000207__6 any; var root_999 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_999, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1001 lang.IFn; if linked_1000 == nil { ifn_1001 = lang.IFn_Cast(root_999) } else { ifn_1001 = nil }; var arg_1002 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1000 == nil { b__1901000207__6 = ifn_1001.Invoke_O__O(arg_1002) } else { b__1901000207__6 = linked_1000.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_999, arg_1002) }; var tmp2 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(b__1901000207__6, size__1927001038__auto____5, c__1927001037__auto____4, t.F_shas); var tmp3 *jrt.Class; var fncls__1019 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class; if fncls__1019 == nil { var fncls__1019d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_165, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class = fncls__1019d; tmp3 = fncls__1019d } else { tmp3 = fncls__1019 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1020 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1021 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1020, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1022 lang.IFn; if linked_1021 == nil { ifn_1022 = lang.IFn_Cast(root_1020) } else { ifn_1022 = nil }; var arg_1023 any; var root_1025 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1026 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1025, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1027 lang.IFn; if linked_1026 == nil { ifn_1027 = lang.IFn_Cast(root_1025) } else { ifn_1027 = nil }; var arg_1028 any = b__1901000207__6; if linked_1026 == nil { arg_1023 = ifn_1027.Invoke_O__O(arg_1028) } else { arg_1023 = linked_1026.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1025, arg_1028) }; var arg_1024 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp5 any; var root_1029 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1030 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1029, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1031 lang.IFn; if linked_1030 == nil { ifn_1031 = lang.IFn_Cast(root_1029) } else { ifn_1031 = nil }; var arg_1032 any = s__1901000205__3; if linked_1030 == nil { tmp5 = ifn_1031.Invoke_O__O(arg_1032) } else { tmp5 = linked_1030.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1029, arg_1032) }; arg_1024 = tmp4.Invoke_O__O(tmp5); if linked_1021 == nil { return ifn_1022.Invoke_O_O__O(arg_1023, arg_1024) } else { return linked_1021.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1020, arg_1023, arg_1024) } } else { var root_1033 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1034 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1033, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1035 lang.IFn; if linked_1034 == nil { ifn_1035 = lang.IFn_Cast(root_1033) } else { ifn_1035 = nil }; var arg_1036 any; var root_1038 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1038, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1040 lang.IFn; if linked_1039 == nil { ifn_1040 = lang.IFn_Cast(root_1038) } else { ifn_1040 = nil }; var arg_1041 any = b__1901000207__6; if linked_1039 == nil { arg_1036 = ifn_1040.Invoke_O__O(arg_1041) } else { arg_1036 = linked_1039.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1038, arg_1041) }; var arg_1037 any; if linked_1034 == nil { return ifn_1035.Invoke_O_O__O(arg_1036, arg_1037) } else { return linked_1034.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1033, arg_1036, arg_1037) } } } else { var pkg__4 any; var root_1042 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1042, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1044 lang.IFn; if linked_1043 == nil { ifn_1044 = lang.IFn_Cast(root_1042) } else { ifn_1044 = nil }; var arg_1045 any = s__1901000205__3; if linked_1043 == nil { pkg__4 = ifn_1044.Invoke_O__O(arg_1045) } else { pkg__4 = linked_1043.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1042, arg_1045) }; var root_1046 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1046, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1048 lang.IFn; if linked_1047 == nil { ifn_1048 = lang.IFn_Cast(root_1046) } else { ifn_1048 = nil }; var arg_1049 any; var tmp6 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(pkg__4))).GetPath__String().Ref(); var tmp7 any = A_arbace_build_go_A_const_64; var tmp8 any; var root_1051 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_1052 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1051, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1053 lang.IFn

	if linked_1052 == nil { ifn_1053 = lang.IFn_Cast(root_1051) } else { ifn_1053 = nil }; var arg_1054 any; var tmp9 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(t.F_shas); var tmp10 *jrt.Class; var fncls__1056 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class; if fncls__1056 == nil { var fncls__1056d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_166, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class = fncls__1056d; tmp10 = fncls__1056d } else { tmp10 = fncls__1056 }; arg_1054 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp9, tmp10, nil); var arg_1055 any = A_arbace_build_go_A_const_64.Invoke_O__O(pkg__4); if linked_1052 == nil { tmp8 = ifn_1053.Invoke_O_O__O(arg_1054, arg_1055) } else { tmp8 = linked_1052.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1051, arg_1054, arg_1055) }
//line :225:1
	var tmp11 any = tmp8; var tmp12 any = A_arbace_build_go_A_const_82; var tmp13 any; var root_1057 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1058 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1057, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1059 lang.IFn


	if linked_1058 == nil { ifn_1059 = lang.IFn_Cast(root_1057) } else { ifn_1059 = nil }; var arg_1060 any = pkg__4; var arg_1061 any = A_arbace_build_go_A_const_100; if linked_1058 == nil { tmp13 = ifn_1059.Invoke_O_O__O(arg_1060, arg_1061) } else { tmp13 = linked_1058.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1057, arg_1060, arg_1061) }
//line :225:1
	arg_1049 = lang.Tuple_Create_O_O__IPersistentVector(tmp6, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp7, tmp11, tmp12, tmp13))); var arg_1050 any; var tmp14 lang.IFn = lang.IFn_Cast(t.F_iter__1901000204); var tmp15 any; var root_1062 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1062, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1064 lang.IFn; if linked_1063 == nil { ifn_1064 = lang.IFn_Cast(root_1062) } else { ifn_1064 = nil }; var arg_1065 any = s__1901000205__3; if linked_1063 == nil { tmp15 = ifn_1064.Invoke_O__O(arg_1065) } else { tmp15 = linked_1063.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1062, arg_1065) }; arg_1050 = tmp14.Invoke_O__O(tmp15); if linked_1047 == nil { return ifn_1048.Invoke_O_O__O(arg_1049, arg_1050) } else { return linked_1047.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1046, arg_1049, arg_1050) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :225:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Ctor_O_I_O_O(c__b__1901000207 any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__, c__shas any) { t.F_b__1901000207 = c__b__1901000207; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__; t.F_shas = c__shas }
//line :225:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A) Invoke_O__O(self any) any { { var i__1901000206__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000206__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000206__1)); var root_1003 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1004 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1003, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1005 lang.IFn; if linked_1004 == nil { ifn_1005 = lang.IFn_Cast(root_1003) } else { ifn_1005 = nil }; var arg_1006 any = t.F_b__1901000207; var arg_1007 any; var tmp2 any = jrt.NN(jrt.File_Cast(A_arbace_build_go_A_const_50.Invoke_O__O(pkg__2))).GetPath__String().Ref(); var tmp3 any = A_arbace_build_go_A_const_64; var tmp4 any; var root_1008 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_1009 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1008, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1010 lang.IFn

	if linked_1009 == nil { ifn_1010 = lang.IFn_Cast(root_1008) } else { ifn_1010 = nil }; var arg_1011 any; var tmp5 any = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(t.F_shas); var tmp6 *jrt.Class; var fncls__1013 *jrt.Class = A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class; if fncls__1013 == nil { var fncls__1013d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_167, false); A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class = fncls__1013d; tmp6 = fncls__1013d } else { tmp6 = fncls__1013 }; arg_1011 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var arg_1012 any = A_arbace_build_go_A_const_64.Invoke_O__O(pkg__2); if linked_1009 == nil { tmp4 = ifn_1010.Invoke_O_O__O(arg_1011, arg_1012) } else { tmp4 = linked_1009.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1008, arg_1011, arg_1012) }
//line :225:1
	var tmp7 any = tmp4; var tmp8 any = A_arbace_build_go_A_const_82; var tmp9 any; var root_1014 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1015 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1014, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1016 lang.IFn


	if linked_1015 == nil { ifn_1016 = lang.IFn_Cast(root_1014) } else { ifn_1016 = nil }; var arg_1017 any = pkg__2; var arg_1018 any = A_arbace_build_go_A_const_99; if linked_1015 == nil { tmp9 = ifn_1016.Invoke_O_O__O(arg_1017, arg_1018) } else { tmp9 = linked_1015.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1014, arg_1017, arg_1018) }
//line :225:1
	arg_1007 = lang.Tuple_Create_O_O__IPersistentVector(tmp2, lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp3, tmp7, tmp8, tmp9))); if linked_1004 == nil { ifn_1005.Invoke_O_O__O(arg_1006, arg_1007) } else { linked_1004.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1003, arg_1006, arg_1007) }; i__1901000206__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000206__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }

func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }
//line :227:1
func A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_New_O(p0 any) *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A{}; t.Ctor_O(p0); return t }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Ctor_O(c__shas any) { t.F_shas = c__shas }
//line :227:1
func (t *A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A) Invoke_O_O__O(self, r__1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(t.F_shas); return lang.Tuple_Create_O_O__IPersistentVector(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref(), tmp1.Invoke_O__O(jrt.NN(jrt.File_Cast(r__1)).GetPath__String().Ref())) }





func A_arbace_build_go_collected_package_A_New() *A_arbace_build_go_collected_package_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_collected_package_A{}; t.Ctor(); return t }
//line :233:1
func (t *A_arbace_build_go_collected_package_A) Ctor() {}
//line :233:1
func (t *A_arbace_build_go_collected_package_A) Invoke_O_O__O(self, pkg__0 any) any { var temp__1927000408__auto____2 any = A_arbace_build_go_A_const_95.Invoke_O__O(pkg__0); if



	jrt.J2g_Truth(temp__1927000408__auto____2) { var d__3 any = temp__1927000408__auto____2; var c__4 any; var root_1125 any = A_arbace_build_go_A_const_6.GetRawRoot__O(); var linked_1126 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1125, aot_arbace_core.A_arbace_core_deref_A_fn_class); var ifn_1127 lang.IFn
		if linked_1126 == nil { ifn_1127 = lang.IFn_Cast(root_1125) } else { ifn_1127 = nil }; var arg_1128 any = d__3; if linked_1126 == nil { c__4 = ifn_1127.Invoke_O__O(arg_1128) } else { c__4 = linked_1126.(*aot_arbace_core.A_arbace_core_deref_A).Invoke_O_O__O(root_1125, arg_1128) }
		var tmp1 any; var root_1129 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1130 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1129, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1131 lang.IFn; if linked_1130 == nil { ifn_1131 = lang.IFn_Cast(root_1129) } else { ifn_1131 = nil }; var arg_1132 any = c__4; var arg_1133 any = A_arbace_build_go_A_const_102; if linked_1130 == nil { tmp1 = ifn_1131.Invoke_O_O__O(arg_1132, arg_1133) } else { tmp1 = linked_1130.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1129, arg_1132, arg_1133) }; var tmp2 any = tmp1; var tmp3 any; var root_1134 any = A_arbace_build_go_A_const_98.GetRawRoot__O(); var linked_1135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1134, aot_arbace_core.A_arbace_core_select_keys_A_fn_class); var ifn_1136 lang.IFn; if linked_1135 == nil { ifn_1136 = lang.IFn_Cast(root_1134) } else { ifn_1136 = nil }; var arg_1137 any = pkg__0; var arg_1138 any = A_arbace_build_go_A_const_103; if linked_1135 == nil { tmp3 = ifn_1136.Invoke_O_O__O(arg_1137, arg_1138) } else { tmp3 = linked_1135.(*aot_arbace_core.A_arbace_core_select_keys_A).Invoke_O_O_O__O(root_1134, arg_1137, arg_1138) }; if lang.Util_Equiv_O_O__Z_NoInit(tmp2, tmp3) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_56), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_46.Invoke_O__O(pkg__0), nil)).Ref()) }
//line :237:1
		return c__4 } else { return pkg__0 } }






func A_arbace_build_go_read_program_edn_A_New() *A_arbace_build_go_read_program_edn_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_read_program_edn_A{}; t.Ctor(); return t }
//line :244:1
func (t *A_arbace_build_go_read_program_edn_A) Ctor() {}
//line :244:1
func (t *A_arbace_build_go_read_program_edn_A) Invoke_O_O__O(self, dir__0 any) any { var f__2 any = jrt.File_New_File_String(jrt.File_Cast(dir__0), Lit_130); if

	jrt.NN(jrt.File_Cast(f__2)).IsFile__Z() { var forms__3 any; var root_1143 any = A_arbace_build_go_A_const_55.GetRawRoot__O(); var linked_1144 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1143, aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A_fn_class); var ifn_1145 lang.IFn
		if linked_1144 == nil { ifn_1145 = lang.IFn_Cast(root_1143) } else { ifn_1145 = nil }; var arg_1146 any = f__2; if linked_1144 == nil { forms__3 = ifn_1145.Invoke_O__O(arg_1146) } else { forms__3 = linked_1144.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_read_forms_A).Invoke_O_O__O(root_1143, arg_1146) }
		var tmp1 any; var and__1927000168__auto____4 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(forms__3))); if and__1927000168__auto____4 { var root_1151 any = A_arbace_build_go_A_const_68.GetRawRoot__O(); var linked_1152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1151, aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A_fn_class); var ifn_1153 lang.IFn; if linked_1152 == nil { ifn_1153 = lang.IFn_Cast(root_1151) } else { ifn_1153 = nil }; var arg_1154 any; var root_1155 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1156 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1155, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1157 lang.IFn; if linked_1156 == nil { ifn_1157 = lang.IFn_Cast(root_1155) } else { ifn_1157 = nil }; var arg_1158 any = forms__3; if linked_1156 == nil { arg_1154 = ifn_1157.Invoke_O__O(arg_1158) } else { arg_1154 = linked_1156.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1155, arg_1158) }; if linked_1152 == nil { tmp1 = ifn_1153.Invoke_O__O(arg_1154) } else { tmp1 = linked_1152.(*aot_arbace_core.A_arbace_core_map_QMARK___1927000036_A).Invoke_O_O__O(root_1151, arg_1154) } } else { tmp1 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____4).Ref() }; if jrt.J2g_Truth(tmp1) { } else {
			lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_131) }
		var root_1147 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1147, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1149 lang.IFn; if linked_1148 == nil { ifn_1149 = lang.IFn_Cast(root_1147) } else { ifn_1149 = nil }; var arg_1150 any = forms__3; if linked_1148 == nil { return ifn_1149.Invoke_O__O(arg_1150) } else { return linked_1148.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1147, arg_1150) } } else {
//line :246:1
			return lang.PersistentArrayMap_EMPTY.Ref() } }






func A_arbace_build_go_run_A_New() *A_arbace_build_go_run_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_run_A{}; t.Ctor(); return t }
//line :253:1
func (t *A_arbace_build_go_run_A) Ctor() {}
//line :253:1
func (t *A_arbace_build_go_run_A) Invoke_O_O_O_O_O__O(self, cmd__0, dir__1, env__2, inherit_QMARK___3 any) any { var pb__5 any; var tmp1 any; var root_1163 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1164 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1163, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1165 lang.IFn; if



	linked_1164 == nil { ifn_1165 = lang.IFn_Cast(root_1163) } else { ifn_1165 = nil }; var arg_1166 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1167 any = cmd__0; if linked_1164 == nil { tmp1 = ifn_1165.Invoke_O_O__O(arg_1166, arg_1167) } else { tmp1 = linked_1164.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1163, arg_1166, arg_1167) }; pb__5 = /*line :253:1*/jrt.ProcessBuilder_New_List(jrt.List_Cast(tmp1));




	jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Directory_File__ProcessBuilder(jrt.File_Cast(dir__1)); var penv__6 any = /*line :253:1*/jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Environment__Map(); var seq_1901000221__7 any; var root_1172 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1172, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1174 lang.IFn; if






	linked_1173 == nil { ifn_1174 = lang.IFn_Cast(root_1172) } else { ifn_1174 = nil }; var arg_1175 any = env__2; if linked_1173 == nil { seq_1901000221__7 = ifn_1174.Invoke_O__O(arg_1175) } else { seq_1901000221__7 = linked_1173.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1172, arg_1175) }; var chunk_1901000222__8 any; var count_1901000223__9 int64 = 0; var i_1901000224__10 int64 = 0; L1:
//line :253:1
	for {






		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000224__10, count_1901000223__9) { var vec__1901000225__11 any = lang.Indexed_Cast(chunk_1901000222__8).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000224__10)); var k__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(0), nil); var v__13 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000225__11, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__12, v__13); seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000224__10); continue L1 } else { var temp__1927000414__auto____11 any; var root_1176 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1177 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1176, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1178 lang.IFn; if linked_1177 == nil { ifn_1178 = lang.IFn_Cast(root_1176) } else { ifn_1178 = nil }; var arg_1179 any = seq_1901000221__7; if linked_1177 == nil { temp__1927000414__auto____11 = ifn_1178.Invoke_O__O(arg_1179) } else { temp__1927000414__auto____11 = linked_1177.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1176, arg_1179) }; if jrt.J2g_Truth(temp__1927000414__auto____11) { var seq_1901000221__12 any = temp__1927000414__auto____11; var tmp2 any; var root_1180 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1181 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1180, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1182 lang.IFn; if linked_1181 == nil { ifn_1182 = lang.IFn_Cast(root_1180) } else { ifn_1182 = nil }; var arg_1183 any = seq_1901000221__12; if linked_1181 == nil { tmp2 = ifn_1182.Invoke_O__O(arg_1183) } else { tmp2 = linked_1181.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1180, arg_1183) }; if jrt.J2g_Truth(tmp2) { var c__1927000678__auto____13 any; var root_1184 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1185 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1184, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1186 lang.IFn; if linked_1185 == nil { ifn_1186 = lang.IFn_Cast(root_1184) } else { ifn_1186 = nil }; var arg_1187 any = seq_1901000221__12; if linked_1185 == nil { c__1927000678__auto____13 = ifn_1186.Invoke_O__O(arg_1187) } else { c__1927000678__auto____13 = linked_1185.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1184, arg_1187) }; var tmp3 any; var root_1192 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1193 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1192, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1194 lang.IFn; if linked_1193 == nil { ifn_1194 = lang.IFn_Cast(root_1192) } else { ifn_1194 = nil }; var arg_1195 any = seq_1901000221__12; if linked_1193 == nil { tmp3 = ifn_1194.Invoke_O__O(arg_1195) } else { tmp3 = linked_1193.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1192, arg_1195) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp3, c__1927000678__auto____13, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____13))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000228__13 any; var root_1188 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1189 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1188, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1190 lang.IFn; if linked_1189 == nil { ifn_1190 = lang.IFn_Cast(root_1188) } else { ifn_1190 = nil }; var arg_1191 any = seq_1901000221__12; if linked_1189 == nil { vec__1901000228__13 = ifn_1190.Invoke_O__O(arg_1191) } else { vec__1901000228__13 = linked_1189.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1188, arg_1191) }; var k__14 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(0), nil); var v__15 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000228__13, lang.RT_IntCast_J__I_NoInit(1), nil); jrt.Map_Cast(penv__6).Put_O_O__O(k__14, v__15); var tmp4 any; var root_1196 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1197 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1196, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1198 lang.IFn; if linked_1197 == nil { ifn_1198 = lang.IFn_Cast(root_1196) } else { ifn_1198 = nil }; var arg_1199 any = seq_1901000221__12; if linked_1197 == nil { tmp4 = ifn_1198.Invoke_O__O(arg_1199) } else { tmp4 = linked_1197.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1196, arg_1199) }; seq_1901000221__7, chunk_1901000222__8, count_1901000223__9, i_1901000224__10 = tmp4, nil, 0, 0; continue L1 } } }
//line :253:1
		break L1 }; if







	jrt.J2g_Truth(inherit_QMARK___3) {
		jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).InheritIO__ProcessBuilder()
//line :261:1
		return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process().WaitFor__I()).Ref(), nil) } else {


			jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).RedirectErrorStream_Z__ProcessBuilder(jrt.NN(jrt.Boolean_TRUE).BooleanValue__Z())
//line :261:1
			var proc__6 any = jrt.NN(jrt.ProcessBuilder_Cast(pb__5)).Start__Process(); var out__7 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(jrt.Process_Cast(proc__6).GetInputStream__InputStream()); return lang.Tuple_Create_O_O__IPersistentVector(jrt.Integer_ValueOf_I__Integer_NoInit(jrt.Process_Cast(proc__6).WaitFor__I()).Ref(), out__7) } }









func A_arbace_build_go_go_env_A_New() *A_arbace_build_go_go_env_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_env_A{}; t.Ctor(); return t }
//line :271:1
func (t *A_arbace_build_go_go_env_A) Ctor() {}
//line :271:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O_O__O(self, goroot__0, arch__1, goos__2 any) any {





	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_11.GetRawRoot__O()); var tmp2 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.ConstRefArray("[0,20,s7:GOFLAGSs0:s11:GO111MODULEs2:ons6:GOARCHh0,s4:GOOSh1,s12:GOEXPERIMENTs0:s6:GOWORKs3:offs7:GOPROXYs3:offs11:CGO_ENABLEDs1:0s6:GOROOTh2,s11:GOTOOLCHAINs5:local", []*jrt.Class{jrt.Object_class}, arch__1, goos__2, goroot__0)); var tmp3 lang.IPersistentMap


	if lang.Util_Equiv_O_O__Z_NoInit(goos__2, Lit_28) { var tmp4 *lang.Keyword = A_arbace_build_go_A_const_46; tmp3 = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_64, tmp4.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()))) } else { tmp3 = nil }
//line :277:1
	var tmp5 any = tmp3; var tmp6 any
	var G__1901000232__4_ any = arch__1


L1: switch { default: switch lang.Util_Hash_O__I_NoInit(G__1901000232__4_) >> 2 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_65) { tmp6 = A_arbace_build_go_A_const_106; break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000232__4_, Lit_5) { tmp6 = A_arbace_build_go_A_const_107; break L1 }; default:}; panic(jrt.Thrown(jrt.IllegalArgumentException_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_66, nil), jrt.RefArrayOf(jrt.Object_class, nil, G__1901000232__4_)))))}
//line :277:1
	return tmp1.Invoke_O_O_O__O(tmp2, tmp5, tmp6) }
//line :271:1
func (t *A_arbace_build_go_go_env_A) Invoke_O_O_O__O(self, goroot__0, arch__1 any) any {



	var root_1207 any = A_arbace_build_go_A_const_108.GetRawRoot__O(); var linked_1208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1207, A_arbace_build_go_go_env_A_fn_class); var ifn_1209 lang.IFn; if linked_1208 == nil { ifn_1209 = lang.IFn_Cast(root_1207) } else { ifn_1209 = nil }; var arg_1210 any = goroot__0; var arg_1211 any = arch__1; var arg_1212 any = Lit_38; if linked_1208 == nil { return ifn_1209.Invoke_O_O_O__O(arg_1210, arg_1211, arg_1212) } else { return linked_1208.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_1207, arg_1210, arg_1211, arg_1212)
	}
}
























func A_arbace_build_go_go_mod_cache_A_New() *A_arbace_build_go_go_mod_cache_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_go_mod_cache_A{}; t.Ctor(); return t }
//line :302:1
func (t *A_arbace_build_go_go_mod_cache_A) Ctor() {}
//line :302:1
func (t *A_arbace_build_go_go_mod_cache_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000234__2 any; var root_1213 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_1214 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1213, A_arbace_build_go_run_A_fn_class); var ifn_1215 lang.IFn; if
											linked_1214 == nil { ifn_1215 = lang.IFn_Cast(root_1213) } else { ifn_1215 = nil }; var arg_1216 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_67, Lit_68); var arg_1217 any = jrt.File_New_String(Lit_69); var arg_1218 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_70, goroot__0, Lit_71, Lit_72)); var arg_1219 any = jrt.Boolean_FALSE.Ref(); if linked_1214 == nil { vec__1901000234__2 = ifn_1215.Invoke_O_O_O_O__O(arg_1216, arg_1217, arg_1218, arg_1219) } else { vec__1901000234__2 = linked_1214.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1213, arg_1216, arg_1217, arg_1218, arg_1219) }; var status__3 any = /*line :302:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000234__2, lang.RT_IntCast_J__I_NoInit(1), nil); var tmp1 bool; var na_1228 any = status__3; if


	jrt.Long_InstanceOf(na_1228) { var n0_1229 int64 = jrt.NN(jrt.Long_Cast(na_1228)).LongValue__J(); tmp1 = n0_1229 == 0 } else { if jrt.Double_InstanceOf(na_1228) { var n0_1229_2 float64 = jrt.NN(jrt.Double_Cast(na_1228)).DoubleValue__D(); tmp1 = n0_1229_2 == 0.0 } else { tmp1 = lang.Numbers_IsZero_O__Z_NoInit(na_1228) } }; if tmp1 { } else { lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_73, nil), jrt.RefArrayOf(jrt.Object_class, nil, out__4)).Ref()) }; var root_1220 any =
	A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1221 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1220, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1222 lang.IFn; if linked_1221 == nil { ifn_1222 = lang.IFn_Cast(root_1220) } else { ifn_1222 = nil }; var arg_1223 any; var root_1224 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1224, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1226 lang.IFn; if linked_1225 == nil { ifn_1226 = lang.IFn_Cast(root_1224) } else { ifn_1226 = nil }; var arg_1227 any = out__4; if linked_1225 == nil { arg_1223 = ifn_1226.Invoke_O__O(arg_1227) } else { arg_1223 = linked_1225.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1224, arg_1227) }; if linked_1221 == nil { return ifn_1222.Invoke_O__O(arg_1223) } else { return linked_1221.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1220, arg_1223) } }

func A_arbace_build_go_h1_of_file_A_New() *A_arbace_build_go_h1_of_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_A{}; t.Ctor(); return t }
//line :308:1
func (t *A_arbace_build_go_h1_of_file_A) Ctor() {}
//line :308:1
func (t *A_arbace_build_go_h1_of_file_A) Invoke_O_O_O__O(self, data__0, name__1 any) any { var hex__3 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_A_New(); var tmp2 *jrt.Class; var fncls__1255 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class; if


	fncls__1255 == nil { var fncls__1255d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_74, false); A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class = fncls__1255d; tmp2 = fncls__1255d } else { tmp2 = fncls__1255 }; hex__3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var sha__4 any; var tmp3 any = /*line :308:1*/A_arbace_build_go_h1_of_file_sha__1901000243_A_New(); var tmp4 *jrt.Class; var fncls__1256 *jrt.Class = A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class; if



	fncls__1256 == nil { var fncls__1256d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_75, false); A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class = fncls__1256d; tmp4 = fncls__1256d } else { tmp4 = fncls__1256 }; sha__4 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil); var summary__5 any = /*line :308:1*/lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_76, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, lang.IFn_Cast(hex__3).Invoke_O__O(lang.IFn_Cast(sha__4).Invoke_O__O(data__0)), nil, name__1, nil)).Ref(); return /*line :314:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_77, nil), jrt.RefArrayOf(jrt.Object_class, nil, jrt.NN(jrt.Base64_GetEncoder__Base64_Encoder()).EncodeToString_B1__String(jrt.ByteArray_Cast(lang.IFn_Cast(sha__4).Invoke_O__O(jrt.NN(jrt.String_Cast(summary__5)).GetBytes_String__B1(Lit_52).Ref()))).Ref())).Ref() }
//line :311:1
func A_arbace_build_go_h1_of_file_hex__1901000239_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_A) Invoke_O_O__O(self, b__1 any) any { var root_1234 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1235 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1234, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1236 lang.IFn; if linked_1235 == nil { ifn_1236 = lang.IFn_Cast(root_1234) } else { ifn_1236 = nil }; var arg_1237 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1238 any; var root_1239 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1240 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1239, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1241 lang.IFn; if linked_1240 == nil { ifn_1241 = lang.IFn_Cast(root_1239) } else { ifn_1241 = nil }; var arg_1242 any; var tmp1 any = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New(); var tmp2 *jrt.Class; var fncls__1254 *jrt.Class = A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class; if fncls__1254 == nil { var fncls__1254d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_78, false); A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class = fncls__1254d; tmp2 = fncls__1254d } else { tmp2 = fncls__1254 }; arg_1242 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1243 any = b__1; if linked_1240 == nil { arg_1238 = ifn_1241.Invoke_O_O__O(arg_1242, arg_1243) } else { arg_1238 = linked_1240.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1239, arg_1242, arg_1243) }; if linked_1235 == nil { return ifn_1236.Invoke_O_O__O(arg_1237, arg_1238) } else { return linked_1235.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1234, arg_1237, arg_1238) } }
//line :311:1
func A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_New() *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A{}; t.Ctor(); return t }
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Ctor() {}
//line :311:1
func (t *A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A) Invoke_O_O__O(self, p1__1901000238_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_1249 any = p1__1901000238_SHARP___1; var na_1250 int64 = 255; if jrt.Long_InstanceOf(na_1249) { var n0_1251 int64 = jrt.NN(jrt.Long_Cast(na_1249)).LongValue__J(); var n1_1252 int64 = na_1250; tmp2 = n0_1251 & n1_1252 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1249, na_1250) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }
func A_arbace_build_go_h1_of_file_sha__1901000243_A_New() *A_arbace_build_go_h1_of_file_sha__1901000243_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_h1_of_file_sha__1901000243_A{}; t.Ctor(); return t }
//line :312:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Ctor() {}
//line :312:1
func (t *A_arbace_build_go_h1_of_file_sha__1901000243_A) Invoke_O_O__O(self, b__1 any) any { return jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51).Digest_B1__B1(jrt.ByteArray_Cast(b__1)).Ref() }



func A_arbace_build_go_tamago_go_sum_A_New() *A_arbace_build_go_tamago_go_sum_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_tamago_go_sum_A{}; t.Ctor(); return t }
//line :316:1
func (t *A_arbace_build_go_tamago_go_sum_A) Ctor() {}
//line :316:1
func (t *A_arbace_build_go_tamago_go_sum_A) Invoke_O_O__O(self, goroot__0 any) any { var map__1901000246__2 any = A_arbace_build_go_A_const_105.GetRawRoot__O(); var map__1901000246__3 any; if



	lang.ISeq_InstanceOf(map__1901000246__2) { var tmp1 any; var root_1257 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1258 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1257, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1259 lang.IFn; if linked_1258 == nil { ifn_1259 = lang.IFn_Cast(root_1257) } else { ifn_1259 = nil }; var arg_1260 any = map__1901000246__2; if linked_1258 == nil { tmp1 = ifn_1259.Invoke_O__O(arg_1260) } else { tmp1 = linked_1258.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1257, arg_1260) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1261 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1262 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1261, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1263 lang.IFn; if linked_1262 == nil { ifn_1263 = lang.IFn_Cast(root_1261) } else { ifn_1263 = nil }; var arg_1264 any = map__1901000246__2; if linked_1262 == nil { tmp2 = ifn_1263.Invoke_O__O(arg_1264) } else { tmp2 = linked_1262.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1261, arg_1264) }; map__1901000246__3 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1265 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1266 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1265, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1267 lang.IFn; if linked_1266 == nil { ifn_1267 = lang.IFn_Cast(root_1265) } else { ifn_1267 = nil }; var arg_1268 any = map__1901000246__2; if linked_1266 == nil { tmp3 = ifn_1267.Invoke_O__O(arg_1268) } else { tmp3 = linked_1266.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1265, arg_1268) }; if jrt.J2g_Truth(tmp3) { var root_1269 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1270 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1269, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1271 lang.IFn; if linked_1270 == nil { ifn_1271 = lang.IFn_Cast(root_1269) } else { ifn_1271 = nil }; var arg_1272 any = map__1901000246__2; if linked_1270 == nil { map__1901000246__3 = ifn_1271.Invoke_O__O(arg_1272) } else { map__1901000246__3 = linked_1270.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1269, arg_1272) } } else { map__1901000246__3 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000246__3 = map__1901000246__2 }; var path__4 any = /*line :316:1*/lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_46); var version__5 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_112); var zip__6 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_113); var mod__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000246__3, A_arbace_build_go_A_const_114); var dir__8 any; var tmp4 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_169, nil, Lit_170); var tmp5 any; var root_1273 any = A_arbace_build_go_A_const_115.GetRawRoot__O(); var linked_1274 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1273, A_arbace_build_go_go_mod_cache_A_fn_class); var ifn_1275 lang.IFn; if




	linked_1274 == nil { ifn_1275 = lang.IFn_Cast(root_1273) } else { ifn_1275 = nil }; var arg_1276 any = goroot__0; if linked_1274 == nil { tmp5 = ifn_1275.Invoke_O__O(arg_1276) } else { tmp5 = linked_1274.(*A_arbace_build_go_go_mod_cache_A).Invoke_O_O__O(root_1273, arg_1276) }; dir__8 = /*line :316:1*/jrt.File_New_String(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp4, jrt.RefArrayOf(jrt.Object_class, tmp5, nil, path__4, nil))); var zf__9 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_171), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var mf__10 any = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_172), jrt.RefArrayOf(jrt.Object_class, version__5, nil))); var ___11 any; var tmp6 bool; var and__1927000168__auto____11 bool = jrt.NN(jrt.File_Cast(zf__9)).IsFile__Z(); _ = ___11; if and__1927000168__auto____11 {







		var and__1927000168__auto____12 bool = jrt.NN(jrt.File_Cast(mf__10)).IsFile__Z(); if and__1927000168__auto____12 { tmp6 = jrt.File_New_File_String(jrt.File_Cast(dir__8), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_173), jrt.RefArrayOf(jrt.Object_class, version__5, nil))).IsFile__Z() } else { tmp6 = and__1927000168__auto____12 } } else { tmp6 = and__1927000168__auto____11 }; if tmp6 { ___11 = nil } else {
			___11 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_174, nil, Lit_175, nil, Lit_176), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, jrt.NN(jrt.File_Cast(dir__8)).GetPath__String().Ref(), nil)).Ref()) }; var zh__12 any; var root_1281 any = /*line :316:1*/A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1281, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1283 lang.IFn; if









	linked_1282 == nil { ifn_1283 = lang.IFn_Cast(root_1281) } else { ifn_1283 = nil }; var arg_1284 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(zf__9); if linked_1282 == nil { zh__12 = ifn_1283.Invoke_O__O(arg_1284) } else { zh__12 = linked_1282.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1281, arg_1284) }; var mh__13 any; var root_1289 any = /*line :316:1*/A_arbace_build_go_A_const_116.GetRawRoot__O(); var linked_1290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1289, A_arbace_build_go_h1_of_file_A_fn_class); var ifn_1291 lang.IFn; if










	linked_1290 == nil { ifn_1291 = lang.IFn_Cast(root_1289) } else { ifn_1291 = nil }; var arg_1292 any = jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(mf__10)).ToPath__Path()).Ref(); var arg_1293 any = Lit_99; if linked_1290 == nil { mh__13 = ifn_1291.Invoke_O_O__O(arg_1292, arg_1293) } else { mh__13 = linked_1290.(*A_arbace_build_go_h1_of_file_A).Invoke_O_O_O__O(root_1289, arg_1292, arg_1293) }; var tmp7 bool; var and__1927000168__auto____14 bool =
	lang.Util_Equiv_O_O__Z_NoInit(zh__12, zip__6); if and__1927000168__auto____14 { tmp7 = lang.Util_Equiv_O_O__Z_NoInit(mh__13, mod__7) } else { tmp7 = and__1927000168__auto____14 }; if tmp7 { } else {
		lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,11,ns1:@ns33: in Go's module cache has hashes ns1: ns17:, not the pinned ns1: n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zh__12, nil, mh__13, nil, zip__6, nil, mod__7)).Ref()) }; return /*line :330:1*/ lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.ConstRefArray("[0,12,ns1: ns1: ns1:\nns1: ns8:/go.mod ns1:\n", []*jrt.Class{jrt.String_class}), jrt.RefArrayOf(jrt.Object_class, path__4, nil, version__5, nil, zip__6, nil, path__4, nil, version__5, nil, mod__7, nil)).Ref() }

func A_arbace_build_go_toolchain_lang_A_New() *A_arbace_build_go_toolchain_lang_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_toolchain_lang_A{}; t.Ctor(); return t }
//line :332:1
func (t *A_arbace_build_go_toolchain_lang_A) Ctor() {}
//line :332:1
func (t *A_arbace_build_go_toolchain_lang_A) Invoke_O_O__O(self, goroot__0 any) any { var vec__1901000249__2 any; var root_1298 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_1299 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1298, A_arbace_build_go_run_A_fn_class); var ifn_1300 lang.IFn; if


	linked_1299 == nil { ifn_1300 = lang.IFn_Cast(root_1298) } else { ifn_1300 = nil }; var arg_1301 any = lang.Tuple_Create_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__0, nil)).Ref(), Lit_67, Lit_177); var arg_1302 any = jrt.File_New_String(Lit_69); var arg_1303 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, Lit_70, goroot__0, Lit_71, Lit_72)); var arg_1304 any = jrt.Boolean_FALSE.Ref(); if linked_1299 == nil { vec__1901000249__2 = ifn_1300.Invoke_O_O_O_O__O(arg_1301, arg_1302, arg_1303, arg_1304) } else { vec__1901000249__2 = linked_1299.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_1298, arg_1301, arg_1302, arg_1303, arg_1304) }; var status__3 any = /*line :332:1*/lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(0), nil); var out__4 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000249__2, lang.RT_IntCast_J__I_NoInit(1), nil); var v__5 any; var root_1305 any = A_arbace_build_go_A_const_110.GetRawRoot__O(); var linked_1306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1305, aot_arbace_string.A_arbace_string_trim_A_fn_class); var ifn_1307 lang.IFn; if




	linked_1306 == nil { ifn_1307 = lang.IFn_Cast(root_1305) } else { ifn_1307 = nil }; var arg_1308 any; var root_1309 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1310 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1309, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1311 lang.IFn; if linked_1310 == nil { ifn_1311 = lang.IFn_Cast(root_1309) } else { ifn_1311 = nil }; var arg_1312 any = out__4; if linked_1310 == nil { arg_1308 = ifn_1311.Invoke_O__O(arg_1312) } else { arg_1308 = linked_1310.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1309, arg_1312) }; if linked_1306 == nil { v__5 = ifn_1307.Invoke_O__O(arg_1308) } else { v__5 = linked_1306.(*aot_arbace_string.A_arbace_string_trim_A).Invoke_O_O__O(root_1305, arg_1308) }; var temp__1927000408__auto____6 any; var and__1927000168__auto____6 bool; var na_1313 any = status__3; if
	jrt.Long_InstanceOf(na_1313) { var n0_1314 int64 = jrt.NN(jrt.Long_Cast(na_1313)).LongValue__J(); and__1927000168__auto____6 = n0_1314 == 0 } else { if jrt.Double_InstanceOf(na_1313) { var n0_1314_2 float64 = jrt.NN(jrt.Double_Cast(na_1313)).DoubleValue__D(); and__1927000168__auto____6 = n0_1314_2 == 0.0 } else { and__1927000168__auto____6 = lang.Numbers_IsZero_O__Z_NoInit(na_1313) } }; if and__1927000168__auto____6 { var root_1315 any = A_arbace_build_go_A_const_117.GetRawRoot__O(); var linked_1316 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1315, aot_arbace_core.A_arbace_core_re_find_A_fn_class); var ifn_1317 lang.IFn; if linked_1316 == nil { ifn_1317 = lang.IFn_Cast(root_1315) } else { ifn_1317 = nil }; var arg_1318 any = A_arbace_build_go_A_const_118; var arg_1319 any = v__5; if linked_1316 == nil { temp__1927000408__auto____6 = ifn_1317.Invoke_O_O__O(arg_1318, arg_1319) } else { temp__1927000408__auto____6 = linked_1316.(*aot_arbace_core.A_arbace_core_re_find_A).Invoke_O_O_O__O(root_1315, arg_1318, arg_1319) } } else { temp__1927000408__auto____6 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____6).Ref() }; if jrt.J2g_Truth(temp__1927000408__auto____6) { var vec__1901000252__7 any = temp__1927000408__auto____6; var ___8 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(0), nil); var l__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000252__7, lang.RT_IntCast_J__I_NoInit(1), nil); _ = ___8; return l__9 } else {

		return lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_178, nil), jrt.RefArrayOf(jrt.Object_class, nil, v__5)).Ref()) } }

func A_arbace_build_go_program_A_New() *A_arbace_build_go_program_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_A{}; t.Ctor(); return t }
//line :342:1
func (t *A_arbace_build_go_program_A) Ctor() {}
//line :342:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O_O__O(self, dir__0, goroot__1, p__1901000259__2 any) any { var map__1901000260__4 any = p__1901000259__2; var map__1901000260__5 any; if lang.ISeq_InstanceOf(map__1901000260__4) { var tmp1 any; var root_1324 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1325 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1324, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1326 lang.IFn; if linked_1325 == nil { ifn_1326 = lang.IFn_Cast(root_1324) } else { ifn_1326 = nil }; var arg_1327 any = map__1901000260__4; if linked_1325 == nil { tmp1 = ifn_1326.Invoke_O__O(arg_1327) } else { tmp1 = linked_1325.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1324, arg_1327) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1328 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1329 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1328, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1330 lang.IFn; if linked_1329 == nil { ifn_1330 = lang.IFn_Cast(root_1328) } else { ifn_1330 = nil }; var arg_1331 any = map__1901000260__4; if linked_1329 == nil { tmp2 = ifn_1330.Invoke_O__O(arg_1331) } else { tmp2 = linked_1329.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1328, arg_1331) }; map__1901000260__5 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1332 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1333 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1332, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1334 lang.IFn; if linked_1333 == nil { ifn_1334 = lang.IFn_Cast(root_1332) } else { ifn_1334 = nil }; var arg_1335 any = map__1901000260__4; if linked_1333 == nil { tmp3 = ifn_1334.Invoke_O__O(arg_1335) } else { tmp3 = linked_1333.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1332, arg_1335) }; if jrt.J2g_Truth(tmp3) { var root_1336 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1337 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1336, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1338 lang.IFn; if linked_1337 == nil { ifn_1338 = lang.IFn_Cast(root_1336) } else { ifn_1338 = nil }; var arg_1339 any = map__1901000260__4; if linked_1337 == nil { map__1901000260__5 = ifn_1338.Invoke_O__O(arg_1339) } else { map__1901000260__5 = linked_1337.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1336, arg_1339) } } else { map__1901000260__5 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000260__5 = map__1901000260__4 }; var opts__6 any = map__1901000260__5; var library_QMARK___7 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_119); var roots__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000260__5, A_arbace_build_go_A_const_120); var pkgs__9 any; var root_1340 any = A_arbace_build_go_A_const_52.GetRawRoot__O(); var linked_1341 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1340, A_arbace_build_go_packages_A_fn_class); var ifn_1342 lang.IFn; if









	linked_1341 == nil { ifn_1342 = lang.IFn_Cast(root_1340) } else { ifn_1342 = nil }; var arg_1343 any = dir__0; var arg_1344 any = roots__8; var arg_1345 any = A_arbace_build_go_A_const_121.Invoke_O__O(opts__6); if linked_1341 == nil { pkgs__9 = ifn_1342.Invoke_O_O_O__O(arg_1343, arg_1344, arg_1345) } else { pkgs__9 = linked_1341.(*A_arbace_build_go_packages_A).Invoke_O_O_O_O__O(root_1340, arg_1343, arg_1344, arg_1345) }; var mains__10 any; var G__1901000262__10_ any; var root_1346 any = /*line :342:1*/A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1347 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1346, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1348 lang.IFn; if










	linked_1347 == nil { ifn_1348 = lang.IFn_Cast(root_1346) } else { ifn_1348 = nil }; var arg_1349 any; var tmp4 any = A_arbace_build_go_program_fn__1901000263_A_New(); var tmp5 *jrt.Class; var fncls__1355 *jrt.Class = A_arbace_build_go_program_fn__1901000263_A_fn_class; if fncls__1355 == nil { var fncls__1355d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_118, false); A_arbace_build_go_program_fn__1901000263_A_fn_class = fncls__1355d; tmp5 = fncls__1355d } else { tmp5 = fncls__1355 }; arg_1349 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp4, tmp5, nil); var arg_1350 any = pkgs__9; if linked_1347 == nil { G__1901000262__10_ = ifn_1348.Invoke_O_O__O(arg_1349, arg_1350) } else { G__1901000262__10_ = linked_1347.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1346, arg_1349, arg_1350) }; if jrt.J2g_Truth(A_arbace_build_go_A_const_122.Invoke_O__O(opts__6)) {
		var root_1356 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1357 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1356, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1358 lang.IFn; if linked_1357 == nil { ifn_1358 = lang.IFn_Cast(root_1356) } else { ifn_1358 = nil }; var arg_1359 any; var tmp6 any = A_arbace_build_go_program_fn__1901000265_A_New_O(opts__6); var tmp7 *jrt.Class; var fncls__1361 *jrt.Class = A_arbace_build_go_program_fn__1901000265_A_fn_class; if fncls__1361 == nil { var fncls__1361d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_119, false); A_arbace_build_go_program_fn__1901000265_A_fn_class = fncls__1361d; tmp7 = fncls__1361d } else { tmp7 = fncls__1361 }; arg_1359 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp6, tmp7, nil); var arg_1360 any = G__1901000262__10_; if linked_1357 == nil { mains__10 = ifn_1358.Invoke_O_O__O(arg_1359, arg_1360) } else { mains__10 = linked_1357.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1356, arg_1359, arg_1360) } } else {
//line :353:1
			mains__10 = G__1901000262__10_ }; var ___11 any; var tmp8 any; var or__1927000174__auto____11 bool = /*line :342:1*/lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(mains__10))); _ = ___11; if or__1927000174__auto____11 {












				tmp8 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(or__1927000174__auto____11).Ref() } else { var and__1927000168__auto____12 any = library_QMARK___7; if jrt.J2g_Truth(and__1927000168__auto____12) { var or__1927000174__auto____13 any; var root_1362 any = A_arbace_build_go_A_const_97.GetRawRoot__O(); var linked_1363 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1362, aot_arbace_core.A_arbace_core_empty_QMARK__A_fn_class); var ifn_1364 lang.IFn; if linked_1363 == nil { ifn_1364 = lang.IFn_Cast(root_1362) } else { ifn_1364 = nil }; var arg_1365 any = mains__10; if linked_1363 == nil { or__1927000174__auto____13 = ifn_1364.Invoke_O__O(arg_1365) } else { or__1927000174__auto____13 = linked_1363.(*aot_arbace_core.A_arbace_core_empty_QMARK__A).Invoke_O_O__O(root_1362, arg_1365) }; if jrt.J2g_Truth(or__1927000174__auto____13) { tmp8 = or__1927000174__auto____13 } else { tmp8 = A_arbace_build_go_A_const_123.Invoke_O__O(opts__6) } } else { tmp8 = and__1927000168__auto____12 } }; if jrt.J2g_Truth(tmp8) { ___11 = nil } else {
					var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp10 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_120, nil, nil); var tmp11 any = jrt.Integer_ValueOf_I__Integer_NoInit(lang.RT_Count_O__I_NoInit(mains__10)).Ref(); var tmp12 *jrt.String; var tmp13 any; var root_1370 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1371 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1370, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1372 lang.IFn
					if linked_1371 == nil { ifn_1372 = lang.IFn_Cast(root_1370) } else { ifn_1372 = nil }; var arg_1373 any = mains__10; if linked_1371 == nil { tmp13 = ifn_1372.Invoke_O__O(arg_1373) } else { tmp13 = linked_1371.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1370, arg_1373) }; if jrt.J2g_Truth(tmp13) { var tmp14 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_86, nil); var tmp15 any; var root_1374 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1375 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1374, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1376 lang.IFn; if linked_1375 == nil { ifn_1376 = lang.IFn_Cast(root_1374) } else { ifn_1376 = nil }; var arg_1377 any = Lit_87; var arg_1378 any; var root_1379 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1380 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1379, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1381 lang.IFn; if linked_1380 == nil { ifn_1381 = lang.IFn_Cast(root_1379) } else { ifn_1381 = nil }; var arg_1382 any = A_arbace_build_go_A_const_46; var arg_1383 any = mains__10; if linked_1380 == nil { arg_1378 = ifn_1381.Invoke_O_O__O(arg_1382, arg_1383) } else { arg_1378 = linked_1380.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1379, arg_1382, arg_1383) }; if linked_1375 == nil { tmp15 = ifn_1376.Invoke_O_O__O(arg_1377, arg_1378) } else { tmp15 = linked_1375.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_1374, arg_1377, arg_1378) }; tmp12 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp14, jrt.RefArrayOf(jrt.Object_class, nil, tmp15)) } else { tmp12 = nil }
//line :356:1
					___11 = tmp9.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp10, jrt.RefArrayOf(jrt.Object_class, nil, tmp11, tmp12.Ref())).Ref()) }; var main__12 any; var root_1384 any = /*line :342:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1384, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1386 lang.IFn; if















	linked_1385 == nil { ifn_1386 = lang.IFn_Cast(root_1384) } else { ifn_1386 = nil }; var arg_1387 any = mains__10; if linked_1385 == nil { main__12 = ifn_1386.Invoke_O__O(arg_1387) } else { main__12 = linked_1385.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1384, arg_1387) }; var edn__13 any; var root_1388 any = /*line :342:1*/A_arbace_build_go_A_const_124.GetRawRoot__O(); var linked_1389 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1388, A_arbace_build_go_read_program_edn_A_fn_class); var ifn_1390 lang.IFn; if
















	linked_1389 == nil { ifn_1390 = lang.IFn_Cast(root_1388) } else { ifn_1390 = nil }; var arg_1391 any = dir__0; if linked_1389 == nil { edn__13 = ifn_1390.Invoke_O__O(arg_1391) } else { edn__13 = linked_1389.(*A_arbace_build_go_read_program_edn_A).Invoke_O_O__O(root_1388, arg_1391) }; var module__14 any; var or__1927000174__auto____14 any = /*line :342:1*/A_arbace_build_go_A_const_123.Invoke_O__O(edn__13); if

















	jrt.J2g_Truth(or__1927000174__auto____14) { module__14 = or__1927000174__auto____14 } else { var or__1927000174__auto____15 any = A_arbace_build_go_A_const_123.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____15) { module__14 = or__1927000174__auto____15 } else { var or__1927000174__auto____16 any = A_arbace_build_go_A_const_46.Invoke_O__O(main__12); if jrt.J2g_Truth(or__1927000174__auto____16) { module__14 = or__1927000174__auto____16 } else {
		module__14 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(Lit_121) } } }; var golang__15 any; var or__1927000174__auto____15_2 any = /*line :342:1*/A_arbace_build_go_A_const_125.Invoke_O__O(edn__13); if





















	jrt.J2g_Truth(or__1927000174__auto____15_2) { golang__15 = or__1927000174__auto____15_2 } else { var or__1927000174__auto____16_2 any = A_arbace_build_go_A_const_125.Invoke_O__O(opts__6); if jrt.J2g_Truth(or__1927000174__auto____16_2) { golang__15 = or__1927000174__auto____16_2 } else { if lang.Util_Equiv_O_O__Z_NoInit(module__14, Lit_98) { golang__15 = nil } else { var root_1396 any = A_arbace_build_go_A_const_126.GetRawRoot__O(); var linked_1397 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1396, A_arbace_build_go_toolchain_lang_A_fn_class); var ifn_1398 lang.IFn; if linked_1397 == nil { ifn_1398 = lang.IFn_Cast(root_1396) } else { ifn_1398 = nil }; var arg_1399 any = goroot__1; if linked_1397 == nil { golang__15 = ifn_1398.Invoke_O__O(arg_1399) } else { golang__15 = linked_1397.(*A_arbace_build_go_toolchain_lang_A).Invoke_O_O__O(root_1396, arg_1399) } } } }; var pkgs__16 any; var root_1400 any = /*line :342:1*/A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1401 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1400, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1402 lang.IFn; if






















	linked_1401 == nil { ifn_1402 = lang.IFn_Cast(root_1400) } else { ifn_1402 = nil }; var arg_1403 any; var iter__1927001039__auto____16 any; var tmp16 any = A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(module__14); var tmp17 *jrt.Class; var fncls__1526 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class; if fncls__1526 == nil { var fncls__1526d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_122, false); A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class = fncls__1526d; tmp17 = fncls__1526d } else { tmp17 = fncls__1526 }; iter__1927001039__auto____16 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); arg_1403 = lang.IFn_Cast(iter__1927001039__auto____16).Invoke_O__O(pkgs__9); if linked_1401 == nil { pkgs__16 = ifn_1402.Invoke_O__O(arg_1403) } else { pkgs__16 = linked_1401.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1400, arg_1403) }; var tmp18 any = A_arbace_build_go_A_const_123; var tmp19 any = A_arbace_build_go_A_const_125; var tmp20 any; var root_1527 any = /*line :342:1*/A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1528 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1527, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1529 lang.IFn; if
































	linked_1528 == nil { ifn_1529 = lang.IFn_Cast(root_1527) } else { ifn_1529 = nil }; var arg_1530 any = golang__15; if linked_1528 == nil { tmp20 = ifn_1529.Invoke_O__O(arg_1530) } else { tmp20 = linked_1528.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1527, arg_1530) }; var tmp21 any = tmp20; var tmp22 any = A_arbace_build_go_A_const_78; var tmp23 any = A_arbace_build_go_A_const_130; var tmp24 any; var root_1531 any = /*line :342:1*/A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1532 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1531, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1533 lang.IFn; if

































	linked_1532 == nil { ifn_1533 = lang.IFn_Cast(root_1531) } else { ifn_1533 = nil }; var arg_1534 any; var root_1535 any = A_arbace_build_go_A_const_15.GetRawRoot__O(); var linked_1536 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1535, aot_arbace_core.A_arbace_core_filter_A_fn_class); var ifn_1537 lang.IFn; if linked_1536 == nil { ifn_1537 = lang.IFn_Cast(root_1535) } else { ifn_1537 = nil }; var arg_1538 any; var tmp25 any = A_arbace_build_go_program_fn__1901000277_A_New(); var tmp26 *jrt.Class; var fncls__1544 *jrt.Class = A_arbace_build_go_program_fn__1901000277_A_fn_class; if fncls__1544 == nil { var fncls__1544d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_123, false); A_arbace_build_go_program_fn__1901000277_A_fn_class = fncls__1544d; tmp26 = fncls__1544d } else { tmp26 = fncls__1544 }; arg_1538 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp25, tmp26, nil); var arg_1539 any = pkgs__16; if linked_1536 == nil { arg_1534 = ifn_1537.Invoke_O_O__O(arg_1538, arg_1539) } else { arg_1534 = linked_1536.(*aot_arbace_core.A_arbace_core_filter_A).Invoke_O_O_O__O(root_1535, arg_1538, arg_1539) }; if linked_1532 == nil { tmp24 = ifn_1533.Invoke_O__O(arg_1534) } else { tmp24 = linked_1532.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1531, arg_1534) }; return /*line :342:1*/ lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp18, module__14, tmp19, tmp21, tmp22, pkgs__16, tmp23, tmp24)) }
//line :342:1
func (t *A_arbace_build_go_program_A) Invoke_O_O_O__O(self, dir__0, goroot__1 any) any {







	var root_1545 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_1546 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1545, A_arbace_build_go_program_A_fn_class); var ifn_1547 lang.IFn; if linked_1546 == nil { ifn_1547 = lang.IFn_Cast(root_1545) } else { ifn_1547 = nil }; var arg_1548 any = dir__0; var arg_1549 any = goroot__1; var arg_1550 any = lang.PersistentArrayMap_EMPTY.Ref(); if linked_1546 == nil { return ifn_1547.Invoke_O_O_O__O(arg_1548, arg_1549, arg_1550) } else { return linked_1546.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_1545, arg_1548, arg_1549, arg_1550)
	}
}
func A_arbace_build_go_program_fn__1901000263_A_New() *A_arbace_build_go_program_fn__1901000263_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000263_A{}; t.Ctor(); return t }
//line :353:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Ctor() {}
//line :353:1
func (t *A_arbace_build_go_program_fn__1901000263_A) Invoke_O_O__O(self, p1__1901000256_SHARP___1 any) any { var tmp1 any; var root_1351 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1352 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1351, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1353 lang.IFn; if linked_1352 == nil { ifn_1353 = lang.IFn_Cast(root_1351) } else { ifn_1353 = nil }; var arg_1354 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000256_SHARP___1); if linked_1352 == nil { tmp1 = ifn_1353.Invoke_O__O(arg_1354) } else { tmp1 = linked_1352.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1351, arg_1354) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_94, tmp1)).Ref() }
func A_arbace_build_go_program_fn__1901000265_A_New_O(p0 any) *A_arbace_build_go_program_fn__1901000265_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000265_A{}; t.Ctor_O(p0); return t }
//line :354:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Ctor_O(c__opts any) { t.F_opts = c__opts }
//line :354:1
func (t *A_arbace_build_go_program_fn__1901000265_A) Invoke_O_O__O(self, p1__1901000257_SHARP___1 any) any { return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_122.Invoke_O__O(t.F_opts), A_arbace_build_go_A_const_46.Invoke_O__O(p1__1901000257_SHARP___1))).Ref() }










func A_arbace_build_go_program_iter__1901000267__1901000271_A_New_O(p0 any) *A_arbace_build_go_program_iter__1901000267__1901000271_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_A{}; t.Ctor_O(p0); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Ctor_O(c__module any) { t.F_module = c__module }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_A) Invoke_O_O__O(self, s__1901000268__1 any) any { var tmp1 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(self, t.F_module, s__1901000268__1); var tmp2 *jrt.Class; var fncls__1525 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class; if fncls__1525 == nil { var fncls__1525d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_124, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class = fncls__1525d; tmp2 = fncls__1525d } else { tmp2 = fncls__1525 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :365:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Ctor_O_O_O(c__iter__1901000267, c__module, c__s__1901000268 any) { t.F_iter__1901000267 = c__iter__1901000267; t.F_module = c__module; t.F_s__1901000268 = c__s__1901000268 }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A) Invoke_O__O(self any) any { { var s__1901000268__1 any; var t_ any = t.F_s__1901000268; t.F_s__1901000268 = nil; s__1901000268__1 = t_; for { var temp__1927000414__auto____2 any; var root_1404 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1405 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1404, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1406 lang.IFn; if linked_1405 == nil { ifn_1406 = lang.IFn_Cast(root_1404) } else { ifn_1406 = nil }; var arg_1407 any = s__1901000268__1; if linked_1405 == nil { temp__1927000414__auto____2 = ifn_1406.Invoke_O__O(arg_1407) } else { temp__1927000414__auto____2 = linked_1405.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1404, arg_1407) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000268__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1408 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1409 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1408, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1410 lang.IFn; if linked_1409 == nil { ifn_1410 = lang.IFn_Cast(root_1408) } else { ifn_1410 = nil }; var arg_1411 any = s__1901000268__3; if linked_1409 == nil { tmp1 = ifn_1410.Invoke_O__O(arg_1411) } else { tmp1 = linked_1409.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1408, arg_1411) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1412 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1413 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1412, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1414 lang.IFn; if linked_1413 == nil { ifn_1414 = lang.IFn_Cast(root_1412) } else { ifn_1414 = nil }; var arg_1415 any = s__1901000268__3; if linked_1413 == nil { c__1927001037__auto____4 = ifn_1414.Invoke_O__O(arg_1415) } else { c__1927001037__auto____4 = linked_1413.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1412, arg_1415) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000270__6 any; var root_1416 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1416, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1418 lang.IFn; if linked_1417 == nil { ifn_1418 = lang.IFn_Cast(root_1416) } else { ifn_1418 = nil }; var arg_1419 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1417 == nil { b__1901000270__6 = ifn_1418.Invoke_O__O(arg_1419) } else { b__1901000270__6 = linked_1417.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1416, arg_1419) }; var tmp2 any = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(b__1901000270__6, size__1927001038__auto____5, t.F_module, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1457 *jrt.Class = A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class; if fncls__1457 == nil { var fncls__1457d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_125, false); A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class = fncls__1457d; tmp3 = fncls__1457d } else { tmp3 = fncls__1457 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1458 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1459 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1458, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1460 lang.IFn; if linked_1459 == nil { ifn_1460 = lang.IFn_Cast(root_1458) } else { ifn_1460 = nil }; var arg_1461 any; var root_1463 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1464 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1463, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1465 lang.IFn; if linked_1464 == nil { ifn_1465 = lang.IFn_Cast(root_1463) } else { ifn_1465 = nil }; var arg_1466 any = b__1901000270__6; if linked_1464 == nil { arg_1461 = ifn_1465.Invoke_O__O(arg_1466) } else { arg_1461 = linked_1464.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1463, arg_1466) }; var arg_1462 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp5 any; var root_1467 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1468 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1467, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1469 lang.IFn; if linked_1468 == nil { ifn_1469 = lang.IFn_Cast(root_1467) } else { ifn_1469 = nil }; var arg_1470 any = s__1901000268__3; if linked_1468 == nil { tmp5 = ifn_1469.Invoke_O__O(arg_1470) } else { tmp5 = linked_1468.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1467, arg_1470) }; arg_1462 = tmp4.Invoke_O__O(tmp5); if linked_1459 == nil { return ifn_1460.Invoke_O_O__O(arg_1461, arg_1462) } else { return linked_1459.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1458, arg_1461, arg_1462) } } else { var root_1471 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1472 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1471, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1473 lang.IFn; if linked_1472 == nil { ifn_1473 = lang.IFn_Cast(root_1471) } else { ifn_1473 = nil }; var arg_1474 any; var root_1476 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1476, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1478 lang.IFn; if linked_1477 == nil { ifn_1478 = lang.IFn_Cast(root_1476) } else { ifn_1478 = nil }; var arg_1479 any = b__1901000270__6; if linked_1477 == nil { arg_1474 = ifn_1478.Invoke_O__O(arg_1479) } else { arg_1474 = linked_1477.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1476, arg_1479) }; var arg_1475 any; if linked_1472 == nil { return ifn_1473.Invoke_O_O__O(arg_1474, arg_1475) } else { return linked_1472.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1471, arg_1474, arg_1475) } } } else { var pkg__4 any; var root_1480 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1480, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1482 lang.IFn; if linked_1481 == nil { ifn_1482 = lang.IFn_Cast(root_1480) } else { ifn_1482 = nil }; var arg_1483 any = s__1901000268__3; if linked_1481 == nil { pkg__4 = ifn_1482.Invoke_O__O(arg_1483) } else { pkg__4 = linked_1481.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1480, arg_1483) }; var root_1484 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1485 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1484, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1486 lang.IFn; if linked_1485 == nil { ifn_1486 = lang.IFn_Cast(root_1484) } else { ifn_1486 = nil }; var arg_1487 any; var path__5 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__4)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_98) {


		var root_1489 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1490 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1489, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1491 lang.IFn; if linked_1490 == nil { ifn_1491 = lang.IFn_Cast(root_1489) } else { ifn_1491 = nil }; var arg_1492 any = pkg__4; var arg_1493 any = A_arbace_build_go_A_const_127; var arg_1494 any = path__5; if linked_1490 == nil { arg_1487 = ifn_1491.Invoke_O_O_O__O(arg_1492, arg_1493, arg_1494) } else { arg_1487 = linked_1490.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1489, arg_1492, arg_1493, arg_1494) } } else {
//line :367:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__5, t.F_module) {



				var root_1495 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1496 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1495, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1497 lang.IFn; if linked_1496 == nil { ifn_1497 = lang.IFn_Cast(root_1495) } else { ifn_1497 = nil }; var arg_1498 any = pkg__4; var arg_1499 any = A_arbace_build_go_A_const_127; var arg_1500 any = Lit_96; if linked_1496 == nil { arg_1487 = ifn_1497.Invoke_O_O_O__O(arg_1498, arg_1499, arg_1500) } else { arg_1487 = linked_1496.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1495, arg_1498, arg_1499, arg_1500) } } else {
//line :367:1
					var tmp6 any; var root_1501 any = A_arbace_build_go_A_const_128.GetRawRoot__O(); var linked_1502 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1501, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1503 lang.IFn




					if linked_1502 == nil { ifn_1503 = lang.IFn_Cast(root_1501) } else { ifn_1503 = nil }; var arg_1504 any = path__5; var arg_1505 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1502 == nil { tmp6 = ifn_1503.Invoke_O_O__O(arg_1504, arg_1505) } else { tmp6 = linked_1502.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1501, arg_1504, arg_1505) }
//line :367:1
					if jrt.J2g_Truth(tmp6) {





						var root_1506 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1507 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1506, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1508 lang.IFn; if linked_1507 == nil { ifn_1508 = lang.IFn_Cast(root_1506) } else { ifn_1508 = nil }; var arg_1509 any = pkg__4; var arg_1510 any = A_arbace_build_go_A_const_127; var arg_1511 any; var root_1512 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1513 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1512, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1514 lang.IFn; if linked_1513 == nil { ifn_1514 = lang.IFn_Cast(root_1512) } else { ifn_1514 = nil }; var arg_1515 any = path__5; var arg_1516 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1513 == nil { arg_1511 = ifn_1514.Invoke_O_O__O(arg_1515, arg_1516) } else { arg_1511 = linked_1513.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1512, arg_1515, arg_1516) }; if linked_1507 == nil { arg_1487 = ifn_1508.Invoke_O_O_O__O(arg_1509, arg_1510, arg_1511) } else { arg_1487 = linked_1507.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1506, arg_1509, arg_1510, arg_1511) } } else {
//line :367:1
							if A_arbace_build_go_A_const_13 != nil {






								arg_1487 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__5, nil, t.F_module)).Ref()) } else {
//line :367:1
									arg_1487 = nil } } } }
//line :365:1
	var arg_1488 any; var tmp7 lang.IFn = lang.IFn_Cast(t.F_iter__1901000267); var tmp8 any; var root_1521 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1522 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1521, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1523 lang.IFn; if linked_1522 == nil { ifn_1523 = lang.IFn_Cast(root_1521) } else { ifn_1523 = nil }; var arg_1524 any = s__1901000268__3; if linked_1522 == nil { tmp8 = ifn_1523.Invoke_O__O(arg_1524) } else { tmp8 = linked_1522.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1521, arg_1524) }; arg_1488 = tmp7.Invoke_O__O(tmp8); if linked_1485 == nil { return ifn_1486.Invoke_O_O__O(arg_1487, arg_1488) } else { return linked_1485.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1484, arg_1487, arg_1488) } } } else { return nil } } }; panic("j2g: unreachable") }
//line :365:1
func A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_New_O_I_O_O(p0 any, p1 int32, p2, p3 any) *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A{}; t.Ctor_O_I_O_O(p0, p1, p2, p3); return t }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Ctor_O_I_O_O(c__b__1901000270 any, c__size__1927001038__auto__ int32, c__module, c__c__1927001037__auto__ any) { t.F_b__1901000270 = c__b__1901000270; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_module = c__module; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :365:1
func (t *A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A) Invoke_O__O(self any) any { { var i__1901000269__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000269__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var pkg__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000269__1)); var root_1420 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1421 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1420, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1422 lang.IFn; if linked_1421 == nil { ifn_1422 = lang.IFn_Cast(root_1420) } else { ifn_1422 = nil }; var arg_1423 any = t.F_b__1901000270; var arg_1424 any; var path__3 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__2)

	if lang.Util_Equiv_O_O__Z_NoInit(t.F_module, Lit_98) {


		var root_1425 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1426 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1425, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1427 lang.IFn; if linked_1426 == nil { ifn_1427 = lang.IFn_Cast(root_1425) } else { ifn_1427 = nil }; var arg_1428 any = pkg__2; var arg_1429 any = A_arbace_build_go_A_const_127; var arg_1430 any = path__3; if linked_1426 == nil { arg_1424 = ifn_1427.Invoke_O_O_O__O(arg_1428, arg_1429, arg_1430) } else { arg_1424 = linked_1426.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1425, arg_1428, arg_1429, arg_1430) } } else {
//line :367:1
			if lang.Util_Equiv_O_O__Z_NoInit(path__3, t.F_module) {



				var root_1431 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1431, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1433 lang.IFn; if linked_1432 == nil { ifn_1433 = lang.IFn_Cast(root_1431) } else { ifn_1433 = nil }; var arg_1434 any = pkg__2; var arg_1435 any = A_arbace_build_go_A_const_127; var arg_1436 any = Lit_96; if linked_1432 == nil { arg_1424 = ifn_1433.Invoke_O_O_O__O(arg_1434, arg_1435, arg_1436) } else { arg_1424 = linked_1432.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1431, arg_1434, arg_1435, arg_1436) } } else {
//line :367:1
					var tmp2 any; var root_1437 any = A_arbace_build_go_A_const_128.GetRawRoot__O(); var linked_1438 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1437, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_1439 lang.IFn




					if linked_1438 == nil { ifn_1439 = lang.IFn_Cast(root_1437) } else { ifn_1439 = nil }; var arg_1440 any = path__3; var arg_1441 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117), jrt.RefArrayOf(jrt.Object_class, t.F_module, nil)).Ref(); if linked_1438 == nil { tmp2 = ifn_1439.Invoke_O_O__O(arg_1440, arg_1441) } else { tmp2 = linked_1438.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_1437, arg_1440, arg_1441) }
//line :367:1
					if jrt.J2g_Truth(tmp2) {





						var root_1442 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1443 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1442, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1444 lang.IFn; if linked_1443 == nil { ifn_1444 = lang.IFn_Cast(root_1442) } else { ifn_1444 = nil }; var arg_1445 any = pkg__2; var arg_1446 any = A_arbace_build_go_A_const_127; var arg_1447 any; var root_1448 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1449 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1448, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1450 lang.IFn; if linked_1449 == nil { ifn_1450 = lang.IFn_Cast(root_1448) } else { ifn_1450 = nil }; var arg_1451 any = path__3; var arg_1452 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Inc_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(t.F_module)))).Ref(); if linked_1449 == nil { arg_1447 = ifn_1450.Invoke_O_O__O(arg_1451, arg_1452) } else { arg_1447 = linked_1449.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O__O(root_1448, arg_1451, arg_1452) }; if linked_1443 == nil { arg_1424 = ifn_1444.Invoke_O_O_O__O(arg_1445, arg_1446, arg_1447) } else { arg_1424 = linked_1443.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1442, arg_1445, arg_1446, arg_1447) } } else {
//line :367:1
							if A_arbace_build_go_A_const_13 != nil {






								arg_1424 = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()).Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_126, nil, Lit_127, nil), jrt.RefArrayOf(jrt.Object_class, nil, path__3, nil, t.F_module)).Ref()) } else {
//line :367:1
									arg_1424 = nil } } } }
//line :365:1
	if linked_1421 == nil { ifn_1422.Invoke_O_O__O(arg_1423, arg_1424) } else { linked_1421.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1420, arg_1423, arg_1424) }; i__1901000269__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000269__1); continue L1 } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }










func A_arbace_build_go_program_fn__1901000277_A_New() *A_arbace_build_go_program_fn__1901000277_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_program_fn__1901000277_A{}; t.Ctor(); return t }
//line :376:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Ctor() {}
//line :376:1
func (t *A_arbace_build_go_program_fn__1901000277_A) Invoke_O_O__O(self, p1__1901000258_SHARP___1 any) any { var tmp1 any; var root_1540 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1541 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1540, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1542 lang.IFn; if linked_1541 == nil { ifn_1542 = lang.IFn_Cast(root_1540) } else { ifn_1542 = nil }; var arg_1543 any = A_arbace_build_go_A_const_36.Invoke_O__O(p1__1901000258_SHARP___1); if linked_1541 == nil { tmp1 = ifn_1542.Invoke_O__O(arg_1543) } else { tmp1 = linked_1541.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1540, arg_1543) }; return jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.Util_Equiv_O_O__Z_NoInit(Lit_94, tmp1)).Ref() }




func A_arbace_build_go_sha256_A_New() *A_arbace_build_go_sha256_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_A{}; t.Ctor(); return t }
//line :381:1
func (t *A_arbace_build_go_sha256_A) Ctor() {}
//line :381:1
func (t *A_arbace_build_go_sha256_A) Invoke_O_O__O(self, f__0 any) any { var md__2 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51); var root_1551 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1552 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1551, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1553 lang.IFn; if

	linked_1552 == nil { ifn_1553 = lang.IFn_Cast(root_1551) } else { ifn_1553 = nil }; var arg_1554 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1555 any; var root_1556 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1557 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1556, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1558 lang.IFn; if linked_1557 == nil { ifn_1558 = lang.IFn_Cast(root_1556) } else { ifn_1558 = nil }; var arg_1559 any; var tmp1 any = A_arbace_build_go_sha256_fn__1901000281_A_New(); var tmp2 *jrt.Class; var fncls__1571 *jrt.Class = A_arbace_build_go_sha256_fn__1901000281_A_fn_class; if fncls__1571 == nil { var fncls__1571d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_168, false); A_arbace_build_go_sha256_fn__1901000281_A_fn_class = fncls__1571d; tmp2 = fncls__1571d } else { tmp2 = fncls__1571 }; arg_1559 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1560 any = jrt.MessageDigest_Cast(md__2).Digest_B1__B1(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__0)).ToPath__Path())).Ref(); if linked_1557 == nil { arg_1555 = ifn_1558.Invoke_O_O__O(arg_1559, arg_1560) } else { arg_1555 = linked_1557.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1556, arg_1559, arg_1560) }; if linked_1552 == nil { return ifn_1553.Invoke_O_O__O(arg_1554, arg_1555) } else { return linked_1552.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1551, arg_1554, arg_1555) } }
//line :383:1
func A_arbace_build_go_sha256_fn__1901000281_A_New() *A_arbace_build_go_sha256_fn__1901000281_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_sha256_fn__1901000281_A{}; t.Ctor(); return t }
//line :383:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Ctor() {}
//line :383:1
func (t *A_arbace_build_go_sha256_fn__1901000281_A) Invoke_O_O__O(self, p1__1901000280_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_1566 any = p1__1901000280_SHARP___1; var na_1567 int64 = 255; if jrt.Long_InstanceOf(na_1566) { var n0_1568 int64 = jrt.NN(jrt.Long_Cast(na_1566)).LongValue__J(); var n1_1569 int64 = na_1567; tmp2 = n0_1568 & n1_1569 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1566, na_1567) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_copy_file_A_New() *A_arbace_build_go_copy_file_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_copy_file_A{}; t.Ctor(); return t }
//line :385:1
func (t *A_arbace_build_go_copy_file_A) Ctor() {}
//line :385:1
func (t *A_arbace_build_go_copy_file_A) Invoke_O_O_O__O(self, from__0, to__1 any) any {
	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(to__1)).GetParentFile__File()).Mkdirs__Z())
	var tmp1 jrt.Path = jrt.NN(jrt.File_Cast(from__0)).ToPath__Path(); var tmp2 jrt.Path = jrt.NN(jrt.File_Cast(to__1)).ToPath__Path(); var tmp3 any; var root_1572 any = A_arbace_build_go_A_const_132.GetRawRoot__O(); var linked_1573 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1572, aot_arbace_core.A_arbace_core_into_array_A_fn_class); var ifn_1574 lang.IFn
	if linked_1573 == nil { ifn_1574 = lang.IFn_Cast(root_1572) } else { ifn_1574 = nil }; var arg_1575 any = A_arbace_build_go_A_const_133; var arg_1576 any; var tmp4 *jrt.StandardCopyOption; jrt.StandardCopyOption_Init(); tmp4 = jrt.StandardCopyOption_REPLACE_EXISTING; arg_1576 = lang.Tuple_Create_O__IPersistentVector(tmp4.Ref()); if linked_1573 == nil { tmp3 = ifn_1574.Invoke_O_O__O(arg_1575, arg_1576) } else { tmp3 = linked_1573.(*aot_arbace_core.A_arbace_core_into_array_A).Invoke_O_O_O__O(root_1572, arg_1575, arg_1576) }
//line :387:1
	return jrt.Files_Copy_Path_Path_CopyOption1__Path(tmp1, tmp2, jrt.RefArray_Cast(tmp3, jrt.CopyOption_class))
}

func A_arbace_build_go_forms_dir_A_New() *A_arbace_build_go_forms_dir_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_forms_dir_A{}; t.Ctor(); return t }
//line :390:1
func (t *A_arbace_build_go_forms_dir_A) Ctor() {}
//line :390:1
func (t *A_arbace_build_go_forms_dir_A) Invoke_O_O__O(self, pkg__0 any) any { var f__2 any = A_arbace_build_go_A_const_50.Invoke_O__O(pkg__0); var n__3 any = jrt.NN(jrt.File_Cast(f__2)).GetName__String().Ref(); var tmp1 *jrt.File = jrt.NN(jrt.File_Cast(f__2)).GetParentFile__File(); var tmp2 any; var root_1577 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1578 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1577, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1579 lang.IFn; if





	linked_1578 == nil { ifn_1579 = lang.IFn_Cast(root_1577) } else { ifn_1579 = nil }; var arg_1580 any = n__3; var arg_1581 any = A_arbace_build_go_A_const_134; var arg_1582 any = jrt.Long_ValueOf_J__Long_NoInit(lang.Numbers_Minus_J_J__J_NoInit(int64(lang.RT_Count_O__I_NoInit(n__3)), 3)).Ref(); if linked_1578 == nil { tmp2 = ifn_1579.Invoke_O_O_O__O(arg_1580, arg_1581, arg_1582) } else { tmp2 = linked_1578.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1577, arg_1580, arg_1581, arg_1582) }; return /*line :390:1*/ jrt.File_New_File_String(tmp1, jrt.String_Cast(tmp2)) }







func A_arbace_build_go_with_line_files_A_New() *A_arbace_build_go_with_line_files_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_A{}; t.Ctor(); return t }
//line :398:1
func (t *A_arbace_build_go_with_line_files_A) Ctor() {}
//line :398:1
func (t *A_arbace_build_go_with_line_files_A) Invoke_O_O__O(self, pkg__0 any) any { var fdir__2 any; var root_1583 any = A_arbace_build_go_A_const_135.GetRawRoot__O(); var linked_1584 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1583, A_arbace_build_go_forms_dir_A_fn_class); var ifn_1585 lang.IFn; if





	linked_1584 == nil { ifn_1585 = lang.IFn_Cast(root_1583) } else { ifn_1585 = nil }; var arg_1586 any = pkg__0; if linked_1584 == nil { fdir__2 = ifn_1585.Invoke_O__O(arg_1586) } else { fdir__2 = linked_1584.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_1583, arg_1586) }; var root_1587 any =
	A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_1588 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1587, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1589 lang.IFn; if linked_1588 == nil { ifn_1589 = lang.IFn_Cast(root_1587) } else { ifn_1589 = nil }; var arg_1590 any = pkg__0; var arg_1591 any = A_arbace_build_go_A_const_136; var arg_1592 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(fdir__2); var tmp2 *jrt.Class; var fncls__1615 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class; if fncls__1615 == nil { var fncls__1615d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_179, false); A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class = fncls__1615d; tmp2 = fncls__1615d } else { tmp2 = fncls__1615 }; arg_1592 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1588 == nil { return ifn_1589.Invoke_O_O_O__O(arg_1590, arg_1591, arg_1592) } else { return linked_1588.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1587, arg_1590, arg_1591, arg_1592) } }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_A) Invoke_O_O__O(self, fs__1 any) any { var root_1593 any = A_arbace_build_go_A_const_94.GetRawRoot__O(); var linked_1594 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1593, aot_arbace_core.A_arbace_core_mapv_A_fn_class); var ifn_1595 lang.IFn; if linked_1594 == nil { ifn_1595 = lang.IFn_Cast(root_1593) } else { ifn_1595 = nil }; var arg_1596 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(t.F_fdir); var tmp2 *jrt.Class; var fncls__1614 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class; if fncls__1614 == nil { var fncls__1614d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_180, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class = fncls__1614d; tmp2 = fncls__1614d } else { tmp2 = fncls__1614 }; arg_1596 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1597 any = fs__1; if linked_1594 == nil { return ifn_1595.Invoke_O_O__O(arg_1596, arg_1597) } else { return linked_1594.(*aot_arbace_core.A_arbace_core_mapv_A).Invoke_O_O_O__O(root_1593, arg_1596, arg_1597) } }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A) Invoke_O_O__O(self, p1__1901000286_SHARP___1 any) any { var root_1598 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_1599 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1598, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1600 lang.IFn; if linked_1599 == nil { ifn_1600 = lang.IFn_Cast(root_1598) } else { ifn_1600 = nil }; var arg_1601 any = p1__1901000286_SHARP___1; var arg_1602 any = A_arbace_build_go_A_const_137; var arg_1603 any; var tmp1 any = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(t.F_fdir); var tmp2 *jrt.Class; var fncls__1613 *jrt.Class = A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class; if fncls__1613 == nil { var fncls__1613d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_181, false); A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class = fncls__1613d; tmp2 = fncls__1613d } else { tmp2 = fncls__1613 }; arg_1603 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1599 == nil { return ifn_1600.Invoke_O_O_O__O(arg_1601, arg_1602, arg_1603) } else { return linked_1599.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1598, arg_1601, arg_1602, arg_1603) } }
//line :405:1
func A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_New_O(p0 any) *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A{}; t.Ctor_O(p0); return t }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Ctor_O(c__fdir any) { t.F_fdir = c__fdir }
//line :405:1
func (t *A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A) Invoke_O_O__O(self, s__1 any) any { var root_1604 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1605 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1604, A_arbace_build_go_rel_path_A_fn_class); var ifn_1606 lang.IFn; if linked_1605 == nil { ifn_1606 = lang.IFn_Cast(root_1604) } else { ifn_1606 = nil }; var arg_1607 any = t.F_fdir; var arg_1608 any; var tmp1 any; var root_1609 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1610 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1609, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1611 lang.IFn; if linked_1610 == nil { ifn_1611 = lang.IFn_Cast(root_1609) } else { ifn_1611 = nil }; var arg_1612 any = s__1; if linked_1610 == nil { tmp1 = ifn_1611.Invoke_O__O(arg_1612) } else { tmp1 = linked_1610.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1609, arg_1612) }; arg_1608 = jrt.File_New_String(jrt.String_Cast(tmp1)); if linked_1605 == nil { return ifn_1606.Invoke_O_O__O(arg_1607, arg_1608) } else { return linked_1605.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1604, arg_1607, arg_1608) } }



func A_arbace_build_go_print_cache_key_A_New() *A_arbace_build_go_print_cache_key_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_A{}; t.Ctor(); return t }
//line :409:1
func (t *A_arbace_build_go_print_cache_key_A) Ctor() {}
//line :409:1
func (t *A_arbace_build_go_print_cache_key_A) Invoke_O_O_O_O_O_O__O(self, host_id__0, pkg__1, dir__2, opts__3, tests__4 any) any { var md__6 any = jrt.MessageDigest_GetInstance_String__MessageDigest(Lit_51); var add__7 any; var tmp1 any = A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(md__6); var tmp2 *jrt.Class; var fncls__1616 *jrt.Class = A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class; if





	fncls__1616 == nil { var fncls__1616d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_95, false); A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class = fncls__1616d; tmp2 = fncls__1616d } else { tmp2 = fncls__1616 }; add__7 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil);
	lang.IFn_Cast(add__7).Invoke_O__O(host_id__0); var tmp3 lang.IFn =
	lang.IFn_Cast(add__7); var tmp4 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()); var tmp5 any = A_arbace_build_go_A_const_138.Invoke_O__O(opts__3); var tmp6 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(A_arbace_build_go_A_const_139.Invoke_O__O(opts__3))).Ref(); var tmp7 any = jrt.Boolean_ValueOf_Z__Boolean_NoInit(lang.RT_BooleanCast_O__Z_NoInit(tests__4)).Ref(); var tmp8 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp9 any; var root_1662 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1663 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1662, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1664 lang.IFn; if linked_1663 == nil { ifn_1664 = lang.IFn_Cast(root_1662) } else { ifn_1664 = nil }; var arg_1665 any = A_arbace_build_go_A_const_36.Invoke_O__O(pkg__1); if linked_1663 == nil { tmp9 = ifn_1664.Invoke_O__O(arg_1665) } else { tmp9 = linked_1663.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1662, arg_1665) }; tmp3.Invoke_O__O(tmp4.Invoke_O__O(lang.Tuple_Create_O_O_O_O_O__IPersistentVector(tmp5, tmp6, tmp7, tmp8, tmp9))); var seq_1901000297__8 any; var root_1638 any = /*line :409:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1638, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1640 lang.IFn; if








	linked_1639 == nil { ifn_1640 = lang.IFn_Cast(root_1638) } else { ifn_1640 = nil }; var arg_1641 any = A_arbace_build_go_A_const_64.Invoke_O__O(pkg__1); if linked_1639 == nil { seq_1901000297__8 = ifn_1640.Invoke_O__O(arg_1641) } else { seq_1901000297__8 = linked_1639.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1638, arg_1641) }; var chunk_1901000298__9 any; var count_1901000299__10 int64 = 0; var i_1901000300__11 int64 = 0; L1:
//line :409:1
	for {








		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000300__11, count_1901000299__10) { var f__12 any = lang.Indexed_Cast(chunk_1901000298__9).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000300__11)); var tmp10 lang.IFn = lang.IFn_Cast(add__7); var tmp11 any; var root_1666 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1666, A_arbace_build_go_rel_path_A_fn_class); var ifn_1668 lang.IFn
			if linked_1667 == nil { ifn_1668 = lang.IFn_Cast(root_1666) } else { ifn_1668 = nil }; var arg_1669 any = dir__2; var arg_1670 any = f__12; if linked_1667 == nil { tmp11 = ifn_1668.Invoke_O_O__O(arg_1669, arg_1670) } else { tmp11 = linked_1667.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1666, arg_1669, arg_1670) }; tmp10.Invoke_O__O(tmp11)
			jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__12)).ToPath__Path()))
			lang.IFn_Cast(add__7).Invoke_O__O(Lit_96)
//line :418:1
			seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000300__11); continue L1 } else { var temp__1927000414__auto____12 any; var root_1642 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1642, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1644 lang.IFn; if linked_1643 == nil { ifn_1644 = lang.IFn_Cast(root_1642) } else { ifn_1644 = nil }; var arg_1645 any = seq_1901000297__8; if linked_1643 == nil { temp__1927000414__auto____12 = ifn_1644.Invoke_O__O(arg_1645) } else { temp__1927000414__auto____12 = linked_1643.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1642, arg_1645) }; if jrt.J2g_Truth(temp__1927000414__auto____12) { var seq_1901000297__13 any = temp__1927000414__auto____12; var tmp12 any; var root_1646 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1647 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1646, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1648 lang.IFn; if linked_1647 == nil { ifn_1648 = lang.IFn_Cast(root_1646) } else { ifn_1648 = nil }; var arg_1649 any = seq_1901000297__13; if linked_1647 == nil { tmp12 = ifn_1648.Invoke_O__O(arg_1649) } else { tmp12 = linked_1647.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1646, arg_1649) }; if jrt.J2g_Truth(tmp12) { var c__1927000678__auto____14 any; var root_1650 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1651 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1650, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1652 lang.IFn; if linked_1651 == nil { ifn_1652 = lang.IFn_Cast(root_1650) } else { ifn_1652 = nil }; var arg_1653 any = seq_1901000297__13; if linked_1651 == nil { c__1927000678__auto____14 = ifn_1652.Invoke_O__O(arg_1653) } else { c__1927000678__auto____14 = linked_1651.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1650, arg_1653) }; var tmp13 any; var root_1671 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1672 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1671, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1673 lang.IFn; if linked_1672 == nil { ifn_1673 = lang.IFn_Cast(root_1671) } else { ifn_1673 = nil }; var arg_1674 any = seq_1901000297__13; if linked_1672 == nil { tmp13 = ifn_1673.Invoke_O__O(arg_1674) } else { tmp13 = linked_1672.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1671, arg_1674) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp13, c__1927000678__auto____14, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____14))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var f__14 any; var root_1654 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1655 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1654, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1656 lang.IFn; if linked_1655 == nil { ifn_1656 = lang.IFn_Cast(root_1654) } else { ifn_1656 = nil }; var arg_1657 any = seq_1901000297__13; if linked_1655 == nil { f__14 = ifn_1656.Invoke_O__O(arg_1657) } else { f__14 = linked_1655.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1654, arg_1657) }
				var tmp14 lang.IFn = lang.IFn_Cast(add__7); var tmp15 any; var root_1675 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_1676 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1675, A_arbace_build_go_rel_path_A_fn_class); var ifn_1677 lang.IFn; if linked_1676 == nil { ifn_1677 = lang.IFn_Cast(root_1675) } else { ifn_1677 = nil }; var arg_1678 any = dir__2; var arg_1679 any = f__14; if linked_1676 == nil { tmp15 = ifn_1677.Invoke_O_O__O(arg_1678, arg_1679) } else { tmp15 = linked_1676.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_1675, arg_1678, arg_1679) }; tmp14.Invoke_O__O(tmp15)
				jrt.MessageDigest_Cast(md__6).Update_B1__V(jrt.Files_ReadAllBytes_Path__B1(jrt.NN(jrt.File_Cast(f__14)).ToPath__Path()))
				lang.IFn_Cast(add__7).Invoke_O__O(Lit_96)
//line :418:1
				var tmp16 any; var root_1680 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1680, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1682 lang.IFn; if linked_1681 == nil { ifn_1682 = lang.IFn_Cast(root_1680) } else { ifn_1682 = nil }; var arg_1683 any = seq_1901000297__13; if linked_1681 == nil { tmp16 = ifn_1682.Invoke_O__O(arg_1683) } else { tmp16 = linked_1681.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1680, arg_1683) }; seq_1901000297__8, chunk_1901000298__9, count_1901000299__10, i_1901000300__11 = tmp16, nil, 0, 0; continue L1 } } }
//line :409:1
		break L1 }; var root_1617 any =












	A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1618 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1617, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1619 lang.IFn; if linked_1618 == nil { ifn_1619 = lang.IFn_Cast(root_1617) } else { ifn_1619 = nil }; var arg_1620 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1621 any; var root_1622 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1623 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1622, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1624 lang.IFn; if linked_1623 == nil { ifn_1624 = lang.IFn_Cast(root_1622) } else { ifn_1624 = nil }; var arg_1625 any; var tmp17 any = A_arbace_build_go_print_cache_key_fn__1901000301_A_New(); var tmp18 *jrt.Class; var fncls__1637 *jrt.Class = A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class; if fncls__1637 == nil { var fncls__1637d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_97, false); A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class = fncls__1637d; tmp18 = fncls__1637d } else { tmp18 = fncls__1637 }; arg_1625 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil); var arg_1626 any = jrt.MessageDigest_Cast(md__6).Digest__B1().Ref(); if linked_1623 == nil { arg_1621 = ifn_1624.Invoke_O_O__O(arg_1625, arg_1626) } else { arg_1621 = linked_1623.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1622, arg_1625, arg_1626) }; if linked_1618 == nil { return ifn_1619.Invoke_O_O__O(arg_1620, arg_1621) } else { return linked_1618.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1617, arg_1620, arg_1621) } }
//line :415:1
func A_arbace_build_go_print_cache_key_add__1901000295_A_New_O(p0 any) *A_arbace_build_go_print_cache_key_add__1901000295_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_add__1901000295_A{}; t.Ctor_O(p0); return t }
//line :415:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Ctor_O(c__md any) { t.F_md = c__md }
//line :415:1
func (t *A_arbace_build_go_print_cache_key_add__1901000295_A) Invoke_O_O__O(self, x__1 any) any { var tmp1 jrt.MessageDigest_I = jrt.MessageDigest_Cast(t.F_md); tmp1.Update_B1__V(jrt.NN(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, x__1, nil))).GetBytes_String__B1(Lit_52)); return nil }






func A_arbace_build_go_print_cache_key_fn__1901000301_A_New() *A_arbace_build_go_print_cache_key_fn__1901000301_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_cache_key_fn__1901000301_A{}; t.Ctor(); return t }
//line :422:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Ctor() {}
//line :422:1
func (t *A_arbace_build_go_print_cache_key_fn__1901000301_A) Invoke_O_O__O(self, p1__1901000294_SHARP___1 any) any { var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_57.GetRawRoot__O()); var tmp2 int64; var na_1632 any = p1__1901000294_SHARP___1; var na_1633 int64 = 255; if jrt.Long_InstanceOf(na_1632) { var n0_1634 int64 = jrt.NN(jrt.Long_Cast(na_1632)).LongValue__J(); var n1_1635 int64 = na_1633; tmp2 = n0_1634 & n1_1635 } else { tmp2 = lang.Numbers_And_O_J__J_NoInit(na_1632, na_1633) }; return tmp1.Invoke_O_O__O(Lit_79, jrt.Long_ValueOf_J__Long_NoInit(tmp2).Ref()) }

func A_arbace_build_go_cached_texts_A_New() *A_arbace_build_go_cached_texts_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_A{}; t.Ctor(); return t }
//line :424:1
func (t *A_arbace_build_go_cached_texts_A) Ctor() {}
//line :424:1
func (t *A_arbace_build_go_cached_texts_A) Invoke_O_O__O(self, entry__0 any) any { var names__2 any = jrt.File_New_File_String(jrt.File_Cast(entry__0), Lit_42); if





	jrt.NN(jrt.File_Cast(names__2)).IsFile__Z() {
		jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(entry__0)).SetLastModified_J__Z(jrt.System_CurrentTimeMillis__J()))
		var root_1684 any = A_arbace_build_go_A_const_79.GetRawRoot__O(); var linked_1685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1684, aot_arbace_core.A_arbace_core_into_A_fn_class); var ifn_1686 lang.IFn; if linked_1685 == nil { ifn_1686 = lang.IFn_Cast(root_1684) } else { ifn_1686 = nil }; var arg_1687 any = lang.IFn_Cast(A_arbace_build_go_A_const_80.GetRawRoot__O()).Invoke__O(); var arg_1688 any; var iter__1927001039__auto____3 any; var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(entry__0); var tmp2 *jrt.Class; var fncls__1762 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class
		if fncls__1762 == nil { var fncls__1762d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_45, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class = fncls__1762d; tmp2 = fncls__1762d } else { tmp2 = fncls__1762 }; iter__1927001039__auto____3 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var tmp3 lang.IFn = lang.IFn_Cast(iter__1927001039__auto____3); var tmp4 any; var root_1763 any = A_arbace_build_go_A_const_140.GetRawRoot__O(); var linked_1764 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1763, aot_arbace_string.A_arbace_string_split_lines_A_fn_class); var ifn_1765 lang.IFn; if linked_1764 == nil { ifn_1765 = lang.IFn_Cast(root_1763) } else { ifn_1765 = nil }; var arg_1766 any = lang.IFn_Cast(A_arbace_build_go_A_const_104.GetRawRoot__O()).Invoke_O__O(names__2); if linked_1764 == nil { tmp4 = ifn_1765.Invoke_O__O(arg_1766) } else { tmp4 = linked_1764.(*aot_arbace_string.A_arbace_string_split_lines_A).Invoke_O_O__O(root_1763, arg_1766) }; arg_1688 = tmp3.Invoke_O__O(tmp4)
//line :432:1
		if linked_1685 == nil { return ifn_1686.Invoke_O_O__O(arg_1687, arg_1688) } else { return linked_1685.(*aot_arbace_core.A_arbace_core_into_A).Invoke_O_O_O__O(root_1684, arg_1687, arg_1688) } } else {
//line :430:1
			return nil } }


func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_New_O(p0 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A{}; t.Ctor_O(p0); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Ctor_O(c__entry any) { t.F_entry = c__entry }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A) Invoke_O_O__O(self, s__1901000305__1 any) any { var tmp1 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(s__1901000305__1, self, t.F_entry); var tmp2 *jrt.Class; var fncls__1761 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class; if fncls__1761 == nil { var fncls__1761d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_46, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class = fncls__1761d; tmp2 = fncls__1761d } else { tmp2 = fncls__1761 }; return lang.LazySeq_New_IFn(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)) }
//line :433:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Ctor_O_O_O(c__s__1901000305, c__iter__1901000304, c__entry any) { t.F_s__1901000305 = c__s__1901000305; t.F_iter__1901000304 = c__iter__1901000304; t.F_entry = c__entry }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A) Invoke_O__O(self any) any { { var s__1901000305__1 any; var t_ any = t.F_s__1901000305; t.F_s__1901000305 = nil; s__1901000305__1 = t_; L1: for { var temp__1927000414__auto____2 any; var root_1692 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1693 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1692, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1694 lang.IFn; if linked_1693 == nil { ifn_1694 = lang.IFn_Cast(root_1692) } else { ifn_1694 = nil }; var arg_1695 any = s__1901000305__1; if linked_1693 == nil { temp__1927000414__auto____2 = ifn_1694.Invoke_O__O(arg_1695) } else { temp__1927000414__auto____2 = linked_1693.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1692, arg_1695) }; if jrt.J2g_Truth(temp__1927000414__auto____2) { var s__1901000305__3 any = temp__1927000414__auto____2; var tmp1 any; var root_1696 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1697 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1696, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1698 lang.IFn; if linked_1697 == nil { ifn_1698 = lang.IFn_Cast(root_1696) } else { ifn_1698 = nil }; var arg_1699 any = s__1901000305__3; if linked_1697 == nil { tmp1 = ifn_1698.Invoke_O__O(arg_1699) } else { tmp1 = linked_1697.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1696, arg_1699) }; if jrt.J2g_Truth(tmp1) { var c__1927001037__auto____4 any; var root_1700 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1701 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1700, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1702 lang.IFn; if linked_1701 == nil { ifn_1702 = lang.IFn_Cast(root_1700) } else { ifn_1702 = nil }; var arg_1703 any = s__1901000305__3; if linked_1701 == nil { c__1927001037__auto____4 = ifn_1702.Invoke_O__O(arg_1703) } else { c__1927001037__auto____4 = linked_1701.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1700, arg_1703) }; var size__1927001038__auto____5 int32 = lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927001037__auto____4)); var b__1901000307__6 any; var root_1704 any = A_arbace_build_go_A_const_34.GetRawRoot__O(); var linked_1705 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1704, aot_arbace_core.A_arbace_core_chunk_buffer_A_fn_class); var ifn_1706 lang.IFn; if linked_1705 == nil { ifn_1706 = lang.IFn_Cast(root_1704) } else { ifn_1706 = nil }; var arg_1707 any = jrt.Integer_ValueOf_I__Integer_NoInit(size__1927001038__auto____5).Ref(); if linked_1705 == nil { b__1901000307__6 = ifn_1706.Invoke_O__O(arg_1707) } else { b__1901000307__6 = linked_1705.(*aot_arbace_core.A_arbace_core_chunk_buffer_A).Invoke_O_O__O(root_1704, arg_1707) }; var tmp2 any = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(b__1901000307__6, t.F_entry, size__1927001038__auto____5, c__1927001037__auto____4); var tmp3 *jrt.Class; var fncls__1717 *jrt.Class = A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class; if fncls__1717 == nil { var fncls__1717d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_47, false); A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class = fncls__1717d; tmp3 = fncls__1717d } else { tmp3 = fncls__1717 }; if jrt.J2g_Truth(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil).Invoke__O()) { var root_1718 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1719 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1718, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1720 lang.IFn; if linked_1719 == nil { ifn_1720 = lang.IFn_Cast(root_1718) } else { ifn_1720 = nil }; var arg_1721 any; var root_1723 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1724 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1723, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1725 lang.IFn; if linked_1724 == nil { ifn_1725 = lang.IFn_Cast(root_1723) } else { ifn_1725 = nil }; var arg_1726 any = b__1901000307__6; if linked_1724 == nil { arg_1721 = ifn_1725.Invoke_O__O(arg_1726) } else { arg_1721 = linked_1724.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1723, arg_1726) }; var arg_1722 any; var tmp4 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp5 any; var root_1727 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1728 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1727, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1729 lang.IFn; if linked_1728 == nil { ifn_1729 = lang.IFn_Cast(root_1727) } else { ifn_1729 = nil }; var arg_1730 any = s__1901000305__3; if linked_1728 == nil { tmp5 = ifn_1729.Invoke_O__O(arg_1730) } else { tmp5 = linked_1728.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1727, arg_1730) }; arg_1722 = tmp4.Invoke_O__O(tmp5); if linked_1719 == nil { return ifn_1720.Invoke_O_O__O(arg_1721, arg_1722) } else { return linked_1719.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1718, arg_1721, arg_1722) } } else { var root_1731 any = A_arbace_build_go_A_const_38.GetRawRoot__O(); var linked_1732 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1731, aot_arbace_core.A_arbace_core_chunk_cons_A_fn_class); var ifn_1733 lang.IFn; if linked_1732 == nil { ifn_1733 = lang.IFn_Cast(root_1731) } else { ifn_1733 = nil }; var arg_1734 any; var root_1736 any = A_arbace_build_go_A_const_39.GetRawRoot__O(); var linked_1737 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1736, aot_arbace_core.A_arbace_core_chunk_A_fn_class); var ifn_1738 lang.IFn; if linked_1737 == nil { ifn_1738 = lang.IFn_Cast(root_1736) } else { ifn_1738 = nil }; var arg_1739 any = b__1901000307__6; if linked_1737 == nil { arg_1734 = ifn_1738.Invoke_O__O(arg_1739) } else { arg_1734 = linked_1737.(*aot_arbace_core.A_arbace_core_chunk_A).Invoke_O_O__O(root_1736, arg_1739) }; var arg_1735 any; if linked_1732 == nil { return ifn_1733.Invoke_O_O__O(arg_1734, arg_1735) } else { return linked_1732.(*aot_arbace_core.A_arbace_core_chunk_cons_A).Invoke_O_O_O__O(root_1731, arg_1734, arg_1735) } } } else { var n__4 any; var root_1740 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1741 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1740, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1742 lang.IFn; if linked_1741 == nil { ifn_1742 = lang.IFn_Cast(root_1740) } else { ifn_1742 = nil }; var arg_1743 any = s__1901000305__3; if linked_1741 == nil { n__4 = ifn_1742.Invoke_O__O(arg_1743) } else { n__4 = linked_1741.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1740, arg_1743) }; var tmp6 any; var root_1744 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1745 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1744, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1746 lang.IFn; if linked_1745 == nil { ifn_1746 = lang.IFn_Cast(root_1744) } else { ifn_1746 = nil }; var arg_1747 any = n__4; if linked_1745 == nil { tmp6 = ifn_1746.Invoke_O__O(arg_1747) } else { tmp6 = linked_1745.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1744, arg_1747) }; if jrt.J2g_Truth(tmp6) { var root_1748 any = A_arbace_build_go_A_const_41.GetRawRoot__O(); var linked_1749 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1748, aot_arbace_core.A_arbace_core_cons__1927000000_A_fn_class); var ifn_1750 lang.IFn; if linked_1749 == nil { ifn_1750 = lang.IFn_Cast(root_1748) } else { ifn_1750 = nil }; var tmp7 *jrt.File = jrt.File_Cast(t.F_entry); var arg_1751 any = lang.Tuple_Create_O_O__IPersistentVector(n__4, jrt.File_New_File_String(tmp7, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__4)))); var arg_1752 any; var tmp8 lang.IFn = lang.IFn_Cast(t.F_iter__1901000304); var tmp9 any; var root_1753 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1754 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1753, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1755 lang.IFn; if linked_1754 == nil { ifn_1755 = lang.IFn_Cast(root_1753) } else { ifn_1755 = nil }; var arg_1756 any = s__1901000305__3; if linked_1754 == nil { tmp9 = ifn_1755.Invoke_O__O(arg_1756) } else { tmp9 = linked_1754.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1753, arg_1756) }; arg_1752 = tmp8.Invoke_O__O(tmp9); if linked_1749 == nil { return ifn_1750.Invoke_O_O__O(arg_1751, arg_1752) } else { return linked_1749.(*aot_arbace_core.A_arbace_core_cons__1927000000_A).Invoke_O_O_O__O(root_1748, arg_1751, arg_1752) } } else { var tmp10 any; var root_1757 any = A_arbace_build_go_A_const_42.GetRawRoot__O(); var linked_1758 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1757, aot_arbace_core.A_arbace_core_rest__1927000012_A_fn_class); var ifn_1759 lang.IFn; if linked_1758 == nil { ifn_1759 = lang.IFn_Cast(root_1757) } else { ifn_1759 = nil }; var arg_1760 any = s__1901000305__3; if linked_1758 == nil { tmp10 = ifn_1759.Invoke_O__O(arg_1760) } else { tmp10 = linked_1758.(*aot_arbace_core.A_arbace_core_rest__1927000012_A).Invoke_O_O__O(root_1757, arg_1760) }; s__1901000305__1 = tmp10; continue L1 } } } else { return nil } } }; panic("j2g: unreachable") }
//line :433:1
func A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_New_O_O_I_O(p0, p1 any, p2 int32, p3 any) *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A{}; t.Ctor_O_O_I_O(p0, p1, p2, p3); return t }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Ctor_O_O_I_O(c__b__1901000307, c__entry any, c__size__1927001038__auto__ int32, c__c__1927001037__auto__ any) { t.F_b__1901000307 = c__b__1901000307; t.F_entry = c__entry; t.F_size__1927001038__auto__ = c__size__1927001038__auto__; t.F_c__1927001037__auto__ = c__c__1927001037__auto__ }
//line :433:1
func (t *A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A) Invoke_O__O(self any) any { { var i__1901000306__1 int64 = lang.RT_LongCast_I__J_NoInit(lang.RT_IntCast_J__I_NoInit(0)); L1: for { if lang.Numbers_Lt_J_J__Z_NoInit(i__1901000306__1, int64(t.F_size__1927001038__auto__)) { var tmp1 lang.Indexed = lang.Indexed_Cast(t.F_c__1927001037__auto__); var n__2 any = tmp1.Nth_I__O(lang.RT_IntCast_J__I_NoInit(i__1901000306__1)); var tmp2 any; var root_1708 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1709 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1708, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1710 lang.IFn; if linked_1709 == nil { ifn_1710 = lang.IFn_Cast(root_1708) } else { ifn_1710 = nil }; var arg_1711 any = n__2; if linked_1709 == nil { tmp2 = ifn_1710.Invoke_O__O(arg_1711) } else { tmp2 = linked_1709.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1708, arg_1711) }; if jrt.J2g_Truth(tmp2) { var root_1712 any = A_arbace_build_go_A_const_37.GetRawRoot__O(); var linked_1713 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1712, aot_arbace_core.A_arbace_core_chunk_append_A_fn_class); var ifn_1714 lang.IFn; if linked_1713 == nil { ifn_1714 = lang.IFn_Cast(root_1712) } else { ifn_1714 = nil }; var arg_1715 any = t.F_b__1901000307; var tmp3 *jrt.File = jrt.File_Cast(t.F_entry); var arg_1716 any = lang.Tuple_Create_O_O__IPersistentVector(n__2, jrt.File_New_File_String(tmp3, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__2)))); if linked_1713 == nil { ifn_1714.Invoke_O_O__O(arg_1715, arg_1716) } else { linked_1713.(*aot_arbace_core.A_arbace_core_chunk_append_A).Invoke_O_O_O__O(root_1712, arg_1715, arg_1716) }; i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } else { i__1901000306__1 = lang.Numbers_Unchecked_inc_J__J_NoInit(i__1901000306__1); continue L1 } } else { return jrt.Boolean_TRUE.Ref() } } }; panic("j2g: unreachable") }


func A_arbace_build_go_cache_texts_BANG__A_New() *A_arbace_build_go_cache_texts_BANG__A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__A{}; t.Ctor(); return t }
//line :436:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Ctor() {}
//line :436:1
func (t *A_arbace_build_go_cache_texts_BANG__A) Invoke_O_O_O__O(self, entry__0, texts__1 any) any { var tmp__3 any = jrt.File_New_File_String(jrt.NN(jrt.File_Cast(entry__0)).GetParentFile__File(), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_40, nil), jrt.RefArrayOf(jrt.Object_class, jrt.NN(jrt.File_Cast(entry__0)).GetName__String().Ref(), nil, jrt.Long_ValueOf_J__Long_NoInit(jrt.System_NanoTime__J()).Ref())));



	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(tmp__3)).Mkdirs__Z()); var seq_1901000316__4 any; var root_1775 any = /*line :436:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1776 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1775, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1777 lang.IFn; if




	linked_1776 == nil { ifn_1777 = lang.IFn_Cast(root_1775) } else { ifn_1777 = nil }; var arg_1778 any = texts__1; if linked_1776 == nil { seq_1901000316__4 = ifn_1777.Invoke_O__O(arg_1778) } else { seq_1901000316__4 = linked_1776.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1775, arg_1778) }; var chunk_1901000317__5 any; var count_1901000318__6 int64 = 0; var i_1901000319__7 int64 = 0; L1:
//line :436:1
	for {




		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000319__7, count_1901000318__6) { var vec__1901000320__8 any = lang.Indexed_Cast(chunk_1901000317__5).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000319__7)); var n__9 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(0), nil); var text__10 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000320__8, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__9))), text__10); seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000319__7); continue L1 } else { var temp__1927000414__auto____8 any; var root_1779 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1780 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1779, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1781 lang.IFn; if linked_1780 == nil { ifn_1781 = lang.IFn_Cast(root_1779) } else { ifn_1781 = nil }; var arg_1782 any = seq_1901000316__4; if linked_1780 == nil { temp__1927000414__auto____8 = ifn_1781.Invoke_O__O(arg_1782) } else { temp__1927000414__auto____8 = linked_1780.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1779, arg_1782) }; if jrt.J2g_Truth(temp__1927000414__auto____8) { var seq_1901000316__9 any = temp__1927000414__auto____8; var tmp1 any; var root_1783 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_1784 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1783, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_1785 lang.IFn; if linked_1784 == nil { ifn_1785 = lang.IFn_Cast(root_1783) } else { ifn_1785 = nil }; var arg_1786 any = seq_1901000316__9; if linked_1784 == nil { tmp1 = ifn_1785.Invoke_O__O(arg_1786) } else { tmp1 = linked_1784.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_1783, arg_1786) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____10 any; var root_1787 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_1788 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1787, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_1789 lang.IFn; if linked_1788 == nil { ifn_1789 = lang.IFn_Cast(root_1787) } else { ifn_1789 = nil }; var arg_1790 any = seq_1901000316__9; if linked_1788 == nil { c__1927000678__auto____10 = ifn_1789.Invoke_O__O(arg_1790) } else { c__1927000678__auto____10 = linked_1788.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_1787, arg_1790) }; var tmp2 any; var root_1819 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_1820 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1819, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_1821 lang.IFn; if linked_1820 == nil { ifn_1821 = lang.IFn_Cast(root_1819) } else { ifn_1821 = nil }; var arg_1822 any = seq_1901000316__9; if linked_1820 == nil { tmp2 = ifn_1821.Invoke_O__O(arg_1822) } else { tmp2 = linked_1820.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_1819, arg_1822) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp2, c__1927000678__auto____10, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____10))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000323__10 any; var root_1791 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1792 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1791, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1793 lang.IFn; if linked_1792 == nil { ifn_1793 = lang.IFn_Cast(root_1791) } else { ifn_1793 = nil }; var arg_1794 any = seq_1901000316__9; if linked_1792 == nil { vec__1901000323__10 = ifn_1793.Invoke_O__O(arg_1794) } else { vec__1901000323__10 = linked_1792.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1791, arg_1794) }; var n__11 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(0), nil); var text__12 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000323__10, lang.RT_IntCast_J__I_NoInit(1), nil); lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(tmp__3), lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_41, nil), jrt.RefArrayOf(jrt.Object_class, nil, n__11))), text__12); var tmp3 any; var root_1828 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1829 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1828, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1830 lang.IFn; if linked_1829 == nil { ifn_1830 = lang.IFn_Cast(root_1828) } else { ifn_1830 = nil }; var arg_1831 any = seq_1901000316__9; if linked_1829 == nil { tmp3 = ifn_1830.Invoke_O__O(arg_1831) } else { tmp3 = linked_1829.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1828, arg_1831) }; seq_1901000316__4, chunk_1901000317__5, count_1901000318__6, i_1901000319__7 = tmp3, nil, 0, 0; continue L1 } } }
//line :436:1
		break L1 }; var tmp4 lang.IFn =





	lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp5 any = jrt.File_New_File_String(jrt.File_Cast(tmp__3), Lit_42); var tmp6 any; var root_1800 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_1801 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1800, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_1802 lang.IFn; if linked_1801 == nil { ifn_1802 = lang.IFn_Cast(root_1800) } else { ifn_1802 = nil }; var arg_1803 any; var root_1804 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1805 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1804, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1806 lang.IFn; if linked_1805 == nil { ifn_1806 = lang.IFn_Cast(root_1804) } else { ifn_1806 = nil }; var arg_1807 any; var tmp7 any = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New(); var tmp8 *jrt.Class; var fncls__1809 *jrt.Class = A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class; if fncls__1809 == nil { var fncls__1809d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_43, false); A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class = fncls__1809d; tmp8 = fncls__1809d } else { tmp8 = fncls__1809 }; arg_1807 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp7, tmp8, nil); var arg_1808 any; var root_1810 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1811 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1810, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1812 lang.IFn; if linked_1811 == nil { ifn_1812 = lang.IFn_Cast(root_1810) } else { ifn_1812 = nil }; var arg_1813 any = texts__1; if linked_1811 == nil { arg_1808 = ifn_1812.Invoke_O__O(arg_1813) } else { arg_1808 = linked_1811.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1810, arg_1813) }; if linked_1805 == nil { arg_1803 = ifn_1806.Invoke_O_O__O(arg_1807, arg_1808) } else { arg_1803 = linked_1805.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1804, arg_1807, arg_1808) }; if linked_1801 == nil { tmp6 = ifn_1802.Invoke_O__O(arg_1803) } else { tmp6 = linked_1801.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O__O(root_1800, arg_1803) }; tmp4.Invoke_O_O__O(tmp5, tmp6); if
	jrt.NN(jrt.File_Cast(tmp__3)).RenameTo_File__Z(jrt.File_Cast(entry__0)) { return nil } else { var root_1771 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_1772 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1771, A_arbace_build_go_delete_tree_A_fn_class); var ifn_1773 lang.IFn; if linked_1772 == nil { ifn_1773 = lang.IFn_Cast(root_1771) } else { ifn_1773 = nil }; var arg_1774 any = tmp__3; if linked_1772 == nil { return ifn_1773.Invoke_O__O(arg_1774) } else { return linked_1772.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_1771, arg_1774) } } }
//line :442:1
func A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_New() *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_cache_texts_BANG__fn__1901000326_A{}; t.Ctor(); return t }
//line :442:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Ctor() {}
//line :442:1
func (t *A_arbace_build_go_cache_texts_BANG__fn__1901000326_A) Invoke_O_O__O(self, p1__1901000315_SHARP___1 any) any { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_44), jrt.RefArrayOf(jrt.Object_class, p1__1901000315_SHARP___1, nil)).Ref() }


func A_arbace_build_go_print_module_A_New() *A_arbace_build_go_print_module_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_A{}; t.Ctor(); return t }
//line :445:1
func (t *A_arbace_build_go_print_module_A) Ctor() {}
//line :445:1
func (t *A_arbace_build_go_print_module_A) Invoke_O_O_O_O_O__O(self, p__1901000331__0, dir__1, out__2, p__1901000332__3 any) any { var map__1901000333__5 any = p__1901000331__0; var map__1901000333__6 any; if lang.ISeq_InstanceOf(map__1901000333__5) { var tmp1 any; var root_1832 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1833 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1832, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1834 lang.IFn; if linked_1833 == nil { ifn_1834 = lang.IFn_Cast(root_1832) } else { ifn_1834 = nil }; var arg_1835 any = map__1901000333__5; if linked_1833 == nil { tmp1 = ifn_1834.Invoke_O__O(arg_1835) } else { tmp1 = linked_1833.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1832, arg_1835) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_1836 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1837 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1836, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1838 lang.IFn; if linked_1837 == nil { ifn_1838 = lang.IFn_Cast(root_1836) } else { ifn_1838 = nil }; var arg_1839 any = map__1901000333__5; if linked_1837 == nil { tmp2 = ifn_1838.Invoke_O__O(arg_1839) } else { tmp2 = linked_1837.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1836, arg_1839) }; map__1901000333__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_1840 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1841 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1840, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1842 lang.IFn; if linked_1841 == nil { ifn_1842 = lang.IFn_Cast(root_1840) } else { ifn_1842 = nil }; var arg_1843 any = map__1901000333__5; if linked_1841 == nil { tmp3 = ifn_1842.Invoke_O__O(arg_1843) } else { tmp3 = linked_1841.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1840, arg_1843) }; if jrt.J2g_Truth(tmp3) { var root_1844 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1845 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1844, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1846 lang.IFn; if linked_1845 == nil { ifn_1846 = lang.IFn_Cast(root_1844) } else { ifn_1846 = nil }; var arg_1847 any = map__1901000333__5; if linked_1845 == nil { map__1901000333__6 = ifn_1846.Invoke_O__O(arg_1847) } else { map__1901000333__6 = linked_1845.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1844, arg_1847) } } else { map__1901000333__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000333__6 = map__1901000333__5 }; var module__7 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_123); var packages__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_78); var golang__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000333__6, A_arbace_build_go_A_const_125); var map__1901000335__10 any = p__1901000332__3; var map__1901000335__11 any; if lang.ISeq_InstanceOf(map__1901000335__10) { var tmp4 any; var root_1848 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_1849 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1848, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_1850 lang.IFn; if linked_1849 == nil { ifn_1850 = lang.IFn_Cast(root_1848) } else { ifn_1850 = nil }; var arg_1851 any = map__1901000335__10; if linked_1849 == nil { tmp4 = ifn_1850.Invoke_O__O(arg_1851) } else { tmp4 = linked_1849.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_1848, arg_1851) }; if jrt.J2g_Truth(tmp4) { var tmp5 any; var root_1852 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_1853 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1852, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_1854 lang.IFn; if linked_1853 == nil { ifn_1854 = lang.IFn_Cast(root_1852) } else { ifn_1854 = nil }; var arg_1855 any = map__1901000335__10; if linked_1853 == nil { tmp5 = ifn_1854.Invoke_O__O(arg_1855) } else { tmp5 = linked_1853.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_1852, arg_1855) }; map__1901000335__11 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp5)).Ref() } else { var tmp6 any; var root_1856 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1857 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1856, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1858 lang.IFn; if linked_1857 == nil { ifn_1858 = lang.IFn_Cast(root_1856) } else { ifn_1858 = nil }; var arg_1859 any = map__1901000335__10; if linked_1857 == nil { tmp6 = ifn_1858.Invoke_O__O(arg_1859) } else { tmp6 = linked_1857.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1856, arg_1859) }; if jrt.J2g_Truth(tmp6) { var root_1860 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_1861 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1860, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_1862 lang.IFn; if linked_1861 == nil { ifn_1862 = lang.IFn_Cast(root_1860) } else { ifn_1862 = nil }; var arg_1863 any = map__1901000335__10; if linked_1861 == nil { map__1901000335__11 = ifn_1862.Invoke_O__O(arg_1863) } else { map__1901000335__11 = linked_1861.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_1860, arg_1863) } } else { map__1901000335__11 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000335__11 = map__1901000335__10 }; var layout__12 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_138); var line_file__13 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_139); var tests__14 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_143); var goos__15 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_144); var goroot__16 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_145); var goos_dir__17 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_146); var print_cache__18 any = lang.RT_Get_O_O__O_NoInit(map__1901000335__11, A_arbace_build_go_A_const_121);









	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(out__2)).Mkdirs__Z()); if
	lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_98) { } else {
		var tmp7 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp8 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_99); var tmp9 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_100, nil, Lit_101, nil, Lit_44, nil); var tmp10 *jrt.String
		if lang.Util_Equiv_O_O__Z_NoInit(goos__15, Lit_28) {
			var tmp11 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_102, nil, Lit_103, nil, Lit_44, nil); var tmp12 *lang.Keyword = A_arbace_build_go_A_const_46; var tmp13 any = tmp12.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp14 *lang.Keyword = A_arbace_build_go_A_const_112; var tmp15 any = tmp14.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp16 *jrt.String

			if jrt.J2g_Truth(goos_dir__17) {
				var tmp17 *jrt.RefArray = jrt.ConstRefArray("[0,7,s81:\n// from its Go forms printed (bin/tamago-vendor), not Go's module cache\nreplace ns1: ns4: => ns1:\n", []*jrt.Class{jrt.String_class}); var tmp18 *lang.Keyword = A_arbace_build_go_A_const_46; var tmp19 any = tmp18.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp20 *lang.Keyword = A_arbace_build_go_A_const_112; var tmp21 any = tmp20.Invoke_O__O(A_arbace_build_go_A_const_105.GetRawRoot__O()); var tmp22 any; var root_2268 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2269 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2268, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2270 lang.IFn

				if linked_2269 == nil { ifn_2270 = lang.IFn_Cast(root_2268) } else { ifn_2270 = nil }; var arg_2271 any = goos_dir__17; if linked_2269 == nil { tmp22 = ifn_2270.Invoke_O__O(arg_2271) } else { tmp22 = linked_2269.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2268, arg_2271) }
//line :462:1
				tmp16 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp17, jrt.RefArrayOf(jrt.Object_class, nil, tmp19, nil, tmp21, nil, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp22)).GetAbsoluteFile__File()).GetPath__String().Ref(), nil)) } else {
//line :461:1
					tmp16 = nil }
//line :459:1
			tmp10 = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp11, jrt.RefArrayOf(jrt.Object_class, nil, tmp13, nil, tmp15, nil, tmp16.Ref())) } else {
//line :458:1
				tmp10 = nil }
//line :457:1
		tmp7.Invoke_O_O__O(tmp8, lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp9, jrt.RefArrayOf(jrt.Object_class, nil, module__7, nil, golang__9, nil, tmp10.Ref())).Ref()) }; var tmp23 any; var and__1927000168__auto____19 bool =







	lang.Util_Equiv_O_O__Z_NoInit(goos__15, Lit_28); if and__1927000168__auto____19 { var root_2272 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2273 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2272, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2274 lang.IFn; if linked_2273 == nil { ifn_2274 = lang.IFn_Cast(root_2272) } else { ifn_2274 = nil }; var arg_2275 any = goos_dir__17; if linked_2273 == nil { tmp23 = ifn_2274.Invoke_O__O(arg_2275) } else { tmp23 = linked_2273.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2272, arg_2275) } } else { tmp23 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____19).Ref() }; if jrt.J2g_Truth(tmp23) {
		var tmp24 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()); var tmp25 any = jrt.File_New_File_String(jrt.File_Cast(out__2), Lit_104); var tmp26 any; var root_2281 any = A_arbace_build_go_A_const_163.GetRawRoot__O(); var linked_2282 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2281, A_arbace_build_go_tamago_go_sum_A_fn_class); var ifn_2283 lang.IFn; if linked_2282 == nil { ifn_2283 = lang.IFn_Cast(root_2281) } else { ifn_2283 = nil }; var arg_2284 any = goroot__16; if linked_2282 == nil { tmp26 = ifn_2283.Invoke_O__O(arg_2284) } else { tmp26 = linked_2282.(*A_arbace_build_go_tamago_go_sum_A).Invoke_O_O__O(root_2281, arg_2284) }; tmp24.Invoke_O_O__O(tmp25, tmp26) }; var root_1864 any =
	A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_1865 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1864, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_1866 lang.IFn; if linked_1865 == nil { ifn_1866 = lang.IFn_Cast(root_1864) } else { ifn_1866 = nil }; var arg_1867 any; var root_1868 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1869 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1868, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1870 lang.IFn; if
	linked_1869 == nil { ifn_1870 = lang.IFn_Cast(root_1868) } else { ifn_1870 = nil }; var arg_1871 any; if lang.Util_Equiv_O_O__Z_NoInit(module__7, Lit_98) { arg_1871 = nil } else { arg_1871 = A_arbace_build_go_A_const_147 }; var arg_1872 any; var root_1873 any = A_arbace_build_go_A_const_56.GetRawRoot__O(); var linked_1874 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1873, aot_arbace_core.A_arbace_core_apply_A_fn_class); var ifn_1875 lang.IFn; if
	linked_1874 == nil { ifn_1875 = lang.IFn_Cast(root_1873) } else { ifn_1875 = nil }; var arg_1876 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var arg_1877 any; var root_1878 any = A_arbace_build_go_A_const_54.GetRawRoot__O(); var linked_1879 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1878, aot_arbace_core.A_arbace_core_pmap_A_fn_class); var ifn_1880 lang.IFn; if linked_1879 == nil { ifn_1880 = lang.IFn_Cast(root_1878) } else { ifn_1880 = nil }; var arg_1881 any; var tmp27 any = A_arbace_build_go_print_module_fn__1901000337_A_New_O_O_O_O_O_O(dir__1, out__2, tests__14, line_file__13, layout__12, print_cache__18); var tmp28 *jrt.Class; var fncls__2262 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_A_fn_class; if
	fncls__2262 == nil { var fncls__2262d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_105, false); A_arbace_build_go_print_module_fn__1901000337_A_fn_class = fncls__2262d; tmp28 = fncls__2262d } else { tmp28 = fncls__2262 }; arg_1881 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp27, tmp28, nil); var arg_1882 any = packages__8; if /*line :469:1*/ linked_1879 == nil { arg_1877 = ifn_1880.Invoke_O_O__O(arg_1881, arg_1882) } else { arg_1877 = linked_1879.(*aot_arbace_core.A_arbace_core_pmap_A).Invoke_O_O_O__O(root_1878, arg_1881, arg_1882) }; if linked_1874 == nil { arg_1872 = ifn_1875.Invoke_O_O__O(arg_1876, arg_1877) } else { arg_1872 = linked_1874.(*aot_arbace_core.A_arbace_core_apply_A).Invoke_O_O_O__O(root_1873, arg_1876, arg_1877) }; if /*line :468:1*/ linked_1869 == nil { arg_1867 = ifn_1870.Invoke_O_O__O(arg_1871, arg_1872) } else { arg_1867 = linked_1869.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1868, arg_1871, arg_1872) }; if /*line :467:1*/ linked_1865 == nil { return ifn_1866.Invoke_O__O(arg_1867) } else { return linked_1865.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_1864, arg_1867) } }


func A_arbace_build_go_print_module_fn__1901000337_A_New_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5 any) *A_arbace_build_go_print_module_fn__1901000337_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_A{}; t.Ctor_O_O_O_O_O_O(p0, p1, p2, p3, p4, p5); return t }
//line :470:1
func (t *A_arbace_build_go_print_module_fn__1901000337_A) Ctor_O_O_O_O_O_O(c__dir, c__out, c__tests, c__line_file, c__layout, c__print_cache any) { t.F_dir = c__dir; t.F_out = c__out; t.F_tests = c__tests; t.F_line_file = c__line_file; t.F_layout = c__layout; t.F_print_cache = c__print_cache }
//line :470:1
func (t *A_arbace_build_go_print_module_fn__1901000337_A) Invoke_O_O__O(self, pkg__1 any) any { var pdir__2 any; if
												lang.Util_Equiv_O_O__Z_NoInit(Lit_96, A_arbace_build_go_A_const_127.Invoke_O__O(pkg__1)) { pdir__2 = t.F_out } else { var tmp1 *jrt.File = jrt.File_Cast(t.F_out); pdir__2 = jrt.File_New_File_String(tmp1, jrt.String_Cast(A_arbace_build_go_A_const_127.Invoke_O__O(pkg__1))) }; var opts__3 any; var G__1901000338__3_ any; var tmp2 any = A_arbace_build_go_A_const_138; var tmp3 any; var or__1927000174__auto____3 any = /*line :470:1*/t.F_layout; if

	jrt.J2g_Truth(or__1927000174__auto____3) { tmp3 = or__1927000174__auto____3 } else { if jrt.J2g_Truth(t.F_line_file) { tmp3 = A_arbace_build_go_A_const_148 } else { tmp3 = A_arbace_build_go_A_const_149 } }; G__1901000338__3_ = /*line :470:1*/lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3)); if

	jrt.J2g_Truth(t.F_line_file) {
		var root_1883 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_1884 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1883, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_1885 lang.IFn; if linked_1884 == nil { ifn_1885 = lang.IFn_Cast(root_1883) } else { ifn_1885 = nil }; var arg_1886 any = G__1901000338__3_; var arg_1887 any = A_arbace_build_go_A_const_139; var arg_1888 any = jrt.Boolean_TRUE.Ref(); if linked_1884 == nil { opts__3 = ifn_1885.Invoke_O_O_O__O(arg_1886, arg_1887, arg_1888) } else { opts__3 = linked_1884.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_1883, arg_1886, arg_1887, arg_1888) } } else {
//line :472:1
			opts__3 = G__1901000338__3_ }; var test_files__4 any; var root_1889 any = /*line :470:1*/A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_1890 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1889, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_1891 lang.IFn; if



	linked_1890 == nil { ifn_1891 = lang.IFn_Cast(root_1889) } else { ifn_1891 = nil }; var arg_1892 any; var root_1893 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1894 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1893, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1895 lang.IFn; if linked_1894 == nil { ifn_1895 = lang.IFn_Cast(root_1893) } else { ifn_1895 = nil }; var arg_1896 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_150; var arg_1897 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_1894 == nil { arg_1892 = ifn_1895.Invoke_O_O__O(arg_1896, arg_1897) } else { arg_1892 = linked_1894.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1893, arg_1896, arg_1897) }; if linked_1890 == nil { test_files__4 = ifn_1891.Invoke_O__O(arg_1892) } else { test_files__4 = linked_1890.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_1889, arg_1892) }; var printable__5 any; var tmp5 any = /*line :470:1*/A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_New_O_O(test_files__4, t.F_tests); var tmp6 *jrt.Class; var fncls__1919 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class; if
	fncls__1919 == nil { var fncls__1919d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_106, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class = fncls__1919d; tmp6 = fncls__1919d } else { tmp6 = fncls__1919 }; printable__5 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp5, tmp6, nil); var host_id__6 any = /*line :470:1*/jrt.System_Getenv_String__String(Lit_107).Ref(); var entry__7 any; var tmp7 any; var and__1927000168__auto____7 any = t.F_print_cache; if








	jrt.J2g_Truth(and__1927000168__auto____7) { var root_1920 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_1921 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1920, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_1922 lang.IFn; if linked_1921 == nil { ifn_1922 = lang.IFn_Cast(root_1920) } else { ifn_1922 = nil }; var arg_1923 any = host_id__6; if linked_1921 == nil { tmp7 = ifn_1922.Invoke_O__O(arg_1923) } else { tmp7 = linked_1921.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_1920, arg_1923) } } else { tmp7 = and__1927000168__auto____7 }; if jrt.J2g_Truth(tmp7) { var k__7 any; var root_1924 any = A_arbace_build_go_A_const_152.GetRawRoot__O(); var linked_1925 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1924, A_arbace_build_go_print_cache_key_A_fn_class); var ifn_1926 lang.IFn
		if linked_1925 == nil { ifn_1926 = lang.IFn_Cast(root_1924) } else { ifn_1926 = nil }; var arg_1927 any = host_id__6; var arg_1928 any = pkg__1; var arg_1929 any = t.F_dir; var arg_1930 any = opts__3; var arg_1931 any = t.F_tests; if linked_1925 == nil { k__7 = ifn_1926.Invoke_O_O_O_O_O__O(arg_1927, arg_1928, arg_1929, arg_1930, arg_1931) } else { k__7 = linked_1925.(*A_arbace_build_go_print_cache_key_A).Invoke_O_O_O_O_O_O__O(root_1924, arg_1927, arg_1928, arg_1929, arg_1930, arg_1931) }
//line :479:1
		var tmp8 *jrt.Class = A_arbace_build_go_A_const_67; var tmp9 any; var root_1932 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1933 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1932, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1934 lang.IFn

		if linked_1933 == nil { ifn_1934 = lang.IFn_Cast(root_1932) } else { ifn_1934 = nil }; var arg_1935 any = t.F_print_cache; if linked_1933 == nil { tmp9 = ifn_1934.Invoke_O__O(arg_1935) } else { tmp9 = linked_1933.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1932, arg_1935) }
//line :479:1
		var tmp10 *jrt.String = jrt.String_Cast(tmp9); var tmp11 any; var root_1936 any = A_arbace_build_go_A_const_129.GetRawRoot__O(); var linked_1937 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1936, aot_arbace_core.A_arbace_core_subs_A_fn_class); var ifn_1938 lang.IFn

		if linked_1937 == nil { ifn_1938 = lang.IFn_Cast(root_1936) } else { ifn_1938 = nil }; var arg_1939 any = k__7; var arg_1940 any = A_arbace_build_go_A_const_134; var arg_1941 any = A_arbace_build_go_A_const_153; if linked_1937 == nil { tmp11 = ifn_1938.Invoke_O_O_O__O(arg_1939, arg_1940, arg_1941) } else { tmp11 = linked_1937.(*aot_arbace_core.A_arbace_core_subs_A).Invoke_O_O_O_O__O(root_1936, arg_1939, arg_1940, arg_1941) }
//line :479:1
		entry__7 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp8, jrt.RefArrayOf(jrt.Object_class, jrt.File_New_String_String(tmp10, jrt.String_Cast(tmp11)), k__7)) } else { entry__7 = nil }; var texts__8 any; var or__1927000174__auto____8 any; if


	jrt.J2g_Truth(entry__7) { var root_1942 any = A_arbace_build_go_A_const_154.GetRawRoot__O(); var linked_1943 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1942, A_arbace_build_go_cached_texts_A_fn_class); var ifn_1944 lang.IFn; if linked_1943 == nil { ifn_1944 = lang.IFn_Cast(root_1942) } else { ifn_1944 = nil }; var arg_1945 any = entry__7; if linked_1943 == nil { or__1927000174__auto____8 = ifn_1944.Invoke_O__O(arg_1945) } else { or__1927000174__auto____8 = linked_1943.(*A_arbace_build_go_cached_texts_A).Invoke_O_O__O(root_1942, arg_1945) } } else { or__1927000174__auto____8 = nil }; if jrt.J2g_Truth(or__1927000174__auto____8) { texts__8 = or__1927000174__auto____8 } else { var t__9 any; var root_1946 any = A_arbace_build_go_A_const_155.GetRawRoot__O(); var linked_1947 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1946, aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A_fn_class); var ifn_1948 lang.IFn
		if linked_1947 == nil { ifn_1948 = lang.IFn_Cast(root_1946) } else { ifn_1948 = nil }; var arg_1949 any; var G__1901000345__9_ any; var tmp12 lang.IFn = lang.IFn_Cast(printable__5); var tmp13 any; var root_1955 any = A_arbace_build_go_A_const_157.GetRawRoot__O(); var linked_1956 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1955, A_arbace_build_go_collected_package_A_fn_class); var ifn_1957 lang.IFn; if linked_1956 == nil { ifn_1957 = lang.IFn_Cast(root_1955) } else { ifn_1957 = nil }; var arg_1958 any = pkg__1; if linked_1956 == nil { tmp13 = ifn_1957.Invoke_O__O(arg_1958) } else { tmp13 = linked_1956.(*A_arbace_build_go_collected_package_A).Invoke_O_O__O(root_1955, arg_1958) }; G__1901000345__9_ = tmp12.Invoke_O__O(tmp13); if jrt.J2g_Truth(t.F_line_file) { var root_1951 any = A_arbace_build_go_A_const_156.GetRawRoot__O(); var linked_1952 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1951, A_arbace_build_go_with_line_files_A_fn_class); var ifn_1953 lang.IFn; if linked_1952 == nil { ifn_1953 = lang.IFn_Cast(root_1951) } else { ifn_1953 = nil }; var arg_1954 any = G__1901000345__9_; if linked_1952 == nil { arg_1949 = ifn_1953.Invoke_O__O(arg_1954) } else { arg_1949 = linked_1952.(*A_arbace_build_go_with_line_files_A).Invoke_O_O__O(root_1951, arg_1954) } } else { arg_1949 = G__1901000345__9_ }; var arg_1950 any = opts__3; if linked_1947 == nil { t__9 = ifn_1948.Invoke_O_O__O(arg_1949, arg_1950) } else { t__9 = linked_1947.(*aot_arbace_repr_go_print.A_arbace_repr_go_print_print_forms_A).Invoke_O_O_O__O(root_1946, arg_1949, arg_1950) }
		if jrt.J2g_Truth(entry__7) {
			jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.NN(jrt.File_Cast(entry__7)).GetParentFile__File()).Mkdirs__Z())
			var root_1999 any = A_arbace_build_go_A_const_160.GetRawRoot__O(); var linked_2000 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1999, A_arbace_build_go_cache_texts_BANG__A_fn_class); var ifn_2001 lang.IFn; if linked_2000 == nil { ifn_2001 = lang.IFn_Cast(root_1999) } else { ifn_2001 = nil }; var arg_2002 any = entry__7; var arg_2003 any = t__9; if linked_2000 == nil { ifn_2001.Invoke_O_O__O(arg_2002, arg_2003) } else { linked_2000.(*A_arbace_build_go_cache_texts_BANG__A).Invoke_O_O_O__O(root_1999, arg_2002, arg_2003) } }
//line :482:1
		texts__8 = t__9 }; var declared__9 any; var tmp14 /*line :470:1*/*lang.Keyword = A_arbace_build_go_A_const_136; var temp__1927000414__auto____9 any = tmp14.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if

















	jrt.J2g_Truth(temp__1927000414__auto____9) { var fs__10 any = temp__1927000414__auto____9; var root_1959 any = A_arbace_build_go_A_const_43.GetRawRoot__O(); var linked_1960 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1959, aot_arbace_core.A_arbace_core_concat_A_fn_class); var ifn_1961 lang.IFn
		if linked_1960 == nil { ifn_1961 = lang.IFn_Cast(root_1959) } else { ifn_1961 = nil }; var arg_1962 any = fs__10; var arg_1963 any; if jrt.J2g_Truth(t.F_tests) { var tmp15 *lang.Keyword = A_arbace_build_go_A_const_150; arg_1963 = tmp15.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)) } else { arg_1963 = nil }; if linked_1960 == nil { declared__9 = ifn_1961.Invoke_O_O__O(arg_1962, arg_1963) } else { declared__9 = linked_1960.(*aot_arbace_core.A_arbace_core_concat_A).Invoke_O_O_O__O(root_1959, arg_1962, arg_1963) } } else {
//line :488:1
			declared__9 = nil }; var rel__10 any; var tmp16 any = /*line :470:1*/A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_New_O(pkg__1); var tmp17 *jrt.Class; var fncls__1964 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class; if
	fncls__1964 == nil { var fncls__1964d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_108, false); A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class = fncls__1964d; tmp17 = fncls__1964d } else { tmp17 = fncls__1964 }; rel__10 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp16, tmp17, nil); var src__11 any; var root_1965 any = /*line :470:1*/A_arbace_build_go_A_const_135.GetRawRoot__O(); var linked_1966 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1965, A_arbace_build_go_forms_dir_A_fn_class); var ifn_1967 lang.IFn; if




















	linked_1966 == nil { ifn_1967 = lang.IFn_Cast(root_1965) } else { ifn_1967 = nil }; var arg_1968 any = pkg__1; if linked_1966 == nil { src__11 = ifn_1967.Invoke_O__O(arg_1968) } else { src__11 = linked_1966.(*A_arbace_build_go_forms_dir_A).Invoke_O_O__O(root_1965, arg_1968) }; var tmp18 any; var and__1927000168__auto____12 any = declared__9; if
	jrt.J2g_Truth(and__1927000168__auto____12) { var root_2004 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2005 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2004, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2006 lang.IFn; if linked_2005 == nil { ifn_2006 = lang.IFn_Cast(root_2004) } else { ifn_2006 = nil }; var arg_2007 any; var root_2009 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_2010 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2009, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2011 lang.IFn; if linked_2010 == nil { ifn_2011 = lang.IFn_Cast(root_2009) } else { ifn_2011 = nil }; var arg_2012 any; var root_2013 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_2014 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2013, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_2015 lang.IFn; if linked_2014 == nil { ifn_2015 = lang.IFn_Cast(root_2013) } else { ifn_2015 = nil }; var arg_2016 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_2017 any = declared__9; if linked_2014 == nil { arg_2012 = ifn_2015.Invoke_O_O__O(arg_2016, arg_2017) } else { arg_2012 = linked_2014.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_2013, arg_2016, arg_2017) }; if linked_2010 == nil { arg_2007 = ifn_2011.Invoke_O__O(arg_2012) } else { arg_2007 = linked_2010.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2009, arg_2012) }; var arg_2008 any; var root_2018 any = A_arbace_build_go_A_const_90.GetRawRoot__O(); var linked_2019 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2018, aot_arbace_core.A_arbace_core_set_A_fn_class); var ifn_2020 lang.IFn; if linked_2019 == nil { ifn_2020 = lang.IFn_Cast(root_2018) } else { ifn_2020 = nil }; var arg_2021 any; var root_2022 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_2023 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2022, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2024 lang.IFn; if linked_2023 == nil { ifn_2024 = lang.IFn_Cast(root_2022) } else { ifn_2024 = nil }; var arg_2025 any = texts__8; if linked_2023 == nil { arg_2021 = ifn_2024.Invoke_O__O(arg_2025) } else { arg_2021 = linked_2023.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2022, arg_2025) }; if linked_2019 == nil { arg_2008 = ifn_2020.Invoke_O__O(arg_2021) } else { arg_2008 = linked_2019.(*aot_arbace_core.A_arbace_core_set_A).Invoke_O_O__O(root_2018, arg_2021) }; if linked_2005 == nil { tmp18 = ifn_2006.Invoke_O_O__O(arg_2007, arg_2008) } else { tmp18 = linked_2005.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2004, arg_2007, arg_2008) } } else { tmp18 = and__1927000168__auto____12 }; if jrt.J2g_Truth(tmp18) {
		var tmp19 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp20 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_109, nil, Lit_110, nil); var tmp21 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp22 any = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()).Invoke_O__O(declared__9); var tmp23 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_69.GetRawRoot__O()); var tmp24 any; var root_2038 any = A_arbace_build_go_A_const_44.GetRawRoot__O(); var linked_2039 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2038, aot_arbace_core.A_arbace_core_vec_A_fn_class); var ifn_2040 lang.IFn
		if linked_2039 == nil { ifn_2040 = lang.IFn_Cast(root_2038) } else { ifn_2040 = nil }; var arg_2041 any; var root_2042 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_2043 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2042, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_2044 lang.IFn; if linked_2043 == nil { ifn_2044 = lang.IFn_Cast(root_2042) } else { ifn_2044 = nil }; var arg_2045 any = texts__8; if linked_2043 == nil { arg_2041 = ifn_2044.Invoke_O__O(arg_2045) } else { arg_2041 = linked_2043.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_2042, arg_2045) }; if linked_2039 == nil { tmp24 = ifn_2040.Invoke_O__O(arg_2041) } else { tmp24 = linked_2039.(*aot_arbace_core.A_arbace_core_vec_A).Invoke_O_O__O(root_2038, arg_2041) }
//line :493:1
		tmp19.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp20, jrt.RefArrayOf(jrt.Object_class, tmp21, nil, tmp22, nil, tmp23.Invoke_O__O(tmp24))).Ref()) };

	jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(pdir__2)).Mkdirs__Z()); var seq_1901000348__12 any; var root_2046 any = /*line :470:1*/A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2047 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2046, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2048 lang.IFn; if

























	linked_2047 == nil { ifn_2048 = lang.IFn_Cast(root_2046) } else { ifn_2048 = nil }; var arg_2049 any = texts__8; if linked_2047 == nil { seq_1901000348__12 = ifn_2048.Invoke_O__O(arg_2049) } else { seq_1901000348__12 = linked_2047.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2046, arg_2049) }; var chunk_1901000349__13 any; var count_1901000350__14 int64 = 0; var i_1901000351__15 int64 = 0; L1:
//line :470:1
	for {

























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000351__15, count_1901000350__14) { var vec__1901000352__16 any = lang.Indexed_Cast(chunk_1901000349__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000351__15)); var n__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000352__16, lang.RT_IntCast_J__I_NoInit(0), nil); var text__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000352__16, lang.RT_IntCast_J__I_NoInit(1), nil)
			if jrt.File_InstanceOf(text__18) {
				var root_2106 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2107 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2106, A_arbace_build_go_copy_file_A_fn_class); var ifn_2108 lang.IFn; if linked_2107 == nil { ifn_2108 = lang.IFn_Cast(root_2106) } else { ifn_2108 = nil }; var arg_2109 any = text__18; var arg_2110 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)); if linked_2107 == nil { ifn_2108.Invoke_O_O__O(arg_2109, arg_2110) } else { linked_2107.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2106, arg_2109, arg_2110) } } else {
					lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__17)), text__18) }
//line :496:1
			seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000351__15); continue L1 } else { var temp__1927000414__auto____16 any; var root_2050 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2051 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2050, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2052 lang.IFn; if linked_2051 == nil { ifn_2052 = lang.IFn_Cast(root_2050) } else { ifn_2052 = nil }; var arg_2053 any = seq_1901000348__12; if linked_2051 == nil { temp__1927000414__auto____16 = ifn_2052.Invoke_O__O(arg_2053) } else { temp__1927000414__auto____16 = linked_2051.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2050, arg_2053) }; if jrt.J2g_Truth(temp__1927000414__auto____16) { var seq_1901000348__17 any = temp__1927000414__auto____16; var tmp25 any; var root_2054 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2055 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2054, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2056 lang.IFn; if linked_2055 == nil { ifn_2056 = lang.IFn_Cast(root_2054) } else { ifn_2056 = nil }; var arg_2057 any = seq_1901000348__17; if linked_2055 == nil { tmp25 = ifn_2056.Invoke_O__O(arg_2057) } else { tmp25 = linked_2055.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2054, arg_2057) }; if jrt.J2g_Truth(tmp25) { var c__1927000678__auto____18 any; var root_2058 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2059 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2058, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2060 lang.IFn; if linked_2059 == nil { ifn_2060 = lang.IFn_Cast(root_2058) } else { ifn_2060 = nil }; var arg_2061 any = seq_1901000348__17; if linked_2059 == nil { c__1927000678__auto____18 = ifn_2060.Invoke_O__O(arg_2061) } else { c__1927000678__auto____18 = linked_2059.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2058, arg_2061) }; var tmp26 any; var root_2116 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2117 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2116, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2118 lang.IFn; if linked_2117 == nil { ifn_2118 = lang.IFn_Cast(root_2116) } else { ifn_2118 = nil }; var arg_2119 any = seq_1901000348__17; if linked_2117 == nil { tmp26 = ifn_2118.Invoke_O__O(arg_2119) } else { tmp26 = linked_2117.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2116, arg_2119) }; seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = tmp26, c__1927000678__auto____18, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var vec__1901000355__18 any; var root_2062 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2063 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2062, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2064 lang.IFn; if linked_2063 == nil { ifn_2064 = lang.IFn_Cast(root_2062) } else { ifn_2064 = nil }; var arg_2065 any = seq_1901000348__17; if linked_2063 == nil { vec__1901000355__18 = ifn_2064.Invoke_O__O(arg_2065) } else { vec__1901000355__18 = linked_2063.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2062, arg_2065) }; var n__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000355__18, lang.RT_IntCast_J__I_NoInit(0), nil); var text__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000355__18, lang.RT_IntCast_J__I_NoInit(1), nil)
				if jrt.File_InstanceOf(text__20) {
					var root_2120 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2121 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2120, A_arbace_build_go_copy_file_A_fn_class); var ifn_2122 lang.IFn; if linked_2121 == nil { ifn_2122 = lang.IFn_Cast(root_2120) } else { ifn_2122 = nil }; var arg_2123 any = text__20; var arg_2124 any = jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)); if linked_2121 == nil { ifn_2122.Invoke_O_O__O(arg_2123, arg_2124) } else { linked_2121.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2120, arg_2123, arg_2124) } } else {
						lang.IFn_Cast(A_arbace_build_go_A_const_84.GetRawRoot__O()).Invoke_O_O__O(jrt.File_New_File_String(jrt.File_Cast(pdir__2), jrt.String_Cast(n__19)), text__20) }
//line :496:1
				var tmp27 any; var root_2130 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2131 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2130, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2132 lang.IFn; if linked_2131 == nil { ifn_2132 = lang.IFn_Cast(root_2130) } else { ifn_2132 = nil }; var arg_2133 any = seq_1901000348__17; if linked_2131 == nil { tmp27 = ifn_2132.Invoke_O__O(arg_2133) } else { tmp27 = linked_2131.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2130, arg_2133) }; seq_1901000348__12, chunk_1901000349__13, count_1901000350__14, i_1901000351__15 = tmp27, nil, 0, 0; continue L1 } } }
//line :470:1
		break L1 }; var seq_1901000358__12 any; var root_2066 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2067 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2066, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2068 lang.IFn; if





























	linked_2067 == nil { ifn_2068 = lang.IFn_Cast(root_2066) } else { ifn_2068 = nil }; var tmp28 *lang.Keyword = A_arbace_build_go_A_const_158; var arg_2069 any = tmp28.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_2067 == nil { seq_1901000358__12 = ifn_2068.Invoke_O__O(arg_2069) } else { seq_1901000358__12 = linked_2067.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2066, arg_2069) }; var chunk_1901000359__13 any; var count_1901000360__14 int64 = 0; var i_1901000361__15 int64 = 0; L2:
//line :470:1
	for {





























		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000361__15, count_1901000360__14) { var f__16 any = lang.Indexed_Cast(chunk_1901000359__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000361__15)); var root_2134 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2135 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2134, A_arbace_build_go_copy_file_A_fn_class); var ifn_2136 lang.IFn
			if linked_2135 == nil { ifn_2136 = lang.IFn_Cast(root_2134) } else { ifn_2136 = nil }; var arg_2137 any; var tmp29 *jrt.File = jrt.File_Cast(src__11); var tmp30 any; var root_2139 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2140 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2139, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2141 lang.IFn; if linked_2140 == nil { ifn_2141 = lang.IFn_Cast(root_2139) } else { ifn_2141 = nil }; var arg_2142 any = f__16; if linked_2140 == nil { tmp30 = ifn_2141.Invoke_O__O(arg_2142) } else { tmp30 = linked_2140.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2139, arg_2142) }; arg_2137 = jrt.File_New_File_String(tmp29, jrt.String_Cast(tmp30)); var arg_2138 any; var tmp31 *jrt.File = jrt.File_Cast(pdir__2); var tmp32 any; var root_2143 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2144 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2143, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2145 lang.IFn; if linked_2144 == nil { ifn_2145 = lang.IFn_Cast(root_2143) } else { ifn_2145 = nil }; var arg_2146 any = f__16; if linked_2144 == nil { tmp32 = ifn_2145.Invoke_O__O(arg_2146) } else { tmp32 = linked_2144.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2143, arg_2146) }; arg_2138 = jrt.File_New_File_String(tmp31, jrt.String_Cast(tmp32)); if linked_2135 == nil { ifn_2136.Invoke_O_O__O(arg_2137, arg_2138) } else { linked_2135.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2134, arg_2137, arg_2138) }
//line :500:1
			seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000361__15); continue L2 } else { var temp__1927000414__auto____16_2 any; var root_2070 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2071 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2070, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2072 lang.IFn; if linked_2071 == nil { ifn_2072 = lang.IFn_Cast(root_2070) } else { ifn_2072 = nil }; var arg_2073 any = seq_1901000358__12; if linked_2071 == nil { temp__1927000414__auto____16_2 = ifn_2072.Invoke_O__O(arg_2073) } else { temp__1927000414__auto____16_2 = linked_2071.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2070, arg_2073) }; if jrt.J2g_Truth(temp__1927000414__auto____16_2) { var seq_1901000358__17 any = temp__1927000414__auto____16_2; var tmp33 any; var root_2074 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2075 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2074, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2076 lang.IFn; if linked_2075 == nil { ifn_2076 = lang.IFn_Cast(root_2074) } else { ifn_2076 = nil }; var arg_2077 any = seq_1901000358__17; if linked_2075 == nil { tmp33 = ifn_2076.Invoke_O__O(arg_2077) } else { tmp33 = linked_2075.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2074, arg_2077) }; if jrt.J2g_Truth(tmp33) { var c__1927000678__auto____18_2 any; var root_2078 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2079 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2078, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2080 lang.IFn; if linked_2079 == nil { ifn_2080 = lang.IFn_Cast(root_2078) } else { ifn_2080 = nil }; var arg_2081 any = seq_1901000358__17; if linked_2079 == nil { c__1927000678__auto____18_2 = ifn_2080.Invoke_O__O(arg_2081) } else { c__1927000678__auto____18_2 = linked_2079.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2078, arg_2081) }; var tmp34 any; var root_2147 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2148 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2147, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2149 lang.IFn; if linked_2148 == nil { ifn_2149 = lang.IFn_Cast(root_2147) } else { ifn_2149 = nil }; var arg_2150 any = seq_1901000358__17; if linked_2148 == nil { tmp34 = ifn_2149.Invoke_O__O(arg_2150) } else { tmp34 = linked_2148.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2147, arg_2150) }; seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = tmp34, c__1927000678__auto____18_2, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_2))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L2 } else { var f__18 any; var root_2082 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2083 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2082, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2084 lang.IFn; if linked_2083 == nil { ifn_2084 = lang.IFn_Cast(root_2082) } else { ifn_2084 = nil }; var arg_2085 any = seq_1901000358__17; if linked_2083 == nil { f__18 = ifn_2084.Invoke_O__O(arg_2085) } else { f__18 = linked_2083.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2082, arg_2085) }
				var root_2151 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2152 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2151, A_arbace_build_go_copy_file_A_fn_class); var ifn_2153 lang.IFn; if linked_2152 == nil { ifn_2153 = lang.IFn_Cast(root_2151) } else { ifn_2153 = nil }; var arg_2154 any; var tmp35 *jrt.File = jrt.File_Cast(src__11); var tmp36 any; var root_2156 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2157 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2156, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2158 lang.IFn; if linked_2157 == nil { ifn_2158 = lang.IFn_Cast(root_2156) } else { ifn_2158 = nil }; var arg_2159 any = f__18; if linked_2157 == nil { tmp36 = ifn_2158.Invoke_O__O(arg_2159) } else { tmp36 = linked_2157.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2156, arg_2159) }; arg_2154 = jrt.File_New_File_String(tmp35, jrt.String_Cast(tmp36)); var arg_2155 any; var tmp37 *jrt.File = jrt.File_Cast(pdir__2); var tmp38 any; var root_2160 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2161 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2160, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2162 lang.IFn; if linked_2161 == nil { ifn_2162 = lang.IFn_Cast(root_2160) } else { ifn_2162 = nil }; var arg_2163 any = f__18; if linked_2161 == nil { tmp38 = ifn_2162.Invoke_O__O(arg_2163) } else { tmp38 = linked_2161.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2160, arg_2163) }; arg_2155 = jrt.File_New_File_String(tmp37, jrt.String_Cast(tmp38)); if linked_2152 == nil { ifn_2153.Invoke_O_O__O(arg_2154, arg_2155) } else { linked_2152.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2151, arg_2154, arg_2155) }
//line :500:1
				var tmp39 any; var root_2164 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2165 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2164, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2166 lang.IFn; if linked_2165 == nil { ifn_2166 = lang.IFn_Cast(root_2164) } else { ifn_2166 = nil }; var arg_2167 any = seq_1901000358__17; if linked_2165 == nil { tmp39 = ifn_2166.Invoke_O__O(arg_2167) } else { tmp39 = linked_2165.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2164, arg_2167) }; seq_1901000358__12, chunk_1901000359__13, count_1901000360__14, i_1901000361__15 = tmp39, nil, 0, 0; continue L2 } } }
//line :470:1
		break L2 }; var seq_1901000362__12 any; var root_2086 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2087 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2086, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2088 lang.IFn; if































	linked_2087 == nil { ifn_2088 = lang.IFn_Cast(root_2086) } else { ifn_2088 = nil }; var tmp40 *lang.Keyword = A_arbace_build_go_A_const_159; var arg_2089 any = tmp40.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_2087 == nil { seq_1901000362__12 = ifn_2088.Invoke_O__O(arg_2089) } else { seq_1901000362__12 = linked_2087.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2086, arg_2089) }; var chunk_1901000363__13 any; var count_1901000364__14 int64 = 0; var i_1901000365__15 int64 = 0; L3:
//line :470:1
	for {































		if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000365__15, count_1901000364__14) { var vec__1901000366__16 any = lang.Indexed_Cast(chunk_1901000363__13).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000365__15)); var f__17 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000366__16, lang.RT_IntCast_J__I_NoInit(0), nil); var h__18 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000366__16, lang.RT_IntCast_J__I_NoInit(1), nil); var from__19 any; var tmp41 *jrt.File = jrt.File_Cast(src__11); var tmp42 any; var root_2168 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2169 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2168, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2170 lang.IFn
			if linked_2169 == nil { ifn_2170 = lang.IFn_Cast(root_2168) } else { ifn_2170 = nil }; var arg_2171 any = f__17; if linked_2169 == nil { tmp42 = ifn_2170.Invoke_O__O(arg_2171) } else { tmp42 = linked_2169.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2168, arg_2171) }
//line :502:1
			from__19 = jrt.File_New_File_String(tmp41, jrt.String_Cast(tmp42))

			if jrt.NN(jrt.File_Cast(from__19)).IsFile__Z() { } else {
				var tmp43 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp44 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp45 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp46 any; var root_2185 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_2186 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2185, A_arbace_build_go_rel_path_A_fn_class); var ifn_2187 lang.IFn; if linked_2186 == nil { ifn_2187 = lang.IFn_Cast(root_2185) } else { ifn_2187 = nil }; var arg_2188 any = t.F_dir; var arg_2189 any = from__19; if linked_2186 == nil { tmp46 = ifn_2187.Invoke_O_O__O(arg_2188, arg_2189) } else { tmp46 = linked_2186.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2185, arg_2188, arg_2189) }; tmp43.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp44, jrt.RefArrayOf(jrt.Object_class, tmp45, nil, tmp46)).Ref()) }
			var tmp47 any; var and__1927000168__auto____20 any = h__18; if jrt.J2g_Truth(and__1927000168__auto____20) { var root_2190 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2191 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2190, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2192 lang.IFn; if linked_2191 == nil { ifn_2192 = lang.IFn_Cast(root_2190) } else { ifn_2192 = nil }; var arg_2193 any; var root_2195 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2196 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2195, A_arbace_build_go_sha256_A_fn_class); var ifn_2197 lang.IFn; if linked_2196 == nil { ifn_2197 = lang.IFn_Cast(root_2195) } else { ifn_2197 = nil }; var arg_2198 any = from__19; if linked_2196 == nil { arg_2193 = ifn_2197.Invoke_O__O(arg_2198) } else { arg_2193 = linked_2196.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2195, arg_2198) }; var arg_2194 any; var root_2199 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2200 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2199, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2201 lang.IFn; if linked_2200 == nil { ifn_2201 = lang.IFn_Cast(root_2199) } else { ifn_2201 = nil }; var arg_2202 any = h__18; if linked_2200 == nil { arg_2194 = ifn_2201.Invoke_O__O(arg_2202) } else { arg_2194 = linked_2200.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2199, arg_2202) }; if linked_2191 == nil { tmp47 = ifn_2192.Invoke_O_O__O(arg_2193, arg_2194) } else { tmp47 = linked_2191.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2190, arg_2193, arg_2194) } } else { tmp47 = and__1927000168__auto____20 }; if jrt.J2g_Truth(tmp47) {
				var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp49 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113, nil, Lit_114, nil); var tmp50 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp51 any; var root_2207 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2208 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2207, A_arbace_build_go_sha256_A_fn_class); var ifn_2209 lang.IFn; if linked_2208 == nil { ifn_2209 = lang.IFn_Cast(root_2207) } else { ifn_2209 = nil }; var arg_2210 any = from__19; if linked_2208 == nil { tmp51 = ifn_2209.Invoke_O__O(arg_2210) } else { tmp51 = linked_2208.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2207, arg_2210) }; tmp48.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp49, jrt.RefArrayOf(jrt.Object_class, tmp50, nil, f__17, nil, tmp51, nil, h__18)).Ref())
			}
			var root_2172 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2173 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2172, A_arbace_build_go_copy_file_A_fn_class); var ifn_2174 lang.IFn; if linked_2173 == nil { ifn_2174 = lang.IFn_Cast(root_2172) } else { ifn_2174 = nil }; var arg_2175 any = from__19; var arg_2176 any; var tmp52 *jrt.File = jrt.File_Cast(pdir__2); var tmp53 any; var root_2177 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2178 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2177, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2179 lang.IFn; if linked_2178 == nil { ifn_2179 = lang.IFn_Cast(root_2177) } else { ifn_2179 = nil }; var arg_2180 any = f__17; if linked_2178 == nil { tmp53 = ifn_2179.Invoke_O__O(arg_2180) } else { tmp53 = linked_2178.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2177, arg_2180) }; arg_2176 = jrt.File_New_File_String(tmp52, jrt.String_Cast(tmp53)); if linked_2173 == nil { ifn_2174.Invoke_O_O__O(arg_2175, arg_2176) } else { linked_2173.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2172, arg_2175, arg_2176) }
//line :502:1
			seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000365__15); continue L3 } else { var temp__1927000414__auto____16_3 any; var root_2090 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2091 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2090, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2092 lang.IFn; if linked_2091 == nil { ifn_2092 = lang.IFn_Cast(root_2090) } else { ifn_2092 = nil }; var arg_2093 any = seq_1901000362__12; if linked_2091 == nil { temp__1927000414__auto____16_3 = ifn_2092.Invoke_O__O(arg_2093) } else { temp__1927000414__auto____16_3 = linked_2091.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2090, arg_2093) }; if jrt.J2g_Truth(temp__1927000414__auto____16_3) { var seq_1901000362__17 any = temp__1927000414__auto____16_3; var tmp54 any; var root_2094 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2095 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2094, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2096 lang.IFn; if linked_2095 == nil { ifn_2096 = lang.IFn_Cast(root_2094) } else { ifn_2096 = nil }; var arg_2097 any = seq_1901000362__17; if linked_2095 == nil { tmp54 = ifn_2096.Invoke_O__O(arg_2097) } else { tmp54 = linked_2095.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2094, arg_2097) }; if jrt.J2g_Truth(tmp54) { var c__1927000678__auto____18_3 any; var root_2098 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2099 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2098, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2100 lang.IFn; if linked_2099 == nil { ifn_2100 = lang.IFn_Cast(root_2098) } else { ifn_2100 = nil }; var arg_2101 any = seq_1901000362__17; if linked_2099 == nil { c__1927000678__auto____18_3 = ifn_2100.Invoke_O__O(arg_2101) } else { c__1927000678__auto____18_3 = linked_2099.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2098, arg_2101) }; var tmp55 any; var root_2211 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2212 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2211, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2213 lang.IFn; if linked_2212 == nil { ifn_2213 = lang.IFn_Cast(root_2211) } else { ifn_2213 = nil }; var arg_2214 any = seq_1901000362__17; if linked_2212 == nil { tmp55 = ifn_2213.Invoke_O__O(arg_2214) } else { tmp55 = linked_2212.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2211, arg_2214) }; seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = tmp55, c__1927000678__auto____18_3, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____18_3))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L3 } else { var vec__1901000369__18 any; var root_2102 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2103 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2102, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2104 lang.IFn; if linked_2103 == nil { ifn_2104 = lang.IFn_Cast(root_2102) } else { ifn_2104 = nil }; var arg_2105 any = seq_1901000362__17; if linked_2103 == nil { vec__1901000369__18 = ifn_2104.Invoke_O__O(arg_2105) } else { vec__1901000369__18 = linked_2103.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2102, arg_2105) }; var f__19 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000369__18, lang.RT_IntCast_J__I_NoInit(0), nil); var h__20 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000369__18, lang.RT_IntCast_J__I_NoInit(1), nil); var from__21 any; var tmp56 *jrt.File = jrt.File_Cast(src__11); var tmp57 any; var root_2215 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2216 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2215, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2217 lang.IFn
				if linked_2216 == nil { ifn_2217 = lang.IFn_Cast(root_2215) } else { ifn_2217 = nil }; var arg_2218 any = f__19; if linked_2216 == nil { tmp57 = ifn_2217.Invoke_O__O(arg_2218) } else { tmp57 = linked_2216.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2215, arg_2218) }
//line :502:1
				from__21 = jrt.File_New_File_String(tmp56, jrt.String_Cast(tmp57))

				if jrt.NN(jrt.File_Cast(from__21)).IsFile__Z() { } else {
					var tmp58 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp59 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_111, nil); var tmp60 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp61 any; var root_2232 any = A_arbace_build_go_A_const_66.GetRawRoot__O(); var linked_2233 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2232, A_arbace_build_go_rel_path_A_fn_class); var ifn_2234 lang.IFn; if linked_2233 == nil { ifn_2234 = lang.IFn_Cast(root_2232) } else { ifn_2234 = nil }; var arg_2235 any = t.F_dir; var arg_2236 any = from__21; if linked_2233 == nil { tmp61 = ifn_2234.Invoke_O_O__O(arg_2235, arg_2236) } else { tmp61 = linked_2233.(*A_arbace_build_go_rel_path_A).Invoke_O_O_O__O(root_2232, arg_2235, arg_2236) }; tmp58.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp59, jrt.RefArrayOf(jrt.Object_class, tmp60, nil, tmp61)).Ref()) }
				var tmp62 any; var and__1927000168__auto____22 any = h__20; if jrt.J2g_Truth(and__1927000168__auto____22) { var root_2237 any = A_arbace_build_go_A_const_35.GetRawRoot__O(); var linked_2238 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2237, aot_arbace_core.A_arbace_core_not_EQ__A_fn_class); var ifn_2239 lang.IFn; if linked_2238 == nil { ifn_2239 = lang.IFn_Cast(root_2237) } else { ifn_2239 = nil }; var arg_2240 any; var root_2242 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2243 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2242, A_arbace_build_go_sha256_A_fn_class); var ifn_2244 lang.IFn; if linked_2243 == nil { ifn_2244 = lang.IFn_Cast(root_2242) } else { ifn_2244 = nil }; var arg_2245 any = from__21; if linked_2243 == nil { arg_2240 = ifn_2244.Invoke_O__O(arg_2245) } else { arg_2240 = linked_2243.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2242, arg_2245) }; var arg_2241 any; var root_2246 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2247 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2246, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2248 lang.IFn; if linked_2247 == nil { ifn_2248 = lang.IFn_Cast(root_2246) } else { ifn_2248 = nil }; var arg_2249 any = h__20; if linked_2247 == nil { arg_2241 = ifn_2248.Invoke_O__O(arg_2249) } else { arg_2241 = linked_2247.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2246, arg_2249) }; if linked_2238 == nil { tmp62 = ifn_2239.Invoke_O_O__O(arg_2240, arg_2241) } else { tmp62 = linked_2238.(*aot_arbace_core.A_arbace_core_not_EQ__A).Invoke_O_O_O__O(root_2237, arg_2240, arg_2241) } } else { tmp62 = and__1927000168__auto____22 }; if jrt.J2g_Truth(tmp62) {
					var tmp63 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_47.GetRawRoot__O()); var tmp64 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, nil, Lit_112, nil, Lit_113, nil, Lit_114, nil); var tmp65 any = A_arbace_build_go_A_const_46.Invoke_O__O(pkg__1); var tmp66 any; var root_2254 any = A_arbace_build_go_A_const_162.GetRawRoot__O(); var linked_2255 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2254, A_arbace_build_go_sha256_A_fn_class); var ifn_2256 lang.IFn; if linked_2255 == nil { ifn_2256 = lang.IFn_Cast(root_2254) } else { ifn_2256 = nil }; var arg_2257 any = from__21; if linked_2255 == nil { tmp66 = ifn_2256.Invoke_O__O(arg_2257) } else { tmp66 = linked_2255.(*A_arbace_build_go_sha256_A).Invoke_O_O__O(root_2254, arg_2257) }; tmp63.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp64, jrt.RefArrayOf(jrt.Object_class, tmp65, nil, f__19, nil, tmp66, nil, h__20)).Ref())
				}
				var root_2219 any = A_arbace_build_go_A_const_161.GetRawRoot__O(); var linked_2220 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2219, A_arbace_build_go_copy_file_A_fn_class); var ifn_2221 lang.IFn; if linked_2220 == nil { ifn_2221 = lang.IFn_Cast(root_2219) } else { ifn_2221 = nil }; var arg_2222 any = from__21; var arg_2223 any; var tmp67 *jrt.File = jrt.File_Cast(pdir__2); var tmp68 any; var root_2224 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2225 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2224, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2226 lang.IFn; if linked_2225 == nil { ifn_2226 = lang.IFn_Cast(root_2224) } else { ifn_2226 = nil }; var arg_2227 any = f__19; if linked_2225 == nil { tmp68 = ifn_2226.Invoke_O__O(arg_2227) } else { tmp68 = linked_2225.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2224, arg_2227) }; arg_2223 = jrt.File_New_File_String(tmp67, jrt.String_Cast(tmp68)); if linked_2220 == nil { ifn_2221.Invoke_O_O__O(arg_2222, arg_2223) } else { linked_2220.(*A_arbace_build_go_copy_file_A).Invoke_O_O_O__O(root_2219, arg_2222, arg_2223) }
//line :502:1
				var tmp69 any; var root_2258 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2259 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2258, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2260 lang.IFn; if linked_2259 == nil { ifn_2260 = lang.IFn_Cast(root_2258) } else { ifn_2260 = nil }; var arg_2261 any = seq_1901000362__17; if linked_2259 == nil { tmp69 = ifn_2260.Invoke_O__O(arg_2261) } else { tmp69 = linked_2259.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2258, arg_2261) }; seq_1901000362__12, chunk_1901000363__13, count_1901000364__14, i_1901000365__15 = tmp69, nil, 0, 0; continue L3 } } }
//line :470:1
		break L3 }; var root_1969 any =







































	A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1970 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1969, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1971 lang.IFn; if linked_1970 == nil { ifn_1971 = lang.IFn_Cast(root_1969) } else { ifn_1971 = nil }; var arg_1972 any = rel__10; var arg_1973 any; var tmp70 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp71 any; var root_1980 any = A_arbace_build_go_A_const_142.GetRawRoot__O(); var linked_1981 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1980, aot_arbace_core.A_arbace_core_keys_A_fn_class); var ifn_1982 lang.IFn; if linked_1981 == nil { ifn_1982 = lang.IFn_Cast(root_1980) } else { ifn_1982 = nil }; var arg_1983 any = texts__8; if linked_1981 == nil { tmp71 = ifn_1982.Invoke_O__O(arg_1983) } else { tmp71 = linked_1981.(*aot_arbace_core.A_arbace_core_keys_A).Invoke_O_O__O(root_1980, arg_1983) }; var tmp72 any = tmp71; var tmp73 any; var root_1984 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1985 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1984, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1986 lang.IFn; if linked_1985 == nil { ifn_1986 = lang.IFn_Cast(root_1984) } else { ifn_1986 = nil }; var arg_1987 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var tmp74 *lang.Keyword = A_arbace_build_go_A_const_158; var arg_1988 any = tmp74.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_1985 == nil { tmp73 = ifn_1986.Invoke_O_O__O(arg_1987, arg_1988) } else { tmp73 = linked_1985.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1984, arg_1987, arg_1988) }; var tmp75 any = tmp73; var tmp76 any; var root_1989 any = A_arbace_build_go_A_const_49.GetRawRoot__O(); var linked_1990 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1989, aot_arbace_core.A_arbace_core_map_A_fn_class); var ifn_1991 lang.IFn; if
	linked_1990 == nil { ifn_1991 = lang.IFn_Cast(root_1989) } else { ifn_1991 = nil }; var arg_1992 any; var root_1994 any = A_arbace_build_go_A_const_81.GetRawRoot__O(); var linked_1995 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1994, aot_arbace_core.A_arbace_core_comp_A_fn_class); var ifn_1996 lang.IFn; if linked_1995 == nil { ifn_1996 = lang.IFn_Cast(root_1994) } else { ifn_1996 = nil }; var arg_1997 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var arg_1998 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); if linked_1995 == nil { arg_1992 = ifn_1996.Invoke_O_O__O(arg_1997, arg_1998) } else { arg_1992 = linked_1995.(*aot_arbace_core.A_arbace_core_comp_A).Invoke_O_O_O__O(root_1994, arg_1997, arg_1998) }; var tmp77 *lang.Keyword = A_arbace_build_go_A_const_159; var arg_1993 any = tmp77.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(pkg__1)); if linked_1990 == nil { tmp76 = ifn_1991.Invoke_O_O__O(arg_1992, arg_1993) } else { tmp76 = linked_1990.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1989, arg_1992, arg_1993) }; arg_1973 = /*line :510:1*/tmp70.Invoke_O_O_O__O(tmp72, tmp75, tmp76); if linked_1970 == nil { return ifn_1971.Invoke_O_O__O(arg_1972, arg_1973) } else { return linked_1970.(*aot_arbace_core.A_arbace_core_map_A).Invoke_O_O_O__O(root_1969, arg_1972, arg_1973) } }
//line :471:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_New_O_O(p0, p1 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A{}; t.Ctor_O_O(p0, p1); return t }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A) Ctor_O_O(c__test_files, c__tests any) { t.F_test_files = c__test_files; t.F_tests = c__tests }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A) Invoke_O_O__O(self, p1__1901000329_SHARP___1 any) any {



	if jrt.J2g_Truth(t.F_tests) { return p1__1901000329_SHARP___1 } else {

		var root_1898 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_1899 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1898, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_1900 lang.IFn; if linked_1899 == nil { ifn_1900 = lang.IFn_Cast(root_1898) } else { ifn_1900 = nil }; var arg_1901 any = p1__1901000329_SHARP___1; var arg_1902 any = A_arbace_build_go_A_const_136; var arg_1903 any; var tmp1 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_New_O(t.F_test_files); var tmp2 *jrt.Class; var fncls__1918 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class; if fncls__1918 == nil { var fncls__1918d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_115, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class = fncls__1918d; tmp2 = fncls__1918d } else { tmp2 = fncls__1918 }; arg_1903 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); if linked_1899 == nil { return ifn_1900.Invoke_O_O_O__O(arg_1901, arg_1902, arg_1903) } else { return linked_1899.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O__O(root_1898, arg_1901, arg_1902, arg_1903) } } }
//line :471:1
func A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A{}; t.Ctor_O(p0); return t }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A) Ctor_O(c__pkg any) { t.F_pkg = c__pkg }
//line :471:1
func (t *A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A) Invoke_O_O__O(self, p1__1901000330_SHARP___1 any) any {


















	if lang.Util_Equiv_O_O__Z_NoInit(Lit_96, A_arbace_build_go_A_const_127.Invoke_O__O(t.F_pkg)) { return p1__1901000330_SHARP___1 } else { return lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_117, nil), jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_127.Invoke_O__O(t.F_pkg), nil, p1__1901000330_SHARP___1)).Ref() } }
//line :477:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A{}; t.Ctor_O(p0); return t }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A) Invoke_O_O__O(self, fs__1 any) any { var root_1904 any = A_arbace_build_go_A_const_151.GetRawRoot__O(); var linked_1905 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1904, aot_arbace_core.A_arbace_core_filterv_A_fn_class); var ifn_1906 lang.IFn; if linked_1905 == nil { ifn_1906 = lang.IFn_Cast(root_1904) } else { ifn_1906 = nil }; var arg_1907 any; var tmp1 any = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_New_O(t.F_test_files); var tmp2 *jrt.Class; var fncls__1917 *jrt.Class = A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class; if fncls__1917 == nil { var fncls__1917d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_116, false); A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class = fncls__1917d; tmp2 = fncls__1917d } else { tmp2 = fncls__1917 }; arg_1907 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil); var arg_1908 any = fs__1; if linked_1905 == nil { return ifn_1906.Invoke_O_O__O(arg_1907, arg_1908) } else { return linked_1905.(*aot_arbace_core.A_arbace_core_filterv_A).Invoke_O_O_O__O(root_1904, arg_1907, arg_1908) } }
//line :477:1
func A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_New_O(p0 any) *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A{}; t.Ctor_O(p0); return t }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A) Ctor_O(c__test_files any) { t.F_test_files = c__test_files }
//line :477:1
func (t *A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A) Invoke_O_O__O(self, f__1 any) any { var root_1909 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_1910 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_1909, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_1911 lang.IFn; if linked_1910 == nil { ifn_1911 = lang.IFn_Cast(root_1909) } else { ifn_1911 = nil }; var arg_1912 any; var tmp1 lang.IFn = lang.IFn_Cast(t.F_test_files); var tmp2 any; var root_1913 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_1914 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_1913, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_1915 lang.IFn; if linked_1914 == nil { ifn_1915 = lang.IFn_Cast(root_1913) } else { ifn_1915 = nil }; var arg_1916 any = A_arbace_build_go_A_const_36.Invoke_O__O(f__1); if linked_1914 == nil { tmp2 = ifn_1915.Invoke_O__O(arg_1916) } else { tmp2 = linked_1914.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_1913, arg_1916) }; arg_1912 = tmp1.Invoke_O__O(tmp2); if linked_1910 == nil { return ifn_1911.Invoke_O__O(arg_1912) } else { return linked_1910.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_1909, arg_1912) } }







































func A_arbace_build_go_delete_tree_A_New() *A_arbace_build_go_delete_tree_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_delete_tree_A{}; t.Ctor(); return t }
//line :517:1
func (t *A_arbace_build_go_delete_tree_A) Ctor() {}
//line :517:1
func (t *A_arbace_build_go_delete_tree_A) Invoke_O_O__O(self, f__0 any) any {
	if jrt.NN(jrt.File_Cast(f__0)).IsDirectory__Z() { var seq_1901000374__2 any; var root_2285 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2286 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2285, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2287 lang.IFn
		if linked_2286 == nil { ifn_2287 = lang.IFn_Cast(root_2285) } else { ifn_2287 = nil }; var arg_2288 any = jrt.NN(jrt.File_Cast(f__0)).ListFiles__File1().Ref(); if linked_2286 == nil { seq_1901000374__2 = ifn_2287.Invoke_O__O(arg_2288) } else { seq_1901000374__2 = linked_2286.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2285, arg_2288) }
//line :518:1
		var chunk_1901000375__3 any; var count_1901000376__4 int64 = 0; var i_1901000377__5 int64 = 0; L1: for {
			if lang.Numbers_Lt_J_J__Z_NoInit(i_1901000377__5, count_1901000376__4) { var c__6 any = lang.Indexed_Cast(chunk_1901000375__3).Nth_I__O(lang.RT_IntCast_J__I_NoInit(i_1901000377__5)); var root_2305 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2306 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2305, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2307 lang.IFn; if linked_2306 == nil { ifn_2307 = lang.IFn_Cast(root_2305) } else { ifn_2307 = nil }; var arg_2308 any = c__6; if linked_2306 == nil { ifn_2307.Invoke_O__O(arg_2308) } else { linked_2306.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2305, arg_2308) }; seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, lang.Numbers_Unchecked_inc_J__J_NoInit(i_1901000377__5); continue L1 } else { var temp__1927000414__auto____6 any; var root_2289 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2290 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2289, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2291 lang.IFn; if linked_2290 == nil { ifn_2291 = lang.IFn_Cast(root_2289) } else { ifn_2291 = nil }; var arg_2292 any = seq_1901000374__2; if linked_2290 == nil { temp__1927000414__auto____6 = ifn_2291.Invoke_O__O(arg_2292) } else { temp__1927000414__auto____6 = linked_2290.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2289, arg_2292) }; if jrt.J2g_Truth(temp__1927000414__auto____6) { var seq_1901000374__7 any = temp__1927000414__auto____6; var tmp1 any; var root_2293 any = A_arbace_build_go_A_const_32.GetRawRoot__O(); var linked_2294 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2293, aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A_fn_class); var ifn_2295 lang.IFn; if linked_2294 == nil { ifn_2295 = lang.IFn_Cast(root_2293) } else { ifn_2295 = nil }; var arg_2296 any = seq_1901000374__7; if linked_2294 == nil { tmp1 = ifn_2295.Invoke_O__O(arg_2296) } else { tmp1 = linked_2294.(*aot_arbace_core.A_arbace_core_chunked_seq_QMARK__A).Invoke_O_O__O(root_2293, arg_2296) }; if jrt.J2g_Truth(tmp1) { var c__1927000678__auto____8 any; var root_2297 any = A_arbace_build_go_A_const_33.GetRawRoot__O(); var linked_2298 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2297, aot_arbace_core.A_arbace_core_chunk_first_A_fn_class); var ifn_2299 lang.IFn; if linked_2298 == nil { ifn_2299 = lang.IFn_Cast(root_2297) } else { ifn_2299 = nil }; var arg_2300 any = seq_1901000374__7; if linked_2298 == nil { c__1927000678__auto____8 = ifn_2299.Invoke_O__O(arg_2300) } else { c__1927000678__auto____8 = linked_2298.(*aot_arbace_core.A_arbace_core_chunk_first_A).Invoke_O_O__O(root_2297, arg_2300) }; var tmp2 any; var root_2309 any = A_arbace_build_go_A_const_40.GetRawRoot__O(); var linked_2310 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2309, aot_arbace_core.A_arbace_core_chunk_rest_A_fn_class); var ifn_2311 lang.IFn; if linked_2310 == nil { ifn_2311 = lang.IFn_Cast(root_2309) } else { ifn_2311 = nil }; var arg_2312 any = seq_1901000374__7; if linked_2310 == nil { tmp2 = ifn_2311.Invoke_O__O(arg_2312) } else { tmp2 = linked_2310.(*aot_arbace_core.A_arbace_core_chunk_rest_A).Invoke_O_O__O(root_2309, arg_2312) }; seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = tmp2, c__1927000678__auto____8, int64(lang.RT_IntCast_I__I_NoInit(lang.RT_Count_O__I_NoInit(c__1927000678__auto____8))), int64(lang.RT_IntCast_J__I_NoInit(0)); continue L1 } else { var c__8 any; var root_2301 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2302 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2301, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2303 lang.IFn; if linked_2302 == nil { ifn_2303 = lang.IFn_Cast(root_2301) } else { ifn_2303 = nil }; var arg_2304 any = seq_1901000374__7; if linked_2302 == nil { c__8 = ifn_2303.Invoke_O__O(arg_2304) } else { c__8 = linked_2302.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2301, arg_2304) }; var root_2313 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2314 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2313, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2315 lang.IFn; if linked_2314 == nil { ifn_2315 = lang.IFn_Cast(root_2313) } else { ifn_2315 = nil }; var arg_2316 any = c__8; if linked_2314 == nil { ifn_2315.Invoke_O__O(arg_2316) } else { linked_2314.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2313, arg_2316) }; var tmp3 any; var root_2317 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2318 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2317, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2319 lang.IFn; if linked_2318 == nil { ifn_2319 = lang.IFn_Cast(root_2317) } else { ifn_2319 = nil }; var arg_2320 any = seq_1901000374__7; if linked_2318 == nil { tmp3 = ifn_2319.Invoke_O__O(arg_2320) } else { tmp3 = linked_2318.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2317, arg_2320) }; seq_1901000374__2, chunk_1901000375__3, count_1901000376__4, i_1901000377__5 = tmp3, nil, 0, 0; continue L1 } } }
//line :518:1
			break L1
		} }
	return jrt.Boolean_ValueOf_Z__Boolean_NoInit(jrt.NN(jrt.File_Cast(f__0)).Delete__Z()).Ref()
}
func A_arbace_build_go_build_A_New() *A_arbace_build_go_build_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_build_A{}; t.Ctor(); return t }
//line :522:1
func (t *A_arbace_build_go_build_A) Ctor() {}
//line :522:1
func (t *A_arbace_build_go_build_A) Invoke_O_O_O_O_O__O(self, dir__0, arch__1, out__2, p__1901000379__3 any) any { var map__1901000380__5 any = p__1901000379__3; var map__1901000380__6 any; if lang.ISeq_InstanceOf(map__1901000380__5) { var tmp1 any; var root_2321 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2322 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2321, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2323 lang.IFn; if linked_2322 == nil { ifn_2323 = lang.IFn_Cast(root_2321) } else { ifn_2323 = nil }; var arg_2324 any = map__1901000380__5; if linked_2322 == nil { tmp1 = ifn_2323.Invoke_O__O(arg_2324) } else { tmp1 = linked_2322.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2321, arg_2324) }; if jrt.J2g_Truth(tmp1) { var tmp2 any; var root_2325 any = A_arbace_build_go_A_const_111.GetRawRoot__O(); var linked_2326 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2325, aot_arbace_core.A_arbace_core_to_array_A_fn_class); var ifn_2327 lang.IFn; if linked_2326 == nil { ifn_2327 = lang.IFn_Cast(root_2325) } else { ifn_2327 = nil }; var arg_2328 any = map__1901000380__5; if linked_2326 == nil { tmp2 = ifn_2327.Invoke_O__O(arg_2328) } else { tmp2 = linked_2326.(*aot_arbace_core.A_arbace_core_to_array_A).Invoke_O_O__O(root_2325, arg_2328) }; map__1901000380__6 = lang.PersistentArrayMap_CreateAsIfByAssoc_O1__PersistentArrayMap_NoInit(jrt.ObjectArray_Cast(tmp2)).Ref() } else { var tmp3 any; var root_2329 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2330 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2329, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2331 lang.IFn; if linked_2330 == nil { ifn_2331 = lang.IFn_Cast(root_2329) } else { ifn_2331 = nil }; var arg_2332 any = map__1901000380__5; if linked_2330 == nil { tmp3 = ifn_2331.Invoke_O__O(arg_2332) } else { tmp3 = linked_2330.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2329, arg_2332) }; if jrt.J2g_Truth(tmp3) { var root_2333 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2334 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2333, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2335 lang.IFn; if linked_2334 == nil { ifn_2335 = lang.IFn_Cast(root_2333) } else { ifn_2335 = nil }; var arg_2336 any = map__1901000380__5; if linked_2334 == nil { map__1901000380__6 = ifn_2335.Invoke_O__O(arg_2336) } else { map__1901000380__6 = linked_2334.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2333, arg_2336) } } else { map__1901000380__6 = lang.PersistentArrayMap_EMPTY.Ref() } } } else { map__1901000380__6 = map__1901000380__5 }; var opts__7 any = map__1901000380__6; var work__8 any = lang.RT_Get_O_O__O_NoInit(map__1901000380__6, A_arbace_build_go_A_const_164); var goroot__9 any = lang.RT_Get_O_O__O_NoInit(map__1901000380__6, A_arbace_build_go_A_const_145); var prog__10 any; var root_2337 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2338 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2337, A_arbace_build_go_program_A_fn_class); var ifn_2339 lang.IFn; if



	linked_2338 == nil { ifn_2339 = lang.IFn_Cast(root_2337) } else { ifn_2339 = nil }; var arg_2340 any = dir__0; var arg_2341 any = goroot__9; var arg_2342 any = opts__7; if linked_2338 == nil { prog__10 = ifn_2339.Invoke_O_O_O__O(arg_2340, arg_2341, arg_2342) } else { prog__10 = linked_2338.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2337, arg_2340, arg_2341, arg_2342) }; var main__11 any = /*line :522:1*/A_arbace_build_go_A_const_130.Invoke_O__O(prog__10); var tmp4 *lang.Keyword = A_arbace_build_go_A_const_165; var config__12 any = tmp4.Invoke_O__O(A_arbace_build_go_A_const_62.Invoke_O__O(main__11)); var tmp_QMARK___13 bool = lang.Util_Identical_O_O__Z_NoInit(work__8, nil); var work__14 any; if







	jrt.J2g_Truth(work__8) { var tmp5 any; var root_2343 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2344 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2343, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2345 lang.IFn
		if linked_2344 == nil { ifn_2345 = lang.IFn_Cast(root_2343) } else { ifn_2345 = nil }; var arg_2346 any = work__8; if linked_2344 == nil { tmp5 = ifn_2345.Invoke_O__O(arg_2346) } else { tmp5 = linked_2344.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2343, arg_2346) }
//line :530:1
		work__14 = jrt.File_New_String(jrt.String_Cast(tmp5)) } else {

			var tmp6 *jrt.String = Lit_27; var tmp7 any; var root_2347 any = A_arbace_build_go_A_const_166.GetRawRoot__O(); var linked_2348 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2347, aot_arbace_core.A_arbace_core_make_array_A_fn_class); var ifn_2349 lang.IFn; if linked_2348 == nil { ifn_2349 = lang.IFn_Cast(root_2347) } else { ifn_2349 = nil }; var arg_2350 any = A_arbace_build_go_A_const_167; var arg_2351 any = A_arbace_build_go_A_const_134; if linked_2348 == nil { tmp7 = ifn_2349.Invoke_O_O__O(arg_2350, arg_2351) } else { tmp7 = linked_2348.(*aot_arbace_core.A_arbace_core_make_array_A).Invoke_O_O_O__O(root_2347, arg_2350, arg_2351) }; work__14 = jrt.Files_CreateTempDirectory_String_FileAttribute1__Path(tmp6, jrt.RefArray_Cast(tmp7, jrt.FileAttribute_class)).ToFile__File().Ref() }; var tmp8 any; tmp23 := /*line :522:1*/func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var mod__17 any = jrt.File_New_File_String(jrt.File_Cast(work__14), Lit_24)












				if jrt.NN(jrt.File_Cast(mod__17)).Exists__Z() { var root_2405 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2406 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2405, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2407 lang.IFn; if linked_2406 == nil { ifn_2407 = lang.IFn_Cast(root_2405) } else { ifn_2407 = nil }; var arg_2408 any = mod__17; if linked_2406 == nil { ifn_2407.Invoke_O__O(arg_2408) } else { linked_2406.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2405, arg_2408) } }
				var root_2409 any = A_arbace_build_go_A_const_173.GetRawRoot__O(); var linked_2410 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2409, A_arbace_build_go_print_module_A_fn_class); var ifn_2411 lang.IFn; if linked_2410 == nil { ifn_2411 = lang.IFn_Cast(root_2409) } else { ifn_2411 = nil }; var arg_2412 any = prog__10; var arg_2413 any = dir__0; var arg_2414 any = mod__17; var arg_2415 any = opts__7; if linked_2410 == nil { ifn_2411.Invoke_O_O_O_O__O(arg_2412, arg_2413, arg_2414, arg_2415) } else { linked_2410.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2409, arg_2412, arg_2413, arg_2414, arg_2415) }
//line :522:1
				var tags__18 any = A_arbace_build_go_A_const_168.Invoke_O__O(config__12); var tamago_QMARK___19 bool = lang.Util_Equiv_O_O__Z_NoInit(A_arbace_build_go_A_const_144.Invoke_O__O(opts__7), Lit_28); var cmd__20 any; var tmp9 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_43.GetRawRoot__O()); var tmp10 any = lang.Tuple_Create_O_O_O_O__IPersistentVector(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, nil, Lit_29), jrt.RefArrayOf(jrt.Object_class, goroot__9, nil)).Ref(), Lit_30, Lit_31, Lit_32); var tmp11 lang.IPersistentVector; var tmp12 any; var root_2361 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2362 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2361, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2363 lang.IFn

















				if linked_2362 == nil { ifn_2363 = lang.IFn_Cast(root_2361) } else { ifn_2363 = nil }; var arg_2364 any = tags__18; if linked_2362 == nil { tmp12 = ifn_2363.Invoke_O__O(arg_2364) } else { tmp12 = linked_2362.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2361, arg_2364) }; if jrt.J2g_Truth(tmp12) { var tmp13 any; var root_2365 any = A_arbace_build_go_A_const_48.GetRawRoot__O(); var linked_2366 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2365, aot_arbace_string.A_arbace_string_join_A_fn_class); var ifn_2367 lang.IFn; if linked_2366 == nil { ifn_2367 = lang.IFn_Cast(root_2365) } else { ifn_2367 = nil }; var arg_2368 any = Lit_34; var arg_2369 any = tags__18; if linked_2366 == nil { tmp13 = ifn_2367.Invoke_O_O__O(arg_2368, arg_2369) } else { tmp13 = linked_2366.(*aot_arbace_string.A_arbace_string_join_A).Invoke_O_O_O__O(root_2365, arg_2368, arg_2369) }; tmp11 = lang.Tuple_Create_O_O__IPersistentVector(Lit_33, tmp13) } else { tmp11 = nil }
//line :539:1
				var tmp14 any = tmp11; var tmp15 lang.IPersistentVector

				if tamago_QMARK___19 { tmp15 = lang.Tuple_Create_O_O__IPersistentVector(Lit_35, A_arbace_build_go_A_const_169.GetRawRoot__O()) } else { tmp15 = nil }
//line :539:1
				var tmp16 any = tmp15; var tmp17 lang.IPersistentVector; var temp__1927000414__auto____20 any = A_arbace_build_go_A_const_170.Invoke_O__O(opts__7)


				if jrt.J2g_Truth(temp__1927000414__auto____20) { var o__21 any = temp__1927000414__auto____20; var tmp18 any; var root_2370 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2371 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2370, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2372 lang.IFn
					if linked_2371 == nil { ifn_2372 = lang.IFn_Cast(root_2370) } else { ifn_2372 = nil }; var arg_2373 any = o__21; if linked_2371 == nil { tmp18 = ifn_2372.Invoke_O__O(arg_2373) } else { tmp18 = linked_2371.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2370, arg_2373) }
//line :542:1
					tmp17 = lang.Tuple_Create_O_O__IPersistentVector(Lit_36, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp18)).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp17 = nil }
//line :539:1
				var tmp19 any = tmp17; var tmp20 lang.IPersistentVector; var temp__1927000414__auto____20_2 any = A_arbace_build_go_A_const_171.Invoke_O__O(opts__7)




				if jrt.J2g_Truth(temp__1927000414__auto____20_2) { var f__21 any = temp__1927000414__auto____20_2; var tmp21 any; var root_2374 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2375 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2374, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2376 lang.IFn
					if linked_2375 == nil { ifn_2376 = lang.IFn_Cast(root_2374) } else { ifn_2376 = nil }; var arg_2377 any = f__21; if linked_2375 == nil { tmp21 = ifn_2376.Invoke_O__O(arg_2377) } else { tmp21 = linked_2375.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2374, arg_2377) }
//line :544:1
					tmp20 = lang.Tuple_Create_O_O__IPersistentVector(Lit_37, jrt.NN(jrt.File_New_String(jrt.String_Cast(tmp21)).GetAbsoluteFile__File()).GetPath__String().Ref()) } else { tmp20 = nil }
//line :539:1
				cmd__20 = tmp9.Invoke_O_O_O_O_O_O__O(tmp10, tmp14, tmp16, tmp19, tmp20, lang.Tuple_Create_O_O_O__IPersistentVector(Lit_12, jrt.NN(jrt.NN(jrt.File_Cast(out__2)).GetAbsoluteFile__File()).GetPath__String().Ref(), A_arbace_build_go_A_const_46.Invoke_O__O(main__11)))
//line :522:1
				var env__21 any; var G__1901000385__21_ any; var root_2378 any = A_arbace_build_go_A_const_108.GetRawRoot__O(); var linked_2379 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2378, A_arbace_build_go_go_env_A_fn_class); var ifn_2380 lang.IFn
























				if linked_2379 == nil { ifn_2380 = lang.IFn_Cast(root_2378) } else { ifn_2380 = nil }; var arg_2381 any = goroot__9; var arg_2382 any = arch__1; var arg_2383 any; var or__1927000174__auto____21 any = A_arbace_build_go_A_const_144.Invoke_O__O(opts__7); if jrt.J2g_Truth(or__1927000174__auto____21) { arg_2383 = or__1927000174__auto____21 } else { arg_2383 = Lit_38 }; if linked_2379 == nil { G__1901000385__21_ = ifn_2380.Invoke_O_O_O__O(arg_2381, arg_2382, arg_2383) } else { G__1901000385__21_ = linked_2379.(*A_arbace_build_go_go_env_A).Invoke_O_O_O_O__O(root_2378, arg_2381, arg_2382, arg_2383) }; var tmp22 any; var root_2384 any = A_arbace_build_go_A_const_31.GetRawRoot__O(); var linked_2385 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2384, aot_arbace_core.A_arbace_core_seq__1927000026_A_fn_class); var ifn_2386 lang.IFn
				if linked_2385 == nil { ifn_2386 = lang.IFn_Cast(root_2384) } else { ifn_2386 = nil }; var arg_2387 any = A_arbace_build_go_A_const_172.Invoke_O__O(config__12); if linked_2385 == nil { tmp22 = ifn_2386.Invoke_O__O(arg_2387) } else { tmp22 = linked_2385.(*aot_arbace_core.A_arbace_core_seq__1927000026_A).Invoke_O_O__O(root_2384, arg_2387) }
//line :547:1
				if jrt.J2g_Truth(tmp22) {
					var root_2388 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2389 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2388, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2390 lang.IFn; if linked_2389 == nil { ifn_2390 = lang.IFn_Cast(root_2388) } else { ifn_2390 = nil }; var arg_2391 any = G__1901000385__21_; var arg_2392 any = Lit_39; var arg_2393 any = A_arbace_build_go_A_const_172.Invoke_O__O(config__12); if linked_2389 == nil { env__21 = ifn_2390.Invoke_O_O_O__O(arg_2391, arg_2392, arg_2393) } else { env__21 = linked_2389.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2388, arg_2391, arg_2392, arg_2393) } } else {
//line :547:1
						env__21 = G__1901000385__21_ }
//line :522:1
				var vec__1901000382__22 any; var root_2394 any = A_arbace_build_go_A_const_109.GetRawRoot__O(); var linked_2395 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2394, A_arbace_build_go_run_A_fn_class); var ifn_2396 lang.IFn


























				if linked_2395 == nil { ifn_2396 = lang.IFn_Cast(root_2394) } else { ifn_2396 = nil }; var arg_2397 any = cmd__20; var arg_2398 any = mod__17; var arg_2399 any = env__21; var arg_2400 any = jrt.Boolean_TRUE.Ref(); if linked_2395 == nil { vec__1901000382__22 = ifn_2396.Invoke_O_O_O_O__O(arg_2397, arg_2398, arg_2399, arg_2400) } else { vec__1901000382__22 = linked_2395.(*A_arbace_build_go_run_A).Invoke_O_O_O_O_O__O(root_2394, arg_2397, arg_2398, arg_2399, arg_2400) }
//line :522:1
				var status__23 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1901000382__22, lang.RT_IntCast_J__I_NoInit(0), nil); tmp8 = status__23 }; return nil }(); if tmp_QMARK___13 {





























					var root_2401 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2402 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2401, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2403 lang.IFn; if linked_2402 == nil { ifn_2403 = lang.IFn_Cast(root_2401) } else { ifn_2403 = nil }; var arg_2404 any = work__14; if linked_2402 == nil { ifn_2403.Invoke_O__O(arg_2404) } else { linked_2402.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2401, arg_2404) } }; if /*line :522:1*/ tmp23 != nil { panic(tmp23) }; return tmp8 }































func A_arbace_build_go__main_A_New() *A_arbace_build_go__main_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_A{}; t.Ctor(); return t }
//line :554:1
func (t *A_arbace_build_go__main_A) Ctor() {}
//line :554:1
func (t *A_arbace_build_go__main_A) DoInvoke_O_O__O(self, argv__0 any) any { { var goroot__2 any; var or__1927000174__auto____2 any = jrt.System_Getenv_String__String(Lit_1).Ref()
										if jrt.J2g_Truth(or__1927000174__auto____2) { goroot__2 = or__1927000174__auto____2 } else { goroot__2 = Lit_2 }
//line :554:1
	var usage__3 any = lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_3, Lit_4), jrt.RefArrayOf(jrt.Object_class, nil, nil)).Ref(); var as__4 any = argv__0; var opts__5 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, A_arbace_build_go_A_const_174, Lit_5, A_arbace_build_go_A_const_145, goroot__2)); L1: for { var G__1901000387__6_ any; var root_2416 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2417 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2416, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2418 lang.IFn




		if linked_2417 == nil { ifn_2418 = lang.IFn_Cast(root_2416) } else { ifn_2418 = nil }; var arg_2419 any = as__4; if linked_2417 == nil { G__1901000387__6_ = ifn_2418.Invoke_O__O(arg_2419) } else { G__1901000387__6_ = linked_2417.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2416, arg_2419) }; switch lang.Util_Hash_O__I_NoInit(G__1901000387__6_) >> 4 & 63 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_6) {











			var tmp1 any; var root_2490 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2491 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2490, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2492 lang.IFn; if linked_2491 == nil { ifn_2492 = lang.IFn_Cast(root_2490) } else { ifn_2492 = nil }; var arg_2493 any = as__4; if linked_2491 == nil { tmp1 = ifn_2492.Invoke_O__O(arg_2493) } else { tmp1 = linked_2491.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2490, arg_2493) }; var tmp2 any = tmp1; var tmp3 any; var root_2494 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2495 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2494, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2496 lang.IFn; if linked_2495 == nil { ifn_2496 = lang.IFn_Cast(root_2494) } else { ifn_2496 = nil }; var arg_2497 any = opts__5; var arg_2498 any = A_arbace_build_go_A_const_123; var arg_2499 any; var root_2500 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2501 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2500, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2502 lang.IFn; if linked_2501 == nil { ifn_2502 = lang.IFn_Cast(root_2500) } else { ifn_2502 = nil }; var arg_2503 any = as__4; if linked_2501 == nil { arg_2499 = ifn_2502.Invoke_O__O(arg_2503) } else { arg_2499 = linked_2501.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2500, arg_2503) }; if linked_2495 == nil { tmp3 = ifn_2496.Invoke_O_O_O__O(arg_2497, arg_2498, arg_2499) } else { tmp3 = linked_2495.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2494, arg_2497, arg_2498, arg_2499) }; as__4, opts__5 = tmp2, tmp3; continue L1 }
//line :559:1
		case 6: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_7) {









			var tmp4 any; var root_2504 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2505 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2504, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2506 lang.IFn; if linked_2505 == nil { ifn_2506 = lang.IFn_Cast(root_2504) } else { ifn_2506 = nil }; var arg_2507 any = as__4; if linked_2505 == nil { tmp4 = ifn_2506.Invoke_O__O(arg_2507) } else { tmp4 = linked_2505.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2504, arg_2507) }; var tmp5 any = tmp4; var tmp6 any; var root_2508 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2509 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2508, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2510 lang.IFn; if linked_2509 == nil { ifn_2510 = lang.IFn_Cast(root_2508) } else { ifn_2510 = nil }; var arg_2511 any = opts__5; var arg_2512 any = A_arbace_build_go_A_const_175; var arg_2513 any = jrt.Boolean_TRUE.Ref(); if linked_2509 == nil { tmp6 = ifn_2510.Invoke_O_O_O__O(arg_2511, arg_2512, arg_2513) } else { tmp6 = linked_2509.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2508, arg_2511, arg_2512, arg_2513) }; as__4, opts__5 = tmp5, tmp6; continue L1 }
//line :559:1
		case 8: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_8) {










			var tmp7 any; var root_2514 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2515 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2514, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2516 lang.IFn; if linked_2515 == nil { ifn_2516 = lang.IFn_Cast(root_2514) } else { ifn_2516 = nil }; var arg_2517 any = as__4; if linked_2515 == nil { tmp7 = ifn_2516.Invoke_O__O(arg_2517) } else { tmp7 = linked_2515.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2514, arg_2517) }; var tmp8 any = tmp7; var tmp9 any; var root_2518 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2519 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2518, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2520 lang.IFn; if linked_2519 == nil { ifn_2520 = lang.IFn_Cast(root_2518) } else { ifn_2520 = nil }; var arg_2521 any = opts__5; var arg_2522 any = A_arbace_build_go_A_const_143; var arg_2523 any = jrt.Boolean_TRUE.Ref(); if linked_2519 == nil { tmp9 = ifn_2520.Invoke_O_O_O__O(arg_2521, arg_2522, arg_2523) } else { tmp9 = linked_2519.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2518, arg_2521, arg_2522, arg_2523) }; as__4, opts__5 = tmp8, tmp9; continue L1 }
//line :559:1
		case 11: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_9) {






			var tmp10 any; var root_2524 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2525 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2524, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2526 lang.IFn; if linked_2525 == nil { ifn_2526 = lang.IFn_Cast(root_2524) } else { ifn_2526 = nil }; var arg_2527 any = as__4; if linked_2525 == nil { tmp10 = ifn_2526.Invoke_O__O(arg_2527) } else { tmp10 = linked_2525.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2524, arg_2527) }; var tmp11 any = tmp10; var tmp12 any; var root_2528 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2529 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2528, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2530 lang.IFn; if linked_2529 == nil { ifn_2530 = lang.IFn_Cast(root_2528) } else { ifn_2530 = nil }; var arg_2531 any = opts__5; var arg_2532 any = A_arbace_build_go_A_const_164; var arg_2533 any; var root_2534 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2535 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2534, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2536 lang.IFn; if linked_2535 == nil { ifn_2536 = lang.IFn_Cast(root_2534) } else { ifn_2536 = nil }; var arg_2537 any = as__4; if linked_2535 == nil { arg_2533 = ifn_2536.Invoke_O__O(arg_2537) } else { arg_2533 = linked_2535.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2534, arg_2537) }; if linked_2529 == nil { tmp12 = ifn_2530.Invoke_O_O_O__O(arg_2531, arg_2532, arg_2533) } else { tmp12 = linked_2529.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2528, arg_2531, arg_2532, arg_2533) }; as__4, opts__5 = tmp11, tmp12; continue L1 }
//line :559:1
		case 12: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_10) {




			var tmp13 any; var root_2538 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2539 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2538, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2540 lang.IFn; if linked_2539 == nil { ifn_2540 = lang.IFn_Cast(root_2538) } else { ifn_2540 = nil }; var arg_2541 any = as__4; if linked_2539 == nil { tmp13 = ifn_2540.Invoke_O__O(arg_2541) } else { tmp13 = linked_2539.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2538, arg_2541) }; var tmp14 any = tmp13; var tmp15 any; var root_2542 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2543 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2542, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2544 lang.IFn; if linked_2543 == nil { ifn_2544 = lang.IFn_Cast(root_2542) } else { ifn_2544 = nil }; var arg_2545 any = opts__5; var arg_2546 any = A_arbace_build_go_A_const_138; var arg_2547 any; var root_2548 any = A_arbace_build_go_A_const_189.GetRawRoot__O(); var linked_2549 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2548, aot_arbace_core.A_arbace_core_keyword_A_fn_class); var ifn_2550 lang.IFn; if linked_2549 == nil { ifn_2550 = lang.IFn_Cast(root_2548) } else { ifn_2550 = nil }; var arg_2551 any; var root_2552 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2553 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2552, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2554 lang.IFn; if linked_2553 == nil { ifn_2554 = lang.IFn_Cast(root_2552) } else { ifn_2554 = nil }; var arg_2555 any = as__4; if linked_2553 == nil { arg_2551 = ifn_2554.Invoke_O__O(arg_2555) } else { arg_2551 = linked_2553.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2552, arg_2555) }; if linked_2549 == nil { arg_2547 = ifn_2550.Invoke_O__O(arg_2551) } else { arg_2547 = linked_2549.(*aot_arbace_core.A_arbace_core_keyword_A).Invoke_O_O__O(root_2548, arg_2551) }; if linked_2543 == nil { tmp15 = ifn_2544.Invoke_O_O_O__O(arg_2545, arg_2546, arg_2547) } else { tmp15 = linked_2543.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2542, arg_2545, arg_2546, arg_2547) }; as__4, opts__5 = tmp14, tmp15; continue L1 }
//line :559:1
		case 26: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_11) {













			var tmp16 any; var root_2556 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2557 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2556, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2558 lang.IFn; if linked_2557 == nil { ifn_2558 = lang.IFn_Cast(root_2556) } else { ifn_2558 = nil }; var arg_2559 any = as__4; if linked_2557 == nil { tmp16 = ifn_2558.Invoke_O__O(arg_2559) } else { tmp16 = linked_2557.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2556, arg_2559) }; var tmp17 any = tmp16; var tmp18 any; var root_2560 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2561 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2560, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2562 lang.IFn; if linked_2561 == nil { ifn_2562 = lang.IFn_Cast(root_2560) } else { ifn_2562 = nil }; var arg_2563 any = opts__5; var arg_2564 any = A_arbace_build_go_A_const_146; var arg_2565 any; var root_2566 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2567 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2566, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2568 lang.IFn; if linked_2567 == nil { ifn_2568 = lang.IFn_Cast(root_2566) } else { ifn_2568 = nil }; var arg_2569 any = as__4; if linked_2567 == nil { arg_2565 = ifn_2568.Invoke_O__O(arg_2569) } else { arg_2565 = linked_2567.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2566, arg_2569) }; if linked_2561 == nil { tmp18 = ifn_2562.Invoke_O_O_O__O(arg_2563, arg_2564, arg_2565) } else { tmp18 = linked_2561.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2560, arg_2563, arg_2564, arg_2565) }; as__4, opts__5 = tmp17, tmp18; continue L1 }
//line :559:1
		case 30: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_12) {



			var tmp19 any; var root_2570 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2571 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2570, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2572 lang.IFn; if linked_2571 == nil { ifn_2572 = lang.IFn_Cast(root_2570) } else { ifn_2572 = nil }; var arg_2573 any = as__4; if linked_2571 == nil { tmp19 = ifn_2572.Invoke_O__O(arg_2573) } else { tmp19 = linked_2571.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2570, arg_2573) }; var tmp20 any = tmp19; var tmp21 any; var root_2574 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2575 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2574, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2576 lang.IFn; if linked_2575 == nil { ifn_2576 = lang.IFn_Cast(root_2574) } else { ifn_2576 = nil }; var arg_2577 any = opts__5; var arg_2578 any = A_arbace_build_go_A_const_176; var arg_2579 any; var root_2580 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2581 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2580, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2582 lang.IFn; if linked_2581 == nil { ifn_2582 = lang.IFn_Cast(root_2580) } else { ifn_2582 = nil }; var arg_2583 any = as__4; if linked_2581 == nil { arg_2579 = ifn_2582.Invoke_O__O(arg_2583) } else { arg_2579 = linked_2581.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2580, arg_2583) }; if linked_2575 == nil { tmp21 = ifn_2576.Invoke_O_O_O__O(arg_2577, arg_2578, arg_2579) } else { tmp21 = linked_2575.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2574, arg_2577, arg_2578, arg_2579) }; as__4, opts__5 = tmp20, tmp21; continue L1 }
//line :559:1
		case 31: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_13) {
			var tmp22 any; var root_2584 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2585 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2584, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2586 lang.IFn; if linked_2585 == nil { ifn_2586 = lang.IFn_Cast(root_2584) } else { ifn_2586 = nil }; var arg_2587 any = as__4; if linked_2585 == nil { tmp22 = ifn_2586.Invoke_O__O(arg_2587) } else { tmp22 = linked_2585.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2584, arg_2587) }; var tmp23 any = tmp22; var tmp24 any; var root_2588 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2589 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2588, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2590 lang.IFn; if linked_2589 == nil { ifn_2590 = lang.IFn_Cast(root_2588) } else { ifn_2590 = nil }; var arg_2591 any = opts__5; var arg_2592 any = A_arbace_build_go_A_const_174; var arg_2593 any; var root_2594 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2595 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2594, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2596 lang.IFn; if linked_2595 == nil { ifn_2596 = lang.IFn_Cast(root_2594) } else { ifn_2596 = nil }; var arg_2597 any = as__4; if linked_2595 == nil { arg_2593 = ifn_2596.Invoke_O__O(arg_2597) } else { arg_2593 = linked_2595.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2594, arg_2597) }; if linked_2589 == nil { tmp24 = ifn_2590.Invoke_O_O_O__O(arg_2591, arg_2592, arg_2593) } else { tmp24 = linked_2589.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2588, arg_2591, arg_2592, arg_2593) }; as__4, opts__5 = tmp23, tmp24; continue L1 }
//line :559:1
		case 33: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_14) {





			var tmp25 any; var root_2598 any = A_arbace_build_go_A_const_51.GetRawRoot__O(); var linked_2599 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2598, aot_arbace_core.A_arbace_core_next__1927000010_A_fn_class); var ifn_2600 lang.IFn; if linked_2599 == nil { ifn_2600 = lang.IFn_Cast(root_2598) } else { ifn_2600 = nil }; var arg_2601 any = as__4; if linked_2599 == nil { tmp25 = ifn_2600.Invoke_O__O(arg_2601) } else { tmp25 = linked_2599.(*aot_arbace_core.A_arbace_core_next__1927000010_A).Invoke_O_O__O(root_2598, arg_2601) }; var tmp26 any = tmp25; var tmp27 any; var root_2602 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2603 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2602, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2604 lang.IFn; if linked_2603 == nil { ifn_2604 = lang.IFn_Cast(root_2602) } else { ifn_2604 = nil }; var arg_2605 any = opts__5; var arg_2606 any = A_arbace_build_go_A_const_139; var arg_2607 any = jrt.Boolean_TRUE.Ref(); if linked_2603 == nil { tmp27 = ifn_2604.Invoke_O_O_O__O(arg_2605, arg_2606, arg_2607) } else { tmp27 = linked_2603.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2602, arg_2605, arg_2606, arg_2607) }; as__4, opts__5 = tmp26, tmp27; continue L1 }
//line :559:1
		case 38: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_15) {

			var tmp28 any; var root_2608 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2609 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2608, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2610 lang.IFn; if linked_2609 == nil { ifn_2610 = lang.IFn_Cast(root_2608) } else { ifn_2610 = nil }; var arg_2611 any = as__4; if linked_2609 == nil { tmp28 = ifn_2610.Invoke_O__O(arg_2611) } else { tmp28 = linked_2609.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2608, arg_2611) }; var tmp29 any = tmp28; var tmp30 any; var root_2612 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2613 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2612, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2614 lang.IFn; if linked_2613 == nil { ifn_2614 = lang.IFn_Cast(root_2612) } else { ifn_2614 = nil }; var arg_2615 any = opts__5; var arg_2616 any = A_arbace_build_go_A_const_144; var arg_2617 any; var root_2618 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2619 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2618, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2620 lang.IFn; if linked_2619 == nil { ifn_2620 = lang.IFn_Cast(root_2618) } else { ifn_2620 = nil }; var arg_2621 any = as__4; if linked_2619 == nil { arg_2617 = ifn_2620.Invoke_O__O(arg_2621) } else { arg_2617 = linked_2619.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2618, arg_2621) }; if linked_2613 == nil { tmp30 = ifn_2614.Invoke_O_O_O__O(arg_2615, arg_2616, arg_2617) } else { tmp30 = linked_2613.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2612, arg_2615, arg_2616, arg_2617) }; as__4, opts__5 = tmp29, tmp30; continue L1 }
//line :559:1
		case 40: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_16) {


			var tmp31 any; var root_2622 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2623 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2622, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2624 lang.IFn; if linked_2623 == nil { ifn_2624 = lang.IFn_Cast(root_2622) } else { ifn_2624 = nil }; var arg_2625 any = as__4; if linked_2623 == nil { tmp31 = ifn_2624.Invoke_O__O(arg_2625) } else { tmp31 = linked_2623.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2622, arg_2625) }; var tmp32 any = tmp31; var tmp33 any; var root_2626 any = A_arbace_build_go_A_const_77.GetRawRoot__O(); var linked_2627 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2626, aot_arbace_core.A_arbace_core_update_A_fn_class); var ifn_2628 lang.IFn; if linked_2627 == nil { ifn_2628 = lang.IFn_Cast(root_2626) } else { ifn_2628 = nil }; var arg_2629 any = opts__5; var arg_2630 any = A_arbace_build_go_A_const_120; var arg_2631 any; var root_2633 any = A_arbace_build_go_A_const_190.GetRawRoot__O(); var linked_2634 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2633, aot_arbace_core.A_arbace_core_fnil_A_fn_class); var ifn_2635 lang.IFn; if linked_2634 == nil { ifn_2635 = lang.IFn_Cast(root_2633) } else { ifn_2635 = nil }; var arg_2636 any = A_arbace_build_go_A_const_8.GetRawRoot__O(); var arg_2637 any = lang.PersistentVector_EMPTY.Ref(); if linked_2634 == nil { arg_2631 = ifn_2635.Invoke_O_O__O(arg_2636, arg_2637) } else { arg_2631 = linked_2634.(*aot_arbace_core.A_arbace_core_fnil_A).Invoke_O_O_O__O(root_2633, arg_2636, arg_2637) }; var arg_2632 any; var root_2638 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2639 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2638, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2640 lang.IFn; if linked_2639 == nil { ifn_2640 = lang.IFn_Cast(root_2638) } else { ifn_2640 = nil }; var arg_2641 any = as__4; if linked_2639 == nil { arg_2632 = ifn_2640.Invoke_O__O(arg_2641) } else { arg_2632 = linked_2639.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2638, arg_2641) }; if linked_2627 == nil { tmp33 = ifn_2628.Invoke_O_O_O_O__O(arg_2629, arg_2630, arg_2631, arg_2632) } else { tmp33 = linked_2627.(*aot_arbace_core.A_arbace_core_update_A).Invoke_O_O_O_O_O__O(root_2626, arg_2629, arg_2630, arg_2631, arg_2632) }; as__4, opts__5 = tmp32, tmp33; continue L1 }
//line :559:1
		case 43: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_17) {







			var tmp34 any; var root_2642 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2643 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2642, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2644 lang.IFn; if linked_2643 == nil { ifn_2644 = lang.IFn_Cast(root_2642) } else { ifn_2644 = nil }; var arg_2645 any = as__4; if linked_2643 == nil { tmp34 = ifn_2644.Invoke_O__O(arg_2645) } else { tmp34 = linked_2643.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2642, arg_2645) }; var tmp35 any = tmp34; var tmp36 any; var root_2646 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2647 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2646, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2648 lang.IFn; if linked_2647 == nil { ifn_2648 = lang.IFn_Cast(root_2646) } else { ifn_2648 = nil }; var arg_2649 any = opts__5; var arg_2650 any = A_arbace_build_go_A_const_170; var arg_2651 any; var root_2652 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2653 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2652, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2654 lang.IFn; if linked_2653 == nil { ifn_2654 = lang.IFn_Cast(root_2652) } else { ifn_2654 = nil }; var arg_2655 any = as__4; if linked_2653 == nil { arg_2651 = ifn_2654.Invoke_O__O(arg_2655) } else { arg_2651 = linked_2653.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2652, arg_2655) }; if linked_2647 == nil { tmp36 = ifn_2648.Invoke_O_O_O__O(arg_2649, arg_2650, arg_2651) } else { tmp36 = linked_2647.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2646, arg_2649, arg_2650, arg_2651) }; as__4, opts__5 = tmp35, tmp36; continue L1 }
//line :559:1
		case 44: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_18) {














			var tmp37 any; var root_2656 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2657 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2656, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2658 lang.IFn; if linked_2657 == nil { ifn_2658 = lang.IFn_Cast(root_2656) } else { ifn_2658 = nil }; var arg_2659 any = as__4; if linked_2657 == nil { tmp37 = ifn_2658.Invoke_O__O(arg_2659) } else { tmp37 = linked_2657.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2656, arg_2659) }; var tmp38 any = tmp37; var tmp39 any; var root_2660 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2661 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2660, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2662 lang.IFn; if linked_2661 == nil { ifn_2662 = lang.IFn_Cast(root_2660) } else { ifn_2662 = nil }; var arg_2663 any = opts__5; var arg_2664 any = A_arbace_build_go_A_const_121; var arg_2665 any; var root_2666 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2667 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2666, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2668 lang.IFn; if linked_2667 == nil { ifn_2668 = lang.IFn_Cast(root_2666) } else { ifn_2668 = nil }; var arg_2669 any = as__4; if linked_2667 == nil { arg_2665 = ifn_2668.Invoke_O__O(arg_2669) } else { arg_2665 = linked_2667.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2666, arg_2669) }; if linked_2661 == nil { tmp39 = ifn_2662.Invoke_O_O_O__O(arg_2663, arg_2664, arg_2665) } else { tmp39 = linked_2661.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2660, arg_2663, arg_2664, arg_2665) }; as__4, opts__5 = tmp38, tmp39; continue L1 }
//line :559:1
		case 53: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_19) {












			var tmp40 any; var root_2670 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2671 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2670, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2672 lang.IFn; if linked_2671 == nil { ifn_2672 = lang.IFn_Cast(root_2670) } else { ifn_2672 = nil }; var arg_2673 any = as__4; if linked_2671 == nil { tmp40 = ifn_2672.Invoke_O__O(arg_2673) } else { tmp40 = linked_2671.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2670, arg_2673) }; var tmp41 any = tmp40; var tmp42 any; var root_2674 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2675 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2674, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2676 lang.IFn; if linked_2675 == nil { ifn_2676 = lang.IFn_Cast(root_2674) } else { ifn_2676 = nil }; var arg_2677 any = opts__5; var arg_2678 any = A_arbace_build_go_A_const_122; var arg_2679 any; var root_2680 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2681 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2680, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2682 lang.IFn; if linked_2681 == nil { ifn_2682 = lang.IFn_Cast(root_2680) } else { ifn_2682 = nil }; var arg_2683 any = as__4; if linked_2681 == nil { arg_2679 = ifn_2682.Invoke_O__O(arg_2683) } else { arg_2679 = linked_2681.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2680, arg_2683) }; if linked_2675 == nil { tmp42 = ifn_2676.Invoke_O_O_O__O(arg_2677, arg_2678, arg_2679) } else { tmp42 = linked_2675.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2674, arg_2677, arg_2678, arg_2679) }; as__4, opts__5 = tmp41, tmp42; continue L1 }
//line :559:1
		case 59: if lang.Util_Equiv_O_O__Z_NoInit(G__1901000387__6_, Lit_20) {








			var tmp43 any; var root_2684 any = A_arbace_build_go_A_const_187.GetRawRoot__O(); var linked_2685 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2684, aot_arbace_core.A_arbace_core_nnext__1927000024_A_fn_class); var ifn_2686 lang.IFn; if linked_2685 == nil { ifn_2686 = lang.IFn_Cast(root_2684) } else { ifn_2686 = nil }; var arg_2687 any = as__4; if linked_2685 == nil { tmp43 = ifn_2686.Invoke_O__O(arg_2687) } else { tmp43 = linked_2685.(*aot_arbace_core.A_arbace_core_nnext__1927000024_A).Invoke_O_O__O(root_2684, arg_2687) }; var tmp44 any = tmp43; var tmp45 any; var root_2688 any = A_arbace_build_go_A_const_63.GetRawRoot__O(); var linked_2689 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2688, aot_arbace_core.A_arbace_core_assoc__1927000040_A_fn_class); var ifn_2690 lang.IFn; if linked_2689 == nil { ifn_2690 = lang.IFn_Cast(root_2688) } else { ifn_2690 = nil }; var arg_2691 any = opts__5; var arg_2692 any = A_arbace_build_go_A_const_171; var arg_2693 any; var root_2694 any = A_arbace_build_go_A_const_188.GetRawRoot__O(); var linked_2695 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2694, aot_arbace_core.A_arbace_core_second__1927000016_A_fn_class); var ifn_2696 lang.IFn; if linked_2695 == nil { ifn_2696 = lang.IFn_Cast(root_2694) } else { ifn_2696 = nil }; var arg_2697 any = as__4; if linked_2695 == nil { arg_2693 = ifn_2696.Invoke_O__O(arg_2697) } else { arg_2693 = linked_2695.(*aot_arbace_core.A_arbace_core_second__1927000016_A).Invoke_O_O__O(root_2694, arg_2697) }; if linked_2689 == nil { tmp45 = ifn_2690.Invoke_O_O_O__O(arg_2691, arg_2692, arg_2693) } else { tmp45 = linked_2689.(*aot_arbace_core.A_arbace_core_assoc__1927000040_A).Invoke_O_O_O_O__O(root_2688, arg_2691, arg_2692, arg_2693) }; as__4, opts__5 = tmp44, tmp45; continue L1 }
//line :559:1
		default:
		}















		var tmp46 any; var and__1927000168__auto____7 bool = lang.Util_Equiv_J_J__Z_NoInit(1, int64(lang.RT_Count_O__I_NoInit(as__4))); if and__1927000168__auto____7 { var and__1927000168__auto____8 any; var root_2698 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2699 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2698, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2700 lang.IFn; if linked_2699 == nil { ifn_2700 = lang.IFn_Cast(root_2698) } else { ifn_2700 = nil }; var arg_2701 any; var root_2702 any = A_arbace_build_go_A_const_128.GetRawRoot__O(); var linked_2703 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2702, aot_arbace_string.A_arbace_string_starts_with_QMARK__A_fn_class); var ifn_2704 lang.IFn; if linked_2703 == nil { ifn_2704 = lang.IFn_Cast(root_2702) } else { ifn_2704 = nil }; var arg_2705 any; var root_2707 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2708 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2707, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2709 lang.IFn; if linked_2708 == nil { ifn_2709 = lang.IFn_Cast(root_2707) } else { ifn_2709 = nil }; var arg_2710 any = as__4; if linked_2708 == nil { arg_2705 = ifn_2709.Invoke_O__O(arg_2710) } else { arg_2705 = linked_2708.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2707, arg_2710) }; var arg_2706 any = Lit_21; if linked_2703 == nil { arg_2701 = ifn_2704.Invoke_O_O__O(arg_2705, arg_2706) } else { arg_2701 = linked_2703.(*aot_arbace_string.A_arbace_string_starts_with_QMARK__A).Invoke_O_O_O__O(root_2702, arg_2705, arg_2706) }; if linked_2699 == nil { and__1927000168__auto____8 = ifn_2700.Invoke_O__O(arg_2701) } else { and__1927000168__auto____8 = linked_2699.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2698, arg_2701) }; if jrt.J2g_Truth(and__1927000168__auto____8) { var tmp47 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_191); var and__1927000168__auto____9 any = tmp47.Invoke_O__O(A_arbace_build_go_A_const_174.Invoke_O__O(opts__5)); if jrt.J2g_Truth(and__1927000168__auto____9) { var and__1927000168__auto____10 any; var root_2711 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_2712 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2711, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2713 lang.IFn

			if linked_2712 == nil { ifn_2713 = lang.IFn_Cast(root_2711) } else { ifn_2713 = nil }; var arg_2714 any = A_arbace_build_go_A_const_192; var arg_2715 any = A_arbace_build_go_A_const_144.Invoke_O__O(opts__5); if linked_2712 == nil { and__1927000168__auto____10 = ifn_2713.Invoke_O_O__O(arg_2714, arg_2715) } else { and__1927000168__auto____10 = linked_2712.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2711, arg_2714, arg_2715) }
//line :576:1
			if jrt.J2g_Truth(and__1927000168__auto____10) { var and__1927000168__auto____11 any; var root_2716 any = A_arbace_build_go_A_const_27.GetRawRoot__O(); var linked_2717 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2716, aot_arbace_core.A_arbace_core_contains_QMARK__A_fn_class); var ifn_2718 lang.IFn


				if linked_2717 == nil { ifn_2718 = lang.IFn_Cast(root_2716) } else { ifn_2718 = nil }; var arg_2719 any = A_arbace_build_go_A_const_193; var arg_2720 any = A_arbace_build_go_A_const_138.Invoke_O__O(opts__5); if linked_2717 == nil { and__1927000168__auto____11 = ifn_2718.Invoke_O_O__O(arg_2719, arg_2720) } else { and__1927000168__auto____11 = linked_2717.(*aot_arbace_core.A_arbace_core_contains_QMARK__A).Invoke_O_O_O__O(root_2716, arg_2719, arg_2720) }
//line :576:1
				if jrt.J2g_Truth(and__1927000168__auto____11) { var or__1927000174__auto____12 any; var root_2721 any = A_arbace_build_go_A_const_17.GetRawRoot__O(); var linked_2722 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2721, aot_arbace_core.A_arbace_core_not_A_fn_class); var ifn_2723 lang.IFn



					if linked_2722 == nil { ifn_2723 = lang.IFn_Cast(root_2721) } else { ifn_2723 = nil }; var arg_2724 any = A_arbace_build_go_A_const_175.Invoke_O__O(opts__5); if linked_2722 == nil { or__1927000174__auto____12 = ifn_2723.Invoke_O__O(arg_2724) } else { or__1927000174__auto____12 = linked_2722.(*aot_arbace_core.A_arbace_core_not_A).Invoke_O_O__O(root_2721, arg_2724) }; if jrt.J2g_Truth(or__1927000174__auto____12) { tmp46 = or__1927000174__auto____12 } else { tmp46 = A_arbace_build_go_A_const_164.Invoke_O__O(opts__5) } } else {
//line :576:1
						tmp46 = and__1927000168__auto____11 } } else { tmp46 = and__1927000168__auto____10 } } else { tmp46 = and__1927000168__auto____9 } } else { tmp46 = and__1927000168__auto____8 } } else { tmp46 = jrt.Boolean_ValueOf_Z__Boolean_NoInit(and__1927000168__auto____7).Ref() }; if jrt.J2g_Truth(tmp46) { } else {




							var root_2733 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2734 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2733, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2735 lang.IFn; if linked_2734 == nil { ifn_2735 = lang.IFn_Cast(root_2733) } else { ifn_2735 = nil }; var tmp48 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()); var tmp49 any = A_arbace_build_go_A_const_185; var arg_2736 any = tmp48.Invoke_O_O__O(tmp49, A_arbace_build_go_A_const_186.Get__O()); if linked_2734 == nil { ifn_2735.Invoke_O__O(arg_2736) } else { linked_2734.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2733, arg_2736) }; var tmp50 any = A_arbace_build_go__main_fn__1901000388_A_New_O(usage__3); var tmp51 *jrt.Class; var fncls__2732 *jrt.Class = A_arbace_build_go__main_fn__1901000388_A_fn_class; if fncls__2732 == nil { var fncls__2732d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_22, false); A_arbace_build_go__main_fn__1901000388_A_fn_class = fncls__2732d; tmp51 = fncls__2732d } else { tmp51 = fncls__2732 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp50, tmp51, nil).Invoke__O()
							jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2)) }
//line :559:1
		var dir__7 any; var tmp52 any; var root_2421 any = A_arbace_build_go_A_const_20.GetRawRoot__O(); var linked_2422 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2421, aot_arbace_core.A_arbace_core_first__1927000008_A_fn_class); var ifn_2423 lang.IFn























		if linked_2422 == nil { ifn_2423 = lang.IFn_Cast(root_2421) } else { ifn_2423 = nil }; var arg_2424 any = as__4; if linked_2422 == nil { tmp52 = ifn_2423.Invoke_O__O(arg_2424) } else { tmp52 = linked_2422.(*aot_arbace_core.A_arbace_core_first__1927000008_A).Invoke_O_O__O(root_2421, arg_2424) }
//line :559:1
		dir__7 = jrt.File_New_String(jrt.String_Cast(tmp52)); var status__8 any; var tmp53 any = A_arbace_build_go__main_fn__1901000390_A_New_O_O_O(dir__7, goroot__2, opts__5); var tmp54 *jrt.Class
		var fncls__2489 /*line :559:1*/*jrt.Class = A_arbace_build_go__main_fn__1901000390_A_fn_class
























		if fncls__2489 == nil { var fncls__2489d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_23, false); A_arbace_build_go__main_fn__1901000390_A_fn_class = fncls__2489d; tmp54 = fncls__2489d } else { tmp54 = fncls__2489 }; status__8 = lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp53, tmp54, nil).Invoke__O()















		var root_2742 any = A_arbace_build_go_A_const_194.GetRawRoot__O(); var linked_2743 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2742, aot_arbace_core.A_arbace_core_shutdown_agents_A_fn_class); var ifn_2744 lang.IFn; if linked_2743 == nil { ifn_2744 = lang.IFn_Cast(root_2742) } else { ifn_2744 = nil }; if linked_2743 == nil { ifn_2744.Invoke__O() } else { linked_2743.(*aot_arbace_core.A_arbace_core_shutdown_agents_A).Invoke_O__O(root_2742) }
		jrt.System_Exit_I__V(lang.RT_IntCast_O__I_NoInit(status__8)); return nil } }; /*line :554:1*/panic("j2g: unreachable") }


























func A_arbace_build_go__main_fn__1901000388_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000388_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000388_A{}; t.Ctor_O(p0); return t }
//line :581:1
func (t *A_arbace_build_go__main_fn__1901000388_A) Ctor_O(c__usage any) { t.F_usage = c__usage }
//line :581:1
func (t *A_arbace_build_go__main_fn__1901000388_A) Invoke_O__O(self any) any { var tmp1 any; tmp4 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_184.GetRawRoot__O()); var tmp3 any; var t_ any = t.F_usage; t.F_usage = nil; tmp3 = t_; tmp1 = tmp2.Invoke_O__O(tmp3) }; return nil }(); var root_2729 any = A_arbace_build_go_A_const_70.GetRawRoot__O(); var linked_2730 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2729, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2731 lang.IFn; if linked_2730 == nil { ifn_2731 = lang.IFn_Cast(root_2729) } else { ifn_2731 = nil }; if linked_2730 == nil { ifn_2731.Invoke__O() } else { linked_2730.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2729) }; if tmp4 != nil { panic(tmp4) }; return tmp1 }


func A_arbace_build_go__main_fn__1901000390_A_New_O_O_O(p0, p1, p2 any) *A_arbace_build_go__main_fn__1901000390_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000390_A{}; t.Ctor_O_O_O(p0, p1, p2); return t }
//line :584:1
func (t *A_arbace_build_go__main_fn__1901000390_A) Ctor_O_O_O(c__dir, c__goroot, c__opts any) { t.F_dir = c__dir; t.F_goroot = c__goroot; t.F_opts = c__opts }
//line :584:1
func (t *A_arbace_build_go__main_fn__1901000390_A) Invoke_O__O(self any) any { var tmp1 any; tmp12 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc)
										if jrt.J2g_Truth(A_arbace_build_go_A_const_175.Invoke_O__O(t.F_opts)) { var prog__3 any; var root_2425 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2426 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2425, A_arbace_build_go_program_A_fn_class); var ifn_2427 lang.IFn
											if linked_2426 == nil { ifn_2427 = lang.IFn_Cast(root_2425) } else { ifn_2427 = nil }; var arg_2428 any = t.F_dir; var arg_2429 any; var t_ any = t.F_goroot; t.F_goroot = nil; arg_2429 = t_; var tmp2 any = A_arbace_build_go_A_const_119; var tmp3 any = jrt.Boolean_TRUE.Ref(); var tmp4 any = A_arbace_build_go_A_const_123; var tmp5 any = A_arbace_build_go_A_const_123.Invoke_O__O(t.F_opts); var tmp6 any = A_arbace_build_go_A_const_120; var arg_2430 any = lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp2, tmp3, tmp4, tmp5, tmp6, A_arbace_build_go_A_const_120.Invoke_O__O(t.F_opts))); if linked_2426 == nil { prog__3 = ifn_2427.Invoke_O_O_O__O(arg_2428, arg_2429, arg_2430) } else { prog__3 = linked_2426.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2425, arg_2428, arg_2429, arg_2430) }
//line :585:1
		var mod__4 any; var tmp7 any; var root_2431 any = A_arbace_build_go_A_const_29.GetRawRoot__O(); var linked_2432 any = lang.Compiler_AOTRestFn_Linked_O_Class__O(root_2431, aot_arbace_core.A_arbace_core_str_A_fn_class); var ifn_2433 lang.IFn

		if linked_2432 == nil { ifn_2433 = lang.IFn_Cast(root_2431) } else { ifn_2433 = nil }; var arg_2434 any = A_arbace_build_go_A_const_164.Invoke_O__O(t.F_opts); if linked_2432 == nil { tmp7 = ifn_2433.Invoke_O__O(arg_2434) } else { tmp7 = linked_2432.(*aot_arbace_core.A_arbace_core_str_A).Invoke_O_O__O(root_2431, arg_2434) }
//line :585:1
		mod__4 = jrt.File_New_File_String(jrt.File_New_String(jrt.String_Cast(tmp7)), Lit_24)


		if jrt.NN(jrt.File_Cast(mod__4)).Exists__Z() { var root_2457 any = A_arbace_build_go_A_const_141.GetRawRoot__O(); var linked_2458 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2457, A_arbace_build_go_delete_tree_A_fn_class); var ifn_2459 lang.IFn; if linked_2458 == nil { ifn_2459 = lang.IFn_Cast(root_2457) } else { ifn_2459 = nil }; var arg_2460 any = mod__4; if linked_2458 == nil { ifn_2459.Invoke_O__O(arg_2460) } else { linked_2458.(*A_arbace_build_go_delete_tree_A).Invoke_O_O__O(root_2457, arg_2460) } }
		var root_2461 any = A_arbace_build_go_A_const_173.GetRawRoot__O(); var linked_2462 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2461, A_arbace_build_go_print_module_A_fn_class); var ifn_2463 lang.IFn; if linked_2462 == nil { ifn_2463 = lang.IFn_Cast(root_2461) } else { ifn_2463 = nil }; var arg_2464 any = prog__3; var arg_2465 any; var t__2 any = t.F_dir; t.F_dir = nil; arg_2465 = t__2; var arg_2466 any = mod__4; var arg_2467 any; var t__3 any = t.F_opts; t.F_opts = nil; arg_2467 = t__3; if linked_2462 == nil { ifn_2463.Invoke_O_O_O_O__O(arg_2464, arg_2465, arg_2466, arg_2467) } else { linked_2462.(*A_arbace_build_go_print_module_A).Invoke_O_O_O_O_O__O(root_2461, arg_2464, arg_2465, arg_2466, arg_2467) }
//line :585:1
		tmp1 = A_arbace_build_go_A_const_134 } else { var prog_main__3 any





			if jrt.J2g_Truth(A_arbace_build_go_A_const_176.Invoke_O__O(t.F_opts)) { prog_main__3 = nil } else { var tmp8 *lang.Keyword = A_arbace_build_go_A_const_130; var tmp9 any; var root_2435 any = A_arbace_build_go_A_const_131.GetRawRoot__O(); var linked_2436 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2435, A_arbace_build_go_program_A_fn_class); var ifn_2437 lang.IFn; if linked_2436 == nil { ifn_2437 = lang.IFn_Cast(root_2435) } else { ifn_2437 = nil }; var arg_2438 any = t.F_dir; var arg_2439 any; var t__4 any = t.F_goroot; t.F_goroot = nil; arg_2439 = t__4; var arg_2440 any = t.F_opts; if linked_2436 == nil { tmp9 = ifn_2437.Invoke_O_O_O__O(arg_2438, arg_2439, arg_2440) } else { tmp9 = linked_2436.(*A_arbace_build_go_program_A).Invoke_O_O_O_O__O(root_2435, arg_2438, arg_2439, arg_2440) }; prog_main__3 = tmp8.Invoke_O__O(tmp9) }
//line :585:1
			var out__4 any; var tmp10 *jrt.Class = A_arbace_build_go_A_const_67; var tmp11 any; var or__1927000174__auto____4 any = A_arbace_build_go_A_const_176.Invoke_O__O(t.F_opts)






			if jrt.J2g_Truth(or__1927000174__auto____4) { tmp11 = or__1927000174__auto____4 } else {
				var root_2441 any = A_arbace_build_go_A_const_177.GetRawRoot__O(); var linked_2442 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2441, aot_arbace_core.A_arbace_core_last__1927000054_A_fn_class); var ifn_2443 lang.IFn; if linked_2442 == nil { ifn_2443 = lang.IFn_Cast(root_2441) } else { ifn_2443 = nil }; var arg_2444 any; var root_2445 any = A_arbace_build_go_A_const_178.GetRawRoot__O(); var linked_2446 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2445, aot_arbace_string.A_arbace_string_split_A_fn_class); var ifn_2447 lang.IFn; if linked_2446 == nil { ifn_2447 = lang.IFn_Cast(root_2445) } else { ifn_2447 = nil }; var arg_2448 any = A_arbace_build_go_A_const_46.Invoke_O__O(prog_main__3); var arg_2449 any = A_arbace_build_go_A_const_179; if linked_2446 == nil { arg_2444 = ifn_2447.Invoke_O_O__O(arg_2448, arg_2449) } else { arg_2444 = linked_2446.(*aot_arbace_string.A_arbace_string_split_A).Invoke_O_O_O__O(root_2445, arg_2448, arg_2449) }; if linked_2442 == nil { tmp11 = ifn_2443.Invoke_O__O(arg_2444) } else { tmp11 = linked_2442.(*aot_arbace_core.A_arbace_core_last__1927000054_A).Invoke_O_O__O(root_2441, arg_2444) } }
//line :585:1
			out__4 = lang.Reflector_InvokeConstructor_Class_O1__O(tmp10, jrt.RefArrayOf(jrt.Object_class, tmp11))








			var root_2450 any = A_arbace_build_go_A_const_180.GetRawRoot__O(); var linked_2451 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2450, A_arbace_build_go_build_A_fn_class); var ifn_2452 lang.IFn; if linked_2451 == nil { ifn_2452 = lang.IFn_Cast(root_2450) } else { ifn_2452 = nil }; var arg_2453 any; var t__5 any = t.F_dir; t.F_dir = nil; arg_2453 = t__5; var arg_2454 any = A_arbace_build_go_A_const_174.Invoke_O__O(t.F_opts); var arg_2455 any = out__4; var arg_2456 any; var t__6 any = t.F_opts; t.F_opts = nil; arg_2456 = t__6; if linked_2451 == nil { tmp1 = ifn_2452.Invoke_O_O_O_O__O(arg_2453, arg_2454, arg_2455, arg_2456) } else { tmp1 = linked_2451.(*A_arbace_build_go_build_A).Invoke_O_O_O_O_O__O(root_2450, arg_2453, arg_2454, arg_2455, arg_2456) } }
//line :584:1
	return nil }(); if tmp12 != nil { if lang.ExceptionInfo_InstanceOf(tmp12) { var e__3 lang.ExceptionInfo_I = lang.ExceptionInfo_Cast(tmp12); var tmp13 *lang.Keyword = A_arbace_build_go_A_const_181; var tmp14 any; var root_2468 any = A_arbace_build_go_A_const_182.GetRawRoot__O(); var linked_2469 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2468, aot_arbace_core.A_arbace_core_ex_data_A_fn_class); var ifn_2470 lang.IFn











		if linked_2469 == nil { ifn_2470 = lang.IFn_Cast(root_2468) } else { ifn_2470 = nil }; var arg_2471 any = e__3; if linked_2469 == nil { tmp14 = ifn_2470.Invoke_O__O(arg_2471) } else { tmp14 = linked_2469.(*aot_arbace_core.A_arbace_core_ex_data_A).Invoke_O_O__O(root_2468, arg_2471) }; if jrt.J2g_Truth(tmp13.Invoke_O__O(tmp14)) {
			var root_2480 any = A_arbace_build_go_A_const_71.GetRawRoot__O(); var linked_2481 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2480, aot_arbace_core.A_arbace_core_push_thread_bindings_A_fn_class); var ifn_2482 lang.IFn; if linked_2481 == nil { ifn_2482 = lang.IFn_Cast(root_2480) } else { ifn_2482 = nil }; var tmp15 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_72.GetRawRoot__O()); var tmp16 any = A_arbace_build_go_A_const_185; var arg_2483 any = tmp15.Invoke_O_O__O(tmp16, A_arbace_build_go_A_const_186.Get__O()); if linked_2481 == nil { ifn_2482.Invoke_O__O(arg_2483) } else { linked_2481.(*aot_arbace_core.A_arbace_core_push_thread_bindings_A).Invoke_O_O__O(root_2480, arg_2483) }; var tmp17 any = A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_New_O(e__3); var tmp18 *jrt.Class; var fncls__2479 *jrt.Class = A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class; if fncls__2479 == nil { var fncls__2479d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_25, false); A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class = fncls__2479d; tmp18 = fncls__2479d } else { tmp18 = fncls__2479 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp17, tmp18, nil).Invoke__O()
//line :596:1
			tmp1 = A_arbace_build_go_A_const_183 } else { panic(jrt.Thrown(e__3)) } } else {
//line :584:1
				panic(tmp12) } }; return tmp1 }












func A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_New_O(p0 any) *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go__main_fn__1901000390_fn__1901000391_A{}; t.Ctor_O(p0); return t }
//line :597:1
func (t *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A) Ctor_O(c__e any) { t.F_e = c__e }
//line :597:1
func (t *A_arbace_build_go__main_fn__1901000390_fn__1901000391_A) Invoke_O__O(self any) any { var tmp1 any; tmp5 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_build_go_A_const_184.GetRawRoot__O()); var tmp3 *jrt.RefArray = jrt.RefArrayOf(jrt.String_class, Lit_26, nil); var tmp4 any; var t_ any = t.F_e; t.F_e = nil; tmp4 = t_; tmp1 = tmp2.Invoke_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(tmp3, jrt.RefArrayOf(jrt.Object_class, nil, jrt.Throwable_Cast(tmp4).GetMessage__String().Ref())).Ref()) }; return nil }(); var root_2476 any = A_arbace_build_go_A_const_70.GetRawRoot__O(); var linked_2477 any = lang.Compiler_AOTFn_Linked_O_Class__O(root_2476, aot_arbace_core.A_arbace_core_pop_thread_bindings_A_fn_class); var ifn_2478 lang.IFn; if linked_2477 == nil { ifn_2478 = lang.IFn_Cast(root_2476) } else { ifn_2478 = nil }; if linked_2477 == nil { ifn_2478.Invoke__O() } else { linked_2477.(*aot_arbace_core.A_arbace_core_pop_thread_bindings_A).Invoke_O__O(root_2476) }; if tmp5 != nil { panic(tmp5) }; return tmp1 }

















































































































































type A_arbace_build_go_A struct{ jrt.Object }

var A_arbace_build_go_A_const_pool *jrt.RefArray

var A_arbace_build_go_A_const_0 *lang.Var

var A_arbace_build_go_A_const_1 any

var A_arbace_build_go_A_const_2 *lang.Var

var A_arbace_build_go_A_const_3 any

var A_arbace_build_go_A_const_4 any

var A_arbace_build_go_A_const_5 *lang.Var

var A_arbace_build_go_A_const_6 *lang.Var

var A_arbace_build_go_A_const_7 *lang.Var

var A_arbace_build_go_A_const_8 *lang.Var

var A_arbace_build_go_A_const_9 any

var A_arbace_build_go_A_const_10 *lang.Var

var A_arbace_build_go_A_const_11 *lang.Var

var A_arbace_build_go_A_const_12 any

var A_arbace_build_go_A_const_13 *lang.Keyword

var A_arbace_build_go_A_const_14 *lang.Var

var A_arbace_build_go_A_const_15 *lang.Var

var A_arbace_build_go_A_const_16 *lang.Var

var A_arbace_build_go_A_const_17 *lang.Var

var A_arbace_build_go_A_const_18 *lang.Var

var A_arbace_build_go_A_const_19 *lang.Var

var A_arbace_build_go_A_const_20 *lang.Var

var A_arbace_build_go_A_const_21 *lang.Var

var A_arbace_build_go_A_const_22 any

var A_arbace_build_go_A_const_23 *lang.Var

var A_arbace_build_go_A_const_24 *lang.Var

var A_arbace_build_go_A_const_25 *lang.Var

var A_arbace_build_go_A_const_26 *lang.Var

var A_arbace_build_go_A_const_27 *lang.Var

var A_arbace_build_go_A_const_28 *lang.Var

var A_arbace_build_go_A_const_29 *lang.Var

var A_arbace_build_go_A_const_30 *lang.Var

var A_arbace_build_go_A_const_31 *lang.Var

var A_arbace_build_go_A_const_32 *lang.Var

var A_arbace_build_go_A_const_33 *lang.Var

var A_arbace_build_go_A_const_34 *lang.Var

var A_arbace_build_go_A_const_35 *lang.Var

var A_arbace_build_go_A_const_36 *lang.Keyword

var A_arbace_build_go_A_const_37 *lang.Var

var A_arbace_build_go_A_const_38 *lang.Var

var A_arbace_build_go_A_const_39 *lang.Var

var A_arbace_build_go_A_const_40 *lang.Var

var A_arbace_build_go_A_const_41 *lang.Var

var A_arbace_build_go_A_const_42 *lang.Var

var A_arbace_build_go_A_const_43 *lang.Var

var A_arbace_build_go_A_const_44 *lang.Var

var A_arbace_build_go_A_const_45 *lang.Var

var A_arbace_build_go_A_const_46 *lang.Keyword

var A_arbace_build_go_A_const_47 *lang.Var

var A_arbace_build_go_A_const_48 *lang.Var

var A_arbace_build_go_A_const_49 *lang.Var

var A_arbace_build_go_A_const_50 *lang.Keyword

var A_arbace_build_go_A_const_51 *lang.Var

var A_arbace_build_go_A_const_52 *lang.Var

var A_arbace_build_go_A_const_53 *lang.Var

var A_arbace_build_go_A_const_54 *lang.Var

var A_arbace_build_go_A_const_55 *lang.Var

var A_arbace_build_go_A_const_56 *lang.Var

var A_arbace_build_go_A_const_57 *lang.Var

var A_arbace_build_go_A_const_58 *lang.Var

var A_arbace_build_go_A_const_59 *lang.Var

var A_arbace_build_go_A_const_60 *lang.Var

var A_arbace_build_go_A_const_61 *lang.Var

var A_arbace_build_go_A_const_62 *lang.Keyword

var A_arbace_build_go_A_const_63 *lang.Var

var A_arbace_build_go_A_const_64 *lang.Keyword

var A_arbace_build_go_A_const_65 *lang.Var

var A_arbace_build_go_A_const_66 *lang.Var

var A_arbace_build_go_A_const_67 *jrt.Class

var A_arbace_build_go_A_const_68 *lang.Var

var A_arbace_build_go_A_const_69 *lang.Var

var A_arbace_build_go_A_const_70 *lang.Var

var A_arbace_build_go_A_const_71 *lang.Var

var A_arbace_build_go_A_const_72 *lang.Var

var A_arbace_build_go_A_const_73 *lang.Var

var A_arbace_build_go_A_const_74 *lang.Var

var A_arbace_build_go_A_const_75 *lang.Var

var A_arbace_build_go_A_const_76 *lang.Var

var A_arbace_build_go_A_const_77 *lang.Var

var A_arbace_build_go_A_const_78 *lang.Keyword

var A_arbace_build_go_A_const_79 *lang.Var

var A_arbace_build_go_A_const_80 *lang.Var

var A_arbace_build_go_A_const_81 *lang.Var

var A_arbace_build_go_A_const_82 *lang.Keyword

var A_arbace_build_go_A_const_83 *lang.Var

var A_arbace_build_go_A_const_84 *lang.Var

var A_arbace_build_go_A_const_85 *lang.Var

var A_arbace_build_go_A_const_86 *lang.Var

var A_arbace_build_go_A_const_87 *lang.Var

var A_arbace_build_go_A_const_88 *lang.Var

var A_arbace_build_go_A_const_89 *lang.Var

var A_arbace_build_go_A_const_90 *lang.Var

var A_arbace_build_go_A_const_91 *lang.Keyword

var A_arbace_build_go_A_const_92 *lang.Var

var A_arbace_build_go_A_const_93 *lang.Var

var A_arbace_build_go_A_const_94 *lang.Var

var A_arbace_build_go_A_const_95 *lang.Keyword

var A_arbace_build_go_A_const_96 *lang.Var

var A_arbace_build_go_A_const_97 *lang.Var

var A_arbace_build_go_A_const_98 *lang.Var

var A_arbace_build_go_A_const_99 any

var A_arbace_build_go_A_const_100 any

var A_arbace_build_go_A_const_101 *lang.Var

var A_arbace_build_go_A_const_102 any

var A_arbace_build_go_A_const_103 any

var A_arbace_build_go_A_const_104 *lang.Var

var A_arbace_build_go_A_const_105 *lang.Var

var A_arbace_build_go_A_const_106 any

var A_arbace_build_go_A_const_107 any

var A_arbace_build_go_A_const_108 *lang.Var

var A_arbace_build_go_A_const_109 *lang.Var

var A_arbace_build_go_A_const_110 *lang.Var

var A_arbace_build_go_A_const_111 *lang.Var

var A_arbace_build_go_A_const_112 *lang.Keyword

var A_arbace_build_go_A_const_113 *lang.Keyword

var A_arbace_build_go_A_const_114 *lang.Keyword

var A_arbace_build_go_A_const_115 *lang.Var

var A_arbace_build_go_A_const_116 *lang.Var

var A_arbace_build_go_A_const_117 *lang.Var

var A_arbace_build_go_A_const_118 any

var A_arbace_build_go_A_const_119 *lang.Keyword

var A_arbace_build_go_A_const_120 *lang.Keyword

var A_arbace_build_go_A_const_121 *lang.Keyword

var A_arbace_build_go_A_const_122 *lang.Keyword

var A_arbace_build_go_A_const_123 *lang.Keyword

var A_arbace_build_go_A_const_124 *lang.Var

var A_arbace_build_go_A_const_125 *lang.Keyword

var A_arbace_build_go_A_const_126 *lang.Var

var A_arbace_build_go_A_const_127 *lang.Keyword

var A_arbace_build_go_A_const_128 *lang.Var

var A_arbace_build_go_A_const_129 *lang.Var

var A_arbace_build_go_A_const_130 *lang.Keyword

var A_arbace_build_go_A_const_131 *lang.Var

var A_arbace_build_go_A_const_132 *lang.Var

var A_arbace_build_go_A_const_133 *jrt.Class

var A_arbace_build_go_A_const_134 any

var A_arbace_build_go_A_const_135 *lang.Var

var A_arbace_build_go_A_const_136 *lang.Keyword

var A_arbace_build_go_A_const_137 *lang.Keyword

var A_arbace_build_go_A_const_138 *lang.Keyword

var A_arbace_build_go_A_const_139 *lang.Keyword

var A_arbace_build_go_A_const_140 *lang.Var

var A_arbace_build_go_A_const_141 *lang.Var

var A_arbace_build_go_A_const_142 *lang.Var

var A_arbace_build_go_A_const_143 *lang.Keyword

var A_arbace_build_go_A_const_144 *lang.Keyword

var A_arbace_build_go_A_const_145 *lang.Keyword

var A_arbace_build_go_A_const_146 *lang.Keyword

var A_arbace_build_go_A_const_147 any

var A_arbace_build_go_A_const_148 *lang.Keyword

var A_arbace_build_go_A_const_149 *lang.Keyword

var A_arbace_build_go_A_const_150 *lang.Keyword

var A_arbace_build_go_A_const_151 *lang.Var

var A_arbace_build_go_A_const_152 *lang.Var

var A_arbace_build_go_A_const_153 any

var A_arbace_build_go_A_const_154 *lang.Var

var A_arbace_build_go_A_const_155 *lang.Var

var A_arbace_build_go_A_const_156 *lang.Var

var A_arbace_build_go_A_const_157 *lang.Var

var A_arbace_build_go_A_const_158 *lang.Keyword

var A_arbace_build_go_A_const_159 *lang.Keyword

var A_arbace_build_go_A_const_160 *lang.Var

var A_arbace_build_go_A_const_161 *lang.Var

var A_arbace_build_go_A_const_162 *lang.Var

var A_arbace_build_go_A_const_163 *lang.Var

var A_arbace_build_go_A_const_164 *lang.Keyword

var A_arbace_build_go_A_const_165 *lang.Keyword

var A_arbace_build_go_A_const_166 *lang.Var

var A_arbace_build_go_A_const_167 *jrt.Class

var A_arbace_build_go_A_const_168 *lang.Keyword

var A_arbace_build_go_A_const_169 *lang.Var

var A_arbace_build_go_A_const_170 *lang.Keyword

var A_arbace_build_go_A_const_171 *lang.Keyword

var A_arbace_build_go_A_const_172 *lang.Keyword

var A_arbace_build_go_A_const_173 *lang.Var

var A_arbace_build_go_A_const_174 *lang.Keyword

var A_arbace_build_go_A_const_175 *lang.Keyword

var A_arbace_build_go_A_const_176 *lang.Keyword

var A_arbace_build_go_A_const_177 *lang.Var

var A_arbace_build_go_A_const_178 *lang.Var

var A_arbace_build_go_A_const_179 any

var A_arbace_build_go_A_const_180 *lang.Var

var A_arbace_build_go_A_const_181 *lang.Keyword

var A_arbace_build_go_A_const_182 *lang.Var

var A_arbace_build_go_A_const_183 any

var A_arbace_build_go_A_const_184 *lang.Var

var A_arbace_build_go_A_const_185 *lang.Var

var A_arbace_build_go_A_const_186 *lang.Var

var A_arbace_build_go_A_const_187 *lang.Var

var A_arbace_build_go_A_const_188 *lang.Var

var A_arbace_build_go_A_const_189 *lang.Var

var A_arbace_build_go_A_const_190 *lang.Var

var A_arbace_build_go_A_const_191 any

var A_arbace_build_go_A_const_192 any

var A_arbace_build_go_A_const_193 any

var A_arbace_build_go_A_const_194 *lang.Var

var A_arbace_build_go_A_init jrt.ClassInit

func A_arbace_build_go_A_Init() { if !A_arbace_build_go_A_init.Done() { A_arbace_build_go_A_init.Run(A_arbace_build_go_A_clinit) } }

func A_arbace_build_go_A_clinit() { A_arbace_build_go_A_clinit_p0(); A_arbace_build_go_A_clinit_p1(); A_arbace_build_go_A_clinit_p2(); A_arbace_build_go_A_clinit_p3(); A_arbace_build_go_A_clinit_p4(); A_arbace_build_go_A_clinit_p5(); A_arbace_build_go_A_clinit_p6(); A_arbace_build_go_A_clinit_p7(); A_arbace_build_go_A_clinit_p8(); A_arbace_build_go_A_clinit_p9(); A_arbace_build_go_A_clinit_p10(); A_arbace_build_go_A_clinit_p11(); A_arbace_build_go_A_clinit_p12(); A_arbace_build_go_A_clinit_p13(); A_arbace_build_go_A_clinit_p14(); A_arbace_build_go_A_clinit_p15(); A_arbace_build_go_A_clinit_p16() }

func A_arbace_build_go_A_clinit_p0() { jrt.StartCheck(); A_arbace_build_go_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 247); A_arbace_build_go_A_const_0 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[52]); A_arbace_build_go_A_const_1 = A_arbace_build_go_A_const_pool.A[53]; A_arbace_build_go_A_const_2 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[54]); A_arbace_build_go_A_const_3 = A_arbace_build_go_A_const_pool.A[55]; A_arbace_build_go_A_const_4 = A_arbace_build_go_A_const_pool.A[56]; A_arbace_build_go_A_const_5 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[57]); A_arbace_build_go_A_const_6 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[58]); A_arbace_build_go_A_const_7 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[59]); A_arbace_build_go_A_const_8 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[60]); A_arbace_build_go_A_const_9 = A_arbace_build_go_A_const_pool.A[61]; A_arbace_build_go_A_const_10 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[62]); A_arbace_build_go_A_const_11 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[63]) }

func A_arbace_build_go_A_clinit_p1() { A_arbace_build_go_A_const_12 = A_arbace_build_go_A_const_pool.A[64]; A_arbace_build_go_A_const_13 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[65]); A_arbace_build_go_A_const_14 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[66]); A_arbace_build_go_A_const_15 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[67]); A_arbace_build_go_A_const_16 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[68]); A_arbace_build_go_A_const_17 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[69]); A_arbace_build_go_A_const_18 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[70]); A_arbace_build_go_A_const_19 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[71]); A_arbace_build_go_A_const_20 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[72]); A_arbace_build_go_A_const_21 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[73]); A_arbace_build_go_A_const_22 = A_arbace_build_go_A_const_pool.A[74]; A_arbace_build_go_A_const_23 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[75]) }

func A_arbace_build_go_A_clinit_p2() { A_arbace_build_go_A_const_24 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[76]); A_arbace_build_go_A_const_25 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[77]); A_arbace_build_go_A_const_26 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[78]); A_arbace_build_go_A_const_27 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[79]); A_arbace_build_go_A_const_28 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[80]); A_arbace_build_go_A_const_29 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[81]); A_arbace_build_go_A_const_30 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[82]); A_arbace_build_go_A_const_31 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[83]); A_arbace_build_go_A_const_32 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[84]); A_arbace_build_go_A_const_33 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[85]); A_arbace_build_go_A_const_34 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[86]); A_arbace_build_go_A_const_35 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[87]) }

func A_arbace_build_go_A_clinit_p3() { A_arbace_build_go_A_const_36 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[88]); A_arbace_build_go_A_const_37 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[89]); A_arbace_build_go_A_const_38 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[90]); A_arbace_build_go_A_const_39 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[91]); A_arbace_build_go_A_const_40 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[92]); A_arbace_build_go_A_const_41 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[93]); A_arbace_build_go_A_const_42 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[94]); A_arbace_build_go_A_const_43 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[95]); A_arbace_build_go_A_const_44 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[96]); A_arbace_build_go_A_const_45 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[97]); A_arbace_build_go_A_const_46 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[98]); A_arbace_build_go_A_const_47 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[99]) }

func A_arbace_build_go_A_clinit_p4() { A_arbace_build_go_A_const_48 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[100]); A_arbace_build_go_A_const_49 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[101]); A_arbace_build_go_A_const_50 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[102]); A_arbace_build_go_A_const_51 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[103]); A_arbace_build_go_A_const_52 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[104]); A_arbace_build_go_A_const_53 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[105]); A_arbace_build_go_A_const_54 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[106]); A_arbace_build_go_A_const_55 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[107]); A_arbace_build_go_A_const_56 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[108]); A_arbace_build_go_A_const_57 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[109]); A_arbace_build_go_A_const_58 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[110]); A_arbace_build_go_A_const_59 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[111]) }

func A_arbace_build_go_A_clinit_p5() { A_arbace_build_go_A_const_60 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[112]); A_arbace_build_go_A_const_61 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[113]); A_arbace_build_go_A_const_62 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[114]); A_arbace_build_go_A_const_63 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[115]); A_arbace_build_go_A_const_64 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[116]); A_arbace_build_go_A_const_65 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[117]); A_arbace_build_go_A_const_66 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[118]); A_arbace_build_go_A_const_67 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[119]); A_arbace_build_go_A_const_68 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[120]); A_arbace_build_go_A_const_69 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[121]); A_arbace_build_go_A_const_70 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[122]); A_arbace_build_go_A_const_71 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[123]) }

func A_arbace_build_go_A_clinit_p6() { A_arbace_build_go_A_const_72 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[124]); A_arbace_build_go_A_const_73 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[125]); A_arbace_build_go_A_const_74 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[126]); A_arbace_build_go_A_const_75 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[127]); A_arbace_build_go_A_const_76 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[128]); A_arbace_build_go_A_const_77 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[129]); A_arbace_build_go_A_const_78 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[130]); A_arbace_build_go_A_const_79 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[131]); A_arbace_build_go_A_const_80 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[132]); A_arbace_build_go_A_const_81 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[133]); A_arbace_build_go_A_const_82 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[134]); A_arbace_build_go_A_const_83 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[135]) }

func A_arbace_build_go_A_clinit_p7() { A_arbace_build_go_A_const_84 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[136]); A_arbace_build_go_A_const_85 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[137]); A_arbace_build_go_A_const_86 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[138]); A_arbace_build_go_A_const_87 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[139]); A_arbace_build_go_A_const_88 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[140]); A_arbace_build_go_A_const_89 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[141]); A_arbace_build_go_A_const_90 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[142]); A_arbace_build_go_A_const_91 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[143]); A_arbace_build_go_A_const_92 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[144]); A_arbace_build_go_A_const_93 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[145]); A_arbace_build_go_A_const_94 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[146]); A_arbace_build_go_A_const_95 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[147]) }

func A_arbace_build_go_A_clinit_p8() { A_arbace_build_go_A_const_96 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[148]); A_arbace_build_go_A_const_97 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[149]); A_arbace_build_go_A_const_98 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[150]); A_arbace_build_go_A_const_99 = A_arbace_build_go_A_const_pool.A[151]; A_arbace_build_go_A_const_100 = A_arbace_build_go_A_const_pool.A[152]; A_arbace_build_go_A_const_101 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[153]); A_arbace_build_go_A_const_102 = A_arbace_build_go_A_const_pool.A[154]; A_arbace_build_go_A_const_103 = A_arbace_build_go_A_const_pool.A[155]; A_arbace_build_go_A_const_104 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[156]); A_arbace_build_go_A_const_105 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[157]); A_arbace_build_go_A_const_106 = A_arbace_build_go_A_const_pool.A[158]; A_arbace_build_go_A_const_107 = A_arbace_build_go_A_const_pool.A[159]; A_arbace_build_go_A_const_108 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[160]) }

func A_arbace_build_go_A_clinit_p9() { A_arbace_build_go_A_const_109 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[161]); A_arbace_build_go_A_const_110 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[162]); A_arbace_build_go_A_const_111 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[163]); A_arbace_build_go_A_const_112 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[164]); A_arbace_build_go_A_const_113 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[165]); A_arbace_build_go_A_const_114 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[166]); A_arbace_build_go_A_const_115 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[167]); A_arbace_build_go_A_const_116 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[168]); A_arbace_build_go_A_const_117 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[169]); A_arbace_build_go_A_const_118 = A_arbace_build_go_A_const_pool.A[170]; A_arbace_build_go_A_const_119 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[171]); A_arbace_build_go_A_const_120 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[172]) }

func A_arbace_build_go_A_clinit_p10() { A_arbace_build_go_A_const_121 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[173]); A_arbace_build_go_A_const_122 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[174]); A_arbace_build_go_A_const_123 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[175]); A_arbace_build_go_A_const_124 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[176]); A_arbace_build_go_A_const_125 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[177]); A_arbace_build_go_A_const_126 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[178]); A_arbace_build_go_A_const_127 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[179]); A_arbace_build_go_A_const_128 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[180]); A_arbace_build_go_A_const_129 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[181]); A_arbace_build_go_A_const_130 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[182]); A_arbace_build_go_A_const_131 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[183]); A_arbace_build_go_A_const_132 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[184]) }

func A_arbace_build_go_A_clinit_p11() { A_arbace_build_go_A_const_133 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[185]); A_arbace_build_go_A_const_134 = A_arbace_build_go_A_const_pool.A[186]; A_arbace_build_go_A_const_135 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[187]); A_arbace_build_go_A_const_136 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[188]); A_arbace_build_go_A_const_137 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[189]); A_arbace_build_go_A_const_138 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[190]); A_arbace_build_go_A_const_139 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[191]); A_arbace_build_go_A_const_140 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[192]); A_arbace_build_go_A_const_141 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[193]); A_arbace_build_go_A_const_142 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[194]); A_arbace_build_go_A_const_143 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[195]); A_arbace_build_go_A_const_144 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[196]) }

func A_arbace_build_go_A_clinit_p12() { A_arbace_build_go_A_const_145 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[197]); A_arbace_build_go_A_const_146 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[198]); A_arbace_build_go_A_const_147 = A_arbace_build_go_A_const_pool.A[199]; A_arbace_build_go_A_const_148 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[200]); A_arbace_build_go_A_const_149 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[201]); A_arbace_build_go_A_const_150 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[202]); A_arbace_build_go_A_const_151 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[203]); A_arbace_build_go_A_const_152 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[204]); A_arbace_build_go_A_const_153 = A_arbace_build_go_A_const_pool.A[205]; A_arbace_build_go_A_const_154 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[206]); A_arbace_build_go_A_const_155 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[207]); A_arbace_build_go_A_const_156 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[208]) }

func A_arbace_build_go_A_clinit_p13() { A_arbace_build_go_A_const_157 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[209]); A_arbace_build_go_A_const_158 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[210]); A_arbace_build_go_A_const_159 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[211]); A_arbace_build_go_A_const_160 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[212]); A_arbace_build_go_A_const_161 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[213]); A_arbace_build_go_A_const_162 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[214]); A_arbace_build_go_A_const_163 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[215]); A_arbace_build_go_A_const_164 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[216]); A_arbace_build_go_A_const_165 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[217]); A_arbace_build_go_A_const_166 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[218]); A_arbace_build_go_A_const_167 = jrt.Class_Cast(A_arbace_build_go_A_const_pool.A[219]); A_arbace_build_go_A_const_168 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[220]) }

func A_arbace_build_go_A_clinit_p14() { A_arbace_build_go_A_const_169 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[221]); A_arbace_build_go_A_const_170 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[222]); A_arbace_build_go_A_const_171 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[223]); A_arbace_build_go_A_const_172 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[224]); A_arbace_build_go_A_const_173 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[225]); A_arbace_build_go_A_const_174 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[226]); A_arbace_build_go_A_const_175 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[227]); A_arbace_build_go_A_const_176 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[228]); A_arbace_build_go_A_const_177 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[229]); A_arbace_build_go_A_const_178 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[230]); A_arbace_build_go_A_const_179 = A_arbace_build_go_A_const_pool.A[231]; A_arbace_build_go_A_const_180 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[232]) }

func A_arbace_build_go_A_clinit_p15() { A_arbace_build_go_A_const_181 = lang.Keyword_Cast(A_arbace_build_go_A_const_pool.A[233]); A_arbace_build_go_A_const_182 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[234]); A_arbace_build_go_A_const_183 = A_arbace_build_go_A_const_pool.A[235]; A_arbace_build_go_A_const_184 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[236]); A_arbace_build_go_A_const_185 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[237]); A_arbace_build_go_A_const_186 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[238]); A_arbace_build_go_A_const_187 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[239]); A_arbace_build_go_A_const_188 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[240]); A_arbace_build_go_A_const_189 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[241]); A_arbace_build_go_A_const_190 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[242]); A_arbace_build_go_A_const_191 = A_arbace_build_go_A_const_pool.A[243]; A_arbace_build_go_A_const_192 = A_arbace_build_go_A_const_pool.A[244]; A_arbace_build_go_A_const_193 = A_arbace_build_go_A_const_pool.A[245] }

func A_arbace_build_go_A_clinit_p16() { A_arbace_build_go_A_const_194 = lang.Var_Cast(A_arbace_build_go_A_const_pool.A[246]) }

func A_arbace_build_go_A_New() *A_arbace_build_go_A { A_arbace_build_go_A_Init(); t := &A_arbace_build_go_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_A) Ctor() {}

func (t *A_arbace_build_go_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_A_class }

func (t *A_arbace_build_go_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_A); return ok }

func A_arbace_build_go_A_Cast(x any) *A_arbace_build_go_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_A_class)) }; return v }



type A_arbace_build_go__main_A struct{ j2g_header uint64 }

var A_arbace_build_go__main_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000388_A struct{ j2g_header uint64; F_usage any }

var A_arbace_build_go__main_fn__1901000388_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000390_A struct{ j2g_header uint64; F_dir, F_goroot, F_opts any }

var A_arbace_build_go__main_fn__1901000390_A_fn_class *jrt.Class



type A_arbace_build_go__main_fn__1901000390_fn__1901000391_A struct{ j2g_header uint64; F_e any }

var A_arbace_build_go__main_fn__1901000390_fn__1901000391_A_fn_class *jrt.Class



type A_arbace_build_go_build_A struct{ j2g_header uint64 }

var A_arbace_build_go_build_A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_cache_texts_BANG__fn__1901000326_A struct{ j2g_header uint64 }

var A_arbace_build_go_cache_texts_BANG__fn__1901000326_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_A struct{ j2g_header uint64 }

var A_arbace_build_go_cached_texts_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A struct{ j2g_header uint64; F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A struct{ j2g_header uint64; F_s__1901000305, F_iter__1901000304, F_entry any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_A_fn_class *jrt.Class



type A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A struct{ j2g_header uint64; F_b__1901000307, F_entry any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_cached_texts_iter__1901000304__1901000308_fn__1901000309_fn__1901000310_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000020_A struct{ j2g_header uint64 }

var A_arbace_build_go_clj_files_fn__1901000020_A_fn_class *jrt.Class



type A_arbace_build_go_clj_files_fn__1901000022_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_clj_files_fn__1901000022_A_fn_class *jrt.Class



type A_arbace_build_go_collect_index_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_index_file_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collect_package_A_fn_class *jrt.Class



type A_arbace_build_go_collect_package_fn__1901000076_A struct{ j2g_header uint64; F_read_fn, F_read any }

var A_arbace_build_go_collect_package_fn__1901000076_A_fn_class *jrt.Class



type A_arbace_build_go_collected_package_A struct{ j2g_header uint64 }

var A_arbace_build_go_collected_package_A_fn_class *jrt.Class



type A_arbace_build_go_copy_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_copy_file_A_fn_class *jrt.Class



type A_arbace_build_go_data_dir_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_data_dir_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_delete_tree_A struct{ j2g_header uint64 }

var A_arbace_build_go_delete_tree_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000004_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000004_A_New() *A_arbace_build_go_eval1901000004_A { t := &A_arbace_build_go_eval1901000004_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000004_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000004_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000004_A_class }

func (t *A_arbace_build_go_eval1901000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000004_A); return ok }

func A_arbace_build_go_eval1901000004_A_Cast(x any) *A_arbace_build_go_eval1901000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000004_A_class)) }; return v }



type A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000004_loading__1927001464__auto____1901000005_A_fn_class *jrt.Class



type A_arbace_build_go_eval1901000008_A struct{ jrt.Object }

func A_arbace_build_go_eval1901000008_A_New() *A_arbace_build_go_eval1901000008_A { t := &A_arbace_build_go_eval1901000008_A{}; t.Ctor(); return t }

func (t *A_arbace_build_go_eval1901000008_A) Ctor() {}

func (t *A_arbace_build_go_eval1901000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_build_go_eval1901000008_A) GetClass__Class() *jrt.Class { return A_arbace_build_go_eval1901000008_A_class }

func (t *A_arbace_build_go_eval1901000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_build_go_eval1901000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_build_go_eval1901000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_build_go_eval1901000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_build_go_eval1901000008_A); return ok }

func A_arbace_build_go_eval1901000008_A_Cast(x any) *A_arbace_build_go_eval1901000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_build_go_eval1901000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_build_go_eval1901000008_A_class)) }; return v }



type A_arbace_build_go_eval1901000008_fn__1901000009_A struct{ j2g_header uint64 }

var A_arbace_build_go_eval1901000008_fn__1901000009_A_fn_class *jrt.Class



type A_arbace_build_go_fail_A struct{ j2g_header uint64 }

var A_arbace_build_go_fail_A_fn_class *jrt.Class



type A_arbace_build_go_file_sha_A struct{ j2g_header uint64 }

var A_arbace_build_go_file_sha_A_fn_class *jrt.Class



type A_arbace_build_go_forms_dir_A struct{ j2g_header uint64 }

var A_arbace_build_go_forms_dir_A_fn_class *jrt.Class



type A_arbace_build_go_go_env_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_env_A_fn_class *jrt.Class



type A_arbace_build_go_go_mod_cache_A struct{ j2g_header uint64 }

var A_arbace_build_go_go_mod_cache_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_hex__1901000239_fn__1901000240_A_fn_class *jrt.Class



type A_arbace_build_go_h1_of_file_sha__1901000243_A struct{ j2g_header uint64 }

var A_arbace_build_go_h1_of_file_sha__1901000243_A_fn_class *jrt.Class



type A_arbace_build_go_hex_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_A_fn_class *jrt.Class



type A_arbace_build_go_hex_fn__1901000072_A struct{ j2g_header uint64 }

var A_arbace_build_go_hex_fn__1901000072_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000027_A struct{ j2g_header uint64 }

var A_arbace_build_go_package_file_QMARK__fn__1901000027_A_fn_class *jrt.Class



type A_arbace_build_go_package_file_QMARK__fn__1901000029_A struct{ j2g_header uint64; F_aliases any }

var A_arbace_build_go_package_file_QMARK__fn__1901000029_A_fn_class *jrt.Class



type A_arbace_build_go_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000057_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000057_A_fn_class *jrt.Class



type A_arbace_build_go_packages_fn__1901000062_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_fn__1901000062_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_A struct{ j2g_header uint64; F_print_cache any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A struct{ j2g_header uint64; F_iter__1901000034, F_print_cache, F_s__1901000035 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A struct{ j2g_header uint64 }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A struct{ j2g_header uint64; F_iter__1901000036, F_s__1901000037 any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_A_fn_class *jrt.Class



type A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A struct{ j2g_header uint64; F_b__1901000039 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_packages_iter__1901000034__1901000040_fn__1901000041_iter__1901000036__1901000042_fn__1901000043_fn__1901000044_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_add__1901000295_A struct{ j2g_header uint64; F_md any }

var A_arbace_build_go_print_cache_key_add__1901000295_A_fn_class *jrt.Class



type A_arbace_build_go_print_cache_key_fn__1901000301_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_cache_key_fn__1901000301_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_A struct{ j2g_header uint64 }

var A_arbace_build_go_print_module_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_A struct{ j2g_header uint64; F_dir, F_out, F_tests, F_line_file, F_layout, F_print_cache any }

var A_arbace_build_go_print_module_fn__1901000337_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A struct{ j2g_header uint64; F_test_files, F_tests any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A struct{ j2g_header uint64; F_test_files any }

var A_arbace_build_go_print_module_fn__1901000337_printable__1901000339_fn__1901000340_fn__1901000341_A_fn_class *jrt.Class



type A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A struct{ j2g_header uint64; F_pkg any }

var A_arbace_build_go_print_module_fn__1901000337_rel__1901000346_A_fn_class *jrt.Class



type A_arbace_build_go_program_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000263_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000263_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000265_A struct{ j2g_header uint64; F_opts any }

var A_arbace_build_go_program_fn__1901000265_A_fn_class *jrt.Class



type A_arbace_build_go_program_fn__1901000277_A struct{ j2g_header uint64 }

var A_arbace_build_go_program_fn__1901000277_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_A struct{ j2g_header uint64; F_module any }

var A_arbace_build_go_program_iter__1901000267__1901000271_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A struct{ j2g_header uint64; F_iter__1901000267, F_module, F_s__1901000268 any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_A_fn_class *jrt.Class



type A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A struct{ j2g_header uint64; F_b__1901000270 any; F_size__1927001038__auto__ int32; F_module, F_c__1927001037__auto__ any }

var A_arbace_build_go_program_iter__1901000267__1901000271_fn__1901000272_fn__1901000273_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000066_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_all_fn__1901000066_A_fn_class *jrt.Class



type A_arbace_build_go_read_all_fn__1901000068_A struct{ j2g_header uint64; F_cache any }

var A_arbace_build_go_read_all_fn__1901000068_A_fn_class *jrt.Class



type A_arbace_build_go_read_index_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_index_A_fn_class *jrt.Class



type A_arbace_build_go_read_program_edn_A struct{ j2g_header uint64 }

var A_arbace_build_go_read_program_edn_A_fn_class *jrt.Class



type A_arbace_build_go_rel_path_A struct{ j2g_header uint64 }

var A_arbace_build_go_rel_path_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000099_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_fn__1901000099_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000101_A struct{ j2g_header uint64; F_m any }

var A_arbace_build_go_root_packages_fn__1901000101_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000158_A struct{ j2g_header uint64; F_covered, F_known_QMARK_ any }

var A_arbace_build_go_root_packages_fn__1901000158_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000187_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000187_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_fn__1901000192_A struct{ j2g_header uint64; F_dir any }

var A_arbace_build_go_root_packages_fn__1901000192_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A struct{ j2g_header uint64; F_s__1901000104, F_iter__1901000103, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A struct{ j2g_header uint64; F_b__1901000106 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000109_fn__1901000114_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000103__1901000107_fn__1901000108_fn__1901000124_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A struct{ j2g_header uint64; F_iter__1901000131, F_s__1901000132 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A struct{ j2g_header uint64; F_iter__1901000133, F_s__1901000134 any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A struct{ j2g_header uint64; F_b__1901000136 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000131__1901000137_fn__1901000138_iter__1901000133__1901000142_fn__1901000143_fn__1901000144_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_dir, F_valid, F_s__1901000163, F_iter__1901000162 any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_read_fn, F_b__1901000165, F_dir, F_valid any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__ any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000169_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000168_fn__1901000171_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A struct{ j2g_header uint64 }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000174_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A struct{ j2g_header uint64; F_f, F_dir any }

var A_arbace_build_go_root_packages_iter__1901000162__1901000166_fn__1901000167_fn__1901000176_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_s__1901000195, F_iter__1901000194, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A struct{ j2g_header uint64; F_pkg_file_QMARK_, F_b__1901000197 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000194__1901000198_fn__1901000199_fn__1901000200_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A struct{ j2g_header uint64; F_s__1901000205, F_iter__1901000204, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A struct{ j2g_header uint64; F_b__1901000207 any; F_size__1927001038__auto__ int32; F_c__1927001037__auto__, F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000210_fn__1901000211_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A struct{ j2g_header uint64; F_shas any }

var A_arbace_build_go_root_packages_iter__1901000204__1901000208_fn__1901000209_fn__1901000214_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_known_QMARK___1901000156_A struct{ j2g_header uint64; F_index_file, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_known_QMARK___1901000156_A_fn_class *jrt.Class



type A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A struct{ j2g_header uint64; F_read_fn, F_known_QMARK_, F_pf_index, F_shas any }

var A_arbace_build_go_root_packages_pkg_file_QMARK___1901000160_A_fn_class *jrt.Class



type A_arbace_build_go_run_A struct{ j2g_header uint64 }

var A_arbace_build_go_run_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_A_fn_class *jrt.Class



type A_arbace_build_go_sha256_fn__1901000281_A struct{ j2g_header uint64 }

var A_arbace_build_go_sha256_fn__1901000281_A_fn_class *jrt.Class



type A_arbace_build_go_tamago_go_sum_A struct{ j2g_header uint64 }

var A_arbace_build_go_tamago_go_sum_A_fn_class *jrt.Class



type A_arbace_build_go_toolchain_lang_A struct{ j2g_header uint64 }

var A_arbace_build_go_toolchain_lang_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_A struct{ j2g_header uint64 }

var A_arbace_build_go_with_line_files_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_A_fn_class *jrt.Class



type A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A struct{ j2g_header uint64; F_fdir any }

var A_arbace_build_go_with_line_files_fn__1901000287_fn__1901000288_fn__1901000289_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__fn__1901000091_A struct{ j2g_header uint64; F_ok_QMARK_ any }

var A_arbace_build_go_write_index_BANG__fn__1901000091_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A struct{ j2g_header uint64; F_printed any }

var A_arbace_build_go_write_index_BANG__ok_QMARK___1901000089_A_fn_class *jrt.Class



type A_arbace_build_go_write_index_BANG__printed__1901000087_A struct{ j2g_header uint64 }

var A_arbace_build_go_write_index_BANG__printed__1901000087_A_fn_class *jrt.Class
