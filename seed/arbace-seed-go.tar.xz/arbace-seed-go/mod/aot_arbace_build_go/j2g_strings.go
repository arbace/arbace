//line j2g_strings.ae:1
package aot_arbace_build_go

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.coreyn20,arbace.repr.go.printkn2,asyn1,pyn13,arbace.stringyn3,strkn3,docks15,arbace.build.go4,userkn4,elseyn2,nskn4,namekn4,pathkn4,filekn7,packagekn4,readkn8,packageskn3,pkgkn13,package-file?kn9,collectedkn7,versionkn3,zipkn3,modkn8,library?kn5,rootskn11,print-cachekn9,main-pathkn6,modulekn2,gokn3,dirkn4,mainkn5,fileskn3,srckn6,layoutkn9,line-filekn5,testskn4,gooskn6,gorootkn8,goos-dirkn5,lineskn5,gofmtkn10,test-fileskn11,other-fileskn11,embed-fileskn4,workkn6,configkn4,tagskn7,overlaykn3,pgokn12,goexperimentkn4,archkn10,print-onlykn3,outv11,arbace.core5,referR0,v11,arbace.core7,requireV3,R1,R2,R3,V3,R4,R2,R5,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core13,*loaded-libs*v11,arbace.core4,conjMyn15,arbace.build.gom2,R6,s4280,The program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/build-go [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] [--main PATH] DIR\n  bin/build-go --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.build.go with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.repr.go.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $ARBACE_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with REPR_GO_HOST_ID set, as bin/build-go sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again, nor its forms read (DIR/collect/, the collect index)\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --main PATH   the main package's import path, when DIR holds several (box/: the launcher,\n                  arbace/box/cmd/arbace-box, and the test guests, doc/go/BOX-NOTES.md)\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)v11,arbace.core7,ex-infov11,arbace.core5,mergem2,R7,TR8,v11,arbace.core7,sort-byv11,arbace.core6,filterv13,arbace.string10,ends-with?v11,arbace.core3,notv15,arbace.build.go9,data-dir?v11,arbace.core8,file-seqv11,arbace.core5,firstv11,arbace.core4,seq?R9,v20,arbace.repr.go.print13,go-ns-aliasesv11,arbace.core4,somev11,arbace.core7,symbol?v11,arbace.core4,namev11,arbace.core9,contains?v11,arbace.core9,namespacev11,arbace.core3,strv15,arbace.build.go13,root-packagesv11,arbace.core3,seqv11,arbace.core12,chunked-seq?v11,arbace.core11,chunk-firstv11,arbace.core12,chunk-bufferv11,arbace.core4,not=R10,v11,arbace.core12,chunk-appendv11,arbace.core10,chunk-consv11,arbace.core5,chunkv11,arbace.core10,chunk-restv11,arbace.core4,consv11,arbace.core4,restv11,arbace.core6,concatv11,arbace.core3,vecv11,arbace.core8,group-byR11,v15,arbace.build.go4,failv13,arbace.string4,joinv11,arbace.core3,mapR12,v11,arbace.core4,nextv15,arbace.build.go8,packagesv11,arbace.core6,zipmapv11,arbace.core4,pmapv20,arbace.repr.go.print10,read-formsv11,arbace.core5,applyv11,arbace.core6,formatv15,arbace.build.go3,hexv11,arbace.core4,atomv20,arbace.repr.go.print7,collectv11,arbace.core5,swap!R13,v11,arbace.core5,assocR14,v11,arbace.core7,string?v15,arbace.build.go8,rel-pathC12,java.io.Filev11,arbace.core4,map?v11,arbace.core6,pr-strv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core12,*print-meta*v11,arbace.core14,*print-length*v11,arbace.core13,*print-level*v11,arbace.core11,read-stringv11,arbace.core6,updateR15,v11,arbace.core4,intov11,arbace.core10,sorted-mapv11,arbace.core4,compR16,v11,arbace.core3,valv11,arbace.core4,spitv15,arbace.build.go9,clj-filesv15,arbace.build.go18,collect-index-filev15,arbace.build.go10,read-indexv15,arbace.build.go8,file-shav11,arbace.core6,every?v11,arbace.core3,setR17,v15,arbace.build.go8,read-allv15,arbace.build.go13,package-file?v11,arbace.core4,mapvR18,v15,arbace.build.go15,collect-packagev11,arbace.core6,empty?v11,arbace.core11,select-keysV3,R13,R10,R11,V3,R13,R10,R11,v15,arbace.build.go12,write-index!V4,R13,R10,R11,R14,V4,R13,R10,R11,R14,v11,arbace.core5,slurpv15,arbace.build.go11,tamago-goosm2,s7,GOARM64s4,v8.0m2,s7,GOAMD64s2,v1v15,arbace.build.go6,go-envv15,arbace.build.go3,runv13,arbace.string4,trimv11,arbace.core8,to-arrayR19,R20,R21,v15,arbace.build.go12,go-mod-cachev15,arbace.build.go10,h1-of-filev11,arbace.core7,re-findp13,^go(\\d+\\.\\d+)R22,R23,R24,R25,R26,v15,arbace.build.go16,read-program-ednR27,v15,arbace.build.go14,toolchain-langR28,v13,arbace.string12,starts-with?v11,arbace.core4,subsR29,v15,arbace.build.go7,programv11,arbace.core10,into-arrayC24,java.nio.file.CopyOptionl0,v15,arbace.build.go9,forms-dirR30,R31,R32,R33,v13,arbace.string11,split-linesv15,arbace.build.go11,delete-treev11,arbace.core4,keysR34,R35,R36,R37,V1,s6,go.modR38,R39,R40,v11,arbace.core7,filtervv15,arbace.build.go15,print-cache-keyl2,v15,arbace.build.go12,cached-textsv20,arbace.repr.go.print11,print-formsv15,arbace.build.go15,with-line-filesv15,arbace.build.go17,collected-packageR41,R42,v15,arbace.build.go12,cache-texts!v15,arbace.build.go9,copy-filev15,arbace.build.go6,sha256v15,arbace.build.go13,tamago-go-sumR43,R44,v11,arbace.core10,make-arrayC37,java.nio.file.attribute.FileAttributeR45,v15,arbace.build.go14,tamago-ldflagsR46,R47,R48,v15,arbace.build.go12,print-moduleR49,R50,R51,v11,arbace.core4,lastv13,arbace.string5,splitp1,/v15,arbace.build.go5,buildR7,v11,arbace.core7,ex-datal1,v11,arbace.core7,printlnv11,arbace.core5,*out*v11,arbace.core5,*err*v11,arbace.core5,nnextv11,arbace.core6,secondv11,arbace.core7,keywordv11,arbace.core4,fnilS2,s5,amd64s5,arm64S4,ns5,linuxs6,tamagos6,darwinS3,nR38,R39,v11,arbace.core15,shutdown-agents")

var Lit_1 *jrt.String = jrt.Intern("ARBACE_GOROOT")

var Lit_2 *jrt.String = jrt.Intern("/root/tamago-go")

var Lit_3 *jrt.String = jrt.Intern("usage: bin/build-go [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines] [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--root ROOT]... [--goos-dir DIR] [--main PATH] DIR\n")

var Lit_4 *jrt.String = jrt.Intern("       bin/build-go --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines] [--line-file] SRC")

var Lit_5 *jrt.String = jrt.Intern("amd64")

var Lit_6 *jrt.String = jrt.Intern("--module")

var Lit_7 *jrt.String = jrt.Intern("--print-only")

var Lit_8 *jrt.String = jrt.Intern("--tests")

var Lit_9 *jrt.String = jrt.Intern("--work")

var Lit_10 *jrt.String = jrt.Intern("--layout")

var Lit_11 *jrt.String = jrt.Intern("--goos-dir")

var Lit_12 *jrt.String = jrt.Intern("-o")

var Lit_13 *jrt.String = jrt.Intern("--arch")

var Lit_14 *jrt.String = jrt.Intern("--line-file")

var Lit_15 *jrt.String = jrt.Intern("--goos")

var Lit_16 *jrt.String = jrt.Intern("--root")

var Lit_17 *jrt.String = jrt.Intern("--overlay")

var Lit_18 *jrt.String = jrt.Intern("--print-cache")

var Lit_19 *jrt.String = jrt.Intern("--main")

var Lit_20 *jrt.String = jrt.Intern("--pgo")

var Lit_21 *jrt.String = jrt.Intern("-")

var Lit_22 *jrt.String = jrt.Intern("arbace.build.go$_main$fn__1901000388")

var Lit_23 *jrt.String = jrt.Intern("arbace.build.go$_main$fn__1901000390")

var Lit_24 *jrt.String = jrt.Intern("mod")

var Lit_25 *jrt.String = jrt.Intern("arbace.build.go$_main$fn__1901000390$fn__1901000391")

var Lit_26 *jrt.String = jrt.Intern("build-go: ")

var Lit_27 *jrt.String = jrt.Intern("build-go")

var Lit_28 *jrt.String = jrt.Intern("tamago")

var Lit_29 *jrt.String = jrt.Intern("/bin/go")

var Lit_30 *jrt.String = jrt.Intern("build")

var Lit_31 *jrt.String = jrt.Intern("-trimpath")

var Lit_32 *jrt.String = jrt.Intern("-buildvcs=false")

var Lit_33 *jrt.String = jrt.Intern("-tags")

var Lit_34 *jrt.String = jrt.Intern(",")

var Lit_35 *jrt.String = jrt.Intern("-ldflags")

var Lit_36 *jrt.String = jrt.Intern("-overlay")

var Lit_37 *jrt.String = jrt.Intern("-pgo")

var Lit_38 *jrt.String = jrt.Intern("linux")

var Lit_39 *jrt.String = jrt.Intern("GOEXPERIMENT")

var Lit_40 *jrt.String = jrt.Intern(".tmp.")

var Lit_41 *jrt.String = jrt.Intern("f-")

var Lit_42 *jrt.String = jrt.Intern("names")

var Lit_43 *jrt.String = jrt.Intern("arbace.build.go$cache_texts_BANG_$fn__1901000326")

var Lit_44 *jrt.String = jrt.Intern("\n")

var Lit_45 *jrt.String = jrt.Intern("arbace.build.go$cached_texts$iter__1901000304__1901000308")

var Lit_46 *jrt.String = jrt.Intern("arbace.build.go$cached_texts$iter__1901000304__1901000308$fn__1901000309")

var Lit_47 *jrt.String = jrt.Intern("arbace.build.go$cached_texts$iter__1901000304__1901000308$fn__1901000309$fn__1901000310")

var Lit_48 *jrt.String = jrt.Intern("arbace.build.go$clj_files$fn__1901000020")

var Lit_49 *jrt.String = jrt.Intern("arbace.build.go$clj_files$fn__1901000022")

var Lit_50 *jrt.String = jrt.Intern(".ae")

var Lit_51 *jrt.String = jrt.Intern("SHA-256")

var Lit_52 *jrt.String = jrt.Intern("UTF-8")

var Lit_53 *jrt.String = jrt.Intern("collect")

var Lit_54 *jrt.String = jrt.Intern("arbace.build.go$collect_package$fn__1901000076")

var Lit_55 *jrt.String = jrt.Intern(": go/package without :path")

var Lit_56 *jrt.String = jrt.Intern(": collected again, the package differs from the collect index's")

var Lit_57 *jrt.String = jrt.Intern(".build-go-data")

var Lit_58 *jrt.String = jrt.Intern("java.io.File")

var Lit_59 *jrt.String = jrt.Intern("java.nio.file.Files")

var Lit_60 *jrt.String = jrt.Intern("java.nio.file.CopyOption")

var Lit_61 *jrt.String = jrt.Intern("java.nio.file.StandardCopyOption")

var Lit_62 *jrt.String = jrt.Intern("java.nio.file.attribute.FileAttribute")

var Lit_63 *jrt.String = jrt.Intern("java.security.MessageDigest")

var Lit_64 *jrt.String = jrt.Intern("GOOSPKG")

var Lit_65 *jrt.String = jrt.Intern("arm64")

var Lit_66 *jrt.String = jrt.Intern("No matching clause: ")

var Lit_67 *jrt.String = jrt.Intern("env")

var Lit_68 *jrt.String = jrt.Intern("GOMODCACHE")

var Lit_69 *jrt.String = jrt.Intern(".")

var Lit_70 *jrt.String = jrt.Intern("GOROOT")

var Lit_71 *jrt.String = jrt.Intern("GOTOOLCHAIN")

var Lit_72 *jrt.String = jrt.Intern("local")

var Lit_73 *jrt.String = jrt.Intern("go env GOMODCACHE: ")

var Lit_74 *jrt.String = jrt.Intern("arbace.build.go$h1_of_file$hex__1901000239")

var Lit_75 *jrt.String = jrt.Intern("arbace.build.go$h1_of_file$sha__1901000243")

var Lit_76 *jrt.String = jrt.Intern("  ")

var Lit_77 *jrt.String = jrt.Intern("h1:")

var Lit_78 *jrt.String = jrt.Intern("arbace.build.go$h1_of_file$hex__1901000239$fn__1901000240")

var Lit_79 *jrt.String = jrt.Intern("%02x")

var Lit_80 *jrt.String = jrt.Intern("arbace.build.go$hex$fn__1901000072")

var Lit_81 *jrt.String = jrt.Intern("arbace.build.go$package_file_QMARK_$fn__1901000027")

var Lit_82 *jrt.String = jrt.Intern("arbace.build.go$package_file_QMARK_$fn__1901000029")

var Lit_83 *jrt.String = jrt.Intern("package")

var Lit_84 *jrt.String = jrt.Intern("arbace.build.go$packages$iter__1901000034__1901000040")

var Lit_85 *jrt.String = jrt.Intern("two package files for ")

var Lit_86 *jrt.String = jrt.Intern(": ")

var Lit_87 *jrt.String = jrt.Intern(", ")

var Lit_88 *jrt.String = jrt.Intern("arbace.build.go$packages$fn__1901000057")

var Lit_89 *jrt.String = jrt.Intern("arbace.build.go$packages$fn__1901000062")

var Lit_90 *jrt.String = jrt.Intern("arbace.build.go$packages$iter__1901000034__1901000040$fn__1901000041")

var Lit_91 *jrt.String = jrt.Intern("arbace.build.go$packages$iter__1901000034__1901000040$fn__1901000041$iter__1901000036__1901000042")

var Lit_92 *jrt.String = jrt.Intern("arbace.build.go$packages$iter__1901000034__1901000040$fn__1901000041$iter__1901000036__1901000042$fn__1901000043")

var Lit_93 *jrt.String = jrt.Intern("arbace.build.go$packages$iter__1901000034__1901000040$fn__1901000041$iter__1901000036__1901000042$fn__1901000043$fn__1901000044")

var Lit_94 *jrt.String = jrt.Intern("main")

var Lit_95 *jrt.String = jrt.Intern("arbace.build.go$print_cache_key$add__1901000295")

var Lit_96 *jrt.String = jrt.Intern("")

var Lit_97 *jrt.String = jrt.Intern("arbace.build.go$print_cache_key$fn__1901000301")

var Lit_98 *jrt.String = jrt.Intern("std")

var Lit_99 *jrt.String = jrt.Intern("go.mod")

var Lit_100 *jrt.String = jrt.Intern("module ")

var Lit_101 *jrt.String = jrt.Intern("\n\ngo ")

var Lit_102 *jrt.String = jrt.Intern("\n// GOOSPKG, the runtime's goos (TamaGo's): imported by no package\nrequire ")

var Lit_103 *jrt.String = jrt.Intern(" ")

var Lit_104 *jrt.String = jrt.Intern("go.sum")

var Lit_105 *jrt.String = jrt.Intern("arbace.build.go$print_module$fn__1901000337")

var Lit_106 *jrt.String = jrt.Intern("arbace.build.go$print_module$fn__1901000337$printable__1901000339")

var Lit_107 *jrt.String = jrt.Intern("REPR_GO_HOST_ID")

var Lit_108 *jrt.String = jrt.Intern("arbace.build.go$print_module$fn__1901000337$rel__1901000346")

var Lit_109 *jrt.String = jrt.Intern(": go/package :files ")

var Lit_110 *jrt.String = jrt.Intern(" but go/file forms ")

var Lit_111 *jrt.String = jrt.Intern(": no embedded file ")

var Lit_112 *jrt.String = jrt.Intern(": embedded file ")

var Lit_113 *jrt.String = jrt.Intern(" has sha256 ")

var Lit_114 *jrt.String = jrt.Intern(", the forms say ")

var Lit_115 *jrt.String = jrt.Intern("arbace.build.go$print_module$fn__1901000337$printable__1901000339$fn__1901000340")

var Lit_116 *jrt.String = jrt.Intern("arbace.build.go$print_module$fn__1901000337$printable__1901000339$fn__1901000340$fn__1901000341")

var Lit_117 *jrt.String = jrt.Intern("/")

var Lit_118 *jrt.String = jrt.Intern("arbace.build.go$program$fn__1901000263")

var Lit_119 *jrt.String = jrt.Intern("arbace.build.go$program$fn__1901000265")

var Lit_120 *jrt.String = jrt.Intern("a program has one main package; found ")

var Lit_121 *jrt.String = jrt.Intern("no module path: give program.edn's :module or --module")

var Lit_122 *jrt.String = jrt.Intern("arbace.build.go$program$iter__1901000267__1901000271")

var Lit_123 *jrt.String = jrt.Intern("arbace.build.go$program$fn__1901000277")

var Lit_124 *jrt.String = jrt.Intern("arbace.build.go$program$iter__1901000267__1901000271$fn__1901000272")

var Lit_125 *jrt.String = jrt.Intern("arbace.build.go$program$iter__1901000267__1901000271$fn__1901000272$fn__1901000273")

var Lit_126 *jrt.String = jrt.Intern("package ")

var Lit_127 *jrt.String = jrt.Intern(" is not in the module ")

var Lit_128 *jrt.String = jrt.Intern("arbace.build.go$read_all$fn__1901000066")

var Lit_129 *jrt.String = jrt.Intern("arbace.build.go$read_all$fn__1901000068")

var Lit_130 *jrt.String = jrt.Intern("program.edn")

var Lit_131 *jrt.String = jrt.Intern("program.edn must hold one map, {:module \"path\" :go \"1.N\"}")

var Lit_132 *jrt.String = jrt.Intern("go")

var Lit_133 *jrt.String = jrt.Intern("no ")

var Lit_134 *jrt.String = jrt.Intern(": the program's forms go under DIR/go (doc/go/BUILD.md)")

var Lit_135 *jrt.String = jrt.Intern("arbace.build.go$root_packages$fn__1901000099")

var Lit_136 *jrt.String = jrt.Intern("arbace.build.go$root_packages$fn__1901000101")

var Lit_137 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000103__1901000107")

var Lit_138 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000131__1901000137")

var Lit_139 *jrt.String = jrt.Intern("arbace.build.go$root_packages$known_QMARK___1901000156")

var Lit_140 *jrt.String = jrt.Intern("arbace.build.go$root_packages$fn__1901000158")

var Lit_141 *jrt.String = jrt.Intern("arbace.build.go$root_packages$pkg_file_QMARK___1901000160")

var Lit_142 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166")

var Lit_143 *jrt.String = jrt.Intern("no package files (ns and go/package) under ")

var Lit_144 *jrt.String = jrt.Intern("arbace.build.go$root_packages$fn__1901000187")

var Lit_145 *jrt.String = jrt.Intern("arbace.build.go$root_packages$fn__1901000192")

var Lit_146 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000194__1901000198")

var Lit_147 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000204__1901000208")

var Lit_148 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000103__1901000107$fn__1901000108")

var Lit_149 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000103__1901000107$fn__1901000108$fn__1901000109")

var Lit_150 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000103__1901000107$fn__1901000108$fn__1901000124")

var Lit_151 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000103__1901000107$fn__1901000108$fn__1901000109$fn__1901000114")

var Lit_152 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000131__1901000137$fn__1901000138")

var Lit_153 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000131__1901000137$fn__1901000138$iter__1901000133__1901000142")

var Lit_154 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000131__1901000137$fn__1901000138$iter__1901000133__1901000142$fn__1901000143")

var Lit_155 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000131__1901000137$fn__1901000138$iter__1901000133__1901000142$fn__1901000143$fn__1901000144")

var Lit_156 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166$fn__1901000167")

var Lit_157 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166$fn__1901000167$fn__1901000168")

var Lit_158 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166$fn__1901000167$fn__1901000174")

var Lit_159 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166$fn__1901000167$fn__1901000176")

var Lit_160 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166$fn__1901000167$fn__1901000168$fn__1901000169")

var Lit_161 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000162__1901000166$fn__1901000167$fn__1901000168$fn__1901000171")

var Lit_162 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000194__1901000198$fn__1901000199")

var Lit_163 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000194__1901000198$fn__1901000199$fn__1901000200")

var Lit_164 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000204__1901000208$fn__1901000209")

var Lit_165 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000204__1901000208$fn__1901000209$fn__1901000210")

var Lit_166 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000204__1901000208$fn__1901000209$fn__1901000214")

var Lit_167 *jrt.String = jrt.Intern("arbace.build.go$root_packages$iter__1901000204__1901000208$fn__1901000209$fn__1901000210$fn__1901000211")

var Lit_168 *jrt.String = jrt.Intern("arbace.build.go$sha256$fn__1901000281")

var Lit_169 *jrt.String = jrt.Intern("/cache/download/")

var Lit_170 *jrt.String = jrt.Intern("/@v")

var Lit_171 *jrt.String = jrt.Intern(".ziphash")

var Lit_172 *jrt.String = jrt.Intern(".mod")

var Lit_173 *jrt.String = jrt.Intern(".zip")

var Lit_174 *jrt.String = jrt.Intern("@")

var Lit_175 *jrt.String = jrt.Intern(" is not in Go's module cache (")

var Lit_176 *jrt.String = jrt.Intern("): GOPROXY=off")

var Lit_177 *jrt.String = jrt.Intern("GOVERSION")

var Lit_178 *jrt.String = jrt.Intern("go env GOVERSION: ")

var Lit_179 *jrt.String = jrt.Intern("arbace.build.go$with_line_files$fn__1901000287")

var Lit_180 *jrt.String = jrt.Intern("arbace.build.go$with_line_files$fn__1901000287$fn__1901000288")

var Lit_181 *jrt.String = jrt.Intern("arbace.build.go$with_line_files$fn__1901000287$fn__1901000288$fn__1901000289")

var Lit_182 *jrt.String = jrt.Intern("arbace.build.go$write_index_BANG_$printed__1901000087")

var Lit_183 *jrt.String = jrt.Intern("arbace.build.go$write_index_BANG_$ok_QMARK___1901000089")

var Lit_184 *jrt.String = jrt.Intern("arbace.build.go$write_index_BANG_$fn__1901000091")

var Lit_185 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,msgyn1,&yn4,datakn4,linekn6,columnkn4,filekn3,tagyn4,Fileyn7,read-fnkn8,declaredyn5,rootsyn11,print-cacheyn5,filesyn5,bytesyn7,host-idyn12,java.io.Fileyn5,indexyn3,pkgyn3,cmdyn3,envyn8,inherit?yn6,gorootyn4,archyn4,gooskn4,pathkn7,versionkn3,zipkn3,modyn4,namekn4,keysyn8,library?kn2,asyn4,optsyn5,testsyn5,textsyn6,moduleyn8,packagesyn6,golangkn2,goyn6,layoutyn9,line-fileyn8,goos-diryn4,workyn4,argvv11,arbace.core5,in-nsMyn15,arbace.build.gom2,R0,s4280,The program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/build-go [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] [--main PATH] DIR\n  bin/build-go --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.build.go with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.repr.go.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $ARBACE_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with REPR_GO_HOST_ID set, as bin/build-go sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again, nor its forms read (DIR/collect/, the collect index)\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --main PATH   the main package's import path, when DIR holds several (box/: the launcher,\n                  arbace/box/cmd/arbace-box, and the test guests, doc/go/BOX-NOTES.md)\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)m2,R0,s4280,The program build: a Go program held as Go forms (doc/go/SPEC.md) to a static Linux\n  executable (doc/go/BUILD.md).\n\n  bin/build-go [--arch amd64|arm64] [--goos linux|tamago|darwin] [-o OUT] [--layout gofmt|lines]\n                [--line-file] [--work DIR] [--overlay FILE] [--pgo FILE] [--print-cache DIR] [--root ROOT]...\n                [--goos-dir DIR] [--main PATH] DIR\n  bin/build-go --print-only --work DIR [--tests] [--module PATH] [--layout gofmt|lines]\n                [--line-file] SRC\n  runs -m arbace.build.go with the same arguments. DIR holds the program's packages as forms\n  under DIR/go/ (SPEC §4.1: go/<path>.ae, the package file, and the files it loads), and\n  optionally DIR/program.edn, {:module \"path\" :go \"1.N\"} (go.mod's module and go lines; by\n  default the main package's path and the toolchain's language version). Each package is\n  printed (arbace.repr.go.print) into a temporary module, its other and embedded files copied\n  from its forms directory (go/<path>/), and the main package is built with\n\n    CGO_ENABLED=0 GOOS=linux GOARCH=<arch> go build -trimpath -buildvcs=false -o OUT\n\n  into a static executable (GOOS=tamago: a TamaGo image, below). OUT defaults to the main package path's last element in the\n  current directory. The toolchain is $ARBACE_GOROOT/bin/go (default /root/tamago-go, go1.27.1).\n    --arch        amd64 (default) or arm64 (GOAMD64=v1, GOARM64=v8.0)\n    --layout      the printed Go's layout: gofmt (default) or lines (SPEC §12.3)\n    --line-file   layout lines, each file starting with a //line directive naming its forms\n                  file, so that gc's positions (panics' tracebacks) name the forms files and\n                  lines: <package path>/<file>.ae for DIR/go/<path>/<file>.ae\n    --work DIR    print the module into DIR (kept); by default a temporary directory, removed\n                  after the build\n    --overlay FILE  passed to go build as -overlay FILE (absolute): a JSON file replacing\n                  files of the build, such as patched Go runtime files (BUILD.md, \"Overlays\")\n    --pgo FILE    passed to go build as -pgo FILE (absolute): a CPU profile for gc's\n                  profile-guided optimization (doc/go/SPEED-NOTES.md)\n    --print-cache DIR  a cache of printed packages (with REPR_GO_HOST_ID set, as bin/build-go sets it\n                  for this option): a package the same host printed from the same forms\n                  is not printed again, nor its forms read (DIR/collect/, the collect index)\n    --goos        linux (default); darwin (the box's launcher on the Mac, cgo off: S4, BX61);\n                  or tamago: a guest image for the box (doc/go/BOX-NOTES.md,\n                  S1), built with GOOS=tamago and TamaGo's goos module as GOOSPKG\n                  (github.com/usbarmory/tamago, tamago-goos below: go.mod requires it and\n                  go.sum holds its hashes, taken from Go's module cache, GOPROXY=off, and\n                  checked against the pinned ones), linked at the box's addresses\n                  (-ldflags \"-T 0x201000 -R 0x1000\", go-whim's), symbols kept (the monitor\n                  reads them), DWARF dropped (-w)\n    --root ROOT   another source root of forms (ROOT/go/...), whose packages but a main one\n                  join the program (the box's, box/: the board the guest imports); repeated\n                  for several\n    --print-only  print the module into --work DIR/mod and stop: no build, and no main\n                  package required (a library such as jrt, built and tested by bin/jrt)\n    --tests       also print the packages' :test-files (SPEC §4.2), for go test\n    --main PATH   the main package's import path, when DIR holds several (box/: the launcher,\n                  arbace/box/cmd/arbace-box, and the test guests, doc/go/BOX-NOTES.md)\n    --module PATH the module path when SRC has no program.edn (a library has no main\n                  package to take it from); std prints the standard library's packages at\n                  their import paths, as GOROOT/src holds them, without go.mod\n    --goos-dir DIR  with --goos tamago: TamaGo's goos module is DIR (go.mod replaces it by\n                  DIR), not Go's module cache: the module printed from its Go forms\n                  (bin/tamago-vendor print)R1,v15,arbace.build.go4,failm10,R2,TR3,L1,V3,R4,R5,V1,R6,R7,i64,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go9,data-dir?m12,R2,TR3,L1,V2,Myn3,dirm2,R10,R11,Myn1,fm2,R10,R11,R0,s171,Whether f is under a directory of data, not forms: one holding a file .build-go-data (a\n  package's embedded files, such as j2g --program's sources, doc/go/EVAL-NOTES.md).R7,i70,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go9,clj-filesm10,R2,TR3,L1,V1,Myn3,dirm2,R10,R11,R7,i79,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go13,package-file?m12,R2,TR3,L1,V2,Myn1,fm2,R10,R11,R12,R0,s109,Whether a forms file is a package file: it holds an ns form and a go/package form.\n  read-fn gives its forms.R7,i85,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go13,root-packagesm8,R13,TR7,i99,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go8,rel-pathm10,R2,TR3,L1,V2,Myn4,basem2,R10,R11,Myn1,fm2,R10,R11,R7,i101,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go8,packagesm10,R3,L3,V1,Myn3,dirm2,R10,R11,V2,Myn3,dirm2,R10,R11,R14,V3,Myn3,dirm2,R10,R11,R14,R15,R0,s465,The program's packages: the package files under DIR/go, each collected (arbace.repr.go.print\n  /collect) with :file (the package file) and :path; then those of each of the other roots\n  (--root), but their main packages. With print-cache (a directory) and the environment's\n  REPR_GO_HOST_ID, a package whose files are unchanged since the same host collected it is taken\n  from the print cache's collect index, its forms read only if it must be printed (collected).R7,i104,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go8,read-allm12,R2,TR3,L1,V1,R16,R0,s253,A function of a forms file giving its forms (p/read-forms), the files given read\n  beforehand, in parallel, each once: reading is most of collecting a large program on the Go\n  executable, whose reader is slower than the JVM's (doc/STANDALONE-NOTES.md).R7,i124,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go3,hexm10,R2,TR3,L1,V1,Myn2,bsm2,R10,R17,R7,i135,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go8,file-sham12,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R0,s60,The SHA-256 of a file's bytes, or nil when it is not a file.R7,i138,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go15,collect-packagem12,R2,TR3,L1,V3,Myn3,dirm2,R10,R11,Myn1,fm2,R10,R11,R12,R0,s145,Package file f collected (arbace.repr.go.print/collect), with :file, :path and :read (the forms\n  files it is made of: print-module's cache key).R7,i144,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go18,collect-index-filem10,R2,TR3,L1,MV3,R15,R18,Myn3,dirm2,R10,R11,m2,R10,R19,R7,i161,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go10,read-indexm12,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R0,s93,The collect index in f, or nil; its mtime set, as the print cache's entries' (trimmed alike).R7,i166,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go12,write-index!m12,R2,TR3,L1,V2,Myn1,fm2,R10,R11,R20,R0,s143,Writes the collect index atomically (a file renamed); an entry whose data does not print and\n  read back equal (metadata included) is left out.R7,i174,R8,i1,R9,s18,arbace/build/go.aem12,R2,TR3,L1,V2,Myn3,dirm2,R10,R11,R15,R0,s176,The package files under DIR/go, collected (with print-cache, from the collect index when\n  their files are unchanged: :collected then delays the collection, collected-package).R7,i186,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go17,collected-packagem12,R2,TR3,L1,V1,R21,R0,s108,A package from the collect index collected, its forms read (to print it): the same package\n  as the index's.R7,i233,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go16,read-program-ednm10,R2,TR3,L1,V1,Myn3,dirm2,R10,R11,R7,i244,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go3,runm12,R2,TR3,L1,V4,R22,Myn3,dirm2,R10,R11,R23,R24,R0,s148,Runs cmd in dir with env added to the JVM's; [exit output] with output captured, or\n  [exit nil] with the child's output on the JVM's when inherit?.R7,i253,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go11,tamago-goosm8,R13,TR7,i269,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go6,go-envm10,R3,L2,V2,R25,R26,V3,R25,R26,R27,R0,s195,The build's environment: the toolchain, GOOS/ARCH (linux by default; tamago with TamaGo's\n  goos module as GOOSPKG), no cgo, nothing from the user's Go environment that could change\n  the output.R7,i271,R8,i1,R9,s18,arbace/build/go.aem8,R28,s27,github.com/usbarmory/tamagoR29,s7,v1.27.1R30,s47,h1:Zl4w3hu5DaogGvcLzunS4gjwNEqdjFFJedMO3pDQa5k=R31,s47,h1:nLuV/bBHbtlpWOJftse7cr219b/Z6vitr5fyv/OHkK4=m8,R7,i288,R8,i1,R9,s18,arbace/build/go.aeR0,s275,TamaGo's goos module, the runtime/goos implementation a GOOS=tamago build names as GOOSPKG\n  (BSD-3-Clause, LICENSE.md): its version and its go.sum hashes, pinned (the module's zip, its\n  go.mod). The build takes it from Go's module cache (GOPROXY=off) and checks the hashes.v15,arbace.build.go14,tamago-ldflagsm8,R7,i296,R8,i1,R9,s18,arbace/build/go.aeR0,s189,A box guest's link: text at 0x201000, 4 KiB segments (go-whim's guest/gotamago.go), the\n  symbol table kept (the monitor finds the board's and the runtime's symbols in it), DWARF\n  dropped.v15,arbace.build.go12,go-mod-cachem10,R2,TR3,L1,V1,R25,R7,i302,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go10,h1-of-filem12,R2,TR3,L1,V2,Myn4,datam2,R10,R17,R32,R0,s75,go.sum's h1 hash of one file named name (golang.org/x/mod's dirhash.Hash1).R7,i308,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go13,tamago-go-summ10,R3,L1,V1,R25,R0,s101,go.sum's lines for TamaGo's goos module, from Go's module cache, checked against the pinned\n  hashes.R7,i316,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go14,toolchain-langm12,R2,TR3,L1,V1,R25,R0,s62,The toolchain's language version, 1.N (from go env GOVERSION).R7,i332,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go7,programm10,R3,L2,V2,Myn3,dirm2,R10,R11,R25,V3,Myn3,dirm2,R10,R11,R25,m4,R33,V2,R34,R14,R35,R36,R0,s629,The program in DIR: {:module :go :main pkg :packages [pkg ...]}, every package with :dir,\n  its directory in the module (\"\" for the module's root). With :library? (opts), no main\n  package is required and :module (opts) gives the module path when program.edn does not; with\n  :module, a library may hold several (GOROOT/src's tree, module std: Go's toolchain, cmd/'s,\n  standalone S9; box/, module arbace: the launcher and the test guests, doc/go/BOX-NOTES.md);\n  :main-path (opts), the import path of the main package, chooses it among several;\n  :go (opts) the language version when program.edn does not (else the toolchain's).R7,i342,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go6,sha256m10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i381,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go9,copy-filem10,R2,TR3,L1,V2,Myn4,fromm2,R10,R11,Myn2,tom2,R10,R11,R7,i385,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go9,forms-dirm12,R2,TR3,L1,MV1,R21,m2,R10,R19,R0,s114,The package's forms directory: its package file without .ae (SPEC §4.1), where its\n  other and embedded files are.R7,i390,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go15,with-line-filesm12,R2,TR3,L1,V1,R21,R0,s348,The package's files with :src for --line-file: the forms file's path relative to the\n  package's forms directory (go/<path>/), which gc resolves in the package's directory, so\n  that -trimpath names it <package path>/<file>.ae, wherever DIR is. (A path outside the\n  package's directory would escape -trimpath's rewriting and keep the host's path.)R7,i398,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go11,delete-treem8,R13,TR7,i407,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go15,print-cache-keym12,R2,TR3,L1,V5,R18,R21,Myn3,dirm2,R10,R11,R36,R37,R0,s286,The key of a package's printed files in the print cache: the host's identity (REPR_GO_HOST_ID:\n  the executable's and repr/go's sources' hashes, bin/lib/repr-go-host.bash), the options that change\n  the printing, the package's path and its forms files (their paths in dir and contents).R7,i409,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go12,cached-textsm12,R2,TR3,L1,V1,Myn5,entrym2,R10,R11,R0,s233,The printed files of a package from the print cache, each the File of its entry's copy (its\n  bytes copied as they are, not decoded and encoded again), or nil. The entry's mtime is set:\n  bin/arbace-go trims entries unused for hours.R7,i424,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go12,cache-texts!m12,R2,TR3,L1,V2,Myn5,entrym2,R10,R11,R38,R0,s87,Records a package's printed files in the print cache, atomically (a directory renamed).R7,i436,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go12,print-modulem10,R3,L1,V4,m4,R33,V2,R39,R40,R41,R42,Myn3,dirm2,R10,R11,Myn3,outm2,R10,R11,m2,R33,V7,R43,R44,R37,R27,R25,R45,R15,R0,s713,Prints the program into the module directory out: go.mod, and per package its Go files\n  and the other and embedded files it names. Returns the printed files, relative to out.\n  The module std (the standard library, GOROOT/src) gets no go.mod: GOROOT/src's go.mod,\n  go.sum and vendor/modules.txt are files of the tree it is printed into (bin/tamago-vendor).\n  With goos-dir (GOOS=tamago), TamaGo's goos module is that directory (a replace), not Go's\n  module cache. Packages are printed in parallel. With print-cache (a directory) and the\n  environment's REPR_GO_HOST_ID, a package printed before by the same host from the same forms is\n  taken from the cache (standalone S6: a build reprints only what changed).R7,i445,R8,i1,R9,s18,arbace/build/go.aem10,R2,TR3,L1,V1,Myn1,fm2,R10,R11,R7,i517,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go5,buildm10,R3,L1,V4,Myn3,dirm2,R10,R11,R26,Myn3,outm2,R10,R11,m4,R33,V2,R46,R25,R35,R36,R0,s118,Builds the program in dir for linux/arch into out (a File); returns go build's exit\n  status, its output on the JVM's.R7,i522,R8,i1,R9,s18,arbace/build/go.aev15,arbace.build.go5,-mainm8,R3,L1,V2,R5,R47,R7,i554,R8,i1,R9,s18,arbace/build/go.ae")

var Lit_186 *jrt.String = jrt.Intern("arbace.build.go$eval1901000004$loading__1927001464__auto____1901000005")

var Lit_187 *jrt.String = jrt.Intern("arbace.build.go$eval1901000008$fn__1901000009")

var Lit_188 *jrt.String = jrt.Intern("arbace.build.go$fail")

var Lit_189 *jrt.String = jrt.Intern("arbace.build.go$data_dir_QMARK_")

var Lit_190 *jrt.String = jrt.Intern("arbace.build.go$clj_files")

var Lit_191 *jrt.String = jrt.Intern("arbace.build.go$package_file_QMARK_")

var Lit_192 *jrt.String = jrt.Intern("arbace.build.go$rel_path")

var Lit_193 *jrt.String = jrt.Intern("arbace.build.go$packages")

var Lit_194 *jrt.String = jrt.Intern("arbace.build.go$read_all")

var Lit_195 *jrt.String = jrt.Intern("arbace.build.go$hex")

var Lit_196 *jrt.String = jrt.Intern("arbace.build.go$file_sha")

var Lit_197 *jrt.String = jrt.Intern("arbace.build.go$collect_package")

var Lit_198 *jrt.String = jrt.Intern("arbace.build.go$collect_index_file")

var Lit_199 *jrt.String = jrt.Intern("arbace.build.go$read_index")

var Lit_200 *jrt.String = jrt.Intern("arbace.build.go$write_index_BANG_")

var Lit_201 *jrt.String = jrt.Intern("arbace.build.go$root_packages")

var Lit_202 *jrt.String = jrt.Intern("arbace.build.go$collected_package")

var Lit_203 *jrt.String = jrt.Intern("arbace.build.go$read_program_edn")

var Lit_204 *jrt.String = jrt.Intern("arbace.build.go$run")

var Lit_205 *jrt.String = jrt.Intern("arbace.build.go$go_env")

var Lit_206 *jrt.String = jrt.Intern("-T 0x201000 -R 0x1000 -w")

var Lit_207 *jrt.String = jrt.Intern("arbace.build.go$go_mod_cache")

var Lit_208 *jrt.String = jrt.Intern("arbace.build.go$h1_of_file")

var Lit_209 *jrt.String = jrt.Intern("arbace.build.go$tamago_go_sum")

var Lit_210 *jrt.String = jrt.Intern("arbace.build.go$toolchain_lang")

var Lit_211 *jrt.String = jrt.Intern("arbace.build.go$program")

var Lit_212 *jrt.String = jrt.Intern("arbace.build.go$sha256")

var Lit_213 *jrt.String = jrt.Intern("arbace.build.go$copy_file")

var Lit_214 *jrt.String = jrt.Intern("arbace.build.go$forms_dir")

var Lit_215 *jrt.String = jrt.Intern("arbace.build.go$with_line_files")

var Lit_216 *jrt.String = jrt.Intern("arbace.build.go$print_cache_key")

var Lit_217 *jrt.String = jrt.Intern("arbace.build.go$cached_texts")

var Lit_218 *jrt.String = jrt.Intern("arbace.build.go$cache_texts_BANG_")

var Lit_219 *jrt.String = jrt.Intern("arbace.build.go$print_module")

var Lit_220 *jrt.String = jrt.Intern("arbace.build.go$delete_tree")

var Lit_221 *jrt.String = jrt.Intern("arbace.build.go$build")

var Lit_222 *jrt.String = jrt.Intern("arbace.build.go$_main")
