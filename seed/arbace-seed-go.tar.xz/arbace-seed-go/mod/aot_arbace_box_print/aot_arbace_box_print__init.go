//line aot_arbace_box_print__init.ae:1
package aot_arbace_box_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_print__init_A_Unit0__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return lang.IFn_Cast(jrt.NN(A_arbace_box_print__init_A_const_0).GetRawRoot__O()).Invoke_O__O(A_arbace_box_print__init_A_const_1) }
//line :4:1
func A_arbace_box_print__init_A_Unit1__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); return Up_Namespace_AReference(lang.Namespace_Find_Symbol__Namespace(lang.Symbol_Cast(A_arbace_box_print__init_A_const_1))).ResetMeta_IPersistentMap__IPersistentMap(lang.IPersistentMap_Cast(A_arbace_box_print__init_A_const_2)) }
//line :4:1
func A_arbace_box_print__init_A_Unit2__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); var tmp1 any = A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New(); var tmp2 *jrt.Class; A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_Init(); tmp2 = A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class; return lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil).Invoke__O() }
//line :4:1
func A_arbace_box_print__init_A_Unit3__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(4, 1); if jrt.NN(lang.Symbol_Cast(A_arbace_box_print__init_A_const_1)).Equals_O__Z(A_arbace_box_print__init_A_const_3) { return nil } else { var tmp1 any = A_arbace_box_print_eval1463000008_fn__1463000009_A_New(); var tmp2 *jrt.Class; A_arbace_box_print_eval1463000008_fn__1463000009_A_Init(); tmp2 = A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class; lang.LockingTransaction_RunInTransaction_Callable__O(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp1, tmp2, nil)); return nil } }
func A_arbace_box_print__init_A_Load__O() any { A_arbace_box_print__init_A_Init(); A_arbace_box_print__init_A_Unit0__O(); A_arbace_box_print__init_A_Unit1__O(); A_arbace_box_print__init_A_Unit2__O(); A_arbace_box_print__init_A_Unit3__O(); A_arbace_box_print__init_A_Unit4__O(); A_arbace_box_print__init_A_Unit5__O(); A_arbace_box_print__init_A_Unit6__O(); A_arbace_box_print__init_A_Unit7__O(); return nil }






func A_arbace_box_print__init_A_Unit4__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(12, 1); var tmp1 *lang.Var = A_arbace_box_print__init_A_const_4; var tmp2 any = A_arbace_box_print_g2a_A_New(); var tmp3 *jrt.Class; A_arbace_box_print_g2a_A_Init(); tmp3 = A_arbace_box_print_g2a_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_print__init_A_const_4; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_print__init_A_const_5)); return A_arbace_box_print__init_A_const_4.Ref() }


func A_arbace_box_print__init_A_Unit5__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(15, 1); var tmp1 *lang.Var = A_arbace_box_print__init_A_const_6; var tmp2 any = A_arbace_box_print_print_goroot_A_New(); var tmp3 *jrt.Class; A_arbace_box_print_print_goroot_A_Init(); tmp3 = A_arbace_box_print_print_goroot_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_print__init_A_const_6; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_print__init_A_const_7)); return A_arbace_box_print__init_A_const_6.Ref() }

















func A_arbace_box_print__init_A_Unit6__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(33, 1); var tmp1 *lang.Var = A_arbace_box_print__init_A_const_8; var tmp2 any = A_arbace_box_print_print_program_A_New(); var tmp3 *jrt.Class; A_arbace_box_print_print_program_A_Init(); tmp3 = A_arbace_box_print_print_program_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp2, tmp3, nil)); var tmp4 *lang.Var = A_arbace_box_print__init_A_const_8; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_print__init_A_const_9)); return A_arbace_box_print__init_A_const_8.Ref() }












func A_arbace_box_print__init_A_Unit7__O() any { A_arbace_box_print__init_A_Init(); lang.Compiler_AOT_At_I_I__V(46, 1); var tmp1 *lang.Var = A_arbace_box_print__init_A_const_10; var tmp2 any = A_arbace_box_print__main_A_New(); var tmp3 *jrt.Class; A_arbace_box_print__main_A_Init(); tmp3 = A_arbace_box_print__main_A_fn_class; jrt.NN(tmp1).BindRoot_O__V(lang.Compiler_AOTRestFn_New_O_Class_IPersistentMap_I(tmp2, tmp3, nil, 0)); var tmp4 *lang.Var = A_arbace_box_print__init_A_const_10; jrt.NN(tmp4).SetMeta_IPersistentMap__V(lang.IPersistentMap_Cast(A_arbace_box_print__init_A_const_11)); return A_arbace_box_print__init_A_const_10.Ref() }



type A_arbace_box_print__init_A struct{ jrt.Object }

var A_arbace_box_print__init_A_const_0 *lang.Var

var A_arbace_box_print__init_A_const_1 any

var A_arbace_box_print__init_A_const_2 any

var A_arbace_box_print__init_A_const_3 any

var A_arbace_box_print__init_A_const_4 *lang.Var

var A_arbace_box_print__init_A_const_5 any

var A_arbace_box_print__init_A_const_6 *lang.Var

var A_arbace_box_print__init_A_const_7 any

var A_arbace_box_print__init_A_const_8 *lang.Var

var A_arbace_box_print__init_A_const_9 any

var A_arbace_box_print__init_A_const_10 *lang.Var

var A_arbace_box_print__init_A_const_11 any

var A_arbace_box_print__init_A_init jrt.ClassInit

func A_arbace_box_print__init_A_Init() { if !A_arbace_box_print__init_A_init.Done() { A_arbace_box_print__init_A_init.Run(A_arbace_box_print__init_A_clinit) } }

func A_arbace_box_print__init_A_clinit() { A_arbace_box_print__init_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_70); A_arbace_box_print__init_A_const_1 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_box_print__init_A_const_2 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7)); A_arbace_box_print__init_A_const_3 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_print__init_A_const_4 = lang.RT_Var_String_String__Var(Lit_5, Lit_11); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_71).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box_print__init_A_const_5 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_73).Ref())))), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(12).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_77)); A_arbace_box_print__init_A_const_6 = lang.RT_Var_String_String__Var(Lit_5, Lit_40); A_arbace_box_print__init_A_const_7 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_78, lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(15).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_77)); A_arbace_box_print__init_A_const_8 = lang.RT_Var_String_String__Var(Lit_5, Lit_39); A_arbace_box_print__init_A_const_9 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create__IPersistentVector()))), lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_79, lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(33).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_77)); A_arbace_box_print__init_A_const_10 = lang.RT_Var_String_String__Var(Lit_5, Lit_80); A_arbace_box_print__init_A_const_11 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_72).Ref(), lang.PersistentList_Create_List__IPersistentList(jrt.Arrays_AsList_O1__List(jrt.RefArrayOf(jrt.Object_class, lang.Tuple_Create_O_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_81).Ref(), lang.Tuple_Create_O__IPersistentVector(lang.Symbol_Intern_String_String__Symbol(nil, Lit_82).Ref()))))), lang.RT_Keyword_String_String__Keyword(nil, Lit_74).Ref(), jrt.Integer_ValueOf_I__Integer(46).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_75).Ref(), jrt.Integer_ValueOf_I__Integer(1).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_76).Ref(), Lit_77)) }

func A_arbace_box_print__init_A_New() *A_arbace_box_print__init_A { A_arbace_box_print__init_A_Init(); t := &A_arbace_box_print__init_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print__init_A) Ctor() {}

func (t *A_arbace_box_print__init_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print__init_A) GetClass__Class() *jrt.Class { return A_arbace_box_print__init_A_class }

func (t *A_arbace_box_print__init_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print__init_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print__init_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print__init_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print__init_A); return ok }

func A_arbace_box_print__init_A_Cast(x any) *A_arbace_box_print__init_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print__init_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print__init_A_class)) }; return v }
