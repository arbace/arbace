//line a2g_strings.ae:1
package aot_arbace_box_print

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("arbace.core")

var Lit_1 *jrt.String = jrt.Intern("refer")

var Lit_2 *jrt.String = jrt.Intern("commute")

var Lit_3 *jrt.String = jrt.Intern("deref")

var Lit_4 *jrt.String = jrt.Intern("conj")

var Lit_5 *jrt.String = jrt.Intern("arbace.box.print")

var Lit_6 *jrt.String = jrt.Intern("doc")

var Lit_7 *jrt.String = jrt.Intern("The printing steps of arbace.box.rebuild, each in its own guest:\n\n    arbace -m arbace.box.print print-goroot    tamago/ and overlay/go printed\n    arbace -m arbace.box.print print-program   a2g's program printed")

var Lit_8 *jrt.String = jrt.Intern("*loaded-libs*")

var Lit_9 *jrt.String = jrt.Intern("requiring-resolve")

var Lit_10 *jrt.String = jrt.Intern("ex-info")

var Lit_11 *jrt.String = jrt.Intern("g2a")

var Lit_12 *jrt.String = jrt.Intern("arbace.g2a.build")

var Lit_13 *jrt.String = jrt.Intern("program")

var Lit_14 *jrt.String = jrt.Intern("print-module")

var Lit_15 *jrt.String = jrt.Intern("arbace.g2a.print")

var Lit_16 *jrt.String = jrt.Intern("print-package")

var Lit_17 *jrt.String = jrt.Intern("library?")

var Lit_18 *jrt.String = jrt.Intern("module")

var Lit_19 *jrt.String = jrt.Intern("std")

var Lit_20 *jrt.String = jrt.Intern("layout")

var Lit_21 *jrt.String = jrt.Intern("lines")

var Lit_22 *jrt.String = jrt.Intern("github.com/usbarmory/tamago")

var Lit_23 *jrt.String = jrt.Intern("go")

var Lit_24 *jrt.String = jrt.Intern("1.27")

var Lit_25 *jrt.String = jrt.Intern("gofmt")

var Lit_26 *jrt.String = jrt.Intern("goos")

var Lit_27 *jrt.String = jrt.Intern("tamago")

var Lit_28 *jrt.String = jrt.Intern("line-file")

var Lit_29 *jrt.String = jrt.Intern("goos-dir")

var Lit_30 *jrt.String = jrt.Intern("/goos")

var Lit_31 *jrt.String = jrt.Intern("roots")

var Lit_32 *jrt.String = jrt.Intern("/s/box")

var Lit_33 *jrt.String = jrt.Intern("/s/x509roots")

var Lit_34 *jrt.String = jrt.Intern("spit")

var Lit_35 *jrt.String = jrt.Intern("pr-str")

var Lit_36 *jrt.String = jrt.Intern("config")

var Lit_37 *jrt.String = jrt.Intern("package")

var Lit_38 *jrt.String = jrt.Intern("main")

var Lit_39 *jrt.String = jrt.Intern("print-program")

var Lit_40 *jrt.String = jrt.Intern("print-goroot")

var Lit_41 *jrt.String = jrt.Intern("shutdown-agents")

var Lit_42 *jrt.String = jrt.Intern("println")

var Lit_43 *jrt.String = jrt.Intern("pop-thread-bindings")

var Lit_44 *jrt.String = jrt.Intern("push-thread-bindings")

var Lit_45 *jrt.String = jrt.Intern("hash-map")

var Lit_46 *jrt.String = jrt.Intern("*out*")

var Lit_47 *jrt.String = jrt.Intern("*err*")

var Lit_48 *jrt.String = jrt.Intern("arbace.box.print$_main")

var Lit_49 *jrt.String = jrt.Intern("arbace.box.print$_main$fn__1463000020")

var Lit_50 *jrt.String = jrt.Intern("usage: arbace -m arbace.box.print print-goroot|print-program")

var Lit_51 *jrt.String = jrt.Intern("arbace.box.print$eval1463000004$loading__1927001464__auto____1463000005")

var Lit_52 *jrt.String = jrt.Intern("java.io.File")

var Lit_53 *jrt.String = jrt.Intern("arbace.box.print$eval1463000008$fn__1463000009")

var Lit_54 *jrt.String = jrt.Intern("arbace.box.print$g2a")

var Lit_55 *jrt.String = jrt.Intern("arbace.box.print: no ")

var Lit_56 *jrt.String = jrt.Intern("arbace.box.print$print_goroot")

var Lit_57 *jrt.String = jrt.Intern("/nonexistent")

var Lit_58 *jrt.String = jrt.Intern("/f")

var Lit_59 *jrt.String = jrt.Intern("/o/std")

var Lit_60 *jrt.String = jrt.Intern("/g")

var Lit_61 *jrt.String = jrt.Intern("/o/goos")

var Lit_62 *jrt.String = jrt.Intern("overlay/go/runtime.ae")

var Lit_63 *jrt.String = jrt.Intern("/o/runtime")

var Lit_64 *jrt.String = jrt.Intern("overlay/go/syscall.ae")

var Lit_65 *jrt.String = jrt.Intern("/o/syscall")

var Lit_66 *jrt.String = jrt.Intern("arbace.box.print$print_program")

var Lit_67 *jrt.String = jrt.Intern("/p")

var Lit_68 *jrt.String = jrt.Intern("/o/mod")

var Lit_69 *jrt.String = jrt.Intern("/o/config.edn")

var Lit_70 *jrt.String = jrt.Intern("in-ns")

var Lit_71 *jrt.String = jrt.Intern("private")

var Lit_72 *jrt.String = jrt.Intern("arglists")

var Lit_73 *jrt.String = jrt.Intern("sym")

var Lit_74 *jrt.String = jrt.Intern("line")

var Lit_75 *jrt.String = jrt.Intern("column")

var Lit_76 *jrt.String = jrt.Intern("file")

var Lit_77 *jrt.String = jrt.Intern("arbace/box/print.ae")

var Lit_78 *jrt.String = jrt.Intern("In a guest (cwd /s, the sources): tamago/'s forms (/f the standard library's, /g the goos\n  module's: each its go/ with arch/amd64/go laid over it) printed as bin/tamago-vendor print\n  prints them into /o/std (GOROOT/src's layout) and /o/goos; overlay/go's runtime and syscall\n  printed as bin/jrt overlay and bin/lib/box-overlay.bash print them into /o/runtime and\n  /o/syscall.")

var Lit_79 *jrt.String = jrt.Intern("In a guest (cwd /s, the sources): a2g's program (/p) printed as bin/arbace-go --build --box\n  prints it (bin/g2a build --goos tamago --line-file, the roots box/ and x509roots/), into\n  /o/mod, the goos module's directory named /goos; the main package's configuration\n  (:tags, :goexperiment) into /o/config.edn.")

var Lit_80 *jrt.String = jrt.Intern("-main")

var Lit_81 *jrt.String = jrt.Intern("&")

var Lit_82 *jrt.String = jrt.Intern("cmd")
