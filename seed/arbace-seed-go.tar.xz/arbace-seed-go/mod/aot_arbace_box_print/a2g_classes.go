//line a2g_classes.ae:1
package aot_arbace_box_print

import (
	"arbace/jrt"
	"arbace/lang"
	"reflect"
)
//line :6:1
func A_arbace_box_print_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_A_New()}; return nil }

var A_arbace_box_print_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_print_A_new}

var A_arbace_box_print_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_print.A_arbace_box_print_A"})

func init() { i := A_arbace_box_print_A_class.Info(); i.IsInstance = A_arbace_box_print_A_InstanceOf; i.Init = A_arbace_box_print_A_Init; i.Table = A_arbace_box_print_A_members; jrt.RegisterGoType(A_arbace_box_print_A_class, reflect.TypeFor[A_arbace_box_print_A]()) }

func A_arbace_box_print__main_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print__main_A).DoInvoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_print__main_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print__main_A_New()}; return nil }

func A_arbace_box_print__main_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print__main_A_fn_class)}; return nil }

var A_arbace_box_print__main_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 doInvoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print__main_A_invoke, New: A_arbace_box_print__main_A_new, Get: A_arbace_box_print__main_A_get}

var A_arbace_box_print__main_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$_main", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTR0_class}, Declaring: A_arbace_box_print_A_class, Simple: "_main", Go: "arbace/aot_arbace_box_print.A_arbace_box_print__main_A", Source: "print.ae"})

func init() { i := A_arbace_box_print__main_A_class.Info(); i.IsInstance = A_arbace_box_print__main_A_InstanceOf; i.Init = A_arbace_box_print__main_A_Init; i.Table = A_arbace_box_print__main_A_members; jrt.RegisterGoType(A_arbace_box_print__main_A_class, reflect.TypeFor[A_arbace_box_print__main_A]()) }

func A_arbace_box_print__main_fn__1463000020_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print__main_fn__1463000020_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_print__main_fn__1463000020_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print__main_fn__1463000020_A_New()}; return nil }

func A_arbace_box_print__main_fn__1463000020_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print__main_fn__1463000020_A_fn_class)}; return nil }

var A_arbace_box_print__main_fn__1463000020_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print__main_fn__1463000020_A_invoke, New: A_arbace_box_print__main_fn__1463000020_A_new, Get: A_arbace_box_print__main_fn__1463000020_A_get}

var A_arbace_box_print__main_fn__1463000020_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$_main$fn__1463000020", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_print__main_A_class, Simple: "fn__1463000020", Go: "arbace/aot_arbace_box_print.A_arbace_box_print__main_fn__1463000020_A", Source: "print.ae"})

func init() { i := A_arbace_box_print__main_fn__1463000020_A_class.Info(); i.IsInstance = A_arbace_box_print__main_fn__1463000020_A_InstanceOf; i.Init = A_arbace_box_print__main_fn__1463000020_A_Init; i.Table = A_arbace_box_print__main_fn__1463000020_A_members; jrt.RegisterGoType(A_arbace_box_print__main_fn__1463000020_A_class, reflect.TypeFor[A_arbace_box_print__main_fn__1463000020_A]()) }

func A_arbace_box_print_eval1463000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_eval1463000004_A_New()}; return nil }

var A_arbace_box_print_eval1463000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_print_eval1463000004_A_new}

var A_arbace_box_print_eval1463000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$eval1463000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_print_A_class, Simple: "eval1463000004", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000004_A"})

func init() { i := A_arbace_box_print_eval1463000004_A_class.Info(); i.IsInstance = A_arbace_box_print_eval1463000004_A_InstanceOf; i.Table = A_arbace_box_print_eval1463000004_A_members; jrt.RegisterGoType(A_arbace_box_print_eval1463000004_A_class, reflect.TypeFor[A_arbace_box_print_eval1463000004_A]()) }

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New()}; return nil }

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class)}; return nil }

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_invoke, New: A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_new, Get: A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_get}

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$eval1463000004$loading__1927001464__auto____1463000005", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_print_eval1463000004_A_class, Simple: "loading__1927001464__auto____1463000005", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A", Source: "print.ae"})

func init() { i := A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class.Info(); i.IsInstance = A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_InstanceOf; i.Init = A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_Init; i.Table = A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_members; jrt.RegisterGoType(A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class, reflect.TypeFor[A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A]()) }

func A_arbace_box_print_eval1463000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_eval1463000008_A_New()}; return nil }

var A_arbace_box_print_eval1463000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_print_eval1463000008_A_new}

var A_arbace_box_print_eval1463000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$eval1463000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_print_A_class, Simple: "eval1463000008", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000008_A"})

func init() { i := A_arbace_box_print_eval1463000008_A_class.Info(); i.IsInstance = A_arbace_box_print_eval1463000008_A_InstanceOf; i.Table = A_arbace_box_print_eval1463000008_A_members; jrt.RegisterGoType(A_arbace_box_print_eval1463000008_A_class, reflect.TypeFor[A_arbace_box_print_eval1463000008_A]()) }

func A_arbace_box_print_eval1463000008_fn__1463000009_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print_eval1463000008_fn__1463000009_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_print_eval1463000008_fn__1463000009_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_eval1463000008_fn__1463000009_A_New()}; return nil }

func A_arbace_box_print_eval1463000008_fn__1463000009_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class)}; return nil }

var A_arbace_box_print_eval1463000008_fn__1463000009_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print_eval1463000008_fn__1463000009_A_invoke, New: A_arbace_box_print_eval1463000008_fn__1463000009_A_new, Get: A_arbace_box_print_eval1463000008_fn__1463000009_A_get}

var A_arbace_box_print_eval1463000008_fn__1463000009_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$eval1463000008$fn__1463000009", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_print_eval1463000008_A_class, Simple: "fn__1463000009", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000008_fn__1463000009_A", Source: "print.ae"})

func init() { i := A_arbace_box_print_eval1463000008_fn__1463000009_A_class.Info(); i.IsInstance = A_arbace_box_print_eval1463000008_fn__1463000009_A_InstanceOf; i.Init = A_arbace_box_print_eval1463000008_fn__1463000009_A_Init; i.Table = A_arbace_box_print_eval1463000008_fn__1463000009_A_members; jrt.RegisterGoType(A_arbace_box_print_eval1463000008_fn__1463000009_A_class, reflect.TypeFor[A_arbace_box_print_eval1463000008_fn__1463000009_A]()) }

func A_arbace_box_print_g2a_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print_g2a_A).Invoke_O_O__O(args[0], args[1])}; return nil }

func A_arbace_box_print_g2a_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_g2a_A_New()}; return nil }

func A_arbace_box_print_g2a_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print_g2a_A_fn_class)}; return nil }

var A_arbace_box_print_g2a_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print_g2a_A_invoke, New: A_arbace_box_print_g2a_A_new, Get: A_arbace_box_print_g2a_A_get}

var A_arbace_box_print_g2a_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$g2a", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF1_class}, Declaring: A_arbace_box_print_A_class, Simple: "g2a", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_g2a_A", Source: "print.ae"})

func init() { i := A_arbace_box_print_g2a_A_class.Info(); i.IsInstance = A_arbace_box_print_g2a_A_InstanceOf; i.Init = A_arbace_box_print_g2a_A_Init; i.Table = A_arbace_box_print_g2a_A_members; jrt.RegisterGoType(A_arbace_box_print_g2a_A_class, reflect.TypeFor[A_arbace_box_print_g2a_A]()) }

func A_arbace_box_print_print_goroot_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print_print_goroot_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_print_print_goroot_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_print_goroot_A_New()}; return nil }

func A_arbace_box_print_print_goroot_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print_print_goroot_A_fn_class)}; return nil }

var A_arbace_box_print_print_goroot_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print_print_goroot_A_invoke, New: A_arbace_box_print_print_goroot_A_new, Get: A_arbace_box_print_print_goroot_A_get}

var A_arbace_box_print_print_goroot_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$print_goroot", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_print_A_class, Simple: "print_goroot", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_print_goroot_A", Source: "print.ae"})

func init() { i := A_arbace_box_print_print_goroot_A_class.Info(); i.IsInstance = A_arbace_box_print_print_goroot_A_InstanceOf; i.Init = A_arbace_box_print_print_goroot_A_Init; i.Table = A_arbace_box_print_print_goroot_A_members; jrt.RegisterGoType(A_arbace_box_print_print_goroot_A_class, reflect.TypeFor[A_arbace_box_print_print_goroot_A]()) }

func A_arbace_box_print_print_program_A_invoke(i int32, this any, args []any) any { switch i { case 0: return this.(*A_arbace_box_print_print_program_A).Invoke_O__O(args[0])}; return nil }

func A_arbace_box_print_print_program_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_print_program_A_New()}; return nil }

func A_arbace_box_print_print_program_A_get(i int32, o any) any { switch i { case 0: return jrt.A2g_RefP(A_arbace_box_print_print_program_A_fn_class)}; return nil }

var A_arbace_box_print_print_program_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M1 invoke (Ljava.lang.Object;)Ljava.lang.Object;\nC1 ()V\nG25 fn-class Ljava.lang.Class;", Invoke: A_arbace_box_print_print_program_A_invoke, New: A_arbace_box_print_print_program_A_new, Get: A_arbace_box_print_print_program_A_get}

var A_arbace_box_print_print_program_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$print_program", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Interfaces: []*jrt.Class{lang.Compiler_AOTF0_class}, Declaring: A_arbace_box_print_A_class, Simple: "print_program", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_print_program_A", Source: "print.ae"})

func init() { i := A_arbace_box_print_print_program_A_class.Info(); i.IsInstance = A_arbace_box_print_print_program_A_InstanceOf; i.Init = A_arbace_box_print_print_program_A_Init; i.Table = A_arbace_box_print_print_program_A_members; jrt.RegisterGoType(A_arbace_box_print_print_program_A_class, reflect.TypeFor[A_arbace_box_print_print_program_A]()) }

func A_arbace_box_print__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_print__init_A_Load__O(); case 1: return A_arbace_box_print__init_A_Unit0__O(); case 2: return A_arbace_box_print__init_A_Unit1__O(); case 3: return A_arbace_box_print__init_A_Unit2__O(); case 4: return A_arbace_box_print__init_A_Unit3__O(); case 5: return A_arbace_box_print__init_A_Unit4__O(); case 6: return A_arbace_box_print__init_A_Unit5__O(); case 7: return A_arbace_box_print__init_A_Unit6__O(); case 8: return A_arbace_box_print__init_A_Unit7__O()}; return nil }

func A_arbace_box_print__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print__init_A_New()}; return nil }

var A_arbace_box_print__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nM9 unit0 ()Ljava.lang.Object;\nM9 unit1 ()Ljava.lang.Object;\nM9 unit2 ()Ljava.lang.Object;\nM9 unit3 ()Ljava.lang.Object;\nM9 unit4 ()Ljava.lang.Object;\nM9 unit5 ()Ljava.lang.Object;\nM9 unit6 ()Ljava.lang.Object;\nM9 unit7 ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_print__init_A_invoke, New: A_arbace_box_print__init_A_new}

var A_arbace_box_print__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_print.A_arbace_box_print__init_A", Source: "print.ae"})

func init() { i := A_arbace_box_print__init_A_class.Info(); i.IsInstance = A_arbace_box_print__init_A_InstanceOf; i.Init = A_arbace_box_print__init_A_Init; i.Table = A_arbace_box_print__init_A_members; jrt.RegisterGoType(A_arbace_box_print__init_A_class, reflect.TypeFor[A_arbace_box_print__init_A]()) }
