//line a2g_classes.ae:1
package aot_arbace_box_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :6:1
var a2gCode []jrt.CodeDecl = []jrt.CodeDecl{jrt.CodeDecl{Out: &A_arbace_box_print__main_A_class, Name: "arbace.box.print$_main", Modifiers: 25, Simple: "_main", Go: "arbace/aot_arbace_box_print.A_arbace_box_print__main_A", Source: "print.ae", Declaring: &A_arbace_box_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTR0_class}}, jrt.CodeDecl{Out: &A_arbace_box_print__main_fn__1463000020_A_class, Name: "arbace.box.print$_main$fn__1463000020", Modifiers: 25, Simple: "fn__1463000020", Go: "arbace/aot_arbace_box_print.A_arbace_box_print__main_fn__1463000020_A", Source: "print.ae", Declaring: &A_arbace_box_print__main_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class, Name: "arbace.box.print$eval1463000004$loading__1927001464__auto____1463000005", Modifiers: 25, Simple: "loading__1927001464__auto____1463000005", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A", Source: "print.ae", Declaring: &A_arbace_box_print_eval1463000004_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_print_eval1463000008_fn__1463000009_A_class, Name: "arbace.box.print$eval1463000008$fn__1463000009", Modifiers: 25, Simple: "fn__1463000009", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000008_fn__1463000009_A", Source: "print.ae", Declaring: &A_arbace_box_print_eval1463000008_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_print_g2a_A_class, Name: "arbace.box.print$g2a", Modifiers: 25, Simple: "g2a", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_g2a_A", Source: "print.ae", Declaring: &A_arbace_box_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF1_class}}, jrt.CodeDecl{Out: &A_arbace_box_print_print_goroot_A_class, Name: "arbace.box.print$print_goroot", Modifiers: 25, Simple: "print_goroot", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_print_goroot_A", Source: "print.ae", Declaring: &A_arbace_box_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}, jrt.CodeDecl{Out: &A_arbace_box_print_print_program_A_class, Name: "arbace.box.print$print_program", Modifiers: 25, Simple: "print_program", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_print_program_A", Source: "print.ae", Declaring: &A_arbace_box_print_A_class, Interfaces: []**jrt.Class{&lang.Compiler_AOTF0_class}}}

var a2gCodeDefined bool = jrt.DefineCode(a2gCode)

func init() { jrt.LinkCode(a2gCode) }

func A_arbace_box_print_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_A_New()}; return nil }

var A_arbace_box_print_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_print_A_new}

var A_arbace_box_print_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_print.A_arbace_box_print_A"})

func init() { i := A_arbace_box_print_A_class.Info(); i.IsInstance = A_arbace_box_print_A_InstanceOf; i.Init = A_arbace_box_print_A_Init; i.Table = A_arbace_box_print_A_members }

var A_arbace_box_print__main_A_class *jrt.Class

var A_arbace_box_print__main_fn__1463000020_A_class *jrt.Class

func A_arbace_box_print_eval1463000004_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_eval1463000004_A_New()}; return nil }

var A_arbace_box_print_eval1463000004_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_print_eval1463000004_A_new}

var A_arbace_box_print_eval1463000004_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$eval1463000004", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_print_A_class, Simple: "eval1463000004", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000004_A"})

func init() { i := A_arbace_box_print_eval1463000004_A_class.Info(); i.IsInstance = A_arbace_box_print_eval1463000004_A_InstanceOf; i.Table = A_arbace_box_print_eval1463000004_A_members }

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class *jrt.Class

func A_arbace_box_print_eval1463000008_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print_eval1463000008_A_New()}; return nil }

var A_arbace_box_print_eval1463000008_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "C1 ()V", New: A_arbace_box_print_eval1463000008_A_new}

var A_arbace_box_print_eval1463000008_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print$eval1463000008", Modifiers: 25, Kind: jrt.KindClass, Super: jrt.Object_class, Declaring: A_arbace_box_print_A_class, Simple: "eval1463000008", Go: "arbace/aot_arbace_box_print.A_arbace_box_print_eval1463000008_A"})

func init() { i := A_arbace_box_print_eval1463000008_A_class.Info(); i.IsInstance = A_arbace_box_print_eval1463000008_A_InstanceOf; i.Table = A_arbace_box_print_eval1463000008_A_members }

var A_arbace_box_print_eval1463000008_fn__1463000009_A_class *jrt.Class

var A_arbace_box_print_g2a_A_class *jrt.Class

var A_arbace_box_print_print_goroot_A_class *jrt.Class

var A_arbace_box_print_print_program_A_class *jrt.Class

func A_arbace_box_print__init_A_invoke(i int32, this any, args []any) any { switch i { case 0: return A_arbace_box_print__init_A_Load__O()}; return nil }

func A_arbace_box_print__init_A_new(i int32, args []any) any { switch i { case 0: return A_arbace_box_print__init_A_New()}; return nil }

var A_arbace_box_print__init_A_members *jrt.MemberTable = &jrt.MemberTable{Data: "M9 load ()Ljava.lang.Object;\nC1 ()V", Invoke: A_arbace_box_print__init_A_invoke, New: A_arbace_box_print__init_A_new}

var A_arbace_box_print__init_A_class = jrt.Define(&jrt.ClassInfo{Name: "arbace.box.print__init", Modifiers: 17, Kind: jrt.KindClass, Super: jrt.Object_class, Go: "arbace/aot_arbace_box_print.A_arbace_box_print__init_A", Source: "print.ae"})

func init() { i := A_arbace_box_print__init_A_class.Info(); i.IsInstance = A_arbace_box_print__init_A_InstanceOf; i.Init = A_arbace_box_print__init_A_Init; i.Table = A_arbace_box_print__init_A_members }
