//line j2g_strings.ae:1
package aot_arbace_box_print

import "arbace/jrt"


var Lit_0 *jrt.String = jrt.Intern("yn11,arbace.corekn3,docys15,arbace.build.go7,programys15,arbace.build.go12,print-moduleys20,arbace.repr.go.print13,print-packagekn8,library?kn6,modulekn6,layoutkn5,lineskn2,gokn5,gofmtkn4,gooskn9,line-filekn8,goos-dirkn5,rootskn6,configkn7,packagekn4,mainv11,arbace.core5,referR0,v11,arbace.core7,commutev11,arbace.core5,derefv11,arbace.core4,conjMyn16,arbace.box.printm2,R1,s212,The printing steps of arbace.box.rebuild, each in its own guest:\n\n    arbace -m arbace.box.print print-goroot    tamago/ and overlay/go printed\n    arbace -m arbace.box.print print-program   j2g's program printedv11,arbace.core13,*loaded-libs*v11,arbace.core17,requiring-resolvev11,arbace.core7,ex-infov16,arbace.box.print4,toolR2,R3,R4,m4,R5,TR6,s3,stdm2,R7,R8,m6,R5,TR6,s27,github.com/usbarmory/tamagoR9,s4,1.27m2,R7,R8,m2,R7,R10,m2,R7,R10,m8,R11,s6,tamagoR12,TR13,s5,/goosR14,V2,s6,/s/boxs12,/s/x509rootsv11,arbace.core4,spitR2,R3,v11,arbace.core6,pr-strR15,R16,R17,v16,arbace.box.print13,print-programv16,arbace.box.print12,print-gorootv11,arbace.core15,shutdown-agentsv11,arbace.core7,printlnv11,arbace.core19,pop-thread-bindingsv11,arbace.core20,push-thread-bindingsv11,arbace.core8,hash-mapv11,arbace.core5,*out*v11,arbace.core5,*err*")

var Lit_1 *jrt.String = jrt.Intern("print-program")

var Lit_2 *jrt.String = jrt.Intern("print-goroot")

var Lit_3 *jrt.String = jrt.Intern("arbace.box.print$_main$fn__1463000020")

var Lit_4 *jrt.String = jrt.Intern("usage: arbace -m arbace.box.print print-goroot|print-program")

var Lit_5 *jrt.String = jrt.Intern("java.io.File")

var Lit_6 *jrt.String = jrt.Intern("/nonexistent")

var Lit_7 *jrt.String = jrt.Intern("/f")

var Lit_8 *jrt.String = jrt.Intern("/o/std")

var Lit_9 *jrt.String = jrt.Intern("/g")

var Lit_10 *jrt.String = jrt.Intern("/o/goos")

var Lit_11 *jrt.String = jrt.Intern("overlay/go/runtime.ae")

var Lit_12 *jrt.String = jrt.Intern("/o/runtime")

var Lit_13 *jrt.String = jrt.Intern("overlay/go/syscall.ae")

var Lit_14 *jrt.String = jrt.Intern("/o/syscall")

var Lit_15 *jrt.String = jrt.Intern("/p")

var Lit_16 *jrt.String = jrt.Intern("/o/mod")

var Lit_17 *jrt.String = jrt.Intern("/o/config.edn")

var Lit_18 *jrt.String = jrt.Intern("arbace.box.print: no ")

var Lit_19 *jrt.String = jrt.Intern("kn3,docyn11,arbace.corekn7,privatekn8,arglistsyn3,symkn4,linekn6,columnkn4,fileyn1,&yn3,cmdv11,arbace.core5,in-nsMyn16,arbace.box.printm2,R0,s212,The printing steps of arbace.box.rebuild, each in its own guest:\n\n    arbace -m arbace.box.print print-goroot    tamago/ and overlay/go printed\n    arbace -m arbace.box.print print-program   j2g's program printedm2,R0,s212,The printing steps of arbace.box.rebuild, each in its own guest:\n\n    arbace -m arbace.box.print print-goroot    tamago/ and overlay/go printed\n    arbace -m arbace.box.print print-program   j2g's program printedR1,v16,arbace.box.print4,toolm10,R2,TR3,L1,V1,R4,R5,i13,R6,i1,R7,s19,arbace/box/print.aev16,arbace.box.print12,print-gorootm10,R3,L1,V0,R0,s379,In a guest (cwd /s, the sources): tamago/'s forms (/f the standard library's, /g the goos\n  module's: each its go/ with arch/amd64/go laid over it) printed as bin/tamago-vendor print\n  prints them into /o/std (GOROOT/src's layout) and /o/goos; overlay/go's runtime and syscall\n  printed as bin/jrt overlay and bin/lib/box-overlay.bash print them into /o/runtime and\n  /o/syscall.R5,i16,R6,i1,R7,s19,arbace/box/print.aev16,arbace.box.print13,print-programm10,R3,L1,V0,R0,s310,In a guest (cwd /s, the sources): j2g's program (/p) printed as bin/arbace-go --build --box\n  prints it (bin/build-go --goos tamago --line-file, the roots box/ and x509roots/), into\n  /o/mod, the goos module's directory named /goos; the main package's configuration\n  (:tags, :goexperiment) into /o/config.edn.R5,i34,R6,i1,R7,s19,arbace/box/print.aev16,arbace.box.print5,-mainm8,R3,L1,V2,R8,V1,R9,R5,i47,R6,i1,R7,s19,arbace/box/print.ae")

var Lit_20 *jrt.String = jrt.Intern("arbace.box.print$eval1463000004$loading__1927001464__auto____1463000005")

var Lit_21 *jrt.String = jrt.Intern("arbace.box.print$eval1463000008$fn__1463000009")

var Lit_22 *jrt.String = jrt.Intern("arbace.box.print$tool")

var Lit_23 *jrt.String = jrt.Intern("arbace.box.print$print_goroot")

var Lit_24 *jrt.String = jrt.Intern("arbace.box.print$print_program")

var Lit_25 *jrt.String = jrt.Intern("arbace.box.print$_main")
