//line aot_arbace_box_print.ae:1
package aot_arbace_box_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :4:1
func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New() *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A { A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_Init(); t := &A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; lang.Compiler_Init(); tmp1 = lang.Compiler_LOADER; var tmp2 any = tmp1.Ref(); lang.Var_PushThreadBindings_Associative__V(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp2, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp3 any; tmp8 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp4 *lang.Var; A_arbace_box_print_A_Init(); tmp4 = A_arbace_box_print_A_const_0; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_print_A_Init(); tmp6 = A_arbace_box_print_A_const_1; tmp5.Invoke_O__O(tmp6); var tmp7 *lang.Var; lang.RT_Init(); tmp7 = lang.RT_CURRENT_NS; jrt.NN(lang.Namespace_Cast(jrt.NN(tmp7).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class(Lit_52)); tmp3 = nil }; return nil }(); lang.Var_PopThreadBindings__V(); if tmp8 != nil { panic(tmp8) }; return tmp3 }
//line :4:1
func A_arbace_box_print_eval1463000008_fn__1463000009_A_New() *A_arbace_box_print_eval1463000008_fn__1463000009_A { A_arbace_box_print_eval1463000008_fn__1463000009_A_Init(); t := &A_arbace_box_print_eval1463000008_fn__1463000009_A{}; t.Ctor(); return t }
//line :4:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Ctor() {}
//line :4:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Invoke_O__O(self any) any { var tmp1 *lang.Var; A_arbace_box_print_A_Init(); tmp1 = A_arbace_box_print_A_const_2; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 *lang.Var; A_arbace_box_print_A_Init(); tmp3 = A_arbace_box_print_A_const_3; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_print_A_Init(); tmp5 = A_arbace_box_print_A_const_6; var tmp6 any = tmp4.Invoke_O__O(tmp5.Ref()); var tmp7 *lang.Var; A_arbace_box_print_A_Init(); tmp7 = A_arbace_box_print_A_const_4; var tmp8 any = jrt.NN(tmp7).GetRawRoot__O(); var tmp9 any; A_arbace_box_print_A_Init(); tmp9 = A_arbace_box_print_A_const_5; return tmp2.Invoke_O_O_O__O(tmp6, tmp8, tmp9) }







func A_arbace_box_print_g2a_A_New() *A_arbace_box_print_g2a_A { A_arbace_box_print_g2a_A_Init(); t := &A_arbace_box_print_g2a_A{}; t.Ctor(); return t }
//line :12:1
func (t *A_arbace_box_print_g2a_A) Ctor() {}
//line :12:1
func (t *A_arbace_box_print_g2a_A) Invoke_O_O__O(self, sym__0 any) any { var or__1927000174__auto____2 any; var tmp1 *lang.Var;
									A_arbace_box_print_A_Init(); tmp1 = A_arbace_box_print_A_const_7; or__1927000174__auto____2 = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke_O__O(sym__0); if jrt.A2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { var tmp2 *lang.Var; A_arbace_box_print_A_Init(); tmp2 = A_arbace_box_print_A_const_8; var tmp3 lang.IFn = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()); var tmp4 any = lang.Compiler_AOT_StrConcat_String1_O1__String(jrt.RefArrayOf(jrt.String_class, Lit_55, nil), jrt.RefArrayOf(jrt.Object_class, nil, sym__0)).Ref(); var tmp5 *lang.PersistentArrayMap; lang.PersistentArrayMap_Init(); tmp5 = lang.PersistentArrayMap_EMPTY; panic(jrt.Thrown(jrt.Throwable_Cast(tmp3.Invoke_O_O__O(tmp4, tmp5.Ref())))) } }

func A_arbace_box_print_print_goroot_A_New() *A_arbace_box_print_print_goroot_A { A_arbace_box_print_print_goroot_A_Init(); t := &A_arbace_box_print_print_goroot_A{}; t.Ctor(); return t }
//line :15:1
func (t *A_arbace_box_print_print_goroot_A) Ctor() {}
//line :15:1
func (t *A_arbace_box_print_print_goroot_A) Invoke_O__O(self any) any { var program__1 any; var tmp1 *lang.Var;






	A_arbace_box_print_A_Init(); tmp1 = A_arbace_box_print_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_box_print_A_Init(); tmp3 = A_arbace_box_print_A_const_10; program__1 = tmp2.Invoke_O__O(tmp3); var print_module__2 any; var tmp4 /*line :15:1*/*lang.Var;







	A_arbace_box_print_A_Init(); tmp4 = A_arbace_box_print_A_const_9; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_print_A_Init(); tmp6 = A_arbace_box_print_A_const_11; print_module__2 = tmp5.Invoke_O__O(tmp6); var print_package__3 any; var tmp7 /*line :15:1*/*lang.Var;








	A_arbace_box_print_A_Init(); tmp7 = A_arbace_box_print_A_const_9; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 any; A_arbace_box_print_A_Init(); tmp9 = A_arbace_box_print_A_const_12; print_package__3 = tmp8.Invoke_O__O(tmp9); var goroot__4 any = Lit_57; var p__5 any; var tmp10 lang.IFn = /*line :15:1*/lang.IFn_Cast(program__1); var tmp11 any = jrt.File_New_String(Lit_58); var tmp12 any;










	A_arbace_box_print_A_Init(); tmp12 = A_arbace_box_print_A_const_13; p__5 = tmp10.Invoke_O_O_O__O(tmp11, goroot__4, tmp12); var tmp13 lang.IFn =
	lang.IFn_Cast(print_module__2); var tmp14 any = jrt.File_New_String(Lit_58); var tmp15 any = jrt.File_New_String(Lit_59); var tmp16 any; A_arbace_box_print_A_Init(); tmp16 = A_arbace_box_print_A_const_14; tmp13.Invoke_O_O_O_O__O(p__5, tmp14, tmp15, tmp16); var p__5_2 any; var tmp17 lang.IFn = /*line :15:1*/lang.IFn_Cast(program__1); var tmp18 any = jrt.File_New_String(Lit_60); var tmp19 any;












	A_arbace_box_print_A_Init(); tmp19 = A_arbace_box_print_A_const_15; p__5_2 = tmp17.Invoke_O_O_O__O(tmp18, goroot__4, tmp19); var tmp20 lang.IFn =
	lang.IFn_Cast(print_module__2); var tmp21 any = jrt.File_New_String(Lit_60); var tmp22 any = jrt.File_New_String(Lit_61); var tmp23 any; A_arbace_box_print_A_Init(); tmp23 = A_arbace_box_print_A_const_16; tmp20.Invoke_O_O_O_O__O(p__5_2, tmp21, tmp22, tmp23); var tmp24 lang.IFn =
	lang.IFn_Cast(print_package__3); var tmp25 any; A_arbace_box_print_A_Init(); tmp25 = A_arbace_box_print_A_const_17; tmp24.Invoke_O_O_O__O(Lit_62, Lit_63, tmp25); var tmp26 lang.IFn =
	lang.IFn_Cast(print_package__3); var tmp27 any; A_arbace_box_print_A_Init(); tmp27 = A_arbace_box_print_A_const_18; return tmp26.Invoke_O_O_O__O(Lit_64, Lit_65, tmp27) }

func A_arbace_box_print_print_program_A_New() *A_arbace_box_print_print_program_A { A_arbace_box_print_print_program_A_Init(); t := &A_arbace_box_print_print_program_A{}; t.Ctor(); return t }
//line :33:1
func (t *A_arbace_box_print_print_program_A) Ctor() {}
//line :33:1
func (t *A_arbace_box_print_print_program_A) Invoke_O__O(self any) any { var program__1 any; var tmp1 *lang.Var;





	A_arbace_box_print_A_Init(); tmp1 = A_arbace_box_print_A_const_9; var tmp2 lang.IFn = lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()); var tmp3 any; A_arbace_box_print_A_Init(); tmp3 = A_arbace_box_print_A_const_21; program__1 = tmp2.Invoke_O__O(tmp3); var print_module__2 any; var tmp4 /*line :33:1*/*lang.Var;






	A_arbace_box_print_A_Init(); tmp4 = A_arbace_box_print_A_const_9; var tmp5 lang.IFn = lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()); var tmp6 any; A_arbace_box_print_A_Init(); tmp6 = A_arbace_box_print_A_const_22; print_module__2 = tmp5.Invoke_O__O(tmp6); var opts__3 any; /*line :33:1*/A_arbace_box_print_A_Init(); opts__3 = A_arbace_box_print_A_const_19; var p__4 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_67), Lit_57, opts__3);









	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__4, jrt.File_New_String(Lit_67), jrt.File_New_String(Lit_68), opts__3); var tmp7 /*line :44:1*/*lang.Var; A_arbace_box_print_A_Init(); tmp7 = A_arbace_box_print_A_const_20; var tmp8 lang.IFn = lang.IFn_Cast(jrt.NN(tmp7).GetRawRoot__O()); var tmp9 *lang.Var; A_arbace_box_print_A_Init(); tmp9 = A_arbace_box_print_A_const_23; var tmp10 lang.IFn = lang.IFn_Cast(jrt.NN(tmp9).GetRawRoot__O()); var tmp11 any; var or__1927000174__auto____5 any; var tmp12 *lang.Keyword; A_arbace_box_print_A_Init(); tmp12 = A_arbace_box_print_A_const_24; var tmp13 *lang.Keyword = tmp12; var tmp14 *lang.Keyword; A_arbace_box_print_A_Init(); tmp14 = A_arbace_box_print_A_const_25; var tmp15 *lang.Keyword = tmp14; var tmp16 *lang.Keyword; A_arbace_box_print_A_Init(); tmp16 = A_arbace_box_print_A_const_26; or__1927000174__auto____5 = jrt.NN(tmp13).Invoke_O__O(jrt.NN(tmp15).Invoke_O__O(jrt.NN(tmp16).Invoke_O__O(p__4))); if jrt.A2g_Truth(or__1927000174__auto____5) { tmp11 = or__1927000174__auto____5 } else { lang.PersistentArrayMap_Init(); tmp11 = lang.PersistentArrayMap_EMPTY.Ref() }; return tmp8.Invoke_O_O__O(Lit_69, tmp10.Invoke_O__O(tmp11)) }

func A_arbace_box_print__main_A_New() *A_arbace_box_print__main_A { A_arbace_box_print__main_A_Init(); t := &A_arbace_box_print__main_A{}; t.Ctor(); return t }
//line :46:1
func (t *A_arbace_box_print__main_A) Ctor() {}
//line :46:1
func (t *A_arbace_box_print__main_A) DoInvoke_O_O__O(self, p__1463000015__0 any) any { var vec__1463000016__2 any = p__1463000015__0; var cmd__3 any = lang.RT_Nth_O_I_O__O(vec__1463000016__2, lang.RT_IntCast_J__I(0), nil); var G__1463000019__4_ any = cmd__3; L1:
switch { default: switch lang.Util_Hash_O__I(G__1463000019__4_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z(G__1463000019__4_, Lit_39) {

	var tmp1 *lang.Var; A_arbace_box_print_A_Init(); tmp1 = A_arbace_box_print_A_const_27; lang.IFn_Cast(jrt.NN(tmp1).GetRawRoot__O()).Invoke__O()
//line :47:1
	break L1 }; case 1: if lang.Util_Equiv_O_O__Z(G__1463000019__4_, Lit_40) {
		var tmp2 *lang.Var; A_arbace_box_print_A_Init(); tmp2 = A_arbace_box_print_A_const_28; lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke__O()
//line :47:1
		break L1 }; default:
}

	var tmp3 *lang.Var; A_arbace_box_print_A_Init(); tmp3 = A_arbace_box_print_A_const_32; var tmp4 lang.IFn = lang.IFn_Cast(jrt.NN(tmp3).GetRawRoot__O()); var tmp5 *lang.Var; A_arbace_box_print_A_Init(); tmp5 = A_arbace_box_print_A_const_33; var tmp6 lang.IFn = lang.IFn_Cast(jrt.NN(tmp5).GetRawRoot__O()); var tmp7 *lang.Var; A_arbace_box_print_A_Init(); tmp7 = A_arbace_box_print_A_const_34; var tmp8 any = tmp7.Ref(); var tmp9 *lang.Var; A_arbace_box_print_A_Init(); tmp9 = A_arbace_box_print_A_const_35; tmp4.Invoke_O__O(tmp6.Invoke_O_O__O(tmp8, jrt.NN(tmp9).Get__O())); var tmp10 any = A_arbace_box_print__main_fn__1463000020_A_New(); var tmp11 *jrt.Class; A_arbace_box_print__main_fn__1463000020_A_Init(); tmp11 = A_arbace_box_print__main_fn__1463000020_A_fn_class; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp10, tmp11, nil).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I(2))}; var tmp12 /*line :52:1*/*lang.Var; A_arbace_box_print_A_Init(); tmp12 = A_arbace_box_print_A_const_29; lang.IFn_Cast(jrt.NN(tmp12).GetRawRoot__O()).Invoke__O();
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I(0)); return nil }
//line :50:1
func A_arbace_box_print__main_fn__1463000020_A_New() *A_arbace_box_print__main_fn__1463000020_A { A_arbace_box_print__main_fn__1463000020_A_Init(); t := &A_arbace_box_print__main_fn__1463000020_A{}; t.Ctor(); return t }
//line :50:1
func (t *A_arbace_box_print__main_fn__1463000020_A) Ctor() {}
//line :50:1
func (t *A_arbace_box_print__main_fn__1463000020_A) Invoke_O__O(self any) any { var tmp1 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); { var tmp2 *lang.Var; A_arbace_box_print_A_Init(); tmp2 = A_arbace_box_print_A_const_30; tmp1 = lang.IFn_Cast(jrt.NN(tmp2).GetRawRoot__O()).Invoke_O__O(Lit_50) }; return nil }(); var tmp4 *lang.Var; A_arbace_box_print_A_Init(); tmp4 = A_arbace_box_print_A_const_31; lang.IFn_Cast(jrt.NN(tmp4).GetRawRoot__O()).Invoke__O(); if tmp3 != nil { panic(tmp3) }; return tmp1 }









type A_arbace_box_print_A struct{ jrt.Object }

var A_arbace_box_print_A_const_0 *lang.Var

var A_arbace_box_print_A_const_1 any

var A_arbace_box_print_A_const_2 *lang.Var

var A_arbace_box_print_A_const_3 *lang.Var

var A_arbace_box_print_A_const_4 *lang.Var

var A_arbace_box_print_A_const_5 any

var A_arbace_box_print_A_const_6 *lang.Var

var A_arbace_box_print_A_const_7 *lang.Var

var A_arbace_box_print_A_const_8 *lang.Var

var A_arbace_box_print_A_const_9 *lang.Var

var A_arbace_box_print_A_const_10 any

var A_arbace_box_print_A_const_11 any

var A_arbace_box_print_A_const_12 any

var A_arbace_box_print_A_const_13 any

var A_arbace_box_print_A_const_14 any

var A_arbace_box_print_A_const_15 any

var A_arbace_box_print_A_const_16 any

var A_arbace_box_print_A_const_17 any

var A_arbace_box_print_A_const_18 any

var A_arbace_box_print_A_const_19 any

var A_arbace_box_print_A_const_20 *lang.Var

var A_arbace_box_print_A_const_21 any

var A_arbace_box_print_A_const_22 any

var A_arbace_box_print_A_const_23 *lang.Var

var A_arbace_box_print_A_const_24 *lang.Keyword

var A_arbace_box_print_A_const_25 *lang.Keyword

var A_arbace_box_print_A_const_26 *lang.Keyword

var A_arbace_box_print_A_const_27 *lang.Var

var A_arbace_box_print_A_const_28 *lang.Var

var A_arbace_box_print_A_const_29 *lang.Var

var A_arbace_box_print_A_const_30 *lang.Var

var A_arbace_box_print_A_const_31 *lang.Var

var A_arbace_box_print_A_const_32 *lang.Var

var A_arbace_box_print_A_const_33 *lang.Var

var A_arbace_box_print_A_const_34 *lang.Var

var A_arbace_box_print_A_const_35 *lang.Var

var A_arbace_box_print_A_init jrt.ClassInit

func A_arbace_box_print_A_Init() { if !A_arbace_box_print_A_init.Done() { A_arbace_box_print_A_init.Run(A_arbace_box_print_A_clinit) } }

func A_arbace_box_print_A_clinit() { A_arbace_box_print_A_const_0 = lang.RT_Var_String_String__Var(Lit_0, Lit_1); A_arbace_box_print_A_const_1 = lang.Symbol_Intern_String_String__Symbol(nil, Lit_0).Ref(); A_arbace_box_print_A_const_2 = lang.RT_Var_String_String__Var(Lit_0, Lit_2); A_arbace_box_print_A_const_3 = lang.RT_Var_String_String__Var(Lit_0, Lit_3); A_arbace_box_print_A_const_4 = lang.RT_Var_String_String__Var(Lit_0, Lit_4); A_arbace_box_print_A_const_5 = Up_Symbol_IObj(lang.Symbol_Intern_String_String__Symbol(nil, Lit_5)).WithMeta_IPersistentMap__IObj(lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_6).Ref(), Lit_7))); A_arbace_box_print_A_const_6 = lang.RT_Var_String_String__Var(Lit_0, Lit_8); A_arbace_box_print_A_const_7 = lang.RT_Var_String_String__Var(Lit_0, Lit_9); A_arbace_box_print_A_const_8 = lang.RT_Var_String_String__Var(Lit_0, Lit_10); A_arbace_box_print_A_const_9 = lang.RT_Var_String_String__Var(Lit_5, Lit_11); A_arbace_box_print_A_const_10 = lang.Symbol_Intern_String_String__Symbol(Lit_12, Lit_13).Ref(); A_arbace_box_print_A_const_11 = lang.Symbol_Intern_String_String__Symbol(Lit_12, Lit_14).Ref(); A_arbace_box_print_A_const_12 = lang.Symbol_Intern_String_String__Symbol(Lit_15, Lit_16).Ref(); var tmp1 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(); var tmp2 *jrt.Boolean; jrt.Boolean_Init(); tmp2 = jrt.Boolean_TRUE; var tmp3 any = tmp2.Ref(); A_arbace_box_print_A_const_13 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp1, tmp3, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_19)); A_arbace_box_print_A_const_14 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref())); var tmp4 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_17).Ref(); var tmp5 *jrt.Boolean; jrt.Boolean_Init(); tmp5 = jrt.Boolean_TRUE; var tmp6 any = tmp5.Ref(); A_arbace_box_print_A_const_15 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp4, tmp6, lang.RT_Keyword_String_String__Keyword(nil, Lit_18).Ref(), Lit_22, lang.RT_Keyword_String_String__Keyword(nil, Lit_23).Ref(), Lit_24)); A_arbace_box_print_A_const_16 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_21).Ref())); A_arbace_box_print_A_const_17 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_25).Ref())); A_arbace_box_print_A_const_18 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, lang.RT_Keyword_String_String__Keyword(nil, Lit_20).Ref(), lang.RT_Keyword_String_String__Keyword(nil, Lit_25).Ref())); var tmp7 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_26).Ref(); var tmp8 any = lang.RT_Keyword_String_String__Keyword(nil, Lit_28).Ref(); var tmp9 *jrt.Boolean; jrt.Boolean_Init(); tmp9 = jrt.Boolean_TRUE; var tmp10 any = tmp9.Ref(); A_arbace_box_print_A_const_19 = lang.RT_Map_O1__IPersistentMap(jrt.RefArrayOf(jrt.Object_class, tmp7, Lit_27, tmp8, tmp10, lang.RT_Keyword_String_String__Keyword(nil, Lit_29).Ref(), Lit_30, lang.RT_Keyword_String_String__Keyword(nil, Lit_31).Ref(), lang.Tuple_Create_O_O__IPersistentVector(Lit_32, Lit_33))); A_arbace_box_print_A_const_20 = lang.RT_Var_String_String__Var(Lit_0, Lit_34); A_arbace_box_print_A_const_21 = lang.Symbol_Intern_String_String__Symbol(Lit_12, Lit_13).Ref(); A_arbace_box_print_A_const_22 = lang.Symbol_Intern_String_String__Symbol(Lit_12, Lit_14).Ref(); A_arbace_box_print_A_const_23 = lang.RT_Var_String_String__Var(Lit_0, Lit_35); A_arbace_box_print_A_const_24 = lang.RT_Keyword_String_String__Keyword(nil, Lit_36); A_arbace_box_print_A_const_25 = lang.RT_Keyword_String_String__Keyword(nil, Lit_37); A_arbace_box_print_A_const_26 = lang.RT_Keyword_String_String__Keyword(nil, Lit_38); A_arbace_box_print_A_const_27 = lang.RT_Var_String_String__Var(Lit_5, Lit_39); A_arbace_box_print_A_const_28 = lang.RT_Var_String_String__Var(Lit_5, Lit_40); A_arbace_box_print_A_const_29 = lang.RT_Var_String_String__Var(Lit_0, Lit_41); A_arbace_box_print_A_const_30 = lang.RT_Var_String_String__Var(Lit_0, Lit_42); A_arbace_box_print_A_const_31 = lang.RT_Var_String_String__Var(Lit_0, Lit_43); A_arbace_box_print_A_const_32 = lang.RT_Var_String_String__Var(Lit_0, Lit_44); A_arbace_box_print_A_const_33 = lang.RT_Var_String_String__Var(Lit_0, Lit_45); A_arbace_box_print_A_const_34 = lang.RT_Var_String_String__Var(Lit_0, Lit_46); A_arbace_box_print_A_const_35 = lang.RT_Var_String_String__Var(Lit_0, Lit_47) }

func A_arbace_box_print_A_New() *A_arbace_box_print_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_A) Ctor() {}

func (t *A_arbace_box_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_A_class }

func (t *A_arbace_box_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_A); return ok }

func A_arbace_box_print_A_Cast(x any) *A_arbace_box_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_A_class)) }; return v }



type A_arbace_box_print__main_A struct{ jrt.Object }

func (t *A_arbace_box_print__main_A) Is_Compiler_AOTR0() {}

var A_arbace_box_print__main_A_fn_class *jrt.Class

var A_arbace_box_print__main_A_init jrt.ClassInit

func A_arbace_box_print__main_A_Init() { if !A_arbace_box_print__main_A_init.Done() { A_arbace_box_print__main_A_init.Run(A_arbace_box_print__main_A_clinit) } }

func A_arbace_box_print__main_A_clinit() { A_arbace_box_print__main_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_48, lang.Compiler_AOTRestFn_class) }

func (t *A_arbace_box_print__main_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print__main_A) GetClass__Class() *jrt.Class { return A_arbace_box_print__main_A_class }

func (t *A_arbace_box_print__main_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print__main_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print__main_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print__main_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print__main_A); return ok }

func A_arbace_box_print__main_A_Cast(x any) *A_arbace_box_print__main_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print__main_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print__main_A_class)) }; return v }



type A_arbace_box_print__main_fn__1463000020_A struct{ jrt.Object }

func (t *A_arbace_box_print__main_fn__1463000020_A) Is_Compiler_AOTF0() {}

var A_arbace_box_print__main_fn__1463000020_A_fn_class *jrt.Class

var A_arbace_box_print__main_fn__1463000020_A_init jrt.ClassInit

func A_arbace_box_print__main_fn__1463000020_A_Init() { if !A_arbace_box_print__main_fn__1463000020_A_init.Done() { A_arbace_box_print__main_fn__1463000020_A_init.Run(A_arbace_box_print__main_fn__1463000020_A_clinit) } }

func A_arbace_box_print__main_fn__1463000020_A_clinit() { A_arbace_box_print__main_fn__1463000020_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_49, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_print__main_fn__1463000020_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print__main_fn__1463000020_A) GetClass__Class() *jrt.Class { return A_arbace_box_print__main_fn__1463000020_A_class }

func (t *A_arbace_box_print__main_fn__1463000020_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print__main_fn__1463000020_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print__main_fn__1463000020_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print__main_fn__1463000020_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print__main_fn__1463000020_A); return ok }

func A_arbace_box_print__main_fn__1463000020_A_Cast(x any) *A_arbace_box_print__main_fn__1463000020_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print__main_fn__1463000020_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print__main_fn__1463000020_A_class)) }; return v }



type A_arbace_box_print_eval1463000004_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000004_A_New() *A_arbace_box_print_eval1463000004_A { t := &A_arbace_box_print_eval1463000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000004_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000004_A_class }

func (t *A_arbace_box_print_eval1463000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000004_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000004_A); return ok }

func A_arbace_box_print_eval1463000004_A_Cast(x any) *A_arbace_box_print_eval1463000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000004_A_class)) }; return v }



type A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A struct{ jrt.Object }

func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Is_Compiler_AOTF0() {}

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class *jrt.Class

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_init jrt.ClassInit

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_Init() { if !A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_init.Done() { A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_init.Run(A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_clinit) } }

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_clinit() { A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_51, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class }

func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A); return ok }

func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_Cast(x any) *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_class)) }; return v }



type A_arbace_box_print_eval1463000008_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000008_A_New() *A_arbace_box_print_eval1463000008_A { t := &A_arbace_box_print_eval1463000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000008_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000008_A_class }

func (t *A_arbace_box_print_eval1463000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000008_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000008_A); return ok }

func A_arbace_box_print_eval1463000008_A_Cast(x any) *A_arbace_box_print_eval1463000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000008_A_class)) }; return v }



type A_arbace_box_print_eval1463000008_fn__1463000009_A struct{ jrt.Object }

func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Is_Compiler_AOTF0() {}

var A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class *jrt.Class

var A_arbace_box_print_eval1463000008_fn__1463000009_A_init jrt.ClassInit

func A_arbace_box_print_eval1463000008_fn__1463000009_A_Init() { if !A_arbace_box_print_eval1463000008_fn__1463000009_A_init.Done() { A_arbace_box_print_eval1463000008_fn__1463000009_A_init.Run(A_arbace_box_print_eval1463000008_fn__1463000009_A_clinit) } }

func A_arbace_box_print_eval1463000008_fn__1463000009_A_clinit() { A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_53, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000008_fn__1463000009_A_class }

func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000008_fn__1463000009_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000008_fn__1463000009_A); return ok }

func A_arbace_box_print_eval1463000008_fn__1463000009_A_Cast(x any) *A_arbace_box_print_eval1463000008_fn__1463000009_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000008_fn__1463000009_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000008_fn__1463000009_A_class)) }; return v }



type A_arbace_box_print_g2a_A struct{ jrt.Object }

func (t *A_arbace_box_print_g2a_A) Is_Compiler_AOTF1() {}

var A_arbace_box_print_g2a_A_fn_class *jrt.Class

var A_arbace_box_print_g2a_A_init jrt.ClassInit

func A_arbace_box_print_g2a_A_Init() { if !A_arbace_box_print_g2a_A_init.Done() { A_arbace_box_print_g2a_A_init.Run(A_arbace_box_print_g2a_A_clinit) } }

func A_arbace_box_print_g2a_A_clinit() { A_arbace_box_print_g2a_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_54, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_print_g2a_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_g2a_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_g2a_A_class }

func (t *A_arbace_box_print_g2a_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_g2a_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_g2a_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_g2a_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_g2a_A); return ok }

func A_arbace_box_print_g2a_A_Cast(x any) *A_arbace_box_print_g2a_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_g2a_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_g2a_A_class)) }; return v }



type A_arbace_box_print_print_goroot_A struct{ jrt.Object }

func (t *A_arbace_box_print_print_goroot_A) Is_Compiler_AOTF0() {}

var A_arbace_box_print_print_goroot_A_fn_class *jrt.Class

var A_arbace_box_print_print_goroot_A_init jrt.ClassInit

func A_arbace_box_print_print_goroot_A_Init() { if !A_arbace_box_print_print_goroot_A_init.Done() { A_arbace_box_print_print_goroot_A_init.Run(A_arbace_box_print_print_goroot_A_clinit) } }

func A_arbace_box_print_print_goroot_A_clinit() { A_arbace_box_print_print_goroot_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_56, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_print_print_goroot_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_print_goroot_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_print_goroot_A_class }

func (t *A_arbace_box_print_print_goroot_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_print_goroot_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_print_goroot_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_print_goroot_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_print_goroot_A); return ok }

func A_arbace_box_print_print_goroot_A_Cast(x any) *A_arbace_box_print_print_goroot_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_print_goroot_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_print_goroot_A_class)) }; return v }



type A_arbace_box_print_print_program_A struct{ jrt.Object }

func (t *A_arbace_box_print_print_program_A) Is_Compiler_AOTF0() {}

var A_arbace_box_print_print_program_A_fn_class *jrt.Class

var A_arbace_box_print_print_program_A_init jrt.ClassInit

func A_arbace_box_print_print_program_A_Init() { if !A_arbace_box_print_print_program_A_init.Done() { A_arbace_box_print_print_program_A_init.Run(A_arbace_box_print_print_program_A_clinit) } }

func A_arbace_box_print_print_program_A_clinit() { A_arbace_box_print_print_program_A_fn_class = lang.Compiler_Dyn_DefineFnClass_String_Class__Class(Lit_66, lang.Compiler_AOTFn_class) }

func (t *A_arbace_box_print_print_program_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_print_program_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_print_program_A_class }

func (t *A_arbace_box_print_print_program_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_print_program_A) Clone__O() any { return jrt.A2g_ObjectClone(t) }

func (t *A_arbace_box_print_print_program_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_print_program_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_print_program_A); return ok }

func A_arbace_box_print_print_program_A_Cast(x any) *A_arbace_box_print_print_program_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_print_program_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_print_program_A_class)) }; return v }
