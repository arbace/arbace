//line aot_arbace_box_print.ae:1
package aot_arbace_box_print

import (
	"arbace/jrt"
	"arbace/lang"
)
//line :5:1
func A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_New() *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A) Invoke_O__O(self any) any { var tmp1 any = lang.Compiler_LOADER.Ref(); lang.Var_PushThreadBindings_Associative__V_NoInit(lang.RT_Map_O1__IPersistentMap_NoInit(jrt.RefArrayOf(jrt.Object_class, tmp1, jrt.NN(jrt.GetClass(self)).GetClassLoader__ClassLoader()))); var tmp2 any; tmp3 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); lang.IFn_Cast(A_arbace_box_print_A_const_0.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_1); tmp2 = jrt.NN(lang.Namespace_Cast(jrt.NN(lang.RT_CURRENT_NS).Deref__O())).ImportClass_Class__Class(lang.RT_ClassForNameNonLoading_String__Class_NoInit(Lit_5)).Ref(); return nil }(); lang.Var_PopThreadBindings__V_NoInit(); if tmp3 != nil { panic(tmp3) }; return tmp2 }
//line :5:1
func A_arbace_box_print_eval1463000008_fn__1463000009_A_New() *A_arbace_box_print_eval1463000008_fn__1463000009_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_eval1463000008_fn__1463000009_A{}; t.Ctor(); return t }
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Ctor() {}
//line :5:1
func (t *A_arbace_box_print_eval1463000008_fn__1463000009_A) Invoke_O__O(self any) any { return lang.IFn_Cast(A_arbace_box_print_A_const_2.GetRawRoot__O()).Invoke_O_O_O__O(lang.IFn_Cast(A_arbace_box_print_A_const_3.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_6), A_arbace_box_print_A_const_4.GetRawRoot__O(), A_arbace_box_print_A_const_5) }







func A_arbace_box_print_tool_A_New() *A_arbace_box_print_tool_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_tool_A{}; t.Ctor(); return t }
//line :13:1
func (t *A_arbace_box_print_tool_A) Ctor() {}
//line :13:1
func (t *A_arbace_box_print_tool_A) Invoke_O_O__O(self, sym__0 any) any { var or__1927000174__auto____2 any = lang.IFn_Cast(A_arbace_box_print_A_const_7.GetRawRoot__O()).Invoke_O__O(sym__0); if
									jrt.J2g_Truth(or__1927000174__auto____2) { return or__1927000174__auto____2 } else { panic(jrt.Thrown(jrt.Throwable_Cast(lang.IFn_Cast(A_arbace_box_print_A_const_8.GetRawRoot__O()).Invoke_O_O__O(lang.Compiler_AOT_StrConcat_String1_O1__String_NoInit(jrt.RefArrayOf(jrt.String_class, Lit_18, nil), jrt.RefArrayOf(jrt.Object_class, nil, sym__0)).Ref(), lang.PersistentArrayMap_EMPTY.Ref())))) } }

func A_arbace_box_print_print_goroot_A_New() *A_arbace_box_print_print_goroot_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_goroot_A{}; t.Ctor(); return t }
//line :16:1
func (t *A_arbace_box_print_print_goroot_A) Ctor() {}
//line :16:1
func (t *A_arbace_box_print_print_goroot_A) Invoke_O__O(self any) any { var program__1 any = lang.IFn_Cast(A_arbace_box_print_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_10); var print_module__2 any = lang.IFn_Cast(A_arbace_box_print_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_11); var print_package__3 any = lang.IFn_Cast(A_arbace_box_print_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_12); var goroot__4 any = Lit_6; var p__5 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_7), goroot__4, A_arbace_box_print_A_const_13);











	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5, jrt.File_New_String(Lit_7), jrt.File_New_String(Lit_8), A_arbace_box_print_A_const_14); var p__5_2 any = /*line :16:1*/lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_9), goroot__4, A_arbace_box_print_A_const_15);













	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__5_2, jrt.File_New_String(Lit_9), jrt.File_New_String(Lit_10), A_arbace_box_print_A_const_16);
	lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(Lit_11, Lit_12, A_arbace_box_print_A_const_17); return /*line :32:1*/ lang.IFn_Cast(print_package__3).Invoke_O_O_O__O(Lit_13, Lit_14, A_arbace_box_print_A_const_18) }

func A_arbace_box_print_print_program_A_New() *A_arbace_box_print_print_program_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_print_program_A{}; t.Ctor(); return t }
//line :34:1
func (t *A_arbace_box_print_print_program_A) Ctor() {}
//line :34:1
func (t *A_arbace_box_print_print_program_A) Invoke_O__O(self any) any { var program__1 any = lang.IFn_Cast(A_arbace_box_print_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_21); var print_module__2 any = lang.IFn_Cast(A_arbace_box_print_A_const_9.GetRawRoot__O()).Invoke_O__O(A_arbace_box_print_A_const_22); var opts__3 any = A_arbace_box_print_A_const_19; var p__4 any = lang.IFn_Cast(program__1).Invoke_O_O_O__O(jrt.File_New_String(Lit_15), Lit_6, opts__3);









	lang.IFn_Cast(print_module__2).Invoke_O_O_O_O__O(p__4, jrt.File_New_String(Lit_15), jrt.File_New_String(Lit_16), opts__3); var tmp1 lang.IFn =
	lang.IFn_Cast(A_arbace_box_print_A_const_20.GetRawRoot__O()); var tmp2 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_23.GetRawRoot__O()); var tmp3 any; var tmp4 *lang.Keyword = A_arbace_box_print_A_const_24; var tmp5 *lang.Keyword = A_arbace_box_print_A_const_25; var or__1927000174__auto____5 any = tmp4.Invoke_O__O(tmp5.Invoke_O__O(A_arbace_box_print_A_const_26.Invoke_O__O(p__4))); if jrt.J2g_Truth(or__1927000174__auto____5) { tmp3 = or__1927000174__auto____5 } else { tmp3 = lang.PersistentArrayMap_EMPTY.Ref() }; return tmp1.Invoke_O_O__O(Lit_17, tmp2.Invoke_O__O(tmp3)) }

func A_arbace_box_print__main_A_New() *A_arbace_box_print__main_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_A{}; t.Ctor(); return t }
//line :47:1
func (t *A_arbace_box_print__main_A) Ctor() {}
//line :47:1
func (t *A_arbace_box_print__main_A) DoInvoke_O_O__O(self, p__1463000015__0 any) any { var vec__1463000016__2 any = p__1463000015__0; var cmd__3 any = lang.RT_Nth_O_I_O__O_NoInit(vec__1463000016__2, lang.RT_IntCast_J__I_NoInit(0), nil); var G__1463000019__4_ any = cmd__3; L1:
switch { default: switch lang.Util_Hash_O__I_NoInit(G__1463000019__4_) >> 1 & 1 { case 0: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000019__4_, Lit_1) {

	lang.IFn_Cast(A_arbace_box_print_A_const_27.GetRawRoot__O()).Invoke__O()
//line :48:1
	break L1 }; case 1: if lang.Util_Equiv_O_O__Z_NoInit(G__1463000019__4_, Lit_2) {
		lang.IFn_Cast(A_arbace_box_print_A_const_28.GetRawRoot__O()).Invoke__O()
//line :48:1
		break L1 }; default:
}

	var tmp1 lang.IFn = lang.IFn_Cast(A_arbace_box_print_A_const_33.GetRawRoot__O()); var tmp2 any = A_arbace_box_print_A_const_34; lang.IFn_Cast(A_arbace_box_print_A_const_32.GetRawRoot__O()).Invoke_O__O(tmp1.Invoke_O_O__O(tmp2, A_arbace_box_print_A_const_35.Get__O())); var tmp3 any = A_arbace_box_print__main_fn__1463000020_A_New(); var tmp4 *jrt.Class; var fncls__2 *jrt.Class = A_arbace_box_print__main_fn__1463000020_A_fn_class; if fncls__2 == nil { var fncls__2d *jrt.Class = lang.Compiler_AOT_FnClass_String_Z__Class_NoInit(Lit_3, false); A_arbace_box_print__main_fn__1463000020_A_fn_class = fncls__2d; tmp4 = fncls__2d } else { tmp4 = fncls__2 }; lang.Compiler_AOTFn_New_O_Class_IPersistentMap(tmp3, tmp4, nil).Invoke__O()
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(2))};
	lang.IFn_Cast(A_arbace_box_print_A_const_29.GetRawRoot__O()).Invoke__O();
	jrt.System_Exit_I__V(lang.RT_IntCast_J__I_NoInit(0)); return nil }
//line :51:1
func A_arbace_box_print__main_fn__1463000020_A_New() *A_arbace_box_print__main_fn__1463000020_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print__main_fn__1463000020_A{}; t.Ctor(); return t }
//line :51:1
func (t *A_arbace_box_print__main_fn__1463000020_A) Ctor() {}
//line :51:1
func (t *A_arbace_box_print__main_fn__1463000020_A) Invoke_O__O(self any) any { var tmp1 any; tmp2 := func() (exc jrt.Throwable_I) { defer jrt.Catch(&exc); tmp1 = lang.IFn_Cast(A_arbace_box_print_A_const_30.GetRawRoot__O()).Invoke_O__O(Lit_4); return nil }(); lang.IFn_Cast(A_arbace_box_print_A_const_31.GetRawRoot__O()).Invoke__O(); if tmp2 != nil { panic(tmp2) }; return tmp1 }









type A_arbace_box_print_A struct{ jrt.Object }

var A_arbace_box_print_A_const_pool *jrt.RefArray

var A_arbace_box_print_A_const_0 *lang.Var

var A_arbace_box_print_A_const_1 any

var A_arbace_box_print_A_const_2 *lang.Var

var A_arbace_box_print_A_const_3 *lang.Var

var A_arbace_box_print_A_const_4 *lang.Var

var A_arbace_box_print_A_const_5 any

var A_arbace_box_print_A_const_6 *lang.Var

var A_arbace_box_print_A_const_7 *lang.Var

var A_arbace_box_print_A_const_8 *lang.Var

var A_arbace_box_print_A_const_9 *lang.Var

var A_arbace_box_print_A_const_10 any

var A_arbace_box_print_A_const_11 any

var A_arbace_box_print_A_const_12 any

var A_arbace_box_print_A_const_13 any

var A_arbace_box_print_A_const_14 any

var A_arbace_box_print_A_const_15 any

var A_arbace_box_print_A_const_16 any

var A_arbace_box_print_A_const_17 any

var A_arbace_box_print_A_const_18 any

var A_arbace_box_print_A_const_19 any

var A_arbace_box_print_A_const_20 *lang.Var

var A_arbace_box_print_A_const_21 any

var A_arbace_box_print_A_const_22 any

var A_arbace_box_print_A_const_23 *lang.Var

var A_arbace_box_print_A_const_24 *lang.Keyword

var A_arbace_box_print_A_const_25 *lang.Keyword

var A_arbace_box_print_A_const_26 *lang.Keyword

var A_arbace_box_print_A_const_27 *lang.Var

var A_arbace_box_print_A_const_28 *lang.Var

var A_arbace_box_print_A_const_29 *lang.Var

var A_arbace_box_print_A_const_30 *lang.Var

var A_arbace_box_print_A_const_31 *lang.Var

var A_arbace_box_print_A_const_32 *lang.Var

var A_arbace_box_print_A_const_33 *lang.Var

var A_arbace_box_print_A_const_34 *lang.Var

var A_arbace_box_print_A_const_35 *lang.Var

var A_arbace_box_print_A_init jrt.ClassInit

func A_arbace_box_print_A_Init() { if !A_arbace_box_print_A_init.Done() { A_arbace_box_print_A_init.Run(A_arbace_box_print_A_clinit) } }

func A_arbace_box_print_A_clinit() { A_arbace_box_print_A_clinit_p0(); A_arbace_box_print_A_clinit_p1(); A_arbace_box_print_A_clinit_p2() }

func A_arbace_box_print_A_clinit_p0() { jrt.StartCheck(); A_arbace_box_print_A_const_pool = lang.Compiler_AOT_Pool_String_I__O1_NoInit(Lit_0, 54); A_arbace_box_print_A_const_0 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[18]); A_arbace_box_print_A_const_1 = A_arbace_box_print_A_const_pool.A[19]; A_arbace_box_print_A_const_2 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[20]); A_arbace_box_print_A_const_3 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[21]); A_arbace_box_print_A_const_4 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[22]); A_arbace_box_print_A_const_5 = A_arbace_box_print_A_const_pool.A[23]; A_arbace_box_print_A_const_6 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[24]); A_arbace_box_print_A_const_7 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[25]); A_arbace_box_print_A_const_8 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[26]); A_arbace_box_print_A_const_9 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[27]); A_arbace_box_print_A_const_10 = A_arbace_box_print_A_const_pool.A[28]; A_arbace_box_print_A_const_11 = A_arbace_box_print_A_const_pool.A[29] }

func A_arbace_box_print_A_clinit_p1() { A_arbace_box_print_A_const_12 = A_arbace_box_print_A_const_pool.A[30]; A_arbace_box_print_A_const_13 = A_arbace_box_print_A_const_pool.A[31]; A_arbace_box_print_A_const_14 = A_arbace_box_print_A_const_pool.A[32]; A_arbace_box_print_A_const_15 = A_arbace_box_print_A_const_pool.A[33]; A_arbace_box_print_A_const_16 = A_arbace_box_print_A_const_pool.A[34]; A_arbace_box_print_A_const_17 = A_arbace_box_print_A_const_pool.A[35]; A_arbace_box_print_A_const_18 = A_arbace_box_print_A_const_pool.A[36]; A_arbace_box_print_A_const_19 = A_arbace_box_print_A_const_pool.A[37]; A_arbace_box_print_A_const_20 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[38]); A_arbace_box_print_A_const_21 = A_arbace_box_print_A_const_pool.A[39]; A_arbace_box_print_A_const_22 = A_arbace_box_print_A_const_pool.A[40]; A_arbace_box_print_A_const_23 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[41]); A_arbace_box_print_A_const_24 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[42]); A_arbace_box_print_A_const_25 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[43]) }

func A_arbace_box_print_A_clinit_p2() { A_arbace_box_print_A_const_26 = lang.Keyword_Cast(A_arbace_box_print_A_const_pool.A[44]); A_arbace_box_print_A_const_27 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[45]); A_arbace_box_print_A_const_28 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[46]); A_arbace_box_print_A_const_29 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[47]); A_arbace_box_print_A_const_30 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[48]); A_arbace_box_print_A_const_31 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[49]); A_arbace_box_print_A_const_32 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[50]); A_arbace_box_print_A_const_33 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[51]); A_arbace_box_print_A_const_34 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[52]); A_arbace_box_print_A_const_35 = lang.Var_Cast(A_arbace_box_print_A_const_pool.A[53]) }

func A_arbace_box_print_A_New() *A_arbace_box_print_A { A_arbace_box_print_A_Init(); t := &A_arbace_box_print_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_A) Ctor() {}

func (t *A_arbace_box_print_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_A_class }

func (t *A_arbace_box_print_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_A); return ok }

func A_arbace_box_print_A_Cast(x any) *A_arbace_box_print_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_A_class)) }; return v }



type A_arbace_box_print__main_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_A_fn_class *jrt.Class



type A_arbace_box_print__main_fn__1463000020_A struct{ j2g_header uint64 }

var A_arbace_box_print__main_fn__1463000020_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000004_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000004_A_New() *A_arbace_box_print_eval1463000004_A { t := &A_arbace_box_print_eval1463000004_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000004_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000004_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000004_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000004_A_class }

func (t *A_arbace_box_print_eval1463000004_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000004_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000004_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000004_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000004_A); return ok }

func A_arbace_box_print_eval1463000004_A_Cast(x any) *A_arbace_box_print_eval1463000004_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000004_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000004_A_class)) }; return v }



type A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000004_loading__1927001464__auto____1463000005_A_fn_class *jrt.Class



type A_arbace_box_print_eval1463000008_A struct{ jrt.Object }

func A_arbace_box_print_eval1463000008_A_New() *A_arbace_box_print_eval1463000008_A { t := &A_arbace_box_print_eval1463000008_A{}; t.Ctor(); return t }

func (t *A_arbace_box_print_eval1463000008_A) Ctor() {}

func (t *A_arbace_box_print_eval1463000008_A) Ref() any { if t == nil { return nil }; return t }

func (t *A_arbace_box_print_eval1463000008_A) GetClass__Class() *jrt.Class { return A_arbace_box_print_eval1463000008_A_class }

func (t *A_arbace_box_print_eval1463000008_A) ToString__String() *jrt.String { return jrt.Object_toString(t) }

func (t *A_arbace_box_print_eval1463000008_A) Clone__O() any { return jrt.J2g_ObjectClone(t) }

func (t *A_arbace_box_print_eval1463000008_A) CloneShallow() any { panic(jrt.CloneNotSupported(t)) }

func A_arbace_box_print_eval1463000008_A_InstanceOf(x any) bool { _, ok := x.(*A_arbace_box_print_eval1463000008_A); return ok }

func A_arbace_box_print_eval1463000008_A_Cast(x any) *A_arbace_box_print_eval1463000008_A { if x == nil { return nil }; v, ok := x.(*A_arbace_box_print_eval1463000008_A); if !ok { panic(jrt.ClassCast(x, A_arbace_box_print_eval1463000008_A_class)) }; return v }



type A_arbace_box_print_eval1463000008_fn__1463000009_A struct{ j2g_header uint64 }

var A_arbace_box_print_eval1463000008_fn__1463000009_A_fn_class *jrt.Class



type A_arbace_box_print_print_goroot_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_goroot_A_fn_class *jrt.Class



type A_arbace_box_print_print_program_A struct{ j2g_header uint64 }

var A_arbace_box_print_print_program_A_fn_class *jrt.Class



type A_arbace_box_print_tool_A struct{ j2g_header uint64 }

var A_arbace_box_print_tool_A_fn_class *jrt.Class
